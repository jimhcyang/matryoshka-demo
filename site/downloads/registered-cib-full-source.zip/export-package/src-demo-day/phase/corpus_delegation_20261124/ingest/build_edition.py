"""Register complete source editions in a new index/envelope. No task execution."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WORKSPACE = ROOT.parent
sys.path.insert(0,str(ROOT))
from matryoshka_current import resources as r
from matryoshka_current.index import extend_index, CorpusIndex
from matryoshka_demo.io import digest as shared_digest, offline
from matryoshka_demo.source_view_policy import SUPPLIED_DOCUMENTS_INCLUSIVE, descriptor
from matryoshka_current.supplemental_sources import VERSION


def ref(path):
    path = r.safe_path(WORKSPACE,path)
    return dict(path=r.relative(WORKSPACE,path),sha256=r.file_sha(path))


def source_manifest(source_path, physical_review_path, edition):
    source = r.load_json(source_path)
    review = r.load_json(physical_review_path)
    entry = source["editions"][edition]
    if (source["document_id"] != review["document_id"]
            or source["document_date"] != review["historical_document_date"] or review["edition"] != edition
            or source.get("unknown_text_not_reconstructed") is not True):
        raise ValueError("Full source document and physical review disagree")
    pages_path = r.safe_path(WORKSPACE,entry["pages_ref"]["path"])
    if r.file_sha(pages_path) != entry["pages_ref"]["sha256"]:
        raise ValueError("Full source page ledger changed")
    rows = [json.loads(line) for line in pages_path.read_text().splitlines() if line.strip()]
    markings = {}
    classification = review["classification"]
    if classification.get("cover_historical_marking"):
        markings["1"] = classification["cover_historical_marking"]
    for name,value in classification.items():
        match = re.fullmatch(r"physical_page_([1-9][0-9]*)_historical_marking",name)
        if match:
            markings[match[1]] = value
    stamp = review["release_stamp"]
    document = dict(document_id=source["document_id"],document_date=source["document_date"],record_id=source["record_id"],
        edition=edition,original_source_edition_id=rows[0]["source_edition_id"],
        pages_ref=entry["pages_ref"],pdf_ref=entry["local_pdf_ref"],physical_page_count=entry["physical_page_count"],
        structured_classification=source["classification_level_from_structured_manifest"],
        distribution_controls=source["distribution_controls_from_structured_manifest"],historical_page_markings=markings,
        document_historical_marking=classification.get("cover_historical_marking"),
        classification_review_ref=ref(physical_review_path),source_document_ref=ref(source_path),
        source_release=dict(edition=edition,release_date=stamp["release_stamp_date"],release_mark=stamp["release_record_mark"],
            verbatim_release_stamp=stamp["verbatim"],public_release=True,
            admission_basis="USER_AUTHORIZED_REGISTERED_FULL_PUBLIC_DOCUMENT_EDITION"))
    return dict(version=VERSION,corpus="cib",documents=[document])


def build(args):
    if not args.register_released_edition:
        raise ValueError("Explicit authorization to register the complete released edition is required")
    output = r.safe_path(WORKSPACE,args.output,must_exist=False)
    if not output.is_relative_to(HERE):
        raise ValueError("This builder writes only its new ingest scope")
    base_path = r.safe_path(WORKSPACE,args.execution_refs)
    base = r.load_json(base_path)
    registry_path = r.safe_path(ROOT,base["registry_ref"]["path"])
    if r.file_sha(registry_path) != base["registry_ref"]["sha256"]:
        raise ValueError("Base execution registry changed")
    execution = r.load_json(registry_path)
    if execution["sha256"] != shared_digest({k:v for k,v in execution.items() if k != "sha256"}):
        raise ValueError("Base execution envelope changed")
    parent_path = r.safe_path(WORKSPACE,args.parent_registry)
    parent = r.load_json(parent_path)
    if parent != execution["corpora"]["cib"]["native_registry"]:
        raise ValueError("Parent registry is not the explicit base execution resource")
    manifest_path = output/"registered_documents.json"
    r.immutable_json(manifest_path,source_manifest(r.safe_path(WORKSPACE,args.source_document),
        r.safe_path(WORKSPACE,args.physical_review),args.edition))
    child = r.create_supplied_registry(WORKSPACE,ref(parent_path),ref(manifest_path))
    child_path = output/"native-cib-registry.json"
    r.write_registry(child,child_path)
    native = extend_index(WORKSPACE,parent,base["index_refs"]["cib"]["native_index_ref"],child,
        output/"indexes",minimum_free_bytes=int(args.minimum_free_gib*1024**3))
    envelope = r.create_execution_registry(WORKSPACE,child,
        {k:base["index_refs"][k]["native_index_ref"] for k in ("iran","vietnam")})
    envelope_path = output/"execution-registry.json"
    r.immutable_json(envelope_path,envelope)
    refs = dict(version="current-execution-resource-handshake/1",
        registry_ref=dict(path=str(envelope_path.relative_to(ROOT)),sha256=r.file_sha(envelope_path)),
        index_refs={k:r.execution_index_ref(envelope,k,native if k == "cib" else base["index_refs"][k]["native_index_ref"])
            for k in ("cib","iran","vietnam")},resource_id=child["resource_id"],
        source_edition_id=child["source_edition_id"],root_contract=base["root_contract"],api_calls=0)
    refs_path = output/"execution_refs.json"
    r.immutable_json(refs_path,refs)
    with CorpusIndex(WORKSPACE,child,native) as index:
        rows = index.supplied.pages()
        if len(rows) != sum(d["physical_page_count"] for d in index.supplied.documents.values()):
            raise ValueError("Not all supplied pages entered the bound index")
    receipt = dict(version="registered-source-edition-build/1",execution_refs=ref(refs_path),
        source_edition_id=child["source_edition_id"],canonical_KG_resource_id_unchanged=child["resource_id"] == parent["resource_id"],
        alias_graph_hierarchy_ids_unchanged=all(child[k] == parent[k] for k in ("alias_id","graph_id","hierarchy_id")),
        supplied_pages=len(rows),new_policy=descriptor(SUPPLIED_DOCUMENTS_INCLUSIVE),
        parent_index_unchanged=True,semantic_graph_tables_modified=False,api_calls=0,native_executions=0,
        registered_manifest=ref(manifest_path),source_registry=ref(child_path),native_index_ref=native,
        builder_ref=ref(Path(__file__)))
    r.immutable_json(output/"BUILD_RECEIPT.json",receipt)
    print(json.dumps(receipt,indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execution-refs",required=True)
    parser.add_argument("--parent-registry",required=True)
    parser.add_argument("--source-document",required=True)
    parser.add_argument("--physical-review",required=True)
    parser.add_argument("--edition",choices=("earlier","later"),required=True)
    parser.add_argument("--output",required=True)
    parser.add_argument("--register-released-edition",action="store_true")
    parser.add_argument("--minimum-free-gib",type=float,default=8.)
    with offline():
        build(parser.parse_args())
