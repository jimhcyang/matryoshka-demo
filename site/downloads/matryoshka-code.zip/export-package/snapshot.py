"""Copy read-only implementation inputs into this isolated exporter package."""
import ast
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PACKAGE = ROOT.parent / 'matryoshka_demo_site'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=ROOT)
    parser.add_argument('--package-root', type=Path, default=PACKAGE)
    parser.add_argument('--output', type=Path, default=HERE)
    parser.add_argument('--backend-only', action='store_true')
    args = parser.parse_args()
    source_root, package, output = args.source_root.resolve(), args.package_root.resolve(), args.output.absolute()
    assert output.is_relative_to(HERE) and output.resolve() == output
    if output != HERE:
        output.mkdir(parents=True, exist_ok=False)
    pairs = [] if args.backend_only else [(source_root / 'experiments/full_resume_20261120/deploy/export_narrative.py', output / 'export_narrative.py')]
    local, pending = set(), ['matryoshka_narrative', 'matryoshka_current', 'matryoshka_demo', 'matryoshka_next']
    while pending:
        name = pending.pop()
        local.add(name)
        for source in sorted((source_root / name).rglob('*.py')):
            if '__pycache__' in source.parts:
                continue
            pairs.append((source, output / 'backend' / source.relative_to(source_root)))
            for node in ast.walk(ast.parse(source.read_text())):
                modules = [node.module] if isinstance(node, ast.ImportFrom) and node.level == 0 and node.module else (
                    [a.name for a in node.names] if isinstance(node, ast.Import) else [])
                for module in modules:
                    dependency = module.split('.')[0]
                    if (source_root / dependency / '__init__.py').is_file() and dependency not in local and dependency not in pending:
                        pending.append(dependency)
    if not args.backend_only:
        for name in ('export_current_replays.py', 'export_replays.py', 'validate_publication.py'):
            pairs.append((package / 'tools' / name, output / 'vendor/tools' / name))
        for name in ('public-runtime.js', 'replay.html', 'replay.js'):
            pairs.append((package / 'runtime' / name, output / 'vendor/runtime' / name))
    for source in sorted((source_root / 'contracts').rglob('*')):
        if source.is_file():
            pairs.append((source, output / 'backend' / source.relative_to(source_root)))
    rows = []
    for source, target in pairs:
        raw = source.read_bytes()
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(raw)
        assert source.read_bytes() == raw
        rows.append(dict(source=str(source), target=str(target.relative_to(output)), sha256=hashlib.sha256(raw).hexdigest()))
    for row in rows:
        assert hashlib.sha256(Path(row['source']).read_bytes()).hexdigest() == row['sha256']
    (output / 'snapshot.json').write_text(json.dumps(dict(packages=sorted(local), files=rows, api_calls=0, canonical_backend=False), indent=2) + '\n')
    print(json.dumps(dict(files=len(rows), packages=sorted(local))))


if __name__ == '__main__':
    main()
