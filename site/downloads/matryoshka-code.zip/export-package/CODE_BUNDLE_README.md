# Scoped S2 Release Code

Actual scoped engine runs use an explicit S2 policy; they are not unchanged canonical native executions. Gold is unknown. Archived lexical results remain separate. The isolated namespace contains only explicitly pinned Python files and allowlisted source metadata. No context corpus, API receipts, ledger or private execution packet is bundled. See patch/release/scoped_s2_v03/HANDOFF.md.
