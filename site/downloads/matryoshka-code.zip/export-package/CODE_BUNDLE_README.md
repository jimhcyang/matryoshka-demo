# Matryoshka Code Snapshot

This archive accompanies the 23 November 2026 source-bound workbench release.
The public repository serves the saved examples and corpus maps without the
private research workspace. This code archive additionally records the inference,
source inspection, scoring, Live, and export implementations behind that release.

## Active Paths

- `backend/matryoshka_narrative/`: query parsing, deterministic retrieval,
  matching, task decisions, terminal scores, and detached model digest.
- `backend/matryoshka_current/`: source and graph adapters and source inspection.
- `backend/phase/motion_login_20261122/live/`: authenticated private Live backend.
- `backend/scripts/start_live_local.py`: local Live launcher.
- `interactive/site/`: the current browser interface.
- `ci/`: publication integrity and managed Chromium checks.

Selected examples have fresh full native executions under one pinned code epoch.
Historical files under `history/` document previous implementations; they are not
the active implementation. Existing source/version labels in those files are
retained rather than rewritten retrospectively.

## Source And Decision Boundaries

Inference sees the visible input, not a supplied redaction answer. Retrieval uses
its parsed facts, not a whole-query search. CIB admits earlier-release or jointly
visible text through the source day, including the earlier origin version; later
text remains ineligible. Iran and Vietnam admit eligible CONFIDENTIAL documents,
excluding the whole originating SECRET cable and document-wide handling vetoes.

The matcher preserves exact source offsets while analyzing line-wrapped cable
syntax. Terminal evidence-and-fit scores are deterministic indices, not
probabilities. A ranked contextual suggestion is not an evidence-backed recovery.
The final model digest is generated after the native decision and cannot change
that decision.

## Running And Reproducing

For the self-contained saved website, use `release-tools/serve_static.py` in the
public repository; its README gives the command. Large public graph assets are
bound to immutable repository commits and verified by content hashes.

New native execution additionally needs the declared corpus inputs, resource
registry, Python dependencies, and a privately supplied provider credential.
Those private inputs and credentials are deliberately not included in this code
download. Do not present an import-only test as reproduction of a native result.
The public guide and release manifests identify the saved results and the
implementation versions actually used.

Live is optional and requires a separately configured authenticated backend.
Never embed a provider key, a reversibly split key, or a shared backend password
in the static site. Completed public Live envelopes are retained in bounded
browser-tab history; credentials are not stored with those envelopes.
