"""Bounded actual-byte prefix preflight. Read-only dataset mount, not offline approval."""
import gzip
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import threading
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright, expect
from export_narrative import adapt_runtime, encoded, sha, ROOT

HERE = Path(__file__).resolve().parent
PREFIX = '/nested/matryoshka-demo/'
STAGE = HERE / 'stage_v06_08'
MAPS = ROOT.parent / 'matryoshka_demo_site'


def main():
    out = HERE / 'prefix-probe-01'
    out.mkdir(exist_ok=False)
    checkpoint = json.loads((STAGE / 'case_checkpoint.json').read_bytes())
    entries = checkpoint['entries']
    for entry in entries.values():
        if entry.get('external_url'):
            relative = '/'.join(urlsplit(entry.pop('external_url')).path.split('/')[-3:])
            entry['path'] = '__graph_mount/' + relative
    packets = {}
    parity = json.loads((HERE / 'stage_v06_05/slots-parity.json').read_bytes())
    for i, item in enumerate(parity):
        params = dict(offset='0', limit='32', scan='0', q='', **{})
        params.update(item['params'])
        from urllib.parse import urlencode
        key = '/api/current/slots-v1?' + urlencode(sorted(params.items()))
        raw = encoded(item['expected'])
        wire = gzip.compress(raw, mtime=0)
        path = '__probe_packets/' + str(i) + '.json.gz'
        packets[path] = wire
        entries[key] = dict(path=path, encoding='gzip', sha256=sha(raw), wire_sha256=sha(wire), mime='application/json')
    index = encoded(dict(version='matryoshka-public-api-index/1', entries=entries))
    runtime = adapt_runtime((HERE / 'vendor/runtime/public-runtime.js').read_bytes())
    names = {p.name for root in (ROOT/'experiments/full_resume_20261120/ui', ROOT/'narrative_demo/web') for p in root.iterdir() if p.is_file()}
    leaked = []
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_): pass
        def do_GET(self):
            path = urlsplit(self.path).path
            if not path.startswith(PREFIX):
                self.send_error(404);return
            name = path[len(PREFIX):]
            mime = 'application/octet-stream'
            if name.startswith('api/'):
                leaked.append(name)
            if name == 'data/api-index.json': raw,mime=index,'application/json'
            elif name == 'runtime/public-runtime.js': raw,mime=runtime,'text/javascript'
            elif name in packets: raw=packets[name]
            elif name.startswith('__graph_mount/'):
                p = MAPS / name.removeprefix('__graph_mount/')
                assert p.resolve() == p and p.is_relative_to(MAPS / 'datasets')
                raw=p.read_bytes()
            elif (STAGE/'site'/name).is_file(): raw=(STAGE/'site'/name).read_bytes()
            else:
                relative = name.removeprefix('narrative-assets/')
                p = next((root/relative for root in (ROOT/'experiments/full_resume_20261120/ui', ROOT/'narrative_demo/web') if (root/relative).is_file()), None)
                if p is None:
                    self.send_error(404);return
                text=p.read_text()
                if p.suffix=='.html':
                    text=re.sub(r'\b(href|src)=(["\'])(/(?!/)[^"\']*)\2',lambda m:m[1]+'='+m[2]+m[3][1:]+m[2],text)
                    text=text.replace('<head>','<head><script src="runtime/public-runtime.js" data-index="data/api-index.json" data-index-sha256="'+sha(index)+'"></script>')
                    mime='text/html'
                elif p.suffix=='.js':
                    text=re.sub(r"(\bimport\s*\(\s*|\bfrom\s*)(['\"])/(?!/)([^'\"]+)\2",lambda m:m[1]+m[2]+'./'+m[3]+m[2],text)
                    for css in (n for n in names if n.endswith('.css')):
                        text=text.replace("'/"+css+"'","'./"+css+"'").replace('"/'+css+'"','"./'+css+'"')
                    mime='text/javascript'
                elif p.suffix=='.css': mime='text/css'
                raw=text.encode()
            self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    http=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    thread=threading.Thread(target=http.serve_forever,daemon=True);thread.start()
    rows=[]
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(headless=True)
            for corpus in ('cib','iran','vietnam'):
                context=browser.new_context(reduced_motion='reduce',viewport=dict(width=1440,height=1000))
                page=context.new_page();errors=[]
                page.on('pageerror',lambda e:errors.append(str(e)))
                page.goto('http://127.0.0.1:'+str(http.server_port)+PREFIX+'graph-full-v6.html?corpus='+corpus,wait_until='domcontentloaded')
                try:
                    page.wait_for_function("()=>document.body.dataset.graphReady==='true'",timeout=90000)
                    rows.append(dict(corpus=corpus,pass_=True,nodes=page.evaluate('()=>state.panels.current.nodes.length'),errors=errors))
                except Exception as e:
                    rows.append(dict(corpus=corpus,pass_=False,error=str(e),body=page.locator('body').inner_text()[-1500:],errors=errors))
                page.screenshot(path=str(out/(corpus+'.png')))
                context.close()
            browser.close()
    finally:
        http.shutdown();http.server_close();thread.join()
    result=dict(cells=rows,success=all(r['pass_'] for r in rows) and not leaked, leaked_api_requests=leaked,
        scope='PREFIX PREFLIGHT ONLY: actual frozen UI/case packets, exact read-only mounted dataset bytes. Not a self-contained packed-site or full Slots QA pass.',
        model_api_calls=0,native_executions=0,managed_chromium_headless_shell=True,browser_closed=True)
    (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    if not result['success']:raise SystemExit(1)


if __name__=='__main__':main()
