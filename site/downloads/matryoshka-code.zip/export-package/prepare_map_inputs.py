"""Freeze the original map export independently of the replaceable live site."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
INDEX_SHA256 = "a4f08ac865bb21faed97e1792fc2c84baba0e8483f5fb92c7604fec96f5e30f0"


def checked_tree(root):
    assert root.resolve() == root and root.is_dir()
    paths = list(root.rglob("*"))
    assert all(not p.is_symlink() and p.resolve() == p for p in paths)
    return sum(p.is_file() for p in paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-site", type=Path, required=True)
    parser.add_argument("--datasets", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    original, datasets, output = (p.absolute() for p in (args.original_site, args.datasets, args.output))
    assert output.resolve() == output and output.is_relative_to(HERE) and not output.exists()
    assert not any(output.is_relative_to(source) or source.is_relative_to(output)
                   for source in (original, datasets)), "Input and output trees must not overlap"
    counts = dict(site=checked_tree(original), datasets=checked_tree(datasets))
    index = (original / "data/api-index.json").read_bytes()
    assert hashlib.sha256(index).hexdigest() == INDEX_SHA256, "Original map index pin changed"
    assert shutil.disk_usage(HERE).free >= 8 * 1024 ** 3
    output.mkdir()
    # These are immutable inputs. Hard links save storage; the exporter only reads them.
    shutil.copytree(original, output / "site", copy_function=os.link)
    shutil.copytree(datasets, output / "datasets", copy_function=os.link)
    assert (output / "site/data/api-index.json").read_bytes() == index
    receipt = dict(version="immutable-original-map-inputs/1", original_map_index_sha256=INDEX_SHA256,
        files=counts, hard_linked_read_only_inputs=True, source_bytes_modified=False,
        live_site_reconfigured=False, native_runs=0, api_calls=0)
    (output / "input_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
