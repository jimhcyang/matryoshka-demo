"""Exact consumer-reference closure of the three active map descriptors."""
import json
import re


def active_graph_keys(maps, entries):
    selected = set()
    for corpus in ('cib', 'iran', 'vietnam'):
        base = '/graph-assets-v4/' + corpus + '/'
        assets = {key[len(base):]: key for key in entries if key.startswith(base)}
        metadata = json.loads(maps.packet('/api/graph-v4-viewer?corpus=' + corpus)[0])
        active = {'current_earlier', 'current_later'} if corpus == 'cib' else {'current_redaction', 'current_later'}
        bootstrap = (metadata['comparison_asset'], metadata['search_asset'])
        documents = [json.loads(maps.packet(base + name)[0]) for name in bootstrap]
        views = set(documents[0]['views'])
        found = set(bootstrap)

        def walk(value, parent=None):
            if isinstance(value, dict):
                for key, child in value.items():
                    if key not in {'bytes', 'view_bytes', 'evidence_view_bytes'} and key not in views - active:
                        walk(child, value)
            elif isinstance(value, list):
                for child in value:
                    walk(child, parent)
            elif isinstance(value, str):
                if value in assets:
                    found.add(value)
                elif '{shard}' in value:
                    pattern = re.escape(value).replace(r'\{shard\}', r'[0-9]{2}')
                    names = [name for name in assets if re.fullmatch(pattern, name)]
                    assert names, 'Declared graph shard template has no exact bound files'
                    if isinstance(parent, dict) and 'shard_count' in parent:
                        assert len(names) == parent['shard_count']
                    found.update(names)

        for value in documents:
            walk(value)
        assert set(bootstrap) <= found
        selected.update(assets[name] for name in found)
    return selected
