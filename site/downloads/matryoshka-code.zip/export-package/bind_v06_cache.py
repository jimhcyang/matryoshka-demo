"""Record the exact observed v06_04 invocation selectors beside its sealed bytes."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


if __name__ == '__main__':
    stage = HERE / 'stage_v06_04'
    raw = (stage / 'case_checkpoint.json').read_bytes()
    checkpoint = json.loads(raw)
    expected = json.loads((ROOT / 'experiments/full_resume_20261120/publication_preview_v06/report_ref.json').read_text())
    assert checkpoint['report_ref'] == expected and len(checkpoint['coverage']) == 14
    # These are the actual CLI inputs from build_v06.py, not a substituted final publication.
    value = dict(checkpoint_sha256=hashlib.sha256(raw).hexdigest(),
        casebook_ref=json.loads((ROOT / 'experiments/full_resume_20261120/publication_preview_v06/casebook_ref.json').read_text()),
        digest_ref=json.loads((ROOT / 'experiments/full_resume_20261120/digests_preview_v06/index_ref.json').read_text()),
        map_index_sha256='a4f08ac865bb21faed97e1792fc2c84baba0e8483f5fb92c7604fec96f5e30f0', node_scope='routes')
    with (stage / 'case_cache_binding.json').open('x') as stream:
        stream.write(json.dumps(value, sort_keys=True, separators=(',', ':')))
    print(value['checkpoint_sha256'])
