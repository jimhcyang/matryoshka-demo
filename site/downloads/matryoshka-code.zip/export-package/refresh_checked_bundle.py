"""Create a new candidate for a code-only QA fixture repair; preserve the old seal."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--bundle', type=Path, required=True)
    args = parser.parse_args()
    source, output, bundle = args.source.resolve(), args.output.absolute(), args.bundle.resolve()
    assert all(p.is_relative_to(HERE) for p in (source, output, bundle))
    assert source.is_dir() and not output.exists() and bundle.is_file()
    assert shutil.disk_usage(HERE).free > 8 * 1024**3
    before = hashlib.sha256((source / 'site/release-manifest.json').read_bytes()).hexdigest()
    shutil.copytree(source, output)
    for name in ('release-manifest.json', 'downloads/matryoshka-code.zip',
                 'downloads/matryoshka-code-manifest.json'):
        (output / 'site' / name).unlink()
    subprocess.run([sys.executable, str(HERE / 'attach_code_bundle.py'), '--stage', str(output),
                    '--bundle', str(bundle)], check=True)
    subprocess.run([sys.executable, str(HERE / 'seal_candidate.py'), '--stage', str(output)], check=True)
    assert hashlib.sha256((source / 'site/release-manifest.json').read_bytes()).hexdigest() == before
    changed = []
    for path in sorted((source / 'site').rglob('*')):
        if path.is_file():
            relative = path.relative_to(source / 'site')
            if path.read_bytes() != (output / 'site' / relative).read_bytes():
                changed.append(str(relative))
    assert set(changed) == {'downloads/matryoshka-code.zip', 'downloads/matryoshka-code-manifest.json',
                            'export-lineage.json', 'publication.json', 'release-manifest.json'}
    receipt = dict(source_manifest_sha256=before, candidate_manifest_sha256=hashlib.sha256(
        (output / 'site/release-manifest.json').read_bytes()).hexdigest(), changed_files=changed,
        native_data_or_ui_modified=False, source_seal_unchanged=True, api_calls=0, native_executions=0)
    (output / 'bundle_refresh_receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
