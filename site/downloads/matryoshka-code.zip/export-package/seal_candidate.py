"""Create a fresh inventory without inheriting old privacy or publication approval."""
import argparse
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('release_manifest_gate', HERE / 'ci/validate_manifest.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    args = parser.parse_args()
    stage = args.stage.resolve()
    assert stage.is_relative_to(HERE)
    receipt = json.loads((stage / 'stage_receipt.json').read_bytes())
    site = stage / 'site'
    lineage = json.loads((site / 'export-lineage.json').read_bytes())
    lineage.pop('backend_root', None)
    lineage['backend_snapshot'] = dict(tree_sha256=receipt['backend_code_sha256'], canonical=False,
        scope='Bundled implementation snapshot; historical native execution versions remain recorded per case.')
    (site / 'export-lineage.json').write_bytes(gate.encoded(lineage))
    publication = json.loads((site / 'publication.json').read_bytes())
    if 'graph_data_manifest' in publication:
        publication['original_graph_source_reference'] = publication.pop('graph_data_manifest')
    publication['privacy_approval_inherited'] = False
    publication['release_qualified'] = False
    publication['files'] = [r for r in gate.inventory(site) if r['path'] != 'publication.json']
    (site / 'publication.json').write_bytes(gate.encoded(publication))
    value = gate.make(site, receipt)
    total = sum(r['bytes'] for r in value['files'])
    assert total < 900_000_000 and max(r['bytes'] for r in value['files']) < 100_000_000
    print(json.dumps(dict(site=str(site), bytes=total, manifest_sha256=gate.sha((site / 'release-manifest.json').read_bytes()), publish_authorized=False)))


if __name__ == '__main__':
    main()
