"""Create a deterministic code-only exporter/backend bundle with contained imports."""
import argparse
import hashlib
from importlib.metadata import version
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--backend-root', type=Path, default=HERE / 'backend')
    parser.add_argument('--output', type=Path, default=HERE / 'backend-export-code-v01.zip')
    args = parser.parse_args()
    backend, output = args.backend_root.resolve(), args.output.absolute()
    assert backend.is_relative_to(HERE) and backend.is_dir()
    assert output.is_relative_to(HERE) and not output.exists()
    selected = []
    excluded_inputs = {'contracts/planning_v2/masked_examples.json'}
    selected.extend(p for p in backend.rglob('*') if p.is_file() and '__pycache__' not in p.parts
        and p.relative_to(backend).as_posix() not in excluded_inputs)
    selected.extend(p for p in (HERE / 'vendor').rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    selected.extend(HERE / name for name in ('export_narrative.py', 'field_guide.py', 'static_slots.py', 'slot-runtime.js', 'packet_pack.py',
        'fragment_reader.py', 'structural_pack.py', 'resume_support.py', 'same_repo.py', 'graph_closure.py', 'graph_layer.py', 'build_v06.py', 'serve_static.py',
        'response_cache.py', 'case_progress.py', 'build_release.py', 'test_export.py', 'test_same_repo.py',
        'browser_qa.py', 'snapshot.py', 'prepare_map_inputs.py', 'test_map_inputs.py', 'seal_candidate.py', 'check_code_bundle.py', 'attach_code_bundle.py', 'finish_assets.py'))
    source_snapshot = backend.parent / 'snapshot.json'
    if source_snapshot.is_file():
        selected.append(source_snapshot)
    selected.extend(p for p in (HERE / 'ci').glob('*') if p.is_file())
    for relative in ('requirements-readonly.txt', 'CODE_BUNDLE_README.md'):
        selected.append(HERE / relative)
    rows = []
    with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for p in sorted(selected):
            raw = p.read_bytes()
            if p == source_snapshot:
                value = json.loads(raw)
                for row in value.get('files', []):
                    row['source'] = 'SOURCE_ROOT/' + row['target'].removeprefix('backend/')
                    row['bundled'] = row['target'].removeprefix('backend/') not in excluded_inputs
                value['source_paths'] = 'RELATIVE_SOURCE_ROOT_TAGS_NO_LOCAL_ABSOLUTE_PATHS'
                raw = (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()
            name = ('backend-source-snapshot.json' if p == source_snapshot else
                'backend/' + str(p.relative_to(backend)) if p.is_relative_to(backend) else str(p.relative_to(HERE)))
            item = zipfile.ZipInfo('export-package/' + name, date_time=(2026, 11, 21, 0, 0, 0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.external_attr = 0o100644 << 16
            archive.writestr(item, raw)
            rows.append(dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
    receipt = dict(files=rows, code_only=True, proprietary_input_corpora_or_keys_included=False,
        backend_tree_sha256=hashlib.sha256(json.dumps({str(p.relative_to(backend)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(backend.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py', '.json', '.txt'}},
            sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        source_snapshot_included=source_snapshot.is_file(),
        public_snapshot_metadata_contains_local_absolute_paths=False,
        excluded_corpus_derived_inputs=[dict(path=relative, sha256=hashlib.sha256((backend / relative).read_bytes()).hexdigest(),
            reason='Corpus-derived authoring fixture; not needed by saved replay, supplied separately for optional regeneration') for relative in sorted(excluded_inputs)],
        package_imports_contained=True, third_party_dependencies={n: version(n) for n in ('numpy', 'jsonschema')},
        saved_replay_server_requires_only_python_stdlib=True, original_backend_code_modified=False,
        api_calls=0, native_executions=0)
    output.with_suffix('.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(files=len(rows), zip_bytes=output.stat().st_size, output=str(output))))


if __name__ == '__main__':
    main()
