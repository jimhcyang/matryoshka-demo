"""Attach an audited code-only ZIP to a completed raw stage, before sealing."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--bundle', type=Path, required=True)
    args = parser.parse_args()
    stage, bundle = args.stage.resolve(), args.bundle.resolve()
    assert stage.is_relative_to(HERE) and bundle.is_relative_to(HERE)
    assert not (stage / 'site/release-manifest.json').exists(), 'Do not mutate a sealed stage'
    receipt = json.loads((stage / 'stage_receipt.json').read_bytes())
    code = json.loads(bundle.with_suffix('.json').read_bytes())
    assert code['backend_tree_sha256'] == receipt['backend_code_sha256']
    raw = bundle.read_bytes()
    assert len(raw) < 100_000_000
    target = stage / 'site/downloads/matryoshka-code.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_bytes(raw)
    code_raw = encoded(code)
    (target.parent / 'matryoshka-code-manifest.json').write_bytes(code_raw)
    ref = dict(path='downloads/matryoshka-code.zip', sha256=sha(raw), bytes=len(raw),
        manifest_path='downloads/matryoshka-code-manifest.json', manifest_sha256=sha(code_raw),
        source_backend_tree_sha256=code['backend_tree_sha256'], code_only=True)
    receipt['code_bundle'] = ref
    (stage / 'stage_receipt.json').write_bytes(encoded(receipt))
    lineage_path = stage / 'site/export-lineage.json'
    lineage = json.loads(lineage_path.read_bytes())
    lineage['code_bundle'] = ref
    lineage_path.write_bytes(encoded(lineage))
    print(json.dumps(ref))


if __name__ == '__main__':
    main()
