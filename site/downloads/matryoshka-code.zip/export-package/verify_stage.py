"""Static transport and source-identity audit, never release qualification."""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

from packet_pack import read_packed

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    stage, out = args.stage.resolve(), args.output.absolute()
    assert stage.is_relative_to(HERE) and out.is_relative_to(HERE) and not out.exists()
    site = stage / 'site'
    receipt = json.loads((stage / 'stage_receipt.json').read_text())
    entries = json.loads((site / 'data/api-index.json').read_text())['entries']
    report_raw = (ROOT / receipt['source_report_ref']['path']).read_bytes()
    assert sha(report_raw) == receipt['source_report_ref']['sha256']
    assert report_raw == (site / 'data/report-v6.json').read_bytes()
    report = json.loads(report_raw)
    seen, physical_bytes, checked = set(), 0, 0
    for key, entry in entries.items():
        if entry.get('external_url') or entry['path'] in seen:
            continue
        seen.add(entry['path'])
        path = site / entry['path']
        assert path.resolve() == path and path.is_file()
        wire = path.read_bytes()
        if entry['encoding'] == 'fragment-dag':
            assert sha(wire) == entry['manifest_sha256']
            pack = json.loads(wire)
            previous = 0
            for ref in pack['chunks']:
                raw = path.parent.joinpath(ref['path']).read_bytes()
                assert sha(raw) == ref['wire_sha256']
                decoded = gzip.decompress(raw)
                assert sha(decoded) == ref['sha256decoded']
                chunk = json.loads(decoded)
                assert chunk['first_id'] == previous + 1 == ref['first_id']
                for i, pieces in enumerate(chunk['fragments'], previous + 1):
                    assert len(pieces) % 2 == 1
                    assert all(isinstance(v, str) and v.isascii() if n % 2 == 0 else isinstance(v, int) and 1 <= v < i for n, v in enumerate(pieces))
                previous = ref['last_id']
                physical_bytes += len(raw)
            for root in pack['assets'].values():
                assert root['encoding'] == 'fragment-dag' and root['decoded_bytes'] <= 512 * 1024**2
                assert all(0 <= i < len(pack['chunks']) for i in root['dependencies'])
        else:
            assert sha(wire) == entry['wire_sha256']
            raw = gzip.decompress(wire) if entry['encoding'] == 'gzip' else wire
            assert sha(raw) == entry['sha256']
        physical_bytes += len(wire)
        checked += 1

    def read(entry):
        if entry['encoding'] == 'fragment-dag':
            return json.loads(read_packed(site, entry))
        raw = (site / entry['path']).read_bytes()
        return json.loads(gzip.decompress(raw) if entry['encoding'] == 'gzip' else raw)

    cases, native = [], []
    for row in report['cases']:
        cases.append(row['case']['case_id'])
        for config, item in row['configurations'].items():
            original_raw = (ROOT / item['native_checkpoint']['path']).read_bytes()
            assert sha(original_raw) == item['native_checkpoint']['sha256']
            original = json.loads(gzip.decompress(original_raw) if original_raw[:2] == b'\x1f\x8b' else original_raw)
            matches = [entry for key, entry in entries.items() if key.startswith('/api/current/native-v6?')
                       and 'case_id=' + row['case']['case_id'] + '&' in key and 'config=' + config + '&' in key]
            assert len(matches) == 1
            actual = read(matches[0])['native']
            for field in ('version', 'result', 'case', 'public_case', 'binding', 'code_pins', 'native_checksum'):
                assert actual[field] == original[field], (row['case']['case_id'], config, field)
            native.append(dict(case_id=row['case']['case_id'], config=config, version=actual['version'], unchanged_core_fields=True))
    for corpus in ('cib', 'iran', 'vietnam'):
        binding = read(entries['/api/graph-v4-viewer?corpus=' + corpus])
        catalog = read(entries['/data/slots/' + corpus + '.json'])
        assert catalog['status']['coverage']['complete'] and catalog['status']['hidden_values_read'] is False
        assert catalog['status']['graph_run_id'] == binding['graph_run_id']
        assert catalog['status']['hierarchy_run_id'] == binding['hierarchy_run_id']
    book = read(entries['/api/current/casebook'])
    assert len(cases) == 14 and len(book['primary']) == 9 and len(book['special_redactions']) == 5
    assert (site / 'swedish-study-data-v02.json').is_file() and not (site / 'swedish-study-data.json').exists()
    result = dict(success=True, source_report_ref=receipt['source_report_ref'], cases=cases, native=native,
        physical_transports_checked=checked, physical_transport_bytes=physical_bytes, routes=len(entries),
        encodings=dict(Counter(e['encoding'] for e in entries.values())),
        note='All stored transport hashes/DAG backward references checked; native core fields checked against original pinned records. Browser verifies reconstructed selected response hashes; this is not research/publication qualification.',
        api_calls=0, native_executions=0)
    out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('cases', 'native')}))


if __name__ == '__main__':
    main()
