"""Real static pages and saved packets at a nested Pages path, managed shell only."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import threading
import traceback
from urllib.parse import parse_qs, urlencode, urlsplit

from playwright.sync_api import expect, sync_playwright
from serve_static import server

HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def packet(site, entry):
    if entry['encoding'] == 'fragment-dag':
        from packet_pack import read_packed
        return json.loads(read_packed(site, entry))
    raw = (site / entry['path']).read_bytes()
    return json.loads(gzip.decompress(raw) if entry['encoding'] == 'gzip' else raw)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--site', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--parity', type=Path, required=True)
    parser.add_argument('--datasets-root', type=Path)
    args = parser.parse_args()
    site, out = args.site.resolve(), args.output.absolute()
    assert site.is_relative_to(HERE) and out.is_relative_to(HERE) and not out.exists()
    out.mkdir()
    index = json.loads((site / 'data/api-index.json').read_bytes())
    from same_repo import dataset
    for key, entry in index['entries'].items():
        if entry.get('external_url'):
            dataset(key, entry)
    report = json.loads((site / 'data/report-v6.json').read_bytes())
    entries = index['entries']
    leaked, external = [], []
    http = server(site, prefix='/nested/matryoshka-demo/', logs=leaked, datasets_root=args.datasets_root)
    thread = threading.Thread(target=http.serve_forever, daemon=True)
    thread.start()
    origin = 'http://127.0.0.1:' + str(http.server_port)
    base = origin + '/nested/matryoshka-demo/'
    result = dict(started_utc=datetime.now(timezone.utc).isoformat(), cells=[], transport=[], errors=[],
        site=str(site.relative_to(HERE)), index_sha256=sha((site / 'data/api-index.json').read_bytes()),
        source_report_sha256=sha((site / 'data/report-v6.json').read_bytes()),
        api_calls=0, native_executions=0, managed_chromium_headless_shell=True, response_interception=False)

    def cell(browser, name, operation, mobile=False):
        context = browser.new_context(viewport=dict(width=390, height=844) if mobile else dict(width=1440, height=1000), reduced_motion='reduce')
        context.route('**/*', lambda route: route.continue_() if route.request.url.startswith(origin + '/') or route.request.url.startswith('blob:') else (external.append(route.request.url), route.abort())[-1])
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        row = dict(name=name, mobile=mobile)
        try:
            operation(page, row)
            assert not errors, errors
            row['pass'] = True
        except Exception:
            row['pass'] = False
            row['error'] = traceback.format_exc()
        row['pageerrors'] = errors
        page.screenshot(path=str(out / (name + '.png')))
        context.close()
        result['cells'].append(row)
        (out / 'progress.json').write_text(json.dumps(result, indent=2) + '\n')
        print(name, 'PASS' if row['pass'] else row['error'], flush=True)

    def transport(page, row):
        page.goto(base + 'index.html', wait_until='domcontentloaded')
        page.wait_for_function("()=>document.querySelector('#narrative-stories')?.dataset.status==='ready'", timeout=90000)
        selected = set(k for k in entries if k in ('/api/health', '/api/narrative-v1/manifest', '/api/current/casebook') or k.startswith(('/api/narrative-v1/trace?', '/api/current/condition-v6?', '/api/current/analyst-digest?', '/api/current/origin-v63?')))
        selected.update(k for k in entries if '/guide-view-v6?' in k and 'phase=source' in k)
        selected.update(k for k in entries if k.startswith(('/api/cib-pdf?', '/api/current/cib-pdf?')))
        row['selected_route_aliases'] = len(selected)
        unique_payloads = {}
        for key in sorted(selected):
            unique_payloads.setdefault(entries[key]['sha256'], key)
        selected = set(unique_payloads.values())
        # Bound the owner browser; full file/route integrity is verified separately.
        assert len(selected) <= 1200
        for key in sorted(selected):
            actual = page.evaluate("""async key=>{const r=await fetch(key),b=await r.arrayBuffer();return {status:r.status,sha256:[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(n=>n.toString(16).padStart(2,'0')).join('')};}""", key)
            assert actual['status'] == 200 and actual['sha256'] == entries[key]['sha256'], (key, actual)
            result['transport'].append(dict(route=key, **actual))
        for item in json.loads(args.parity.read_text()):
            key = '/api/current/slots-v1?' + urlencode(item['params'])
            actual = page.evaluate('async key=>{const r=await fetch(key);return {status:r.status,value:await r.json()};}', key)
            assert actual['status'] == 200 and actual['value'] == item['expected'], key
        row['slots_exact_native_parity'] = len(json.loads(args.parity.read_text()))
        invalid = ['/api/health?bad=1', '/api/health?x=1&x=2', '/api/current/source-v6?case_id=missing', '/api/execute']
        row['invalid_selectors'] = page.evaluate('async keys=>Promise.all(keys.map(async key=>(await fetch(key)).status))', invalid)
        assert row['invalid_selectors'] == [404] * len(invalid)
        assert page.evaluate("async()=> (await fetch('/api/health',{method:'POST'})).status") == 405

    def workbench(saved):
        def run(page, row):
            page.goto(base + 'workbench-v6.html?' + urlencode(dict(case=saved['case']['case_id'], arm='A')), wait_until='domcontentloaded')
            expect(page.get_by_test_id('open-saved-result')).to_be_visible(timeout=90000)
            assert page.get_by_test_id('query-text').text_content() == saved['case']['query']
            page.get_by_test_id('open-saved-result').click()
            page.wait_for_function("()=>document.querySelector('#case-view')?.getAttribute('aria-busy')==='false'", timeout=90000)
            assert not page.locator('[data-testid=source-document]').count()
            row['case_id'] = saved['case']['case_id']
            row['native_bound_saved_result_opened'] = True
        return run

    def walk(fixture):
        saved, values, trace, path = fixture
        steps = [next(s for s in trace['steps'] if s['id'] == sid) for sid in path['steps']]
        def run(page, row):
            query = dict(corpus=saved['case']['corpus'], walk_case=values['case_id'], walk_config=values['config'],
                         walk_reading=values['reading'], walk_path=path['id'], **{k: values[k] for k in ('resource_id', 'registry_sha256', 'index_sha256')})
            requested = []
            page.on('request', lambda r: requested.append(r.url) if '/data/replays/' in r.url else None)
            page.goto(base + 'graph-full-v6.html?' + urlencode(query), wait_until='domcontentloaded')
            expect(page.get_by_test_id('kg-walk-reveal')).to_be_visible(timeout=90000)
            assert not page.locator('[data-walk-stage],#saved-kg-walk blockquote').count()
            page.get_by_test_id('kg-walk-reveal').click()
            page.wait_for_function("()=>document.querySelector('#saved-kg-walk')?.dataset.status==='ready'&&document.body.dataset.graphReady==='true'", timeout=90000)
            boxes = page.locator('[data-walk-stage]')
            assert boxes.count() == len(steps)
            before = page.evaluate('()=>({selected:state.panels.current.selected?.id,level:state.panels.current.level,ids:state.panels.current.nodes.map(n=>n.id)})')
            active = [(i, n) for i, s in enumerate(steps) for n in s['nodes'] if n.get('is_graph_node') is True]
            if active:
                i, node = active[0]
                boxes.nth(i).click()
                page.wait_for_function("()=>document.querySelector('#saved-kg-walk')?.getAttribute('aria-busy')==='false'", timeout=90000)
                page.locator('.walk-nodes > summary').click()
                wanted = [n for n in steps[i]['nodes'] if n.get('is_graph_node') is True]
                for node in wanted:
                    button = page.locator('[data-walk-node="' + node['id'] + '"]')
                    assert button.text_content() == node['label']
                    button.click()
                    page.wait_for_function("id=>document.querySelector('#saved-kg-walk')?.dataset.focusedNode===id&&state.panels.current.selected?.id===id&&state.panels.current.nodeMap.has(id)", arg=node['id'], timeout=90000)
                    assert page.locator('.walk-nodes').evaluate('n=>n.open')
                row['actual_node_focus'] = [n['id'] for n in wanted]
            else:
                for i in range(len(steps)):
                    boxes.nth(i).click()
                after = page.evaluate('()=>({selected:state.panels.current.selected?.id,level:state.panels.current.level,ids:state.panels.current.nodes.map(n=>n.id)})')
                assert before == after
                row['source_only_no_graph_change'] = True
            boxes.last.click()
            expected = steps[-1]['source_refs']
            actual = page.locator('.walk-current blockquote').all_text_contents()
            assert actual == [p['text'] for p in expected]
            row['path_id'] = path['id']
        return run

    def graph(corpus):
        def run(page, row):
            page.goto(base + 'graph-full-v6.html?corpus=' + corpus, wait_until='domcontentloaded')
            page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=90000)
            value = page.evaluate('async()=>{await ensureSlotCensus();return slotOverlayState.payload;}')
            assert value['coverage']['complete'] and value['hidden_values_read'] is False
            page.locator('#slots-menu > summary').click()
            check = page.locator('#show-slot-overlay')
            expect(check).to_be_visible()
            check.uncheck()
            check.check()
            row['slots_coverage'] = value['coverage']
        return run

    def swedish(page, row):
        page.goto(base + 'swedish-study.html?policy=S2', wait_until='domcontentloaded')
        page.wait_for_function("()=>document.body.dataset.studyReady==='true'", timeout=60000)
        card = page.locator('[data-policy=S2]')
        expect(card.get_by_test_id('open-saved-result')).to_be_disabled()
        card.get_by_test_id('origin-exception-ack').check()
        card.get_by_test_id('open-saved-result').click()
        expect(card.get_by_test_id('saved-candidate').first).to_be_visible()
        row['explicit_S2_ack_retained'] = True

    def guide_fixture(page, row):
        for key, entry in entries.items():
            if not key.startswith('/api/current/guide-v6?'):
                continue
            values = {k: v[0] for k, v in parse_qs(urlsplit(key).query, keep_blank_values=True).items()}
            if not values['candidate_id'].startswith('path_'):
                continue
            saved = next(r for r in report['cases'] if r['case']['case_id'] == values['case_id'])
            guide = packet(site, entry)
            if guide.get('graph_guide_available') and guide['route']['hops'] and guide['candidate'].get('sources'):
                break
        else:
            raise AssertionError('No actual saved graph guide fixture; no endpoint fabricated')
        proof = guide['candidate']['sources'][0]
        query = dict(corpus=saved['case']['corpus'], guide_case=values['case_id'], guide_arm=values['config'], guide_reading=values['reading'],
            guide_candidate=values['candidate_id'], guide_route=values['route_index'], guide_source=proof['canonical_page_id'],
            guide_start=proof['start'], guide_end=proof['end'], guide_hash=proof['page_sha256'],
            **{k: values[k] for k in ('resource_id', 'registry_sha256', 'index_sha256')})
        page.goto(base + 'graph-full-v6.html?' + urlencode(query), wait_until='domcontentloaded')
        expect(page.get_by_test_id('acknowledge-story-reveal')).to_be_visible(timeout=90000)
        assert not page.locator('#study-guide-drawer').count()
        page.get_by_test_id('acknowledge-story-reveal').click()
        page.wait_for_function("()=>state.guidePath&&!state.guidePath.busy&&document.body.dataset.graphReady==='true'", timeout=90000)
        buttons = page.locator('[data-guide-step]')
        for i in range(buttons.count()):
            buttons.nth(i).click()
            page.wait_for_function('()=>state.guidePath&&!state.guidePath.busy', timeout=90000)
            assert page.evaluate('()=>state.guidePath.error') is None
        drawer = page.locator('#study-guide-drawer')
        expect(drawer).to_have_attribute('data-proof-page', proof['canonical_page_id'], timeout=90000)
        expect(drawer).to_have_attribute('data-proof-hash', proof['page_sha256'])
        assert drawer.locator('.source-quotation').text_content() == proof['text']
        row.update(exact_source_handoff=True, candidate_id=values['candidate_id'], stages=buttons.count())
        page.locator('[data-study-close]').click()
        expect(drawer).to_have_count(0)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            cell(browser, 'transport-and-selectors', transport)
            for saved in report['cases']:
                cell(browser, 'wb-' + str(report['cases'].index(saved)), workbench(saved))
            for corpus in ('iran', 'cib', 'vietnam'):
                cell(browser, 'graph-slots-' + corpus, graph(corpus), mobile=corpus == 'cib')
            fixtures = {}
            for key, entry in entries.items():
                if not key.startswith('/api/narrative-v1/trace?'):
                    continue
                values = {k: v[0] for k, v in parse_qs(urlsplit(key).query, keep_blank_values=True).items()}
                trace = packet(site, entry)
                saved = next(r for r in report['cases'] if r['case']['case_id'] == values['case_id'])
                for path in trace['paths']:
                    has_nodes = any(n.get('is_graph_node') is True for s in trace['steps'] if s['id'] in path['steps'] for n in s['nodes'])
                    category = saved['case']['corpus'] + ('-graph' if has_nodes else '-source')
                    fixtures.setdefault(category, (saved, values, trace, path))
            for key in ('iran-graph', 'cib-graph', 'cib-source', 'vietnam-source'):
                if key in fixtures:
                    cell(browser, 'walk-' + key, walk(fixtures[key]), mobile=key in ('cib-graph', 'vietnam-source'))
            assert any(key.endswith('-graph') for key in fixtures), 'No actual graph-node trace fixture; no route fabricated'
            cell(browser, 'guide-exact-source', guide_fixture)
            cell(browser, 'swedish-S2', swedish, mobile=True)
            browser.close()
    finally:
        http.shutdown()
        http.server_close()
        thread.join()
    result.update(leaked_api_requests=leaked, blocked_external_requests=external,
        success=all(c['pass'] for c in result['cells']) and not leaked and not external,
        ended_utc=datetime.now(timezone.utc).isoformat(), browser_closed=True)
    (out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(success=result['success'], cells=len(result['cells']), transport=len(result['transport']))))
    if not result['success']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
