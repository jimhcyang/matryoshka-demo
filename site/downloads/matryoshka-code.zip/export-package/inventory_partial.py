"""Preserve stopped-stage evidence without pretending it is a completed cache."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024**2), b''):
            value.update(block)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    stage, output = args.stage.resolve(), args.output.absolute()
    assert stage.is_relative_to(HERE) and output.is_relative_to(HERE) and not output.exists()
    files = [dict(path=p.relative_to(stage).as_posix(), bytes=p.stat().st_size, sha256=digest(p))
        for p in sorted(stage.rglob('*')) if p.is_file()]
    value = dict(version='stopped-partial-export-inventory/1', stage=stage.name, files=files,
        status='STOPPED_PARTIAL_NOT_A_COMPLETED_CACHE', case_checkpoint_exists=(stage / 'case_checkpoint.json').exists(),
        stage_receipt_exists=(stage / 'stage_receipt.json').exists(), original_stage_modified=False,
        in_memory_route_map_available=False, reusable_only_after_exact_fresh_response_verification=True)
    output.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(dict(files=len(files), bytes=sum(r['bytes'] for r in files), status=value['status'])))


if __name__ == '__main__':
    main()
