"""Content-addressed transport reuse AFTER fresh guarded response generation."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def fingerprint(report):
    return [dict(case=r['case'], resource_binding=r['resource_binding'], origin_refs=r['origin_refs'],
        native={k:v['native_checkpoint'] for k,v in r['configurations'].items()}) for r in report['cases']]


class ResponseCache:
    def __init__(self, source, stage, report, map_pin, code_pin):
        here = Path(__file__).resolve().parent
        assert source.is_relative_to(here) and source.resolve() == source and source != stage.output
        self.source, self.stage, self.copied, self.hits = source / 'site', stage, set(), 0
        self.loaded_manifests = set()
        receipt = json.loads((source / 'stage_receipt.json').read_bytes())
        assert receipt['map_index_sha256'] == map_pin and receipt['backend_code_sha256'] == code_pin
        previous_raw = (self.source / 'data/report-v6.json').read_bytes()
        assert sha(previous_raw) == receipt['source_report_ref']['sha256']
        assert fingerprint(json.loads(previous_raw)) == fingerprint(report), 'Cache public/native/origin source policy differs'
        raw = (self.source / 'data/api-index.json').read_bytes()
        assert sha(raw) == receipt['index_sha256']
        entries = json.loads(raw)['entries']
        self.entries = {e['sha256']:e for k,e in entries.items() if not e.get('external_url') and e['mime'] == 'application/json'
            and k.startswith(('/api/current/', '/api/narrative-v1/', '/data/slots/'))}

    def copy(self, relative, pin):
        if relative in self.copied:
            return
        assert not relative.startswith('/') and '\\' not in relative and '..' not in Path(relative).parts
        path = self.source / relative
        assert path.resolve() == path
        raw = path.read_bytes()
        assert sha(raw) == pin
        self.stage.write('site/' + relative, raw)
        self.copied.add(relative)

    def fetch(self, generated_sha256):
        entry = self.entries.get(generated_sha256)
        if entry is None:
            return None
        if entry['encoding'] == 'fragment-dag':
            if entry['path'] not in self.loaded_manifests:
                self.copy(entry['path'], entry['manifest_sha256'])
                manifest = json.loads((self.source / entry['path']).read_bytes())
                for chunk in manifest['chunks']:
                    self.copy((Path(entry['path']).parent / chunk['path']).as_posix(), chunk['wire_sha256'])
                self.loaded_manifests.add(entry['path'])
        else:
            self.copy(entry['path'], entry['wire_sha256'])
        self.hits += 1
        return deepcopy(entry)
