#!/usr/bin/env python3
"""Bounded offline static transport for one exact narrative Viewer publication.

No server, network, inference, git operation, or deployment installation occurs.
The output is a NEW staging directory, never a release qualification receipt.
"""
from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import signal
import sys
import time
from types import FunctionType, SimpleNamespace
from urllib.parse import parse_qsl, urlencode, urlsplit


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
VERSION = "narrative-static-export/2"
PHASES = ("start_community", "start_connections", "relation", "target_reveal",
          "target_connections", "target_community")
PINS = ("resource_id", "registry_sha256", "index_sha256")
DEFAULT_LIMITS = dict(max_bytes=900_000_000, min_free_bytes=8 * 1024**3,
    max_requests=100_000, max_sources=10_000, max_nodes=50_000,
    max_packet_bytes=210_000_000, max_seconds=3600)


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=True, allow_nan=False).encode()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def at(root, relative):
    require(isinstance(relative, str) and relative and "\\" not in relative
        and not relative.startswith("/") and all(p not in {"", ".", ".."}
        for p in relative.split("/")), "Unsafe relative path")
    path = root / relative
    require(path.resolve() == path, "Symlinked or redirected input/output")
    return path


class Inputs:
    def __init__(self):
        self.pins = {}

    def raw(self, root, ref):
        path = at(root, ref["path"])
        raw = path.read_bytes()
        require(re.fullmatch(r"[a-f0-9]{64}", ref["sha256"])
            and sha(raw) == ref["sha256"], "Explicit input byte pin changed: " + ref["path"])
        old = self.pins.setdefault(path, ref["sha256"])
        require(old == ref["sha256"], "Conflicting input pins")
        return raw

    def read(self, root, ref):
        raw = self.raw(root, ref)
        return json.loads(gzip.decompress(raw) if ref["path"].endswith(".gz") else raw)

    def unchanged(self):
        for path, expected in self.pins.items():
            require(path.resolve() == path and sha(path.read_bytes()) == expected,
                    "Input changed during export: " + path.name)


def reference(root, filename, inputs):
    path = Path(filename).absolute()
    require(path.resolve() == path, "Symlinked reference file")
    raw = path.read_bytes()
    inputs.pins[path] = sha(raw)
    value = json.loads(raw)
    require(set(value) == {"path", "sha256"}, "Expected an explicit path/sha256 reference")
    inputs.raw(root, value)
    return value


class Stage:
    def __init__(self, output, limits=None, resume=False):
        self.output = Path(output).absolute()
        self.limits = dict(DEFAULT_LIMITS, **(limits or {}))
        require(0 < self.limits["max_bytes"] <= 900_000_000, "Published stage maximum is 900 MB")
        require(self.limits["min_free_bytes"] >= 8 * 1024**3, "Disk guard must be at least 8 GiB")
        require(self.output.resolve() == self.output and (resume or not self.output.exists()),
                "Output must be a new directory or an explicitly resumed nonsymlinked stage")
        require(self.output.is_relative_to(HERE) and self.output != HERE,
                "Output must stay under this worker's deploy directory")
        self.started, self.bytes, self.files = time.monotonic(), 0, {}
        self.resuming = resume
        self.guard()
        if resume:
            require((self.output / 'case_checkpoint.json').is_file() and not (self.output / 'stage_receipt.json').exists(),
                    'Resume requires an unsealed stage with its completed case checkpoint')
            for path in sorted((self.output / 'site').rglob('*')):
                if path.is_file():
                    require(path.resolve() == path, 'No symlinks in resumed stage')
                    raw = path.read_bytes()
                    relative = path.relative_to(self.output).as_posix()
                    self.files[relative] = dict(path=relative, sha256=sha(raw), bytes=len(raw))
                    self.bytes += len(raw)
            self.guard()
        else:
            self.output.mkdir(parents=True)

    def guard(self, extra=0):
        require(time.monotonic() - self.started < self.limits["max_seconds"], "Static export deadline")
        require(self.bytes + extra <= self.limits["max_bytes"], "Static stage byte budget")
        require(shutil.disk_usage(HERE).free - extra >= self.limits["min_free_bytes"], "8 GiB disk guard")

    def write(self, relative, raw):
        require(not relative.startswith('site/') or len(raw) < 100_000_000, 'Published files must stay below 100 MB')
        path = at(self.output, relative)
        if relative in self.files:
            require(self.files[relative]["sha256"] == sha(raw),
                'Immutable stage file differs: ' + relative + ' old=' + self.files[relative]['sha256'] + ' new=' + sha(raw))
            return
        if path.exists():
            require(self.resuming and path.is_file() and sha(path.read_bytes()) == sha(raw),
                    'Existing resumed file differs')
            self.bytes += len(raw)
            self.files[relative] = dict(path=relative, sha256=sha(raw), bytes=len(raw))
            self.guard()
            return
        self.guard(len(raw))
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as handle:
            handle.write(raw)
        self.bytes += len(raw)
        self.files[relative] = dict(path=relative, sha256=sha(raw), bytes=len(raw))


def route(name, params):
    return name + ("?" + urlencode(sorted((k, str(v)) for k, v in params.items())) if params else "")


def parameters(row, arm):
    return dict(case_id=row["case"]["case_id"], config=arm,
                **{k: row["resource_binding"][k] for k in PINS})


def collection_manifest_projection(manifest, report):
    """Explicit schema alias only; never nominate cases or invent family IDs."""
    require(manifest.get("version") == report.get("version") == "narrative-workbench-publication/1",
            "Collection alias requires an actual narrative publication")
    additional = []
    for row in report["cases"]:
        selected = row.get("selected_additional") is True
        marked = row.get("collection") == "additional_real_redaction"
        require(selected == marked, "Additional collection marker and selection disagree")
        if marked:
            require(row["case"]["corpus"] == "cib" and row["case"]["task"] == "redaction"
                and row.get("selected_demo") is False and row.get("selected_bench") is False,
                "Additional redaction cannot replace a core case")
            additional.append(row["case"]["case_id"])
    require(len(set(additional)) == len(additional), "Repeated additional case")
    for key in ("additional", "additional_real_redaction"):
        if key in manifest:
            ids = manifest[key]
            require(isinstance(ids, list) and all(isinstance(x, str) for x in ids)
                and len(set(ids)) == len(ids) and set(ids) == set(additional),
                "Manifest additional identities disagree with the pinned report")
    require("additional" in manifest or "additional_real_redaction" in manifest,
            "No source collection list to alias")
    source = manifest.get("additional", manifest.get("additional_real_redaction"))
    projected = deepcopy(manifest)
    projected["additional_real_redaction"] = deepcopy(source)
    lineage = dict(version="narrative-static-collection-schema/1", scope="COLLECTION_KEY_ALIAS_ONLY",
        source_manifest_sha256=sha(encoded(manifest)), projected_manifest_sha256=sha(encoded(projected)),
        checksum_scope="Canonical JSON object, not HTTP wire bytes", source_key="additional" if "additional" in manifest else "additional_real_redaction",
        target_key="additional_real_redaction", report_bytes_unchanged=True,
        case_membership_and_order_unchanged=True, native_outputs_modified=False,
        family_or_target_ids_invented=False)
    return projected, lineage


def collection_identity_gaps(report):
    return [dict(case_id=row["case"]["case_id"],
        missing=[key for key in ("source_target_id", "family_id") if not isinstance(row.get(key), str) or not row[key].strip()])
        for row in report["cases"] if row["case"]["corpus"] == "cib" and row["case"]["task"] == "redaction"
        and (row.get("selected_demo") is True or row.get("selected_bench") is True
             or row.get("collection") == "additional_real_redaction")
        and any(not isinstance(row.get(key), str) or not row[key].strip() for key in ("source_target_id", "family_id"))]


def citations(value):
    if isinstance(value, dict):
        identity = value.get("canonical_page_id")
        if isinstance(identity, str) and identity:
            yield identity
        for child in value.values():
            yield from citations(child)
    elif isinstance(value, list):
        for child in value:
            yield from citations(child)


def visible_nodes(value):
    """Only finite displayed/incident inventories, never unrestricted corpus BFS."""
    if not isinstance(value, dict):
        return set()
    nodes = [value.get("node"), value.get("community")]
    for key in ("nodes", "neighbors", "breadcrumbs"):
        nodes.extend(value.get(key, []) or [])
    incident = value.get("incident", {})
    nodes.extend(incident.get("neighbors", []))
    nodes.append(incident.get("node"))
    return {n["id"] for n in nodes if isinstance(n, dict) and isinstance(n.get("id"), str)}


class SavedReader:
    """Cache exact validated records and one read-only source view per case.

    No production module/global is modified. Every cached input is rehashed at
    completion. The source inspection functions still verify exact source policy.
    """
    def __init__(self, viewer, inputs):
        from matryoshka_current import inspection
        self.viewer, self.inputs = viewer, inputs
        self.selections, self.views, self.guides, self.pdf_policies = {}, {}, {}, {}
        self.original_select = viewer.select
        viewer.select = self.select
        namespace = dict(viewer.api.__func__.__globals__)

        def borrowed(context, case):
            key = encoded(case)
            if key not in self.views:
                view = inspection._View(context, case)
                # Repeated guide pages inspect the same immutable case view.
                # Return copies so caller list enrichment cannot poison a cache.
                def memo(original):
                    cache = {}
                    def call(*args):
                        identity = encoded(args)
                        if identity not in cache:
                            cache[identity] = original(*args)
                        return deepcopy(cache[identity])
                    return call
                for name in ('source_edges', 'incident_ids', 'relation'):
                    setattr(view, name, memo(getattr(view, name)))
                self.views[key] = view

        class BorrowedView:
            def __init__(self, context, case):
                borrowed(context, case)
                self.view = self_reader.views[encoded(case)]
            def __enter__(self):
                return self.view
            def __exit__(self, *_):
                return False

        self_reader = self
        proxy = SimpleNamespace()
        functions = {}
        for name in ("source", "node", "neighborhood", "guide_overlay", "guide_view"):
            original = getattr(inspection, name)
            globals_copy = dict(original.__globals__, _View=BorrowedView)
            functions[name] = FunctionType(original.__code__, globals_copy, original.__name__,
                                          original.__defaults__, original.__closure__)
        for function in functions.values():
            function.__globals__.update(functions)
        proxy.__dict__.update(functions)
        self.inspection = proxy
        namespace["inspection"] = proxy
        original = viewer.api.__func__
        self.call = FunctionType(original.__code__, namespace, original.__name__,
                                 original.__defaults__, original.__closure__).__get__(viewer)

    def select(self, params):
        key = tuple((k, tuple(v)) for k, v in sorted(params.items()) if k in {"case_id", "config", *PINS})
        if key not in self.selections:
            selected = self.original_select(params)
            _, _, item, _, native = selected
            for ref in (item["condition_ref"], item["native_checkpoint"]):
                self.inputs.raw(self.viewer.root, ref)
            self.selections[key] = selected
            for corpus in list(self.viewer.contexts):
                if corpus != native["case"]["corpus"]:
                    self.viewer.contexts.pop(corpus).close()
            context = self.viewer.context(native)
            for ref in (context.registry_ref, context.index_ref):
                self.inputs.raw(self.viewer.root, ref)
        return self.selections[key]

    def api(self, name, params):
        if name in {"guide-overlay-v63", "guide-overlay-v64", "guide-view-v6"}:
            guide_keys = {"case_id", "config", *PINS, "reading", "candidate_id", "route_index"}
            extra = {"phase", "source_id", "node_id", "hop_index", "limit", "offset", "page_size"} if name == "guide-view-v6" else set()
            require(set(params) <= guide_keys | extra, "Unsupported narrative guide selector")
            selection = {k: v for k, v in params.items() if k in guide_keys}
            key = tuple(sorted(selection.items()))
            if key not in self.guides:
                self.guides[key] = self.call("guide-v6", {k: [str(v)] for k, v in selection.items()})
            row, _, _, _, native = self.select({k: [str(v)] for k, v in params.items()})
            context = self.viewer.context(native)
            if name == "guide-view-v6":
                value = self.inspection.guide_view(context, native["case"], self.guides[key], params)
            else:
                value = self.inspection.guide_overlay(context, native["case"], self.guides[key])
            return dict(value, resource_binding=row["resource_binding"])
        return self.call(name, {k: [str(v)] for k, v in params.items()})

    def close_case(self):
        for view in self.views.values():
            view.__exit__(None, None, None)
        self.views.clear()
        self.selections.clear()
        self.guides.clear()
        self.pdf_policies.clear()

    def pdf(self, params):
        """The Viewer's exact PDF guards, with one SourcePolicy per exact case."""
        from matryoshka_current.server import one
        from matryoshka_next.facts import SourcePolicy
        allowed = {"case_id", "config", *PINS, "doc_id", "release"}
        require(set(params) <= allowed, "Unknown PDF selector")
        for key in params:
            one(params, key)
        row, _, _, _, native = self.select(params)
        case = row["case"]
        document, release = one(params, "doc_id"), one(params, "release")
        require(case["corpus"] == "cib" and release in {"earlier", "later"}, "CIB release PDF required")
        if document != case["document_id"]:
            key = encoded(dict(case=native["case"], binding=row["resource_binding"]))
            if key not in self.pdf_policies:
                context = self.viewer.context(native)
                policy = SourcePolicy(context.corpus, native["case"], context.source_index)
                eligible_documents = {p["document_id"] for i, p in enumerate(context.corpus.pages) if policy.allowed(i)}
                self.pdf_policies[key] = policy, eligible_documents
            require(release == "earlier" and document in self.pdf_policies[key][1], "PDF is outside eligible evidence view")
        else:
            require(row["origin_refs"], "Original requires verified source provenance")
            self.viewer.origin(row, "0")
        if self.viewer.pdf_catalog is not None and document + "/" + release in self.viewer.pdf_catalog["entries"]:
            from matryoshka_narrative import pdfs
            catalog = self.inputs.read(self.viewer.root, self.viewer.report["pdf_catalog_ref"])
            require(catalog == self.viewer.pdf_catalog, "Pinned PDF catalog changed")
            raw, mime = pdfs.read(self.viewer.root, catalog, document, release)
        else:
            require(self.viewer.maps is not None, "No exact PDF catalog or immutable map export selected")
            raw, mime = self.viewer.maps.packet(route("/api/cib-pdf", dict(doc_id=document, release=release)))
        require(raw.startswith(b"%PDF-") and mime == "application/pdf", "Not an original source PDF")
        return raw, mime


class Exporter:
    def __init__(self, stage, viewer, reader, public, scan, node_scope="routes"):
        self.stage, self.viewer, self.reader = stage, viewer, reader
        self.public, self.scan = public, scan
        self.entries, self.coverage = {}, []
        self.requests, self.metadata_projections = 0, []
        self.guide_cache = {}
        from packet_pack import PacketPack
        self.packet_pack = PacketPack(stage)
        require(node_scope in {"routes", "displayed"}, "Unknown finite node scope")
        self.node_scope = node_scope

    def put(self, key, value, *, raw=None, mime="application/json"):
        supplied_raw = raw is not None
        if raw is None:
            projected = self.public(value)
            if projected != value:
                self.metadata_projections.append(dict(route=key, original_sha256=sha(encoded(value)),
                    public_sha256=sha(encoded(projected)), scope="private metadata locations only"))
            self.scan(projected, None)
            raw = encoded(projected)
        require(len(raw) <= self.stage.limits["max_packet_bytes"], "Saved packet byte limit")
        cache = getattr(self, 'response_cache', None)
        if cache is not None and mime == 'application/json' and not supplied_raw:
            cached = cache.fetch(sha(raw))
            if cached is not None:
                require(key not in self.entries or self.entries[key]['sha256'] == cached['sha256'], 'Cached route identity differs')
                self.entries[key] = cached
                return value
        if mime == 'application/json' and len(raw) >= 32768 and not supplied_raw:
            from structural_pack import put_graph
            entry = put_graph(self.packet_pack, raw, sha(raw))
            require(key not in self.entries or self.entries[key].get('encoding') == 'fragment-dag'
                and self.entries[key].get('sha256') == entry['sha256'], 'Conflicting packed route identity')
            self.entries[key] = entry
            return value
        if mime == "application/json":
            wire, encoding, suffix = gzip.compress(raw, compresslevel=6, mtime=0), "gzip", ".json.gz"
        else:
            wire, encoding, suffix = raw, "identity", ".pdf"
        path = "data/replays/" + sha(wire) + suffix
        self.stage.write("site/" + path, wire)
        entry = dict(path=path, sha256=sha(raw), wire_sha256=sha(wire), encoding=encoding, mime=mime)
        require(key not in self.entries or self.entries[key] == entry, "Conflicting route identity")
        self.entries[key] = entry
        return value

    def get(self, name, params):
        self.requests += 1
        require(self.requests <= self.stage.limits["max_requests"], "Finite request limit")
        self.stage.guard()
        key = route("/api/current/" + name, params)
        if key in self.entries:
            entry = self.entries[key]
            if entry['encoding'] == 'fragment-dag':
                return json.loads(self.packet_pack.read(entry['asset']))
            wire = at(self.stage.output / "site", entry["path"]).read_bytes()
            require(sha(wire) == entry["wire_sha256"], "Cached static packet changed")
            raw = gzip.decompress(wire) if entry["encoding"] == "gzip" else wire
            require(sha(raw) == entry["sha256"], "Cached decoded packet changed")
            return json.loads(raw)
        value = self.reader.api(name, params)
        if name == "native-v6":
            original, projected = value["native"], self.public(value)["native"]
            for field in ("version", "result", "case", "public_case", "binding", "code_pins", "native_checksum"):
                require(projected[field] == original[field], "Public transport changes native identity/result: " + field)
        if name == "native-v6" and self.public(value) != value:
            value = dict(value, public_native_projection=dict(
                original_native_checkpoint=self.viewer.cases[params["case_id"]]["configurations"][params["config"]]["native_checkpoint"],
                original_native_record_sha256=sha(encoded(value["native"])),
                original_plan_sha256=sha(encoded(value["native"]["plan"])),
                public_plan_sha256=sha(encoded(self.public(value)["native"]["plan"])),
                full_checkpoint_exported=False, metadata_locations_redacted=True,
                result_version_engine_and_source_identities_unchanged=True))
        self.put(key, value)
        return value

    def one_case(self, row):
        for arm, item in row["configurations"].items():
            params = parameters(row, arm)
            condition = self.get("condition-v6", params)
            native = self.get("native-v6", params)
            original = native["native"]
            projected = self.public(native)["native"]
            for field in ("version", "result", "case", "public_case", "binding", "code_pins", "native_checksum"):
                require(projected[field] == original[field], "Public transport changes native identity/result: " + field)
            source_ids = set(citations(condition)) | set(citations(original["result"]))
            pdf_source_ids = set(citations(condition))
            for reveal in ("0", "1"):
                self.get("origin-v63", dict(params, reveal_focal=reveal))
                self.get("postrun-review", dict(params, reveal=reveal))
            source_ids.update(citations(self.get("analyst-digest", params)))
            readings = {""} | set(item.get("trace_refs", {}))
            readings.update(r["reading"]["id"] for r in original["result"].get("readings", []))
            for reading in sorted(readings):
                refs = item.get("trace_refs", {})
                if refs and reading not in refs and not (not reading and len(refs) == 1):
                    continue
                for limit in (256, 1024, 2048):
                    flow = self.get("flow-v6", dict(params, reading=reading, limit=str(limit)))
                    source_ids.update(citations(flow))
                if not item.get("trace_refs"):
                    continue
                if reading not in item["trace_refs"] and not (not reading and len(item["trace_refs"]) == 1):
                    continue
                trace = self.reader.api("trace", dict(params, reading=reading))
                self.put(route("/api/narrative-v1/trace", dict(params, reading=reading)), trace)
                source_ids.update(citations(trace))
                pdf_source_ids.update(citations(trace))
                selectors = {}
                for path in trace["paths"]:
                    for identity in {path["id"], path["candidate_or_atom_id"], path["candidate_or_atom_id"].rsplit("/", 1)[-1]}:
                        selectors.setdefault(identity, []).append(path)
                for identity, paths in sorted(selectors.items()):
                    for index, path in enumerate(paths):
                        selection = dict(params, reading=reading, candidate_id=identity, route_index=str(index))
                        self.guide(selection, path, source_ids)
            require(len(source_ids) <= self.stage.limits["max_sources"], "Finite source limit")
            for identity in sorted(source_ids):
                self.get("source-v6", dict(params, source_id=identity))
            if row["case"]["corpus"] == "cib":
                documents = {row["case"]["document_id"]}
                for identity in sorted(pdf_source_ids):
                    value = self.reader.api("source-v6", dict(params, source_id=identity))
                    documents.add(value["document_id"])
                for document in sorted(documents):
                    for release in (("earlier", "later") if document == row["case"]["document_id"] else ("earlier",)):
                        pdf_params = dict(params, doc_id=document, release=release)
                        raw, mime = self.reader.pdf({k: [str(v)] for k, v in pdf_params.items()})
                        require(raw.startswith(b"%PDF-") and mime == "application/pdf", "Exact physical PDF required")
                        self.put(route("/api/current/cib-pdf", pdf_params), None, raw=raw, mime=mime)
                # Ordinary map viewers (including walk_case) request unbound PDFs.
                # These explicit viewer actions are not case-eligible evidence APIs.
                for document in sorted(documents):
                    for release in ("earlier", "later"):
                        values = dict(doc_id=document, release=release)
                        raw, mime = self.viewer.maps.packet(route("/api/cib-pdf", values))
                        require(raw.startswith(b"%PDF-") and mime == "application/pdf", "Original map PDF required")
                        self.put(route("/api/cib-pdf", values), None, raw=raw, mime=mime)
            self.coverage.append(dict(case_id=params["case_id"], config=arm,
                native_version=original["version"], native_checkpoint=item["native_checkpoint"],
                native_result_sha256=sha(encoded(original["result"])), source_ids=sorted(source_ids)))
        self.reader.close_case()

    def guide(self, selection, path, source_ids):
        cache_key = selection["case_id"], selection["config"], selection["reading"], path["id"]
        if cache_key in self.guide_cache:
            entries, sources = self.guide_cache[cache_key]
            for key, entry in entries.items():
                parsed = urlsplit(key)
                params = dict(parse_qsl(parsed.query, keep_blank_values=True))
                if "candidate_id" in params:
                    params.update(candidate_id=selection["candidate_id"], route_index=selection["route_index"])
                    self.entries[route(parsed.path, params)] = entry
            source_ids.update(sources)
            return
        before = set(self.entries)
        self._guide(selection, path, source_ids)
        entries = {k: v for k, v in self.entries.items() if k not in before}
        self.guide_cache[cache_key] = entries, set(source_ids)

    def _guide(self, selection, path, source_ids):
        guide = self.get("guide-v6", selection)
        source_ids.update(citations(guide))
        final_sources = set(citations(path["decision_source_refs"]))
        require(final_sources <= set(citations(guide)), "Guide lost final decision-used sources")
        if not guide.get("graph_guide_available"):
            require(not path["graph_hops"], "A saved graph route became unavailable")
            return
        nodes, hops = guide["route"]["nodes"], guide["route"]["hops"]
        inspection_ids = {n["id"] for n in nodes}
        for name in ("guide-overlay-v63", "guide-overlay-v64"):
            source_ids.update(citations(self.get(name, selection)))
        for hop in range(max(1, len(hops))):
            for phase in PHASES if hops else PHASES[:2]:
                for limit in (32, 256, 2048):
                    offset = 0
                    while True:
                        values = dict(selection, phase=phase, hop_index=str(hop), limit=str(limit),
                                      offset=str(offset), page_size="24")
                        value = self.get("guide-view-v6", values)
                        source_ids.update(citations(value))
                        if self.node_scope == "displayed":
                            inspection_ids.update(visible_nodes(value))
                        following = value.get("incident", {}).get("next_offset")
                        if following is None:
                            break
                        require(type(following) is int and following > offset, "Nonadvancing guide pagination")
                        offset = following
        require(len(inspection_ids) <= self.stage.limits["max_nodes"], "Finite node limit")
        for identity in sorted(inspection_ids):
            value = self.get("guide-view-v6", dict(selection, phase="inspect", node_id=identity))
            source_ids.update(citations(value))
            source_ids.update(citations(self.get("node-v6", dict(
                **{k: selection[k] for k in ("case_id", "config", *PINS)}, node_id=identity))))
        # Deliberately after every hop/phase: the route must reach the actual
        # decision-used quotations, not stop at an intermediate source phase.
        for identity in sorted(set(citations(guide)) | final_sources):
            value = self.get("guide-view-v6", dict(selection, phase="source", source_id=identity))
            source_ids.update(citations(value))


def adapt_runtime(raw, supplement_paths=()):
    text = raw.decode()
    require("/* narrative-static-transport/1 */" not in text, "Runtime already adapted")
    seam = "  const isPDF = path =>"
    require(text.count(seam) == 1, "Public runtime route seam changed")
    extra = '''  /* narrative-static-transport/1 */
  for (const page of ["/corpus-home.html", "/corpus-tour.html", "/docs/matryoshka-guide.pdf"]) pages.add(page);
  routes["/api/current/casebook"] = {defaults: {}, required: []};
  routes["/api/current/report-v6"] = {defaults: {}, required: []};
  routes["/api/narrative-v1/manifest"] = {defaults: {}, required: []};
  routes["/api/narrative-v1/presentation-context-sources"] = {defaults: {narrative_id: ""}, required: ["corpus"]};
  routes["/api/narrative-v1/trace"] = {defaults: {config: "llm_readings", reading: ""}, required: currentPins};
  routes["/api/current/analyst-digest"] = {defaults: {config: "llm_readings"}, required: currentPins};
  routes["/api/current/slots-v1"] = {defaults: {offset: "0", limit: "32", scan: "0", q: ""}, required: ["corpus", "graph_id", "hierarchy_id"], optional: ["slot_id", "anchor_id", "domain_id", "theme_id", "community_id"]};
  const narrativeGlobalRoutes = new Set(["/api/current/casebook", "/api/current/report-v6", "/api/current/slots-v1"]);
'''
    text = text.replace(seam, extra + seam)
    extra_pages = "\n".join("  pages.add(" + json.dumps("/" + path) + ");" for path in supplement_paths)
    text = text.replace("  /* narrative-static-transport/1 */", "  /* narrative-static-transport/1 */\n" + extra_pages)
    text = text.replace('if (path.startsWith("/api/current/")) {',
        'if ((path.startsWith("/api/current/") && !narrativeGlobalRoutes.has(path)) || path === "/api/narrative-v1/trace") {')
    # The narrative Viewer supports ALL exact saved routes, not only top three.
    text = text.replace('if (own(values, "route_index") && Number(values.route_index) > 2)',
        'if (own(values, "route_index") && Number(values.route_index) > 99999)')
    slot_code = (HERE / 'slot-runtime.js').read_text()
    require(text.count('  async function verified(input, signal) {') == 1, 'Static verification seam changed')
    text = text.replace('  async function verified(input, signal) {', slot_code + '\n  async function verified(input, signal) {')
    text = text.replace('    if (!own(index.entries, key)) fail("PUBLIC_PACKET_NOT_EXPORTED"',
        '    if (key.startsWith("/api/current/slots-v1?") && !own(index.entries,key)) return verifiedSlots(key, signal);\n    if (!own(index.entries, key)) fail("PUBLIC_PACKET_NOT_EXPORTED"')
    text = text.replace('return savedIndex !== null && own(savedIndex.entries, canonicalKey(input));',
        'const key=canonicalKey(input);return savedIndex !== null && (own(savedIndex.entries,key)||key.startsWith("/api/current/slots-v1?")&&own(savedIndex.entries,"/data/slots/"+new URL(input,document.baseURI).searchParams.get("corpus")+".json"));')
    seam = '    const response = await originalFetch(entryURL(entry, key), {method: "GET", credentials: "omit", redirect: "error", mode: external ? "cors" : "same-origin", signal});'
    require(text.count(seam) == 1, 'Same-repository dataset transport seam changed')
    text = text.replace(seam, '''    const approvedURL = entryURL(entry, key);
    const mirrored = external && script.dataset.datasetMirror === "same-repository" &&
      ["localhost", "127.0.0.1", "[::1]", "::1"].includes(location.hostname);
    const packetURL = mirrored ? new URL("/datasets/" + approvedURL.pathname.split("/datasets/")[1], base) : approvedURL;
    const response = await originalFetch(packetURL, {method: "GET", credentials: "omit", redirect: "error", mode: external && !mirrored ? "cors" : "same-origin", signal});''')
    text = text.replace('      if (typeof piece === "string") {\n        check(piece.length <= result.length - length,',
        '      if (typeof piece === "string") {\n        if(pack.manifest.literal_encoding==="base64"){const bytes=Uint8Array.from(atob(piece),c=>c.charCodeAt(0));check(bytes.length<=result.length-length,"Fragment bytes exceed declared root");result.set(bytes,length);length+=bytes.length;continue;}\n        check(piece.length <= result.length - length,')
    return text.encode()


def retain_maps(stage, package, index, inputs, *, include_graphs=True):
    entries = {k: deepcopy(v) for k, v in index["entries"].items()
        if k.startswith(("/graph-assets-v4/", "/api/graph-v4-viewer?", "/api/cib-pdf?"))
        and (include_graphs or not k.startswith('/graph-assets-v4/'))}
    for corpus in ("cib", "iran", "vietnam"):
        require("/api/graph-v4-viewer?corpus=" + corpus in entries, "Missing complete corpus map")
    files = {}
    for key, entry in entries.items():
        if entry.get("external_url"):
            match = re.fullmatch(r"https://raw\.githubusercontent\.com/jimhcyang/matryoshka-demo/[a-f0-9]{40}/datasets/(cib|iran|vietnam)/([a-f0-9]{64})\.json\.gz", entry["external_url"])
            require(match and match[2] == entry["wire_sha256"] and key.startswith("/graph-assets-v4/" + match[1] + "/"),
                    "Unapproved immutable dataset URL")
            continue
        pin = entry["manifest_sha256"] if entry["encoding"] == "fragment-dag" else entry["wire_sha256"]
        files[entry["path"]] = pin
        if entry["encoding"] == "fragment-dag":
            manifest = inputs.read(package / "site", dict(path=entry["path"], sha256=pin))
            for chunk in manifest["chunks"]:
                files[(Path(entry["path"]).parent / chunk["path"]).as_posix()] = chunk["wire_sha256"]
    for relative, pin in sorted(files.items()):
        stage.write("site/" + relative, inputs.raw(package / "site", dict(path=relative, sha256=pin)))
    return entries


def ui_assets(stage, viewer, package, index_sha, inputs, supplements=(), field_guide=None, same_repository=False):
    roots = [viewer.root / "narrative_demo/web"]
    if viewer.ui_root:
        roots.append(viewer.ui_root)
    names = {p.name for root in roots for p in root.iterdir() if p.suffix in {".html", ".js", ".css"}}
    names.update({"app-navigation.js", "app-navigation.css", "workbench-visuals.js"})
    names.discard('index.html')  # The public entry point is the transformed Corpus home alias.
    lineage = []
    for name in sorted(names):
        path = viewer.asset(name)
        if path is None:
            continue
        raw = path.read_bytes()
        inputs.pins[path] = sha(raw)
        text = raw.decode()
        if name.endswith(".html"):
            text = re.sub(r'\b(href|src|action|poster)=(["\'])(/(?!/)[^"\']*)\2',
                          lambda m: m[1] + "=" + m[2] + (m[3][1:] or "index.html") + m[2], text)
            text = text.replace("connect-src 'self';", "connect-src 'self' https://raw.githubusercontent.com;")
            require("</head>" in text, "UI page needs an early runtime head")
            hook = '<script src="runtime/public-runtime.js" data-index="data/api-index.json" data-index-sha256="' + index_sha + '"></script>'
            if same_repository:
                hook = hook.replace(' data-index=', ' data-dataset-mirror="same-repository" data-index=')
            text = text.replace("<head>", "<head>\n" + hook + "\n<link rel=\"stylesheet\" href=\"public-transport.css\">")
        elif name.endswith(".js"):
            # Module resolution is not fetch interception. Rewrite literal local
            # import specifiers only; no data/validator/qualification code changes.
            text = re.sub(r"(\bimport\s*\(\s*|\bfrom\s*)(['\"])/(?!/)([^'\"]+)\2",
                          lambda m: m[1] + m[2] + "./" + m[3] + m[2], text)
            for style in sorted(n for n in names if n.endswith(".css")):
                text = text.replace("'/" + style + "'", "'./" + style + "'")
                text = text.replace('"/' + style + '"', '"./' + style + '"')
        public = text.encode()
        stage.write("site/" + name, public)
        lineage.append(dict(path=name, source_sha256=sha(raw), public_sha256=sha(public)))
    for name in sorted(__import__("matryoshka_narrative.server", fromlist=["NARRATIVE_DISPLAY_ASSETS"]).NARRATIVE_DISPLAY_ASSETS):
        path = viewer.narrative_asset(name)
        raw = path.read_bytes()
        inputs.pins[path] = sha(raw)
        stage.write("site/narrative-assets/" + name, raw)
    stage.write("site/index.html", (stage.output / "site/corpus-home.html").read_bytes())
    for name in ("public-runtime.js", "replay.html", "replay.js"):
        path = HERE / "vendor/runtime" / name
        raw = path.read_bytes()
        inputs.pins[path] = sha(raw)
        if name == "public-runtime.js":
            raw = adapt_runtime(raw, (item["target"] for item in supplements))
        elif name == "replay.html":
            raw = raw.replace(b'<script src="public-runtime.js"',
                ('<script data-index="data/api-index.json" data-index-sha256="' + index_sha + '" src="public-runtime.js"').encode())
        stage.write("site/runtime/" + name, raw)
    for name in ("NOTICES.txt", "public-transport.css"):
        path = package / "site" / name
        raw = path.read_bytes()
        inputs.pins[path] = sha(raw)
        stage.write("site/" + name, raw)
    guide = viewer.root / "docs/demo-guide/guide.pdf"
    if field_guide is not None:
        from field_guide import install
        lineage.extend(install(stage, viewer.root, field_guide, inputs))
    elif guide.is_file():
        raw = guide.read_bytes()
        inputs.pins[guide] = sha(raw)
        stage.write("site/docs/matryoshka-guide.pdf", raw)
        lineage.append(dict(path='docs/matryoshka-guide.pdf', source_ref=dict(path='docs/demo-guide/guide.pdf', sha256=sha(raw)),
            source_sha256=sha(raw), public_sha256=sha(raw), report_sha256=None, scope='LEGACY_UNBOUND_GUIDE_NOT_CURRENT_CASE_GUIDE'))
    stage.write("site/.nojekyll", b"")
    return lineage


def supplement_assets(root, filename, inputs):
    if not filename:
        return None, []
    ref = reference(root, filename, inputs)
    manifest = inputs.read(root, ref)
    if isinstance(manifest.get("public_allowlist"), list):
        require(manifest.get("version") == "swedish-study-integration-handoff/1",
                "Unsupported public allowlist manifest version")
        listed = [dict(source_ref=item, target=Path(item["path"]).name) for item in manifest["public_allowlist"]]
    else:
        require(manifest.get("version") == "narrative-static-supplement/1", "Unsupported supplement manifest version")
        listed = manifest.get("assets")
    require(isinstance(listed, list) and 1 <= len(listed) <= 50, "Expected a finite explicit supplement asset list")
    if manifest.get("version") == "swedish-study-integration-handoff/1":
        proof_ref = manifest.get("public_projection_ref")
        require(isinstance(proof_ref, dict), "Swedish public projection needs an explicit pin")
        owner = root.parent if proof_ref["path"].startswith("src-demo-day/") else root
        projection = inputs.read(owner, proof_ref)
        require(projection.get("version") == "withheld-nationality-static-projection-pins/1",
                "Unsupported Swedish public projection")
        pins = {item["target"]: item["source_ref"]["sha256"] for item in listed}
        expected = {item["name"]: item["sha256"] for key in ("display_files", "shared_navigation") for item in projection[key]}
        for key in ("data_ref", "history_ref", "origin_ref"):
            item = projection[key]
            expected[Path(item["path"]).name] = item["sha256"]
        require(pins == expected and "swedish-study-data-v02.json" in pins
            and "swedish-study-data.json" not in pins, "Swedish allowlist/public projection pins disagree")
    assets, targets, total = [], set(), 0
    forbidden = re.compile(r"(^|[/_.-])(private|credentials|receipts|requests|responses|raw.logs|manuscripts?|git|env)([/_.-]|$)", re.I)
    for item in listed:
        require(set(item) == {"source_ref", "target"}, "Supplement assets require only source_ref and target")
        target, source_ref = item["target"], item["source_ref"]
        require(isinstance(target, str) and re.fullmatch(r"[A-Za-z0-9_./-]+", target)
            and not forbidden.search(target) and not forbidden.search(source_ref["path"])
            and not any(c in source_ref["path"] for c in "*?[]{}")
            and Path(target).suffix in {".html", ".js", ".css", ".json"}
            and not target.startswith(("api/", "runtime/", "graph-assets-v4/"))
            and target not in {"index.html", "publication.json", "export-lineage.json", "data/api-index.json", "data/report-v6.json", "swedish-study-data.json"},
            "Unsafe/private/globbed or reserved supplement asset")
        at(root, target)
        require(target not in targets, "Repeated supplement target")
        targets.add(target)
        owner = root.parent if source_ref["path"].startswith("src-demo-day/") else root
        raw = inputs.raw(owner, source_ref)
        total += len(raw)
        require(total <= 10_000_000, "Supplement assets exceed 10 MB")
        assets.append(dict(target=target, source_ref=source_ref, raw=raw))
    return ref, assets


def install_supplements(stage, assets, worker, viewer=None, inputs=None):
    lineage = []
    for item in assets:
        target, raw = item["target"], item["raw"]
        if target in {"app-navigation.js", "app-navigation.css"} and viewer is not None:
            active = viewer.asset(target)
            if active is not None:
                active_raw = active.read_bytes()
                if inputs is not None:
                    inputs.pins[active] = sha(active_raw)
                lineage.append(dict(target=target, source_ref=item["source_ref"],
                    supplied_sha256=sha(raw), active_ui_sha256=sha(active_raw),
                    supplied_equals_active=raw == active_raw,
                    binding="ACTIVE_UI_PREFERRED_NO_CLOBBER", native_conversion=False))
                continue
        if target.endswith('.html') and viewer is not None:
            active = viewer.asset(target)
            require(active is not None and active.read_bytes() == raw, 'Allowlisted HTML must match its active UI source: ' + target)
            if inputs is not None:
                inputs.pins[active] = sha(raw)
            lineage.append(dict(target=target, source_ref=item['source_ref'], supplied_sha256=sha(raw),
                binding='DEFERRED_TO_VERIFIED_UI_HTML_TRANSFORM', native_conversion=False))
            continue
        require("site/" + target not in stage.files, "Supplement cannot replace an existing site asset")
        if target.endswith(".json"):
            json.loads(raw)
            worker.put("/" + target, None, raw=raw)
        stage.write("site/" + target, raw)
        lineage.append(dict(target=target, source_ref=item["source_ref"], public_sha256=sha(raw),
                            bytes_unchanged=True, native_conversion=False))
    return lineage


def prune_data(stage, entries, pending_pack=None):
    referenced = {'site/data/report-v6.json', 'site/data/dataset-delivery.json', 'site/data/original-map-index.json.gz'}
    seen_manifests = set()
    if pending_pack is not None:
        # Unsealed roots still refer to these exact, immutable transport chunks.
        referenced.update('site/data/packet-pack/' + c['path'] for c in pending_pack.chunks)
    for entry in entries.values():
        if entry.get('external_url'):
            continue
        relative = 'site/' + entry['path']
        referenced.add(relative)
        if pending_pack is not None and entry.get('path') == pending_pack.path:
            continue
        if entry['encoding'] == 'fragment-dag' and relative not in seen_manifests:
            seen_manifests.add(relative)
            manifest = json.loads((stage.output / relative).read_bytes())
            referenced.update((Path(relative).parent / row['path']).as_posix() for row in manifest['chunks'])
    for relative in list(stage.files):
        if relative.startswith('site/data/') and relative not in referenced:
            (stage.output / relative).unlink()
            stage.bytes -= stage.files.pop(relative)['bytes']


def build(args):
    root, package = args.root.resolve(), args.map_root.resolve()
    require(not (args.graph_delivery == 'same-repository' and args.reuse_graph_stage),
            'Same-repository delivery uses original map entries, not an offline graph pack')
    inputs = Inputs()
    report_ref = reference(root, args.report_ref, inputs)
    casebook_ref = reference(root, args.casebook_ref, inputs)
    digest_ref = reference(root, args.digest_ref, inputs) if args.digest_ref else None
    supplement_ref, supplements = supplement_assets(root, args.supplement_manifest, inputs)
    from field_guide import assets as field_guide_assets
    field_guide = field_guide_assets(root, args.field_guide_directory, report_ref, inputs)
    code_root = args.backend_root.resolve()
    require(code_root.is_relative_to(HERE) and code_root.is_dir(), 'Use an explicit contained code snapshot')
    sys.path.insert(0, str(code_root))
    code_pin = sha(encoded({str(p.relative_to(code_root)):sha(p.read_bytes()) for p in sorted(code_root.rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py', '.json', '.txt'}}))
    from matryoshka_narrative.server import Viewer
    from matryoshka_current.map_transport import SavedMaps
    current = module("narrative_static_current_conventions", HERE / "vendor/tools/export_current_replays.py")
    guard = current.GUARD
    index_raw = inputs.raw(package / "site", dict(path="data/api-index.json", sha256=args.map_index_sha256))
    map_index = json.loads(index_raw)
    pdfs = None
    pdf_ref = None
    require(bool(args.pdf_catalog) == bool(args.pdf_catalog_sha256), "PDF catalog path and pin are a pair")
    if args.pdf_catalog:
        from matryoshka_current.local_pdfs import LocalPDFs
        pdf_ref = dict(path=args.pdf_catalog, sha256=args.pdf_catalog_sha256)
        catalog = inputs.read(root, pdf_ref)
        inputs.raw(root.parent, catalog["documents_ref"])
        pdfs = LocalPDFs(root.parent, root, pdf_ref)
    maps = SavedMaps(package, args.map_index_sha256, pdfs=pdfs)
    viewer = Viewer(root, report_ref, maps, ui_root=args.ui_root,
                    casebook_ref=casebook_ref, digest_ref=digest_ref)
    reader = SavedReader(viewer, inputs)
    stage = Stage(args.output, {k: getattr(args, k) for k in DEFAULT_LIMITS}, resume=args.resume)
    try:
        if args.graph_delivery == 'same-repository':
            stage.write('site/data/original-map-index.json.gz', gzip.compress(index_raw, compresslevel=9, mtime=0))
        report, book = viewer.pinned_report(), viewer.casebook()
        require(report["version"] == "narrative-workbench-publication/1", "Not a native narrative publication")
        require(1 <= len(report["cases"]) <= 30, "Bounded publication: at most 30 saved cases")
        public = current.public_metadata if args.public_metadata_projection else lambda value: value
        scan = guard.scan_json if args.public_metadata_projection else lambda *_: None
        worker = Exporter(stage, viewer, reader, public, scan, node_scope=args.node_scope)
        worker.response_cache = None
        if args.reuse_response_stage:
            from response_cache import ResponseCache
            worker.response_cache = ResponseCache(args.reuse_response_stage.resolve(), stage, report,
                args.map_index_sha256, code_pin)
        if args.resume:
            worker.entries.update(json.loads((stage.output / 'case_checkpoint.json').read_bytes())['entries'])
        else:
            worker.entries.update(retain_maps(stage, package, map_index, inputs, include_graphs=not args.reuse_graph_stage))
        for corpus in ('cib', 'iran', 'vietnam'):
            key = '/api/graph-v4-viewer?corpus=' + corpus
            raw, _ = maps.packet(key)
            worker.entries.pop(key)
            worker.put(key, None, raw=raw)
        report_raw = inputs.raw(root, report_ref)
        guard.scan_json(report, None)
        guard.scan_json(book, None)
        stage.write("site/data/report-v6.json", report_raw)
        worker.put("/data/report-v6.json", None, raw=report_raw)
        worker.put("/api/current/report-v6", None, raw=report_raw)
        worker.put("/api/current/casebook", None, raw=inputs.raw(root, casebook_ref))
        source_manifest = viewer.manifest()
        manifest, manifest_projection = source_manifest, None
        if args.collection_schema_alias:
            require(not collection_identity_gaps(report),
                    "Source-owner target/family identities are required; collection alias cannot bypass the report guard")
            manifest, manifest_projection = collection_manifest_projection(source_manifest, report)
            stage.write("site/data/source-narrative-manifest.json", encoded(source_manifest))
        worker.put("/api/narrative-v1/manifest", manifest)
        health = dict(status="ok", service="narrative-resource-workbench", report_ref=report_ref,
            cases=len(viewer.cases), api_calls=0, live_inference=False,
            execution_kind="saved_narrative", current_native_execution=False,
            narrative_display_assets="/narrative-assets/", display_modules_only=True)
        worker.put("/api/health", health)
        if args.reuse_case_stage or args.resume:
            prior = stage.output if args.resume else args.reuse_case_stage.resolve()
            require(prior.is_relative_to(HERE), 'Case cache must remain inside this staging package')
            checkpoint = json.loads((prior / 'case_checkpoint.json').read_bytes())
            cache_binding = json.loads((prior / 'case_cache_binding.json').read_bytes())
            require(cache_binding == dict(checkpoint_sha256=sha((prior / 'case_checkpoint.json').read_bytes()),
                casebook_ref=casebook_ref, digest_ref=digest_ref, map_index_sha256=args.map_index_sha256,
                node_scope=args.node_scope), 'Cached casebook/digest/map/scope selectors differ')
            require(checkpoint['report_ref'] == report_ref and checkpoint['backend_code_sha256'] == code_pin
                and checkpoint['pdf_catalog_ref'] == pdf_ref and checkpoint['response_policy'] == args.public_metadata_projection,
                'Cached case closure is not the exact report/code/PDF/projection selection')
            for relative, meta in checkpoint['files'].items():
                if args.resume and relative not in stage.files:
                    # Earlier pruning may remove unreferenced baseline files.
                    continue
                raw = (prior / relative).read_bytes()
                require(sha(raw) == meta['sha256'], 'Case cache file changed')
                stage.write(relative, raw)
            worker.entries.update(checkpoint['entries'])
            worker.coverage.extend(checkpoint['coverage'])
            partial = prior / 'case-progress.json'
            if args.resume and partial.exists():
                progress = json.loads(partial.read_bytes())
                require(progress['bindings']['report_ref'] == report_ref
                    and progress['bindings']['backend_code_sha256'] == code_pin, 'Progress metadata binding differs')
                worker.metadata_projections.extend(progress.get('metadata_projections', []))
            from fragment_reader import Reader
            from structural_pack import put_graph
            saved_reader = None if args.resume else Reader(prior / 'site', stage.output / 'case-cache-reader.sqlite3')
            replacements = {}
            try:
                for key, entry in list(worker.entries.items()):
                    if args.resume:
                        continue
                    if entry['encoding'] != 'fragment-dag':
                        continue
                    identity = entry['path'], entry['asset']
                    if identity not in replacements:
                        raw = saved_reader.read(entry)
                        if key in {'/data/report-v6.json', '/api/current/report-v6', '/api/current/casebook'}:
                            worker.entries.pop(key)
                            worker.put(key, None, raw=raw)
                            replacements[identity] = worker.entries[key]
                        else:
                            replacements[identity] = put_graph(worker.packet_pack, raw, entry['sha256'])
                    worker.entries[key] = replacements[identity]
            finally:
                if saved_reader:
                    saved_reader.close()
        from case_progress import save as save_case_progress
        completed_cases = []
        progress_bindings = dict(report_ref=report_ref, casebook_ref=casebook_ref, digest_ref=digest_ref,
            backend_code_sha256=code_pin, map_index_sha256=args.map_index_sha256, pdf_catalog_ref=pdf_ref,
            response_policy=args.public_metadata_projection, node_scope=args.node_scope)
        for row in ([] if args.reuse_case_stage or args.resume else report["cases"]):
            for item in row["configurations"].values():
                for ref in item.get("trace_refs", {}).values():
                    inputs.raw(root, ref)
            for ref in row["origin_refs"].values():
                inputs.raw(root, ref)
            worker.one_case(row)
            completed_cases.append(row['case']['case_id'])
            save_case_progress(worker, progress_bindings, completed_cases)
            prune_data(stage, worker.entries, worker.packet_pack)
            print(json.dumps(dict(case=row["case"]["case_id"], routes=len(worker.entries), bytes=stage.bytes)), flush=True)
        if not args.resume:
            worker.packet_pack.finish(worker.entries)
            prune_data(stage, worker.entries)
            stage.write('case_checkpoint.json', encoded(dict(report_ref=report_ref, backend_code_sha256=code_pin,
                pdf_catalog_ref=pdf_ref, response_policy=args.public_metadata_projection, entries=worker.entries,
                coverage=worker.coverage, files=stage.files)))
            stage.write('case_cache_binding.json', encoded(dict(checkpoint_sha256=sha((stage.output / 'case_checkpoint.json').read_bytes()),
                casebook_ref=casebook_ref, digest_ref=digest_ref, map_index_sha256=args.map_index_sha256, node_scope=args.node_scope)))
        from static_slots import export_slots
        slot_coverage = export_slots(worker, maps, report['cases'])
        # Repack original graph bytes losslessly; no remote dataset or raw-copy tree.
        from structural_pack import put_graph
        from graph_closure import active_graph_keys
        active_keys = active_graph_keys(maps, map_index['entries'])
        omitted_inactive_graph_routes = []
        for key in ([] if args.graph_delivery == 'same-repository' else list(worker.entries)):
            if key.startswith('/graph-assets-v4/') and key not in active_keys or key.startswith('/api/graph-v4-viewer?') and key not in {'/api/graph-v4-viewer?corpus=' + c for c in ('cib','iran','vietnam')}:
                omitted_inactive_graph_routes.append(key)
                worker.entries.pop(key)
        print(json.dumps(dict(active_graph_assets=len(active_keys), inactive_archive_routes_omitted=len(omitted_inactive_graph_routes))), flush=True)
        if args.resume and args.graph_delivery == 'fragment':
            from resume_support import recover_graphs
            recover_graphs(worker, maps, active_keys)
        # Prune immediately after inactive-route filtering, not after full packing.
        prune_data(stage, worker.entries, worker.packet_pack)
        from resume_support import checkpoint_graphs
        checkpoint_graphs(worker)
        packed_graphs = 0
        graph_cache_pin = None
        dataset_delivery = None
        if args.graph_delivery == 'same-repository':
            from same_repo import manifest as dataset_manifest
            dataset_delivery = dataset_manifest(package, map_index['entries'], args.map_index_sha256, stage.guard)
            stage.write('site/data/dataset-delivery.json', encoded(dataset_delivery))
            print(json.dumps(dict(dataset_files=len(dataset_delivery['files']), original_graph_routes_retained=True)), flush=True)
        if args.reuse_graph_stage:
            from graph_layer import reuse
            cached_graphs, graph_cache_pin = reuse(stage, args.reuse_graph_stage.resolve(), args.map_index_sha256, active_keys, map_index['entries'])
            for key in list(worker.entries):
                if key.startswith('/graph-assets-v4/'):
                    worker.entries.pop(key)
            worker.entries.update(cached_graphs)
        for key, entry in ([] if args.reuse_graph_stage or args.graph_delivery == 'same-repository' else list(worker.entries.items())):
            if entry.get('external_url'):
                raw, mime = maps.packet(key)
                packed = put_graph(worker.packet_pack, raw, entry['sha256'])
                packed.update(original_wire_sha256=entry['wire_sha256'], original_external_url=entry['external_url'])
                require(packed['sha256'] == entry['sha256'], 'Graph decoded bytes changed')
                worker.entries[key] = packed
                packed_graphs += 1
                if packed_graphs % 50 == 0:
                    worker.packet_pack.flush()
                    checkpoint_graphs(worker)
                    prune_data(stage, worker.entries, worker.packet_pack)
                    print(json.dumps(dict(graph_assets_packed=packed_graphs, bytes=stage.bytes)), flush=True)
        if args.pdf_scope == 'catalog':
            require(pdfs is not None, 'Catalog PDF scope requires the explicitly pinned LocalPDFs transport')
            for document in sorted(catalog['entries']):
                for release in ('earlier', 'later'):
                    values = dict(doc_id=document, release=release)
                    raw, mime = maps.packet(route('/api/cib-pdf', values))
                    worker.put(route('/api/cib-pdf', values), None, raw=raw, mime=mime)
        if report.get("presentation_context_sources_ref"):
            intro = inputs.read(root, report["presentation_context_sources_ref"])
            for corpus in sorted({r["case"]["corpus"] for r in report["cases"]}):
                narratives = {""} | {r["narrative_id"] for r in report["cases"]
                    if r["case"]["corpus"] == corpus and r['narrative_id'] in intro['narratives']}
                for identity in sorted(narratives):
                    params = dict(corpus=corpus, narrative_id=identity)
                    worker.put(route("/api/narrative-v1/presentation-context-sources", params),
                               viewer.presentation_context_sources({k: [v] for k, v in params.items()}))
        supplement_lineage = install_supplements(stage, supplements, worker, viewer, inputs)
        worker.packet_pack.finish(worker.entries)
        worker.packet_pack.close()
        prune_data(stage, worker.entries)
        index_raw = encoded(dict(version=map_index["version"], entries=worker.entries))
        stage.write("site/data/api-index.json", index_raw)
        lineage = ui_assets(stage, viewer, package, sha(index_raw), inputs, supplements, field_guide,
            same_repository=args.graph_delivery == 'same-repository')
        inputs.unchanged()
        receipt = dict(version=VERSION, status="STATIC_TRANSPORT_COMPLETE_NOT_RELEASE_QUALIFIED",
            source_report_ref=report_ref, casebook_ref=casebook_ref, digest_ref=digest_ref,
            pdf_catalog_ref=pdf_ref,
            supplement_manifest_ref=supplement_ref, supplement_assets=supplement_lineage,
            field_guide=field_guide,
            publication_manifest_projection=manifest_projection,
            collection_identity_gaps=collection_identity_gaps(report),
            response_policy=("PUBLIC_METADATA_LOCATION_PROJECTION" if args.public_metadata_projection else
                "EXACT_CASE_PACKETS_WITH_EXPLICIT_MANIFEST_ALIAS" if manifest_projection else "EXACT_VIEWER_JSON_NO_METADATA_REDACTION"),
            node_scope=args.node_scope,
            privacy_validation="NOT_RUN" if not args.public_metadata_projection else "PACKET_METADATA_SCAN_ONLY_NOT_PUBLICATION_VALIDATION",
            run_id=report["run_id"], report_version=report["version"], report_bytes_unchanged=True,
            native_versions=dict(Counter(c["native_version"] for c in worker.coverage)),
            coverage=worker.coverage, routes=len(worker.entries), requests=worker.requests,
            retained_map_pdf_routes=sum(k.startswith(("/graph-assets-v4/", "/api/graph-v4-viewer?", "/api/cib-pdf?")) for k in worker.entries),
            map_index_sha256=args.map_index_sha256, index_sha256=sha(index_raw),
            static_slots=slot_coverage, self_contained_lossless_graph_fragments=args.graph_delivery == 'fragment', pdf_scope=args.pdf_scope,
            graph_delivery=args.graph_delivery, installed_repository_self_contained=True,
            pages_fully_offline=args.graph_delivery == 'fragment',
            dataset_delivery_ref=(dict(path='data/dataset-delivery.json', sha256=sha(encoded(dataset_delivery))) if dataset_delivery else None),
            backend_root=str(code_root), backend_code_sha256=code_pin, backend_snapshot_canonical=False,
            inactive_archive_graph_routes_omitted=len(omitted_inactive_graph_routes), active_graph_assets=len(active_keys),
            reused_generic_graph_layer_sha256=graph_cache_pin, case_policy_responses_retargeted=False,
            regenerated_response_cache_hits=(worker.response_cache.hits if worker.response_cache else 0),
            api_calls=0, native_executions=0, current_native_execution=False,
            native_outputs_modified=False, metadata_projections=worker.metadata_projections,
            asset_lineage=lineage, limits=stage.limits,
            transport_guard_change=dict(previous_max_bytes=750_000_000, max_bytes=900_000_000,
                previous_max_seconds=1800, max_seconds=3600,
                reason='Lead-approved static transport recovery; below Pages 1GB, no API/native budget changes',
                resumed_existing_stage=args.resume),
            limitations=["Finite saved route/source transport, not arbitrary new guide queries or inference.",
                "Slots is an eagerly completed exact base-visible census; arbitrary allowed search/filter/page selectors run over the pinned saved catalog, not graph inference.",
                "Unbound ordinary-map PDFs are finite: both releases for all selected-case origin/evidence documents, plus retained baseline PDFs. Other catalog PDFs fail closed unless separately exported.",
                ("Graph datasets remain in the same repository: localhost uses the validated local mirror; Pages uses exact immutable same-repository RAW URLs. Pages is not fully offline." if dataset_delivery else
                 "Full graph response bytes are reconstructed losslessly from local lazy fragments; original wire/decoded hashes are retained."),
                "Node inspection scope is explicit: routes exports exact saved route nodes; displayed additionally exports every surrounding node in finite guide views. All guide phases/caps/pages remain complete in both modes.",
                "Publication validator and qualification gate have not been satisfied by this transport build.",
                "Exact replay stages can retain private audit locations in metadata and are not approved public artifacts. Explicit --public-metadata-projection removes such locations, never native results or identities."],
            release_qualified=False, publication_validator="NOT_RUN", browser_smoke="NOT_RUN")
        stage.write("site/export-lineage.json", encoded(receipt))
        # Do not inherit an old publication's approval/qualification declarations.
        stage.write("site/publication.json", encoded(dict(version=VERSION, run_id=report["run_id"],
            status="UNQUALIFIED_STATIC_STAGE", source_report_ref=report_ref, api_index="data/api-index.json",
            graph_data_manifest=json.loads((package / "site/publication.json").read_bytes()).get("graph_data_manifest"),
            files=[dict(v, path=k.removeprefix("site/")) for k, v in sorted(stage.files.items()) if k.startswith("site/")],
            release_qualified=False)))
        receipt["stored_bytes_before_receipt"] = stage.bytes
        stage.write("stage_receipt.json", encoded(receipt))
        return receipt
    finally:
        reader.close_case()
        viewer.close()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--map-root", type=Path, default=ROOT.parent / "matryoshka_demo_site")
    parser.add_argument("--map-index-sha256", required=True)
    parser.add_argument("--report-ref", type=Path, required=True)
    parser.add_argument("--casebook-ref", type=Path, required=True)
    parser.add_argument("--digest-ref", type=Path)
    parser.add_argument("--supplement-manifest", type=Path, help="Reference file pinning an explicit narrative-static-supplement/1 asset manifest")
    parser.add_argument('--field-guide-directory', type=Path, help='Explicit source-root directory containing report-bound field-guide.pdf/.txt and guide-public.json; no silent legacy fallback')
    parser.add_argument('--graph-delivery', choices=('same-repository', 'fragment'), default='same-repository',
        help='Default preserves original same-repository immutable dataset entries; fragment is the superseded offline diagnostic')
    parser.add_argument("--collection-schema-alias", action="store_true", help="Explicitly alias the exact additional list to additional_real_redaction; never add report identities or bypass UI guards")
    parser.add_argument("--public-metadata-projection", action="store_true", help="Opt in to existing private-metadata-location redactions; default preserves exact Viewer JSON")
    parser.add_argument("--node-scope", choices=("routes", "displayed"), default="routes")
    parser.add_argument("--pdf-catalog", help="Optional exact LocalPDFs catalog relative to --root")
    parser.add_argument("--pdf-catalog-sha256")
    parser.add_argument("--ui-root", type=Path, required=True)
    parser.add_argument('--backend-root', type=Path, default=HERE / 'backend', help='Explicit contained backend snapshot; final release must choose the lead-approved snapshot')
    parser.add_argument('--reuse-case-stage', type=Path, help='Reuse only a byte-verified exact report/backend/PDF case closure from a prior owned stage')
    parser.add_argument('--reuse-response-stage', type=Path, help='Immutable byte cache for unchanged public/native/origin inputs; every response is regenerated then matched by full SHA, never retargeted')
    parser.add_argument('--reuse-graph-stage', type=Path, help='Generic graph layer only; exact original map-index and every active decoded asset SHA must match')
    parser.add_argument('--resume', action='store_true', help='Resume this unsealed output in place; exact case/code/map selectors must match')
    parser.add_argument('--pdf-scope', choices=('selected', 'catalog'), default='selected', help='Ordinary map PDF scope only; case-bound PDF evidence guards stay unchanged')
    parser.add_argument("--output", type=Path, required=True)
    for name, default in DEFAULT_LIMITS.items():
        parser.add_argument("--" + name.replace("_", "-"), type=int, default=default)
    args = parser.parse_args(argv)
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError("Bounded export deadline")))
    signal.alarm(args.max_seconds)
    result = build(args)
    signal.alarm(0)
    print(json.dumps({k: result[k] for k in ("status", "run_id", "routes", "native_versions", "stored_bytes_before_receipt")}, sort_keys=True))


if __name__ == "__main__":
    main()
