"""Inventory only our failed/unsealed generated sites, then reclaim their payloads."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
REASONS = {'stage_v06_01': 'FAILED: 1.5GB guard in the inherited unfactored export',
           'stage_v06_02': 'OWNER_INTERRUPTED: optimize repeated immutable guide inspection and non-display-audit PDF expansion',
           'stage_v06_03': 'FAILED: unsharded full-slot catalog exceeded the 210MB response bound',
           'stage_v06_05': 'FAILED: 750MB guard in byte-fragment graph factoring; replacing with exact structural factoring',
           'stage_v06_06': 'OWNER_INTERRUPTED: remove obsolete unreferenced graph exports; retain exact active descriptor closure',
           'stage_v06_07': 'OWNER_INTERRUPTED: use ASCII structural sharing across API/Slots/graphs instead of base64 overhead'}


def main():
    for name, reason in REASONS.items():
        directory = HERE / name
        site = directory / 'site'
        assert directory.resolve() == directory and not (directory / 'stage_receipt.json').exists()
        if not site.exists():
            continue
        rows = [dict(path=str(p.relative_to(site)), bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                for p in sorted(site.rglob('*')) if p.is_file()]
        value = dict(status=reason, source_report_ref=json.loads((HERE.parents[2] / 'experiments/full_resume_20261120/publication_preview_v06/report_ref.json').read_text()),
                     files=rows, retained_payloads=False, bytes_reclaimed=sum(p['bytes'] for p in rows), api_calls=0)
        with (directory / 'failed_inventory.json.gz').open('xb') as stream:
            stream.write(gzip.compress(json.dumps(value, sort_keys=True).encode(), mtime=0))
        shutil.rmtree(site)
        database = directory / 'packet-dictionary.sqlite3'
        if database.exists():
            with database.open('rb') as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            (directory / 'temporary_dictionary.json').write_text(json.dumps(dict(bytes=database.stat().st_size, sha256=digest, removed=True)) + '\n')
            database.unlink()
        print(name, value['bytes_reclaimed'], flush=True)


if __name__ == '__main__':
    main()
