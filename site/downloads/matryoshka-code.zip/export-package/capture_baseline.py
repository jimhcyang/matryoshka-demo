"""Record read-only source UI and checkout boundaries for the staging task."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PACKAGE = ROOT.parent / 'matryoshka_demo_site'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def baseline():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(PACKAGE), *args], text=True).strip()
    paths = list((ROOT / 'experiments/full_resume_20261120/ui').glob('*'))
    paths.extend((PACKAGE / relative) for relative in ('README.md', 'site/publication.json', 'site/data/api-index.json'))
    return dict(checkout=dict(origin=git('remote', 'get-url', 'origin'), head=git('rev-parse', 'HEAD'), status=git('status', '--porcelain')),
        files={str(p): sha(p.read_bytes()) for p in paths if p.is_file()}, network_calls=0, api_calls=0)


if __name__ == '__main__':
    path = HERE / 'baseline.json'
    with path.open('x') as stream:
        stream.write(json.dumps(baseline(), indent=2) + '\n')
    print(path)
