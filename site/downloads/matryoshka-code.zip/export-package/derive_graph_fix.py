"""Derive a new candidate from a sealed stage; refresh only approved graph JS."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
OLD = '799acbd747279f2b12c16d17b885c1999011d2ce29b5b2feb792ad49b0e77450'
SOURCE = '9e8a82f65b88269e4c81b1c3e51bfc2de513c1427dc06698d0904e948ff6dff5'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-stage', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--graph-source', type=Path, required=True)
    args = parser.parse_args()
    original, output = args.source_stage.resolve(), args.output.absolute()
    assert original.is_relative_to(HERE) and output.is_relative_to(HERE) and not output.exists()
    old_raw = (original / 'site/release-manifest.json').read_bytes()
    assert sha(old_raw) == OLD
    raw = args.graph_source.read_bytes()
    assert sha(raw) == SOURCE, 'Lead-frozen graph source differs'
    assert shutil.disk_usage(HERE).free - 1024**3 >= 8 * 1024**3
    shutil.copytree(original, output)
    site = output / 'site'
    text = raw.decode()
    text = re.sub(r"(\bimport\s*\(\s*|\bfrom\s*)(['\"])/(?!/)([^'\"]+)\2",
        lambda m: m[1] + m[2] + './' + m[3] + m[2], text)
    for style in sorted(p.name for p in site.glob('*.css')):
        text = text.replace("'/" + style + "'", "'./" + style + "'")
        text = text.replace('"/' + style + '"', '"./' + style + '"')
    public = text.encode()
    (site / 'graph-full-v6.js').write_bytes(public)
    derivation = dict(version='frozen-graph-display-fix/1', parent_manifest_sha256=OLD,
        graph_source_sha256=SOURCE, graph_public_sha256=sha(public),
        scope='ADAPTER4_EXACT_PATH_SELECTOR_DISPLAY_GUARD_ONLY', native_or_source_packets_modified=False)
    for path in (output / 'stage_receipt.json', site / 'export-lineage.json'):
        value = json.loads(path.read_bytes())
        found = [r for r in value['asset_lineage'] if r['path'] == 'graph-full-v6.js']
        assert len(found) == 1
        found[0].update(source_sha256=SOURCE, public_sha256=sha(public))
        value['derived_display_fix'] = derivation
        path.write_bytes(encoded(value))
    allowed = {'graph-full-v6.js', 'export-lineage.json'}
    changed = []
    for row in json.loads(old_raw)['files']:
        relative = row['path']
        if sha((site / relative).read_bytes()) != row['sha256']:
            assert relative in allowed, 'Unexpected candidate change: ' + relative
            changed.append(relative)
    assert set(changed) == allowed
    (site / 'release-manifest.json').unlink()
    assert sha((original / 'site/release-manifest.json').read_bytes()) == OLD
    (output / 'derivation.json').write_bytes(encoded(dict(derivation, changed_site_files=changed)))
    print(json.dumps(dict(output=str(output), graph_public_sha256=sha(public), changed_site_files=changed, old_stage_unchanged=True)))


if __name__ == '__main__':
    main()
