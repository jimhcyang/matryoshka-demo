# Stage08 Recovery

The original Stage08 ended at the 1,800-second export alarm with `TimeoutError: Bounded export deadline` after 500 of 1,188 active graph assets. Its unsealed `site/` held 705,586,532 bytes; the 4,470,636,544-byte SQLite dictionary and completed 14-case checkpoint were retained. No final index, UI assets or stage receipt existed. The original traceback was terminal output, not a confirmed disk log.

The lead explicitly approved changing only transport guards from 750,000,000 bytes / 1,800 seconds to 900,000,000 bytes / 3,600 seconds. The 8GiB free-disk guard, source policies, original hashes, graph content and API/native execution budgets remain unchanged.

The first bounded in-place resume passed dictionary integrity and regenerated the identical complete Slots closure, then stopped because its pre-existing private `slots-parity.json` was absent from the resumed file inventory. `resume.log` records that bookkeeping error. The retry verifies and registers identical pre-existing files instead of overwriting them; `resume-02.log` records the subsequent build. No ninth full stage was created.

Exact-hash recovery found all 500 completed graph roots without re-parsing/repacking them. The six original local bootstrap assets were already available, leaving 682 external assets. Subsequent roots and route entries are atomically checkpointed in `graph-progress.json` every 50 new assets. Inactive archive routes are removed and unreachable physical data is pruned before further packing. All chunks used by the still-unsealed dictionary are protected.

The proposed 319MiB orphan-DAG deletion was not assumed safe: the actual pre-resume site contained 417,685,389 bytes in packet chunks, 263,710,849 bytes of PDFs and 14,324,899 bytes of replay JSON, plus bootstrap/manifests. Required PDFs and referenced fragments are not expendable. Case/Slots roots account for approximately 58.8MB of the packet-chunk prefix, rather than a separate removable 319MiB archive.

## Final Data Replacement

After the generic layer is frozen, run the generic exporter with fresh explicit `--report-ref`, `--casebook-ref`, `--digest-ref`, `--backend-root`, `--ui-root`, supplement and PDF pins plus `--reuse-graph-stage`. Graph reuse requires an exact original map-index hash and every active asset's original decoded SHA256. It copies graph assets only; case-bound sources, guides, eligibility, native responses, digests and Slots/workbench links are regenerated from the new inputs. `--reuse-case-stage` is not valid for changed case inputs.

The baseline backend snapshot used by this recovery is test-only, not the canonical final engine. `snapshot.py --backend-only` can prepare a distinct contained snapshot from the lead-selected code, and `bundle_code.py --backend-root` can bundle that selection. No deployment, checkout installation, commit, push, data qualification or privacy authorization is performed by this worker.
