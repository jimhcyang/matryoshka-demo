"""Run preserved generic transport tests against this export's adapted runtime."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

from export_narrative import adapt_runtime

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.absolute()
    assert output.is_relative_to(HERE) and not output.exists()
    (output / 'runtime/tests').mkdir(parents=True)
    (output / 'tools').mkdir()
    refs = []
    for name in ('runtime_browser_test.py', 'runtime_fragment_test.py', 'runtime_external_test.py'):
        raw = (source / 'runtime/tests' / name).read_bytes()
        (output / 'runtime/tests' / name).write_bytes(raw)
        refs.append(dict(path='runtime/tests/' + name, sha256=hashlib.sha256(raw).hexdigest()))
    for name in ('public-runtime.js', 'replay.html', 'replay.js'):
        raw = (HERE / 'vendor/runtime' / name).read_bytes()
        if name == 'public-runtime.js':
            raw = adapt_runtime(raw)
        (output / 'runtime' / name).write_bytes(raw)
    (output / 'tools/pack_graphs.py').write_bytes((HERE / 'vendor/tools/pack_graphs.py').read_bytes())
    result = subprocess.run([sys.executable, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
        '--basetemp', str(output / 'tmp'), str(output / 'runtime/tests')], cwd=output,
        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'), text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / 'pytest.log').write_text(result.stdout)
    receipt = dict(success=result.returncode == 0, exit_code=result.returncode, original_tests=refs,
        runtime_sha256=hashlib.sha256((output / 'runtime/public-runtime.js').read_bytes()).hexdigest(),
        scope='Generic synthetic transport fixtures, not research/source qualification; actual maps tested separately',
        managed_chromium_headless_shell_only=True, original_checkout_modified=False, api_calls=0, native_executions=0)
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(result.stdout)
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
