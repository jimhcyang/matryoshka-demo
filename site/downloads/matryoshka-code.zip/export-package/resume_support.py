"""Recover an interrupted transport build by exact bytes, never graph inference."""
from collections import OrderedDict, defaultdict
import gzip
import hashlib
import json
from pathlib import Path
import struct


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def restore_pack(pack):
    assert pack.db.execute('PRAGMA quick_check').fetchone()[0] == 'ok', 'Interrupted dictionary is corrupt'
    chunks = []
    directory = pack.stage.output / 'site/data/packet-pack'
    for path in (directory / 'chunks').glob('*.json.gz'):
        wire = path.read_bytes()
        assert path.stem == sha(wire) + '.json', 'Resume chunk wire hash differs'
        raw = gzip.decompress(wire)
        payload = json.loads(raw)
        assert payload['version'] == 'graph-fragment-dag-chunk/1'
        chunks.append(dict(first_id=payload['first_id'], last_id=payload['first_id'] + len(payload['fragments']) - 1,
            path='chunks/' + path.name, encoding='gzip', decoded_bytes=len(raw), wire_bytes=len(wire),
            sha256decoded=sha(raw), wire_sha256=sha(wire)))
    chunks.sort(key=lambda c: c['first_id'])
    for i, chunk in enumerate(chunks):
        assert chunk['first_id'] == (chunks[i-1]['last_id'] + 1 if i else 1), 'Resume chunks are not contiguous'
        chunk['id'] = i
    count, last = pack.db.execute('SELECT count(*),max(id) FROM fragments').fetchone()
    assert count == last == chunks[-1]['last_id'], 'Committed dictionary/chunk boundary differs; do not guess a tail'
    pack.chunks, pack.total_nodes = chunks, last
    checkpoint = json.loads((pack.stage.output / 'case_checkpoint.json').read_bytes())
    manifests = {e['path']:e['manifest_sha256'] for e in checkpoint['entries'].values() if e['encoding'] == 'fragment-dag'}
    for path, pin in manifests.items():
        raw = (pack.stage.output / 'site' / path).read_bytes()
        assert sha(raw) == pin
        manifest = json.loads(raw)
        assert manifest.get('literal_encoding', 'ascii') == pack.literal_encoding
        pack.roots.update(manifest['assets'])
    progress = pack.stage.output / 'graph-progress.json'
    if progress.exists():
        value = json.loads(progress.read_bytes())
        assert value['dictionary_nodes'] <= last
        pack.roots.update(value['roots'])
    print(json.dumps(dict(resumed_dictionary_nodes=last, chunks=len(chunks), cached_roots=len(pack.roots))), flush=True)


def checkpoint_graphs(worker):
    worker.packet_pack.flush()
    path = worker.stage.output / 'graph-progress.json'
    raw = encoded(dict(version='static-graph-progress/1', dictionary_nodes=worker.packet_pack.total_nodes,
        roots=worker.packet_pack.roots, entries=worker.entries))
    temporary = path.with_suffix('.tmp')
    with temporary.open('wb') as handle:
        handle.write(raw)
        handle.flush()
        __import__('os').fsync(handle.fileno())
    temporary.replace(path)


def recover_graphs(worker, maps, active_keys):
    pack = worker.packet_pack
    progress = worker.stage.output / 'graph-progress.json'
    if progress.exists():
        saved = json.loads(progress.read_bytes())
        for key, entry in saved['entries'].items():
            if key in active_keys and entry['encoding'] == 'fragment-dag':
                assert entry['sha256'] == maps.entries[key]['sha256']
                worker.entries[key] = entry
    # The gzip footer only narrows candidates. Acceptance requires the complete
    # reconstructed SHA256 to equal the original immutable map-index decoded pin.
    targets = defaultdict(dict)
    for key in sorted(active_keys):
        entry = worker.entries[key]
        if not entry.get('external_url'):
            continue
        relative = entry['external_url'].split('/datasets/', 1)[1]
        path = maps.root / 'datasets' / relative
        assert path.resolve() == path
        with path.open('rb') as handle:
            handle.seek(-4, 2)
            size = struct.unpack('<I', handle.read(4))[0]
        targets[size][entry['sha256']] = key
    if not targets:
        return
    worker.stage.guard()
    pack.db.execute('CREATE INDEX IF NOT EXISTS fragments_size ON fragments(size)')
    pack.db.commit()
    pieces_cache = OrderedDict()

    def digest(identity):
        checksum, size, stack = hashlib.sha256(), 0, [identity]
        while stack:
            value = stack.pop()
            if type(value) is int:
                if value not in pieces_cache:
                    pieces_cache[value] = json.loads(pack.db.execute('SELECT pieces FROM fragments WHERE id=?', (value,)).fetchone()[0])
                    if len(pieces_cache) > 65536:
                        pieces_cache.popitem(last=False)
                pieces_cache.move_to_end(value)
                stack.extend(reversed(pieces_cache[value]))
            else:
                raw = value.encode('ascii')
                checksum.update(raw)
                size += len(raw)
        return checksum.hexdigest(), size

    recovered = 0
    for size, expected in targets.items():
        for identity, dependencies in pack.db.execute('SELECT id,dependencies FROM fragments WHERE size=?', (size,)):
            worker.stage.guard()
            checksum, actual_size = digest(identity)
            if actual_size == size and checksum in expected:
                key = expected[checksum]
                source = maps.entries[key]
                pack.roots[checksum] = dict(encoding='fragment-dag', pieces=['', identity, ''], decoded_bytes=size,
                    sha256decoded=checksum, dependencies=json.loads(dependencies))
                worker.entries[key] = dict(encoding='fragment-dag', path=pack.path, asset=checksum, sha256=checksum,
                    mime=source['mime'], original_wire_sha256=source['wire_sha256'], original_external_url=source['external_url'])
                recovered += 1
                if recovered % 50 == 0:
                    checkpoint_graphs(worker)
                    print(json.dumps(dict(graph_roots_recovered=recovered)), flush=True)
                break
    checkpoint_graphs(worker)
    for key in active_keys:
        source = worker.entries[key]
        if source.get('external_url') and source['sha256'] in pack.roots:
            checksum = source['sha256']
            worker.entries[key] = dict(encoding='fragment-dag', path=pack.path, asset=checksum, sha256=checksum,
                mime=source['mime'], original_wire_sha256=source['wire_sha256'], original_external_url=source['external_url'])
    checkpoint_graphs(worker)
    print(json.dumps(dict(graph_roots_recovered=recovered, remaining=sum(bool(worker.entries[k].get('external_url')) for k in active_keys))), flush=True)
