"""Completed response maps survive independently of a live Python process."""
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

from case_progress import save
from export_narrative import HERE, Stage, encoded
from packet_pack import PacketPack, read_packed


class CaseProgressTests(unittest.TestCase):
    def test_atomic_partial_checkpoint_has_readable_roots_and_no_completed_receipt(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            stage = Stage(Path(temporary) / 'stage')
            pack = PacketPack(stage)
            raw = encoded(dict(exact_saved_response='body ' * 10000))
            entry = pack.put(raw)
            worker = SimpleNamespace(stage=stage, packet_pack=pack, entries={'/api/current/example':entry}, coverage=[], metadata_projections=[])
            save(worker, {'report_ref':{'sha256':'a'*64}}, ['saved-case'])
            value = json.loads((stage.output / 'case-progress.json').read_bytes())
            self.assertEqual(value['status'], 'PARTIAL_NOT_RELEASE_QUALIFIED')
            self.assertEqual(value['completed_case_ids'], ['saved-case'])
            pack.db.close()
            self.assertEqual(read_packed(stage.output / 'site', value['entries']['/api/current/example']), raw)
            self.assertFalse((stage.output / 'stage_receipt.json').exists())
            self.assertFalse((stage.output / 'case-progress.tmp').exists())


if __name__ == '__main__':
    unittest.main()
