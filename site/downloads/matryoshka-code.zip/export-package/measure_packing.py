"""Bounded codec measurement on actual active graph shards, no full rebuild."""
import gzip
import json
from pathlib import Path
import sys
import time

from packet_pack import PacketPack
from structural_pack import put_graph
from graph_closure import active_graph_keys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(HERE / 'backend'))
from matryoshka_current.map_transport import SavedMaps


class Stage:
    def __init__(self, output):
        self.output = output
        output.mkdir(parents=True, exist_ok=False)
    def write(self, relative, raw):
        path = self.output / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists(): assert path.read_bytes() == raw
        else: path.write_bytes(raw)


def main():
    output = HERE / 'packing-probe-01'
    output.mkdir(exist_ok=False)
    package = ROOT.parent / 'matryoshka_demo_site'
    index = json.loads((package / 'site/data/api-index.json').read_bytes())['entries']
    maps = SavedMaps(package, 'a4f08ac865bb21faed97e1792fc2c84baba0e8483f5fb92c7604fec96f5e30f0')
    active = active_graph_keys(maps, index)
    selected = []
    for corpus in ('cib','iran','vietnam'):
        for kind in ('adjacency','neighborhood'):
            matches = sorted(k for k in active if k.startswith('/graph-assets-v4/'+corpus+'/') and 'current_' in k and kind in k and '.00.' in k)
            assert matches, (corpus,kind)
            selected.append(matches[0])
    rows=[]
    for minimum in (256, 32):
        stage=Stage(output/str(minimum))
        pack=PacketPack(stage)
        entries={};start=time.monotonic();original=0
        for key in selected:
            raw,_=maps.packet(key)
            original+=len(raw)
            entries[key]=put_graph(pack,raw,index[key]['sha256'],minimum=minimum)
        pack.finish(entries);pack.close()
        size=sum(p.stat().st_size for p in stage.output.rglob('*') if p.is_file())
        rows.append(dict(minimum=minimum,bytes=size,decoded_bytes=original,elapsed_seconds=round(time.monotonic()-start,3)))
        print(json.dumps(rows[-1]),flush=True)
    result=dict(selected=selected,measurements=rows,source_graph_bytes_preserved=True,native_executions=0,api_calls=0,
        scope='Six actual active shards only; not a full-corpus compression or browser pass')
    (output/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')


if __name__=='__main__':main()
