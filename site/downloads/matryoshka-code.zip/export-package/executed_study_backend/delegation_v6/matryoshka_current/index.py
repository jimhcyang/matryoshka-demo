"""Content-addressed current CIB index with explicit, typed authority routes."""
from contextlib import AbstractContextManager
from copy import deepcopy
from datetime import date
from functools import lru_cache
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sqlite3
import uuid
import zlib

from matryoshka_demo.io import digest as shared_digest
from matryoshka_demo.source_view_policy import (
    STRICT_PRIOR, LIVE_POLICIES, SUPPLIED_DOCUMENTS_INCLUSIVE, descriptor, require_policy)

from . import resources as r

VERSION = "matryoshka-current-typed-source-index/1"
_MASK = re.compile(r"\[(?:REDACTED|REDACTION|MASK|UNKNOWN)[^\]]*\]", re.I)
_ID_FIELDS = {"entity_mentions": "mention_id", "event_mentions": "event_mention_id", "claim_mentions": "claim_mention_id"}
_TYPES = {"entity_mentions": "Entity", "event_mentions": "Event", "claim_mentions": "Claim"}


def _pack(value):
    return zlib.compress(json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode())


def _unpack(value):
    return json.loads(zlib.decompress(value))


def _rows(workspace, registry, name):
    path = r.safe_path(workspace, registry["files"][name]["path"])
    with path.open() as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def _iso(value):
    if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
        raise ValueError("Exact ISO source date required")
    return value


def _native_node(prefix, observation_id):
    return prefix + "_" + hashlib.sha256(observation_id.encode()).hexdigest()[:20]


def _validate_metadata(row, job, document):
    for field in ("document_id", "record_id", "document_date_iso"):
        if row.get(field) != job.get(field):
            raise ValueError(f"Observation/job metadata mismatch: {field}")
    if row["document_date_iso"] != document["document_date_iso"] or row["record_id"] != document["record_id"]:
        raise ValueError("Observation/original prepared document metadata mismatch")
    if row.get("canonical_page_id") != job.get("canonical_page_id") or row.get("visibility") != job.get("visibility"):
        raise ValueError("Observation/job page or visibility mismatch")
    for value in (row, job):
        nested = value.get("source_provenance", {})
        if any(nested.get(k, value[k]) != value[k] for k in ("record_id", "document_date_iso")):
            raise ValueError("Conflicting nested provenance")


def build_index(workspace, registry, new_output_root, *, minimum_free_bytes=6 * 1024**3):
    output = r.safe_path(workspace, new_output_root, must_exist=False)
    if "graph_indexes_v2" in output.parts or "preparation_refresh" in output.parts:
        raise ValueError("Refusing an incumbent or producer output directory")
    output.mkdir(parents=True, exist_ok=True)
    with (output / ".build.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return _build_index(workspace, registry, output, minimum_free_bytes=minimum_free_bytes)


def _build_index(workspace, registry, new_output_root, *, minimum_free_bytes):
    """Build a fresh index. Incomplete attempts survive; completed ones are reused."""
    r.check_registry(registry)
    root = Path(workspace).absolute()
    output = r.safe_path(root, new_output_root, must_exist=False)
    if "graph_indexes_v2" in output.parts or "preparation_refresh" in output.parts:
        raise ValueError("Refusing an incumbent or producer output directory")
    r.verify_files(root, registry)
    identity = dict(version=VERSION, registry_digest=registry["registry_digest"],
        builder_sha256=r.file_sha(__file__), resources_sha256=r.file_sha(r.__file__))
    index_id = "current_index_" + r.digest(identity)[:24]
    directory = output / index_id
    directory.mkdir(parents=True, exist_ok=True)
    completed = directory / "manifest.json"
    if completed.exists():
        manifest = r.load_json(completed)
        reference = dict(path=r.relative(root, directory / "graph.sqlite3"), sha256=manifest["index_sha256"],
            manifest=dict(path=r.relative(root, completed), sha256=r.file_sha(completed)),
            registry_digest=registry["registry_digest"], resource_id=registry["resource_id"], index_id=index_id)
        with CorpusIndex(root, registry, reference):
            pass
        return reference
    if shutil.disk_usage(directory).free < minimum_free_bytes:
        raise RuntimeError("Insufficient disk headroom; no source or completed index deleted")
    temporary = directory / ("building_" + uuid.uuid4().hex + ".sqlite3")
    db = sqlite3.connect(temporary)
    db.row_factory = sqlite3.Row
    counters = {}
    try:
        db.executescript('''
        PRAGMA journal_mode=DELETE;
        CREATE TABLE metadata(key TEXT PRIMARY KEY,payload TEXT NOT NULL);
        CREATE TABLE document(id TEXT PRIMARY KEY,date TEXT NOT NULL,payload BLOB NOT NULL);
        CREATE TABLE page(id TEXT PRIMARY KEY,doc TEXT NOT NULL,date TEXT NOT NULL,eligible INTEGER NOT NULL,payload TEXT NOT NULL);
        CREATE INDEX page_scope ON page(eligible,date,doc);
        CREATE VIRTUAL TABLE page_fts USING fts5(id UNINDEXED,text);
        CREATE TABLE job(id TEXT PRIMARY KEY,payload BLOB NOT NULL);
        CREATE TABLE canonical(id TEXT PRIMARY KEY,route_class TEXT NOT NULL,payload BLOB NOT NULL);
        CREATE TABLE node(id TEXT PRIMARY KEY,kind TEXT NOT NULL,payload BLOB NOT NULL);
        CREATE TABLE assignment(mention TEXT PRIMARY KEY,node TEXT NOT NULL,profile TEXT,job TEXT,page TEXT,doc TEXT,payload BLOB NOT NULL);
        CREATE INDEX assignment_node ON assignment(node,page);
        CREATE TABLE observation(id TEXT PRIMARY KEY,job TEXT NOT NULL,local TEXT NOT NULL,node TEXT,kind TEXT NOT NULL,
            page TEXT,doc TEXT,date TEXT,eligible INTEGER NOT NULL,reason TEXT,payload BLOB NOT NULL,UNIQUE(job,local));
        CREATE INDEX observation_node ON observation(node,eligible,page);
        CREATE TABLE assertion(id TEXT PRIMARY KEY,a TEXT,b TEXT,a_observation TEXT,b_observation TEXT,page TEXT,doc TEXT,date TEXT,
            eligible INTEGER NOT NULL,reason TEXT,payload BLOB NOT NULL);
        CREATE INDEX assertion_a ON assertion(a,eligible,page);
        CREATE INDEX assertion_b ON assertion(b,eligible,page);
        CREATE TABLE relation(id TEXT PRIMARY KEY,payload BLOB NOT NULL);
        CREATE TABLE membership(node TEXT PRIMARY KEY,payload BLOB NOT NULL);
        CREATE TABLE context(row_id INTEGER PRIMARY KEY,id TEXT,entity TEXT,job TEXT,page TEXT,doc TEXT,eligible INTEGER,reason TEXT,payload BLOB NOT NULL);
        CREATE INDEX context_scope ON context(job,page,eligible);
        CREATE TABLE route(id INTEGER PRIMARY KEY,hub TEXT,target TEXT,kind TEXT,payload BLOB NOT NULL);
        CREATE INDEX route_target ON route(target);
        CREATE INDEX route_hub ON route(hub);
        CREATE TABLE audit(kind TEXT,id INTEGER,payload BLOB NOT NULL,PRIMARY KEY(kind,id));
        ''')
        documents = {}
        for row in _rows(root, registry, "documents"):
            _iso(row["document_date_iso"])
            if row["document_id"] in documents:
                raise ValueError("Duplicate document identity")
            documents[row["document_id"]] = row
            db.execute("INSERT INTO document VALUES(?,?,?)", (row["document_id"], row["document_date_iso"], _pack(row)))
        quarantined = set()
        for i, row in enumerate(_rows(root, registry, "quarantine")):
            quarantined.add(row["page_pair_id"])
            db.execute("INSERT INTO audit VALUES(?,?,?)", ("prepared_quarantine", i, _pack(row)))
        guard = r.load_json(r.safe_path(root, registry["files"]["source_quarantine_policy"]["path"]))
        quarantined.update(p["canonical_page_id"] for p in guard["quarantined_pages"] + guard["quarantined_jobs"])
        pages = {}
        for row in _rows(root, registry, "pages"):
            pid, did = row["canonical_page_id"], row["document_id"]
            doc = documents[did]
            if row.get("view") != "earlier" or pid in pages:
                raise ValueError("Duplicate or non-earlier canonical page")
            text = row["text"]
            page = dict(id=pid, corpus="cib", document_id=did, date=doc["document_date_iso"], text=text,
                source_sha256=shared_digest(text), source_hash_contract="shared-json-string-ensure-ascii-true/sha256",
                raw_text_sha256=hashlib.sha256(text.encode()).hexdigest(),
                permitted=pid not in quarantined, visibility="earlier", earlier_page=row.get("source_page"),
                canonical_sequence=row.get("sequence_in_document"), classification=doc.get("classification_level"),
                handling=doc.get("distribution_controls", []), native_page=row)
            pages[pid] = page
            db.execute("INSERT INTO page VALUES(?,?,?,?,?)", (pid, did, page["date"], int(page["permitted"]), json.dumps(page, ensure_ascii=False)))
            if page["permitted"]:
                db.execute("INSERT INTO page_fts VALUES(?,?)", (pid, text))
        for row in _rows(root, registry, "jobs"):
            doc = documents[row["document_id"]]
            _validate_metadata(row, row, doc)
            db.execute("INSERT INTO job VALUES(?,?)", (row["job_id"], _pack(row)))
        for row in _rows(root, registry, "canonical_entities"):
            db.execute("INSERT INTO canonical VALUES(?,?,?)", (row["canonical_entity_id"], r.authority(row)["route_class"], _pack(row)))
        kinds = {}
        for row in _rows(root, registry, "semantic_nodes"):
            nid, kind = row["node_id"], row["node_type"]
            if kind not in {"Entity", "Event", "Claim"} or nid in kinds:
                raise ValueError("Unknown or duplicate semantic node kind")
            kinds[nid] = kind
            db.execute("INSERT INTO node VALUES(?,?,?)", (nid, kind, _pack(row)))
        for row in _rows(root, registry, "mention_assignments"):
            if row.get("alias_run_id") != registry["alias_id"]:
                raise ValueError("Mixed alias assignment release")
            db.execute("INSERT INTO assignment VALUES(?,?,?,?,?,?,?)", (row["mention_id"], row["canonical_entity_id"],
                row.get("surface_profile_id"), row["job_id"], row["canonical_page_id"], row["document_id"], _pack(row)))

        @lru_cache(maxsize=2048)
        def job(identity):
            found = db.execute("SELECT payload FROM job WHERE id=?", (identity,)).fetchone()
            if not found:
                raise ValueError("Observation has no bound extraction job")
            return _unpack(found[0])

        def citation_eligible(row):
            bound = job(row["job_id"])
            _validate_metadata(row, bound, documents[row["document_id"]])
            page = pages.get(row["canonical_page_id"])
            if row["visibility"] not in {"both", "earlier_only"}:
                return False, "NOT_EARLIER_VISIBLE"
            if page is None or not page["permitted"]:
                return False, "MISSING_OR_QUARANTINED_EARLIER_PAGE"
            a, b, text = row.get("char_start"), row.get("char_end"), row.get("evidence_quote")
            if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"]) or page["text"][a:b] != text:
                return False, "QUOTE_NOT_LITERAL_IN_MASKED_EARLIER_SOURCE"
            if _MASK.search(text):
                return False, "OPAQUE_QUOTATION"
            if any(x.get("canonical_page_id") in quarantined for x in bound.get("context_provenance", [])):
                return False, "QUARANTINED_EXTRACTION_CONTEXT"
            return True, None

        for table, id_field in _ID_FIELDS.items():
            for row in _rows(root, registry, table):
                oid = row[id_field]
                if not isinstance(oid, str) or not oid:
                    raise ValueError("Nonempty unique observation identity required")
                if table == "entity_mentions":
                    assignment = db.execute("SELECT * FROM assignment WHERE mention=?", (oid,)).fetchone()
                    if not assignment or (assignment["job"], assignment["page"], assignment["doc"]) != (
                            row["job_id"], row["canonical_page_id"], row["document_id"]):
                        raise ValueError("Source occurrence/alias assignment mismatch")
                    nid = assignment["node"]
                else:
                    nid = _native_node("event" if table == "event_mentions" else "claim", oid)
                eligible, reason = citation_eligible(row)
                if kinds.get(nid) != _TYPES[table]:
                    eligible, reason = False, "NO_TYPED_EARLIER_GRAPH_NODE"
                db.execute("INSERT INTO observation VALUES(?,?,?,?,?,?,?,?,?,?,?)", (oid, row["job_id"], row["local_id"],
                    nid, _TYPES[table], row["canonical_page_id"], row["document_id"], row["document_date_iso"], int(eligible), reason, _pack(row)))
        for row in _rows(root, registry, "relation_evidence"):
            _validate_metadata(row, job(row["job_id"]), documents[row["document_id"]])
            db.execute("INSERT INTO relation VALUES(?,?)", (row["relation_evidence_id"], _pack(row)))
        for edge in _rows(root, registry, "semantic_edge_evidence"):
            found = db.execute("SELECT payload FROM relation WHERE id=?", (edge["relation_evidence_id"],)).fetchone()
            if not found:
                raise ValueError("Graph assertion has no source relation ledger")
            row = _unpack(found[0])
            if any(edge[k] != row[k] for k in ("job_id", "document_id", "document_date_iso", "canonical_page_id", "visibility")):
                raise ValueError("Graph assertion/source ledger metadata mismatch")
            if edge["relation_type"] != row["relation"]:
                raise ValueError("Native relation type changed")
            endpoints = [db.execute("SELECT * FROM observation WHERE job=? AND local=?", (row["job_id"], row[k])).fetchone()
                for k in ("source", "target")]
            if any(x is None for x in endpoints):
                raise ValueError("Unbound typed relation endpoint")
            if [x["node"] for x in endpoints] != [edge["source_id"], edge["target_id"]]:
                raise ValueError("Typed graph endpoints disagree with local source observations")
            eligible, reason = citation_eligible(row)
            if not all(x["eligible"] for x in endpoints):
                eligible, reason = False, "ENDPOINT_WITHOUT_ELIGIBLE_LITERAL_QUOTATION"
            payload = dict(native_edge=edge, native_relation=row, source_kind=endpoints[0]["kind"], target_kind=endpoints[1]["kind"],
                relation_evidence_id=row["relation_evidence_id"], assertion_mode=row.get("assertion_mode"),
                source_observation_id=endpoints[0]["id"], target_observation_id=endpoints[1]["id"],
                source_assertion_not_world_truth=True)
            db.execute("INSERT INTO assertion VALUES(?,?,?,?,?,?,?,?,?,?,?)", (edge["semantic_edge_id"] + ":" + edge["relation_evidence_id"], edge["source_id"], edge["target_id"],
                endpoints[0]["id"], endpoints[1]["id"], row["canonical_page_id"], row["document_id"], row["document_date_iso"],
                int(eligible), reason, _pack(payload)))
        for row in _rows(root, registry, "memberships"):
            if row["node_id"] not in kinds:
                raise ValueError("Hierarchy membership has no matching graph node")
            db.execute("INSERT INTO membership VALUES(?,?)", (row["node_id"], _pack(row)))
        for i, row in enumerate(_rows(root, registry, "reference_routes")):
            kind = "WITHHELD_DISTINCTION" if row.get("relation_type") == "SCOPED_CANNOT_LINK" else (
                "SOURCE_SCOPED_REFERENCE" if row.get("relation_type") == "NAME_REFERS_TO_CONTEXT"
                and row.get("is_evidence") is False and row.get("eligible_as_semantic_shortcut") is False else "UNKNOWN_WITHHELD")
            db.execute("INSERT INTO route VALUES(?,?,?,?,?)", (i, row.get("name_hub_id"), row.get("target_entity_id"), kind, _pack(row)))
        for context_row_id, row in enumerate(_rows(root, registry, "contextual_source_contexts")):
            page = pages.get(row.get("canonical_page_id"))
            bound = job(row["job_id"])
            if (row["document_id"], row["canonical_page_id"], row["document_date_iso"]) != (
                    bound["document_id"], bound["canonical_page_id"], bound["document_date_iso"]):
                raise ValueError("Reference context source metadata mismatch")
            paragraph = row.get("paragraph")
            eligible = bool(page and page["permitted"] and isinstance(paragraph, str) and paragraph
                and paragraph in page["text"] and not _MASK.search(paragraph) and row.get("visibility") in {"both", "earlier_only"})
            db.execute("INSERT INTO context VALUES(?,?,?,?,?,?,?,?,?)", (context_row_id, row["context_id"], row.get("entity_id"), row["job_id"],
                row["canonical_page_id"], row["document_id"], int(eligible), None if eligible else "UNBOUND_OR_INELIGIBLE_REFERENCE_CONTEXT", _pack(row)))
        for name in ("accepted_alias_edges", "candidate_decisions", "projection_holds", "withheld_source_contexts", "identity_provenance", "topology_edges"):
            for i, row in enumerate(_rows(root, registry, name)):
                db.execute("INSERT INTO audit VALUES(?,?,?)", (name, i, _pack(row)))
        for table in ("document", "page", "canonical", "node", "assignment", "observation", "assertion", "context", "route", "membership", "audit"):
            counters[table] = db.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
        counters["eligible_observations"] = db.execute("SELECT COUNT(*) FROM observation WHERE eligible=1").fetchone()[0]
        counters["eligible_assertions"] = db.execute("SELECT COUNT(*) FROM assertion WHERE eligible=1").fetchone()[0]
        db.execute("INSERT INTO metadata VALUES(?,?)", ("identity", json.dumps(identity, sort_keys=True)))
        db.execute("INSERT INTO metadata VALUES(?,?)", ("resource_id", json.dumps(registry["resource_id"])))
        db.commit()
        if db.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
            raise ValueError("SQLite integrity check failed")
    except sqlite3.IntegrityError as error:
        db.rollback()
        raise ValueError("Duplicate or ambiguous native identity in index input") from error
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
    r.verify_files(root, registry)
    path = directory / "graph.sqlite3"
    if path.exists():
        raise ValueError("Uncommitted index already exists; preserve it for diagnosis")
    os.link(temporary, path)
    temporary.unlink()
    manifest = dict(version=VERSION, identity=identity, index_id=index_id, resource_id=registry["resource_id"],
        registry_digest=registry["registry_digest"], index_sha256=r.file_sha(path), counts=counters,
        authority_contract=registry["authority_contract"], source_policy=registry["evidence_policy"], api_calls=0,
        historical_identities_and_hierarchy_retrospective=True, benchmark_authorized=False)
    r.immutable_json(completed, manifest)
    return dict(path=r.relative(root, path), sha256=manifest["index_sha256"],
        manifest=dict(path=r.relative(root, completed), sha256=r.file_sha(completed)),
        registry_digest=registry["registry_digest"], resource_id=registry["resource_id"], index_id=index_id)


def extend_index(workspace, parent_registry, parent_reference, registry, new_output_root,
                 *, minimum_free_bytes=8 * 1024**3):
    """Copy-on-write source edition; semantic/alias/hierarchy tables stay intact."""
    import sys
    from .supplemental_sources import Registration
    root = Path(workspace).absolute()
    r.check_registry(parent_registry)
    r.check_registry(registry)
    if (registry["resource_id"] != parent_registry["resource_id"]
            or any(registry[k] != parent_registry[k] for k in ("alias_id","graph_id","hierarchy_id"))
            or r.load_json(r.safe_path(root,registry["parent_registry_ref"]["path"])) != parent_registry
            or r.file_sha(r.safe_path(root,registry["parent_registry_ref"]["path"])) != registry["parent_registry_ref"]["sha256"]):
        raise ValueError("Source edition must retain and pin its canonical KG parent")
    registration = Registration(root,registry)
    output = r.safe_path(root,new_output_root,must_exist=False)
    if "graph_indexes_v2" in output.parts or "preparation_refresh" in output.parts:
        raise ValueError("Supplied editions cannot overwrite incumbent/producer outputs")
    output.mkdir(parents=True,exist_ok=True)
    identity = dict(version=VERSION,registry_digest=registry["registry_digest"],
        builder_sha256=r.file_sha(__file__),resources_sha256=r.file_sha(r.__file__),
        parent_index_ref=parent_reference,source_edition_id=registry["source_edition_id"],
        supplemental_sources_sha256=r.file_sha(sys.modules[Registration.__module__].__file__))
    index_id = "current_index_"+r.digest(identity)[:24]
    directory = output/index_id
    directory.mkdir(exist_ok=True)
    completed = directory/"manifest.json"
    def reference(manifest):
        return dict(path=r.relative(root,directory/"graph.sqlite3"),sha256=manifest["index_sha256"],
            manifest=dict(path=r.relative(root,completed),sha256=r.file_sha(completed)),
            registry_digest=registry["registry_digest"],resource_id=registry["resource_id"],index_id=index_id)
    with (output/".supplement-build.lock").open("a") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        if completed.exists():
            result = reference(r.load_json(completed))
            with CorpusIndex(root,registry,result):
                pass
            return result
        with CorpusIndex(root,parent_registry,parent_reference):
            pass
        source = r.safe_path(root,parent_reference["path"])
        if source.parent == directory or (directory/"graph.sqlite3").exists():
            raise ValueError("Refusing incumbent or incomplete edition overwrite")
        temporary = directory/("building_"+uuid.uuid4().hex+".sqlite3")
        if shutil.disk_usage(directory).free < minimum_free_bytes:
            raise RuntimeError("Insufficient supplied-edition disk headroom")
        mode = "PHYSICAL_COPY_WITH_RESERVED_HEADROOM"
        cloned = False
        if sys.platform == "darwin":
            import ctypes
            libc = ctypes.CDLL(None,use_errno=True)
            clonefile = libc.clonefile
            clonefile.argtypes = [ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int]
            clonefile.restype = ctypes.c_int
            cloned = clonefile(os.fsencode(source),os.fsencode(temporary),0) == 0
            if cloned:
                mode = "APFS_COPY_ON_WRITE_CLONE"
        if not cloned:
            if shutil.disk_usage(directory).free < minimum_free_bytes + source.stat().st_size:
                raise RuntimeError("No copy-on-write support and insufficient space for safe physical index copy")
            shutil.copyfile(source,temporary)
        if source.stat().st_ino == temporary.stat().st_ino:
            raise ValueError("Hard-linked incumbent index is never writable")
        db = sqlite3.connect(temporary)
        try:
            db.execute("CREATE TABLE supplied_page(id TEXT PRIMARY KEY,payload_sha256 TEXT NOT NULL)")
            added_documents = 0
            for did,doc in registration.documents.items():
                found = db.execute("SELECT date,payload FROM document WHERE id=?",(did,)).fetchone()
                if found is not None and found[0] != doc["document_date"]:
                    raise ValueError("Supplied historical document date disagrees with canonical parent")
                if found is not None and _unpack(found[1]).get("record_id") != doc["record_id"]:
                    raise ValueError("Supplied original record identity disagrees with canonical parent")
                if found is None:
                    metadata = dict(document_id=did,record_id=doc["record_id"],document_date_iso=doc["document_date"],
                        classification_level=doc.get("structured_classification","unknown"))
                    db.execute("INSERT INTO document VALUES(?,?,?)",(did,doc["document_date"],_pack(metadata)))
                    added_documents += 1
            for page in registration.pages():
                db.execute("INSERT INTO page VALUES(?,?,?,?,?)",(page["id"],page["document_id"],page["date"],1,
                    json.dumps(dict(page),ensure_ascii=False,allow_nan=False)))
                db.execute("INSERT INTO page_fts VALUES(?,?)",(page["id"],page["text"]))
                db.execute("INSERT INTO supplied_page VALUES(?,?)",(page["id"],registration.page_hashes[page["id"]]))
            db.execute("UPDATE metadata SET payload=? WHERE key='identity'",(json.dumps(identity,sort_keys=True),))
            db.execute("INSERT INTO metadata VALUES(?,?)",("source_edition",json.dumps(dict(
                source_edition_id=registration.edition_id,source_manifest_ref=registration.manifest_ref),sort_keys=True)))
            db.commit()
            if db.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise ValueError("Supplied edition SQLite check failed")
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()
        if r.file_sha(source) != parent_reference["sha256"]:
            raise ValueError("Canonical parent changed during edition build")
        Registration(root,registry)
        final = directory/"graph.sqlite3"
        os.link(temporary,final)
        temporary.unlink()
        parent_manifest = r.load_json(r.safe_path(root,parent_reference["manifest"]["path"]))
        counts = dict(parent_manifest["counts"])
        counts["page"] += len(registration.page_hashes)
        counts["document"] += added_documents
        counts["supplied_pages"] = len(registration.page_hashes)
        manifest = dict(version=VERSION,identity=identity,index_id=index_id,resource_id=registry["resource_id"],
            registry_digest=registry["registry_digest"],index_sha256=r.file_sha(final),counts=counts,
            authority_contract=registry["authority_contract"],source_policy=registry["evidence_policy"],api_calls=0,
            source_edition_id=registry["source_edition_id"],source_edition_scope=registry["source_edition_scope"],
            parent_index_ref=parent_reference,storage_copy_mode=mode,semantic_graph_tables_modified=False,
            historical_identities_and_hierarchy_retrospective=True,benchmark_authorized=False)
        r.immutable_json(completed,manifest)
        return reference(manifest)


class CorpusIndex(AbstractContextManager):
    """Explicit immutable registry/index pair; no inherited binding lookups."""
    def __init__(self, workspace, registry, reference):
        self.root = Path(workspace).absolute()
        self.registry = r.check_registry(registry)
        self.reference = dict(reference)
        if reference["registry_digest"] != registry["registry_digest"] or reference["resource_id"] != registry["resource_id"]:
            raise ValueError("Mixed registry/resource/index request")
        path = r.safe_path(self.root, reference["path"])
        mref = reference["manifest"]
        mpath = r.safe_path(self.root, mref["path"])
        if mpath.parent != path.parent or path.name != "graph.sqlite3" or r.file_sha(mpath) != mref["sha256"]:
            raise ValueError("Index completion manifest mismatch")
        manifest = r.load_json(mpath)
        if (manifest["version"] != VERSION or manifest["registry_digest"] != registry["registry_digest"]
                or manifest["resource_id"] != registry["resource_id"] or manifest["index_id"] != reference["index_id"]
                or manifest["index_sha256"] != reference["sha256"] or r.file_sha(path) != reference["sha256"]):
            raise ValueError("Index bytes, contract or source binding changed")
        self.db = sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True)
        self.db.row_factory = sqlite3.Row
        stored = json.loads(self.db.execute("SELECT payload FROM metadata WHERE key='identity'").fetchone()[0])
        if stored != manifest["identity"]:
            self.db.close()
            raise ValueError("Database identity differs from completion manifest")
        self.binding = dict(resource_id=registry["resource_id"], registry_digest=registry["registry_digest"],
            index_sha256=reference["sha256"], corpus="cib", graph_id=registry["graph_id"],
            hierarchy_id=registry["hierarchy_id"], alias_id=registry["alias_id"], authority_contract=registry["authority_contract"])
        self.supplied = None
        if "registered_supplied_documents" in registry:
            from .supplemental_sources import Registration
            try:
                self.supplied = Registration(self.root,registry)
                stored_pages = {x["id"]:x["payload_sha256"] for x in self.db.execute("SELECT * FROM supplied_page")}
                if stored_pages != dict(self.supplied.page_hashes):
                    raise ValueError("Supplied index rows differ from registered source edition")
                for pid in stored_pages:
                    raw = self.db.execute("SELECT payload FROM page WHERE id=?",(pid,)).fetchone()
                    if raw is None or not self.supplied.matches(json.loads(raw[0])):
                        raise ValueError("Registered supplied page payload changed")
                self.binding["source_edition_id"] = registry["source_edition_id"]
            except Exception:
                self.db.close()
                raise

    def _page(self, value):
        if self.supplied is not None and value["id"] in self.supplied.page_hashes:
            return self.supplied.bind(value)
        if value.get("visibility") == "supplied_registered" or "supplied_source" in value:
            raise ValueError("Unregistered supplied page in source index")
        return value

    def __exit__(self, *args):
        self.db.close()

    def _case(self, case, *, source_view_policy=STRICT_PRIOR):
        require_policy(source_view_policy)
        if case.get("corpus") != "cib" or case.get("resource_id", self.registry["resource_id"]) != self.registry["resource_id"]:
            raise ValueError("Case bound to a different current resource")
        _iso(case["date"])
        if not isinstance(case["document_id"], str) or not case["document_id"]:
            raise ValueError("Whole-origin exclusion requires an explicit document ID")
        origin = self.db.execute("SELECT date FROM document WHERE id=?", (case["document_id"],)).fetchone()
        if origin and origin[0] != case["date"] and source_view_policy not in LIVE_POLICIES:
            raise ValueError("Case date conflicts with its pinned original document")
        return case["date"], case["document_id"]

    def _scope(self, case, source_view_policy):
        cutoff, origin = self._case(case, source_view_policy=source_view_policy)
        relation = descriptor(source_view_policy)["date_relation"]
        ordinary = ("json_extract(p.payload,'$.visibility') IN ('earlier','both') "
            "AND REPLACE(UPPER(COALESCE(json_extract(p.payload,'$.classification'),'')),' ','') NOT IN ('SECRET','TOPSECRET') "
            "AND COALESCE(json_extract(p.payload,'$.native_page.view'),'earlier') IN ('earlier','both') "
            "AND COALESCE(json_extract(p.payload,'$.view'),'earlier') IN ('earlier','both') "
            "AND json_extract(p.payload,'$.supplied_source') IS NULL")
        sql = f"p.eligible=1 AND p.date{relation}? AND ("+ordinary
        params = [cutoff]
        if source_view_policy is SUPPLIED_DOCUMENTS_INCLUSIVE and self.supplied is not None:
            ids = sorted(self.supplied.page_hashes)
            sql += " OR p.id IN ("+",".join("?" for _ in ids)+")"
            params.extend(ids)
        sql += ")"
        if source_view_policy is STRICT_PRIOR:
            sql += " AND p.doc!=?"
            params.append(origin)
        return sql, params

    def source(self, case, page_id, *, source_view_policy=STRICT_PRIOR):
        scope, params = self._scope(case, source_view_policy)
        row = self.db.execute("SELECT p.payload FROM page p WHERE p.id=? AND "+scope, [page_id]+params).fetchone()
        if not row:
            raise ValueError("Source missing or not eligible under this exact question")
        return dict(binding=dict(self.binding), page=self._page(json.loads(row[0])), source_view_policy=descriptor(source_view_policy))

    def document_excerpt(self, case, page_id, start, end, *, source_view_policy=STRICT_PRIOR):
        page = self.source(case,page_id,source_view_policy=source_view_policy)["page"]
        if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(page["text"]):
            raise ValueError("Literal document excerpt offsets required")
        return dict(binding=dict(self.binding),source_view_policy=descriptor(source_view_policy),
            document_id=page["document_id"],page_id=page_id,date=page["date"],
            start=start,end=end,text=page["text"][start:end],page_sha256=page["source_sha256"],
            pdf_ref=deepcopy(page.get("supplied_source",{}).get("pdf_ref")),
            physical_page=page.get("pdf_page",page.get("earlier_page")),
            route_class="DOCUMENT_PAGE_LITERAL_EXCERPT_PROVENANCE_ONLY",
            semantic_edge_asserted=False,identity_or_task_support_certified=False)

    def pages(self, case, *, source_view_policy=STRICT_PRIOR):
        scope, params = self._scope(case, source_view_policy)
        return [self._page(json.loads(x[0])) for x in self.db.execute("SELECT p.payload FROM page p WHERE "+scope+" ORDER BY p.id", params)]

    def search(self, case, text, limit=100, *, source_view_policy=STRICT_PRIOR):
        scope, params = self._scope(case, source_view_policy)
        if not isinstance(text, str) or type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError("Invalid bounded lexical request")
        terms = sorted(set(re.findall(r"\w+", text, re.UNICODE)))
        if not terms:
            return []
        query = " OR ".join('"' + term.replace('"', '""') + '"' for term in terms)
        rows = self.db.execute("SELECT p.payload,bm25(page_fts) rank FROM page_fts JOIN page p ON p.id=page_fts.id "
            "WHERE page_fts MATCH ? AND "+scope+" ORDER BY rank,p.id LIMIT ?", [query]+params+[limit])
        return [dict(page=self._page(json.loads(x[0])), bm25_rank=x[1], binding=dict(self.binding),
            source_view_policy=descriptor(source_view_policy)) for x in rows]

    def _observations(self, case, node_id, *, source_view_policy=STRICT_PRIOR):
        scope, params = self._scope(case, source_view_policy)
        return self.db.execute("SELECT o.* FROM observation o JOIN page p ON p.id=o.page WHERE o.node=? AND o.eligible=1 "
            "AND "+scope+" ORDER BY o.id", [node_id]+params).fetchall()

    def observations(self, case, node_id, *, source_view_policy=STRICT_PRIOR):
        return [dict(observation_id=x["id"], node_id=x["node"], node_type=x["kind"],
            source=_unpack(x["payload"]), binding=dict(self.binding),source_view_policy=descriptor(source_view_policy))
            for x in self._observations(case, node_id, source_view_policy=source_view_policy)]

    def node(self, case, node_id, *, source_view_policy=STRICT_PRIOR):
        observations = self.observations(case, node_id, source_view_policy=source_view_policy)
        found = self.db.execute("SELECT * FROM node WHERE id=?", (node_id,)).fetchone()
        if not found or not observations:
            raise ValueError("Node has no eligible typed occurrence for this question")
        canonical = self.db.execute("SELECT payload FROM canonical WHERE id=?", (node_id,)).fetchone()
        authority = r.authority(_unpack(canonical[0]) if canonical else {})
        membership = self.db.execute("SELECT payload FROM membership WHERE node=?", (node_id,)).fetchone()
        return dict(binding=dict(self.binding), source_view_policy=descriptor(source_view_policy),
            node=dict(id=node_id, kind=found["kind"], authority=authority,
            observations=observations, hierarchy=_unpack(membership[0]) if membership else None,
            labels_are_from_eligible_observations_not_global_descriptions=True))

    def routes(self, case, node_id, *, source_view_policy=STRICT_PRIOR):
        cutoff, origin = self._case(case, source_view_policy=source_view_policy)
        where_sql, params = self._scope(case, source_view_policy)
        routes = []
        for edge in self.db.execute("SELECT a.* FROM assertion a JOIN page p ON p.id=a.page WHERE (a.a=? OR a.b=?) "
                "AND a.eligible=1 AND "+where_sql+" ORDER BY a.id", [node_id, node_id]+params):
            payload = _unpack(edge["payload"])
            routes.append(dict(route_class="SOURCE_ASSERTION", source=edge["a"], target=edge["b"],
                is_identity=False, historical_truth_certified=False, **payload))
        for route in self.db.execute("SELECT * FROM route ORDER BY id"):
            raw = _unpack(route["payload"])
            target = route["target"]
            explicit_mentions = raw.get("mention_ids") or ([raw["mention_id"]] if raw.get("mention_id") else [])
            if route["kind"] in {"WITHHELD_DISTINCTION", "UNKNOWN_WITHHELD"} and explicit_mentions:
                observed = []
                for mid in explicit_mentions:
                    if not isinstance(mid, str):
                        continue
                    found = self.db.execute("SELECT o.* FROM observation o JOIN page p ON p.id=o.page "
                        "WHERE o.id=? AND o.eligible=1 AND "+where_sql, [mid]+params).fetchone()
                    if found:
                        observed.append(dict(observation_id=found["id"], node_id=found["node"], source=_unpack(found["payload"])))
            else:
                observed = self.observations(case, target, source_view_policy=source_view_policy) if target and (target == node_id or route["hub"] == node_id) else []
            if target != node_id and route["hub"] != node_id and not any(x["node_id"] == node_id for x in observed):
                continue
            if not observed:
                continue
            scopes = [dict(mention_id=x["observation_id"], document_id=x["source"]["document_id"],
                canonical_page_id=x["source"]["canonical_page_id"], job_id=x["source"]["job_id"]) for x in observed]
            if raw.get("mention_ids"):
                scopes = [x for x in scopes if x["mention_id"] in raw["mention_ids"]]
            if not scopes:
                continue
            contexts = []
            for scope in scopes:
                for context in self.db.execute("SELECT payload FROM context WHERE job=? AND page=? AND doc=? AND eligible=1",
                        (scope["job_id"], scope["canonical_page_id"], scope["document_id"])):
                    native_context = _unpack(context[0])
                    if native_context.get("entity_id") == target or native_context.get("name_hub_id") == route["hub"]:
                        contexts.append(native_context)
            routes.append(dict(route_class=route["kind"], source=route["hub"], target=target,
                native_reference_route=raw, source_scope=scopes, native_source_contexts=contexts, is_evidence=False,
                global_union_authorized=False, factual_support_credit=False, identity_authority_from_route=False))
        if self._observations(case, node_id, source_view_policy=source_view_policy):
            member = self.db.execute("SELECT payload FROM membership WHERE node=?", (node_id,)).fetchone()
            if member:
                raw = _unpack(member[0])
                previous = node_id
                for kind in ("community_id", "theme_id", "domain_id"):
                    target = raw.get(kind)
                    if target:
                        routes.append(dict(route_class="HIERARCHY_NAVIGATION", source=previous, target=target,
                            is_evidence=False, identity_authority=False, membership=raw))
                        previous = target
        return dict(binding=dict(self.binding), routes=routes, cutoff=cutoff,
            source_view_policy=descriptor(source_view_policy),whole_origin_excluded=origin if source_view_policy is STRICT_PRIOR else None,
            withheld_routes=[x for x in routes if x["route_class"] in {"WITHHELD_DISTINCTION", "UNKNOWN_WITHHELD"}],
            retrospective_identities_and_hierarchy=True, task_support_assessed=False)


def open_index(workspace, registry, reference):
    return CorpusIndex(workspace, registry, reference)


from matryoshka_demo.corpus import Corpus as _SharedCorpus


class IndexedCorpus(_SharedCorpus):
    """Instance-local shared-kernel adapter materialized from this exact index.

    Authority stays on nodes/occurrences/edges. Kernel connectivity is discovery,
    never actor equivalence or task support; the task layer must inspect types.
    """
    def __init__(self, current, execution_binding):
        from collections import Counter, defaultdict
        import numpy as np
        from matryoshka_demo.corpus import BM25, words

        self.current_index = current
        self.workspace = current.root
        self.binding = execution_binding
        self.corpus = "cib"
        self.files = {k: r.safe_path(self.workspace, ref["path"]) for k, ref in execution_binding.get("files", {}).items()}
        self.documents = {x["id"]: _unpack(x["payload"]) for x in current.db.execute("SELECT * FROM document")}
        self.classification = {}
        self.pages = [current._page(json.loads(x[0])) for x in current.db.execute("SELECT payload FROM page ORDER BY id")]
        self.page_index = {p["id"]: i for i, p in enumerate(self.pages)}
        self.page_ids = [p["id"] for p in self.pages]
        self.page_dates = np.asarray([p["date"] for p in self.pages])
        self.page_docs = np.asarray([p["document_id"] for p in self.pages])
        self.allowed = np.asarray([p["permitted"] for p in self.pages], dtype=bool)
        self.nodes = {}
        for row in current.db.execute("SELECT n.id,n.kind,c.payload canonical FROM node n LEFT JOIN canonical c ON c.id=n.id ORDER BY n.id"):
            canonical = _unpack(row["canonical"]) if row["canonical"] else {}
            types = canonical.get("type_counts", {})
            self.nodes[row["id"]] = dict(id=row["id"], kind=row["kind"], entity_type=max(types, key=types.get) if types else None,
                native_reference_authority=r.authority(canonical))
        self.node_ids = list(self.nodes)
        self.node_index = {n: i for i, n in enumerate(self.node_ids)}
        self.units, self.unit_pages, self.unit_map = [], [], {}
        self.surfaces, self.surface_nodes, self.surface_pages = [], [], []
        self.occurrences = []
        self.occurrences_by_page, self.occurrences_by_node = defaultdict(list), defaultdict(list)
        self.rejections = Counter()
        fields = {"Entity": "entities", "Event": "events", "Claim": "claims"}
        for stored in current.db.execute("SELECT * FROM observation WHERE eligible=1 ORDER BY id"):
            row = _unpack(stored["payload"])
            pi, ni = self.page_index[stored["page"]], self.node_index[stored["node"]]
            interval = row["char_start"], row["char_end"]
            quote = self.pages[pi]["text"][slice(*interval)]
            if quote != row["evidence_quote"]:
                raise ValueError("Indexed source occurrence no longer replays")
            ui = self.add_unit(pi, quote, interval, [ni])
            label = row.get("label") or row.get("claim_text") or quote
            terms = set(words(quote))
            source_label = " ".join(w for w in words(label) if w in terms)
            self.surfaces.append(source_label or quote)
            self.surface_nodes.append(ni)
            self.surface_pages.append(pi)
            occurrence = dict(node_id=stored["node"], page_index=pi, unit_index=ui, label=label,
                entity_type=row.get("type"), start=interval[0], end=interval[1],
                source_type=fields[stored["kind"]], source_row_id=stored["id"],
                native_reference_authority=self.nodes[stored["node"]]["native_reference_authority"])
            self.occurrences_by_page[pi].append(len(self.occurrences))
            self.occurrences_by_node[stored["node"]].append(len(self.occurrences))
            self.occurrences.append(occurrence)
        self.edge_rows = []
        for stored in current.db.execute("SELECT * FROM assertion WHERE eligible=1 ORDER BY id"):
            row = _unpack(stored["payload"])
            relation = row["native_relation"]
            pi = self.page_index[stored["page"]]
            a, b = self.node_index[stored["a"]], self.node_index[stored["b"]]
            if a == b:
                continue
            interval = relation["char_start"], relation["char_end"]
            ui = self.add_unit(pi, relation["evidence_quote"], interval, [a, b])
            self.edge_rows.append(dict(a=a, b=b, pi=pi, ui=ui, source_row_id=relation["relation_evidence_id"],
                relation=relation["relation"], route_class="SOURCE_ASSERTION", native_assertion_mode=relation.get("assertion_mode"),
                source_observation_id=stored["a_observation"], target_observation_id=stored["b_observation"],
                actor_identity_or_task_support_certified=False))
        self.unit_pages = np.asarray(self.unit_pages, dtype=int)
        self.surface_pages = np.asarray(self.surface_pages, dtype=int)
        self.surface_nodes = np.asarray(self.surface_nodes, dtype=int)
        self.membership = [(ui, ni) for ui, unit in enumerate(self.units) for ni in unit["nodes"]]
        self.hierarchy = {x["node"]: _unpack(x["payload"]) for x in current.db.execute("SELECT * FROM membership")}
        self.page_bm25 = BM25([p["text"] for p in self.pages])
        self.node_bm25 = BM25(self.surfaces)
        self.counts = dict(pages=len(self.pages), nodes=len(self.nodes), units=len(self.units), relations=len(self.edge_rows),
            rejected=dict(self.rejections), authority_preserved=True, resource_id=current.registry["resource_id"])

    def eligible(self, case):
        self.current_index._case(case)
        return super().eligible(case)
