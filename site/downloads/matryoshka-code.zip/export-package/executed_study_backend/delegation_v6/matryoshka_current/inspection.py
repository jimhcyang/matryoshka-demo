"""Bound current-context inspection DTOs; never reopen an ambient old graph."""
from copy import deepcopy
from datetime import date
import math
import json
from pathlib import Path
import re
import sqlite3
from types import MappingProxyType

from matryoshka_demo.io import digest
from . import planning, resources
from matryoshka_demo.source_view_policy import policy_of, descriptor, from_descriptor

VERSION = "current-context-inspection/1"
_LEVELS = ("domain", "theme", "community")


def _get(context, name, default=None):
    return context.get(name, default) if isinstance(context, dict) else getattr(context, name, default)


def _identifier(value):
    if not isinstance(value, str) or not value or len(value) > 600 or any(ord(c) < 32 for c in value):
        raise ValueError("Invalid exact source/node identity")
    return value


def _count(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError("Invalid bounded inspection count")
    return value


def _resource_binding(context, case):
    registry, reference = _get(context, "registry"), _get(context, "index_ref")
    binding = planning.validate_registry(registry, reference, case)
    return dict(corpus=case["corpus"], resource_id=binding.get("resource_id") or binding["graph_id"],
        registry_sha256=registry["sha256"], index_sha256=reference["sha256"],
        graph_id=binding["graph_id"],
        hierarchy_id=binding["hierarchy_id"], source_status=binding["status"])


def _verify_ref(context, root, reference):
    path = planning.bound(root, reference["path"])
    stat = path.stat()
    key = (str(path), reference["sha256"], stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino)
    cache = _get(context, "_inspection_verified_bytes")
    if cache is None:
        cache = set()
        if isinstance(context, dict):
            context["_inspection_verified_bytes"] = cache
        else:
            context._inspection_verified_bytes = cache
    if key not in cache:
        if resources.file_sha(path) != reference["sha256"]:
            raise ValueError("Current inspection reference bytes changed")
        cache.add(key)
    return path


class _View:
    def __init__(self, context, case):
        self.context, self.case = context, deepcopy(case)
        self.corpus = _get(context, "corpus")
        self.source_view_policy = policy_of(self.corpus)
        self.binding = _resource_binding(context, case)
        self.bound = _get(context, "registry")["corpora"][case["corpus"]]
        expected = self.bound.get("incumbent_binding", self.bound)
        if self.corpus.binding != expected or self.corpus.corpus != case["corpus"]:
            raise ValueError("Inspection Corpus differs from selected binding")
        if date.fromisoformat(case["date"]).isoformat() != case["date"]:
            raise ValueError("Exact ISO query cutoff required")
        if case.get("resource_id", self.binding["resource_id"]) != self.binding["resource_id"]:
            raise ValueError("Inspection case belongs to another resource")
        self.root = Path(self.corpus.workspace) / "src-demo-day"
        registry_ref = _get(context, "registry_ref")
        _verify_ref(context, self.root, registry_ref)
        if resources.load_json(planning.bound(self.root, registry_ref["path"])) != _get(context, "registry"):
            raise ValueError("Inspection envelope differs from its byte pin")
        self.path = _verify_ref(context, self.root, _get(context, "index_ref"))
        self.index = _get(context, "index")
        self.own_db = None
        if case["corpus"] == "cib":
            if self.index is None or self.index.registry["resource_id"] != self.binding["resource_id"]:
                raise ValueError("Current CIB inspection requires its explicit typed index")
            if self.index.reference != _get(context, "index_ref")["native_index_ref"]:
                raise ValueError("Current context DB differs from its explicit native index reference")
            self.index._case(case, source_view_policy=self.source_view_policy)
        else:
            self.own_db = sqlite3.connect(self.path.as_uri() + "?mode=ro&immutable=1", uri=True)
        # Keep the entire cable body/sibling veto, not just the requested page.
        veto = set(getattr(self.corpus, "excluded_documents", []))
        if case["corpus"] != "cib":
            veto.update(p["document_id"] for p in self.corpus.pages
                if re.search(r"\bNOFORN\b", p["text"], re.I)
                or any("NOFORN" in str(x).upper() for x in p.get("handling", [])))
        from matryoshka_next.facts import SourcePolicy
        checked = SourcePolicy(self.corpus, case, _get(context, "source_index"))
        self.allowed = [bool(self.corpus.allowed[i]) and checked.allowed(i)
            for i in range(len(self.corpus.pages))]
        self._pages, self._nodes, self._groups, self._member_ids = {}, {}, {}, {}
        self._active = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        if self.own_db is not None:
            self.own_db.close()

    def meta(self):
        policy = descriptor(self.source_view_policy)
        origin = (self.case["document_id"] if self.case["corpus"] != "cib"
            or self.source_view_policy.value == "strict_prior" else None)
        return dict(version=VERSION, binding=deepcopy(self.bound), resource_binding=deepcopy(self.binding),
            index_ref=deepcopy(_get(self.context, "index_ref")), registry_ref=deepcopy(_get(self.context, "registry_ref")),
            cutoff=self.case["date"], whole_origin_excluded=origin, source_view_policy=policy,
            scope=dict(corpus=self.case["corpus"], cutoff=self.case["date"],date_relation=policy["date_relation"],
                source_view_policy=policy,strictly_before=self.case["date"] if policy["date_relation"] == "<" else None,
                whole_origin_excluded=origin,
                binding=deepcopy(self.bound), retrospective_hierarchy=True),
            retrospective_identities_and_hierarchy=True, task_support_assessed=False)

    def page(self, identity):
        _identifier(identity)
        if identity in self._pages:
            return deepcopy(self._pages[identity])
        pi = self.corpus.page_index.get(identity)
        if pi is None or not self.allowed[pi]:
            raise ValueError("Source outside current cutoff/origin/classification/quarantine scope")
        expected = self.corpus.pages[pi]
        if self.index is not None:
            page = self.index.source(self.case, identity, source_view_policy=self.source_view_policy)["page"]
        else:
            relation = descriptor(self.source_view_policy)["date_relation"]
            row = self.own_db.execute("SELECT payload FROM page WHERE id=? AND date"+relation+"? AND doc!=?", (identity,
                self.case["date"], self.case["document_id"])).fetchone()
            if row is None:
                raise ValueError("Source not in explicit incumbent index")
            page = json.loads(row[0])
        for key in ("id", "document_id", "date", "text", "source_sha256"):
            if page.get(key) != expected.get(key):
                raise ValueError("Source API/index/retrieval text or metadata differs")
        if page["source_sha256"] != digest(page["text"]) or page.get("permitted") is not True:
            raise ValueError("Source digest or permission invalid")
        page["canonical_page_id"] = identity
        if page.get("corpus") != self.case["corpus"] or page.get("visibility") not in {None, "both", "earlier"}:
            raise ValueError("Source corpus or visibility mismatch")
        self._pages[identity] = page
        return deepcopy(page)

    def citation(self, page_id, start, end, text=None):
        page = self.page(page_id)
        if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(page["text"]):
            raise ValueError("Invalid original Unicode source interval")
        raw = page["text"][start:end]
        if text is not None and raw != text:
            raise ValueError("Saved quote does not replay in the selected current source")
        return dict(canonical_page_id=page_id, document_id=page["document_id"], date=page["date"],
            start=start, end=end, text=raw, page_sha256=page["source_sha256"], earlier_page=page.get("earlier_page"))

    @property
    def active(self):
        if self._active is None:
            if self.index is not None:
                scope, params = self.index._scope(self.case, self.source_view_policy)
                self._active = {x[0] for x in self.index.db.execute(
                    "SELECT DISTINCT o.node FROM observation o JOIN page p ON p.id=o.page "
                    "WHERE o.eligible=1 AND "+scope, params)}
            else:
                allowed = {p["id"] for i, p in enumerate(self.corpus.pages) if self.allowed[i]}
                self._active = {x[0] for x in self.own_db.execute("SELECT node,page FROM mention") if x[1] in allowed}
        return self._active

    @property
    def hierarchy(self):
        cached = _get(self.context, "_inspection_hierarchy")
        key = self.binding["index_sha256"]
        if cached is None or cached[0] != key:
            if self.index is not None:
                from .index import _unpack
                values = {x[0]: MappingProxyType(_unpack(x[1])) for x in self.index.db.execute("SELECT node,payload FROM membership")}
            else:
                values = {x[0]: MappingProxyType(json.loads(x[1])) for x in self.own_db.execute("SELECT id,hierarchy FROM node")}
            cached = key, MappingProxyType(values)
            if isinstance(self.context, dict):
                self.context["_inspection_hierarchy"] = cached
            else:
                self.context._inspection_hierarchy = cached
        return cached[1]

    def semantic(self, identity):
        if identity in self._nodes:
            return deepcopy(self._nodes[identity])
        if identity not in self.corpus.nodes or identity not in self.active:
            raise ValueError("Exact node has no eligible current source occurrence; no spelling fallback")
        occurrences = [self.corpus.occurrences[i] for i in self.corpus.occurrences_by_node[identity]
            if self.allowed[self.corpus.occurrences[i]["page_index"]]]
        occurrences.sort(key=lambda x: (self.corpus.pages[x["page_index"]]["date"], x["source_row_id"]))
        sample = occurrences[0]
        page = self.corpus.pages[sample["page_index"]]
        proof = self.citation(page["id"], sample["start"], sample["end"])
        label = sample.get("label")
        label = label if isinstance(label, str) and label and label in proof["text"] else proof["text"]
        metadata = self.corpus.nodes[identity]
        native_authority = dict(route_class="LEGACY_AUTHORITY_NOT_ASSERTED", global_identity_authorized=False,
            instance_identity_asserted=None)
        if self.index is not None:
            original = self.index.db.execute("SELECT kind FROM node WHERE id=?", (identity,)).fetchone()
            source = self.index.db.execute("SELECT node,page,payload FROM observation WHERE id=? AND eligible=1", (sample["source_row_id"],)).fetchone()
            from .index import _unpack
            raw = _unpack(source[2]) if source else {}
            if (not original or original[0] != metadata["kind"] or not source or source[0] != identity or source[1] != page["id"]
                    or (raw.get("char_start"), raw.get("char_end")) != (sample["start"], sample["end"])):
                raise ValueError("Displayed node/occurrence ownership differs from the pinned typed index")
            canonical = self.index.db.execute("SELECT payload FROM canonical WHERE id=?", (identity,)).fetchone()
            native_authority = resources.authority(_unpack(canonical[0]) if canonical else {})
        else:
            original = self.own_db.execute("SELECT kind FROM node WHERE id=?", (identity,)).fetchone()
            source = self.own_db.execute("SELECT 1 FROM mention WHERE node=? AND page=? AND label=? LIMIT 1",
                (identity, page["id"], sample.get("label"))).fetchone()
            if not original or original[0] != metadata["kind"] or not source:
                raise ValueError("Displayed node differs from explicit incumbent index")
        hierarchy = self.hierarchy.get(identity, {})
        result = dict(id=identity, node_id=identity, type=metadata["kind"], kind=metadata["kind"], label=label,
            label_basis="Exact eligible source occurrence, not a global display-label join", citations=[proof],
            page_count=len({o["page_index"] for o in occurrences}),
            document_count=len({self.corpus.pages[o["page_index"]]["document_id"] for o in occurrences}),
            authority=native_authority,
            **{key: hierarchy.get(key) for key in ("domain_id", "theme_id", "community_id")})
        self._nodes[identity] = result
        return deepcopy(result)

    def group(self, level, identity):
        if level not in _LEVELS:
            raise ValueError("Unknown hierarchy level")
        key = level, identity
        if key in self._groups:
            return deepcopy(self._groups[key])
        ids = self.member_ids(level, identity)
        if not ids:
            raise ValueError("Exact current hierarchy group has no eligible members")
        memberships = [self.hierarchy[n] for n in ids]
        parents = {m.get("theme_id" if level == "community" else "domain_id") for m in memberships}
        if level != "domain" and (len(parents) != 1 or None in parents):
            raise ValueError("Current hierarchy parent is missing or ambiguous")
        result = dict(id="hierarchy:" + level + ":" + identity, group_id=identity, type=level.capitalize(),
            label=level.capitalize() + ": " + " / ".join(self.semantic(n)["label"] for n in ids[:2]),
            member_count=len(ids), parent_id=next(iter(parents)) if level != "domain" else None,
            domain_id=identity if level == "domain" else memberships[0]["domain_id"],
            theme_id=identity if level == "theme" else memberships[0]["theme_id"] if level == "community" else None,
            community_id=identity if level == "community" else None,
            membership_kind="NAVIGATION", historical_relation_certified=False)
        self._groups[key] = result
        return deepcopy(result)

    def members(self, level, identity):
        return [self.semantic(n) for n in self.member_ids(level, identity)]

    def member_ids(self, level, identity):
        key = level, identity
        if key not in self._member_ids:
            self._member_ids[key] = [n for n in sorted(self.active)
                if self.hierarchy.get(n, {}).get(level + "_id") == identity]
        return self._member_ids[key]

    def resolve(self, identity):
        _identifier(identity)
        match = re.fullmatch(r"hierarchy:(domain|theme|community):(.+)", identity)
        if match:
            return self.group(match[1], match[2])
        if identity in self.corpus.nodes:
            return self.semantic(identity)
        levels = [level for level in _LEVELS if any(h.get(level + "_id") == identity for h in self.hierarchy.values())]
        if len(levels) == 1:
            return self.group(levels[0], identity)
        raise ValueError("Unknown current ID; labels and old graph IDs are never substituted")

    def source_edges(self, identity):
        edges = []
        if self.index is not None:
            for route in self.index.routes(self.case, identity, source_view_policy=self.source_view_policy)["routes"]:
                if route["route_class"] != "SOURCE_ASSERTION":
                    continue
                edge, relation = route["native_edge"], route["native_relation"]
                if edge["source_id"] not in self.active or edge["target_id"] not in self.active:
                    continue
                proof = self.citation(relation["canonical_page_id"], relation["char_start"], relation["char_end"], relation["evidence_quote"])
                edges.append(dict(id=edge["semantic_edge_id"] + ":" + relation["relation_evidence_id"],
                    source=edge["source_id"], target=edge["target_id"], kind="SOURCE", route_class="SOURCE_ASSERTION",
                    relation=relation["relation"], edge_type=relation["relation"], citations=[proof],
                    relation_evidence_id=relation["relation_evidence_id"], assertion_mode=relation.get("assertion_mode"),
                    source_observation_id=route["source_observation_id"], target_observation_id=route["target_observation_id"],
                    historical_relation_certified=False, identity_equivalence_implied=False))
        else:
            ni = self.corpus.node_index[identity]
            for edge in self.corpus.edge_rows:
                if ni not in (edge["a"], edge["b"]) or not self.allowed[edge["pi"]]:
                    continue
                a, b = self.corpus.node_ids[edge["a"]], self.corpus.node_ids[edge["b"]]
                if a not in self.active or b not in self.active:
                    continue
                unit = self.corpus.units[edge["ui"]]
                if unit["pi"] != edge["pi"]:
                    raise ValueError("Incumbent relation/unit page binding differs")
                proof = self.citation(self.corpus.pages[edge["pi"]]["id"], unit["start"], unit["end"], unit["text"])
                edges.append(dict(id="incumbent-source:" + edge["source_row_id"], source=a, target=b, kind="SOURCE",
                    route_class="SOURCE_ASSERTION", relation=edge["relation"], edge_type=edge["relation"], citations=[proof],
                    relation_evidence_id=edge["source_row_id"], historical_relation_certified=False, identity_equivalence_implied=False))
        return edges

    def mother(self, node):
        level = node["type"].lower()
        if level in _LEVELS:
            return node
        return self.group("community", node["community_id"]) if node.get("community_id") else None

    def incident_ids(self, node):
        """Enumerate exact connections without hydrating every neighbor's text."""
        level = node["type"].lower()
        if level in _LEVELS:
            ids = self.member_ids(level, node["group_id"])
            if level == "community":
                neighbors = list(ids)
            else:
                child = "community" if level == "theme" else "theme"
                neighbors = ["hierarchy:" + child + ":" + identity for identity in sorted({self.hierarchy[n][child + "_id"]
                    for n in ids if self.hierarchy[n].get(child + "_id")})]
            if level != "domain":
                neighbors.append("hierarchy:" + ("theme" if level == "community" else "domain") + ":" + node["parent_id"])
            edges = [dict(id="membership:" + node["id"] + ":" + identity, source=node["id"], target=identity,
                kind="NAVIGATION", route_class="HIERARCHY_NAVIGATION", relation="Recorded membership", edge_type="Recorded membership",
                citations=[], historical_relation_certified=False, identity_equivalence_implied=False) for identity in neighbors]
        else:
            edges = self.source_edges(node["id"])
            neighbors = list(dict.fromkeys(n for e in edges for n in (e["source"], e["target"]) if n != node["id"]))
            mother = self.mother(node)
            if mother:
                neighbors.append(mother["id"])
                edges.append(dict(id="membership:" + node["id"] + ":" + mother["id"], source=node["id"], target=mother["id"],
                    kind="NAVIGATION", route_class="HIERARCHY_NAVIGATION", relation="Recorded membership", edge_type="Recorded membership",
                    citations=[], historical_relation_certified=False, identity_equivalence_implied=False))
        return neighbors, edges

    def incident(self, node):
        identities, edges = self.incident_ids(node)
        return [self.resolve(identity) for identity in identities], edges

    def relation(self, a, b, hop):
        kind = hop["kind"]
        if kind == "SOURCE":
            if a["type"].lower() in _LEVELS or b["type"].lower() in _LEVELS:
                return []
            result = [e for e in self.source_edges(a["id"]) if {e["source"], e["target"]} == {a["id"], b["id"]}]
            # The shared kernel can walk backwards. Preserve the factual
            # relation's original direction and label the separate traversal.
            return [dict(e, traversal=dict(source=a["id"], target=b["id"],
                reversed_for_navigation=e["source"] != a["id"])) for e in result]
        if kind == "NAVIGATION":
            _, edges = self.incident_ids(a)
            return [e for e in edges if {e["source"], e["target"]} == {a["id"], b["id"]}]
        if kind == "SOURCE_AGGREGATE":
            level = a["type"].lower()
            if level not in _LEVELS or b["type"].lower() != level:
                return []
            field = level + "_id"
            sources = []
            for edge in self.corpus.edge_rows:
                if not self.allowed[edge["pi"]]:
                    continue
                left, right = self.corpus.node_ids[edge["a"]], self.corpus.node_ids[edge["b"]]
                if left not in self.active or right not in self.active:
                    continue
                groups = {self.hierarchy.get(left, {}).get(field), self.hierarchy.get(right, {}).get(field)}
                if groups != {a["group_id"], b["group_id"]}:
                    continue
                unit = self.corpus.units[edge["ui"]]
                sources.append(self.citation(self.corpus.pages[edge["pi"]]["id"], unit["start"], unit["end"], unit["text"]))
            if sources:
                return [dict(id="aggregate:" + a["id"] + ":" + b["id"], source=a["id"], target=b["id"],
                    kind="SOURCE_AGGREGATE", relation="Eligible source aggregate, not a group assertion", source_edge_count=len(sources),
                    citations=sources[:3], citation_display_limit=3, historical_relation_certified=False, identity_equivalence_implied=False)]
        return []


def source(context, case, identity):
    with _View(context, case) as view:
        page = view.page(identity)
        pages = [view.page(p["id"]) for i, p in enumerate(view.corpus.pages)
            if p["document_id"] == page["document_id"] and view.allowed[i]]
        pages.sort(key=lambda p: (p.get("canonical_sequence", p.get("earlier_page")) or 0, p["id"]))
        return dict(page, document_pages=pages, resource_binding=deepcopy(view.binding), binding=deepcopy(view.bound),
            source_scope="All eligible paired-earlier canonical pages of this document" if case["corpus"] == "cib" else
                "All eligible original cable text segments; segment numbers are not physical PDF pages",
            document_bound_segments=sum(p["document_id"] == page["document_id"] for p in view.corpus.pages),
            document_eligible_segments=len(pages), original_document_completeness_certified=False,
            cutoff=case["date"], source_view_policy=descriptor(view.source_view_policy),
            whole_origin_excluded=view.meta()["whole_origin_excluded"],version=VERSION)


def neighborhood(context, case, identity, limit=30):
    _count(limit, 1, 100)
    with _View(context, case) as view:
        central = view.resolve(identity)
        if central["type"].lower() in _LEVELS:
            ids = view.member_ids(central["type"].lower(), central["group_id"])
            nodes = [view.semantic(n) for n in ids[:limit]]
            return dict(**view.meta(), node_id=identity, node=central, nodes=[central] + nodes[:limit], edges=[],
                total_source_edges=0, displayed_source_edges=0, omitted_source_edges=0,
                membership_is_factual=False, member_count=len(ids), hierarchy=central)
        all_edges = view.source_edges(identity)
        edges = all_edges[:limit]
        ids = list(dict.fromkeys(n for e in edges for n in (e["source"], e["target"])))
        nodes = [central] + [view.semantic(n) for n in ids if n != identity]
        routes = view.index.routes(case, identity, source_view_policy=view.source_view_policy) if view.index is not None else dict(routes=[], withheld_routes=[])
        return dict(**view.meta(), node_id=identity, node=central, nodes=nodes, edges=edges,
            total_source_edges=len(all_edges), displayed_source_edges=len(edges), omitted_source_edges=max(0, len(all_edges) - len(edges)),
            hierarchy=dict(view.hierarchy.get(identity, {})),
            reference_routes=[r for r in routes["routes"] if r["route_class"] != "SOURCE_ASSERTION"],
            withheld_routes=routes.get("withheld_routes", []),
            meaning="Eligible current source connections; reference and hierarchy navigation are not actor identity or task support")


def node(context, case, identity):
    return neighborhood(context, case, identity)


_READOUT_KINDS = ("SEARCH_RECEIPT_READOUT", "EXACT_QUOTATION_READOUT", "CONSTRUCTION_READOUT")
_PHASES = ("start_community", "start_connections", "relation", "target_reveal", "target_connections", "target_community")


def _guide(view, packet):
    case = view.case
    if packet.get("case_id") != case["case_id"] or packet.get("corpus") != case["corpus"]:
        raise ValueError("Guide belongs to a different exact case")
    if packet.get("graph_binding") != view.bound:
        raise ValueError("Guide graph/resource binding differs; archived guides are not remapped")
    scope = packet.get("scope", {})
    policy = from_descriptor(scope.get("source_view_policy", packet.get("source_view_policy")))
    expected_origin = case["document_id"] if case["corpus"] != "cib" or policy.value == "strict_prior" else None
    dates = [scope[k] for k in ("strictly_before", "date", "cutoff") if scope.get(k) is not None]
    origins = [scope[k] for k in ("whole_origin_excluded", "excluded_origin") if k in scope]
    if (policy is not view.source_view_policy or not dates or any(value != case["date"] for value in dates)
            or not origins or any(value != expected_origin for value in origins)
            or scope.get("binding", view.bound) != view.bound):
        raise ValueError("Guide source boundary differs from its selected current context")
    for field, expected in (("registry_sha256", view.binding["registry_sha256"]),
            ("source_binding_sha256", _get(view.context, "index_ref")["source_binding_sha256"])):
        if field in packet and packet[field] != expected:
            raise ValueError("Guide execution-envelope hash mismatch")
    if "index_ref" in packet and packet["index_ref"] != _get(view.context, "index_ref"):
        raise ValueError("Guide explicit index reference differs")
    if "resource_binding" in packet and packet["resource_binding"] != view.binding:
        raise ValueError("Guide compact resource DTO differs from selected context")
    route = packet.get("route", {})
    nodes, hops = route.get("nodes"), route.get("hops")
    if not isinstance(nodes, list) or not nodes or not isinstance(hops, list) or len(hops) != len(nodes) - 1:
        raise ValueError("Guide requires an ordered saved route")
    for n in nodes:
        _identifier(n.get("id"))
    lexical = route.get("route_kind") == "LEXICAL_SOURCE_READOUT"
    allowed = set(_READOUT_KINDS) if lexical else {"SOURCE", "NAVIGATION", "SOURCE_AGGREGATE"}
    for i, hop in enumerate(hops):
        if hop.get("source") != nodes[i]["id"] or hop.get("target") != nodes[i + 1]["id"] or hop.get("kind") not in allowed:
            raise ValueError("Guide hop order or route kind changed")
        if "transition" in hop and (type(hop["transition"]) not in {int, float}
                or not math.isfinite(hop["transition"]) or not 0 < hop["transition"] <= 1):
            raise ValueError("Invalid saved numerical transition; no replacement is manufactured")
    if lexical:
        if ([h["kind"] for h in hops] != list(_READOUT_KINDS)
                or any(n.get("solver_state") is not False or n.get("readout_only") is not True for n in nodes)
                or any(h.get("numerical_transition") or "transition" in h for h in hops)):
            raise ValueError("A lexical readout is not a kernel walk or a KG identity")
        proofs = []
        for raw in packet.get("candidate", {}).get("sources", []):
            proof = view.citation(raw["canonical_page_id"], raw["start"], raw["end"], raw["text"])
            if any(raw.get(k) != proof[k] for k in ("document_id", "date", "page_sha256")):
                raise ValueError("Lexical source receipt differs")
            proofs.append(proof)
        if not proofs:
            raise ValueError("Lexical source readout has no eligible original quotation")
        return nodes, hops, [], True
    resolved = [view.resolve(n["id"]) for n in nodes]
    proofs = []
    for left, right, hop in zip(resolved, resolved[1:], hops):
        relations = view.relation(left, right, hop)
        if not relations:
            raise ValueError("Saved current hop lacks an eligible source relation or exact membership")
        proofs.append(relations)
    return resolved, hops, proofs, False


def guide_overlay(context, case, packet):
    with _View(context, case) as view:
        nodes, hops, proofs, lexical = _guide(view, packet)
        groups = sorted({h[field] for identity in view.active for h in [view.hierarchy.get(identity, {})]
            for field in ("domain_id", "theme_id", "community_id") if h.get(field)})
        mappings = []
        for n in nodes:
            level = n.get("type", "").lower()
            mappings.append(dict(native_id=n["id"], browser_id=None if lexical else n.get("group_id", n["id"]),
                status="READOUT_NOT_A_GRAPH_STATE" if lexical else "EXACT_CURRENT_HIERARCHY_ID" if level in _LEVELS else
                    "EXACT_BOUND_NODE_ID_WITH_ELIGIBLE_SOURCE", label_join_used=False,
                source_citations=deepcopy(n.get("citations", []))))
        connections = [dict(native_source=hop["source"], native_target=hop["target"], kind=hop["kind"],
            native_source_verified=True, browser_edge_verified=False, browser_edge_ids=[],
            source_relations=deepcopy(relations), citations=[p for e in relations for p in e.get("citations", [])],
            meaning="Exact current membership, not a historical assertion" if hop["kind"] == "NAVIGATION" else
                "Eligible original source connection; no query entailment or exported-browser-edge proof")
            for hop, relations in zip(hops, proofs)]
        return dict(**view.meta(), lens="current_resource_overlay", case_id=case["case_id"], corpus=case["corpus"],
            browser_binding=deepcopy(view.binding), study_binding=deepcopy(view.bound),
            layout_matches_study=None, native_source_graph_matches_selected_context=True,
            browser_layout_comparison="NOT_PERFORMED", layout_coordinates_reused=False, browser_export_verified=False,
            eligible_ids=sorted(view.active), eligible_group_ids=groups,
            eligible_document_ids=sorted({p["document_id"] for i, p in enumerate(view.corpus.pages) if view.allowed[i]}),
            endpoint_mappings=mappings, connections=connections, verified_browser_edges=[],
            current_source_edges=[e for row in proofs for e in row if e["kind"] != "NAVIGATION"],
            topology_replaced=False, membership_is_factual=False, lexical_only=lexical,
            saved_kernel_walk_reverified=False, guidance_is_entailment=False,
            meaning="Same explicit current source graph/hierarchy IDs; no old spelling crosswalk. Source/membership checks do not certify kernel flow, query support or an uninspected browser export.")


def guide_view(context, case, packet, params):
    def arg(key, default=None):
        value = params.get(key, default)
        if isinstance(value, list):
            if len(value) != 1:
                raise ValueError("Ambiguous repeated guide parameter")
            value = value[0]
        return value
    with _View(context, case) as view:
        nodes, hops, proofs, lexical = _guide(view, packet)
        phase = arg("phase", "start_community")
        if phase == "source":
            page_id = _identifier(arg("source_id"))
            value = source(context, case, page_id)
            return dict(**view.meta(), page={k: v for k, v in value.items() if k != "document_pages"}, document_pages=value["document_pages"])
        if phase == "inspect":
            selected = view.resolve(_identifier(arg("node_id")))
            return dict(**view.meta(), node=selected, citations=deepcopy(selected.get("citations", [])))
        if lexical:
            raise ValueError("Lexical source readout has no graph mother community or numerical path")
        if phase not in _PHASES:
            raise ValueError("Unknown guide phase")
        hop_index = _count(int(arg("hop_index", 0)), 0, max(0, len(hops) - 1))
        limit = _count(int(arg("limit", 256)), 2, 2048)
        offset = _count(int(arg("offset", 0)), 0, 10_000_000)
        page_size = _count(int(arg("page_size", 24)), 1, 100)
        if not hops and phase not in _PHASES[:2]:
            raise ValueError("No saved hop exists for this phase")
        a, b = nodes[hop_index], nodes[hop_index + 1] if hops else nodes[0]
        hop = hops[hop_index] if hops else None
        relations = proofs[hop_index] if proofs else []
        focus = b if phase in {"target_connections", "target_community"} else a
        mother = view.mother(focus)
        community_view = phase in {"start_community", "target_community"}
        incident_ids, incident_edges = view.incident_ids(focus)
        all_member_ids = view.member_ids(mother["type"].lower(), mother["group_id"]) if community_view and mother else None
        available_ids = all_member_ids[:limit] if all_member_ids is not None else [focus["id"]] if community_view else incident_ids[:limit]
        available = [view.resolve(identity) for identity in available_ids]
        pins = [focus] + ([a] if phase == "target_community" and a["id"] != b["id"] else [] if community_view else [b if focus["id"] == a["id"] else a])
        complete = {n["id"]: n for n in pins + ([mother] if mother else []) + available}
        complete_ids = set(complete) | set(all_member_ids if all_member_ids is not None else [] if community_view else incident_ids)
        graph_nodes = list(complete.values())[:limit]
        shown = {n["id"] for n in graph_nodes}
        candidate_edges = (relations if phase == "target_community" else []) if community_view else incident_edges + relations
        graph_edges = list({e["id"]: e for e in candidate_edges if e["source"] in shown and e["target"] in shown}.values())
        neighbors = [view.resolve(identity) for identity in incident_ids[offset:offset + page_size]]
        neighbor_ids = {n["id"] for n in neighbors} | {focus["id"]}
        return dict(**view.meta(), lens="current_resource_case", phase=phase, hop_index=hop_index, focus_id=focus["id"],
            layout_key=("community:" if community_view else "incident:") + (mother["id"] if community_view and mother else focus["id"]),
            view_kind="community" if community_view else "incident", community=mother, nodes=graph_nodes, edges=graph_edges,
            outside_membership_ids=[a["id"]] if phase == "target_community" and a["id"] not in (set(all_member_ids) if all_member_ids is not None else {n["id"] for n in available}) else [],
            highlighted_node_ids=[a["id"]] if phase in _PHASES[:2] else list(dict.fromkeys([a["id"], b["id"]])),
            highlighted_edge_ids=[e["id"] for e in relations] if phase not in _PHASES[:2] else [],
            saved_hop=deepcopy(hop), relation_edges=deepcopy(relations),
            incident=dict(node=focus, neighbors=neighbors, edges=[e for e in incident_edges if e["source"] in neighbor_ids and e["target"] in neighbor_ids],
                total_nodes=len(incident_ids), total_edges=len(incident_edges), offset=offset, limit=page_size,
                next_offset=offset + page_size if offset + page_size < len(incident_ids) else None),
            available_nodes=len(complete_ids), displayed_nodes=len(graph_nodes),
            member_count=len(all_member_ids) if all_member_ids is not None else len(available) if community_view else None,
            drawing_limit=limit, membership_is_factual=False, saved_kernel_walk_reverified=False,
            breadcrumbs=[view.group(level, focus[level + "_id"]) for level in _LEVELS if focus.get(level + "_id")])
