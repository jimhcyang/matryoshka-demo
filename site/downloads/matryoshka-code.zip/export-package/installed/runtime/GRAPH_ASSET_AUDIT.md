# Graph Reachability Decision

The current six GUI view sets do **not** fit a 1 GB public artifact budget.
No graph assets, frontend features, native records or active web files were
modified by this audit.

| Corpus | Bound Files | Bound Bytes | Reachable Files | Reachable Bytes |
| --- | ---: | ---: | ---: | ---: |
| CIB | 396 | 1,056,611,810 | 396 | 1,056,611,810 |
| Iran | 593 | 575,293,233 | 396 | 377,993,603 |
| Vietnam | 593 | 2,093,277,679 | 396 | 1,387,012,786 |
| Total | 1,582 | 3,725,182,722 | 1,188 | 2,821,618,199 |

Exactly **394 files / 903,564,523 bytes** can be pruned: unused cable
`current_reveal` variants. The current GUI selects `current_earlier` and
`current_later` for CIB, and `current_redaction` and `current_later` for each
cable corpus. `view=pair/single`, release switching and guide earlier/later
selection do not activate `current_reveal`. No corresponding CIB savings exist.

| Reachable Category | Stored Bytes |
| --- | ---: |
| Neighborhood shards | 1,467,097,812 |
| Hierarchy catalogs | 715,521,760 |
| Search manifests and indexes | 359,297,525 |
| Community member detail shards | 104,414,411 |
| Compact adjacency shards | 94,443,220 |
| Source transcript shards | 43,157,517 |
| Comparison bootstrap JSON | 37,685,954 |

Of these reachable bytes, **1,801,856,636 are already gzip** and
1,019,761,563 are plain JSON. Exact whole-file deduplication by the bound
SHA-256 saves **zero bytes**, even across corpora. Thus recompressing all plain
JSON alone cannot reach 1 GB. Neighborhood shards alone already exceed it.

## Method And Limits

Inputs: `src-demo-day/data/full_graph_bindings_v4.json`, its three bound
comparison files and three search manifests, and current
`src-demo-day/web/graph-full-v6.js`. All bound file sizes were independently
checked against the existing files: no missing files or size mismatches.

Reachability starts at comparison/search, selects the two active views above,
then follows each active view's `levels` URLs and member-detail maps,
neighborhood and compact-adjacency filename templates, source-view transcript
maps, and entity/evidence search files. Templates expand against only bound
filenames. All referenced filenames resolved. `ensureHierarchyCatalog`,
`ensureCommunityDetail`, `ensureNodeNeighborhood`, `ensureCompactAdjacency`,
source drawers and search loaders were checked against this closure. Numeric
`bytes` accounting dictionaries do not themselves create fetch dependencies.

This is a reference/consumer audit, not a browser download trace or a proof
that every shard is loaded during one demonstration. Full arbitrary search,
direct traversal and source inspection can reach every retained shard; a
single demo trace is therefore not a sufficient full-feature asset manifest.

## Decision Needed

A feature-preserving sub-1-GB artifact requires a **measured structural,
lossless neighborhood/object/source repack** with client reconstruction tests.
Existing graph IDs, memberships, edge kinds, dates, source texts, proof hashes
and complete incident inventories must survive. Such savings are not yet
measured and must not be claimed in advance. The bound files are not identical
duplicates; a simple file-hash content store will not solve the size problem.

Alternatively the user must explicitly approve a smaller public scope. Keep
all selected case routes and proofs and the original map's control language,
but label omitted global exploration/search coverage; never silently substitute
a study projection for the full map or call a selected neighborhood the whole
corpus. Full source shards also contain unrelated corpus transcripts; keeping
all of them is a public-release decision, not merely a hosting optimization.

## Selected Case Packet Inventory

The intended thirty are `selected_demo OR selected_bench`: fifteen presentation
plus fifteen bench cases, not the `selected_demo` flag alone. Their immutable
native checkpoints contain **90 conditions, 97 flow/reading views, and 312
candidate/view pairs**. The three-route cap gives **936 potential route keys**;
actual V6.5 route availability must be measured from exported V6.5 projections,
not inferred from this upper bound or old native routes.

Those ninety native checkpoints occupy **941,304,285 compressed bytes**; a
compact reserialization of their decoded payloads is **4,946,345,723 bytes**.
Their thirty published case-detail files occupy **62,823,775 compressed bytes**.
Neither is an appropriate wholesale public upload. Recursively encountered
native citations reach 904 documents and 1,753 case/page pairs, including
global drawing context, not just focal proof. CIB native citation/origin sizing
reaches 812 PDFs across both releases totaling **376,304,645 bytes**. This is
**not** a public PDF allowlist or complete V6.5-derived proof closure.

The minimal exporter should emit source-reviewed public response packets and
an explicit finite API index; omit private keys, full native walks/audits,
request/response logs, manuscripts, credentials and unrestricted corpus bulk.
Public static files cannot be made secret by a collapsed drawer or Reveal
button. Exported source pages must remain byte/hash exact; do not redact a
page and retain its old source hash.
