# Public Replay Runtime V1

Owned files are confined to this runtime directory. No active web, native,
server, source, exporter, packer, GitHub repository or publication pointer was
edited by this worker. This is a static saved-research replay, not a public
model/query service or a claim of paper accuracy.

## Early Installation

Inject this classic script before the existing page scripts on both copies:

```html
<script src="runtime/public-runtime.js"
        data-site-base="../"
        data-index="data/api-index.json"></script>
```

The base comes from `document.currentScript.src`, not a repository name or host
root. It must be a same-origin HTTP(S) directory. The index default is
`data/api-index.json`; optional `data-index-sha256` pins its exact bytes. Keep
the existing public descriptor's canonical `/graph-assets-v4/<corpus>/`
`asset_base` value: fetch URLs are remapped, response values are not rewritten.

Public HTML must permit `frame-src 'self' blob:`. Same-origin static scripts,
styles and API packets remain local. For immutable external graph datasets,
also permit `connect-src 'self' https://raw.githubusercontent.com`. No API
credentials or third-party scripts are needed.
The runtime does not replace `location`, `history`, `URL` or query state.
Existing browser navigation still occurs in response to a user's link/form.

## Index And Request Keys

```json
{
  "version": "matryoshka-public-api-index/1",
  "entries": {
    "/api/flow-v6?case_id=CASE&config=llm_readings&limit=1024&reading=": {
      "path": "data/replays/CONTENT_HASH.json.gz",
      "encoding": "gzip",
      "mime": "application/json",
      "sha256": "DECODED_BYTE_SHA256",
      "wire_sha256": "STORED_GZIP_SHA256"
    }
  }
}
```

Keys are a logical root pathname plus Python-compatible
`urlencode(sorted(params.items()))`: spaces use `+`, `~` remains literal,
`*` is escaped, and blank values remain `key=`. The JS implementation uses
the same encoding, not `URLSearchParams.toString()`'s different safe alphabet.
Root and project-prefixed API requests share one key. Duplicate and unknown
parameters fail closed. A/B/C normalize to llm_readings/llm_atoms/llm_local.

Defaults are explicit: condition/native config=llm_readings; flow additionally
reading="", limit=1024; guide/overlay config=llm_readings, reading="",
route_index=0; graph corpus=cib; origin reveal_focal=0; PDF release=earlier.
The PDF document_id alias normalizes to doc_id, never both together.
Default reading aliases must be actual index entries, not a runtime guess of
the first reading. Missing entries return UNAVAILABLE; no method substitution.

`guide-view-v6` currently has one production UI use: phase=source plus source_id
and the guide selectors. Its source/inspect phases do not accept pagination in
this static contract. The legacy six context phases remain supported only if
explicitly exported, with hop_index=0, limit=256, offset=0, page_size=24 defaults.
The runtime performs no context generation. These extra defaults must be
reflected in an exporter's keys if those legacy capabilities are included.

All browser fetches, including `/data/report-v6.json`, require index entries.
Static graph entries use logical `/graph-assets-v4/corpus/filename` keys.
Unknown APIs, non-GET fetches, credentials, traversal, external fetches, unsafe
manifest paths and redirects fail closed without a server/proxy fallback.
The saved native endpoint must be a public receipt, not the full private walk.
Exporter public-field/source-approval checks remain necessary: a filename
allowlist cannot detect private text inside a JSON body.

## Gzip And Integrity

`sha256` pins decoded bytes, not parsed/reserialized values. Optional
`wire_sha256` pins stored bytes. GitHub-style raw `.gz` downloads are decoded
with DecompressionStream. For ordinary graph `.gz` URLs, verified original
gzip bytes are returned so the existing graph parser performs its own decode.
API JSON callers receive decoded bytes. Transport decoding never repairs a
fill, reranks, changes an endpoint or alters a source-page hash.

The source-page text/hash check remains the frontend's separate proof check.
An index hash is transport integrity, not a historical entailment certificate,
independent signature or access control. The node API's `data.note`, including
SAVED_DISPLAY_PROJECTION_ONLY scope, is shown in the public status notice.

## Immutable Graph Dataset Entries

Graph keys may have an `external_url` instead of a local `path`:

```json
{
  "external_url": "https://raw.githubusercontent.com/jimhcyang/matryoshka-demo/aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/datasets/cib/0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef.json.gz",
  "encoding": "gzip",
  "mime": "application/json",
  "sha256": "DECODED_BYTE_SHA256",
  "wire_sha256": "STORED_GZIP_SHA256"
}
```

Only that literal HTTPS host, owner and repository, a lowercase 40-hex commit,
`datasets/<cib|iran|vietnam>/<64hex>.json.gz`, and no query/fragment/credentials
are allowed. The logical key must be under `/graph-assets-v4/<same-corpus>/`.
Gzip, JSON MIME and both exact SHA pins are mandatory. If `path` is also present,
it must pass the unchanged local-only `assetURL` checks but is never a fallback.
Unknown hosts, repositories, branch refs, normalization/traversal tricks, ports
and corpus mismatches fail during index validation before a dataset request.

Callers continue fetching only logical same-origin paths. Captured original
fetch alone reads an indexed dataset with GET, `mode: cors`, `credentials: omit`
and `redirect: error`. Original raw gzip bytes must remain accessible; transport
auto-decompression cannot bypass the compressed SHA check. Both hashes are
verified before returning original gzip to the existing graph parser. External
URLs passed directly to `fetch` still fail closed and are never proxied.
The external `datasets/manifest.json` can be a publication provenance receipt;
it is not an allowed runtime data URL. The local verified API index supplies
the finite individual graph-file bindings.

This deployment uses direct gzip graph datasets outside the Pages site, not
full-KG fragment DAGs. A negative packing result showed excessive per-root
dependency transfer. Local API overlays/source packets may still use DAGs;
condition/flow packets can use direct local gzip for latency. Runtime support
does not imply publication approval or promise corpus-scale load timing.

## Fragment DAG

An index entry may instead contain:

```json
{
  "encoding": "fragment-dag",
  "path": "data/packed/manifest.json",
  "manifest_sha256": "MANIFEST_FILE_BYTE_SHA256",
  "asset": "EXACT_KEY_IN_MANIFEST_ASSETS",
  "mime": "application/json",
  "sha256": "ROOT_DECODED_CANONICAL_BYTE_SHA256"
}
```

The reader follows `tools/pack_graphs.py`: manifest version
graph-fragment-dag/1; chunk version graph-fragment-dag-chunk/1; contiguous ID
ranges; chunk paths `chunks/<sha256>.json.gz` relative to the manifest. Root and
chunk decoded pins are named `sha256decoded` inside the pack manifest.
`entry.asset` is exact: the current packer uses selected item names, which may
be basenames rather than full logical graph paths. No prefix guessing occurs.

Templates are odd arrays alternating literal ASCII JSON text and positive safe
integer references to strictly smaller fragment IDs. The reader seeds needed
IDs from the root, visits declared chunks in descending index order, and visits
each loaded chunk's rows in descending ID order. Only needed templates are
retained; their smaller-ID children become needed for the remaining pass.
Unused declared chunks are not fetched. A chunk is fetched at most once per
root reconstruction, even when dependencies exceed the shared LRU capacity.
Retained literals are copied to avoid pinning unused chunk string storage.

Reconstruction then uses only retained templates, with no chunk reads or
number-token parsing/serialization. Compressed/decompressed SHA and byte lengths
are checked before use, followed by root length and SHA. Cached chunks cannot
bypass root dependencies. Manifest loading uses captured original fetch
directly, never the outer index. No full fragment dictionary is loaded/retained.

Global cache limits are eight chunks and 32 MiB of decoded chunk bytes, with
four manifest promises. Limits are 32 MiB per manifest, 16 MiB per compressed
or decoded chunk, 512 MiB per decoded root, 16,384 expansion depth and
50,000,000 traversal operations. Oversize, cycles/forward references, missing
dependencies and bad hashes fail, never truncate. Cache byte accounting bounds
serialized template bytes, not an exact measurement of JavaScript heap usage.

For a reconstructed logical `.gz` URL, the synthetic response carries
Content-Encoding: gzip with its already-decoded JSON body. This intentionally
matches the existing graph parser's decoded-response branch and avoids double
decompression. The caller parses JSON once, after verified byte reconstruction.

Packing canonicalizes whitespace/string escaping, not source numeric lexemes.
If comparison/search bootstrap files are packed, public descriptor transport
SHA fields must pin reconstructed bytes; retain original parent byte hashes
separately. Do not claim the pack reproduces an original gzip header or pretty
JSON byte layout. Graph IDs, object values and source-text hashes stay intact.

## Navigation And Source Frames

Root internal links/forms are scoped to the project base. PDF/native links and
window.open use runtime/replay.html. The replay page verifies before showing
JSON with textContent or a source PDF in a blob iframe; download is explicit.
Iframe src property/setAttribute calls for allowlisted PDF API URLs are
rewritten before loading, with MutationObserver fallback for inserted markup.
No backend `/api/cib-pdf` route is needed. Unknown archives have an explicit
unavailable page, never a substituted V6 casebook.

PDF coverage is an explicit finite publication subset, not every document
referenced by a full graph. Once the index is ready, an unexported PDF anchor
loses its href and becomes an aria-disabled "PDF available in local archive"
label. Its tooltip says the transcript remains inspectable and the PDF lies
outside the public cited-document subset. Links created before index readiness
are rescanned after load; missing PDFs never open an unavailable viewer through
those anchors. `PublicReplay.hasSaved(input)` synchronously checks canonical
entry membership, returning false before readiness or for invalid/absent keys.
This is a membership check, not a substitute for byte verification. Direct
missing fetches, including PDF fetches, still fail closed without fallback.
The exporter owns `publication.scopePDFcitations` and source-document approval.

Ordinary public HTTPS citation anchors remain ordinary user navigation with
noopener/noreferrer. Fetch never proxies those destinations. Credentials,
non-HTTPS citations, localhost/private literal addresses, unsafe schemes and
private-host suffixes are blocked. This is hostname/literal-address validation,
not a DNS-resolution or network-firewall guarantee. Public JSON files cannot
be made secret by hiding a drawer or reference-answer toggle.

## Verification

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B -m pytest -q -p no:cacheprovider \
  matryoshka_demo_site/runtime/tests/runtime_browser_test.py \
  matryoshka_demo_site/runtime/tests/runtime_fragment_test.py \
  matryoshka_demo_site/runtime/tests/runtime_external_test.py
```

Tests use Playwright-managed Chromium and a plain SimpleHTTPRequestHandler
under `/a-different-project/`, never the app backend. They include a small
actual packer round trip and a 70-dependency root that references every fragment
twice while asserting exactly one descending-order request per chunk. Hybrid
checks combine gzip condition bootstraps with DAG flow/overlay/node API and
graph responses. No real
corpus packing, inference, real external network,
installed Chrome or paid calls are involved. Existing graph-size findings are
in GRAPH_ASSET_AUDIT.md; these transport tests do not establish a sub-1-GB site.
External-data checks intercept every nonlocal request in Playwright and cover
all three allowed corpora, URL negatives, omitted credentials, both digest
failures, redirect rejection and unchanged source packet values.
