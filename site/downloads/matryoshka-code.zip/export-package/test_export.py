"""Local exporter safety and selector tests; no native engine or model calls."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('new_export', HERE / 'export_narrative.py')
export = importlib.util.module_from_spec(spec)
spec.loader.exec_module(export)


class ExportTests(unittest.TestCase):
    def test_prune_before_graph_pack_protects_pending_chunks_only(self):
        from packet_pack import PacketPack
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            stage = export.Stage(Path(directory) / 'new')
            pack = PacketPack(stage)
            raw = export.encoded(dict(actual=['native label'] * 100))
            entry = pack.put(raw)
            pack.flush()
            stage.write('site/data/obsolete.json.gz', b'orphan transport only')
            chunks = list((stage.output / 'site/data/packet-pack/chunks').glob('*'))
            export.prune_data(stage, {'graph':entry}, pack)
            self.assertFalse((stage.output / 'site/data/obsolete.json.gz').exists())
            self.assertTrue(all(p.exists() for p in chunks))
            self.assertEqual(pack.read(entry['asset']), raw)
            pack.db.close()

    def test_graph_layer_reuse_keeps_graph_bytes_not_case_responses(self):
        from packet_pack import PacketPack, read_packed
        from graph_layer import extract, reuse
        from structural_pack import put_graph
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            parent = Path(directory)
            stage = export.Stage(parent / 'original')
            pack = PacketPack(stage)
            raw = export.encoded(dict(nodes=[dict(id=i, label='Exact existing graph ' * 20) for i in range(50)]))
            graph = put_graph(pack, raw, export.sha(raw))
            case = pack.put(export.encoded(dict(private_case_only='not a graph' * 1000)))
            key = '/graph-assets-v4/iran/existing.json.gz'
            entries = {key:graph, '/api/current/saved-case':case}
            pack.finish(entries)
            stage.write('site/data/api-index.json', export.encoded(dict(entries=entries)))
            stage.write('stage_receipt.json', export.encoded(dict(map_index_sha256='a' * 64)))
            layer = parent / 'generic'
            extract(stage.output, layer)
            target = export.Stage(parent / 'final-fresh-cases')
            copied, pin = reuse(target, layer, 'a' * 64, {key}, {key:graph})
            self.assertEqual(set(copied), {key})
            self.assertEqual(read_packed(target.output / 'site', copied[key]), raw)
            self.assertEqual(len(pin), 64)
            with self.assertRaises(AssertionError):
                reuse(target, layer, 'b' * 64, {key}, {key:graph})
            pack.db.close()

    def test_interrupted_pack_recovers_exact_root_without_repacking(self):
        from packet_pack import PacketPack
        from structural_pack import put_graph
        from resume_support import recover_graphs, checkpoint_graphs
        import gzip
        from types import SimpleNamespace
        class Stage:
            resuming = False
            def __init__(self, output): self.output = output
            def guard(self): pass
            def write(self, relative, raw):
                p = self.output / relative
                p.parent.mkdir(parents=True, exist_ok=True)
                if p.exists(): self_check = p.read_bytes() == raw; assert self_check
                else: p.write_bytes(raw)
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            stage = Stage(Path(directory))
            raw = export.encoded(dict(nodes=[dict(id=i, label='Actual unchanged source ' * 10) for i in range(400)]))
            pack = PacketPack(stage)
            entry = put_graph(pack, raw, export.sha(raw))
            entries = {'case': entry}
            pack.finish(entries)
            stage.write('case_checkpoint.json', export.encoded(dict(entries=entries)))
            pack.db.close()
            stage.resuming = True
            restored = PacketPack(stage)
            count = restored.total_nodes
            relative = 'iran/graph.json.gz'
            stage.write('datasets/' + relative, gzip.compress(raw, mtime=0))
            key = '/graph-assets-v4/iran/saved.json.gz'
            original = dict(encoding='gzip', sha256=export.sha(raw), wire_sha256=export.sha(gzip.compress(raw, mtime=0)),
                external_url='https://example.invalid/datasets/' + relative, mime='application/json')
            worker = SimpleNamespace(stage=stage, packet_pack=restored, entries={key:original})
            maps = SimpleNamespace(root=stage.output, entries={key:original})
            recover_graphs(worker, maps, {key})
            self.assertEqual(restored.total_nodes, count)
            self.assertEqual(worker.entries[key]['sha256'], export.sha(raw))
            self.assertNotIn('external_url', worker.entries[key])
            self.assertEqual(restored.read(export.sha(raw)), raw)
            checkpoint_graphs(worker)
            restored.db.close()

    def test_lossless_packet_fragments_preserve_literal_bytes_floats_and_reuse(self):
        from packet_pack import PacketPack, read_packed
        class Stage:
            def __init__(self, output): self.output = output
            def write(self, relative, raw):
                p = self.output / relative
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(raw)
        with tempfile.TemporaryDirectory(dir=HERE) as directory:
            stage = Stage(Path(directory))
            pack = PacketPack(stage)
            raw = export.encoded(dict(nodes=[dict(id=i, text='Exact source ' * 80, value=1e-7) for i in range(100)], selected='a'))
            entry = pack.put(raw)
            self.assertEqual(pack.read(entry['asset']), raw)
            second = pack.put(raw.replace(b'"selected":"a"', b'"selected":"b"'))
            entries = {'one': entry, 'two': second}
            pack.finish(entries)
            self.assertEqual(read_packed(stage.output / 'site', entry), raw)
            self.assertEqual(read_packed(stage.output / 'site', second), raw.replace(b'"selected":"a"', b'"selected":"b"'))
            self.assertLess(sum(p.stat().st_size for p in (stage.output / 'site').rglob('*') if p.is_file()), len(raw))

    def test_runtime_adds_exact_slot_selectors_and_narrative_walk_routes(self):
        raw = export.adapt_runtime((HERE / 'vendor/runtime/public-runtime.js').read_bytes())
        text = raw.decode()
        self.assertIn('"/api/narrative-v1/trace"', text)
        self.assertIn('"q":', text.replace('q:', '"q":'))
        self.assertIn('"anchor_id", "domain_id", "theme_id", "community_id"', text)
        self.assertIn('return verifiedSlots(key, signal)', text)
        self.assertIn('pack.manifest.literal_encoding==="base64"', text)
        self.assertNotIn('source_id", "query", "offset', text)
        with self.assertRaises(ValueError):
            export.adapt_runtime(raw)

    def test_runtime_retains_explicit_origin_reveal_and_pin_checks(self):
        text = export.adapt_runtime((HERE / 'vendor/runtime/public-runtime.js').read_bytes()).decode()
        for guard in ('DUPLICATE_PARAMETER', 'UNKNOWN_PARAMETER', 'MISSING_PARAMETER', 'INTEGRITY_FAILURE', 'GET_ONLY', 'NO_CREDENTIALS'):
            self.assertIn(guard, text)
        self.assertIn('reveal_focal: "0"', text)
        self.assertIn('if (own(values, "reveal_focal") && !["0", "1"].includes', text)

    def test_path_traversal_and_symlinks_are_not_inputs(self):
        for name in ('../x', '/absolute', 'a/../b', 'a\\b', 'a//b'):
            with self.assertRaises(ValueError):
                export.at(HERE, name)

    def test_explicit_case_resource_parameters_are_never_dropped(self):
        row = {'case': {'case_id': 'saved'}, 'resource_binding': {k: k + '-bound' for k in export.PINS}}
        self.assertEqual(set(export.parameters(row, 'llm_readings')), {'case_id', 'config', *export.PINS})

    def test_backend_imports_are_contained_even_with_python_isolation(self):
        code = "import sys;sys.path.insert(0," + repr(str(HERE / 'backend')) + ");import matryoshka_narrative.server;from pathlib import Path;root=Path(" + repr(str(HERE / 'backend')) + ");mods=[m for n,m in sys.modules.items() if n.startswith('matryoshka_') and getattr(m,'__file__',None)];assert mods and all(Path(m.__file__).is_relative_to(root) for m in mods);print(len(mods))"
        result = subprocess.run([sys.executable, '-I', '-B', '-c', code], capture_output=True, text=True, cwd='/tmp')
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_slot_filter_matches_the_native_normalized_token_semantics(self):
        code = (HERE / 'slot-runtime.js').read_text()
        script = "const vm=require('vm'),assert=require('assert/strict');const api=vm.runInNewContext(" + json.dumps(code + ';({selectStaticSlots});') + ",{fail:(c,m)=>{throw Error(c+':'+m)}});" + """
const row={id:'opaque_slot_a',slot_id:'slot_ab',document_id:'Doc-01',date:'1973-02-01',context_preview:'Visible MR IV words',anchors:[{id:'native-a'}],community_id:'native-c'};
const catalog={status:{corpus:'vietnam',graph_run_id:'g',hierarchy_run_id:'h'},slots:[row]};
const p={corpus:'vietnam',graph_id:'g',hierarchy_id:'h',offset:'0',limit:'32',scan:'0',q:''};
assert.equal(api.selectStaticSlots(catalog,{...p,q:'MR IV'}).matched_count,1);
assert.equal(api.selectStaticSlots(catalog,{...p,q:'MRIV'}).matched_count,0);
assert.equal(api.selectStaticSlots(catalog,{...p,anchor_id:'native-a'}).matched_count,1);
assert.equal(api.selectStaticSlots(catalog,{...p,community_id:'unrelated'}).matched_count,0);
assert.equal(api.selectStaticSlots(catalog,{...p,slot_id:row.id}).slot.id,row.id);
for(const change of [{graph_id:'wrong'},{limit:'65'},{offset:'-1'},{scan:'2'},{q:'x'.repeat(201)},{slot_id:'unknown'}])assert.throws(()=>api.selectStaticSlots(catalog,{...p,...change}));
"""
        result = subprocess.run(['node', '-e', script], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == '__main__':
    unittest.main()
