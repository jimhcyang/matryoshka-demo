"""Explicit replaceable reference inputs; a new output directory is always required."""
import argparse
from pathlib import Path
from export_narrative import ROOT, main


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report-ref', default='experiments/full_resume_20261120/publication_preview_v06/report_ref.json')
    parser.add_argument('--casebook-ref', default='experiments/full_resume_20261120/publication_preview_v06/casebook_ref.json')
    parser.add_argument('--digest-ref', default='experiments/full_resume_20261120/digests_preview_v06/index_ref.json')
    parser.add_argument('--supplement-manifest', default='experiments/full_resume_20261120/deploy/swedish_supplement_v03_ref.json')
    parser.add_argument('--output', required=True)
    parser.add_argument('--backend-root', type=Path, default=Path(__file__).resolve().parent / 'backend')
    parser.add_argument('--reuse-case-stage', type=Path)
    parser.add_argument('--reuse-graph-stage', type=Path)
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--field-guide-directory', type=Path)
    args = parser.parse_args()
    flags = ['--root', str(ROOT), '--map-root', str(ROOT.parent / 'matryoshka_demo_site'),
             '--ui-root', str(ROOT / 'experiments/full_resume_20261120/ui'),
             '--map-index-sha256', 'a4f08ac865bb21faed97e1792fc2c84baba0e8483f5fb92c7604fec96f5e30f0',
             '--pdf-catalog', 'experiments/visual_refinement_20261120/pdfs/catalog-resource-bound.json',
             '--pdf-catalog-sha256', '9cff25abf01546029a3fc6060bb0490b07f79424c684f8182770c72afbc9c0ef',
             '--public-metadata-projection', '--backend-root', str(args.backend_root), '--output', args.output, '--max-bytes', '900000000', '--max-seconds', '3600']
    for name in ('report_ref', 'casebook_ref', 'digest_ref', 'supplement_manifest'):
        flags.extend(('--' + name.replace('_', '-'), str(ROOT / getattr(args, name))))
    if args.reuse_case_stage:
        flags.extend(('--reuse-case-stage', str(args.reuse_case_stage)))
    if args.reuse_graph_stage:
        flags.extend(('--reuse-graph-stage', str(args.reuse_graph_stage)))
    if args.resume:
        flags.append('--resume')
    if args.field_guide_directory:
        flags.extend(('--field-guide-directory', str(args.field_guide_directory)))
    main(flags)
