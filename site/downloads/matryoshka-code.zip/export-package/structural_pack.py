"""Reuse the baseline's structural JSON parser, requiring exact original bytes."""
import base64
from collections import OrderedDict
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

spec = importlib.util.spec_from_file_location('release_json_parser', Path(__file__).parent / 'vendor/tools/pack_graphs.py')
original = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = original
spec.loader.exec_module(original)


class Sink:
    def __init__(self):
        self.hash, self.size, self.buffer = hashlib.sha256(), 0, bytearray()
    def write(self, text):
        self.buffer.extend(text.encode('ascii'))
        if len(self.buffer) >= 65536:
            self.flush()
    def flush(self):
        self.hash.update(self.buffer)
        self.size += len(self.buffer)
        self.buffer.clear()
    def finish(self):
        self.flush()
        return self.hash.hexdigest()


class Dictionary:
    def __init__(self, pack):
        self.pack, self.metadata = pack, OrderedDict()
    def dependencies(self, identity):
        if identity in self.metadata:
            return self.metadata[identity]
        return frozenset(json.loads(self.pack.db.execute('SELECT dependencies FROM fragments WHERE id=?', (identity,)).fetchone()[0]))
    def intern(self, pieces):
        converted, size, dependencies = [], 0, set()
        for i, piece in enumerate(pieces):
            if i % 2:
                converted.append(piece.id)
                size += piece.size
                dependencies.update(self.dependencies(piece.id))
            else:
                raw = piece.encode('ascii')
                converted.append(self.pack.literal(raw))
                size += len(raw)
        identity, size, deps = self.pack.node(converted, size, dependencies)
        self.metadata[identity] = deps
        self.metadata.move_to_end(identity)
        if len(self.metadata) > 65536:
            self.metadata.popitem(last=False)
        return original.Ref(identity, identity.to_bytes(8, 'big'), size)


def put_graph(pack, raw, expected, minimum=256):
    assert hashlib.sha256(raw).hexdigest() == expected
    if expected in pack.roots:
        assert pack.roots[expected]['decoded_bytes'] == len(raw)
        return dict(encoding='fragment-dag', path=pack.path, asset=expected, sha256=expected, mime='application/json')
    parser = original.Parser(raw.decode('utf-8'), Dictionary(pack), minimum=minimum)
    parser.sink = Sink()
    root, checksum = parser.parse()
    assert checksum == expected == hashlib.sha256(raw).hexdigest(), 'Structural graph transport must preserve exact original decoded bytes; no silent canonicalization'
    deps = parser.dictionary.dependencies(root.id)
    pack.roots[checksum] = dict(encoding='fragment-dag', pieces=['', root.id, ''], decoded_bytes=len(raw), sha256decoded=checksum, dependencies=sorted(deps))
    return dict(encoding='fragment-dag', path=pack.path, asset=checksum, sha256=checksum, mime='application/json')
