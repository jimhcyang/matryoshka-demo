"""Finish only derived assets of an unsealed, completed saved-response index."""
import argparse
from collections import Counter
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import export_narrative as ex
from field_guide import assets as guide_assets


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--backend-root', type=Path, required=True)
    parser.add_argument('--ui-root', type=Path, default=ex.ROOT / 'experiments/full_resume_20261120/ui')
    parser.add_argument('--report-ref', type=Path, default=ex.ROOT / 'phase/release_finish_20261121/publication_review_update_v02/report_ref.json')
    parser.add_argument('--casebook-ref', type=Path, default=ex.ROOT / 'phase/release_finish_20261121/publication_review_update_v02/casebook_ref.json')
    parser.add_argument('--digest-ref', type=Path, default=ex.ROOT / 'experiments/full_resume_20261120/digests_release_finish_v02/index_ref.json')
    parser.add_argument('--field-guide-directory', type=Path, default=ex.ROOT / 'phase/release_finish_20261121/walkthrough/saved_fourteen_v03')
    args = parser.parse_args()
    stage_root, backend = args.stage.resolve(), args.backend_root.resolve()
    assert stage_root.is_relative_to(ex.HERE) and backend.is_relative_to(ex.HERE)
    assert not (stage_root / 'stage_receipt.json').exists() and not (stage_root / 'site/release-manifest.json').exists()
    inputs = ex.Inputs()
    report_ref = ex.reference(ex.ROOT, args.report_ref, inputs)
    book_ref = ex.reference(ex.ROOT, args.casebook_ref, inputs)
    digest_ref = ex.reference(ex.ROOT, args.digest_ref, inputs)
    report = inputs.read(ex.ROOT, report_ref)
    guide = guide_assets(ex.ROOT, args.field_guide_directory, report_ref, inputs)
    checkpoint = json.loads((stage_root / 'case_checkpoint.json').read_bytes())
    binding = json.loads((stage_root / 'case_cache_binding.json').read_bytes())
    code_pin = ex.sha(ex.encoded({str(p.relative_to(backend)):ex.sha(p.read_bytes()) for p in sorted(backend.rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py', '.json', '.txt'}}))
    assert checkpoint['report_ref'] == report_ref and checkpoint['backend_code_sha256'] == code_pin
    assert binding['checkpoint_sha256'] == ex.sha((stage_root / 'case_checkpoint.json').read_bytes())
    assert binding['casebook_ref'] == book_ref and binding['digest_ref'] == digest_ref
    coverage = checkpoint['coverage']
    assert {(r['case_id'],r['config']) for r in coverage} == {
        (r['case']['case_id'],config) for r in report['cases'] for config in r['configurations']}
    site = stage_root / 'site'
    index_raw = (site / 'data/api-index.json').read_bytes()
    entries = json.loads(index_raw)['entries']
    dataset_raw = (site / 'data/dataset-delivery.json').read_bytes()
    datasets = json.loads(dataset_raw)
    assert datasets['original_map_index_sha256'] == binding['map_index_sha256']
    sys.path.insert(0, str(backend))
    from matryoshka_narrative.server import Viewer
    from matryoshka_current.map_transport import SavedMaps
    package = ex.ROOT.parent / 'matryoshka_demo_site'
    maps = SavedMaps(package, binding['map_index_sha256'])
    viewer = Viewer(ex.ROOT, report_ref, maps, ui_root=args.ui_root, casebook_ref=book_ref, digest_ref=digest_ref)
    supplement_ref, supplements = ex.supplement_assets(ex.ROOT,
        ex.ROOT / 'experiments/full_resume_20261120/deploy/swedish_supplement_v03_ref.json', inputs)
    captured = {}
    def capture(relative, raw):
        assert relative.startswith('site/')
        assert relative not in captured or captured[relative] == raw
        captured[relative] = raw
    preview = SimpleNamespace(output=stage_root, write=capture)
    try:
        lineage = ex.ui_assets(preview, viewer, package, ex.sha(index_raw), inputs, supplements, guide, same_repository=True)
    finally:
        viewer.close()
    stage = ex.Stage(stage_root, resume=True)
    archived = []
    html_sources = {r['target']:r for r in supplements if r['target'].endswith('.html')}
    supplement_lineage = []
    for row in supplements:
        target = row['target']
        if target in {'app-navigation.js','app-navigation.css'}:
            supplement_lineage.append(dict(target=target, source_ref=row['source_ref'], binding='ACTIVE_UI_PREFERRED_NO_CLOBBER'))
        elif target.endswith('.html'):
            supplement_lineage.append(dict(target=target, source_ref=row['source_ref'], supplied_sha256=ex.sha(row['raw']),
                public_sha256=ex.sha(captured['site/'+target]), binding='DEFERRED_TO_VERIFIED_UI_HTML_TRANSFORM'))
        else:
            assert (site / target).read_bytes() == row['raw'], 'Pinned non-HTML supplement differs'
            supplement_lineage.append(dict(target=target, source_ref=row['source_ref'], public_sha256=ex.sha(row['raw']), bytes_unchanged=True))
    for relative, raw in captured.items():
        path = stage_root / relative
        if path.exists() and ex.sha(path.read_bytes()) != ex.sha(raw):
            target = relative.removeprefix('site/')
            assert path.suffix in {'.html','.js','.css'} and not target.startswith(('data/','graph-assets-v4/','downloads/'))
            old = path.read_bytes()
            if target in html_sources:
                assert old == html_sources[target]['raw'], 'Only exact allowlisted raw HTML may be replaced'
            archive = stage_root / 'derived-ui-archive' / target
            assert not archive.exists()
            archive.parent.mkdir(parents=True, exist_ok=True)
            path.rename(archive)
            stage.bytes -= stage.files.pop(relative)['bytes']
            archived.append(dict(path=target, old_sha256=ex.sha(old), public_sha256=ex.sha(raw), scope='UNSEALED_DERIVED_UI_ONLY'))
        stage.write(relative, raw)
    assert (site / 'data/api-index.json').read_bytes() == index_raw, 'Asset finalization cannot modify response/index data'
    assert (site / 'data/report-v6.json').read_bytes() == inputs.raw(ex.ROOT, report_ref)
    inputs.unchanged()
    parity = json.loads((stage_root / 'slots-parity.json').read_bytes())
    slots = [dict(corpus=r['params']['corpus'], slots=r['expected']['coverage']['total_slots'],
        pages=r['expected']['coverage'].get('pages_with_markers',0), coverage=r['expected']['coverage'],
        graph_run_id=r['expected']['graph_run_id'], hierarchy_run_id=r['expected']['hierarchy_run_id'])
        for r in parity if r['params'].get('limit') == '1']
    progress = json.loads((stage_root / 'case-progress.json').read_bytes())
    receipt = dict(version=ex.VERSION, status='STATIC_TRANSPORT_COMPLETE_NOT_RELEASE_QUALIFIED',
        source_report_ref=report_ref, casebook_ref=book_ref, digest_ref=digest_ref, field_guide=guide,
        pdf_catalog_ref=checkpoint['pdf_catalog_ref'], supplement_manifest_ref=supplement_ref, supplement_assets=supplement_lineage,
        backend_root=str(backend), backend_code_sha256=code_pin, backend_snapshot_canonical=False,
        response_policy='PUBLIC_METADATA_LOCATION_PROJECTION', node_scope=checkpoint.get('node_scope',binding['node_scope']),
        coverage=coverage, native_versions=dict(Counter(r['native_version'] for r in coverage)),
        run_id=report['run_id'], report_version=report['version'], report_bytes_unchanged=True,
        map_index_sha256=binding['map_index_sha256'], index_sha256=ex.sha(index_raw), routes=len(entries),
        graph_delivery='same-repository', dataset_delivery_ref=dict(path='data/dataset-delivery.json',sha256=ex.sha(dataset_raw)),
        static_slots=slots, pages_fully_offline=False, installed_repository_self_contained=True,
        pdf_scope='selected', self_contained_lossless_graph_fragments=False,
        api_calls=0, native_executions=0, current_native_execution=False, native_outputs_modified=False,
        case_policy_responses_retargeted=False, asset_lineage=lineage, asset_finalization_only=True,
        archived_derived_ui=archived, data_index_unchanged_during_asset_finalization=True,
        metadata_projections=progress.get('metadata_projections',[]),
        saved_request_count=None, saved_request_count_note='Not retained after the earlier asset-only finalization exception; no inferred count',
        limits=ex.DEFAULT_LIMITS, release_qualified=False, privacy_validation='NOT_RUN', publication_validator='NOT_RUN', browser_smoke='NOT_RUN',
        limitations=['Same-repository immutable RAW datasets online; local repository mirror on localhost. Pages is not fully offline.',
            'Ordinary PDFs cover selected evidence/origins and explicit addons, not every catalog PDF.',
            'Saved display transport only; no new inference or research/privacy qualification.'])
    stage.write('derived-ui-finalization.json', ex.encoded(dict(archived=archived, api_index_sha256=ex.sha(index_raw),
        source_report_ref=report_ref, case_packets_modified=False, native_executions=0)))
    stage.write('site/export-lineage.json', ex.encoded(receipt))
    stage.write('site/publication.json', ex.encoded(dict(version=ex.VERSION, status='UNQUALIFIED_STATIC_STAGE',
        run_id=report['run_id'], source_report_ref=report_ref, api_index='data/api-index.json', release_qualified=False,
        files=[dict(v,path=k.removeprefix('site/')) for k,v in sorted(stage.files.items()) if k.startswith('site/')])) )
    receipt['stored_bytes_before_receipt'] = stage.bytes
    stage.write('stage_receipt.json', ex.encoded(receipt))
    print(json.dumps(dict(status=receipt['status'], routes=len(entries), site_bytes=sum(p.stat().st_size for p in site.rglob('*') if p.is_file()),
        archived=archived, source_report_sha256=report_ref['sha256'])))


if __name__ == '__main__':
    main()
