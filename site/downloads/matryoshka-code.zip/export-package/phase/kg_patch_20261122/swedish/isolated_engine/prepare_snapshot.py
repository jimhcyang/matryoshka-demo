"""Deterministic new-file snapshot with a complete byte/diff manifest.

This bulk copier never edits a canonical module or rebinds its globals.
Each replacement is exact and fails if the inspected upstream source changed.
"""
import difflib
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def replace(text, before, after, count=1):
    if text.count(before) != count:
        raise ValueError("Snapshot seam count differs: " + before[:100])
    return text.replace(before,after)


def copy(name, source, transform):
    path = ROOT / source
    raw = path.read_bytes()
    text = transform(raw.decode())
    compile(text,str(HERE / name),"exec")
    target = HERE / name
    if target.exists() and target.read_text() != text and (HERE / "execution-started.json").exists():
        raise ValueError("An execution already bound this snapshot: " + name)
    target.write_text(text)
    return dict(source=source,source_sha256=sha(raw),snapshot=name,snapshot_sha256=sha(text.encode()),
        diff="".join(difflib.unified_diff(raw.decode().splitlines(True),text.splitlines(True),fromfile=source,tofile=name)))


def narrative(text):
    text = re.sub(r"from \. import ","from matryoshka_narrative import ",text)
    text = re.sub(r"from \.(\w+) import ",r"from matryoshka_narrative.\1 import ",text)
    text = replace(text,"from matryoshka_next import construction as shared","from . import next_construction as shared")
    text = replace(text,'VERSION = "narrative-bounded-red-construction/27"','VERSION = "narrative-bounded-red-construction/27+s2-policy-1"')
    text = replace(text,"def _bounded_pool(case,plan,retrieval,source_index,passage_budget,selection_profile=None):",
        "def _bounded_pool(case,plan,retrieval,source_index,passage_budget,selection_profile=None,source_policy=None):")
    text = replace(text,"shared._pages(case,panel,source_index)","shared._pages(case,panel,source_index,source_policy=source_policy)")
    text = replace(text,"shared._pages(case,pool,source_index)","shared._pages(case,pool,source_index,source_policy=source_policy)")
    text = replace(text,"passage_budget=DEFAULT_PASSAGES, draft_budget=DEFAULT_DRAFTS,selection_profile=None):",
        "passage_budget=DEFAULT_PASSAGES, draft_budget=DEFAULT_DRAFTS,selection_profile=None,source_policy=None):")
    text = replace(text,"_bounded_pool(case,plan,retrieval,source_index,passage_budget,selection_profile)",
        "_bounded_pool(case,plan,retrieval,source_index,passage_budget,selection_profile,source_policy)")
    text = replace(text,"shared._gate(case,plan,group[\"reading\"],candidate,admitted,parser)",
        "shared._gate(case,plan,group[\"reading\"],candidate,admitted,parser,source_policy=source_policy)")
    return text


def next_construction(text):
    text = replace(text,"from matryoshka_current.arm_controls import _checked_page","from .policy import checked_page as _checked_page")
    text = replace(text,"from matryoshka_demo_v6 import reporting_fixed_pool_decisions_v65 as evidence_gate","from . import evidence_gate")
    text = replace(text,"from . import constraints","from matryoshka_next import constraints")
    text = replace(text,"from .source_label_spans import spans as source_label_spans","from matryoshka_next.source_label_spans import spans as source_label_spans")
    text = replace(text,"from .facts import SourcePolicy","from matryoshka_next.facts import SourcePolicy")
    text = replace(text,"def _pages(case, retrieval, source_index=None):","def _pages(case, retrieval, source_index=None, *, source_policy=None):")
    text = replace(text,"    policy=SourcePolicy(corpus,case,supplied_index) if supplied_index is not None else retrieval.get(\"source_policy\")",
        "    if source_policy is not None:\n        from .policy import validate_policy\n        validate_policy(source_policy,case,corpus,supplied_index)\n    policy=source_policy if source_policy is not None else (SourcePolicy(corpus,case,supplied_index) if supplied_index is not None else retrieval.get(\"source_policy\"))")
    text = replace(text,'or p.get("visibility") not in {None,"earlier","both"}:',
        'or source_policy is None and p.get("visibility") not in {None,"earlier","both"}:')
    text = replace(text,"        _checked_page(p,case)","        _checked_page(p,case,source_policy=source_policy)")
    text = replace(text,"def _gate(case, plan, reading, candidate, pages, parse=None):",
        "def _gate(case, plan, reading, candidate, pages, parse=None, *, source_policy=None):")
    text = replace(text,"evidence_gate.derive(sanitized,case,pages)","evidence_gate.derive(sanitized,case,pages,source_policy=source_policy)")
    # Other relative imports are compatibility helpers, not copied implementations.
    text = text.replace("from .readings import", "from matryoshka_next.readings import")
    return text


def local_gate(text):
    text = replace(text,"def _quote(ref, pages, masks, veto, case):","def _quote(ref, pages, masks, veto, case, source_policy=None):")
    before = '''    if (page.get("permitted") is not True or page.get("corpus") != case["corpus"]
            or page["document_id"] == case["document_id"] or page["date"] >= case["date"]
            or page.get("visibility") not in {None, "earlier", "both"}
            or page["document_id"] in veto):'''
    text = replace(text,before,'''    if source_policy is not None:
        from .policy import validate_policy
        validate_policy(source_policy,case)
        pi = source_policy.corpus.page_index.get(page["id"])
        if pi is None or source_policy.bound_pages.get(page["id"]) != page or not source_policy.allowed(pi):
            raise ValueError("Quote fails the explicit scoped source policy")
    if (page.get("permitted") is not True or page.get("corpus") != case["corpus"]
            or source_policy is None and (page["document_id"] == case["document_id"] or page["date"] >= case["date"]
                or page.get("visibility") not in {None, "earlier", "both"})
            or page["document_id"] in veto):''')
    text = replace(text,"index, engine, matcher, grammar=None):","index, engine, matcher, grammar=None, source_policy=None):")
    text = replace(text,"_quote(ref, pages, masks, veto, case)","_quote(ref, pages, masks, veto, case,source_policy=source_policy)")
    text = replace(text,"def derive(record, case, eligible_index):","def derive(record, case, eligible_index, source_policy=None):")
    text = replace(text,"case, index, engine, matcher, grammar)","case, index, engine, matcher, grammar,source_policy=source_policy)")
    text = replace(text,"case, index, engine, matcher))","case, index, engine, matcher,source_policy=source_policy))")
    text = replace(text,'"Pinned quotes replay; strict cutoff, whole-origin and whole-cable handling checks passed."',
        '("Pinned quotes replay under the explicit scoped source policy." if source_policy is not None else "Pinned quotes replay; strict cutoff, whole-origin and whole-cable handling checks passed.")')
    return text


def evidence_gate(text):
    text = replace(text,"from . import reporting_local_decisions_v65 as parent","from . import local_gate as parent")
    text = replace(text,"from . import reporting_fixed_pool_grammar_v65 as slot_grammar","from . import slot_grammar")
    text = replace(text,"def derive(record, case, eligible_index):","def derive(record, case, eligible_index, source_policy=None):")
    text = replace(text,"(record, case, eligible_index)\n        if case[\"task\"] == \"redaction\":",
        "(record, case, eligible_index,source_policy=source_policy)\n        if case[\"task\"] == \"redaction\":")
    text = replace(text,"parent._pages(eligible_index, case), scoped.Engine(), parent)",
        "parent._pages(eligible_index, case), scoped.Engine(), parent,source_policy=source_policy)")
    text = replace(text,"parent._quote(ref, pages, masks, veto, case)","parent._quote(ref, pages, masks, veto, case,source_policy=source_policy)")
    text = text.replace("from .reporting_fixed_pool_role_projection_v2 import", "from matryoshka_demo_v6.reporting_fixed_pool_role_projection_v2 import")
    return text


def grammar(text):
    text = replace(text,"def apply(packet, record, case, index, engine, parent):",
        "def apply(packet, record, case, index, engine, parent,source_policy=None):")
    return replace(text,"parent._quote(reference, *index, case)","parent._quote(reference, *index, case,source_policy=source_policy)")


def retrieval(text):
    text = replace(text,"document_budget=40, discovery_profile=None):","document_budget=40, discovery_profile=None, source_policy=None):")
    text = replace(text,"    policy = SourcePolicy(selected, case, source_index)",
        "    if source_policy is not None:\n        from .policy import validate_policy\n        validate_policy(source_policy,case,selected,source_index)\n    policy = source_policy if source_policy is not None else SourcePolicy(selected, case, source_index)")
    text = text.replace("from .focal_retrieval import", "from matryoshka_narrative.focal_retrieval import")
    text = replace(text,'    return value\n', '''    if source_policy is not None:
        value["receipt"]["legacy_scope_metadata"] = {k:value["receipt"].get(k) for k in ("whole_origin_excluded","source_policy_version")}
        value["receipt"].update(source_policy_version=source_policy.VERSION,whole_origin_excluded=False,
            source_scope=source_policy.scope.binding(),source_view_sha256=source_policy.view_sha256,
            source_scope_is_retrospective=True)
    return value
''')
    return text


def planning(text):
    return replace(text,"from .contracts import engine_case, public_query","from matryoshka_narrative.contracts import engine_case, public_query")


def main():
    entries = [copy(name,source,fn) for name,source,fn in (
        ("narrative_construction.py","matryoshka_narrative/construction.py",narrative),
        ("next_construction.py","matryoshka_next/construction.py",next_construction),
        ("local_gate.py","matryoshka_demo_v6/reporting_local_decisions_v65.py",local_gate),
        ("evidence_gate.py","matryoshka_demo_v6/reporting_fixed_pool_decisions_v65.py",evidence_gate),
        ("slot_grammar.py","matryoshka_demo_v6/reporting_fixed_pool_grammar_v65.py",grammar),
        ("retrieval.py","matryoshka_narrative/retrieval.py",retrieval),
        ("planning.py","matryoshka_narrative/planning.py",planning),
        ("api.py","matryoshka_narrative/api.py",lambda text:text))]
    result = dict(version="isolated-narrative-s2-source-snapshot/1",files=entries,
        canonical_files_modified=False,in_place_global_monkeypatching=False,
        additional_guard_delta="Isolated artifact/API headroom 3GiB, per bounded study authorization; ordinary guards unchanged")
    target = HERE / "snapshot-manifest-v02.json"
    raw = json.dumps(result,sort_keys=True,indent=2) + "\n"
    if target.exists() and target.read_text() != raw:
        raise ValueError("Snapshot manifest changed")
    target.write_text(raw)
    print(json.dumps(dict(snapshot_files=len(entries),manifest_sha256=sha(raw.encode())),indent=2))


if __name__ == "__main__":
    main()
