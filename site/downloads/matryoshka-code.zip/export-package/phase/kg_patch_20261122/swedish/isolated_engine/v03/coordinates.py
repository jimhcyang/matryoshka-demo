"""Producer job-local offsets only; no global-match rescue or quote search."""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest

VERSION = "declared-producer-job-local-coordinates/3"
LEGACY_SHA = "2d418fff58c3b731a53cbbb5355e1b8d6bd96a49f4edb0f18c110f25ea2cfae4"


def resolve(row, props, corpus, jobs, counts):
    def held(reason):
        counts["coordinate_held_" + reason] += 1
        return None

    pid = row.get("canonical_page_id")
    job = jobs.get(row.get("job_id"))
    if job is None or pid not in corpus.source_index:
        return held("missing_job_or_page")
    page = corpus.source_index[pid]
    identity = (pid, row.get("document_id"), row.get("document_date_iso"), row.get("visibility"))
    if identity != job[:4] or (job[1], job[2]) != (page["document_id"], page["date"]):
        raise ValueError("Observation/job/page document, date or visibility mismatch")
    if page.get("source_sha256") != digest(page["text"]):
        raise ValueError("Source page text/hash mismatch")
    source = props.get("source_provenance")
    if not isinstance(source, dict):
        raise ValueError("Missing source provenance object")
    if source.get("record_id") != job[4] or source.get("document_date_iso") != page["date"]:
        raise ValueError("Nested source provenance record/date mismatch")
    if source.get("document_id", job[1]) != job[1] or row.get("record_id", job[4]) != job[4]:
        raise ValueError("Nested or row document/record mismatch")
    window, job_text = job[5], job[6]
    if not isinstance(window, dict) or not isinstance(job_text, str):
        return held("invalid_window_type")
    tag = window.get("coordinate_system")
    if tag == "later_canonical_page_text":
        if job[3] != "later_only":
            return held("tag_visibility_mismatch")
    elif tag == "earlier_canonical_page_text":
        # This is an identity proof, not guessed alignment across redactions.
        if job[3] != "both" or pid not in getattr(corpus, "verified_earlier_identity_pages", frozenset()):
            return held("earlier_later_page_not_identical")
    else:
        return held("untrusted_coordinate_tag")
    if "target_span" in props and props["target_span"] != window:
        return held("observation_target_span_mismatch")
    base, end = window.get("char_start"), window.get("char_end")
    if type(base) is not int or type(end) is not int or not 0 <= base < end <= len(page["text"]):
        return held("window_bounds")
    if page["text"][base:end] != job_text:
        return held("full_window_mismatch")
    job_sha = props.get("source_text_sha256")
    if job_sha is not None and job_sha != hashlib.sha256(job_text.encode()).hexdigest():
        return held("job_text_sha_mismatch")
    a, b, text = props.get("char_start"), props.get("char_end"), props.get("evidence_quote")
    if type(a) is not int or type(b) is not int or not isinstance(text, str):
        return held("quote_type")
    if not 0 <= a < b <= len(job_text) or job_text[a:b] != text:
        return held("job_local_quote_mismatch")
    if MASK.search(text):
        return held("opaque_quote")
    start, stop = base + a, base + b
    if not base <= start < stop <= end or page["text"][start:stop] != text:
        return held("mapped_quote_mismatch")
    counts["coordinate_accepted_" + tag] += 1
    if base:
        counts["declared_job_window_local_offsets_mapped"] += 1
    return corpus.page_index[pid], start, stop, text


def legacy_replay(corpus, jobs):
    path = Path(__file__).resolve().parent.parent / "v02/context.py"
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != LEGACY_SHA:
        raise ValueError("Old coordinate comparator changed")
    load = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == "load_context")
    replay = next(n for n in load.body if isinstance(n, ast.FunctionDef) and n.name == "replay")
    factory = ast.parse("def factory(corpus, jobs, counts, MASK):\n    pass\n").body[0]
    factory.body = [deepcopy(replay), ast.Return(value=ast.Name(id="replay", ctx=ast.Load()))]
    module = ast.fix_missing_locations(ast.Module(body=[factory], type_ignores=[]))
    namespace = {}
    exec(compile(module, str(path), "exec"), namespace)
    return namespace["factory"](corpus, jobs, Counter(), MASK)


class CoordinateAudit:
    """Compare during the existing source stream; retain counts, not a dataset."""
    def __init__(self, corpus, jobs):
        self.corpus, self.jobs = corpus, jobs
        self.old = legacy_replay(corpus, jobs)
        self.counts, self.reasons, self.examples = Counter(), Counter(), {}
        self.checksum = hashlib.sha256()

    def compare(self, kind, row, props):
        reasons = Counter()
        new = resolve(row, props, self.corpus, self.jobs, reasons)
        old = self.old(row, props)
        category = ("both_held" if new is None and old is None else
                    "old_accepted_new_held" if new is None else
                    "old_held_new_accepted" if old is None else
                    "same_occurrence" if new == old else "changed_occurrence")
        self.counts[kind + ":" + category] += 1
        if new is None:
            self.reasons.update(reasons)
        record = dict(kind=kind, row_id=row.get("node_id", row.get("relation_evidence_id")),
            job_id=row.get("job_id"), page_id=row.get("canonical_page_id"),
            raw_span=[props.get("char_start"), props.get("char_end")],
            old_page_span=None if old is None else list(old[1:3]),
            new_page_span=None if new is None else list(new[1:3]), category=category)
        self.checksum.update((json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n").encode())
        if category not in {"both_held", "same_occurrence"}:
            bucket = self.examples.setdefault(kind + ":" + category, [])
            if len(bucket) < 12:
                bucket.append(record)
        return new

    def report(self):
        return dict(version="old-new-producer-coordinate-audit/1", old_context_sha256=LEGACY_SHA,
            new_coordinate_version=VERSION, counts=dict(self.counts), held_reasons=dict(self.reasons),
            ordered_row_resolution_sha256=self.checksum.hexdigest(), bounded_examples=self.examples,
            scope="All scoped supported evidence-node rows and all scoped relation-evidence rows in the existing pinned streams; relation comparison occurs before new graph endpoint filtering.",
            historical_old_materialized_graph_reconstructed=False,
            full_population_occurrence_resolution_comparison=True)
