"""Attempt03: declared producer coordinates; cached query planning; zero API."""
from copy import deepcopy
from datetime import datetime, timezone
import os
import time
from matryoshka_next.workflow import read
from matryoshka_demo.io import digest
from matryoshka_narrative.workflow import code_pins
from ..run_study import write, pin, cite_replay
from ..api import Budget
from ..context import HERE as BASE, ROOT, file_sha, memory_mb
from ..guards import require_headroom
from .. import retrieval
from ..v02 import narrative_construction
from .context import load_context
from .coordinates import VERSION


def main():
    before = Budget(ROOT / "experiments/narrative_demo/api").total()
    os.environ["NARRATIVE_INCREMENTAL_BASELINE_USD"] = str(before)
    os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"] = "0"
    first, out = BASE / "attempt01", BASE / "attempt03"
    require_headroom(BASE)
    out.mkdir(exist_ok=False)
    inputs = read(first / "public-inputs.json")
    canonical = code_pins()
    manifest_ref = pin(BASE / "v03/variant-manifest.json")
    manifest = read(BASE / "v03/variant-manifest.json")
    code = manifest["version_three_code_pins"]
    inherited = read(BASE / "SCOPED_RELEASE_CONTRACT_v03.json")["code_snapshot_ref"]["python_source_allowlist"]

    def verify():
        assert canonical == code_pins()
        for name, expected in code.items(): assert file_sha(BASE / name) == expected
        for ref in inherited: assert file_sha(ROOT / ref["path"]) == ref["sha256"]

    verify()
    write(out / "authorization.json", dict(version="s2-scoped-study-attempt/3", started_utc=datetime.now(timezone.utc).isoformat(),
        incremental_ceiling_usd=0, api_calls_authorized=0, cumulative_ceiling_usd=50,
        budget_before_usd=before, variant_manifest_ref=manifest_ref, version_three_code_pins=code,
        inherited_python_source_pins=inherited, canonical_code_pins=canonical, no_publication=True))
    write(out / "public-inputs.json", inputs)
    corpus = load_context(inputs["cases"][0])
    audit_ref = write(out / "coordinate-audit.json", corpus.coordinate_audit)
    context_ref = write(out / "context-binding.json", dict(binding=corpus.binding,
        view_sha256=digest(corpus.binding), rss_peak_mb=memory_mb(), coordinate_audit_ref=audit_ref))
    rows = []
    for position, case in zip(("first", "second"), inputs["cases"], strict=True):
        start = time.perf_counter()
        base = read(first / position / "normal-plan.json")
        readings = read(first / position / "normal-readings.json")
        plan = deepcopy(base["native_plan"]); plan["readings_packet"] = readings["packet"]
        previous = read(BASE / "attempt02" / position / "execution.json.gz")
        assert plan == previous["plan"] and case == previous["case"]
        policy = corpus.policy_for(case)
        print(dict(stage="attempt03_retrieval", position=position), flush=True)
        found = retrieval.retrieve(corpus, case, plan, source_index=corpus.source_index, source_policy=policy,
            document_budget=40, passage_budget=80)
        ret_ref = write(out / position / "retrieval.json.gz", found["receipt"])
        result = narrative_construction.construct(case, plan, found, source_index=corpus.source_index, source_policy=policy,
            passage_budget=20, draft_budget=24, top_k=5)
        replayed = cite_replay(result, policy)
        verify()
        assert result["query_sha256"] == digest(case["query"]) and result["provided_plan_sha256"] == digest(plan)
        packet = dict(version="narrative-scoped-source-study-execution/3", parent_workflow="narrative-local-execution/3",
            original_canonical_native_run=False, canonical_native_run=False, execution_performed=True, case=case, plan=plan,
            result=result, native_checksum=digest(result), query_sha256=digest(case["query"]), source_context_ref=context_ref,
            source_view_sha256=digest(corpus.binding), retrieval_ref=ret_ref, canonical_code_pins=canonical,
            variant_code_pins=code, inherited_python_source_pins=inherited, coordinate_policy_version=VERSION,
            coordinate_audit_ref=audit_ref, plan_ref=pin(first / position / "normal-plan.json"),
            readings_ref=pin(first / position / "normal-readings.json"), engine_manifest_ref=manifest_ref,
            source_snapshot_ref=pin(BASE / "snapshot-manifest-v02.json"),
            configuration=dict(retrieval_documents=40, retrieval_pages=80, construction_pages=20, drafts_per_reading=24,
                top_k=5, selection_profile=None, discovery_profile=None), api_calls=0, gold=None,
            source_citations_replayed=replayed, elapsed_seconds=time.perf_counter() - start)
        execution_ref = write(out / position / "execution.json.gz", packet)
        completion_ref = write(out / position / "execution-completion.json", dict(version="scoped-study-execution-completion/3",
            execution_ref=execution_ref, execution_digest=digest(packet), native_checksum=digest(result),
            coordinate_policy_version=VERSION, original_canonical_native_completion=False, execution_performed=True, gold=None))
        row = dict(position=position, execution_ref=execution_ref, completion_ref=completion_ref,
            inspected_origin="page_d884726ce3791d6d8092" in result["inspected_page_ids"],
            readings=[dict(reading_id=r["reading"]["id"], candidates=[dict(rank=c["rank"], fill=c["fill"],
                status=c["local_decision"]["status"], source_variants=len(c["surface_duplicate_group"]["source_variants"]))
                for c in r["candidates"]]) for r in result["readings"]])
        rows.append(row); print(row, flush=True)
    after = Budget(ROOT / "experiments/narrative_demo/api").total()
    assert before == after
    write(out / "study-complete.json", dict(version="isolated-s2-two-query-study/3", cases=rows,
        source_context_ref=context_ref, coordinate_audit_ref=audit_ref, variant_manifest_ref=manifest_ref,
        budget_before_usd=before, budget_after_usd=after, new_spend_usd=0, api_calls=0,
        exact_cached_plans_and_readings_reused=True, both_queries_executed=True, gold=None, rss_peak_mb=memory_mb()))


if __name__ == "__main__":
    main()
