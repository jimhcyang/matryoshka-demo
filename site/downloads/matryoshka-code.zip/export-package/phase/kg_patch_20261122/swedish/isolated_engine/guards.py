"""This bounded study's explicitly authorized 3GiB artifact guard."""
from datetime import datetime, timezone
from pathlib import Path
import os
import shutil


def remaining_seconds(*, new_work=False):
    value = os.environ.get("S2_STUDY_DEADLINE_UTC")
    if not value:
        return None
    seconds = (datetime.fromisoformat(value.replace("Z","+00:00")) - datetime.now(timezone.utc)).total_seconds()
    if seconds <= 0:
        raise TimeoutError("Bounded S2 study deadline reached")
    return seconds


def require_headroom(path):
    remaining_seconds()
    target = Path(path).resolve()
    while not target.exists():
        target = target.parent
    free = shutil.disk_usage(target).free
    if free < 3 * 1024**3:
        raise OSError("Stop: below the study's 3GiB free-space boundary")
    return free
