"""Full eligible later text plus native literal graph projections, in memory.

No database, dataset copy, answer seeds, or inferred source records are written.
Producer job-local offsets map only through complete declared source windows.
Earlier coordinates need pinned full-page identity; no global-match rescue.
"""
from collections import Counter, defaultdict
from collections.abc import Mapping
from copy import deepcopy
import gc
import hashlib
import json
from pathlib import Path
import resource
import sys

import numpy as np
from scipy import sparse

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.corpus import BM25, Corpus, Eligible, words
from matryoshka_demo.corpus_policy_v5 import PolicyView
from matryoshka_demo.io import digest
from matryoshka_current.resources import authority
from phase.kg_patch_20261122.swedish.scoped_context import SourceScope
from ..guards import require_headroom
from ..policy import StudyPolicy, register_verified_corpus
from .coordinates import CoordinateAudit, VERSION as COORDINATE_VERSION

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
WORKSPACE = ROOT.parent
REFS = ROOT / "experiments/current_refresh/resource_handoff/registries/db09a0bd26047428e9350b57/execution_refs_v01.json"


def file_sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()


def memory_mb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / (1024**2 if sys.platform == "darwin" else 1024)


def pinned_rows(pin, *, field=None, wanted=None):
    path = WORKSPACE / pin["path"]
    if path.resolve() != path or not path.is_file():
        raise ValueError("Missing or redirected source artifact")
    checksum = hashlib.sha256()
    count = 0
    with path.open("rb") as stream:
        for line in stream:
            checksum.update(line)
            count += 1
            if count % 30000 == 0:
                require_headroom(HERE)
            if not line.strip(): continue
            row = json.loads(line)
            if wanted is None or row.get(field) in wanted:
                yield row
    if checksum.hexdigest() != pin["sha256"]:
        raise ValueError("Source artifact byte pin changed: " + pin["path"])


class Compact(Mapping):
    """Fixed-key immutable rows avoid per-observation dictionaries."""
    __slots__ = ("values",)
    keys_tuple = ()
    def __init__(self,*values): self.values = values
    def __getitem__(self,key):
        try: return self.values[self.keys_tuple.index(key)]
        except ValueError: raise KeyError(key) from None
    def __iter__(self): return iter(self.keys_tuple)
    def __len__(self): return len(self.keys_tuple)


class Occurrence(Compact):
    __slots__ = ()
    keys_tuple = ("node_id","page_index","unit_index","label","entity_type","start","end","source_type","source_row_id")


class Unit(Compact):
    __slots__ = ()
    keys_tuple = ("id","pi","text","start","end","nodes")


class Edge(Compact):
    __slots__ = ()
    keys_tuple = ("a","b","pi","ui","source_row_id","relation","route_class","native_assertion_mode",
        "source_observation_id","target_observation_id","semantic_edge_id")


class LazyFacts:
    def __init__(self,corpus): self.corpus,self.value=corpus,None
    def __getattr__(self,name):
        if self.value is None:
            from matryoshka_next.facts import FactIndex
            self.value=FactIndex(self.corpus)
        return getattr(self.value,name)


class StudyEligible(Eligible):
    def __init__(self,corpus,case):
        self.corpus,self.case=corpus,public_case(case)
        self.source_policy=corpus.policy_for(case)
        self.page_mask=self.source_policy.mask()
        self.unit_mask=self.page_mask[corpus.unit_pages]
        self.surface_mask=self.page_mask[corpus.surface_pages]
        self.active=np.zeros(len(corpus.nodes),dtype=bool)
        self.active[corpus.surface_nodes[self.surface_mask]]=True
        support={(min(e["a"],e["b"]),max(e["a"],e["b"]),corpus.pages[e["pi"]]["document_id"])
            for e in corpus.edge_rows if self.page_mask[e["pi"]] and self.active[e["a"]] and self.active[e["b"]]}
        aa,bb=[],[]
        for a,b,_ in sorted(support): aa.extend((a,b));bb.extend((b,a))
        self.adjacency=sparse.coo_matrix((np.ones(len(aa)),(aa,bb)),shape=(len(self.active),len(self.active))).tocsr()
        self.page_stats=corpus.page_bm25.stats(self.page_mask)
        self.node_stats=corpus.node_bm25.stats(self.surface_mask)

    def citation(self,ui):
        unit=self.corpus.units[ui]
        return dict(super().citation(ui),**self.source_policy.citation(unit["pi"],unit["start"],unit["end"]))


class FullCorpus(Corpus,PolicyView):
    def __getattr__(self,name): raise AttributeError(name)
    def eligible(self,case): return StudyEligible(self,case)
    def policy_for(self,case):
        key=digest(case)
        if key not in self._policies: self._policies[key]=StudyPolicy(self,case)
        return self._policies[key]


def source_pins():
    refs=json.loads(REFS.read_bytes())
    registry_path=ROOT/refs["registry_ref"]["path"]
    if file_sha(registry_path)!=refs["registry_ref"]["sha256"]: raise ValueError("Registry pin changed")
    native=json.loads(registry_path.read_bytes())["corpora"]["cib"]["native_registry"]
    pins={k:{x:v[x] for x in ("path","sha256")} for k,v in native["files"].items()}
    earlier_pages_pin = dict(pins["pages"])
    late=json.loads((ROOT/"experiments/recovery_comparison_20261120/swedes/resource_pins_v2.json").read_bytes())["source_files"]
    for name,suffix in (("pages","/views/later/pages.jsonl"),("evidence_nodes","/views/later/evidence_nodes.jsonl"),
        ("semantic_edge_evidence","/views/later/semantic_edge_evidence.jsonl")):
        pins[name]=next(dict(path=p,sha256=s) for p,s in late.items() if p.endswith(suffix))
    # The existing later hierarchy is observed/pinned before reading, not rebuilt.
    hp=pins["memberships"]["path"].replace("/views/earlier/","/views/later/")
    pins["memberships"]=dict(path=hp,sha256=file_sha(WORKSPACE/hp),
        verification="Observed existing declared later hierarchy artifact, not a producer-declared byte hash")
    selected={k:pins[k] for k in ("documents","pages","quarantine","source_quarantine_policy","jobs",
        "canonical_entities","evidence_nodes","semantic_edge_evidence","relation_evidence","memberships")}
    selected["earlier_pages_identity_proof"] = earlier_pages_pin
    return native,selected


def load_context(case, progress=print):
    require_headroom(HERE)
    native,pins=source_pins()
    scope=SourceScope.swedish_s2(case)
    corpus=FullCorpus.__new__(FullCorpus)
    corpus.corpus,corpus.scope="cib",scope
    corpus.classification,corpus.files,corpus.excluded_documents={}, {}, []
    counts=Counter()
    docs={r["document_id"]:r for r in pinned_rows(pins["documents"])}
    quarantine={r["page_pair_id"] for r in pinned_rows(pins["quarantine"])}
    guard_raw=(WORKSPACE/pins["source_quarantine_policy"]["path"]).read_bytes()
    if hashlib.sha256(guard_raw).hexdigest()!=pins["source_quarantine_policy"]["sha256"]:raise ValueError("Quarantine pin changed")
    guard=json.loads(guard_raw)
    quarantine.update(r["canonical_page_id"] for r in guard["quarantined_pages"]+guard["quarantined_jobs"])
    corpus.pages=[]
    for row in pinned_rows(pins["pages"]):
        counts["later_pages_scanned"]+=1
        doc=docs[row["document_id"]]
        pid=row["canonical_page_id"]
        p=dict(id=pid,corpus="cib",document_id=row["document_id"],date=doc["document_date_iso"],text=row["text"],
            source_sha256=digest(row["text"]),release="later",visibility="later",source_page=row["source_page"],earlier_page=None,
            permitted=pid not in quarantine,quarantined=pid in quarantine,
            classification=doc.get("classification_level"),handling=doc.get("distribution_controls",[]))
        if row.get("view")!="later":raise ValueError("Wrong page release")
        if scope.admits(p):corpus.pages.append(p)
    corpus.pages.sort(key=lambda p:p["id"])
    corpus.page_ids=[p["id"] for p in corpus.pages]
    corpus.page_index={p:i for i,p in enumerate(corpus.page_ids)}
    corpus.source_index={p["id"]:p for p in corpus.pages}
    if len(corpus.source_index)!=len(corpus.pages):raise ValueError("Duplicate source page")
    corpus.page_dates=np.asarray([p["date"] for p in corpus.pages]);corpus.page_docs=np.asarray([p["document_id"] for p in corpus.pages])
    corpus.allowed=np.ones(len(corpus.pages),dtype=bool)
    progress(dict(stage="source_pages",eligible_pages=len(corpus.pages),rss_peak_mb=memory_mb()),flush=True)
    identical = set()
    for earlier in pinned_rows(pins["earlier_pages_identity_proof"],field="canonical_page_id",wanted=corpus.source_index):
        page = corpus.source_index[earlier["canonical_page_id"]]
        if earlier.get("view") != "earlier" or earlier["document_id"] != page["document_id"]:
            raise ValueError("Earlier identity proof page/document/view mismatch")
        if earlier["text"] == page["text"]:
            identical.add(page["id"])
    corpus.verified_earlier_identity_pages = frozenset(identical)
    counts["earlier_later_full_pages_identical"] = len(identical)
    jobs={}
    for r in pinned_rows(pins["jobs"],field="canonical_page_id",wanted=corpus.source_index):
        if r["visibility"] not in {"both","later_only"}:continue
        if any(c.get("canonical_page_id") in quarantine for c in r.get("context_provenance",[])):continue
        p=corpus.source_index[r["canonical_page_id"]]
        if (r["document_id"],r["document_date_iso"])!=(p["document_id"],p["date"]):raise ValueError("Job date/document mismatch")
        if r["record_id"] != docs[r["document_id"]]["record_id"]:raise ValueError("Job/document record mismatch")
        jobs[r["job_id"]]=(r["canonical_page_id"],r["document_id"],r["document_date_iso"],r["visibility"],r["record_id"],r.get("target_span",{}),r["text"])
    coordinate_audit = CoordinateAudit(corpus,jobs)
    def replay(row,props):
        from .coordinates import resolve
        return resolve(row,props,corpus,jobs,counts)
    corpus.nodes={};corpus.node_ids=[];corpus.node_index={}
    corpus.units=[];unit_map={};unit_nodes=[]
    corpus.occurrences=[];corpus.occurrences_by_page=defaultdict(list);corpus.occurrences_by_node=defaultdict(list)
    corpus.surfaces=[];surface_pages=[];surface_nodes=[]
    endpoints={}
    def node(nid,kind,etype=None):
        nid=sys.intern(nid)
        if nid not in corpus.node_index:
            corpus.node_index[nid]=len(corpus.node_ids);corpus.node_ids.append(nid)
            corpus.nodes[nid]=dict(id=nid,kind=kind,entity_type=etype)
        elif corpus.nodes[nid]["kind"]!=kind:raise ValueError("Mixed native node kinds")
        return nid,corpus.node_index[nid]
    def unit(pi,a,b,text,nodes):
        key=pi,a,b
        if key not in unit_map:
            unit_map[key]=len(corpus.units)
            corpus.units.append(Unit("quote_"+digest([corpus.page_ids[pi],[a,b]])[:20],pi,text,a,b,None));unit_nodes.append(set())
        ui=unit_map[key];unit_nodes[ui].update(nodes);return ui
    for row in pinned_rows(pins["evidence_nodes"],field="canonical_page_id",wanted=corpus.source_index):
        kind={"EntityMention":"Entity","EventMention":"Event","ClaimMention":"Claim"}.get(row["node_type"])
        if kind is None:continue
        props=row["properties"];own=replay(row,props)
        coordinate_audit.compare("node",row,props)
        if own is None:continue
        pi,a,b,text=own
        nid=props.get("canonical_entity_id") if kind=="Entity" else kind.casefold()+"_"+hashlib.sha256(row["node_id"].encode()).hexdigest()[:20]
        if not nid:counts["unmapped_alias_observation_held"]+=1;continue
        nid,ni=node(nid,kind,props.get("entity_type"))
        oid=sys.intern(row["node_id"]);ui=unit(pi,a,b,text,[ni])
        label=row.get("canonical_label") or text
        terms=set(words(text));surface=" ".join(w for w in words(label) if w in terms) or text
        field={"Entity":"entities","Event":"events","Claim":"claims"}[kind]
        oi=len(corpus.occurrences)
        corpus.occurrences.append(Occurrence(nid,pi,ui,label,props.get("entity_type"),a,b,field,oid))
        corpus.occurrences_by_page[pi].append(oi);corpus.occurrences_by_node[nid].append(oi)
        corpus.surfaces.append(surface);surface_pages.append(pi);surface_nodes.append(ni)
        endpoints[(row["job_id"],props["local_id"])]=(nid,oid)
    progress(dict(stage="native_observations",observations=len(corpus.occurrences),nodes=len(corpus.nodes),rss_peak_mb=memory_mb()),flush=True)
    for r in pinned_rows(pins["canonical_entities"]):
        nid=r["canonical_entity_id"]
        if nid in corpus.nodes:
            corpus.nodes[nid]["native_reference_authority"]=authority(r)
    edge_lookup={}
    for r in pinned_rows(pins["semantic_edge_evidence"],field="canonical_page_id",wanted=corpus.source_index):
        if r["visibility"] not in {"both","later_only"}:continue
        if r["source_id"] not in corpus.node_index or r["target_id"] not in corpus.node_index:continue
        edge_lookup[r["relation_evidence_id"]]=(r["semantic_edge_id"],r["source_id"],r["target_id"],r["canonical_page_id"],r["job_id"],r["relation_type"],r["document_id"],r["document_date_iso"],r["visibility"])
    corpus.edge_rows=[]
    for r in pinned_rows(pins["relation_evidence"],field="canonical_page_id",wanted=corpus.source_index):
        coordinate_audit.compare("relation",r,r)
        edge=edge_lookup.get(r["relation_evidence_id"])
        if edge is None:continue
        if edge[3:]!=(r["canonical_page_id"],r["job_id"],r["relation"],r["document_id"],r["document_date_iso"],r["visibility"]):
            raise ValueError("Native graph edge/source relation metadata mismatch")
        own=replay(r,r)
        if own is None:continue
        left,right=endpoints.get((r["job_id"],r["source"])),endpoints.get((r["job_id"],r["target"]))
        if left is None or right is None:counts["edge_endpoint_without_literal_source_held"]+=1;continue
        if (left[0],right[0])!=(edge[1],edge[2]):raise ValueError("Native graph endpoints differ from exact job-local observations")
        pi,a,b,text=own;na,nb=corpus.node_index[left[0]],corpus.node_index[right[0]]
        if na==nb:continue
        ui=unit(pi,a,b,text,[na,nb])
        corpus.edge_rows.append(Edge(na,nb,pi,ui,r["relation_evidence_id"],r["relation"],"SOURCE_ASSERTION",r.get("assertion_mode"),left[1],right[1],edge[0]))
    corpus.coordinate_audit = coordinate_audit.report()
    del coordinate_audit,jobs,endpoints,edge_lookup,unit_map,docs
    corpus.units=[Unit(*u.values[:-1],tuple(sorted(ns))) for u,ns in zip(corpus.units,unit_nodes)]
    del unit_nodes
    corpus.unit_pages=np.asarray([u["pi"] for u in corpus.units],dtype=int)
    corpus.surface_pages=np.asarray(surface_pages,dtype=int);corpus.surface_nodes=np.asarray(surface_nodes,dtype=int)
    corpus.membership=[(ui,ni) for ui,u in enumerate(corpus.units) for ni in u["nodes"]]
    corpus.hierarchy={}
    for r in pinned_rows(pins["memberships"]):
        if r["node_id"] not in corpus.node_index:continue
        if r.get("view")!="later":raise ValueError("Wrong hierarchy source view")
        corpus.hierarchy[r["node_id"]]={k:r.get(k) for k in ("domain_id","theme_id","community_id")}
    gc.collect()
    progress(dict(stage="native_graph",edges=len(corpus.edge_rows),units=len(corpus.units),rss_peak_mb=memory_mb()),flush=True)
    corpus.page_bm25=BM25([p["text"] for p in corpus.pages]);corpus.node_bm25=BM25(corpus.surfaces)
    corpus._next_source_fact_index=LazyFacts(corpus)
    corpus._policies={}
    corpus.binding=dict(version="full-later-source-view/1",verified_source_bytes=True,source_scope=scope.binding(),
        graph_id=native["graph_id"],hierarchy_id=native["hierarchy_id"],alias_id=native["alias_id"],resource_id=native["resource_id"],
        source_pins=pins,complete_eligible_source_page_universe=True,actual_release="later",
        offsets=COORDINATE_VERSION,
        earlier_coordinate_policy="Only pinned earlier/later full-page identity permits earlier-window coordinates; otherwise held, never aligned or searched",
        coordinate_audit_sha256=digest(corpus.coordinate_audit),
        counts=dict(counts,pages=len(corpus.pages),nodes=len(corpus.nodes),occurrences=len(corpus.occurrences),units=len(corpus.units),edges=len(corpus.edge_rows)))
    register_verified_corpus(corpus)
    progress(dict(stage="context_ready",view_sha256=digest(corpus.binding),rss_peak_mb=memory_mb()),flush=True)
    return corpus
