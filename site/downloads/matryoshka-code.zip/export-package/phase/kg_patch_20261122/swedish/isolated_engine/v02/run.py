"""Attempt02: no planner calls; exact Attempt01 plans/readings reused."""
from copy import deepcopy
import json
import time
from matryoshka_next.workflow import read
from matryoshka_demo.io import digest
from matryoshka_narrative.workflow import code_pins
from ..run_study import write, pin, cite_replay
from ..api import Budget
from ..context import HERE as BASE, ROOT, file_sha, memory_mb
from .. import retrieval
from .context import load_context
from . import narrative_construction


def main():
    before=Budget(ROOT/"experiments/narrative_demo/api").total()
    first=BASE/"attempt01";out=BASE/"attempt02"
    inputs=read(first/"public-inputs.json")
    canonical=code_pins()
    code={"v02/"+p.name:file_sha(p) for p in sorted((BASE/"v02").glob("*.py"))}
    corpus=load_context(inputs["cases"][0])
    context_ref=write(out/"context-binding.json",dict(binding=corpus.binding,view_sha256=digest(corpus.binding),rss_peak_mb=memory_mb()))
    rows=[]
    for position,case in zip(("first","second"),inputs["cases"]):
        start=time.perf_counter()
        base=read(first/position/"normal-plan.json")
        readings=read(first/position/"normal-readings.json")
        plan=deepcopy(base["native_plan"]);plan["readings_packet"]=readings["packet"]
        policy=corpus.policy_for(case)
        print(dict(stage="attempt02_retrieval",position=position),flush=True)
        found=retrieval.retrieve(corpus,case,plan,source_index=corpus.source_index,source_policy=policy,document_budget=40,passage_budget=80)
        ret_ref=write(out/position/"retrieval.json.gz",found["receipt"])
        result=narrative_construction.construct(case,plan,found,source_index=corpus.source_index,source_policy=policy,
            passage_budget=20,draft_budget=24,top_k=5)
        replayed=cite_replay(result,policy)
        assert result["query_sha256"]==digest(case["query"]) and result["provided_plan_sha256"]==digest(plan)
        assert canonical==code_pins()
        packet=dict(version="narrative-scoped-source-study-execution/2",parent_workflow="narrative-local-execution/3",
            original_canonical_native_run=False,canonical_native_run=False,execution_performed=True,case=case,plan=plan,result=result,
            native_checksum=digest(result),query_sha256=digest(case["query"]),source_context_ref=context_ref,
            source_view_sha256=digest(corpus.binding),retrieval_ref=ret_ref,canonical_code_pins=canonical,variant_code_pins=code,
            plan_ref=pin(first/position/"normal-plan.json"),readings_ref=pin(first/position/"normal-readings.json"),
            engine_manifest_ref=pin(BASE/"v02/variant-manifest.json"),source_snapshot_ref=pin(BASE/"snapshot-manifest-v02.json"),
            configuration=dict(retrieval_documents=40,retrieval_pages=80,construction_pages=20,drafts_per_reading=24,top_k=5,
                selection_profile=None,discovery_profile=None),api_calls=0,gold=None,source_citations_replayed=replayed,
            elapsed_seconds=time.perf_counter()-start)
        execution_ref=write(out/position/"execution.json.gz",packet)
        completion_ref=write(out/position/"execution-completion.json",dict(version="scoped-study-execution-completion/2",
            execution_ref=execution_ref,execution_digest=digest(packet),native_checksum=digest(result),
            original_canonical_native_completion=False,execution_performed=True,gold=None))
        summary=dict(position=position,execution_ref=execution_ref,completion_ref=completion_ref,
            inspected_origin="page_d884726ce3791d6d8092" in result["inspected_page_ids"],
            readings=[dict(reading_id=r["reading"]["id"],candidates=[dict(rank=c["rank"],fill=c["fill"],status=c["local_decision"]["status"],
                source_variants=len(c["surface_duplicate_group"]["source_variants"])) for c in r["candidates"]]) for r in result["readings"]])
        rows.append(summary);print(summary,flush=True)
    after=Budget(ROOT/"experiments/narrative_demo/api").total()
    assert after==before
    write(out/"study-complete.json",dict(version="isolated-s2-two-query-study/2",cases=rows,source_context_ref=context_ref,
        variant_manifest_ref=pin(BASE/"v02/variant-manifest.json"),budget_before_usd=before,budget_after_usd=after,new_spend_usd=0,
        api_calls=0,exact_cached_plans_and_readings_reused=True,both_queries_executed=True,gold=None,rss_peak_mb=memory_mb()))


if __name__=="__main__":main()
