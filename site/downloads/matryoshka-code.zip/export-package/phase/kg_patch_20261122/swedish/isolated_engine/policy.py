"""Explicit trusted S2 admission; ordinary SourcePolicy remains the default."""
from weakref import WeakSet

from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy
from matryoshka_current.arm_controls import _checked_page
from ..scoped_context import SourceScope

_VERIFIED = WeakSet()


def register_verified_corpus(corpus):
    if corpus.binding.get("version") != "full-later-source-view/1" or corpus.binding.get("verified_source_bytes") is not True:
        raise ValueError("Unverified alternate source corpus")
    _VERIFIED.add(corpus)


class StudyPolicy(SourcePolicy):
    VERSION = "isolated-explicit-s2-source-admission/1"

    def __init__(self, corpus, case):
        if corpus not in _VERIFIED:
            raise ValueError("Only the verified full source loader can issue a study policy")
        self.scope = SourceScope.swedish_s2(case)
        if self.scope != corpus.scope:
            raise ValueError("Source scope differs from verified view")
        self.view_sha256 = digest(corpus.binding)
        super().__init__(corpus,case,corpus.source_index)

    def allowed(self, pi):
        return self.scope.admits(self.corpus.pages[int(pi)])

    def citation(self, pi, start, end):
        page = self.corpus.pages[int(pi)]
        bound = self.bound_pages.get(page["id"])
        if bound is None or any(bound.get(k) != page.get(k) for k in ("release","quarantined","source_page")):
            raise ValueError("Citation source view binding changed")
        return dict(super().citation(pi,start,end),release=page["release"],source_page=page["source_page"])


def validate_policy(policy, case, corpus=None, source_index=None):
    if type(policy) is not StudyPolicy or policy.corpus not in _VERIFIED:
        raise ValueError("Unrecognized or unauthorized scoped policy")
    policy.scope.check_case(case)
    if policy.case != case or policy.view_sha256 != digest(policy.corpus.binding):
        raise ValueError("Policy belongs to another exact query or source view")
    if corpus is not None and policy.corpus is not corpus:
        raise ValueError("Policy/corpus identity differs")
    if source_index is not None and source_index is not policy.corpus.source_index:
        raise ValueError("Policy requires this view's complete explicit source mapping")
    return policy


def checked_page(page, case=None, *, source_policy=None):
    if source_policy is None:
        return _checked_page(page,case)
    validate_policy(source_policy,case)
    pi = source_policy.corpus.page_index.get(page["id"])
    if pi is None or source_policy.bound_pages.get(page["id"]) != page or not source_policy.allowed(pi):
        raise ValueError("Page fails the explicitly bound study policy")
    # The unchanged generic page checker retains exact text/hash/permission checks.
    return _checked_page(page)
