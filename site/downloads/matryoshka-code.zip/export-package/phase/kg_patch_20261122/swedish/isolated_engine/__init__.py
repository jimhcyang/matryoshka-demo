"""Isolated narrative source-policy study; never a production engine replacement."""
