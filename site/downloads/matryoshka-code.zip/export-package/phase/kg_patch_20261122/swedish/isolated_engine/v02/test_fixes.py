from copy import deepcopy
from phase.kg_patch_20261122.swedish.isolated_engine.v02.fixes import supplemental_page, unique_surface_shortlist


def test_strong_second_page_same_document_beats_another_document_background():
    baseline=[dict(page_id="first",document_id="same")]
    remaining=[dict(page_id="second",document_id="same",literal_selection_score=[10,16]),
        dict(page_id="other",document_id="different",literal_selection_score=[0,3])]
    assert supplemental_page(remaining)["page_id"]=="second"
    assert len(baseline)+1==2


def test_normalized_surface_grouping_before_cap_keeps_source_decisions_separate():
    def candidate(i,fill):return dict(id=str(i),fill=fill,source_span=[0,2],source_wording=fill,
        sources=[dict(canonical_page_id="p"+str(i))],local_decision=dict(status="exploratory_contextual",id=str(i)))
    values=[candidate(i,"same" if i<5 else "unique"+str(i)) for i in range(9)]
    before=deepcopy(values)
    selected=unique_surface_shortlist(values,5)
    assert [c["fill"] for c in selected]==["same","unique5","unique6","unique7","unique8"]
    group=selected[0]["surface_duplicate_group"]
    assert len(group["source_variants"])==5 and len(group["citation_union"])==5
    assert group["citation_union_is_support_proof"] is False
    assert selected[0]["local_decision"]==before[0]["local_decision"]
    assert selected[0]["sources"]==before[0]["sources"]


def test_case_whitespace_not_lemma_or_alias_merging():
    def c(i,s):return dict(id=i,fill=s,source_span=[0,1],source_wording=s,sources=[],local_decision={})
    result=unique_surface_shortlist([c("1"," A  B "),c("2","a b"),c("3","AB")],5)
    assert len(result)==2
