"""Declared-coordinate, fail-closed scoped source adapter version three."""
