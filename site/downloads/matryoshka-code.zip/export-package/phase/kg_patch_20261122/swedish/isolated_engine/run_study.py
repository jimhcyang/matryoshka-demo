"""Two actual query-only scoped-engine executions, never an old lexical adapter."""
from copy import deepcopy
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import time
import traceback

from matryoshka_demo.io import digest
from matryoshka_next.workflow import put_immutable, read
from matryoshka_narrative.workflow import code_pins
from .context import HERE, ROOT, WORKSPACE, load_context, file_sha, memory_mb
from .guards import require_headroom
from .api import Budget


def pin(path):
    return dict(path=Path(path).relative_to(ROOT).as_posix(),sha256=file_sha(path))


def write(path,value):
    require_headroom(path)
    put_immutable(path,value)
    return pin(path)


def cite_replay(value,policy,counts=None):
    counts=counts if counts is not None else [0]
    if isinstance(value,dict):
        if {"canonical_page_id","document_id","date","start","end","text","page_sha256"} <= value.keys():
            pi=policy.corpus.page_index.get(value["canonical_page_id"])
            if pi is None:raise ValueError("Executed result cites outside the source view")
            clean=policy.citation(pi,value["start"],value["end"])
            if any(clean.get(k)!=value[k] for k in clean if k in value):raise ValueError("Executed result citation changed")
            counts[0]+=1
        for child in value.values():cite_replay(child,policy,counts)
    elif isinstance(value,list):
        for child in value:cite_replay(child,policy,counts)
    return counts[0]


def main():
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("--attempt",default="attempt01")
    parser.add_argument("--context-only",action="store_true")
    args=parser.parse_args()
    if not args.attempt.isalnum():raise ValueError("Literal new attempt name required")
    from dotenv import load_dotenv
    load_dotenv(WORKSPACE/".env");load_dotenv(WORKSPACE/"src-redaction/.env")
    ledger=ROOT/"experiments/narrative_demo/api"
    before=Budget(ledger).total()
    os.environ["NARRATIVE_INCREMENTAL_BASELINE_USD"]=str(before)
    os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"]="2"
    output=HERE/args.attempt
    if output.exists():raise ValueError("Use a new attempt namespace")
    output.mkdir()
    started=datetime.now(timezone.utc).isoformat()
    snapshot=pin(HERE/"snapshot-manifest-v02.json")
    isolated_pins={p.name:file_sha(p) for p in sorted(HERE.glob("*.py"))}
    canonical=code_pins()
    marker=HERE/"execution-started.json"
    if not marker.exists():write(marker,dict(started_utc=started,snapshot=snapshot,source_code_pins=isolated_pins))
    authorization=dict(version="s2-scoped-study-attempt/1",started_utc=started,snapshot=snapshot,
        budget_before_usd=before,incremental_ceiling_usd=2,cumulative_ceiling_usd=50,ledger_root=ledger.relative_to(ROOT).as_posix(),
        configuration=dict(retrieval_documents=40,retrieval_pages=80,construction_pages=20,drafts_per_reading=24,
            top_k=5,method="current_hierarchy",selection_profile=None,discovery_profile=None),
        canonical_code_pins=canonical,isolated_code_pins=isolated_pins,no_publication=True)
    write(output/"authorization.json",authorization)
    cases=read(ROOT/"experiments/full_resume_20261120/swedish/artifacts_v02/public_catalog.json")["cases"]
    fields={"case_id","corpus","task","query","document_id","date","focal_marker"}
    if len(cases)!=2 or any(set(c)!=fields for c in cases):raise ValueError("Exactly two seven-field public packets required")
    write(output/"public-inputs.json",dict(cases=cases,query_only=True,gold=None))
    try:
        corpus=load_context(cases[0])
        write(output/"context-binding.json",dict(binding=corpus.binding,view_sha256=digest(corpus.binding),rss_peak_mb=memory_mb()))
        # These are the actual downstream seams, checked before any paid planning.
        from . import next_construction, local_gate, retrieval, narrative_construction, planning
        from .policy import checked_page
        for case in cases:
            policy=corpus.policy_for(case)
            pi=next(i for i,p in enumerate(corpus.pages) if p["document_id"]==case["document_id"])
            checked_page(corpus.pages[pi],case,source_policy=policy)
            pool=dict(eligible=corpus.eligible(case),pages=[pi],passage_budget=20)
            next_construction._pages(case,pool,corpus.source_index,source_policy=policy)
        if args.context_only:
            write(output/"context-only.json",dict(context_ready=True,api_calls=0,budget_after_usd=Budget(ledger).total()))
            return
        summaries=[]
        for position,case in zip(("first","second"),cases):
            require_headroom(output)
            folder=output/position
            started_case=time.perf_counter()
            print(dict(stage="normal_query_planning",position=position),flush=True)
            base=planning.parse(case,ledger,model="gpt-6.1-sol")
            plan_ref=write(folder/"normal-plan.json",base)
            selected,reading_audit=planning.model_readings(case,ledger,model="gpt-6.1-sol")
            readings_ref=write(folder/"normal-readings.json",dict(packet=selected,audit=reading_audit))
            plan=deepcopy(base["native_plan"]);plan["readings_packet"]=selected
            policy=corpus.policy_for(case)
            print(dict(stage="shared_kernel_retrieval",position=position),flush=True)
            found=retrieval.retrieve(corpus,case,plan,source_index=corpus.source_index,source_policy=policy,
                method="current_hierarchy",document_budget=40,passage_budget=80)
            retrieval_ref=write(folder/"retrieval.json.gz",found["receipt"])
            print(dict(stage="actual_narrative_constructor",position=position),flush=True)
            result=narrative_construction.construct(case,plan,found,source_index=corpus.source_index,
                source_policy=policy,passage_budget=20,draft_budget=24,top_k=5)
            replayed=cite_replay(result,policy)
            if result.get("query_sha256")!=digest(case["query"]) or result.get("provided_plan_sha256")!=digest(plan):
                raise ValueError("Result lost its exact public query or executed plan")
            if code_pins()!=canonical or {p.name:file_sha(p) for p in sorted(HERE.glob("*.py"))}!=isolated_pins:
                raise ValueError("Engine source changed during this scoped execution")
            packet=dict(version="narrative-scoped-source-study-execution/1",parent_workflow="narrative-local-execution/3",
                unchanged_original_native_packet=False,canonical_native_run=False,execution_performed=True,
                source_policy_delta="EXPLICIT_S2_LATER_PRIOR_PLUS_EXACT_ORIGIN_DATE",case=case,plan=plan,
                result=result,native_checksum=digest(result),query_sha256=digest(case["query"]),
                source_view_sha256=digest(corpus.binding),source_context_ref=pin(output/"context-binding.json"),
                plan_ref=plan_ref,readings_ref=readings_ref,retrieval_ref=retrieval_ref,
                configuration=authorization["configuration"],code_snapshot=snapshot,code_pins=isolated_pins,
                query_only=True,answers_read=False,grades_read=False,gold=None,source_citations_replayed=replayed,
                elapsed_seconds=time.perf_counter()-started_case)
            result_ref=write(folder/"execution.json.gz",packet)
            completion_ref=write(folder/"execution-completion.json",dict(version="scoped-study-execution-completion/1",
                execution_ref=result_ref,execution_digest=digest(packet),native_checksum=digest(result),
                original_canonical_native_completion=False,execution_performed=True,source_view_sha256=digest(corpus.binding),
                code_snapshot=snapshot,query_sha256=digest(case["query"]),gold=None))
            public=dict(version="scoped-study-public-result/1",case=case,position=position,gold=None,
                execution_ref=result_ref,completion_ref=completion_ref,source_view_sha256=digest(corpus.binding),
                execution_kind="ACTUAL_ISOLATED_NARRATIVE_ENGINE_WITH_EXPLICIT_S2_POLICY",
                original_canonical_native_run=False,atoms=base["native_plan"]["atoms"],readings=selected,
                result=result,configuration=authorization["configuration"],source_citations_replayed=replayed)
            public_ref=write(folder/"public-result.json.gz",public)
            summaries.append(dict(case_id=case["case_id"],position=position,execution_ref=result_ref,
                completion_ref=completion_ref,public_projection_ref=public_ref,
                readings=[dict(reading_id=r["reading"]["id"],candidates=[dict(rank=i,fill=c["fill"],status=c.get("local_decision",{}).get("status"))
                    for i,c in enumerate(r["candidates"],1)]) for r in result.get("readings",[])]))
            print(dict(stage="execution_sealed",position=position,summary=summaries[-1],budget_total=Budget(ledger).total()),flush=True)
        after=Budget(ledger).total()
        if after-before>2+1e-9:raise ValueError("Incremental budget exceeded")
        write(output/"study-complete.json",dict(version="isolated-s2-two-query-study/1",cases=summaries,
            source_view_sha256=digest(corpus.binding),code_snapshot=snapshot,budget_before_usd=before,
            budget_after_usd=after,new_spend_usd=after-before,gold=None,canonical_native_run=False,
            both_queries_executed=True,api_ledger_unchanged_authorization=True,rss_peak_mb=memory_mb()))
    except BaseException as error:
        write(output/"failed-attempt.json",dict(version="s2-scoped-attempt-failure/1",error_type=type(error).__name__,
            error=str(error),traceback=traceback.format_exc(),budget_before_usd=before,budget_after_usd=Budget(ledger).total(),
            partial_outputs_preserved=True,no_native_success_claimed=True))
        raise


if __name__=="__main__":main()
