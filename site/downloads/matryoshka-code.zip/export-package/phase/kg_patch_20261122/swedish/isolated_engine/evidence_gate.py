"""New deterministic task decisions over exactly saved inspected source pages.

The 6.5.2 reporting helper is an immutable parent. This adapter neither runs
retrieval nor modifies its native checkpoints, graph routes, grades or source.
Scope projections are local grammatical certificates, never dictionary aliases.
"""
from copy import deepcopy
from collections import Counter, OrderedDict
from datetime import date, datetime
import re
from threading import RLock
from types import FunctionType, SimpleNamespace

from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import scope_matching as scoped
from . import local_gate as parent
from . import slot_grammar


VERSION = "local-evidence-sufficiency/6.5.5-fixed-pool"
ENGINE_VERSION = "fixed-inspected-pool-task-decisions/3"
PARENT_VERSION = parent.VERSION
MASK = scoped.native.MASK
PURPOSE_PARENTS = {"hope", "intend", "plan", "schedule", "aim", "prepare", "elect"}
_SOURCE_FRAMES = OrderedDict()
_FRAME_LOCK = RLock()


def _tokens(frame, doc):
    return [t for t in doc if t.idx == frame["predicate_proof"]["start"]]


def _adjectival_only(frame, doc):
    tokens = _tokens(frame, doc)
    if frame["roles"] or len(tokens) != 1:
        return False
    token = tokens[0]
    return (token.dep_ == "amod" and token.tag_ in {"VBN", "VBG"}
            and token.head.pos_ in {"NOUN", "PROPN"}
            and not any(c.dep_ in {"nsubj", "nsubjpass", "dobj", "obj", "ccomp", "xcomp", "agent", "prep", "aux", "auxpass"}
                        for c in token.children))


def _paragraph(text, start):
    left = text.rfind("\n\n", 0, start)
    left = 0 if left < 0 else left + 2
    right = text.find("\n\n", start)
    return left, len(text) if right < 0 else right


def _phrase_signature(value):
    return (value["head"], sorted(value["terms"]), sorted(value["names"]), value["quantifiers"], value["role_qualifiers"],
            [(m["relation"], _phrase_signature(m["phrase"])) for m in value.get("modifiers", [])])


def _scope_signature(value):
    if isinstance(value, dict):
        return {k: _scope_signature(v) for k, v in value.items() if k not in {"start", "end", "negation_proofs"}}
    if isinstance(value, list):
        return [_scope_signature(v) for v in value]
    return " ".join(value.casefold().split()) if isinstance(value, str) else value


def _constraint_signature(frame):
    # Proof offsets can differ; every argument and semantic scope still must
    # agree. In particular, negation inside an adjective/goal is not erased.
    return (frame["predicate"], [(r, [_phrase_signature(p) for p in ps]) for r, ps in sorted(frame["roles"].items())],
            _scope_signature(frame["qualifiers"]),
            [(d.get("value"), d["text"].casefold()) for d in frame["event_dates"]],
            [d["text"].casefold() for d in frame.get("deictic_time", [])])


class Engine(scoped.Engine):
    def __init__(self, pages):
        super().__init__()
        self.pages = {p["text"]: p for p in pages.values()}
        self.normalizations = []

    def source_view(self, text):
        view, first, edits = super().source_view(text)
        omitted = {i for m in re.finditer(r"(?<=[A-Za-z]-)[ \t]+(?=[A-Za-z])", view) for i in range(*m.span())}
        if not omitted:
            return view, first, edits
        indices = [i for i in range(len(view)) if i not in omitted]
        offsets = [first[i] if first is not None else i for i in indices]
        return "".join(view[i] for i in indices), offsets, [*edits, dict(kind="LITERAL_HYPHEN_HORIZONTAL_LAYOUT",
            source_modified=False, hyphen_retained=True, deleted_characters="WHITESPACE_ONLY")]

    def frames(self, text, *, antecedents=False):
        key = (ENGINE_VERSION, text, antecedents)
        if key in self.cache:
            return deepcopy(self.cache[key])
        source_cache = text in self.pages
        if source_cache:
            with _FRAME_LOCK:
                cached = _SOURCE_FRAMES.get(key)
                if cached is not None:
                    _SOURCE_FRAMES.move_to_end(key)
                    self.cache[key] = deepcopy(cached[0])
                    self.normalizations.extend(deepcopy(cached[1]))
                    return deepcopy(cached[0])
        normalization_start = len(self.normalizations)
        analysis = MASK.sub(lambda m: " " * len(m.group()), text)
        blocks = list(re.finditer(r"\S[\s\S]*?(?=\n[ \t]*\n|\Z)", analysis))
        if source_cache and len(blocks) > 1:
            frames = []
            for i, block in enumerate(blocks):
                local = super().frames(block.group(), antecedents=antecedents)
                restored = scoped.native.old._Engine.restore_offsets(local, analysis, list(range(block.start(), block.end())))
                if i and scoped.native._reporting_block(blocks[i - 1].group(), self.parse):
                    for frame in restored:
                        frame["qualifiers"]["unresolved"].append("PRIOR_PARAGRAPH_REPORTING_SCOPE_NOT_BOUND")
                frames.extend(restored)
        else:
            frames = super().frames(analysis, antecedents=antecedents)
        doc = self.parse(analysis)
        retained = []
        for frame in frames:
            if _adjectival_only(frame, doc):
                self.normalizations.append(dict(kind="ADJECTIVAL_PARTICIPLE_NOT_INDEPENDENT_ASSERTION",
                    predicate=frame["predicate"], start=frame["predicate_proof"]["start"], source_text_sha256=digest(text)))
                continue
            frame["end"] = frame["start"] + len(analysis[frame["start"]:frame["end"]].rstrip())
            frame["quote"] = text[frame["start"]:frame["end"]]
            frame["fixed_pool_raw_text"] = text
            tokens = _tokens(frame, doc)
            if (frame["kind"] == "EVENT" and len(tokens) == 1 and tokens[0].tag_ == "VBN"
                    and tokens[0].dep_ == "acl" and tokens[0].head.pos_ in {"NOUN", "PROPN"}
                    and not frame["roles"].get("patient")):
                token = tokens[0]
                agents = [o for c in token.children if c.dep_ in {"agent", "prep"} and c.lower_ == "by"
                          for o in c.children if o.dep_ == "pobj"]
                opaque_owner = any(c.lemma_.casefold() in {"allege", "alleged", "possible", "purport", "purported", "suspect", "suspected", "imaginary", "fake"} for c in token.head.children)
                if len(agents) == 1 and not opaque_owner:
                    frame["roles"].update(agent=[scoped.matching.phrase(agents[0])], patient=[scoped.matching.phrase(token.head)])
                    frame["roles"].pop("prep:by", None)
                    frame.update(passive=True, reduced_relative_patient_recheck=True)
            retained.append(frame)

        by_start = {f["predicate_proof"]["start"]: f for f in retained}
        remove, additions = set(), []
        for token in doc:
            if token.lemma_.casefold() not in {"seem", "appear"} or token.idx not in by_start:
                continue
            adjectives = [c for c in token.children if c.pos_ == "ADJ" and c.dep_ in {"oprd", "acomp", "xcomp"}]
            if len(adjectives) != 1:
                continue
            adjective = adjectives[0]
            goals = [c for c in [*adjective.children, *token.children] if c.pos_ == "VERB"
                     and c.dep_ in {"xcomp", "advcl"} and any(a.lower_ == "to" for a in c.children)]
            if len(goals) != 1 or goals[0].idx not in by_start:
                continue
            goal = goals[0]
            outer, inner = by_start[token.idx], by_start[goal.idx]
            if not outer["roles"].get("agent"):
                continue
            value = deepcopy(outer)
            value.update(kind="PROPERTY", predicate=adjective.lemma_.casefold(),
                predicate_proof=scoped.matching.proof(adjective), predicate_phrase=scoped.matching.phrase(adjective),
                copula=None, roles=dict(owner=deepcopy(outer["roles"]["agent"]), goal_object=deepcopy(inner["roles"].get("patient", []))))
            value["qualifiers"]["modality"] = [*value["qualifiers"]["modality"], token.lemma_.casefold()]
            constraints = {k: deepcopy(inner.get(k, [])) for k in ("predicate", "roles", "qualifiers", "event_dates", "deictic_time")}
            constraints["roles"].pop("patient", None)  # Checked by the projected goal_object, including certified anaphora.
            value["fixed_pool_attitude"] = dict(governor=token.lemma_.casefold(), governor_tag=token.tag_,
                adjective=adjective.lemma_.casefold(), goal=goal.lemma_.casefold(), actual_goal_event_established=False,
                adjective_modifiers=[(c.dep_, c.lemma_.casefold()) for c in adjective.children if c.dep_ in {"neg", "advmod"}],
                goal_constraints=constraints,
                temporal_surfaces=[m.group().casefold() for m in re.finditer(r"\bat\s+(?:this|that)\s+time\b", value["quote"], re.I)])
            remove.update({token.idx, goal.idx})
            additions.append(value)

        # Nonfactive infinitival complements remain constraints on the asserted
        # parent, never separate certificates that the intended event occurred.
        for token in doc:
            if token.lemma_.casefold() not in PURPOSE_PARENTS or token.idx not in by_start:
                continue
            goals = [c for c in token.subtree if c.pos_ == "VERB" and c.idx != token.idx
                     and c.dep_ in {"xcomp", "advcl", "acl"} and any(a.lower_ == "to" for a in c.children)
                     and c.idx in by_start]
            if not goals:
                continue
            value = deepcopy(by_start[token.idx])
            value["fixed_pool_purpose_constraints"] = [dict(predicate=by_start[g.idx]["predicate"],
                roles=deepcopy(by_start[g.idx]["roles"]), qualifiers=deepcopy(by_start[g.idx]["qualifiers"]),
                event_dates=deepcopy(by_start[g.idx]["event_dates"]),
                deictic_time=deepcopy(by_start[g.idx].get("deictic_time", []))) for g in goals]
            remove.add(token.idx)
            remove.update(g.idx for g in goals)
            additions.append(value)
        result = [f for f in retained if f["predicate_proof"]["start"] not in remove] + additions
        self.cache[key] = deepcopy(result)
        if source_cache:
            with _FRAME_LOCK:
                _SOURCE_FRAMES[key] = (deepcopy(result), deepcopy(self.normalizations[normalization_start:]))
                while len(_SOURCE_FRAMES) > 128:  # RAM bound, never a source/decision budget.
                    _SOURCE_FRAMES.popitem(last=False)
        return result

    def targets(self, text):
        # Own requirements, not the old leaf-only target filter. Qualifiers and
        # descriptive participles stay in their argument proofs.
        result = []
        frames = super().targets(text)
        for frame in frames:
            if frame.get("v3_binding") or frame.get("v61_embedded_constraint") or frame.get("v61_replaced_existential_nominal"):
                continue
            if frame["kind"] == "EVENT" and not frame["roles"]:
                continue
            if frame["kind"] == "NOMINAL_RELATION" and any(
                    other["kind"] != "NOMINAL_RELATION" and any(
                        p["start"] == frame["predicate_proof"]["start"]
                        for values in other["roles"].values() for phrase in values for p in phrase["proofs"])
                    for other in frames if other is not frame):
                continue  # Ownership remains in the complete argument proof.
            actors = frame["roles"].get("agent", [])
            if len(actors) > 1:
                for i, actor in enumerate(actors):
                    value = deepcopy(frame)
                    value["roles"]["agent"] = [deepcopy(actor)]
                    value["fixed_pool_conjunction"] = dict(index=i, count=len(actors), all_required=True)
                    result.append(value)
            else:
                result.append(frame)
        return result


def _same_paragraph_heading(source):
    raw = source.get("fixed_pool_raw_text", "")
    a, b = _paragraph(raw, source["predicate_proof"]["start"])
    match = re.match(r"\s*\*?([A-Z][A-Za-z -]{1,60}):", raw[a:b])
    if match is None:
        return None
    return dict(start=a + match.start(1), end=a + match.end(1), text=match.group(1), colon=a + match.end() - 1)


def _local_scope(target_phrase, source_phrase, heading, engine):
    value = deepcopy(source_phrase)
    certificates = []
    for wanted in target_phrase.get("modifiers", []):
        if any(m["relation"] == wanted["relation"] and scoped.native.old._phrase_match(wanted["phrase"], m["phrase"])
               for m in value.get("modifiers", [])):
            continue
        words = lambda s: " ".join(s.casefold().split())
        if (heading and wanted["relation"] in {"of", "in", "at"}
                and words(wanted["phrase"]["text"]) == words(heading["text"])
                and not value.get("modifiers")):
            chunks = list(engine.parse(heading["text"]).noun_chunks)
            if len(chunks) != 1:
                continue
            phrase = scoped.matching.phrase(chunks[0].root)
            for proof in phrase["proofs"]:
                proof["start"] += heading["start"]
                proof["end"] += heading["start"]
            value["modifiers"].append(dict(relation=wanted["relation"], phrase=phrase,
                relation_proof=dict(start=heading["colon"], end=heading["colon"] + 1, text=":", lemma=":", pos="PUNCT", dependency="section_scope"),
                derived_relation="SAME_PARAGRAPH_COLON_SCOPE_NOT_LITERAL_PREPOSITION"))
            certificates.append(dict(kind="EXACT_LITERAL_PARAGRAPH_HEADING_SCOPE", **heading))
    return value, certificates


def _resolve_same_object(target, source, engine):
    """Only a unique explicit same-head NP antecedent; no topic inference."""
    projected = deepcopy(source)
    notes = []
    raw = source.get("fixed_pool_raw_text", "")
    for role, wanted_values in target["roles"].items():
        offered_values = projected["roles"].get(role, [])
        if len(wanted_values) != 1 or len(offered_values) != 1:
            continue
        wanted, offered = wanted_values[0], offered_values[0]
        if not any(p["lemma"] == "same" for p in wanted["proofs"]) or wanted["head"] != offered["head"]:
            continue
        current = min(p["start"] for p in offered["proofs"])
        heads = [t for t in engine.parse(MASK.sub(lambda m: " " * len(m.group()), raw))
                 if t.lemma_.casefold() == offered["head"] and any(p["start"] == t.idx for p in offered["proofs"])]
        if len(heads) != 1 or not any(c.lower_ in {"the", "same", "such", "this", "that"} for c in heads[0].children):
            continue
        a, _ = _paragraph(raw, current)
        prefix = raw[a:current]
        # This intentionally refuses a bare topic (e.g. "neutralization") as
        # proof that "such a proposal" is one particular proposal token.
        descriptors = [p["text"] for p in wanted["proofs"] if p["lemma"] not in {"same", wanted["head"]}]
        if not descriptors:
            continue
        phrase = " ".join([*descriptors, wanted["head"]])
        hits = list(re.finditer(r"\b" + re.escape(phrase) + r"\b", prefix, re.I))
        competing = [chunk for chunk in engine.parse(prefix).noun_chunks if chunk.root.lemma_.casefold() == wanted["head"]]
        if len(hits) != 1 or len(competing) != 1 or MASK.search(prefix):
            continue
        old_same = [p for p in offered["proofs"] if p["lemma"] in {"same", "such"}]
        offered["proofs"] = [p for p in offered["proofs"] if p not in old_same]
        for p in wanted["proofs"]:
            if p["lemma"] in {wanted["head"], "same"}:
                continue
            hit = re.search(r"\b" + re.escape(p["text"]) + r"\b", hits[0].group(), re.I)
            if hit:
                offered["proofs"].append(dict(p, start=a + hits[0].start() + hit.start(), end=a + hits[0].start() + hit.end(), text=hit.group()))
        offered["terms"] = [x for x in offered["terms"] if x not in {"same", "such"}] + [p["lemma"] for p in wanted["proofs"] if p["lemma"] not in {"same", wanted["head"]}]
        offered["descriptive_terms"] = [x for x in offered.get("descriptive_terms", []) if x not in {"same", "such"}]
        # Keep anaphoric identity as an explicit derived constraint; never a
        # fabricated word or changed quotation from the original document.
        notes.append(dict(kind="UNIQUE_LITERAL_SAME_HEAD_ANTECEDENT", start=a + hits[0].start(), end=a + hits[0].end(), text=hits[0].group(), role=role))
    return projected, notes


def _literal_name_projection(wanted, offered, records):
    proper = [p for p in wanted["proofs"] if p["pos"] == "PROPN"]
    old = offered["proofs"]
    if (len(proper) >= 2 and any(p["pos"] == "PROPN" for p in old)
            and [p["text"].casefold() for p in wanted["proofs"]] == [p["text"].casefold() for p in old]
            and [(p["lemma"], p["pos"]) for p in wanted["proofs"]] != [(p["lemma"], p["pos"]) for p in old]):
        records.append(dict(kind="EXACT_MULTIWORD_NAME_CASE_ANALYSIS", start=min(p["start"] for p in old),
            end=max(p["end"] for p in old), original_analysis=deepcopy(old)))
        for target, source in zip(wanted["proofs"], old):
            source.update(lemma=target["lemma"], pos=target["pos"])
        for key in ("head", "terms", "names", "descriptive_terms"):
            offered[key] = deepcopy(wanted[key])
    for t in wanted.get("modifiers", []):
        matches = [s for s in offered.get("modifiers", []) if s["relation"] == t["relation"]]
        if len(matches) == 1:
            _literal_name_projection(t["phrase"], matches[0]["phrase"], records)


def _scoped_content(frame, engine):
    view, _, _ = scoped._layout(engine, frame["quote"])
    return Counter(t.lemma_.casefold() if t.pos_ == "VERB" else t.text.casefold()
        for t in engine.parse(view) if not t.is_space and not t.is_punct and t.pos_ not in {"DET", "AUX"})


def _qualified_actor_scope(target, match):
    original = parent._actor_scope(target, match)
    if original[0] or not target.get("v655_named_holder_certificate"):
        return original
    return True, "A literal named belief/report holder owns the complete matched qualified proposition; its hypothetical inner actor is not certified as an actual-world participant."


_qualified_comparison = FunctionType(parent._match.__code__, dict(vars(parent), _actor_scope=_qualified_actor_scope),
                                    parent._match.__name__, parent._match.__defaults__)


def _guard_partial_scope(value, target, source, comparison):
    if value["direction"] != "Partial":
        return value
    d = comparison["diagnostics"]
    unbound = d["attribution"]["status"] not in parent.GOOD
    negative_scope = any(q.get("negated") for frame in (target, source) for q in frame["qualifiers"]["scope"])
    if unbound and (d["polarity"]["status"] == "OPPOSED" or negative_scope):
        value.update(direction="Context", surrounding_event_established=False,
            scoped_partial_guard="UNBOUND_ATTRIBUTION_WITH_OPPOSED_OR_NEGATED_SCOPE",
            derivation_note="Shared participants or topic do not ground the required signed relation when its reporting scope is unbound. This witness is context only, not counterevidence or partial positive support.")
        for item in value["checks"]:
            if item["id"] == "integral_evidence":
                item.update(state="missing", detail="Opposed inner polarity or an unmatched negated reporting scope prevents integral positive grounding of this required relation.")
    return value


def _partial_antecedent(target, source, engine):
    wanted, offered = target["roles"]["goal_object"][0], source["roles"]["goal_object"][0]
    if not any(p["lemma"] == "same" for p in wanted["proofs"]):
        return True, []
    raw = source.get("fixed_pool_raw_text", "")
    current = min(p["start"] for p in offered["proofs"])
    a, _ = _paragraph(raw, current)
    if MASK.search(raw[a:current]):
        return False, []
    analysis = MASK.sub(lambda m: " " * len(m.group()), raw)
    heads = [t for t in engine.parse(analysis) if t.lemma_.casefold() == offered["head"]
             and any(p["start"] == t.idx for p in offered["proofs"])]
    if len(heads) != 1 or not any(c.lower_ in {"such", "same", "the", "this", "that"} for c in heads[0].children):
        return False, []
    descriptors = {p["lemma"] for p in wanted["proofs"]} - {"same", wanted["head"]}
    if not descriptors:
        return False, []
    chunks = [c for c in engine.parse(raw[a:current]).noun_chunks if c.root.lemma_.casefold() == wanted["head"]]
    if len(chunks) > 1:
        return False, []
    candidates = []
    if chunks:
        chunk = chunks[0]
        if descriptors <= {t.lemma_.casefold() for t in chunk}:
            candidates.append((a + chunk.start_char, a + chunk.end_char))
    else:
        for frame in engine.frames(raw, antecedents=True):
            if not a <= frame["predicate_proof"]["start"] < source["predicate_proof"]["start"]:
                continue
            for phrase in frame["roles"].get("patient", []):
                if descriptors <= {p["lemma"] for p in phrase["proofs"]}:
                    candidates.append((min(p["start"] for p in phrase["proofs"]), max(p["end"] for p in phrase["proofs"])))
    if not candidates or len({raw[x:y].casefold() for x, y in candidates}) != 1:
        return False, []
    x, y = candidates[0]
    return True, [dict(kind="PARTIAL_LITERAL_TOPIC_NOT_FULL_REFERENT_IDENTITY", start=x, end=y, text=raw[x:y])]


def _attitude_integral_partial(target, source, comparison, engine):
    t, s = target.get("fixed_pool_attitude"), source.get("fixed_pool_attitude")
    if not t or not s or any(t[k] != s[k] for k in ("governor", "adjective", "goal", "adjective_modifiers")):
        return False
    def goal_signature(attitude):
        value = deepcopy(attitude["goal_constraints"])
        value["qualifiers"]["scope"] = [q for q in value["qualifiers"]["scope"]
            if q["predicate"] not in {attitude["governor"], attitude["adjective"]} or q.get("negated") or q.get("modality")]
        return _constraint_signature(value)
    if goal_signature(t) != goal_signature(s):
        return False
    d = comparison["diagnostics"]
    if (d["polarity"]["status"] != "MATCH" or d["modality"]["status"] != "MATCH"
            or d["attribution"]["status"] not in parent.GOOD
            or any(d[k]["status"] in {"MISMATCH", "OPPOSED"} for k in ("quantity", "event_date"))):
        return False
    def subset(wanted, offered):
        deixis = {"same", "such", "this", "that"}
        return (wanted["head"] == offered["head"] and not offered["unresolved"]
            and set(offered["terms"]) - deixis <= set(wanted["terms"]) - deixis
            and set(offered["names"]) <= set(wanted["names"])
            and wanted["quantifiers"] == offered["quantifiers"]
            and set(wanted["role_qualifiers"]) - deixis == set(offered["role_qualifiers"]) - deixis
            and all(any(x["relation"] == y["relation"] and subset(x["phrase"], y["phrase"])
                        for x in wanted.get("modifiers", [])) for y in offered.get("modifiers", [])))
    bounded = all(len(target["roles"].get(role, [])) == len(source["roles"].get(role, [])) == 1
        and subset(target["roles"][role][0], source["roles"][role][0]) for role in ("owner", "goal_object"))
    if not bounded:
        return False
    referent, proof = _partial_antecedent(target, source, engine)
    if referent:
        comparison.setdefault("fixed_pool_scope_proofs", []).extend(proof)
    return referent


def _reduced_relative_integral_partial(target, source):
    if not source.get("reduced_relative_patient_recheck") or target["predicate"] != source["predicate"]:
        return False
    for frame in (target, source):
        q = frame["qualifiers"]
        if any(q.get(k) for k in ("negated", "modality", "conditional", "question", "epistemic_absence", "unresolved")):
            return False
        if any(s.get("negated") or s.get("modality") or s["predicate"] in {"deny", "allege", "doubt"} for s in q["scope"]):
            return False
    for role in ("agent", "patient"):
        t, s = target["roles"].get(role, []), source["roles"].get(role, [])
        if len(t) != 1 or len(s) != 1 or _phrase_signature(t[0]) != _phrase_signature(s[0]):
            return False
    if not any(p["pos"] == "NUM" for p in target["roles"]["patient"][0]["proofs"]):
        return False
    td, sd = target["event_dates"], source["event_dates"]
    if len(td) != 1 or len(sd) != 1:
        return False
    def calendar(value):
        if value.get("value"):
            try:
                day = date.fromisoformat(value["value"])
            except ValueError:
                return None
            return day.month, day.day
        for fmt in ("%d %B", "%d %b", "%B %d", "%b %d"):
            try:
                day = datetime.strptime(value["text"], fmt)
                return day.month, day.day
            except ValueError:
                pass
        return None
    if (calendar(td[0]) is None or calendar(td[0]) != calendar(sd[0])
            or td[0].get("value") and sd[0].get("value") and td[0]["value"] != sd[0]["value"]):
        return False
    t, s = target.get("fixed_pool_purpose_constraints", []), source.get("fixed_pool_purpose_constraints", [])
    if len(t) != len(s) or not t:
        return False
    def names(frame):
        def all_proofs(p):
            yield from p["proofs"]
            for m in p.get("modifiers", []):
                yield from all_proofs(m["phrase"])
        return {p["text"].casefold() for ps in frame["roles"].values() for value in ps for p in all_proofs(value)
                if p["pos"] == "PROPN" and p["lemma"] != value["head"]}
    def terms(frame):
        def words(p):
            yield from (x["lemma"] for x in p["proofs"] if x["pos"] in {"NOUN", "PROPN", "ADJ", "NUM"})
            for m in p.get("modifiers", []):
                yield from words(m["phrase"])
        return {x for ps in frame["roles"].values() for p in ps for x in words(p)}
    return all(a["predicate"] == b["predicate"] and len(names(a)) >= 2 and names(a) == names(b)
               and terms(a) <= terms(b)
               and not any(f["qualifiers"].get(k) for f in (a, b) for k in ("negated", "modality", "conditional", "question", "epistemic_absence", "unresolved")) for a, b in zip(t, s))


def compare_frames(target, source, *, engine):
    projected, refs = _resolve_same_object(target, source, engine)
    wanted = deepcopy(target)
    if refs:
        for values in wanted["roles"].values():
            for phrase in values:
                phrase["proofs"] = [p for p in phrase["proofs"] if p["lemma"] != "same"]
                phrase["terms"] = [x for x in phrase["terms"] if x != "same"]
                phrase["descriptive_terms"] = [x for x in phrase.get("descriptive_terms", []) if x != "same"]
    heading = _same_paragraph_heading(source)
    for role, phrases in wanted["roles"].items():
        offered = projected["roles"].get(role, [])
        candidates = [i for i, phrase in enumerate(offered) if len(phrases) == 1 and phrases[0]["head"] == phrase["head"]]
        if len(candidates) == 1:
            i = candidates[0]
            _literal_name_projection(phrases[0], offered[i], refs)
            offered[i], records = _local_scope(phrases[0], offered[i], heading, engine)
            refs.extend(records)
    match = scoped.compare_frames(wanted, projected, engine=engine)
    if match is None:
        return None
    if target.get("fixed_pool_attitude") or source.get("fixed_pool_attitude"):
        t, s = target.get("fixed_pool_attitude"), source.get("fixed_pool_attitude")
        if (not t or not s or any(t[k] != s[k] for k in ("governor", "adjective", "goal", "adjective_modifiers"))
                or _constraint_signature(t["goal_constraints"]) != _constraint_signature(s["goal_constraints"])):
            match["direction"] = "RELATED"
            match["reasons"].append("NONFACTIVE_ATTITUDE_AND_GOAL_NOT_SAME")
        elif t["governor_tag"] != s["governor_tag"] or t["temporal_surfaces"] != s["temporal_surfaces"]:
            match["direction"] = "PARTIAL" if match["direction"] == "SUPPORT" else "RELATED"
            match["diagnostics"]["event_date"]["status"] = "UNRESOLVED"
            match["reasons"].append("ATTITUDE_TENSE_OR_DEICTIC_TIME_NOT_BOUND")
    for key in ("fixed_pool_purpose_constraints",):
        t, s = target.get(key, []), source.get(key, [])
        if t or s:
            if [_constraint_signature(f) for f in t] != [_constraint_signature(f) for f in s]:
                match["direction"] = "RELATED"
                match["reasons"].append("NONFACTIVE_PURPOSE_CONSTRAINT_NOT_BOUND")
    # A descriptive participle remains required wording in its own argument,
    # even though it is no longer an independent informing event.
    for row in match["bindings"].get("argument_matches", []):
        if row.get("source") is None:
            continue
        required = {p["lemma"] for p in row["target"]["proofs"] if p["dependency"] == "amod" and p["pos"] == "VERB"}
        available = {p["lemma"] for p in row["source"]["proofs"] if p["dependency"] == "amod" and p["pos"] == "VERB"}
        if not required <= available and match["direction"] == "SUPPORT":
            match["direction"] = "PARTIAL"
            match["diagnostics"]["actor"]["status"] = "PARTIAL"
            match["reasons"].append("DESCRIPTIVE_PARTICIPLE_NOT_ATTESTED_FOR_THIS_ARGUMENT")
    match["fixed_pool_scope_proofs"] = refs
    def named(phrase):
        return bool(phrase.get("names")) or any(named(m["phrase"]) for m in phrase.get("modifiers", []))
    named_holders = [p for q in wanted["qualifiers"]["scope"] if q["predicate"] in {"believe", "think", "expect", "hope"}
                     for p in q.get("speakers", []) if named(p)]
    match["v655_named_holder_certificate"] = bool(named_holders and match["direction"] == "SUPPORT"
        and all(match["diagnostics"].get("modality" if k == "uncertainty" else k, {}).get("status") in parent.GOOD for k in parent.FIELDS)
        and _scoped_content(wanted, engine) == _scoped_content(projected, engine))
    return match


def _fact(target, admitted, engine, matcher, number, *, property_recheck=False):
    matches = []
    for page in admitted.values():
        for source in engine.frames(page["text"], antecedents=True):
            if MASK.search(source["quote"]):
                continue
            if (source["predicate"] != target["predicate"] and not
                    (target["predicate"] == "say" and source["predicate"] in scoped.native._ASSERTIVE_REPORTS)):
                continue  # Only scoped exact predicates can pass the integral gate.
            comparison = compare_frames(target, source, engine=engine)
            if comparison is None:
                continue
            once = SimpleNamespace(compare_frames=lambda *args, **kwargs: comparison, native=scoped.native)
            checked = dict(target, v655_named_holder_certificate=comparison.get("v655_named_holder_certificate", False))
            value = _qualified_comparison(checked, source, page, engine, once)
            if comparison.get("v655_named_holder_certificate"):
                value.update(surrounding_event_established=False,
                    derivation_note="The named holder's qualified belief/proposition is source-backed, not occurrence of its hypothetical inner event.",
                    qualified_proposition_certificate=True)
            if value["direction"] == "Context" and _attitude_integral_partial(target, source, comparison, engine):
                value.update(direction="Partial", surrounding_event_established=False,
                    derivation_note="Integral attitude, owner class and goal-object class are source-backed; country, referent and time bindings remain unresolved. No full identity or action completion is inferred.")
                for check in value["checks"]:
                    if check["id"] == "integral_evidence":
                        check.update(state="pass", detail="The same scoped attitude and explicit owner/object classes are retained in one witness; missing descriptors are not treated as matched.")
                    if check["id"] == "event_date" and (target["fixed_pool_attitude"]["governor_tag"] != source["fixed_pool_attitude"]["governor_tag"]
                            or target["fixed_pool_attitude"]["temporal_surfaces"] or source["fixed_pool_attitude"]["temporal_surfaces"]):
                        check.update(state="missing", detail="Original tense and deictic time are retained; their event-date reference is not resolved by this partial relationship.")
            if value["direction"] == "Context" and _reduced_relative_integral_partial(target, source):
                value.update(direction="Partial", surrounding_event_established=False,
                    derivation_note="The raw reduced relative binds the same agent, numbered patient, calendar day/month and named attendance purpose. Year context, attribution and complete purpose alignment are not certified or silently inferred.")
                for check in value["checks"]:
                    if check["id"] == "integral_evidence":
                        check.update(state="pass", detail="One witness grounds the counted passive event and its named purpose; unresolved year/scope checks remain missing.")
            value = _guard_partial_scope(value, target, source, comparison)
            for proof in comparison.get("fixed_pool_scope_proofs", []):
                value["citations"].append(parent._citation(page, proof["start"], proof["end"]))
            value.update(adapter=ENGINE_VERSION, supplemental_source_evidence=True, numerical_transport_claim=False)
            if target.get("fixed_pool_attitude"):
                value.update(surrounding_event_established=False,
                    derivation_note="The source describes the scoped appearance/inclination, not completion of its infinitival action.")
            matches.append(value)
    support = [m for m in matches if m["direction"] == "Support"]
    counter = [m for m in matches if m["direction"] == "Counterevidence"]
    partial = [m for m in matches if m["direction"] == "Partial"]
    context = [m for m in matches if m["direction"] == "Context"]
    focused = [m for m in context if any(c["id"] == "predicate" and c["state"] == "pass" for c in m["checks"])]
    selected = next(iter(support or counter or partial or focused or context), None)
    def actor_text(phrase):
        def proofs(value):
            yield from value["proofs"]
            for modifier in value.get("modifiers", []):
                if modifier.get("relation_proof"):
                    yield modifier["relation_proof"]
                yield from proofs(modifier["phrase"])
        spans = list(proofs(phrase))
        raw = target.get("fixed_pool_raw_text", "")
        return raw[min(p["start"] for p in spans):max(p["end"] for p in spans)] if raw and spans else phrase["text"]
    actors = [actor_text(p) for p in target["roles"].get("agent", target["roles"].get("owner", []))]
    return dict(id=f"f{number}", kind=target["kind"], predicate=target["predicate"], text=target["quote"], actors=actors,
        coverage="Established" if support else "Partial" if partial else "Missing", counterevidence=bool(counter),
        direction="Support + Counterevidence" if support and counter else "Support" if support else "Counterevidence" if counter else "Partial" if partial else "Unresolved",
        checks=selected["checks"] if selected else [parent._check(k, parent.FIELD_LABELS[k], "missing", "No matching witness in the saved inspected pool.") for k in parent.FIELDS],
        evidence=support + counter + partial, context_citations=[c for m in focused[:3] for c in m["citations"]],
        context_comparisons=focused[:3], aggregation="Each requirement is compared to the complete saved pool before any display limit. No fields are spliced across witnesses.")


_context = dict(vars(parent), _fact=_fact)
_decision = FunctionType(parent._decision.__code__, _context, parent._decision.__name__, parent._decision.__defaults__)
_decision.__kwdefaults__ = deepcopy(parent._decision.__kwdefaults__)


def _property_targets(case, fill, reading, engine, matcher):
    targets, reason = parent._focal_targets(case, fill, reading, engine, matcher)
    strict = (reading.get("form") == "modifier" and reading.get("role") == "nominal_property"
              and reading.get("target_kind") == "property")
    if strict and targets:
        if any(t["kind"] != "PROPERTY" for t in targets):
            return [], "Strict property reading lacks a certified focal property; the surrounding event cannot substitute."
        for target in targets:
            target["v65_strict_focal_property"] = True
    return targets, reason


def _property_owner_scope(target, match):
    original = parent._actor_scope(target, match)
    certificate = match.get("derived_disposition", {})
    rows = [r for r in match["bindings"].get("argument_matches", []) if r["role"] == "owner"]
    if (not target.get("v65_strict_focal_property") or target["kind"] != "PROPERTY"
            or target.get("copula") is not None or match["direction"] != "SUPPORT"
            or certificate.get("kind") != "CAN_EASILY_PASSIVE_DISPOSITION"
            or match["diagnostics"]["actor"]["status"] != "MATCH" or len(rows) != 1):
        return original
    row = rows[0]
    wanted, offered = row["target"], row.get("source")
    discriminator = any(p["pos"] in {"ADJ", "PROPN", "NUM"} and p["lemma"] != wanted["head"]
                        for p in wanted["proofs"]) or bool(wanted.get("modifiers"))
    if (row["status"] != "EXACT_SCOPED_ARGUMENT" or not offered or not discriminator
            or wanted["unresolved"] or offered["unresolved"] or _phrase_signature(wanted) != _phrase_signature(offered)):
        return original
    return True, "Exact owner and visible literal discriminators bind this focal ease/ability property; the existing can-easily passive certificate does not establish an action or a shared event actor."


_property_comparison = FunctionType(parent._match.__code__, dict(vars(parent), _actor_scope=_property_owner_scope),
                                  parent._match.__name__, parent._match.__defaults__)


def _red_match(target, source, page, engine, matcher):
    match = matcher.compare_frames(target, source, engine=engine)
    if match is None:
        return None
    once = SimpleNamespace(compare_frames=lambda *args, **kwargs: match, native=matcher.native)
    value = _property_comparison(target, source, page, engine, once)
    value = _guard_partial_scope(value, target, source, match)
    if value["direction"] == "Support" and match.get("derived_disposition") and target.get("v65_strict_focal_property"):
        value["focal_property_certificate"] = dict(kind="EXISTING_CAN_EASILY_PASSIVE_WITH_EXACT_OWNER",
            raw_source_rechecked=True, source_modal=match["derived_disposition"]["source_modal"],
            owner_bindings=deepcopy(match["bindings"]["argument_matches"]),
            surrounding_event_established=False, source_sha256=page["source_sha256"])
    return value


_red_fact = FunctionType(parent._fact.__code__, dict(vars(parent), _match=_red_match), parent._fact.__name__, parent._fact.__defaults__)
_red_fact.__kwdefaults__ = deepcopy(parent._fact.__kwdefaults__)
_red_decision = FunctionType(parent._decision.__code__, dict(vars(parent), _fact=_red_fact), parent._decision.__name__, parent._decision.__defaults__)
_red_decision.__kwdefaults__ = deepcopy(parent._decision.__kwdefaults__)
_red_derive = FunctionType(parent.derive.__code__, dict(vars(parent), _decision=_red_decision, _focal_targets=_property_targets),
                         parent.derive.__name__, parent.derive.__defaults__)


def derive(record, case, eligible_index, source_policy=None):
    case = parent._case(case)
    if case["task"] == "redaction" or "inspected_page_ids" not in record:
        packet = (_red_derive if case["task"] == "redaction" else parent.derive)(record, case, eligible_index,source_policy=source_policy)
        if case["task"] == "redaction":
            packet = slot_grammar.apply(packet, record, case, parent._pages(eligible_index, case), scoped.Engine(), parent,source_policy=source_policy)
        packet.update(version=VERSION, decision_engine=ENGINE_VERSION,
            pool_replay=dict(applied=False, reason="Redaction uses its source-rechecked focal property/action gate, not a pool replay" if case["task"] == "redaction" else "Saved inspected-page pool not recorded; no pool invented"))
        return _task_labels(packet, case["task"])
    if record.get("case") is not None and parent._case(record["case"]) != case:
        raise ValueError("Fixed-pool record belongs to another case")
    if record["plan"].get("query_sha256") != digest(case["query"]):
        raise ValueError("Fixed-pool query binding changed")
    with offline():
        index = parent._pages(eligible_index, case)
        pages, masks, veto = index
        ids = record["inspected_page_ids"]
        budget = record["result"].get("passage_budget")
        if (not isinstance(ids, list) or any(not isinstance(pid, str) for pid in ids)
                or len(set(ids)) != len(ids) or type(budget) is not int or len(ids) > budget
                or record["result"].get("source_pages_inspected") != len(ids)):
            raise ValueError("Saved inspected-pool count/budget is not exact")
        refs, admitted = [], {}
        for pid in ids:
            page = pages.get(pid)
            if page is None:
                raise ValueError("Saved inspected page is absent from its bound source index")
            ref = parent._citation(page, 0, len(page["text"]))
            parent._quote(ref, pages, masks, veto, case,source_policy=source_policy)
            refs.append(ref)
            admitted[pid] = page
        engine = Engine(admitted)
        matcher = SimpleNamespace(compare_frames=compare_frames, native=scoped.native)
        units, covered = [], set()
        for item in record["plan"].get("atoms", []):
            atom = {k: item[k] for k in ("id", "text", "source_quote", "start", "end", "required")}
            a, b = atom["start"], atom["end"]
            if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(case["query"]) or case["query"][a:b] != atom["source_quote"]:
                targets, issues = [], ["Public query atom offsets do not replay"]
            else:
                targets, issues = scoped._bind(atom, case["query"], engine)
            for target in targets:
                covered.add((target["kind"], target["predicate"], target.get("query_context", {}).get("start", a) + target["predicate_proof"]["start"]))
            units.append(_decision(atom["id"], atom["text"], atom["required"] is not False,
                targets, issues, refs, case, index, engine, matcher))
        if len(set(u["id"] for u in units)) != len(units):
            raise ValueError("Duplicate fixed-pool requirement identity")
        raw = engine.targets(case["query"])
        omitted = [(t["kind"], t["predicate"], t["predicate_proof"]["start"]) for t in raw
                   if (t["kind"], t["predicate"], t["predicate_proof"]["start"]) not in covered]
        required = [u for u in units if u["required"]]
        complete = bool(required) and not omitted and all(u["status"] == parent.BACKED for u in required)
        status = parent.BACKED if complete else parent.PARTIAL if any(u["coverage"] in {"Established", "Partial"} for u in required) else parent.CONTEXT
        if any(u["status"] == parent.INCOMPATIBLE and u["counterevidence"] for u in required):
            status = parent.INCOMPATIBLE
        overall = dict(status=status, label=parent.LABELS[status],
            coverage="Established" if required and not omitted and all(u["coverage"] == "Established" for u in required) else "Partial" if any(u["coverage"] in {"Established", "Partial"} for u in required) else "Missing",
            counterevidence=any(u["counterevidence"] for u in required),
            established_components=[u["id"] for u in required if u["coverage"] == "Established"],
            missing_components=[u["id"] for u in required if u["coverage"] != "Established"],
            checklist=[parent._check("required_units", "All required components", "pass" if complete else "missing", "Every conjunct and scoped requirement needs a complete witness."),
                       parent._check("query_coverage", "Whole-query typed requirements", "missing" if omitted or not raw else "pass", "No roleless descriptive adjective is an independent action; nonfactive goals remain constraints.")],
            what_would_suffice=["Resolve each missing actor, object, referent, date and uncertainty constraint with an eligible source from this exact saved pool. No new retrieval or graph walk is implied."])
        packet = dict(version=VERSION, decision_engine=ENGINE_VERSION, parent_version=PARENT_VERSION,
            field=parent.FIELD, case_id=case["case_id"], query_sha256=digest(case["query"]), config=record.get("config"),
            derived=True, frozen_native_unchanged=True, keys_read=False, grades_read=False, model_calls=0,
            decisions=units, atoms={u["id"]: u for u in units}, candidates={}, reading_overviews={}, overall=overall,
            binding=dict(case_id=case["case_id"], query_sha256=digest(case["query"]), config=record.get("config"), native_run_id=record.get("run_id"), native_checksum=record.get("native_checksum")),
            source_scope="Exactly the recorded inspected-page pool, independently source-checked; no fresh retrieval and no use of the larger admitted pool.",
            pool_replay=dict(applied=True, inspected_pages=len(ids), passage_budget=budget, larger_admitted_count=record["result"].get("source_pages_admitted"),
                page_ids=deepcopy(ids), page_ids_sha256=digest(ids), source_hashes={pid: admitted[pid]["source_sha256"] for pid in ids}, new_retrieval=False, numerical_transport_claim=False,
                allocation="ALL_SAVED_POOL_MATCHES_PER_REQUIREMENT_BEFORE_DISPLAY_LIMITS"),
            normalizations=engine.normalizations,
            limitations=["New deterministic task decision, not frozen V6.1 inference or a new model grade.",
                "No dictionaries, demonym aliases, arbitrary country co-occurrence, inferred calendar dates or unresolved proposal identities certify support.",
                "Supplemental quotations are source evidence, not retroactively saved native graph endpoints or numerical walks."])
        return _task_labels(packet, case["task"])


def _task_labels(packet, task):
    for unit in packet["decisions"]:
        unit["task"] = task
        unit["support_present"] = any(e["direction"] == "Support" for f in unit["requirements"] for e in f["evidence"])
        unit["mixed_evidence"] = any(f["counterevidence"] and any(e["direction"] == "Support" for e in f["evidence"]) for f in unit["requirements"])
        unit["decisive_counter"] = any(f["counterevidence"] and not any(e["direction"] == "Support" for e in f["evidence"]) for f in unit["requirements"])
        if unit["counterevidence"] and task == "hypothesis":
            unit["label"] = "Opposed by eligible evidence" if unit["decisive_counter"] else "Mixed eligible evidence"
            if unit["decisive_counter"]:
                unit["status"] = parent.INCOMPATIBLE
        elif unit["counterevidence"] and task == "reconstruction":
            unit["label"] = "Conflicting component"
    overall = packet["overall"]
    overall.update(task=task, support_present=any(u["support_present"] for u in packet["decisions"]), is_overall=True)
    mixed = any(u["mixed_evidence"] for u in packet["decisions"] if u["required"])
    decisive = any(u["decisive_counter"] for u in packet["decisions"] if u["required"])
    overall.update(mixed_evidence=mixed, decisive_counter=decisive)
    if overall["counterevidence"] and task == "hypothesis":
        if decisive:
            overall["status"] = parent.INCOMPATIBLE
        overall.update(label="Opposed by eligible evidence" if decisive else "Mixed eligible evidence",
            decision_resolved=decisive, conclusion="Scoped counterevidence resolves a required hypothesis claim; this is an informative decision, not an algorithm failure." if decisive else "Support and counterevidence conflict within a required claim; do not hide either direction.")
    elif overall["counterevidence"] and task == "reconstruction":
        overall.update(label="Conflicting reconstruction component", conclusion="Counterevidence is a separate component warning, never a replacement for Established / Partial / Missing coverage.")
    return packet


def evaluate(root, report, record):
    from matryoshka_demo.corpus_explorer_v3 import _connection
    case = parent._case(record["case"])
    rows = [r for r in report["cases"] if r["case"]["case_id"] == case["case_id"]]
    if len(rows) != 1 or parent._case(rows[0]["case"]) != case:
        raise ValueError("Fixed-pool case is not the published public query")
    reference = report["graph_indexes"][case["corpus"]]
    if record.get("exploration_index_ref") != reference or record.get("source_binding_sha256") != report["source_binding"]["sha256"]:
        raise ValueError("Fixed-pool source index binding changed")
    with offline():
        db = _connection(root, reference)
        try:
            packet = derive(record, case, db)
        finally:
            db.close()
    packet["binding"].update(source_index_sha256=reference["sha256"], source_binding_sha256=report["source_binding"]["sha256"])
    return packet
