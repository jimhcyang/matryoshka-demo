from copy import deepcopy
from matryoshka_demo.io import digest


def supplemental_page(remaining):
    """Input is already focal-score ordered; document repetition is not a veto."""
    return remaining[0]


def unique_surface_shortlist(ordered, top_k):
    groups={}
    for original_rank,candidate in enumerate(ordered,1):
        key=" ".join(candidate["fill"].split()).casefold()
        groups.setdefault(key,[]).append((original_rank,candidate))
    selected=[]
    for key,variants in groups.items():
        representative=variants[0][1]
        union={digest(ref):deepcopy(ref) for _,c in variants for ref in c["sources"]}
        representative["surface_duplicate_group"]=dict(normalized_surface=key,
            original_order_positions=[rank for rank,_ in variants],source_variants=[dict(id=c["id"],fill=c["fill"],
                source_span=deepcopy(c["source_span"]),source_wording=c["source_wording"],sources=deepcopy(c["sources"]),
                local_decision=deepcopy(c["local_decision"])) for _,c in variants],citation_union=list(union.values()),
            representative_decision_unchanged=True,citation_union_is_support_proof=False,identity_merged=False)
        if len(selected)<top_k:selected.append(representative)
    return selected
