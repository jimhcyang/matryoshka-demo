"""Bounded fresh Red suggestions with unchanged source/slot/factual gates.

This version can display attested context without a positive action clue. It
does not relabel that context as support or relax a failed insertion gate.
"""
from collections import Counter, defaultdict
from copy import deepcopy
import json
import re
import time

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from .. import next_construction as shared
from .fixes import supplemental_page, unique_surface_shortlist
from matryoshka_next import readings as reader
from matryoshka_next.facts import public_plan
from matryoshka_narrative import redaction_selection as selection
from matryoshka_narrative import redaction_counters as counters
from matryoshka_narrative import candidate_salience as salience
from matryoshka_narrative import role_context as role_matcher
from matryoshka_narrative import proper_nominal_compounds as compounds
from matryoshka_narrative import source_nominals
from matryoshka_narrative import context_relevance
from matryoshka_narrative import context_priority
from matryoshka_narrative import nominal_realization
from matryoshka_narrative import visible_query_labels, visible_apposition_context, visible_apposition_order
from matryoshka_narrative import role_kind_context


VERSION = "narrative-bounded-red-construction/27+s2-policy-1+page-surface-2"
ROLE_CONTEXT_ORDER_VERSION = "native-role-kind-visible-attachment-order/1"
ADAPTER_VERSION = "next-reading-to-narrative-construction/2"
FINAL_FORM_VERSION = "narrative-completed-outer-form/2"
SELECTION_VERSION = "narrative-source-family-and-cue-budget-selection/6"
TYPE_VERSION = "narrative-literal-completed-head-kind/3"
DEFAULT_PASSAGES = 20
DEFAULT_DRAFTS = 48


def _typed_constructor(reading, converted):
    if (converted is None or reading.get("outer_family") != "adjectival"
            or reading.get("function") != "modifier" or reading.get("role") != "nominal_property"
            or converted.get("form") != "modifier" or converted.get("role") != "nominal_property"
            or converted.get("target_kind") != "any"):
        return converted, None
    effective = dict(converted, target_kind="property")
    return effective, dict(version=ADAPTER_VERSION, reading_id=reading["id"],
        rule="DECLARED_ATTRIBUTIVE_ADJECTIVAL_PROPERTY", original_target_kind="any",
        effective_target_kind="property", declared_reading_sha256=digest(reading),
        original_constructor_sha256=digest(converted), effective_constructor_sha256=digest(effective),
        declared_model_reading_modified=False, new_reading_created=False,
        factual_support_certified=False, source_or_answer_input_used=False)


def _support_label(decision):
    labels = {"evidence_backed_suggestion":"SOURCE_SUPPORTED",
        "partial_grounding":"PARTIALLY_SOURCE_GROUNDED",
        "exploratory_contextual":"SOURCE_WORDING_CONTEXT_ONLY"}
    if decision.get("status") not in labels:
        raise ValueError("Only adjudicated viable candidates receive final support labels")
    return labels[decision["status"]]


def _reviewed_role_kind_context(case, candidate, page, types, parser, entities):
    observations = []
    for entity in entities:
        if entity.get("type") != "person":
            continue
        visible = visible_query_labels.observe(case["query"], entity, parser)
        observations.append(role_kind_context.evaluate(case, candidate["declared_reading"],
            entity, visible, candidate, candidate["final_form_fit"], page, parser, types))
    possible = {digest(o):o for o in observations if o["state"] == "possible"}
    if len(possible) == 1:
        return next(iter(possible.values()))
    return dict(version=role_kind_context.VERSION, state="hold",
        reason="NO_UNAMBIGUOUS_REVIEWED_ROLE_KIND_CONTEXT", lexical_reference_only=True,
        factual_support_certified=False, source_type_match_added=False)


def _lexical_kind_decision_hold(candidate, decision, *, trusted_admission=None):
    compatible = candidate.get("context_slot_compatibility", {})
    if trusted_admission is None and (compatible.get("state") != "possible" or not compatible.get("lexical_reference_only")):
        return False
    try:
        selection.require_context_decision(candidate, decision)
    except selection.ContextTypeSupportError:
        return True
    return False


def _context_kind_compatibility(case, candidate, page, types, parser, entities, mode):
    form = candidate["final_form_fit"]
    compatible = selection.context_head(candidate, form, page, types, parser)
    if compatible["state"] != "possible" and mode in {"same_page_reference", "visible_role_context"}:
        compatible = selection.literal_reference_kind(candidate, form, page, types, parser)
    if compatible["state"] != "possible" and mode == "visible_role_context":
        compatible = _reviewed_role_kind_context(case, candidate, page, types, parser, entities)
    return compatible


def _replay_lexical_admission(case, candidate, parser, plan, admitted, own_types, *, trusted_admission=None):
    """A stale admission is withheld, not retained with a weaker soft key."""
    try:
        if not isinstance(trusted_admission, bytes):
            return False
        admission = json.loads(trusted_admission)
        saved = candidate["context_slot_compatibility"]
        if (candidate.get("lexical_context_admission") != admission
                or saved != admission["context_observation"]
                or candidate["completed_head_kind_fit"] != admission["original_completed_head_kind"]
                or saved.get("state") != "possible" or saved.get("lexical_reference_only") is not True):
            return False
        if _lexical_kind_decision_hold(candidate, candidate["local_decision"], trusted_admission=trusted_admission):
            return False
        page_id = candidate["context_rank_key"][16]
        form = final_form_fit(case, candidate["declared_reading"], candidate["fill"], parser)
        if form.get("state") != "pass" or form != candidate["final_form_fit"]:
            return False
        kind = completed_head_kind(candidate, form, parser, source_page=admitted[page_id],
            source_types=own_types[page_id])
        if kind != candidate["completed_head_kind_fit"]:
            return False
        fresh = _context_kind_compatibility(case, candidate, admitted[page_id], own_types[page_id],
            parser, plan.get("extractions", {}).get("entities", []), "visible_role_context")
        return fresh.get("state") == "possible" and fresh == saved
    except (KeyError, IndexError, TypeError, ValueError):
        return False


def _visible_attachment_priority(case, candidate, parser, plan, admitted, own_types):
    result = dict(version=ROLE_CONTEXT_ORDER_VERSION, matched=False, producer_replayed=False,
        native_exploratory_only=True, factual_support_certified=False, identity_certified=False)
    saved = candidate.get("context_slot_compatibility", {})
    if (candidate["local_decision"].get("status") != "exploratory_contextual"
            or saved.get("version") != role_kind_context.VERSION
            or saved.get("state") != "possible" or _lexical_kind_decision_hold(candidate, candidate["local_decision"])):
        return result
    if plan is None or admitted is None or own_types is None:
        return result
    try:
        page_id = candidate["context_rank_key"][16]
        fresh = _reviewed_role_kind_context(case, candidate, admitted[page_id], own_types[page_id],
            parser, plan.get("extractions", {}).get("entities", []))
        result.update(producer_replayed=True, matched=fresh.get("state") == "possible" and fresh == saved,
            fresh_observation_sha256=digest(fresh), saved_observation_equal=fresh == saved)
    except (KeyError, IndexError, TypeError, ValueError):
        pass
    return result


def _final_context_order(case, values, parser, mode, *, plan=None, admitted=None, own_types=None):
    """Order only already viable observations; no new support or nominations."""
    if mode == "legacy":
        return None
    if mode not in {"focal_after_source", "focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"}:
        raise ValueError("Unknown final context ordering")
    observations, caches, keys = {}, {}, {}
    for candidate in values:
        observed = context_relevance.observe(candidate, case["query"], case["focal_marker"], parser)
        caches[candidate["id"]] = context_relevance.validate_observation(candidate,
            case["query"], case["focal_marker"], parser, observed)
        keys[candidate["id"]] = context_relevance.ordering_key(candidate,
            case["query"], case["focal_marker"], observation=caches[candidate["id"]])
        observations[candidate["id"]] = observed
        if mode in {"focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"}:
            candidate["context_priority"] = context_priority.observe(candidate)
            keys[candidate["id"]] = context_priority.ordering_key(candidate, case["query"], case["focal_marker"],
                lexical_observation=caches[candidate["id"]], priority_observation=candidate["context_priority"])
            if mode in {"focal_visible_owner", "focal_visible_attachment"}:
                matched = visible_apposition_order.matches_candidate(candidate, digest(case["query"]))
                candidate["visible_owner_context_priority"] = dict(version=visible_apposition_order.VERSION,
                    matched=matched, factual_support_certified=False)
                keys[candidate["id"]] = keys[candidate["id"]][:11] + (not matched,) + keys[candidate["id"]][11:]
            if mode == "focal_visible_attachment":
                priority = _visible_attachment_priority(case, candidate, parser, plan, admitted, own_types)
                candidate["focal_visible_attachment_priority"] = priority
                keys[candidate["id"]] = (not priority["matched"],) + keys[candidate["id"]]
    utility = context_relevance.ordering_utilities(values, case["query"], case["focal_marker"],
        observations=caches)
    if mode in {"focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"}:
        full = {c["id"]:(c["context_priority"]["effective_ordering_tier"],) + keys[c["id"]] for c in values}
        distinct = sorted(set(full.values()))
        positions = {key:i for i, key in enumerate(distinct)}
        denominator = max(1, len(distinct) - 1)
        utility = dict(pool_sha256=digest(sorted(full.items())), candidates={cid:dict(
            value=(denominator-positions[key])/denominator,
            exact_numerator=denominator-positions[key], exact_denominator=denominator,
            distinct_key_rank=positions[key]+1, ordering_key=key,
            ordering_scope=("FULL_TIER_VISIBLE_ATTACHMENT_AND_ENTIRE_V26_KEY_ORDINAL_NOT_CONFIDENCE"
                if mode == "focal_visible_attachment" else "FULL_TIER_AND_ROLE_PRIORITY_ORDINAL_NOT_CONFIDENCE")) for cid, key in full.items()})
    for candidate in values:
        candidate["context_ordering"] = dict(version=(ROLE_CONTEXT_ORDER_VERSION
            if mode == "focal_visible_attachment" else context_relevance.VERSION), mode=mode,
            observation=observations[candidate["id"]], exact_key=keys[candidate["id"]],
            ordinal_context_utility=utility["candidates"][candidate["id"]],
            pool_sha256=utility["pool_sha256"], factual_tier_applied_by_caller=True,
            priority_version=context_priority.VERSION if mode in {"focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"} else None,
            correctness_probability=False, changes_support=False)
    return keys


def adapt_plan(case, plan):
    """Preserve bound interpretations; only declared constructor subsets execute."""
    case = public_case(case)
    if case["task"] != "redaction" or not plan.get("atoms"):
        raise ValueError("Red requires an explicit public atom plan")
    public_plan(case,plan)
    packet = plan.get("readings_packet")
    reader.validate_readings(packet,case)
    if len(packet["readings"]) > 8:
        raise ValueError("At most eight actual declared readings; no product fallback")
    rows = []
    for row in packet["readings"]:
        converted = reader.constructor_view(row,case) if row["constructor_form"] is not None else None
        converted, target_binding = _typed_constructor(row, converted)
        reason = shared._route_issue(case,converted) if converted else "UNSUPPORTED_FINAL_SURFACE_CONSTRUCTION"
        if reason:
            converted = None
        rows.append(dict(reading=deepcopy(row),constructor=converted,hold_reason=reason,
            grammatical_target_binding=target_binding))
    return dict(version=ADAPTER_VERSION,case_sha256=digest(case),query_sha256=digest(case["query"]),
        source_plan_sha256=digest(plan),shared_atoms_sha256=digest(plan["atoms"]),
        readings_packet_sha256=digest(packet),reader_version=reader.VERSION,readings=rows,
        original_outer_families_preserved=True,new_readings_generated=False,api_calls=0)


def _focus_text(case,plan):
    values = [a["text"] for a in plan["atoms"] if case["focal_marker"] in a["text"]]
    if not values:
        values = [a["text"] for a in plan["atoms"]
            if any(case["focal_marker"] in s.get("text","") for s in a.get("query_spans",[]))]
    return " ".join(values) if values else case["query"]


def _cue_score(text,focus):
    # Literal relevance schedules work only; it never certifies a source claim.
    tokens = [w for w in re.findall(r"[A-Za-z]+",MASK.sub(" ",focus).casefold())
        if w not in shared.ENGLISH_STOP_WORDS]
    actual = [w for w in re.findall(r"[A-Za-z]+",text.casefold()) if w not in shared.ENGLISH_STOP_WORDS]
    terms = set(tokens)
    grams = {tuple(tokens[i:i+3]) for i in range(len(tokens)-2)}
    matches = sum(tuple(actual[i:i+3]) in grams for i in range(len(actual)-2))
    return matches,len(terms & set(actual))


def _content_goals(predicate):
    """Owned complement heads only; never a different embedded subject's goal."""
    from matryoshka_narrative.nonfactive_content import _OPERATORS
    pending = [c for c in predicate.children if c.dep_ in {"xcomp", "ccomp"}]
    values = []
    while pending:
        token = pending.pop()
        if token.pos_ != "VERB" or any(c.dep_ in {"nsubj", "nsubjpass", "csubj", "neg"} for c in token.children):
            continue
        pending.extend(c for c in token.children if c.dep_=="conj"
            or token.lemma_.casefold() in _OPERATORS and c.dep_ in {"xcomp","ccomp"})
        if token.lemma_.casefold() in _OPERATORS:
            continue
        objects = sorted({c.lemma_.casefold() for c in token.children if c.dep_ in {"dobj", "obj"}
            and c.lemma_.casefold() not in shared.ENGLISH_STOP_WORDS})
        values.append(dict(lemma=token.lemma_.casefold(),objects=objects,
            passive=any(c.dep_ == "auxpass" for c in token.children),span=[token.idx,token.idx+len(token)]))
    return values


def _predicate_priority_context(case,query,parse):
    text=MASK.sub(lambda m:"thing"+" "*(len(m.group())-5) if m.group()==case["focal_marker"]
        else " "*len(m.group()),case["query"])
    doc=parse(text)
    at=case["query"].index(case["focal_marker"])
    slot=next((t for t in doc if t.idx==at and t.lower_=="thing"),None)
    predicates=[]
    if slot is not None:
        predicates=[shared._actor_predicate(slot),shared._argument_binding(slot)[0]]
    return {p.lemma_.casefold():_content_goals(p) for p in predicates if p is not None}


def _guard_operator_priority(part,feature,query_goals,own_goal):
    """Withhold operator-only ranking credit, without changing scoped relations."""
    from matryoshka_narrative.nonfactive_content import _OPERATORS
    predicates=[shared._actor_predicate(part.root),shared._argument_binding(part.root)[0]]
    audit={}
    for key,predicate in zip(("focal_actor_predicate_match","focal_argument_predicate_match"),predicates):
        if not feature.get(key) or predicate is None:
            continue
        lemma=predicate.lemma_.casefold()
        wanted=query_goals.get(lemma,[])
        if lemma not in _OPERATORS and not wanted:
            continue
        actual=_content_goals(predicate)
        matches=[dict(query=q,source=s) for q in wanted for s in actual
            if q["lemma"]==s["lemma"] and q["passive"]==s["passive"] and set(q["objects"])<=set(s["objects"])]
        own=bool(own_goal.get("matched") and any(q.get("passive") is False and q["lemma"]==own_goal.get("goal", "").casefold()
            and set(q["objects"])<=set(own_goal.get("goal_object_heads",[])) for q in wanted))
        eligible=bool(matches or own)
        audit[key]=dict(observed_match=True,operator=lemma,query_content=wanted,source_content=actual,
            meaningful_content_match=eligible,matched_content=matches,owned_goal_match=own,
            ranking_only=True,support_decisions_modified=False,absence_is_counterevidence=False)
        feature[key]=eligible
    if audit:
        feature["operator_priority_guard"]=audit


def _baseline_page_cap(limit):
    if type(limit) is not int or limit < 1:
        raise ValueError("Positive integer page cap required")
    return min(16,max(1,limit-limit//4))


def _bounded_pool(case,plan,retrieval,source_index,passage_budget,selection_profile=None,source_policy=None):
    pool = dict(retrieval)
    original_budget = retrieval.get("passage_budget")
    if type(original_budget) is not int or original_budget < 1:
        raise ValueError("Original retrieval must declare its inspection budget")
    limit = min(passage_budget,original_budget)
    pool["passage_budget"] = limit
    scan = []
    baseline_count = _baseline_page_cap(limit)
    if selection_profile is not None:
        baseline_count = max(1, limit-int(limit*selection_profile.get("page_focal_fraction", .5)))
    if "inspected_page_ids" in retrieval:
        pool["inspected_page_ids"] = list(retrieval["inspected_page_ids"][:limit])
    else:
        # Validate before reading even the cheap selection panel. No new retrieval.
        scan_cap = (selection_profile or {}).get("scan_pages", 256)
        panel = dict(retrieval,passage_budget=min(scan_cap,len(retrieval["pages"])) or 1)
        _,scanned,_,_ = shared._pages(case,panel,source_index,source_policy=source_policy)
        focus = _focus_text(case,plan)
        for rank,(pi,page) in enumerate(scanned):
            score = max((_cue_score(p,focus) for p in re.split(r"\n\s*\n",page["text"])),default=(0,0))
            scan.append(dict(page_id=page["id"],document_id=page["document_id"],admitted_rank=rank+1,
                literal_selection_score=list(score),page_sha256=page["source_sha256"]))
        chosen = list(scan[:baseline_count])
        remaining = sorted(scan[len(chosen):],key=lambda s:(-s["literal_selection_score"][0],
            -s["literal_selection_score"][1],s["admitted_rank"]))
        while remaining and len(chosen)<limit:
            best = supplemental_page(remaining)
            chosen.append(best)
            remaining.remove(best)
        pool["inspected_page_ids"] = [s["page_id"] for s in chosen]
    corpus,pages,policy,budget = shared._pages(case,pool,source_index,source_policy=source_policy)
    budget.update(constructor_passage_cap=passage_budget,original_passage_budget=original_budget,
        selection_version=SELECTION_VERSION,selection_is_source_prefix_not_answer_selection=False,
        explicit_inspected_pool_preserved="inspected_page_ids" in retrieval,
        selection_uses_public_atoms_only=True,selection_is_factual_support=False,
        selection_scan_page_count=len(scan),selection_scan=scan,source_parse_page_cap=limit)
    budget.update(baseline_page_ids=[p["id"] for _,p in pages[:baseline_count]],
        baseline_prefix_cap=baseline_count,cue_addition_cap=max(0,limit-baseline_count),
        allocation_rule="At most 16 relevance-prefix pages; reserve floor(total cap/4) focal-clue opportunities",
        total_page_cap_increased=False)
    return corpus,pages,policy,budget,pool


def _source_readouts(pages,policy):
    values = []
    for pi,page in pages[:3]:
        for match in re.finditer(r"[^\n]+(?:\n(?!\s*\n)[^\n]+)*",page["text"]):
            if match.group().strip() and not MASK.search(match.group()):
                values.append(dict(citation=policy.citation(pi,match.start(),match.end()),
                    purpose="UNINTERPRETED_SOURCE_READOUT_NOT_A_FILL_OR_SUPPORT",candidate_id=None))
                break
    return values


def final_form_fit(case, reading, fill, parse):
    """Check final surface, not the shared legacy operation or the raw source NP."""
    left,right = case["query"].split(case["focal_marker"])
    completed = left+fill+right
    doc = parse(completed)
    a,b = len(left),len(left)+len(fill)
    part = doc.char_span(a,b,alignment_mode="strict")
    value = dict(version=FINAL_FORM_VERSION,outer_family=reading["outer_family"],
        constructor_form=reading["constructor_form"],variant=reading["variant"],inserted_span=[a,b],
        completed_query_sha256=digest(completed),state="missing",reason="FINAL_SURFACE_TOKEN_BOUNDARIES_UNRESOLVED",
        reading_modified=False,pos_coercion=False,factual_support_certified=False,
        unlicensed_form_is_counterevidence=False,full_english_grammar_certified=False)
    if part is None or not fill.strip():
        return value
    head = part.root
    coordinate=salience.coordinate_head(reading,part)
    if coordinate is not None:
        head=coordinate
        value["coordinate_head_resolution"]=dict(coordinator=part[0].text,head=head.text,
            original_span_root=part.root.text,reason="EXPLICIT_IN_SPAN_CONJUNCT_OF_VISIBLE_COORDINATOR_GOVERNOR",
            source_evidence_certified=False)
    value["head"] = dict(text=head.text,lemma=head.lemma_,pos=head.pos_,tag=head.tag_,dependency=head.dep_,
        span=[head.idx,head.idx+len(head)])
    if reading["constructor_form"]=="member_example" and head.pos_=="ADP":
        arguments = [t for t in head.children if t in part and t.dep_ in {"pobj","obj"}
            and t.pos_ in {"NOUN","PROPN","PRON"}]
        if len(arguments)==1:
            token = arguments[0]
            value["entity_head"] = dict(text=token.text,lemma=token.lemma_,pos=token.pos_,
                span=[token.idx,token.idx+len(token)])
    finite = any(t.pos_ in {"VERB","AUX"} and ("Fin" in t.morph.get("VerbForm")
        or t.tag_ in {"VBD","VBP","VBZ","MD"}) for t in part)
    family = reading["outer_family"]
    if family == "nominal":
        activity=bool(salience.quoted_owner(case,reading) and head.tag_=="VBG" and not finite)
        matched = (head.pos_ in {"NOUN","PROPN","PRON"} or activity) and not finite
        reason = "FINAL_NOMINAL_HEAD" if matched else "DECLARED_NOMINAL_HEAD_NOT_ESTABLISHED"
        number=salience.number_fit(reading,part)
        value["declared_number_fit"]=number
        if number["state"]!="pass":matched,reason=False,"DECLARED_ARGUMENT_NUMBER_CONFLICT"
    elif family == "adjectival":
        matched = (head.pos_ == "ADJ" or head.pos_ == "VERB" and head.tag_ in {"VBN","VBG"}) and not finite
        reason = "FINAL_ADJECTIVAL_HEAD" if matched else "DECLARED_ADJECTIVAL_HEAD_NOT_ESTABLISHED"
    elif family == "prepositional":
        matched = head.pos_ == "ADP" and not finite
        reason = "FINAL_PREPOSITIONAL_HEAD" if matched else "DECLARED_PREPOSITIONAL_HEAD_NOT_ESTABLISHED"
    elif family == "nominal_specifier" and reading["variant"] == "numeric_quantity":
        matched = head.pos_ == "NUM" and not finite
        reason = "FINAL_NUMERIC_SPECIFIER" if matched else "DECLARED_NUMERIC_SPECIFIER_NOT_ESTABLISHED"
    else:
        matched,reason = False,"UNSUPPORTED_FINAL_SURFACE_CONSTRUCTION"
    return dict(value,state="pass" if matched else "missing",reason=reason)


def completed_head_kind(candidate,final_form,parse,*,source_page=None,source_types=None):
    """A fixed kind belongs to the completed head, never its named possessor."""
    target = candidate["ranking"]["features"]["effective_target_kind"]
    value = dict(version=TYPE_VERSION,target_kind=target,state="pass",reason="NO_ENTITY_KIND_CONSTRAINT",
        factual_support_certified=False,proper_name_dictionary_lookup=False)
    form = final_form.get("constructor_form",candidate.get("v6_reading",{}).get("form"))
    if form not in {"nominal","possessive","member_example"}:
        return dict(value,reason="NOT_AN_IDENTITY_FILL_EXISTING_CARRIER_GATES_REQUIRED",
            entity_head_kind_applicable=False,property_owner_certified=False)
    if target not in {"person","organization","place"}:
        return value
    head = final_form.get("entity_head",final_form["head"])
    raw = candidate["source_wording"]
    if source_page is None and "fill" not in candidate:
        # Retain the narrow legacy helper probe shape. Real constructor calls
        # always provide the complete insertion and source-page binding below.
        matches = list(re.finditer(r"(?<!\w)"+re.escape(head["text"])+r"(?!\w)",raw,re.I))
        interval = ([candidate["source_span"][0]+matches[0].start(),
                     candidate["source_span"][0]+matches[0].end()] if len(matches)==1 else None)
    else:
        interval = selection.literal_head_span(candidate,final_form)
    if interval is None:
        return dict(value,state="missing",reason="COMPLETED_HEAD_SOURCE_COORDINATES_AMBIGUOUS")
    a,b = interval
    proposed = (source_types if source_types is not None else
                candidate["ranking"]["features"].get("source_type_witnesses",[]))
    witnesses = []
    for w in proposed:
        if source_page is not None:
            lo,hi = w.get("start"),w.get("end")
            if (w.get("canonical_page_id") != source_page["id"]
                    or w.get("page_sha256") != source_page["source_sha256"]
                    or type(lo) is not int or type(hi) is not int or not 0 <= lo < hi <= len(source_page["text"])
                    or source_page["text"][lo:hi] != w.get("label")):
                raise ValueError("Completed-head type witness lost its exact source binding")
        if w["start"]<=a<b<=w["end"]:
            witnesses.append(w)
    kinds = {shared.TYPE_MAP[w["source_entity_type"]] for w in witnesses if w.get("source_entity_type") in shared.TYPE_MAP}
    value.update(mapped_source_head_span=[a,b],head_witnesses=deepcopy(witnesses),observed_kinds=sorted(kinds))
    if any(w.get("source_entity_type") not in set(shared.TYPE_MAP)|{"Other"} for w in witnesses):
        return dict(value,state="missing",reason="UNINTERPRETED_SOURCE_HEAD_KIND")
    if kinds:
        passed = kinds=={target}
        return dict(value,state="pass" if passed else "missing",reason="SOURCE_ENTITY_COVERS_COMPLETED_HEAD"
            if passed else "SOURCE_HEAD_KIND_CONFLICT")
    # Only common nouns get dictionary senses. A capitalized name is not a type.
    if head["pos"]=="NOUN":
        lookup = parse.noun_resource.lookup(head["lemma"])
        senses = lookup.get("senses",[])
        passed = lookup["status"]=="SENSES_AVAILABLE" and bool(senses) and all(
            s["possible_kinds"].get(target,False) for s in senses)
        return dict(value,state="pass" if passed else "missing",reason="ALL_ORDINARY_HEAD_SENSES_COMPATIBLE"
            if passed else "COMPLETED_HEAD_KIND_UNRESOLVED",head_senses=[s["synset"] for s in senses])
    return dict(value,state="missing",reason="NO_SOURCE_ENTITY_KIND_AT_COMPLETED_HEAD")


def _schedule(groups,focus):
    """Round-robin source pages; prefer local cues over crowded global context."""
    lanes = defaultdict(list)
    for group in groups:
        primary = group["primary"]
        f = primary["features"]
        local = _cue_score(primary["source_wording"],focus)
        sentence = _cue_score(primary["citation"]["text"],focus)
        family = group.get("original_reading",{}).get("outer_family")
        source_head = primary.get("source_head",{})
        shape = family!="adjectival" or source_head.get("pos")=="ADJ" or (
            source_head.get("pos")=="VERB" and source_head.get("tag") in {"VBN","VBG"})
        fixed_type = f.get("effective_target_kind") in {"person","organization","place"}
        rank = (not shape,not f["source_owned_relation_match"],fixed_type and not f.get("source_type_match",False),
            -local[0],-local[1],-sentence[0],-sentence[1],
            len(primary["source_wording"].split()),group["key"])
        group["scheduling"] = dict(version=SELECTION_VERSION,literal_span_score=list(local),
            literal_sentence_score=list(sentence),preliminary_source_form_match=shape,is_factual_support=False)
        lanes[(group["reading"]["id"],not shape,primary["citation"]["canonical_page_id"])].append((rank,group))
    by_reading = defaultdict(list)
    for (rid,shape_hold,pid),values in lanes.items():
        values.sort(key=lambda row:row[0])
        # Nested NPs sharing the same source endpoint should not consume a page's
        # entire early budget before another complete phrase is attempted.
        unique,duplicates,seen = [],[],set()
        for rank,g in values:
            raw = re.findall(r"[A-Za-z]+",g["primary"]["source_wording"].casefold())
            head = raw[-1] if raw else g["fill"]
            (duplicates if head in seen else unique).append((rank,g))
            seen.add(head)
        by_reading[(rid,shape_hold)].append(unique+duplicates)
    ordered = []
    for lane in sorted(by_reading):
        pages = sorted(by_reading[lane],key=lambda rows:rows[0][0])
        while any(pages):
            for rows in pages:
                if rows:
                    ordered.append(rows.pop(0)[1])
    return ordered


def _draft_union(groups,focus,baseline_pages,draft_budget,focal_fraction=.25,*,cue_order_mode="source_priority",
                 supplemental_mode="legacy", query_sha256=None):
    """Allocate both lanes at every useful budget; no stored rank input."""
    groups = list(groups)
    for group in groups:
        if group["primary"]["citation"]["canonical_page_id"] not in baseline_pages:
            original = [o for o in group["occurrences"] if o["citation"]["canonical_page_id"] in baseline_pages]
            if original:
                primary = min(original,key=lambda o:shared._key(o["features"],
                    {"id":o["citation"]["canonical_page_id"]},o["source_span"],group["reading"]["id"],group["fill"]))
                group.update(primary=primary,key=selection.source_rank(primary,shared._key(primary["features"],
                    {"id":primary["citation"]["canonical_page_id"]},primary["source_span"],group["reading"]["id"],group["fill"])))
    cue_order = _schedule(groups,focus)
    cue_order = sorted(enumerate(cue_order),key=lambda item:(
        item[1]["reading"]["id"],not item[1]["primary"].get("selection_cue",{}).get("named_example_priority",False),
        not item[1]["primary"].get("selection_cue",{}).get("own_person_role_context_priority",False),item[0]))
    return selection.allocate(groups,[g for _,g in cue_order],baseline_pages,draft_budget,
        focal_fraction=focal_fraction,cue_order_mode=cue_order_mode,supplemental_mode=supplemental_mode,
        query_sha256=query_sha256)


def _proper_modifier_proposals(page, rows, doc, parser):
    applicable = [row for row in rows if row["reading"].get("outer_family") == "nominal"
        and row["reading"].get("variant") == "compound_modifier"
        and row["reading"].get("function") == "modifier"
        and row["reading"].get("form") in {"nominal", "modifier"}]
    if not applicable:
        return []
    text = page["text"]
    analysis = parser(text.lower()) if text.isupper() and len(text.lower()) == len(text) else None
    return [dict(raw, only_reading=row["reading"]["id"])
        for row in applicable for raw in compounds.bind_proposals(page, row["reading"], doc, analysis)]


def construct(case, plan, retrieval, top_k=5, *, source_index=None,
              passage_budget=DEFAULT_PASSAGES, draft_budget=DEFAULT_DRAFTS,selection_profile=None,source_policy=None):
    """Fresh bounded construction, not old-pool reranking or rank transplantation."""
    if selection_profile is not None:
        if not isinstance(selection_profile,dict) or set(selection_profile)-{"page_focal_fraction","candidate_focal_fraction","scan_pages","identity_first","cue_order_mode","context_kind_mode","nominal_boundary_mode","counter_policy","context_ordering_mode","coordinate_boundary_mode","supplemental_mode"}:
            raise ValueError("Unknown selection profile field")
        if selection_profile.get("supplemental_mode", "legacy") not in {"legacy", "source_head_opportunities"}:
            raise ValueError("Unknown supplemental opportunity mode")
        for name in ("page_focal_fraction","candidate_focal_fraction"):
            if name in selection_profile and (type(selection_profile[name]) not in (int,float) or not 0 <= selection_profile[name] <= 1):
                raise ValueError("Declared focal fractions must be between zero and one")
        scan_cap=selection_profile.get("scan_pages",256)
        if type(scan_cap) is not int or not 1 <= scan_cap <= 1024:
            raise ValueError("Cheap scan requires a declared one-to-1024 page cap")
        if "identity_first" in selection_profile and type(selection_profile["identity_first"]) is not bool:
            raise ValueError("Identity-first flag must be boolean")
        if selection_profile.get("cue_order_mode", "source_priority") not in {"source_priority", "focal_sentence"}:
            raise ValueError("Unknown supplemental cue ordering")
        if selection_profile.get("context_kind_mode", "own_observation") not in {"own_observation", "same_page_reference", "visible_role_context"}:
            raise ValueError("Unknown context kind mode")
        if selection_profile.get("nominal_boundary_mode", "legacy") not in {"legacy", "literal_visible_prefix"}:
            raise ValueError("Unknown nominal boundary policy")
        if selection_profile.get("counter_policy", "complete_pool") not in {"complete_pool", "positive_support"}:
            raise ValueError("Unknown counter coverage policy")
        if selection_profile.get("context_ordering_mode", "legacy") not in {"legacy", "focal_after_source", "focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"}:
            raise ValueError("Unknown final context ordering")
        if selection_profile.get("coordinate_boundary_mode", "legacy") not in {"legacy", "visible_boundary"}:
            raise ValueError("Unknown coordinate boundary policy")
    if (type(top_k) is not int or not 1 <= top_k <= 5 or type(passage_budget) is not int
            or not 1 <= passage_budget <= (64 if selection_profile is not None else 20)
            or type(draft_budget) is not int or not 1 <= draft_budget <= (128 if selection_profile is not None else 64)):
        raise ValueError("One-to-five display, one-to-twenty pages, one-to-sixty-four checks per reading")
    case = public_case(case)
    started = time.perf_counter()
    adaptation = adapt_plan(case,plan)
    corpus,pages,policy,budget,pool = _bounded_pool(case,plan,retrieval,source_index,passage_budget,selection_profile,source_policy)
    if selection_profile is not None:
        budget["allocation_rule"]="Declared baseline/focal page fraction within fixed cap; source eligibility unchanged"
        budget["selection_profile"]=deepcopy(selection_profile)
    parser = shared.SourceParses()
    usable = [r for r in adaptation["readings"] if r["constructor"] is not None]
    admitted = {p["id"]:p for _,p in pages}
    own_types = {page["id"]:selection.page_types(corpus,pi,page) for pi,page in pages}
    counter_comparison = counters.CounterComparison(case,pages,policy,
        policy_mode=(selection_profile or {}).get("counter_policy", "complete_pool"))
    counter_records = []
    counts = Counter()
    groups, rejections, lexical_admissions = {}, [], {}
    checked, viable = defaultdict(int),defaultdict(list)
    with offline():
        features = {r["reading"]["id"]:shared._query_features(case,r["constructor"],parser) for r in usable}
        anchors=salience.visible_anchors(case,plan,parser)
        visible_people = []
        for entity in plan.get("extractions", {}).get("entities", []):
            if entity.get("type") == "person":
                observed = visible_query_labels.observe(case["query"], entity, parser)
                if observed is not None:
                    visible_people.append((entity, observed))
        role_contexts = {r["reading"]["id"]:role_matcher.query_context(case,r["constructor"],parser) for r in usable}
        predicate_contexts = {rid:_predicate_priority_context(case,q,parser) for rid,q in features.items()}
        focal_goals={}
        for token in parser(MASK.sub("thing",_focus_text(case,plan))):
            if token.pos_=="VERB":
                focal_goals.setdefault(token.lemma_.casefold(),set()).update(
                    c.lemma_.casefold() for c in token.children if c.dep_ in {"dobj","obj"})
        for pi,page in pages if usable else ():
            doc,spans = shared.proposal_spans(page["text"],parser)
            spans=list(spans)
            for raw in list(spans):
                if raw["kind"]=="nominal" and raw["text"].startswith("(") and ")" not in raw["text"]:
                    spans.append(dict(raw,start=raw["start"]+1,text=raw["text"][1:]))
            for row in usable:
                for raw in salience.activity_proposals(case,row["reading"],doc,parser):
                    spans.append(dict(raw,only_reading=row["reading"]["id"]))
            spans.extend(_proper_modifier_proposals(page, usable, doc, parser))
            if (selection_profile or {}).get("nominal_boundary_mode") == "literal_visible_prefix":
                for raw in list(spans):
                    if raw.get("source_format_rejection"):
                        continue
                    part = doc.char_span(raw["start"], raw["end"], alignment_mode="strict")
                    alternative = source_nominals.visible_prefix_nominal(page, raw, part, case)
                    if alternative is not None:
                        spans.append(alternative)
            seen = set()
            for raw in spans:
                key = raw["start"],raw["end"],raw["kind"],raw.get("only_reading")
                if key in seen:
                    continue
                seen.add(key)
                counts["source_constituents_enumerated"] += 1
                if raw.get("source_format_rejection"):
                    counts["source_format_rejections"] += 1
                    continue
                a,b = raw["start"],raw["end"]
                if page["text"][a:b] != raw["text"]:
                    raise ValueError("Raw source span changed")
                part = doc.char_span(a,b,alignment_mode="strict")
                if (part is None or not part.root.sent.start_char <= a < b <= part.root.sent.end_char
                        or re.search(r"\n[ \t]*\n",part.text)
                        or MASK.search(page["text"][part.root.sent.start_char:part.root.sent.end_char])):
                    counts["source_unit_boundary_or_opacity_holds"] += 1
                    continue
                if part[0].lower_=="both" and not any(t.dep_=="conj" and t.head in part for t in part):
                    counts["incomplete_paired_nominal_holds"]+=1
                    continue
                ref = policy.citation(pi,part.root.sent.start_char,part.root.sent.end_char)
                facts = shared._facts(corpus,pi,page,part)
                for row in usable:
                    reading = row["constructor"]
                    rid = reading["id"]
                    if raw.get("only_reading") and raw["only_reading"]!=rid:continue
                    if raw.get("only_constructor_forms") and reading["form"] not in raw["only_constructor_forms"]:continue
                    if features[rid]["effective_target_kind"] == "person" and any(e.label_ == "PERSON"
                            and e.start_char <= part.root.idx < e.end_char and not a <= e.start_char < e.end_char <= b for e in doc.ents):
                        counts["incomplete_person_span_holds"] += 1
                        continue
                    activity=raw.get("kind")=="nominal_activity"
                    wording,reason = ((raw["realization"],raw["edits"]),None) if activity else shared._wording(case,reading,raw,part)
                    if reason:
                        counts["wording_"+reason] += 1
                        continue
                    feature,reason = shared._source_features(part,raw,facts,reading,features[rid],page,pi,pool,parser)
                    if reason:
                        counts["feature_"+reason] += 1
                        continue
                    anchor_context=salience.anchor_match(raw["text"],ref,anchors)
                    role_anchor=role_matcher.independent_anchor_context(raw["text"],ref,anchors,role_contexts[rid])
                    if feature["effective_target_kind"] in {"person","organization"}:
                        feature["source_owned_role_context"] = role_matcher.owned_role_context(part,role_contexts[rid],facts,role_anchor)
                    feature["focal_term_count"]=len(features[rid]["focal_terms"])
                    feature["attachment_term_count"]=len(features[rid]["attachment_terms"])
                    feature["whole_query_term_count"]=len(features[rid]["whole_query_terms"])
                    fill,edits = wording
                    coordinate_check = None
                    if reading.get("role")=="actor_enumeration" and row["reading"].get("function")=="coordinate_member" and not re.search(r"\band\s*$",case["query"].split(case["focal_marker"])[0],re.I):
                        if (selection_profile or {}).get("coordinate_boundary_mode") == "visible_boundary":
                            coordinate_check = nominal_realization.coordinate_boundary(case, row["reading"], parser)
                        if coordinate_check is None or coordinate_check["add_connector"]:
                            edits=[*edits,dict(kind="COORDINATE_CONNECTOR_REALIZED",before=fill,after="and "+fill,
                                source_modified=False,source_evidence_credit=False,reason="DECLARED_COORDINATE_READING_AFTER_LITERAL_NOMINATION")]
                            fill="and "+fill
                    identity_first=bool((selection_profile or {}).get("identity_first"))
                    nomination_fill=raw["text"] if identity_first else fill
                    nodes = {f["node_id"] for f in facts}
                    node = next(iter(nodes)) if len(nodes) == 1 else None
                    # Identical spellings on another page/span remain separate
                    # source observations, including homonyms and counterclaims.
                    key = rid," ".join(fill.casefold().split()),node,page["id"],a,b
                    occurrence = dict(source_span=[a,b],source_wording=raw["text"],citation=ref,
                        source_head=dict(text=part.root.text,pos=part.root.pos_,tag=part.root.tag_,
                            span=[part.root.idx,part.root.idx+len(part.root)]),
                        insertion_edits=edits,features=feature,identity_merged=False)
                    if coordinate_check is not None:
                        occurrence["coordinate_boundary"] = coordinate_check
                    if raw.get("source_constituent"):
                        occurrence["source_constituent"] = deepcopy(raw["source_constituent"])
                    if identity_first:
                        occurrence["nomination"]=dict(source_identity=raw["text"],
                            source_span=[a,b],stage="SOURCE_CONSTITUENT_BEFORE_SURFACE_REALIZATION",
                            realized_surface=fill,grammatical_edits_are_source_evidence=False,
                            used_as_search_seed=False,hidden_names_supplied=False)
                    # A post-head PP may describe another actor. Match only
                    # this head's prefix and its own direct apposition; never
                    # lend a by-agent's role to the recipient noun phrase.
                    role_context = (role_matcher.owned_role_context(part,role_contexts[rid],facts,role_anchor)
                        if reading.get("form")=="nominal" and feature["effective_target_kind"]=="any" else None)
                    occurrence["selection_cue"] = selection.named_example(part,reading,feature,own_types[page["id"]],
                        own_role_context=role_context)
                    occurrence["selection_cue"]=salience.source_nomination_cue(case,reading,part,feature,occurrence["selection_cue"],own_types[page["id"]])
                    own_goal=salience.owned_goal(part,focal_goals,own_types[page["id"]])
                    _guard_operator_priority(part,feature,predicate_contexts[rid],own_goal)
                    occurrence["selection_cue"]["owned_goal_context"]=own_goal
                    occurrence["selection_cue"]["owned_goal_priority"]=bool(own_goal["matched"] and reading["form"] in {"nominal","possessive","member_example"})
                    occurrence["selection_cue"]["visible_anchor_context"]=anchor_context
                    if raw.get("kind") == "nominal" and part.root.dep_ == "appos" and part.root.head.pos_ == "PROPN":
                        observations = [visible_apposition_context.observe(case, row["reading"], entity,
                            observed, page, doc, raw) for entity, observed in visible_people]
                        matched = {digest(o):o for o in observations if o["matched"]}
                        if len(matched) == 1:
                            occurrence["selection_cue"]["visible_apposition_context"] = next(iter(matched.values()))
                    if activity:
                        occurrence["activity_projection"]=deepcopy(raw)
                        occurrence["selection_cue"]["owned_activity_priority"]=True
                        occurrence["selection_cue"]["source_only"]=True
                    rank = selection.source_rank(occurrence,shared._key(feature,page,[a,b],rid,nomination_fill))
                    counts["source_reading_drafts"] += 1
                    if key not in groups:
                        groups[key] = dict(key=rank,reading=reading,original_reading=row["reading"],fill=nomination_fill,
                            node_id=node,primary=occurrence,occurrences=[occurrence])
                    else:
                        group = groups[key]
                        group["occurrences"].append(occurrence)
                        if rank < group["key"]:
                            group.update(key=rank,fill=nomination_fill,primary=occurrence)
        cue_fraction=(selection_profile or {}).get("candidate_focal_fraction",.25)
        ordered = _draft_union(groups.values(),_focus_text(case,plan),set(budget["baseline_page_ids"]),draft_budget,
            cue_fraction,cue_order_mode=(selection_profile or {}).get("cue_order_mode", "source_priority"),
            supplemental_mode=(selection_profile or {}).get("supplemental_mode", "legacy"),
            query_sha256=digest(case["query"]))
        execution_order = [g for g in ordered if g["selected_for_evaluation"]]
        positions = {id(g):i for i,g in enumerate(ordered,1)}
        def fallback(group,attempt):
            selection.queue_family_fallback(group,attempt,ordered,execution_order)
        for attempt,group in enumerate(execution_order,1):
            position = positions[id(group)]
            rid,primary = group["reading"]["id"],group["primary"]
            if group["checked"] or checked[rid] >= draft_budget:
                continue
            checked[rid] += 1
            group.update(checked=True,assessment_state="CHECKED_BEFORE_FOCAL_GATE",assessment_reason=None)
            realized=primary.get("nomination",{}).get("realized_surface",group["fill"])
            candidate = dict(id="narrative_fill_"+digest([VERSION,case["case_id"],rid,realized,group["node_id"],
                primary["citation"]["page_sha256"],primary["source_span"]])[:28],reading_id=rid,fill=realized,
                node_id=group["node_id"],source_span=primary["source_span"],source_wording=primary["source_wording"],
                insertion_edits=primary["insertion_edits"],source_occurrences=group["occurrences"],
                sources=list({digest(o["citation"]):o["citation"] for o in group["occurrences"]}.values()),
                v6_reading=group["reading"],declared_reading=deepcopy(group["original_reading"]),
                support="SOURCE_WORDING_CONTEXT_ONLY",source_rank_position=position,
                ranking=dict(tiers=shared.RANK_TIERS,features=primary["features"],calibrated_probability=False),
                draft_scheduling=group["scheduling"],
                alternative_family=group["alternative_family"],context_rank_key=group["key"],
                evaluation_lanes=group["evaluation_lanes"],
                source_candidate_feasibility=shared._positive_feasibility(primary["features"]))
            if primary.get("nomination"):
                candidate["source_identity"]=primary["source_wording"]
                candidate["nomination"]=deepcopy(primary["nomination"])
                candidate["surface_realization"]=dict(source_identity=primary["source_wording"],
                    proposed_insertion=realized,edits=deepcopy(primary["insertion_edits"]),
                    performed_after_source_nomination_and_allocation=True,
                    added_connectors_are_not_source_quotations=True,seeded_retrieval=False)
            candidate["visible_anchor_context"]=deepcopy(primary["selection_cue"].get("visible_anchor_context"))
            candidate["owned_goal_context"]=deepcopy(primary["selection_cue"].get("owned_goal_context"))
            if primary.get("activity_projection"):candidate["activity_projection"]=deepcopy(primary["activity_projection"])
            final_form = final_form_fit(case,group["original_reading"],candidate["fill"],parser)
            counts["final_form_checks"] += 1
            candidate["final_form_fit"] = final_form
            if final_form["state"] != "pass":
                group["assessment_reason"] = "FINAL_FORM_HOLD"
                counts["final_form_holds"] += 1
                rejections.append(dict(candidate_id=candidate["id"],reading_id=rid,fill=candidate["fill"],
                    reason="DECLARED_FINAL_OUTER_FORM_NOT_ESTABLISHED",final_form_fit=final_form,not_factual_counterevidence=True))
                fallback(group,attempt)
                continue
            source_page = admitted[primary["citation"]["canonical_page_id"]]
            kind_fit = completed_head_kind(candidate,final_form,parser,source_page=source_page,
                source_types=own_types[source_page["id"]])
            candidate["completed_head_kind_fit"] = kind_fit
            counts["completed_head_kind_checks"] += 1
            if kind_fit["state"] != "pass":
                counts["completed_head_kind_holds"] += 1
                compatible = _context_kind_compatibility(case, candidate, source_page,
                    own_types[source_page["id"]], parser, plan.get("extractions", {}).get("entities", []),
                    (selection_profile or {}).get("context_kind_mode", "own_observation"))
                candidate["context_slot_compatibility"] = compatible
                if compatible["state"] != "possible":
                    group["assessment_reason"] = "COMPLETED_HEAD_KIND_HOLD"
                    rejections.append(dict(candidate_id=candidate["id"],reading_id=rid,fill=candidate["fill"],
                        reason="COMPLETED_HEAD_KIND_NOT_ESTABLISHED",completed_head_kind_fit=kind_fit,
                        context_slot_compatibility=compatible,not_factual_counterevidence=True))
                    fallback(group,attempt)
                    continue
                counts["context_only_head_compatibility_admissions"] += 1
                if (selection_profile or {}).get("context_kind_mode") == "visible_role_context" and compatible.get("lexical_reference_only"):
                    candidate["lexical_context_admission"] = dict(original_completed_head_kind=deepcopy(kind_fit),
                        context_observation=deepcopy(compatible), factual_support_certified=False)
                    # Keep immutable admission history outside every mutable producer input.
                    # Retaining the object also prevents Python object-ID reuse in this call.
                    lexical_admissions[id(candidate)] = (candidate,
                        json.dumps(candidate["lexical_context_admission"], sort_keys=True).encode(), group, candidate["id"])
            joint = shared._joint_slot_fit(case,group["reading"],candidate,parser)
            counts["joint_slot_checks"] += 1
            candidate["joint_slot_fit"] = joint
            if joint["state"] != "pass":
                group["assessment_reason"] = "JOINT_SLOT_HOLD"
                rejections.append(dict(candidate_id=candidate["id"],reading_id=rid,fill=candidate["fill"],
                    reason="JOINT_SLOT_FIT_NOT_ESTABLISHED",joint_slot_fit=joint,not_factual_counterevidence=True))
                fallback(group,attempt)
                continue
            decision = shared._gate(case,plan,group["reading"],candidate,admitted,parser,source_policy=source_policy)
            counts["scoped_gate_calls"] += 1
            group.update(focal_assessed=True,assessment_state="FOCAL_ASSESSED")
            candidate["local_decision"] = decision
            trusted_entry = lexical_admissions.get(id(candidate))
            if (selection_profile or {}).get("context_kind_mode") == "visible_role_context" and _lexical_kind_decision_hold(
                    candidate, decision, trusted_admission=trusted_entry[1] if trusted_entry is not None else None):
                group["assessment_reason"] = "LEXICAL_KIND_REFERENCE_CANNOT_AUTHORIZE_SIGNED_DECISION"
                rejections.append(dict(candidate_id=candidate["id"], reading_id=rid,
                    fill=candidate["fill"], reason=group["assessment_reason"],
                    observed_gate_decision=deepcopy(decision), gate_decision_modified=False,
                    enforcement_stage="BEFORE_LOCAL_PROCESSING"))
                fallback(group,attempt)
                continue
            if candidate.get("context_slot_compatibility",{}).get("state") == "possible":
                if candidate["context_slot_compatibility"].get("lexical_reference_only") and decision.get("status") not in {
                        "exploratory_contextual", "incompatible_not_viable"}:
                    group["assessment_reason"] = "LEXICAL_KIND_REFERENCE_CANNOT_AUTHORIZE_SIGNED_DECISION"
                    rejections.append(dict(candidate_id=candidate["id"], reading_id=rid,
                        fill=candidate["fill"], reason=group["assessment_reason"],
                        observed_gate_decision=deepcopy(decision), gate_decision_modified=False))
                    fallback(group,attempt)
                    continue
                selection.require_context_decision(candidate,decision)
            decision, provenance_binding = selection.bind_decision_sources(decision,admitted)
            candidate["positive_citation_decision"] = deepcopy(decision)
            candidate["positive_citation_decision_provenance_binding"] = provenance_binding
            decision, counter_receipt = counter_comparison.apply(candidate,group["reading"],decision)
            decision=salience.focal_scope_guard(case,group["reading"],candidate,decision)
            decision=salience.projection_context_decision(candidate,decision)
            candidate["inspected_pool_counter_comparison"] = counter_receipt
            decision, provenance_binding = selection.bind_decision_sources(decision,admitted)
            candidate["local_decision"] = decision
            candidate["local_decision_provenance_binding"] = provenance_binding
            if (selection_profile or {}).get("context_kind_mode") == "visible_role_context" and _lexical_kind_decision_hold(
                    candidate, decision, trusted_admission=trusted_entry[1] if trusted_entry is not None else None):
                group["assessment_reason"] = "LEXICAL_KIND_REFERENCE_CANNOT_AUTHORIZE_SIGNED_DECISION"
                rejections.append(dict(candidate_id=candidate["id"], reading_id=rid,
                    fill=candidate["fill"], reason=group["assessment_reason"],
                    observed_gate_decision=deepcopy(decision), gate_decision_modified=False,
                    enforcement_stage="AFTER_LOCAL_PROCESSING"))
                fallback(group,attempt)
                continue
            if decision["counterevidence"]:
                counter_records.append(dict(candidate_id=candidate["id"],reading_id=rid,fill=candidate["fill"],
                    candidate_sources=deepcopy(candidate["sources"]),decision=deepcopy(decision),
                    inspected_pool_counter_comparison=counter_receipt))
            grammar = next((q for q in decision["checklist"] if q["id"] == "grammar"),None)
            if decision["status"] == "incompatible_not_viable" or grammar is None or grammar["state"] != "pass":
                group["assessment_reason"] = "FACTUAL_COUNTER_OR_GRAMMAR_WITHHELD"
                rejections.append(dict(candidate_id=candidate["id"],reading_id=rid,fill=candidate["fill"],
                    reason="FACTUAL_COUNTER_OR_GRAMMAR_GATE_WITHHELD",decision=decision,
                    positive_citation_decision=candidate["positive_citation_decision"],
                    inspected_pool_counter_comparison=counter_receipt))
                fallback(group,attempt)
                continue
            candidate.update(support=_support_label(decision),
                source_wording_credit="LITERAL_SOURCE_WORDING_IS_NOT_FACTUAL_SUPPORT",
                support_assessment=dict(label=decision["label"],
                substantive_support=decision["status"] == "evidence_backed_suggestion",
                same_scoped_counterevidence=decision["counterevidence"],scope=decision.get("scope"),absence_is_counterevidence=False),
                candidate_feasibility=dict(status="SOURCE_ATTESTED_CONTEXT_WITH_SLOT_FIT" if not candidate["source_candidate_feasibility"]["positive_clue"]
                    else "POSITIVE_SOURCE_CLUE_WITH_SLOT_FIT",positive_source_clue=candidate["source_candidate_feasibility"]["positive_clue"],
                    contextual_display_is_not_action_support=True,factual_support_certified=False))
            viable[rid].append(candidate)
            group.update(assessment_state="ASSESSED_FEASIBLE",assessment_reason=decision["status"])
    for group in ordered:
        group["selected_for_evaluation"] = group["checked"]
        if not group["checked"]:
            counts["draft_budget_unevaluated"] += 1
            if group["initial_opportunity_allocated"]:
                group["assessment_reason"] = "CHECK_CAP_EXHAUSTED_AFTER_FAMILY_FALLBACK"
    tiers = {"evidence_backed_suggestion":0,"partial_grounding":1,"exploratory_contextual":2}
    views = []
    context_mode = (selection_profile or {}).get("context_ordering_mode", "legacy")
    for row in adaptation["readings"]:
        pool_values = viable[row["reading"]["id"]]
        if (selection_profile or {}).get("context_kind_mode") == "visible_role_context":
            retained = []
            for candidate in pool_values:
                compatible = candidate.get("context_slot_compatibility", {})
                trusted_entry = lexical_admissions.get(id(candidate))
                if trusted_entry is not None:
                    counts["context_exception_replay_checks"] += 1
                    if not _replay_lexical_admission(case, candidate, parser, plan, admitted, own_types,
                            trusted_admission=trusted_entry[1]):
                        counts["context_exception_replay_holds"] += 1
                        trusted_entry[2].update(assessment_state="WITHHELD_BEFORE_FINAL_ORDER",
                            assessment_reason="LEXICAL_CONTEXT_REPLAY_NOT_EXACT")
                        rejections.append(dict(candidate_id=trusted_entry[3], reading_id=candidate["reading_id"],
                            fill=candidate["fill"], reason="LEXICAL_CONTEXT_REPLAY_NOT_EXACT",
                            enforcement_stage="BEFORE_FINAL_ORDER", observed_gate_decision=deepcopy(candidate["local_decision"]),
                            gate_decision_modified=False, saved_context_observation=deepcopy(compatible),
                            no_additional_checks_or_fallback_reallocation=True))
                        continue
                retained.append(candidate)
            pool_values = viable[row["reading"]["id"]] = retained
        context_keys = _final_context_order(case, pool_values, parser, context_mode,
            plan=plan, admitted=admitted, own_types=own_types)
        ordering_tiers = ({c["id"]:c["context_priority"]["effective_ordering_tier"] for c in pool_values}
            if context_mode in {"focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"} else None)
        occurrence_order = selection.shortlist(pool_values, len(pool_values), context_keys=context_keys, ordering_tiers=ordering_tiers)
        values = unique_surface_shortlist(occurrence_order, top_k)
        for rank,candidate in enumerate(values,1):
            candidate["rank"] = rank
            candidate["ranking"].update(adjudication_tier=tiers.get(candidate["local_decision"]["status"],3),
                canonical_order="Full focal support, partial grounding, context; named example and own person-role priority, source alignment, lexical role distance, broad context, stable source; same-unit alternatives retained separately")
            if ordering_tiers is not None:
                candidate["ranking"].update(effective_ordering_tier=ordering_tiers[candidate["id"]],
                    canonical_order="Full focal evidence; partials with an Established requirement; contextual and unestablished partials; first eleven source/function priorities; exact attested argument-role affinity; focal lexical cues; stable source")
                if context_mode == "focal_visible_owner":
                    candidate["ranking"]["canonical_order"] = "Full focal evidence; partials with an Established requirement; contextual and unestablished partials; first eleven source/function priorities; literal visible-name apposition context; exact attested argument-role affinity; focal lexical cues; stable source"
                if context_mode == "focal_visible_attachment":
                    candidate["ranking"]["canonical_order"] = "Full focal evidence; partials with an Established requirement; contextual and unestablished partials; revalidated reviewed role-kind visible attachment ONLY for native exploratory_contextual; entire V26 soft key (first eleven source/function priorities; literal visible-name apposition context; exact attested argument-role affinity; focal lexical cues; remaining context/retrieval and stable source)"
            if context_mode != "legacy":
                candidate["ranking"].update(context_ordering_version=(ROLE_CONTEXT_ORDER_VERSION
                    if context_mode == "focal_visible_attachment" else context_relevance.VERSION),
                    canonical_order=(candidate["ranking"]["canonical_order"] if context_mode in {"focal_role_affinity", "focal_visible_owner", "focal_visible_attachment"} else
                        "Factual tier; original source/function priorities; focal-sentence overlap and source precision; remaining original context priorities; stable source"))
        views.append(dict(reading=row["reading"],constructor_reading=row["constructor"],candidates=values))
    selected = [c for row in views for c in row["candidates"]]
    from matryoshka_narrative.fit_scores import score_candidate_fit
    for values in viable.values():
        for candidate in values:
            candidate["fit_scorecard"]=score_candidate_fit(candidate,include_banded_aggregate=True)
            if context_mode == "legacy":
                candidate["ending_utility"]=salience.ordering_utility(candidate)
            else:
                candidate["legacy_context_utility_not_used_for_ordering"]=salience.ordering_utility(candidate)
    return dict(version=VERSION,task="redaction",status="CANDIDATE_SUGGESTIONS" if selected else "NO_SOURCE_GROUNDED_SUGGESTIONS",
        context_ordering_policy=dict(mode=context_mode, version=(ROLE_CONTEXT_ORDER_VERSION
            if context_mode == "focal_visible_attachment" else context_relevance.VERSION if context_mode != "legacy" else None),
            factual_tiers_precede_context=True, context_utility_is_ordinal_not_confidence=True,
            **(dict(native_exploratory_only=True, prefix_precedes_entire_v26_soft_key=True,
                    role_kind_context_version=role_kind_context.VERSION)
               if context_mode == "focal_visible_attachment" else {})),
        query_sha256=digest(case["query"]),provided_plan_sha256=digest(plan),readings=views,candidates=selected,
        reading_adapter=adaptation,unsupported_readings=[dict(reading_id=r["reading"]["id"],outer_family=r["reading"]["outer_family"],
            reason=r["hold_reason"]) for r in adaptation["readings"] if r["constructor"] is None],
        source_passage_readouts=_source_readouts(pages,policy) if any(r["constructor"] is None for r in adaptation["readings"]) else [],
        inspected_page_ids=list(admitted),source_pages_inspected=len(admitted),source_budget=budget,
        source_pages_enumerated=len(pages) if usable else 0,all_admitted_pages_enumerated=bool(usable) and len(pages) == len(retrieval["pages"]),
        execution=dict(elapsed_seconds=time.perf_counter()-started,counts=dict(counts),draft_budget_per_reading=draft_budget,
            counter_comparison=counter_comparison.summary(),
            draft_lane_caps=dict(fresh_baseline=max(1,draft_budget-int(draft_budget*cue_fraction)),visible_cue=min(draft_budget-1,int(draft_budget*cue_fraction))),
            focal_assessment_cap_per_reading=draft_budget,completed_checks_are_not_all_focal_assessments=True,
            supplemental_source_priority_fields=11,
            cue_order_mode=(selection_profile or {}).get("cue_order_mode", "source_priority"),
            supplemental_mode=(selection_profile or {}).get("supplemental_mode", "legacy"),
            source_fit_priorities_precede_cue_round_robin=(selection_profile or {}).get("cue_order_mode", "source_priority") == "source_priority",
            source_role_distance_is_factual_support=False,
            union_deduplicated_before_checks=True,duplicate_lane_entries_not_replenished=(selection_profile or {}).get("supplemental_mode", "legacy") == "legacy",
            checked_per_reading=dict(checked),source_parse_requests=parser.calls,unique_parsed_texts=parser.misses,
            full_old_constructor_called=False,source_index_rebuilt=False,old_ranks_reused=False),
        _candidate_audit=dict(source_groups=[dict(reading_id=g["reading"]["id"],fill=g["fill"],node_id=g["node_id"],
            rank_key=list(g["key"]),scheduling=g["scheduling"],evaluation_lanes=g["evaluation_lanes"],
            allocation_input_index=g.get("allocation_input_index"),allocation_opportunity=g.get("allocation_opportunity"),
            selected_for_evaluation=g["selected_for_evaluation"],initial_opportunity_allocated=g["initial_opportunity_allocated"],
            alternative_family=g["alternative_family"],assessment_state=g["assessment_state"],
            assessment_reason=g["assessment_reason"],focal_assessed=g["focal_assessed"],
            occurrences=g["occurrences"]) for g in ordered],
            allocation_receipts={g["reading"]["id"]:g["allocation_receipt"] for g in ordered if "allocation_receipt" in g},rejections=rejections,
            checked_viable=[dict(id=c["id"],reading_id=c["reading_id"],fill=c["fill"],local_decision=c["local_decision"])
                for rows in viable.values() for c in rows],unevaluated_is_rejection=False),
        assessed_candidates=[c for rows in viable.values() for c in rows],
        unassessed_remainder=[dict(reading_id=g["reading"]["id"],fill=g["fill"],node_id=g["node_id"],
            alternative_family=g["alternative_family"],reason=g["assessment_reason"],
            source_group_position=i,not_rejected=True) for i,g in enumerate(ordered,1) if not g["checked"]],
        material_counterevidence=counter_records,
        selection_helper_version=selection.VERSION,certificate_contract_version="narrative-decision-certificate/2",
        display_budgets=dict(per_reading=top_k,actual_total=len(selected),padding=False),
        evidence_gate_version=counter_comparison.decision_version,positive_citation_gate_version=shared.evidence_gate.VERSION,
        counter_comparison_version=counter_comparison.version,source_gate_version=shared.PROPERTY_SCOPE_VERSION,
        final_form_gate_version=FINAL_FORM_VERSION,
        completed_head_kind_version=TYPE_VERSION,selection_version=SELECTION_VERSION,
        scope="Bounded fresh construction, not corpus-exhaustive recovery or an unchanged old native rank",
        contextual_display_without_positive_slot_clue=True,known_answer_bonus=False,keys_read=False,grades_read=False,api_calls=0)
