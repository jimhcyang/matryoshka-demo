"""Tampering and fresh-authorization checks; no historical approval fixture."""
import json
from pathlib import Path
import tempfile
import unittest

from validate_manifest import at, authorize, unique


class ManifestTests(unittest.TestCase):
    def test_duplicate_metadata_keys_fail(self):
        with self.assertRaises(AssertionError):
            json.loads('{"x":1,"x":2}', object_pairs_hook=unique)

    def test_private_or_traversal_dependency_is_not_a_file(self):
        for name in ('../outside', '/absolute', 'a\\b', 'a//b'):
            with self.assertRaises(AssertionError):
                at(Path.cwd(), name)

    def test_no_approval_is_never_publish_authorization(self):
        with self.assertRaises(AssertionError):
            authorize(Path.cwd(), None)

    def test_prior_epoch_or_wrong_candidate_approval_fails(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'release-manifest.json').write_text('{}')
            (root / 'approval.json').write_text('{"version":"old-dataset-privacy-pass/1"}')
            (root / 'ref.json').write_text('{"path":"approval.json","sha256":"' + '0' * 64 + '"}')
            with self.assertRaises(AssertionError):
                authorize(root, root / 'ref.json')


if __name__ == '__main__':
    unittest.main()
