"""Guide copy/report-binding regressions, no generator, API or native execution."""
import json
from pathlib import Path
import tempfile
import unittest

from export_narrative import HERE, ROOT, Inputs, Stage, encoded, sha
from field_guide import TARGETS, assets, install
from ci.validate_manifest import validate_field_guide


class FieldGuideTests(unittest.TestCase):
    def fixture(self, root):
        directory = root / 'guide'
        directory.mkdir()
        case = dict(case_id='saved', corpus='iran', task='hypothesis', query='A literal saved question?')
        report = dict(cases=[dict(case=case)])
        raw = encoded(report)
        (root / 'report.json').write_bytes(raw)
        report_ref = dict(path='report.json', sha256=sha(raw))
        pdf, text = b'%PDF-1.7\nunit fixture only', b'Exact guide text\n'
        guide = dict(version='evidence-field-guide/1', mode='saved_report_snapshot', report_byte_sha256=sha(raw),
            cases=[dict(case_id=case['case_id'], corpus=case['corpus'], task=case['task'], query_utf8_sha256=sha(case['query'].encode()))],
            files={'field-guide.pdf':sha(pdf), 'field-guide.txt':sha(text)}, pdf_pages=1)
        for name, value in {'field-guide.pdf':pdf, 'field-guide.txt':text, 'guide-public.json':encoded(guide),
            'private-qa.json':b'NOT AN OUTWARD ASSET'}.items():
            (directory / name).write_bytes(value)
        return directory, report_ref, report, guide

    def test_only_three_canonical_assets_copied_exactly_and_ci_binding_checked(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            directory, ref, report, _ = self.fixture(root)
            inputs = Inputs()
            selection = assets(root, directory, ref, inputs)
            stage = Stage(root / 'candidate')
            lineage = install(stage, root, selection, inputs)
            self.assertEqual({r['path'] for r in lineage}, set(TARGETS.values()))
            self.assertEqual({p.relative_to(stage.output / 'site').as_posix()
                for p in (stage.output / 'site').rglob('*') if p.is_file()}, set(TARGETS.values()))
            for name, target in TARGETS.items():
                self.assertEqual((stage.output / 'site' / target).read_bytes(), (directory / name).read_bytes())
            self.assertTrue(all(r['report_sha256'] == ref['sha256'] for r in lineage))
            validate_field_guide(stage.output / 'site', selection, report, ref)
            inputs.unchanged()

    def test_stale_report_or_changed_guide_bytes_fail_closed(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            directory, ref, _, guide = self.fixture(root)
            with self.assertRaisesRegex(ValueError, 'report binding'):
                assets(root, directory, dict(ref, sha256='0' * 64), Inputs())
            (directory / 'field-guide.pdf').write_bytes(b'%PDF-altered')
            with self.assertRaises(ValueError):
                assets(root, directory, ref, Inputs())

    def test_draft_partial_coverage_query_mismatch_and_symlink_rejected(self):
        for change in ('draft', 'coverage', 'query', 'symlink'):
            with self.subTest(change=change), tempfile.TemporaryDirectory(dir=HERE) as temporary:
                root = Path(temporary)
                directory, ref, _, guide = self.fixture(root)
                if change == 'draft': guide['mode'] = 'draft_selection_pending'
                if change == 'coverage': guide['cases'] = []
                if change == 'query': guide['cases'][0]['query_utf8_sha256'] = 'f' * 64
                if change == 'symlink':
                    link = root / 'linked-guide'
                    link.symlink_to(directory, target_is_directory=True)
                    directory = link
                else:
                    (directory / 'guide-public.json').write_bytes(encoded(guide))
                with self.assertRaises(ValueError):
                    assets(root, directory, ref, Inputs())

    def test_actual_fourteen_case_guide_matches_exact_publication(self):
        directory = ROOT / 'phase/release_finish_20261121/walkthrough/saved_fourteen_v01'
        ref = json.loads((ROOT / 'phase/release_finish_20261121/publication_v01/report_ref.json').read_bytes())
        inputs = Inputs()
        selection = assets(ROOT, directory, ref, inputs)
        self.assertEqual(len(selection['cases']), 14)
        self.assertEqual(selection['pdf_pages'], 36)
        self.assertEqual(selection['assets'][0]['public_sha256'], '65648160e5f5548d44038e5388eab1f6d58e8d7577a9e5e2b17cc78d23211e96')
        self.assertFalse(selection['bytes_modified'])
        inputs.unchanged()

    def test_final_v03_guide_has_exact_final_v02_report_and_pdf(self):
        directory = ROOT / 'phase/release_finish_20261121/walkthrough/saved_fourteen_v03'
        ref = json.loads((ROOT / 'phase/release_finish_20261121/publication_review_update_v02/report_ref.json').read_bytes())
        inputs = Inputs()
        selection = assets(ROOT, directory, ref, inputs)
        self.assertEqual(ref['sha256'], '0444fc3704868b557b26f0a539357cc5edc3813c8f67e2a804f67c57dca0d3bf')
        self.assertEqual(len(selection['cases']), 14)
        self.assertEqual(selection['pdf_pages'], 36)
        self.assertEqual(selection['assets'][0]['public_sha256'], '2be344edcbee3da90d14fa1d160502b30046f8514ef561d67fc6bdb004319c5e')
        inputs.unchanged()


if __name__ == '__main__':
    unittest.main()
