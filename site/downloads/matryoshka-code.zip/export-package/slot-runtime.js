  // Query only the byte-verified complete base-visible slot snapshot.
  const slotCatalogs = new Map();
  const slotNormalized = text => text.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
  function selectStaticSlots(catalog, p) {
    const status = catalog.status;
    if (p.corpus !== status.corpus || p.graph_id !== status.graph_run_id || p.hierarchy_id !== status.hierarchy_run_id)
      fail("INVALID_PARAMETER", "Opaque slots require the exact saved corpus graph and hierarchy");
    const offset=Number(p.offset),limit=Number(p.limit);
    if (!Number.isSafeInteger(offset)||offset<0||!Number.isSafeInteger(limit)||limit<1||limit>64||p.q.length>200||!["0","1"].includes(p.scan))
      fail("INVALID_PARAMETER", "Opaque-slot pagination/search bounds exceeded");
    if (Object.prototype.hasOwnProperty.call(p,"slot_id")) {
      const slot=catalog.slots.find(s=>s.id===p.slot_id);
      if (!slot) fail("PUBLIC_PACKET_NOT_EXPORTED", "Unknown opaque slot; no identity substitute");
      return {...status,slot};
    }
    const terms=slotNormalized(p.q).split(" ").filter(Boolean);
    const matches=catalog.slots.filter(s=>{
      const surface=slotNormalized([s.id,s.slot_id||"","opaque slot",s.document_id,s.date,s.context_preview].join(" ")).split(" ");
      if (!terms.every(t=>surface.includes(t))) return false;
      if (Object.prototype.hasOwnProperty.call(p,"anchor_id")&&!s.anchors.some(a=>a.id===p.anchor_id)) return false;
      return ["domain_id","theme_id","community_id"].every(k=>!Object.prototype.hasOwnProperty.call(p,k)||s[k]===p[k]);
    });
    return {...status,slots:matches.slice(offset,offset+limit),offset,limit,matched_count:matches.length,next_offset:offset+limit<matches.length?offset+limit:null};
  }
  async function verifiedSlots(key, signal) {
    const p=Object.fromEntries(new URL(key,base).searchParams),path="/data/slots/"+p.corpus+".json";
    if (!slotCatalogs.has(path)) slotCatalogs.set(path,(async()=>{
      const packet=await verified(new URL(path.slice(1),base));
      return JSON.parse(new TextDecoder("utf-8",{fatal:true}).decode(packet.decoded));
    })());
    let catalog;
    try { catalog=await slotCatalogs.get(path); } catch(error) { slotCatalogs.delete(path);throw error; }
    if(signal?.aborted)throw new DOMException("Aborted","AbortError");
    const value=selectStaticSlots(catalog,p);
    const records=new Map();
    async function hydrate(thin){
      if(!records.has(thin.record_path))records.set(thin.record_path,(async()=>{
        const packet=await verified(new URL(thin.record_path.slice(1),base),signal);
        return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(packet.decoded));
      })());
      const record=(await records.get(thin.record_path)).find(s=>s.id===thin.id);
      if(!record)fail('INTEGRITY_FAILURE','Exact opaque record is absent from its declared shard');
      return record;
    }
    if(value.slot){
      value.slot=await hydrate(value.slot);
      const page=await verified(new URL(catalog.details[value.slot.id].slice(1),base),signal);
      value.page=JSON.parse(new TextDecoder("utf-8",{fatal:true}).decode(page.decoded));
      if(value.page.text_sha256!==value.slot.page_provenance.text_sha256)fail("INTEGRITY_FAILURE","Opaque page differs from its exact slot provenance");
    }else value.slots=await Promise.all(value.slots.map(hydrate));
    const decoded=new TextEncoder().encode(JSON.stringify(value));
    return {key,entry:{mime:"application/json"},wire:decoded,decoded,gzip:false,httpDecoded:false};
  }
