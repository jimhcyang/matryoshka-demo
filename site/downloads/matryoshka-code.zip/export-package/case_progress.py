"""Durable PARTIAL route/fragment checkpoints; never a completion receipt."""
import json
import os


def save(worker, bindings, completed_cases):
    worker.packet_pack.finish(worker.entries)
    value = dict(version='partial-saved-response-checkpoint/1', status='PARTIAL_NOT_RELEASE_QUALIFIED',
        bindings=bindings, completed_case_ids=list(completed_cases), entries=worker.entries,
        coverage=worker.coverage, files=worker.stage.files,
        metadata_projections=worker.metadata_projections, api_calls=0, native_executions=0)
    raw = json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()
    target = worker.stage.output / 'case-progress.json'
    temporary = target.with_suffix('.tmp')
    with temporary.open('wb') as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    temporary.replace(target)
