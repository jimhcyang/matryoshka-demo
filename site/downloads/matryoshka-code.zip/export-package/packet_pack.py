"""Lossless ASCII byte fragments using the existing public fragment-DAG contract.

Splits are transport boundaries, not JSON edits. Balanced concatenation shares
unchanged long sequences while retaining every original response byte/hash.
"""
import gzip
import base64
import hashlib
import json
import re
import sqlite3
from collections import OrderedDict


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class PacketPack:
    path = 'data/packet-pack/manifest.json'

    def __init__(self, stage, literal_encoding='ascii'):
        self.stage = stage
        self.literal_encoding = literal_encoding
        self.roots = {}
        self.hot = OrderedDict()
        self.total_nodes = 0
        self.db_path = stage.output / 'packet-dictionary.sqlite3'
        self.db = sqlite3.connect(self.db_path)
        self.db.execute('PRAGMA journal_mode=OFF')
        self.db.execute('PRAGMA cache_size=-8192')
        self.chunks, self.pending, self.pending_bytes = [], [], 0
        if getattr(stage, 'resuming', False):
            from resume_support import restore_pack
            restore_pack(self)
        else:
            self.db.execute('CREATE TABLE fragments(id INTEGER PRIMARY KEY, digest TEXT UNIQUE NOT NULL, size INTEGER NOT NULL, pieces BLOB NOT NULL, dependencies BLOB NOT NULL)')

    def node(self, pieces, size, dependencies=()):
        raw = encoded(pieces)
        key = sha(raw)
        if key in self.hot:
            self.hot.move_to_end(key)
            return self.hot[key]
        previous = self.db.execute('SELECT id,size,dependencies FROM fragments WHERE digest=?', (key,)).fetchone()
        if previous is not None:
            result = previous[0], previous[1], frozenset(json.loads(previous[2]))
            self.hot[key] = result
            if len(self.hot) > 65536:
                self.hot.popitem(last=False)
            return result
        identity = self.total_nodes + 1
        value = (identity, size, frozenset(dependencies) | {len(self.chunks)})
        self.db.execute('INSERT INTO fragments VALUES(?,?,?,?,?)', (identity, key, size, raw, encoded(sorted(value[2]))))
        self.total_nodes = identity
        self.hot[key] = value
        if len(self.hot) > 65536:
            self.hot.popitem(last=False)
        self.pending.append(pieces)
        self.pending_bytes += len(raw) + 1
        if self.pending_bytes >= 2 * 1024**2:
            self.flush()
        return value

    def flush(self):
        if not self.pending:
            return
        first = self.total_nodes - len(self.pending) + 1
        raw = encoded(dict(version='graph-fragment-dag-chunk/1', first_id=first, fragments=self.pending))
        wire = gzip.compress(raw, compresslevel=6, mtime=0)
        relative = 'chunks/' + sha(wire) + '.json.gz'
        self.stage.write('site/data/packet-pack/' + relative, wire)
        self.chunks.append(dict(id=len(self.chunks), first_id=first, last_id=self.total_nodes, path=relative,
            encoding='gzip', decoded_bytes=len(raw), wire_bytes=len(wire), sha256decoded=sha(raw), wire_sha256=sha(wire)))
        self.pending, self.pending_bytes = [], 0
        self.db.commit()

    def put(self, raw, minimum=4096):
        identity = sha(raw)
        if identity not in self.roots:
            parts, start = [], 0
            for match in re.finditer(br'\},\{|\\n|\n', raw):
                end = match.start() + 2
                if end - start < minimum:
                    continue
                while end - start > 65536:
                    chunk = raw[start:start + 65536]
                    parts.append(self.node([self.literal(chunk)], len(chunk)))
                    start += 65536
                chunk = raw[start:end]
                parts.append(self.node([self.literal(chunk)], len(chunk)))
                start = end
            while start < len(raw):
                chunk = raw[start:start + 65536]
                parts.append(self.node([self.literal(chunk)], len(chunk)))
                start += len(chunk)
            while len(parts) > 1:
                combined = []
                for i in range(0, len(parts), 2):
                    if i + 1 == len(parts):
                        combined.append(parts[i])
                    else:
                        a, b = parts[i:i + 2]
                        combined.append(self.node(['', a[0], '', b[0], ''], a[1] + b[1], a[2] | b[2]))
                parts = combined
            root = parts[0]
            self.roots[identity] = dict(encoding='fragment-dag', pieces=['', root[0], ''], decoded_bytes=len(raw),
                sha256decoded=identity, dependencies=sorted(root[2]))
        return dict(encoding='fragment-dag', path=self.path, asset=identity, sha256=identity, mime='application/json')

    def read(self, asset):
        output, stack = [], [self.roots[asset]['pieces']]
        while stack:
            pieces = stack.pop()
            for piece in reversed(pieces):
                stack.append(piece)
            while stack and isinstance(stack[-1], (str, int)):
                value = stack.pop()
                if isinstance(value, str):
                    output.append(base64.b64decode(value) if self.literal_encoding == 'base64' else value.encode('ascii'))
                else:
                    stack.append(json.loads(self.db.execute('SELECT pieces FROM fragments WHERE id=?', (value,)).fetchone()[0]))
                    break
        raw = b''.join(output)
        assert sha(raw) == asset
        return raw

    def finish(self, entries):
        self.flush()
        if not self.roots:
            return
        raw = encoded(dict(version='graph-fragment-dag/1', encoding='fragment-dag', literal_encoding=self.literal_encoding, chunks=self.chunks, assets=self.roots))
        assert len(raw) <= 32 * 1024**2, 'Public fragment manifest exceeds the existing browser bound'
        path = 'data/packet-pack/' + sha(raw) + '.json'
        self.stage.write('site/' + path, raw)
        for entry in entries.values():
            if entry.get('encoding') == 'fragment-dag' and entry.get('asset') in self.roots and entry.get('path', '').startswith('data/packet-pack/'):
                entry['path'] = path
                entry['manifest_sha256'] = sha(raw)

    def close(self):
        self.db.close()
        self.db_path.unlink()

    def literal(self, raw):
        return base64.b64encode(raw).decode('ascii') if self.literal_encoding == 'base64' else raw.decode('ascii')


def read_packed(site, entry):
    manifest_raw = (site / entry['path']).read_bytes()
    assert sha(manifest_raw) == entry['manifest_sha256']
    manifest = json.loads(manifest_raw)
    root = manifest['assets'][entry['asset']]
    nodes = {}
    for i in root['dependencies']:
        ref = manifest['chunks'][i]
        wire = (site / entry['path']).parent.joinpath(ref['path']).read_bytes()
        assert sha(wire) == ref['wire_sha256']
        raw = gzip.decompress(wire)
        assert sha(raw) == ref['sha256decoded']
        value = json.loads(raw)
        nodes.update((value['first_id'] + n, pieces) for n, pieces in enumerate(value['fragments']))
    output, stack = [], [root['pieces']]
    while stack:
        value = stack.pop()
        if isinstance(value, list):
            stack.extend(reversed(value))
        elif isinstance(value, str):
            output.append(base64.b64decode(value) if manifest.get('literal_encoding') == 'base64' else value.encode('ascii'))
        else:
            stack.append(nodes[value])
    raw = b''.join(output)
    assert len(raw) == root['decoded_bytes'] and sha(raw) == entry['sha256']
    return raw
