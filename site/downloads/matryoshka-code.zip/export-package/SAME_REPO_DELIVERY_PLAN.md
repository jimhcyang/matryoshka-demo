# Authorized Same-Repository Delivery

Status: PLAN REGISTERED, implementation and new-architecture QA pending. No deployment, installation, commit or push authorized to this worker.

## Stop Receipt

The owned Stage08 resume process had already exited when the stop instruction arrived; PID 63826 was absent. No signal was sent to another process. `stage_v06_08/resume-02.log` ends with `ValueError: Static stage byte budget` from the 900,000,000-byte guard. The last durable graph checkpoint contains 906 local assets (500 recovered, 400 newly packed, six original bootstrap assets) and 282 pending external assets. Actual unsealed site bytes: 897,982,024. Retained dictionary: 6,605,692,928 bytes. The completed 14-case checkpoint, Slots parity, graph progress and all existing artifacts remain in place. No ninth full graph pack will be started.

The prior 108/108 managed-shell generic transport tests and 10/10 owner unit tests remain useful compatibility evidence, not a pass for the newly authorized mirror resolver.

## Delivery Contract

The deliverable is a self-contained REPOSITORY, not a fully offline Pages artifact. Publish the small `site/` through Pages and retain the original complete `datasets/` in that same GitHub repository. The Pages runtime keeps exact immutable same-repository RAW dataset URLs and checks their original wire and decoded SHA256 values. No graph node, edge, label, source object, opaque slot or resource identity is dropped to meet the site cap. No arbitrary external repository/domain or old-CIB-resource fallback is introduced.

The read-only baseline dataset directory currently contains 1,584 gzip files totaling 2,925,979,851 bytes; this includes files beyond the stated 1,576 indexed external dataset files. Preserve all of them. The exact indexed subset and every original wire/decoded hash will be recorded from the pinned map index; unreferenced extras are not deleted.

Original map-index source pin remains `a4f08ac865bb21faed97e1792fc2c84baba0e8483f5fb92c7604fec96f5e30f0`. The new combined API index necessarily has a new hash because it adds fresh case, guide, trace, digest and Slots responses. Preserve original graph wire entries and their pins rather than pretending the combined index has the old hash.

## Bounded Implementation

1. Stop structural graph repacking. Retain the original graph entries/bootstrap files and all same-repository dataset files. Reuse the complete case/Slots transport prefix from Stage08 only after verifying exact checkpoint bindings and reconstructed response hashes; never reuse changed final case-policy responses. The old large failed site and dictionary remain preserved until a separate authorized cleanup.
2. Add a narrow localhost resolver to the exported static transport. Only literal `localhost`, `127.0.0.1` and IPv6 loopback origins may map an otherwise approved immutable RAW dataset entry to `/datasets/{corpus}/{wire_sha256}.json.gz` on their own origin. Validate the original URL's owner/repository, 40-hex commit, corpus, filename and both pins BEFORE selecting this mirror. Local HTTP does not relax any existing graph resource binding or integrity check. Pages keeps the exact pinned RAW URL with credentials omitted and redirects rejected.
3. Extend the standalone read-only server to serve that mirror from installed-repository-relative `datasets/` by default, without Python imports or runtime data dependencies outside the installed repository. A QA-only explicit dataset-root option can point at the existing read-only pinned checkout, avoiding another multi-GB copy. Reject traversal, encoded traversal, symlinks, non-allowlisted files and mismatched wire hashes. Never forward to arbitrary network locations or API backends.
4. Make final report/casebook/digest/UI/code references explicit and parametric. Retain all 14 saved cases, guides, exact-source handoffs, paired PDF response bytes and acknowledgement guards. Regenerate case-bound eligibility and Slots/workbench links for changed final references; no graph/native/API/inference execution or hidden retargeting.
5. Replace offline-only CI assertions with same-repository delivery checks: complete site inventory and hashes; original graph entry/pin parity; repository dataset inventory and exact wire/decoded hashes; no unapproved external runtime dependency; source/report/native reference preservation; site below 900,000,000 bytes and every published file below 100,000,000 bytes. Maintain the 8GiB disk guard. Fresh lead-authored data/privacy/licensing/publication authorization remains mandatory, never inherited from the old fixture.

## Required Tests And Handoff

- Unit tests for local/remote URL selection, non-loopback rejection, repository/commit/corpus/hash mismatch, traversal, symlink and changed-wire rejection.
- Managed Chromium headless-shell checks of actual Iran, CIB and Vietnam maps under a nested project prefix using the local repository mirror, real Slots controls, actual graph-node walks, honest zero-hop/source-only handoffs, explicit original-source acknowledgement and paired PDF byte hashes.
- Remote-mode checks allow only exact pinned RAW URLs from the same repository; no broad external-network allowance. Local QA performs no model/API/native execution.
- Compatible generic runtime suite, fresh manifest validator and isolated code-bundle import tests; record pass/fail scopes without claiming data/privacy qualification.
- A small self-contained `site/`, reusable original graph-delivery manifest, parametric exporter/standalone server/code bundle, immutable hashes and concise final handoff. README must explicitly describe same-repository immutable large-asset delivery, not fully offline Pages.

All changes stay under `phase/release_finish_20261121/deploy/`. Frozen UI, native/data source files, the baseline GitHub checkout and its uncommitted README are untouched. Await lead CONTINUE after this status handoff.
