"""Input mirrors reject changed pins, traversal and symlinks without retargeting."""
import importlib.util
from pathlib import Path
import sys

import pytest

SPEC = importlib.util.spec_from_file_location("map_inputs_under_test", Path(__file__).with_name("prepare_map_inputs.py"))
mirror = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mirror)


def run(tmp_path, monkeypatch, *, mutate=None, output=None):
    original, datasets = tmp_path / "original", tmp_path / "datasets"
    (original / "data").mkdir(parents=True)
    datasets.mkdir()
    index = original / "data/api-index.json"
    index.write_bytes(b'{"entries":{}}')
    (datasets / "one.json").write_text("{}")
    monkeypatch.setattr(mirror, "HERE", tmp_path)
    monkeypatch.setattr(mirror, "INDEX_SHA256", mirror.hashlib.sha256(index.read_bytes()).hexdigest())
    if mutate:
        mutate(original, datasets)
    destination = output or tmp_path / "mirror"
    monkeypatch.setattr(sys, "argv", ["prepare", "--original-site", str(original),
        "--datasets", str(datasets), "--output", str(destination)])
    mirror.main()
    return original, datasets, destination


def test_exact_mirror_keeps_original_bytes_and_uses_links(tmp_path, monkeypatch):
    original, datasets, result = run(tmp_path, monkeypatch)
    for source, target in ((original / "data/api-index.json", result / "site/data/api-index.json"),
                           (datasets / "one.json", result / "datasets/one.json")):
        assert source.read_bytes() == target.read_bytes()
        assert source.stat().st_ino == target.stat().st_ino


def test_changed_index_rejects_before_output_creation(tmp_path, monkeypatch):
    with pytest.raises(AssertionError, match="index pin"):
        run(tmp_path, monkeypatch, mutate=lambda original, _: (original / "data/api-index.json").write_text("[]"))
    assert not (tmp_path / "mirror").exists()


def test_symlink_input_rejects_before_output_creation(tmp_path, monkeypatch):
    with pytest.raises(AssertionError):
        run(tmp_path, monkeypatch, mutate=lambda original, datasets: (datasets / "alias").symlink_to(original))
    assert not (tmp_path / "mirror").exists()


def test_dotdot_output_rejects_before_output_creation(tmp_path, monkeypatch):
    with pytest.raises(AssertionError):
        run(tmp_path, monkeypatch, output=tmp_path / "child/../escaped")
    assert not (tmp_path / "escaped").exists()


@pytest.mark.parametrize("folder", ["original", "datasets"])
def test_output_nested_in_input_rejects_before_mutation(tmp_path, monkeypatch, folder):
    output = tmp_path / folder / "nested"
    with pytest.raises(AssertionError, match="must not overlap"):
        run(tmp_path, monkeypatch, output=output)
    assert not output.exists()
