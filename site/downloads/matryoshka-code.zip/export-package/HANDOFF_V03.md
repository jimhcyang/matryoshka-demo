# Frozen V03 Handoff

Ready for lead installation as a validated diagnostic saved-data package. Publication remains held pending independent review and fresh authorization. No install, push, native execution or inference API call was performed by this worker.

## Candidate And Hashes

- Stage: `release_final_v03/site/`; raw receipt: `release_final_v03/stage_receipt.json`.
- Manifest SHA256: `53b5fd298b506a4756b09de9c99cb8fc2e2d680612b369344d1de048f9836452`.
- Bytes: 438,122,194 excluding the manifest; 443,130,133 including it. Largest file: 36,280,138 bytes.
- Final report SHA256: `0444fc3704868b557b26f0a539357cc5edc3813c8f67e2a804f67c57dca0d3bf`.
- API-index SHA256: `5a284ed4383118ed5bf1ad7d6bc7ebdf0b0c9b278c1fbb7f16ec16294bee5c8a`.
- Frozen graph JS source/public SHA256: `9e8a82f65b88269e4c81b1c3e51bfc2de513c1427dc06698d0904e948ff6dff5`.
- Guide: `docs/matryoshka-guide.pdf`, 36 pages, SHA256 `2be344edcbee3da90d14fa1d160502b30046f8514ef561d67fc6bdb004319c5e`.
- Code ZIP: `downloads/matryoshka-code.zip`, 1,339,835 bytes, SHA256 `e6a96b000b657be44e1fcb4eac451e3b415f54345e9d3a8145ddc78367318a05`.
- Implementation snapshot SHA256: `680099140564e27227f4904046541176d2bf48742f06531038fc4dd6d286e13a`; historical native execution versions remain recorded per case.

V03 derives from immutable V02 manifest `799acbd747279f2b12c16d17b885c1999011d2ce29b5b2feb792ad49b0e77450`. Only the lead-frozen graph display selector repair and associated lineage/publication/manifest metadata changed. API/native/source packets, all 14 cases, PDF addon, guide, code ZIP and graph datasets are unchanged. `release_final_v03/derivation.json` records the narrow derivation. The old failed browser receipt remains in `browser-final-v01/`.

## Verification

- `validation-v03.json`: PASS; all 11,117 local logical roots reconstructed, all 1,576 same-repository dataset wire/decoded hashes checked (2,918,125,927 bytes), native checksums and original references preserved.
- `browser-v03/receipt.json`: PASS, 24/24 cells and 754 distinct transport payloads. All 14 workbench cases, three corpus maps/Slots, real-node and zero-hop walks, exact source guide handoff and explicit Swedish S2 acknowledgment. No external requests, leaked backend API requests or page errors. Screenshots are beside the receipt.
- `ci-browser-v03/receipt.json`: PASS, 8/8 cells, managed Chromium headless shell, no API backend or external requests.
- `compatibility-final-v01/pytest.log`: 108/108 compatible runtime tests passed against the adapted runtime. V03 runtime bytes are unchanged from that tested stage.
- CI manifest/authorization unit tests: 4/4 passed. Owner exporter/guide/checkpoint/mirror unit tests: 19/19 passed.
- `code-bundle-check-final-v03.json`: PASS; all 299 ZIP entries hashed, 19 backend modules imported in isolation from the contained package. Public snapshot metadata is source-root tagged; the corpus-derived planner example fixture is excluded and only its input hash is retained.
- Lead-provided French addon remains included: 20 ordinary PDF routes for 10 documents, 10,514,074 bytes; case eligibility APIs unchanged.

## Installation And Scope

Lead owns installation/publishing. Preserve repository `datasets/` and the old site backup. Install `serve_static.py`, `fragment_reader.py`, `same_repo.py`, `ci/*.py`, and `ci/pages.yml` as the prepared standalone server/CI helpers; the workflow deploy label is **Validated**, not a research-qualification claim. No extra Python source module is required by these installed helpers.

The repository is self-contained for local saved viewing: the server defaults to repository-relative `site/` and `datasets/`, with GET `/` redirecting to its literal project prefix. Pages is not fully offline: it uses the exact dual-hash, commit-pinned RAW graph files in this same repository. Arbitrary external repositories and old-resource fallbacks remain rejected. Unexported ordinary PDFs fail closed; selected evidence/origin PDFs and the explicit addon are included.

Worker preview `127.0.0.1:59776` is stopped at handoff. Lead preview `8978` is untouched. Candidate bytes are frozen; no further owner edits are planned.
