"""Narrow/pair packing and actual saved source-walk regression checks."""
import hashlib
import json
from pathlib import Path
import shutil
import time
from urllib.parse import urlsplit,parse_qs
from playwright.sync_api import sync_playwright

HERE=Path(__file__).resolve().parent
SITE=HERE.parent/'stage/site'
BASE='http://127.0.0.1:8978/matryoshka-demo/'
result={'status':'RUNNING','model_calls':0,'modes':[],'captures':[],'errors':[],'started_at':time.time()}
def hashes():return {n:hashlib.sha256((SITE/n).read_bytes()).hexdigest() for n in ['graph-full-v6.js','graph-kg-v1.js']}
try:
  assert shutil.disk_usage(HERE).free>=3*1024**3
  result['hashes_before']=hashes()
  with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    context=browser.new_context(viewport={'width':390,'height':844},reduced_motion='no-preference')
    context.route('**/*',lambda route:route.continue_() if route.request.url.startswith('http://127.0.0.1:8978/') or route.request.url.startswith('data:') else route.abort())
    page=context.new_page();page.on('pageerror',lambda e:result['errors'].append(str(e)))
    page.goto(BASE+'graph-full-v6.html?corpus=cib',wait_until='domcontentloaded')
    page.wait_for_function('() => typeof state!=="undefined"&&state.panels.current?.nodes.length>0',timeout=90000)
    for width,pair in [(390,False),(390,True),(1440,True)]:
      page.set_viewport_size({'width':width,'height':1000 if width>600 else 844})
      page.locator('[data-display-mode="'+('pair' if pair else 'single')+'"]').click()
      page.wait_for_timeout(150)
      rows=page.evaluate("""async () => {const out=[];for(const p of activePanels()){
        await ensureHierarchyCatalog(p.view,'community');const c=p.levelRows('community').slice().sort((a,b)=>b.mass-a.mass)[0];await ensureCommunityDetail(p.view,c);
        p.level='evidence';p.trail=[c];p.neighborhood=null;p.nodeLimit=2048;p.refreshGraph();
        const a=p.usableBounds(),s=p.transform.scale;
        out.push({panel:p.name,count:p.nodes.length,cap:p.nodeLimit,available:p.graph.availableNodeCount,scale:s,density:p.packingDensity,
          feasible:p.packingFeasible,overlaps:GraphKG.overlaps(p.motionPoints(),0,.05/s),paintMetric:'body + actual ordinary half-stroke; active adornments excluded',area:a,maxWorld:Math.max(...p.nodes.map(n=>Math.hypot(n.x,n.y))),
          outside:p.nodes.filter(n=>{const q=p.screen(n),r=p.nodeRadius(n,0,3.5)+p.nodeStrokeRadius(n);return q.x-r<a.left-1||q.x+r>a.right+1||q.y-r<a.top-1||q.y+r>a.bottom+1;}).length});
      }return out;}""")
      entry={'width':width,'pair':pair,'panels':rows};result['modes'].append(entry);print(json.dumps(entry),flush=True)
      assert all(r['count']==min(2048,r['available']) and r['feasible'] and r['outside']==0 and r['overlaps']==0 and r['scale']>.001 and r['maxWorld']<100000 for r in rows),entry
      entry['interactions']=[]
      for name in [r['panel'] for r in rows]:
        page.locator('#'+name+'-canvas').scroll_into_view_if_needed()
        target=page.evaluate("""name => {const p=state.panels[name],rect=p.canvas.getBoundingClientRect(),toolbar=document.querySelector('.map-toolbar').getBoundingClientRect();
          const candidates=p.nodes.map(n=>({id:n.id,...p.screen(n)})).filter(q=>q.x>40&&q.x<p.width-70&&q.y+rect.y>toolbar.bottom+30&&q.y+rect.y<innerHeight-60&&document.elementFromPoint(q.x+rect.x,q.y+rect.y)===p.canvas&&p.hitNode(q)?.id===q.id);
          const q=candidates[Math.floor(candidates.length/2)];if(!q)throw Error('No visible actual canvas hit target');return {id:q.id,x:q.x+rect.x,y:q.y+rect.y,radius:Math.max(...p.nodes.map(n=>p.nodeRadius(n)))};}""",name)
        page.mouse.move(target['x'],target['y']);page.wait_for_timeout(50)
        assert page.evaluate('name => state.panels[name].hover?.id',name)==target['id'],'actual hover hit'
        page.mouse.down();assert page.evaluate('name => !!state.panels[name].drag?.node',name)
        page.mouse.move(target['x']+28,target['y']+18,steps=7);page.mouse.up();page.mouse.move(5,5)
        page.wait_for_function('name => !state.panels[name].motionJob',arg=name,timeout=10000)
        steps=[]
        for delta in [400,400,400,-400,-400,-400,-400,-400]:
          # Keep the pointer on this real canvas rather than invoking its handler.
          page.mouse.move(target['x'],target['y']);before=page.evaluate('name => state.panels[name].transform.scale',name)
          page.mouse.wheel(0,delta);page.wait_for_timeout(60);page.mouse.move(5,5)
          page.wait_for_function('name => !state.panels[name].motionJob',arg=name,timeout=10000)
          check=page.evaluate("""name => {const p=state.panels[name];return {scale:p.transform.scale,count:p.nodes.length,radius:Math.max(...p.nodes.map(n=>p.nodeRadius(n))),maxWorld:Math.max(...p.nodes.map(n=>Math.hypot(n.x,n.y))),overlaps:GraphKG.overlaps(p.motionPoints(),0,.05/p.transform.scale)};}""",name)
          assert check['scale']<before if delta>0 else check['scale']>before,check
          assert check['overlaps']==0 and check['count']==2048 and check['maxWorld']<100000,check
          steps.append(check)
        assert steps[-1]['radius']>target['radius']*1.2,'zoom-in must visibly grow actual nodes'
        # Fit, unlike intentional magnification, must include every circle inside usable bounds.
        page.evaluate('name => {const p=state.panels[name];p.compactLayout({immediate:true});p.fit();}',name)
        fitted=page.evaluate("""name => {const p=state.panels[name],a=p.usableBounds();return {scale:p.transform.scale,outside:p.nodes.filter(n=>{const q=p.screen(n),r=p.nodeRadius(n,0,3.5)+p.nodeStrokeRadius(n);return q.x-r<a.left-1||q.x+r>a.right+1||q.y-r<a.top-1||q.y+r>a.bottom+1;}).length,overlaps:GraphKG.overlaps(p.motionPoints(),0,.05/p.transform.scale)};}""",name)
        assert fitted['outside']==0 and fitted['overlaps']==0 and fitted['scale']>.001,fitted
        entry['interactions'].append({'panel':name,'actual_hover_drag':True,'zoom_steps':steps,'fit':fitted})
      if width==390 and not pair:
        assert page.evaluate('() => state.panels.current.nodes.length')==2048
        page.screenshot(path=str(HERE/'dense-mobile.png'))
        result['captures'].append({'path':'dense-mobile.png','width':390,'pair':False,'counts':{'current':2048}})
      if width==1440 and pair:
        counts=page.evaluate('() => Object.fromEntries(activePanels().map(p=>[p.name,p.nodes.length]))')
        assert counts=={'legacy':2048,'current':2048}
        page.screenshot(path=str(HERE/'dense-pair-desktop.png'))
        result['captures'].append({'path':'dense-pair-desktop.png','width':1440,'pair':True,'counts':counts})
    page.locator('[data-display-mode=single]').click();page.wait_for_timeout(100)
    page.evaluate("""async () => {const p=state.panels.current;await ensureHierarchyCatalog(p.view,'community');const c=p.levelRows('community').slice().sort((a,b)=>b.mass-a.mass)[0];await ensureCommunityDetail(p.view,c);p.level='evidence';p.trail=[c];p.neighborhood=null;p.nodeLimit=2048;p.refreshGraph();p.fit();}""")
    assert page.evaluate('() => state.panels.current.nodes.length')==2048
    page.screenshot(path=str(HERE/'dense-desktop.png'))
    result['captures'].append({'path':'dense-desktop.png','width':1440,'pair':False,'counts':{'current':2048}})
    page.emulate_media(reduced_motion='reduce')
    page.set_viewport_size({'width':1440,'height':1000})
    page.goto(BASE+'workbench-v6.html?case=narrative_cib_revision_ac39b62cbc7070a340c5d62d&arm=A',wait_until='domcontentloaded')
    page.wait_for_selector('[data-testid=map-view-on-kg]',timeout=90000)
    with page.expect_navigation(wait_until='domcontentloaded'):page.locator('[data-testid=map-view-on-kg]').first.click()
    link={k:v[0] for k,v in parse_qs(urlsplit(page.url).query).items()}
    page.wait_for_function("() => document.querySelector('#saved-kg-walk')?.dataset.status==='ready'",timeout=90000)
    page.wait_for_function("() => {const h=document.querySelector('#saved-kg-walk');return h.dataset.activeStage==h.querySelectorAll('[data-walk-stage]').length-1&&h.getAttribute('aria-busy')==='false'&&!!document.querySelector('#study-guide-drawer .source-quotation');}",timeout=60000)
    result['arias']=page.evaluate("""() => {const p=state.panels.current,d=document.querySelector('#study-guide-drawer'),q=document.querySelector('#saved-kg-walk blockquote');
      return {sameCanvas:p.canvas===document.querySelector('#current-canvas'),canvases:document.querySelectorAll('canvas').length,
       exact:d.dataset.proofPage===q.dataset.proofPage&&d.dataset.proofHash===q.dataset.proofHash&&d.dataset.proofStart===q.dataset.proofStart&&d.dataset.proofEnd===q.dataset.proofEnd&&d.querySelector('.source-quotation').textContent===q.textContent,
       page:d.dataset.proofPage,start:d.dataset.proofStart,end:d.dataset.proofEnd,hash:d.dataset.proofHash,guideMotionIdle:!p.motionJob&&!p.orbitEnabled,extraAcknowledgements:document.querySelectorAll('[data-testid=acknowledge-story-reveal]').length};}""")
    assert result['arias']['exact'] and result['arias']['sameCanvas'] and result['arias']['canvases']==2 and result['arias']['extraAcknowledgements']==0,result['arias']
    assert result['arias']['page']=='page_f4e91be8f65a8efcc32b' and result['arias']['start']=='454' and result['arias']['end']=='705'
    assert link['walk_autoplay']=='1' and link['walk_path']=='path_b0b2749d36a46eb8e22b7e75'
    browser.close()
  assert not result['errors'],result['errors']
  result['status']='PASS'
except Exception as error:
  result['status']='FAIL';result['failure']=str(error);raise
finally:
  result['hashes_after']=hashes();result['changed_during_test']=result.get('hashes_before')!=result['hashes_after'];result['ended_at']=time.time()
  (HERE/'modes-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2),flush=True)
