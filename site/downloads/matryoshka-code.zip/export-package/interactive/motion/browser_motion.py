"""Actual saved KG interaction; managed Chromium shell, local preview, API/model 0."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import time
from playwright.sync_api import sync_playwright

HERE=Path(__file__).resolve().parent
SITE=HERE.parent/'stage/site'
BASE=os.environ.get('MOTION_PREVIEW','http://127.0.0.1:8978/matryoshka-demo/')
RESULT={'status':'RUNNING','model_calls':0,'browser':'managed Chromium headless shell','cases':[],'errors':[],'started_at':time.time()}
def guard():assert shutil.disk_usage(HERE).free>=3*1024**3,'3 GiB floor'
def hashes():return {name:hashlib.sha256((SITE/name).read_bytes()).hexdigest() for name in ['graph-full-v6.js','graph-kg-v1.js']}
GEOMETRY="""() => {const p=state.panels.current,s=p.transform.scale,a=p.usableBounds();
 const nodes=p.motionPoints(),screen=p.nodes.map(n=>({...p.screen(n),r:p.nodeRadius(n,0,3.5)+p.nodeStrokeRadius(n)}));
 return {count:p.nodes.length,cap:p.nodeLimit,available:p.graph.availableNodeCount,scale:s,packed:p.packedLayout,
 overlaps:GraphKG.overlaps(nodes,0,.05/s),paintMetric:'body + actual ordinary half-stroke; intentional active adornments excluded',finite:screen.every(n=>[n.x,n.y,n.r].every(Number.isFinite)),packingFeasible:p.packingFeasible,density:p.packingDensity,
 outside:screen.filter(n=>n.x-n.r<a.left-1||n.x+n.r>a.right+1||n.y-n.r<a.top-1||n.y+n.r>a.bottom+1).length,
 selectionPreserved:JSON.stringify(p.nodes.map(n=>n.id))===JSON.stringify(p.graph.selectionAudit?.selectedIds),
 motionStats:{...p.motionStats},framePending:p.motionFrame!==null,settling:!!p.motionJob};} """
PROBE="""() => {const p=state.panels.current;window.motionProbe={steps:[],intervals:[],active:true,bandError:0};
 let prev=p.nodes.map(n=>({x:n.x,y:n.y})),last=performance.now();
 const tick=now=>{const q=window.motionProbe;if(!q.active)return;let step=0;
 p.nodes.forEach((n,i)=>{step=Math.max(step,Math.hypot(n.x-prev[i].x,n.y-prev[i].y)*p.transform.scale);prev[i]={x:n.x,y:n.y};
 if(p.graph.focusMode&&n.id!==p.graph.focusNodeId){const b=p.focusBands.find(b=>b.index===n.orbitBand),r=Math.hypot(n.x,n.y);q.bandError=Math.max(q.bandError,b.inner-r,r-b.outer);}});
 q.steps.push(step);q.intervals.push(now-last);last=now;requestAnimationFrame(tick);};requestAnimationFrame(tick);}
"""
def wait_settle(page):
    page.wait_for_function('() => !state.panels.current.motionJob && !state.panels.current.inducedLoading && !state.panels.current.v64Busy',timeout=15000)
    page.wait_for_timeout(120)
def stop_probe(page):
    return page.evaluate("""() => {const q=window.motionProbe;q.active=false;const sort=a=>a.slice().sort((a,b)=>a-b),t=sort(q.intervals);return {rafFrames:t.length,p95RafMs:t[Math.floor(t.length*.95)],maxRafMs:Math.max(...t),maxStepPx:Math.max(...q.steps),movingFrames:q.steps.filter(x=>x>.01).length,bandError:q.bandError};}""")
def drag(page,focus=False):
    point=page.evaluate("""focus => {const p=state.panels.current,a=p.usableBounds(),rect=p.canvas.getBoundingClientRect();
      const candidates=p.nodes.filter(n=>!focus||n.id!==p.graph.focusNodeId).map(n=>({n,s:p.screen(n)}))
        .filter(({n,s})=>s.x>a.left+30&&s.x<a.right-110&&s.y>a.top+30&&s.y<a.bottom-90&&p.hitNode(s)?.id===n.id)
        .sort((a,b)=>Math.hypot(a.s.x-p.width*.6,a.s.y-p.height*.5)-Math.hypot(b.s.x-p.width*.6,b.s.y-p.height*.5));
      const row=candidates[0];if(!row)throw Error('No hittable real drag target');
      return {id:row.n.id,x:rect.x+row.s.x,y:rect.y+row.s.y};}""",focus)
    page.mouse.move(point['x'],point['y']);page.mouse.down()
    assert page.evaluate('() => !!state.panels.current.drag?.node'),'actual canvas node pointerdown'
    page.mouse.move(point['x']+85,point['y']+45,steps=10)
    before=page.evaluate('() => state.panels.current.nodes.map(n=>({x:n.x,y:n.y}))')
    page.mouse.up();page.mouse.move(5,5)
    immediate=page.evaluate("""before => {const p=state.panels.current;return {job:!!p.motionJob,delta:Math.max(...p.nodes.map((n,i)=>Math.hypot(n.x-before[i].x,n.y-before[i].y)*p.transform.scale))};}""",before)
    page.evaluate(PROBE);wait_settle(page);probe=stop_probe(page)
    return {'actual_node_drag':True,'immediate':immediate,'warm':probe}

def run():
    guard();RESULT['hashes_before']=hashes()
    with sync_playwright() as pw:
      browser=pw.chromium.launch(headless=True)
      context=browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='no-preference')
      context.route('**/*',lambda route:route.continue_() if route.request.url.startswith('http://127.0.0.1:8978/') or route.request.url.startswith('data:') else route.abort())
      page=context.new_page();page.on('pageerror',lambda e:RESULT['errors'].append(str(e)))
      page.goto(BASE+'graph-full-v6.html?corpus=cib',wait_until='domcontentloaded')
      page.wait_for_function('() => typeof state!=="undefined" && state.panels.current?.nodes.length>0',timeout=90000)
      RESULT['community']=page.evaluate("""async () => {const p=state.panels.current;await ensureHierarchyCatalog(p.view,'community');
       const c=p.levelRows('community').slice().sort((a,b)=>b.mass-a.mass)[0];await ensureCommunityDetail(p.view,c);
       p.level='evidence';p.trail=[c];p.neighborhood=null;p.closeInspector(false);window.reviewCommunity=c;
       window.sourceSnapshot=JSON.stringify([c.member_nodes,c.member_edges]);return {id:c.id,mass:c.mass};}""")
      for cap in [32,256,2048]:
        guard();entry={'cap':cap};RESULT['cases'].append(entry)
        entry['coldRefreshMs']=page.evaluate("""cap => {const p=state.panels.current,t=performance.now();p.setNodeCap(cap);return performance.now()-t;}""",cap)
        wait_settle(page);entry['initial']=page.evaluate(GEOMETRY)
        assert entry['initial']['count']==cap and entry['initial']['selectionPreserved'] and entry['initial']['overlaps']==0,entry
        camera=page.evaluate('() => ({...state.panels.current.transform})')
        entry['drag']=drag(page)
        assert entry['drag']['immediate']['job'] and entry['drag']['immediate']['delta']<8,entry['drag']
        assert entry['drag']['warm']['movingFrames']>=8,entry['drag']
        assert entry['drag']['warm']['maxStepPx']<32,entry['drag']
        assert entry['drag']['warm']['p95RafMs']<50 and entry['drag']['warm']['maxRafMs']<150,entry['drag']
        entry['after_drag']=page.evaluate(GEOMETRY)
        assert entry['after_drag']['overlaps']==0 and not entry['after_drag']['framePending'],entry['after_drag']
        assert page.evaluate('() => ({...state.panels.current.transform})')==camera,'no global camera refit after drag'
        page.mouse.move(900,650);scale=entry['after_drag']['scale']
        page.mouse.wheel(0,500);page.wait_for_timeout(100);page.mouse.move(5,5);page.evaluate(PROBE);wait_settle(page)
        entry['zoom_warm']=stop_probe(page);entry['after_zoom']=page.evaluate(GEOMETRY)
        assert entry['after_zoom']['scale']<scale,'zoom-out must never jump inward to .12'
        assert entry['after_zoom']['count']==cap and entry['after_zoom']['overlaps']==0,entry['after_zoom']
        before=page.evaluate('() => JSON.stringify(state.panels.current.nodes.map(n=>[n.x,n.y]))');page.wait_for_timeout(500)
        assert page.evaluate('() => JSON.stringify(state.panels.current.nodes.map(n=>[n.x,n.y]))')==before,'stable non-orbital idle'
        entry['idleStable']=True
        print(json.dumps({'cap':cap,'count':entry['after_zoom']['count'],'restingOverlaps':entry['after_zoom']['overlaps'],'warmDrag':entry['drag']['warm']}),flush=True)
        assert page.evaluate('() => JSON.stringify([reviewCommunity.member_nodes,reviewCommunity.member_edges])===sourceSnapshot'),'source records unchanged'
      # Exercise the real listeners with an explicit synthetic visibility event.
      # This is a handler regression probe, not a claim to drive an OS tab switch.
      page.evaluate("""() => {const p=state.panels.current;p.nodes[0].x+=80/p.transform.scale;p.compactLayout();window.probeHidden=false;Object.defineProperty(document,'hidden',{configurable:true,get:()=>probeHidden});}""")
      page.wait_for_timeout(150)
      page.evaluate("() => {probeHidden=true;document.dispatchEvent(new Event('visibilitychange'));}")
      frozen=page.evaluate('() => JSON.stringify(state.panels.current.nodes.map(n=>[n.x,n.y]))');page.wait_for_timeout(160)
      assert page.evaluate('() => JSON.stringify(state.panels.current.nodes.map(n=>[n.x,n.y]))')==frozen
      page.evaluate("() => {probeHidden=false;document.dispatchEvent(new Event('visibilitychange'));delete document.hidden;}")
      wait_settle(page);assert page.evaluate(GEOMETRY)['overlaps']==0
      RESULT['syntheticVisibilityReturnResumed']=True
      RESULT['neighborhood']=page.evaluate("""async () => {const p=state.panels.current,degree=new Map();
       for(const e of reviewCommunity.member_edges||[]){degree.set(e.source,(degree.get(e.source)||0)+1);degree.set(e.target,(degree.get(e.target)||0)+1);}
       const node=reviewCommunity.member_nodes.slice().sort((a,b)=>(degree.get(b.id)||0)-(degree.get(a.id)||0))[0];
       await p.focusNeighborhood(node,{scroll:false});p.setNodeCap(256);p.closeInspector(false);p.hover=null;return {id:node.id,shown:p.nodes.length,available:p.graph.availableNodeCount};}""")
      wait_settle(page);page.mouse.move(5,5);page.evaluate('() => {const p=state.panels.current;p.hover=null;p.startOrbit();}')
      page.wait_for_timeout(180)
      first=page.evaluate('() => ({phase:state.panels.current.orbitPhase,time:performance.now()})');page.wait_for_timeout(1200)
      last=page.evaluate('() => ({phase:state.panels.current.orbitPhase,time:performance.now()})')
      RESULT['orbitObservedRadPerSecond']=(last['phase']-first['phase'])/((last['time']-first['time'])/1000)
      RESULT['focus_warm_geometry']=page.evaluate(GEOMETRY)
      print(json.dumps({'orbitObservedRadPerSecond':RESULT['orbitObservedRadPerSecond'],'focus':RESULT['focus_warm_geometry']}),flush=True)
      assert .020<RESULT['orbitObservedRadPerSecond']<.026,RESULT['orbitObservedRadPerSecond']
      RESULT['focus_drag']=drag(page,True)
      assert RESULT['focus_drag']['immediate']['job'] and RESULT['focus_drag']['immediate']['delta']<8
      assert RESULT['focus_drag']['warm']['movingFrames']>=8
      assert RESULT['focus_drag']['warm']['bandError']<.5
      RESULT['focus_after']=page.evaluate(GEOMETRY)
      assert RESULT['focus_after']['overlaps']==0,RESULT['focus_after']
      RESULT['ringBandsPreserved']=page.evaluate("""() => {const p=state.panels.current;return p.nodes.every(n=>{if(n.id===p.graph.focusNodeId)return Math.hypot(n.x,n.y)<.001;const b=p.focusBands.find(b=>b.index===n.orbitBand);return Math.hypot(n.x,n.y)>=b.inner-.01&&Math.hypot(n.x,n.y)<=b.outer+.01;});}""")
      assert RESULT['ringBandsPreserved']
      page.evaluate('() => state.panels.current.setNodeCap(2048)');wait_settle(page)
      RESULT['focus2048Zoom']=[]
      for _ in range(3):
        page.mouse.move(900,650);page.mouse.wheel(0,400);page.wait_for_timeout(70);page.mouse.move(5,5);wait_settle(page)
        geometry=page.evaluate(GEOMETRY);RESULT['focus2048Zoom'].append(geometry)
        assert geometry['count']==2048 and geometry['overlaps']==0 and geometry['finite'],geometry
      page.evaluate('() => {state.neighborhoodMotion=false;state.panels.current.stopOrbit();}')
      phase=page.evaluate('() => state.panels.current.orbitPhase');page.wait_for_timeout(300)
      assert page.evaluate('() => state.panels.current.orbitPhase')==phase
      RESULT['pauseRespected']=True
      page.emulate_media(reduced_motion='reduce');page.evaluate('() => {state.neighborhoodMotion=true;state.panels.current.startOrbit();}')
      page.mouse.move(900,650);page.mouse.wheel(0,400);page.wait_for_timeout(150)
      RESULT['reducedMotion']=page.evaluate('() => {const p=state.panels.current;return !p.motionJob&&!p.orbitEnabled;}')
      assert RESULT['reducedMotion']
      # Mobile keeps all 2,048 actual members, not an alternative lower-cap fixture.
      page.set_viewport_size({'width':390,'height':844})
      page.evaluate("""() => {const p=state.panels.current;p.neighborhood=null;p.level='evidence';p.trail=[reviewCommunity];p.nodeLimit=2048;p.refreshGraph();}""")
      page.wait_for_timeout(200);RESULT['mobile2048']=page.evaluate(GEOMETRY)
      assert RESULT['mobile2048']['count']==2048 and RESULT['mobile2048']['overlaps']==0 and RESULT['mobile2048']['packingFeasible'] and RESULT['mobile2048']['outside']==0,RESULT['mobile2048']
      browser.close()
    assert not RESULT['errors'],RESULT['errors']

try:
    run();RESULT['status']='PASS'
except Exception as error:
    RESULT['status']='FAIL';RESULT['failure']=str(error);raise
finally:
    RESULT['hashes_after']=hashes();RESULT['renderer_changed_during_test']=RESULT.get('hashes_before')!=RESULT['hashes_after']
    RESULT['ended_at']=time.time();guard();(HERE/'browser-results.json').write_text(json.dumps(RESULT,indent=2)+'\n')
    print(json.dumps(RESULT,indent=2),flush=True)
