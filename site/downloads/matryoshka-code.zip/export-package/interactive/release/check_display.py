"""Actual controls: eligibility presentation is not evidence admission."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
BASE = "http://127.0.0.1:8978/matryoshka-demo/"


def snapshot(page):
    return page.evaluate("""()=>({mode:state.visibilityMode,show:state.showIneligible,
      slots:slotOverlayState.enabled,cutoff:state.asOfPolicy.cutoff,
      minimum:state.asOfPolicy.minimum,maximum:state.asOfPolicy.maximum,
      panels:Object.fromEntries(Object.entries(state.panels).map(([key,p])=>[key,{
        count:p.nodes.length,ineligible:p.nodes.filter(n=>n.eligibility_ineligible).length,
        dim:p.nodes.filter(n=>n.visibility_dimmed).length,
        hiddenNonAnchor:p.nodes.filter(n=>n.eligibility_ineligible&&!n.visibility_hidden_anchor).length,
        semanticSlots:p.edges.filter(e=>e.slot_navigation&&GraphKG.semanticEdge(e)).length
      }]))})""")


def main():
    results = []
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(viewport={"width": 1440, "height": 1000}, reduced_motion="reduce")
        page = context.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))
        for corpus in ("cib", "iran", "vietnam"):
            page.goto(BASE + "graph-full-v6.html?corpus=" + corpus + "&view=pair&level=community")
            page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=120000)
            value = snapshot(page)
            assert "snap" not in page.locator("#as-of-range-hint").text_content().lower()
            page.locator("#as-of-date").fill("1900-01-01")
            page.locator("#as-of-date").press("Enter")
            page.wait_for_function("()=>state.asOfPolicy.cutoff===state.asOfPolicy.minimum")
            assert page.locator("#as-of-date").input_value() == value["minimum"]
            page.locator('[data-eligibility-style="show"]').click()
            shown = snapshot(page)
            assert shown["mode"] == "show" and shown["show"]
            assert all(row["dim"] == 0 for row in shown["panels"].values())
            assert sum(row["ineligible"] for row in shown["panels"].values()) > 0
            page.locator('[data-eligibility-style="dim"]').click()
            dim = snapshot(page)
            assert dim["mode"] == "dim" and dim["show"]
            assert all(row["dim"] == row["ineligible"] for row in dim["panels"].values())
            assert [row["count"] for row in shown["panels"].values()] == [row["count"] for row in dim["panels"].values()]
            page.locator("#hide-ineligible").click()
            hidden = snapshot(page)
            assert not hidden["show"]
            assert all(row["hiddenNonAnchor"] == 0 for row in hidden["panels"].values())
            page.locator('[data-eligibility-style="show"]').click()
            assert snapshot(page)["mode"] == "show"
            page.reload()
            page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=120000)
            assert snapshot(page)["mode"] == "show" and snapshot(page)["show"]
            assert page.locator('[data-eligibility-style="show"]').get_attribute("aria-pressed") == "true"
            page.locator('[data-redactions="hide"]').click()
            assert not snapshot(page)["slots"] and snapshot(page)["mode"] == "show"
            page.locator('[data-redactions="show"]').click()
            assert snapshot(page)["slots"] and snapshot(page)["mode"] == "show"
            assert all(row["semanticSlots"] == 0 for row in snapshot(page)["panels"].values())
            page.locator("#as-of-date").fill("2099-01-01")
            page.locator("#as-of-date").press("Enter")
            page.wait_for_function("()=>state.asOfPolicy.cutoff===state.asOfPolicy.maximum")
            assert page.locator("#as-of-date").input_value() == value["maximum"]
            results.append({"corpus": corpus, "show": shown, "dim": dim, "hide": hidden,
                            "roundtrip": True, "date_boundaries": True, "independent_slots": True})
        page.goto(BASE + "graph-full-v6.html?corpus=cib")
        page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=120000)
        page.evaluate("async()=>{const p=state.panels.current;p.drawerOpen=true;await p.inspectRenderedEdge(p.edges[0]);}")
        page.wait_for_selector('[data-edge-weight-audit="true"]', state="attached")
        technical = page.locator(".map-technical").filter(has=page.locator('[data-edge-weight-audit="true"]'))
        assert not technical.evaluate("element=>element.open")
        assert not page.locator('[data-edge-weight-audit="true"]').is_visible()
        assert "aggregate edge weight" not in page.locator(".inspector-stats:visible").inner_text()
        technical.locator(":scope > summary").click()
        assert page.locator('[data-edge-weight-audit="true"]').is_visible()
        results.append({"technical_weight_optional": True})
        context.close()
        mobile = browser.new_context(viewport={"width": 390, "height": 844}, reduced_motion="reduce")
        page = mobile.new_page()
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.goto(BASE + "graph-full-v6.html?corpus=cib&view=pair")
        page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=120000)
        assert page.evaluate("document.documentElement.scrollWidth<=innerWidth+2")
        for selector in ('[data-eligibility-style="show"]', '[data-eligibility-style="dim"]', '#hide-ineligible'):
            assert page.locator(selector).is_visible()
        results.append({"mobile_controls": True, "mobile_no_overflow": True})
        mobile.close()
        browser.close()
    assert not errors, errors
    (HERE / "display-checks.json").write_text(json.dumps({"status": "PASS", "results": results, "errors": errors}, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "cases": len(results)}))


if __name__ == "__main__":
    main()
