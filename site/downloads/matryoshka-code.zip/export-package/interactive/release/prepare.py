"""Clone only the published static site; never duplicate corpus datasets."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPO = ROOT / "matryoshka_demo_site"
PIN = "d1fccd88477dcca734d96ee0899251ace296f15e1610fd7906441d2162018398"


if __name__ == "__main__":
    assert shutil.disk_usage(HERE).free >= 3 * 1024**3
    raw = (REPO / "site/release-manifest.json").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PIN
    target = HERE / "stage/site"
    assert not target.exists()
    target.parent.mkdir(parents=True)
    subprocess.run(["cp", "-cR", str(REPO / "site"), str(target)], check=True)
    (target / "release-manifest.json").unlink()
    (HERE / "baseline.json").write_text(json.dumps({
        "manifest_sha256": PIN, "commit": "4a120dad71dece99adc63663edb340c14c9964b7",
        "source_report_ref": json.loads(raw)["source_report_ref"], "datasets_copied": False
    }, indent=2) + "\n")
    print("UNSEALED_APFS_CLONE_READY")
