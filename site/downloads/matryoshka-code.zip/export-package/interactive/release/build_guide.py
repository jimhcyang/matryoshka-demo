"""Public interface/method addendum; no model-generated assertions or credentials."""
from pathlib import Path
import json
import io
import textwrap

HERE=Path(__file__).resolve().parent
SITE=HERE/'stage/site'
SECTIONS=[
('Matryoshka / Interactive Guide',
 'Explore the corpus map, inspect the selected evidence, and distinguish a promising candidate from an established claim. The saved casebook and Live execution use the same evidence-oriented presentation.'),
('The Corpus Map',
 'Redactions Show/Hide controls source-visible redacted-slot markers. Ineligible Show/Dim/Hide controls the appearance of evidence outside the active access/date view. Show uses full color without making an object eligible. They are independent controls. In paired mode, shared Back and Fit affect both releases; the controls beside a map affect only that map. Search applies to both until a map is individually explored. The date field states the available range and uses its nearest boundary for an out-of-range entry.'),
('Why These Nodes?',
 'The display ceiling is not a source filter. Pinned selections are retained first. Additional nodes greedily add previously uncovered semantic neighbors, represent new hierarchy/type facets, and expose source-backed connections to the current selection. Context-only slot links do not count as semantic evidence, and unpinned context markers have a separate small display quota. The node-selection audit is available under More.'),
('Size, Strength And Movement',
 'Node radius is normalized within the displayed view. With t equal to the normalized log(1 + mass), evidence radius is 9 + 22 t^0.8 pixels before zoom; communities use 13 + 24 t^0.8, higher groups 16 + 26 t^0.8. Slot markers use a fixed base radius of 10. Zoom, density and overlap caps apply. Edge width is 0.55 + 1.1 sqrt(w / maximum displayed w) pixels. These are orientation encodings, not probabilities. Stored aggregate weight is optional under Technical fields, not independent corroboration or date-recomputed support. Nominal orbit is 0.024 radians/second, twice the previous rate, with slower outer bands. Orbit and return share a 30-Hz scheduler. Smoothstep return targets 720-2400 milliseconds; a 24-pixel step cap can extend completion. Dense layouts use precomputed packing, not an endless fit/repulsion loop. Motion adds no factual edges.'),
('Input, Facts And Sources',
 'Opening an example loads its completed result immediately. A redaction marker toggles its reference on a second click. Unknown references remain unknown. The initial grammatical reading is chosen from readings that contain saved candidates when available; an explicitly selected empty reading stays empty. Facts are query assertions, not established historical facts.'),
('Reading The Source Map',
 'The directed diagram begins with the input facts and ends only at quotations retained for the displayed decisions. Shared sources merge visually. Dotted lookup/readout links are not historical KG assertions. Where the saved trace does not assign a match to one particular fact, the diagram uses Combined facts rather than inventing attribution. Green means support, red opposition, and amber context or partial evidence.'),
('Follow A Result On The KG',
 'View on KG opens the existing corpus canvas and plays the exact saved inspection stages. It does not build a second graph. Source-bound node IDs and actual stored edges are retained. The final handoff binds the selected quotation by page, character interval and text hash. Clicking an excerpt opens its supplied document pages with that exact span highlighted. Some saved paths are post-run inspection routes; they must not be read as the original retrieval execution or as a chain of factual entailment.'),
('Ranks, Evidence And Repeated Wording',
 'Candidate rank and the evidence verdict are separate. Existing ordered criteria and source-priority arithmetic remain unchanged. The score chart identifies its basis; a ranking-position index is not calibrated confidence and is not comparable as a correctness probability across questions. Identical completed fill surfaces appear once, preserving the first native-ranked occurrence and separate source assessments. Repeated page observations from one document are not independent corroboration.'),
('A Concrete Saved Example',
 'For the Salvadoran-peasants redaction, the earlier report says the peasants can easily be manipulated politically. The displayed fill easily politically manipulated remains rank one and evidence-backed for that focal description. Two saved observations of the same wording now occupy one row, not two. Arias remains a high-ranking contextual candidate: a source identifying a powerful opposition organizer is not by itself proof of every action in the masked report.'),
('Unknown Delegation',
 'The study offers two gaps and four retained input windows, including a window with the visible Swedes sentence. That sentence is an explicit input clue, never an independent evidence vote. The entire originating report is excluded from retrieved evidence. Seven primary executions completed and one planning failure is retained. The reference words are not given, and these trials do not establish recovery. A source mention of a nationality elsewhere does not establish the identity of this visiting delegation.'),
('Live Execution',
 'Log in with a private backend password. The server verifies it and issues a random, origin-bound session held only in browser memory. The OpenAI API key stays in the server environment; it is never split into public fragments or reconstructed in the browser. No shared public demo word is configured as a password. Query-only model planning and redaction readings precede local deterministic retrieval, construction and verdicts. Progress reports stage names, not model reasoning. Logout revokes the session; cancellation cannot undo incurred charges. The retained spending ceiling, runtime limit, source cutoff and whole-origin exclusion remain enforced.'),
('Hosting And Source Boundaries',
 'GitHub Pages hosts the saved casebook and Live frontend, not Python inference. Run the local companion or connect an independently hosted authenticated backend with explicit origin permissions. The source-only CIB resource is unchanged. Iran and Vietnam retain their existing resource exports; no new source-only alias certification is implied. Additional document pages are provenance context, not extra inspected evidence. The richer experimental questions remain outside the presentation until their native results qualify.')]

def main():
    target=SITE/'docs';target.mkdir(exist_ok=True)
    text='\n\n'.join(title+'\n'+body for title,body in SECTIONS)+'\n'
    (target/'interactive-release.txt').write_text(text)
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>']
    pages=[]
    for number,index in enumerate(range(0,len(SECTIONS),2),1):
        commands=['0.97 0.98 0.96 rg 0 0 612 792 re f','0.09 0.28 0.29 rg 0 694 612 98 re f']
        def draw(x,y,size,font,value,color='0.10 0.23 0.25'):
            literal='('+value.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')+')'
            commands.append(f'{color} rg BT /{font} {size} Tf 1 0 0 1 {x} {y} Tm {literal} Tj ET')
        draw(44,755,11,'F2','MATRYOSHKA / INTERACTIVE GUIDE','0.95 0.98 0.94')
        draw(44,718,23,'F2',SECTIONS[index][0],'1 1 1')
        y=648
        for title,body in SECTIONS[index:index+2]:
            draw(44,y,15,'F2',title);y-=28
            for line in textwrap.wrap(body,width=82):draw(44,y,11,'F1',line);y-=16
            y-=30
        assert y>=65,'Guide page overflow'
        draw(44,32,9,'F1','Source-first analysis / 22 November 2026');draw(540,32,9,'F2',str(number))
        stream=('\n'.join(commands)+'\n').encode('ascii');content=len(objects)+1
        objects.append(b'<< /Length '+str(len(stream)).encode()+b' >>\nstream\n'+stream+b'endstream');page=len(objects)+1
        objects.append(('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents '+str(content)+' 0 R >>').encode());pages.append(page)
    objects[1]=('<< /Type /Pages /Count '+str(len(pages))+' /Kids ['+' '.join(str(p)+' 0 R' for p in pages)+'] >>').encode()
    output=io.BytesIO();output.write(b'%PDF-1.4\n');offsets=[0]
    for i,raw in enumerate(objects,1):offsets.append(output.tell());output.write(str(i).encode()+b' 0 obj\n'+raw+b'\nendobj\n')
    xref=output.tell();output.write(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:output.write(f'{offset:010d} 00000 n \n'.encode())
    output.write(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    (target/'interactive-release.pdf').write_bytes(output.getvalue())
    print('PUBLIC_GUIDE_WRITTEN')
if __name__=='__main__':main()
