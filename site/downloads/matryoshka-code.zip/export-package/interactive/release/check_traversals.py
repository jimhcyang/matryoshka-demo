"""Every ordinary CIB redaction: real workbench link, existing canvas, exact endpoint."""
import json
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from playwright.sync_api import sync_playwright
HERE=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8972/matryoshka-demo/'
def main():
    report=json.loads((HERE/'stage/site/data/report-v6.json').read_bytes());results=[]
    cases=[r['case'] for r in report['cases'] if r['case']['corpus']=='cib' and r['case']['task']=='redaction']
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True);context=browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce');page=context.new_page();errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        for c in cases:
            print(c['case_id'],flush=True)
            page.goto(BASE+'workbench-v6.html?case='+c['case_id']);page.wait_for_selector('[data-testid=quote-view-on-kg]',timeout=90000)
            quotation=page.locator('.exact-quote').filter(has=page.locator('[data-testid=quote-view-on-kg]')).first.locator('blockquote').text_content()
            page.locator('[data-testid=quote-view-on-kg]').first.click();page.wait_for_url('**/graph-full-v6.html?**')
            params={k:v[0] for k,v in parse_qs(urlsplit(page.url).query).items()}
            assert params['walk_case']==c['case_id'] and params['walk_autoplay']=='1'
            page.wait_for_function("() => ['ready','unavailable'].includes(document.querySelector('#saved-kg-walk')?.dataset.status)",timeout=90000)
            assert page.locator('#saved-kg-walk').get_attribute('data-status')=='ready',page.locator('#saved-kg-walk').inner_text()
            assert page.locator('[data-testid=kg-walk-reveal],[data-testid=acknowledge-story-reveal]').count()==0
            steps=page.locator('[data-walk-stage]');states=[]
            for i in range(steps.count()):
                steps.nth(i).click();page.wait_for_function("() => document.querySelector('#saved-kg-walk').getAttribute('aria-busy')==='false'",timeout=90000)
                state=page.evaluate("() => {const h=document.querySelector('#saved-kg-walk'),p=state.panels.current;return {mode:h.dataset.mapStatus,focused:h.dataset.focusedNode||null,selected:p.selected?.id||null,present:h.dataset.focusedNode?p.nodeMap.has(h.dataset.focusedNode):null,canvas:p.canvas.id}}")
                if state['focused']:assert state['focused']==state['selected'] and state['present']
                assert state['mode']!='unavailable',page.locator('.walk-status').inner_text()
                assert state['canvas']=='current-canvas';states.append(state)
            page.wait_for_selector('#study-guide-drawer .source-quotation',timeout=20000)
            popup=page.locator('#study-guide-drawer')
            assert popup.locator('.source-quotation').text_content()==quotation
            assert popup.get_attribute('data-proof-page')==params['walk_source']
            assert popup.get_attribute('data-proof-hash')==params['walk_hash']
            results.append({'case':c['case_id'],'stages':states,'exact_quotation':True,'full_supplied_source':True,'same_canvas':True})
        browser.close()
    assert not errors,errors
    (HERE/'traversal-checks.json').write_text(json.dumps({'cases':results,'errors':errors},indent=2)+'\n');print('Six exact-source CIB traversals passed.')
if __name__=='__main__':main()
