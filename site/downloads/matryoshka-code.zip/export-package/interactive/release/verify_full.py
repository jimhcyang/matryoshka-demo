"""Full installed integrity gate with an in-memory dictionary, not fewer checks."""
import json
from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
REPO=HERE.parents[2]/'matryoshka_demo_site'
sys.path.insert(0,str(REPO/'release-tools/ci'))
import validate_manifest as gate
from fragment_reader import Reader

class MemoryReader(Reader):
    def __init__(self,site,database,**kwargs):super().__init__(site,Path(':memory:'),**kwargs)
    def close(self):self.pieces.cache_clear();self.db.close()

if __name__=='__main__':
    gate.Reader=MemoryReader
    result=gate.validate((HERE/'stage/site').resolve(),HERE/'verification-cache',full=True,repository=REPO.resolve(),minimum_free_bytes=3*1024**3)
    (HERE/'integrity.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='native'}))
