"""Minimize a hash-bound study projection; preserve all arms and exact sources."""
import hashlib
import json
from pathlib import Path
import re
import shutil

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'cib/dto/public-study-complete-v03.json'
SITE=HERE/'stage/site'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
def digest(value):return sha(encoded(value))
def decision(value):
    return {**{k:value[k] for k in ('status','label','scope','reason','needed') if k in value},'native_decision_sha256':digest(value),'public_projection':True}
def candidate(value):
    result={k:value[k] for k in ('id','rank','fill','reading_id','source_wording','ending_utility') if k in value}
    result.update(local_decision=decision(value['local_decision']),sources=value['sources'],
                  citation_union=value.get('citation_union',value['sources']),native_candidate_sha256=digest(value))
    result['source_variants']=[dict(source_wording=v.get('source_wording'),sources=v.get('sources',[]),local_decision=decision(v['local_decision']),native_variant_sha256=digest(v)) for v in value.get('source_variants',[value])]
    return result
def main():
    assert shutil.disk_usage(HERE).free>=3*1024**3
    raw=SOURCE.read_bytes();data=json.loads(raw)
    assert data['version']=='cib-delegation-public-study/1' and len(data['cases'])==8
    assert data['origin']['entire_origin_excluded'] and data['design']['unknown_gold']
    out={k:data[k] for k in ('version','title','completeness','design','trace_policy','variants')}
    out['projection']={'source_ref':{'path':SOURCE.relative_to(HERE.parents[1]).as_posix(),'sha256':sha(raw)},'all_input_arms_preserved':True,'native_decisions_or_ranks_modified':False,'technical_audits_abbreviated':True}
    out['origin']={k:data['origin'][k] for k in ('document_id','date','canonical_page_id','source_page','release','full_window','input_window_mappings','entire_origin_excluded','eligible_as_corpus_evidence','input_only')}
    out['cases']=[];referenced=set()
    for value in data['cases']:
        row={k:value[k] for k in ('case','position','window_arm','status','execution_performed','execution_ref','gold','reference_answer','scope','facts','inspected_page_count','visible_clue_given','visible_clue_is_corpus_proof','selected_evidence_handoffs','failures') if k in value}
        row['readings']=[dict(reading=r['reading'],candidates=[candidate(c) for c in r['candidates']]) for r in value['readings']]
        row['source_budget']={k:value.get('source_budget',{}).get(k) for k in ('constructor_passage_cap','inspected_page_count','admitted_page_count','selection_profile','allocation_rule')}
        for reading in row['readings']:
            for c in reading['candidates']:
                for p in c['sources']+c['citation_union']+[p for v in c['source_variants'] for p in v['sources']]:referenced.add(p['canonical_page_id'])
        out['cases'].append(row)
    out['source_pages']={key:data['source_pages'][key] for key in sorted(referenced)}
    for row in out['cases']:
        for r in row['readings']:
            for c in r['candidates']:
                for proof in c['sources']+c['citation_union']:
                    p=out['source_pages'][proof['canonical_page_id']]
                    assert p['document_id']!=out['origin']['document_id'] and p['date']<row['case']['date']
                    assert p['document_id']==proof['document_id'] and p['date']==proof['date']
                    assert digest(p['text'])==proof['page_sha256']==p['source_sha256']
                    assert p['text'][proof['start']:proof['end']]==proof['text']
    rendered=encoded(out)+b'\n'
    assert not any(t in rendered for t in (b'/Users/',b'OPENAI_API_KEY=',b'Bearer '))
    target=SITE/'delegation-study-data.json';target.write_bytes(rendered)
    html=SITE/'swedish-study.html';text=html.read_text()
    text,count=re.subn(r'(name="study-data-sha256" data-file="delegation-study-data.json" content=")[a-f0-9]{64}',r'\g<1>'+sha(rendered),text)
    assert count==1;html.write_text(text)
    receipt=dict(version='delegation-public-projection/1',source_sha256=sha(raw),public_sha256=sha(rendered),bytes=len(rendered),cases=len(out['cases']),selected_source_pages=len(out['source_pages']),all_arms_preserved=True,proofs_replayed=True)
    (HERE/'study-projection.json').write_bytes(encoded(receipt)+b'\n');print(json.dumps(receipt))
if __name__=='__main__':main()
