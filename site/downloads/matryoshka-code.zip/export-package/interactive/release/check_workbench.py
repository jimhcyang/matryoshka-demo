"""Behavior checks use Playwright's managed headless shell only."""
import json
import os
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE=Path(__file__).resolve().parent
BASE=os.environ.get('INTERACTIVE_PREVIEW','http://127.0.0.1:8972/matryoshka-demo/')
CASES=['narrative_cib_revision_50e63144067940b5debe3fea',
       'narrative_cib_revision_ac39b62cbc7070a340c5d62d',
       'fullresume_iran_two_roles_m_v03_e51b40d8265237f1',
       'iran_factual_h_9b61144cb419baafa343']

def run():
    results=[]
    cases=CASES
    if '--all' in sys.argv:
        report=json.loads((HERE/'stage/site/data/report-v6.json').read_bytes())
        cases=[row['case']['case_id'] for row in report['cases']]
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True)
        context=browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce')
        context.route('**/*',lambda r:r.continue_() if r.request.url.startswith(BASE.split('/matryoshka-demo/')[0]) or r.request.url.startswith('data:') else r.abort())
        page=context.new_page()
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        for case in cases:
            print('Checking '+case,flush=True)
            page.goto(BASE+'workbench-v6.html?case='+case,wait_until='domcontentloaded')
            page.wait_for_function("() => document.querySelector('[data-testid=evidence-map]') || document.querySelector('#diffusion-v6')?.dataset.status==='unavailable' || !document.querySelector('#page-error')?.hidden",timeout=90000)
            assert page.locator('[data-testid=evidence-map]').count(),page.locator('#case-view').inner_text()[-2000:]
            assert page.locator('#page-error').is_hidden(),page.locator('#page-error').inner_text()
            assert page.locator('.workflow-nav').inner_text().startswith('01\nInput\n02\nFacts')
            assert page.get_by_text('Open saved result',exact=True).count()==0
            assert page.get_by_text('Reveal all story answers',exact=True).count()==0
            assert page.locator('#retrieval-paths-v6 select').count()==0
            fills=page.locator('[data-testid=candidate-card] h3').all_text_contents()
            assert len(fills)==len(set(text.casefold().strip() for text in fills)),'Duplicate visible fills'
            quotes=page.locator('[data-testid=used-source-quote]')
            page.wait_for_selector('[data-testid=used-source-quote]',timeout=60000)
            quotes.first.click()
            page.wait_for_selector('#detail-drawer[open] [data-testid=source-document]',timeout=60000)
            assert page.locator('#detail-drawer .source-document mark').count()>0
            assert page.locator('#detail-drawer .transcript-segment').count()>0
            page.locator('#detail-close').click()
            record={'case':case,'facts':page.locator('[data-testid=plan-atom]').count(),'quotes':quotes.count(),'fills':fills,
                    'map_nodes':page.locator('[data-map-node]').count(),'map_edges':page.locator('.evidence-map-edge').count()}
            if page.locator('[data-testid=focal-mask]').count():
                mask=page.locator('[data-testid=focal-mask]');original=mask.inner_text()
                mask.click();page.wait_for_function("() => document.querySelector('[data-testid=focal-mask]').getAttribute('aria-pressed')==='true'")
                mask=page.locator('[data-testid=focal-mask]');mask.click()
                assert page.locator('[data-testid=focal-mask]').inner_text()==original
                record['reveal_reversible']=True
            results.append(record)
        page.screenshot(path=str(HERE/'workbench-desktop.png'))
        # Verify real navigation, not merely a button that opens an explanation.
        page.locator('[data-testid=quote-view-on-kg]').first.click()
        page.wait_for_url('**/graph-full-v6.html?**',timeout=30000)
        assert 'walk_autoplay=1' in page.url or 'guide_autoplay=1' in page.url
        results.append({'direct_kg_navigation':True,'guide_autoplay':True})
        context.close()
        mobile=browser.new_context(viewport={'width':390,'height':844},reduced_motion='reduce')
        page=mobile.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(BASE+'workbench-v6.html?case='+CASES[0],wait_until='domcontentloaded')
        page.wait_for_selector('[data-testid=evidence-map]',timeout=90000)
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+2'),'Unexpected outer horizontal overflow'
        page.screenshot(path=str(HERE/'workbench-mobile.png'))
        results.append({'mobile_outer_overflow':False,'errors':errors})
        assert not errors,errors
        browser.close()
    (HERE/'workbench-checks.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))

if __name__=='__main__':run()
