"""Two gaps and all preregistered context windows, without model calls."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
HERE=Path(__file__).resolve().parent
BASE='http://127.0.0.1:8972/matryoshka-demo/'
def main():
    data=json.loads((HERE/'stage/site/delegation-study-data.json').read_bytes());results=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True);page=browser.new_page(viewport={'width':1440,'height':1000},reduced_motion='reduce');errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        for c in data['cases']:
            page.goto(BASE+'swedish-study.html?window='+c['window_arm']+'&slot='+c['position'])
            page.wait_for_function("() => document.body.dataset.studyReady==='true' || document.querySelector('[role=alert]')",timeout=30000)
            assert page.locator('[role=alert]').count()==0,page.locator('#study-status').inner_text()
            assert page.get_by_role('tab').count()==2
            assert 'nationality' not in page.locator('.study-intro').inner_text().lower()
            assert page.locator('#query-text mark').count()==1
            assert page.locator('#fact-list li').count()==len(c['facts'])
            expected=next((r['candidates'] for r in c['readings'] if r['candidates']),c['readings'][0]['candidates'] if c['readings'] else [])
            assert page.locator('[data-testid=scoped-candidate] .fill').all_text_contents()==[i['fill'] for i in expected[:5]]
            page.locator('#study-origin').click();page.wait_for_selector('#dialog-body .study-transcription',timeout=10000)
            assert page.locator('#dialog-body mark').count()>0
            page.locator('#dialog-close').click()
            if expected:
                page.locator('[data-testid=inspect-variants]').first.click();page.wait_for_selector('#dialog-body .study-transcription mark',timeout=10000)
                assert page.locator('#dialog-body [role=alert]').count()==0
                page.locator('#dialog-close').click()
            results.append({'window':c['window_arm'],'slot':c['position'],'status':c['status'],'fills':[i['fill'] for i in expected[:5]],'origin_verified':True,'source_verified':bool(expected)})
        page.set_viewport_size({'width':390,'height':844});page.reload();page.wait_for_function("() => document.body.dataset.studyReady==='true'")
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+2')
        page.screenshot(path=str(HERE/'study-mobile.png'));assert not errors,errors;browser.close()
    (HERE/'study-checks.json').write_text(json.dumps({'results':results,'errors':errors,'mobile_no_overflow':True},indent=2)+'\n')
    print(json.dumps(results,indent=2))
if __name__=='__main__':main()
