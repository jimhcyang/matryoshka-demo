"""Prepare the motion/password patch without re-exporting native results."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import zipfile
import io

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REPO=ROOT/'matryoshka_demo_site'
SITE=HERE/'stage/site'
OLD=REPO/'site'
sys.path.insert(0,str(HERE.parent/'kg_patch_20261122/release'))
from code_snapshot import unpack,make_zip,replace,tree_sha
sys.path.insert(0,str(REPO/'release-tools/ci'))
import validate_manifest as gate

def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()
def load(path):return json.loads(path.read_bytes())
def write(path,value):
    raw=encoded(value)+b'\n';assert shutil.disk_usage(HERE).free-len(raw)>=3*1024**3
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
def extend_bundle():
    prior=load(OLD/'downloads/matryoshka-code-manifest.json')
    files=unpack((OLD/'downloads/matryoshka-code.zip').read_bytes(),prior)
    assert tree_sha(files,prior.get('excluded_corpus_derived_inputs',[]))==prior['backend_tree_sha256']
    for path in SITE.iterdir():
        if path.suffix in {'.js','.css','.html'}:replace(files,'interactive/site/'+path.name,path.read_bytes())
    for folder in ('live','motion'):
        for path in (HERE/folder).glob('*.py'):
            replace(files,'interactive/'+folder+'/'+path.name,path.read_bytes())
    # This is the new server extension, not a replacement historical engine.
    for path in (HERE/'live').glob('*.py'):
        replace(files,'backend/phase/motion_login_20261122/live/'+path.name,path.read_bytes())
    for path in HERE.glob('*.py'):
        replace(files,'interactive/release/'+path.name,path.read_bytes())
    for name in ('CONTRACT.md','README.md'):replace(files,'interactive/live/'+name,(HERE/'live'/name).read_bytes())
    replace(files,'interactive/README.txt',(SITE/'docs/interactive-release.txt').read_bytes())
    if (HERE/'browser_smoke.py').is_file():
        smoke=(HERE/'browser_smoke.py').read_bytes()
        for target in ('ci/browser_smoke.py','installed/release-tools/ci/browser_smoke.py'):replace(files,target,smoke)
    new_tree=tree_sha(files,prior.get('excluded_corpus_derived_inputs',[]))
    metadata=dict(prior,files=[],backend_tree_sha256=new_tree,prior_bundle_sha256=sha((OLD/'downloads/matryoshka-code.zip').read_bytes()),
        interactive_extension=True,ordinary_engine_source_modified=False,ordinary_native_outputs_modified=False,
        live_corpus_resources_included=False,private_live_state_included=False,credentials_included=False)
    snapshot=load_json(files.get('backend-source-snapshot.json',b'{}'))
    snapshot.update(tree_sha256=new_tree,prior_tree_sha256=prior['backend_tree_sha256'],canonical=False,
        scope='Historical engine plus new authenticated Live server extension; saved native versions unchanged.')
    snapshot['files']=[dict(target=name,source='SOURCE_ROOT/'+name,sha256=sha(raw)) for name,raw in sorted(files.items()) if name.startswith('backend/')]
    replace(files,'backend-source-snapshot.json',encoded(snapshot))
    raw,rows=make_zip(files);metadata['files']=rows
    (SITE/'downloads/matryoshka-code.zip').write_bytes(raw);write(SITE/'downloads/matryoshka-code-manifest.json',metadata)
    return dict(path='downloads/matryoshka-code.zip',sha256=sha(raw),bytes=len(raw),code_only=True,
                manifest_path='downloads/matryoshka-code-manifest.json',manifest_sha256=sha((SITE/'downloads/matryoshka-code-manifest.json').read_bytes()),source_backend_tree_sha256=new_tree)
def load_json(raw):return json.loads(raw)
def prepare():
    assert shutil.disk_usage(HERE).free>=3*1024**3
    baseline=load(HERE/'baseline.json');assert sha((OLD/'release-manifest.json').read_bytes())==baseline['manifest_sha256']
    assert (SITE/'data/report-v6.json').read_bytes()==(OLD/'data/report-v6.json').read_bytes()
    for name in ('data/api-index.json','runtime/public-runtime.js','data/dataset-delivery.json'):
        if (OLD/name).exists():assert (SITE/name).read_bytes()==(OLD/name).read_bytes(),name
    if (SITE/'release-manifest.json').exists():
        prior=(SITE/'release-manifest.json').read_bytes();archive=HERE/'prepared-history'/sha(prior)
        archive.mkdir(parents=True,exist_ok=False);(archive/'release-manifest.json').write_bytes(prior)
        shutil.copyfile(HERE/'prepared.json',archive/'prepared.json')
        (SITE/'release-manifest.json').unlink()
    bundle=extend_bundle();receipt=load(SITE/'export-lineage.json')
    receipt.update(code_bundle=bundle,backend_code_sha256=bundle['source_backend_tree_sha256'],publish_authorized=False,privacy_approval_inherited=False,release_qualified=False)
    receipt['motion_login_release']=dict(version='motion-and-password-diagnostic-release/1',date='2026-11-22',
        ordinary_native_outputs_modified=False,ordinary_data_and_alias_bindings_changed=False,
        graph_motion='DISPLAY_ONLY_TIME_BASED_DENSE_LAYOUT',ineligible_display=['show','dim','hide'],
        aggregate_weights='OPTIONAL_TECHNICAL_FIELDS',live='SERVER_PASSWORD_LOGIN_NOT_CLIENT_API_KEY_RECONSTRUCTION',
        new_api_calls=0,public_paid_backend_deployed=False,new_research_gates_claimed_passed=False)
    write(SITE/'export-lineage.json',receipt)
    publication=load(SITE/'publication.json');publication.update(publish_authorized=False,privacy_approval_inherited=False,release_qualified=False,motion_login_release=receipt['motion_login_release'])
    publication['files']=[r for r in gate.inventory(SITE) if r['path']!='publication.json'];write(SITE/'publication.json',publication)
    for path in SITE.rglob('*.html'):gate.Dependencies(SITE,path).feed(path.read_text())
    manifest=gate.make(SITE,receipt)
    write(HERE/'prepared.json',dict(version='motion-login-release-prepared/1',manifest_sha256=sha((SITE/'release-manifest.json').read_bytes()),
        source_report_ref=manifest['source_report_ref'],backend_tree_sha256=manifest['backend_snapshot']['tree_sha256'],
        source_data_index_sha256=manifest['api_index']['sha256'],native_outputs_modified=False,datasets_copied=False,files=len(manifest['files'])))
    print(json.dumps(load(HERE/'prepared.json')))
def install():
    prepared=load(HERE/'prepared.json');assert sha((SITE/'release-manifest.json').read_bytes())==prepared['manifest_sha256']
    approval=load(HERE/'release-approval/approval_ref.json');record=load(HERE/'release-approval'/approval['path'])
    assert record['candidate_manifest_sha256']==prepared['manifest_sha256'] and record['publish_authorized']
    gate.authorize(SITE,HERE/'release-approval/approval_ref.json')
    assert sha((OLD/'release-manifest.json').read_bytes())==load(HERE/'baseline.json')['manifest_sha256'],'Installed release changed during staging'
    for path in SITE.rglob('*'):
        if path.is_file():
            target=OLD/path.relative_to(SITE);target.parent.mkdir(parents=True,exist_ok=True)
            if not target.exists() or sha(target.read_bytes())!=sha(path.read_bytes()):shutil.copyfile(path,target)
    for path in (HERE/'release-approval').iterdir():
        if path.is_file():shutil.copyfile(path,REPO/'release'/path.name)
    shutil.copyfile(HERE/'browser_smoke.py',REPO/'release-tools/ci/browser_smoke.py')
    print('INSTALLED_EXACT_AUTHORIZED_SITE_NO_DATASET_COPIES')
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['prepare','install']);args=parser.parse_args()
    (prepare if args.action=='prepare' else install)()
