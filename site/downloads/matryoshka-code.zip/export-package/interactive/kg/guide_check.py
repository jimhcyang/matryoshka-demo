"""Replay one indexed, source-pinned CIB guide on the actual shared KG canvas."""
import json
import os
import shutil
from pathlib import Path
from urllib.parse import parse_qs, urlencode
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
BASE = os.environ.get('KG_PREVIEW', 'http://127.0.0.1:8972/matryoshka-demo/')
assert shutil.disk_usage(ROOT).free >= 3 * 1024**3, 'Stop below 3 GiB free'
index = json.loads((ROOT.parent / 'stage/site/data/api-index.json').read_text())
key = next(key for key in index['entries'] if key.startswith('/api/current/guide-v6?candidate_id=a1&case_id=narrative_cib_') and '&config=llm_readings&' in key)
query = {key: values[0] for key, values in parse_qs(key.split('?', 1)[1], keep_blank_values=True).items()}
params = {'corpus': 'cib', 'guide_autoplay': '1'}
for source, target in {'case_id': 'guide_case', 'config': 'guide_arm', 'reading': 'guide_reading', 'candidate_id': 'guide_candidate', 'route_index': 'guide_route', 'resource_id': 'resource_id', 'registry_sha256': 'registry_sha256', 'index_sha256': 'index_sha256'}.items():
    params[target] = query[source]
result = {'case_id': query['case_id'], 'indexed_saved_route': True}

try:
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        context = browser.new_context(viewport={'width': 1440, 'height': 1000}, reduced_motion='reduce')
        context.route('**/*', lambda route: route.continue_() if route.request.url.startswith(BASE.split('/matryoshka-demo/')[0]) or route.request.url.startswith('data:') else route.abort())
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto(BASE + 'graph-full-v6.html?' + urlencode(params), wait_until='domcontentloaded')
        page.wait_for_function("typeof state!=='undefined' && (state.guideError || state.guidePath?.settledAt || document.querySelector('[data-testid=acknowledge-story-reveal]'))", timeout=90000)
        if page.locator('[data-testid="acknowledge-story-reveal"]').count():
            page.locator('[data-testid="acknowledge-story-reveal"]').click()
        page.wait_for_function("typeof state!=='undefined' && (state.guideError || state.guidePath?.settledAt)", timeout=90000)
        result['initial'] = page.evaluate("""() => ({error:state.guideError||state.guidePath?.error,playing:state.guidePath?.playing,index:state.guidePath?.index,steps:state.guidePath?.steps.length,canvas:state.panels.current.canvas.id,binding:refreshBinding.graph_run_id,routeBinding:state.guidePath?.packet.resource_binding?.graph_id,badge:document.querySelector('#guide-route-provenance-v65')?.textContent})""")
        assert not result['initial']['error'], result
        assert result['initial']['playing'], result
        assert result['initial']['canvas'] == 'current-canvas'
        assert result['initial']['binding'] == result['initial']['routeBinding']
        page.wait_for_function('state.guidePath.index>0 && !state.guidePath.busy', timeout=30000)
        result['advanced_without_click'] = page.evaluate('state.guidePath.index')
        citation = page.evaluate("""() => {
          pauseGuide();const c=state.guidePath.packet.candidate.sources.find(c=>c.canonical_page_id&&c.page_sha256&&Number.isInteger(c.start)&&Number.isInteger(c.end));
          return c?{guide_source:c.canonical_page_id,guide_hash:c.page_sha256,guide_start:c.start,guide_end:c.end}:null;
        }""")
        assert citation, 'No exact indexed source handoff'
        # Replay the exact workbench handoff shape, including quote coordinates and hash.
        params.update(citation)
        page.goto(BASE + 'graph-full-v6.html?' + urlencode(params), wait_until='domcontentloaded')
        page.wait_for_function("typeof state!=='undefined' && (state.guideError || state.guidePath?.settledAt)", timeout=90000)
        assert page.evaluate('!state.guideError && !state.guidePath.error && state.guidePath.playing')
        page.evaluate('pauseGuide()')
        page.evaluate("async () => {const g=state.guidePath;await activateGuideStep(g.steps.findIndex(s=>s.type==='source'));}")
        result['quoted_span_exact'] = page.evaluate("""() => {
          const c=state.guidePath.handoffCitation,mark=document.querySelector('.source-quotation'),drawer=document.querySelector('#study-guide-drawer');
          return mark?.textContent===c.text&&drawer.dataset.proofHash===c.page_sha256&&Number(drawer.dataset.proofStart)===c.start&&Number(drawer.dataset.proofEnd)===c.end;
        }""")
        assert result['quoted_span_exact']
        result['postrun_label_guard'] = page.evaluate("guideRouteBadgeV65({postrun_view:true,route:{route_kind:'POSTRUN_GRAPH_VIEW'}}).kind==='postrun_inspection'")
        assert result['postrun_label_guard']
        result['page_errors'] = errors
        assert not errors, errors
        page.screenshot(path=str(ROOT / 'guide-source-desktop.png'))
        context.close()
        browser.close()
finally:
    assert shutil.disk_usage(ROOT).free >= 3 * 1024**3, 'Stop below 3 GiB free'
    (ROOT / 'guide-results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
