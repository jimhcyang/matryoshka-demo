"""KG-only checks on the shared preview; managed headless shell, no model calls."""
import json
import os
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
URL = os.environ.get('KG_PREVIEW', 'http://127.0.0.1:8972/matryoshka-demo/')
RESULTS = {}


def space_guard():
    assert shutil.disk_usage(ROOT).free >= 3 * 1024**3, 'Stop below 3 GiB free'


GEOMETRY = """() => {
  const p=state.panels.current, nodes=p.nodes.map(n=>({...p.screen(n),r:p.nodeRadius(n),id:n.id}));
  let nodeOverlap=0,labelOverlap=0,labelNodeOverlap=0;
  for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++)if(Math.hypot(nodes[i].x-nodes[j].x,nodes[i].y-nodes[j].y)<nodes[i].r+nodes[j].r-.6)nodeOverlap++;
  const stage=p.canvas.getBoundingClientRect(),labels=[...p.labelButtons].map(([id,b])=>{const r=b.getBoundingClientRect();return {id,x:r.x-stage.x,y:r.y-stage.y,w:r.width,h:r.height};});
  for(let i=0;i<labels.length;i++){
    const a=labels[i];
    for(let j=i+1;j<labels.length;j++){const b=labels[j];if(a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y)labelOverlap++;}
    for(const n of nodes)if(Math.hypot(n.x-Math.max(a.x,Math.min(n.x,a.x+a.w)),n.y-Math.max(a.y,Math.min(n.y,a.y+a.h)))<n.r-.6)labelNodeOverlap++;
  }
  return {nodes:nodes.length,labels:labels.length,nodeOverlap,labelOverlap,labelNodeOverlap,scale:p.transform.scale};
}"""


def geometry(page, name):
    page.wait_for_timeout(700)
    value = page.evaluate(GEOMETRY)
    RESULTS[name] = value
    assert value['nodeOverlap'] == 0, (name, value)
    assert value['labelOverlap'] == 0, (name, value)
    assert value['labelNodeOverlap'] == 0, (name, value)


def run():
    space_guard()
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        context = browser.new_context(viewport={'width': 1440, 'height': 1000}, reduced_motion='reduce')
        # Only the shared isolated loopback preview may be contacted.
        context.route('**/*', lambda route: route.continue_() if route.request.url.startswith(URL.split('/matryoshka-demo/')[0]) or route.request.url.startswith('data:') else route.abort())
        page = context.new_page()
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto(URL + 'graph-full-v6.html?corpus=cib', wait_until='domcontentloaded')
        page.wait_for_function("typeof state !== 'undefined' && state.panels.current?.nodes.length > 0", timeout=90000)
        page.wait_for_function("typeof slotOverlayState !== 'undefined' && slotOverlayState.payload", timeout=90000)
        assert page.locator('[data-eligibility-style="show"]').count() == 0
        assert page.locator('[data-redactions]').count() == 2
        geometry(page, 'desktop_overview')
        page.evaluate("state.panels.current.openInspector(state.panels.current.nodes[0])")
        assert page.locator('#current-inspector .map-detail-disclosure').count() == 0
        assert page.locator('#current-inspector .incident-neighborhood').count() > 0
        RESULTS['inspector_immediate'] = True
        page.evaluate("state.panels.current.closeInspector(false)")
        # Exercise a real saved Community without copying or changing its data.
        RESULTS['real_community'] = page.evaluate("""async () => {
          const p=state.panels.current;await ensureHierarchyCatalog(p.view,'community');
          const community=[...p.levelRows('community')].sort((a,b)=>b.mass-a.mass)[0];
          await ensureCommunityDetail(p.view,community);
          p.level='evidence';p.trail=[community];p.nodeLimit=32;p.neighborhood=null;p.refreshGraph();
          return {id:community.id,available:p.graph.availableNodeCount,shown:p.nodes.length,slots:p.nodes.filter(n=>n.overlay_slot).length,audit:p.graph.selectionAudit};
        }""")
        assert RESULTS['real_community']['shown'] == 32
        assert RESULTS['real_community']['slots'] < 32
        geometry(page, 'community_32')
        page.evaluate("state.panels.current.setNodeCap(256)")
        geometry(page, 'community_256')
        # Zoom and synthetic display-only hole perturbation, not source data edits.
        RESULTS['compaction'] = page.evaluate("""() => {
          const p=state.panels.current;const extent=()=>Math.max(...p.nodes.map(n=>Math.hypot(n.x,n.y)));
          p.nodes.forEach(n=>{n.x*=2;n.y*=2;});const expanded=extent();
          p.selected=null;p.labelOverrides.clear();p.compactLayout({immediate:true});
          const compact=extent();const ids=p.nodes.map(n=>n.id).join('|');
          p.wheel({preventDefault(){},deltaY:-350,clientX:p.canvas.getBoundingClientRect().x+p.width/2,clientY:p.canvas.getBoundingClientRect().y+p.height/2});
          return {expanded,compact,idsUnchanged:ids===p.nodes.map(n=>n.id).join('|')};
        }""")
        assert RESULTS['compaction']['compact'] < RESULTS['compaction']['expanded'] * .8
        assert RESULTS['compaction']['idsUnchanged']
        geometry(page, 'zoom_compacted')
        RESULTS['ordinary_neighborhood'] = page.evaluate("""async () => {
          const p=state.panels.current,node=p.nodes[0];await p.focusNeighborhood(node,{scroll:false});p.setNodeCap(32);
          return {id:node.id,available:p.graph.availableNodeCount,shown:p.nodes.length,pinned:p.nodes[0].id===node.id};
        }""")
        assert RESULTS['ordinary_neighborhood']['pinned']
        geometry(page, 'ordinary_neighborhood_32')
        page.evaluate("state.panels.current.setNodeCap(256)")
        geometry(page, 'ordinary_neighborhood_256')
        RESULTS['focus_drag_bands'] = page.evaluate("""() => {
          const p=state.panels.current,n=p.nodes.find(n=>n.orbitBand!==undefined),other=p.nodes.find(m=>m!==n&&m.orbitBand===n.orbitBand);
          if(!n||!other)return true;
          n.x=other.x;n.y=other.y;p.resolveFocusCollisions(n);p.draw();
          return p.nodes.filter(n=>n.orbitBand!==undefined).every(n=>{const band=p.focusBands.find(b=>b.index===n.orbitBand),r=Math.hypot(n.x,n.y);return r>=band.inner-.1&&r<=band.outer+.1;});
        }""")
        assert RESULTS['focus_drag_bands']
        geometry(page, 'focus_drag_collision')
        RESULTS['selection_integration'] = page.evaluate("""() => {
          const native=Array.from({length:80},(_,i)=>({id:'fixture-node-'+i,type:i%2?'Entity':'Claim',community_id:'fixture-community',theme_id:'fixture-theme'}));
          const slots=Array.from({length:40},(_,i)=>({id:'fixture-slot-'+i,overlay_slot:true,semantic:false,canonical_page_id:'fixture-page-'+i}));
          const edges=native.slice(1).map((n,i)=>({id:'fixture-edge-'+i,source:native[i].id,target:n.id,weight:1}));
          const context=slots.map((n,i)=>({id:'fixture-context-'+i,source:n.id,target:native[0].id,weight:0,layout_weight:0,semantic:false,eligible_evidence:false,slot_navigation:true}));
          slots.forEach((slot,i)=>{slot.anchors=[native[0]];slot.context_links=[context[i]];});
          const all=[...slots,...native],topology=[...context,...edges];
          const p=Object.create(GraphPanel.prototype);
          Object.assign(p,{view:{key:'fixture',levels:{evidence:{nodes:all,edges:topology}}},level:'evidence',trail:[{type:'Community',id:'fixture-community',member_nodes:all,member_edges:topology}],nodeLimit:32,neighborhood:null,selected:null,external:null,slotFocusId:'fixture-slot-39',pinnedFocusIds:new Set(['fixture-slot-39','fixture-node-79']),pinnedSearchRecords:new Map(),inducedNeighborEdges:[],showNeighborEdges:true});
          const community=p.graphSelection();
          const savedRows=slotOverlayState.rows;slotOverlayState.rows=new Map(slots.map(slot=>[slot.id,slot]));
          p.neighborhood={node:native[0],neighbors:[...slots,...native.slice(1)],edges:topology,slot_context:{ids:slots.map(slot=>slot.id)}};
          let incident;try{incident=p.graphSelection();}finally{slotOverlayState.rows=savedRows;}
          return {community:community.nodes.length===32&&community.nodes[0].id==='fixture-slot-39'&&community.nodes[1].id==='fixture-node-79'&&community.nodes.filter(n=>n.overlay_slot).length<=4,
            incident:incident.nodes.length===32&&incident.nodes[0].id==='fixture-node-0'&&incident.nodes[1].id==='fixture-slot-39'&&incident.selectionAudit.trace[1].components.semanticReach===0};
        }""")
        assert all(RESULTS['selection_integration'].values())
        # The actual opaque-source path validates page pins and exact code-point spans.
        RESULTS['real_slot_source'] = page.evaluate("""async () => {
          const packet=await slotPacket({limit:1});const slot=packet.slot||packet.slots[0];
          if(!slot)throw Error('No saved slot fixture available');
          const p=state.panels.current;p.slotFocusId=slot.id;await p.focusNeighborhood(slot,{scroll:false});p.setNodeCap(32);
          const trace=p.graph.selectionAudit.trace[0];
          const proof=slot.context_links[0]?.source_proof||null;
          await openOpaqueSlotSource(slot,proof);
          const source=await ensureOpaqueSlotPage(slot),chars=Array.from(source.text);
          const mark=document.querySelector('[data-focal-opaque-slot]');
          const term=document.querySelector('[data-visible-context-term]');
          const result={pinned:trace.id===slot.id&&trace.reason==='pinned focus',zeroSemanticReach:trace.components.semanticReach===0&&trace.components.semanticExpansion===0,
            markerExact:mark?.textContent===chars.slice(slot.marker_start,slot.marker_end).join(''),termExact:!proof||term?.textContent===proof.text,sourceCount:document.querySelectorAll('.slot-source-page').length};
          closeCibSource();return result;
        }""")
        assert all(RESULTS['real_slot_source'].values())
        geometry(page, 'slot_neighborhood_32')
        # Real exact-source excerpt and opaque marker helper, including substring exclusions.
        RESULTS['source_literals'] = page.evaluate("""() => {
          const q='Observed [REDACTED] context.';
          return highlightedSourceText(q,[q])==='<mark>'+q+'</mark>' && highlightedSourceText('US USSR us',['US'])==='<mark>US</mark> USSR us';
        }""")
        assert RESULTS['source_literals']
        # Controls must remain independent.
        page.locator('[data-redactions="hide"]').click()
        assert page.evaluate("!slotOverlayState.enabled && state.showIneligible")
        page.locator('#hide-ineligible').click()
        assert page.evaluate("!slotOverlayState.enabled && !state.showIneligible && state.visibilityMode==='dim'")
        page.locator('[data-redactions="show"]').click()
        assert page.evaluate("slotOverlayState.enabled && !state.showIneligible")
        page.locator('[data-eligibility-style="dim"]').click()
        assert page.evaluate("slotOverlayState.enabled && state.showIneligible && state.visibilityMode==='dim'")
        RESULTS['independent_controls'] = True
        # Enter pair mode via the real control, then test dispatch concurrently with stubs.
        page.locator('[data-display-mode="pair"]').click()
        page.wait_for_function("state.displayMode==='pair' && state.panels.legacy.nodes.length>0")
        assert page.locator('[data-back="current"]').is_visible()
        assert page.locator('[data-fit="current"]').is_visible()
        assert page.locator('[data-back="legacy"]').is_visible()
        assert page.locator('[data-fit="legacy"]').is_visible()
        page.evaluate("async () => {await Promise.all(activePanels().map(p=>p.enterNode(p.nodes[0])));}")
        assert page.evaluate("activePanels().every(p=>p.level==='theme')")
        page.locator('[data-back="current"]').click()
        page.wait_for_function("state.panels.current.level==='domain'&&!state.panels.current.v64Busy")
        assert page.evaluate("state.panels.legacy.level==='theme'")
        page.locator('[data-back="all"]').click()
        page.wait_for_function("activePanels().every(p=>p.level==='domain'&&!p.v64Busy)")
        RESULTS['pair_actual_hierarchy_back'] = True
        page.wait_for_timeout(400)
        page.evaluate("""() => {window.fitExpected={};for(const p of activePanels()){p.compactLayout({immediate:true});p.fit();fitExpected[p.name]={...p.transform};p.transform.x+=70;p.transform.y+=40;p.draw();}}""")
        page.locator('[data-fit="all"]').click()
        assert page.evaluate("activePanels().every(p=>Math.abs(p.transform.x-fitExpected[p.name].x)<2&&Math.abs(p.transform.y-fitExpected[p.name].y)<2)")
        page.evaluate("for(const p of activePanels()){p.transform.x+=70;p.transform.y+=40;p.draw();}")
        page.locator('[data-fit="current"]').click()
        assert page.evaluate("Math.abs(state.panels.current.transform.x-fitExpected.current.x)<2&&Math.abs(state.panels.legacy.transform.x-fitExpected.legacy.x-70)<2")
        page.locator('[data-fit="legacy"]').click()
        assert page.evaluate("Math.abs(state.panels.legacy.transform.x-fitExpected.legacy.x)<2")
        RESULTS['pair_actual_shared_local_fit'] = True
        page.evaluate("""() => {
          window.navigationCalls=[];window.originalNav={};
          for(const [name,p] of Object.entries(state.panels)){
            originalNav[name]={back:p.back,fit:p.fit,compactLayout:p.compactLayout,trail:p.trail};
            p.trail=[{id:'test-dispatch'}];
            p.back=async()=>{navigationCalls.push('start:'+name);await new Promise(r=>setTimeout(r,60));navigationCalls.push('end:'+name);};
            p.fit=()=>navigationCalls.push('fit:'+name);p.compactLayout=()=>{};
          }
          document.querySelectorAll('[data-back="current"],[data-back="legacy"]').forEach(button=>button.disabled=false);
          syncPairActions();
        }""")
        page.locator('[data-back="all"]').click()
        page.wait_for_timeout(100)
        calls = page.evaluate('navigationCalls')
        assert [call for call in calls if not call.startswith('fit:')][:2] == ['start:legacy', 'start:current'], calls
        page.evaluate('navigationCalls.length=0')
        page.locator('[data-back="current"]').click()
        page.wait_for_timeout(100)
        assert page.evaluate('navigationCalls') == ['start:current', 'end:current']
        page.evaluate('navigationCalls.length=0')
        page.locator('[data-fit="all"]').click()
        assert page.evaluate('navigationCalls') == ['fit:legacy', 'fit:current']
        page.evaluate('navigationCalls.length=0')
        page.locator('[data-fit="legacy"]').click()
        assert page.evaluate('navigationCalls') == ['fit:legacy']
        RESULTS['pair_dispatch_concurrent_local'] = True
        page.evaluate("for(const [name,p] of Object.entries(state.panels))Object.assign(p,originalNav[name]);")
        page.emulate_media(reduced_motion='no-preference')
        page.evaluate("""() => {const p=state.panels.current;p.nodes.forEach(n=>{n.x*=1.5;n.y*=1.5;});window.expandedExtent=Math.max(...p.nodes.map(n=>Math.hypot(n.x,n.y)));p.compactLayout();}""")
        page.wait_for_function("!state.panels.current.canvas.dataset.settling")
        RESULTS['bounded_animated_compaction'] = page.evaluate("Math.max(...state.panels.current.nodes.map(n=>Math.hypot(n.x,n.y))) < expandedExtent*.9")
        assert RESULTS['bounded_animated_compaction']
        page.emulate_media(reduced_motion='reduce')
        space_guard()
        if os.environ.get('KG_CAPTURE', '1') == '1':
            page.screenshot(path=str(ROOT / 'pair-desktop.png'))
        # Synthetic binding readiness guard for autoplay; do not fabricate a route.
        RESULTS['autoplay_guards'] = page.evaluate("""() => {
          const params=new URLSearchParams('guide_autoplay=1'),saved=state.guidePath;
          const g={steps:[{},{}],index:0,overlay:null,busy:false,error:null,settledAt:1};state.guidePath=g;
          const noOverlay=!startBoundGuideAutoplay(g,params);g.overlay={};g.busy=true;
          const busy=!startBoundGuideAutoplay(g,params);g.busy=false;g.error='unverified';
          const error=!startBoundGuideAutoplay(g,params);state.guidePath=saved;
          return noOverlay&&busy&&error;
        }""")
        assert RESULTS['autoplay_guards']
        context.close()
        mobile = browser.new_context(viewport={'width': 390, 'height': 844}, reduced_motion='reduce')
        mobile.route('**/*', lambda route: route.continue_() if route.request.url.startswith(URL.split('/matryoshka-demo/')[0]) or route.request.url.startswith('data:') else route.abort())
        page = mobile.new_page()
        page.goto(URL + 'graph-full-v6.html?corpus=cib', wait_until='domcontentloaded')
        page.wait_for_function("typeof state !== 'undefined' && state.panels.current?.nodes.length > 0", timeout=90000)
        geometry(page, 'mobile_overview')
        if os.environ.get('KG_CAPTURE', '1') == '1':
            page.screenshot(path=str(ROOT / 'single-mobile.png'))
        mobile.close()
        browser.close()
        RESULTS['page_errors'] = errors
        assert not errors, errors


if __name__ == '__main__':
    try:
        run()
    finally:
        space_guard()
        (ROOT / 'browser-results.json').write_text(json.dumps(RESULTS, indent=2) + '\n')
    print(json.dumps({key: value for key, value in RESULTS.items() if key != 'real_community'}, indent=2))
