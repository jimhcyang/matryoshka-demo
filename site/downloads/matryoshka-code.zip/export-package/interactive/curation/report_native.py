"""Project actual native packets and all paid/parser attempts for integration."""
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from run_native import API, CONFIG, HERE, OUT, ROOT, pin, read, write
from matryoshka_demo.io import digest
from matryoshka_demo.runner_v2 import environment_binding
from matryoshka_narrative import workflow


def receipt_inventory(queries, initial):
    rows = []
    for path in sorted((API / "receipts").glob("*.json")):
        if path.name in initial:
            continue
        receipt = read(path)
        attempt = API / "attempts" / path.stem
        request = read(attempt / "request.json")
        try:
            payload = json.loads(request["input"][0]["content"][0]["text"])
        except (KeyError, IndexError, TypeError, ValueError):
            continue
        if payload.get("query") not in queries:
            continue
        allowed = {"task", "query", "focal_marker", "invalid_response", "validation_error"}
        if set(payload) - allowed:
            raise ValueError("A planning request carried non-public/source fields")
        row = dict(receipt_ref=pin(path), request_ref=pin(attempt / "request.json"),
            query=payload["query"], model=receipt["model"], status=receipt["status"],
            charged_or_reserved_usd=receipt["charged_or_reserved_usd"],
            correction="invalid_response" in payload, query_only_payload_verified=True)
        response = attempt / "response.json"
        if response.exists():
            row["response_ref"] = pin(response)
        rows.append(row)
    return rows


def main():
    source = read(HERE / "case_packets_v02.json")
    authorization = read(OUT / "authorization.json")
    refs = read(ROOT / workflow.native.REFS)
    pins = workflow.code_pins()
    environment = environment_binding(ROOT)
    summaries = []
    for candidate in source["cases"]:
        if candidate["qualification"] != "PENDING_NATIVE_QUALIFICATION":
            continue
        case = candidate["native_case_stub"]
        folder = OUT / "cases" / case["case_id"]
        attempts = [dict(attempt_ref=pin(p), **read(p)) for p in sorted(folder.glob("attempt_*.json"))]
        row = dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"], query=case["query"],
            qualification="PENDING_ACTUAL_RELEASE_QUALIFICATION", release_substitution_authorized=False,
            attempts=attempts, native_execution_completed=False)
        native_path = folder / "native.json.gz"
        if native_path.exists():
            packet = read(native_path)
            saved = read(folder / "planning.json")
            workflow.validate_packet(packet, case, saved["native_plan"], None, pins=pins,
                binding=refs["index_refs"][case["corpus"]], environment=environment,
                settings=workflow.configuration(**CONFIG))
            if packet["native_checksum"] != digest(packet["result"]):
                raise ValueError("Native result checksum changed")
            audit = read(folder / "source_audit.json")
            assert audit["passed"]
            assert audit["excluded_origin_document_ids"] == candidate["excluded_origin_document_ids"]
            assert audit["earliest_origin_date"] == candidate["earliest_origin_date"]
            atoms = []
            support_docs = set()
            for atom in packet["result"].get("atoms", []):
                positive = atom.get("positive_evidence", [])
                negative = atom.get("counterevidence", [])
                partial = atom.get("partial_evidence", [])
                docs = sorted({r["citation"]["document_id"] for r in positive})
                support_docs.update(docs)
                atoms.append(dict(id=atom["id"], text=atom["text"], status=atom["status"],
                    positive_count=len(positive), against_count=len(negative), partial_count=len(partial),
                    positive_document_ids=docs))
            row.update(native_execution_completed=True, native_ref=pin(native_path),
                planning_ref=pin(folder / "planning.json"), source_audit_ref=pin(folder / "source_audit.json"),
                native_status=packet["result"]["status"], atoms=atoms,
                native_positive_count=sum(a["positive_count"] for a in atoms),
                native_against_count=sum(a["against_count"] for a in atoms),
                native_partial_count=sum(a["partial_count"] for a in atoms),
                native_support_document_count=len(support_docs),
                inspected_page_count=len(packet["result"].get("inspected_page_ids", [])),
                inspected_document_count=audit["inspected_document_count"],
                all_diagnostic_citations_replayed=audit["unique_citation_count"],
                diagnostic_citation_count_is_not_case_support=True,
                actual_requirements=packet["result"].get("query_requirements"),
                native_checksum=packet["native_checksum"], canonical_packet_validation_passed=True)
            if not atoms or any(not a["positive_count"] or a["against_count"] for a in atoms):
                row["qualification"] = "NOT_QUALIFIED_NATIVE_SUPPORT_INCOMPLETE_OR_CONFLICTED"
            if candidate["task"] == "mosaic" and len(support_docs) < 2:
                row["qualification"] = "NOT_QUALIFIED_NATIVE_MULTIDOCUMENT_SUPPORT_MISSING"
        elif attempts:
            row["native_status"] = "NOT_EXECUTED_PLANNING_OR_RUNTIME_FAILURE"
            row["last_failure"] = {k:attempts[-1].get(k) for k in ("error_type", "error", "qualification")}
        else:
            row["native_status"] = "NOT_YET_ATTEMPTED"
        summaries.append(row)
    receipts = receipt_inventory({c["query"] for c in summaries}, set(authorization["initial_receipt_names"]))
    cost = round(sum(r["charged_or_reserved_usd"] for r in receipts), 9)
    assert cost <= 3
    report = dict(version="rich-native-integration-report/1", cases=summaries,
        completed_native_executions=sum(c["native_execution_completed"] for c in summaries),
        requested_case_count=len(summaries), new_api_charged_or_reserved_usd=cost,
        shared_ledger_root="experiments/narrative_demo/api", cumulative_cap_usd=50,
        incremental_envelope_usd=3, provider_attempts=receipts,
        source_catalog_coverage_not_native_success=True, canonical_engine_files_modified=False,
        launch_floor_bytes=authorization["guard_floor_bytes"], no_engine_guard_file_edit=True,
        release_substitution_authorized=False, cib_starter_redaction="RETAIN_EXISTING_SALVADOR_ANCHOR",
        corrected_counter_semantics="An early attempt field named qualified_evidence_citation_count counted all replayed diagnostic spans, not qualified support. Use only native_positive_count/native_against_count/native_support_document_count in this report.")
    write(OUT / "native_current.json", report)
    print(json.dumps(dict(report_ref=pin(OUT / "native_current.json"),
        completed_native_executions=report["completed_native_executions"],
        spend=cost, cases=[{k:c.get(k) for k in ("case_id", "native_status", "native_positive_count", "native_against_count", "native_support_document_count", "last_failure")} for c in summaries]), indent=2))


if __name__ == "__main__":
    main()
