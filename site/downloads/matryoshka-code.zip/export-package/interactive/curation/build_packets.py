"""Bounded, fixed-source tests. All outputs stay here; canonical code is read-only.

The only native execution attempted is the unchanged disk preflight. Signed
semantic links below come from candidates.py's disclosed curator review. The
test checks those links' provenance/admissibility, not independent entailment.
"""
from collections import defaultdict
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
DEMO = HERE.parents[2]
ROOT = DEMO.parent
sys.path.insert(0, str(DEMO))
from matryoshka_next import sourcebank as bank
from matryoshka_narrative import guards
from candidates import candidates
from inspect_sources import INDEXES, connect, decode

FLOOR = 3 * 1024**3


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def ref(path):
    path = Path(path)
    return dict(path=str(path.relative_to(ROOT)), sha256=sha(path))


def read(path):
    return json.loads(Path(path).read_text())


def put(name, value):
    path = (HERE / name).resolve()
    if path.parent != HERE:
        raise ValueError("Outputs are restricted to curation")
    if shutil.disk_usage(HERE).free < FLOOR:
        raise OSError("3 GiB floor reached; no substantial writes")
    wire = (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2) + "\n").encode()
    if path.exists():
        if path.read_bytes() != wire:
            raise ValueError(f"Immutable output differs: {path.name}; use a new version")
    else:
        with path.open("xb") as stream:
            stream.write(wire)
    return ref(path)


def exact(text, spec):
    start = text.index(spec["start_anchor"])
    finish = spec["end_anchor"] or spec["start_anchor"]
    end = text.index(finish, start) + len(finish)
    if not 0 <= start < end <= len(text):
        raise ValueError("Invalid half-open source span")
    return dict(start=start, end=end, text=text[start:end],
                quote_utf8_sha256=bank.text_sha(text[start:end]))


def admit(source, cutoff, excluded, corpus):
    reasons = []
    if source["document_id"] in excluded:
        reasons.append("WHOLE_ORIGIN_DOCUMENT_EXCLUDED")
    if not source.get("date") or source["date"] >= cutoff:
        reasons.append("NOT_STRICTLY_BEFORE_EARLIEST_ORIGIN")
    if not source.get("whole_document_policy", {}).get("eligible"):
        reasons.append("WHOLE_SOURCE_POLICY_VETO")
    if corpus != "cib" and source.get("classification") != "CONFIDENTIAL":
        reasons.append("NOT_LOWER_CLASSIFICATION")
    if corpus == "cib" and not source.get("eligible_earlier_view"):
        reasons.append("NOT_PERMITTED_EARLIER_PAIRED_VIEW")
    return reasons


class CableSources:
    def __init__(self, corpus):
        self.corpus = corpus
        self.inputs = bank.Inputs(DEMO)
        folder = "iran_89cdf5130bc937911259" if corpus == "iran" else "vietnam_8ca9868da3a4e1fdbf5a"
        identity = DEMO / "experiments/presentation_refresh/reconstruction/full_source_discovery_v01" / folder / "identity.json"
        self.refs = self.inputs.load(dict(path=str(identity.relative_to(DEMO)), sha256=sha(identity)), "demo")["source_refs"]
        self.raw = {r["id"]: r for r in self.inputs.csv(self.refs["raw"])}
        metadata = {r["local_doc_id"].strip(): r for r in self.inputs.csv(self.refs["metadata"]) if r["corpora"].lower() == corpus}
        docs = {r["document_id"]: r for r in self.inputs.rows(self.refs["documents"])}
        projection = self.inputs.load(self.refs["projection"])["document_metadata"]
        self.pages = defaultdict(list)
        for row in self.inputs.rows(self.refs["canonical"]):
            self.pages[row["document_id"]].append(row)
        self.policies = {did: bank.document_admission(self.raw.get(did, {}), metadata.get(did, {}), projection.get(did, {}), pages, docs.get(did, {})) for did, pages in self.pages.items()}

    def bind(self, spec):
        did = spec["document_id"]
        raw = self.raw[did]
        policy = self.policies[did]
        span = exact(raw["body"], spec)
        segments = []
        for page in self.pages[did]:
            a = max(span["start"], page["source_char_start"])
            b = min(span["end"], page["source_char_end"])
            if a >= b:
                continue
            lo, hi = a - page["source_char_start"], b - page["source_char_start"]
            assert page["text"][lo:hi] == raw["body"][a:b]
            segments.append(dict(source_id=page["segment_id"], document_id=did,
                segment_sequence=page["segment_sequence"], start=lo, end=hi,
                raw_document_start=a, raw_document_end=b, text=page["text"][lo:hi],
                segment_text_utf8_sha256=bank.text_sha(page["text"])))
        assert segments and sum(r["end"] - r["start"] for r in segments) == span["end"] - span["start"]
        return dict(**span, corpus=self.corpus, document_id=did, date=raw["date"],
            event_date=spec.get("event_date"), event_date_is_not_evidence_admission_date=True,
            classification=policy["classification"], handling=policy["handling"],
            whole_document_policy=policy, source_id=[s["source_id"] for s in segments],
            source_segments=segments, coordinate_space="ORIGINAL_FULL_CABLE_BODY_PYTHON_CHARACTERS_HALF_OPEN",
            source_refs=self.refs, all_siblings_replayed=policy["eligible"])

    def exclusions(self, ids):
        hashes = {self.policies[did]["whole_body_sha256"] for did in ids}
        return sorted(set(ids) | {did for did, policy in self.policies.items() if policy["whole_body_sha256"] in hashes})


class CibSources:
    def __init__(self, wanted):
        self.docs = {}
        self.all_docs = []
        documents = ROOT / "src-redaction/data/prepared/documents.jsonl"
        canonical = ROOT / "src-redaction/data/prepared/canonical_pages.jsonl"
        self.source_refs = dict(documents=ref(documents), canonical=ref(canonical))
        with documents.open() as stream:
            for line in stream:
                d = json.loads(line)
                self.all_docs.append(d)
                if d["document_id"] in wanted:
                    self.docs[d["document_id"]] = d
        self.canonical = {}
        with canonical.open() as stream:
            for line in stream:
                page = json.loads(line)
                if page["document_id"] in wanted:
                    self.canonical[page["canonical_page_id"]] = page
        self.db = connect("cib")
        self.siblings = {}
        self.raw_earlier = {}
        raw_path = ROOT / "src-redaction/data/source/corpus/corpus_v3_clean.jsonl"
        self.source_refs["raw"] = ref(raw_path)
        with raw_path.open() as stream:
            for line in stream:
                r = json.loads(line)
                if r["document_id"] in wanted:
                    self.raw_earlier[r["document_id"]] = "\n\n".join(r.get("raw_ocr", {}).get("redacted", []))
        for did in wanted:
            pages = [(pid, eligible, decode(payload)) for pid, eligible, payload in self.db.execute("SELECT id,eligible,payload FROM page WHERE doc=? ORDER BY id", (did,))]
            self.siblings[did] = pages

    def bind(self, spec):
        did, pid = spec["document_id"], spec["page_id"]
        canonical = self.canonical[pid]
        doc = self.docs[did]
        _, eligible, page = next(r for r in self.siblings[did] if r[0] == pid)
        unit_index = spec["unit_index"]
        revealed = unit_index is not None
        if revealed:
            unit = canonical["units"][unit_index]
            assert unit["unit_type"] == "redaction_zone" and unit["slot_ids"]
            assert set(unit["reveal_states"]) & {"revealed", "partially_revealed"}
            text = unit["later_text"]
            view = "LITERAL_LATER_REVEALED_UNIT_TEXT"
        else:
            unit = None
            text = page["text"]
            view = "CURRENT_INDEX_EARLIER_PAGE_TEXT"
        span = exact(text, spec)
        whole_earlier = self.raw_earlier[did]
        combined = whole_earlier + " " + " ".join(p["text"] + " " + " ".join(p.get("handling", [])) for _, _, p in self.siblings[did])
        noforn = bool(bank.NOFORN.search(combined + " " + " ".join(doc.get("distribution_controls", []))))
        earlier = eligible == 1 and page["permitted"] is True and page["visibility"] == "earlier"
        assert page["document_id"] == did and page["date"] == doc["document_date_iso"]
        pdfs = {side: ref(ROOT / "src-redaction" / doc[side + "_pdf"]) for side in ("earlier", "later")}
        # An actual reveal, not a synthetic mask or a visible target beside one.
        novel = revealed and bank.normalize(span["text"]) not in bank.normalize(whole_earlier)
        return dict(**span, corpus="cib", source_id=pid, document_id=did,
            date=doc["document_date_iso"], event_date=spec.get("event_date"),
            event_date_is_not_evidence_admission_date=True,
            classification=doc["classification_level"], classification_note="Original manifest unknown; no lower-classification inference is made for paired CIB sources.",
            whole_document_policy=dict(eligible=not noforn, whole_earlier_text_checked=True, noforn_veto=noforn,
                whole_earlier_text_utf8_sha256=bank.text_sha(whole_earlier), sibling_page_count=len(self.siblings[did])),
            eligible_earlier_view=earlier, coordinate_space=view + "_PYTHON_CHARACTERS_HALF_OPEN",
            source_refs=self.source_refs, earlier_page=canonical["earlier_source_page"], later_page=canonical["later_source_page"],
            page_text_utf8_sha256=bank.text_sha(text), paired_pdfs=pdfs,
            canonical_page_sha256=bank.digest(canonical), unit_index=unit_index,
            unit_sha256=bank.digest(unit) if unit else None,
            authentic_revealed_slot_ids=unit["slot_ids"] if unit else [],
            authentic_target_depends_on_reveal=bool(novel),
            earlier_mask_replays=bool(unit and all(slot in page["text"] for slot in unit["slot_ids"])))

    def exclusions(self, ids):
        selected = [self.docs[did] for did in ids]
        return sorted({d["document_id"] for d in self.all_docs if any(
            d["record_id"].lstrip("0") == s["record_id"].lstrip("0") or
            d["earlier_pdf"] == s["earlier_pdf"] or d["later_pdf"] == s["later_pdf"]
            for s in selected)})


def evaluate(packet):
    cutoff, excluded, corpus = packet["earliest_origin_date"], packet["excluded_origin_document_ids"], packet["corpus"]
    policy_issues = [dict(evidence_index=i, reasons=admit(e, cutoff, excluded, corpus)) for i,e in enumerate(packet["eligible_evidence"]) if admit(e, cutoff, excluded, corpus)]
    component_results = []
    for component in packet["components"]:
        assessments = component["evidence_assessments"]
        allowed = [a for a in assessments if not admit(packet["eligible_evidence"][a["evidence_index"]], cutoff, excluded, corpus)]
        counts = {d: sum(a["direction"] == d for a in allowed) for d in ("FOR", "AGAINST", "CONTEXT")}
        direct_for = [a for a in allowed if a["direction"] == "FOR" and a["strength"] == "direct"]
        if counts["FOR"] and counts["AGAINST"]:
            verdict = "MIXED_DATED_ASSESSMENTS"
        elif direct_for:
            verdict = "CURATOR_MAPPED_SUPPORT_PRESENT"
        elif counts["FOR"]:
            verdict = "PARTIAL_ONLY"
        else:
            verdict = "NO_DECLARED_ELIGIBLE_SUPPORT"
        component_results.append(dict(id=component["id"], verdict=verdict, counts=counts,
            direct_for_count=len(direct_for), semantic_assessment_origin="MANUAL_SOURCE_REVIEW_NOT_ENGINE"))
    supported_docs = {packet["eligible_evidence"][a["evidence_index"]]["document_id"] for c in packet["components"] for a in c["evidence_assessments"] if a["direction"] == "FOR" and not admit(packet["eligible_evidence"][a["evidence_index"]], cutoff, excluded, corpus)}
    provenance_pass = (any(o["classification"] == "SECRET" for o in packet["origins"]) if corpus != "cib" else all(o["authentic_target_depends_on_reveal"] and o["earlier_mask_replays"] for o in packet["origins"]) and packet.get("reveal_dependency_review", {}).get("passed", False))
    mosaic_richness_pass = packet["task"] != "mosaic" or (len(packet["components"]) >= 3 and len(supported_docs) >= 2 and packet["query"].count(".") in (1, 2))
    all_supported = all(r["direct_for_count"] for r in component_results)
    if policy_issues or not provenance_pass or not mosaic_richness_pass:
        verdict = "FAILED_SOURCE_CONTRACT"
    elif any(r["counts"]["AGAINST"] for r in component_results):
        verdict = "BOUNDED_MIXED_NOT_RESOLVED"
    elif all_supported:
        verdict = "BOUNDED_SOURCE_COVERAGE_PRESENT"
    else:
        verdict = "BOUNDED_PARTIAL"
    return dict(case_id=packet["case_id"], task=packet["task"], corpus=corpus,
        method="FIXED_SOURCE_OFFSET_POLICY_TEST_WITH_DISCLOSED_CURATOR_SEMANTIC_MAPPING",
        actual_local_verdict=verdict, native_verdict=None, native_execution=False,
        independent_semantic_entailment_test=False, benchmark_accuracy_claimed=False,
        component_count=len(component_results), component_results=component_results,
        eligible_evidence_document_count=len({e["document_id"] for e in packet["eligible_evidence"] if not admit(e, cutoff, excluded, corpus)}),
        curator_mapped_support_document_count=len(supported_docs), provenance_pass=provenance_pass,
        mosaic_richness_pass=mosaic_richness_pass, policy_issues=policy_issues,
        rejected_evidence_count=len(packet["rejected_evidence"]),
        signed_link_counts={d:sum(r["counts"][d] for r in component_results) for d in ("FOR", "AGAINST", "CONTEXT")},
        note="Counts enumerate reviewed source links, not independent facts, model votes, probabilities or benchmark accuracy. Multiple CIB witnesses may repeat assessments.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--revision", default="")
    args = parser.parse_args()
    if args.revision and not args.revision.isalnum():
        raise ValueError("Alphanumeric revision required")
    suffix = "_" + args.revision if args.revision else ""
    packet_name, result_name = "case_packets" + suffix + ".json", "local_results" + suffix + ".json"
    specs = candidates()
    loaders = {c: CableSources(c) for c in ("iran", "vietnam")}
    wanted = {q["document_id"] for s in specs if s["corpus"] == "cib" for q in s["origins"] + s["evidence"]}
    loaders["cib"] = CibSources(wanted)
    pins = read(DEMO / "experiments/narrative_parallel/coordination/BOARD.json")["starting_epoch"]["resources"]
    resources = {}
    for corpus in INDEXES:
        checksum = sha(DEMO / INDEXES[corpus])
        assert checksum == pins[corpus]["expected_index_sha256"], corpus
        resources[corpus] = dict(pins[corpus], actual_index_sha256=checksum,
                                verified_index_ref=ref(DEMO / INDEXES[corpus]))
    packets, results = [], []
    for spec in specs:
        loader = loaders[spec["corpus"]]
        origins = [loader.bind(q) for q in spec["origins"]]
        cutoff = min(o["date"] for o in origins)
        excluded = loader.exclusions([o["document_id"] for o in origins])
        identity = {k:spec[k] for k in ("key", "corpus", "task", "query")}
        cid = "interactive_rich_20261122_" + spec["key"] + "_" + bank.digest(identity)[:12]
        evidence = [loader.bind(q) for q in spec["evidence"]]
        rejected = []
        for row in spec["rejected_evidence"]:
            source = loader.bind(row["source"])
            reasons = admit(source, cutoff, excluded, spec["corpus"])
            assert reasons, "A rejected source must have a real admission failure"
            rejected.append(dict(source=source, rejection_reasons=reasons,
                intended_component=row["intended_component"], explanation=row["reason"]))
        packet = dict(case_id=cid, **{k:spec[k] for k in ("corpus", "task", "title", "query", "components", "temporal_scope", "attribution", "preference_reason", "limits")},
            activity_provenance="GENERATED_SOURCE_BASED_ANALYST_SIMULATION_MANUALLY_AUTHORED_NOT_REAL_ANALYST_ACTIVITY",
            source_aware_outcome_informed_curation=True, old_queries_rewritten=False,
            resource_ref=resources[spec["corpus"]], origins=origins,
            earliest_origin_date=cutoff, excluded_origin_document_ids=excluded,
            eligible_evidence=evidence, rejected_evidence=rejected,
            evidence_policy=dict(strict_before_earliest_origin=True, whole_origin_excluded=True,
                lower_classification_only=spec["corpus"] != "cib", noforn_whole_document_veto=True,
                cib_earlier_paired_projection_only=spec["corpus"] == "cib", absence_is_not_opposition=True),
            native_case_stub=dict(case_id=cid, corpus=spec["corpus"], task=spec["task"], query=spec["query"],
                document_id=origins[0]["document_id"], date=cutoff, focal_marker=None),
            native_case_stub_not_ready_for_execution=len(origins) > 1,
            native_additional_origins_must_be_bound_before_execution=excluded,
            test_ref=dict(path=result_name, case_id=cid),
            qualification="PENDING_NATIVE_QUALIFICATION", release_substitution_authorized=False)
        if "reveal_dependency_review" in spec:
            packet["reveal_dependency_review"] = spec["reveal_dependency_review"]
            review = spec["reveal_dependency_review"]
            if review["passed"]:
                assert any(review["exact_revealed_anchor"] in o["text"] for o in origins)
        if spec["task"] == "hypothesis":
            packet["proposition"] = spec["query"]
        result = evaluate(packet)
        if result["actual_local_verdict"] == "FAILED_SOURCE_CONTRACT":
            packet["qualification"] = "FAILED_SOURCE_CONTRACT_NO_SUBSTITUTION"
        packets.append(packet)
        results.append(result)
    try:
        guards.require_headroom(HERE)
        native_preflight = dict(attempted=True, passed=True, exception=None)
    except OSError as error:
        native_preflight = dict(attempted=True, passed=False, exception_type=type(error).__name__, exception=str(error),
            native_guard_bytes=guards.MINIMUM_FREE_BYTES, actual_free_bytes=shutil.disk_usage(HERE).free,
            ownership_floor_bytes=FLOOR, engine_guard_changed=False)
    ledger = DEMO / "experiments/narrative_demo/api"
    receipts = [read(p) for p in sorted((ledger / "receipts").glob("*.json"))]
    assert all(r["authorization"] == "narrative-demo-new-phase-50-usd" for r in receipts)
    budget = dict(shared_ledger="src-demo-day/experiments/narrative_demo/api", shared_ceiling_usd=50,
        new_spend_envelope_usd=3, new_api_calls=0, new_api_spend_usd=0,
        shared_charged_or_reserved_snapshot_usd=round(sum(r["charged_or_reserved_usd"] for r in receipts), 9),
        shared_receipt_count_snapshot=len(receipts), separate_budget_created=False, ledger_modified=False)
    audit = dict(version="rich-curation-local-tests/1", generated_utc=datetime.now(timezone.utc).isoformat(),
        results=results, native_preflight=native_preflight, budget=budget,
        native_qualification_pending=True, release_substitution_authorized=False,
        native_blockers=["Unchanged canonical native guard requires 8 GiB; available disk is above the authorized 3 GiB floor but below that guard. No override or canonical edit was made.",
            "No existing exact-query native plan/run is claimed for these manually authored new cases. Prior catalog forecasts are not native verdicts.",
            "Vietnam Mosaic has two whole origins. A one-document native stub must not be run without independently binding both exclusions; fixed-source test already excludes both."],
        retained_failures=[dict(kind="INSPECTOR_SCHEMA_COMPATIBILITY", attempts=1,
            error="sqlite3.OperationalError: no such column: eligible", resolution="Read-only inspector now introspects schema; no database changes."),
            dict(kind="IRAN_FOUR_REACTOR_SCREEN", origin_document_id="1978TEHRAN10103",
                source_clause="Only four power plants would move ahead.", disposition="Not admitted as an evidence-backed component; no earlier eligible four-reactor witness located in the bounded search.",
                forbidden_repair="Do not use earlier SECRET 1978TEHRAN09872 as lower-classification evidence or move the origin date."),
            dict(kind="PRIOR_PROPOSAL_FORECAST_NOT_EXECUTION", references=[
                "src-demo-day/experiments/curation_v65_cables/blue_result_v01.json",
                "src-demo-day/experiments/curation_v65_cib/calls/curation_v65_cib_blue_v01_result.json"],
                disposition="Inspected as source-discovery history, with no transferred recoverability grades or native outcomes.")],
        code_refs=[ref(Path(__file__)), ref(HERE / "candidates.py"), ref(HERE / "inspect_sources.py"), ref(Path(bank.__file__)), ref(Path(guards.__file__))],
        input_refs=[ref(DEMO / "docs/KG_PATCH_RELEASE_20261122.md"), ref(ROOT / "matryoshka_demo_site/site/data/report-v6.json"),
            ref(DEMO / "phase/interactive_release_20261122/PLAN.md")],
        source_replay_method="Unmodified native sourcebank.document_admission for cable whole-body metadata/all-sibling checks; current read-only CIB index and literal paired redaction units for CIB. All quoted coordinates are Python characters [start,end), never PDF pixel offsets.",
        semantic_method="Explicit manually reviewed source-to-component links. The local test recomputes admissibility, exact replay and counts only. It cannot independently certify entailment or produce native rankings.")
    # Snapshot all three in one small run; immutable publication-facing names.
    put(packet_name, dict(version="rich-case-packets/2", cases=packets,
        cib_starter_redaction="RETAIN_EXISTING_SALVADOR_ANCHOR", benchmark_accuracy_claimed=False))
    put(result_name, audit)
    print(json.dumps(dict(cases=[{k:r[k] for k in ("case_id", "actual_local_verdict", "component_count", "eligible_evidence_document_count", "signed_link_counts")} for r in results],
        native_preflight=native_preflight, budget=budget), indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        put("failed_build_" + stamp + ".json", dict(error_type=type(error).__name__, error=str(error),
            generated_utc=stamp, native_execution=False, release_substitution_authorized=False))
        raise
