"""Negative tests for the isolated wire guard and real saved native packets."""
from copy import deepcopy
import unittest

from run_native import API, HERE, read
from literal_copy_planner import PREFIX, PROMPT, bind, canonical, schema
from matryoshka_narrative.api import _output


class LiteralPlannerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        packets = read(HERE / "case_packets_v02.json")["cases"]
        p = next(p for p in packets if "iran_nuclear_m01" in p["case_id"])
        cls.case = p["native_case_stub"]
        saved = read(HERE / "native_literal_v01/cases" / cls.case["case_id"] / "planning.json")
        receipt = saved["isolated_planner_variant"]["attempts"][-1]["receipt"]["receipt"]
        cls.raw = _output(read(API / "attempts" / receipt.split("/")[-1].replace(".json", "") / "response.json"))

    def test_real_wire_and_canonical_bind_pass(self):
        plan = bind(self.case, self.raw)
        self.assertTrue(plan["query_only"])
        self.assertFalse(plan["corpus_read"])
        self.assertFalse(plan["hidden_answers_read"])

    def test_exact_copy_instruction_is_in_actual_prompt(self):
        self.assertTrue(PROMPT.startswith(PREFIX))
        self.assertTrue(PROMPT.endswith(canonical.PROMPT))
        wire = schema(self.case["query"])
        self.assertEqual(wire["properties"]["normalized_query"]["enum"], [self.case["query"]])
        self.assertIn("normalized_query", wire["required"])

    def test_whitespace_case_punctuation_normalization_is_rejected(self):
        for text in (self.case["query"] + " ", self.case["query"].lower(), self.case["query"].replace(".", ";", 1)):
            raw = deepcopy(self.raw)
            raw["normalized_query"] = text
            with self.assertRaisesRegex(ValueError, "exactly equal"):
                bind(self.case, raw)

    def test_unseen_actor_still_fails_canonical_guard(self):
        raw = deepcopy(self.raw)
        raw["atoms"][0]["subject"] = "UNPROVIDED_ACTOR_FOR_NEGATIVE_TEST"
        with self.assertRaises(ValueError):
            bind(self.case, raw)

    def test_changed_atom_fact_is_rejected(self):
        raw = deepcopy(self.raw)
        raw["atoms"][0]["text"] = "Iran abandoned all nuclear safeguards."
        with self.assertRaisesRegex(ValueError, "literal contiguous"):
            bind(self.case, raw)

    def test_dropping_required_propositions_is_rejected(self):
        raw = deepcopy(self.raw)
        for atom in raw["atoms"]:
            atom.update(kind="context", required=False)
        with self.assertRaises(ValueError):
            bind(self.case, raw)

    def test_completed_native_runs_are_not_human_mapping_results(self):
        report = read(HERE / "native_integration_report.json")
        self.assertEqual(report["qualified_case_count"], 0)
        self.assertFalse(report["release_substitution_authorized"])
        self.assertTrue(all(r["attempted"] for r in report["cases"]))
        self.assertLessEqual(report["new_api_charged_or_reserved_usd"], 3)
        self.assertTrue(report["no_budget_reset"])
        self.assertGreaterEqual(report["distinct_cases_executed_natively"], 4)
        for case in report["cases"]:
            for variant in case["variants"]:
                if variant["native_execution_completed"]:
                    self.assertTrue(variant["native_packet_validation_passed"])
                    self.assertEqual(variant["positive_count"], sum(a["positive_count"] for a in variant["atoms"]))
                    self.assertEqual(variant["against_count"], sum(a["against_count"] for a in variant["atoms"]))
                    if case["corpus"] == "cib":
                        self.assertEqual(variant["native_resource_id"], "cib_resource_623c60e1e128944377f0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
