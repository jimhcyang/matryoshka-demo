"""Source-aware POST-RUN diagnosis only; never changes inference or its inputs."""
from collections import Counter
import json
import sys

sys.dont_write_bytecode = True
from run_native import HERE, OUT, pin, read, write


def main():
    source = read(HERE / "case_packets_v02.json")
    rows = []
    for candidate in source["cases"]:
        if candidate["corpus"] != "iran":
            continue
        folder = OUT / "cases" / candidate["case_id"]
        if not (folder / "native.json.gz").exists():
            continue
        native = read(folder / "native.json.gz")
        audit = read(folder / "source_audit.json")
        result = native["result"]
        expected = []
        for evidence in candidate["eligible_evidence"]:
            did = evidence["document_id"]
            diagnostics = [d for d in result["frame_diagnostics"] if d["citation"]["document_id"] == did]
            issues = Counter(i for d in diagnostics for i in d.get("query_issues", []))
            pairs = [p for d in diagnostics for group in d.get("comparisons", []) for p in group]
            matches = Counter(str(p.get("bindings", {}).get("predicate_match")) for p in pairs)
            statuses = {}
            for dimension in ("actor", "attribution", "predicate", "object", "polarity", "time", "modality"):
                counts = Counter(str(p.get("diagnostics", {}).get(dimension, {}).get("status")) for p in pairs)
                if counts:
                    statuses[dimension] = dict(counts)
            expected.append(dict(document_id=did,
                inspected_page_ids=[r["source_id"] for r in audit["inspected_pages"] if r["document_id"] == did],
                native_diagnostic_span_count=len(diagnostics), query_issue_counts=dict(issues),
                diagnostic_predicate_match_counts=dict(matches), diagnostic_dimension_counts=statuses,
                diagnostic_counts_are_not_case_support_or_accuracy=True,
                sample_diagnostics=[dict(atom_id=d["atom_id"], citation=d["citation"], query_issues=d.get("query_issues", [])) for d in diagnostics[:2]]))
        rows.append(dict(case_id=candidate["case_id"], task=candidate["task"], native_ref=pin(folder / "native.json.gz"),
            status=result["status"], source_coverage_diagnosis=expected,
            actual_query_requirements=result["query_requirements"],
            actual_retained_assembly_audit=result.get("retained_8941_certificate_audit"),
            no_human_witness_injection=True))
    diagnosis = dict(version="iran-post-native-diagnosis/1", cases=rows,
        conclusion=[
            "The Mosaic's expected AEOI reorganization witness 1978TEHRAN09464 was not among the 55 inspected pages. This is a retrieval-coverage gap, not disproof of the source.",
            "1978TEHRAN06636 and 1978TEHRAN10054 were inspected, but matching still returned no signed evidence. Saved target diagnostics explicitly include unresolved pronoun/deictic references and required query content not represented by target frames.",
            "The first Mosaic atom combines reorganization with a description of the consent rule. The source's conditional approval formulation is not a literal predicate/role certificate for the generated 'linked parity' formulation.",
            "The second atom names Sullivan and uses 'favored deferring'; the witness expresses the embassy recommendation in first-person language. The native matcher does not automatically turn a signature/footer into a source-owner/speech-act identity certificate. This is an interpretation of the saved source/target frames, not a new supported engine fact.",
            "The saved whole-query scope gate explicitly withholds PUBLIC_CROSS_ATOM_EVENT_OR_CAUSAL_LINK_NOT_CERTIFIED. The introductory 'As' adds scope that a union of independent witnesses cannot certify.",
            "The Hypothesis is an explanatory interpretation of a conditional draft rule, not a matching literal historical role fact. Its run stays UNRESOLVED; no absence is promoted to opposition.",
        ],
        limits="Post-run diagnosis uses the source packet only to identify the predeclared expected witnesses. It neither changes retrieval nor injects them into execution. Diagnostic frame counts are not evaluation accuracy.")
    write(HERE / "iran_native_diagnosis.json", diagnosis)
    print(json.dumps(dict(ref=pin(HERE / "iran_native_diagnosis.json"),
        cases=[dict(case_id=r["case_id"], status=r["status"], witnesses=[dict(document_id=d["document_id"], inspected=bool(d["inspected_page_ids"]), issues=d["query_issue_counts"]) for d in r["source_coverage_diagnosis"]]) for r in rows]), indent=2))


if __name__ == "__main__":
    main()
