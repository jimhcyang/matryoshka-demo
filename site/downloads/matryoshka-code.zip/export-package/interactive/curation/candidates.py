"""Manually authored NEW source-based simulations, not old-query transformations.

Span anchors select unchanged source text. Component assessments are explicit
curator judgments, not model judgments or native-engine outcomes.
"""


def quote(document, start, end=None, *, page=None, unit=None, event_date=None):
    return dict(document_id=document, start_anchor=start, end_anchor=end,
                page_id=page, unit_index=unit, event_date=event_date)


def component(key, text, births, evidence, scope):
    return dict(id=key, text=text, birth_indices=births,
                evidence_assessments=[dict(evidence_index=i, direction=d, strength=s,
                    rationale=r) for i, d, s, r in evidence], scope=scope)


def candidates():
    iran_origin = quote("1978TEHRAN10103", "1.  TAKING INTO ACCOUNT", "SULLIVAN\n")
    iran_admin = quote("1978TEHRAN09464", "1.  ON 30 SEPTEMBER", "IRAN.\n", event_date="1978-09-30")
    iran_terms = quote("1978TEHRAN06636", "A. REPROCESSING MFN", 'SUCH OTHER STAE."', event_date="1978-07-11")
    iran_delay = quote("1978TEHRAN10054", "1.  AS YOUR WILL SEE", "SULLIVAN\n")
    v_rule = quote("1974STATE013407", "3.  ACCORDING TO ARTICLE 27", 'REQUIRED.\n')
    v_withdraw = quote("1974SAIGON01040", "1. FOREIGN MINISTER BAC", "SEES FIT.\n", event_date="1974-01-23")
    v_options = quote("1974SAIGON00868", "2. BECAUSE OF THE OVERWHELMINGLY", "FAVORABLE DECISION.\n", event_date="1974-01-20")
    v_late = quote("1974SAIGON01759", "ASKED WHY GVN DID NOT", "TIME IS APPROPRIATE.\n", event_date="1974-02-14")
    v_march = quote("1974SAIGON02847", "5. DISPUTE OVER THE PARACELS", "ASK YOUR ADVICE.\n")
    c_origin = quote("CIA-RDP79T00975A005500260001-2", "Brigadier Maung Maung,", "for criticizing Burma",
        page="page_471d08643f56fd340ea8", unit=1,
        event_date="1961-01-21 (dated argument); surrounding policy assessed by 1961-02-01")
    c_pressure = quote("CIA-RDP79T00975A005300340001-5", "Senior officers,", 'their popularity. [REDACTED]',
        page="page_6302b21c5a82c57176cf")
    c_restraint = quote("CIA-RDP79T00975A005400160001-4", "Brigadier Maung Maung,", "government affairs.",
        page="page_b8e1fcd54ac2c3df7f63", event_date="1960-11-10 (reported meeting)")
    c_change = quote("CIA-RDP79T00975A005500040001-6", "Senior Burmese Army officers,", 'prime ministership are convincing Ne Win that he should resume office.',
        page="page_81834d9f60224ebcd63a")
    rows = [
        dict(key="iran_nuclear_m01", corpus="iran", task="mosaic",
            title="Nuclear institutions, conditional parity and signature timing",
            query="As Iran reorganized its nuclear administration under the energy ministry, the draft US-Iran agreement linked reprocessing parity to comparable needs and approvals granted to other states after entry into force. Sullivan favored deferring signature until a more propitious political moment.",
            origins=[iran_origin], evidence=[iran_admin, iran_terms, iran_delay], rejected_evidence=[],
            components=[
                component("m1", "Iran placed AEOI under the energy ministry.", [0], [(0,"FOR","direct","The earlier report states AEOI would continue under the Ministry of Power, no longer independently.")], "Institutional subordination, not proof that reorganization caused a negotiating delay."),
                component("m2", "The draft linked comparable-needs reprocessing parity to other states' approvals after entry into force.", [0], [(1,"FOR","direct","The quoted July draft has both the entry-into-force clock and comparable-needs condition.")], "Draft clause, not an effective agreement or a completed reprocessing authorization."),
                component("m3", "Sullivan favored politically timed deferral of signature.", [0], [(2,"FOR","direct","Sullivan explicitly recommends awaiting the most politically propitious time.")], "An embassy policy preference, not proof of an eventual signing date."),
            ],
            temporal_scope="Distinct reported developments through 17 October 1978; no fabricated simultaneous meeting or causal join.",
            attribution="Embassy reporting, negotiated draft text, and Sullivan's recommendation are separate source frames.",
            preference_reason="Connects the administrative, consent-rule and diplomatic-timing constraints in one nuclear negotiation; three substantive components across three earlier documents.",
            limits=["Power/Energy ministry terminology varies in the sources; no assertion of two distinct institutions.", "The four-reactor cap is deliberately not included: no earlier eligible CONFIDENTIAL witness was located in this bounded screen.", "The 6 October SECRET Washington special-contract directive is not eligible lower-classification evidence."]),
        dict(key="iran_nuclear_h01", corpus="iran", task="hypothesis",
            title="Nuclear parity was conditional, not blanket consent",
            query="The proposed US-Iran nuclear agreement's nondiscrimination promise did not amount to unconditional reprocessing consent: comparable Iranian needs and approvals for other states after entry into force still mattered.",
            origins=[quote("1978STATE254667", "5.   BECAUSE THE TWO JAPANESE", "END QUOTE   VANCE\n")],
            evidence=[iran_terms, quote("1978TEHRAN06263", "1.  BAYANDOR,", "END COMMENT.\n")], rejected_evidence=[],
            components=[component("h1", "Nondiscrimination did not erase the draft's temporal and comparable-needs conditions.", [0], [
                (0,"FOR","direct","The actual draft clause conditions parity on later third-country approvals and comparable needs."),
                (1,"FOR","partial","Bayandor relays the prime minister's demand for equal benefits after ratification, while the embassy discusses possible limited research exceptions. This is a negotiating position, not an unconditional authorization."),
            ], "Tests the bounded interpretation of the proposed arrangement, not whether Iran ever received reprocessing permission.")],
            temporal_scope="Draft and negotiating positions before 6 October 1978; not a prediction of subsequent Iranian nuclear activity.",
            attribution="US draft text; Bayandor's clarification of the prime minister's position; Washington's proposed special-contract understanding in the origin.",
            preference_reason="A consent-rule interpretation with explicit conditions, rather than a name/office fact. Earlier diplomatic aspirations remain attributed, not treated as contrary treaty law.",
            limits=["The specific pre-April-1977 contract exception is explicit in the SECRET origin but not independently established by the eligible quotations; do not expand the proposition to claim that exception was already agreed.", "No genuine AGAINST quotation was found in this fixed pool. Equal-treatment demands are not automatically opposition to the conditional proposition."]),
        dict(key="vietnam_paracels_m01", corpus="vietnam", task="mosaic",
            title="China crisis: Security Council hurdle and a legal alternative",
            query="During the January 1974 Paracels crisis, placing the dispute on the UN Security Council's agenda required nine affirmative votes, the GVN withdrew its request for a Council meeting, and it considered taking the dispute to the International Court of Justice.",
            origins=[quote("1974STATE020425", "4.  VIETNAM:", "PARACELS ISSUE.\n"), v_march],
            evidence=[v_rule, v_withdraw, v_options], rejected_evidence=[dict(source=v_late, intended_component="m3", reason="Later than earliest origin, despite being earlier than the March origin; never admitted.")],
            components=[
                component("m1", "Agenda inscription required nine affirmative votes.", [0], [(0,"FOR","direct","The earlier cable explains both the procedural majority and why abstentions do not supply affirmative votes.")], "Procedure for inscription, not a substantive Security Council resolution or veto rule."),
                component("m2", "The GVN withdrew the meeting request.", [0], [(1,"FOR","direct","Bac reports Thieu's midnight instructions and the withdrawal letter.")], "23 January instructions reported on 24 January; not abandonment of the sovereignty claim."),
                component("m3", "The GVN considered taking the dispute to the ICJ.", [1], [(2,"FOR","direct","Bac states consideration while explicitly doubting PRC acceptance of jurisdiction and a favorable decision.")], "Consideration on 20 January, not a referral, acceptance of jurisdiction or successful recovery."),
            ],
            temporal_scope="January 1974 reported procedure/actions/options; no assertion that ICJ consideration began after withdrawal.",
            attribution="US procedural advice and Bac's reports of GVN instructions/options; not court findings.",
            preference_reason="A coherent diplomatic response to a military loss: institutional hurdle, actual withdrawal and still-open legal option. Two SECRET origin documents and three distinct earlier witnesses.",
            limits=["The earliest origin is 31 January, not 5 March. The attractive 15 February source is rejected.", "This is a new source-based simulation, not an observed analyst query or a programmatic rewrite of the earlier two-component case."]),
        dict(key="vietnam_paracels_h01", corpus="vietnam", task="hypothesis",
            title="Military disparity constrained the response to China",
            query="Chinese military superiority made diplomatic and legal pressure, rather than a renewed military bid, the more practicable GVN response to the loss of the Paracels.",
            origins=[v_march], evidence=[v_options, v_late], rejected_evidence=[],
            components=[component("h1", "Military disparity constrained the GVN toward diplomatic/legal options.", [0], [
                (0,"FOR","direct","Bac explicitly says a military solution and even an air counterattack were impractical because of superior Chinese forces, and reports Thieu's diplomatic instructions."),
                (1,"FOR","partial","The February declaration stresses peaceful recovery and says ICJ action is still under study. It corroborates the policy direction, not a successful remedy."),
            ], "Analytical inference from an attributed assessment of feasibility and later stated policy; not a universal assertion that every possible military operation was impossible.")],
            temporal_scope="Historical assessments and options, January-February 1974, known before the 5 March origin; not a prediction that China would never face a challenge.",
            attribution="Bac's 20 January feasibility assessment, GVN spokesmen's 14 February position, and the March briefing's description of US encouragement of peaceful legal avenues.",
            preference_reason="Tests a substantive military-to-diplomatic constraint with direct attributed evidence and a later policy check, without confusing consideration with execution.",
            limits=["No eligible contrary feasibility assessment in the fixed pool; no AGAINST vote from silence.", "The March birth provides the military-expulsion/diplomatic-strategy frame; 'more practicable' is an explicitly generated analytical interpretation, not a verbatim claim by that briefing's author."]),
        dict(key="cib_burma_m01", corpus="cib", task="mosaic",
            title="Civilian rule under army pressure and China constraints",
            query="After Burma returned to civilian rule, senior officers pressed for renewed army intervention, Ne Win resisted their demands, and his restraint extended to avoiding moves offensive to Communist China.",
            origins=[c_origin], evidence=[c_pressure, c_restraint, c_change], rejected_evidence=[],
            components=[
                component("m1", "Senior officers pressed for a return to army intervention.", [0], [(0,"FOR","direct","Officers were reported waiting and planning to take over if the government made a mistake."),(1,"FOR","direct","Maung Maung threatens resignation unless more forceful intervention is allowed."),(2,"FOR","direct","The January bulletin reports persistent pressure and assurances obtained from Ne Win.")], "Reported pressure and plans, not an accomplished takeover."),
                component("m2", "Ne Win had resisted the officers' demands.", [0], [(1,"FOR","direct","Ne Win is reported reluctant to intervene and to have permitted Nu free rein outside army affairs."),(2,"FOR","direct","Even the more interventionist January assessment explicitly records Ne Win's prior resistance since April.")], "A documented historical phase of restraint, not a claim that resistance was unconditional or unchanging."),
                component("m3", "Restraint included avoiding moves offensive to Communist China.", [0], [(1,"FOR","direct","The reported 10 November meeting explicitly joins avoidance of offending Chinese Communists and civilian political leaders.")], "Reported foreign-policy restraint, not pro-Communist allegiance or a completed border-demarcation timetable."),
            ],
            temporal_scope="Reported phases after the 1960 return to civilian rule and before 1 February 1961; the January trend toward intervention is retained, not flattened into permanent restraint.",
            attribution="CIB attributed reporting and analysis; the source cannot independently establish private intentions or all subsequent acts.",
            preference_reason="Three linked forces in the same regime dilemma: officer pressure, a leadership brake and China-related restraint. The authentic revealed passage materially supplies the latter two targets.",
            limits=["The source's April border-demarcation forecast is not asserted by this query.", "Shared origin/topic with the Hypothesis means these are related demonstrations, not independent evaluation samples.", "No new CIB redaction is qualified; Salvador stays the starter anchor."]),
        dict(key="cib_burma_h01", corpus="cib", task="hypothesis",
            title="Was Ne Win still a brake on a second takeover?",
            query="Ne Win remained a substantial brake on a renewed military takeover in Burma despite pressure from senior officers.",
            origins=[c_origin], evidence=[c_restraint, c_change, c_pressure], rejected_evidence=[],
            components=[component("h1", "Ne Win's restraint was still a meaningful barrier to another takeover.", [0], [
                (0,"FOR","direct","The November assessment explicitly records his reluctance and policy of nonintervention despite Maung Maung's demands."),
                (1,"AGAINST","partial","The 5 January assessment explicitly says deterioration was convincing Ne Win he should resume office. This challenges persistence of the brake; it is a dated assessment/forecast, not evidence that a coup occurred."),
                (2,"CONTEXT","contextual","Disgruntled officers' planning establishes pressure, not by itself Ne Win's willingness to intervene."),
            ], "A bounded assessment as of the 1 February origin. The eligible sources leave a real temporal dispute between a November restraint account and a January change-of-mind assessment.")],
            temporal_scope="An early-1961 analytical proposition; evidence dates and assessments stay distinct. No hindsight about any later coup is admitted.",
            attribution="November and January CIB assessments, challenged by a genuinely later revealed origin that is excluded from evidence.",
            preference_reason="Tests whether leadership restraint constrained intervention and preserves an explicit contrary assessment, instead of filling another person's office.",
            limits=["The origin itself cannot resolve the evidence conflict because its whole document is excluded.", "January's possible February/March takeover remains a forecast, not an outcome.", "Bounded assessment must be mixed/temporally uncertain, not unanimously supported."]),
    ]
    rows.append(dict(key="cib_france_visible_only_m01", corpus="cib", task="mosaic",
        title="Failed screen: visible French NATO account",
        query="France obstructed NATO's integrated air-defense and atomic-stockpile programs while seeking allied support for its North African policy. It also decided to withdraw its Mediterranean fleet from its existing NATO status.",
        origins=[quote("CIA-RDP79T00975A004300050001-8", "III. THE WEST", "other NATO members [REDACTED]", page="page_57f967c6c440eb614f80")],
        evidence=[
            quote("CIA-RDP79T00975A004200010001-3", "France has lodged a reservation", "stockpiled in France.", page="page_efcd6750e52d1d73fb5e"),
            quote("CIA-RDP79T00975A004300250001-6", "Premier Debr", "at France's request.", page="page_1ec07edaf0e3e7c8cbdb", event_date="1959-02-06"),
            quote("CIA-RDP79T00975A004300120001-0", "*France-NATO:", 'national interests.', page="page_8d1057bdb441c2d8cda3", event_date="1959-02-27"),
        ], rejected_evidence=[],
        components=[
            component("m1", "France obstructed integrated air-defense and atomic-stockpile projects.", [0], [(0,"FOR","direct","Both reservations/refusals are explicit, with the authentic communications-system mask left opaque.")], "Past NATO obstruction, not evidence of withdrawal from the alliance."),
            component("m2", "France sought allied support for North African policy.", [0], [(1,"FOR","direct","Debre makes fleet status contingent on allied Algerian backing.")], "Attributed French demand."),
            component("m3", "France decided to withdraw the fleet from existing NATO status.", [0], [(2,"FOR","direct","The 28 February bulletin reports the decision while preserving the then-stated effective date.")], "The announcement's expected 2 March effective date is not promoted to an accomplished act; later dates are not silently substituted."),
        ],
        temporal_scope="Reports preceding 9 March 1959; dates of decision and predicted implementation remain separate.",
        attribution="French positions as reported by CIB.",
        preference_reason="Historically rich, but not eligible as a paired-mask target because every birth clause is already shared/visible.",
        limits=["REJECTED: source has no revealed redaction-zone target. Do not repair by inventing a mask or by borrowing an unrelated adjacent reveal."]))
    rows.append(dict(key="cib_burma_h02", corpus="cib", task="hypothesis",
        title="Political costs, not a shortage of army pressure",
        query="Ne Win's reluctance to restore military rule reflected concern about its political costs, not an absence of pressure from senior officers.",
        origins=[c_origin], evidence=[c_restraint, c_change, c_pressure], rejected_evidence=[],
        components=[component("h1", "The reluctance to intervene reflected perceived political costs despite officer pressure.", [0], [
            (0,"FOR","direct","The November account explicitly attributes reluctance to fear of political power corrupting the officer corps while recording Maung Maung's demand for intervention. The broad political-cost interpretation is the curator's, not a quotation."),
            (1,"CONTEXT","contextual","January's change-of-mind assessment is a real caveat about persistence of reluctance, but does not refute the proposed earlier cost mechanism or establish a coup."),
            (2,"CONTEXT","contextual","Senior-officer planning corroborates the existence of pressure, not the motive for resisting it."),
        ], "Bounded explanatory interpretation of reported reluctance. Does not assert identical motives in November and January, a permanent veto, or a specific civilian coalition not attested by the earlier witnesses.")],
        temporal_scope="Reported reluctance and its costs in late 1960/early 1961, before the 1 February origin. Not a forecast of whether another coup would occur.",
        attribution="November CIB attributed fear of officer-corps corruption; the authentic February reveal adds personal distaste and an estimate of civilian rejection. These are distinct assessments, not interchangeable exact speech acts.",
        preference_reason="A more source-revealed explanatory target than the visible general fact of restraint. Examines costs versus pressure without treating a later forecast as opposition to an earlier motive.",
        limits=["The exact revealed claim that civilian politicians would reject a second military government lacks earlier same-mechanism corroboration. The eligible source instead supports the broader political-cost interpretation; do not silently substitute that narrower mechanism.", "January suggests reluctance might be changing; no permanent barrier or subsequent outcome is claimed.", "No AGAINST link is fabricated: a change-of-mind forecast does not directly negate this bounded explanation."]))
    for row in rows:
        if row["corpus"] != "cib":
            continue
        if row["key"] == "cib_burma_m01":
            row["reveal_dependency_review"] = dict(passed=True, assessment_origin="MANUAL_NOT_ENGINE",
                target="m3", exact_revealed_anchor="he will tolerate no action which might interfere with demarcation of the Sino-Burmese border",
                reason="The actual reveal supplies Ne Win's China-related restraint; generic visible discontent/reluctance is only context.")
        elif row["key"] == "cib_burma_h02":
            row["reveal_dependency_review"] = dict(passed=True, assessment_origin="MANUAL_NOT_ENGINE",
                target="h1", exact_revealed_anchor="His refusal has been based on a personal distaste for political office and a shrewd estimate that civilian politicians would not willingly accept a second military government under present circumstances.",
                reason="This motive/cost explanation materially depends on the reveal; earlier support tests the bounded broader interpretation, not the exact civilian-rejection mechanism.")
        else:
            row["reveal_dependency_review"] = dict(passed=False, assessment_origin="MANUAL_NOT_ENGINE",
                target="general restraint" if row["task"] == "hypothesis" else "all components",
                reason="The general target already appears in visible origin context. An authentic nearby reveal alone does not establish target dependency.")
    return rows
