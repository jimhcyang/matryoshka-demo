"""One explicitly requested manual new query, retaining every old case/run."""
from copy import deepcopy
import sys

sys.dont_write_bytecode = True
from build_packets import HERE, bank, evaluate, put, read, ref


def main():
    bundle = read(HERE / "case_packets_v02.json")
    original = next(p for p in bundle["cases"] if "iran_nuclear_m01" in p["case_id"])
    packet = deepcopy(original)
    # New literal authored by the curator; no rewriting/normalizing function is used.
    query = ("AEOI was to continue operations under the Ministry of Power rather than independently, "
        "and the draft nuclear agreement provided that the United States would approve reprocessing "
        "of Iranian spent fuel to meet comparable Iranian needs if the United States has approved "
        "another cooperating state's reprocessing after the agreement's entry into force. "
        "Sullivan argued against pressing ahead with the agreement until a more politically propitious time.")
    cid = "interactive_rich_20261122_iran_nuclear_m02_" + bank.digest(dict(query=query, origins=original["excluded_origin_document_ids"]))[:12]
    packet.update(case_id=cid, query=query, title="Nuclear administration, conditional consent and deferred signature: no temporal join",
        qualification="PENDING_NATIVE_QUALIFICATION", release_substitution_authorized=False,
        native_case_stub=dict(original["native_case_stub"], case_id=cid, query=query),
        test_ref=dict(path="iran_m02_local_result.json", case_id=cid),
        manually_authored_revision=True, programmatic_query_rewriting=False,
        prior_case_id=original["case_id"], prior_case_and_runs_retained=True,
        prior_source_packet_ref=ref(HERE / "case_packets_v02.json"),
        reason_for_revision="Explicit user request: remove the unasserted 'As' temporal/event join while retaining three substantive source-grounded components. No source/role/join checker changes.",
        preference_reason="Prefer this conjunction-only wording for the next test because it does not assert a cross-document temporal/causal link. This is not a claim of improved native performance.")
    packet["components"][0]["text"] = "AEOI was to continue operations under the Ministry of Power rather than independently."
    packet["components"][0]["scope"] = "Preserves the earlier source's prospective 'will continue' formulation, rather than certifying a completed reorganization from that future statement. Ministry of Power/Energy naming differs between origin and witness."
    packet["components"][1]["text"] = "The draft provided conditional reprocessing approval for comparable Iranian needs following other-state approvals after entry into force."
    packet["components"][1]["scope"] = "The proposed clause's conditional consent, not completed Iranian reprocessing or effective entry into force. No deictic pronoun stands in for the approving state."
    packet["components"][2]["text"] = "Sullivan argued against pressing ahead until a politically propitious time."
    packet["limits"] += ["Earlier native run did not retrieve 1978TEHRAN09464. This revision does not inject that document or guarantee retrieval.",
        "The Ministry of Power witness and Ministry of Energy origin are retained as written; no hidden alias or dictionary repair is introduced.",
        "Sullivan attribution still needs native source-owner proof; the signature alone is not assumed to pass that guard."]
    packet["temporal_scope"] = "Independent institutional, draft-consent and timing propositions before 17 October 1978; no 'As' causal/temporal relationship between them."
    bundle["cases"].append(packet)
    bundle["version"] = "rich-case-packets/3"
    bundle["preferred_iran_mosaic_case_id"] = cid
    put("case_packets_v03.json", bundle)
    put("iran_m02_local_result.json", evaluate(packet))
    print(cid)


if __name__ == "__main__":
    main()
