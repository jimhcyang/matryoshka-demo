"""Normal query-only planning and canonical native runs, with local outputs.

The launch configuration mirrors this phase's live/worker.py: the authorized
3 GiB guard is process-local and OUTPUT is redirected. No inference function,
query, source policy, engine source file or budget authorization is changed.
"""
import argparse
from datetime import datetime, timedelta, timezone
import gc
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import sys
import time
import traceback

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WORKSPACE = ROOT.parent
sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
from matryoshka_narrative import guards

FLOOR = 3 * 1024**3
guards.MINIMUM_FREE_BYTES = FLOOR
from matryoshka_narrative import workflow
from matryoshka_narrative.api import Budget
from matryoshka_next.facts import SourcePolicy
from matryoshka_demo.io import digest

OUT = HERE / "native_v01"
API = ROOT / "experiments/narrative_demo/api"
workflow.OUTPUT = OUT / "checkpoints"
CONFIG = dict(method="current_hierarchy", passage_budget=80, document_budget=40,
              construction_pages=16, draft_budget=24)


def read(path):
    raw = Path(path).read_bytes()
    return json.loads(gzip.decompress(raw) if str(path).endswith(".gz") else raw)


def pin(path):
    path = Path(path)
    with path.open("rb") as stream:
        checksum = hashlib.file_digest(stream, "sha256").hexdigest()
    return dict(path=str(path.relative_to(ROOT)), sha256=checksum)


def write(path, value, *, immutable=False):
    path = Path(path)
    if not path.resolve().is_relative_to(HERE):
        raise ValueError("Only curation output paths are authorized")
    guards.require_headroom(HERE)
    return (workflow.native.put_immutable if immutable else workflow.native.put)(path, value)


def receipt_snapshot():
    return {p.name: read(p) for p in sorted((API / "receipts").glob("*.json"))}


def case_summary(packet):
    result = packet["result"]
    atoms = result.get("atoms", [])
    return dict(status=result.get("status"), atom_count=len(atoms),
        atoms=[dict(id=a.get("id"), text=a.get("text"), status=a.get("status"),
            evidence_count=len(a.get("evidence", [])),
            positive_evidence_count=len(a.get("positive_evidence", [])),
            negative_evidence_count=len(a.get("counterevidence", [])),
            partial_evidence_count=len(a.get("partial_evidence", []))) for a in atoms],
        inspected_page_count=len(result.get("inspected_page_ids", [])),
        native_checksum=packet["native_checksum"], timings=packet["timings"])


def audit_sources(packet, source_packet, context):
    policy = SourcePolicy(context.corpus, packet["case"], context.source_index)
    excluded = set(source_packet["excluded_origin_document_ids"])
    cutoff = source_packet["earliest_origin_date"]
    inspected = []
    for pid in packet["result"].get("inspected_page_ids", []):
        pi = context.corpus.page_index[pid]
        page = context.corpus.pages[pi]
        if page["document_id"] in excluded or page["date"] >= cutoff or not policy.allowed(pi):
            raise ValueError("A native inspected page violated the complete origin/cutoff policy")
        inspected.append(dict(source_id=pid, document_id=page["document_id"], date=page["date"],
            classification=page.get("classification"), permitted=page["permitted"], visibility=page["visibility"]))
    citations = {}
    def visit(value):
        if isinstance(value, dict):
            if all(k in value for k in ("canonical_page_id", "start", "end", "text", "document_id", "date")):
                key = (value["canonical_page_id"], value["start"], value["end"])
                pi = context.corpus.page_index[value["canonical_page_id"]]
                checked = policy.citation(pi, value["start"], value["end"])
                if checked["text"] != value["text"] or checked["document_id"] in excluded or checked["date"] >= cutoff:
                    raise ValueError("Native citation replay/origin/date failed")
                citations[key] = checked
            for child in value.values():
                visit(child)
        elif isinstance(value, (list, tuple)):
            for child in value:
                visit(child)
    visit(packet["result"])
    return dict(passed=True, earliest_origin_date=cutoff, excluded_origin_document_ids=sorted(excluded),
        inspected_pages=inspected, inspected_document_count=len({p["document_id"] for p in inspected}),
        unique_citation_count=len(citations), citations=list(citations.values()),
        additional_origins_excluded_without_policy_change=True,
        explanation="Normal strict-before policy rejects every later origin; the earliest origin is also excluded by document ID. All inspected pages and returned citation spans were independently checked.")


def main():
    global OUT
    parser = argparse.ArgumentParser()
    parser.add_argument("--task", choices=("mosaic", "hypothesis", "all"), default="mosaic")
    parser.add_argument("--corpus", choices=("iran", "vietnam", "cib", "all"), default="all")
    parser.add_argument("--model", choices=("gpt-6.1-sol", "gpt-6-luna"), default="gpt-6.1-sol")
    parser.add_argument("--only-missing-native", action="store_true")
    parser.add_argument("--recovered-query-only-plan", action="store_true")
    parser.add_argument("--planner-variant", choices=("canonical", "literal_copy_v01"), default="canonical")
    parser.add_argument("--packet", default="case_packets_v02.json")
    parser.add_argument("--case-key")
    args = parser.parse_args()
    if args.planner_variant == "literal_copy_v01":
        OUT = HERE / "native_literal_v01"
        workflow.OUTPUT = OUT / "checkpoints"
    load_dotenv(WORKSPACE / ".env")
    load_dotenv(WORKSPACE / "src-redaction/.env")
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_FSIZE, (24 * 1024**2, 24 * 1024**2))
    deadline = datetime.now(timezone.utc) + timedelta(minutes=35)
    os.environ.update(NARRATIVE_DEADLINE_UTC=deadline.isoformat(),
        NARRATIVE_NO_NEW_WORK_UTC=deadline.isoformat(), MATRYOSHKA_API_CONNECT_SECONDS="15",
        MATRYOSHKA_API_RESPONSE_SECONDS="150")
    guards.require_headroom(HERE)
    budget = Budget(API, cap=50)
    # Every variant shares the FIRST persistent envelope; never reset its baseline.
    auth_path = HERE / "native_v01/authorization.json"
    if auth_path.exists():
        authorization = read(auth_path)
    else:
        authorization = dict(version="rich-native-authorization/1", shared_cumulative_cap_usd=50,
            incremental_envelope_usd=3, shared_total_at_start_usd=budget.total(),
            initial_receipt_names=sorted(receipt_snapshot()),
            guard_floor_bytes=FLOOR, output_redirect=str(workflow.OUTPUT.relative_to(ROOT)),
            launch_configuration_reference=pin(HERE.parent / "live/worker.py"),
            inference_code_pins=workflow.code_pins(), created_utc=datetime.now(timezone.utc).isoformat())
        write(auth_path, authorization, immutable=True)
    os.environ["NARRATIVE_INCREMENTAL_BASELINE_USD"] = str(authorization["shared_total_at_start_usd"])
    os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"] = "3"
    if args.planner_variant != "canonical":
        write(OUT / "launch_variant.json", dict(planner_variant=args.planner_variant,
            parent_budget_authorization=pin(auth_path), budget_reset=False,
            literal_planner_source=pin(HERE / "literal_copy_planner.py"),
            disk_floor_bytes=FLOOR, canonical_inference_sources_unchanged=True), immutable=True)
    packet_path = (HERE / args.packet).resolve()
    if packet_path.parent != HERE:
        raise ValueError("Case packet must be an owned artifact")
    source = read(packet_path)
    selected = [p for p in source["cases"] if p["qualification"] == "PENDING_NATIVE_QUALIFICATION"
        and (args.task == "all" or p["task"] == args.task)
        and (args.corpus == "all" or p["corpus"] == args.corpus)
        and (not args.case_key or "_" + args.case_key + "_" in p["case_id"])
        and (not args.only_missing_native or not (OUT / "cases" / p["case_id"] / "native.json.gz").exists())]
    # Prioritize one actual rich Mosaic per corpus before spending on Hypotheses.
    selected.sort(key=lambda p: (p["task"] != "mosaic", ("iran", "vietnam", "cib").index(p["corpus"])))
    summaries = []
    progress = OUT / ("progress_" + args.task + "_" + args.corpus + "_" + args.model + ("_" + args.case_key if args.case_key else "") + ("_recovered" if args.recovered_query_only_plan else "") + ".json")
    for source_packet in selected:
        case = source_packet["native_case_stub"]
        target = OUT / "cases" / case["case_id"]
        started = time.monotonic()
        row = dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
            query=case["query"], planning_model=args.model, planner_variant=args.planner_variant,
            qualified=False, source_packet_ref=pin(packet_path))
        try:
            guards.require_headroom(HERE)
            print(json.dumps(dict(stage="normal_query_only_planning", case_id=case["case_id"])), flush=True)
            if args.planner_variant == "literal_copy_v01":
                from literal_copy_planner import parse
                saved = parse(case, API, model=args.model)
            elif args.recovered_query_only_plan:
                saved = read(OUT / "recovered_planning" / (case["case_id"] + ".json"))
                from matryoshka_narrative.contracts import engine_case, public_query
                if saved["public_query"] != public_query(case) or not saved.get("supplemental_query_only_correction", {}).get("canonical_schema_and_bind"):
                    raise ValueError("A strict source-free correction plan is required")
                workflow.validate_plan(saved["native_plan"], engine_case(case))
            else:
                saved = workflow.plan_case(case, api_root=API, model=args.model)
            write(target / "planning.json", saved, immutable=True)
            print(json.dumps(dict(stage="opening_current_resources", case_id=case["case_id"])), flush=True)
            with workflow.Session() as session:
                expected = dict(pins=workflow.code_pins(), binding=session.refs["index_refs"][case["corpus"]],
                    environment=session.environment, settings=workflow.configuration(**CONFIG))
                native_path = target / "native.json.gz"
                if native_path.exists():
                    packet = read(native_path)
                    workflow.validate_packet(packet, case, saved["native_plan"], None, **expected)
                    cached = True
                else:
                    print(json.dumps(dict(stage="normal_native_execute", case_id=case["case_id"])), flush=True)
                    packet = session.execute(case, saved["native_plan"], **CONFIG)
                    workflow.validate_packet(packet, case, saved["native_plan"], None, **expected)
                    write(native_path, packet, immutable=True)
                    write(target / "completion.json", workflow._completion(native_path, packet, digest([case, saved, CONFIG])), immutable=True)
                    cached = False
                context = session.context(case["corpus"])
                audit = audit_sources(packet, source_packet, context)
                write(target / "source_audit.json", audit, immutable=True)
                row.update(execution_performed=True, execution_cache_hit=cached, native_ref=pin(native_path),
                    planning_ref=pin(target / "planning.json"), source_audit_ref=pin(target / "source_audit.json"),
                    summary=case_summary(packet), source_audit_passed=audit["passed"],
                    query_only_planning=True, no_curator_components_or_quotes_in_plan_input=True,
                    inference_functions_changed=False, launch_disk_guard_override_only=True,
                    inspected_document_count=audit["inspected_document_count"],
                    replayed_citation_count_including_diagnostics=audit["unique_citation_count"],
                    replayed_citations_are_not_all_signed_case_support=True)
                try:
                    adapters = workflow.inspection_artifacts(packet)
                    write(target / "decision_adapters.json", adapters, immutable=True)
                    row["decision_adapters_ref"] = pin(target / "decision_adapters.json")
                except Exception as error:
                    row["adapter_error"] = dict(type=type(error).__name__, message=str(error))
            print(json.dumps(dict(stage="native_result_saved", **row)), flush=True)
        except Exception as error:
            row.update(execution_performed=False, error_type=type(error).__name__, error=str(error),
                traceback=traceback.format_exc(), qualification="NOT_QUALIFIED_FAILURE_PRESERVED")
            print(json.dumps(dict(stage="attempt_failed", **row)), flush=True)
        row["wall_seconds"] = time.monotonic() - started
        # Failed planning/native attempts get their own permanent receipt.
        attempt = target / ("attempt_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + ".json")
        write(attempt, row, immutable=True)
        summaries.append(row)
        write(progress, dict(version="rich-native-progress/1", cases=summaries,
            requested_case_count=len(selected), completed_native_executions=sum(r["execution_performed"] for r in summaries),
            new_spend_upper_bound_usd=round(budget.total() - authorization["shared_total_at_start_usd"], 9),
            spending_includes_any_concurrent_other_jobs=True,
            canonical_engine_files_modified=False, all_qualification_pending=True))
        gc.collect()
    print(json.dumps(dict(progress_ref=pin(progress)), indent=2), flush=True)


if __name__ == "__main__":
    main()
