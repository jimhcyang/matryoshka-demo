"""Regression checks for the fixed-source packet, not native qualification."""
from copy import deepcopy
import json
from pathlib import Path
import unittest

from build_packets import CableSources, CibSources, DEMO, HERE, ROOT, admit, evaluate, ref
from candidates import candidates
from matryoshka_next import sourcebank as bank


class PacketTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.bundle = json.loads((HERE / "case_packets_v02.json").read_text())
        cls.packets = cls.bundle["cases"]
        cls.results = json.loads((HERE / "local_results_v02.json").read_text())
        cls.by_key = {p["case_id"]: p for p in cls.packets}
        cls.specs = candidates()

    def test_new_queries_are_not_published_queries(self):
        report = json.loads((ROOT / "matryoshka_demo_site/site/data/report-v6.json").read_text())
        old = {r["case"]["query"] for r in report["cases"]}
        self.assertTrue(all(p["query"] not in old for p in self.packets))
        self.assertEqual(len({p["case_id"] for p in self.packets}), len(self.packets))

    def test_results_recompute_without_mutation(self):
        for result in self.results["results"]:
            self.assertEqual(evaluate(self.by_key[result["case_id"]]), result)

    def test_no_native_or_release_success_claim(self):
        for p in self.packets:
            self.assertFalse(p["release_substitution_authorized"])
            self.assertIn(p["qualification"], ("PENDING_NATIVE_QUALIFICATION", "FAILED_SOURCE_CONTRACT_NO_SUBSTITUTION"))
            self.assertIn("SIMULATION", p["activity_provenance"])
        for result in self.results["results"]:
            self.assertIsNone(result["native_verdict"])
            self.assertFalse(result["native_execution"])
            self.assertFalse(result["independent_semantic_entailment_test"])

    def test_one_preferred_pair_per_corpus_is_pending(self):
        usable = [p for p in self.packets if p["qualification"] == "PENDING_NATIVE_QUALIFICATION"]
        self.assertEqual(len(usable), 6)
        for corpus in ("iran", "vietnam", "cib"):
            self.assertEqual({p["task"] for p in usable if p["corpus"] == corpus}, {"mosaic", "hypothesis"})

    def test_mosaics_are_rich_and_multidocument(self):
        for p in self.packets:
            if p["task"] != "mosaic" or p["qualification"] != "PENDING_NATIVE_QUALIFICATION":
                continue
            result = evaluate(p)
            self.assertGreaterEqual(result["component_count"], 3)
            self.assertGreaterEqual(result["curator_mapped_support_document_count"], 2)
            self.assertTrue(all(r["direct_for_count"] for r in result["component_results"]))
            self.assertIn(p["query"].count("."), (1, 2))

    def test_all_evidence_strictly_precedes_every_origin(self):
        for p in self.packets:
            self.assertEqual(p["earliest_origin_date"], min(o["date"] for o in p["origins"]))
            for e in p["eligible_evidence"]:
                self.assertEqual(admit(e, p["earliest_origin_date"], p["excluded_origin_document_ids"], p["corpus"]), [])
                self.assertTrue(all(e["date"] < o["date"] for o in p["origins"]))

    def test_second_vietnam_origin_and_attractive_later_witness_stay_excluded(self):
        p = next(p for p in self.packets if "vietnam_paracels_m01" in p["case_id"])
        self.assertEqual(p["earliest_origin_date"], "1974-01-31")
        self.assertIn("1974STATE020425", p["excluded_origin_document_ids"])
        self.assertIn("1974SAIGON02847", p["excluded_origin_document_ids"])
        self.assertTrue(p["native_case_stub_not_ready_for_execution"])
        self.assertEqual(p["rejected_evidence"][0]["source"]["date"], "1974-02-15")
        self.assertIn("NOT_STRICTLY_BEFORE_EARLIEST_ORIGIN", p["rejected_evidence"][0]["rejection_reasons"])

    def test_same_day_and_any_origin_document_fail(self):
        p = next(p for p in self.packets if p["corpus"] == "vietnam")
        source = deepcopy(p["eligible_evidence"][0])
        source["date"] = p["earliest_origin_date"]
        self.assertIn("NOT_STRICTLY_BEFORE_EARLIEST_ORIGIN", admit(source, p["earliest_origin_date"], p["excluded_origin_document_ids"], p["corpus"]))
        source["date"] = "1970-01-01"
        for origin in p["excluded_origin_document_ids"]:
            source["document_id"] = origin
            self.assertIn("WHOLE_ORIGIN_DOCUMENT_EXCLUDED", admit(source, p["earliest_origin_date"], p["excluded_origin_document_ids"], p["corpus"]))

    def test_secret_cable_cannot_become_lower_evidence(self):
        p = next(p for p in self.packets if p["corpus"] == "iran")
        source = deepcopy(p["eligible_evidence"][0])
        source["classification"] = "SECRET"
        self.assertIn("NOT_LOWER_CLASSIFICATION", admit(source, p["earliest_origin_date"], p["excluded_origin_document_ids"], "iran"))

    def test_cib_requires_an_eligible_earlier_paired_view(self):
        p = next(p for p in self.packets if p["corpus"] == "cib")
        source = deepcopy(p["eligible_evidence"][0])
        source["eligible_earlier_view"] = False
        self.assertIn("NOT_PERMITTED_EARLIER_PAIRED_VIEW", admit(source, p["earliest_origin_date"], p["excluded_origin_document_ids"], "cib"))

    def test_noforn_in_whole_body_vetoes_even_unselected_span(self):
        body = "An innocuous selected sentence.\nUnselected sibling NOFORN.\n"
        raw = dict(date="1978-01-01", body=body)
        metadata = dict(origclass="CONFIDENTIAL", orighand="")
        policy = bank.document_admission(raw, metadata, {}, [], {})
        self.assertFalse(policy["eligible"])
        self.assertEqual(policy["reason"], "WHOLE_ORIGINAL_BODY_OR_HANDLING_NOFORN")

    def test_revealed_source_near_visible_target_is_not_enough(self):
        failed = [p for p in self.packets if p["corpus"] == "cib" and not p["reveal_dependency_review"]["passed"]]
        self.assertEqual(len(failed), 2)
        for p in failed:
            self.assertEqual(evaluate(p)["actual_local_verdict"], "FAILED_SOURCE_CONTRACT")
        old_h = next(p for p in failed if "burma_h01" in p["case_id"])
        self.assertEqual(evaluate(old_h)["signed_link_counts"], dict(FOR=1, AGAINST=1, CONTEXT=1))

    def test_changed_mind_is_not_opposition_to_earlier_motive(self):
        p = next(p for p in self.packets if "burma_h02" in p["case_id"])
        assessments = p["components"][0]["evidence_assessments"]
        self.assertEqual(assessments[1]["direction"], "CONTEXT")
        self.assertEqual(evaluate(p)["signed_link_counts"]["AGAINST"], 0)
        for p in self.packets:
            for c in p["components"]:
                for a in c["evidence_assessments"]:
                    if a["direction"] == "AGAINST":
                        self.assertTrue(a["rationale"])
                        self.assertNotIn("no evidence", a["rationale"].lower())

    def test_live_cable_source_replay(self):
        for corpus in ("iran", "vietnam"):
            loader = CableSources(corpus)
            specs = [s for s in self.specs if s["corpus"] == corpus]
            for spec in specs:
                p = next(p for p in self.packets if "_" + spec["key"] + "_" in p["case_id"])
                self.assertEqual([loader.bind(q) for q in spec["origins"]], p["origins"])
                self.assertEqual([loader.bind(q) for q in spec["evidence"]], p["eligible_evidence"])
                self.assertEqual(loader.exclusions([o["document_id"] for o in p["origins"]]), p["excluded_origin_document_ids"])

    def test_live_cib_source_replay_and_pdf_bindings(self):
        specs = [s for s in self.specs if s["corpus"] == "cib"]
        wanted = {q["document_id"] for s in specs for q in s["origins"] + s["evidence"]}
        loader = CibSources(wanted)
        try:
            for spec in specs:
                p = next(p for p in self.packets if "_" + spec["key"] + "_" in p["case_id"])
                self.assertEqual([loader.bind(q) for q in spec["origins"]], p["origins"])
                self.assertEqual([loader.bind(q) for q in spec["evidence"]], p["eligible_evidence"])
                for origin in p["origins"]:
                    for pdf in origin["paired_pdfs"].values():
                        self.assertEqual(ref(ROOT / pdf["path"]), pdf)
        finally:
            loader.db.close()

    def test_code_pins_and_no_api_spend(self):
        for bound in self.results["code_refs"] + self.results["input_refs"]:
            self.assertEqual(ref(ROOT / bound["path"]), bound)
        self.assertEqual(self.results["budget"]["new_api_calls"], 0)
        self.assertEqual(self.results["budget"]["new_api_spend_usd"], 0)
        self.assertFalse(self.results["budget"]["separate_budget_created"])
        self.assertFalse(self.results["native_preflight"]["engine_guard_changed"])
        self.assertFalse(self.results["native_preflight"]["passed"])

    def test_current_cib_resource_and_salvador_retained(self):
        for p in self.packets:
            if p["corpus"] == "cib":
                self.assertEqual(p["resource_ref"]["resource_id"], "cib_resource_623c60e1e128944377f0")
                self.assertEqual(p["resource_ref"]["alias_release"], "alias_sense_fa9fe8608add36db785f")
        self.assertEqual(self.bundle["cib_starter_redaction"], "RETAIN_EXISTING_SALVADOR_ANCHOR")


if __name__ == "__main__":
    unittest.main(verbosity=2)
