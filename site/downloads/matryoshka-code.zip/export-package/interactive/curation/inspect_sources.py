"""Read-only inspection of existing compressed source indexes; no API or writes."""
import argparse
import json
from pathlib import Path
import re
import sqlite3
import zlib

HERE = Path(__file__).resolve().parent
DEMO = HERE.parents[2]
ROOT = DEMO.parent
INDEXES = {
    "iran": "data/graph_indexes_v2/78167a37229d2345cd9b/graph.sqlite3",
    "vietnam": "data/graph_indexes_v2/38ea42a3bb013f05f25f/graph.sqlite3",
    "cib": "experiments/current_refresh/resource_handoff/indexes/current_index_0c8587c8fa8e78ddad1c24cc/graph.sqlite3",
}


def decode(payload):
    return json.loads(zlib.decompress(payload) if isinstance(payload, bytes) else payload)


def connect(corpus):
    return sqlite3.connect(f"file:{DEMO / INDEXES[corpus]}?mode=ro&immutable=1", uri=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus", choices=INDEXES)
    parser.add_argument("pattern", nargs="?", default=".")
    parser.add_argument("--documents", nargs="*", default=[])
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--context", type=int, default=500)
    parser.add_argument("--after", default="0000-01-01")
    parser.add_argument("--before", default="9999-12-31")
    args = parser.parse_args()
    pattern = re.compile(args.pattern, re.I)
    count = 0
    with connect(args.corpus) as db:
        columns = {r[1] for r in db.execute("PRAGMA table_info(page)")}
        flag = "eligible" if "eligible" in columns else "NULL"
        sql = f"SELECT id,doc,date,{flag},payload FROM page WHERE date>=? AND date<? ORDER BY date,id"
        for pid, did, date, eligible, payload in db.execute(sql, (args.after, args.before)):
            if args.documents and did not in args.documents:
                continue
            page = decode(payload)
            match = pattern.search(page["text"])
            if not match:
                continue
            count += 1
            print(json.dumps({k: page.get(k) for k in ("id", "document_id", "date", "classification", "handling", "visibility", "permitted", "earlier_page")}, sort_keys=True))
            print("eligible:", eligible, "text_chars:", len(page["text"]))
            start, end = max(0, match.start() - args.context), min(len(page["text"]), match.end() + args.context)
            print(page["text"][start:end])
            if count >= args.limit:
                break


if __name__ == "__main__":
    main()
