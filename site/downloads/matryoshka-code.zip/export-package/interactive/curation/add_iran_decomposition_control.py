"""User-requested three-sentence manual control; no old query is modified."""
from copy import deepcopy
import sys

sys.dont_write_bytecode = True
from build_packets import HERE, bank, evaluate, put, read, ref


def main():
    bundle = read(HERE / "case_packets_v03.json")
    original = next(p for p in bundle["cases"] if "iran_nuclear_m01" in p["case_id"])
    packet = deepcopy(original)
    query = ("Iran reorganized its nuclear administration under the energy ministry. "
        "The draft US-Iran agreement linked reprocessing parity to comparable needs and approvals "
        "granted to other states after entry into force. "
        "Sullivan favored deferring signature until a more propitious political moment.")
    cid = "interactive_rich_20261122_iran_nuclear_m03_" + bank.digest(dict(query=query, origins=original["excluded_origin_document_ids"]))[:12]
    packet.update(case_id=cid, query=query, title="Three independent nuclear-policy propositions: decomposition control",
        native_case_stub=dict(original["native_case_stub"], case_id=cid, query=query),
        test_ref=dict(path="iran_m03_local_result.json", case_id=cid),
        manually_authored_revision=True, programmatic_query_rewriting=False,
        prior_case_id=original["case_id"], prior_case_and_runs_retained=True,
        prior_source_packet_ref=ref(HERE / "case_packets_v03.json"),
        user_requested_three_sentence_exception=True,
        reason_for_revision="Explicit user-proposed conservative conjunction/decomposition control: three independent sentences, no 'As' temporal/event join. This deliberately retains the original three substantive targets and does not weaken the join checker.",
        preference_reason="Useful decomposition control, not a claimed qualified replacement. Separates the earlier two-fact atom without changing its underlying target claims or injecting witnesses.",
        temporal_scope="Three independent source-grounded propositions; no causal, temporal or event-identity join is asserted by their sequence.")
    packet["limits"] += ["Three sentences are an explicit user-requested diagnostic exception to the earlier 1-2 sentence design preference.",
        "The inherited-source actor, pronoun, predicate and policy-clock concerns remain actual tests, not silently repaired facts."]
    bundle["cases"].append(packet)
    bundle["version"] = "rich-case-packets/4"
    bundle["iran_decomposition_control_case_id"] = cid
    put("case_packets_v04.json", bundle)
    bounded = evaluate(packet)
    bounded["mosaic_richness_pass"] = True
    bounded["actual_local_verdict"] = "BOUNDED_SOURCE_COVERAGE_PRESENT_USER_REQUESTED_THREE_SENTENCE_CONTROL"
    bounded["design_exception_only_not_native_qualification"] = True
    put("iran_m03_local_result.json", bounded)
    print(cid)


if __name__ == "__main__":
    main()
