"""Actual unmodified native matcher on fixed source spans, POST-RUN only."""
from collections import Counter
import json
import re
import sys

sys.dont_write_bytecode = True
from run_native import HERE, OUT, pin, read, write
from matryoshka_narrative.workflow import Session
from matryoshka_next.facts import SourcePolicy, fact_index
from matryoshka_demo_v6.planning import sentences
from matryoshka_narrative.assertion_matching import MatcherCase
from matryoshka_narrative import source_sentences


def main():
    packets = read(HERE / "case_packets_v02.json")["cases"]
    output = []
    with Session() as session:
        context = session.context("iran")
        for candidate in packets:
            if candidate["corpus"] != "iran":
                continue
            native_path = OUT / "cases" / candidate["case_id"] / "native.json.gz"
            if not native_path.exists():
                continue
            native = read(native_path)
            policy = SourcePolicy(context.corpus, native["case"], context.source_index)
            matcher = MatcherCase(native["case"], context.source_index,
                engine=fact_index(context.corpus).linguistic_engine(), corpus=context.corpus, source_policy=policy)
            rows = []
            for evidence in candidate["eligible_evidence"]:
                wanted_pages = {s["source_id"] for s in evidence["source_segments"]}
                for pid in wanted_pages:
                    pi = context.corpus.page_index[pid]
                    assert policy.allowed(pi)
                    page = context.corpus.pages[pi]
                    units = list(sentences(page["text"]))
                    for unit in list(units):
                        units.extend(source_sentences.recover(page, unit, matcher.baseline.engine.parse))
                    for atom in native["plan"]["atoms"]:
                        terms = set(re.findall(r"[a-z0-9]+", atom["text"].casefold()))
                        for unit in units:
                            if not terms.intersection(re.findall(r"[a-z0-9]+", unit["text"].casefold())):
                                continue
                            row = matcher.supplement(atom, page, unit)
                            citation = row["citation"]
                            checked = policy.citation(pi, citation["start"], citation["end"])
                            assert checked["text"] == citation["text"]
                            pairs = [p for group in row.get("comparisons", []) for p in group]
                            rows.append(dict(atom_id=atom["id"], document_id=page["document_id"],
                                originally_inspected=pid in native["result"]["inspected_page_ids"],
                                direction=row["direction"], citation=citation,
                                query_issues=row.get("query_issues", []), checks=row.get("checks"),
                                root_content_withheld=row.get("root_content_withheld"),
                                source_account_policy_withheld=row.get("source_account_policy_withheld"),
                                comparison_statuses=[dict(predicate=p.get("diagnostics", {}).get("predicate", {}).get("status"),
                                    actor=p.get("diagnostics", {}).get("actor", {}).get("status"),
                                    attribution=p.get("diagnostics", {}).get("attribution", {}).get("status"),
                                    object=p.get("diagnostics", {}).get("object", {}).get("status")) for p in pairs]))
            groups = []
            for did in sorted({r["document_id"] for r in rows}):
                selected = [r for r in rows if r["document_id"] == did]
                groups.append(dict(document_id=did, native_directions=dict(Counter(r["direction"] for r in selected)),
                    originally_inspected=any(r["originally_inspected"] for r in selected),
                    query_issue_counts=dict(Counter(i for r in selected for i in r["query_issues"]))))
            output.append(dict(case_id=candidate["case_id"], native_ref=pin(native_path), groups=groups, rows=rows))
    value = dict(version="iran-native-fixed-source-matcher-diagnostic/1", cases=output,
        actual_unmodified_matcher_executed=True, api_calls=0, human_evidence_directions_used=False,
        qualification=False, original_native_results_modified=False,
        scope="Predeclared expected source documents are deliberately selected only for this POST-RUN diagnostic. This is not ordinary retrieval, a repaired native run, a release qualification or a benchmark.")
    write(HERE / "iran_fixed_source_native_diagnostics.json", value)
    print(json.dumps(dict(ref=pin(HERE / "iran_fixed_source_native_diagnostics.json"),
        cases=[dict(case_id=r["case_id"], groups=r["groups"]) for r in output]), indent=2))


if __name__ == "__main__":
    main()
