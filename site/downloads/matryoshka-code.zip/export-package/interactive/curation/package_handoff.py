"""Small unqualified public catalog, fresh verification and owned-file manifest."""
from datetime import datetime, timezone
import io
import json
import sys
import unittest

sys.dont_write_bytecode = True
from run_native import HERE, pin, read, write


def main():
    report_path = HERE / "native_integration_report.json"
    report = read(report_path)
    packets = {p["case_id"]: p for p in read(HERE / "case_packets_v04.json")["cases"]}
    prospects = []
    current_projection = []
    for result in report["cases"]:
        packet = packets[result["case_id"]]
        prospects.append(dict(case_id=packet["case_id"], corpus=packet["corpus"], task=packet["task"],
            title=packet["title"], query=packet["query"],
            activity_provenance="GENERATED_SOURCE_BASED_ANALYST_SIMULATION_NOT_REAL_ANALYST_ACTIVITY",
            qualification="NOT_QUALIFIED_THIS_RUN", release_substitution_authorized=False,
            actual_native_status=result["latest_native_status"],
            actual_native_support_count=result["actual_signed_support_count"],
            actual_native_against_count=result["actual_signed_against_count"],
            origin_references=[dict(document_id=o["document_id"], date=o["date"],
                classification=o["classification"]) for o in packet["origins"]],
            earliest_origin_date=packet["earliest_origin_date"],
            excluded_origin_document_ids=packet["excluded_origin_document_ids"],
            preference_reason=packet["preference_reason"],
            result_ref=dict(path="native_integration_report.json", case_id=packet["case_id"])))
        current_projection.append(dict(case_id=packet["case_id"], corpus=packet["corpus"], task=packet["task"],
            query=packet["query"], native_status=result["latest_native_status"],
            native_execution_completed=bool(result["completed_native_execution_count"]),
            native_positive_count=result["actual_signed_support_count"],
            native_against_count=result["actual_signed_against_count"],
            native_support_document_count=result["actual_support_document_count"],
            qualified=False, release_substitution_authorized=False))
    write(HERE / "public_prospects.json", dict(version="unqualified-rich-public-prospects/1",
        cases=prospects, notice="Prospects only. No richer primary replacement is qualified.",
        cib_starter_redaction="RETAIN_EXISTING_SALVADOR_ANCHOR", actual_outcomes_ref=pin(report_path)), immutable=True)
    # Refresh the previously stale convenience path without overwriting any run.
    write(HERE / "native_v01/native_current.json", dict(version="rich-native-current-projection/2",
        authoritative_report_ref=pin(report_path), cases=current_projection,
        completed_native_executions=report["total_native_executions"],
        distinct_cases_executed_natively=report["distinct_cases_executed_natively"],
        attempted_case_count=report["attempted_case_count"],
        new_api_charged_or_reserved_usd=report["new_api_charged_or_reserved_usd"],
        qualified_case_count=0, release_substitution_authorized=False,
        notice="Combined canonical/recovered/exact-copy variants. Diagnostic spans are not signed support."))
    suite = unittest.defaultTestLoader.discover(str(HERE), pattern="test_*.py")
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    verification = dict(version="rich-curation-verification/1", generated_utc=datetime.now(timezone.utc).isoformat(),
        tests_run=result.testsRun, passed=result.wasSuccessful(), failures=len(result.failures), errors=len(result.errors),
        output=stream.getvalue(), report_ref=pin(report_path),
        test_refs=[pin(HERE / "test_packets.py"), pin(HERE / "test_literal_planner.py")])
    write(HERE / "verification_v01.json", verification, immutable=True)
    if not result.wasSuccessful():
        raise RuntimeError("Handoff verification failed; no qualification authorized")
    manifest = dict(version="rich-curation-owned-manifest/1",
        files=[dict(path=str(p.relative_to(HERE)), sha256=pin(p)["sha256"], bytes=p.stat().st_size)
            for p in sorted(HERE.rglob("*")) if p.is_file() and p.name != "MANIFEST.json" and "__pycache__" not in p.parts],
        canonical_or_published_assets_modified=False, qualified_replacements=0)
    write(HERE / "MANIFEST.json", manifest, immutable=True)
    print(json.dumps(dict(report_ref=pin(report_path), public_prospects_ref=pin(HERE / "public_prospects.json"),
        verification_ref=pin(HERE / "verification_v01.json"), manifest_ref=pin(HERE / "MANIFEST.json"),
        tests_run=result.testsRun, passed=result.wasSuccessful()), indent=2))


if __name__ == "__main__":
    main()
