"""Audited integration index: actual native verdicts, never curator grades."""
import json
import sys

sys.dont_write_bytecode = True
from run_native import CONFIG, HERE, ROOT, pin, read, write
from report_native import receipt_inventory
from matryoshka_narrative import workflow
from matryoshka_demo.runner_v2 import environment_binding


def main():
    source_path = HERE / "case_packets_v04.json"
    source = read(source_path)
    refs = read(ROOT / workflow.native.REFS)
    environment, pins = environment_binding(ROOT), workflow.code_pins()
    original_auth = HERE / "native_v01/authorization.json"
    authorization = read(original_auth)
    rows = []
    for case_packet in source["cases"]:
        if case_packet["qualification"] != "PENDING_NATIVE_QUALIFICATION":
            continue
        case = case_packet["native_case_stub"]
        variants = []
        for variant in ("native_v01", "native_literal_v01"):
            folder = HERE / variant / "cases" / case["case_id"]
            attempts = [dict(ref=pin(p), **read(p)) for p in sorted(folder.glob("attempt_*.json"))]
            if not attempts and not (folder / "native.json.gz").exists():
                continue
            row = dict(variant=variant, attempts=attempts, native_execution_completed=False)
            if (folder / "native.json.gz").exists():
                native_path = folder / "native.json.gz"
                packet, saved = read(native_path), read(folder / "planning.json")
                workflow.validate_packet(packet, case, saved["native_plan"], None,
                    pins=pins, binding=refs["index_refs"][case["corpus"]], environment=environment,
                    settings=workflow.configuration(**CONFIG))
                audit = read(folder / "source_audit.json")
                assert audit["passed"] and audit["earliest_origin_date"] == case_packet["earliest_origin_date"]
                assert audit["excluded_origin_document_ids"] == case_packet["excluded_origin_document_ids"]
                atoms, positive_docs = [], set()
                for atom in packet["result"]["atoms"]:
                    positive, negative, partial = (atom.get(k, []) for k in ("positive_evidence", "counterevidence", "partial_evidence"))
                    docs = sorted({r["citation"]["document_id"] for r in positive})
                    positive_docs.update(docs)
                    atoms.append(dict(id=atom["id"], text=atom["text"], status=atom["status"],
                        positive_count=len(positive), against_count=len(negative), partial_count=len(partial),
                        positive_document_ids=docs))
                literal = saved.get("isolated_planner_variant")
                if literal:
                    assert saved["normalized_query"] == case["query"]
                    assert literal["canonical_atom_meaning_roles_negation_and_scope_guards_unchanged"]
                row.update(native_execution_completed=True, native_status=packet["result"]["status"],
                    native_ref=pin(native_path), planning_ref=pin(folder / "planning.json"),
                    source_audit_ref=pin(folder / "source_audit.json"),
                    atoms=atoms, atom_count=len(atoms),
                    positive_count=sum(a["positive_count"] for a in atoms),
                    against_count=sum(a["against_count"] for a in atoms),
                    partial_count=sum(a["partial_count"] for a in atoms),
                    positive_document_count=len(positive_docs),
                    inspected_page_count=len(packet["result"]["inspected_page_ids"]),
                    inspected_document_count=audit["inspected_document_count"],
                    query_requirements=packet["result"]["query_requirements"],
                    native_checksum=packet["native_checksum"], literal_copy_planner=literal,
                    supplemental_query_only_correction=saved.get("supplemental_query_only_correction"),
                    native_packet_validation_passed=True,
                    native_resource_id=packet["binding"].get("resource_id"),
                    diagnostic_citation_count_not_case_support=audit["unique_citation_count"])
            else:
                row.update(native_status="NOT_EXECUTED_STRICT_PLANNER_FAILURE",
                    error=attempts[-1].get("error"), error_type=attempts[-1].get("error_type"))
            variants.append(row)
        executed = [v for v in variants if v["native_execution_completed"]]
        rows.append(dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"], query=case["query"],
            source_packet_ref=pin(source_path), variants=variants,
            attempted=bool(variants), completed_native_execution_count=len(executed),
            latest_native_status=executed[-1]["native_status"] if executed else "NOT_EXECUTED_STRICT_PLANNER_FAILURE" if variants else "NOT_YET_ATTEMPTED",
            actual_signed_support_count=executed[-1]["positive_count"] if executed else None,
            actual_signed_against_count=executed[-1]["against_count"] if executed else None,
            actual_support_document_count=executed[-1]["positive_document_count"] if executed else None,
            qualified=False, release_substitution_authorized=False,
            qualification="NOT_QUALIFIED_NATIVE_RESULT_OR_PLANNER_BLOCK", manually_selected_witnesses_are_not_native_evidence=True))
    receipts = receipt_inventory({r["query"] for r in rows}, set(authorization["initial_receipt_names"]))
    spend = round(sum(r["charged_or_reserved_usd"] for r in receipts), 9)
    assert spend <= 3
    value = dict(version="rich-native-handoff/1", cases=rows,
        case_packet_ref=pin(source_path), budget_authorization_ref=pin(original_auth),
        new_api_charged_or_reserved_usd=spend, new_provider_attempt_count=len(receipts), provider_attempts=receipts,
        shared_cumulative_cap_usd=50, shared_incremental_envelope_usd=3, no_budget_reset=True,
        attempted_case_count=sum(r["attempted"] for r in rows), requested_case_count=len(rows),
        distinct_cases_executed_natively=sum(r["completed_native_execution_count"] > 0 for r in rows),
        total_native_executions=sum(r["completed_native_execution_count"] for r in rows),
        source_contract_failures_retained=[dict(case_id=p["case_id"], qualification=p["qualification"],
            review=p.get("reveal_dependency_review")) for p in source["cases"] if p["qualification"] != "PENDING_NATIVE_QUALIFICATION"],
        canonical_engine_files_modified=False, disk_guard_override="SCOPED_PROCESS_ONLY_3_GIB_AUTHORIZED",
        dataset_copied=False, stage_or_published_site_modified=False,
        release_substitution_authorized=False, qualified_case_count=0,
        cib_starter_redaction="RETAIN_EXISTING_SALVADOR_ANCHOR",
        source_mapping_is_not_a_native_verdict=True, benchmark_accuracy_claimed=False,
        diagnostic_citations_not_signed_support=True,
        literal_copy_variant_ref=pin(HERE / "literal_copy_planner.py"),
        source_diagnostic_refs=[pin(HERE / "iran_native_diagnosis.json"), pin(HERE / "iran_fixed_source_native_diagnostics.json")])
    write(HERE / "native_integration_report.json", value)
    print(json.dumps(dict(report_ref=pin(HERE / "native_integration_report.json"),
        attempted=value["attempted_case_count"], distinct_native_cases=value["distinct_cases_executed_natively"],
        native_runs=value["total_native_executions"], spend=spend,
        cases=[{k:r[k] for k in ("case_id", "latest_native_status", "actual_signed_support_count", "actual_signed_against_count", "actual_support_document_count")} for r in rows]), indent=2))


if __name__ == "__main__":
    main()
