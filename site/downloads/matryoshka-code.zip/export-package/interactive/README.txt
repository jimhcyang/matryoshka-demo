Matryoshka / Interactive Guide
Begin with a question, inspect its facts, follow the selected sources and compare the local verdict with the source passages. A promising answer is not necessarily established by the corpus. Saved results remain inspectable without a model call.

The Corpus Map
Redactions Show/Hide controls redacted-slot markers. Ineligible Show/Dim/Hide changes appearance, not evidence eligibility. Paired maps share Back, Fit and search controls until individually explored. Date guidance states the available range and applies the nearest boundary to an out-of-range date. Click a node to inspect it, or open its direct connections. Concentric rings distinguish the same community, theme, domain and other domains.

Size And Movement
Node size is normalized within the displayed view. Dense views retain their selected nodes and use finite packing rather than endless repulsion. Neighborhood orbit is 0.024 radians per second before outer-band adjustment. Orbit and return share a bounded 30-Hz scheduler; return easing targets 720-2400 milliseconds. Edge width represents stored connection weight. Aggregate weight is available in technical details, not a correctness probability or an independent corroboration count. None of these display encodings changes the underlying evidence.

Input And Facts
A redaction marker toggles a supplied reference on a second click. Unknown reference words remain unknown. Facts are the parsed requirements of the question, not historical findings. Iran and Vietnam cables use a letter-case-only reader edition for clarity. Original wording, punctuation, whitespace, source offsets and hashes remain unchanged. Original capitalization is available in source details. CIB wording is unchanged.

Facts To Evidence
Facts connect directly to recorded matches. Where an atomic search demonstrably matched the selected page, a dashed page-lookup link identifies that fact. Such a link does not assert that the excerpt supports it or that this search alone caused the document to be selected. Missing per-fact records remain query matches. Shared graph states and documents merge visually. Green identifies support, red opposition and amber context or partial evidence. Raw source phrases, when supplied, follow their exact quotations before grammatical processing; they are not additional evidence votes.

Follow The Existing Graph
View on KG opens the actual corpus canvas. The guide selects the starting node in its mother community and highlights the saved connection toward the next node. Connected nodes in the same community stay there. When needed, a cross-community step uses existing direct connections before opening the destination community. Missing browser edges are not drawn. A source handoff with no recorded graph hop remains a source handoff. The final document opens at the exact selected quotation. Post-run inspection paths are not represented as original retrieval chronology or factual entailment chains.

Verdicts And Reported Views
Redaction rank is separate from corpus support. Mosaic asks which requested components can be assembled from eligible sources. Hypothesis distinguishes support, opposition, partial evidence and unresolved requirements. A person's conditional endorsement, warning or forecast is their attributed view, not proof of the eventual political outcome. Missing support is not opposition. Repeated passages from one document are not independent corroboration. Scores and ranking-position indices are not calibrated correctness probabilities.

Source Boundaries And Live Access
Ordinary evidence predates the originating question and excludes its entire origin document. The unknown-delegation study retains its declared input windows and source scope; its visible Swedes clue is not an independent evidence vote. The current CIB source-only alias resource is preserved. Iran and Vietnam retain their existing resources. Live uses a private backend password and short-lived session; the OpenAI key stays on the server. GitHub Pages hosts the frontend, not the Python engine. A separately operated backend is needed for live inference, with its spending and source limits intact.
