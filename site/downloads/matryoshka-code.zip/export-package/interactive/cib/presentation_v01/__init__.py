"""Presentation-only helpers over completed, natively selected candidates."""
