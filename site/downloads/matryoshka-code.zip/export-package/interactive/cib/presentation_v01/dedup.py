"""Group duplicate displayed fills without reopening native family selection."""
from collections import OrderedDict
from copy import deepcopy
from matryoshka_demo.io import digest

VERSION = "cib-native-selected-surface-presentation/1"
TIERS = {"evidence_backed_suggestion": 0, "partial_grounding": 1, "exploratory_contextual": 2}


def normalize(fill):
    return " ".join(fill.casefold().split())


def deduplicate_reading(reading_result, *, assessed_pool=()):
    """No new fills, rank swaps, cap replenishment, gate changes or identity merge.

    The existing native selected order chooses the representative. A complete
    assessed pool may supply MORE proofs of that exact same surface, never a
    previously unselected fill or a replacement representative decision.
    """
    reading_id = reading_result["reading"]["id"]
    candidates = reading_result["candidates"]
    if any(type(c["rank"]) is not int or c["rank"] < 1 for c in candidates):
        raise ValueError("Positive existing native ranks required")
    if [c["rank"] for c in candidates] != sorted({c["rank"] for c in candidates}):
        raise ValueError("Preserve the existing unique native rank order")
    groups = OrderedDict()
    for candidate in candidates:
        if candidate["reading_id"] != reading_id:
            raise ValueError("Do not merge different reading pools")
        groups.setdefault(normalize(candidate["fill"]), []).append(candidate)
    output = []
    for surface, selected in groups.items():
        representative = deepcopy(selected[0])
        variants = OrderedDict((c["id"], c) for c in selected)
        for c in assessed_pool:
            if c["reading_id"] == reading_id and normalize(c["fill"]) == surface:
                variants.setdefault(c["id"], c)
        tier = TIERS[representative["local_decision"]["status"]]
        if any(TIERS[c["local_decision"]["status"]] < tier for c in variants.values()):
            raise ValueError("Native selected representative is not the best existing decision; do not silently rerank")
        union = OrderedDict((digest(ref), deepcopy(ref)) for c in variants.values() for ref in c["sources"])
        representative["native_rank"] = representative["rank"]
        representative["rank"] = len(output) + 1
        representative["surface_duplicate_group"] = dict(version=VERSION, normalized_surface=surface,
            selected_native_ranks=[c["rank"] for c in selected],
            source_variants=[deepcopy(c) for c in variants.values()], citation_union=list(union.values()),
            citation_union_is_support_proof=False, representative_decision_unchanged=True,
            no_new_surface_admitted=True, original_family_selection_preserved=True, identity_merged=False)
        output.append(representative)
    return dict(reading_result, candidates=output, presentation_contract=dict(version=VERSION,
        native_reading_sha256=digest(reading_result), native_judgments_modified=False,
        selected_surface_order_preserved=True, cap_replenished=False))
