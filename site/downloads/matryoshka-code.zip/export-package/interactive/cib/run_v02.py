"""Canonical-page-policy comparison and sole preregistered paid batch."""
from matryoshka_next.workflow import Session
from . import run_v01
from .artifacts import HERE, write
from .engine_v01.construction import fork_functions
from .engine_v02.construction import construct
from .local_compare import controls, rows

_RUN = fork_functions(run_v01, construct=construct, OUT=HERE / "fresh_v02")


def local():
    saved, _ = controls()
    summaries = []
    with Session() as session:
        context = session.context("cib")
        for old, old_ref in saved:
            matched = fork_functions(run_v01, construct=construct, CONFIG=old["configuration"],
                OUT=HERE / "saved_settings_v02")
            packet, ref = matched["execute"](old["public_case"], old["plan"], context.corpus,
                context.source_index, label="saved_settings_fresh_dedup_only")
            common, common_ref = _RUN["execute"](old["public_case"], old["plan"], context.corpus,
                context.source_index, label="fresh_common_pipeline_cached_query_plan_readings")
            summaries.append(dict(case_id=old["case"]["case_id"], control_ref=old_ref,
                matched_settings_ref=ref, common_ref=common_ref, control=rows(old["result"]),
                matched_settings=rows(packet["result"]), common=rows(common["result"])))
    write(HERE / "fresh_v02/six-summary.json", dict(version="six-cib-conservative-regression/2",
        cases=summaries, api_calls=0, configs_compared_separately=True))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("local", "batch"))
    args = parser.parse_args()
    local() if args.mode == "local" else _RUN["bounded_batch"]()
