"""Tighten the verified v03 S2 superset to strict-prior whole-origin exclusion.

No page identity, date, visibility or source text is rewritten. The in-RAM
loader superset is explicitly recorded; per-case masks apply before retrieval.
"""
from dataclasses import replace
from types import MethodType
from matryoshka_demo.io import digest
from phase.kg_patch_20261122.swedish.isolated_engine.v03.context import load_context as load_v03
from phase.kg_patch_20261122.swedish.isolated_engine.policy import StudyPolicy
from phase.kg_patch_20261122.swedish.isolated_engine import retrieval as parent

VERSION = "later-release-strict-prior-origin-veto/1"


def strict_policy(corpus, case):
    key = digest(case)
    if key not in corpus._policies:
        policy = StudyPolicy(corpus, case)
        # This only removes the exceptional origin admission. All original
        # source verification and trusted policy validation remain in force.
        policy.scope = replace(policy.scope, exact_origin_at_cutoff=False)
        corpus._policies[key] = policy
    return corpus._policies[key]


def load_context(case):
    corpus = load_v03(case)
    corpus._policies.clear()
    corpus.policy_for = MethodType(strict_policy, corpus)
    corpus.execution_adapter = dict(version=VERSION, loader_scope=corpus.scope.binding(),
        execution_scope=replace(corpus.scope, exact_origin_at_cutoff=False).binding(),
        loader_superset_contains_masked_origin=True, source_metadata_rewritten=False,
        coordinate_policy="declared-producer-job-local-coordinates/3")
    return corpus


def retrieve(corpus, case, plan, **kwargs):
    policy = corpus.policy_for(case)
    if policy.scope.exact_origin_at_cutoff:
        raise ValueError("No exact-origin admission in ordinary context experiments")
    result = parent.retrieve(corpus, case, plan, source_index=corpus.source_index, source_policy=policy, **kwargs)
    result["receipt"].update(source_policy_version=VERSION, whole_origin_excluded=True,
        source_scope=policy.scope.binding(), execution_adapter=corpus.execution_adapter,
        source_scope_is_retrospective=True)
    if any(policy.allowed(i) and (p["document_id"] == case["document_id"] or p["date"] >= case["date"])
           for i, p in enumerate(corpus.pages)):
        raise AssertionError("Origin or non-prior source escaped the execution mask")
    return result
