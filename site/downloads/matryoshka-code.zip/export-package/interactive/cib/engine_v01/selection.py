"""Exact-surface display deduplication, never source-proof pooling."""
from copy import deepcopy
from matryoshka_demo.io import digest
from matryoshka_narrative import redaction_selection as parent

VERSION = "cib-exact-surface-independent-proof/1"


def __getattr__(name):
    return getattr(parent, name)


def shortlist(values, top_k, *, context_keys=None, ordering_tiers=None):
    """Preserve the parent's full ordering but do not collapse source families.

    A family groups grammar alternatives, not identical fills. Surface grouping
    happens only AFTER every variant has its own final gate and ordering key.
    """
    ids = {c["id"] for c in values}
    if context_keys is not None and set(context_keys) != ids:
        raise ValueError("Context keys must bind the complete viable reading pool")
    tiers = {"evidence_backed_suggestion": 0, "partial_grounding": 1, "exploratory_contextual": 2}
    if ordering_tiers is not None:
        if set(ordering_tiers) != ids or any(
            type(ordering_tiers[c["id"]]) is not int
            or not tiers.get(c["local_decision"]["status"], 3) <= ordering_tiers[c["id"]] <= 3
            or c["local_decision"]["status"] == "evidence_backed_suggestion" and ordering_tiers[c["id"]] != 0
            for c in values
        ):
            raise ValueError("Ordering tiers may only demote, never promote full evidence")
    return sorted(values, key=lambda c: (
        tiers.get(c["local_decision"]["status"], 3) if ordering_tiers is None else ordering_tiers[c["id"]],
        c["context_rank_key"] if context_keys is None else context_keys[c["id"]], c["source_rank_position"]
    ))[:top_k]


def unique_surfaces(ordered, top_k):
    groups = {}
    for position, original in enumerate(ordered, 1):
        key = " ".join(original["fill"].split()).casefold()
        groups.setdefault(key, []).append((position, original))
    selected = []
    for key, variants in groups.items():
        representative = deepcopy(variants[0][1])
        refs = {digest(ref): deepcopy(ref) for _, c in variants for ref in c["sources"]}
        representative["surface_duplicate_group"] = dict(
            version=VERSION, normalized_surface=key,
            original_order_positions=[i for i, _ in variants],
            source_variants=[deepcopy(c) for _, c in variants],
            citation_union=list(refs.values()), citation_union_is_support_proof=False,
            representative_decision_unchanged=True, identity_merged=False,
        )
        if len(selected) < top_k:
            selected.append(representative)
    return selected
