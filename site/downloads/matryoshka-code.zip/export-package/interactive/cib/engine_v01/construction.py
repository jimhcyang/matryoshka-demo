"""Reuse shared functions in private globals, never monkeypatch a parent.

The inherited v02 source adapter is the canonical /27 constructor plus explicit
source-policy plumbing and focal supplemental-page selection. Both ordinary
and later-release arms execute these same functions and gates.
"""
from types import FunctionType
from copy import deepcopy
from phase.kg_patch_20261122.swedish.isolated_engine.v02 import narrative_construction as parent
from . import selection

VERSION = "cib-common-bounded-construction/1"


def fork_functions(module, **overrides):
    namespace = dict(vars(module))
    for name, value in vars(module).items():
        if isinstance(value, FunctionType) and value.__globals__ is vars(module):
            clone = FunctionType(value.__code__, namespace, value.__name__, value.__defaults__, value.__closure__)
            clone.__kwdefaults__ = deepcopy(value.__kwdefaults__)
            namespace[name] = clone
    namespace.update(overrides)
    return namespace


_ENGINE = fork_functions(parent, selection=selection, unique_surface_shortlist=selection.unique_surfaces, VERSION=VERSION)


def construct(*args, **kwargs):
    result = _ENGINE["construct"](*args, **kwargs)
    result["selection_helper_version"] = selection.VERSION
    result["isolated_delta"] = dict(
        common_constructor=True, parent=parent.VERSION, surface_grouping_after_independent_gate=True,
        source_variants_complete=True, no_named_rules=True, no_demonym_mapping=True,
        parent_modules_modified=False, support_gates_modified=False,
    )
    return result
