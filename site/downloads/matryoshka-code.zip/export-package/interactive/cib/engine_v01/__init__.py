"""Versioned delta over the pinned shared constructor, not canonical edits."""
