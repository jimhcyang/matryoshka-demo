"""Small immutable experiment artifacts; no dataset/index copies."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WORKSPACE = ROOT.parent
RESERVE = 3 * 1024**3


def headroom():
    free = shutil.disk_usage(HERE).free
    if free < RESERVE:
        raise OSError("Stop: below 3 GiB free")
    return free


def read(path):
    raw = Path(path).read_bytes()
    return json.loads(gzip.decompress(raw) if str(path).endswith(".gz") else raw)


def pin(path):
    path = Path(path).resolve()
    with path.open("rb") as stream:
        sha = hashlib.file_digest(stream, "sha256").hexdigest()
    return dict(path=str(path.relative_to(WORKSPACE)), sha256=sha)


def write(path, value):
    headroom()
    path = Path(path).resolve()
    if not path.is_relative_to(HERE) or path.is_symlink():
        raise ValueError("Experiment writes must stay in the owned CIB directory")
    raw = (json.dumps(value, sort_keys=True, ensure_ascii=True, indent=2, allow_nan=False) + "\n").encode()
    if path.suffix == ".gz":
        raw = gzip.compress(raw, mtime=0)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Preserve previous outcomes; use a new versioned path")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
    return pin(path)


def code_pins():
    from matryoshka_narrative.workflow import code_pins as canonical
    result = canonical()
    base = ROOT / "phase/kg_patch_20261122/swedish/isolated_engine"
    paths = list(base.glob("*.py")) + list((base / "v02").glob("*.py")) + list((base / "v03").glob("*.py"))
    paths += list(HERE.glob("*.py")) + list(HERE.glob("engine_v*/*.py"))
    for path in paths:
        result[str(path.relative_to(ROOT))] = pin(path)["sha256"]
    return result
