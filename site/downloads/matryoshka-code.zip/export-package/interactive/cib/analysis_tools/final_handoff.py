"""Minimal integration handoff, exact UI/source pins, conservative API audit."""
from datetime import datetime, timezone
from xml.etree import ElementTree
from matryoshka_demo.io import digest
from ..artifacts import HERE, ROOT, WORKSPACE, headroom, pin, read, write
from ..local_compare import controls
from ..presentation_v01.dedup import deduplicate_reading
from .report import HISTORICAL


def compact(packet):
    return [dict(reading_id=r["reading"]["id"], outer_family=r["reading"]["outer_family"],
        candidates=[dict(rank=c["rank"], fill=c["fill"], status=c["local_decision"]["status"],
            candidate_id=c["id"], source_variants=len(c.get("surface_duplicate_group", {}).get("source_variants", [c])),
            citations=[{k:s[k] for k in ("canonical_page_id", "document_id", "date", "start", "end", "page_sha256")}
                for s in c["sources"]]) for c in r["candidates"]]) for r in packet["result"]["readings"]]


def budget_audit():
    authorization = read(HERE / "fresh_v02/batch-authorization.json")
    catalog = read(HERE / "preregistered_v01/public-cases.json")
    queries = {c["query"].strip() for c in catalog["extra_cases"]}
    queries.update(r["case"]["query"].strip() for r in catalog["delegation"])
    ledger = ROOT / "experiments/narrative_demo/api"
    own = []
    import json
    for path in sorted((ledger / "receipts").glob("*.json")):
        receipt = read(path)
        if receipt["started_utc"] < authorization["started_utc"]:
            continue
        request = read(ledger / "attempts" / path.stem / "request.json")
        belongs = False
        for item in request.get("input", []):
            for part in item.get("content", []):
                try:
                    payload = json.loads(part.get("text", "null"))
                except ValueError:
                    continue
                if isinstance(payload, dict) and payload.get("query") in queries:
                    belongs = True
        if belongs:
            own.append(dict(receipt_ref=pin(path), status=receipt["status"],
                charged_or_reserved_usd=receipt["charged_or_reserved_usd"], model=receipt["model"]))
    total = sum(read(p)["charged_or_reserved_usd"] for p in (ledger / "receipts").glob("*.json"))
    cost = sum(r["charged_or_reserved_usd"] for r in own)
    assert cost <= 8 and total <= 50
    result = dict(version="cib-experiment-shared-ledger-audit/1", actual_new_experiment_charged_or_reserved_usd=cost,
        identified_new_requests=len(own), shared_before_usd=authorization["budget_before_usd"], shared_after_usd=total,
        shared_increase_including_other_workers_usd=total-authorization["budget_before_usd"],
        new_experiment_cap_usd=8, cumulative_cap_usd=50, paid_batches=1, no_further_provider_calls=True,
        source_coverage_budget_controls_api_calls=0, receipts=own, keys_logged=False)
    return result


def main():
    xml = HERE / "tests/targeted_final_v04.xml"
    root = ElementTree.parse(xml).getroot()
    suites = root.findall("testsuite") if root.tag == "testsuites" else [root]
    tests = sum(int(s.get("tests", "0")) for s in suites)
    failures = sum(int(s.get("failures", "0"))+int(s.get("errors", "0")) for s in suites)
    assert failures == 0
    saved, report_ref = controls()
    baseline = read(WORKSPACE / "matryoshka_demo_site/site/data/report-v6.json")
    baseline_refs = []
    for row in baseline["cases"]:
        ref = row["configurations"]["llm_readings"]["native_checkpoint"]
        actual = pin(ROOT / ref["path"])
        assert actual["sha256"] == ref["sha256"]
        baseline_refs.append(dict(case_id=row["case"]["case_id"], native_ref=actual))
    assert len(baseline_refs) == 14
    presented, ordinary = [], []
    for old, old_ref in saved:
        cid = old["case"]["case_id"]
        viewed = [deduplicate_reading(r, assessed_pool=old["result"]["assessed_candidates"])
            for r in old["result"]["readings"]]
        presented.append(dict(case=old["public_case"], native_ref=old_ref, readings=viewed,
            native_result_sha256=old["native_checksum"], native_judgments_modified=False))
        matched_path = HERE / "saved_settings_v02" / cid / "execution.json.gz"
        common_path = HERE / "fresh_v02" / cid / "execution.json.gz"
        matched, common = read(matched_path), read(common_path)
        ordinary.append(dict(case_id=cid, historical_fill=HISTORICAL[cid], historical_fill_is_not_gold=True,
            saved_engine=old["result"]["version"], saved=compact(old),
            fresh_same_saved_settings=dict(execution_ref=pin(matched_path), configuration=matched["configuration"], readings=compact(matched)),
            fresh_common_settings=dict(execution_ref=pin(common_path), configuration=common["configuration"], readings=compact(common)),
            expert_flags=["PRESERVE_BASELINE_NATIVE_PIN", "CURRENT_ENGINE_IS_NOT_HISTORICAL_REPLAY",
                "CONTEXT_IS_NOT_MISSING_ACTION_PROOF", "V02_NOT_APPROVED_AS_REPLACEMENT"]))
    presentation_ref = write(HERE / "presentation_v01/saved-presentation.json.gz", dict(
        version="cib-saved-native-selected-presentation/1", cases=presented, api_calls=0,
        baseline_native_pins_modified=False, native_family_selection_preserved=True, no_cap_replenishment=True))
    budget = budget_audit()
    budget_ref = write(HERE / "final_v01/api-audit.json", budget)
    sources = {str(p.relative_to(ROOT)):pin(p)["sha256"] for p in sorted(HERE.rglob("*.py"))}
    archive = pin(HERE / "snapshots/artifacts_before_v02.py")
    source_manifest_ref = write(HERE / "final_v01/source-manifest.json", dict(
        version="cib-isolated-source-manifest/1", python_sources=sources,
        historical_executed_helper_archives=[dict(original_path="phase/interactive_release_20261122/cib/artifacts.py",
            executed_sha256=archive["sha256"], archive_ref=archive)], canonical_sources_modified=False,
        stage_ui_or_published_repo_modified=False, no_dataset_copy=True))
    dto_path = HERE / "dto/public-study-complete-v03.json"
    dto = read(dto_path)
    extras = []
    for case in read(HERE / "preregistered_v01/public-cases.json")["extra_cases"]:
        path = HERE / "fresh_v02" / case["case_id"] / "execution.json.gz"
        extras.append(dict(case=case, execution_ref=pin(path), readings=compact(read(path)),
            qualified_replacement=False, expert_flags=["AUTHENTIC_ORIGIN_DATE_VERIFIED", "NEGATIVE_DEVELOPMENT_RESULT_RETAINED",
                "PARTIAL_IS_NOT_CORRECT_HIDDEN_FILL"]))
    handoff = dict(version="cib-interactive-integration-handoff/1", created_utc=datetime.now(timezone.utc).isoformat(),
        ownership="src-demo-day/phase/interactive_release_20261122/cib/ only; shared authorized API ledger exception",
        baseline_14_native_pins_unchanged=True, baseline_report_ref=report_ref, baseline_native_refs=baseline_refs,
        replacement_engine_approved=False, isolated_v02_study_only=True,
        presentation=dict(interface="presentation_v01.dedup.deduplicate_reading(reading_result, assessed_pool=...)",
            source_ref=pin(HERE / "presentation_v01/dedup.py"), saved_presentation_ref=presentation_ref,
            no_new_surface=True, native_family_selection_preserved=True, best_native_decision_unchanged=True,
            individual_source_variant_proofs_preserved=True, citation_union_is_support_proof=False),
        ordinary_fresh_results=ordinary,
        delegation_public_dto_ref=pin(dto_path), delegation_completeness=dto["completeness"],
        delegation_results=[dict(case_id=c["case"]["case_id"], arm=c["window_arm"], position=c["position"], status=c["status"],
            execution_ref=c["execution_ref"], candidates=[dict(reading_id=r["reading"]["id"], rank=v["rank"],
                fill=v["fill"], status=v["local_decision"]["status"]) for r in c["readings"] for v in r["candidates"]],
            gold=None) for c in dto["cases"]],
        source_coverage=dto["source_coverage"],
        arias_exact_diagnosis_ref=pin(HERE / "coverage_v01/arias-exact-diagnosis.json"),
        outcome_flags_ref=pin(HERE / "COVERAGE_AND_FLAGS_v01.md"),
        authentic_extra_cases=extras, extra_provenance_ref=pin(HERE / "preregistered_v01/source-provenance.json"),
        full_regression_ref=pin(HERE / "assessment_v02/regression.json"),
        api_audit_ref=budget_ref, new_experiment_spend_usd=budget["actual_new_experiment_charged_or_reserved_usd"],
        tests=dict(passed=tests, failures=failures, receipt_ref=pin(xml), browser_tests_performed=False,
            scope="Owned engine/provenance/DTO/presentation plus inherited v03 coordinates and source guards"),
        source_manifest_ref=source_manifest_ref, final_free_bytes=headroom(), reserve_bytes=3*1024**3,
        expert_flags=["NO_ALL_SEVEN_SUCCESS_CLAIM", "UNKNOWN_REFERENCE_NOT_SCORED", "NO_NAMED_BONUS_OR_DEMONYM_PAIR",
            "AUNG_GYI_NOT_REPORTED_IS_ATTRIBUTED_ABSENCE_NOT_PROOF_OF_INITIATIVE",
            "V02_ARIAS_FAMILY_SELECTION_REGRESSION_NOT_APPROVED_FOR_LIVE",
            "SWEDISH_LITERAL_SOURCE_ATTESTED_BUT_NO_ATTESTATION_PAGE_INSPECTED",
            "ORIGIN_INPUT_AND_OLD_S2_CONTROL_ARE_NOT_ORDINARY_EVIDENCE"],
        trace_contract=dict(fresh_execution="cib-isolated-common-pipeline-execution/1",
            never_relabel_as="narrative-local-execution/3", existing_POSTRUN_GRAPH_VIEW_is_original_walk=False,
            fresh_source_handoffs_have_no_invented_graph_edges=True),
        no_git_or_publication_performed=True, dto_frozen_after_this_handoff=True)
    ref = write(HERE / "final_v01/HANDOFF.json", handoff)
    print(dict(handoff_ref=ref, ui_dto_ref=handoff["delegation_public_dto_ref"], tests=tests,
        new_spend_usd=handoff["new_experiment_spend_usd"], shared_ledger_usd=budget["shared_after_usd"],
        free_bytes=handoff["final_free_bytes"]), flush=True)


if __name__ == "__main__":
    main()
