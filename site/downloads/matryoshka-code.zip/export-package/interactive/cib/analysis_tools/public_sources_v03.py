"""Versioned full-page inspection DTO, from pinned adapter source artifacts."""
from copy import deepcopy
from matryoshka_demo.io import digest
from phase.kg_patch_20261122.swedish.isolated_engine.v03.context import source_pins, pinned_rows
from ..artifacts import HERE, ROOT, WORKSPACE, pin, read, write
from .public_study import readings_dto

ORIGIN = "CIA-RDP79T00975A004300220001-9"
DATE = "1959-02-17"


def citations(value):
    if isinstance(value, dict):
        if {"canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256"} <= value.keys():
            yield value
        for child in value.values():
            yield from citations(child)
    elif isinstance(value, list):
        for child in value:
            yield from citations(child)


def main():
    prior = HERE / "dto/public-study-complete-v02.json"
    dto = deepcopy(read(prior))
    dto.update(revision=3, supersedes_ref=pin(prior), integration_approval="ISOLATED_STUDY_ONLY_NOT_NATIVE_REPLACEMENT",
        expert_flags_ref=pin(HERE / "COVERAGE_AND_FLAGS_v01.md"))
    dto["design"]["constructor_replacement_approved"] = False
    dto["design"]["presentation_dedup_interface"] = "presentation_v01.dedup.deduplicate_reading"
    dto["design"]["preserve_native_family_selection"] = True
    controls = []
    for path in sorted((HERE / "coverage_v01").glob("delegation*/*/execution.json.gz")):
        packet = read(path)
        assert packet["native_checksum"] == digest(packet["result"])
        completion = read(path.with_name("completion.json"))
        assert completion["execution_digest"] == digest(packet)
        side = "first" if path.parent.parent.name.endswith("_first") else "second"
        controls.append(dict(variant_id=path.parent.parent.name + "__" + path.parent.name,
            position=side, window_arm="full_middle_clue", budget_arm=path.parent.name,
            case=packet["case"], plan=packet["plan"], facts=packet["plan"]["atoms"],
            readings_packet=packet["plan"]["readings_packet"], readings=readings_dto(packet),
            status="EXECUTED", execution_performed=True, execution_ref=pin(path),
            execution_contract=packet["version"], budget=packet["budget"],
            inspected_page_count=packet["result"]["source_pages_inspected"],
            inspected_page_ids=packet["result"]["inspected_page_ids"],
            source_budget=packet["result"]["source_budget"], gold=None,
            scope=dict(release="later", strict_prior=True, whole_origin_excluded=True,
                origin=ORIGIN, cutoff=DATE, exact_origin_admitted=False),
            expert_flags=["ZERO_API_BUDGET_CONTROL", "NO_ATTESTATION_PAGES_INSPECTED",
                "UNKNOWN_REFERENCE_NOT_SCORED", "NO_ORIGINAL_RETRIEVAL_WALK_CLAIMED"]))
    assert len(controls) == 6
    dto["supplemental_budget_controls"] = controls
    dto["variants"].extend(dict(variant_id=c["variant_id"], case_id=c["case"]["case_id"],
        position=c["position"], window_arm=c["window_arm"], budget_arm=c["budget_arm"],
        status=c["status"], execution_ref=c["execution_ref"], execution_performed=True) for c in controls)
    dto["source_coverage"] = dict(summary=read(HERE / "coverage_v01/summary.json"),
        literal_Swedish_attested_pages=66, literal_Swedes_attested_pages=5,
        union_attested_pages=68, all_primary_and_budget_inspected_attestation_pages=0,
        diagnosis="SOURCE_COVERAGE_MISS_BEFORE_DRAFT_GENERATION_NOT_REALIZATION_FAILURE",
        morphology_pair_added=False, query_seed_added=False, reference_stays_unknown=True)
    for case in dto["cases"]:
        case["expert_flags"].append("ISOLATED_V02_CONSTRUCTOR_HAS_ARIAS_SELECTION_REGRESSION")
        if case["execution_performed"]:
            case["expert_flags"].append("ATTESTED_SOURCE_WORD_PAGES_NOT_INSPECTED")
    window = dto["origin"]["full_window"]
    mapping = dict(canonical_page_id=dto["origin"]["canonical_page_id"], source_page=dto["origin"]["source_page"],
        source_span=[0, len(window["text"])], source_sha256=window["page_text_sha256"],
        query_windows=dto["origin"]["input_window_mappings"], read_only_input=True,
        producer_evidence_coordinates=False)
    dto["origin"].update(text=window["text"], source_sha256=window["page_text_sha256"], source_mapping=mapping)
    dto["origin"]["document"].update(text=window["text"], source_sha256=window["page_text_sha256"],
        hash=window["page_text_sha256"], source_mapping=mapping,
        text_scope="EXACT_ORIGIN_SOURCE_PAGE_FULL_WINDOW_NOT_ENTIRE_PDF", eligible_as_corpus_evidence=False)
    refs = list(citations([dto["cases"], controls, dto["historical_exact_origin_controls"]]))
    wanted_pages = {r["canonical_page_id"] for r in refs}
    wanted_docs = {r["document_id"] for r in refs}
    _, pins = source_pins()
    docs = {r["document_id"]:r for r in pinned_rows(pins["documents"])}
    quarantine = {r["page_pair_id"] for r in pinned_rows(pins["quarantine"])}
    guard_path = WORKSPACE / pins["source_quarantine_policy"]["path"]
    assert pin(guard_path)["sha256"] == pins["source_quarantine_policy"]["sha256"]
    guard = read(guard_path)
    quarantine.update(r["canonical_page_id"] for r in guard["quarantined_pages"]+guard["quarantined_jobs"])
    source_pages, provenance_only = {}, {}
    for raw in pinned_rows(pins["pages"]):
        if raw["document_id"] not in wanted_docs:
            continue
        doc = docs[raw["document_id"]]
        pid = raw["canonical_page_id"]
        when = doc["document_date_iso"]
        permitted = pid not in quarantine
        if raw["view"] != "later":
            raise ValueError("Wrong source release")
        strict = permitted and when < DATE and raw["document_id"] != ORIGIN
        old_origin_control = permitted and when == DATE and raw["document_id"] == ORIGIN
        if not strict and not old_origin_control:
            continue
        page = dict(id=pid, canonical_page_id=pid, corpus="cib", document_id=raw["document_id"], date=when,
            text=raw["text"], source_sha256=digest(raw["text"]), release="later", visibility="later",
            source_page=raw["source_page"], permitted=permitted, quarantined=not permitted,
            classification=doc.get("classification_level"), handling=doc.get("distribution_controls", []),
            eligible_for_primary_study_evidence=strict, origin_control_or_input_only=old_origin_control,
            provenance_only=pid not in wanted_pages, corroboration_added_by_page_inspection=False,
            source_artifact_sha256=pins["pages"]["sha256"])
        if pid in wanted_pages:
            source_pages[pid] = page
        else:
            provenance_only[pid] = page
    if set(source_pages) != wanted_pages:
        raise ValueError("Cited selected page missing from the exact bound source view")
    for ref in refs:
        page = source_pages[ref["canonical_page_id"]]
        if (page["document_id"] != ref["document_id"] or page["date"] != ref["date"]
                or page["source_sha256"] != ref["page_sha256"]
                or page["text"][ref["start"]:ref["end"]] != ref["text"]):
            raise ValueError("Full source page does not replay a selected citation")
    dto.update(source_pages=source_pages, provenance_only_source_pages=provenance_only,
        source_pages_contract=dict(version="verified-later-source-inspection-pages/1", selected_citations_replayed=len(refs),
            full_page_text=True, source_metadata_rewritten=False, citation_union_is_support_proof=False,
            uncited_sibling_pages_are_provenance_only=True, origin_is_ineligible_for_primary_evidence=True,
            source_artifact_pins={k:pins[k] for k in ("documents","pages","quarantine","source_quarantine_policy")}))
    dto["completeness"].update(supplemental_budget_cases=6, supplemental_budget_executed=6,
        source_pages=len(source_pages), provenance_only_pages=len(provenance_only))
    ref = write(HERE / "dto/public-study-complete-v03.json", dto)
    print(dict(dto_ref=ref, source_pages=len(source_pages), provenance_only_pages=len(provenance_only),
        completeness=dto["completeness"]), flush=True)


if __name__ == "__main__":
    main()
