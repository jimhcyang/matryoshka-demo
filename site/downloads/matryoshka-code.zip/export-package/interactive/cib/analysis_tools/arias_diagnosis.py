"""Separate exact current-core feature drift from v02 shortlist regression."""
from copy import deepcopy
from matryoshka_demo.io import digest
from matryoshka_narrative import redaction_selection as current
from ..artifacts import HERE, read, write
from ..local_compare import controls
from ..engine_v01 import selection


def main():
    saved, _ = controls()
    old, ref = next((p, r) for p, r in saved if p["case"]["case_id"] == "narrative_cib_revision_ac39b62cbc7070a340c5d62d")
    new = read(HERE / "saved_settings_v02" / old["case"]["case_id"] / "execution.json.gz")
    expected = "like former President Harmodio Arias"
    before = next(c for c in old["result"]["assessed_candidates"] if c["fill"] == expected)
    after = next(c for c in new["result"]["assessed_candidates"] if c["fill"] == expected)
    rid = after["reading_id"]
    pool = [c for c in new["result"]["assessed_candidates"] if c["reading_id"] == rid]
    parent = current.shortlist(deepcopy(pool), len(pool))
    expanded = selection.unique_surfaces(selection.shortlist(deepcopy(pool), len(pool)), len(pool))
    def listing(values):
        return [dict(rank=i, fill=c["fill"], id=c["id"], status=c["local_decision"]["status"],
            source_page_ids=[r["canonical_page_id"] for r in c["sources"]]) for i, c in enumerate(values, 1)]
    old_role = before["ranking"]["features"]["source_owned_role_context"]
    new_role = after["ranking"]["features"]["source_owned_role_context"]
    write(HERE / "coverage_v01/arias-exact-diagnosis.json", dict(case_id=old["case"]["case_id"],
        reading_id=rid, saved_control_ref=ref, saved_engine=old["result"]["version"], current_parent_engine="narrative-bounded-red-construction/27",
        plan_identical=old["plan"] == new["plan"],
        inspected_pages_identical=old["result"]["inspected_page_ids"] == new["result"]["inspected_page_ids"],
        inspected_page_ids=old["result"]["inspected_page_ids"],
        source_citations_identical=before["sources"] == after["sources"], source_citations=after["sources"],
        source_span=after["source_span"], unchanged_retrieval_page_rank=after["ranking"]["features"]["retrieval_page_rank"],
        old_rank_key=before["context_rank_key"], new_rank_key=after["context_rank_key"],
        changed_key_positions=[dict(index=i, old=a, new=b) for i, (a,b) in enumerate(zip(before["context_rank_key"],after["context_rank_key"])) if a != b],
        old_owned_role=old_role, current_owned_role=new_role,
        old_feasibility=before["source_candidate_feasibility"], current_feasibility=after["source_candidate_feasibility"],
        factual_status_before=before["local_decision"]["status"], factual_status_after=after["local_decision"]["status"],
        current_parent_shortlist_replay=listing(parent), v02_expanded_surface_replay=listing(expanded),
        replay_is_not_a_fresh_canonical_execution=True,
        diagnosis="All 32 pages and the Arias citation are identical. Historical /13 treats politico in politico-economic power as politician.n.02 for the copular descriptor; current /27 owned-role guard does not. Source feasibility changes POSITIVE_SOURCE_CLUE to NO_INFO, not factual status. In the SAME current assessed pool parent family selection puts the full Arias fill at 5; v02 additionally admits shorter like Remon from that family, displacing Arias to 6. Thus v02 has a real independent selection regression, not merely version drift or a viewer artifact.",
        integration_recommendation="DO NOT PROMOTE v02 AS A REPLACEMENT. Deduplicate only the already natively selected surfaces for presentation; preserve native family selection.",
        no_named_rule_added=True, no_role_guard_weakened=True))
    print("Arias: identical 32 pages and source; old rank 1, current parent shortlist 5, v02 expanded-surface rank 6", flush=True)


if __name__ == "__main__":
    main()
