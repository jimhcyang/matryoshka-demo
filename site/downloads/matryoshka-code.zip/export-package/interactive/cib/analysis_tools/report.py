"""Assessment-only regression/provenance summary, never an engine input."""
from collections import Counter
from pathlib import Path
from matryoshka_demo.io import digest
from ..artifacts import HERE, ROOT, WORKSPACE, read, pin, write, headroom
from ..local_compare import controls, rows
from ..engine_v01 import selection

HISTORICAL = {
    "narrative_cib_revision_ac39b62cbc7070a340c5d62d": "like former President Harmodio Arias",
    "narrative_cib_revision_3eea5176c0eab4abfb6452a4": "the air force commander",
    "cloze_132dbc991d56c1c3ff66331a": "and Betancourt",
    "cloze_225a750400eb38718fa5bb9b": "corrupt",
    "narrative_cib_revision_ac4fb499beb4b345b5384ae6": "Brigadier Aung Gyi's",
    "narrative_cib_revision_50e63144067940b5debe3fea": "easily politically manipulated",
}


def norm(value):
    return " ".join(value.casefold().split())


def result_summary(result, expected=None):
    selected = rows(result)
    found = [r for r in selected if expected is not None and norm(r["fill"]) == norm(expected)]
    audit = result.get("_candidate_audit", {})
    assessed = [c for c in result.get("assessed_candidates", []) if expected is not None and norm(c["fill"]) == norm(expected)]
    return dict(candidates=selected, reading_outcomes=[dict(reading_id=r["reading"]["id"],
        reading=r["reading"], count=len(r["candidates"]), unsupported=not r.get("constructor_reading")) for r in result["readings"]],
        historical_fill=expected, historical_fill_is_not_gold=True,
        historical_selected=found, historical_assessed=[dict(id=c["id"], fill=c["fill"],
            local_decision=c["local_decision"], sources=c["sources"]) for c in assessed],
        matching_source_groups=[r for r in audit.get("source_groups", []) if expected is not None and norm(r["fill"]) == norm(expected)],
        matching_rejections=[r for r in audit.get("rejections", []) if expected is not None and norm(r.get("fill", "")) == norm(expected)],
        inspected_page_ids=result.get("inspected_page_ids", []),
        statuses=dict(Counter(r["status"] for r in selected)),
        duplicate_display_surfaces=[dict(reading_id=r["reading_id"], fill=r["fill"], count=r["duplicate_display_count"])
            for r in selected if r["duplicate_display_count"] > 1])


def trace_audit():
    report = read(WORKSPACE / "matryoshka_demo_site/site/data/report-v6.json")
    output = []
    for row in report["cases"]:
        if row["case"]["case_id"] not in HISTORICAL:
            continue
        for reading, ref in row["configurations"]["llm_readings"]["trace_refs"].items():
            path = ROOT / ref["path"]
            assert pin(path)["sha256"] == ref["sha256"]
            trace = read(path)
            steps = {s["id"]: s for s in trace["steps"]}
            modes = Counter()
            for route in trace["paths"]:
                modes[route["route_mode"]] += 1
                actual_edges = [e for sid in route["steps"] for e in steps[sid]["edges"]]
                assert len(actual_edges) == route["graph_hops"]
                assert all(e.get("citation") for e in actual_edges)
                assert route["decision_source_refs"]
                if route["route_mode"] == "POSTRUN_GRAPH_VIEW":
                    assert route["original_traversal_claimed"] is False
            output.append(dict(case_id=row["case"]["case_id"], reading_id=reading, trace_ref=pin(path),
                route_modes=dict(modes), actual_edges_and_source_endpoints_checked=True,
                relabeled=False, postrun_is_original_walk=False))
    return output


def main(output="assessment_v01"):
    if output not in {"assessment_v01", "assessment_v02", "assessment_v03"}:
        raise ValueError("Versioned assessment path required")
    saved, report = controls()
    cases, flat, completions = [], [], []
    for old, ref in saved:
        cid = old["case"]["case_id"]
        expected = HISTORICAL[cid]
        arms = {"saved_control": dict(native_ref=ref, result=result_summary(old["result"], expected),
            engine_version=old["result"]["version"], configuration=old["configuration"])}
        for name in ("local_v01", "fresh_v01", "saved_settings_v02", "fresh_v02"):
            path = HERE / name / cid / ("posthoc.json.gz" if name == "local_v01" else "execution.json.gz")
            if not path.exists():
                arms[name] = dict(not_executed=True)
                continue
            packet = read(path)
            result = packet["result"]
            if "native_checksum" in packet:
                assert digest(result) == packet["native_checksum"]
                completion = read(path.with_name("completion.json"))
                assert completion["execution_digest"] == digest(packet)
                assert completion["execution_ref"] == pin(path)
                completions.append(pin(path.with_name("completion.json")))
            arms[name] = dict(native_ref=pin(path), result=result_summary(result, expected),
                engine_version=result.get("version", "saved-pool-posthoc-only"), configuration=packet.get("configuration"))
        cases.append(dict(case_id=cid, original_document_id=old["case"]["document_id"], date=old["case"]["date"], arms=arms))
        for arm, detail in arms.items():
            for candidate in detail.get("result", {}).get("candidates", []):
                flat.append(dict(case_id=cid, arm=arm, **candidate))
    public = read(HERE / "preregistered_v01/public-cases.json")
    experiments = []
    for spec in public["delegation"] + [dict(case=c, arm="authentic_extra") for c in public["extra_cases"]]:
        case = spec["case"]
        path = HERE / "fresh_v02" / case["case_id"] / "execution.json.gz"
        if not path.exists():
            experiments.append(dict(case_id=case["case_id"], arm=spec["arm"], executed=False,
                failure_paths=[str(p.relative_to(HERE)) for p in path.parent.glob("*failure.json")]))
            continue
        packet = read(path)
        assert digest(packet["result"]) == packet["native_checksum"]
        completion = read(path.with_name("completion.json"))
        assert completion["execution_digest"] == digest(packet)
        assert completion["execution_ref"] == pin(path)
        completions.append(pin(path.with_name("completion.json")))
        for candidate in packet["result"]["candidates"]:
            for ref in candidate["sources"]:
                assert ref["date"] < case["date"] and ref["document_id"] != case["document_id"]
        plan = packet["plan"]
        summary = dict(case_id=case["case_id"], arm=spec["arm"], focal=spec.get("focal"), executed=True,
            native_ref=pin(path), visible_clue_given=spec.get("visible_clue_given", False), gold=None,
            visible_clue_is_corpus_proof=False, result=result_summary(packet["result"]),
            original_retrieval_walk_recorded=False, trace_contract=packet["trace_contract"],
            source_adapter=packet["source_adapter"],
            shared_facts_preserved=plan["atoms"], extractions=plan.get("extractions", {}),
            planning_ref=pin(path.with_name("normal-plan.json")), readings_ref=pin(path.with_name("normal-readings.json")))
        experiments.append(summary)
        for candidate in summary["result"]["candidates"]:
            flat.append(dict(case_id=case["case_id"], arm=spec["arm"], **candidate))
    trace_rows = trace_audit()
    write(HERE / output / "regression.json", dict(version="cib-assessment-only-regression/1", report_ref=report,
        cases=cases, context_and_extra_experiments=experiments, exact_candidate_rows=flat,
        saved_trace_audit=trace_rows, completion_refs=completions,
        outcome_informed_development=True, benchmark_accuracy_claimed=False,
        unknown_reference_cases_not_scored=True, expected_guesses_not_inserted=True))
    print("Verified", len(completions), "fresh completions;", len(flat), "candidate rows;", len(trace_rows), "original trace references")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="assessment_v01")
    main(parser.parse_args().output)
