"""Late-field inspection projection; never rewrite native ranks or decisions.

Canonical construction attaches fit scorecards to its assessed occurrences AFTER
shortlisting. Exact-surface display copies therefore need a late-field join by
candidate ID. All computations already exist in the sealed raw execution.
"""
from copy import deepcopy
from matryoshka_demo.io import digest
from ..artifacts import HERE, pin, read, write


def project(packet):
    result = packet["result"]
    assessed = {c["id"]: c for c in result.get("assessed_candidates", [])}
    rows = []
    for reading in result["readings"]:
        candidates = []
        for original in reading["candidates"]:
            candidate = deepcopy(original)
            full = assessed[candidate["id"]]
            for field in ("fit_scorecard", "ending_utility", "legacy_context_utility_not_used_for_ordering"):
                if field in full:
                    if field in candidate and candidate[field] != full[field]:
                        raise ValueError("Inspection join cannot replace a conflicting computed field")
                    candidate[field] = deepcopy(full[field])
            group = candidate.get("surface_duplicate_group")
            if group:
                complete = []
                for variant in group["source_variants"]:
                    raw = assessed[variant["id"]]
                    if raw["local_decision"] != variant["local_decision"] or raw["sources"] != variant["sources"]:
                        raise ValueError("Independent decision/source proof changed")
                    complete.append(deepcopy(raw))
                group["source_variants"] = complete
            assert candidate["rank"] == original["rank"] and candidate["fill"] == original["fill"]
            assert candidate["local_decision"] == original["local_decision"]
            candidates.append(candidate)
        rows.append(dict(reading=reading["reading"], candidates=candidates))
    return dict(version="cib-complete-independent-inspection-projection/1", readings=rows,
        native_result_sha256=digest(result), native_judgments_modified=False,
        computed_scorecards_joined_by_exact_candidate_id=True, source_proofs_merged=False,
        new_scoring_performed=False, new_inference_performed=False)


def main():
    for variant in ("fresh_v01", "fresh_v02", "saved_settings_v02"):
        for path in sorted((HERE / variant).glob("*/execution.json.gz")):
            packet = read(path)
            projected = project(packet)
            projected["execution_ref"] = pin(path)
            write(HERE / "inspection_v01" / variant / path.parent.name / "inspection.json.gz", projected)


if __name__ == "__main__":
    main()
