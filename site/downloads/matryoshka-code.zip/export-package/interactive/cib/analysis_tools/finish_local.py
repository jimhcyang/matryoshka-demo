"""Resume unpaid v02 comparisons after an older optional-config-field mismatch."""
from matryoshka_next.workflow import Session
from .. import run_v01
from ..run_v02 import _RUN
from ..artifacts import HERE, write
from ..engine_v01.construction import fork_functions
from ..engine_v02.construction import construct
from ..local_compare import controls, rows


def main():
    write(HERE / "fresh_v02/local-resume-receipt.json", dict(
        original_failure="KeyError: selection_profile", case_id="narrative_cib_revision_ac4fb499beb4b345b5384ae6",
        cause="Historical /6 configuration omitted optional selection_profile; no inference ran for this case before failure",
        repair="Supply explicit None in the runner configuration only", provider_calls=0,
        previous_outputs_preserved=True, inference_sources_modified=False))
    saved, _ = controls()
    summaries = []
    with Session() as session:
        context = session.context("cib")
        for old, ref in saved:
            config = {"selection_profile": None, **old["configuration"]}
            matched = fork_functions(run_v01, construct=construct, CONFIG=config, OUT=HERE / "saved_settings_v02")
            packet, matched_ref = matched["execute"](old["public_case"], old["plan"], context.corpus,
                context.source_index, label="saved_settings_fresh_dedup_only")
            common, common_ref = _RUN["execute"](old["public_case"], old["plan"], context.corpus,
                context.source_index, label="fresh_common_pipeline_cached_query_plan_readings")
            summaries.append(dict(case_id=old["case"]["case_id"], control_ref=ref,
                matched_settings_ref=matched_ref, common_ref=common_ref, control=rows(old["result"]),
                matched_settings=rows(packet["result"]), common=rows(common["result"])))
    write(HERE / "fresh_v02/six-summary.json", dict(version="six-cib-conservative-regression/2",
        cases=summaries, api_calls=0, configs_compared_separately=True))


if __name__ == "__main__":
    main()
