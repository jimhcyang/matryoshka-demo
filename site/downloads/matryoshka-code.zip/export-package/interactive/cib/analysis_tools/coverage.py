"""Zero-API source-coverage diagnosis and preregistered budget-only controls."""
from collections import defaultdict
from copy import deepcopy
import gc
import re
import time
import numpy as np
from matryoshka_demo.io import digest
from matryoshka_demo.corpus import ordered
from matryoshka_demo.retrieval import rrf
from matryoshka_demo.retrieval_v5 import searches
from phase.kg_patch_20261122.swedish.isolated_engine.run_study import cite_replay
from ..artifacts import HERE, pin, read, write, headroom, code_pins
from ..engine_v01 import source_adapter
from ..engine_v02.construction import construct
from ..prepare_v01 import CONFIG


def ranking_channels(corpus, case, plan, found):
    eligible = found["eligible"]
    families, atom_ranks = defaultdict(list), []
    for search in searches(plan, case):
        scores = corpus.page_bm25.score(search["query"], eligible.page_mask, eligible.page_stats)
        order = ordered(scores, corpus.page_ids)
        families[search["kind"]].append(order)
        atom_ranks.append((search["id"], {pi: (rank, float(scores[pi])) for rank, pi in enumerate(order, 1)}))
    lexical, _ = rrf([rrf(ranks)[0] for ranks in families.values()])
    degree = np.zeros(len(corpus.nodes))
    for ui, ni in corpus.membership:
        if eligible.unit_mask[ui]:
            degree[ni] += 1
    mass = np.zeros(len(corpus.pages))
    for ui, ni in corpus.membership:
        if eligible.unit_mask[ui] and degree[ni]:
            mass[corpus.units[ui]["pi"]] += found["node_mass"][ni] / degree[ni]
    graph = ordered(mass, corpus.page_ids)
    return ({pi: rank for rank, pi in enumerate(lexical, 1)},
        {pi: rank for rank, pi in enumerate(graph, 1)}, atom_ranks)


def result_coverage(result):
    groups = result["_candidate_audit"]["source_groups"]
    return dict(
        matching_groups=[g for g in groups if re.search(r"\b(?:Swedish|Swedes)\b", g["fill"], re.I)],
        matching_rejections=[g for g in result["_candidate_audit"]["rejections"]
            if re.search(r"\b(?:Swedish|Swedes)\b", g.get("fill", ""), re.I)],
        readings=[dict(reading_id=r["reading"]["id"], outer_family=r["reading"]["outer_family"],
            constructor_form=r["reading"]["constructor_form"], candidates=[dict(id=c["id"], rank=c["rank"],
                fill=c["fill"], status=c["local_decision"]["status"], sources=c["sources"])
                for c in r["candidates"]]) for r in result["readings"]],
        inspected_page_ids=result["inspected_page_ids"],
        unassessed_matching=[g for g in result["unassessed_remainder"]
            if re.search(r"\b(?:Swedish|Swedes)\b", g["fill"], re.I)])


def main():
    specs = read(HERE / "preregistered_v01/public-cases.json")["delegation"]
    write(HERE / "coverage_v01/design.json", dict(version="zero-api-coverage-budget-diagnostic/1",
        established_before_budget_control_results=True, provider_calls_authorized=0,
        budgets=[dict(name="pages24_docs40", construction_pages=24, retrieval_documents=40, retrieval_pages=80),
            dict(name="pages48_docs40", construction_pages=48, retrieval_documents=40, retrieval_pages=80),
            dict(name="pages48_docs120", construction_pages=48, retrieval_documents=120, retrieval_pages=160)],
        control_cases=[s["case"]["case_id"] for s in specs if s["arm"] == "full_middle_clue"],
        same_saved_plans_readings=True, same_source_gates=True, same_draft_budget=64,
        diagnostic_term_scan_is_not_a_query_seed=True, correctness_not_forced=True,
        unknown_reference=None, all_outcomes_retained=True))
    corpus = source_adapter.load_context(specs[0]["case"])
    hits = []
    policy = corpus.policy_for(specs[0]["case"])
    for pi, page in enumerate(corpus.pages):
        if not policy.allowed(pi):
            continue
        found = list(re.finditer(r"\b(?:Swedish|Swedes)\b", page["text"], re.I))
        if found:
            hits.append(dict(pi=pi, page_id=page["id"], document_id=page["document_id"], date=page["date"],
                source_page=page["source_page"], page_sha256=page["source_sha256"],
                word_citations=[policy.citation(pi, m.start(), m.end()) for m in found],
                excerpts=[dict(start=max(0,m.start()-160), end=min(len(page["text"]),m.end()+240),
                    text=page["text"][max(0,m.start()-160):min(len(page["text"]),m.end()+240)]) for m in found]))
    write(HERE / "coverage_v01/eligible-attestations.json", dict(source_view_sha256=digest(corpus.binding),
        strict_prior_whole_origin=True, eligible_pages=int(policy.mask().sum()), hit_pages=hits,
        diagnostic_not_engine_input=True))
    summaries = []
    for spec in specs:
        case = spec["case"]
        path = HERE / "fresh_v02" / case["case_id"] / "execution.json.gz"
        if not path.exists():
            summaries.append(dict(case_id=case["case_id"], execution_not_available=True,
                no_plan_or_outcome_fabricated=True))
            continue
        packet = read(path)
        plan, result = packet["plan"], packet["result"]
        headroom()
        found = source_adapter.retrieve(corpus, case, plan, document_budget=40, passage_budget=80)
        # Recomputed diagnostics must describe the exact prior deterministic run.
        assert found["receipt"] == packet["retrieval"]
        lexical, graph, atom = ranking_channels(corpus, case, plan, found)
        admitted = {pi: rank for rank, pi in enumerate(found["pages"], 1)}
        inspected = {pid: rank for rank, pid in enumerate(result["inspected_page_ids"], 1)}
        scan = {r["page_id"]: r for r in result["source_budget"]["selection_scan"]}
        hit_rows = [dict(**hit, bm25_rrf_rank=lexical.get(hit["pi"]), graph_mass_rank=graph.get(hit["pi"]),
            combined_rank=found["page_ranks"].get(hit["pi"]), admitted_page_rank=admitted.get(hit["pi"]),
            inspected_position=inspected.get(hit["page_id"]), selection_scan=scan.get(hit["page_id"]),
            atom_bm25=[dict(atom_id=aid, rank=ranks.get(hit["pi"], (None,None))[0],
                score=ranks.get(hit["pi"], (None,None))[1]) for aid, ranks in atom],
            native_observations_on_page=len(corpus.occurrences_by_page.get(hit["pi"], []))) for hit in hits]
        row = dict(case_id=case["case_id"], arm=spec["arm"], focal=spec["focal"], execution_ref=pin(path),
            source_hit_pages=hit_rows, result_coverage=result_coverage(result),
            reading_definitions=[r["reading"] for r in result["readings"]])
        write(HERE / "coverage_v01" / case["case_id"] / "coverage.json", row)
        summaries.append(dict(case_id=case["case_id"], eligible_lexical_hit_pages=len(hits),
            hits_admitted=sum(r["admitted_page_rank"] is not None for r in hit_rows),
            hits_inspected=sum(r["inspected_position"] is not None for r in hit_rows),
            best_bm25_rank=min((r["bm25_rrf_rank"] for r in hit_rows if r["bm25_rrf_rank"]), default=None),
            best_graph_rank=min((r["graph_mass_rank"] for r in hit_rows if r["graph_mass_rank"]), default=None),
            matching_groups=len(row["result_coverage"]["matching_groups"])))
        print(summaries[-1], flush=True)
        if spec["arm"] == "full_middle_clue":
            for name, pages, docs, retrieval_pages in (("pages24_docs40",24,40,80),
                    ("pages48_docs40",48,40,80),("pages48_docs120",48,120,160)):
                headroom()
                current = found if docs == 40 else source_adapter.retrieve(corpus, case, plan,
                    document_budget=docs, passage_budget=retrieval_pages)
                start = time.perf_counter()
                observed = construct(case, plan, current, source_index=corpus.source_index,
                    source_policy=corpus.policy_for(case), passage_budget=pages, draft_budget=64,
                    selection_profile=CONFIG["selection_profile"], top_k=5)
                replayed = cite_replay(observed, corpus.policy_for(case))
                output = dict(version="cib-local-coverage-budget-execution/1", original_canonical_native_execution=False,
                    case=case, plan=plan, result=observed, native_checksum=digest(observed),
                    parent_execution_ref=pin(path), source_view_sha256=digest(corpus.binding),
                    budget=dict(construction_pages=pages, retrieval_documents=docs, retrieval_pages=retrieval_pages,
                        draft_budget=64, selection_profile=CONFIG["selection_profile"]),
                    retrieval=current["receipt"], api_calls=0, unknown_reference=None,
                    citations_replayed=replayed, seconds=time.perf_counter()-start, code_pins=code_pins(),
                    original_retrieval_walk_recorded=False)
                target = HERE / "coverage_v01" / case["case_id"] / name / "execution.json.gz"
                ref = write(target, output)
                write(target.with_name("completion.json"), dict(version="cib-local-coverage-budget-completion/1",
                    execution_ref=ref, execution_digest=digest(output), native_checksum=digest(observed)))
                readout = result_coverage(observed)
                write(target.with_name("coverage.json"), readout)
                print(dict(case_id=case["case_id"], budget=name, candidates=[(c["rank"],c["fill"],c["status"])
                    for r in readout["readings"] for c in r["candidates"]],
                    matching_groups=len(readout["matching_groups"]), citations_replayed=replayed), flush=True)
                del observed, output, current
                gc.collect()
        del found
        gc.collect()
    write(HERE / "coverage_v01/summary.json", dict(cases=summaries, api_calls=0, eligible_hit_pages=len(hits),
        no_hidden_word_correctness_claimed=True))


if __name__ == "__main__":
    main()
