"""Neutral public-study DTO from actual executions, including failed arms."""
from copy import deepcopy
import hashlib
import re
from matryoshka_demo.io import digest
from phase.kg_patch_20261122.swedish.isolated_engine.v03.context import source_pins, pinned_rows
from ..artifacts import HERE, ROOT, read, pin, write
from .complete_views import project


def origin_packet(specs):
    _, pins = source_pins()
    pages = [p for p in pinned_rows(pins["pages"])
        if p["canonical_page_id"] == "page_d884726ce3791d6d8092"]
    if len(pages) != 1:
        raise ValueError("Exact origin page missing or duplicated")
    page = pages[0]
    provenance = read(HERE / "preregistered_v01/source-provenance.json")
    bound = provenance["delegation_origin_page"]
    assert digest(page["text"]) == bound["text_sha256"]
    assert page["document_id"] == provenance["delegation_origin_document"]["document_id"]
    text = page["text"]
    paragraphs = list(re.finditer(r"[^\n]+(?:\n(?!\n)[^\n]+)*", text))
    if len(paragraphs) != 7:
        raise ValueError("Original source paragraph boundaries changed")
    mappings = []
    for spec in specs:
        query = spec["case"]["query"]
        offset, pieces = 0, []
        for index in spec["original_paragraph_indices"]:
            source = paragraphs[index]
            original = source.group()
            rendered = original
            needle = "visiting [REDACTED] military delegation" if spec["focal"] == "first" else "The [REDACTED] delegation"
            if needle in original:
                rendered = original.replace(needle, needle.replace("[REDACTED]", "[MASK]"), 1)
            assert query[offset:offset+len(rendered)] == rendered
            source_span = [source.start(), source.end()]
            value = dict(paragraph_index=index, source_span=source_span,
                query_span=[offset, offset+len(rendered)], source_text_sha256=digest(original),
                exact_source_text=original, rendered_query_text=rendered,
                transformation="OPAQUE_FOCAL_MARKER_ONLY" if rendered != original else "EXACT_SOURCE_PARAGRAPH")
            if rendered != original:
                local = original.index(needle) + needle.index("[REDACTED]")
                value["focal_source_span"] = [source.start()+local, source.start()+local+len("[REDACTED]")]
                value["focal_query_span"] = [query.index("[MASK]"), query.index("[MASK]")+len("[MASK]")]
            pieces.append(value)
            offset += len(rendered) + 2
        mappings.append(dict(case_id=spec["case"]["case_id"], segments=pieces, query_sha256=digest(query),
            producer_observation_coordinates=False, mapping_purpose="READ_ONLY_INPUT_WINDOW_NOT_EVIDENCE"))
    return dict(document_id=page["document_id"], date="1959-02-17", canonical_page_id=page["canonical_page_id"],
        source_page=page["source_page"], release="later", full_window=dict(start=0, end=len(text), text=text,
            page_text_sha256=digest(text), hash_convention="matryoshka_demo.io.digest(text)",
            raw_utf8_sha256=hashlib.sha256(text.encode()).hexdigest()),
        source_artifact_ref=pins["pages"], document=provenance["delegation_origin_document"],
        input_only=True, eligible_as_corpus_evidence=False, entire_origin_excluded=True,
        visible_Swedes_is_explicit_given_clue=True, visible_clue_is_corpus_proof=False,
        all_other_unknown_masks_preserved=True, input_window_mappings=mappings)


def readings_dto(packet):
    projected = project(packet)
    output = []
    for row in projected["readings"]:
        candidates = []
        for original in row["candidates"]:
            candidate = deepcopy(original)
            group = candidate.pop("surface_duplicate_group", None)
            variants = group["source_variants"] if group else [deepcopy(original)]
            candidate.update(source_variants=variants,
                citation_union=group["citation_union"] if group else deepcopy(candidate["sources"]),
                citation_union_is_support_proof=False, individual_source_decisions_preserved=True)
            candidates.append(candidate)
        output.append(dict(reading=row["reading"], candidates=candidates))
    return output


def case_dto(spec, directory):
    case = spec["case"]
    execution = directory / "execution.json.gz"
    plan_path, reading_path = directory / "normal-plan.json", directory / "normal-readings.json"
    plan = read(plan_path)["native_plan"] if plan_path.exists() else None
    selected = read(reading_path)["packet"] if reading_path.exists() else None
    failures = [read(p) for p in sorted(directory.glob("*failure.json"))]
    result = dict(position=spec["focal"], window_arm=spec["arm"], case=case, gold=None, reference_answer=None,
        facts=plan["atoms"] if plan else [], plan=plan, readings_packet=selected,
        readings=[dict(reading=r, candidates=[]) for r in selected["readings"]] if selected else [],
        status="PLANNING_FAILED" if failures else "EXECUTION_PENDING" if selected else "PLANNING_PENDING",
        execution_performed=False, execution_ref=None, inspected_page_count=None,
        failures=failures, visible_clue_given=spec["visible_clue_given"], visible_clue_is_corpus_proof=False,
        scope=dict(release="later", cutoff=case["date"], strict_prior=True, origin=case["document_id"],
            whole_origin_excluded=True, exact_origin_admitted=False, retrospective_source_view=True),
        expert_flags=["UNKNOWN_REFERENCE_NOT_SCORED", "INPUT_CLUE_IS_NOT_CORPUS_PROOF",
            "NO_NATIONALITY_ASSUMED_IN_QUERY_PLANNING", "SOURCE_WORDING_ALONE_DOES_NOT_PROVE_FOCAL_ACTION"],
        provider_planning_ref=pin(plan_path) if plan_path.exists() else None,
        provider_readings_ref=pin(reading_path) if reading_path.exists() else None)
    if execution.exists():
        packet = read(execution)
        assert digest(packet["result"]) == packet["native_checksum"]
        result.update(status="EXECUTED", execution_performed=True, execution_ref=pin(execution),
            execution_contract=packet["version"], original_canonical_native_execution=False,
            plan=packet["plan"], facts=packet["plan"]["atoms"], readings=readings_dto(packet),
            inspected_page_count=packet["result"]["source_pages_inspected"],
            inspected_page_ids=packet["result"]["inspected_page_ids"],
            source_budget=packet["result"]["source_budget"],
            trace_contract=packet["trace_contract"],
            selected_evidence_handoffs=packet["selected_evidence_handoffs"],
            native_result_sha256=packet["native_checksum"])
        for row in result["readings"]:
            for candidate in row["candidates"]:
                for ref in candidate["sources"]:
                    if ref["document_id"] == case["document_id"] or ref["date"] >= case["date"]:
                        raise ValueError("Ineligible source in public study")
    return result


def main(name):
    if name not in {"public-study-planning-v01.json", "public-study-complete-v02.json", "public-study-complete-v03.json"}:
        raise ValueError("Explicit versioned DTO filename required")
    specs = read(HERE / "preregistered_v01/public-cases.json")["delegation"]
    cases = [case_dto(spec, HERE / "fresh_v02" / spec["case"]["case_id"]) for spec in specs]
    arms = []
    for arm in dict.fromkeys(r["arm"] for r in specs):
        pair = [r for r in specs if r["arm"] == arm]
        arms.append(dict(id=arm, paragraph_indices=pair[0]["original_paragraph_indices"],
            middle_present="full_middle" in arm, visible_clue_given=pair[0]["visible_clue_given"],
            case_ids=[r["case"]["case_id"] for r in pair], equal_two_focal_queries=True))
    controls = []
    old = ROOT / "phase/kg_patch_20261122/swedish/isolated_engine/attempt03"
    for position in ("first", "second"):
        path = old / position / "execution.json.gz"
        packet = read(path)
        # Old packets do not use this experiment's late detached display copies.
        inherited = []
        for row in packet["result"]["readings"]:
            inherited.append(dict(reading=row["reading"], candidates=deepcopy(row["candidates"])))
        controls.append(dict(position=position, case=packet["case"], gold=None, plan=packet["plan"],
            facts=packet["plan"]["atoms"], readings=inherited,
            inspected_page_count=packet["result"]["source_pages_inspected"], execution_ref=pin(path),
            execution_contract=packet["version"], ordinary_evidence=False,
            scope=dict(exact_origin_admitted=True, retrospective_prior_plus_exact_origin=True),
            control_only=True, original_canonical_native_execution=False))
    completed = sum(c["execution_performed"] for c in cases)
    dto = dict(version="cib-delegation-public-study/1", title="Delegation Context / Unknown Reference",
        design=dict(window_arms=arms, focal_positions=["first", "second"], preregistered=True,
            design_ref=pin(HERE / "preregistered_v01/design.json"),
            engine_variant="cib-canonical-pages-exact-surface-construction/2",
            engine_rationale_ref=pin(HERE / "ENGINE_V02_RATIONALE.md"),
            configuration=read(HERE / "preregistered_v01/design.json")["ordinary_and_delegation_configuration"],
            unknown_gold=True, no_expected_word_inserted=True, no_named_bonus=True,
            no_dictionary_demonyms=True, parsed_shared_facts_preserved=True,
            last_paragraph_definition="Last delegation paragraph, before the separate tactical-exercise clue"),
        origin=origin_packet(specs), cases=cases,
        variants=[dict(window_arm=c["window_arm"], position=c["position"], case_id=c["case"]["case_id"],
            status=c["status"], execution_performed=c["execution_performed"], execution_ref=c["execution_ref"])
            for c in cases],
        historical_exact_origin_controls=controls,
        completeness=dict(expected_cases=8, executed_cases=completed,
            planning_failed_cases=sum(c["status"] == "PLANNING_FAILED" for c in cases),
            pending_cases=sum(c["status"].endswith("PENDING") for c in cases),
            all_variants_visible=True, all_cases_successful_claimed=False),
        canonical_baseline_modified=False, publication_performed=False,
        trace_policy=dict(postrun_graph_view_is_original_walk=False,
            fresh_graph_routes_invented=False, direct_source_handoffs_only=True))
    ref = write(HERE / "dto" / name, dto)
    print(dict(dto_ref=ref, completeness=dto["completeness"]), flush=True)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("name")
    main(parser.parse_args().name)
