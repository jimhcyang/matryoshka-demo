"""Reconstruct saved native controls, then a clearly post-hoc local dedup arm."""
from collections import Counter
from copy import deepcopy
from matryoshka_demo.io import digest
from .artifacts import HERE, ROOT, WORKSPACE, read, pin, write, code_pins
from .engine_v01.selection import shortlist, unique_surfaces


def controls():
    report_path = WORKSPACE / "matryoshka_demo_site/site/data/report-v6.json"
    report = read(report_path)
    result = []
    for row in report["cases"]:
        if row["case"]["corpus"] != "cib" or row["case"]["task"] != "redaction":
            continue
        ref = row["configurations"]["llm_readings"]["native_checkpoint"]
        path = ROOT / ref["path"]
        if pin(path)["sha256"] != ref["sha256"]:
            raise ValueError("Original report native reference changed")
        packet = read(path)
        if packet["native_checksum"] != digest(packet["result"]):
            raise ValueError("Saved native result checksum changed")
        if packet["public_case"] != row["case"]:
            raise ValueError("Report and native public cases differ")
        result.append((packet, pin(path)))
    if len(result) != 6:
        raise ValueError("Expected exactly six current CIB redaction controls")
    return result, pin(report_path)


def rows(result):
    output = []
    for reading in result["readings"]:
        counts = Counter(" ".join(c["fill"].split()).casefold() for c in reading["candidates"])
        for c in reading["candidates"]:
            output.append(dict(reading_id=reading["reading"]["id"], rank=c["rank"], fill=c["fill"],
                status=c["local_decision"]["status"], candidate_id=c["id"],
                sources=c["sources"], local_decision_sha256=digest(c["local_decision"]),
                duplicate_display_count=counts[" ".join(c["fill"].split()).casefold()],
                source_variants=len(c.get("surface_duplicate_group", {}).get("source_variants", [c]))))
    return output


def main():
    saved, report = controls()
    summaries = []
    for packet, ref in saved:
        result = packet["result"]
        views = []
        for r in result["readings"]:
            pool = deepcopy([c for c in result["assessed_candidates"] if c["reading_id"] == r["reading"]["id"]])
            context = {c["id"]: c["context_ordering"]["exact_key"] for c in pool} if pool and "context_ordering" in pool[0] else None
            tiers = {c["id"]: c["context_priority"]["effective_ordering_tier"] for c in pool} if pool and "context_priority" in pool[0] else None
            selected = unique_surfaces(shortlist(pool, len(pool), context_keys=context, ordering_tiers=tiers), 5)
            for rank, c in enumerate(selected, 1):
                c["rank"] = rank
            views.append(dict(reading=deepcopy(r["reading"]), candidates=selected))
        after = dict(readings=views)
        target = HERE / "local_v01" / packet["case"]["case_id"] / "posthoc.json.gz"
        after_ref = write(target, dict(version="saved-pool-posthoc-dedup/1", saved_native_ref=ref,
            fresh_inference=False, new_api_calls=0, original_assessed_pool_sha256=digest(result["assessed_candidates"]),
            result=after))
        summaries.append(dict(case_id=packet["case"]["case_id"], saved_native_ref=ref,
            configuration=packet["configuration"], control=rows(result), posthoc=rows(after), posthoc_ref=after_ref))
    write(HERE / "local_v01/comparison.json", dict(report_ref=report, cases=summaries,
        code_pins=code_pins(), new_api_calls=0, fresh_inference=False))
    for row in summaries:
        print(row["case_id"], [(c["fill"], c["rank"], c["status"], c["source_variants"]) for c in row["posthoc"]], flush=True)


if __name__ == "__main__":
    main()
