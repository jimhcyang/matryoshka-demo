"""Preregister query windows from pinned original source bytes, before calls."""
from datetime import datetime, timezone
import re
from matryoshka_demo.io import digest
from phase.kg_patch_20261122.swedish.isolated_engine.v03.context import source_pins, pinned_rows
from .artifacts import HERE, ROOT, WORKSPACE, read, pin, write
from .local_compare import controls

ORIGIN = "CIA-RDP79T00975A004300220001-9"
DATE = "1959-02-17"
EXTRAS = ("slot_f9468e1544a9a7b29da1", "slot_target_f5e863d6c4ba5f790e", "slot_target_c99e5ba52323601c5f")
PROFILE = dict(page_focal_fraction=.5, candidate_focal_fraction=.5, scan_pages=512,
    identity_first=True, cue_order_mode="focal_sentence", context_kind_mode="same_page_reference",
    nominal_boundary_mode="literal_visible_prefix", counter_policy="positive_support")
CONFIG = dict(method="current_hierarchy", retrieval_document_budget=40, retrieval_passage_budget=80,
    construction_pages=32, completed_drafts_per_reading=64, top_k=5, selection_profile=PROFILE)


def make_context_cases(page):
    text = page["text"].strip()
    paragraphs = text.split("\n\n")
    if len(paragraphs) != 7 or "Malinovsky Comments on Soviet Strategy" not in paragraphs[1]:
        raise ValueError("Original document passage structure changed")
    if not paragraphs[2].startswith("Soviet Marshal Malinovsky told a visiting [REDACTED]"):
        raise ValueError("First opaque focal context changed")
    if not paragraphs[5].startswith("The [REDACTED] delegation") or "Swedes" not in paragraphs[6]:
        raise ValueError("Second opaque focal context or explicit clue changed")
    # 'Last' is the last delegation paragraph, not the separate tactical-exercise
    # clue. This fourth arm completes the middle-context x visible-clue design.
    windows = dict(full_middle_clue=(1, 2, 3, 4, 5, 6), full_middle_no_clue=(1, 2, 3, 4, 5),
        minimal_first_last=(1, 2, 5), minimal_first_last_clue=(1, 2, 5, 6))
    rows = []
    for arm, indices in windows.items():
        query = "\n\n".join(paragraphs[i] for i in indices)
        for focal in ("first", "second"):
            prefix = "visiting " if focal == "first" else "The "
            needle = prefix + "[REDACTED]" + (" military delegation" if focal == "first" else " delegation")
            if query.count(needle) != 1:
                raise ValueError("Focal marker mapping is ambiguous")
            replaced = query.replace(needle, needle.replace("[REDACTED]", "[MASK]"), 1)
            case = dict(case_id="delegation_" + arm + "_" + focal, task="redaction", corpus="cib",
                document_id=ORIGIN, date=DATE, query=replaced, focal_marker="[MASK]")
            rows.append(dict(arm=arm, focal=focal, case=case, gold=None,
                visible_clue_given="Swedes" in replaced, visible_clue_is_corpus_proof=False,
                original_paragraph_indices=list(indices),
                opaque_markers_preserved=len(re.findall(r"\[REDACTED\]", replaced)) == 2,
                query_sha256=digest(replaced)))
    return rows


def main():
    saved, report = controls()
    catalog_path = WORKSPACE / "src-redaction/data/workbench_studies/cib_substantive_expansion_v2/canonical_targets.jsonl"
    import json
    targets = [r for line in catalog_path.open() if (r := json.loads(line))["slot_id"] in EXTRAS]
    if len(targets) != 3:
        raise ValueError("Extra source catalog changed")
    wanted = {r["document_id"] for r in targets} | {ORIGIN}
    _, pins = source_pins()
    docs = {r["document_id"]: r for r in pinned_rows(pins["documents"]) if r["document_id"] in wanted}
    pages = {r["canonical_page_id"]: r for r in pinned_rows(pins["pages"]) if r["document_id"] in wanted}
    origin_page = pages["page_d884726ce3791d6d8092"]
    if docs[ORIGIN]["document_date_iso"] != DATE or origin_page["document_id"] != ORIGIN:
        raise ValueError("Original document/date differs")
    context_cases = make_context_cases(origin_page)
    extra_cases, provenance = [], []
    for slot in EXTRAS:
        r = next(r for r in targets if r["slot_id"] == slot)
        p = pages[r["canonical_page_id"]]
        revealed = (r.get("slot_kind") == "revealed"
            or r.get("projection_case", {}).get("ground_truth_status") == "verified_later_release_v4")
        if (docs[r["document_id"]]["document_date_iso"] != r["document_date_iso"]
                or p["document_id"] != r["document_id"] or not revealed):
            raise ValueError("Extra original document/date/release status mismatch")
        matches = list(re.finditer(re.escape(r["hidden_text"]), p["text"], re.I))
        if not matches:
            raise ValueError("Saved revealed text absent from original source page")
        case = dict(case_id="cib_extra_" + slot, task="redaction", corpus="cib", date=r["document_date_iso"],
            document_id=r["document_id"], query=r["query_sentence"], focal_marker=r["focus_marker"])
        extra_cases.append(case)
        provenance.append(dict(case_id=case["case_id"], original_slot_id=slot,
            parent_slot_id=r.get("parent_slot_id", slot), document=docs[r["document_id"]],
            page_id=p["canonical_page_id"], source_page=p["source_page"], page_text_sha256=digest(p["text"]),
            revealed_text=r["hidden_text"], source_spans=[[m.start(), m.end()] for m in matches],
            source_provenance=r.get("source_provenance", dict(
                registry_schema=r["schema_version"], ground_truth_status=r["projection_case"]["ground_truth_status"]))
                if "source_provenance" not in r else r["source_provenance"], provider_input=False,
            selection="Outcome-informed saved success for fighters; authentic NATO/China technical/uncertainty cases, not claimed successes"))
    old = ROOT / "phase/kg_patch_20261122/swedish/isolated_engine/attempt03"
    write(HERE / "preregistered_v01/public-cases.json", dict(delegation=context_cases, extra_cases=extra_cases))
    write(HERE / "preregistered_v01/source-provenance.json", dict(source_pins=pins,
        source_catalog_ref=pin(catalog_path), delegation_origin_document=docs[ORIGIN],
        delegation_origin_page=dict(id=origin_page["canonical_page_id"], source_page=origin_page["source_page"],
            text_sha256=digest(origin_page["text"])), extra_cases=provenance,
        no_dataset_copies=True, source_page_text_copied=False))
    write(HERE / "preregistered_v01/design.json", dict(version="cib-common-pipeline-preregistration/1",
        created_utc=datetime.now(timezone.utc).isoformat(), report_ref=report,
        saved_controls=[dict(case_id=p["case"]["case_id"], native_ref=ref) for p, ref in saved],
        old_s2_controls=[pin(old / side / "execution.json.gz") for side in ("first", "second")],
        ordinary_and_delegation_configuration=CONFIG, comparisons="All four windows x two equal focal masks; preserve failures and all readings",
        last_paragraph_definition="Last delegation paragraph; optional separate Swedes tactical-exercise clue is explicit given input",
        strict_prior=True, whole_origin_excluded=True, later_release_is_retrospective=True,
        unknown_reference=None, provider_sees_only_seven_public_fields=True,
        no_answer_conditioned_selection=True, no_named_bonus=True, no_dictionary_demonyms=True,
        new_api_spend_ceiling_usd=8, cumulative_api_ceiling_usd=50, at_most_one_bounded_batch=True,
        maximum_planning_cases=11, cache_plans_and_readings=True,
        route_contract=dict(saved_route_mode_preserved=True, postrun_graph_view_is_original_walk=False,
            fresh_routes="No graph routes invented. Only directly cited selected-evidence handoffs; actual retrieval receipt retained.")))
    print("Preregistered 6 saved controls, 8 delegation cases and 3 authentic extra cases", flush=True)


if __name__ == "__main__":
    main()
