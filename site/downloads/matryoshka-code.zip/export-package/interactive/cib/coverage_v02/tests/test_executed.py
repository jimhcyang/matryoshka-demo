from pathlib import Path
from matryoshka_demo.io import digest
from phase.interactive_release_20261122.cib.artifacts import HERE as PARENT, WORKSPACE, read, pin

HERE = PARENT / "coverage_v02"


def packets():
    for path in sorted((HERE / "runs").glob("*/*/execution.json.gz")):
        yield path, read(path)


def signature(result):
    return [(r["reading"]["id"], [(c["id"],c["rank"],c["fill"],c["local_decision"]["status"])
        for c in r["candidates"]]) for r in result["readings"]]


def test_all_preregistered_pairs_completed_inside_bounds():
    summary = read(HERE/"summary.json")
    assert summary["completed_cases"] == summary["expected_cases"] == 8
    assert summary["failures"] == []
    assert len(list(packets())) == 16
    assert summary["elapsed_seconds"] <= 900
    assert summary["api_calls"] == summary["actual_new_spend_usd"] == 0
    assert summary["final_free_bytes"] >= 3*1024**3
    for path, packet in packets():
        completion = read(path.with_name("completion.json"))
        assert completion["execution_digest"] == digest(packet)
        assert completion["execution_ref"] == pin(path)
        assert packet["native_checksum"] == digest(packet["result"])
        assert packet["seconds"] <= 90


def test_source_pool_prefix_lanes_plan_readings_and_draft_cap_preserved():
    inputs = read(HERE/"inputs.json.gz")["cases"]
    for spec in inputs:
        cid = spec["case"]["case_id"]
        control = read(HERE/"runs"/cid/"primary_replay/execution.json.gz")
        supplemented = read(HERE/"runs"/cid/"primary_plus_entity_coverage/execution.json.gz")
        original = spec["primary_page_ids"]
        assert control["result"]["inspected_page_ids"] == original
        assert supplemented["result"]["inspected_page_ids"][:len(original)] == original
        assert len(supplemented["added_page_ids"]) <= 8
        assert not set(supplemented["added_page_ids"]) & set(original)
        assert control["plan_sha256"] == supplemented["plan_sha256"] == digest(spec["plan"])
        assert control["draft_budget"] == supplemented["draft_budget"] == 64
        assert control["result"]["source_budget"]["baseline_page_ids"] == supplemented["result"]["source_budget"]["baseline_page_ids"]
        assert supplemented["canonical_family_selection_unchanged"] is True
        assert supplemented["result"]["isolated_delta"]["prior_v02_family_reopening_used"] is False


def test_selected_supplement_literals_replay_exact_bound_source_pages():
    for coverage_path in (HERE/"runs").glob("*/coverage.json"):
        coverage = read(coverage_path)
        pages = read(coverage_path.with_name("supplement-source-pages.json.gz"))["source_pages"]
        for selected in coverage["supplement_pages"]:
            page = pages[selected["page_id"]]
            citation = selected["literal_citation"]
            assert page["source_sha256"] == digest(page["text"]) == citation["page_sha256"]
            assert page["text"][citation["start"]:citation["end"]] == citation["text"]
            assert page["document_id"] == citation["document_id"]
            assert selected["literal_attestation_is_focal_support"] is False


def test_frozen_artifacts_unchanged_and_selected_outcomes_not_forced():
    design = read(HERE/"design.json")
    for ref in design["frozen_artifacts"]:
        assert pin(WORKSPACE/ref["path"]) == ref
    for row in read(HERE/"summary.json")["cases"]:
        cid = row["case_id"]
        a = read(HERE/"runs"/cid/"primary_replay/execution.json.gz")["result"]
        b = read(HERE/"runs"/cid/"primary_plus_entity_coverage/execution.json.gz")["result"]
        assert signature(a) == signature(b)


def test_declared_clue_coverage_now_reaches_source_drafts_but_not_a_displayed_fill():
    for side in ("first","second"):
        root = HERE/"runs"/("delegation_full_middle_clue_"+side)
        coverage = read(root/"coverage.json")
        clue = next(r for r in coverage["anchor_receipts"] if r["anchor"]["key"] == "swedes")
        assert not clue["primary_occurrence_pages"]
        assert clue["final_occurrence_pages"]
        assert clue["eligible_literal_pages"] == 5
        result = read(root/"primary_plus_entity_coverage/execution.json.gz")["result"]
        groups = [g for g in result["_candidate_audit"]["source_groups"] if g["fill"].casefold() == "swedish"]
        assert groups
        assert all(g["assessment_state"] == "UNASSESSED" and g["assessment_reason"] == "NOT_ALLOCATED" for g in groups)
        assert not any(c["fill"].casefold() == "swedish" for c in result["candidates"])
