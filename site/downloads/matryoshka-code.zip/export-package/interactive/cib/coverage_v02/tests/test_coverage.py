from copy import deepcopy
from types import SimpleNamespace
from pathlib import Path
import pytest
from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy
from matryoshka_next.readings import _model
from phase.interactive_release_20261122.cib.artifacts import HERE, read
from phase.interactive_release_20261122.cib.coverage_v02.selector import anchors, pattern, supplement


def case():
    return dict(case_id="synthetic", task="redaction", corpus="cib", document_id="origin",
        date="1959-02-17", query="A [MASK] delegation visited.", focal_marker="[MASK]")


def corpus(rows):
    pages = []
    for i, row in enumerate(rows):
        value = dict(id="p"+str(i), corpus="cib", document_id="doc"+str(i), date="1959-02-16",
            text=row if isinstance(row, str) else row["text"], permitted=True, visibility="earlier")
        if isinstance(row, dict):
            value.update(row)
        value["source_sha256"] = digest(value["text"])
        pages.append(value)
    c = SimpleNamespace(corpus="cib", pages=pages, page_index={p["id"]:i for i,p in enumerate(pages)}, classification={})
    return c, SourcePolicy(c, case(), {p["id"]:p for p in pages})


def query_anchors(*labels):
    return dict(anchors=[dict(key=s.casefold(), surface=s, first_query_offset=i,
        query_occurrences=[]) for i,s in enumerate(labels)])


def test_full_clue_visible_entity_present_in_both_saved_plans():
    extracted = []
    for side in ("first", "second"):
        p = read(HERE / ("fresh_v02/delegation_full_middle_clue_"+side+"/execution.json.gz"))
        raw = next(e for e in p["plan"]["extractions"]["entities"] if e["local_id"] == "e19")
        assert raw["evidence_quote"] == "the Swedes" and raw["contains_unknown_slot"] is False
        actual = anchors(p["case"], p["plan"], _model())
        surface = next(a for a in actual["anchors"] if a["key"] == "swedes")
        assert surface["surface"] == "Swedes"
        assert any(o["entity_id"] == "e19" for o in surface["query_occurrences"])
        assert all(p["case"]["query"][o["query_span"]["start"]:o["query_span"]["end"]] == o["query_span"]["text"] for o in surface["query_occurrences"])
        extracted.append(surface["key"])
    assert extracted[0] == extracted[1]


def test_literal_boundary_whitespace_case_without_morphological_expansion():
    expression = pattern("North Harbor")
    assert expression.search("NORTH\nHARBOR")
    assert not expression.search("North Harbors")
    assert not pattern("harbor").search("harbors")


def test_primary_prefix_retained_and_shared_supplement_not_duplicated():
    c,p = corpus(["Alpha is visible.", "Beta and Gamma met.", "Gamma spoke."])
    actual = supplement(c, case(), p, ["p0"], query_anchors("Alpha", "Beta", "Gamma"), {0:1,1:9,2:2})
    assert actual["primary_page_ids"] == ["p0"]
    assert actual["final_page_ids"] == ["p0", "p1"]
    assert [r["state"] for r in actual["anchor_receipts"]] == ["PRIMARY_COVERED", "SUPPLEMENT_SELECTED", "COVERED_BY_SHARED_SUPPLEMENT"]


def test_existing_query_rank_selects_occurrence_not_new_document_or_answer_bonus():
    c,p = corpus(["Primary text.", "Beta one.", "Beta two."])
    actual = supplement(c, case(), p, ["p0"], query_anchors("Beta"), {0:1,1:300,2:20})
    assert actual["supplement_pages"][0]["page_id"] == "p2"
    assert actual["supplement_pages"][0]["literal_citation"]["text"] == "Beta"


@pytest.mark.parametrize("veto", [dict(document_id="origin"),dict(date="1959-02-17"),dict(date="1959-02-18"),dict(permitted=False)])
def test_source_vetoes_apply_before_literal_nomination(veto):
    c,p = corpus(["Primary.", dict(text="Beta.", **veto)])
    actual = supplement(c, case(), p, ["p0"], query_anchors("Beta"), {})
    assert actual["final_page_ids"] == ["p0"]
    assert actual["anchor_receipts"][0]["state"] == "NO_ELIGIBLE_LITERAL_OCCURRENCE"


def test_eight_page_cap_preserves_negative_remainder():
    labels = ["Token"+chr(65+i) for i in range(10)]
    c,p = corpus(["Primary."]+[s+"." for s in labels])
    actual = supplement(c, case(), p, ["p0"], query_anchors(*labels), {}, cap=8)
    assert len(actual["final_page_ids"]) == 9
    assert sum(r["state"] == "SUPPLEMENT_CAP_HOLD" for r in actual["anchor_receipts"]) == 2
    assert actual["primary_page_removed"] is False


def test_rare_first_is_general_and_does_not_change_candidate_support():
    c,p = corpus(["Primary.", "Alpha.", "Alpha.", "Beta."])
    actual = supplement(c, case(), p, ["p0"], query_anchors("Alpha", "Beta"), {}, cap=1)
    assert actual["supplement_pages"][0]["nominated_by"] == "beta"
    assert actual["supplement_pages"][0]["literal_attestation_is_focal_support"] is False


def test_core_selector_and_constructor_have_no_named_literal_pair():
    import ast
    base = HERE / "coverage_v02"
    for path in (base/"selector.py", base/"engine.py"):
        constants = [node.value.casefold() for node in ast.walk(ast.parse(path.read_text()))
            if isinstance(node, ast.Constant) and isinstance(node.value, str)]
        assert not any(word in value for value in constants for word in ("swedes", "swedish", "arias", "aung gyi"))
