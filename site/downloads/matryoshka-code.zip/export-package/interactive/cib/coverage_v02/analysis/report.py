"""Post-execution coverage/reading audit, not a nomination input."""
from collections import Counter
from xml.etree import ElementTree
from matryoshka_demo.io import digest
from ...artifacts import read, pin, WORKSPACE
from ..run import HERE, save
from ..selector import pattern


def signature(result):
    return [(r["reading"]["id"], [(c["id"],c["rank"],c["fill"],c["local_decision"]["status"])
        for c in r["candidates"]]) for r in result["readings"]]


def literal_audit(anchor, packet):
    expression = pattern(anchor["surface"])
    result = packet["result"]
    groups = [g for g in result["_candidate_audit"]["source_groups"] if expression.search(g["fill"])]
    rejections = [g for g in result["_candidate_audit"]["rejections"] if expression.search(g.get("fill", ""))]
    assessed = [g for g in result["assessed_candidates"]
        if expression.search(g["fill"]) or expression.search(g["source_wording"])]
    selected = [g for g in result["candidates"] if expression.search(g["fill"]) or expression.search(g["source_wording"])]
    return dict(anchor=anchor["surface"],
        source_groups=[dict(fill=g["fill"], reading_id=g["reading_id"], state=g["assessment_state"],
            reason=g["assessment_reason"], selected_for_evaluation=g["selected_for_evaluation"],
            rank_key=g["rank_key"], occurrences=g["occurrences"]) for g in groups],
        rejections=rejections,
        assessed=[dict(id=g["id"], fill=g["fill"], reading_id=g["reading_id"],
            status=g["local_decision"]["status"], sources=g["sources"], local_decision=g["local_decision"]) for g in assessed],
        selected=[dict(id=g["id"], fill=g["fill"], reading_id=g["reading_id"], rank=g["rank"],
            status=g["local_decision"]["status"], sources=g["sources"], local_decision=g["local_decision"]) for g in selected],
        exact_literal_audit_only_not_a_morphology_or_gold_test=True)


def main():
    summary = read(HERE/"summary.json")
    design = read(HERE/"design.json")
    cases = read(HERE/"inputs.json.gz")["cases"]
    comparisons = []
    for spec in cases:
        cid = spec["case"]["case_id"]
        root = HERE/"runs"/cid
        paths = [root/arm/"execution.json.gz" for arm in ("primary_replay", "primary_plus_entity_coverage")]
        if not all(p.exists() for p in paths):
            comparisons.append(dict(case_id=cid, pair_completed=False,
                failure_ref=pin(root/"failure.json") if (root/"failure.json").exists() else None))
            continue
        primary, supplemented = [read(p) for p in paths]
        coverage = read(root/"coverage.json")
        for packet, path in zip((primary,supplemented), paths, strict=True):
            assert digest(packet["result"]) == packet["native_checksum"]
            completion = read(path.with_name("completion.json"))
            assert completion["execution_digest"] == digest(packet)
            assert completion["execution_ref"] == pin(path)
        before, after = primary["result"], supplemented["result"]
        assert before["inspected_page_ids"] == spec["primary_page_ids"]
        assert after["inspected_page_ids"] == coverage["final_page_ids"]
        assert after["inspected_page_ids"][:len(spec["primary_page_ids"])] == spec["primary_page_ids"]
        assert primary["plan_sha256"] == supplemented["plan_sha256"] == digest(spec["plan"])
        assert after["source_budget"]["baseline_page_ids"] == before["source_budget"]["baseline_page_ids"]
        primary_by_id = {c["id"]:c for c in before["assessed_candidates"]}
        supplemental_by_id = {c["id"]:c for c in after["assessed_candidates"]}
        shared = sorted(primary_by_id.keys() & supplemental_by_id.keys())
        changed_decisions = [dict(id=cid, before=primary_by_id[cid]["local_decision"],
            after=supplemental_by_id[cid]["local_decision"]) for cid in shared
            if primary_by_id[cid]["local_decision"] != supplemental_by_id[cid]["local_decision"]]
        entry = dict(case_id=cid, source_view=spec["source_view"], pair_completed=True,
            primary_execution_ref=pin(paths[0]), supplemented_execution_ref=pin(paths[1]),
            primary_pages=len(before["inspected_page_ids"]), supplemented_pages=len(after["inspected_page_ids"]),
            added_page_ids=[p["page_id"] for p in coverage["supplement_pages"]],
            primary_pages_and_lanes_preserved=True, coverage=coverage["anchor_receipts"],
            primary_covered_anchors=sum(bool(r["primary_occurrence_pages"]) for r in coverage["anchor_receipts"]),
            supplemented_covered_anchors=sum(bool(r["final_occurrence_pages"]) for r in coverage["anchor_receipts"]),
            selected_signature_unchanged=signature(before) == signature(after),
            primary_readings=summary["cases"][[r["case_id"] for r in summary["cases"]].index(cid)]["arms"][0]["readings"],
            supplemented_readings=summary["cases"][[r["case_id"] for r in summary["cases"]].index(cid)]["arms"][1]["readings"],
            shared_assessed_count=len(shared), changed_shared_decisions=changed_decisions,
            original_assessed_now_unassessed_or_unavailable=[dict(id=c["id"], fill=c["fill"], reading_id=c["reading_id"])
                for c in before["assessed_candidates"] if c["id"] not in supplemental_by_id],
            anchor_realization_audits=[dict(primary=literal_audit(row["anchor"],primary),
                supplemented=literal_audit(row["anchor"],supplemented)) for row in coverage["anchor_receipts"]
                if not row["primary_occurrence_pages"]],
            same_draft_budget=True, new_literal_source_coverage_is_not_focal_action_proof=True,
            unknown_reference_not_scored=True)
        added = set(entry["added_page_ids"])
        entry["supplement_page_source_groups"] = [dict(fill=g["fill"], reading_id=g["reading_id"],
            state=g["assessment_state"], reason=g["assessment_reason"], selected_for_evaluation=g["selected_for_evaluation"],
            rank_key=g["rank_key"], source_pages=sorted({o["citation"]["canonical_page_id"] for o in g["occurrences"]} & added))
            for g in after["_candidate_audit"]["source_groups"]
            if any(o["citation"]["canonical_page_id"] in added for o in g["occurrences"])]
        entry["supplement_page_proposal_states"] = [dict(fill=fill, reading_id=reading_id,
            assessment_state=state, reason=reason, source_groups=count)
            for (fill,reading_id,state,reason),count in sorted(Counter(
                (g["fill"],g["reading_id"],g["state"],g["reason"])
                for g in entry["supplement_page_source_groups"]).items())]
        save(root/"paired-analysis.json.gz", entry)
        comparisons.append(entry)
    for ref in design["frozen_artifacts"]:
        assert pin(WORKSPACE/ref["path"]) == ref
    source_refs = {str(p.relative_to(HERE)):pin(p)["sha256"] for p in sorted(HERE.rglob("*.py"))}
    manifest_ref = save(HERE/"source-manifest.json", dict(version="query-entity-coverage-source-manifest/2",
        python_sources=source_refs, original_frozen_artifacts=design["frozen_artifacts"],
        parent_source_pins=design["source_pins"], prior_frozen_files_modified=False))
    receipt_path = HERE/"tests/final.xml"
    tree = ElementTree.parse(receipt_path).getroot()
    suites = tree.findall("testsuite") if tree.tag == "testsuites" else [tree]
    passed = sum(int(s.get("tests","0")) for s in suites)
    failures = sum(int(s.get("errors","0"))+int(s.get("failures","0")) for s in suites)
    assert failures == 0
    handoff = dict(version="query-entity-coverage-followup-handoff/2", design_ref=pin(HERE/"design.json"),
        summary_ref=pin(HERE/"summary.json"), entity_inventory_ref=pin(HERE/"query-entity-inventory.json"),
        source_manifest_ref=manifest_ref, api_calls=0, new_spend_usd=0,
        cases=[{k:v for k,v in c.items() if k not in {"anchor_realization_audits", "changed_shared_decisions", "supplement_page_source_groups"}}
            for c in comparisons],
        detailed_analysis_refs=[pin(p) for p in sorted((HERE/"runs").glob("*/paired-analysis.json.gz"))],
        frozen_v03_dto_unchanged=True, frozen_handoff_unchanged=True,
        no_named_literal_rule=True, no_demonym_mapping=True, no_answer_conditioned_selection=True,
        family_selection_is_canonical_parent_in_both_arms=True,
        no_engine_or_presentation_publication_performed=True,
        coverage_not_correctness_experiment=True, source_literal_is_not_focal_support=True,
        original_reference_stays_unknown=True, tests=dict(passed=passed, failures=failures, receipt_ref=pin(receipt_path)))
    ref = save(HERE/"HANDOFF.json", handoff)
    print(dict(handoff_ref=ref, completed_pairs=sum(c["pair_completed"] for c in comparisons),
        changed_selected_pairs=[c["case_id"] for c in comparisons if c.get("pair_completed") and not c["selected_signature_unchanged"]],
        tests=passed, new_spend_usd=0), flush=True)


if __name__ == "__main__":
    main()
