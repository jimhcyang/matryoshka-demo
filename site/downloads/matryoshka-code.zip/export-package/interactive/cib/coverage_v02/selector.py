"""Query-only named surface anchors and eligible literal-occurrence coverage.

No answer, requested fill, nationality inference, alias dictionary, source
support status, or candidate ranking enters page supplementation.
"""
from collections import OrderedDict
import re
import time
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_next.facts import public_plan

VERSION = "query-entity-literal-coverage/1"
NAMED_TYPES = frozenset({"PERSON", "ORG", "GPE", "LOC", "FAC", "NORP", "PRODUCT", "EVENT", "WORK_OF_ART", "LAW", "LANGUAGE"})


def anchors(case, plan, parser):
    public_plan(case, plan)
    query = case["query"]
    document = parser(MASK.sub(lambda m: " " * len(m.group()), query))
    located, withheld = [], []
    entities = plan.get("extractions", {}).get("entities", [])
    for entity in entities:
        for span in entity.get("query_spans", []):
            a, b = span.get("start"), span.get("end")
            if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(query)
                    or query[a:b] != span.get("text")):
                raise ValueError("Saved query entity span does not replay")
            if entity.get("contains_unknown_slot") or MASK.search(query[a:b]):
                withheld.append(dict(entity_id=entity.get("local_id"), span=span, reason="OPAQUE_QUERY_ENTITY"))
                continue
            own = document.char_span(a, b, alignment_mode="strict")
            if own is None:
                withheld.append(dict(entity_id=entity.get("local_id"), span=span, reason="NON_TOKEN_ALIGNED_ENTITY_SPAN"))
                continue
            named = [e for e in document.ents if e.label_ in NAMED_TYPES and a <= e.start_char < e.end_char <= b]
            pieces = [(e.start_char, e.end_char, "QUERY_NER_SURFACE", e.label_) for e in named]
            root = own.root
            if root.pos_ == "PROPN" and not any(x <= root.idx < root.idx + len(root) <= y for x,y,_,_ in pieces):
                pieces.append((root.idx, root.idx + len(root), "QUERY_PROPER_HEAD_SURFACE", root.pos_))
            for token in own:
                if (len(token.text) >= 2 and token.text.isalpha() and token.text.isupper()
                        and not any(x <= token.idx < token.idx+len(token) <= y for x,y,_,_ in pieces)):
                    pieces.append((token.idx, token.idx+len(token), "QUERY_LITERAL_ACRONYM_SURFACE", token.pos_))
            for start, end, basis, kind in pieces:
                surface = query[start:end]
                if MASK.search(surface) or not re.search(r"[A-Za-z]", surface):
                    continue
                located.append(dict(surface=surface, key=" ".join(surface.casefold().split()),
                    query_span=dict(start=start, end=end, text=surface), entity_id=entity.get("local_id"),
                    basis=basis, observed_query_kind=kind, identity_certified=False))
    groups = OrderedDict()
    for value in sorted(located, key=lambda r:(r["query_span"]["start"], r["query_span"]["end"], r["key"])):
        row = groups.setdefault(value["key"], dict(key=value["key"], surface=value["surface"],
            first_query_offset=value["query_span"]["start"], query_occurrences=[]))
        if value not in row["query_occurrences"]:
            row["query_occurrences"].append(value)
    return dict(version=VERSION, query_sha256=digest(query), anchors=list(groups.values()),
        withheld=withheld, extraction_entities_preserved=entities,
        source_or_answer_read_during_anchor_extraction=False, nationality_assumed=False,
        normalized_identity_is_case_and_whitespace_only=True, generated_aliases=False)


def pattern(surface):
    return re.compile(r"(?<!\w)" + r"\s+".join(re.escape(w) for w in surface.split()) + r"(?!\w)", re.I)


def supplement(corpus, case, policy, primary_page_ids, query_anchors, page_ranks, *, cap=8, seconds=45):
    if type(cap) is not int or not 0 <= cap <= 8:
        raise ValueError("At most eight declared supplemental pages")
    if len(primary_page_ids) != len(set(primary_page_ids)):
        raise ValueError("Primary page identities must be unique")
    primary = set(primary_page_ids)
    for pid in primary_page_ids:
        pi = corpus.page_index[pid]
        if not policy.allowed(pi):
            raise ValueError("Primary source is ineligible")
    start = time.monotonic()
    compiled = [(a, pattern(a["surface"])) for a in query_anchors["anchors"]]
    hits = {a["key"]: [] for a, _ in compiled}
    eligible = policy.mask()
    for pi, page in enumerate(corpus.pages):
        if pi % 256 == 0 and time.monotonic() - start > seconds:
            raise TimeoutError("Bounded literal-entity source scan exceeded its time cap")
        if not eligible[pi]:
            continue
        for anchor, expression in compiled:
            match = expression.search(page["text"])
            if match and " ".join(match.group().casefold().split()) == anchor["key"]:
                hits[anchor["key"]].append((pi, match.start(), match.end()))
    covered_primary = {key: [h for h in rows if corpus.pages[h[0]]["id"] in primary] for key, rows in hits.items()}
    uncovered = [a for a, _ in compiled if not covered_primary[a["key"]] and hits[a["key"]]]
    # Scarce literal anchors receive coverage opportunities first, independently
    # of any proposed fill. Existing query retrieval ranks choose the occurrence.
    uncovered.sort(key=lambda a:(len(hits[a["key"]]), a["first_query_offset"], a["key"]))
    selected, reasons = [], {}
    selected_set = set()
    for anchor in uncovered:
        key = anchor["key"]
        shared = next((h for h in hits[key] if h[0] in selected_set), None)
        if shared:
            reasons[key] = dict(state="COVERED_BY_SHARED_SUPPLEMENT", selected_page_id=corpus.pages[shared[0]]["id"])
            continue
        if len(selected) == cap:
            reasons[key] = dict(state="SUPPLEMENT_CAP_HOLD", not_disproved=True)
            continue
        chosen = min(hits[key], key=lambda h:(page_ranks.get(h[0], float("inf")), corpus.pages[h[0]]["id"], h[1]))
        pi, a, b = chosen
        citation = policy.citation(pi, a, b)
        if citation["document_id"] == case["document_id"] or citation["date"] >= case["date"]:
            raise ValueError("Whole-origin/strict-prior veto escaped")
        selected_set.add(pi)
        selected.append(dict(page_id=corpus.pages[pi]["id"], page_index=pi, nominated_by=key,
            original_combined_query_rank=page_ranks.get(pi), literal_citation=citation,
            literal_attestation_is_focal_support=False))
        reasons[key] = dict(state="SUPPLEMENT_SELECTED", selected_page_id=corpus.pages[pi]["id"])
    receipts = []
    for anchor, _ in compiled:
        key = anchor["key"]
        final = [h for h in hits[key] if corpus.pages[h[0]]["id"] in primary or h[0] in selected_set]
        state = "PRIMARY_COVERED" if covered_primary[key] else "NO_ELIGIBLE_LITERAL_OCCURRENCE" if not hits[key] else reasons[key]["state"]
        receipts.append(dict(anchor=anchor, eligible_literal_pages=len(hits[key]),
            primary_occurrence_pages=[corpus.pages[h[0]]["id"] for h in covered_primary[key]],
            final_occurrence_pages=[corpus.pages[h[0]]["id"] for h in final],
            state=state, selection=reasons.get(key), absence_is_counterevidence=False))
    appended = [r["page_id"] for r in selected]
    assert not primary.intersection(appended) and len(appended) <= cap
    return dict(version=VERSION, primary_page_ids=list(primary_page_ids), supplement_pages=selected,
        final_page_ids=list(primary_page_ids)+appended, anchor_receipts=receipts,
        primary_prefix_retained=True, primary_page_removed=False, budget_cap=cap,
        source_scan_seconds=time.monotonic()-start, source_scan_page_count=int(eligible.sum()),
        alias_policy="LITERAL_SOURCE_OCCURRENCES_ONLY_NO_ALIAS_EXPANSION", answer_conditioned_scan=False,
        source_identity_or_focal_action_certified=False)
