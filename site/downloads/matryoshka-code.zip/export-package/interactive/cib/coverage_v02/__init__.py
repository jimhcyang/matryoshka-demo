"""Bounded, API-free query-entity page-coverage experiment."""
