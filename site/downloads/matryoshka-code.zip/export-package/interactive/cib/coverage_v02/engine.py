"""Canonical factual gates and family selection; explicit additive source pool."""
from copy import deepcopy
from types import SimpleNamespace
from matryoshka_narrative import construction as canonical
from phase.kg_patch_20261122.swedish.isolated_engine import next_construction as scoped
from ..engine_v01.construction import fork_functions

VERSION = "cib-additive-query-entity-coverage-construction/1"


def construct(case, plan, retrieval, *, source_index, primary_budget, primary_page_ids,
              final_page_ids, source_policy=None, draft_budget=64, selection_profile=None):
    if final_page_ids[:len(primary_page_ids)] != primary_page_ids:
        raise ValueError("All current primary pages must remain an unchanged prefix")
    if len(final_page_ids) > len(primary_page_ids)+8 or len(final_page_ids) != len(set(final_page_ids)):
        raise ValueError("Bounded distinct supplemental source pages required")
    shared = canonical.shared
    if source_policy is not None:
        def pages(*args, **options):
            return scoped._pages(*args, source_policy=source_policy, **options)
        def gate(*args, **options):
            return scoped._gate(*args, source_policy=source_policy, **options)
        shared = SimpleNamespace(**dict(vars(shared), _pages=pages, _gate=gate))
    engine = fork_functions(canonical, shared=shared, VERSION=VERSION)
    original_pool = engine["_bounded_pool"]

    def bounded_pool(*args, **kwargs):
        corpus, pages, policy, budget, pool = original_pool(*args, **kwargs)
        if [p["id"] for _, p in pages] != final_page_ids:
            raise ValueError("Constructor changed the preregistered exact page pool")
        # Preserve the original primary/cue lanes instead of silently moving
        # primary candidates when the total page cap grows.
        budget.update(baseline_page_ids=deepcopy(primary_budget["baseline_page_ids"]),
            baseline_prefix_cap=primary_budget["baseline_prefix_cap"],
            cue_addition_cap=len(final_page_ids)-primary_budget["baseline_prefix_cap"],
            primary_constructor_page_cap=len(primary_page_ids),
            supplemental_page_count=len(final_page_ids)-len(primary_page_ids),
            total_page_cap_increased=len(final_page_ids)>len(primary_page_ids),
            primary_page_ids_preserved=list(primary_page_ids),
            original_primary_lane_preserved=True,
            allocation_rule="Original primary source lanes plus bounded uncovered query-entity literal pages; same draft cap")
        return corpus, pages, policy, budget, pool

    engine["_bounded_pool"] = bounded_pool
    panel = dict(retrieval)
    corpus = panel["eligible"].corpus
    additional = [corpus.page_index[p] for p in final_page_ids if corpus.page_index[p] not in set(panel["pages"])]
    panel.update(pages=list(panel["pages"])+additional, inspected_page_ids=list(final_page_ids),
        passage_budget=max(retrieval["passage_budget"], len(final_page_ids)))
    result = engine["construct"](case, plan, panel, source_index=source_index,
        passage_budget=len(final_page_ids), draft_budget=draft_budget,
        selection_profile=selection_profile, top_k=5)
    result["isolated_delta"] = dict(additive_query_entity_coverage=True, parent=canonical.VERSION,
        canonical_factual_gates_unchanged=True, canonical_family_selection_unchanged=True,
        prior_v02_family_reopening_used=False, primary_pages_and_lanes_preserved=True,
        draft_cap_unchanged=True, hidden_reference_used=False)
    return result
