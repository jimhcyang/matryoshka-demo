"""One preregistered API-zero paired experiment; all writes owned here."""
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
import gc
import gzip
import json
from pathlib import Path
import shutil
import signal
import time

from matryoshka_demo.io import digest, offline
from matryoshka_next.workflow import Session
from matryoshka_next.facts import SourcePolicy
from matryoshka_next.readings import _model
from matryoshka_narrative.retrieval import retrieve as ordinary_retrieve
from phase.kg_patch_20261122.swedish.isolated_engine.run_study import cite_replay
from ..artifacts import HERE as PARENT, ROOT, WORKSPACE, read, pin, code_pins
from ..engine_v01 import source_adapter
from .engine import construct, VERSION as ENGINE_VERSION
from .selector import anchors, supplement, VERSION as SELECTOR_VERSION

HERE = Path(__file__).resolve().parent
RESERVE = 3 * 1024**3
OUTPUT_CAP = 48 * 1024**2
TOTAL_SECONDS = 900
CASE_SECONDS = 90


def save(path, value):
    path = Path(path).resolve()
    if not path.is_relative_to(HERE) or path.is_symlink():
        raise ValueError("All follow-up writes must remain in coverage_v02")
    data = (json.dumps(value, ensure_ascii=True, sort_keys=True, indent=2, allow_nan=False)+"\n").encode()
    if path.suffix == ".gz":
        data = gzip.compress(data, mtime=0)
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError("Do not overwrite a preregistration or prior outcome")
        return pin(path)
    free = shutil.disk_usage(HERE).free
    if free-len(data) < RESERVE:
        raise OSError("Write would cross the 3 GiB reserve")
    used = sum(p.stat().st_size for p in HERE.rglob("*") if p.is_file())
    if used+len(data) > OUTPUT_CAP:
        raise OSError("Bounded follow-up output cap reached")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return pin(path)


def ledger_total():
    return sum(read(p)["charged_or_reserved_usd"] for p in (ROOT/"experiments/narrative_demo/api/receipts").glob("*.json"))


def pins():
    result = code_pins()
    for p in sorted(HERE.glob("*.py")):
        result[str(p.relative_to(ROOT))] = pin(p)["sha256"]
    return result


def inputs():
    report = read(WORKSPACE/"matryoshka_demo_site/site/data/report-v6.json")
    ordinary = [r["case"]["case_id"] for r in report["cases"]
        if r["case"]["corpus"] == "cib" and r["case"]["task"] == "redaction"]
    specs = read(PARENT/"preregistered_v01/public-cases.json")["delegation"]
    focal = [r["case"]["case_id"] for r in specs if r["arm"] == "full_middle_clue"]
    assert len(ordinary) == 6 and len(focal) == 2
    result = []
    for cid in ordinary+focal:
        path = PARENT/"fresh_v02"/cid/"execution.json.gz"
        packet = read(path)
        assert digest(packet["result"]) == packet["native_checksum"]
        configuration = packet["configuration"]
        assert configuration["construction_pages"] == 32 and configuration["completed_drafts_per_reading"] == 64
        result.append(dict(case=packet["case"], plan=packet["plan"], baseline_ref=pin(path),
            configuration=configuration, primary_page_ids=packet["result"]["inspected_page_ids"],
            primary_source_budget=packet["result"]["source_budget"], retrieval_receipt=packet["retrieval"],
            source_view="later_strict_prior" if cid in focal else "ordinary_earlier_strict_prior"))
    return result


def prepare():
    if (HERE/"design.json").exists():
        raise RuntimeError("One bounded follow-up is already preregistered; do not restart silently")
    cases = inputs()
    inventories = [dict(case_id=r["case"]["case_id"], source_view=r["source_view"],
        query_entity_inventory=anchors(r["case"], r["plan"], _model())) for r in cases]
    save(HERE/"query-entity-inventory.json", dict(version="query-entity-inventory-before-source-scan/1",
        inventories=inventories, provider_calls=0, original_extraction_entities_preserved=True))
    save(HERE/"inputs.json.gz", dict(cases=cases, query_plans_and_readings_reused=True,
        reference_answer_not_present=True))
    frozen = [pin(PARENT/"dto/public-study-complete-v03.json"), pin(PARENT/"final_v01/HANDOFF.json")]
    design = dict(version="query-entity-coverage-preregistration/2", registered_utc=datetime.now(timezone.utc).isoformat(),
        cases=[dict(case_id=r["case"]["case_id"], source_view=r["source_view"], baseline_ref=r["baseline_ref"]) for r in cases],
        arms=["primary_replay", "primary_plus_entity_coverage"], maximum_executions=16,
        primary_pages=32, primary_pages_and_lane_assignments_retained=True,
        max_supplement_pages=8, max_total_pages=40, draft_budget_per_reading=64,
        top_k=5, source_gate_changes=False, reading_changes=False,
        family_selection="CANONICAL_CURRENT_PARENT_NOT_REGRESSING_V02_SURFACE_REOPENING",
        hypothesis="Balanced query-anchor coverage can expose eligible literal source occurrences missed by primary retrieval; it need not produce a correct or supported fill",
        anchor_rule="Replay saved entity spans; use located nonnumeric query NER mentions, uncovered proper heads, and literal uppercase acronym tokens; withhold opaque spans; case/whitespace identity only",
        allocation_rule="Uncovered anchors with eligible literal occurrences, fewest distinct eligible pages first, then query position; one best existing combined-query-rank occurrence per anchor, reuse shared supplement pages",
        source_scan="ALL eligible source pages, matched ONLY against derived query anchors; never a requested fill or reference; no aliases or morphological expansion",
        supplementation_is_new_explicit_source_admission=True, supplement_is_not_an_original_retrieval_walk=True,
        whole_origin_exclusion=True, strict_prior=True, full_source_coordinates_v03_unchanged=True,
        selection_is_not_proof=True, unknown_gold_not_scored=True,
        api_calls_authorized=0, network_disabled=True, total_seconds=TOTAL_SECONDS,
        constructor_seconds_per_arm=CASE_SECONDS, source_scan_seconds_per_case=45,
        max_new_output_bytes=OUTPUT_CAP, reserve_bytes=RESERVE,
        frozen_artifacts=frozen, source_pins=pins(),
        development_is_outcome_informed=True, named_bonus=False, invented_support=False,
        initial_shared_ledger_usd=ledger_total())
    save(HERE/"design.json", design)
    return cases, inventories, design


def summary(result):
    return dict(readings=[dict(reading_id=r["reading"]["id"], outer_family=r["reading"]["outer_family"],
        candidates=[dict(id=c["id"], rank=c["rank"], fill=c["fill"], status=c["local_decision"]["status"],
            sources=c["sources"]) for c in r["candidates"]]) for r in result["readings"]],
        status_counts=dict(Counter(c["local_decision"]["status"] for c in result["candidates"])),
        inspected_page_ids=result["inspected_page_ids"],
        checked_per_reading=result["execution"]["checked_per_reading"])


def run_case(spec, inventory, corpus, index, *, later, design, deadline):
    if time.monotonic() > deadline:
        raise TimeoutError("Preregistered global time cap reached")
    case, plan = spec["case"], spec["plan"]
    cid = case["case_id"]
    print(dict(stage="retrieval_and_literal_coverage", case_id=cid), flush=True)
    kwargs = dict(document_budget=40, passage_budget=80, method="current_hierarchy")
    found = source_adapter.retrieve(corpus, case, plan, **kwargs) if later else ordinary_retrieve(corpus, case, plan, source_index=index, **kwargs)
    assert found["receipt"] == spec["retrieval_receipt"], "Saved primary retrieval changed"
    selected = found["eligible"].corpus
    policy = corpus.policy_for(case) if later else SourcePolicy(selected, case, index)
    coverage = supplement(selected, case, policy, spec["primary_page_ids"], inventory["query_entity_inventory"],
        found["page_ranks"], cap=8, seconds=45)
    coverage_ref = save(HERE/"runs"/cid/"coverage.json", coverage)
    source_pages = {}
    for row in coverage["supplement_pages"]:
        p = selected.pages[row["page_index"]]
        source_pages[p["id"]] = dict(p)
    save(HERE/"runs"/cid/"supplement-source-pages.json.gz", dict(source_pages=source_pages,
        source_view=spec["source_view"], literal_attestation_is_not_focal_action_proof=True))
    outputs = []
    for arm, page_ids in (("primary_replay", spec["primary_page_ids"]),
            ("primary_plus_entity_coverage", coverage["final_page_ids"])):
        if time.monotonic() >= deadline:
            raise TimeoutError("Preregistered global time cap reached")
        print(dict(stage="construct", case_id=cid, arm=arm, pages=len(page_ids)), flush=True)
        def alarm(*_):
            raise TimeoutError("Preregistered constructor time cap reached")
        previous = signal.signal(signal.SIGALRM, alarm)
        signal.setitimer(signal.ITIMER_REAL, min(CASE_SECONDS, max(.01, deadline-time.monotonic())))
        started = time.perf_counter()
        try:
            result = construct(case, plan, found, source_index=index,
                primary_budget=spec["primary_source_budget"], primary_page_ids=spec["primary_page_ids"],
                final_page_ids=page_ids, source_policy=policy if later else None,
                draft_budget=64, selection_profile=spec["configuration"]["selection_profile"])
            replayed = cite_replay(result, policy)
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)
        assert result["inspected_page_ids"] == page_ids
        assert result["source_budget"]["baseline_page_ids"] == spec["primary_source_budget"]["baseline_page_ids"]
        assert result["query_sha256"] == digest(case["query"])
        assert result["provided_plan_sha256"] == digest(plan)
        assert pins() == design["source_pins"], "Implementation changed after preregistration"
        packet = dict(version="cib-query-entity-coverage-execution/2", canonical_native_execution=False,
            case=case, plan_sha256=digest(plan), plan_and_readings_ref=pin(HERE/"inputs.json.gz"),
            result=result, native_checksum=digest(result), arm=arm, source_view=spec["source_view"],
            parent_frozen_execution_ref=spec["baseline_ref"], coverage_ref=coverage_ref,
            retrieval_receipt=found["receipt"], primary_page_ids=spec["primary_page_ids"],
            added_page_ids=[p for p in page_ids if p not in set(spec["primary_page_ids"])],
            draft_budget=64, top_k=5, factual_gates_unchanged=True,
            canonical_family_selection_unchanged=True, source_citations_replayed=replayed,
            source_pins=design["source_pins"], original_retrieval_walk_recorded=False,
            supplemental_source_admission_is_explicit=True, api_calls=0, gold=None,
            seconds=time.perf_counter()-started)
        path = HERE/"runs"/cid/arm/"execution.json.gz"
        ref = save(path, packet)
        save(path.with_name("completion.json"), dict(version="cib-query-entity-coverage-completion/2",
            execution_ref=ref, execution_digest=digest(packet), native_checksum=digest(result)))
        readout = summary(result)
        outputs.append(dict(arm=arm, execution_ref=ref, **readout))
        print(dict(stage="complete", case_id=cid, arm=arm, seconds=round(packet["seconds"],2),
            candidates=[(c["rank"],c["fill"],c["status"]) for r in readout["readings"] for c in r["candidates"]]), flush=True)
    return dict(case_id=cid, coverage_ref=coverage_ref, added_pages=[r["page_id"] for r in coverage["supplement_pages"]],
        anchors_total=len(coverage["anchor_receipts"]),
        covered_primary=sum(bool(r["primary_occurrence_pages"]) for r in coverage["anchor_receipts"]),
        covered_final=sum(bool(r["final_occurrence_pages"]) for r in coverage["anchor_receipts"]),
        anchor_states=dict(Counter(r["state"] for r in coverage["anchor_receipts"])), arms=outputs)


def main():
    started = time.monotonic()
    deadline = started+TOTAL_SECONDS
    with offline():
        cases, inventories, design = prepare()
        rows, failures = [], []
        ordinary = [(s,i) for s,i in zip(cases,inventories,strict=True) if s["source_view"] == "ordinary_earlier_strict_prior"]
        later = [(s,i) for s,i in zip(cases,inventories,strict=True) if s["source_view"] == "later_strict_prior"]
        with Session() as session:
            context = session.context("cib")
            for spec, inventory in ordinary:
                try:
                    rows.append(run_case(spec, inventory, context.corpus, context.source_index, later=False, design=design, deadline=deadline))
                except Exception as error:
                    failure = dict(case_id=spec["case"]["case_id"], error_type=type(error).__name__, message=str(error),
                        no_api_calls=True, prior_outputs_retained=True)
                    save(HERE/"runs"/spec["case"]["case_id"]/"failure.json", failure)
                    failures.append(failure)
                    print(failure, flush=True)
        del context, session
        gc.collect()
        if time.monotonic() < deadline:
            corpus = source_adapter.load_context(later[0][0]["case"])
            save(HERE/"later-context-binding.json", dict(binding=corpus.binding,
                execution_adapter=corpus.execution_adapter, in_ram=True, dataset_copied=False))
            for spec, inventory in later:
                try:
                    rows.append(run_case(spec, inventory, corpus, corpus.source_index, later=True, design=design, deadline=deadline))
                except Exception as error:
                    failure = dict(case_id=spec["case"]["case_id"], error_type=type(error).__name__, message=str(error),
                        no_api_calls=True, prior_outputs_retained=True)
                    save(HERE/"runs"/spec["case"]["case_id"]/"failure.json", failure)
                    failures.append(failure)
                    print(failure, flush=True)
        for ref in design["frozen_artifacts"]:
            assert pin(WORKSPACE/ref["path"]) == ref, "Frozen handoff or v03 DTO changed"
        save(HERE/"summary.json", dict(version="cib-query-entity-coverage-study/2", cases=rows, failures=failures,
            expected_cases=8, expected_arms=16, completed_cases=len(rows), api_calls=0, actual_new_spend_usd=0,
            shared_ledger_before_usd=design["initial_shared_ledger_usd"], shared_ledger_after_usd=ledger_total(),
            shared_ledger_changes_if_any_are_external=True, elapsed_seconds=time.monotonic()-started,
            all_outcomes_retained=True, frozen_artifacts_unchanged=True, original_v03_dto_not_modified=True,
            family_selection="CANONICAL_PARENT_REPLAY_IN_BOTH_ARMS", no_correctness_claimed=True,
            final_free_bytes=shutil.disk_usage(HERE).free))


if __name__ == "__main__":
    main()
