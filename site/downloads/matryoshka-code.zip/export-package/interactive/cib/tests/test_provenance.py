from copy import deepcopy
from collections import Counter
import pytest
from matryoshka_demo.io import digest
from phase.interactive_release_20261122.cib.artifacts import HERE, read
from phase.interactive_release_20261122.cib.local_compare import controls
from phase.interactive_release_20261122.cib.prepare_v01 import make_context_cases
from phase.interactive_release_20261122.cib.engine_v01 import selection


def test_original_report_native_pins_and_queries():
    saved, _ = controls()
    assert len(saved) == 6
    for packet, _ in saved:
        assert packet["query_sha256"] == digest(packet["case"]["query"])
        assert packet["result"]["query_sha256"] == packet["query_sha256"]


def test_context_arm_pairs_preserve_all_other_unknowns():
    public = read(HERE / "preregistered_v01/public-cases.json")
    by_arm = {}
    for row in public["delegation"]:
        assert row["gold"] is None
        assert row["opaque_markers_preserved"]
        assert row["case"]["query"].count("[MASK]") == 1
        assert row["case"]["query"].count("[REDACTED]") == 2
        assert row["case"]["document_id"] == "CIA-RDP79T00975A004300220001-9"
        assert row["case"]["date"] == "1959-02-17"
        assert row["visible_clue_is_corpus_proof"] is False
        by_arm.setdefault(row["arm"], []).append(row)
    assert len(by_arm) == 4
    for pair in by_arm.values():
        assert {r["focal"] for r in pair} == {"first", "second"}
        assert pair[0]["case"]["query"].replace("[MASK]", "[REDACTED]") == pair[1]["case"]["query"].replace("[MASK]", "[REDACTED]")


def test_no_nationality_in_focal_planning_input():
    public = read(HERE / "preregistered_v01/public-cases.json")
    for row in public["delegation"]:
        query = row["case"]["query"]
        assert "Swedish" not in query
        assert ("Swedes" in query) is row["visible_clue_given"]
        assert set(row["case"]) == {"case_id", "task", "corpus", "query", "document_id", "date", "focal_marker"}


def test_duplicate_salvadoran_is_same_document_repeated_wording_not_independent_corroboration():
    saved, _ = controls()
    packet = next(p for p, _ in saved if p["case"]["case_id"] == "narrative_cib_revision_50e63144067940b5debe3fea")
    duplicates = packet["result"]["readings"][0]["candidates"][:2]
    assert duplicates[0]["fill"] == duplicates[1]["fill"]
    assert duplicates[0]["alternative_family"] != duplicates[1]["alternative_family"]
    assert duplicates[0]["sources"][0]["canonical_page_id"] != duplicates[1]["sources"][0]["canonical_page_id"]
    assert duplicates[0]["sources"][0]["document_id"] == duplicates[1]["sources"][0]["document_id"]
    assert duplicates[0]["sources"][0]["text"] == duplicates[1]["sources"][0]["text"]
    assert all(c["local_decision"]["status"] == "evidence_backed_suggestion" for c in duplicates)
    grouped = selection.unique_surfaces(deepcopy(duplicates), 5)
    assert len(grouped) == 1
    assert grouped[0]["surface_duplicate_group"]["source_variants"] == duplicates


def test_extra_queries_have_no_revealed_target_input():
    public = read(HERE / "preregistered_v01/public-cases.json")
    proof = read(HERE / "preregistered_v01/source-provenance.json")
    assert len(public["extra_cases"]) == 3
    for case, provenance in zip(public["extra_cases"], proof["extra_cases"], strict=True):
        assert case["case_id"] == provenance["case_id"]
        assert case["document_id"] == provenance["document"]["document_id"]
        assert case["date"] == provenance["document"]["document_date_iso"]
        assert provenance["source_spans"]
        assert provenance["revealed_text"].casefold() not in case["query"].casefold()
        assert provenance["provider_input"] is False


def test_top_k_is_unique_surfaces_not_first_five_occurrences():
    from .test_engine_v01 import candidate
    original = [candidate(str(i), "same" if i < 7 else str(i), key=i) for i in range(11)]
    result = selection.unique_surfaces(selection.shortlist(original, len(original)), 5)
    assert [c["fill"] for c in result] == ["same", "7", "8", "9", "10"]
    assert len(result[0]["surface_duplicate_group"]["source_variants"]) == 7


def test_negative_reporting_scope_is_not_an_asserted_negative_action():
    saved, _ = controls()
    packet = next(p for p, _ in saved if p["case"]["case_id"] == "narrative_cib_revision_ac4fb499beb4b345b5384ae6")
    candidate = packet["result"]["readings"][0]["candidates"][2]
    original = deepcopy(candidate)
    projected = selection.unique_surfaces([candidate], 5)[0]
    assert "is not reported to have taken any position" in projected["sources"][0]["text"]
    assert projected["local_decision"] == original["local_decision"]
    assert projected["local_decision"]["status"] == "exploratory_contextual"
    assert projected["local_decision"]["requirements"][0]["coverage"] == "Missing"
    assert projected["local_decision"]["requirements"][0]["direction"] == "Unresolved"
