"""Owned CIB regression tests."""
