from copy import deepcopy
import pytest
from matryoshka_narrative import redaction_selection as current
from phase.interactive_release_20261122.cib.artifacts import HERE, read
from phase.interactive_release_20261122.cib.local_compare import controls
from phase.interactive_release_20261122.cib.presentation_v01.dedup import deduplicate_reading, normalize


def test_all_six_native_surface_orders_preserved_without_cap_replenishment():
    saved, _ = controls()
    for packet, _ in saved:
        for reading in packet["result"]["readings"]:
            before = deepcopy(reading)
            result = deduplicate_reading(reading, assessed_pool=packet["result"]["assessed_candidates"])
            expected = list(dict.fromkeys(normalize(c["fill"]) for c in before["candidates"]))
            assert [normalize(c["fill"]) for c in result["candidates"]] == expected
            assert reading == before
            assert result["presentation_contract"]["cap_replenished"] is False
            for c in result["candidates"]:
                original = next(o for o in before["candidates"] if o["id"] == c["id"])
                assert c["local_decision"] == original["local_decision"]
                assert c.get("fit_scorecard") == original.get("fit_scorecard")
                assert c["sources"] == original["sources"]


def test_arias_current_parent_fifth_not_displaced_by_unselected_remon():
    packet = read(HERE / "saved_settings_v02/narrative_cib_revision_ac39b62cbc7070a340c5d62d/execution.json.gz")
    rid = "next_reading_1a005fb20ea90c8bede96ba7"
    pool = [c for c in packet["result"]["assessed_candidates"] if c["reading_id"] == rid]
    parent = current.shortlist(deepcopy(pool), 5)
    for rank, c in enumerate(parent, 1):
        c["rank"] = rank
    reading = dict(reading=dict(id=rid), candidates=parent)
    displayed = deduplicate_reading(reading, assessed_pool=pool)
    assert displayed["candidates"][4]["fill"] == "like former President Harmodio Arias"
    assert all(c["fill"] != "like Remon" for c in displayed["candidates"])


def test_salvadoran_two_independent_decisions_one_visible_surface():
    packet = next(p for p, _ in controls()[0] if p["case"]["case_id"] == "narrative_cib_revision_50e63144067940b5debe3fea")
    reading = packet["result"]["readings"][0]
    displayed = deduplicate_reading(reading, assessed_pool=packet["result"]["assessed_candidates"])
    first = displayed["candidates"][0]
    assert first["rank"] == 1 and first["native_rank"] == 1
    assert first["local_decision"]["status"] == "evidence_backed_suggestion"
    variants = first["surface_duplicate_group"]["source_variants"]
    assert len(variants) == 2
    assert len({v["id"] for v in variants}) == 2
    assert len({v["sources"][0]["document_id"] for v in variants}) == 1
    assert [c["fill"] for c in displayed["candidates"]] == ["easily politically manipulated", "poorer"]
