from copy import deepcopy
from types import SimpleNamespace
import numpy as np
import pytest
from matryoshka_demo.io import digest
from phase.kg_patch_20261122.swedish.isolated_engine.test_isolated import fixture_context, page, public
from phase.kg_patch_20261122.swedish.isolated_engine.policy import validate_policy, checked_page
from phase.kg_patch_20261122.swedish.isolated_engine import local_gate, next_construction
from phase.interactive_release_20261122.cib.engine_v01.source_adapter import strict_policy


def test_registered_v03_policy_is_tightened_not_relabeled():
    original = page()
    corpus = fixture_context(original)
    policy = strict_policy(corpus, public())
    validate_policy(policy, public(), corpus, corpus.source_index)
    assert policy.scope.exact_origin_at_cutoff is False
    assert policy.allowed(0) is False
    assert corpus.pages[0] == original
    assert corpus.scope.exact_origin_at_cutoff is True
    with pytest.raises(ValueError):
        checked_page(original, public(), source_policy=policy)


def test_strict_prior_later_quote_runs_same_scoped_gate():
    original = page(document_id="genuinely_prior", date="1959-02-16")
    corpus = fixture_context(original)
    policy = strict_policy(corpus, public())
    validate_policy(policy, public(), corpus, corpus.source_index)
    assert policy.allowed(0) is True
    citation = policy.citation(0, 0, len(original["text"]))
    index = local_gate._pages(corpus.source_index, public())
    assert local_gate._quote(citation, *index, public(), source_policy=policy) == original
    eligible = SimpleNamespace(corpus=corpus, page_mask=np.array([True]))
    pool = dict(eligible=eligible, pages=[0], passage_budget=20)
    assert next_construction._pages(public(), pool, corpus.source_index, source_policy=policy)[2] is policy
    assert original["visibility"] == "later" and original["document_id"] == "genuinely_prior"


@pytest.mark.parametrize("change", ["document", "date", "quote", "page_hash"])
def test_strict_citations_reject_forged_origin_or_relabeling(change):
    corpus = fixture_context(page(document_id="genuinely_prior", date="1959-02-16"))
    policy = strict_policy(corpus, public())
    ref = policy.citation(0, 0, len(corpus.pages[0]["text"]))
    ref[{"document": "document_id", "date": "date", "quote": "text", "page_hash": "page_sha256"}[change]] = "forged"
    with pytest.raises(ValueError):
        local_gate._quote(ref, *local_gate._pages(corpus.source_index, public()), public(), source_policy=policy)
