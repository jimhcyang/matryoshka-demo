from copy import deepcopy
from dataclasses import replace
from types import SimpleNamespace
import pytest
from phase.interactive_release_20261122.cib.engine_v01 import selection
from phase.interactive_release_20261122.cib.engine_v01.construction import fork_functions
from phase.kg_patch_20261122.swedish.scoped_context import SourceScope


def candidate(cid, fill="alpha", status="exploratory_contextual", key=0, family="same"):
    return dict(id=cid, fill=fill, local_decision=dict(status=status, proof=dict(attribution="reported", negated=True)),
        context_rank_key=[key], source_rank_position=key, sources=[dict(text=cid)],
        source_span=[key, key+1], source_wording=fill, alternative_family=family,
        insertion_edits=[dict(kind="literal")], declared_reading=dict(id="r"))


def test_surface_dedup_preserves_full_variants_and_originals():
    original = [candidate("a"), candidate("b", " ALPHA "), candidate("c", "beta")]
    before = deepcopy(original)
    result = selection.unique_surfaces(original, 5)
    assert len(result) == 2
    group = result[0]["surface_duplicate_group"]
    assert group["source_variants"] == before[:2]
    assert result[0]["local_decision"] == before[0]["local_decision"]
    assert group["citation_union_is_support_proof"] is False
    assert original == before


def test_same_family_different_fills_not_erased():
    pool = [candidate("a", "alpha"), candidate("b", "beta")]
    assert len(selection.shortlist(pool, 99)) == 2


def test_factual_tier_precedes_context_without_pooled_support():
    context = candidate("context", key=0)
    evidence = candidate("proof", status="evidence_backed_suggestion", key=100)
    selected = selection.unique_surfaces(selection.shortlist([context, evidence], 10), 5)
    assert selected[0]["id"] == "proof"
    assert selected[0]["local_decision"]["status"] == "evidence_backed_suggestion"
    assert selected[0]["surface_duplicate_group"]["source_variants"][1] == context


def test_context_cannot_be_promoted_by_ordering_tier():
    with pytest.raises(ValueError):
        selection.shortlist([candidate("x")], 5, ordering_tiers={"x": 0})


def test_unknown_context_key_set_rejected():
    with pytest.raises(ValueError):
        selection.shortlist([candidate("x")], 5, context_keys={})


def test_private_function_globals_do_not_modify_parent():
    from matryoshka_narrative import construction as parent
    old = parent.selection
    fork = fork_functions(parent, selection=SimpleNamespace(VERSION="new"))
    assert fork["construct"].__globals__["selection"].VERSION == "new"
    assert parent.selection is old
    assert parent.construct.__globals__["selection"] is old


@pytest.mark.parametrize("date,document,expected", [
    ("1959-02-16", "prior", True), ("1959-02-17", "other", False),
    ("1959-02-18", "future", False), ("1959-02-16", "origin", False),
    ("1959-02-17", "origin", False),
])
def test_strict_origin_scope(date, document, expected):
    s2 = SourceScope("cib", "later", "1959-02-17", "origin", True)
    strict = replace(s2, exact_origin_at_cutoff=False)
    page = dict(corpus="cib", permitted=True, quarantined=False, release="later", visibility="later",
        date=date, document_id=document)
    assert strict.admits(page) is expected


def test_no_dictionary_or_added_fill_realization():
    original = [candidate("a", "Swedes"), candidate("b", "Swedish")]
    result = selection.unique_surfaces(original, 5)
    assert [c["fill"] for c in result] == ["Swedes", "Swedish"]
