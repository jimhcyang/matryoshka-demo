from pathlib import Path
import pytest
from matryoshka_demo.io import digest
from phase.interactive_release_20261122.cib.artifacts import HERE, read
from phase.interactive_release_20261122.cib.analysis_tools.complete_views import project


def dto_path():
    latest = HERE / "dto/public-study-complete-v03.json"
    if latest.exists():
        return latest
    final = HERE / "dto/public-study-complete-v02.json"
    return final if final.exists() else HERE / "dto/public-study-planning-v01.json"


def test_dto_has_all_eight_states_not_a_success_subset():
    dto = read(dto_path())
    assert len(dto["cases"]) == 8
    assert len([v for v in dto["variants"] if "budget_arm" not in v]) == 8
    assert len(dto["design"]["window_arms"]) == 4
    assert len({(c["window_arm"], c["position"]) for c in dto["cases"]}) == 8
    for case in dto["cases"]:
        assert case["gold"] is None and case["reference_answer"] is None
        assert (case["status"] == "EXECUTED") is case["execution_performed"]
        if not case["execution_performed"]:
            assert case["execution_ref"] is None
            assert case["inspected_page_count"] is None
            assert all(not r["candidates"] for r in case["readings"])


def test_origin_full_window_and_piecewise_input_offsets_replay():
    dto = read(dto_path())
    origin = dto["origin"]
    window = origin["full_window"]
    assert window["start"] == 0 and window["end"] == len(window["text"])
    assert window["page_text_sha256"] == digest(window["text"])
    assert origin["eligible_as_corpus_evidence"] is False
    assert origin["input_only"] and origin["entire_origin_excluded"]
    cases = {c["case"]["case_id"]: c["case"] for c in dto["cases"]}
    for mapping in origin["input_window_mappings"]:
        case = cases[mapping["case_id"]]
        for segment in mapping["segments"]:
            a, b = segment["source_span"]
            c, d = segment["query_span"]
            assert window["text"][a:b] == segment["exact_source_text"]
            assert case["query"][c:d] == segment["rendered_query_text"]
        assert mapping["producer_observation_coordinates"] is False


def test_old_s2_controls_never_become_ordinary_evidence():
    dto = read(dto_path())
    assert len(dto["historical_exact_origin_controls"]) == 2
    for control in dto["historical_exact_origin_controls"]:
        assert control["control_only"]
        assert control["ordinary_evidence"] is False
        assert control["scope"]["exact_origin_admitted"]
    for case in dto["cases"]:
        assert case["scope"]["whole_origin_excluded"]
        assert case["scope"]["strict_prior"]
        assert case["scope"]["exact_origin_admitted"] is False
        for reading in case["readings"]:
            for candidate in reading["candidates"]:
                assert candidate["citation_union_is_support_proof"] is False
                for variant in candidate["source_variants"]:
                    for citation in variant["sources"]:
                        assert citation["document_id"] != case["case"]["document_id"]
                        assert citation["date"] < case["case"]["date"]


def test_public_dto_has_no_machine_absolute_paths():
    def inspect(value):
        if isinstance(value, dict):
            for child in value.values():
                inspect(child)
        elif isinstance(value, list):
            for child in value:
                inspect(child)
        elif isinstance(value, str):
            assert "/Users/" not in value
            assert "OPENAI_API_KEY" not in value
    inspect(read(dto_path()))


def test_late_scorecard_projection_preserves_decisions_and_native_packet():
    from copy import deepcopy
    for path in sorted((HERE / "fresh_v02").glob("*/execution.json.gz")):
        packet = read(path)
        before = digest(packet)
        projected = project(packet)
        assert digest(packet) == before
        assert projected["new_scoring_performed"] is False
        for original, view in zip(packet["result"]["readings"], projected["readings"], strict=True):
            assert [(c["id"], c["rank"], c["fill"], c["local_decision"]) for c in original["candidates"]] == [
                (c["id"], c["rank"], c["fill"], c["local_decision"]) for c in view["candidates"]]
            for candidate in view["candidates"]:
                assert "fit_scorecard" in candidate
                assert candidate["fit_scorecard"]["factual_support_implied"] is False


def test_v03_full_source_pages_replay_all_selected_variant_citations():
    from phase.interactive_release_20261122.cib.analysis_tools.public_sources_v03 import citations
    dto = read(HERE / "dto/public-study-complete-v03.json")
    pages = dto["source_pages"]
    for ref in citations([dto["cases"], dto["historical_exact_origin_controls"], dto["supplemental_budget_controls"]]):
        page = pages[ref["canonical_page_id"]]
        assert page["id"] == ref["canonical_page_id"]
        assert page["document_id"] == ref["document_id"] and page["date"] == ref["date"]
        assert page["source_sha256"] == digest(page["text"]) == ref["page_sha256"]
        assert page["text"][ref["start"]:ref["end"]] == ref["text"]
        assert page["release"] == page["visibility"] == "later"
        assert page["permitted"] is True
    for page in dto["provenance_only_source_pages"].values():
        assert page["provenance_only"] is True
        assert page["corroboration_added_by_page_inspection"] is False
    assert dto["origin"]["document"]["text"] == dto["origin"]["full_window"]["text"]
    assert dto["origin"]["document"]["hash"] == digest(dto["origin"]["document"]["text"])
    assert dto["origin"]["source_mapping"] == dto["origin"]["document"]["source_mapping"]


def test_budget_controls_do_not_invent_sources_or_answers():
    dto = read(HERE / "dto/public-study-complete-v03.json")
    assert len(dto["supplemental_budget_controls"]) == 6
    assert len(dto["variants"]) == 14
    for control in dto["supplemental_budget_controls"]:
        assert control["gold"] is None
        assert control["execution_performed"] is True
        assert control["execution_contract"] == "cib-local-coverage-budget-execution/1"
        assert control["scope"]["whole_origin_excluded"] is True
    assert dto["source_coverage"]["literal_Swedish_attested_pages"] == 66
    assert dto["source_coverage"]["all_primary_and_budget_inspected_attestation_pages"] == 0


def test_v01_helper_snapshot_matches_actual_executed_byte_pin():
    from phase.interactive_release_20261122.cib.artifacts import pin
    packet = read(HERE / "fresh_v01/narrative_cib_revision_ac39b62cbc7070a340c5d62d/execution.json.gz")
    assert pin(HERE / "snapshots/artifacts_before_v02.py")["sha256"] == packet["code_pins"][
        "phase/interactive_release_20261122/cib/artifacts.py"]
