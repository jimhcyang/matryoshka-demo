"""Fresh isolated runs; one bounded shared-ledger planning batch at most."""
from copy import deepcopy
from datetime import datetime, timezone
import gc
import os
import time
from matryoshka_demo.io import digest
from matryoshka_next.workflow import Session
from matryoshka_narrative.retrieval import retrieve as ordinary_retrieve
from matryoshka_next.facts import SourcePolicy
from phase.kg_patch_20261122.swedish.isolated_engine import planning
from phase.kg_patch_20261122.swedish.isolated_engine.api import Budget
from phase.kg_patch_20261122.swedish.isolated_engine.run_study import cite_replay
from .artifacts import HERE, ROOT, WORKSPACE, headroom, read, pin, write, code_pins
from .engine_v01.construction import construct
from .engine_v01 import source_adapter
from .local_compare import controls, rows
from .prepare_v01 import CONFIG

LEDGER = ROOT / "experiments/narrative_demo/api"
OUT = HERE / "fresh_v01"


def execute(case, plan, corpus, source_index, *, later=False, label=None):
    target = OUT / case["case_id"] / "execution.json.gz"
    if target.exists():
        previous = read(target)
        if previous["case"] != case or previous["plan"] != plan or previous["code_pins"] != code_pins():
            raise ValueError("Execution cache mismatch; never silently substitute an old result")
        return previous, pin(target)
    headroom()
    start = time.perf_counter()
    pins = code_pins()
    options = dict(method=CONFIG["method"], passage_budget=CONFIG["retrieval_passage_budget"],
        document_budget=CONFIG["retrieval_document_budget"])
    if later:
        found = source_adapter.retrieve(corpus, case, plan, **options)
        policy = corpus.policy_for(case)
    else:
        found = ordinary_retrieve(corpus, case, plan, source_index=source_index, **options)
        policy = SourcePolicy(found["eligible"].corpus, case, source_index)
    kwargs = dict(source_index=source_index, passage_budget=CONFIG["construction_pages"],
        draft_budget=CONFIG["completed_drafts_per_reading"], selection_profile=CONFIG["selection_profile"], top_k=5)
    if later:
        kwargs["source_policy"] = policy
    print(dict(stage="construct", case_id=case["case_id"], later_release=later), flush=True)
    result = construct(case, plan, found, **kwargs)
    replayed = cite_replay(result, policy)
    if code_pins() != pins:
        raise RuntimeError("Inference code changed during this run")
    if result["query_sha256"] != digest(case["query"]) or result["provided_plan_sha256"] != digest(plan):
        raise AssertionError("Execution query/plan binding changed")
    packet = dict(version="cib-isolated-common-pipeline-execution/1", canonical_native_run=False,
        legacy_native_completion=False, execution_performed=True, case=case, plan=plan, result=result,
        native_checksum=digest(result), configuration=CONFIG, query_sha256=digest(case["query"]), code_pins=pins,
        retrieval=deepcopy(found["receipt"]), original_retrieval_walk_recorded=False,
        source_binding=deepcopy(corpus.binding) if later else None,
        source_adapter=corpus.execution_adapter if later else dict(version="ordinary-strict-earlier/1"),
        source_citations_replayed=replayed, api_calls_during_execution=0, unknown_gold=None,
        whole_origin_excluded=True, strict_prior=True, experiment_label=label,
        selected_evidence_handoffs=[dict(candidate_id=c["id"], reading_id=c["reading_id"],
            route_mode="DIRECT_SOURCE_HANDOFF", graph_edges=[], source_refs=deepcopy(c["sources"]),
            original_retrieval_walk=False, factual_support_implied=False,
            status=c["local_decision"]["status"]) for c in result["candidates"]],
        trace_contract=dict(version="cib-isolated-selected-evidence-handoffs/1", no_graph_route_invented=True,
            postrun_graph_view_is_original_walk=False, saved_control_route_modes_unchanged=True),
        elapsed_seconds=time.perf_counter() - start)
    ref = write(target, packet)
    write(target.with_name("completion.json"), dict(version="cib-isolated-common-pipeline-completion/1",
        execution_ref=ref, execution_digest=digest(packet), result_sha256=digest(result),
        original_canonical_native_completion=False, execution_performed=True))
    print(dict(stage="complete", case_id=case["case_id"], seconds=round(packet["elapsed_seconds"], 2),
        candidates=[(r["reading_id"], r["rank"], r["fill"], r["status"]) for r in rows(result)]), flush=True)
    return packet, ref


def local_six():
    saved, _ = controls()
    summaries = []
    with Session() as session:
        context = session.context("cib")
        for old, old_ref in saved:
            packet, ref = execute(old["public_case"], old["plan"], context.corpus, context.source_index,
                label="fresh_common_pipeline_cached_query_plan_readings")
            summaries.append(dict(case_id=old["case"]["case_id"], control_ref=old_ref,
                fresh_ref=ref, control=rows(old["result"]), fresh=rows(packet["result"])))
    write(OUT / "six-summary.json", dict(version="six-cib-fresh-regression/1", cases=summaries, api_calls=0))


def bounded_batch():
    from dotenv import load_dotenv
    load_dotenv(WORKSPACE / ".env")
    load_dotenv(WORKSPACE / "src-redaction/.env")
    public_path = HERE / "preregistered_v01/public-cases.json"
    catalog = read(public_path)
    design = read(HERE / "preregistered_v01/design.json")
    cases = [r["case"] for r in catalog["delegation"]] + catalog["extra_cases"]
    if len(cases) != design["maximum_planning_cases"]:
        raise ValueError("Preregistered planning batch membership changed")
    auth_path = OUT / "batch-authorization.json"
    if auth_path.exists():
        raise RuntimeError("The sole bounded batch has already started; no second paid batch authorized")
    before = Budget(LEDGER).total()
    os.environ["NARRATIVE_INCREMENTAL_BASELINE_USD"] = str(before)
    os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"] = "8"
    write(auth_path, dict(version="cib-one-bounded-batch/1", started_utc=datetime.now(timezone.utc).isoformat(),
        public_inputs_ref=pin(public_path), design_ref=pin(HERE / "preregistered_v01/design.json"),
        budget_before_usd=before, incremental_ceiling_usd=8, cumulative_ceiling_usd=50,
        maximum_cases=11, canonical_code_pins=code_pins(), key_logged=False))
    failures, prepared = [], []
    for case in cases:
        headroom()
        directory = OUT / case["case_id"]
        try:
            print(dict(stage="query_only_planning", case_id=case["case_id"]), flush=True)
            saved = planning.parse(case, LEDGER, model="gpt-6-luna")
            write(directory / "normal-plan.json", saved)
            selected, audit = planning.model_readings(case, LEDGER)
            write(directory / "normal-readings.json", dict(packet=selected, audit=audit))
            plan = deepcopy(saved["native_plan"])
            plan["readings_packet"] = selected
            prepared.append((case, plan))
        except Exception as error:
            failure = dict(case_id=case["case_id"], stage="planning", error_type=type(error).__name__)
            failures.append(failure)
            write(directory / "planning-failure.json", failure)
    after = Budget(LEDGER).total()
    write(OUT / "planning-complete.json", dict(version="cib-one-batch-planning-complete/1",
        budget_before_usd=before, budget_after_usd=after, shared_ledger_delta_usd=after-before,
        incremental_cap_usd=8, prepared_case_ids=[case["case_id"] for case, _ in prepared], failures=failures))
    os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"] = "0"
    if after - before > 8 + 1e-9:
        raise RuntimeError("Shared incremental envelope exceeded")
    # No provider calls occur below this line. Keep only one large corpus warm.
    extra_ids = {c["case_id"] for c in catalog["extra_cases"]}
    with Session() as session:
        context = session.context("cib")
        for case, plan in prepared:
            if case["case_id"] in extra_ids:
                execute(case, plan, context.corpus, context.source_index, label="authentic_extra_case")
    del context, session
    gc.collect()
    delegation = [(c, p) for c, p in prepared if c["case_id"] not in extra_ids]
    if delegation:
        corpus = source_adapter.load_context(delegation[0][0])
        write(OUT / "later-context-binding.json", dict(binding=corpus.binding, adapter=corpus.execution_adapter,
            coordinate_audit=corpus.coordinate_audit, source_view_sha256=digest(corpus.binding),
            materialized_in_ram=True, new_dataset_copy=False))
        for case, plan in delegation:
            try:
                execute(case, plan, corpus, corpus.source_index, later=True, label="preregistered_delegation_context")
            except Exception as error:
                failure = dict(case_id=case["case_id"], stage="execution", error_type=type(error).__name__)
                failures.append(failure)
                write(OUT / case["case_id"] / "execution-failure.json", failure)
                print(failure, flush=True)
    write(OUT / "batch-complete.json", dict(version="cib-one-bounded-batch-complete/1", failures=failures,
        budget_before_usd=before, budget_after_usd=Budget(LEDGER).total(), new_paid_batches=1,
        expected_cases=[c["case_id"] for c in cases], all_failures_preserved=True))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("local", "batch"))
    args = parser.parse_args()
    local_six() if args.mode == "local" else bounded_batch()
