"""Conservative canonical-page-policy comparison, preserving v01 outcomes."""
