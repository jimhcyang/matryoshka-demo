"""Canonical /27 construction and page policy, exact-surface final shortlist.

Only source-policy plumbing differs for the later-release adapter. No parent
module globals are modified; each call owns its function/global graph.
"""
from types import SimpleNamespace
from matryoshka_narrative import construction as canonical
from phase.kg_patch_20261122.swedish.isolated_engine import next_construction as scoped
from ..engine_v01.construction import fork_functions
from ..engine_v01 import selection

VERSION = "cib-canonical-pages-exact-surface-construction/2"


def construct(case, plan, retrieval, top_k=5, *, source_policy=None, **kwargs):
    shared = canonical.shared
    if source_policy is not None:
        def pages(*args, **options):
            return scoped._pages(*args, source_policy=source_policy, **options)

        def gate(*args, **options):
            return scoped._gate(*args, source_policy=source_policy, **options)

        shared = SimpleNamespace(**dict(vars(shared), _pages=pages, _gate=gate))

    def shortlist(values, count, **options):
        ordered = selection.shortlist(values, len(values), **options)
        return selection.unique_surfaces(ordered, count)

    selected = SimpleNamespace(**dict(vars(canonical.selection), shortlist=shortlist, VERSION=selection.VERSION))
    engine = fork_functions(canonical, shared=shared, selection=selected, VERSION=VERSION)
    result = engine["construct"](case, plan, retrieval, top_k=top_k, **kwargs)
    result["isolated_delta"] = dict(common_constructor=True, parent=canonical.VERSION,
        canonical_page_policy_unchanged=True, support_gates_modified=False,
        exact_surface_final_grouping=True, complete_individual_variants=True,
        parent_modules_modified=False, no_named_rules=True, no_demonym_mapping=True,
        explicit_source_policy_adapter=source_policy is not None)
    return result
