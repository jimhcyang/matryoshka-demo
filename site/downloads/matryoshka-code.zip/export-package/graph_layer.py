"""Case-independent, lossless graph cache; unused dictionary rows are removed.

Dictionary padding is transport-only. Every graph root retains its original
decoded SHA, hence no actual graph node, edge, value or label can be omitted.
"""
import argparse
import gzip
import hashlib
import json
from pathlib import Path


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':')).encode()


def extract(stage, output):
    here = Path(__file__).resolve().parent
    assert stage.is_relative_to(here) and output.is_relative_to(here) and not output.exists()
    site = stage / 'site'
    index = json.loads((site / 'data/api-index.json').read_bytes())
    entries = {k:dict(v) for k,v in index['entries'].items() if k.startswith('/graph-assets-v4/')}
    groups = {}
    for key, entry in entries.items():
        assert entry['encoding'] == 'fragment-dag' and not entry.get('external_url')
        groups.setdefault(entry['path'], []).append(key)
    output.mkdir(parents=True, exist_ok=False)
    files = {}
    def write(relative, raw):
        path = output / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists(): assert path.read_bytes() == raw
        else: path.write_bytes(raw)
        files[relative] = dict(path=relative, sha256=sha(raw), bytes=len(raw))
    for source_path, keys in groups.items():
        old = json.loads((site / source_path).read_bytes())
        roots = {entries[k]['asset']:old['assets'][entries[k]['asset']] for k in keys}
        needed = bytearray(old['chunks'][-1]['last_id'] + 1)
        for root in roots.values():
            for value in root['pieces'][1::2]: needed[value] = 1
        chunks = [None] * len(old['chunks'])
        for i in range(len(old['chunks'])-1, -1, -1):
            chunk = old['chunks'][i]
            wire = (site / Path(source_path).parent / chunk['path']).read_bytes()
            assert sha(wire) == chunk['wire_sha256']
            raw = gzip.decompress(wire)
            assert sha(raw) == chunk['sha256decoded']
            payload = json.loads(raw)
            rows = payload['fragments']
            for n in range(len(rows)-1, -1, -1):
                identity = chunk['first_id'] + n
                if needed[identity]:
                    for child in rows[n][1::2]:
                        assert type(child) is int and 0 < child < identity
                        needed[child] = 1
                else:
                    rows[n] = ['']
            raw = encoded(payload)
            wire = gzip.compress(raw, compresslevel=9, mtime=0)
            relative = 'chunks/' + sha(wire) + '.json.gz'
            write('data/graph-layer/' + relative, wire)
            chunks[i] = dict(chunk, path=relative, wire_sha256=sha(wire), sha256decoded=sha(raw), wire_bytes=len(wire), decoded_bytes=len(raw))
        manifest = dict(version='graph-fragment-dag/1', encoding='fragment-dag', chunks=chunks, assets=roots)
        if old.get('literal_encoding'): manifest['literal_encoding'] = old['literal_encoding']
        raw = encoded(manifest)
        relative = 'data/graph-layer/' + sha(raw) + '.json'
        write(relative, raw)
        for key in keys:
            entries[key].update(path=relative, manifest_sha256=sha(raw))
    receipt = json.loads((stage / 'stage_receipt.json').read_bytes())
    value = dict(version='generic-full-map-layer/1', map_index_sha256=receipt['map_index_sha256'],
        entries=entries, files=list(files.values()), active_asset_sha256={k:v['sha256'] for k,v in entries.items()},
        scope='GENERIC_FULL_MAP_ONLY_NO_CASE_RESPONSES', case_responses_reused=False,
        all_graph_root_hashes_preserved=True, native_or_graph_semantics_modified=False)
    (output / 'graph-layer.json').write_bytes(encoded(value))
    print(json.dumps(dict(graphs=len(entries), bytes=sum(v['bytes'] for v in files.values()), manifest_sha256=sha(encoded(value)))))


def reuse(stage, source, map_index_sha256, active_keys, source_entries):
    raw = (source / 'graph-layer.json').read_bytes()
    layer = json.loads(raw)
    assert layer['version'] == 'generic-full-map-layer/1' and layer['scope'] == 'GENERIC_FULL_MAP_ONLY_NO_CASE_RESPONSES'
    assert layer['map_index_sha256'] == map_index_sha256
    assert layer['active_asset_sha256'] == {k:source_entries[k]['sha256'] for k in active_keys}
    for item in layer['files']:
        assert not item['path'].startswith('/') and '\\' not in item['path'] and all(p not in ('', '.', '..') for p in item['path'].split('/'))
        path = source / item['path']
        assert path.resolve() == path and path.is_file()
        data = path.read_bytes()
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
        stage.write('site/' + item['path'], data)
    return layer['entries'], sha(raw)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    extract(args.stage.resolve(), args.output.absolute())
