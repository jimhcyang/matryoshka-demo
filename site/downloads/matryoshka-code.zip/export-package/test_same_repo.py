"""Same-repository transport safety fixtures; no app graph or story is invented."""
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
from threading import Thread
import unittest
from urllib.error import HTTPError
from urllib.request import urlopen

from export_narrative import HERE, adapt_runtime, encoded, sha
from same_repo import dataset
from serve_static import server
from playwright.sync_api import sync_playwright


class SameRepositoryTests(unittest.TestCase):
    def fixture(self, root):
        site = root / 'site'
        (site / 'data').mkdir(parents=True)
        (site / 'runtime').mkdir()
        raw = encoded(dict(exact='transport fixture, not a KG narrative'))
        wire = gzip.compress(raw, mtime=0)
        key = '/graph-assets-v4/cib/fixture.json.gz'
        entry = dict(encoding='gzip', mime='application/json', sha256=sha(raw), wire_sha256=sha(wire),
            external_url='https://raw.githubusercontent.com/jimhcyang/matryoshka-demo/' + 'a'*40 + '/datasets/cib/' + sha(wire) + '.json.gz')
        row = dataset(key, entry)
        target = root / row['path']
        target.parent.mkdir(parents=True)
        target.write_bytes(wire)
        (site / 'data/dataset-delivery.json').write_bytes(encoded(dict(files=[dict(row, bytes=len(wire))])))
        index = encoded(dict(version='matryoshka-public-api-index/1', entries={key:entry}))
        (site / 'data/api-index.json').write_bytes(index)
        (site / 'runtime/public-runtime.js').write_bytes(adapt_runtime((HERE / 'vendor/runtime/public-runtime.js').read_bytes()))
        html = '<!doctype html><script src="runtime/public-runtime.js" data-dataset-mirror="same-repository" data-index="data/api-index.json" data-index-sha256="' + sha(index) + '"></script>'
        (site / 'index.html').write_text(html)
        return site, key, entry, row, target, wire

    def test_repository_commit_corpus_and_filename_must_match(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            _, key, entry, *_ = self.fixture(Path(temporary))
            for url in (entry['external_url'].replace('/jimhcyang/', '/other/'),
                entry['external_url'].replace('raw.githubusercontent.com', 'example.org'),
                entry['external_url'].replace('a'*40, 'main'), entry['external_url'].replace('/cib/', '/iran/'),
                entry['external_url'].replace(entry['wire_sha256'], '0'*64), entry['external_url']+'?x=1'):
                with self.assertRaises(AssertionError): dataset(key, dict(entry, external_url=url))

    def test_local_mirror_exact_hash_traversal_symlink_and_changed_wire(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root = Path(temporary)
            site, _, _, row, target, wire = self.fixture(root)
            http = server(site)
            thread = Thread(target=http.serve_forever, daemon=True)
            thread.start()
            base = 'http://127.0.0.1:' + str(http.server_port)
            try:
                with urlopen(base + '/') as r:
                    self.assertEqual(r.url, base + '/matryoshka-demo/')
                with self.assertRaises(AssertionError):
                    server(site, prefix='//outside.example/')
                with urlopen(base + '/' + row['path']) as r:
                    self.assertEqual(r.read(), wire)
                    self.assertIsNone(r.headers.get('Content-Encoding'))
                for path in ('/datasets/../private', '/datasets/%2e%2e/private', '/' + row['path']+'?bad=1',
                    '/datasets/cib/'+'0'*64+'.json.gz'):
                    with self.assertRaises(HTTPError) as error: urlopen(base + path)
                    self.assertEqual(error.exception.code, 404)
                target.write_bytes(b'wrong wire')
                with self.assertRaises(HTTPError) as error: urlopen(base + '/' + row['path'])
                self.assertEqual(error.exception.code, 409)
                alternate = root / 'alternate'
                alternate.write_bytes(wire)
                target.unlink()
                target.symlink_to(alternate)
                with self.assertRaises(HTTPError) as error: urlopen(base + '/' + row['path'])
                self.assertEqual(error.exception.code, 404)
            finally:
                http.shutdown(); http.server_close(); thread.join()

    def test_managed_browser_local_mirror_and_exact_remote_only(self):
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            site, key, entry, _, _, wire = self.fixture(Path(temporary))
            http = server(site)
            thread = Thread(target=http.serve_forever, daemon=True)
            thread.start()
            origin = 'http://127.0.0.1:' + str(http.server_port)
            try:
                with sync_playwright() as p:
                    browser = p.chromium.launch(headless=True)
                    for hostname in ('local', 'jimhcyang.github.io', 'localhost.example.org'):
                        context = browser.new_context()
                        seen = []
                        base = origin + '/matryoshka-demo/' if hostname == 'local' else 'https://' + hostname + '/matryoshka-demo/'
                        def route(r):
                            url = r.request.url
                            seen.append(url)
                            if hostname == 'local':
                                r.continue_() if url.startswith(origin + '/') else r.abort()
                            elif url.startswith(base):
                                name = url[len(base):] or 'index.html'
                                path = site / name
                                r.fulfill(status=200, body=path.read_bytes(), content_type='text/html' if name.endswith('.html') else 'application/javascript' if name.endswith('.js') else 'application/json')
                            elif url == entry['external_url']:
                                r.fulfill(status=200, body=wire, content_type='application/gzip')
                            else:
                                r.abort()
                        context.route('**/*', route)
                        page = context.new_page()
                        page.goto(base + 'index.html')
                        page.evaluate('async()=>await PublicReplay.ready')
                        result = page.evaluate("""async key=>{const r=await fetch(key);const b=await r.arrayBuffer();return {status:r.status,sha:[...new Uint8Array(await crypto.subtle.digest('SHA-256',b))].map(x=>x.toString(16).padStart(2,'0')).join('')}}""", key)
                        self.assertEqual(result, dict(status=200, sha=entry['wire_sha256']))
                        if hostname == 'local':
                            self.assertTrue(any('/datasets/cib/' in u for u in seen))
                            self.assertFalse(any(u.startswith('https://raw.') for u in seen))
                        else:
                            self.assertIn(entry['external_url'], seen)
                            self.assertFalse(any(u.startswith(base+'datasets/') for u in seen))
                        context.close()
                    browser.close()
            finally:
                http.shutdown(); http.server_close(); thread.join()


if __name__ == '__main__':
    unittest.main()
