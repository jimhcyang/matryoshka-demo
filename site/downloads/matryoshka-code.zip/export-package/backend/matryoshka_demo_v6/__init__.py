"""Current three-arm workbench; frozen earlier native packages are read-only."""

VERSION = "inspectable-three-task-workbench/6"
