"""Independent legacy-cable source admission; never inference or assessment input."""
from copy import deepcopy
import csv
from datetime import date
import json
from pathlib import Path
import re

from matryoshka_demo.io import digest, load, rows, sha
from . import server_origin_v63 as base


VERSION = "independent-legacy-cable-source-reaudit/6.5.1"
SOURCE_REGISTRY_PATH = "experiments/source_registry/cable_origins_v65_registry_v01.json"
SOURCE_REGISTRY_SHA256 = "ad2de94d9c8c00438a5187b75b5d2134a7a6e5008e8e9af281d686ea8e2a0989"
SOURCE_REGISTRY_REF = dict(path=SOURCE_REGISTRY_PATH, sha256=SOURCE_REGISTRY_SHA256)
METADATA_PATH = "src/data/metadata/cfpf/cfpf_local_documents.csv"


def source_registry_ref(root):
    """The explicit artifact reference for the UI seal; never choose a latest file."""
    root = Path(root).resolve()
    base._bound_file(root, SOURCE_REGISTRY_PATH, SOURCE_REGISTRY_SHA256,
                     directory=root / "experiments/source_registry")
    return dict(path=SOURCE_REGISTRY_PATH, sha256=SOURCE_REGISTRY_SHA256)


def _unique(records, key):
    result = {}
    for record in records:
        value = key(record)
        if value in result:
            raise ValueError("Duplicate source identity: " + str(value))
        result[value] = record
    return result


def source_refs(root, corpus):
    if corpus not in {"iran", "vietnam"}:
        raise ValueError("Only cable corpora may receive a re-audit")
    root = Path(root).resolve()
    binding = load(root / "data/bindings.json")
    files = binding["corpora"][corpus]["files"]
    workspace = root.parent
    return dict(binding=dict(path="data/bindings.json", sha256=sha(root / "data/bindings.json")),
        raw=dict(path=f"src/data/raw/{corpus}/source_input.csv",
                 sha256=sha(workspace / f"src/data/raw/{corpus}/source_input.csv")),
        metadata=dict(path=METADATA_PATH, sha256=sha(workspace / METADATA_PATH)),
        canonical=files["pages"], projection=files["projection"], documents=files["documents"])


def source_bundle(root, corpus, refs):
    """Recheck every file pin before reading original rows and all sibling segments."""
    root = Path(root).resolve()
    if corpus not in {"iran", "vietnam"} or refs["binding"]["path"] != "data/bindings.json":
        raise ValueError("Unsupported source binding")
    binding = base._bound_json(root, **dict(relative=refs["binding"]["path"], expected=refs["binding"]["sha256"]))
    files = binding["corpora"][corpus]["files"]
    for name, key in (("canonical", "pages"), ("projection", "projection"), ("documents", "documents")):
        if refs[name] != files[key]:
            raise ValueError("Source registry differs from current pinned binding")
    if refs["raw"]["path"] != f"src/data/raw/{corpus}/source_input.csv" or refs["metadata"]["path"] != METADATA_PATH:
        raise ValueError("Unexpected original source path")
    paths = {}
    for key in ("raw", "metadata", "canonical", "projection", "documents"):
        ref = refs[key]
        directory = root.parent / ("src/data" if key in {"raw", "metadata"} else f"src-redaction/data/corpora/{corpus}")
        paths[key] = base._bound_file(root.parent, ref["path"], ref["sha256"], directory=directory)
    with paths["raw"].open(newline="") as stream:
        originals = _unique(csv.DictReader(stream), lambda r: r["id"])
    with paths["metadata"].open(encoding="utf-8-sig", newline="") as stream:
        metadata = _unique((r for r in csv.DictReader(stream) if r["corpora"].lower() == corpus),
                           lambda r: r["local_doc_id"].strip())
    canonical = list(rows(paths["canonical"]))
    _unique(canonical, lambda r: r["segment_id"])
    return dict(originals=originals, metadata=metadata, canonical=canonical,
        projection=load(paths["projection"])["document_metadata"],
        documents=_unique(rows(paths["documents"]), lambda r: r["document_id"]), refs=deepcopy(refs))


def audit_case(case, proof, bundle):
    """Pure source replay. No retrieval, grades, required-atom counts, or nomination."""
    corpus, did = case["corpus"], case["document_id"]
    if corpus not in {"iran", "vietnam"}:
        raise ValueError("CIB is outside cable re-audit")
    raw, metadata = bundle["originals"][did], bundle["metadata"][did]
    projected, document = bundle["projection"][did], bundle["documents"][did]
    body = raw["body"]
    classification = metadata["origclass"].strip().upper()
    handling = sorted(t.strip().upper() for t in re.split(r"[,;|]", metadata["orighand"])
                      if t.strip() and t.strip().upper() != "N/A")
    whole_body_noforn = bool(re.search(r"\bNOFORN\b", body, re.I))
    metadata_noforn = bool(re.search(r"\bNOFORN\b", metadata["orighand"], re.I))
    if (classification != "SECRET" or projected["classification"] != "SECRET"
            or projected["policy_role"] != "secret_expansion"):
        raise ValueError("ORIGIN_NOT_SECRET_IN_ORIGINAL_METADATA_AND_PROJECTION")
    if handling != sorted(projected["handling"]) or whole_body_noforn or metadata_noforn:
        raise ValueError("WHOLE_ORIGIN_NOFORN_OR_HANDLING_MISMATCH")
    if (date.fromisoformat(case["date"]).isoformat() != case["date"] or raw["date"] != case["date"]
            or (document.get("document_date_iso") or document.get("date_iso")) != case["date"]):
        raise ValueError("ORIGINAL_DOCUMENT_DATE_MISMATCH")
    siblings = sorted((r for r in bundle["canonical"] if r["document_id"] == did),
                      key=lambda r: r["segment_sequence"])
    if not siblings or [r["segment_sequence"] for r in siblings] != list(range(1, len(siblings) + 1)):
        raise ValueError("CANONICAL_SIBLING_SEQUENCE_MISMATCH")
    for segment in siblings:
        start, end = segment["source_char_start"], segment["source_char_end"]
        if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(body)
                or body[start:end] != segment["text"] or segment["segment_count"] != len(siblings)
                or segment["document_date_iso"] != case["date"]):
            raise ValueError("RAW_CANONICAL_SIBLING_OFFSET_OR_DATE_MISMATCH")
    source = proof["origin"]
    if (source["document_id"] != did or source["date"] != case["date"]
            or source["classification"] != "SECRET" or source.get("permitted") is not False
            or source.get("end") - source.get("start") != len(source["text"])
            or digest(source["text"]) != source["source_text_sha256"]
            or digest(source["text"]) != source.get("quote_sha256", source["source_text_sha256"])):
        raise ValueError("LEGACY_ORIGIN_SOURCE_BINDING_MISMATCH")
    canonical_origin = [r for r in siblings if r["segment_id"] == source["source_id"]]
    if canonical_origin:
        if len(canonical_origin) != 1 or source["text"] != canonical_origin[0]["text"]:
            raise ValueError("LEGACY_CANONICAL_ORIGIN_MISMATCH")
        origin_offset = canonical_origin[0]["source_char_start"]
    else:
        if source["source_id"] not in {did, "raw-cable:" + did} or source["text"] != body:
            raise ValueError("UNKNOWN_OR_NONLITERAL_RAW_ORIGIN")
        origin_offset = 0
    if body.count(source["text"]) != 1 or body[origin_offset:origin_offset + len(source["text"])] != source["text"]:
        raise ValueError("NONUNIQUE_ORIGINAL_BODY_ORIGIN_MAPPING")

    def replay(anchor):
        local = base._anchor(anchor, source["text"], source)
        if anchor.get("classification", "SECRET") != "SECRET" or anchor.get("permitted", False) is not False:
            raise ValueError("ANCHOR_CLASSIFICATION_OR_PERMISSION_MISMATCH")
        start, end = origin_offset + local["start"], origin_offset + local["end"]
        if body[start:end] != local["text"]:
            raise ValueError("RAW_QUOTE_ANCHOR_MISMATCH")
        return dict(local, raw_start=start, raw_end=end, quote_sha256=digest(local["text"]),
            canonical_overlaps=[dict(source_id=r["segment_id"],
                raw_start=max(start, r["source_char_start"]), raw_end=min(end, r["source_char_end"]))
                for r in siblings if max(start, r["source_char_start"]) < min(end, r["source_char_end"])])

    anchors = [replay(a) for a in proof.get("origin_anchors", [])]
    if not anchors:
        raise ValueError("NO_EXACT_ORIGIN_ANCHOR")
    hidden, mask = None, None
    if case["task"] == "redaction":
        hidden = replay(proof["hidden_span"])
        marker = case["focal_marker"]
        if not marker or case["query"].count(marker) != 1:
            raise ValueError("NONUNIQUE_REDACTION_MARKER")
        unmasked = case["query"].replace(marker, hidden["text"])
        if source["text"].count(unmasked) != 1:
            raise ValueError("QUERY_MASK_NOT_EXACT_SOURCE_WINDOW")
        start = source["text"].index(unmasked)
        if start + case["query"].index(marker) != hidden["start"]:
            raise ValueError("QUERY_MASK_NOT_AT_PREDECLARED_HIDDEN_SPAN")
        mask = dict(query_sha256=digest(case["query"]), synthetic_literal_mask=True,
            raw_start=origin_offset + start, raw_end=origin_offset + start + len(unmasked),
            unmasked_text_sha256=digest(unmasked), focal_marker=marker)
    check = dict(document_id=did, classification=classification, handling=handling,
        policy_role=projected["policy_role"], whole_body_noforn=False,
        raw_body_sha256=digest(body), metadata_sha256=digest(metadata), segments_replayed=len(siblings), valid=True)
    return dict(version=VERSION, independent_current_source_reaudit=True,
        original_raw_documents={did: deepcopy(raw)}, original_metadata=deepcopy(metadata),
        document_checks=[check], canonical_ref=deepcopy(bundle["refs"]["canonical"]),
        canonical_origin_rows=deepcopy(siblings), whole_origin_document_excluded=True,
        excluded_canonical_source_ids=[r["segment_id"] for r in siblings],
        handling_veto="WHOLE_ORIGINAL_BODY_AND_METADATA_NOFORN", origin_required_classification="SECRET",
        source_file_refs=deepcopy(bundle["refs"]), exact_anchor_replay=anchors, hidden_span_replay=hidden,
        query_mask_replay=mask, source_review_is_not_gold=True, native_or_question_quality_revalidated=False)


def enrich(root, row, proof, proof_hash):
    """Adapt only a pinned registered cable proof; leave old proof bytes untouched."""
    if row["case"]["corpus"] == "cib":
        return proof, proof_hash
    root = Path(root).resolve()
    ref = source_registry_ref(root)
    registry = load(root / ref["path"])
    unsigned = {k: v for k, v in registry.items() if k != "sha256"}
    if registry.get("version") != VERSION or registry.get("sha256") != digest(unsigned):
        raise ValueError("Source admission registry self-seal changed")
    entry = registry["cases"].get(row["case"]["case_id"])
    if entry is None:
        return proof, proof_hash
    if (entry["case"] != row["case"] or entry["source_manifest_ref"] != row["source_manifest_ref"]
            or entry["source_catalog_ref"] != row["source_catalog_ref"]
            or proof_hash != entry["legacy_proof_ref"]["sha256"]
            or digest(proof) != entry["legacy_proof_item_sha256"]):
        raise ValueError("Re-audit case or legacy proof binding changed")
    for key in ("source_manifest_ref", "source_catalog_ref"):
        bound = entry[key]
        base._bound_file(root, bound["path"], bound["sha256"])
    bound = entry["legacy_proof_ref"]
    sealed = base._bound_json(root, bound["path"], bound["sha256"])
    if sealed["cases"][row["case"]["case_id"]] != proof:
        raise ValueError("Legacy source proof item changed")
    if entry["status"] != "VERIFIED":
        raise ValueError("Independent source re-audit rejected origin: " + entry["reason"])
    audit = audit_case(row["case"], proof, source_bundle(root, row["case"]["corpus"], entry["source_file_refs"]))
    if audit != entry["source_origin_audit"]:
        raise ValueError("Independent raw-source re-audit does not replay")
    adapted = deepcopy(proof)
    current = adapted.setdefault("source_origin_audit", {})
    old_raw = current.get("original_raw_documents", {})
    old_checks = [c for c in current.get("document_checks", []) if c["document_id"] != row["case"]["document_id"]]
    current.update(deepcopy(audit))
    current["original_raw_documents"] = {**old_raw, **current["original_raw_documents"]}
    current["document_checks"] = old_checks + current["document_checks"]
    adapted["source_origin_reaudit_v65"] = dict(version=VERSION, registry_ref=ref,
        legacy_proof_sha256=proof_hash, legacy_proof_item_sha256=entry["legacy_proof_item_sha256"],
        historical_label_preserved=entry["historical_source_category"],
        new_audit_not_old_producer_attestation=True, source_only=True)
    combined = digest(dict(version=VERSION, old_proof_sha256=proof_hash,
        registry_file_sha256=ref["sha256"], adapted_proof_sha256=digest(adapted)))
    return adapted, combined
