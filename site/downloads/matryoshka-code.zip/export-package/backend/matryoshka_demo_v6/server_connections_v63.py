"""Presentation transport only; browser cancellation is not a policy failure."""


class ClosedPeerMixin:
    def handle(self):
        try:
            return super().handle()
        except (BrokenPipeError, ConnectionResetError):
            return

    def json_response(self, *args, **kwargs):
        # A reading change cancels obsolete fetches. Do not attempt a second
        # error response after a client has already closed its connection.
        try:
            return super().json_response(*args, **kwargs)
        except (BrokenPipeError, ConnectionResetError):
            return
