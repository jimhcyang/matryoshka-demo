"""Independent v6 presentation seal, never an inference reseal."""
from pathlib import Path

from matryoshka_demo.graph_assets_v4 import bound
from matryoshka_demo.io import digest, load, save, sha
from .guide_runtime_v63 import FILES as GUIDE_RUNTIME_FILES, validate as validate_guide_runtime
from .guide_runtime_v64 import FILES as GUIDE_RUNTIME_V64_FILES, validate as validate_guide_runtime_v64, outputs as graph_outputs_v64


FILES = (
    "web/workbench-v6.html", "web/workbench-v6.js", "web/workbench-v6.css", "web/app-theme-v6.css",
    "web/flow-view-v6.js", "web/flow-view-v6.css", "web/flow-layout-v4.js",
    "web/graph-full-v6.html", "web/graph-full-v6.js", "web/graph-full-v6.css",
    "matryoshka_demo_v6/server.py", "matryoshka_demo_v6/flow_projection.py",
    "matryoshka_demo_v6/guide_views.py",
    "matryoshka_demo_v6/server_origin_v63.py", "matryoshka_demo_v6/server_connections_v63.py",
    "matryoshka_demo_v6/server_origin_v64.py",
    "matryoshka_demo_v6/flow_projection_v63.py",
    "matryoshka_demo_v6/flow_projection_v64.py", "web/verdict-v64.js", "web/viewport-anchor-v64.js",
) + GUIDE_RUNTIME_FILES + GUIDE_RUNTIME_V64_FILES
POINTER = "web/data/ui-release-v6.json"


def proposal(root):
    root = Path(root).resolve()
    if load(root / "web/data/report-v6.json").get("presentation_version") == "6.5":
        from .ui_release_v65 import proposal as current
        return current(root)
    validate_guide_runtime(root)
    validate_guide_runtime_v64(root)
    if any((root / "web" / name).read_bytes() != raw for name, raw in graph_outputs_v64(root).items()):
        raise ValueError("Published graph differs from the exact V6.4 presentation derivation")
    graph = bound(root)
    path = root / "web/data/report-v6.json"
    report = load(path)
    if report.get("sha256") != digest({k: v for k, v in report.items() if k != "sha256"}):
        raise ValueError("Published v6 report changed")
    value = dict(version="task-directed-workbench-presentation/6", run_id=report["run_id"],
        presentation_version="6.4", native_inference_version=report["version"],
        source_report=dict(path="web/data/report-v6.json", sha256=sha(path)),
        full_graph_binding_sha256=graph["sha256"],
        assets=[dict(path=p, sha256=sha(root / p)) for p in FILES],
        native_outputs_modified=False, inference_api_calls_from_viewer=0,
        population_status=report.get("status", "UNSPECIFIED"))
    value["sha256"] = digest(value)
    return value


def publish(root, execute=False, *, allow_partial=False):
    root = Path(root).resolve()
    value = proposal(root)
    if value["population_status"] != "COMPLETE" and not allow_partial:
        raise ValueError("Native run is incomplete; an explicit partial preview must retain pending labels")
    if execute:
        path = root / "web/data/ui-releases" / ("ui_v6_" + value["sha256"][:20] + ".json")
        if path.exists() and load(path) != value:
            raise ValueError("Immutable UI release changed")
        if not path.exists():
            save(path, value)
        save(root / POINTER, value)
    return value


def validate(root):
    root = Path(root).resolve()
    value = load(root / POINTER)
    if value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"}):
        raise ValueError("Presentation pointer changed")
    if value != proposal(root):
        raise ValueError("Presentation files changed since publication")
    return value
