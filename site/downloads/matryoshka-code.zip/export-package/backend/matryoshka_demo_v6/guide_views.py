"""Focused, read-only study contexts for a saved guide; never an overview join."""
from collections import OrderedDict
from contextlib import contextmanager
from copy import deepcopy
from datetime import date
import json
import re
from threading import RLock

from matryoshka_demo.corpus_explorer_v4 import _identity, _connect, _proof
from matryoshka_demo.corpus import locate
from matryoshka_demo.io import digest


VERSION = "case-scoped-guide-context/6"
PHASES = ("start_community", "start_connections", "relation", "target_reveal",
          "target_connections", "target_community")
_CACHE = OrderedDict()
_VETO = OrderedDict()
_LOCK = RLock()
_LEVELS = {"domain", "theme", "community"}
_READOUT_KINDS = ("SEARCH_RECEIPT_READOUT", "EXACT_QUOTATION_READOUT", "CONSTRUCTION_READOUT")


def _text(value, name):
    if not isinstance(value, str) or not value or len(value) > 600 or any(ord(c) < 32 for c in value):
        raise ValueError("Invalid " + name)
    return value


def _count(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError("Invalid guide display/pagination limit")
    return value


def _binding(case, reference, packet):
    if packet.get("case_id") != case["case_id"] or packet.get("corpus") != case["corpus"]:
        raise ValueError("Guide belongs to another case or corpus")
    if reference["binding"].get("corpus") != case["corpus"]:
        raise ValueError("Study index belongs to another corpus")
    actual = packet.get("graph_binding", {})
    for key in ("graph_id", "hierarchy_id"):
        if actual.get(key) != reference["binding"].get(key):
            raise ValueError("Saved guide and study index bindings differ")
    scope = packet.get("scope", {})
    if scope.get("strictly_before") != case["date"] or scope.get("whole_origin_excluded") != case["document_id"]:
        raise ValueError("Saved guide eligibility scope differs")
    date.fromisoformat(case["date"])
    route = packet.get("route", {})
    nodes, hops = route.get("nodes", []), route.get("hops", [])
    if not nodes or len(hops) != len(nodes)-1:
        raise ValueError("No ordered saved route")
    for node in nodes:
        _text(node.get("id"), "saved state ID")
    for i, hop in enumerate(hops):
        if hop.get("source") != nodes[i]["id"] or hop.get("target") != nodes[i+1]["id"]:
            raise ValueError("Saved route hop order differs")
        allowed = set(_READOUT_KINDS) if route.get("route_kind") == "LEXICAL_SOURCE_READOUT" else {"SOURCE", "NAVIGATION", "SOURCE_AGGREGATE"}
        if hop.get("kind") not in allowed:
            raise ValueError("Unknown saved connection kind")
    if route.get("route_kind") == "LEXICAL_SOURCE_READOUT" and (
            [h["kind"] for h in hops] != list(_READOUT_KINDS)
            or any(n.get("solver_state") is not False or n.get("readout_only") is not True for n in nodes)):
        raise ValueError("Malformed saved lexical readout")
    return nodes, hops


class _Study:
    def __init__(self, path, reference, case, veto):
        self.db = _connect(path)
        self.case, self.binding = deepcopy(case), deepcopy(reference["binding"])
        db = self.db
        db.execute("CREATE TEMP TABLE excluded(doc TEXT PRIMARY KEY)")
        excluded = set(veto)
        if case["corpus"] in {"iran", "vietnam"}:
            key = str(path), reference["sha256"]
            if key not in _VETO:
                db.create_function("has_noforn", 1, lambda text: bool(re.search(r"\bNOFORN\b", text or "", re.I)), deterministic=True)
                _VETO[key] = tuple(r[0] for r in db.execute(
                    "SELECT DISTINCT doc FROM main.page WHERE has_noforn(json_extract(payload,'$.text'))"))
                while len(_VETO) > 3:
                    _VETO.popitem(last=False)
            excluded.update(_VETO[key])
        db.executemany("INSERT INTO excluded VALUES(?)", [(d,) for d in sorted(excluded)])
        db.execute("CREATE TEMP TABLE eligible AS SELECT id,doc,date FROM main.page p WHERE date!='' "
            "AND date<? AND doc!=? AND json_extract(payload,'$.permitted')=1 "
            "AND NOT EXISTS(SELECT 1 FROM excluded x WHERE x.doc=p.doc)", (case["date"], case["document_id"]))
        db.execute("CREATE UNIQUE INDEX temp.eligible_id ON eligible(id)")
        # Match Eligible.active: an eligible edge page alone does not activate
        # an endpoint whose only semantic occurrence is in an excluded page.
        db.execute("CREATE TEMP TABLE active AS SELECT DISTINCT m.node id FROM main.mention m JOIN eligible p ON p.id=m.page")
        db.execute("CREATE UNIQUE INDEX temp.active_id ON active(id)")
        self.nodes = {}
        self.groups = {}
        self.member_cache = {}
        self.proof_cache = {}
        self.incident_cache = {}

    def meta(self):
        return dict(version=VERSION, lens="study_case", binding=self.binding,
            scope=dict(corpus=self.case["corpus"], strictly_before=self.case["date"],
                whole_origin_excluded=self.case["document_id"], independent_of_overview=True,
                retrospective_hierarchy=True),
            meaning="Case-eligible study graph, not the separately bound full corpus overview. Connections and membership are not query entailment.")

    def node(self, identity):
        if identity in self.nodes:
            return deepcopy(self.nodes[identity])
        match = re.fullmatch(r"hierarchy:(domain|theme|community):(.+)", identity)
        if match:
            result = self.group(match[1], match[2])
        else:
            row = self.db.execute("SELECT n.id,n.kind,n.hierarchy,MIN(m.label) label,COUNT(DISTINCT p.id) pages "
                "FROM main.node n JOIN main.mention m ON m.node=n.id JOIN eligible p ON p.id=m.page "
                "WHERE n.id=? GROUP BY n.id", (identity,)).fetchone()
            if row is None:
                raise ValueError("Exact saved state has no eligible study occurrence")
            h = json.loads(row["hierarchy"])
            result = dict(id=identity, type=row["kind"], label=row["label"], mass=row["pages"],
                document_count=row["pages"], **{k: h.get(k) for k in ("community_id", "theme_id", "domain_id")})
        self.nodes[identity] = result
        return deepcopy(result)

    def members(self, level, identity):
        if (level, identity) in self.member_cache:
            return deepcopy(self.member_cache[level, identity])
        field = level + "_id"
        rows = self.db.execute("SELECT n.id,n.kind,n.hierarchy,MIN(m.label) label,COUNT(DISTINCT p.id) pages "
            "FROM main.node n JOIN main.mention m ON m.node=n.id JOIN eligible p ON p.id=m.page "
            f"WHERE json_extract(n.hierarchy,'$.{field}')=? GROUP BY n.id ORDER BY pages DESC,n.id", (identity,)).fetchall()
        result = []
        for row in rows:
            h = json.loads(row["hierarchy"])
            result.append(dict(id=row["id"], label=row["label"], type=row["kind"], mass=row["pages"],
                document_count=row["pages"], **{k: h.get(k) for k in ("community_id", "theme_id", "domain_id")}))
        self.member_cache[level, identity] = result
        return deepcopy(result)

    def group(self, level, identity):
        if (level, identity) in self.groups:
            return deepcopy(self.groups[level, identity])
        members = self.members(level, identity)
        if not members:
            raise ValueError("Exact navigation group has no eligible members")
        parents = {m.get({"community": "theme_id", "theme": "domain_id", "domain": "domain_id"}[level]) for m in members}
        if len(parents) > 1:
            raise ValueError("Conflicting actual study membership")
        result = dict(id="hierarchy:"+level+":"+identity, group_id=identity, type=level.capitalize(),
            label=level.capitalize()+": "+" / ".join(m["label"] for m in members[:2]),
            mass=len(members), member_count=len(members), parent_id=next(iter(parents)),
            domain_id=identity if level == "domain" else members[0].get("domain_id"),
            theme_id=identity if level == "theme" else members[0].get("theme_id") if level == "community" else None,
            community_id=identity if level == "community" else None,
            membership_kind="NAVIGATION", historical_relation_certified=False)
        self.groups[level, identity] = result
        return deepcopy(result)

    def mother(self, node):
        kind = node["type"].lower()
        if kind in _LEVELS:
            return node
        return self.group("community", node["community_id"]) if node.get("community_id") else None

    def proof(self, row):
        key = row["page"], row["unit"]
        if key in self.proof_cache:
            return deepcopy(self.proof_cache[key])
        if not self.db.execute("SELECT 1 FROM eligible WHERE id=?", (row["page"],)).fetchone():
            raise ValueError("Ineligible source unit")
        proof = _proof(self.db, row, self.case["corpus"])
        proof.pop("source_url", None)
        self.proof_cache[key] = proof
        return proof

    def source(self, identity):
        row = self.db.execute("SELECT p.payload,e.doc,e.date FROM main.page p JOIN eligible e ON e.id=p.id WHERE p.id=?", (identity,)).fetchone()
        if row is None:
            raise ValueError("Source page is outside the guide case scope")
        page = json.loads(row[0])
        if (page["id"] != identity or page["document_id"] != row["doc"] or page["date"] != row["date"]
                or page.get("corpus") != self.case["corpus"] or page["source_sha256"] != digest(page["text"])):
            raise ValueError("Study source digest changed")
        return page

    def edge(self, row):
        return dict(id="study-source-"+str(row["row_id"]), source=row["a"], target=row["b"],
            source_label=self.node(row["a"])["label"], target_label=self.node(row["b"])["label"],
            kind="SOURCE", edge_type=row["relation"], relation=row["relation"], weight=1,
            label=row["relation"], citations=[self.proof(row)], historical_relation_certified=False)

    def incident(self, node):
        if node["id"] in self.incident_cache:
            return deepcopy(self.incident_cache[node["id"]])
        kind = node["type"].lower()
        if kind in _LEVELS:
            members = self.members(kind, node["group_id"])
            if kind == "community":
                neighbors = members
            else:
                child = "community" if kind == "theme" else "theme"
                ids = sorted({m.get(child+"_id") for m in members if m.get(child+"_id")})
                neighbors = [self.group(child, i) for i in ids]
            if kind != "domain" and node.get("parent_id"):
                neighbors.append(self.group("theme" if kind == "community" else "domain", node["parent_id"]))
            edges = [dict(id="membership:"+node["id"]+":"+n["id"], source=node["id"], target=n["id"],
                kind="NAVIGATION", edge_type="Recorded membership", weight=1,
                historical_relation_certified=False, citations=[]) for n in neighbors]
        else:
            rows = self.db.execute("SELECT e.rowid row_id,e.* FROM main.edge e JOIN eligible p ON p.id=e.page "
                "JOIN active a ON a.id=e.a JOIN active b ON b.id=e.b "
                "WHERE e.a=? OR e.b=? ORDER BY p.date DESC,e.rowid", (node["id"], node["id"])).fetchall()
            edges = [self.edge(r) for r in rows]
            ids = list(dict.fromkeys(e["target"] if e["source"] == node["id"] else e["source"] for e in edges))
            neighbors = [self.node(i) for i in ids]
            mother = self.mother(node)
            if mother:
                neighbors.append(mother)
                edges.append(dict(id="membership:"+node["id"]+":"+mother["id"], source=node["id"], target=mother["id"],
                    kind="NAVIGATION", edge_type="Recorded membership", weight=1,
                    historical_relation_certified=False, citations=[]))
        self.incident_cache[node["id"]] = neighbors, edges
        return deepcopy((neighbors, edges))

    def relation(self, a, b, hop):
        if hop["kind"] == "SOURCE":
            rows = self.db.execute("SELECT e.rowid row_id,e.* FROM main.edge e JOIN eligible p ON p.id=e.page "
                "JOIN active a ON a.id=e.a JOIN active b ON b.id=e.b "
                "WHERE (e.a=? AND e.b=?) OR (e.a=? AND e.b=?) ORDER BY p.date DESC,e.rowid",
                (a["id"], b["id"], b["id"], a["id"])).fetchall()
            return [self.edge(r) for r in rows]
        if hop["kind"] == "NAVIGATION":
            ak, bk = a["type"].lower(), b["type"].lower()
            linked = ((ak not in _LEVELS and bk == "community" and a.get("community_id") == b.get("group_id"))
                or (bk not in _LEVELS and ak == "community" and b.get("community_id") == a.get("group_id"))
                or (ak == "community" and bk == "theme" and a.get("parent_id") == b.get("group_id"))
                or (bk == "community" and ak == "theme" and b.get("parent_id") == a.get("group_id"))
                or (ak == "theme" and bk == "domain" and a.get("parent_id") == b.get("group_id"))
                or (bk == "theme" and ak == "domain" and b.get("parent_id") == a.get("group_id")))
            return [dict(id="membership:"+a["id"]+":"+b["id"], source=a["id"], target=b["id"],
                kind="NAVIGATION", edge_type="Recorded membership", weight=1, citations=[],
                historical_relation_certified=False)] if linked else []
        kind = a["type"].lower()
        if kind not in _LEVELS or b["type"].lower() != kind:
            return []
        field = kind+"_id"
        rows = self.db.execute("SELECT e.rowid row_id,e.* FROM main.edge e JOIN eligible p ON p.id=e.page "
            "JOIN active aa ON aa.id=e.a JOIN active bb ON bb.id=e.b "
            "JOIN main.node a ON a.id=e.a JOIN main.node b ON b.id=e.b "
            f"WHERE (json_extract(a.hierarchy,'$.{field}')=? AND json_extract(b.hierarchy,'$.{field}')=?) "
            f"OR (json_extract(a.hierarchy,'$.{field}')=? AND json_extract(b.hierarchy,'$.{field}')=?)",
            (a["group_id"], b["group_id"], b["group_id"], a["group_id"])).fetchall()
        return [dict(id="study-aggregate:"+a["id"]+":"+b["id"], source=a["id"], target=b["id"],
            kind="SOURCE_AGGREGATE", edge_type="Eligible source aggregate, not a group fact", weight=len(rows),
            citations=[self.proof(r) for r in rows[:3]], source_edge_count=len(rows), historical_relation_certified=False)] if rows else []


@contextmanager
def _study(root, reference, case, excluded_documents):
    path, checksum = _identity(root, reference)
    key = str(path), checksum, case["case_id"], case["date"], case["document_id"], tuple(sorted(excluded_documents))
    with _LOCK:
        if key not in _CACHE:
            while len(_CACHE) >= 2:
                _, old = _CACHE.popitem(last=False)
                old.db.close()
            _CACHE[key] = _Study(path, reference, case, excluded_documents)
        _CACHE.move_to_end(key)
        yield _CACHE[key]


def clear_cache():
    with _LOCK:
        while _CACHE:
            _, item = _CACHE.popitem()
            item.db.close()
        _VETO.clear()


def context(root, reference, case, packet, *, hop_index=0, phase="start_community", limit=256,
            offset=0, page_size=24, excluded_documents=()):
    nodes, hops = _binding(case, reference, packet)
    if packet["route"].get("route_kind") == "LEXICAL_SOURCE_READOUT":
        raise ValueError("This is a saved lexical source readout, not a graph state with a mother Community")
    if phase not in PHASES:
        raise ValueError("Unknown guide phase")
    _count(hop_index, 0, max(0, len(hops)-1))
    _count(limit, 2, 2048)
    _count(offset, 0, 10000000)
    _count(page_size, 1, 100)
    if not hops and phase not in PHASES[:2]:
        raise ValueError("No saved hop exists for that phase")
    with _study(root, reference, case, excluded_documents) as study:
        a = study.node(nodes[hop_index]["id"])
        b = study.node(nodes[hop_index+1]["id"]) if hops else a
        hop = hops[hop_index] if hops else None
        relations = study.relation(a, b, hop) if hop else []
        if hop and not relations:
            raise ValueError("The exact saved connection has no eligible study source or recorded membership; no substitute was used")
        focus = b if phase.startswith("target_") and phase != "target_reveal" else a
        mother = study.mother(focus)
        community_view = phase in {"start_community", "target_community"}
        outside = []
        if community_view:
            available = study.members(mother["type"].lower(), mother["group_id"]) if mother else [focus]
            pins = [focus]
            if phase == "target_community" and a["id"] != b["id"]:
                pins.append(a)
                if a["id"] not in {n["id"] for n in available} and (not mother or a["id"] != mother["id"]):
                    outside.append(a["id"])
            complete_nodes = {n["id"]: n for n in pins + ([mother] if mother else []) + available}
            graph_nodes = list(complete_nodes.values())[:limit]
            graph_edges = relations if phase == "target_community" else []
            incident_nodes, incident_edges = study.incident(focus)
        else:
            incident_nodes, incident_edges = study.incident(focus)
            pins = [focus, b if focus["id"] == a["id"] else a]
            graph_nodes = list({n["id"]: n for n in pins + incident_nodes}.values())[:limit]
            shown = {n["id"] for n in graph_nodes}
            graph_edges = [e for e in incident_edges if e["source"] in shown and e["target"] in shown]
            for relation in relations:
                if relation["source"] in shown and relation["target"] in shown and relation["id"] not in {e["id"] for e in graph_edges}:
                    graph_edges.append(relation)
            available = [focus] + incident_nodes
            complete_nodes = {n["id"]: n for n in pins + available}
        highlighted = [a["id"]] if phase in {"start_community", "start_connections"} else list(dict.fromkeys([a["id"], b["id"]]))
        return dict(**study.meta(), phase=phase, hop_index=hop_index, focus_id=focus["id"],
            layout_key=("community:"+(mother["id"] if mother else focus["id"])) if community_view else "incident:"+focus["id"],
            view_kind="community" if community_view else "incident", community=mother,
            nodes=graph_nodes, edges=graph_edges, outside_membership_ids=outside,
            highlighted_node_ids=highlighted, highlighted_edge_ids=[e["id"] for e in relations] if phase not in PHASES[:2] else [],
            saved_hop=deepcopy(hop), relation_edges=relations,
            incident=dict(node=focus, neighbors=incident_nodes[offset:offset+page_size],
                edges=incident_edges[offset:offset+page_size], total_nodes=len(incident_nodes), total_edges=len(incident_edges),
                offset=offset, limit=page_size, next_offset=offset+page_size if offset+page_size < len(incident_edges) else None),
            available_nodes=len(complete_nodes), displayed_nodes=len(graph_nodes),
            member_count=len(available) if community_view else None,
            drawing_limit=limit, membership_is_factual=False,
            breadcrumbs=[study.group(level, focus[level+"_id"]) for level in ("domain", "theme", "community") if focus.get(level+"_id")])


def request(root, reference, case, packet, params, *, excluded_documents=()):
    def arg(key, default=None):
        value = params.get(key, default)
        return value[0] if isinstance(value, list) and value else value
    _binding(case, reference, packet)
    phase = arg("phase", "start_community")
    if phase in {"source", "inspect"}:
        with _study(root, reference, case, excluded_documents) as study:
            if phase == "source":
                return dict(**study.meta(), page=study.source(_text(arg("source_id"), "source ID")))
            node = study.node(_text(arg("node_id"), "node ID"))
            _, edges = study.incident(node)
            proofs = [p for e in edges[:3] for p in e.get("citations", [])]
            if not proofs and node["type"].lower() not in _LEVELS:
                row = study.db.execute("SELECT p.id,m.label FROM main.mention m JOIN eligible p ON p.id=m.page WHERE m.node=? ORDER BY p.date DESC LIMIT 1", (node["id"],)).fetchone()
                if row is None:
                    raise ValueError("No eligible source mention exists for this study state")
                page = study.source(row["id"])
                interval = locate(page["text"], row["label"]) or (0, len(page["text"]))
                proofs = [dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
                    start=interval[0], end=interval[1], text=page["text"][slice(*interval)], page_sha256=page["source_sha256"],
                    meaning="Source page with an eligible recorded mention; not query entailment")]
            return dict(**study.meta(), node=node, citations=proofs)
    return context(root, reference, case, packet, phase=phase,
        hop_index=int(arg("hop_index", 0)), limit=int(arg("limit", 256)),
        offset=int(arg("offset", 0)), page_size=int(arg("page_size", 24)), excluded_documents=excluded_documents)
