"""Proposed request-only raw observer, not a change to frozen native inference.

Only an explicit positive past request with one object-controlled infinitive is
certified. The infinitive is request content, never evidence of its completion.
This helper does not modify any decision packet, rank, source, plan or verdict.
"""
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_demo_v61 import scope_matching as scoped
from matryoshka_demo_v6 import planning as literal
from . import reporting_local_decisions_v65 as policy

VERSION = "raw-request-nonfactive-complement-observer/1"
KIND = "REQUEST_WITH_NONFACTIVE_COMPLEMENT"
PARENTS = {"ask", "request"}


def _normal(text):
    return " ".join(text.casefold().split())


def _span(token):
    return token.left_edge.idx, token.right_edge.idx + len(token.right_edge)


def _proof(text, span):
    lo, hi = span
    return dict(start=lo, end=hi, text=text[lo:hi])


def _plain_scope(frame, negative=False):
    qualifiers = frame["qualifiers"]
    if bool(qualifiers["negated"]) != negative:
        return False
    return not any(bool(value) for key, value in qualifiers.items()
        if key not in {"negated", "negation_proofs"}) and not (
        frame.get("event_dates") or frame.get("deictic_time"))


def _goal_tokens(goal):
    # Telegrams can omit an indefinite article before a singular object. Keep
    # definiteness, quantifiers, polarity, every modifier and all goal content.
    return [(t.lemma_.casefold() if t.pos_ == "VERB" else t.text.casefold())
        for t in goal.subtree if not t.is_space and not t.is_punct
        and not (t.dep_ == "det" and t.lower_ in {"a", "an"})]


def _request(text, token, engine, frames, *, negative=False):
    past = token.tag_ == "VBD" or (negative and token.tag_ == "VB"
        and any(c.dep_ == "aux" and c.lower_ == "did" for c in token.children))
    if (token.lemma_.casefold() not in PARENTS or token.pos_ != "VERB"
            or not past or token.dep_ != "ROOT"):
        return None
    sentence = token.sent
    if re.search(r"[\[\]\"\u201c\u201d?]", sentence.text):
        return None
    subjects = [t for t in token.children if t.dep_ == "nsubj"]
    recipients = [t for t in token.children if t.dep_ in {"dobj", "obj"}]
    goals = [t for t in token.children if t.dep_ == "xcomp" and t.pos_ == "VERB"
        and any(c.dep_ in {"aux", "mark"} and c.lower_ == "to" for c in t.children)]
    if len(subjects) != 1 or len(recipients) != 1 or len(goals) != 1:
        return None
    subject, recipient, goal = subjects[0], recipients[0], goals[0]
    if (not any(t.pos_ == "PROPN" for t in subject.subtree)
            or any(t.pos_ == "PRON" or t.dep_ == "conj" for t in [*subject.subtree, *recipient.subtree])
            or any(t.pos_ in {"VERB", "AUX"} for t in [*subject.subtree, *recipient.subtree])):
        return None
    if (any(t != goal and t.pos_ == "VERB" for t in goal.subtree)
            or any(t.dep_ in {"nsubj", "nsubjpass", "conj", "ccomp"} for t in goal.subtree)):
        return None
    parent_frames = [f for f in frames if f["predicate_proof"]["start"] == token.idx and f["kind"] == "EVENT"]
    goal_frames = [f for f in frames if f["predicate_proof"]["start"] == goal.idx and f["kind"] == "EVENT"]
    if len(parent_frames) != 1 or len(goal_frames) != 1 or not _plain_scope(parent_frames[0], negative):
        return None
    parent, child = parent_frames[0], goal_frames[0]
    qualifiers = child["qualifiers"]
    if any(qualifiers.get(k) for k in ("modality", "conditional", "question", "epistemic_absence", "unresolved", "attribution")):
        return None
    scopes = qualifiers["scope"]
    if (len(scopes) != 1 or scopes[0]["relation"] != "xcomp"
            or scopes[0]["predicate"] != token.lemma_.casefold()
            or bool(scopes[0].get("negated")) != negative or scopes[0].get("modality")):
        return None
    if any(x["start"] != goal.idx for x in parent["unbound_arguments"]):
        return None
    consumed = {t.i for t in [*subject.subtree, *recipient.subtree, *goal.subtree, token]}
    if negative:
        consumed.update(t.i for t in token.children if t.dep_ == "neg"
            or (t.dep_ == "aux" and t.lower_ == "did") or t.lower_ == "never")
    if any(t.i not in consumed and not t.is_space and not t.is_punct for t in sentence):
        return None
    # A same-sentence request is not licensed inside a preceding open quote or
    # reporting colon. Do not discard unconsumed source context to get a match.
    paragraph_start = max(text.rfind("\n\n", 0, sentence.start_char) + 2, 0)
    prefix = text[paragraph_start:sentence.start_char].rstrip()
    if prefix and (prefix.endswith(":") or sum(prefix.count(c) for c in ('"', '\u201c', '\u201d')) % 2):
        return None
    return dict(kind=KIND, sentence=_proof(text, (sentence.start_char, sentence.end_char)),
        parent=_proof(text, (token.idx, token.idx + len(token))),
        requester=_proof(text, _span(subject)), recipient=_proof(text, _span(recipient)),
        requester_head=subject.text.casefold(), goal=_proof(text, _span(goal)), goal_tokens=_goal_tokens(goal),
        parent_frame=deepcopy(parent), goal_frame=deepcopy(child),
        negated_request=negative,
        requested_actor=_proof(text, _span(recipient)),
        actual_goal_event_established=False, request_event_only=True,
        incomplete_or_nested_request_not_certified=True)


def query_spec(case, plan, atom_id, *, engine):
    """Bind all atom bytes to the whole public query before projecting a parent."""
    if case["task"] not in {"hypothesis", "reconstruction"} or case.get("focal_marker"):
        return None
    if plan.get("query_sha256") != digest(case["query"]):
        return None
    atoms = plan.get("atoms", [])
    if len({a["id"] for a in atoms}) != len(atoms):
        return None
    found = [a for a in atoms if a["id"] == atom_id]
    if len(found) != 1:
        return None
    prior = 0
    for atom in sorted(atoms, key=lambda a:a["start"]):
        lo, hi = atom["start"], atom["end"]
        if (type(lo) is not int or type(hi) is not int or not prior <= lo < hi <= len(case["query"])
                or case["query"][prior:lo].strip() or atom.get("required") is not True
                or atom["text"] != case["query"][lo:hi] or atom["source_quote"] != atom["text"]):
            return None
        prior = hi
    if case["query"][prior:].strip():
        return None
    atom = found[0]
    doc = engine.parse(atom["text"])
    sentences = [s for s in doc.sents if s.text.strip()]
    if len(sentences) != 1:
        return None
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1:
        return None
    request = _request(atom["text"], roots[0], engine, engine.frames(atom["text"]))
    if request is None:
        return None
    return dict(atom=deepcopy(atom), request=request, query_sha256=digest(case["query"]))


def _requester_binding(wanted, offered, raw, doc):
    if _normal(wanted["requester"]["text"]) == _normal(offered["requester"]["text"]):
        return dict(kind="EXACT_LITERAL_REQUESTER", name_invented=False)
    # Only an explicit complete repeated name in this same paragraph licenses a
    # shorter repeated NP. No surname dictionary, suffix alias or global node.
    start = offered["requester"]["start"]
    boundary = raw.rfind("\n\n", 0, start)
    boundary = 0 if boundary < 0 else boundary + 2
    head = offered["requester_head"]
    chunks = [c for c in doc.noun_chunks if boundary <= c.start_char < start
        and c.root.text.casefold() == head]
    expanded = [c for c in chunks if _normal(c.text) != _normal(offered["requester"]["text"])]
    if len(expanded) != 1 or _normal(expanded[0].text) != _normal(wanted["requester"]["text"]):
        return None
    if re.search(r"[\[\]\"\u201c\u201d]", raw[expanded[0].start_char:start]):
        return None
    return dict(kind="UNIQUE_LITERAL_COMPLETE_NAME_RESTATED_IN_SAME_PARAGRAPH",
        full_name=_proof(raw, (expanded[0].start_char, expanded[0].end_char)),
        repeated_short_name=deepcopy(offered["requester"]), global_aliases_read=False,
        surname_suffix_match=False, title_or_role_current_tenure_inferred=False)


def _source_requests(raw, engine):
    """Reparse complete literal sentences, not a convenient extracted clause.

    The full-body statistical parse can attach a sentence before a printed
    period to a verb in the next sentence. Frozen literal boundary guards keep
    abbreviations and open reporting context intact during this narrow replay.
    """
    previous = None
    for unit in literal.sentences(raw):
        prefix = raw[:unit["start"]]
        if literal._open_reporting_context(prefix):
            previous = unit
            continue
        if previous is not None:
            prior = previous["text"]
            if (scoped.native._reporting_block(prior, engine.parse)
                    or any(scoped.matching.lemma(t) in scoped.matching.parent._REPORTING for t in engine.parse(prior))
                    or re.search(r"\b(?:if|unless|suppose|assuming)\b", prior, re.I)):
                previous = unit
                continue
        text = unit["text"]
        doc, frames = engine.parse(text), engine.frames(text, antecedents=True)
        for token in doc:
            request = _request(text, token, engine, frames) or _request(text, token, engine, frames, negative=True)
            if request is None:
                continue
            for key in ("sentence", "parent", "requester", "recipient", "goal", "requested_actor"):
                request[key]["start"] += unit["start"]
                request[key]["end"] += unit["start"]
            request["literal_boundary_replay"] = dict(start=unit["start"], end=unit["end"],
                complete_printed_sentence=True, abbreviation_guard=True, open_reporting_context_rejected=True,
                source_text_modified=False)
            yield request
        previous = unit


def observe(case, plan, atom_id, admitted, index, *, engine):
    """Return additive request certificates over exactly the saved inspected pool.

The caller must pass the complete bound index (including policy-veto siblings),
not a filtered list of convenient witnesses. Source provenance is replayed first.
"""
    spec = query_spec(case, plan, atom_id, engine=engine)
    result = dict(version=VERSION, atom_id=atom_id, status="UNRESOLVED", certificates=[], signed_conflict_citations=[],
        absence_is_counterevidence=False, native_or_gate_verdict_rewritten=False,
        keys_read=False, grades_read=False, model_calls=0, actual_goal_event_established=False)
    if spec is None:
        result["reason"] = "Outside whole-atom positive finite request scope"
        return result
    pages, masks, veto = index
    for page in admitted.values():
        policy._quote(policy._citation(page, 0, len(page["text"])), pages, masks, veto, case)
        raw, certificates = page["text"], []
        doc = engine.parse(raw)
        for offered in _source_requests(raw, engine):
            wanted = spec["request"]
            if (_normal(wanted["recipient"]["text"]) != _normal(offered["recipient"]["text"])
                    or wanted["goal_tokens"] != offered["goal_tokens"]):
                continue
            binding = _requester_binding(wanted, offered, raw, doc)
            if binding is None:
                continue
            if offered["negated_request"]:
                span = offered["sentence"]
                result["signed_conflict_citations"].append(policy._citation(page, span["start"], span["end"]))
                continue
            certificate = dict(version=VERSION, kind=KIND, atom_id=atom_id,
                query_sha256=spec["query_sha256"], atom_binding=deepcopy(spec["atom"]),
                requester_binding=binding, requested_actor_is_addressee=True,
                request_event_only=True, actual_goal_event_established=False,
                goal_polarity_preserved=True, whole_nonfactive_goal_tokens=offered["goal_tokens"],
                query_parent_predicate=wanted["parent_frame"]["predicate"],
                source_parent_predicate=offered["parent_frame"]["predicate"],
                narrow_request_verb_class=sorted(PARENTS), checked_parent_scope=offered["parent_frame"]["qualifiers"],
                literal_boundary_replay=offered["literal_boundary_replay"],
                source_assertion_not_world_truth=True, new_retrieval=False)
            for name in ("sentence", "parent", "requester", "recipient", "goal"):
                span = offered[name]
                certificate["citation" if name == "sentence" else name] = policy._citation(page, span["start"], span["end"])
            if binding.get("full_name"):
                span = binding["full_name"]
                certificate["requester_identity_citation"] = policy._citation(page, span["start"], span["end"])
            certificate["sha256"] = digest(certificate)
            certificates.append(certificate)
        # Two conflicting or duplicated raw requests in one page are not
        # collapsed into a unique event certificate.
        if len(certificates) == 1:
            result["certificates"].extend(certificates)
    if result["signed_conflict_citations"]:
        result["withheld_positive_certificates"] = result["certificates"]
        result["certificates"] = []
        result["reason"] = "Explicit same-content denial prevents positive request certification; no counter verdict is assigned."
    elif result["certificates"]:
        result["status"] = "REQUEST_ONLY"
    return result
