"""Immutable source-only local decisions; no native edits, keys, grading or API.

prepare/build require an explicit report ref, case IDs and arms. Preview does
not evaluate gates or create artifacts. load_for returns the unchanged gate
packet for record['local_decisions_v65']; it never evaluates the gate. Lead
owns any pointer/UI seal. No experiments namespace or existing UI cache is used.
"""
from collections import OrderedDict
from concurrent.futures import ProcessPoolExecutor, as_completed
from copy import deepcopy
import builtins
import fcntl
import gzip
from hashlib import sha256
import importlib.util
import json
import multiprocessing
import os
from pathlib import Path
import re
import tempfile
from threading import RLock
from types import SimpleNamespace

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest, disk_guard, offline
from matryoshka_demo_v61 import study


VERSION = "source-only-local-decision-release/6.5"
FIELD = "local_decisions_v65"
OUTPUT_ROOT = "experiments/ui_v65/decision_releases"
ARMS = {"A": "llm_readings", "B": "llm_atoms", "C": "llm_local"}
MAX_CONDITIONS = 200
# Hold two bounded build batches so a full manifest scan does not evict itself.
OUTPUT_CACHE_LIMIT = 2 * MAX_CONDITIONS
# Stable roles for callers; code_files(root) adds the complete sibling file set.
CODE_FILES = ("matryoshka_demo_v6/reporting_local_decisions_v65.py",
    "matryoshka_demo_v6/reporting_fixed_pool_decisions_v65.py",
    "matryoshka_demo_v6/reporting_decision_release_v65.py")
BUILDER = "scripts/build_local_decision_release_v65.py"
FILES = (*CODE_FILES, BUILDER)
PROCESS_ENVIRONMENT = {"PYTHONHASHSEED": "0", "OPENBLAS_NUM_THREADS": "1",
    "OMP_NUM_THREADS": "1", "VECLIB_MAXIMUM_THREADS": "1", "MKL_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1", "BLIS_NUM_THREADS": "1"}
REVIEW_ONLY = frozenset({"assessment", "analyst_digest", "post_unmask_comparison", "reference_answer",
    "reference_answer_kind", "ground_truth", "correct_answer", "evaluation_keys", "evaluation_keys_ref",
    "answer_key_ref", "assessment_release_ref", "assessment_ref", "llm_assessment", "llm_review",
    "local_decision_assessment_v65", "local_decisions_v65", "local_sufficiency_v65", "presentation_criterion"})
_SELF_SHA = sha256(Path(__file__).read_bytes()).hexdigest()
_HASHES, _GATES, _OUTPUTS = OrderedDict(), OrderedDict(), OrderedDict()
_LOCK = RLock()


def require(value, message):
    if not value:
        raise ValueError(message)


def sanitize(value):
    if isinstance(value, dict):
        return {k: sanitize(v) for k, v in value.items() if k not in REVIEW_ONLY}
    if isinstance(value, (list, tuple)):
        return [sanitize(v) for v in value]
    return value


def _hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _path(root, relative, under=None):
    root = Path(root).resolve(); rel = Path(relative)
    require(not rel.is_absolute() and ".." not in rel.parts and rel.parts
        and "private" not in rel.parts and not any("evaluation_keys" in p for p in rel.parts), "Unbound/private release path")
    path = root/rel
    require(path.resolve() == path and path.is_relative_to(root/(under or "")), "Release path escaped or used a symlink")
    return path


def _stamp(path):
    stat = path.stat()
    return (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)


def _checksum(path):
    before = _stamp(path); key = (str(path), *before)
    with _LOCK:
        value = _HASHES.get(key)
    if value is None:
        with path.open("rb") as stream:
            value = __import__("hashlib").file_digest(stream, "sha256").hexdigest()
        require(_stamp(path) == before, "Input changed while hashing")
        with _LOCK:
            _HASHES[key] = value
            while len(_HASHES) > 2048: _HASHES.popitem(last=False)
    return value


def _ref(root, path):
    path = _path(root, str(Path(path).relative_to(root)))
    return dict(path=str(path.relative_to(root)), sha256=_checksum(path))


def _bound(root, reference, under=None):
    require(isinstance(reference, dict) and _hash(reference.get("sha256")), "An explicit input SHA is required")
    path = _path(root, reference["path"], under)
    require(_checksum(path) == reference["sha256"], "Pinned release input changed: "+reference["path"])
    return path


def _read(root, reference, under=None):
    path = _bound(root, reference, under); content = path.read_bytes()
    require(sha256(content).hexdigest() == reference["sha256"], "Input changed while reading")
    value = json.loads(gzip.decompress(content) if path.suffix == ".gz" else content)
    if path.suffix == ".gz":
        require(set(value) == {"payload", "sha256"} and digest(value["payload"]) == value["sha256"], "Compressed input seal changed")
        value = value["payload"]
    return value


def _sealed(value):
    return dict(value, sha256=digest(value))


def _check_seal(value):
    require(value.get("sha256") == digest({k: v for k, v in value.items() if k != "sha256"}), "Release JSON self-seal changed")


def _bytes(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)+"\n").encode()


def _write(path, value, *, immutable=False, content=None):
    raw = _bytes(value) if content is None else content
    require(path.resolve() == path, "Output path is symlinked")
    if immutable and path.exists():
        require(path.read_bytes() == raw, "Immutable release output changed")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix=".decision-release-")
    temp = Path(name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        if immutable:
            temp.chmod(0o444); os.link(temp, path)
        else:
            os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def code_files(root):
    """Snapshot every fixed-pool sibling, including currently unused modules."""
    root = Path(root).resolve()
    siblings = {str(path.relative_to(root)) for path in
        _path(root, "matryoshka_demo_v6").glob("reporting_fixed_pool*.py")}
    return tuple(sorted(set(CODE_FILES) | siblings))


def _code(root):
    names = (*code_files(root), BUILDER)
    code = {name: _checksum(_path(root, name)) for name in names}
    require(names == (*code_files(root), BUILDER), "Gate dependency file set changed while hashing")
    require(code[CODE_FILES[2]] == _SELF_SHA, "Release helper changed; restart with its new source")
    return code


def _module(path, content, importer=None):
    spec = importlib.util.spec_from_file_location("matryoshka_demo_v6._release_"+sha256(content).hexdigest(), path)
    require(spec is not None, "No gate source loader")
    module = importlib.util.module_from_spec(spec)
    module.__dict__["__builtins__"] = dict(vars(builtins), **({"__import__": importer} if importer else {}))
    exec(compile(content, str(path), "exec"), module.__dict__)
    return module


def _gate(root, code):
    root = Path(root).resolve()
    require(_code(root) == code, "Gate dependency bytes/file set changed before loading")
    key = (str(root), tuple(sorted(code.items())))
    with _LOCK:
        if key in _GATES: return _GATES[key]
    names = [name for name in code if name == CODE_FILES[0] or Path(name).name.startswith("reporting_fixed_pool")]
    raw = {name: _bound(root, dict(path=name, sha256=code[name])).read_bytes() for name in names}
    require(all(sha256(raw[n]).hexdigest() == code[n] for n in raw), "Gate changed while loading")
    sources = {Path(name).stem: name for name in raw}
    modules, loading = {}, set()
    package = "matryoshka_demo_v6"
    parent_name = Path(CODE_FILES[0]).stem
    def owned(name):
        return name == parent_name or name.startswith("reporting_fixed_pool")
    def module(name):
        require(name in sources, "Unpinned fixed-pool dependency: "+name)
        require(name not in loading, "Circular fixed-pool dependency: "+name)
        if name not in modules:
            loading.add(name)
            try:
                source = sources[name]
                modules[name] = _module(root/source, raw[source], importer)
            finally:
                loading.remove(name)
        return modules[name]
    def importer(name, globals=None, locals=None, fromlist=(), level=0):
        # Resolve owned imports from these exact bytes, never a canonical module
        # object or timestamp-based pyc left by the server/assessment process.
        qualified = package+("."+name if name else "") if level == 1 else name
        if qualified == package and fromlist and any(owned(n) for n in fromlist):
            proxy = SimpleNamespace()
            for item in fromlist:
                value = module(item) if owned(item) else getattr(
                    builtins.__import__(package, globals, locals, (item,), 0), item)
                setattr(proxy, item, value)
            return proxy
        short = qualified.removeprefix(package+".")
        if level in {0, 1} and owned(short):
            value = module(short)
            return value if fromlist or qualified == short else SimpleNamespace(**{short: value})
        return builtins.__import__(name, globals, locals, fromlist, level)
    gate = module(Path(CODE_FILES[1]).stem)
    require(gate.VERSION.startswith("local-evidence-sufficiency/6.5."), "Not the current fixed-pool gate")
    require(_code(root) == code, "Gate dependency bytes/file set changed while loading")
    with _LOCK:
        _GATES[key] = gate
        while len(_GATES) > 3: _GATES.popitem(last=False)
    return gate


def _report(root, reference):
    value = _read(root, reference); _check_seal(value)
    require(value.get("status") == "COMPLETE" and isinstance(value.get("run_id"), str), "Use a completed pinned report")
    ids = [r["case"]["case_id"] for r in value["cases"]]
    require(len(ids) == len(set(ids)), "Duplicate report case identities")
    return value


def _source_pins(root, report, corpora):
    reference = _ref(root, root/"data/bindings.json")
    binding = _read(root, reference); _check_seal(binding)
    require(binding == report["source_binding"], "Current source binding differs from report")
    pins = [dict(base="root", **reference)]
    for corpus in sorted(corpora):
        for ref in binding["corpora"][corpus]["files"].values():
            _bound(root.parent, ref)
            pins.append(dict(base="workspace", path=ref["path"], sha256=ref["sha256"]))
    return sorted({digest(p): p for p in pins}.values(), key=lambda p: (p["base"], p["path"]))


def _presentation_result(root, native, displayed, report):
    """Replay only the frozen reporter's compression; never discard differences.

    Twelve here is the OLD report's evidence preview, not a new gate/search
    budget. The gate still receives the exact pinned presentation record.
    """
    if native == displayed:
        return native, []
    value = deepcopy(native)
    for atom in value.get("atoms", []):
        rows = atom.get("evidence", [])
        if len(rows) > 12:
            buckets = {}
            for row in rows: buckets.setdefault(row.get("status", row.get("direction", "UNSPECIFIED")), []).append(row)
            chosen = []
            for depth in range(len(rows)):
                for key in sorted(buckets):
                    if depth < len(buckets[key]): chosen.append(buckets[key][depth])
                if len(chosen) >= 12: break
            atom["evidence"] = chosen[:12]; atom["presentation_omitted_evidence"] = len(rows)-len(atom["evidence"])
    if "matching_diagnostics" in value:
        value["matching_diagnostics"] = dict(presentation="Original-engine tables remain in the pinned native checkpoint")
    value["presentation_projection"] = dict(version=report["version"], full_native_retained=True,
        evidence_selection="Round-robin over native evidence directions, up to 12 per atom", omitted_lists={})
    pins = []
    if "expanded" in value.get("flow", {}):
        expanded = value["flow"].pop("expanded")
        ref = displayed.get("flow", {}).get("expanded_ref")
        require(ref is not None and _read(root, ref, "web/data/flows-v6") == expanded, "Lazy flow differs from exact native expanded data")
        wire = json.dumps(expanded, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()
        require(ref.get("response_sha256") == sha256(wire).hexdigest(), "Lazy flow response commitment differs")
        value["flow"].update(expanded_ref=deepcopy(ref), expanded_lazy=True); pins.append(ref)
    require(value == displayed, "Published result is not the exact frozen native presentation projection")
    return value, pins


def _condition(root, report, case_id, config, native_code, supplied=None):
    rows = [r for r in report["cases"] if r["case"]["case_id"] == case_id]
    require(len(rows) == 1 and rows[0].get("status") != "PENDING", "Unknown or unexecuted release condition")
    row = rows[0]; case = public_case(row["case"])
    detail = _read(root, row["case_detail_ref"], "web/data/report-v6-cases")
    require(detail["case"] == case and config in detail["configurations"], "Native detail case/arm differs")
    record = sanitize(detail["configurations"][config])
    if supplied is not None:
        require(sanitize(supplied) == record, "Supplied native condition differs from pinned sanitized input")
    checkpoint = record["native_checkpoint"]
    target = _bound(root, checkpoint, "data/runs_v6"); directory = target.parents[1]
    require(target.parent.name == "cases" and target.name == case_id+"__"+config+".json.gz", "Unexpected native checkpoint identity")
    runs = [r for r in report["native_runs"] if r["path"] == str(directory.relative_to(root))]
    require(len(runs) == 1, "No unique bound native manifest")
    manifest_ref = dict(path=runs[0]["path"]+"/manifest.json", sha256=runs[0]["manifest_sha256"])
    manifest = _read(root, manifest_ref, "data/runs_v6")
    require(manifest["version"] == study.VERSION and directory.name == "demo_v6_"+digest(manifest)[:20], "Native run identity changed")
    require(manifest["code"] == native_code, "ALL current native code/file-set must equal the bound native map")
    require([c for c in manifest["cases"] if c["case_id"] == case_id] == [case]
        and config in manifest["settings"]["arms"], "Native manifest membership differs")
    native = _read(root, checkpoint, "data/runs_v6")
    require(native["case"] == case and native["config"] == config and native["run_id"] == directory.name
        and native["native_checksum"] == digest(native["result"]) == record["native_checksum"], "Native checkpoint/checksum differs")
    require(all(native.get(k) is False for k in ("keys_read", "grades_read", "inference_network_access")), "Native input was not source-only")
    clean_native = sanitize(native)
    projected, lazy_pins = _presentation_result(root, clean_native["result"], record["result"], report)
    clean_native["result"] = projected
    require(all(record.get(k) == v for k, v in clean_native.items()), "Displayed result/plan differs from native checkpoint")
    pin_path = directory/"checkpoint_pins"/(target.name.removesuffix(".json.gz")+".json")
    pin_ref = _ref(root, pin_path); pin = _read(root, pin_ref)
    require(pin == study._checkpoint_pin(directory, target, native, manifest), "Native checkpoint commitment changed")
    completion_ref = _ref(root, directory/"checkpoint_manifest.json"); completion = _read(root, completion_ref)
    require(completion["manifest_sha256"] == manifest_ref["sha256"] and completion["run_identity_sha256"] == digest(manifest)
        and completion["checkpoint_pins"][pin_path.name] == pin_ref["sha256"]
        and completion["native_checksums"][case_id+"__"+config] == native["native_checksum"], "Native completion commitment changed")
    source = report["source_binding"]["sha256"]; reference = report["graph_indexes"][case["corpus"]]
    require(record["case"] == case and record["config"] == config
        and record["exploration_index_ref"] == manifest["graph_indexes"][case["corpus"]] == reference
        and record["source_binding_sha256"] == manifest["source_binding_sha256"] == source, "Native/source index binding differs")
    veto = report.get("handling_veto_documents", {}).get(case["corpus"], [])
    require(record["handling_veto_documents"] == manifest["handling_veto_documents"][case["corpus"]] == veto, "Source handling veto differs")
    require(row["configurations"][config]["native_checkpoint"] == checkpoint, "Report/native checkpoint pin differs")
    require(row["configurations"][config].get("native_run_id", directory.name) == directory.name, "Published native run differs")
    _bound(root, reference, "data/graph_indexes_v2")
    planning_ref = manifest["release_ref"]; _bound(root, planning_ref, "data/development_v6")
    references = [row["case_detail_ref"], checkpoint, manifest_ref, pin_ref, completion_ref, reference, planning_ref, *lazy_pins]
    descriptor = dict(key=digest([case_id, config])[:32], case=case, config=config, record_sha256=digest(record),
        native_checksum=record["native_checksum"], native_checkpoint=checkpoint, native_manifest=manifest_ref,
        source_index=reference, source_binding_sha256=source,
        pins=sorted({digest(r): dict(path=r["path"], sha256=r["sha256"]) for r in references}.values(), key=lambda r: r["path"]))
    return descriptor, record


def prepare(root, report_ref, case_ids, *, arms=("A", "B", "C")):
    root = Path(root).resolve()
    require(isinstance(case_ids, (list, tuple)) and case_ids and len(set(case_ids)) == len(case_ids), "Select explicit distinct case IDs")
    configs = [ARMS.get(a, a) for a in arms]
    require(configs and len(set(configs)) == len(configs) and set(configs) <= set(ARMS.values())
        and len(configs)*len(case_ids) <= MAX_CONDITIONS, "Select at most 200 distinct active conditions")
    code = _code(root); gate = _gate(root, code); report = _report(root, report_ref)
    native_code = study.binding(root)
    jobs = []
    for case_id in sorted(case_ids):
        for config in sorted(configs):
            descriptor, record = _condition(root, report, case_id, config, native_code)
            jobs.append(dict(input=descriptor, record=record))
    source_pins = _source_pins(root, report, {j["input"]["case"]["corpus"] for j in jobs})
    identity = dict(version=VERSION, gate_version=gate.VERSION, code=code, native_code=native_code,
        native_code_count=len(native_code), report_ref=deepcopy(report_ref), report_run_id=report["run_id"],
        report_sha256=report["sha256"], case_ids=sorted(case_ids), configurations=sorted(configs),
        source_pins=source_pins, conditions=[j["input"] for j in jobs], process_environment=PROCESS_ENVIRONMENT.copy(),
        keys_read=False, grades_read=False, api_calls=0, native_outputs_modified=False)
    _runtime(root, identity)
    return dict(identity=identity, identity_sha256=digest(identity), jobs=jobs)


def _runtime(root, identity):
    require(identity["version"] == VERSION and _code(root) == identity["code"], "Gate/release/builder source changed; use a new release")
    require(study.binding(root) == identity["native_code"], "ALL current native code/file-set changed")
    for pin in identity["source_pins"]:
        _bound(root if pin["base"] == "root" else root.parent, pin)
    _bound(root, identity["report_ref"])
    for condition in identity["conditions"]:
        for pin in condition["pins"]: _bound(root, pin)


def _packet(value, identity, descriptor, record):
    case = descriptor["case"]
    require(value.get("version") == identity["gate_version"] and value.get("field") == FIELD
        and value.get("derived") is True and value.get("frozen_native_unchanged") is True
        and value.get("keys_read") is False and value.get("grades_read") is False and value.get("model_calls") == 0,
        "Not an exact source-only fixed-pool gate packet")
    expected = dict(case_id=case["case_id"], query_sha256=digest(case["query"]), config=descriptor["config"],
        native_run_id=record["run_id"], native_checksum=record["native_checksum"],
        source_index_sha256=descriptor["source_index"]["sha256"], source_binding_sha256=descriptor["source_binding_sha256"])
    require(all(value.get(k) == expected[k] for k in ("case_id", "query_sha256", "config"))
        and all(value.get("binding", {}).get(k) == v for k, v in expected.items()), "Gate output binding differs")
    require(sanitize(value) == {k: v for k, v in value.items() if k != FIELD}, "Gate output contains review-only fields")


def _environment():
    require(all(os.environ.get(k) == v for k, v in PROCESS_ENVIRONMENT.items()), "Use the reproducibly seeded builder CLI (hashseed 0 / BLAS 1)")


def _worker(root, identity, job):
    root = Path(root); _environment(); _runtime(root, identity)
    report = _report(root, identity["report_ref"])
    descriptor, record = _condition(root, report, job["input"]["case"]["case_id"], job["input"]["config"], identity["native_code"], job["record"])
    require(descriptor == job["input"], "Condition changed before gate computation")
    safe_report = dict(cases=[dict(case=descriptor["case"])], graph_indexes=report["graph_indexes"], source_binding=report["source_binding"])
    with offline():
        value = _gate(root, identity["code"]).evaluate(root, safe_report, record)
    _runtime(root, identity); _packet(value, identity, descriptor, record)
    return _sealed(dict(version=VERSION, identity_sha256=digest(identity), input=descriptor, **{FIELD: value}))


def _case_groups(jobs):
    groups = OrderedDict()
    for job in jobs:
        groups.setdefault(job["input"]["case"]["case_id"], []).append(job)
    return list(groups.values())


def _case_worker(root, identity, jobs):
    """One case stays in one process: source frames survive between its arms.

    Return each completed arm even if a later arm fails. Only the coordinator
    commits output refs/checkpoints; every arm still runs its own full guards.
    """
    require(jobs and len({j["input"]["case"]["case_id"] for j in jobs}) == 1, "Worker group must contain one case")
    results = []
    for job in jobs:
        try:
            results.append(dict(key=job["input"]["key"], output=_worker(root, identity, job)))
        except Exception as error:
            return dict(results=results, failure=dict(key=job["input"]["key"], type=type(error).__name__, message=str(error)))
    return dict(results=results, failure=None)


def _output(root, reference, identity, descriptor):
    path = _bound(root, reference, OUTPUT_ROOT); stamp = _stamp(path)
    key = (str(root), reference["path"], reference["sha256"], stamp)
    with _LOCK: value = deepcopy(_OUTPUTS.get(key))
    if value is None:
        value = _read(root, reference, OUTPUT_ROOT); _check_seal(value)
        with _LOCK:
            _OUTPUTS[key] = deepcopy(value)
            while len(_OUTPUTS) > OUTPUT_CACHE_LIMIT: _OUTPUTS.popitem(last=False)
    require(value["version"] == VERSION and value["identity_sha256"] == digest(identity) and value["input"] == descriptor, "Output belongs to a different exact condition/release")
    return value


def build(root, report_ref, case_ids, *, arms=("A", "B", "C"), execute=False, workers=2):
    require(type(execute) is bool and type(workers) is int and 1 <= workers <= 3, "Explicit execution and at most three workers required")
    root = Path(root).resolve(); prepared = prepare(root, report_ref, case_ids, arms=arms)
    identity, identity_sha = prepared["identity"], prepared["identity_sha256"]
    directory = _path(root, OUTPUT_ROOT+"/release_"+identity_sha[:24], OUTPUT_ROOT)
    preview = dict(version=VERSION, status="PREVIEW", identity_sha256=identity_sha,
        gate_version=identity["gate_version"], native_code_count=identity["native_code_count"],
        conditions=len(prepared["jobs"]), directory=str(directory.relative_to(root)), api_calls=0,
        native_outputs_modified=False, publication_performed=False)
    if not execute: return preview
    _environment(); disk_guard(root, 8)
    directory.parent.mkdir(parents=True, exist_ok=True)
    try: directory.mkdir(); created = True
    except FileExistsError: created = False
    lock_path = _path(root, str((directory/"build.lock").relative_to(root)))
    with lock_path.open("a+") as lock:
        try: fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error: raise RuntimeError("Decision release build already running") from error
        input_path, checkpoint = directory/"input.json", directory/"checkpoint.json"
        if created:
            _write(input_path, _sealed(dict(version=VERSION, identity=identity)), immutable=True)
            state = _sealed(dict(version=VERSION, identity_sha256=identity_sha, status="RUNNING", completed={}, failures={}))
            _write(checkpoint, state)
        else:
            require(input_path.is_file() and checkpoint.is_file(), "Unowned directory; do not adopt existing outputs or UI caches")
            old_input = _read(root, _ref(root, input_path)); _check_seal(old_input)
            require(old_input == _sealed(dict(version=VERSION, identity=identity)), "Resume input identity differs")
            state = _read(root, _ref(root, checkpoint)); _check_seal(state)
            require(state["version"] == VERSION and state["identity_sha256"] == identity_sha, "Resume checkpoint identity differs")
        state.pop("sha256")
        keys = {j["input"]["key"]: j for j in prepared["jobs"]}
        require(set(state["completed"]) <= set(keys), "Checkpoint contains foreign conditions")
        for key, ref in state["completed"].items():
            expected = str((directory/"conditions"/(key+".json")).relative_to(root))
            require(ref["path"] == expected, "Checkpoint output path differs")
            _output(root, ref, identity, keys[key]["input"])
        actual = {p.name for p in (directory/"conditions").glob("*")}
        require(actual == {k+".json" for k in state["completed"]}, "Uncommitted output exists; never adopt directory contents")
        code_refs = []
        for name in code_files(root):
            source = _bound(root, dict(path=name, sha256=identity["code"][name])).read_bytes()
            target = directory/"code"/Path(name).name
            _write(target, None, immutable=True, content=source); code_refs.append(_ref(root, target))
        def commit(job, value):
            _runtime(root, identity); disk_guard(root, 8)
            key = job["input"]["key"]; target = directory/"conditions"/(key+".json")
            require(not target.exists(), "Uncommitted output cannot be adopted")
            _write(target, value, immutable=True)
            state["completed"][key] = _ref(root, target); state["failures"].pop(key, None)
            _write(checkpoint, _sealed(state))
            print("Committed decision", job["input"]["case"]["case_id"], job["input"]["config"], len(state["completed"]), "/", len(keys), flush=True)
        missing = [j for j in prepared["jobs"] if j["input"]["key"] not in state["completed"]]
        try:
            if workers == 1:
                for job in missing: commit(job, _worker(str(root), identity, job))
            elif missing:
                groups = _case_groups(missing)
                pool = ProcessPoolExecutor(max_workers=min(workers, len(groups)), mp_context=multiprocessing.get_context("spawn"))
                try:
                    futures = {pool.submit(_case_worker, str(root), identity, group): group for group in groups}
                    for future in as_completed(futures):
                        result = future.result()
                        group = {j["input"]["key"]: j for j in futures[future]}
                        for item in result["results"]: commit(group[item["key"]], item["output"])
                        if result["failure"]:
                            failure = result["failure"]; state["failures"][failure["key"]] = failure
                            raise ValueError("Case worker "+failure["type"]+": "+failure["message"])
                except BaseException:
                    for future in futures: future.cancel()
                    pool.shutdown(wait=True, cancel_futures=True)
                    raise
                else:
                    pool.shutdown(wait=True)
        except BaseException as error:
            state["status"] = "FAILED"; state["failures"]["build"] = dict(type=type(error).__name__, message=str(error))
            _write(checkpoint, _sealed(state)); raise
        _runtime(root, identity)
        value = _sealed(dict(version=VERSION, status="COMPLETE", identity=identity, identity_sha256=identity_sha,
            input_ref=_ref(root, input_path), code_snapshots=code_refs,
            outputs=[dict(case_id=j["input"]["case"]["case_id"], config=j["input"]["config"], ref=state["completed"][j["input"]["key"]]) for j in prepared["jobs"]],
            public_field=FIELD, api_calls=0, native_outputs_modified=False, publication_performed=False))
        _write(directory/"release.json", value, immutable=True)
        state["status"] = "COMPLETE"; state["failures"] = {}; _write(checkpoint, _sealed(state))
        return dict(preview, status="COMPLETE", release_ref=_ref(root, directory/"release.json"), reused_conditions=len(keys)-len(missing))


def validate_manifest(root, release_ref, report):
    """Replay the complete bundle before publication or individual reads."""
    root = Path(root).resolve(); manifest = _read(root, release_ref, OUTPUT_ROOT); _check_seal(manifest)
    require(manifest["version"] == VERSION and manifest["status"] == "COMPLETE"
        and manifest.get("public_field") == FIELD and manifest.get("api_calls") == 0
        and manifest.get("native_outputs_modified") is False and manifest.get("publication_performed") is False, "No completed source-only decision release")
    identity = manifest["identity"]
    require(manifest["identity_sha256"] == digest(identity), "Release identity changed")
    directory = _path(root, OUTPUT_ROOT+"/release_"+digest(identity)[:24])
    require(release_ref["path"] == str((directory/"release.json").relative_to(root)), "Release path does not match its identity")
    _runtime(root, identity); _check_seal(report)
    require(report["run_id"] == identity["report_run_id"] and report["sha256"] == identity["report_sha256"], "Decision release belongs to another pinned report")
    original = _read(root, manifest["input_ref"], OUTPUT_ROOT); _check_seal(original)
    require(original["identity"] == identity and manifest["input_ref"]["path"] == str((directory/"input.json").relative_to(root)), "Original release input commitment differs")
    expected_code = {str((directory/"code"/Path(n).name).relative_to(root)): identity["code"][n] for n in code_files(root)}
    require(len(manifest["code_snapshots"]) == len(expected_code)
        and {r["path"]: r["sha256"] for r in manifest["code_snapshots"]} == expected_code, "Code snapshot membership differs")
    for ref in manifest["code_snapshots"]: _bound(root, ref, OUTPUT_ROOT)
    expected = {(c["case"]["case_id"], c["config"]) for c in identity["conditions"]}
    require(len(expected) == len(identity["conditions"])
        and expected == {(cid, arm) for cid in identity["case_ids"] for arm in identity["configurations"]},
        "Release condition membership differs")
    require(len(manifest["outputs"]) == len(expected) and {(o["case_id"], o["config"]) for o in manifest["outputs"]} == expected, "Release output membership differs")
    condition_keys = {(c["case"]["case_id"], c["config"]): c["key"] for c in identity["conditions"]}
    descriptors = {(c["case"]["case_id"], c["config"]): c for c in identity["conditions"]}
    for item in manifest["outputs"]:
        key = condition_keys[item["case_id"], item["config"]]
        require(item["ref"]["path"] == str((directory/"conditions"/(key+".json")).relative_to(root)), "Release output ref redirected")
        descriptor = descriptors[item["case_id"], item["config"]]
        value = _output(root, item["ref"], identity, descriptor)[FIELD]
        _packet(value, identity, descriptor, dict(
            run_id=Path(descriptor["native_manifest"]["path"]).parent.name,
            native_checksum=descriptor["native_checksum"]))
    return manifest


def load_for(root, release_ref, case, record, report):
    """Read-only exact packet for record[FIELD]; no gate evaluation, no fallback."""
    root = Path(root).resolve(); manifest = validate_manifest(root, release_ref, report)
    identity = manifest["identity"]
    directory = _path(root, OUTPUT_ROOT+"/release_"+digest(identity)[:24])
    public = public_case(case)
    require(public == sanitize(record["case"]), "Supplied case/query differs")
    descriptor, clean = _condition(root, report, public["case_id"], record["config"], identity["native_code"], record)
    require(descriptor in identity["conditions"], "This exact condition was not built")
    output = next(o for o in manifest["outputs"] if (o["case_id"], o["config"]) == (public["case_id"], record["config"]))
    require(output["ref"]["path"] == str((directory/"conditions"/(descriptor["key"]+".json")).relative_to(root)), "Output ref redirected")
    value = _output(root, output["ref"], identity, descriptor)[FIELD]
    _packet(value, identity, descriptor, clean)
    return deepcopy(value)
