"""Load the fixed-path V6.5 graph derivation without an experiments package."""
from pathlib import Path

from .guide_runtime_v63 import _module


HELPER = "experiments/ui_v65/graph/server_guide_v65.py"


def outputs(root):
    root = Path(root).resolve()
    helper = _module(root, HELPER)
    return {name: helper.graph_asset(name) for name in
            ("graph-full-v6.html", "graph-full-v6.js", "graph-full-v6.css")}
