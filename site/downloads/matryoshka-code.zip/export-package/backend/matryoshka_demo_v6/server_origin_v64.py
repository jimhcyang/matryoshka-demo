"""Source-only V6.4 provenance adapter; never eligible for native inference.

Compose OriginV64Mixin before the existing Handler. The /api/origin-v63 route
and packet schema stay compatible; the V6.3 module and its globals stay intact.
"""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from types import FunctionType
from urllib.parse import parse_qs, unquote, urlsplit

from . import server_origin_v63 as v63


V64_RELEASE_ROOTS = ("experiments/curation_v64_cib/releases",
                     "experiments/curation_v64_cables/releases")
RELEASE_ROOTS = (*v63.RELEASE_ROOTS, *V64_RELEASE_ROOTS)
SOURCE_SEAL = "matryoshka_redaction/data/preflight_v3/release/source_release.json"


def _isolated(function, overrides):
    # Rebind only the adapter hooks, never the old module's process-wide globals.
    context = dict(vars(v63), **overrides)
    copied = FunctionType(function.__code__, context, function.__name__, function.__defaults__)
    copied.__kwdefaults__ = deepcopy(function.__kwdefaults__)
    return copied


_sealed_proof = _isolated(v63._proof, dict(RELEASE_ROOTS=RELEASE_ROOTS))


def _cib_focal_category(root, case, proof):
    source = proof["origin"]
    audit = proof["source_origin_audit"]
    canonical = audit["canonical_row"]
    if not canonical or not audit.get("canonical_ref"):
        raise ValueError("V6.4 focal provenance requires pinned canonical units")
    # Retain the exact canonical file hash, ready-row and paired identity checks.
    category = v63._source_category(root, {}, case, proof, source)
    target = audit["source_sealed_target"]
    index = target["zone_unit_index"]
    anchors = proof["origin_anchors"]
    if (case["task"] != "redaction" or source["classification"] != "CIB_LATER_RELEASE"
            or source.get("permitted") is not False
            or any(audit.get(k) is not True for k in ("secret_derived", "whole_origin_document_excluded",
                       "complete_hidden_extent", "focal_only_reveal", "adjacent_unknowns_opaque"))
            or type(index) is not int or not 0 <= index < len(canonical["units"])
            or len(anchors) != 1):
        raise ValueError("No complete V6.4 focal-only provenance contract")
    unit, anchor = canonical["units"][index], anchors[0]
    bounds, quality = target["cloze_source_boundaries"], target["target_quality"]
    if (target["canonical_page_id"] != source["source_id"]
            or target["document_id"] != case["document_id"] or target["document_date_iso"] != case["date"]
            or unit["unit_type"] != "redaction_zone" or not unit.get("slot_ids")
            or "revealed" not in unit.get("reveal_states", [])
            or sha256(json.dumps(unit, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()).hexdigest() != target["zone_unit_sha256"]
            or target["member_slot_ids"] != unit["slot_ids"]
            or anchor.get("unit_index") != index or type(anchor.get("unit_index")) is not int
            or anchor.get("unit_type") != "redaction_zone" or anchor.get("earlier_visible") is not False
            or anchor.get("slot_ids") != unit["slot_ids"] or anchor["text"] != unit["later_text"]
            or target["answer"] != unit["later_text"].strip()
            or bounds.get("hidden_prefix") is not False or bounds.get("hidden_suffix") is not False
            or bounds["parent_text"] != unit["later_text"]
            or quality.get("pending_review") is not False or quality.get("decision") != "retain"
            or any(quality["attachment"].get(k) is not True for k in ("left", "right"))
            or not case["focal_marker"] or case["query"].count(case["focal_marker"]) != 1
            or case["query"] not in target["query"]):
        raise ValueError("V6.4 focal canonical unit does not replay")
    parts = [u.get("text", "") if u["unit_type"] == "shared_text" else
             u.get("later_text", "") if i == index else "[REDACTED]"
             for i, u in enumerate(canonical["units"])]
    start = sum(map(len, parts[:index]))
    span = v63._anchor(anchor, source["text"], source)
    if (source.get("start") != 0 or source.get("end") != len(source["text"])
            or source["text"] != "".join(parts)
            or span != dict(start=start, end=start + len(parts[index]), text=parts[index])):
        raise ValueError("V6.4 focal-only projection does not replay")

    workspace = Path(root).resolve().parent
    seal = audit["source_seal"]
    if seal["path"] != SOURCE_SEAL:
        raise ValueError("Unsupported V6.4 source seal")
    v63._bound_json(workspace, seal["path"], seal["sha256"],
                    directory=workspace / Path(SOURCE_SEAL).parent)
    ref = audit["paired_transcript_ref"]
    if Path(ref["path"]) != Path(audit["canonical_ref"]["path"]).with_name("page_pairs.jsonl"):
        raise ValueError("Paired transcript is outside the pinned canonical preparation")
    path = v63._bound_file(workspace, ref["path"], ref["sha256"],
                           directory=workspace / "src-redaction/data/preparation_refresh/runs")
    with path.open() as stream:
        pairs = [row for line in stream if (row := json.loads(line)).get("canonical_page_id") == source["source_id"]]
    if pairs != [audit["paired_record"]]:
        raise ValueError("V6.4 paired source transcript does not replay")
    for release in ("earlier", "later"):
        page = audit[release + "_physical_pdf_page"]
        if (type(page) is not int or page <= 0 or page != pairs[0][release + "_page"]
                or page != canonical[release + "_source_page"] or page != target[release + "_page"]
                or proof.get("physical_" + release + "_pdf_page", page) != page):
            raise ValueError("V6.4 physical PDF page does not replay")

    # Redaction certifies this indexed gap, not absence of its words elsewhere.
    category.update(source_category="CIB_VERIFIED_REVEAL", unit_verified=True, secret_derived=True,
        warning="", units=[dict(unit_index=index, unit_type="redaction_zone", unique_in_unit=True,
                                slot_ids=unit["slot_ids"], reveal_states=unit["reveal_states"])])
    return category


def _proof(root, row):
    proof, proof_hash = _sealed_proof(root, row)
    release_root = Path(row["source_manifest_ref"]["path"]).parent.parent.as_posix()
    if release_root not in V64_RELEASE_ROOTS:
        return proof, proof_hash
    case = row["case"]
    if case["corpus"] != "cib":
        if (release_root != V64_RELEASE_ROOTS[1]
                or case["document_id"] not in proof.get("source_origin_audit", {}).get("original_raw_documents", {})):
            raise ValueError("V6.4 cable provenance requires its sealed original body audit")
        return proof, proof_hash  # The unchanged full-body SECRET/NOFORN checks run below.
    if release_root != V64_RELEASE_ROOTS[0]:
        raise ValueError("CIB provenance is outside its explicit V6.4 release root")
    category = _cib_focal_category(root, case, proof)
    proof = deepcopy(proof)
    proof["_origin_v64_category"] = category
    proof["origin"]["projection_policy"] = "focal_reveal_only_all_other_nonshared_units_remain_opaque"
    proof["origin_anchors"][0]["focal"] = True
    return proof, proof_hash


def _source_category(root, report, case, proof, source):
    if "_origin_v64_category" in proof:
        return deepcopy(proof["_origin_v64_category"])
    return v63._source_category(root, report, case, proof, source)


origin = _isolated(v63.origin, dict(_proof=_proof, _source_category=_source_category))


class OriginV64Mixin(v63.OriginV63Mixin):
    """Compatible source-only route; inherited private/no-store response headers."""

    def do_GET(self):
        parsed = urlsplit(self.path)
        if unquote(parsed.path) != "/api/origin-v63":
            return super().do_GET()
        try:
            params = parse_qs(parsed.query, keep_blank_values=True, strict_parsing=True)
            if (set(params) - {"case_id", "reveal_focal"} or len(params.get("case_id", [])) != 1
                    or any(len(v) != 1 for v in params.values())
                    or params.get("reveal_focal", ["0"])[0] not in {"0", "1"}):
                raise ValueError("Only a published case and explicit focal reveal are accepted")
            packet = origin(self.root, self.published_report(6), params["case_id"][0],
                            reveal_focal=params.get("reveal_focal", ["0"])[0] == "1")
            self.json_response(packet, compress=True)
        except (OSError, ValueError, KeyError, TypeError, IndexError):
            self.send_error(409, "No unchanged audited query provenance matches this request")
