"""Inactive role-identification witnesses, not contradiction-aware support.

V1 stays byte-for-byte unchanged. This version adds complete nominal-constituent
checks and conservative lexical/quotation scope guards before issuing a witness.
"""
from copy import deepcopy
import re

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest, offline
from . import reporting_role_identification_prototype as previous
from .reporting_fixed_pool_role_projection_v2 import NONFACTIVE

VERSION = "raw-source-role-identification-prototype/2"
query_spec = previous.query_spec
policy = previous.policy
scoped = previous.scoped
literal = previous.literal
_OUTER_NONFACTIVE = frozenset(NONFACTIVE) | previous._NONASSERTIVE
_MATRIX_NONFACTIVE = (_OUTER_NONFACTIVE - set(scoped.matching.parent._REPORTING)) | previous._NONASSERTIVE
_QUOTES = {'"', "'", "\u2018", "\u2019", "\u201c", "\u201d"}
_LABEL = r"(?:[A-Za-z](?:\d+)?|\d+[A-Za-z]?)"
_LAYOUT_LABEL = re.compile(r"(?:\(\s*" + _LABEL + r"\s*\)|\[\s*" + _LABEL + r"\s*\])")


def _quote_scope(text, begin, end):
    """Do not confuse literal word/telegram possessive apostrophes with quotes."""
    stack = []
    classifications = []
    for at, char in enumerate(text[:end]):
        if char not in _QUOTES:
            continue
        left = text[at - 1] if at else ""
        right = text[at + 1] if at + 1 < len(text) else ""
        single = char in {"'", "\u2018", "\u2019"}
        if single and left.isalnum() and right.isalnum():
            classifications.append(dict(start=at, kind="WORD_INTERNAL_APOSTROPHE"))
            continue
        # Preserve telegram typography such as HELICOPTER' S and CITIZENS'
        # REQUEST. A plural possessive cannot close an already-open quotation.
        if single and left.isalnum() and right.isspace():
            following_s = re.match(r"\s+[sS](?!\w)", text[at + 1:])
            plural = left.lower() == "s" and not stack and re.match(r"\s+\w", text[at + 1:])
            if following_s or plural:
                classifications.append(dict(start=at, kind="PRINTED_POSSESSIVE_APOSTROPHE"))
                continue
        if begin <= at < end:
            return None, "QUOTATION_DELIMITER_INSIDE_DESIGNATION"
        opening = {"\u2018": "\u2019", "\u201c": "\u201d"}
        if char in opening:
            stack.append(opening[char])
        elif stack and stack[-1] == char:
            stack.pop()
        elif char in {"\u2019", "\u201d"}:
            return None, "UNBOUND_CLOSING_QUOTATION"
        else:
            stack.append(char)
    if stack:
        return None, "OPEN_QUOTATION_AT_DESIGNATION"
    return dict(quote_scope_open=False, apostrophes=classifications), None


def _outer_scope(prefix, engine):
    if previous._external_operator_open(prefix, engine):
        return None, "V1_EXTERNAL_OPERATOR_SCOPE"
    for colon in re.finditer(":", prefix):
        at = colon.start()
        if at and at + 1 < len(prefix) and prefix[at - 1].isdigit() and prefix[at + 1].isdigit():
            continue
        head = re.split(r"[.!?]\s+|\n[ \t]*\n", prefix[:at])[-1]
        if (previous._PREFIX_SCOPE.search(head)
                or any(t.lemma_.lower() in _OUTER_NONFACTIVE for t in engine.parse(head))):
            return None, "NONFACTIVE_COLON_SCOPE_NOT_CLOSED_BY_SECTION_MARKER"
    for unit in literal.sentences(prefix):
        if (re.search(r"\bthe\s+following\s*[.:]?\s*$", unit["text"], re.I)
                and any(t.lemma_.lower() in _OUTER_NONFACTIVE for t in engine.parse(unit["text"]))):
            return None, "NONFACTIVE_FOLLOWING_LIST_SCOPE"
    current = re.split(r"[.!?]\s+|\n[ \t]*\n", prefix)[-1]
    if not re.search(r"[.!?]\s*$", current) and any(
            t.lemma_.lower() in _OUTER_NONFACTIVE for t in engine.parse(current)):
        return None, "UNFINISHED_NONFACTIVE_CLAUSE_BEFORE_DESIGNATION"
    return dict(reused_nonfactive_inventory=True, colon_or_following_scope_open=False), None


def _name_constituent(name, role):
    # An appositive suffix is part of the identity boundary, regardless of its
    # spelling. The matched title itself is not a suffix of its owning name.
    core, pending = {name}, [name]
    while pending:
        for child in pending.pop().children:
            if child == role or child in core:
                continue
            if child.dep_ in previous._NAME_DEPS | {"appos"} and not child.is_punct and not child.is_space:
                core.add(child)
                pending.append(child)
    return core


def _complete_boundaries(doc, offset, match, kind):
    names = {t for t in doc if match.start("name") <= t.idx + offset < match.end("name") and not t.is_space}
    name_heads = [t for t in names if t.head not in names]
    roles = [t for t in doc if t.idx + offset == match.start("role")]
    if len(name_heads) != 1 or len(roles) != 1:
        return None, "NO_UNIQUE_LITERAL_NAME_AND_ROLE"
    name, role = name_heads[0], roles[0]
    core = _name_constituent(name, role)
    if core != names:
        return None, "COMPLETE_NAME_CONSTITUENT_EXTENDS_BEYOND_QUERY_NAME"
    if any(c != role and c not in core and not c.is_punct and not c.is_space for n in core for c in n.children):
        return None, "UNMATCHED_NAME_DEPENDENT"
    units = {t for t in doc if match.start("unit") <= t.idx + offset < match.end("unit") and not t.is_space}
    if not units:
        return None, "EMPTY_LITERAL_UNIT"
    complete_unit = set(units)
    markers = []

    def printed_layout_marker(token):
        if token.dep_ != "meta":
            return False
        branch = [t for t in token.subtree if not t.is_space]
        a = min(t.idx for t in branch)
        b = max(t.idx + len(t) for t in branch)
        raw = doc.text[a:b]
        begin = min(match.start("name"), match.start("unit")) - offset
        if (not _LAYOUT_LABEL.fullmatch(raw)
                or doc.text[:a].strip() or b > begin or doc.text[b:begin].strip()):
            return False
        markers.append(dict(text=raw, start=a + offset, end=b + offset,
            kind="LITERAL_BRACKETED_LAYOUT_LABEL_NOT_OMITTED_SOURCE_FACT"))
        return True
    if kind == "NAME_ROLE_OF_UNIT_APPOSITION":
        heads = [t for t in units if t.head not in units]
        if len(heads) != 1:
            return None, "AMBIGUOUS_UNIT_CONSTITUENT"
        unit_head = heads[0]
        # The explicitly licensed optional article remains visible in the full
        # constituent proof; all other attached unit words must be in the match.
        articles = {c for c in unit_head.children if c.dep_ == "det" and c.lower_ == "the"
            and role.idx < c.idx < min(t.idx for t in units)}
        expected = units | articles
        actual = {t for t in unit_head.subtree if not t.is_punct and not t.is_space}
        if actual != expected:
            return None, "COMPLETE_UNIT_CONSTITUENT_EXTENDS_BEYOND_LITERAL_MATCH"
        prep = unit_head.head
        if any(not c.is_punct and not c.is_space and c not in expected for c in prep.children):
            return None, "ADDITIONAL_PREPOSITION_OBJECT_OR_UNIT"
        allowed_children = {prep}
        complete_unit = expected
    else:
        allowed_children = units | {name}
        if any(not c.is_punct and not c.is_space and c not in units and not printed_layout_marker(c)
                for u in units for c in u.children):
            return None, "ATTACHED_UNIT_BRANCH_OUTSIDE_LITERAL_MATCH"
    if any(not c.is_punct and not c.is_space and c not in allowed_children and not printed_layout_marker(c)
            for c in role.children):
        return None, "ATTACHED_TITLE_BRANCH_OUTSIDE_LITERAL_MATCH"
    proof = lambda t: dict(text=t.text, start=t.idx + offset, end=t.idx + offset + len(t),
        dependency=t.dep_, head=t.head.text)
    return dict(name=[proof(t) for t in sorted(core, key=lambda t: t.i)],
        unit=[proof(t) for t in sorted(complete_unit, key=lambda t: t.i)],
        unit_start=min(t.idx for t in complete_unit) + offset,
        unit_end=max(t.idx + len(t) for t in complete_unit) + offset,
        printed_layout_markers=markers,
        omitted_name_or_unit_constituents=False), None


def _certificate(page, kind, match, spec, engine, index, case):
    text = page["text"]
    begin = min(match.start("name"), match.start("unit"))
    end = max(match.end("name"), match.end("unit"), match.end("role"))
    quotes, reason = _quote_scope(text, begin, end)
    if reason:
        return None, reason
    outer, reason = _outer_scope(text[:begin], engine)
    if reason:
        return None, reason
    certificate, reason = previous._certificate(page, kind, match, spec, engine, index, case)
    if certificate is None:
        return None, reason
    citation = certificate["citation"]
    leading = citation["text"][:begin - citation["start"]].strip()
    if re.search(r"[()\[\]]", leading) and not _LAYOUT_LABEL.fullmatch(leading):
        return None, "UNLICENSED_PARENTHETICAL_PREFIX_NOT_A_PRINTED_LAYOUT_LABEL"
    doc = engine.parse(citation["text"])
    boundary, reason = _complete_boundaries(doc, citation["start"], match, kind)
    if reason:
        return None, reason
    if certificate["matrix"]["lemma"].lower() in _MATRIX_NONFACTIVE:
        return None, "REUSED_NONFACTIVE_MATRIX_INVENTORY"
    unit = policy._citation(page, boundary["unit_start"], boundary["unit_end"])
    policy._quote(unit, *index, case)
    certificate.pop("sha256", None)
    certificate.update(version=VERSION, prior_guard_version=previous.VERSION,
        complete_literal_constituents=boundary, complete_source_unit=unit,
        quotation_boundary_check=quotes, external_operator_check=outer,
        contradiction_scan_performed=False, contradiction_aware_support="NOT_ASSESSED",
        cross_source_role_consistency="NOT_ASSESSED", support_decision_provided=False)
    certificate["unit_comparison"]["matched_nominal_unit_core"] = certificate["unit_comparison"]["full_source_unit"]
    certificate["unit_comparison"]["full_source_unit"] = unit["text"]
    certificate["sha256"] = digest(certificate)
    return certificate, None


def observe(record, case, eligible_index):
    case = public_case(case)
    if case["task"] not in {"hypothesis", "reconstruction"} or public_case(record["case"]) != case:
        raise ValueError("One exact public complete-query condition is required")
    atoms = previous._atoms(case, record["plan"])
    ids = record.get("inspected_page_ids")
    if not isinstance(ids, list) or not ids or len(ids) != len(set(ids)):
        raise ValueError("Exact nonempty inspected pool required")
    meta = record["result"]
    if meta.get("source_pages_inspected", len(ids)) != len(ids):
        raise ValueError("Saved inspected count differs")
    budget = meta.get("passage_budget", meta.get("retrieval", {}).get("construction_passage_budget"))
    if type(budget) is not int or budget < len(ids):
        raise ValueError("Pool exceeds recorded budget")
    pages, masks, veto = policy._pages(eligible_index, case)
    index = pages, masks, set(veto) | set(record.get("handling_veto_documents", []))
    admitted = {}
    for pid in ids:
        if pid not in pages:
            raise ValueError("Saved pool source missing from bound index")
        page = pages[pid]
        policy._quote(policy._citation(page, 0, len(page["text"])), *index, case)
        admitted[pid] = page
    decisions = []
    with offline():
        engine = scoped.Engine()
        for atom in atoms:
            spec = query_spec(atom)
            certificates, rejected = [], []
            if spec is not None:
                for page in admitted.values():
                    for kind, match in previous._matches(page["text"], spec):
                        certificate, reason = _certificate(page, kind, match, spec, engine, index, case)
                        if certificate is not None:
                            certificates.append(certificate)
                        else:
                            rejected.append(dict(source_id=page["id"], start=match.start(), end=match.end(), reason=reason))
            decisions.append(dict(atom_id=atom["id"], text=atom["text"], required=True,
                status="SOURCE_ROLE_IDENTIFIED" if certificates else "UNRESOLVED", certificates=certificates,
                rejected=rejected, query_grammar_licensed=spec is not None, source_identification_only=True,
                world_support="NOT_ASSESSED", actual_tenure_or_event_established=False,
                contradiction_aware_support="NOT_ASSESSED", support_decision_provided=False))
    count = sum(d["status"] == "SOURCE_ROLE_IDENTIFIED" for d in decisions)
    return dict(version=VERSION, case_id=case["case_id"], query_sha256=digest(case["query"]),
        decisions=decisions, required_identifications=len(decisions), source_identified=count,
        source_identification_complete=bool(decisions) and count == len(decisions),
        completion_semantics="ALL_REQUESTED_IDENTIFICATIONS_HAVE_LITERAL_WITNESSES_ONLY",
        world_support="NOT_ASSESSED", continuous_tenure_established=False,
        appointment_or_other_event_established=False, native_or_canonical_gate_changed=False,
        contradiction_scan_performed=False, contradiction_aware_support="NOT_ASSESSED",
        cross_source_role_consistency="NOT_ASSESSED", support_decision_provided=False,
        saved_inspected_page_ids=deepcopy(ids), new_retrieval=False, keys_read=False, grades_read=False, api_calls=0,
        limitations=["Literal source-identification witnesses, not world truth, tenure or contradiction-aware support.",
            "No cross-source consistency or opposite-role claim scan is performed, even if every requirement has a witness.",
            "Conservative English construction and scope guards can over-abstain; this is not complete discourse or identity resolution.",
            "The numeric suffix path retains a source namespace and does not merge organization identities.",
            "This prototype remains inactive and is not a replacement for the canonical observer."])
