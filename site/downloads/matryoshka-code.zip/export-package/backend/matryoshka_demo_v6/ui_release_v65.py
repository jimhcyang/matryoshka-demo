"""Independent V6.5 viewer seal over immutable V6.1 inference artifacts."""
from pathlib import Path

from matryoshka_demo.graph_assets_v4 import bound
from matryoshka_demo.io import digest, load, sha
from .guide_runtime_v63 import validate as validate_v63
from .guide_runtime_v64 import validate as validate_v64


ADDITIONAL = (
    "matryoshka_demo_v6/server_v65.py", "matryoshka_demo_v6/server_origin_v65.py",
    "matryoshka_demo_v6/server_origin_reaudit_v65.py",
    "scripts/build_source_registry_v65.py",
    "matryoshka_demo_v6/flow_projection_v65.py", "matryoshka_demo_v6/guide_v65.py",
    "matryoshka_demo_v6/guide_runtime_v65.py",
    "matryoshka_demo_v6/guide_route_selection_v65.py",
    "matryoshka_demo_v6/reporting_local_decisions_v65.py",
    "matryoshka_demo_v6/reporting_fixed_pool_decisions_v65.py",
    "matryoshka_demo_v6/reporting_decision_assessment_v65.py",
    "matryoshka_demo_v6/reporting_decision_release_v65.py",
    "scripts/build_local_decision_release_v65.py",
    "matryoshka_demo_v6/ui_release.py", "matryoshka_demo_v6/ui_release_v65.py",
    "web/local-decisions-v65.js", "scripts/serve_demo_v6.py",
    "experiments/ui_v65/graph/server_guide_v65.py",
    "experiments/ui_v65/graph/guide_route_badges_v65.js",
)


def native_code(root, report):
    from matryoshka_demo_v61.study import binding
    current = binding(root)
    runs = report.get("native_runs")
    if not isinstance(runs, list) or not runs:
        raise ValueError("A V6.5 viewer requires explicit frozen native runs")
    seen = set()
    for ref in runs:
        relative = Path(ref["path"])
        directory = root / relative
        if (relative.is_absolute() or ".." in relative.parts
                or directory.resolve(strict=True) != directory
                or directory.parent != root / "data/runs_v6" or relative in seen):
            raise ValueError("Native viewer runs must be unique literal run directories")
        seen.add(relative)
        path = directory / "manifest.json"
        if path.resolve(strict=True) != path or sha(path) != ref["manifest_sha256"]:
            raise ValueError("Native viewer manifest changed")
        manifest = load(path)
        if (directory.name != "demo_v6_" + digest(manifest)[:20]
                or manifest.get("code") != current):
            raise ValueError("Frozen native dependencies differ from the current viewer runtime")
    return current


def proposal(root):
    from .ui_release import FILES
    from .guide_runtime_v65 import outputs
    root = Path(root).resolve()
    validate_v63(root)
    validate_v64(root)
    for name, raw in outputs(root).items():
        if (root / "web" / name).read_bytes() != raw:
            raise ValueError("Published graph differs from the V6.5 provenance-only derivation")
    path = root / "web/data/report-v6.json"
    report = load(path)
    if (report.get("presentation_version") != "6.5"
            or report.get("sha256") != digest({k: v for k, v in report.items() if k != "sha256"})):
        raise ValueError("Published V6.5 casebook changed")
    runtime_code = native_code(root, report)
    graph = bound(root)
    gate_dependencies = [str(path.relative_to(root)) for path in
                         sorted((root / "matryoshka_demo_v6").glob("reporting_fixed_pool*.py"))]
    from .server_v65 import REVIEW_POINTER, review_index, DECISION_POINTER, decision_index
    review = review_index(root, report)
    extra = ([REVIEW_POINTER] + [item["ref"]["path"] for item in review["assessments"]]) if review else []
    if any(row["case"]["corpus"] in {"iran", "vietnam"} for row in report.get("cases", [])):
        from .server_origin_reaudit_v65 import source_registry_ref
        extra.append(source_registry_ref(root)["path"])
    decisions = decision_index(root, report)
    if decisions:
        extra.append(DECISION_POINTER)
        for item in decisions["releases"]:
            extra.append(item["ref"]["path"])
            from .reporting_decision_release_v65 import validate_manifest
            manifest = validate_manifest(root, item["ref"], report)
            if (manifest.get("version") != "source-only-local-decision-release/6.5"
                    or manifest.get("status") != "COMPLETE"
                    or manifest.get("sha256") != digest({k: v for k, v in manifest.items() if k != "sha256"})
                    or manifest["identity"]["report_run_id"] != report["run_id"]
                    or manifest["identity"]["report_sha256"] != report["sha256"]):
                raise ValueError("Local decision release does not bind this completed viewer")
            mapped = {(cid, arm) for cid in item["cases"] for arm in item["configurations"]}
            available = {(c["case"]["case_id"], c["config"]) for c in manifest["identity"]["conditions"]}
            if not mapped <= available:
                raise ValueError("Decision pointer names a condition absent from its release")
            references = [manifest["input_ref"], *manifest["code_snapshots"],
                          *[output["ref"] for output in manifest["outputs"]]]
            for ref in references:
                relative = Path(ref["path"])
                target = root / relative
                if (relative.is_absolute() or ".." in relative.parts
                        or target.resolve(strict=True) != target
                        or not target.is_relative_to(root / "experiments/ui_v65/decision_releases")
                        or sha(target) != ref["sha256"]):
                    raise ValueError("Local decision output/code/input changed or escaped its release")
                extra.append(ref["path"])
    value = dict(version="task-directed-workbench-presentation/6", run_id=report["run_id"],
        presentation_version="6.5", native_inference_version=report["version"],
        source_report=dict(path="web/data/report-v6.json", sha256=sha(path)),
        full_graph_binding_sha256=graph["sha256"],
        frozen_native_code=runtime_code,
        frozen_native_code_sha256=digest(runtime_code),
        assets=[dict(path=p, sha256=sha(root / p)) for p in sorted(set([*FILES, *ADDITIONAL, *gate_dependencies, *extra]))],
        native_outputs_modified=False, inference_api_calls_from_viewer=0,
        population_status=report.get("status", "UNSPECIFIED"))
    value["sha256"] = digest(value)
    return value
