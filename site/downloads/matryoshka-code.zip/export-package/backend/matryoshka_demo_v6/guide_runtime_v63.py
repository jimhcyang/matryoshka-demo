"""Sealed, fixed-path V6.3 runtime entry points, independent of process cwd."""
from collections import OrderedDict
from hashlib import sha256
import importlib.util
from pathlib import Path
from threading import RLock


FILES = (
    "experiments/ui_v63/graph/guide_overlay_v63.py",
    "experiments/ui_v63/graph/server_guide_v63.py",
    "experiments/ui_v63/graph/guide_mapping_audit.json",
    "experiments/ui_v63/graph/guide_navigator_v63.js",
    "experiments/ui_v63/graph/guide_styles_v63.css",
    "experiments/ui_v63/graph/guide_derive_v63.py",
    "experiments/ui_v63/graph/guide_derivation_v63.json",
    "experiments/ui_v63/graph/guide_v62_archive.zip",
    "matryoshka_demo_v6/guide_runtime_v63.py",
    "scripts/derive_graph_full_v6.py",
    "experiments/ui_v63/graph/guide_canonical_derivation_v63.json",
)
_MODULES = OrderedDict()
_LOCK = RLock()
DERIVER = "scripts/derive_graph_full_v6.py"
OVERLAY = "experiments/ui_v63/graph/guide_overlay_v63.py"


def _path(root, relative):
    path = root / relative
    if path.resolve() != path or not path.is_relative_to(root):
        raise ValueError("Guide runtime paths must remain inside the checkout without symlinks")
    return path


def _module(root, relative, expected=None):
    path = _path(root,relative)
    raw = path.read_bytes()
    checksum = sha256(raw).hexdigest()
    if expected is not None and checksum != expected:
        raise ValueError("Pinned guide helper source changed")
    key = str(root),relative,checksum
    with _LOCK:
        if key not in _MODULES:
            spec = importlib.util.spec_from_file_location("_sealed_guide_v63_"+checksum,path)
            if spec is None or spec.loader is None:
                raise ValueError("Cannot load bound guide helper")
            module = importlib.util.module_from_spec(spec)
            # Execute the exact checked source, not a possibly stale .pyc or a
            # second unverified file read. No sys.path mutation or cwd lookup.
            exec(compile(raw,str(path),"exec"),module.__dict__)
            _MODULES[key] = module
            while len(_MODULES)>4:
                _MODULES.popitem(last=False)
        _MODULES.move_to_end(key)
        return _MODULES[key]


def validate(root):
    root = Path(root).resolve()
    if root != Path(__file__).resolve().parents[1]:
        raise ValueError("Guide runtime must use its owning checkout")
    deriver = _module(root,DERIVER)
    payload = deriver.load_manifest(root)
    return dict(version="sealed-guide-runtime/6.3", files=list(FILES),
        manifest=dict(path=str(_path(root,deriver.MANIFEST_PATH).relative_to(root)),sha256=deriver.MANIFEST_SHA256),
        runtime_sha256=payload["runtime"])


def overlay(root, reference, case, packet, *, excluded_documents=()):
    """Production endpoint facade; helpers retain their sealed staging paths."""
    root = Path(root).resolve()
    receipt = validate(root)
    helper = _module(root,OVERLAY,receipt["runtime_sha256"][OVERLAY])
    return helper.overlay(root,reference,case,packet,excluded_documents=excluded_documents)
