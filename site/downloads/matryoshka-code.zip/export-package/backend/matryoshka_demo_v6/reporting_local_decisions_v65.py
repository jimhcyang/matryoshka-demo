"""New, bounded local sufficiency decisions, never frozen native verdicts.

evaluate(root, report, record) returns record.local_decisions_v65. The pure
derive(record, case, eligible_index) core takes one saved condition and a hash-bound
read-only SQLite source index, native Eligible view, or complete in-memory page
mapping. No paths, keys, grades, model reviews, graph labels or rank scores are
read. The complete index is needed for whole-cable handling vetoes.

The local V6.1 parser/matcher is reused without modifying its functions. An
additional definite-NP modifier adapter rechecks explicit source adjectives:
it certifies only the focal property, not the surrounding action. Source title
location and directly attached relative-clause predicates may bind an owner's
explicit qualifiers; neither co-occurrence nor a generated label may do so.
"""
from collections.abc import Mapping
from copy import deepcopy
from datetime import date
import json
import re

from matryoshka_demo.io import digest, offline


VERSION = "local-evidence-sufficiency/6.5.2"
FIELD = "local_decisions_v65"
BACKED = "evidence_backed_suggestion"
PARTIAL = "partial_grounding"
CONTEXT = "exploratory_contextual"
INCOMPATIBLE = "incompatible_not_viable"
LABELS = {BACKED: "Evidence-backed suggestion", PARTIAL: "Partial grounding",
          CONTEXT: "Exploratory / contextual", INCOMPATIBLE: "Incompatible / not viable"}
FIELDS = ("actor", "predicate", "object", "quantity", "event_date", "location",
          "polarity", "uncertainty", "attribution")
FIELD_LABELS = dict(actor="Same actor / property owner", predicate="Required predicate / property",
    object="Same object / relationship", quantity="Required quantity", event_date="Event date / temporal scope",
    location="Required location", polarity="Assertion polarity", uncertainty="Uncertainty / modality",
    attribution="Assertion / attribution scope")
GOOD = {"MATCH", "UNSPECIFIED"}


def _check(identity, label, state, detail):
    return dict(id=identity, label=label, state=state, detail=detail)


def _case(case):
    result = {k: case[k] for k in ("case_id", "task", "corpus", "document_id", "date", "query")}
    result["focal_marker"] = case.get("focal_marker", "")
    if result["task"] not in {"redaction", "hypothesis", "reconstruction"}:
        raise ValueError("Unknown sufficiency task")
    date.fromisoformat(result["date"])
    if not isinstance(result["query"], str) or not result["query"].strip():
        raise ValueError("A public source-scoped query is required")
    return result


def _pages(index, case):
    if isinstance(index, Mapping):
        pages = list(index.values())
        masks = {p["id"]: True for p in pages}
    elif hasattr(index, "execute"):
        # Read the complete bound index, including hidden-by-policy siblings,
        # solely to veto a cable with any internal NOFORN segment.
        pages = [json.loads(r[0]) for r in index.execute("SELECT payload FROM main.page")]
        masks = {p["id"]: True for p in pages}
    elif hasattr(index, "page_mask") and hasattr(index, "corpus"):
        pages = list(index.corpus.pages)
        masks = {p["id"]: bool(index.page_mask[i]) for i, p in enumerate(pages)}
    else:
        raise ValueError("Supply the bound eligible source index, not a private path")
    by_id, veto = {}, set()
    for page in pages:
        if page["id"] in by_id:
            raise ValueError("Ambiguous canonical source page")
        by_id[page["id"]] = page
        if case["corpus"] != "cib" and (re.search(r"\bNOFORN\b", page["text"], re.I)
                or any("NOFORN" in str(h).upper() for h in page.get("handling", []))):
            veto.add(page["document_id"])
    return by_id, masks, veto


def _quote(ref, pages, masks, veto, case):
    page = pages.get(ref.get("canonical_page_id"))
    if page is None or not masks.get(page["id"]):
        raise ValueError("Quote is outside the supplied eligible index")
    date.fromisoformat(page["date"])
    if (page.get("permitted") is not True or page.get("corpus") != case["corpus"]
            or page["document_id"] == case["document_id"] or page["date"] >= case["date"]
            or page.get("visibility") not in {None, "earlier", "both"}
            or page["document_id"] in veto):
        raise ValueError("Quote fails cutoff, whole-origin, visibility or handling policy")
    if case["corpus"] != "cib" and page.get("classification") != "CONFIDENTIAL":
        raise ValueError("Cable evidence must be CONFIDENTIAL, not an origin SECRET body")
    a, b = ref.get("start"), ref.get("end")
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != ref.get("text") or digest(page["text"]) != ref.get("page_sha256")
            or page.get("source_sha256") != ref.get("page_sha256")
            or ref.get("document_id") != page["document_id"] or ref.get("date") != page["date"]):
        raise ValueError("Raw quote, offsets, document, date or page hash does not replay")
    return page


def _citation(page, start, end):
    return dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
                start=start, end=end, text=page["text"][start:end], page_sha256=page["source_sha256"])


def _references(item):
    refs = []
    # These containers supply coordinates only, never saved support labels.
    for key in ("sources", "evidence", "exploratory_passages"):
        for row in item.get(key, []):
            if not isinstance(row, dict):
                continue
            ref = row.get("citation", row)
            if isinstance(ref, dict) and "canonical_page_id" in ref:
                refs.append({k: ref.get(k) for k in ("canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256")})
    return list({digest(ref): ref for ref in refs}.values())


def _owner_phrase(phrase, property_proof):
    value = deepcopy(phrase)
    removed = {p["lemma"] for p in value["proofs"] if p["start"] == property_proof["start"]}
    value["proofs"] = [p for p in value["proofs"] if p["start"] != property_proof["start"]]
    for field in ("terms", "names", "descriptive_terms", "role_qualifiers"):
        value[field] = [v for v in value.get(field, []) if v not in removed]
    return value


def _property_match(target, page, engine):
    """A direct definite-NP description, never an inferred completed event."""
    if target["kind"] != "PROPERTY" or target.get("copula") is not None:
        return []
    owners = target["roles"].get("owner", [])
    if len(owners) != 1 or owners[0]["unresolved"]:
        return []
    from matryoshka_demo_v61.scope_matching import matching
    from matryoshka_demo_v6.task_execution import MASK
    wanted = owners[0]
    results = []
    blocks = [(m.start(), engine.parse(m.group())) for m in re.finditer(r"\S[\s\S]*?(?=\n[ \t]*\n|\Z)", page["text"])]
    for offset, token in ((offset, token) for offset, block in blocks for token in block):
        owner = token.head
        if (token.dep_ != "amod" or token.pos_ != "ADJ" or token.lemma_.casefold() != target["predicate"]
                or owner.pos_ not in {"NOUN", "PROPN"} or owner.lemma_.casefold() != wanted["head"]
                or not any(c.dep_ == "det" and c.lower_ == "the" for c in owner.children)):
            continue
        proof = matching.proof(token)
        offered = _owner_phrase(matching.phrase(owner), proof)
        owner_proofs = [proof, *offered["proofs"]]
        if MASK.search(page["text"][offset + min(p["start"] for p in owner_proofs):
                                     offset + max(p["end"] for p in owner_proofs)]):
            continue
        qualifiers = matching.qualifiers(token)
        nominal_scopes = all(any(a.pos_ == "NOUN" and a.lemma_.casefold() == s["predicate"]
                                 for a in token.ancestors) and not s.get("speakers")
                             for s in qualifiers["scope"])
        certain = not (qualifiers["negated"] or qualifiers["modality"] or qualifiers["conditional"]
            or qualifiers["question"] or qualifiers["epistemic_absence"] or qualifiers["unresolved"]
            or qualifiers["attribution"] or not nominal_scopes
            or any(c.dep_ in {"advmod", "neg"} for c in token.children)
            or any(c.lemma_.casefold() in {"alleged", "possible", "purported", "imaginary", "fake", "suspected"}
                   for c in owner.children))
        prior = page["text"][:offset].rstrip().split("\n\n")[-1]
        if prior and matcher_reporting_block(prior, engine):
            certain = False
        identity = (not offered["unresolved"] and set(wanted["names"]) == set(offered["names"])
                    and wanted["quantifiers"] == offered["quantifiers"]
                    and wanted["role_qualifiers"] == offered["role_qualifiers"])
        # Every overt owner discriminator must replay. A direct relative
        # predicate can license its participial modifier, not a new action.
        relatives = [c for c in owner.children if c.dep_ == "relcl" and c.pos_ == "VERB"
                     and not any(x.dep_ in {"neg", "aux"} and x.lower_ not in {"has", "have", "had"}
                                 for x in c.children)]
        available = {p["lemma"] for p in offered["proofs"]}
        owner_terms = all(p["lemma"] in available or p["pos"] == "VERB" and
                          any(c.lemma_.casefold() == p["lemma"] for c in relatives)
                          for p in wanted["proofs"])
        names = {p["lemma"] for p in offered["proofs"] if p["pos"] in {"NOUN", "PROPN", "NUM", "ADJ"}}
        identity = identity and names <= {p["lemma"] for p in wanted["proofs"]}
        location_ok, context = True, []
        heading = page["text"].split("\n", 1)[0]
        for modifier in wanted.get("modifiers", []):
            exact = any(m["relation"] == modifier["relation"] and matching.parent.phrase_matches(
                modifier["phrase"], m["phrase"]) for m in offered.get("modifiers", []))
            if not exact:
                phrase = modifier["phrase"]["text"]
                pattern = r"\b" + re.escape(modifier["relation"] + " " + phrase) + r"\b"
                # Title scope is available only for a unique, non-conflicting
                # literal location, not arbitrary whole-page co-occurrence.
                exact = (modifier["relation"] in {"in", "at"} and not offered.get("modifiers")
                         and bool(re.search(pattern, heading, re.I)))
                if exact:
                    context.append(_citation(page, 0, len(heading)))
            location_ok = location_ok and exact
        checks = [ _check("actor", FIELD_LABELS["actor"], "pass" if identity and owner_terms else "missing",
                          "Exact owner and every visible discriminator; direct attached relative wording is retained."),
            _check("predicate", FIELD_LABELS["predicate"], "pass", "The adjective is directly attached to this source owner."),
            _check("location", FIELD_LABELS["location"], "pass" if location_ok else "missing",
                   "Required owner locations must be literal attachments or an explicit single-source title scope."),
            _check("uncertainty", FIELD_LABELS["uncertainty"], "pass" if certain else "missing",
                   "A definite source-described property only; uncertain, quoted, conditional or reported property is not upgraded."),
            _check("polarity", FIELD_LABELS["polarity"], "pass" if not qualifiers["negated"] else "missing",
                   "No negation is erased; this rule never infers opposite-polarity evidence.")]
        target_q = target["qualifiers"]
        target_scope = not any(target_q.get(k) for k in ("scope", "attribution", "modality", "conditional", "question", "epistemic_absence", "unresolved", "negated"))
        checks.append(_check("attribution", FIELD_LABELS["attribution"], "pass" if target_scope else "missing",
                             "The focal property must not demand a distinct speaker, modality or report scope."))
        checks.append(_check("event_date", FIELD_LABELS["event_date"], "pass" if not target["event_dates"] and not target.get("deictic_time") else "missing",
                             "Publication date never substitutes for a required property/event date."))
        checks.append(_check("object", FIELD_LABELS["object"], "pass" if set(target["roles"]) <= {"owner"} else "missing",
                             "This adapter establishes only the owner's property, not another object or surrounding action."))
        checks.append(_check("quantity", FIELD_LABELS["quantity"], "pass" if identity else "missing",
                             "Owner quantifiers must match literally."))
        established = all(c["state"] == "pass" for c in checks)
        results.append(dict(direction="Support" if established else "Partial", checks=checks,
            citations=[_citation(page, offset + token.sent.start_char, offset + token.sent.end_char), *context],
            adapter="EXPLICIT_DEFINITE_NP_PROPERTY/6.5", surrounding_event_established=False,
            explanation="Source-described property of the bound owner; no completion of the surrounding later action is asserted."))
    return results


def matcher_reporting_block(text, engine):
    from matryoshka_demo_v6.task_execution import _reporting_block
    return _reporting_block(text, engine.parse)


def _actor_scope(target, match):
    """A common category/head is not a certificate for an actual actor."""
    role = "owner" if target["kind"] in {"PROPERTY", "NOMINAL_RELATION"} else "agent"
    actors = target["roles"].get(role, [])
    if not actors:
        return True, "No actor/owner is specified by this target; none is invented."

    def named_scope(phrase):
        return bool(phrase.get("names")) or any(named_scope(m["phrase"]) for m in phrase.get("modifiers", []))

    aligned = [row for row in match["bindings"].get("argument_matches", []) if row["role"] == role]
    scoped = (match["diagnostics"]["actor"]["status"] == "MATCH" and len(aligned) == len(actors)
              and all(row["status"] == "EXACT_SCOPED_ARGUMENT" and row.get("source")
                      and named_scope(row["target"]) and named_scope(row["source"]) for row in aligned))
    return scoped, ("Literal named actor/possessor/location discriminators replay within the same typed argument."
                    if scoped else "A common actor/owner head or category match does not bind the actual participant; explicit source-scoped identifying discriminators are required.")


def _integral_grounding(target, match, actor_scoped):
    """Require one scoped substantive relationship, not generic overlap."""
    diagnostics = match["diagnostics"]
    if not actor_scoped or diagnostics["predicate"]["status"] != "MATCH":
        return False
    # A required object/purpose cannot be replaced by a different goal, a
    # matching number/date elsewhere, or a generic intention predicate.
    if diagnostics["object"].get("target"):
        return diagnostics["object"]["status"] == "MATCH"
    if target["kind"] == "PROPERTY":
        return diagnostics["actor"]["status"] == "MATCH"
    if match["direction"] in {"SUPPORT", "COUNTER"}:
        return True  # A complete intransitive assertion needs no invented object.
    return any(diagnostics[key]["status"] == "MATCH" for key in ("quantity", "event_date", "location"))


def _match(target, source, page, engine, matcher):
    match = matcher.compare_frames(target, source, engine=engine)
    if match is None:
        return None
    direction = {"SUPPORT": "Support", "COUNTER": "Counterevidence", "PARTIAL": "Partial"}.get(match["direction"], "Context")
    checks = []
    for key in FIELDS:
        status = match["diagnostics"].get("modality" if key == "uncertainty" else key, {}).get("status")
        state = "pass" if status in GOOD else "conflict" if status == "OPPOSED" and direction == "Counterevidence" else "missing"
        checks.append(_check(key, FIELD_LABELS[key], state,
                             "Not required by this target." if status == "UNSPECIFIED" else str(status or "No typed check returned").replace("_", " ").capitalize()))
    if direction == "Support" and not all(c["state"] == "pass" for c in checks):
        direction = "Partial"
    actor_scoped, actor_detail = _actor_scope(target, match)
    integral = _integral_grounding(target, match, actor_scoped)
    if not actor_scoped:
        for check in checks:
            if check["id"] == "actor" and check["state"] == "pass":
                check.update(state="missing", detail="Lexical argument/head match only; the actual participant is not source-scoped.")
    checks.append(_check("actor_scope", "Actual actor / owner binding", "pass" if actor_scoped else "missing", actor_detail))
    checks.append(_check("integral_evidence", "Integral queried relationship", "pass" if integral else "missing",
        "One witness grounds the required object/purpose, scoped property, event discriminator or complete bound intransitive assertion."
        if integral else "Generic actor/predicate overlap is context only. The required object or purpose must match in the same witness; unrelated quantities, dates and countries cannot substitute for it."))
    if ((direction in {"Support", "Counterevidence"} and not actor_scoped)
            or (direction == "Partial" and not integral)):
        direction = "Context"
    value = dict(direction=direction, checks=checks,
        citations=[_citation(page, source["start"], source["end"])], adapter="SOURCE_SCOPED_MATCHER/6.1",
        surrounding_event_established=target["kind"] == "EVENT" and direction == "Support",
        explanation="; ".join(reason.replace("_", " ").capitalize() for reason in match["reasons"]))
    projection = match.get("derived_disposition")
    if projection:
        value.update(source_modal=projection.get("source_modal"), surrounding_event_established=False,
            derivation_note="Typed capability/disposition conversion only; original source modal "
                + str(projection.get("source_modal")) + " is retained as provenance. This does not establish a completed action.")
    return value


def _fact(target, admitted, engine, matcher, number, *, property_recheck=False):
    matches = []
    for page in admitted.values():
        for source in engine.frames(page["text"], antecedents=True):
            if matcher.native.MASK.search(source["quote"]):
                continue
            value = _match(target, source, page, engine, matcher)
            if value:
                matches.append(value)
        if property_recheck:
            matches.extend(_property_match(target, page, engine))
    support = [m for m in matches if m["direction"] == "Support"]
    counter = [m for m in matches if m["direction"] == "Counterevidence"]
    partial = [m for m in matches if m["direction"] == "Partial"]
    coverage = "Established" if support else "Partial" if partial else "Missing"
    context = [m for m in matches if m["direction"] == "Context"]
    same_predicate_context = [m for m in context if any(c["id"] == "predicate" and c["state"] == "pass" for c in m["checks"])]
    preferred = next(iter(support or counter or partial or same_predicate_context or context), None)
    return dict(id="f" + str(number), kind=target["kind"], predicate=target["predicate"],
        text=target["quote"], coverage=coverage, counterevidence=bool(counter),
        direction="Support + Counterevidence" if support and counter else "Support" if support else "Counterevidence" if counter else "Partial" if partial else "Unresolved",
        checks=preferred["checks"] if preferred else [_check(k, FIELD_LABELS[k], "missing", "No eligible typed witness for this requirement.") for k in FIELDS],
        evidence=[m for m in matches if m["direction"] != "Context"],
        context_citations=[c for m in matches if m["direction"] == "Context" for c in m["citations"]],
        aggregation="Every requirement needs a single complete scoped witness; fields from unrelated quotes are not spliced together.")


def _focal_targets(case, fill, reading, engine, matcher):
    targets, reason = matcher.native.old._focal_frames(case, fill, engine)
    if targets or not (reading.get("form") == "modifier" and reading.get("role") == "nominal_property"
                       and reading.get("target_kind") == "property"):
        return targets, reason
    # A separate opaque suffix cannot supply facts, but need not erase a
    # syntactically independent focal adjective. Blank only for parsing.
    mask = matcher.native.MASK
    analysis = mask.sub(lambda m: m.group() if m.group() == case["focal_marker"] else " " * len(m.group()), case["query"])
    targets, reason = matcher.native.old._focal_frames(dict(case, query=analysis), fill, engine)
    raw = case["query"].replace(case["focal_marker"], fill, 1)
    clean = analysis.replace(case["focal_marker"], fill, 1)
    for target in targets:
        if target["kind"] != "PROPERTY" or clean.count(target["quote"]) != 1:
            return [], "Opaque context does not permit an independent focal property"
        offset = clean.index(target["quote"])
        proofs = [target["predicate_proof"], *[p for owner in target["roles"].get("owner", []) for p in owner["proofs"]]]
        a, b = offset + min(p["start"] for p in proofs), offset + max(p["end"] for p in proofs)
        if any(m.start() < b and a < m.end() for m in mask.finditer(raw)):
            return [], "Opaque content intersects the required property/owner binding"
    return targets, reason


def _decision(identity, text, required, targets, issues, refs, case, index, engine, matcher, grammar=None):
    pages, masks, veto = index
    admitted, failures = {}, []
    for ref in refs:
        try:
            page = _quote(ref, pages, masks, veto, case)
            admitted[page["id"]] = page
        except (ValueError, KeyError, TypeError) as error:
            failures.append(str(error))
    facts = [_fact(t, admitted, engine, matcher, i, property_recheck=case["task"] == "redaction")
             for i, t in enumerate(targets, 1)]
    complete = bool(facts) and all(f["coverage"] == "Established" for f in facts)
    counter = any(f["counterevidence"] for f in facts)
    any_support = any(f["coverage"] in {"Established", "Partial"} for f in facts)
    checklist = [_check("provenance", "Eligible raw source provenance", "conflict" if failures else "pass" if admitted else "missing",
                        "; ".join(failures) if failures else "Pinned quotes replay; strict cutoff, whole-origin and whole-cable handling checks passed." if admitted else "No eligible raw source quote was supplied."),
        _check("binding", "Bound query requirements", "pass" if targets and not issues else "missing",
               "; ".join(issues) or ("Focal contribution only; no surrounding event is inferred." if case["task"] == "redaction" else "Every supplied atom is anchored to the public query.")),
        _check("facts", "All required facts grounded", "pass" if complete else "missing",
               "Every typed requirement has a complete eligible witness." if complete else "At least one required owner, predicate, argument or scope remains unestablished."),
        _check("conflicts", "No same-scoped counterevidence", "conflict" if counter else "pass",
               "Explicit opposing polarity for the same scoped requirement is present." if counter else "No explicit same-scoped counterevidence in the inspected sources; absence is not contradiction.")]
    if grammar is not None:
        checklist.append(grammar)
    incompatible = bool(failures) or grammar is not None and grammar["state"] == "conflict" or counter and not any(f["coverage"] == "Established" for f in facts)
    status = BACKED if all(c["state"] == "pass" for c in checklist) else INCOMPATIBLE if incompatible else PARTIAL if any_support else CONTEXT
    needed = [c["detail"] for c in checklist if c["state"] != "pass"]
    if not complete:
        needed.append("An eligible earlier source must connect this exact owner/actor to the required property or action, with its objects, date, polarity, modality and attribution preserved. Identity alone does not prove an action.")
    return dict(id=identity, text=text, required=required, status=status, label=LABELS[status],
        coverage="Established" if complete else "Partial" if any_support else "Missing", counterevidence=counter,
        checklist=checklist, requirements=facts, what_would_suffice=needed or ["These bounded criteria are satisfied; this is not reference-answer correctness or general entailment certification."],
        source_failures=failures, source_pages_checked=sorted(admitted),
        derivation="NEW_REPORTING_DECISION_NOT_FROZEN_NATIVE")


def derive(record, case, eligible_index):
    """Pure, offline supplement. Attach the returned object only under FIELD."""
    from matryoshka_demo_v61 import candidates, scope_matching as matcher
    case = _case(case)
    if record.get("case") is not None and _case(record["case"]) != case:
        raise ValueError("Saved condition belongs to another public query")
    plan, result = record.get("plan", {}), record.get("result", {})
    if plan.get("query_sha256", digest(case["query"])) != digest(case["query"]):
        raise ValueError("Saved query binding changed")
    with offline():
        index = _pages(eligible_index, case)
        engine = matcher.Engine()
        units, covered = [], set()
        if case["task"] == "redaction":
            if not case["focal_marker"] or case["query"].count(case["focal_marker"]) != 1:
                raise ValueError("A unique public focal marker is required")
            for row in result.get("readings", []):
                reading = {k: row.get("reading", {}).get(k) for k in ("id", "form", "role", "target_kind", "grammatical_number", "finite")}
                for candidate in row.get("candidates", []):
                    fill = candidate["fill"]
                    targets, reason = _focal_targets(case, fill, reading, engine, matcher)
                    try:
                        fit = candidates.grammar_admission(case, reading, fill, parse=engine.parse)
                        grammar = _check("grammar", "Rechecked insertion grammar", "pass" if fit["admissible"] else "conflict",
                                         "; ".join(r.replace("_", " ").capitalize() for r in fit.get("reasons", [])) or "The completed focal slot passes the local grammar checks.")
                    except (ValueError, KeyError, TypeError):
                        grammar = _check("grammar", "Rechecked insertion grammar", "missing", "The reading does not supply a supported insertion contract.")
                    engine.disposition_reading = (reading.get("form") == "modifier" and reading.get("role") == "nominal_property" and reading.get("target_kind") == "property")
                    unit = _decision(candidate["id"], fill, True, targets, [] if targets else [reason], _references(candidate),
                                     case, index, engine, matcher, grammar)
                    unit.update(reading_id=reading.get("id"), scope="FOCAL_PROPERTY_ONLY" if targets and all(t["kind"] == "PROPERTY" for t in targets) else "FOCAL_CONTRIBUTION_ONLY")
                    units.append(unit)
        else:
            saved_atoms = {a["id"]: a for a in result.get("atoms", [])}
            for item in plan.get("atoms", []):
                atom = {k: item[k] for k in ("id", "text", "source_quote", "start", "end", "required")}
                a, b = atom["start"], atom["end"]
                valid = type(a) is int and type(b) is int and 0 <= a < b <= len(case["query"]) and case["query"][a:b] == atom["source_quote"]
                targets, issues = matcher._bind(atom, case["query"], engine) if valid else ([], ["Query atom offsets/quotation do not replay."])
                for target in targets:
                    context = target.get("query_context", {})
                    covered.add((target["kind"], target["predicate"], context.get("start", a) + target["predicate_proof"]["start"]))
                units.append(_decision(atom["id"], atom["text"], atom["required"] is not False, targets, issues,
                    _references(saved_atoms.get(atom["id"], {})), case, index, engine, matcher))
        required = [u for u in units if u["required"]]
        if len({u["id"] for u in units}) != len(units):
            raise ValueError("Ambiguous candidate or atom identity in the saved condition")
        coverage_checks = []
        if case["task"] != "redaction":
            raw_targets = engine.targets(case["query"])
            omitted = [(t["kind"], t["predicate"], t["predicate_proof"]["start"]) for t in raw_targets
                       if (t["kind"], t["predicate"], t["predicate_proof"]["start"]) not in covered]
            coverage_checks.append(_check("query_coverage", "Whole-query typed requirement coverage",
                "pass" if raw_targets and not omitted else "missing",
                "Every locally parsed query requirement is represented; this is not semantic-exhaustiveness certification." if raw_targets and not omitted
                else "The plan omits or cannot bind query requirements: " + ", ".join(p[1] for p in omitted)))
        all_backed = bool(required) and all(u["status"] == BACKED for u in required) and all(c["state"] == "pass" for c in coverage_checks)
        overall_status = BACKED if all_backed else PARTIAL if any(u["coverage"] in {"Established", "Partial"} for u in required) else CONTEXT
        if required and all(u["status"] == INCOMPATIBLE for u in required):
            overall_status = INCOMPATIBLE
        if case["task"] != "redaction" and any(u["status"] == INCOMPATIBLE and u["counterevidence"] for u in required):
            overall_status = INCOMPATIBLE
        if case["task"] == "redaction":
            overall_status = BACKED if any(u["status"] == BACKED for u in units) else PARTIAL if any(u["status"] == PARTIAL for u in units) else CONTEXT
            if units and all(u["status"] == INCOMPATIBLE for u in units):
                overall_status = INCOMPATIBLE
        overall = dict(status=overall_status, label=LABELS[overall_status],
            checklist=[_check("required_units", "All required components" if case["task"] != "redaction" else "At least one fully grounded fill",
                              "pass" if all_backed and case["task"] != "redaction" or case["task"] == "redaction" and overall_status == BACKED else "missing",
                              "Conjunction of explicit checks within each component; candidate alternatives are not conjoined."), *coverage_checks],
            coverage="Established" if required and all(u["coverage"] == "Established" for u in required) and all(c["state"] == "pass" for c in coverage_checks) else "Partial" if any(u["coverage"] in {"Established", "Partial"} for u in required) else "Missing",
            established_components=[u["id"] for u in required if u["coverage"] == "Established"],
            missing_components=[u["id"] for u in required if u["coverage"] != "Established"],
            counterevidence=any(u["counterevidence"] for u in required),
            what_would_suffice=["Resolve every missing/conflicting component check with eligible raw source quotations; required chronology or causal bridges need their own scoped facts."] if not all_backed else ["All explicit bounded criteria pass; no key-aware correctness claim is made."])
    packet = dict(version=VERSION, field=FIELD, case_id=case["case_id"], query_sha256=digest(case["query"]),
        config=record.get("config"), derived=True, frozen_native_unchanged=True, keys_read=False, grades_read=False,
        model_calls=0, acceptance_policy="CONJUNCTION_OF_EXPLICIT_APPLICABLE_CRITERIA_NO_SCORE_THRESHOLD",
        source_scope="Raw pages referenced by this saved output, independently rechecked in the supplied bound eligible index; not an exhaustive corpus search.",
        limitations=["A suggestion is not answer-key correctness, a probability, or unrestricted entailment.",
                    "Native support and ranking remain unchanged; unknown evidence never becomes counterevidence.",
                    "Definite-NP property adapter certifies only the described owner/property, never a completed surrounding event."],
        decisions=units, candidates={u["id"]: u for u in units} if case["task"] == "redaction" else {},
        atoms={u["id"]: u for u in units} if case["task"] != "redaction" else {}, overall=overall,
        binding=dict(case_id=case["case_id"], query_sha256=digest(case["query"]), config=record.get("config"),
                     native_run_id=record.get("run_id"), native_checksum=record.get("native_checksum")))
    packet["reading_overviews"] = {}
    if case["task"] == "redaction":
        for rid in dict.fromkeys(u["reading_id"] for u in units):
            choices = [u for u in units if u["reading_id"] == rid]
            status = BACKED if any(u["status"] == BACKED for u in choices) else PARTIAL if any(u["status"] == PARTIAL for u in choices) else CONTEXT
            if choices and all(u["status"] == INCOMPATIBLE for u in choices):
                status = INCOMPATIBLE
            packet["reading_overviews"][rid] = dict(status=status, label=LABELS[status],
                suggested_candidate_ids=[u["id"] for u in choices if u["status"] == BACKED],
                counterevidence=any(u["counterevidence"] for u in choices),
                what_would_suffice=["Each alternative is judged separately; rank and other readings do not discharge this fill's checks."])
    return packet


def evaluate(root, report, record):
    """Integration entry point; call only after the unchanged native record gate."""
    from matryoshka_demo.corpus_explorer_v3 import _connection
    case = _case(record["case"])
    rows = [r for r in report["cases"] if r["case"]["case_id"] == case["case_id"]]
    if len(rows) != 1 or _case(rows[0]["case"]) != case:
        raise ValueError("Local sufficiency case is not this published query")
    reference = report["graph_indexes"][case["corpus"]]
    if (record.get("exploration_index_ref") != reference
            or record.get("source_binding_sha256") != report["source_binding"]["sha256"]):
        raise ValueError("Local sufficiency source index differs from its published binding")
    with offline():
        db = _connection(root, reference)
        try:
            packet = derive(record, case, db)
        finally:
            db.close()
    packet["binding"].update(source_index_sha256=reference["sha256"], source_binding_sha256=report["source_binding"]["sha256"])
    return packet
