"""Invocation-local batch attachment verification, never assessment execution.

response_fields(root, result_ref, conditions) handles one exact sidecar.
verify_fields(root, requests) also groups multiple exact sidecars; each request
has assessment_ref, case_id, config (A/B/C or saved name), and the exact gate.
Both return ordered fields plus a separately pinned batch-verifier receipt.
No trusted handle/cache is returned or retained, and no artifacts are written.
"""
from copy import deepcopy
from pathlib import Path
import re

from matryoshka_demo.io import digest, offline, sha
from . import reporting_decision_assessment_presentation as assessor


VERSION = "sealed-presentation-assessment-batch-verification/1"
MAX_CONDITIONS = 10000


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def helper_binding():
    """Separate derivation pin; never added to the frozen assessor's identity."""
    path = Path(__file__)
    _require(path.resolve(strict=True) == path, "Batch verifier code cannot redirect through a symlink")
    actual = sha(path)
    _require(actual == _IMPORTED_HELPER_SHA256, "Batch verifier bytes changed after import; restart")
    return dict(version=VERSION, code_ref=dict(path=str(path.relative_to(assessor.adapter.CODE_ROOT)), sha256=actual))


def _requests(values):
    _require(isinstance(values, (list, tuple)) and 1 <= len(values) <= MAX_CONDITIONS,
        "Select a nonempty bounded list of requested conditions")
    selected, seen = [], set()
    for value in values:
        _require(isinstance(value, dict) and set(value) == {"assessment_ref", "case_id", "config", "gate"},
            "Each request needs assessment_ref, case_id, config and exact gate")
        cid, config = value["case_id"], value["config"]
        _require(isinstance(cid, str) and bool(cid) and isinstance(config, str), "Explicit case and condition required")
        config = assessor.ARMS.get(config, config)
        _require(config in assessor.ARMS.values() and isinstance(value["gate"], dict), "Active A/B/C condition and gate required")
        _require((cid, config) not in seen, "Duplicate or ambiguous requested condition")
        seen.add((cid, config))
        selected.append(dict(case_id=cid, config=config, assessment_ref=deepcopy(value["assessment_ref"]),
            gate=value["gate"], gate_sha256=digest(value["gate"])))
    return selected


def _artifact_pins(root, reference, value):
    contract = value["identity"]
    _require(contract["api_root"] == assessor.API_ROOT, "Assessment uses another API ledger")
    pins = [assessor._pin(reference), assessor._pin(value["input_ref"]), assessor._pin(value["code_pins_ref"]),
        *deepcopy(contract["pins"])]
    # Raw paid artifacts are pinned by the authenticated sidecar and independently
    # replayed by the frozen verifier. Include them in both boundary checks too.
    for result in value["results"]:
        for relative, pin in result["assessment"]["artifact_sha256"].items():
            _require(isinstance(relative, str) and relative.split("/", 1)[0] in {"cache", "requests", "responses", "receipts"},
                "Unexpected raw assessment artifact group")
            path = assessor._path(assessor._path(root, assessor.API_ROOT), relative)
            pins.append(dict(path=str(path.relative_to(root)), sha256=pin))
    return assessor._distinct_pins(pins)


def _field_indexes(value):
    grades, mappings = {}, {}
    for result in value["results"]:
        case_grades = grades.setdefault(result["case_id"], {})
        case_grades.update({g["id"]:g for g in result["assessment"]["grades"]})
    for mapping in value["mapping"]:
        mappings.setdefault((mapping["case_id"], mapping["config"]), []).append(mapping)
    return grades, mappings


def _field(value, reference, request, indexes):
    """Project exactly the existing field shape from a fully checked sidecar."""
    cid, config = request["case_id"], request["config"]
    grades, mappings = indexes
    return dict(version=assessor.VERSION, gate_version=value["identity"]["gate_version"],
        gate_sha256=request["gate_sha256"],
        grades=[dict(m, grade=grades[cid][m["item_id"]]) for m in mappings.get((cid, config), [])],
        assessment_ref=deepcopy(reference), used_for_inference=False, old_native_grades_used=False,
        independent_human_validation=False, source_only_assessment=True, method_blinded=True)


def _verify(root, requests):
    root = Path(root).resolve()
    binding = helper_binding()
    selected = _requests(requests)
    groups = {}
    for request in selected:
        ref = request["assessment_ref"]
        # Validate literal path/hash before using it as a grouping identity.
        _require(isinstance(ref, dict) and isinstance(ref.get("sha256"), str)
            and re.fullmatch(r"[0-9a-f]{64}", ref["sha256"]) is not None, "An explicit sidecar SHA-256 is required")
        assessor._path(root, ref.get("path"), under=assessor.OUTPUT_ROOT)
        groups.setdefault((ref["path"], ref["sha256"]), []).append(request)
    plans, pins = [], []
    code = assessor._gate_code()
    _require(code == assessor._IMPORTED_CODE, "Assessor dependency bytes changed after import; restart")
    for members in groups.values():
        reference = members[0]["assessment_ref"]
        value = assessor._read(root, reference, under=assessor.OUTPUT_ROOT)
        _require(value["version"] == assessor.VERSION and value["field"] == assessor.FIELD
            and value["sha256"] == digest({k:v for k,v in value.items() if k != "sha256"}), "Assessment sidecar seal differs")
        _require(value["identity"]["gate_code"] == code, "Assessment observer/assessor code binding differs")
        rows = {(g["case_id"], g["config"]):g for g in value["gate_bindings"]}
        _require(len(rows) == len(value["gate_bindings"]), "Duplicate sidecar gate binding")
        for request in members:
            match = rows.get((request["case_id"], request["config"]))
            _require(match is not None, "Unknown assessed case or condition")
            _require(match["gate_sha256"] == request["gate_sha256"], "Assessment belongs to a different exact gate")
        pins.extend(_artifact_pins(root, reference, value))
        plans.append((reference, value, members))
    pins = assessor._distinct_pins(pins)
    assessor._recheck(root, pins, code)
    fields, verified = {}, []
    for reference, value, members in plans:
        anchor = members[0]
        # This is the ORIGINAL verifier, not a weaker replica. It reconstructs
        # all prepared conditions, quotes, code pins and raw responses once.
        first = assessor.response_field(root, reference, case_id=anchor["case_id"], config=anchor["config"], gate=anchor["gate"])
        indexes = _field_indexes(value)
        _require(first == _field(value, reference, anchor, indexes), "Frozen field projection differs from the batch contract")
        for request in members:
            field = _field(value, request["assessment_ref"], request, indexes)
            fields[(request["case_id"], request["config"])] = deepcopy(field)
        verified.append(dict(assessment_ref=deepcopy(reference), conditions=len(members)))
    # No result escapes before every sidecar and requested gate passes a fresh
    # end check. Local state is discarded, including after a failed invocation.
    assessor._recheck(root, pins, code)
    _require(helper_binding() == binding, "Batch verifier code changed during verification")
    for request in selected:
        _require(digest(request["gate"]) == request["gate_sha256"], "Requested gate changed during verification")
    return dict(version=VERSION,
        fields=[dict(case_id=r["case_id"], config=r["config"], field=fields[(r["case_id"], r["config"])]) for r in selected],
        verification=dict(helper_binding=binding, assessor_code_sha256=digest(code),
            sidecars=verified, full_prepared_replays=len(plans), conditions=len(selected),
            start_end_pins_checked=True, api_calls=0, gate_evaluations=0,
            persistent_trust_cache=False, artifacts_modified=False))


def verify_fields(root, requests):
    """All-or-nothing verification across sidecars; no API/evaluation or writes."""
    with offline():
        try:
            return _verify(root, requests)
        except (KeyError, TypeError, AttributeError, IndexError, OSError) as error:
            raise ValueError("Malformed or changed batch assessment input") from error


def response_fields(root, result_ref, conditions):
    """Verify one exact sidecar once for [{case_id, config, gate}, ...]."""
    _require(isinstance(conditions, (list, tuple)) and all(isinstance(c, dict)
        and set(c) == {"case_id", "config", "gate"} for c in conditions), "Explicit condition list required")
    return verify_fields(root, [dict(c, assessment_ref=deepcopy(result_ref)) for c in conditions])


_IMPORTED_HELPER_SHA256 = sha(Path(__file__))
