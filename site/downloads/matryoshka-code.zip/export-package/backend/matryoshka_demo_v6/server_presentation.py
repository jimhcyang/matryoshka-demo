"""Explicit source observers with code/input-bound sealed gate replay.

This is a separately versioned server adapter, not frozen native inference or
an edit to server_v65. Unverified embedded/old released gates are never reused.
Inputs bind the verified native checkpoint; old reviews cannot assess new gates.
"""
from collections import OrderedDict
from copy import deepcopy
from pathlib import Path
from threading import RLock
from types import FunctionType

from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.flow_projection_v4 import _bound_path
from matryoshka_demo.io import digest, load, load_gzip, sha
from matryoshka_demo_v61.study import binding as native_code_binding
from . import reporting_fixed_pool_decisions_v65 as frozen
from . import reporting_fixed_pool_decisions_presentation_v3 as presentation
from . import server_v65
from .flow_projection import condition as native_condition


PROTOCOL_VERSION = "explicit-source-observer-dispatch/1"
COMMITMENT_VERSION = "sealed-presentation-gate/1"
INPUT_VERSION = "presentation-gate-input/1"
HASH_ENCODING = "python-json-sorted-ascii-compact/1"
CODE_ROOT = Path(__file__).resolve().parents[1]
ENGINES = {"frozen": frozen, "presentation": presentation}
OMIT_FIELDS = server_v65.REVIEW_ONLY | {
    "local_decisions_v65", "local_decisions_presentation", "local_sufficiency_v65",
    "presentation_criterion", "decision_summary_by_arm", "evaluation_keys", "evaluation_keys_ref",
    "answer_key_ref", "assessment_release_ref", "assessment_ref", "llm_assessment", "llm_review",
    "grades", "grade", "reference_answers", "answer_keys",
    "presentation_gate_commitment", "presentation_observer",
}


def clean_native(value):
    if isinstance(value, dict):
        return {key: clean_native(item) for key, item in value.items() if key not in OMIT_FIELDS}
    if isinstance(value, list):
        return [clean_native(item) for item in value]
    return value


def observer_code():
    # Bind the full frozen dependency closure and all observer siblings. A new
    # sibling cannot silently enter a warm process under an earlier code pin.
    pins = native_code_binding(CODE_ROOT)
    paths = [Path(__file__), CODE_ROOT / "matryoshka_demo_v6/reporting_local_decisions_v65.py",
             CODE_ROOT / "matryoshka_demo_v6/server_v65.py",
             CODE_ROOT / "matryoshka_demo_v6/server.py",
             CODE_ROOT / "matryoshka_demo_v6/flow_projection.py",
             CODE_ROOT / "matryoshka_demo/corpus_explorer_v3.py",
             CODE_ROOT / "matryoshka_demo/flow_projection_v4.py",
             CODE_ROOT / "matryoshka_demo/io.py"]
    paths.extend((CODE_ROOT / "matryoshka_demo_v6").glob("reporting_fixed_pool*.py"))
    for path in paths:
        if path.resolve(strict=True) != path or not path.is_file():
            raise ValueError("Observer code cannot redirect through a symlink")
        pins[str(path.relative_to(CODE_ROOT))] = sha(path)
    return dict(sorted(pins.items()))


_IMPORTED_CODE = observer_code()
_NATIVE_INPUTS = OrderedDict()
_NATIVE_LOCK = RLock()
_NATIVE_FIELDS = ("case", "config", "run_id", "native_checksum", "source_binding_sha256", "exploration_index_ref", "inspected_page_ids")


def reading_identities(record):
    result = record.get("result", {})
    result = result.get("redaction", result)
    return [dict(id=row.get("reading", {}).get("id") or row.get("reading_id") or row.get("id"),
        candidates=[dict(id=c.get("id"), fill=c.get("fill")) for c in row.get("candidates", [])])
        for row in result.get("readings", [])]


class DecisionObserver:
    def __init__(self, root, engine, *, engine_protocol_version=None, cache_limit=12, allow_preview_compute=False):
        if engine not in ENGINES:
            raise ValueError("Choose decision engine frozen or presentation explicitly")
        if engine_protocol_version is not None and engine_protocol_version != PROTOCOL_VERSION:
            raise ValueError("Decision engine protocol version differs from this adapter")
        if type(cache_limit) is not int or cache_limit < 1:
            raise ValueError("Positive bounded observer cache size required")
        if type(allow_preview_compute) is not bool:
            raise ValueError("Preview compute permission must be explicit")
        self.root = Path(root).resolve()
        self.engine = engine
        self.module = ENGINES[engine]
        self.code = deepcopy(_IMPORTED_CODE)
        self.code_sha256 = digest(self.code)
        self.cache_limit = cache_limit
        self.allow_preview_compute = allow_preview_compute
        self.cache, self.lock = OrderedDict(), RLock()
        self.check_code()
        scope = dict(server_v65.Handler.study_api.__globals__, condition=self.condition)
        old = server_v65.Handler.study_api
        self.dispatch = FunctionType(old.__code__, scope, old.__name__, old.__defaults__, old.__closure__)
        self.dispatch.__kwdefaults__ = deepcopy(old.__kwdefaults__)

    def check_code(self):
        if observer_code() != self.code:
            raise ValueError("Observer code/file-set changed; restart with an explicit new code pin")

    def manifest(self):
        return dict(decision_engine=self.engine, engine_protocol_version=PROTOCOL_VERSION,
            gate_version=self.module.VERSION, observer_engine_version=self.module.ENGINE_VERSION,
            observer_module=self.module.__name__, observer_code_sha256=self.code_sha256,
            observer_code=deepcopy(self.code),
            sealed_bound_gate_replay=True, unverified_embedded_gates_used=False,
            gate_policy="preview-compute" if self.allow_preview_compute else "sealed",
            old_decision_releases_used=False, old_grades_assess_new_gate=False,
            new_exact_gate_review_status="PENDING")

    def source_binding(self, report, record, case):
        binding_path = self.root / "data/bindings.json"
        if binding_path.resolve(strict=True) != binding_path:
            raise ValueError("Source binding cannot redirect through a symlink")
        byte_pin = sha(binding_path)
        binding = load(binding_path)
        if (binding != report["source_binding"]
                or binding.get("sha256") != digest({k: v for k, v in binding.items() if k != "sha256"})
                or record.get("source_binding_sha256") != binding["sha256"]):
            raise ValueError("Selected observer source binding differs from current pinned sources")
        reference = report["graph_indexes"][case["corpus"]]
        if record.get("exploration_index_ref") != reference:
            raise ValueError("Selected observer source index differs from the native record")
        db = _connection(self.root, reference)
        db.close()
        if sha(binding_path) != byte_pin:
            raise ValueError("Source binding changed during its verification")
        return byte_pin

    def verified_input(self, report, record, case):
        self.check_code()
        checkpoint = record["native_checkpoint"]
        path, stamp = _bound_path(self.root, checkpoint, "data/runs_v6")
        native_key = (str(path), checkpoint["sha256"], stamp, self.code_sha256)
        with _NATIVE_LOCK:
            cached = deepcopy(_NATIVE_INPUTS.get(native_key))
        if cached is not None:
            if (any(cached["bindings"][field] != (case if field == "case" else record.get(field)) for field in _NATIVE_FIELDS)
                    or cached["plan_sha256"] != digest(clean_native(record.get("plan", {})))
                    or cached["candidate_order_sha256"] != digest(reading_identities(record))):
                raise ValueError("Cached native checkpoint and displayed condition inputs differ")
            source_byte_pin = self.source_binding(report, record, case)
            inputs = dict(deepcopy(cached["input_manifest"]), source_binding_byte_sha256=source_byte_pin)
            return inputs, None
        raw = load_gzip(path)
        for field in _NATIVE_FIELDS:
            if raw.get(field) != (case if field == "case" else record.get(field)):
                raise ValueError("Native checkpoint and displayed condition binding differ: " + field)
        if (digest(raw["result"]) != raw["native_checksum"]
                or clean_native(raw.get("plan", {})) != clean_native(record.get("plan", {}))
                or reading_identities(raw) != reading_identities(record)
                or raw.get("keys_read") is not False or raw.get("grades_read") is not False):
            raise ValueError("Native checksum, plan, candidate order or no-key/no-grade binding changed")
        clean = clean_native(raw)
        source_byte_pin = self.source_binding(report, clean, case)
        manifest = dict(version=INPUT_VERSION, case=deepcopy(case), query_sha256=digest(case["query"]),
            config=clean["config"], native_run_id=clean["run_id"], native_checksum=clean["native_checksum"],
            native_checkpoint=deepcopy(checkpoint), source_index=deepcopy(report["graph_indexes"][case["corpus"]]),
            source_binding_sha256=report["source_binding"]["sha256"], source_binding_byte_sha256=source_byte_pin,
            inspected_page_ids_sha256=digest(clean["inspected_page_ids"]),
            plan_sha256=digest(clean.get("plan", {})), candidate_order_sha256=digest(reading_identities(clean)),
            clean_native_sha256=digest(clean))
        # Cache only small verified descriptors, never complete flow snapshots.
        # Every warm access still replays the checkpoint byte/stamp and source
        # guards before consulting a gate, including sealed packet replay.
        cached = dict(bindings={field: deepcopy(raw.get(field)) for field in _NATIVE_FIELDS},
            plan_sha256=manifest["plan_sha256"], candidate_order_sha256=manifest["candidate_order_sha256"],
            input_manifest=deepcopy(manifest))
        with _NATIVE_LOCK:
            _NATIVE_INPUTS[native_key] = cached
            _NATIVE_INPUTS.move_to_end(native_key)
            while len(_NATIVE_INPUTS) > 12:
                _NATIVE_INPUTS.popitem(last=False)
        return manifest, clean

    def check_gate(self, gate, inputs):
        expected = dict(case_id=inputs["case"]["case_id"], config=inputs["config"], query_sha256=inputs["query_sha256"],
            native_run_id=inputs["native_run_id"], native_checksum=inputs["native_checksum"],
            source_index_sha256=inputs["source_index"]["sha256"], source_binding_sha256=inputs["source_binding_sha256"])
        if (not isinstance(gate, dict) or gate.get("version") != self.module.VERSION
                or any(gate.get(k) != expected[k] for k in ["case_id", "config", "query_sha256"])
                or any(gate.get("binding", {}).get(k) != v for k, v in expected.items())
                or gate.get("derived") is not True or gate.get("frozen_native_unchanged") is not True
                or gate.get("keys_read") is not False or gate.get("grades_read") is not False
                or type(gate.get("model_calls")) is not int or gate["model_calls"] != 0):
            raise ValueError("Selected observer gate has different provenance, query/native/source binding or version")

    def commitment(self, report, record, gate):
        """Build-time only: no evaluation, grading or artifact writes.

        The caller seals this alongside the complete gate in case_detail_ref.
        The authenticated outer report/detail byte pins are the trust boundary;
        this self-digest alone is not an independent attestation of correctness.
        """
        inputs, _ = self.verified_input(report, record, record["case"])
        self.check_gate(gate, inputs)
        value = dict(version=COMMITMENT_VERSION, engine=self.engine, engine_protocol_version=PROTOCOL_VERSION,
            gate_version=self.module.VERSION, observer_engine_version=self.module.ENGINE_VERSION,
            observer_code_sha256=self.code_sha256, observer_code=deepcopy(self.code), hash_encoding=HASH_ENCODING,
            input_manifest=inputs, input_manifest_sha256=digest(inputs), gate_content_sha256=digest(gate))
        value["sha256"] = digest(value)
        return value

    def replay(self, commitment, gate, inputs):
        if (not isinstance(commitment, dict) or commitment.get("sha256") != digest({k: v for k, v in commitment.items() if k != "sha256"})
                or commitment.get("version") != COMMITMENT_VERSION or commitment.get("engine") != self.engine
                or commitment.get("engine_protocol_version") != PROTOCOL_VERSION
                or commitment.get("gate_version") != self.module.VERSION
                or commitment.get("observer_engine_version") != self.module.ENGINE_VERSION
                or commitment.get("observer_code") != self.code or commitment.get("observer_code_sha256") != self.code_sha256
                or commitment.get("hash_encoding") != HASH_ENCODING
                or commitment.get("input_manifest") != inputs or commitment.get("input_manifest_sha256") != digest(inputs)
                or commitment.get("gate_content_sha256") != digest(gate)):
            raise ValueError("Sealed presentation gate code/input/content commitment differs; no compute fallback")
        self.check_gate(gate, inputs)
        return deepcopy(gate)

    def condition(self, root, report, case_id, arm):
        if Path(root).resolve() != self.root:
            raise ValueError("Decision observer belongs to another source root")
        self.check_code()
        value = native_condition(self.root, report, case_id, arm)
        if value.get("status") == "PENDING":
            return value
        case = value["case"]
        safe_report = dict(cases=[dict(case=deepcopy(case))], graph_indexes=deepcopy(report["graph_indexes"]),
            source_binding=deepcopy(report["source_binding"]))
        for record in value.get("configurations", {}).values():
            inputs, clean = self.verified_input(report, record, case)
            committed = "presentation_gate_commitment" in record
            sealed_gate = self.replay(record["presentation_gate_commitment"], record.get("local_decisions_v65"), inputs) if committed else None
            if not committed and not self.allow_preview_compute:
                raise ValueError("Missing sealed presentation gate; only explicit PREVIEW compute may evaluate")
            identity = dict(protocol=PROTOCOL_VERSION, engine=self.engine, observer_code=self.code_sha256,
                gate_version=self.module.VERSION, inputs=digest(inputs),
                replay="SEALED_BOUND_PACKET" if committed else "EXPLICIT_PREVIEW_COMPUTE",
                commitment_sha256=record["presentation_gate_commitment"]["sha256"] if committed else None)
            key = digest(identity)
            with self.lock:
                gate = deepcopy(self.cache.get(key))
            cache_hit = gate is not None
            if gate is None:
                if committed:
                    gate = sealed_gate
                else:
                    if clean is None:
                        path, _ = _bound_path(self.root, inputs["native_checkpoint"], "data/runs_v6")
                        clean = clean_native(load_gzip(path))
                        if digest(clean) != inputs["clean_native_sha256"]:
                            raise ValueError("Native observer input differs from the verified descriptor")
                    gate = self.module.evaluate(self.root, safe_report, clean)
            # Repeat cheap pins even on warm hits and after observer execution.
            self.check_code()
            _bound_path(self.root, inputs["native_checkpoint"], "data/runs_v6")
            if self.source_binding(report, clean if clean is not None else record, case) != inputs["source_binding_byte_sha256"]:
                raise ValueError("Observer source binding changed during evaluation")
            self.check_gate(gate, inputs)
            with self.lock:
                self.cache[key] = deepcopy(gate)
                self.cache.move_to_end(key)
                while len(self.cache) > self.cache_limit:
                    self.cache.popitem(last=False)
            record["local_decisions_v65"] = gate
            record["local_decision_assessment_v65"] = dict(status="PENDING", used_for_inference=False,
                gate_version=gate["version"], old_native_grades_used=False,
                reason="The selected source observer has no separately bound exact-gate review. Old native grades do not assess this decision.")
            record["presentation_observer"] = dict(**self.manifest(), cache_key=key, cache_hit=cache_hit,
                replay=identity["replay"], gate_content_sha256=digest(gate))
        value["presentation_pipeline_version"] = PROTOCOL_VERSION
        return value


class Handler(server_v65.Handler):
    """Caller owns report lookup; dispatch retains all existing flow/source APIs."""
    def __init__(self, *args, observer, **kwargs):
        self.decision_observer = observer
        super().__init__(*args, **kwargs)

    def study_api(self, path, params):
        return self.decision_observer.dispatch(self, path, params)
