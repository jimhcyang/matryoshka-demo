"""Versioned compressed development runs; no old run is modified or resealed."""
from contextlib import ExitStack
from copy import deepcopy
import fcntl
import gc
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import time
import zipfile

from matryoshka_demo.contracts import public_case
from matryoshka_demo.corpus import Corpus
from matryoshka_demo.corpus_policy_v5 import policy_view
from matryoshka_demo.integrity import source_objects, verify_sources
from matryoshka_demo.io import digest, disk_guard, load, load_gzip, offline, rows, save, save_gzip, sha
from .planning import prepare as prepare_question, get_plans, validate_plan
from matryoshka_demo.runner_v2 import environment_binding


VERSION = "atomic-only-three-task-study/6"
ARMS = ("llm_readings", "llm_atoms", "llm_local")
ORIGINAL_PREFIX = "original_src/"
ORIGINAL_DIRECTORIES = ()
ORIGINAL_RESOURCES = ()
CHECKPOINT_VERSION = "compressed-native-checkpoint-pin/6"


def _bound(base, name):
    path = (base / name).resolve()
    if not path.is_relative_to(base.resolve()):
        raise ValueError("Artifact path escapes its bound directory")
    return path


def _code_path(root, name):
    if name.startswith(ORIGINAL_PREFIX):
        relative = name.removeprefix(ORIGINAL_PREFIX)
        path = _bound(root.parent, relative)
        if relative not in ORIGINAL_RESOURCES and not any(
                path.is_relative_to(root.parent / directory) for directory in ORIGINAL_DIRECTORIES):
            raise ValueError("Unbound original source code")
        return path
    return _bound(root, name)


def binding(root):
    root = Path(root).resolve()
    excluded = ("server", "reporting", "assessment", "ui_release", "corpus_explorer", "flow_projection", "digest", "guide")
    result = {str(p.relative_to(root)): sha(p) for package in ("matryoshka_demo", "matryoshka_demo_v6")
        for p in (root / package).rglob("*.py")
        if not p.name.startswith(excluded) and p.name not in {"api_v2.py", "cli.py"}}
    for p in (root / "contracts").rglob("*"):
        if p.is_file() and p.suffix in {".json", ".txt"}:
            result[str(p.relative_to(root))] = sha(p)
    for directory in ORIGINAL_DIRECTORIES:
        source = root.parent / directory
        if not source.is_dir():
            raise ValueError("Original src code directory is missing: " + directory)
        for p in sorted(source.rglob("*.py")):
            name = ORIGINAL_PREFIX + str(p.relative_to(root.parent))
            result[name] = sha(_code_path(root, name))
    for name in ORIGINAL_RESOURCES:
        result[ORIGINAL_PREFIX + name] = sha(_code_path(root, ORIGINAL_PREFIX + name))
    return dict(sorted(result.items()))


def check_code(root, expected):
    changed = [name for name, expected_sha in expected.items()
               if not _code_path(root, name).is_file() or sha(_code_path(root, name)) != expected_sha]
    if not changed and binding(root) != expected:
        changed = ["execution file set"]
    if changed:
        raise RuntimeError("Native code changed; preserve this checkpoint and start a new version: " + repr(changed))


def _public_flags(value):
    if isinstance(value, dict):
        for name, child in value.items():
            if name in {"keys_read", "grades_read", "inference_network_access"} and child is not False:
                raise ValueError("Private inputs or network access are not permitted in native runs")
            if name in {"evaluation_keys", "evaluation_keys_ref", "answer_key_ref", "assessment_release_ref"}:
                raise ValueError("Hidden key references are not native inputs")
            _public_flags(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            _public_flags(child)


def catalog(root, path):
    path = Path(path).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Catalog must be workspace-bound")
    value = load(path)
    _public_flags(value)
    if value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"}):
        raise ValueError("Public development catalog changed")
    cases = value["cases"]
    if not cases or len({c["case_id"] for c in cases}) != len(cases) or any(public_case(c) != c for c in cases):
        raise ValueError("Cases must be unique public inputs without answer fields")
    if value["binding_sha256"] != load(root / "data/bindings.json")["sha256"]:
        raise ValueError("Catalog and source bindings disagree")
    return value


def plan(root, catalog_path, *, execute=False, cap=25.):
    root = Path(root).resolve()
    value = catalog(root, catalog_path)
    if not execute:
        return dict(cases=len(value["cases"]), maximum_base_requests=3*len(value["cases"]), api_calls=0)
    plans = {}
    for case in value["cases"]:
        bundle = prepare_question(case, api_root=root / "data/development_v2/api", execute=True,
            approved_targets=tuple(c["case_id"] for c in value["cases"]), cap=cap, model_profile="sol")
        if bundle["status"] != "READY":
            failure = root / "data/development_v6/failures" / (case["case_id"] + "__" + digest(bundle)[:16] + ".json")
            save(failure, bundle)
            raise ValueError("Planning failed; preserved diagnostic: " + str(failure))
        ref = root / "data/development_v6/bundles" / (case["case_id"] + "__" + digest(bundle)[:16] + ".json")
        if ref.exists() and load(ref) != bundle:
            raise ValueError("Saved plan bundle changed")
        if not ref.exists():
            save(ref, bundle)
        plans[case["case_id"]] = dict(path=str(ref.relative_to(root)), sha256=sha(ref))
        print("Planned", case["corpus"], case["task"], case["case_id"], flush=True)
    release = dict(version=VERSION, cases=value["cases"], plans=plans,
        catalog_ref=dict(path=str(Path(catalog_path).resolve().relative_to(root)), sha256=sha(catalog_path)),
        binding_sha256=value["binding_sha256"], keys_read=False, grades_read=False,
        exposure="OUTCOME_INFORMED_DEVELOPMENT_NOT_BENCHMARK_ACCURACY")
    release["sha256"] = digest(release)
    path = root / "data/development_v6" / ("plans_" + release["sha256"][:20] + ".json")
    if path.exists() and load(path) != release:
        raise ValueError("An immutable planning release changed")
    if not path.exists():
        save(path, release)
    save(root / "data/development_v6/latest_plans.json", dict(path=str(path.relative_to(root)), sha256=sha(path)))
    return dict(path=str(path), cases=len(release["cases"]), api_calls="Exact cached requests are reused")


def load_release(root, path=None):
    root = Path(root).resolve()
    if path is None:
        pin = load(root / "data/development_v6/latest_plans.json")
        path = _bound(root, pin["path"])
        if sha(path) != pin["sha256"]:
            raise ValueError("Planning release pointer changed")
    path = Path(path).resolve()
    if not path.is_relative_to(root / "data/development_v6"):
        raise ValueError("Unbound planning release")
    value = load(path)
    expected = {"version", "cases", "plans", "catalog_ref", "binding_sha256", "keys_read", "grades_read", "exposure", "sha256"}
    if (set(value) != expected or value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"})
            or value["version"] != VERSION or value["keys_read"] is not False or value["grades_read"] is not False):
        raise ValueError("Planning release changed")
    _public_flags(value)
    cp = _bound(root, value["catalog_ref"]["path"])
    if sha(cp) != value["catalog_ref"]["sha256"] or catalog(root, cp)["cases"] != value["cases"]:
        raise ValueError("Planning questions differ from source catalog")
    if value["binding_sha256"] != catalog(root, cp)["binding_sha256"] or set(value["plans"]) != {c["case_id"] for c in value["cases"]}:
        raise ValueError("Planning/source membership changed")
    return path, value


def archive_code(root, directory, code):
    target = directory / "code_snapshot.zip"
    if target.exists():
        _verify_archive(directory, code)
        return
    temporary = directory / "code_snapshot.tmp.zip"
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, expected in sorted(code.items()):
            path = _code_path(root, name)
            content = path.read_bytes()
            if hashlib.sha256(content).hexdigest() != expected:
                raise ValueError("Code changed while archiving")
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    temporary.replace(target)
    _verify_archive(directory, code)


def _verify_archive(directory, code):
    target = directory / "code_snapshot.zip"
    if not target.is_file():
        raise ValueError("Missing frozen code archive")
    with zipfile.ZipFile(target) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(code):
            raise ValueError("Archived code entry set changed")
        if any(hashlib.sha256(archive.read(name)).hexdigest() != expected for name, expected in code.items()):
            raise ValueError("Archived code content changed")


def _plans(root, release, cases):
    result = {}
    for case in cases:
        pin = release["plans"][case["case_id"]]
        path = _bound(root / "data/development_v6/bundles", Path(pin["path"]).relative_to("data/development_v6/bundles"))
        if sha(path) != pin["sha256"]:
            raise ValueError("Planning bundle changed")
        bundle = load(path)
        _public_flags(bundle)
        if bundle["case"] != case:
            raise ValueError("Planning belongs to another question")
        plans = get_plans(bundle)
        if set(plans) != set(ARMS):
            raise ValueError("Planning arm membership changed")
        for arm, parsed in plans.items():
            validate_plan(parsed, case)
            if parsed["arm"] != arm:
                raise ValueError("Planning condition changed")
        result[case["case_id"]] = plans
    return result


def _graph_reference(root, reference, expected):
    from matryoshka_demo.exploration_v2 import verified_hash
    path = _bound(root / "data/graph_indexes_v2", Path(reference["path"]).relative_to("data/graph_indexes_v2"))
    if reference.get("binding") != expected:
        raise ValueError("Explorer graph differs from native source binding")
    manifest = load(_bound(path.parent, "manifest.json"))
    stat = path.stat()
    if (manifest.get("binding") != expected or manifest.get("sha256") != reference["sha256"]
            or verified_hash(str(path), stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino) != reference["sha256"]):
        raise ValueError("Explorer index changed")
    return path


def _handling(root, source_binding, corpora):
    result = {}
    for name in corpora:
        veto = set()
        if name in {"iran", "vietnam"}:
            path = _bound(root.parent, source_binding["corpora"][name]["files"]["pages"]["path"])
            for row in rows(path):
                if re.search(r"\bNOFORN\b", row["text"], re.I):
                    veto.add(row["document_id"])
        result[name] = sorted(veto)
    return result


class _SourceReplay:
    """Read-only bound SQLite witnesses; no corpus copies or native engines."""
    def __init__(self, root, manifest, source_binding, stack):
        self.manifest, self.cache, self.databases = manifest, {}, {}
        for name, ref in manifest["graph_indexes"].items():
            path = _graph_reference(root, ref, source_binding["corpora"][name])
            db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
            stack.callback(db.close)
            db.execute("PRAGMA query_only=ON")
            self.databases[name] = db

    def page(self, case, pid):
        key = case["corpus"], pid
        if key not in self.cache:
            row = self.databases[key[0]].execute("SELECT doc,date,payload FROM page WHERE id=?", (pid,)).fetchone()
            if row is None:
                raise ValueError("Source page is absent from the bound SQLite index")
            value = json.loads(row[2])
            if (value["id"] != pid or (value["document_id"], value["date"]) != row[:2]
                    or digest(value["text"]) != value["source_sha256"]):
                raise ValueError("Indexed source content changed")
            self.cache[key] = value
        value = self.cache[key]
        if (value["permitted"] is not True or value["corpus"] != case["corpus"]
                or value["document_id"].strip().casefold() == case["document_id"].strip().casefold()
                or value["date"] >= case["date"]
                or value["document_id"] in self.manifest["handling_veto_documents"][case["corpus"]]):
            raise ValueError("Indexed source violates cutoff/origin/handling eligibility")
        return value

    def replay(self, case, value):
        for source in source_objects(value):
            page = self.page(case, source["canonical_page_id"])
            start, end = source["start"], source["end"]
            if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(page["text"])
                    or page["document_id"] != source["document_id"] or page["date"] != source["date"]
                    or page["source_sha256"] != source["page_sha256"] or page["text"][start:end] != source["text"]):
                raise ValueError("Saved citation does not replay in the bound SQLite source")


def _verify_record(root, directory, record, case, arm, manifest, plans, replay):
    _public_flags(record)
    if arm not in ARMS:
        raise ValueError("Retired reference arms are not native v6 inputs")
    expected_plan = plans[case["case_id"]][arm]
    if (record["case"] != case or record["config"] != arm or record["run_id"] != directory.name
            or record["source_binding_sha256"] != manifest["source_binding_sha256"]
            or record["exploration_index_ref"] != manifest["graph_indexes"][case["corpus"]]
            or record["plan"] != expected_plan or record.get("inference_network_access") is not False
            or record.get("keys_read") is not False or record.get("grades_read") is not False
            or record.get("handling_veto_documents") != manifest["handling_veto_documents"][case["corpus"]]
            or record.get("native_checksum") != digest(record["result"])):
        raise ValueError("Native checkpoint condition/plan/index/checksum changed")
    replay.replay(case, record["result"])
    for pid in record["inspected_page_ids"]:
        replay.page(case, pid)
    ref = record["result"].get("candidate_audit_ref")
    if ref is not None:
        expected_path = "candidate_audits/" + case["case_id"] + "__" + arm + ".json.gz"
        path = _bound(directory, ref["path"])
        if ref["path"] != expected_path or sha(path) != ref["sha256"]:
            raise ValueError("Saved candidate audit changed")
        audit = load_gzip(path)
        _public_flags(audit)
        if audit.get("keys_read") is not False or audit.get("grades_read") is not False:
            raise ValueError("Candidate audit is not answer-blind")
        replay.replay(case, audit)
        for pid in audit["inspected_page_ids"]:
            replay.page(case, pid)
        for reading in audit["readings"]:
            for proposal in reading["proposals"]:
                page = replay.page(case, proposal["sources"][0]["canonical_page_id"])
                start, end = proposal["source_span"]
                if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(page["text"])
                        or page["text"][start:end] != proposal["source_wording"]):
                    raise ValueError("Saved construction span does not replay")
def _checkpoint_pin(directory, target, record, manifest):
    return dict(version=CHECKPOINT_VERSION, run_manifest_sha256=digest(manifest),
                path=str(target.relative_to(directory)), sha256=sha(target), record_sha256=digest(record),
                native_checksum=record["native_checksum"], plan_sha256=digest(record["plan"]),
                exploration_index_sha256=digest(record["exploration_index_ref"]),
                candidate_audit_ref_sha256=digest(record["result"].get("candidate_audit_ref")))


def _read_checkpoint(directory, target, manifest):
    pin_path = directory / "checkpoint_pins" / (target.name.removesuffix(".json.gz") + ".json")
    if not pin_path.is_file():
        raise ValueError("Missing native checkpoint pin; uncommitted outputs are not adopted")
    pin = load(pin_path)
    if pin.get("sha256") != sha(target):
        raise ValueError("Compressed native checkpoint bytes changed")
    record = load_gzip(target)
    if pin != _checkpoint_pin(directory, target, record, manifest):
        raise ValueError("Native checkpoint pin changed")
    return record


def _condition_files(directory, cases, arms, *, complete=False):
    expected = {case["case_id"] + "__" + arm + ".json.gz" for case in cases for arm in arms}
    actual = {path.name for path in (directory / "cases").glob("*")}
    pins = {path.name.removesuffix(".json") + ".json.gz" for path in (directory / "checkpoint_pins").glob("*")}
    if actual - expected or pins != actual or complete and actual != expected:
        raise ValueError("Unexpected, missing or uncommitted native checkpoint condition")


def _completion(directory, manifest, records):
    return dict(version="native-completion-pins/6", manifest_sha256=sha(directory / "manifest.json"),
                code_archive_sha256=sha(directory / "code_snapshot.zip"),
                checkpoint_pins={path.name: sha(path) for path in sorted((directory / "checkpoint_pins").glob("*.json"))},
                native_checksums={case + "__" + arm: record["native_checksum"]
                                  for case, arms in records.items() for arm, record in arms.items()},
                handling_policy_sha256={name: sha(directory / (name + "_handling_policy.json"))
                                       for name in manifest["graph_indexes"]},
                run_identity_sha256=digest(manifest), keys_read=False, grades_read=False)


def _audit_files(directory, grouped):
    expected = {record["result"]["candidate_audit_ref"]["path"] for records in grouped.values()
                for record in records.values() if record["result"].get("candidate_audit_ref") is not None}
    actual = {str(path.relative_to(directory)) for path in (directory / "candidate_audits").glob("*")}
    if actual != expected:
        raise ValueError("Unexpected or uncommitted candidate audit")


def verified_run(root, run_directory=None):
    """Read-only reporter gate: complete exact native run and SQLite replay."""
    root = Path(root).resolve()
    pointer = load(root / "data/latest_run_v6.json") if run_directory is None else None
    directory = Path(run_directory).resolve() if run_directory is not None else _bound(root, pointer["path"])
    if not directory.is_relative_to(root / "data/runs_v6"):
        raise ValueError("Unbound native run directory")
    lock_path = directory / "run.lock"
    if not lock_path.is_file():
        raise ValueError("Missing native run lock")
    with lock_path.open("r") as lock, ExitStack() as stack:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        manifest = load(directory / "manifest.json")
        _public_flags(manifest)
        if manifest["version"] != VERSION or directory.name != "demo_v6_" + digest(manifest)[:20]:
            raise ValueError("Frozen native run identity changed")
        if pointer is not None and (sha(directory / "manifest.json") != pointer["manifest_sha256"]
                or sha(directory / "checkpoint_manifest.json") != pointer["checkpoint_manifest_sha256"]):
            raise ValueError("Native run pointer changed")
        check_code(root, manifest["code"])
        _verify_archive(directory, manifest["code"])
        path = _bound(root, manifest["release_ref"]["path"])
        if sha(path) != manifest["release_ref"]["sha256"]:
            raise ValueError("Native planning release changed")
        _, release = load_release(root, path)
        selected = {case["case_id"] for case in manifest["cases"]}
        arms = manifest["settings"]["arms"]
        if (not selected or len(selected) != len(manifest["cases"])
                or manifest["cases"] != [case for case in release["cases"] if case["case_id"] in selected]
                or not arms or len(set(arms)) != len(arms) or any(arm not in ARMS for arm in arms)
                or set(manifest["graph_indexes"]) != {case["corpus"] for case in manifest["cases"]}
                or manifest.get("checkpoint_contract") != CHECKPOINT_VERSION
                or manifest.get("original_reference_code") != {name: value for name, value in manifest["code"].items()
                                                               if name.startswith(ORIGINAL_PREFIX)}):
            raise ValueError("Native release/condition/code membership changed")
        plans = _plans(root, release, manifest["cases"])
        source_binding = load(root / "data/bindings.json")
        if source_binding["sha256"] != manifest["source_binding_sha256"]:
            raise ValueError("Native source binding changed")
        verify_sources(root.parent, source_binding, set(manifest["graph_indexes"]))
        if _handling(root, source_binding, manifest["graph_indexes"]) != manifest["handling_veto_documents"]:
            raise ValueError("Native handling policy changed")
        progress = load(directory / "progress.json")
        expected = len(manifest["cases"]) * len(manifest["settings"]["arms"])
        if (progress.get("run_id") != directory.name or progress["status"] != "COMPLETE" or progress["completed"] != expected
                or progress["expected"] != expected or progress["failures"]):
            raise ValueError("Native conditions are not complete or have active failures")
        _condition_files(directory, manifest["cases"], manifest["settings"]["arms"], complete=True)
        replay = _SourceReplay(root, manifest, source_binding, stack)
        grouped = {}
        for case in manifest["cases"]:
            records = {}
            for arm in manifest["settings"]["arms"]:
                target = directory / "cases" / (case["case_id"] + "__" + arm + ".json.gz")
                record = _read_checkpoint(directory, target, manifest)
                _verify_record(root, directory, record, case, arm, manifest, plans, replay)
                records[arm] = record
            grouped[case["case_id"]] = records
        if load(directory / "checkpoint_manifest.json") != _completion(directory, manifest, grouped):
            raise ValueError("Native completion/checkpoint seal changed")
        _audit_files(directory, grouped)
        return directory, manifest, grouped, source_binding


def run(root, *, release_path=None, case_ids=None, arms=ARMS, document_budget=100, passage_budget=100):
    from .candidates import construct, finalize_untyped
    from matryoshka_demo.retrieval_v5 import retrieve
    from .flow import replay
    from matryoshka_demo.flow_v5 import task_targets
    from .task_execution import execute as execute_task, filter_redaction
    root = Path(root).resolve()
    if any(type(value) is not int or value < 1 for value in (document_budget, passage_budget)):
        raise ValueError("Positive integer document/page budgets required")
    path, release = load_release(root, release_path)
    by_id = {case["case_id"]: case for case in release["cases"]}
    if case_ids and (len(set(case_ids)) != len(case_ids) or set(case_ids) - set(by_id)):
        raise ValueError("Unknown native case selection")
    cases = [by_id[identity] for identity in case_ids] if case_ids else list(release["cases"])
    if not cases or not arms or len(set(arms)) != len(arms) or any(a not in ARMS for a in arms):
        raise ValueError("Unknown or empty execution selection")
    source_binding = load(root / "data/bindings.json")
    names = list(dict.fromkeys(case["corpus"] for case in cases))
    verify_sources(root.parent, source_binding, names)
    plans = _plans(root, release, cases)
    published_indexes = load(root / "web/data/report-v3.json")["graph_indexes"]
    indexes = {name: deepcopy(published_indexes[name]) for name in names}
    for name in names:
        _graph_reference(root, indexes[name], source_binding["corpora"][name])
    handling = _handling(root, source_binding, names)
    code = binding(root)
    identity = dict(version=VERSION, source_binding_sha256=source_binding["sha256"], code=code,
        original_reference_code={name: expected for name, expected in code.items() if name.startswith(ORIGINAL_PREFIX)},
        environment=environment_binding(root), release_ref=dict(path=str(path.relative_to(root)), sha256=sha(path)),
        graph_indexes=indexes, handling_veto_documents=handling, checkpoint_contract=CHECKPOINT_VERSION,
        settings=dict(arms=list(arms), document_budget=document_budget, passage_budget=passage_budget,
            hierarchy=True, document_states=False, top_k=5, whole_query_search=False, compressed_checkpoints=True,
            checkpoint_pins=True, source_replay="BOUND_READ_ONLY_SQLITE"),
        cases=cases, keys_read=False, grades_read=False, inference_network_access=False)
    directory = root / "data/runs_v6" / ("demo_v6_" + digest(identity)[:20])
    directory.mkdir(parents=True, exist_ok=True)
    disk_guard(directory)
    with (directory / "run.lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        target = directory / "manifest.json"
        if target.exists() and load(target) != identity:
            raise ValueError("Native run identity changed")
        if not target.exists():
            save(target, identity)
        progress = dict(run_id=directory.name, status="RUNNING", completed=0, expected=len(cases)*len(arms), failures=[])
        save(directory / "progress.json", progress)
        try:
            with offline(), ExitStack() as stack:
                check_code(root, code)
                if any((directory / "cases").glob("*")) and not (directory / "code_snapshot.zip").is_file():
                    raise ValueError("Missing frozen code archive")
                archive_code(root, directory, code)
                _condition_files(directory, cases, arms)
                replay_sources = _SourceReplay(root, identity, source_binding, stack)
                grouped = {case["case_id"]: {} for case in cases}
                # Validate every committed condition before any new native call.
                for case in cases:
                    for arm in arms:
                        output = directory / "cases" / (case["case_id"] + "__" + arm + ".json.gz")
                        if output.exists():
                            record = _read_checkpoint(directory, output, identity)
                            _verify_record(root, directory, record, case, arm, identity, plans, replay_sources)
                            grouped[case["case_id"]][arm] = record
                            progress["completed"] += 1
                _audit_files(directory, grouped)
                completed = directory / "checkpoint_manifest.json"
                if completed.exists() and (progress["completed"] != progress["expected"]
                        or load(completed) != _completion(directory, identity, grouped)):
                    raise ValueError("Native completion/checkpoint seal changed")
                for corpus_id in names:
                    policy_path = directory / (corpus_id + "_handling_policy.json")
                    policy = dict(excluded_documents=handling[corpus_id],
                        reason="Internal cable NOFORN marking requires reconciliation; original metadata unchanged")
                    if policy_path.exists() and load(policy_path) != policy:
                        raise ValueError("Saved native handling policy changed")
                    if not policy_path.exists():
                        save(policy_path, policy)
                    corpus = None
                    for case in (c for c in cases if c["corpus"] == corpus_id):
                        for arm in arms:
                            disk_guard(directory); check_code(root, code)
                            output = directory / "cases" / (case["case_id"] + "__" + arm + ".json.gz")
                            if arm in grouped[case["case_id"]]:
                                continue
                            if corpus is None:
                                print("Loading", corpus_id, flush=True)
                                corpus = policy_view(Corpus(root.parent, source_binding["corpora"][corpus_id]))
                                if corpus.excluded_documents != handling[corpus_id]:
                                    raise ValueError("Runtime handling policy differs from frozen source policy")
                            start = time.monotonic()
                            parsed = plans[case["case_id"]][arm]
                            validate_plan(parsed, case)
                            found = retrieve(corpus, case, parsed, document_budget=document_budget, passage_budget=passage_budget)
                            if case["task"] == "redaction":
                                result = construct(case, parsed, found, passage_budget=passage_budget, top_k=5)
                                result = filter_redaction(case, result, top_k=5, retrieval=found, passage_budget=passage_budget)
                                result = finalize_untyped(result, top_k=5)
                            else:
                                result = execute_task(case, parsed, found, passage_budget=passage_budget)
                                result["flow_targets"] = task_targets(case, result)
                            result["flow"] = replay(found, result, case=case)
                            result["retrieval"] = found["receipt"]
                            audit = result.pop("_candidate_audit", None)
                            if audit is not None:
                                ap = directory / "candidate_audits" / (output.name.removesuffix(".json.gz") + ".json.gz")
                                save_gzip(ap, audit)
                                result["candidate_audit_ref"] = dict(path=str(ap.relative_to(directory)), sha256=sha(ap))
                            for pi in found["pages"][:passage_budget]:
                                if not found["eligible"].page_mask[pi]:
                                    raise ValueError("Ineligible source in native output")
                            record = dict(case=case, config=arm, plan=parsed, result=result, run_id=directory.name,
                                runtime_seconds=round(time.monotonic()-start, 4), source_binding_sha256=source_binding["sha256"],
                                exploration_index_ref=indexes[corpus_id], inference_network_access=False, keys_read=False, grades_read=False,
                                handling_veto_documents=corpus.excluded_documents,
                                inspected_page_ids=[corpus.pages[pi]["id"] for pi in found["pages"][:passage_budget]],
                                native_checksum=digest(result))
                            _verify_record(root, directory, record, case, arm, identity, plans, replay_sources)
                            check_code(root, code)
                            save_gzip(output, record)
                            save(directory / "checkpoint_pins" / (output.name.removesuffix(".json.gz") + ".json"),
                                 _checkpoint_pin(directory, output, record, identity))
                            grouped[case["case_id"]][arm] = record
                            progress["completed"] += 1; save(directory / "progress.json", progress)
                            print(progress["completed"], "/", progress["expected"], corpus_id, case["task"], arm,
                                result.get("native_verdict", "RANKED_FILLS"), record["runtime_seconds"], flush=True)
                    corpus = None; gc.collect()
                _condition_files(directory, cases, arms, complete=True)
                _audit_files(directory, grouped)
                check_code(root, code)
                for name in names:
                    _graph_reference(root, indexes[name], source_binding["corpora"][name])
                seal = _completion(directory, identity, grouped)
                if completed.exists() and load(completed) != seal:
                    raise ValueError("Native completion/checkpoint seal changed")
                if not completed.exists():
                    save(completed, seal)
            progress["status"] = "COMPLETE"
            save(directory / "progress.json", progress)
            save(root / "data/latest_run_v6.json", dict(path=str(directory.relative_to(root)), manifest_sha256=sha(target),
                checkpoint_manifest_sha256=sha(directory / "checkpoint_manifest.json")))
        except BaseException as error:
            progress["status"] = "PAUSED_OR_FAILED"
            failure = dict(error_type=type(error).__name__, message=str(error))
            progress["failures"].append(failure)
            save(directory / "failures" / (str(time.time_ns()) + ".json"), failure)
            raise
        finally:
            save(directory / "progress.json", progress)
    return dict(path=str(directory), **progress)
