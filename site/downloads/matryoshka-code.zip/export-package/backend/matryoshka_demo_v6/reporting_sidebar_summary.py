"""Build-time summaries using the very same pure projection as the browser.

The server/browser need not load every case or numerical flow to show badges.
Node is a build dependency only. No retrieval, grading or model is invoked.
"""
from copy import deepcopy
import json
from pathlib import Path
import subprocess


SCRIPT = """
import {pathToFileURL} from 'node:url';
import {webcrypto} from 'node:crypto';
if(!globalThis.crypto)globalThis.crypto=webcrypto;
const {decisionSummaryFor}=await import(pathToFileURL(process.argv[1]).href);
let input='';for await(const chunk of process.stdin)input+=chunk;
const rows=JSON.parse(input),output=[];
for(const row of rows)output.push(await decisionSummaryFor(row.record,row.case));
process.stdout.write(JSON.stringify(output));
"""


def summarize(root, rows):
    inputs = []
    for case, record in rows:
        result = record.get("result", {})
        result = result.get("redaction", result)
        inputs.append(dict(case=case, record=dict(config=record["config"], run_id=record["run_id"],
            native_checksum=deepcopy(record["native_checksum"]),
            plan=dict(atoms=deepcopy(record.get("plan", {}).get("atoms", []))),
            result=dict(readings=[dict(reading=deepcopy(r["reading"]),
                candidates=[dict(id=c["id"], fill=c["fill"]) for c in r["candidates"]])
                for r in result.get("readings", [])]),
            local_decisions_v65=deepcopy(record["local_decisions_v65"]))))
    module = Path(root).resolve() / "web/local-decisions-v65.js"
    result = subprocess.run(["node", "--input-type=module", "-e", SCRIPT, str(module)],
        input=json.dumps(inputs, ensure_ascii=True, allow_nan=False), text=True,
        capture_output=True, timeout=120, check=True)
    values = json.loads(result.stdout)
    if len(values) != len(rows) or any(v is None for v in values):
        raise ValueError("Incomplete source-bound sidebar summaries")
    return values
