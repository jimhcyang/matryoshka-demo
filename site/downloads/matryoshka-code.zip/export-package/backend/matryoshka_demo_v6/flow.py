"""Exact finite restart-walk accounting and honest source readout routes.

This module observes an executed retrieval. It does not change its kernel,
ranking, candidates, or factual assessments. A readout is never a solver edge.
"""
from collections import defaultdict
from copy import deepcopy
import heapq
import math
import re

import numpy as np
from scipy import sparse

from matryoshka_demo import flow_v3
from matryoshka_demo.contracts import public_case
from matryoshka_demo.flow_v5 import task_targets
from matryoshka_demo.graph_kernel import maximum_product_witness
from matryoshka_demo.io import digest
from matryoshka_demo.vendor.matching import clone


VERSION = "source-routes-exact-finite-walk/6"
WALK_DEFINITION = {
    "recurrence": "x[0]=p; x[t+1]=(1-alpha)*p+alpha*K.T@x[t]",
    "shorter_than_horizon": "(1-alpha)*alpha**k*p[path[0]]*product(K[u,v])",
    "equal_to_horizon": "alpha**T*p[path[0]]*product(K[u,v])",
    "event": "The complete suffix after the last restart, ending at iteration T; k=T is the initial component.",
    "disjointness": "Different complete node sequences or lengths are disjoint last-restart events, even with shared edges.",
    "denominator": "Actual native final mass summed over this candidate's explicitly recorded readout endpoints.",
    "not_measured": ["all walks using corridor edges", "historical causality", "answer correctness", "independent explanations"],
}


def _number(value, positive=False):
    return (isinstance(value, (int, float, np.integer, np.floating)) and not isinstance(value, (bool, np.bool_))
            and math.isfinite(value) and (value > 0 if positive else value >= 0))


def unknown_metrics(reason):
    return dict(status="UNKNOWN", reason=reason, component_mass=None, endpoint_share=None,
                endpoint_percent=None, correctness_probability=False)


def _numerics(kernel, prior, iterations, alpha):
    if type(iterations) is not int or iterations < 0 or not _number(alpha, True) or alpha >= 1:
        raise ValueError("Invalid finite walk horizon/alpha")
    matrix = sparse.csr_matrix(kernel, dtype=float, copy=True)
    matrix.sum_duplicates(); matrix.eliminate_zeros(); matrix.sort_indices()
    p = np.asarray(prior, dtype=float)
    if p.ndim != 1 or matrix.shape != (len(p), len(p)):
        raise ValueError("Kernel/prior dimensions differ")
    if not np.isfinite(p).all() or (p < 0).any() or not np.isfinite(matrix.data).all() or (matrix.data < 0).any():
        raise ValueError("Invalid native numerical input")
    if (np.asarray(matrix.sum(axis=1)).ravel() > 1 + 1e-12).any():
        raise ValueError("Native transition rows exceed one")
    return matrix, p


def diffuse(kernel, prior, iterations, alpha=.85):
    matrix, p = _numerics(kernel, prior, iterations, alpha)
    values = p.copy()
    transpose = matrix.T.tocsr()
    for _ in range(iterations):
        values = (1-alpha)*p + alpha*(transpose @ values)
    return values


def walk_component(path, kernel=None, prior=None, *, iterations=None, alpha=None, endpoint_mass=None):
    """Mass of one COMPLETE last-restart walk, not visits to its edge corridor."""
    if kernel is None or prior is None or iterations is None or alpha is None:
        return unknown_metrics("NATIVE_KERNEL_PRIOR_OR_HORIZON_UNAVAILABLE")
    matrix, p = _numerics(kernel, prior, iterations, alpha)
    return _walk_component(path, matrix, p, iterations, alpha, endpoint_mass)


def _walk_component(path, matrix, p, iterations, alpha, endpoint_mass):
    # Callers enumerating paths validate/copy the whole native kernel only once.
    if not path or any(type(i) is not int or not 0 <= i < len(p) for i in path):
        raise ValueError("Invalid complete walk state indices")
    k = len(path)-1
    transitions = [float(matrix[u, v]) for u, v in zip(path, path[1:])]
    product = math.prod(transitions)
    factor = 0. if k > iterations else alpha**k * (1. if k == iterations else 1-alpha)
    mass = factor * float(p[path[0]]) * product
    denominator = endpoint_mass if _number(endpoint_mass, True) else None
    if denominator is not None and mass > denominator + max(1e-12, denominator*1e-9):
        raise ValueError("A complete walk exceeds actual endpoint mass")
    return dict(status="EXACT_FINITE_WALK_COMPONENT", length=k, horizon=iterations,
        component="OUTSIDE_HORIZON" if k > iterations else "INITIAL" if k == iterations else "LAST_RESTART",
        native_seed_mass=float(p[path[0]]), transition_product=product, transitions=transitions,
        restart_and_length_factor=factor, component_mass=mass, endpoint_mass=endpoint_mass,
        endpoint_share=mass/denominator if denominator else None,
        endpoint_percent=100*mass/denominator if denominator else None,
        denominator_status="KNOWN_POSITIVE" if denominator else "ZERO_OR_UNAVAILABLE",
        complete_node_sequence=list(path), correctness_probability=False)


def selected_walk_mass(paths, kernel=None, prior=None, *, iterations=None, alpha=None, endpoint_mass=None):
    if kernel is None or prior is None or iterations is None or alpha is None:
        return unknown_metrics("NATIVE_KERNEL_PRIOR_OR_HORIZON_UNAVAILABLE")
    matrix, p0 = _numerics(kernel, prior, iterations, alpha)
    unique = list(dict.fromkeys(tuple(p) for p in paths))
    components = [_walk_component(list(p), matrix, p0, iterations, alpha, endpoint_mass) for p in unique]
    mass = math.fsum(c["component_mass"] for c in components)
    if _number(endpoint_mass, True) and mass > endpoint_mass + max(1e-12, endpoint_mass*1e-9):
        raise ValueError("Selected disjoint components exceed actual endpoint mass")
    return dict(status="EXACT_SELECTED_DISJOINT_COMPONENT_SUM", component_mass=mass,
        unique_walks=len(unique), repeated_sequences_not_counted=len(paths)-len(unique),
        endpoint_mass=endpoint_mass, endpoint_share=mass/endpoint_mass if _number(endpoint_mass, True) else None,
        endpoint_percent=100*mass/endpoint_mass if _number(endpoint_mass, True) else None,
        overlapping_edges_allowed=True, independent_explanations_claimed=False,
        omitted_walks_included=False, correctness_probability=False)


def starter_endpoint_shares(kernel, prior, starters, endpoints, *, iterations, alpha=.85,
                            native_final=None, batch_size=8):
    """Linear superposition over the WHOLE native kernel, including escapes."""
    matrix, p = _numerics(kernel, prior, iterations, alpha)
    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("Invalid starter batch size")
    rows, total, seen = [], np.zeros(len(p)), set()
    for starter in starters:
        if starter["id"] in seen:
            raise ValueError("Repeated starter identity")
        seen.add(starter["id"])
        raw = np.asarray(starter["values"], dtype=float)
        if raw.ndim != 1 or len(raw) > len(p) or not np.isfinite(raw).all() or (raw < 0).any():
            raise ValueError("Invalid actual starter prior")
        values = np.zeros(len(p)); values[:len(raw)] = raw
        total += values; rows.append((starter, values))
    if not np.allclose(total, p, rtol=1e-11, atol=1e-14):
        return dict(status="UNKNOWN", reason="RECORDED_STARTERS_DO_NOT_PARTITION_NATIVE_PRIOR", candidates={})
    final = diffuse(matrix, p, iterations, alpha) if native_final is None else np.asarray(native_final, dtype=float)
    if final.shape != p.shape or not np.isfinite(final).all() or (final < 0).any():
        raise ValueError("Invalid native final vector")
    summed_final = np.zeros(len(p)); output = {cid: [] for cid in endpoints}
    transpose = matrix.T.tocsr()
    for offset in range(0, len(rows), batch_size):
        batch = rows[offset:offset+batch_size]
        seeds = np.column_stack([p0 for _, p0 in batch]); values = seeds.copy()
        for _ in range(iterations):
            values = (1-alpha)*seeds + alpha*(transpose @ values)
        summed_final += values.sum(axis=1)
        for cid, indices in endpoints.items():
            denominator = float(final[indices].sum())
            for column, (starter, seed) in enumerate(batch):
                mass = float(values[indices, column].sum())
                output[cid].append(dict(starter_id=starter["id"], kind=starter["kind"],
                    label=starter["label"], initial_mass=float(seed.sum()), endpoint_mass=mass,
                    endpoint_share=mass/denominator if denominator else None,
                    endpoint_percent=100*mass/denominator if denominator else None,
                    meaning="All finite native walks from this starter's linear prior component, not one selected path.",
                    correctness_probability=False))
    error = float(np.max(np.abs(summed_final-final), initial=0))
    if not np.allclose(summed_final, final, rtol=1e-10, atol=1e-13):
        raise ValueError("Starter superposition does not reproduce native final mass")
    return dict(status="VERIFIED_LINEAR_SUPERPOSITION", maximum_state_absolute_error=error,
        prior_partition_checked=True, full_state_conservation_checked=True,
        batch_size=batch_size, candidates=output)


def snapshot(bundle, final, iterations, alpha):
    matrix, p = _numerics(bundle.kernel, bundle.prior, iterations, alpha)
    value = dict(version="native-finite-walk-snapshot/6", state_ids=list(bundle.state_ids),
        shape=list(matrix.shape), indptr=matrix.indptr.tolist(), indices=matrix.indices.tolist(),
        data=matrix.data.tolist(), prior=p.tolist(), final=np.asarray(final).tolist(),
        iterations=iterations, alpha=alpha, definition=deepcopy(WALK_DEFINITION))
    return dict(value, sha256=digest(value))


def read_snapshot(value):
    if digest({k: v for k, v in value.items() if k != "sha256"}) != value["sha256"]:
        raise ValueError("Native walk snapshot changed")
    ids = value["state_ids"]
    if len(set(ids)) != len(ids) or value["shape"] != [len(ids), len(ids)]:
        raise ValueError("Ambiguous saved native states")
    matrix = sparse.csr_matrix((value["data"], value["indices"], value["indptr"]), shape=tuple(value["shape"]))
    matrix, p = _numerics(matrix, value["prior"], value["iterations"], value["alpha"])
    final = np.asarray(value["final"], dtype=float)
    if not np.allclose(diffuse(matrix, p, value["iterations"], value["alpha"]), final, rtol=1e-11, atol=1e-13):
        raise ValueError("Saved native final vector does not replay")
    return matrix, p, final, {identity: i for i, identity in enumerate(ids)}


def _veto(corpus):
    if corpus.corpus not in {"iran", "vietnam"}:
        return set()
    return set(getattr(corpus, "excluded_documents", [])) | {p["document_id"] for p in corpus.pages
        if re.search(r"\bNOFORN\b", p["text"], re.I)}


def validate_source(proof, corpus, eligible, case, veto):
    pid = proof["canonical_page_id"]
    pi = corpus.page_index.get(pid)
    if pi is None or not eligible.page_mask[pi]:
        raise ValueError("Flow source is not an eligible page")
    page = corpus.pages[pi]
    if (not page.get("permitted", False) or page.get("corpus", case["corpus"]) != case["corpus"]
            or page["date"] >= case["date"] or page["document_id"] == case["document_id"]
            or page["document_id"] in veto or proof["document_id"] != page["document_id"] or proof["date"] != page["date"]):
        raise ValueError("Flow source violates date/origin/handling scope")
    if case["corpus"] != "cib" and (page.get("classification") != "CONFIDENTIAL"
            or any("NOFORN" in str(h).upper() for h in page.get("handling", []))):
        raise ValueError("Flow cable source is not permitted CONFIDENTIAL")
    start, end = proof["start"], proof["end"]
    if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(page["text"])
            or page["text"][start:end] != proof["text"] or digest(page["text"]) != page["source_sha256"]
            or proof.get("page_sha256") != page["source_sha256"]):
        raise ValueError("Flow exact source quotation/hash changed")
    return pi


def _rows(result, case):
    if case["task"] != "redaction":
        return task_targets(case, result)
    output = []
    for row in result.get("readings", []):
        rid = row.get("reading_id") or row.get("reading", {}).get("id") or row.get("id")
        output.extend(dict(deepcopy(c), reading_id=rid) for c in row.get("candidates", []))
    ids = [c["id"] for c in output]
    if len(ids) != len(set(ids)):
        raise ValueError("V6 candidate IDs must be globally unique per reading/source occurrence")
    return output


def endpoint_sets(rows, retrieval, case, veto):
    c = retrieval["eligible"].corpus; eligible = retrieval["eligible"]
    bundle = retrieval.get("hierarchy_bundle")
    by_page = defaultdict(list)
    for ui, ni in c.membership:
        if eligible.unit_mask[ui]:
            by_page[c.units[ui]["pi"]].append((ui, ni))
    endpoints = {}
    for candidate in rows:
        proofs = candidate.get("sources", [])
        pages = [validate_source(p, c, eligible, case, veto) for p in proofs]
        source_binding = candidate.get("source_entity_binding") or {}
        if not isinstance(source_binding, dict):
            raise ValueError("Invalid source entity binding shape")
        declared = (source_binding.get("node_id") or source_binding.get("canonical_node_id")) \
            if "source_entity_binding" in candidate else candidate.get("node_id")
        ni = c.node_index.get(declared)
        attested = False
        if ni is not None and eligible.active[ni]:
            for proof, pi in zip(proofs, pages):
                for oi in c.occurrences_by_node.get(declared, []):
                    occ = c.occurrences[oi]
                    if occ["page_index"] != pi or occ.get("source_type") != "entities":
                        continue
                    if proof["canonical_page_id"] != proofs[0]["canonical_page_id"]:
                        continue
                    span = candidate.get("fitted_source_span") or candidate.get("source_span") or source_binding.get("source_span") or [proof["start"], proof["end"]]
                    bound_page = source_binding.get("canonical_page_id", proof["canonical_page_id"])
                    label_pattern = r"\s+".join(re.escape(w) for w in occ.get("label", "").split())
                    labels = list(re.finditer(r"(?<!\w)" + label_pattern + r"(?!\w)",
                        c.pages[pi]["text"], re.I)) if label_pattern else []
                    if (occ["page_index"] == pi and occ.get("source_type") == "entities"
                            and bound_page == proof["canonical_page_id"]
                            and occ["start"] < span[1] and span[0] < occ["end"]
                            and any(m.start() < span[1] and span[0] < m.end()
                                    and occ["start"] <= m.start() and m.end() <= occ["end"]
                                    and proof["start"] <= m.start() and m.end() <= proof["end"] for m in labels)):
                        attested = True
            identity = attested or not proofs
        else:
            identity = False
        indices = [int(ni)] if identity else []
        if not indices and bundle is not None:
            page_states = bundle.metadata.get("page_indices", {})
            for proof, pi in zip(proofs, pages):
                state = page_states.get(pi, page_states.get(str(pi)))
                if state is not None:
                    indices.append(int(state)); continue
                for ui, node in by_page.get(pi, []):
                    unit = c.units[ui]
                    if unit["start"] < proof["end"] and proof["start"] < unit["end"]:
                        indices.append(int(node))
        endpoints[candidate["id"]] = dict(indices=list(dict.fromkeys(indices)),
            label=candidate.get("fill", candidate.get("label", "Source evidence")),
            binding="semantic_identity" if attested else "native_graph_identity_unverified" if identity else "source_page_readout",
            identity_source_attested=attested, factual_support_implied=False,
            source_pages=sorted({p["canonical_page_id"] for p in proofs}))
    return endpoints


def lexical_routes(candidate, retrieval, case):
    """Only actual saved search/doc/construction receipts, never an invented KG hop."""
    receipt = retrieval.get("receipt", {})
    searches = {q["id"]: q for q in receipt.get("search_queries", [])}
    c = retrieval["eligible"].corpus
    primary = set(retrieval.get("pages", []))
    output = []
    seen = set()
    for proof in candidate.get("sources", []):
        key = proof["canonical_page_id"], proof["start"], proof["end"]
        if key in seen:
            continue
        seen.add(key)
        document = next((d for d in receipt.get("seeded_documents", []) if d["document_id"] == proof["document_id"]), None)
        hits = deepcopy(document.get("matched_searches", [])) if document else []
        if not hits:
            for q in searches.values():
                for page in q.get("top_pages", []):
                    if page.get("page_id") == proof["canonical_page_id"] and _number(page.get("bm25"), True):
                        hits.append(dict(search_id=q["id"], query=q["query"], bm25=page["bm25"]))
        inputs = [dict(id=h["search_id"], text=searches[h["search_id"]]["query"],
            kind=searches[h["search_id"]]["kind"], role="EXECUTED_LEXICAL_SEARCH_NOT_GRAPH_RESTART")
            for h in hits if h.get("search_id") in searches]
        pi = c.page_index[proof["canonical_page_id"]]
        source_receipt = dict(document_id=proof["document_id"], canonical_page_id=proof["canonical_page_id"],
            matched_searches=hits, query_document_match_saved=bool(hits),
            seeded_document_receipt=deepcopy(document),
            construction_page_rank=retrieval.get("page_ranks", {}).get(pi),
            primary_construction_page=pi in primary,
            method="BM25_DOCUMENT_RECEIPT" if hits else "NATIVE_CONSTRUCTION_SOURCE_READOUT" if pi in primary
                else "SAVED_CANDIDATE_DOSSIER_CITATION",
            query_inputs_unattributed_if_no_saved_match=not bool(inputs))
        prefix = "lexical:" + digest([candidate["id"], key])[:24]
        nodes = [dict(id=prefix+":search", label="Executed query searches" if searches else "Query search receipts unavailable", type="query_search_receipt",
                      executed_searches=[dict(id=q["id"], query=q["query"], kind=q["kind"]) for q in searches.values()]),
                 dict(id=prefix+":document", label=proof["document_id"], type="document_receipt", receipt=source_receipt),
                 dict(id=prefix+":quote", label=proof["text"], type="source_quote", citation=deepcopy(proof)),
                 dict(id=prefix+":fill", label=candidate.get("fill", candidate.get("label", "Source evidence")), type="constructed_fill_readout")]
        for node in nodes:
            node.update(solver_state=False, layout_only=True, readout_only=True)
        output.append(dict(id=prefix, route_kind="LEXICAL_SOURCE_READOUT", nodes=nodes,
            hops=[dict(source=a["id"], target=b["id"], kind=kind, numerical_transition=False)
                for a, b, kind in zip(nodes, nodes[1:], ("SEARCH_RECEIPT_READOUT", "EXACT_QUOTATION_READOUT", "CONSTRUCTION_READOUT"))],
            query_inputs=inputs, source_receipt=source_receipt, source_quotes=[deepcopy(proof)],
            document_ids=[proof["document_id"]], walk_metrics=unknown_metrics("LEXICAL_READOUT_NOT_A_KERNEL_WALK"),
            identity_attestation_is_factual_support=False, factual_support=deepcopy(candidate.get("support_assessment", {})),
            meaning="Executed search/construction provenance to an exact quote and proposed fill. Not a KG edge, solver answer state, or factual entailment."))
        if len(output) == 3:
            break
    return output


def _edge_set(route):
    return {(h["source"], h["target"]) for h in route.get("hops", [])}


def diverse_routes(routes, *, limit=3):
    """Group duplicate shared tails; favor new communities/edges, not new starts."""
    unique = {}
    for route in routes:
        seq = tuple(n["id"] for n in route["nodes"])
        if seq and seq not in unique:
            unique[seq] = deepcopy(route)
    groups = defaultdict(list)
    for seq, route in unique.items():
        at = next((i for i, n in enumerate(route["nodes"]) if n["type"].lower() == "community"), None)
        tail = seq[at:] if at is not None else seq[1:] if len(seq) > 1 else seq
        groups[tail].append(route)
    representatives = []
    shared = []
    for tail, members in groups.items():
        members.sort(key=lambda r: (not r.get("native_witness", False), len(r["hops"]),
            -r.get("walk_metrics", {}).get("component_mass", 0), tuple(n["id"] for n in r["nodes"])))
        best = members[0]
        best["shared_tail_group"] = dict(tail_node_ids=list(tail), complete_walk_count=len(members),
            alternative_complete_sequences=[[n["id"] for n in r["nodes"]] for r in members[1:]],
            alternative_walk_metrics=[deepcopy(r.get("walk_metrics")) for r in members[1:]],
            alternatives_in_selected_mass_sum=False, independent_explanations=False)
        representatives.append(best)
        if len(members) > 1:
            shared.append(deepcopy(best["shared_tail_group"]))
    chosen, used_edges, used_communities = [], set(), set()
    def communities(route):
        return {n["id"] for n in route["nodes"] if n["type"].lower() == "community"}
    while representatives and len(chosen) < limit:
        def order(route):
            edges, comms = _edge_set(route), communities(route)
            return (not route.get("native_witness", False) if not chosen else False,
                -len(comms-used_communities), -len(edges-used_edges), len(edges & used_edges),
                len(route["hops"]), -route.get("walk_metrics", {}).get("component_mass", 0),
                tuple(n["id"] for n in route["nodes"]))
        best = min(representatives, key=order)
        representatives.remove(best)
        chosen.append(best); used_edges |= _edge_set(best); used_communities |= communities(best)
    overlaps = []
    for i, left in enumerate(chosen):
        for j, right in enumerate(chosen[i+1:], i+1):
            edges = sorted(_edge_set(left) & _edge_set(right))
            overlaps.append(dict(left=i, right=j, shared_edges=[list(e) for e in edges],
                shared_community_ids=sorted(communities(left) & communities(right)),
                shared_edge_count=len(edges), independent_explanations=False))
    return chosen, dict(selected_count=len(chosen), unique_positive_sequences=len(unique),
        shared_tail_groups=shared, pairwise_overlap=overlaps, independent_explanations_claimed=False,
        unavailable_reason=None if len(chosen) >= limit else "FEWER_DISTINCT_POSITIVE_TAIL_GROUPS_IN_BOUNDED_SAVED_PROJECTION",
        omitted_tail_groups=len(representatives), enumeration_complete=False, detours_padded=False)


def numerical_routes(cf, nodes, starters, kernel, prior, final, state_index, iterations, alpha):
    node_map = {n["id"]: n for n in nodes if not n.get("layout_only", False)}
    targets = set(cf.get("endpoint_ids") or cf.get("source_contributor_ids") or [])
    denominator = float(final[[state_index[t] for t in targets]].sum())
    edges, graph = {}, defaultdict(list)
    for original in cf.get("contribution_edges", []):
        u, v = original["source"], original["target"]
        influence = original["transported_influence"]
        if not _number(influence):
            raise ValueError("Invalid saved contribution influence")
        if not influence or u == v or u not in node_map or v not in node_map:
            continue
        transition = float(kernel[state_index[u], state_index[v]])
        if not _number(transition, True):
            raise ValueError("Positive saved influence has no actual native transition")
        edge = dict(deepcopy(original), transition=transition)
        edges[u, v] = edge; graph[u].append(v)
    paths, native_paths = [], set()
    for witness in cf.get("witnesses", []):
        seq = tuple(n["id"] for n in witness["nodes"])
        if not seq or len(seq)-1 > iterations:
            continue
        node_map.update({n["id"]: n for n in witness["nodes"]})
        native_paths.add(seq); paths.append(seq)
        for hop in witness["hops"]:
            u, v = hop["source"], hop["target"]
            edges.setdefault((u, v), dict(deepcopy(hop), transition=float(kernel[state_index[u], state_index[v]])))
    queue = []
    for identity in sorted(node_map):
        if identity in state_index and prior[state_index[identity]] > 0:
            heapq.heappush(queue, (0, (identity,)))
    expansions, found = 0, 0
    while queue and expansions < 4096 and found < 256:
        _, seq = heapq.heappop(queue); expansions += 1
        if seq[-1] in targets:
            paths.append(seq); found += 1; continue
        if len(seq)-1 >= min(iterations, 12):
            continue
        for target in sorted(graph[seq[-1]]):
            if target not in seq:
                heapq.heappush(queue, (len(seq), seq+(target,)))
    routes = []
    shortest = {p[0]: min(len(s) for s in paths if s[0] == p[0]) for p in paths}
    for seq in paths:
        if seq not in native_paths and len(seq) > shortest[seq[0]]+2:
            continue
        indices = [state_index[s] for s in seq]
        metrics = _walk_component(indices, kernel, prior, iterations, alpha, denominator)
        if metrics["component_mass"] <= 0:
            continue
        inputs = [dict(id=s["id"], text=s["label"], kind=s["kind"],
            initial_component_mass=next(t["mass"] for t in s["targets"] if t["id"] == seq[0]))
            for s in starters if any(t["id"] == seq[0] and _number(t.get("mass"), True) for t in s["targets"])]
        routes.append(dict(id="walk:"+digest(seq)[:24], nodes=[deepcopy(node_map[s]) for s in seq],
            hops=[deepcopy(edges[u, v]) for u, v in zip(seq, seq[1:])],
            route_kind="NATIVE_MAXIMUM_PRODUCT_WITNESS" if seq in native_paths else "POSITIVE_NATIVE_WALK_COMPONENT",
            native_witness=seq in native_paths, walk_metrics=metrics,
            query_inputs=inputs, starter_id=inputs[0]["id"] if inputs else None,
            starter_target_id=seq[0], starter_target_mass=inputs[0]["initial_component_mass"] if inputs else None,
            source_readout_binding=cf["binding"], time_consistency_certified=True,
            meaning="One complete positive last-restart walk component at the saved horizon; not all corridor usage, factual support, or correctness."))
    selected, diversity = diverse_routes(routes)
    diversity.update(search_expansions=expansions, search_expansion_limit=4096, enumerated_path_limit=256,
        simple_path_hop_limit=min(iterations, 12), longest_extra_detour_hops=2)
    return selected, diversity, selected_walk_mass([[state_index[n["id"]] for n in r["nodes"]] for r in selected],
        kernel, prior, iterations=iterations, alpha=alpha, endpoint_mass=denominator)


def replay(retrieval, result, case=None, *, compact_budget=48, expanded_budget=1024, alpha=.85):
    case = public_case(case)
    rows = _rows(result, case)
    eligible = retrieval["eligible"]; corpus = eligible.corpus
    veto = _veto(corpus)
    endpoints = endpoint_sets(rows, retrieval, case, veto)
    lexical = {r["id"]: lexical_routes(r, retrieval, case) for r in rows}
    raw_starters = retrieval.get("_starter_priors", [])
    if any(s["kind"] == "context" for s in raw_starters):
        raise ValueError("Whole-query numerical restart is not a v6 atomic starter")
    bundle = retrieval.get("hierarchy_bundle")
    common = dict(version=VERSION, task=case["task"], targets=task_targets(case, result),
        case_binding_sha256=digest(case), handling_veto_documents=sorted(veto),
        walk_definitions=deepcopy(WALK_DEFINITION), correctness_probability=False,
        starter_policy="Only recorded actual atom/direct-question priors; no whole-query numerical restart")
    if bundle is None:
        return dict(common, status="LEXICAL_ONLY", nodes=[], edges=[], frames=[], starters=[],
            candidate_flows={r["id"]: dict(**endpoints[r["id"]], endpoint_ids=[], source_contributor_ids=[],
                endpoint_mass=None, represented_routes=lexical[r["id"]], lexical_routes=lexical[r["id"]],
                selected_walk_metrics=unknown_metrics("NO_NATIVE_DIFFUSION"),
                diversity=dict(selected_count=0, unavailable_reason="NO_NATIVE_DIFFUSION")) for r in rows})
    count = retrieval["receipt"]["diffusion"]["iterations"]
    recorded_alpha = retrieval["receipt"]["diffusion"].get("alpha", alpha)
    if recorded_alpha != alpha:
        raise ValueError("Requested alpha differs from executed native diffusion")
    _, functions = clone(flow_v3, dict(endpoint_sets=lambda *_: deepcopy(endpoints),
        maximum_product_witness=lambda kernel, prior, targets: maximum_product_witness(kernel, prior, targets, alpha=alpha)))
    value = functions["replay"](retrieval, result, compact_budget=compact_budget, expanded_budget=expanded_budget, alpha=alpha)
    final = diffuse(bundle.kernel, bundle.prior, count, alpha)
    full_native = retrieval.get("_full_mass")
    if full_native is not None and not np.allclose(final, full_native, rtol=1e-12, atol=1e-14):
        raise ValueError("V6 finite replay differs from native final vector")
    value.update(common)
    state_index = {identity: i for i, identity in enumerate(bundle.state_ids)}
    full_starters = []
    for source in raw_starters:
        full_starters.append(dict(id=source["id"], kind=source["kind"], label=source["label"],
            total_mass=float(np.sum(source["values"])), targets=[dict(id=bundle.state_ids[i], mass=float(m))
                for i, m in enumerate(source["values"]) if m > 0]))
    value["starters"] = full_starters
    candidate_indices = {}
    for cid, cf in value["candidate_flows"].items():
        cf.update(identity_source_attested=endpoints[cid]["identity_source_attested"], factual_support_implied=False)
        for edge in cf["contribution_edges"]:
            edge["transition"] = float(bundle.kernel[state_index[edge["source"]], state_index[edge["target"]]])
        routes, diversity, metrics = numerical_routes(cf, value["expanded"]["nodes"], full_starters,
            bundle.kernel, bundle.prior, final, state_index, count, alpha)
        cf.update(represented_routes=routes or lexical[cid], lexical_routes=lexical[cid],
            diversity=diversity, selected_walk_metrics=metrics)
        candidate_indices[cid] = [state_index[t] for t in cf.get("endpoint_ids", []) + cf.get("source_contributor_ids", [])]
    attribution = starter_endpoint_shares(bundle.kernel, bundle.prior, raw_starters, candidate_indices,
        iterations=count, alpha=alpha, native_final=final)
    for cid, cf in value["candidate_flows"].items():
        cf["starter_endpoint_shares"] = attribution["candidates"].get(cid, [])
        cf["starter_attribution_status"] = attribution["status"]
    value["starter_superposition"] = {k: v for k, v in attribution.items() if k != "candidates"}
    value["expanded"]["walk_snapshot"] = snapshot(bundle, final, count, alpha)
    value["walk_snapshot_sha256"] = value["expanded"]["walk_snapshot"]["sha256"]
    return value
