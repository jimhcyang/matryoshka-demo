"""Local read-only v6 workbench endpoints; frozen earlier viewers stay intact."""
from functools import partial
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace
from urllib.parse import parse_qs, unquote, urlsplit

from matryoshka_demo import exploration_v2
from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.corpus_policy_v5 import scoped_page_view
from .flow_projection import condition, guide, _bound_path
from .flow_projection_v64 import presentation
from .server_origin_v64 import OriginV64Mixin
from .server_connections_v63 import ClosedPeerMixin
from matryoshka_demo.io import load_gzip
from matryoshka_demo.server import Handler as EarlierHandler
from matryoshka_demo.server_v5 import Handler as ArchivedHandler, ASSETS as ARCHIVED_ASSETS
from matryoshka_demo.vendor.matching import clone


ASSETS = {"workbench-v6.html", "workbench-v6.js", "workbench-v6.css", "app-theme-v6.css",
    "verdict-v64.js", "viewport-anchor-v64.js",
    "flow-view-v6.js", "flow-view-v6.css", "graph-full-v6.html", "graph-full-v6.js", "graph-full-v6.css",
    "data/report-v6.json", "data/ui-release-v6.json"}
PAGE_ORDER = "CAST(COALESCE(json_extract(payload,'$.source_char_start'),json_extract(payload,'$.earlier_page'),0) AS INTEGER),id"


def source_tools(excluded):
    def connect(*args, **kwargs):
        db = sqlite3.connect(*args, **kwargs)
        scoped_page_view(db, excluded)
        return db
    _, functions = clone(exploration_v2, dict(sqlite3=SimpleNamespace(connect=connect, Row=sqlite3.Row)))
    return functions


class Handler(ClosedPeerMixin, OriginV64Mixin, EarlierHandler):
    def do_GET(self):
        parsed = urlsplit(self.path)
        path = unquote(parsed.path)
        # Explicit archive URLs remain replayable; never substitute them for a
        # missing current condition or silently redirect the active workbench.
        if path.lstrip("/") in ARCHIVED_ASSETS:
            self.file(self.root / "web" / path.lstrip("/"), self.root / "web")
            return
        if path in {"/api/condition-v5", "/api/flow-v5", "/api/source-v5", "/api/node-v5", "/api/native-v5", "/api/guide-v5"}:
            try:
                ArchivedHandler.study_api(self, path, parse_qs(parsed.query))
            except (OSError, ValueError, KeyError, TypeError, IndexError):
                self.send_error(409, "No unchanged archived condition matches this explicit request")
            return
        if path in {"/", "/index.html"}:
            try:
                from .ui_release import validate
                validate(self.root)
            except (OSError, ValueError, KeyError):
                self.send_error(409, "The v6 presentation has not passed publication checks")
                return
            self.path = "/workbench-v6.html"
            self.file(self.root / "web/workbench-v6.html", self.root / "web")
            return
        if path.lstrip("/") in ASSETS:
            self.file(self.root / "web" / path.lstrip("/"), self.root / "web")
            return
        if path in {"/api/condition-v6", "/api/flow-v6", "/api/source-v6", "/api/node-v6", "/api/native-v6", "/api/guide-v6", "/api/guide-view-v6", "/api/guide-overlay-v63", "/api/guide-overlay-v64"}:
            try:
                self.study_api(path, parse_qs(parsed.query))
            except (OSError, ValueError, KeyError, TypeError, IndexError):
                self.send_error(409, "No unchanged eligible v6 artifact matches this request")
            return
        super().do_GET()

    def study_api(self, path, params):
        report = self.published_report(6)
        case_id = params.get("case_id", [""])[0]
        row = next((r for r in report["cases"] if r["case"]["case_id"] == case_id), None)
        if row is None:
            raise ValueError("Unknown v6 question")
        case = row["case"]
        arm = params.get("config", ["llm_readings"])[0]
        if path == "/api/condition-v6":
            value = condition(self.root, report, case_id, arm)
        elif path == "/api/flow-v6":
            value = presentation(self.root, report, case_id, arm, reading=params.get("reading", [None])[0],
                limit=int(params.get("limit", ["1024"])[0]))
        elif path == "/api/guide-v6":
            value = guide(self.root, report, case_id, arm, params.get("candidate_id", [""])[0],
                int(params.get("route_index", ["0"])[0]), params.get("reading", [None])[0])
        elif path == "/api/guide-view-v6":
            from .guide_views import request
            packet = guide(self.root, report, case_id, arm, params.get("candidate_id", [""])[0],
                int(params.get("route_index", ["0"])[0]), params.get("reading", [None])[0])
            value = request(self.root, report["graph_indexes"][case["corpus"]], case, packet, params,
                excluded_documents=report.get("handling_veto_documents", {}).get(case["corpus"], []))
        elif path in {"/api/guide-overlay-v63", "/api/guide-overlay-v64"}:
            from .ui_release import validate
            if path == "/api/guide-overlay-v64":
                from .guide_runtime_v64 import overlay
            else:
                from .guide_runtime_v63 import overlay
            validate(self.root)
            packet = guide(self.root, report, case_id, arm, params.get("candidate_id", [""])[0],
                int(params.get("route_index", ["0"])[0]), params.get("reading", [None])[0])
            value = overlay(self.root, report["graph_indexes"][case["corpus"]], case, packet,
                excluded_documents=report.get("handling_veto_documents", {}).get(case["corpus"], []))
        elif path == "/api/native-v6":
            selected = condition(self.root, report, case_id, arm)
            saved = next(iter(selected["configurations"].values()))
            target, _ = _bound_path(self.root, saved["native_checkpoint"], "data/runs_v6")
            value = load_gzip(target)
        else:
            reference = report["graph_indexes"][case["corpus"]]
            excluded = report.get("handling_veto_documents", {}).get(case["corpus"], [])
            functions = source_tools(excluded)
            if path == "/api/node-v6":
                value = functions["neighborhood"](self.root, reference, case, params.get("node_id", [""])[0], 30)
            else:
                source_id = params.get("source_id", [""])[0]
                value = functions["source_page"](self.root, reference, case, source_id)
                db = _connection(self.root, reference)
                try:
                    scoped_page_view(db, excluded)
                    pages = [json.loads(r[0]) for r in db.execute(
                        "SELECT payload FROM page WHERE doc=? AND date<? AND doc!=? ORDER BY "
                        + PAGE_ORDER,
                        (value["document_id"], case["date"], case["document_id"]))]
                finally:
                    db.close()
                value = dict(value, document_pages=pages, source_scope="Eligible canonical text segments; not invented PDF pages")
        self.json_response(value, compress=True)


def serve(root, workspace, port=8930):
    server = ThreadingHTTPServer(("127.0.0.1", port), partial(Handler, root=Path(root), workspace=Path(workspace)))
    print(f"Matryoshka v6: http://127.0.0.1:{port}/", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
