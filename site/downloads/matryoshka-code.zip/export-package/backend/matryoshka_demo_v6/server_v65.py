"""V6.5 local presentation and evidence adjudication over immutable native data."""
from collections import OrderedDict
from copy import deepcopy
from functools import partial
from http.server import ThreadingHTTPServer
from pathlib import Path
from threading import RLock
from types import FunctionType
from urllib.parse import unquote, urlsplit

from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.io import digest, load, sha
from . import server as previous
from .flow_projection import condition as native_condition
from .flow_projection_v65 import presentation
from .guide_v65 import guide
from .reporting_fixed_pool_decisions_v65 import evaluate, VERSION as DECISION_VERSION
from .server_origin_v65 import OriginV65Mixin


_DECISIONS = OrderedDict()
_LOCK = RLock()
REVIEW_ONLY = {"assessment", "analyst_digest", "post_unmask_comparison", "reference_answer",
               "reference_answer_kind", "ground_truth", "correct_answer", "local_decision_assessment_v65"}
REVIEW_POINTER = "web/data/local-decision-review-v65.json"
DECISION_POINTER = "web/data/local-decision-release-v65.json"


def decision_index(root, report):
    root = Path(root).resolve()
    path = root / DECISION_POINTER
    if path.is_symlink():
        raise ValueError("Local decision pointer cannot redirect through a symlink")
    if not path.exists():
        return None
    if path.resolve(strict=True) != path:
        raise ValueError("Local decision pointer cannot redirect through a symlink")
    value = load(path)
    if (value.get("version") != "local-decision-release-index/6.5"
            or value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"})):
        raise ValueError("Local decision release pointer changed")
    if value["report_run_id"] != report["run_id"]:
        return None
    if not isinstance(value.get("releases"), list) or not value["releases"]:
        raise ValueError("Local decision release index is empty")
    public_ids = {row["case"]["case_id"] for row in report["cases"]}
    seen = set()
    for item in value["releases"]:
        ref = item["ref"]
        relative = Path(ref["path"])
        target = root / relative
        if (relative.is_absolute() or ".." in relative.parts
                or target.resolve(strict=True) != target
                or not target.is_relative_to(root / "experiments/ui_v65/decision_releases")
                or sha(target) != ref["sha256"]):
            raise ValueError("Local decision release artifact changed")
        if (not item["cases"] or len(item["cases"]) != len(set(item["cases"]))
                or not set(item["cases"]) <= public_ids
                or not item["configurations"]
                or len(item["configurations"]) != len(set(item["configurations"]))
                or not set(item["configurations"]) <= {"llm_readings", "llm_atoms", "llm_local"}):
            raise ValueError("Invalid local decision release membership")
        conditions = {(cid, arm) for cid in item["cases"] for arm in item["configurations"]}
        if seen & conditions:
            raise ValueError("Ambiguous local decision release mapping")
        seen.update(conditions)
    return value


def review_index(root, report):
    root = Path(root).resolve()
    path = root / REVIEW_POINTER
    if path.is_symlink():
        raise ValueError("Local assessment pointer cannot redirect through a symlink")
    if not path.exists():
        return None
    if path.resolve(strict=True) != path:
        raise ValueError("Local assessment pointer cannot redirect through a symlink")
    value = load(path)
    if (value.get("version") != "local-decision-review-index/6.5"
            or value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"})):
        raise ValueError("Local decision assessment pointer changed")
    if value["report_run_id"] != report["run_id"]:
        return None
    for item in value["assessments"]:
        ref = item["ref"]
        target = root / ref["path"]
        if (Path(ref["path"]).is_absolute() or ".." in Path(ref["path"]).parts
                or target.resolve(strict=True) != target
                or not target.is_relative_to(root / "experiments/ui_v65/assessment")
                or sha(target) != ref["sha256"]):
            raise ValueError("Local decision assessment artifact changed")
    return value


def source_only(value):
    if isinstance(value, dict):
        return {k: source_only(v) for k, v in value.items() if k not in REVIEW_ONLY}
    if isinstance(value, list):
        return [source_only(v) for v in value]
    return value


def condition(root, report, case_id, arm):
    root = Path(root).resolve()
    value = native_condition(root, report, case_id, arm)
    safe_report = dict(cases=[dict(case=value["case"])], graph_indexes=report["graph_indexes"],
                       source_binding=report["source_binding"])
    releases = decision_index(root, report)
    for record in value.get("configurations", {}).values():
        case = value["case"]
        reference = report["graph_indexes"][case["corpus"]]
        if (record.get("case") != case or record.get("exploration_index_ref") != reference
                or record.get("source_binding_sha256") != report["source_binding"]["sha256"]):
            raise ValueError("Local decision source index differs from the saved source binding")
        # Retain source/checkpoint gates even on a cached presentation decision.
        db = _connection(root, reference)
        db.close()
        clean = source_only(record)
        key = digest(dict(version=DECISION_VERSION, checkpoint=record["native_checkpoint"],
            native_checksum=record["native_checksum"], case=case, config=record["config"],
            source_index=reference, source_binding=report["source_binding"], clean_observer_input=digest(clean)))
        with _LOCK:
            supplement = deepcopy(_DECISIONS.get(key))
        refs = [entry["ref"] for entry in releases["releases"]
                if case_id in entry["cases"] and record["config"] in entry["configurations"]] if releases else []
        if refs:
            # The verified loader has its own byte/stamp cache. Replaying its
            # guards on every access keeps a warm UI cache from hiding tampering.
            from .reporting_decision_release_v65 import load_for
            supplement = load_for(root, refs[0], case, clean, report)
        elif supplement is None:
            supplement = evaluate(root, safe_report, clean)
            with _LOCK:
                _DECISIONS[key] = deepcopy(supplement)
                _DECISIONS.move_to_end(key)
                while len(_DECISIONS) > 12:
                    _DECISIONS.popitem(last=False)
        record["local_decisions_v65"] = supplement
    # Assessment bytes are read only after every source-only decision has
    # succeeded. A review can annotate an inference, never supply its inputs.
    reviews = review_index(root, report)
    if reviews:
        for record in value.get("configurations", {}).values():
            refs = [entry["ref"] for entry in reviews["assessments"]
                    if case_id in entry["cases"] and record["config"] in entry["configurations"]]
            if len(refs) > 1:
                raise ValueError("Ambiguous local decision assessment mapping")
            if refs:
                from .reporting_decision_assessment_v65 import response_field
                record["local_decision_assessment_v65"] = response_field(root, refs[0],
                    case_id=case_id, config=record["config"], gate=record["local_decisions_v65"])
    value["presentation_pipeline_version"] = "6.5"
    return value


# Dispatch is the same verified source API with three explicitly rebound
# observer functions. The old module globals and old route implementation stay
# intact for archived viewers and tests.
_scope = dict(vars(previous), condition=condition, presentation=presentation, guide=guide)
_api = FunctionType(previous.Handler.study_api.__code__, _scope,
    previous.Handler.study_api.__name__, previous.Handler.study_api.__defaults__,
    previous.Handler.study_api.__closure__)
_api.__kwdefaults__ = deepcopy(previous.Handler.study_api.__kwdefaults__)


class Handler(OriginV65Mixin, previous.Handler):
    study_api = _api

    def published_report(self, version=2):
        report = super().published_report(version)
        if version == 6:
            from .ui_release import POINTER, validate
            pointer = self.root / POINTER
            active = load(pointer) if pointer.exists() else {}
            if report.get("presentation_version") == "6.5" or active.get("presentation_version") == "6.5":
                validate(self.root)
        return report

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        if path == "/local-decisions-v65.js":
            return self.file(self.root / "web/local-decisions-v65.js", self.root / "web")
        return super().do_GET()


def serve(root, workspace, port=8930):
    handler = partial(Handler, root=root, workspace=workspace)
    server = ThreadingHTTPServer(("127.0.0.1", port), handler)
    print(f"Matryoshka V6.5: http://127.0.0.1:{port}/", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
