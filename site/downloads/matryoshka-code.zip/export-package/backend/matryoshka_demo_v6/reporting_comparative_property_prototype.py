"""Opt-in source-owned license for explicit indefinite comparative properties.

This is narrower than English grammaticality: nominal coercion is withheld
unless the same degree+nominal+carrier construction is source-attested. It is
not factual support, counterevidence, a replacement native gate, or active code.
"""
import re

from . import reporting_candidate_alignment_prototype as alignment

VERSION = "source-owned-comparative-property-prototype/1"
_SHELL = re.compile(r"\b(a|an)\s+(more|less)\s*$", re.I)


class ComparativeProperty:
    def __init__(self, case, reading, pages, *, parse=None):
        self.context = alignment.Alignment(case, pages, parse=parse)
        self.reading = reading
        left, right = self.context.case["query"].split(self.context.case["focal_marker"])
        self.shell = _SHELL.search(left)
        self.applies = bool(self.shell and reading.get("form") == "modifier"
            and reading.get("role") == "nominal_property" and reading.get("target_kind") == "property")

    def evaluate(self, candidate):
        value = dict(version=VERSION, prototype_only=True, status="NOT_APPLICABLE", omit=False,
            syntax_license_only=True, factual_support_certified=False,
            english_ungrammaticality_certified=False, absence_is_counterevidence=False)
        if not self.applies:
            return dict(value, reason="NOT_THE_EXPLICIT_INDEFINITE_COMPARATIVE_PROPERTY_READING")
        ctx = self.context
        try:
            page, source, _ = ctx.source(candidate)
            replay = ctx.replay_fill(self.reading, candidate, page)
            left, right = ctx.case["query"].split(ctx.case["focal_marker"])
            raw = left + candidate["fill"] + right
            a, b = len(left), len(left) + len(candidate["fill"])
            part = ctx.part(raw, a, b)
            if part is None:
                raise ValueError("INSERTION_TOKEN_ALIGNMENT_UNRESOLVED")
            degree_at = self.shell.start(2)
            degree = part.doc.char_span(degree_at, degree_at + len(self.shell.group(2)), alignment_mode="strict")
            if degree is None:
                raise ValueError("DEGREE_TOKEN_ALIGNMENT_UNRESOLVED")
            head, source_head, operator = part.root, source.root, degree.root
            carrier = head.head
            value.update(status="UNRESOLVED", source_head=alignment._proof(source_head, page["text"]),
                query_head=alignment._proof(head, raw), degree=alignment._proof(operator, raw),
                query_carrier=alignment._proof(carrier, raw), fill_derivation=replay,
                degree_modifies_inserted_property=operator.dep_ == "advmod" and operator.head in part)
            property_head = lambda t:t.pos_ == "ADJ" or t.tag_ in {"VBN", "VBG"}
            carrier_ok = carrier not in part and carrier.pos_ in {"NOUN", "PROPN"}
            if (property_head(source_head) and property_head(head) and carrier_ok
                    and head.dep_ in {"amod", "acl"} and value["degree_modifies_inserted_property"]):
                return dict(value, status="LICENSED_ADJECTIVAL_OR_PARTICIPIAL_PROPERTY", reason="SOURCE_PROPERTY_AND_QUERY_DEGREE_ATTACHMENT")
            if source_head.pos_ in {"NOUN", "PROPN", "PRON"}:
                if property_head(head):
                    return dict(value, reason="NOMINAL_SOURCE_PROPERTY_QUERY_DISAGREEMENT_NEUTRAL")
                source_carrier = source_head.head
                prior = [t for t in source.doc[:source_head.i] if not t.is_space][-2:]
                attested = (carrier_ok and source_head.dep_ in {"compound", "amod"}
                    and source_carrier not in source and source_carrier.pos_ in {"NOUN", "PROPN"}
                    and alignment._lemma(source_carrier) == alignment._lemma(carrier)
                    and len(prior) == 2 and prior[0].lower_ in {"a", "an"}
                    and prior[1].lower_ == self.shell.group(2).lower()
                    and prior[1].head in {source_head, source_carrier})
                if attested:
                    return dict(value, status="LICENSED_SOURCE_ATTESTED_NOMINAL_DEGREE_CONSTRUCTION",
                        source_degree=alignment._proof(prior[1], page["text"]),
                        source_carrier=alignment._proof(source_carrier, page["text"]),
                        reason="NOMINAL_COERCION_ATTESTED_IN_THE_SAME_SOURCE_CONSTRUCTION_NOT_GENERALIZED")
                return dict(value, status="UNLICENSED_NOMINAL_COMPARATIVE_PROPERTY", omit=True,
                    reason="NOMINAL_SOURCE_HAS_NO_ATTESTED_DEGREE_PROPERTY_USAGE")
            return dict(value, reason="PROPERTY_ATTACHMENT_NOT_PROVED_NEUTRAL")
        except (KeyError, ValueError, TypeError, IndexError) as error:
            return dict(value, status="UNRESOLVED", reason=str(error))
