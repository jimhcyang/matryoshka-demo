"""Current guide facade with fixed checkout paths and sealed helper sources."""
from pathlib import Path

from .guide_runtime_v63 import _module


PREFIX = "experiments/ui_v64/graph/"
HELPER = PREFIX + "guide_runtime_v64.py"
FILES = tuple(PREFIX + name for name in (
    "guide_v63_base.zip", "guide_navigator_v64.js", "guide_motion_v64.js", "guide_styles_v64.css",
    "guide_overlay_v64.py", "guide_mapping_audit_v64.json", "guide_runtime_v64.py", "server_guide_v64.py",
    "guide_contract_v64.json", "guide_derive_v64.py", "guide_derivation_v64.json",
)) + ("matryoshka_demo_v6/guide_runtime_v64.py", "scripts/derive_graph_full_v64.py")


def helper(root):
    root = Path(root).resolve()
    if root != Path(__file__).resolve().parents[1]:
        raise ValueError("Current guide belongs to its own checkout")
    return _module(root, HELPER)


def validate(root):
    return helper(root).validate(root)


def outputs(root):
    value = helper(root)
    value.validate(root)
    return value._module(Path(root).resolve(), "guide_derive_v64.py").outputs(root)


def overlay(root, reference, case, packet, *, excluded_documents=()):
    return helper(root).overlay(root, reference, case, packet, excluded_documents=excluded_documents)
