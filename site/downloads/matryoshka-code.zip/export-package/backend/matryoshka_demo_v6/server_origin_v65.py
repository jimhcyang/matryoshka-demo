"""Privileged V6.5 source-pool origins; never native evidence or planning input."""
from copy import deepcopy
import json
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from . import server_origin_v63 as base
from . import server_origin_v64 as previous


V65_RELEASE_ROOTS = ("experiments/curation_v65_cib/releases", "experiments/curation_v65_cables/releases",
                     "experiments/curation_v65_overlap/releases", "experiments/curation_v65_expanded/releases")
RELEASE_ROOTS = (*previous.RELEASE_ROOTS, *V65_RELEASE_ROOTS)
_sealed_proof = previous._isolated(base._proof, dict(RELEASE_ROOTS=RELEASE_ROOTS))


def _paired_transcript(root, case, proof):
    audit = proof["source_origin_audit"]
    canonical, reference = audit["canonical_ref"], audit["paired_transcript_ref"]
    if Path(reference["path"]) != Path(canonical["path"]).with_name("page_pairs.jsonl"):
        raise ValueError("Paired source transcript is outside its canonical preparation")
    workspace = Path(root).resolve().parent
    path = base._bound_file(workspace, reference["path"], reference["sha256"],
        directory=workspace / "src-redaction/data/preparation_refresh/runs")
    with path.open() as stream:
        matches = [row for line in stream if (row := json.loads(line)).get("canonical_page_id") == proof["origin"]["source_id"]]
    if (matches != [audit["paired_record"]] or matches[0]["document_id"] != case["document_id"]):
        raise ValueError("Paired source transcript does not replay")
    pages = {}
    for release in ("earlier", "later"):
        canonical_page = audit["canonical_row"][release + "_source_page"]
        page = proof.get("physical_" + release + "_pdf_page", audit.get(release + "_physical_pdf_page", canonical_page))
        if (type(page) is not int or page < 1 or page != matches[0][release + "_page"]
                or page != canonical_page
                or (release + "_physical_pdf_page" in audit and audit[release + "_physical_pdf_page"] != page)):
            raise ValueError("Physical source page does not replay")
        pages[release] = page
    return pages


def _proof(root, row):
    release_root = Path(row["source_manifest_ref"]["path"]).parent.parent.as_posix()
    if release_root not in V65_RELEASE_ROOTS:
        proof, proof_hash = previous._proof(root, row)
        if row["case"]["corpus"] != "cib":
            from .server_origin_reaudit_v65 import enrich
            return enrich(root, row, proof, proof_hash)
        return proof, proof_hash
    proof, proof_hash = _sealed_proof(root, row)
    case, source = row["case"], proof["origin"]
    if case["corpus"] != "cib":
        if (release_root not in V65_RELEASE_ROOTS[1:] or source.get("classification") != "SECRET"
                or case["document_id"] not in proof.get("source_origin_audit", {}).get("original_raw_documents", {})):
            raise ValueError("Cable origin requires its sealed original SECRET body")
        # The original full-body, sibling handling, quote and offset guards run
        # unchanged in base.origin; no private audit dictionary is returned.
        return proof, proof_hash
    if release_root != V65_RELEASE_ROOTS[0]:
        raise ValueError("CIB origin is outside its explicit source-curation root")
    if case["task"] == "redaction":
        category = previous._cib_focal_category(root, case, proof)
        adapted = deepcopy(proof)
        adapted["origin"]["projection_policy"] = "focal_reveal_only_all_other_nonshared_units_remain_opaque"
        adapted["origin_anchors"][0]["focal"] = True
    else:
        if not proof.get("source_origin_audit", {}).get("canonical_ref"):
            raise ValueError("CIB analyst questions require exact canonical reveal units")
        category = base._source_category(root, {}, case, proof, source)
        if not (category["source_category"] == "CIB_VERIFIED_REVEAL"
                and category["unit_verified"] is True and category["secret_derived"] is True):
            raise ValueError("CIB analyst question is not verified reveal-dependent")
        pages = _paired_transcript(root, case, proof)
        adapted = deepcopy(proof)
        for release, page in pages.items():
            adapted["physical_" + release + "_pdf_page"] = page
    adapted["_origin_v65_category"] = category
    return adapted, proof_hash


def _source_category(root, report, case, proof, source):
    if "_origin_v65_category" in proof:
        return deepcopy(proof["_origin_v65_category"])
    return previous._source_category(root, report, case, proof, source)


origin = previous._isolated(base.origin, dict(_proof=_proof, _source_category=_source_category))


class OriginV65Mixin(previous.OriginV64Mixin):
    """Backward-compatible route and no-store headers, with explicit V6.5 roots."""

    def do_GET(self):
        parsed = urlsplit(self.path)
        if unquote(parsed.path) != "/api/origin-v63":
            return super().do_GET()
        try:
            params = parse_qs(parsed.query, keep_blank_values=True, strict_parsing=True)
            if (set(params) - {"case_id", "reveal_focal"} or len(params.get("case_id", [])) != 1
                    or any(len(v) != 1 for v in params.values())
                    or params.get("reveal_focal", ["0"])[0] not in {"0", "1"}):
                raise ValueError("Only a published source origin and explicit focal reveal are accepted")
            packet = origin(self.root, self.published_report(6), params["case_id"][0],
                reveal_focal=params.get("reveal_focal", ["0"])[0] == "1")
            self.json_response(packet, compress=True)
        except (OSError, ValueError, KeyError, TypeError, IndexError):
            self.send_error(409, "No unchanged audited query provenance matches this request")
