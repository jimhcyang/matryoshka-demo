"""Literal source units and shared model plans, without parent-global mutation."""
from copy import deepcopy
from functools import lru_cache
import re
from types import FunctionType, ModuleType

from matryoshka_demo import planning_v3 as wire
from matryoshka_demo import planning_v5 as previous
from matryoshka_demo.contracts import public_case, span
from matryoshka_demo.io import digest
from matryoshka_demo.vendor.matching import clone


VERSION = "source-unit-validated-planning/6"
CONTEXT_VERSION = "source-section-and-focal-window/6"
ARMS = wire.ARMS
# Layout syntax, not a list of countries, entities or benchmark answers.
SECTION = re.compile(r"(?m)^[ \t]*[-*]{1,3}[ \t]*(?:[A-Z]|\d+)[.)](?=[ \t]|$)")
_OPEN_QUOTE = re.compile(r"\b(?:qte|quote|unqte|unquote|end\s+quote)\b", re.I)
# Conventional English rank abbreviations missing from the small model's
# tokenizer exceptions. They license punctuation only, never actor identity.
_RANK_ABBREVIATIONS = frozenset("lt. brig. col. maj. capt. cmdr. cdr. adm. sgt. cpl.".split())


@lru_cache(maxsize=1)
def _abbreviations():
    return {s.casefold() for s in wire.nlp().tokenizer.rules if s.endswith(".")} | _RANK_ABBREVIATIONS


def sentences(text):
    """Return exact spans; line wrapping is not a sentence boundary."""
    cuts = {0, len(text)}
    sections = list(SECTION.finditer(text))
    for marker in sections:
        cuts.update(marker.span())
    for match in re.finditer(r"[.!?]+[\"')\]]*(?=\s|$)|\n[ \t\r]*\n", text):
        if match.group().startswith("\n"):
            cuts.update(match.span())
            continue
        if match.group().startswith("."):
            word = re.search(r"[A-Za-z.]+\.$", text[:match.start()+1])
            if word and (re.fullmatch(r"(?:[A-Za-z]\.)+", word.group())
                         or word.group().casefold() in _abbreviations()):
                continue
        cuts.add(match.end())
    ordered = sorted(cuts)
    for a, b in zip(ordered, ordered[1:]):
        while a < b and text[a].isspace():
            a += 1
        while b > a and text[b-1].isspace():
            b -= 1
        if b > a:
            yield span(text, a, b)


def _open_reporting_context(prior):
    # A complete inner sentence is still not an unqualified outer assertion.
    quotes = prior.count('"') + prior.count("\u201c") + prior.count("\u201d")
    if quotes % 2:
        return True
    markers = list(_OPEN_QUOTE.finditer(prior))
    if markers and markers[-1].group().casefold() in {"qte", "quote"}:
        return True
    for match in re.finditer(":", prior):
        at = match.start()
        if at and at+1 < len(prior) and prior[at-1].isdigit() and prior[at+1].isdigit():
            continue
        before = prior[:at].split("\n\n")[-1]
        prefix = re.split(r"[.!?]\s+", before)[-1]
        doc = wire.offset_safe_parser(wire.nlp())(prefix)
        reported = any(wire.matching.lemma(t) in wire.matching.parent._REPORTING for t in doc)
        after = prior[at+1:]
        closed = (after.count('"') >= 2 and after.count('"') % 2 == 0
                  or re.search(r"\b(?:unqte|unquote|end\s+quote)\b", after, re.I))
        if reported and not closed:
            return True
    return False


def _scope_bound(text, quote, query, at):
    normalize = lambda s: " ".join(s.split()).casefold().rstrip(".!?")
    units = list(sentences(query))
    complete = [s for s in units if at <= s["start"] and s["end"] <= at+len(quote)]
    literal_block = bool(complete and complete[0]["start"] == at
                         and complete[-1]["end"] == at+len(quote))
    if (literal_block
            and normalize(text) == normalize(quote)
            and quote.rstrip().endswith("?") == text.rstrip().endswith("?")):
        return not _open_reporting_context(query[:at])
    targets = wire._frames(text)
    available = [f for f in wire._frames(query) if at <= f["predicate_proof"]["start"]
                 and f["predicate_proof"]["end"] <= at+len(quote)]
    if not targets:
        return False
    for target in targets:
        compatible = [s for s in available if s["predicate"] == target["predicate"]
                      and wire._compatible_arguments(target, s)]
        if not any(wire._scope_matches(target, s) for s in compatible):
            return False
    return True


def select_context(case, policy="paragraph", word_budget=wire.PRESENTATION_WORDS):
    case = public_case(case)
    if policy not in {"paragraph", "focal_window"} or type(word_budget) is not int or word_budget < 1:
        raise ValueError("Invalid source context policy")
    q = case["query"]
    a, b, reason, exceeds = 0, len(q), "COMPLETE_CLAIM_QUERY", False
    boundaries = []
    if case["task"] == "redaction":
        at = q.index(case["focal_marker"])
        boundaries = [(m.start(), m.end()) for m in re.finditer(r"\r?\n[ \t\r]*\n", q)]
        boundaries.extend(m.span() for m in SECTION.finditer(q))
        a = max([y for _, y in boundaries if y <= at] or [0])
        b = min([x for x, _ in boundaries if x > at] or [len(q)])
        while a < b and q[a].isspace():
            a += 1
        while b > a and q[b-1].isspace():
            b -= 1
        reason = "FOCAL_SOURCE_SECTION_PARAGRAPH"
        if policy == "focal_window" or len(q[a:b].split()) > word_budget:
            units = list(sentences(q[a:b]))
            i = next(i for i, s in enumerate(units) if s["start"] <= at-a < s["end"])
            lo, hi = units[i]["start"], units[i]["end"]
            exceeds = len(q[a+lo:a+hi].split()) > word_budget
            if i and len(q[a+units[i-1]["start"]:a+hi].split()) <= word_budget:
                lo = units[i-1]["start"]
            if i+1 < len(units) and len(q[a+lo:a+units[i+1]["end"]].split()) <= word_budget:
                hi = units[i+1]["end"]
            a, b = a+lo, a+hi
            reason = "FOCAL_SENTENCE_PRESENTATION_WINDOW"
    selected = q[a:b]
    return dict(case=dict(case, query=selected), mapping=dict(version=CONTEXT_VERSION,
        policy=policy, reason=reason, presentation_word_budget=word_budget,
        focal_sentence_exceeds_budget=exceeds, selected_words=len(selected.split()),
        source_query_sha256=digest(q), query_sha256=digest(selected), source_start=a,
        source_end=b, selected_start=0, selected_end=len(selected),
        pieces=[dict(kind="COPY", source_start=a, source_end=b, selected_start=0,
                     selected_end=len(selected))], support_or_retrieval_tuned=False,
        sentence_splitter="offset-preserving-source-units/6",
        structure_boundaries=[dict(start=x, end=y, text=q[x:y]) for x, y in sorted(boundaries)]))


class _Calls(wire._Calls):
    def call(self, stage, payload, *, record_key=None):
        # One existing format retry gets twice the output room after a proven
        # truncation. This is an operational limit, not answer-dependent tuning.
        limit = wire.MAX_OUTPUT_TOKENS * (2 if "format_retry" in payload else 1)
        context = dict(vars(wire), MAX_OUTPUT_TOKENS=limit)
        call = FunctionType(wire._Calls.call.__code__, context, "call",
                            wire._Calls.call.__defaults__, wire._Calls.call.__closure__)
        call.__kwdefaults__ = deepcopy(wire._Calls.call.__kwdefaults__)
        return call(self, stage, payload, record_key=record_key)


_context, _functions = clone(wire, dict(sentences=sentences, _scope_bound=_scope_bound,
                                      select_context=select_context, _Calls=_Calls))
_wire = ModuleType(wire.__name__)
_wire.__dict__.update(_context)
_, _workflow = clone(previous, dict(previous=_wire))
get_plans = _functions["get_plans"]
validate_plan = _functions["validate_plan"]


def prepare(case, **kwargs):
    bundle = _workflow["prepare"](case, **kwargs)
    bundle["workflow_version"] = VERSION
    bundle["source_unit_policy"] = dict(version=VERSION,
        raw_model_outputs_modified=False, parent_module_globals_modified=False,
        complete_literal_units_licensed=True, open_reporting_context_guard=True)
    return bundle
