"""Optional presentation-only adapter for the staged flow UI.

The lead may call with_solver_stopping on the already verified projection and
its bound native result. This never runs, shortens, or rewrites a native walk.
"""
from copy import deepcopy


PRESENTATION_VERSION = "flow-ui/6.3"


def with_solver_stopping(projection, result):
    value = deepcopy(projection)
    value["flow_ui_presentation_version"] = PRESENTATION_VERSION
    value["solver_stopping"] = None
    if not projection.get("frames"):
        return value
    retrieval = result.get("retrieval", {})
    trace = retrieval.get("diffusion")
    source = "result.retrieval.diffusion"
    if not trace:
        trace = retrieval.get("receipt", {}).get("diffusion")
        source = "result.retrieval.receipt.diffusion"
    if not trace:
        return value
    if (trace.get("iterations") != projection.get("iterations")
            or trace.get("alpha") != projection.get("alpha")):
        raise ValueError("Stopping metadata is not bound to this saved replay")
    value["solver_stopping"] = {
        key: deepcopy(trace.get(key)) for key in
        ("version", "alpha", "tolerance", "iterations", "converged",
         "residual", "error_bound", "norm")
    }
    value["solver_stopping"]["source"] = source
    return value


def presentation(root, report, case_id, arm, *, reading=None, limit=1024):
    """Drop-in staging override; delegate all native validation unchanged.

    Assign this to the staging server's presentation alias, NOT the native
    projection module's function, which must remain unchanged.
    """
    from matryoshka_demo_v6 import flow_projection as native

    value = native.presentation(root, report, case_id, arm, reading=reading, limit=limit)
    selected = native.condition(root, report, case_id, arm)
    records = selected.get("configurations", {})
    result = next(iter(records.values()))["result"] if records else {}
    return with_solver_stopping(value, result)
