"""Explicit new version; immutable6.5.7 and native inference stay unchanged."""
from types import FunctionType

from . import reporting_fixed_pool_decisions_presentation as previous
from . import reporting_fixed_pool_role_projection_v2 as roles

VERSION="local-evidence-sufficiency/6.5.8-presentation-argument-role-request"
ENGINE_VERSION="fixed-inspected-pool-with-finite-argument-role-and-request/3"
parent=previous.parent
frozen=previous.frozen
requests=previous.requests
_read_binding=previous._read_binding


def _bind(function,overrides):
    # Private copied function namespace, never mutation of the frozen parent.
    result=FunctionType(function.__code__,dict(vars(previous),**overrides),function.__name__,function.__defaults__)
    result.__kwdefaults__=function.__kwdefaults__
    return result


_local_groups=_bind(previous._local_groups,dict(roles=roles))
_supplement=_bind(previous._supplement,dict(roles=roles))
derive=_bind(previous.derive,dict(roles=roles,VERSION=VERSION,ENGINE_VERSION=ENGINE_VERSION,
    _local_groups=_local_groups,_supplement=_supplement))
evaluate=_bind(previous.evaluate,dict(derive=derive))
