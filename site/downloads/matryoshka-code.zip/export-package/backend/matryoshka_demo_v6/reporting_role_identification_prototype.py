"""Isolated raw-source role identification, not tenure or event support.

Only explicit `NAME is identified as TITLE` requirements are accepted. Literal
full-name appositions bind titles; there are no aliases, historical dictionaries,
model labels as truth, global node attributes, native verdict reuse or reranking.
"""
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import scope_matching as scoped
from matryoshka_demo_v61.role_alignment import ROLES
from . import planning as literal
from . import reporting_local_decisions_v65 as policy

VERSION = "raw-source-role-identification-prototype/1"
_QUERY = re.compile(r"(?P<name>[A-Za-z]+(?:[-'][A-Za-z]+)*(?:\s+[A-Za-z]+(?:[-'][A-Za-z]+)*)*) is identified as (?P<title>[^.!?;:\n]+)\.", re.I)
_WORD = re.compile(r"[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*")
_NAME_DEPS = {"compound", "flat", "flat:name", "name", "amod", "nmod"}
_NOMINAL_DEPS = _NAME_DEPS | {"nummod", "appos"}
_QUALIFIER = re.compile(r"\b(?:former|formerly|acting|interim|deputy|vice|assistant|alleged|allegedly|"
    r"possible|possibly|purported|purportedly|suspected|apparently|reportedly|probably|perhaps|"
    r"imaginary|fake|future|prospective|not|no|never|neither|nor|if|unless|whether)\b", re.I)
_NONASSERTIVE = {"imagine", "picture", "pretend", "suppose", "assume", "hypothesize", "believe", "think", "doubt",
    "hope", "wish", "want", "intend", "plan", "expect", "predict", "forecast", "propose", "deny", "allege", "claim"}
_PREFIX_SCOPE = re.compile(r"\b(?:according\s+to|if|unless|suppose|assuming|allegedly|reportedly|possibly|perhaps)\b", re.I)
_NUMERAL = re.compile(r"(?:\d+(?:st|nd|rd|th)?|[IVXLCDM]+)", re.I)


def _norm(text): return " ".join(text.lower().split())
def _pattern(text): return r"\s+".join(re.escape(w) for w in text.split())
def _literal_identifier(token): return token.pos_ != "PUNCT" and bool(_NUMERAL.fullmatch(token.text))


def _external_operator_open(prefix, engine):
    if literal._open_reporting_context(prefix): return True
    operators = _NONASSERTIVE | scoped.matching.parent._REPORTING
    # A section marker cannot close an earlier hypothetical/reporting colon.
    # Conservative page-local persistence is intentional when no quotation
    # closure supplies a verifiable end to the operator's scope.
    for colon in re.finditer(":", prefix):
        at = colon.start()
        if at and at + 1 < len(prefix) and prefix[at - 1].isdigit() and prefix[at + 1].isdigit(): continue
        before = re.split(r"[.!?]\s+|\n[ \t]*\n", prefix[:at])[-1]
        doc = engine.parse(before)
        if (_PREFIX_SCOPE.search(before) or any(t.lemma_.lower() in operators for t in doc)):
            after = prefix[at + 1:]
            if not (re.search(r"\b(?:unqte|unquote|end\s+quote)\b", after, re.I)
                    or after.count('"') >= 2 and after.count('"') % 2 == 0): return True
    for unit in literal.sentences(prefix):
        if re.search(r"\bfollowing\b", unit["text"], re.I) and any(t.lemma_.lower() in operators for t in engine.parse(unit["text"])):
            after = prefix[unit["end"]:]
            if not re.search(r"\b(?:unqte|unquote|end\s+quote)\b", after, re.I): return True
    return False


def _atoms(case, plan):
    atoms = plan.get("atoms", [])
    if plan.get("query_sha256") != digest(case["query"]) or not atoms or len({a["id"] for a in atoms}) != len(atoms):
        raise ValueError("Exact source-bound public plan required")
    before = 0
    for atom in sorted(atoms, key=lambda a: a["start"]):
        a, b = atom["start"], atom["end"]
        if (type(a) is not int or type(b) is not int or not before <= a < b <= len(case["query"])
                or case["query"][before:a].strip() or atom.get("required") is not True
                or atom["text"] != case["query"][a:b] or atom["source_quote"] != atom["text"]):
            raise ValueError("Lost, overlapping, optional or paraphrased query scope")
        before = b
    if case["query"][before:].strip(): raise ValueError("Unconsumed public query scope")
    return atoms


def query_spec(atom):
    match = _QUERY.fullmatch(atom["text"])
    if match is None or MASK.search(atom["text"]) or _QUALIFIER.search(match["title"]): return None
    name, title = match["name"], match["title"]
    if any(not word[0].isupper() for word in name.split()): return None
    post = re.fullmatch(r"(?P<role>[A-Za-z]+) of (?:the )?(?P<unit>.+)", title, re.I)
    pre = re.fullmatch(r"(?P<unit>.+) (?P<role>[A-Za-z]+)", title, re.I)
    role_only = title.lower() in ROLES
    selected = post or pre
    if role_only: role, unit = title.lower(), None
    elif selected and selected["role"].lower() in ROLES:
        role, unit = selected["role"].lower(), selected["unit"]
    else: return None
    if unit and (not _WORD.findall(unit) or re.search(r"[,;\[\]!?\"\u201c\u201d]", unit)): return None
    if unit and not any(re.search("[A-Za-z]", w) and not _NUMERAL.fullmatch(w) for w in unit.split()): return None
    return dict(atom=deepcopy(atom), name=name, role=role, unit=unit,
        kind="SOURCE_ROLE_IDENTIFICATION", actual_tenure_required=False, actual_event_required=False)


def _matches(text, spec):
    name = _pattern(spec["name"]); role = re.escape(spec["role"])
    # Both orders are literal appositions, not nominal-to-event paraphrases.
    post = re.compile(r"(?<!\w)(?P<name>" + name + r"),\s*(?P<role>" + role + r")\s+of\s+(?:the\s+)?(?P<unit>[^,;.!?\[\]]+),", re.I)
    reverse = re.compile(r"(?P<unit>[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*(?:[ \t\n]+[A-Za-z0-9]+(?:[-'][A-Za-z0-9]+)*)*)\s+(?P<role>"
        + role + r"),\s*(?P<name>" + name + r"),", re.I)
    for pattern, kind in ((post, "NAME_ROLE_OF_UNIT_APPOSITION"), (reverse, "PRENAME_UNIT_ROLE_APPOSITION")):
        for match in pattern.finditer(text): yield kind, match


def _name_core(head):
    core, pending = {head}, [head]
    while pending:
        for child in pending.pop().children:
            if child.dep_ in _NAME_DEPS and child.pos_ not in {"ADP", "VERB", "AUX", "PRON", "SPACE"} and child not in core:
                core.add(child); pending.append(child)
    return core


def _unit_match(spec, match, doc, offset, role, kind):
    raw = match["unit"].strip()
    if _QUALIFIER.search(raw) or MASK.search(raw): return None
    tokens = [t for t in doc if match.start("unit") <= t.idx + offset < match.end("unit") and not t.is_space]
    if not tokens or any(t.pos_ in {"VERB", "AUX", "PRON", "ADP"} or t.dep_ == "conj" for t in tokens): return None
    if spec["unit"] is None:
        comparison = dict(kind="ROLE_HEAD_ONLY_WITH_FULL_SOURCE_UNIT_PRESERVED", queried_unit=None, full_source_unit=raw)
    elif _norm(raw) == _norm(spec["unit"]):
        comparison = dict(kind="EXACT_LITERAL_UNIT", queried_unit=spec["unit"], full_source_unit=raw)
    else:
        # A numeric unit label can omit a source-supplied namespace. Preserve
        # that namespace explicitly; do NOT equate named organizations globally.
        if not re.match(r"^\d", spec["unit"]): return None
        suffix = re.search(r"(?<!\w)" + _pattern(spec["unit"]) + r"$", raw, re.I)
        if suffix is None or not raw[:suffix.start()].strip(): return None
        absolute = match.start("unit") + suffix.start()
        prefix = [t for t in tokens if t.idx + offset < absolute]
        if not prefix or any(t.pos_ not in {"NOUN", "PROPN"} for t in prefix): return None
        comparison = dict(kind="LITERAL_NUMERIC_UNIT_SUFFIX_WITH_NAMESPACE_RETAINED", queried_unit=spec["unit"],
            full_source_unit=raw, source_namespace=raw[:suffix.start()].strip(),
            organization_identity_or_alias_inferred=False)
    if kind == "PRENAME_UNIT_ROLE_APPOSITION":
        if any(t.head != role and t.head not in tokens for t in tokens): return None
        if any(t.dep_ not in _NOMINAL_DEPS and not (t.head == role and _literal_identifier(t)) for t in tokens): return None
    else:
        heads = [t for t in tokens if t.head not in tokens]
        if len(heads) != 1 or heads[0].dep_ != "pobj" or heads[0].head.lower_ != "of" or heads[0].head.head != role:
            return None
        # The small parser sometimes makes a numerical division label an
        # unpunctuated nominal apposition to its organization namespace.
        if any(t != heads[0] and t.dep_ not in _NOMINAL_DEPS for t in tokens): return None
    comparison["dependency_proofs"] = [dict(text=t.text, start=t.idx + offset, end=t.idx + offset + len(t),
        dependency=t.dep_, head=t.head.text) for t in tokens]
    return comparison


def _certificate(page, kind, match, spec, engine, index, case):
    text = page["text"]
    units = [s for s in literal.sentences(text) if s["start"] <= match.start() and match.end() <= s["end"]]
    if len(units) != 1: return None, "NO_COMPLETE_LITERAL_SOURCE_SENTENCE"
    unit = units[0]; raw, offset = unit["text"], unit["start"]
    if not re.search(r"[.!][\"')\]]*$", raw): return None, "INCOMPLETE_SOURCE_SENTENCE"
    if MASK.search(raw): return None, "OPAQUE_SOURCE_SCOPE"
    # Keep the complete printed citation, but inspect scope at the designation,
    # not hypothetical/modal content subsequently attributed to this speaker.
    prefix = text[:min(match.start("name"), match.start("unit"))]
    if _external_operator_open(prefix, engine): return None, "OPEN_EXTERNAL_QUOTATION_OR_REPORT"
    before = raw[:min(match.start("name"), match.start("unit")) - offset]
    if _PREFIX_SCOPE.search(before) or _QUALIFIER.search(before) or re.search(r"[\[\]\"\u201c\u201d]", raw[:match.end() - offset]):
        return None, "OUTER_ATTRIBUTION_CONDITION_QUOTE_OR_UNKNOWN"
    prior = [s for s in literal.sentences(text[:offset]) if s["text"].strip()]
    if prior and (re.search(r"\b(?:if|unless|following|quotation|quoted|allegation)\b", prior[-1]["text"], re.I)
            or _QUALIFIER.search(prior[-1]["text"]) or prior[-1]["text"].rstrip().endswith(":")):
        return None, "UNBOUND_PRECEDING_OPERATOR"
    doc = engine.parse(raw)
    names = [t for t in doc if match.start("name") <= t.idx + offset < match.end("name") and not t.is_space]
    role_tokens = [t for t in doc if t.idx + offset == match.start("role")]
    if not names or len(role_tokens) != 1: return None, "RAW_TOKEN_BOUNDS_NOT_EXACT"
    heads = [t for t in names if t.head not in names]
    if len(heads) != 1: return None, "AMBIGUOUS_LITERAL_NAME"
    name, role = heads[0], role_tokens[0]
    if {t.i for t in _name_core(name)} != {t.i for t in names}: return None, "PARTIAL_OR_EXTENDED_NAME_NOT_LITERAL_FULL_IDENTITY"
    if kind == "PRENAME_UNIT_ROLE_APPOSITION":
        if name.dep_ != "appos" or name.head != role: return None, "TITLE_NOT_OWNED_BY_THIS_NAME"
        argument = role
        if any(c.dep_ == "appos" and c != name for c in role.children): return None, "MULTIPLE_ROLE_OWNERS"
        matched = {t.i for t in doc if match.start("unit") <= t.idx + offset < match.end("role") and not t.is_space}
        title_core = {role} | {t for t in role.subtree if t.idx < role.idx
            and (t.dep_ in _NOMINAL_DEPS or t.head == role and _literal_identifier(t))}
        if {t.i for t in title_core} != matched: return None, "UNMATCHED_TITLE_MODIFIER"
    else:
        if role.dep_ != "appos" or role.head != name: return None, "ROLE_NOT_ATTACHED_TO_THIS_NAME"
        argument = name
        if any(c.dep_ in {"amod", "advmod", "neg", "compound", "nummod", "poss"} for c in role.children):
            return None, "QUALIFIED_ROLE_HEAD"
    if argument.dep_ in {"nsubj", "nsubjpass", "nsubj:pass", "dobj", "obj", "iobj"}:
        governor = argument.head
    elif argument.dep_ == "pobj" and argument.head.dep_ == "prep":
        governor = argument.head.head
    else: return None, "ROLE_NOT_ROOT_CLAUSE_ARGUMENT"
    if governor.dep_ != "ROOT" or governor.pos_ not in {"VERB", "AUX"}: return None, "EMBEDDED_OR_EXTERNALLY_ATTRIBUTED_ROLE"
    if governor.lemma_.lower() in _NONASSERTIVE: return None, "NONASSERTIVE_GOVERNOR"
    if not (governor.tag_ in {"VBD", "VBP", "VBZ"} or any(c.dep_ in {"aux", "auxpass"} and c.tag_ in {"VBD", "VBP", "VBZ"} for c in governor.children)):
        return None, "NO_FINITE_MATRIX_CLAUSE"
    if any(c.dep_ == "neg" or c.tag_ == "MD" or c.lower_ in {"reportedly", "allegedly", "perhaps", "possibly", "probably"}
            or c.dep_ == "mark" and c.lower_ in {"if", "unless", "whether"} for c in governor.children):
        return None, "NEGATED_MODAL_CONDITIONAL_OR_UNCERTAIN_MATRIX"
    organization = _unit_match(spec, match, doc, offset, role, kind)
    if organization is None: return None, "UNIT_OR_ORGANIZATION_NOT_LITERAL_SCOPED_MATCH"
    citation = policy._citation(page, unit["start"], unit["end"])
    policy._quote(citation, *index, case)
    source_parts = {field: policy._citation(page, *match.span(field)) for field in ("name", "role", "unit")}
    for proof in source_parts.values(): policy._quote(proof, *index, case)
    certificate = dict(version=VERSION, kind="RAW_SOURCE_ROLE_IDENTIFICATION", pattern=kind,
        query_atom=deepcopy(spec["atom"]), query_sha256=digest(case["query"]), citation=citation,
        source_parts=source_parts, literal_full_name=True, partial_name_or_alias_used=False,
        unit_comparison=organization,
        name_dependency_proofs=[dict(text=t.text, start=t.idx + offset, end=t.idx + offset + len(t), dependency=t.dep_) for t in names],
        matrix=dict(text=governor.text, lemma=governor.lemma_, start=governor.idx + offset,
            end=governor.idx + offset + len(governor), dependency=governor.dep_),
        narrator_apposition_outside_reported_complement=True,
        reported_or_future_content_retained_not_certified=True,
        source_identification_only=True, source_role_truth_certified=False,
        continuous_tenure_established=False, appointment_established=False, other_event_established=False,
        publication_date_not_an_inferred_tenure_date=True, raw_source_unchanged=True)
    certificate["sha256"] = digest(certificate)
    return certificate, None


def observe(record, case, eligible_index):
    case = public_case(case)
    if case["task"] not in {"hypothesis", "reconstruction"} or public_case(record["case"]) != case:
        raise ValueError("One exact public complete-query condition is required")
    atoms = _atoms(case, record["plan"])
    ids = record.get("inspected_page_ids")
    if not isinstance(ids, list) or not ids or len(ids) != len(set(ids)): raise ValueError("Exact nonempty inspected pool required")
    meta = record["result"]
    if meta.get("source_pages_inspected", len(ids)) != len(ids): raise ValueError("Saved inspected count differs")
    budget = meta.get("passage_budget", meta.get("retrieval", {}).get("construction_passage_budget"))
    if type(budget) is not int or budget < len(ids): raise ValueError("Pool exceeds recorded budget")
    pages, masks, veto = policy._pages(eligible_index, case)
    index = pages, masks, set(veto) | set(record.get("handling_veto_documents", []))
    admitted = {}
    for pid in ids:
        if pid not in pages: raise ValueError("Saved pool source missing from bound index")
        page = pages[pid]; policy._quote(policy._citation(page, 0, len(page["text"])), *index, case); admitted[pid] = page
    decisions = []
    with offline():
        engine = scoped.Engine()
        for atom in atoms:
            spec = query_spec(atom); certificates, rejected = [], []
            if spec is not None:
                for page in admitted.values():
                    for kind, match in _matches(page["text"], spec):
                        certificate, reason = _certificate(page, kind, match, spec, engine, index, case)
                        if certificate is not None: certificates.append(certificate)
                        else: rejected.append(dict(source_id=page["id"], start=match.start(), end=match.end(), reason=reason))
            decisions.append(dict(atom_id=atom["id"], text=atom["text"], required=True,
                status="SOURCE_ROLE_IDENTIFIED" if certificates else "UNRESOLVED", certificates=certificates,
                rejected=rejected, query_grammar_licensed=spec is not None, source_identification_only=True,
                world_support="NOT_ASSESSED", actual_tenure_or_event_established=False))
    count = sum(d["status"] == "SOURCE_ROLE_IDENTIFIED" for d in decisions)
    return dict(version=VERSION, case_id=case["case_id"], query_sha256=digest(case["query"]),
        decisions=decisions, required_identifications=len(decisions), source_identified=count,
        source_identification_complete=bool(decisions) and count == len(decisions),
        world_support="NOT_ASSESSED", continuous_tenure_established=False,
        appointment_or_other_event_established=False, native_or_canonical_gate_changed=False,
        saved_inspected_page_ids=deepcopy(ids), new_retrieval=False, keys_read=False, grades_read=False, api_calls=0,
        limitations=["Source labels only, not world truth or continued tenure at the query date.",
            "Only literal full names and bounded apposition structures are licensed; aliases and incomplete identities abstain.",
            "A numeric unit suffix may retain additional explicit source namespace, without merging organization identities.",
            "The pinned parser supplies conservative attachment/scope checks; this is not general role extraction or entailment."])
