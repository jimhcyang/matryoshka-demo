"""Source-origin replay for the separately sealed presentation refresh.

This is a privileged readout adapter, not an inference dependency. New releases
retain the existing canonical-unit and full-raw-cable checks.
"""
from copy import deepcopy
from pathlib import Path

from . import server_origin_v63 as base
from . import server_origin_v64 as focal
from . import server_origin_v65 as parent


ROOTS = tuple("experiments/presentation_refresh/" + task + "/releases"
              for task in ("redaction", "hypothesis", "reconstruction"))


def _sealed(root, row):
    ref = row["source_manifest_ref"]
    relative = Path(ref["path"])
    case = row["case"]
    expected = "experiments/presentation_refresh/" + case["task"] + "/releases"
    if (relative.name != "release_manifest.json" or len(relative.parts) != 6
            or relative.parent.parent.as_posix() != expected or expected not in ROOTS):
        raise ValueError("Unsupported presentation source release")
    directory = Path(root).resolve() / relative.parent
    manifest = base._bound_json(root, str(relative), ref["sha256"], directory=directory)
    artifacts = manifest["artifacts"]
    catalog = base._bound_json(root, str(relative.parent / "candidate_public_catalog.json"),
        artifacts["candidate_public_catalog.json"], directory=directory)
    if [c for c in catalog["cases"] if c["case_id"] == case["case_id"]] != [case]:
        raise ValueError("Question differs from its source-sealed catalog")
    proofs = base._bound_json(root, str(relative.parent / "private/source_proofs.json"),
        artifacts["private/source_proofs.json"], directory=directory)
    if manifest["source_proofs_sha256"] != artifacts["private/source_proofs.json"]:
        raise ValueError("Source proof commitments disagree")
    return deepcopy(proofs["cases"][case["case_id"]]), artifacts["private/source_proofs.json"]


def _proof(root, row):
    prefix = Path(row["source_manifest_ref"]["path"]).parent.parent.as_posix()
    if prefix not in ROOTS:
        return parent._proof(root, row)
    proof, proof_hash = _sealed(root, row)
    case, source = row["case"], proof["origin"]
    if case["corpus"] != "cib":
        if (source.get("classification") != "SECRET"
                or case["document_id"] not in proof.get("source_origin_audit", {}).get("original_raw_documents", {})):
            raise ValueError("Cable origin requires its sealed original SECRET body")
        return proof, proof_hash
    if case["task"] == "redaction":
        category = focal._cib_focal_category(root, case, proof)
        proof["origin"]["projection_policy"] = "focal_reveal_only_all_other_nonshared_units_remain_opaque"
        proof["origin_anchors"][0]["focal"] = True
    else:
        if not proof.get("source_origin_audit", {}).get("canonical_ref"):
            raise ValueError("CIB questions require exact canonical reveal units")
        category = base._source_category(root, {}, case, proof, source)
        if (category.get("source_category") != "CIB_VERIFIED_REVEAL"
                or category.get("unit_verified") is not True or category.get("secret_derived") is not True):
            raise ValueError("CIB question is not verified reveal-dependent")
        for release, page in parent._paired_transcript(root, case, proof).items():
            proof["physical_" + release + "_pdf_page"] = page
    proof["_origin_v65_category"] = category
    return proof, proof_hash


_origin = focal._isolated(base.origin, dict(_proof=_proof, _source_category=parent._source_category))


def origin(root, report, case_id, *, reveal_focal=False):
    value = _origin(root, report, case_id, reveal_focal=reveal_focal)
    full = value.get("full_transcription")
    if not full:
        return value
    row, = [r for r in report["cases"] if r["case"]["case_id"] == case_id]
    proof, _ = _proof(root, row)
    audit = proof.get("source_origin_audit", {})
    raw = audit.get("canonical_origin_rows", [])
    body = audit["original_raw_documents"][value["document_id"]]["body"]
    segments = []
    # These are real preparation segments, not invented physical PDF pages.
    # With a masked span, translate offsets but never return its original length.
    hidden = proof.get("hidden_span") if value["task"] == "redaction" else None
    shift = 0
    if hidden and not reveal_focal:
        source = proof["origin"]
        offset = body.index(source["text"])
        hidden_start = hidden["start"] - source.get("start", 0) + offset
        hidden_end = hidden["end"] - source.get("start", 0) + offset
        shift = len(row["case"]["focal_marker"]) - (hidden_end - hidden_start)
    for item in raw:
        a, b = item.get("source_char_start"), item.get("source_char_end")
        if type(a) is not int or type(b) is not int or not 0 <= a < b:
            continue
        if b > len(body) or body[a:b] != item.get("text"):
            raise ValueError("Original-source segment does not replay")
        if hidden and not reveal_focal:
            # A boundary inside the focal span discloses no useful segmentation.
            if hidden_start < a < hidden_end or hidden_start < b < hidden_end:
                continue
            a += shift if a >= hidden_end else 0
            b += shift if b >= hidden_end else 0
        if b > len(full["text"]):
            raise ValueError("Original-source segment boundary exceeds its body")
        segments.append(dict(start=a, end=b, source_id=item.get("segment_id"),
            label="Source segment " + str(len(segments) + 1), physical_pdf_page=False))
    if segments:
        full["segments"] = segments
        full["segment_scope"] = "Verified preparation segments, not physical PDF pages"
    return value
