"""Candidate-focused replay of a sealed native walk, never new inference.

The old drawing saved only its globally strongest edges. A candidate could
therefore be present with none of its incoming edges. This observer recovers
existing transitions from the hash-bound full kernel and replays their actual
iteration values. It does not change that kernel, its ranking, or its verdicts.
"""
from collections import OrderedDict, deque
from copy import deepcopy
import json
import math
from pathlib import Path
from threading import RLock

import numpy as np

from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.corpus_policy_v5 import scoped_page_view
from matryoshka_demo.io import digest
from . import flow as accounting
from . import flow_projection as native
from .flow_projection_v63 import with_solver_stopping


VERSION = "candidate-focused-native-replay/6.4"
_CACHE = OrderedDict()
_LOCK = RLock()


def _distances(graph, starts):
    distance = {v: 0 for v in starts}
    queue = deque(distance)
    while queue:
        u = queue.popleft()
        for v in graph.get(u, ()):
            if v not in distance:
                distance[v] = distance[u] + 1
                queue.append(v)
    return distance


def contributor_cone(projection, candidate, horizon):
    """Reachable contributors inside this drawing, not a full-graph claim."""
    nodes = {n["id"] for n in projection["nodes"] if not n.get("layout_only")}
    ends = set(candidate.get("endpoint_ids") or candidate.get("source_contributor_ids") or []) & nodes
    forward, reverse = {}, {}
    for edge in projection["edges"]:
        a, b = edge["source"], edge["target"]
        if a != b:
            forward.setdefault(a, set()).add(b)
            reverse.setdefault(b, set()).add(a)
    starts = {t["id"] for s in projection["starters"] for t in s.get("targets", []) if t["mass"] > 0}
    left, right = _distances(forward, starts), _distances(reverse, ends)
    included = {n for n in nodes & left.keys() & right.keys() if left[n] + right[n] <= horizon}
    edges = [dict(source=e["source"], target=e["target"]) for e in projection["edges"]
        if e["source"] in included and e["target"] in included
        and left[e["source"]] + 1 + right[e["target"]] <= horizon]
    return dict(graph_node_ids=sorted(included), graph_edges=edges,
        starter_ids=[s["id"] for s in projection["starters"]
            if any(t["id"] in included and t["mass"] > 0 for t in s.get("targets", []))],
        projected_contributor_count=len(included),
        scope="Positive finite walks in the recovered bounded drawing, not every walk in the full graph.")


def _proof(db, source, target, case):
    permission = " AND json_extract(p.payload,'$.permitted')=1"
    if case["corpus"] in {"iran", "vietnam"}:
        permission += " AND json_extract(p.payload,'$.classification')='CONFIDENTIAL'"
    row = db.execute("SELECT p.payload,u.start,u.end FROM edge e JOIN page p ON p.id=e.page "
        "JOIN unit u ON u.id=e.unit AND u.page=e.page WHERE ((e.a=? AND e.b=?) OR (e.a=? AND e.b=?)) "
        "AND p.date<? AND p.doc!=?" + permission + " ORDER BY p.date DESC,e.unit LIMIT 1",
        (source, target, target, source, case["date"], case["document_id"])).fetchone()
    if row is None:
        raise ValueError("Recovered source transition has no eligible source unit")
    page = json.loads(row[0])
    proof = dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
        start=row[1], end=row[2], text=page["text"][row[1]:row[2]],
        page_sha256=page["source_sha256"], earlier_page=page.get("earlier_page"))
    native._verify_quote(db, proof, case)
    return proof


def _metadata(db, identity, case):
    if identity.startswith("hierarchy:"):
        return dict(id=identity, type=identity.split(":")[1], label=identity.split(":")[1].capitalize() + " group")
    permission = " AND json_extract(p.payload,'$.permitted')=1"
    if case["corpus"] in {"iran", "vietnam"}:
        permission += " AND json_extract(p.payload,'$.classification')='CONFIDENTIAL'"
    row = db.execute("SELECT n.kind,m.label FROM node n JOIN mention m ON m.node=n.id "
        "JOIN page p ON p.id=m.page WHERE n.id=? AND p.date<? AND p.doc!=?" + permission +
        " ORDER BY p.date DESC,m.label LIMIT 1", (identity, case["date"], case["document_id"])).fetchone()
    return dict(id=identity, type=row[0], label=row[1]) if row else None


def recover_drawing(flow, expanded, candidates, node_lookup, source_proof, *, incoming_limit=12):
    """Return a derived drawing and exact endpoint balance over the full kernel.

    ``incoming_limit`` is a display budget per endpoint, not a search cutoff.
    All incoming transitions still participate in the balance and its remainder.
    """
    if type(incoming_limit) is not int or incoming_limit < 1:
        raise ValueError("Incoming drawing limit must be a positive integer")
    snapshot = expanded["walk_snapshot"]
    if flow.get("walk_snapshot_sha256") != snapshot["sha256"]:
        raise ValueError("Drawing and native kernel bindings differ")
    matrix, prior, final, indices = accounting.read_snapshot(snapshot)
    state_ids = snapshot["state_ids"]
    incoming = matrix.tocsc()
    drawing, derived_flow = deepcopy(expanded), deepcopy(flow)
    nodes = {n["id"]: n for n in drawing["nodes"]}
    edges = {(e["source"], e["target"]): e for e in drawing["edges"]}
    original_nodes, original_edges = set(nodes), set(edges)
    balances, selected_pairs = {}, {}

    def add_node(identity):
        if identity not in indices:
            raise ValueError("Drawing state is absent from native kernel")
        if identity not in nodes:
            metadata = node_lookup(identity)
            if not metadata or metadata.get("id") != identity:
                raise ValueError("Recovered state lacks source-bound metadata")
            nodes[identity] = dict(metadata, final_mass=float(final[indices[identity]]))

    def add_edge(source, target, kind=None):
        a, b = indices[source], indices[target]
        transition = float(matrix[a, b])
        if transition <= 0:
            raise ValueError("Recovered drawing edge is not a native transition")
        add_node(source); add_node(target)
        if source == target:
            expected = "NUMERICAL_SELF_LOOP"
        elif source.startswith("hierarchy:") and target.startswith("hierarchy:"):
            expected = "SOURCE_AGGREGATE" if nodes[source]["type"].lower() == nodes[target]["type"].lower() else "NAVIGATION"
        else:
            expected = "NAVIGATION" if source.startswith("hierarchy:") or target.startswith("hierarchy:") else "SOURCE"
        if kind is not None and kind != expected:
            raise ValueError("Saved transition kind disagrees with recovered native state types")
        if (source, target) not in edges:
            edge = dict(source=source, target=target, kind=expected, transition=transition,
                recovered_from_native_kernel=True, numerical_transition=True)
            if expected == "SOURCE":
                edge["citations"] = [source_proof(source, target)]
            edges[source, target] = edge
        elif not math.isclose(edges[source, target]["transition"], transition, rel_tol=1e-13):
            raise ValueError("Saved drawing edge differs from native kernel")

    for candidate in candidates:
        cf = derived_flow["candidate_flows"].get(candidate["id"], {})
        ends = cf.get("endpoint_ids") or cf.get("source_contributor_ids") or []
        pairs = []
        for identity in ends:
            j = indices[identity]
            columns = [(int(i), float(w)) for i, w in zip(
                incoming.indices[incoming.indptr[j]:incoming.indptr[j+1]],
                incoming.data[incoming.indptr[j]:incoming.indptr[j+1]])]
            columns.sort(key=lambda v: (-final[v[0]] * v[1], state_ids[v[0]]))
            for i, _ in columns[:incoming_limit]:
                source = state_ids[i]
                add_edge(source, identity)
                pairs.append((source, identity))
        # Native candidate corridors were saved separately from the globally
        # strongest drawing edges, which could otherwise erase their final hop.
        for route in cf.get("represented_routes", []):
            if route.get("route_kind") == "LEXICAL_SOURCE_READOUT":
                continue
            for hop in route.get("hops", []):
                add_edge(hop["source"], hop["target"], hop.get("kind"))
        for edge in cf.get("contribution_edges", []):
            if edge["source"] in nodes and edge["target"] in nodes:
                add_edge(edge["source"], edge["target"], edge.get("kind"))
        selected_pairs[candidate["id"]] = pairs
        direct = [dict(source=a, target=b, kind=edges[a, b]["kind"],
            transition=edges[a, b]["transition"], transported_influence=float(
                snapshot["alpha"] * final[indices[a]] * matrix[indices[a], indices[b]])) for a, b in pairs]
        existing = {(e["source"], e["target"]) for e in direct}
        cf["contribution_edges"] = direct + [e for e in cf.get("contribution_edges", [])
            if (e["source"], e["target"]) not in existing]
        balances[candidate["id"]] = dict(endpoint_ids=list(ends), incoming_frames=[],
            binding=cf.get("binding"), full_incoming_edge_count=int(sum(
                incoming.indptr[indices[n]+1] - incoming.indptr[indices[n]] for n in ends)))

    drawing["nodes"] = list(nodes.values())
    drawing["edges"] = list(edges.values())
    projected = [indices[n["id"]] for n in drawing["nodes"]]
    source_indices = np.array([indices[e["source"]] for e in drawing["edges"]], dtype=int)
    transitions = np.array([e["transition"] for e in drawing["edges"]])
    transpose, values, frames = matrix.T.tocsr(), prior.copy(), []
    for t in range(snapshot["iterations"] + 1):
        previous = values
        if t:
            values = (1-snapshot["alpha"]) * prior + snapshot["alpha"] * (transpose @ previous)
        weights = values[projected]
        transport = snapshot["alpha"] * previous[source_indices] * transitions if t else np.zeros(len(transitions))
        frames.append(dict(iteration=t, weights=weights.tolist(),
            flows=[dict(source=e["source"], target=e["target"], mass=float(m))
                for e, m in zip(drawing["edges"], transport) if m > 0],
            total_mass=float(values.sum()), other_mass=max(0., float(values.sum() - weights.sum())),
            restart_mass=float((1-snapshot["alpha"]) * prior.sum()) if t else 0.))
        for cid, balance in balances.items():
            endpoints = [indices[n] for n in balance["endpoint_ids"]]
            mass = float(values[endpoints].sum())
            restart = float((1-snapshot["alpha"]) * prior[endpoints].sum()) if t else float(prior[endpoints].sum())
            all_incoming = float(snapshot["alpha"] * (transpose[endpoints] @ previous).sum()) if t else 0.
            parts = [dict(source=a, target=b, kind=edges[a, b]["kind"],
                mass=float(snapshot["alpha"] * previous[indices[a]] * matrix[indices[a], indices[b]]) if t else 0.)
                for a, b in selected_pairs[cid]]
            shown = math.fsum(p["mass"] for p in parts)
            if not math.isclose(mass, restart + all_incoming, rel_tol=1e-10, abs_tol=1e-14):
                raise ValueError("Endpoint restart/incoming balance does not close")
            if shown > all_incoming + 1e-13:
                raise ValueError("Displayed incoming exceeds actual native incoming")
            balance["incoming_frames"].append(dict(iteration=t, endpoint_mass=mass, restart_mass=restart,
                incoming_mass=all_incoming, shown_incoming_mass=shown,
                remainder_incoming_mass=max(0., all_incoming-shown), contributions=parts))
    if not np.allclose(values, final, rtol=1e-11, atol=1e-13):
        raise ValueError("Recovered drawing does not reproduce frozen final vector")
    # Reject a saved drawing whose numerical history was independently altered.
    for old in expanded["frames"]:
        values = frames[old["iteration"]]
        if not np.allclose(old["weights"], values["weights"][:len(expanded["nodes"])], rtol=1e-11, atol=1e-13):
            raise ValueError("Original drawing history differs from native replay")
    drawing["frames"] = frames
    restored = dict(node_ids=sorted(set(nodes)-original_nodes),
        edges=[dict(source=a, target=b) for a, b in sorted(set(edges)-original_edges)],
        native_snapshot_sha256=snapshot["sha256"], inference_changed=False,
        meaning="Existing transitions recovered from the sealed native kernel; no new search or inference.")
    return derived_flow, drawing, balances, restored


def presentation(root, report, case_id, arm, *, reading=None, limit=1024):
    root = Path(root).resolve()
    # Reuse all original case/source/native checkpoint checks before deriving.
    original = native.presentation(root, report, case_id, arm, reading=reading, limit=limit)
    selected = native.condition(root, report, case_id, arm)
    if selected.get("status") == "PENDING":
        return original
    record = next(iter(selected["configurations"].values()))
    result, case = record["result"], selected["case"]
    flow = result.get("flow", {})
    if flow.get("status") != "RECORDED":
        return with_solver_stopping(original, result)
    key = (str(root), original["source_case_sha256"], original["source_expanded_sha256"],
        digest(report["graph_indexes"][case["corpus"]]), digest(flow.get("handling_veto_documents", [])), arm, reading, limit)
    with _LOCK:
        if key in _CACHE:
            _CACHE.move_to_end(key)
            return deepcopy(_CACHE[key])
    ref = flow["expanded_ref"]
    path, stamp = native._bound_path(root, ref, "web/data/flows-v6")
    expanded = native._read(str(path), stamp, ref["sha256"])
    db = _connection(root, report["graph_indexes"][case["corpus"]])
    try:
        scoped_page_view(db, flow.get("handling_veto_documents", []))
        def metadata(identity):
            return _metadata(db, identity, case)
        flow_copy, drawing, balances, restored = recover_drawing(flow, expanded, native.targets(result, reading),
            metadata, lambda a, b: _proof(db, a, b, case))
        semantic = [n["id"] for n in drawing["nodes"] if n["type"].lower() not in native.LEVELS]
        placeholders = ",".join("?" for _ in semantic)
        assignments = {r[0]: json.loads(r[1]) for r in db.execute(
            "SELECT id,hierarchy FROM node WHERE id IN (" + placeholders + ")", semantic)} if semantic else {}
        value = native.project(flow_copy, drawing, assignments, native.hierarchy_catalog(db), native.targets(result, reading), limit=limit)
        native.certify_readout_receipts(value, record)
        native.attach_documents(db, value, case, result)
        native.attach_route_sources(db, value, case)
        native.attach_readouts(db, value, case)
        native.decorate(value, case["task"])
        drawn = {n["id"] for n in value["nodes"]}
        for candidate in value["candidates"]:
            explanation = contributor_cone(value, candidate, flow["iterations"])
            balance = balances[candidate["id"]]
            for frame in balance["incoming_frames"]:
                frame["contributions"] = [p for p in frame["contributions"] if p["source"] in drawn and p["target"] in drawn]
                frame["shown_incoming_mass"] = math.fsum(p["mass"] for p in frame["contributions"])
                frame["remainder_incoming_mass"] = max(0., frame["incoming_mass"]-frame["shown_incoming_mass"])
            explanation.update(balance, version=VERSION,
                notes=["Ranking and support are unchanged; diffusion mass is relevance, not correctness.",
                    "Incoming shares are per iteration, not independent complete-path contributions.",
                    "A source-contributor endpoint is not an identity node for an unbound phrase."])
            candidate["contributor_explanation"] = explanation
        for field in ("case_id", "config", "reading_id", "scope", "source_case_sha256", "source_expanded_sha256"):
            value[field] = deepcopy(original[field])
        value.update(version=VERSION, recovered_drawing=restored)
        value = with_solver_stopping(value, result)
        value["flow_ui_presentation_version"] = VERSION
        with _LOCK:
            _CACHE[key] = deepcopy(value)
            while len(_CACHE) > 4:
                _CACHE.popitem(last=False)
        return value
    finally:
        db.close()
