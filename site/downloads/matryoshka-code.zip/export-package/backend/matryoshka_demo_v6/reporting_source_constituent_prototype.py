"""Additive source-span experiment, not an active/native constructor dependency.

Only literal source constituents are proposed. Dependency attachment is syntax
evidence, not identity, entailment, or a factual-support certificate. Promotion
requires a separate runtime profile and matched-budget regression review.
"""
from copy import deepcopy
from types import SimpleNamespace

from matryoshka_demo import source_constituents_v23 as baseline
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import clone

VERSION = "additive-source-constituent-prototype/1"
_NOMINAL = {"NOUN", "PROPN"}
_FINITE_TAGS = {"VBD", "VBP", "VBZ", "MD"}
_NOUN_CHILDREN = {"prep", "acl", "amod", "advmod", "neg", "compound", "det", "poss", "nummod", "nmod"}


def _finite(token):
    return token.pos_ in {"VERB", "AUX"} and (
        token.tag_ in _FINITE_TAGS or "Fin" in token.morph.get("VerbForm"))


def _region(view, selected):
    """No pruning of finite clauses, unknown gaps, negation, or coordination."""
    if not selected:
        return None
    part = view[min(selected):max(selected) + 1]
    if part[0].sent.start_char != part[-1].sent.start_char:
        return None
    if MASK.search(part.text) or any(t.text in {";", ":"} for t in part):
        return None
    if any(not t.is_space and t.i not in selected for t in part):
        return None
    if any(_finite(t) or t.pos_ in {"X", "SYM"} or t.dep_ == "dep" and not t.is_space for t in part):
        return None
    for token in part:
        if token.dep_ in {"ccomp", "advcl", "relcl"}:
            return None
        # A dangling/outgoing coordination is unresolved, not a license to clip.
        children = list(token.children)
        if any(c.dep_ in {"conj", "cc", "preconj", "neg"} and c.i not in selected for c in children):
            return None
        if token.dep_ == "conj" and token.pos_ in _NOMINAL and any(
                t.pos_ in {"VERB", "AUX"} for t in token.subtree):
            return None  # A coordinated nominal with its own proposition is ambiguous.
        if token.dep_ == "conj" and token.pos_ in _NOMINAL and any(
                c.dep_ == "cc" and c.lower_ in {"or", "nor"} for c in token.head.children):
            return None  # Object-vs-complement disjunction needs scope/type evidence.
        if token.dep_ == "conj":
            verbal = token.pos_ in {"VERB", "AUX"}
            parent_verbal = token.head.pos_ in {"VERB", "AUX"}
            if verbal != parent_verbal:
                return None
            if verbal and token.tag_ != token.head.tag_ and not (
                    token.tag_ == "VBG" or any(c.tag_ == "VBG" and c.dep_ in {"aux", "auxpass"} for c in token.children)):
                return None
        if token.pos_ == "CCONJ":
            siblings = [c for c in token.head.children if c.dep_ == "conj" and c.i in selected]
            licensed = (token.dep_ == "preconj" and token.lower_ in {"both", "either", "neither"}
                        or token.dep_ == "cc" and token.lower_ in {"and", "or", "nor", "but"})
            if token.head.i not in selected or not siblings or not licensed:
                return None
    return part


def _closed_right_boundary(part, nominal):
    following = next((t for t in part.doc[part.end:] if not t.is_space), None)
    if following is None or following.pos_ != "CCONJ":
        return True
    after = next((t for t in part.doc[following.i + 1:] if not t.is_space), None)
    governor = nominal.head
    # Only an explicit, inherited-subject outer finite coordination proves a
    # boundary here. "and that ..." or a dangling "and" stays unresolved.
    return bool(after is not None and following.head == governor and _finite(governor)
        and after.dep_ == "conj" and after.head == governor and _finite(after)
        and not any(c.dep_ in {"nsubj", "nsubjpass", "mark"} for c in after.children))


def _noun_gerund(chunk):
    head = chunk.root
    if head.pos_ not in _NOMINAL or head.dep_ == "conj":
        return None
    preps = [c for c in head.children if c.dep_ == "prep" and c.lower_ == "of"]
    if not any(c.dep_ == "pcomp" and c.pos_ in {"VERB", "AUX"}
               and (c.tag_ == "VBG" or any(a.tag_ == "VBG" and a.dep_ in {"aux", "auxpass"} for a in c.children))
               for p in preps for c in p.children):
        return None
    selected = {t.i for t in chunk}
    for child in head.children:
        if child.i in selected or child.is_space or child.dep_ == "punct":
            continue
        if child.dep_ not in _NOUN_CHILDREN:
            return None
        selected.update(t.i for t in child.subtree)
    part = _region(chunk.doc, selected)
    if part is None or not _closed_right_boundary(part, head):
        return None
    return part, head, preps


def _prenominal(head):
    carrier = head.head
    if (head.dep_ not in {"compound", "amod"} or carrier.pos_ != "NOUN"
            or head.i >= carrier.i or head.sent.start_char != carrier.sent.start_char):
        return None
    if head.dep_ == "compound" and (head.pos_ != "NOUN" or head.ent_type_ == "PERSON"):
        return None
    if head.dep_ == "amod" and not (head.pos_ == "ADJ" or head.pos_ == "VERB" and head.tag_ in {"VBG", "VBN"}):
        return None
    selected = {t.i for t in head.subtree}
    if not selected or max(selected) >= carrier.i:
        return None
    part = _region(head.doc, selected)
    if part is None:
        return None
    return part, carrier


def proposal_spans(text, parse):
    """Return unchanged v23 rows plus complete, raw-offset-backed additions."""
    doc, originals = baseline.proposal_spans(text, parse)
    values = list(originals)
    seen = {(s["start"], s["end"], s["kind"]) for s in originals}
    view, normalization = doc, "ORIGINAL_PAGE_ANALYSIS"
    lowered = text.lower()
    if text.isupper() and lowered != text and len(lowered) == len(text):
        view, normalization = parse(lowered), "LOWERCASE_PAGE_SAME_RAW_OFFSETS"
    routing, sections = baseline.format_regions(text, view)

    def add(part, kind, head, carrier, route, details):
        a, b = part.start_char, part.end_char
        raw = doc.char_span(a, b, alignment_mode="strict")
        key = a, b, kind
        if (key in seen or raw is None or raw[0].sent.start_char != raw[-1].sent.start_char
                or any(a < stop and b > start for start, stop in routing + sections)):
            return
        raw_head = doc.char_span(head.idx, head.idx + len(head), alignment_mode="strict")
        raw_carrier = doc.char_span(carrier.idx, carrier.idx + len(carrier), alignment_mode="strict") if carrier is not None else None
        if raw_head is None or carrier is not None and raw_carrier is None:
            return
        certificate = dict(version=VERSION, route=route, normalization=normalization,
            source_span=[a, b], source_text_sha256=digest(text), raw_words_modified=False,
            complete_dependency_region=True, semantic_support_transferred=False,
            prototype_only=True, **details)
        values.append(dict(kind=kind, head=raw_head.root, owner=raw_carrier.root if raw_carrier is not None else None,
            text=text[a:b], edited=text[a:b], start=a, end=b, source_constituent=certificate))
        seen.add(key)

    for chunk in view.noun_chunks:
        found = _noun_gerund(chunk)
        if found:
            part, head, preps = found
            add(part, "nominal", head, None, "COMPLETE_NOUN_OF_NONFINITE_COMPLEMENT",
                dict(nominal_head=[head.idx, head.idx + len(head)],
                     complement_prepositions=[[p.idx, p.idx + len(p)] for p in preps],
                     negation_determiners_and_nonfinite_coordination_preserved=True))
    for head in view:
        found = _prenominal(head)
        if found:
            part, carrier = found
            add(part, "modifier", head, carrier, "SOURCE_ATTACHED_PRENOMINAL_MODIFIER",
                dict(dependency=head.dep_, modifier_head=[head.idx, head.idx + len(head)],
                     carrier_span=[carrier.idx, carrier.idx + len(carrier)],
                     carrier_text=text[carrier.idx:carrier.idx + len(carrier)],
                     owner_identity_certified=False, source_sentence_span=[head.sent.start_char, head.sent.end_char]))
    return doc, values


def construct(case, plan, retrieval, *, passage_budget=100, top_k=5):
    """Explicit opt-in prototype; existing v61 fitting/ranking rules unchanged."""
    from matryoshka_demo_v61 import candidates as current
    current.planning.validate_plan(plan, case)
    registry = {}

    def spans(text, parse):
        doc, rows = proposal_spans(text, parse)
        for row in rows:
            proof = row.get("source_constituent", {})
            if proof.get("version") == VERSION:
                registry[digest(text), row["start"], row["end"]] = deepcopy(proof)
        return doc, rows

    _, functions = clone(current.native_candidates, dict(boundary_fit=current.boundary_fit,
        Context=current.Context, task_execution=current._admission,
        constituents=SimpleNamespace(proposal_spans=spans), VERSION=VERSION))
    with offline():
        value = functions["construct"](case, plan, retrieval, passage_budget=passage_budget, top_k=top_k)
    for row in value["_candidate_audit"]["readings"]:
        for candidate in row["proposals"]:
            source = candidate["sources"][0]
            proof = registry.get((source["page_sha256"], *candidate["source_span"]))
            if proof:
                candidate["source_constituent_prototype"] = deepcopy(proof)
    by_id = {c["id"]: c for r in value["_candidate_audit"]["readings"] for c in r["proposals"]}
    for row in value["readings"]:
        for candidate in row["candidates"]:
            proof = by_id[candidate["id"]].get("source_constituent_prototype")
            if proof:
                candidate["source_constituent_prototype"] = deepcopy(proof)
    value["prototype"].update(execution_kind="ADDITIVE_CONSTITUENT_PROTOTYPE_NOT_NATIVE_RUN", native_results=False)
    value["source_constituent_prototype"] = dict(version=VERSION, prototype_only=True,
        original_constituents_retained=True, active_constructor_modified=False,
        ranking_rules_modified=False, factual_support_certified=False,
        promotion_requires_runtime_profile_and_matched_regressions=True)
    return value
