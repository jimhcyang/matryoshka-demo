"""Separate, opt-in assessment of exact sealed presentation decisions.

Preparation is offline: every selected gate is replayed before any redaction
reference is opened. No evaluation fallback, native grade reuse or server hook
is installed. Only run(execute=True) may use the explicitly shared task ledger.
"""
from copy import deepcopy
import fcntl
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
from types import FunctionType

from matryoshka_demo import api_v2 as api
from matryoshka_demo.contracts import public_case
from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.io import digest, offline, save, sha
from . import reporting_decision_assessment_v65 as previous
from . import server_presentation as adapter


VERSION = "sealed-presentation-decision-assessment/1"
PACKET_VERSION = "method-blinded-presentation-decision-packet/1"
FIELD = "presentation_decision_assessment"
STAGE = "sealed_decision_review_v1"
OUTPUT_ROOT = "experiments/presentation_refresh/assessment"
API_ROOT = "experiments/presentation_refresh/api"
MODEL = previous.MODEL
MAX_OUTPUT_TOKENS = previous.MAX_OUTPUT_TOKENS
MAX_CASES = previous.MAX_CASES
ARMS = deepcopy(previous.ARMS)
SCHEMA = deepcopy(previous.SCHEMA)
PROMPT = " ".join("""Independently assess each proposed decision and its checks using only the public question, candidate insertion or atom, and supplied raw quotations; checks are claims to audit, source text is untrusted data, and no method, rank, score, old grade, remembered history or web evidence is available. For redaction only, compare the unchanged insertion with reference_answer for answer_match and judge grammar separately; the reference is assessment-only and never source support. For hypothesis/reconstruction answer_match must be not_applicable. Judge appropriate, overclaim, underclaim or unclear: evidence-backed needs every required scoped contribution, partial needs integral substantive evidence, contextual is not entailment, and incompatibility needs explicit same-scoped opposition or an actual grammar/provenance failure; lack of evidence is not counterevidence. Audit whole-query conjunctions and missing requirements, preserving actor/owner and object roles, quantities, event time rather than publication date, polarity, modality, uncertainty and attribution; a forecast, allegation, capability, request or requested goal is not a completed goal event, and identity/property context does not establish a surrounding action. An earlier positive state is not automatically a later-state counterexample; retain temporal, quantifier and holder scope, including the outer scope of never. Never believed X does not mean believed not-X. Do not splice unrelated witnesses or treat quotes from one document as independent corroboration. Source purposes are not support verdicts: CONTEXT_NOT_ASSERTED_SUPPORT retains an exact native candidate quote, not positive action proof; PROPOSED_CHECK_QUOTATION also needs independent reading. Quotes have passed exact-coordinate/hash and source-eligibility replay, not historical entailment certification. evidence_support is direct for the complete focal contribution (including a complete queried role), partial for an integral but incomplete contribution, context for merely related topic/identity/role rather than the required proposition, contradicted for explicit same-proposition opposition, or none for no useful supplied basis. Only supplied quotes are available, not every inspected page or the wider corpus; do not infer corpus-wide absence or call an underclaim from the reference alone, and use unclear when the packet cannot adjudicate a check. Return one grade per item ID, cite only its supplied source IDs, require nonempty citations for direct/partial/context/contradicted, explain what is established and missing, and do not repair fills, reuse old assessments or force outcome quotas.""".split())


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _path(root, relative, *, under=None):
    _require(isinstance(relative, str) and bool(relative), "A literal relative path is required")
    parts = relative.split("/")
    _require(not any(p in {"", ".", ".."} for p in parts) and "\\" not in relative
        and not Path(relative).is_absolute(), "Artifact path traversal or nonliteral path")
    path = root / relative
    _require(path.resolve() == path and path.is_relative_to(root / (under or "")),
        "Artifact is outside its scope or redirects through a symlink")
    return path


def _bound(root, reference, *, under=None):
    _require(isinstance(reference, dict) and isinstance(reference.get("sha256"), str)
        and re.fullmatch(r"[0-9a-f]{64}", reference["sha256"]) is not None,
        "An explicit SHA-256 file pin is required")
    path = _path(root, reference.get("path"), under=under)
    _require(path.is_file() and sha(path) == reference["sha256"], "Pinned artifact changed or is missing")
    return path


def _read(root, reference, *, under=None):
    path = _bound(root, reference, under=under)
    raw = path.read_bytes()
    _require(hashlib.sha256(raw).hexdigest() == reference["sha256"], "Artifact changed during read")
    value = json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)
    if path.suffix == ".gz":
        _require(isinstance(value, dict) and value.get("sha256") == digest(value.get("payload")),
            "Compressed audit self-seal differs")
        value = value["payload"]
    return value


def _gate_code():
    """The observer closure plus assessor/transport bytes, never fixture roots."""
    root = adapter.CODE_ROOT
    files = [Path(__file__), Path(previous.__file__), Path(api.__file__),
        root / "matryoshka_demo/assessment_replay_v23.py",
        root / "matryoshka_demo/assessment_v2.py", root / "matryoshka_demo/contracts.py"]
    pins = adapter.observer_code()
    for path in files:
        _require(path.resolve(strict=True) == path and path.is_file(), "Assessor code cannot redirect through a symlink")
        pins[str(path.relative_to(root))] = sha(path)
    return dict(sorted(pins.items()))


def packet(case, gate, eligible_index, *, reference_answer="", native_context=None):
    """Reuse the raw-quote guards and blinded projection, not the old grades."""
    value, mapping, audit = previous.packet(case, gate, eligible_index,
        reference_answer=reference_answer, native_context=native_context)
    value["version"] = PACKET_VERSION
    return value, mapping, audit


_native_context = previous._native_context
_reference = previous._reference


def _pin(reference):
    return {k: reference[k] for k in ("path", "sha256")}


def _distinct_pins(pins):
    values = sorted({(p["path"], p["sha256"]):p for p in pins}.values(), key=lambda p:(p["path"], p["sha256"]))
    _require(len({p["path"] for p in values}) == len(values), "Conflicting artifact pins")
    return values


def _recheck(root, pins, code):
    _require(_gate_code() == code, "Observer/assessor code changed; use a new sealed binding")
    for reference in _distinct_pins(pins):
        _bound(root, reference)


def _prepare(root, report_ref, case_ids, arms, engine):
    root = Path(root).resolve()
    _require(isinstance(case_ids, (list, tuple)) and 1 <= len(case_ids) <= MAX_CASES
        and all(isinstance(c, str) and c for c in case_ids) and len(set(case_ids)) == len(case_ids),
        "Select 1-30 distinct case IDs explicitly")
    _require(isinstance(arms, (list, tuple)) and all(isinstance(a, str) for a in arms), "Explicit A/B/C arms required")
    arms = tuple(ARMS.get(a, a) for a in arms)
    _require(arms and len(set(arms)) == len(arms) and set(arms) <= set(ARMS.values()), "Select distinct active A/B/C arms")
    _require(engine in adapter.ENGINES, "Select an explicit supported observer engine")
    report_path = _bound(root, report_ref)
    _require("private" not in report_path.relative_to(root).parts, "A private key is not a public report")
    report = _read(root, report_ref)
    if "sha256" in report:
        _require(report["sha256"] == digest({k:v for k,v in report.items() if k != "sha256"}), "Report self-seal differs")
    rows = {r["case"]["case_id"]:r for r in report["cases"]}
    _require(len(rows) == len(report["cases"]) and set(case_ids) <= set(rows), "Unknown or duplicate report question")
    code = _gate_code()
    _require(code == _IMPORTED_CODE, "Assessor dependency bytes changed after import; restart before sealing or assessment")
    observer = adapter.DecisionObserver(root, engine, allow_preview_compute=False)
    binding_path = _path(root, "data/bindings.json")
    pins = [_pin(report_ref), dict(path="data/bindings.json", sha256=sha(binding_path))]
    snapshots = []
    # Phase one is replay only. No key helper or evaluation function is called.
    for cid in case_ids:
        row = rows[cid]
        case = public_case(row["case"])
        _require(row.get("status") != "PENDING", "Cannot assess an unexecuted case")
        detail_ref = _pin(row["case_detail_ref"])
        _bound(root, detail_ref, under="web/data/report-v6-cases")
        pins.append(detail_ref)
        index_ref = _pin(report["graph_indexes"][case["corpus"]])
        _bound(root, index_ref, under="data/graph_indexes_v2")
        pins.append(index_ref)
        for arm in arms:
            checkpoint = _pin(row["configurations"][arm]["native_checkpoint"])
            raw = _read(root, checkpoint, under="data/runs_v6")
            selected = observer.condition(root, report, cid, arm)
            record = selected["configurations"][arm]
            gate = record["local_decisions_v65"]
            commitment = record["presentation_gate_commitment"]
            replay = record["presentation_observer"]
            _require(selected["case"] == case == record["case"] == raw["case"]
                and record["config"] == raw["config"] == arm
                and record["native_checkpoint"] == checkpoint
                and replay["replay"] == "SEALED_BOUND_PACKET"
                and replay["gate_content_sha256"] == digest(gate)
                and replay["observer_code"] == observer.code,
                "Not the exact sealed condition replay")
            snapshot = dict(case=case, config=arm, gate=deepcopy(gate), gate_sha256=digest(gate),
                gate_commitment=deepcopy(commitment), detail_ref=detail_ref,
                native_checkpoint=checkpoint, record_sha256=digest(adapter.clean_native(raw)))
            if case["task"] == "redaction":
                snapshot["native_redaction_context"] = _native_context(raw, checkpoint)
            snapshots.append(snapshot)
            pins.append(checkpoint)
    _recheck(root, pins, code)
    packets, mappings, audits = [], [], []
    # Only now may redaction-only references be read. H/R never read keys.
    for cid in case_ids:
        row = rows[cid]
        case = public_case(row["case"])
        answer, key_ref = _reference(root, report, row)
        if key_ref:
            pins.extend([_pin(key_ref), *map(_pin, key_ref["commitment_refs"])])
        db = _connection(root, report["graph_indexes"][case["corpus"]])
        merged, mapped = {}, []
        try:
            for snapshot in (s for s in snapshots if s["case"]["case_id"] == cid):
                value, mapping, audit = packet(case, snapshot["gate"], db,
                    reference_answer=answer, native_context=snapshot.get("native_redaction_context"))
                for item in value["items"]:
                    _require(item["id"] not in merged or merged[item["id"]] == item, "Blinded item identity collision")
                    merged[item["id"]] = item
                mapped.extend(dict(m, case_id=cid, config=snapshot["config"]) for m in mapping)
                audits.append(dict(case_id=cid, config=snapshot["config"], items=audit))
            value["items"] = sorted(merged.values(), key=lambda item:item["id"])
            _require(bool(value["items"]), "No assessable saved decisions")
            packets.append(dict(case_id=cid, packet=value, key_ref=key_ref))
            mappings.extend(mapped)
        finally:
            db.close()
    _recheck(root, pins, code)
    pins = _distinct_pins(pins)
    identity = dict(version=VERSION, report_ref=_pin(report_ref), case_ids=list(case_ids), arms=list(arms),
        engine=engine, gate_version=observer.module.VERSION, gate_code=code, gate_code_sha256=digest(code),
        observer_code_sha256=observer.code_sha256, assessor_code_sha256=sha(Path(__file__)),
        prompt_sha256=digest(PROMPT), schema_sha256=digest(SCHEMA), model=MODEL,
        max_output_tokens=MAX_OUTPUT_TOKENS, api_root=API_ROOT,
        source_binding_sha256=report["source_binding"]["sha256"], pins=pins,
        gates_sha256=digest(snapshots), packets_sha256=digest(packets), mapping_sha256=digest(mappings),
        source_audits_sha256=digest(audits))
    return dict(identity=identity, packets=packets, mapping=mappings, gates=snapshots, source_audits=audits,
        used_for_inference=False, old_native_grades_used=False, gates_replayed_not_recomputed=True,
        keys_read_after_all_gate_replays=True)


def prepare(root, report_ref, case_ids, *, arms=("A", "B", "C"), engine="presentation"):
    """Read-only exact sealed-gate preparation; no API, reservation or fallback."""
    with offline():
        try:
            return _prepare(root, report_ref, case_ids, arms, engine)
        except (KeyError, TypeError, AttributeError, IndexError) as error:
            raise ValueError("Malformed sealed presentation assessment input") from error


def _wire(batch):
    _require(isinstance(STAGE, str) and bool(STAGE), "API format name needs a nonempty stage")
    stage = STAGE + "_" + digest(_gate_code())[:16]
    _require(re.fullmatch(r"[A-Za-z0-9_-]{1,64}", stage) is not None,
        "API format name must contain 1-64 ASCII letters, digits, underscores or hyphens")
    wire = api.request(stage, batch, PROMPT, SCHEMA, model=MODEL, max_output_tokens=MAX_OUTPUT_TOKENS)
    format_value = wire.get("text", {}).get("format", {})
    _require(format_value.get("name") == stage and format_value.get("type") == "json_schema"
        and format_value.get("strict") is True and digest(format_value.get("schema")) == digest(SCHEMA),
        "API structured-output format name/schema contract differs")
    return digest(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=stage, request=wire)), wire


def _cached(api_root, batch):
    key, wire = _wire(batch)
    path = _path(api_root, "cache/" + key + ".json")
    if not path.exists():
        return None
    try:
        cache = json.loads(path.read_bytes())
        _require(digest(cache["request"]) == digest(wire), "Exact-stage cache request differs")
        for group, relative in [("requests", "requests/" + key + ".json"),
                ("responses", "responses/" + key + ".json"), ("receipts", cache["receipt_path"])]:
            _path(api_root, relative, under=group)
        # The reused validator's globals are isolated; the old assessor is untouched.
        scope = dict(previous._cached.__globals__, _wire=_wire, VERSION=VERSION)
        validate = FunctionType(previous._cached.__code__, scope, previous._cached.__name__,
            previous._cached.__defaults__, previous._cached.__closure__)
        result = validate(api_root, batch)
        for relative, expected in result["artifact_sha256"].items():
            _bound(api_root, dict(path=relative, sha256=expected))
        return result
    except (KeyError, TypeError, AttributeError, IndexError) as error:
        raise ValueError("Malformed exact-stage assessment cache") from error


def _check_api_storage(root):
    api_root = _path(root, API_ROOT)
    for directory in ("cache", "requests", "responses", "receipts", "attempts", "request_locks", "response_history"):
        path = _path(api_root, directory)
        _require(not path.exists() or path.is_dir(), "API artifact group must be a directory")
        for child in path.rglob("*"):
            _path(api_root, str(child.relative_to(api_root)))
    _path(api_root, "budget.lock")
    return api_root


def _receipts(root):
    api_root = _check_api_storage(root)
    directory = _path(api_root, "receipts")
    rows = []
    for path in sorted(directory.glob("*.json")):
        _path(api_root, str(path.relative_to(api_root)), under="receipts")
        value = json.loads(path.read_bytes())
        amount = value["charged_or_reserved_usd"]
        _require(type(amount) in (int, float) and math.isfinite(amount) and 0 <= amount <= 25,
            "Invalid shared ledger receipt")
        rows.append((path, value))
    return rows


def _ledger_total(root):
    return sum(row["charged_or_reserved_usd"] for _, row in _receipts(root))


def _immutable(root, path, value):
    _path(root, str(path.relative_to(root)))
    _path(root, str(path.with_name(path.name + ".tmp").relative_to(root)))
    if path.exists():
        _require(digest(json.loads(path.read_bytes())) == digest(value), "Existing immutable assessment sidecar differs")
    else:
        save(path, value)


def _batches(prepared, size):
    for case in prepared["packets"]:
        packet_value = case["packet"]
        for start in range(0, len(packet_value["items"]), size):
            batch = dict(packet_value, items=packet_value["items"][start:start + size])
            _require(len(json.dumps(batch, ensure_ascii=True).encode()) <= 1000000, "Assessment batch exceeds bounded input")
            yield case["case_id"], batch


def _gate_bindings(prepared):
    return [dict(case_id=g["case"]["case_id"], config=g["config"], gate_sha256=g["gate_sha256"],
        commitment_sha256=g["gate_commitment"]["sha256"]) for g in prepared["gates"]]


def run(root, report_ref, case_ids, *, arms=("A", "B", "C"), engine="presentation", execute=False, cap=25., batch_size=8):
    """Preview is read-only. Execution/resume uses only this task's exact stage."""
    _require(type(execute) is bool and type(cap) in (int, float) and math.isfinite(cap) and 0 < cap <= 25,
        "Explicit execute flag and a shared cumulative cap <=25 required")
    _require(type(batch_size) is int and 1 <= batch_size <= 20, "Use 1-20 items per batch")
    root = Path(root).resolve()
    prepared = prepare(root, report_ref, case_ids, arms=arms, engine=engine)
    identity = dict(prepared["identity"], batch_size=batch_size)
    api_root = _path(root, API_ROOT)
    directory = _path(root, OUTPUT_ROOT + "/run_" + digest(identity)[:24])
    batches = []
    for cid, batch in _batches(prepared, batch_size):
        key, wire = _wire(batch)
        cached = _cached(api_root, batch)
        ir, outrate = api.RATES[MODEL]
        reserve = ((len(json.dumps(wire, ensure_ascii=True).encode()) + 4096) * ir + MAX_OUTPUT_TOKENS * outrate) / 1e6
        batches.append(dict(case_id=cid, packet=batch, key=key, cached=cached, reservation_usd=0 if cached else reserve))
    total = _ledger_total(root)
    preview = dict(version=VERSION, status="PREVIEW", case_count=len(case_ids), condition_count=len(prepared["gates"]),
        item_count=sum(len(p["packet"]["items"]) for p in prepared["packets"]), batches=len(batches),
        cached_batches=sum(b["cached"] is not None for b in batches), api_root=API_ROOT,
        conservative_new_reservations_usd=sum(b["reservation_usd"] for b in batches),
        cumulative_charged_or_reserved_usd=total, shared_cumulative_cap_usd=cap,
        path=str(directory.relative_to(root)), identity=identity, api_calls=0,
        artifacts_modified=False, used_for_inference=False, native_artifacts_modified=False)
    if not execute:
        return preview
    _require(total + preview["conservative_new_reservations_usd"] <= cap,
        "Shared task cap includes all charged, failed and outstanding reservations")
    directory.mkdir(parents=True, exist_ok=True)
    lock_path = _path(root, str((directory / "assessment.lock").relative_to(root)))
    results, paid_calls = [], 0
    with lock_path.open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        _recheck(root, identity["pins"], identity["gate_code"])
        _immutable(root, directory / "code_pins.json", identity["gate_code"])
        _immutable(root, directory / "input.json", dict(identity=identity, prepared=prepared))
        for batch in batches:
            result = _cached(api_root, batch["packet"])
            target = directory / "batches" / (batch["key"] + ".json")
            _path(root, str(target.relative_to(root)))
            if target.exists():
                _require(result is not None and json.loads(target.read_bytes()) == result,
                    "Saved sidecar differs from exact new-stage receipt")
            if result is None:
                _recheck(root, identity["pins"], identity["gate_code"])
                _, wire = _wire(batch["packet"])
                attempts = [(p, r) for p, r in _receipts(root) if r.get("request_sha256") == digest(wire)]
                _require(not attempts, "Existing unfinished/failed reservation: no automatic retry or cache repair")
                _check_api_storage(root)
                try:
                    _, receipt = api.call(api_root, wire["text"]["format"]["name"], batch["packet"], PROMPT, SCHEMA,
                        model=MODEL, max_output_tokens=MAX_OUTPUT_TOKENS, cap=cap)
                    paid_calls += int(not receipt.get("cache", False))
                    result = _cached(api_root, batch["packet"])
                    _require(result is not None, "No verified new-stage receipt")
                except BaseException as error:
                    refs = [dict(path=str(p.relative_to(api_root)), sha256=sha(p), status=r["status"],
                        charged_or_reserved_usd=r["charged_or_reserved_usd"])
                        for p, r in _receipts(root) if r.get("request_sha256") == digest(wire)]
                    failure = dict(version=VERSION, request_key=batch["key"], packet_sha256=digest(batch["packet"]),
                        error_type=type(error).__name__, message=str(error), shared_ledger_receipts=refs, automatic_retry=False)
                    _immutable(root, directory / "failures" / (batch["key"] + "__" + digest(failure)[:16] + ".json"), failure)
                    raise
            _recheck(root, identity["pins"], identity["gate_code"])
            _immutable(root, target, result)
            results.append(dict(case_id=batch["case_id"], assessment=result))
        response = dict(version=VERSION, field=FIELD, identity=identity, results=results, mapping=prepared["mapping"],
            source_audits=prepared["source_audits"], gate_bindings=_gate_bindings(prepared),
            input_ref=dict(path=str((directory / "input.json").relative_to(root)), sha256=sha(directory / "input.json")),
            code_pins_ref=dict(path=str((directory / "code_pins.json").relative_to(root)), sha256=sha(directory / "code_pins.json")),
            used_for_inference=False, old_native_grades_used=False, independent_human_validation=False)
        response["sha256"] = digest(response)
        _immutable(root, directory / "assessment.json", response)
    return dict(preview, status="COMPLETE", api_calls=paid_calls, artifacts_modified=True,
        cumulative_charged_or_reserved_usd=_ledger_total(root),
        assessment_ref=dict(path=str((directory / "assessment.json").relative_to(root)), sha256=sha(directory / "assessment.json")))


def response_field(root, result_ref, *, case_id, config, gate):
    """Optional separate integration field; replays sealed gates, never computes."""
    root = Path(root).resolve()
    value = _read(root, result_ref, under=OUTPUT_ROOT)
    _require(value["version"] == VERSION and value["field"] == FIELD
        and value["sha256"] == digest({k:v for k,v in value.items() if k != "sha256"}), "Assessment sidecar seal differs")
    contract = value["identity"]
    prepared = prepare(root, contract["report_ref"], contract["case_ids"], arms=contract["arms"], engine=contract["engine"])
    _require(contract == dict(prepared["identity"], batch_size=contract["batch_size"]),
        "Not the exact sealed presentation assessment contract")
    saved = _read(root, value["input_ref"], under=OUTPUT_ROOT)
    _require(saved == dict(identity=contract, prepared=prepared)
        and _read(root, value["code_pins_ref"], under=OUTPUT_ROOT) == contract["gate_code"],
        "Immutable input/code snapshot differs")
    _require(value["gate_bindings"] == _gate_bindings(prepared)
        and value["mapping"] == prepared["mapping"] and value["source_audits"] == prepared["source_audits"],
        "Assessment gate, item mapping or source audit differs")
    matches = [g for g in value["gate_bindings"] if g["case_id"] == case_id and g["config"] == config]
    _require(len(matches) == 1 and matches[0]["gate_sha256"] == digest(gate), "Assessment belongs to a different exact gate")
    expected = []
    for cid, batch in _batches(prepared, contract["batch_size"]):
        result = _cached(_path(root, API_ROOT), batch)
        _require(result is not None, "Missing exact new-stage receipt")
        expected.append(dict(case_id=cid, assessment=result))
    _require(value["results"] == expected, "Saved grades differ from raw new-stage responses")
    grades = {g["id"]:g for r in expected if r["case_id"] == case_id for g in r["assessment"]["grades"]}
    return dict(version=VERSION, gate_version=contract["gate_version"], gate_sha256=digest(gate),
        grades=[dict(m, grade=grades[m["item_id"]]) for m in value["mapping"] if m["case_id"] == case_id and m["config"] == config],
        assessment_ref=deepcopy(result_ref), used_for_inference=False, old_native_grades_used=False,
        independent_human_validation=False, source_only_assessment=True, method_blinded=True)


# Physical bytes must match the functions imported into this process, not just
# a fresh disk hash taken after a dependency was edited in a warm interpreter.
_IMPORTED_CODE = _gate_code()
