"""Additional argument-owned raw appositions; V1 remains immutable.

No predicate bonus or named identity rule. The new path requires an exact
nominal argument, directly attached role/organization, and an independently
reparsed complete positive finite clause without detected nonfactive scope.
"""
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_demo_v61 import scope_matching as scoped
from . import planning as literal
from . import reporting_fixed_pool_role_projection as previous

VERSION="raw-role-apposition-observer/2"
query_spec=previous.query_spec
load_local_groups=previous.load_local_groups
NAME_DEPENDENCIES={"compound","flat","flat:name","name","amod"}
ARGUMENTS={"nsubj","nsubjpass","nsubj:pass","dobj","obj","iobj"}
# Linguistic scope inventory, not a whitelist of successful factual verbs.
# Unknown English predicate senses remain a stated limitation of this observer.
NONFACTIVE=set(scoped.matching.parent._REPORTING)|{
    "imagine","picture","envisage","visualize","fantasize","dream","pretend","suppose","assume",
    "hypothesize","consider","doubt","hope","wish","want","desire","intend","plan","expect",
    "anticipate","predict","forecast","propose","ask","request","order","seek","try","attempt",
    "aim","prepare","mention","hear","read","dispute","reject","simulate","invent","fabricate",
    "presume","purport","remember","forget",
}


def _full_names(spec,groups):
    names={spec["person"]}
    for group in groups:
        for obj in group["objects"]:
            row=obj["record"]
            if previous._normal(row.get("label",""))!=previous._normal(spec["person"]):continue
            match=re.fullmatch(r"(?P<name>[^,]+),\s*(?:described as|identified as)\s+(?:the\s+)?"
                +previous.local.literal_pattern(spec["role"])+r"\s+of\s+(?:the\s+)?"
                +previous.local.literal_pattern(spec["organization"])+r"\.",row.get("description",""),re.I)
            if match and previous._proper(match["name"]):names.add(match["name"])
    return sorted(names)


def _matches(spec,page,groups):
    found={}
    for name in _full_names(spec,groups):
        pattern=re.compile(r"(?<!\w)(?P<name>"+previous.local.literal_pattern(name)+r"),\s*(?P<role>"
            +previous.local.literal_pattern(spec["role"])+r")\s+of\s+(?:the\s+)?(?P<organization>"
            +previous.local.literal_pattern(spec["organization"])+r"),",re.I)
        for match in pattern.finditer(page["text"]):found[match.span()]=match
    return list(found.values())


def _context(page,match,engine):
    text=page["text"]
    candidates=[s for s in literal.sentences(text) if s["start"]<=match.start() and match.end()<=s["end"]]
    if len(candidates)!=1:return None,"NO_COMPLETE_LITERAL_CLAUSE"
    unit=candidates[0];raw=unit["text"];offset=unit["start"]
    if (not re.search(r"[.!][\"')\]]*$",raw) or previous.OPAQUE.search(raw)
            or re.search(r"[\[\]\"\u201c\u201d]",raw)):
        return None,"QUALIFIED_NEGATIVE_CONDITIONAL_QUOTED_OR_MASKED_CLAUSE"
    if literal._open_reporting_context(text[:offset]):return None,"OPEN_REPORTING_OR_QUOTE_CONTEXT"
    prior=[s for s in literal.sentences(text[:offset]) if s["text"].strip()]
    if prior and (scoped.native._reporting_block(prior[-1]["text"],engine.parse)
            or any(scoped.matching.lemma(t) in scoped.matching.parent._REPORTING
                for t in engine.parse(prior[-1]["text"]))
            or re.search(r"\b(?:if|unless|suppose|assuming)\b",prior[-1]["text"],re.I)):
        return None,"UNRESOLVED_PRIOR_REPORTING_OR_CONDITIONAL_CONTEXT"
    doc=engine.parse(raw)
    role_tokens=[t for t in doc if t.idx+offset==match.start("role")]
    named=[t for t in doc if match.start("name")<=t.idx+offset<match.end("name") and not t.is_space]
    if len(role_tokens)!=1 or not named:return None,"RAW_TOKEN_BOUNDS_NOT_EXACT"
    role=role_tokens[0]
    head=role.head
    if role.dep_!="appos" or head not in named or head.pos_ not in {"NOUN","PROPN"}:
        return None,"ROLE_NOT_DIRECTLY_ATTACHED_TO_OWN_NAME"
    # Compound/amod names can be mistagged in uppercase telegrams. Accept only
    # the literal name bytes, with every name-core dependent inside that span;
    # never inject NER labels or trim a different given name/title to a surname.
    core={head};pending=[head]
    while pending:
        token=pending.pop()
        for child in token.children:
            if child.dep_ in NAME_DEPENDENCIES and child not in core:
                core.add(child);pending.append(child)
    if {t.i for t in named}!={t.i for t in core}:
        return None,"NAME_CORE_NOT_COMPLETE_OR_HAS_EXTRA_CONSTITUENTS"
    if any(c.dep_=="conj" and c.idx<role.idx for c in head.children):
        return None,"MULTIPLE_HEADS_BEFORE_APPOSITION"
    organization=[t for t in doc if match.start("organization")<=t.idx+offset<match.end("organization") and not t.is_space]
    if not organization:return None,"ORGANIZATION_TOKENS_MISSING"
    org_heads=[t for t in organization if t.head not in organization]
    if (len(org_heads)!=1 or org_heads[0].dep_!="pobj" or org_heads[0].head.lower_!="of"
            or org_heads[0].head.head!=role):
        return None,"ROLE_ORGANIZATION_ATTACHMENT_NOT_DIRECT"
    path=[head]
    if head.dep_ in ARGUMENTS:
        governor=head.head
    elif head.dep_=="pobj" and head.head.dep_=="prep":
        path.append(head.head);governor=head.head.head
    else:return None,"PERSON_NOT_DIRECT_SUBJECT_OR_OBJECT_ARGUMENT"
    path.append(governor)
    if governor.pos_!="VERB" or governor.dep_!="ROOT":return None,"EMBEDDED_OR_NONVERBAL_GOVERNOR"
    finite=governor.tag_ in {"VBD","VBP","VBZ"} or (governor.tag_=="VBN" and any(
        c.dep_ in {"aux","auxpass"} and c.tag_ in {"VBD","VBP","VBZ"} for c in governor.children))
    if not finite or governor.lemma_.casefold() in NONFACTIVE:return None,"NONFINITE_OR_NONFACTIVE_GOVERNOR"
    frames=engine.frames(raw,antecedents=True)
    event=[f for f in frames if f["predicate_proof"]["start"]==governor.idx and f["kind"]=="EVENT"]
    if len(event)!=1:return None,"NO_UNIQUE_FINITE_GOVERNOR_FRAME"
    q=event[0]["qualifiers"]
    if any(q.get(k) for k in ("negated","modality","scope","attribution","conditional","question","epistemic_absence","unresolved","role_qualifiers")):
        return None,"FINITE_GOVERNOR_HAS_UNRESOLVED_OR_NONASSERTIVE_SCOPE"
    if re.search(r"\b(?:tomorrow|next|forthcoming|coming)\b",raw,re.I):
        return None,"FUTURE_OR_UNBOUND_TEMPORAL_CONTEXT"
    proof=dict(kind="DIRECT_FINITE_ARGUMENT_APPOSITION",clause=previous.policy._citation(page,unit["start"],unit["end"]),
        role_attachment=dict(dependency=role.dep_,role_span=[role.idx+offset,role.idx+offset+len(role)],
            owner_head_span=[head.idx+offset,head.idx+offset+len(head)],
            organization_path=[dict(text=t.text,dependency=t.dep_,start=t.idx+offset,end=t.idx+offset+len(t))
                for t in (org_heads[0],org_heads[0].head,role)]),
        person_relation=head.dep_,argument_path=[dict(text=t.text,dependency=t.dep_,pos=t.pos_,
            start=t.idx+offset,end=t.idx+offset+len(t)) for t in path],
        finite_governor=dict(text=governor.text,lemma=governor.lemma_,tag=governor.tag_,
            start=governor.idx+offset,end=governor.idx+offset+len(governor)),
        parent_qualifiers=deepcopy(q),parent_event_dates=deepcopy(event[0]["event_dates"]),
        parent_deictic_time=deepcopy(event[0].get("deictic_time",[])),
        temporal_context_preserved_not_resolved_to_new_year=True,role_time_is_source_context_only=True,
        lexical_nonfactive_inventory_used=True,verb_specific_positive_bonus=False,
        role_only=True,governing_event_certified=False)
    return proof,None


def observe(case,plan,atom_id,admitted,index,*,engine,local_groups=None):
    initial=previous.observe(case,plan,atom_id,admitted,index,engine=engine,local_groups=local_groups)
    result=deepcopy(initial);result["version"]=VERSION
    if result["status"]=="ROLE_ONLY":
        for certificate in result["certificates"]:
            certificate.update(version=VERSION,licensing="UNCHANGED_LEADING_APPOSITION_V1")
            certificate.pop("sha256",None);certificate["sha256"]=digest(certificate)
        return result
    spec=query_spec(case,plan,atom_id)
    if spec is None:return result
    result["prior_observer_status"]=initial["status"]
    pages,masks,veto=index;certificates=[]
    for page in admitted.values():
        previous.policy._quote(previous.policy._citation(page,0,len(page["text"])),pages,masks,veto,case)
        groups=(local_groups or {}).get(page["id"],[])
        if any(g["case"]!=previous.policy._case(case) for g in groups):raise ValueError("Source role group case mismatch")
        valid=[]
        for match in _matches(spec,page,groups):
            binding=previous._binding(spec,page,match,groups)
            if binding is None:
                result.setdefault("rejected",[]).append("NO_UNIQUE_SOURCE_LOCAL_PERSON_BINDING");continue
            context,reason=_context(page,match,engine)
            if context is None:
                result.setdefault("rejected",[]).append(reason);continue
            role_frames=[f for f in engine.frames(page["text"],antecedents=True)
                if f["kind"]=="PROPERTY" and f["predicate_proof"]["start"]==match.start("role")
                and previous._normal(f["predicate"])==previous._normal(spec["role"])]
            if len(role_frames)>1 or role_frames and any(bool(v) for v in role_frames[0]["qualifiers"].values()):
                result.setdefault("rejected",[]).append("UNRESOLVED_RAW_ROLE_SCOPE");continue
            # Some ordinary argument appositions have no legacy PROPERTY frame.
            # The new certificate then comes from the exact bare role/OF phrase,
            # direct appos/argument attachments and checked finite clause above,
            # not from an invented native label or a missing frame's verdict.
            checked=(deepcopy(role_frames[0]["qualifiers"]) if role_frames else
                dict(derivation="BARE_RAW_ROLE_AND_INDEPENDENT_FINITE_ARGUMENT_SCOPE",
                    parent_qualifiers=deepcopy(context["parent_qualifiers"]),
                    legacy_role_frame_present=False,qualified_role_text_accepted=False))
            certificate=dict(version=VERSION,kind="RAW_ROLE_APPOSITION",atom_id=atom_id,
                query_sha256=digest(case["query"]),atom_binding=deepcopy(spec["atom"]),
                citation=context["clause"],apposition=previous.policy._citation(page,match.start(),match.end()),
                person=previous.policy._citation(page,*match.span("name")),role=previous.policy._citation(page,*match.span("role")),
                organization=previous.policy._citation(page,*match.span("organization")),identity_binding=binding,
                checked_qualifiers=checked,governing_argument=context,
                licensing="DIRECT_FINITE_ARGUMENT_APPOSITION",role_only=True,current_role_persistence=False,
                other_predicates_certified=False,generated_label_as_evidence=False,
                source_assertion_not_world_truth=True,numerical_transport_claim=False)
            certificate["sha256"]=digest(certificate);valid.append(certificate)
        if len(valid)==1:certificates.extend(valid)
        elif valid:result.setdefault("rejected",[]).append("MULTIPLE_RAW_APPOSITIONS_AMBIGUOUS")
    result["certificates"]=certificates
    result["status"]="ROLE_ONLY" if certificates else "UNRESOLVED"
    return result
