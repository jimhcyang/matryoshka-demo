"""V6 deterministic execution; frozen modules are used through isolated copies."""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import re
from types import ModuleType

from matryoshka_demo import task_execution_v3 as old
from matryoshka_demo import task_execution_v5 as previous
from matryoshka_demo.contracts import MASK, public_case, span
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import clone

VERSION = "source-structured-task-execution/6.0"
SLOTS = old.SLOTS
_ASSERTIVE_REPORTS = {"say", "state", "reply", "report", "note"}


@lru_cache(maxsize=1)
def _raw_parser():
    return previous.base.parser()


def initialism_view(text):
    """Remove internal initialism whitespace only, with an exact raw map."""
    omitted, edits = set(), []
    for m in re.finditer(r"(?<![A-Za-z])(?:[A-Za-z]\.\s*){2,}", text):
        end = m.end()
        while end > m.start() and text[end-1].isspace():
            end -= 1
        fragment = text[m.start():end]
        removed = {m.start()+i for i, c in enumerate(fragment) if c.isspace()}
        if removed:
            omitted.update(removed)
            edits.append(dict(kind="INITIALISM_INTERNAL_WHITESPACE", start=m.start(), end=end,
                text=fragment, analysis_text="".join(c for c in fragment if not c.isspace()),
                identity_dictionary_used=False, source_modified=False))
    offsets = [i for i in range(len(text)) if i not in omitted]
    return "".join(text[i] for i in offsets), offsets if omitted else None, edits


def _reporting_block(prior, parse):
    markers = list(re.finditer(r"\b(?:qte|quote|unqte|unquote|end\s+quote)\b", prior, re.I))
    quotes = prior.count('"')+prior.count("\u201c")+prior.count("\u201d")
    if quotes % 2 or markers and markers[-1].group().casefold() in {"qte", "quote"}:
        return True
    for colon in re.finditer(":", prior):
        at = colon.start()
        if at and at+1 < len(prior) and prior[at-1].isdigit() and prior[at+1].isdigit():
            continue
        before = re.split(r"[.!?]\s+|\n\s*\n", prior[:at])[-1]
        # A reporting predicate after a topic colon does not own that colon.
        reporting = any(previous.base.matching.lemma(t) in previous.base.matching.parent._REPORTING
            or previous.base.matching.lemma(t) in {"statement", "quotation", "quote"} for t in parse(before))
        after = prior[at+1:]
        closed = (after.count('"') >= 2 and after.count('"') % 2 == 0
            or re.search(r"\b(?:unqte|unquote|end\s+quote)\b", after, re.I))
        if reporting and not closed:
            return True
    return False


def _appositions(text, parse):
    doc, result = parse(text), []
    for token in doc:
        if token.dep_ != "appos" or token.pos_ not in {"NOUN", "PROPN"} or token.head.pos_ not in {"NOUN", "PROPN"}:
            continue
        owner = previous.base.matching.phrase(token.head)
        prop = previous.base.matching.phrase(token)
        if owner["unresolved"] or not owner["names"]:
            continue
        q = previous.base.matching.qualifiers(token)
        result.append(dict(kind="PROPERTY", predicate=previous.base.matching.lemma(token),
            predicate_proof=previous.base.matching.proof(token), predicate_phrase=prop, copula="be",
            roles=dict(owner=[owner], property=[prop]), qualifiers=q, event_dates=[], passive=False,
            unbound_arguments=[], deictic_time=[], start=token.sent.start_char, end=token.sent.end_char,
            quote=text[token.sent.start_char:token.sent.end_char],
            v6_binding=dict(kind="EXPLICIT_SOURCE_APPOSITION", owner=deepcopy(owner), property=deepcopy(prop),
                source_only=True, actual_event_inferred=False)))
    return result


class _Engine(previous._Engine):
    def __init__(self, parse=None):
        super().__init__(parse or _raw_parser())
        self.disposition_reading = False

    def frames(self, text, *, antecedents=False):
        key = ("v6", text, antecedents)
        if key not in self.cache:
            view, offsets, edits = initialism_view(text)
            frames = super().frames(view, antecedents=antecedents)
            frames += _appositions(view, self.parse)
            for frame in frames:
                q = frame["qualifiers"]
                if "PRIOR_REPORTING_BLOCK_SCOPE_UNCLEAR" in q["unresolved"]:
                    start = frame["start"]
                    prior_start = view.rfind("\n\n", 0, start)
                    prior = view[0 if prior_start < 0 else prior_start+2:start]
                    if not _reporting_block(prior, self.parse):
                        q["unresolved"] = [x for x in q["unresolved"] if x != "PRIOR_REPORTING_BLOCK_SCOPE_UNCLEAR"]
                        frame.setdefault("v6_analysis", []).append(dict(kind="TOPIC_COLON_NOT_REPORTING_GOVERNOR"))
            if offsets is not None:
                frames = old._Engine.restore_offsets(frames, text, offsets)
                for frame in frames:
                    frame.setdefault("source_normalization", []).extend(deepcopy(edits))
            self.cache[key] = frames
        return deepcopy(self.cache[key])

    def targets(self, text):
        frames = super().targets(text)
        # An adjectival reported-position marker is a qualifier, not a second,
        # roleless assertion that a reporting event independently occurred.
        return [f for f in frames if not (f["kind"] == "EVENT" and not f["roles"]
            and f["predicate"] in _ASSERTIVE_REPORTS and f["predicate_proof"]["dependency"] in {"amod", "acl"})]


def _diagnostics(target, source, alignment):
    result = old._diagnostics(target, source, alignment)
    if (not target.get("deictic_time") and not target["event_dates"] and source.get("deictic_time")
            and result["event_date"]["status"] == "UNRESOLVED"):
        raw = previous.base._diagnostics(target, source, alignment)["event_date"]
        if raw["status"] in old._GOOD:
            result["event_date"].update(status="UNSPECIFIED", target_date_required=False,
                source_time_preserved=deepcopy(source["deictic_time"]),
                resolution="UNDATED_EXISTENTIAL_TARGET_NO_CALENDAR_DATE_CERTIFIED")
    return result


def _report_specialization(target, source):
    """A reply/state/report entails a saying, never the reverse speech act."""
    projected = deepcopy(source)
    changed = []
    if target["predicate"] == "say" and source["predicate"] in _ASSERTIVE_REPORTS-{"say"}:
        projected["predicate"] = "say"
        changed.append(source["predicate"])
    ts, ss = target["qualifiers"]["scope"], projected["qualifiers"]["scope"]
    if len(ts) == len(ss):
        for t, s in zip(ts, ss):
            if t["predicate"] == "say" and s["predicate"] in _ASSERTIVE_REPORTS-{"say"}:
                changed.append(s["predicate"])
                s["predicate"] = "say"
    return projected, changed


def _disposition_source(target, source, engine):
    if not engine.disposition_reading or target["kind"] != "PROPERTY" or target.get("copula") is not None:
        return None
    if source["kind"] != "EVENT" or not source["passive"] or target["predicate"] != source["predicate"]:
        return None
    t, s = target["qualifiers"], source["qualifiers"]
    if s["modality"] != ["can"] or t["modality"] or "easily" not in t["manner"] or set(t["manner"]) != set(s["manner"]):
        return None
    for f in (target, source):
        q = f["qualifiers"]
        if (f["event_dates"] or f.get("deictic_time") or f["unbound_arguments"] or q["negated"]
                or q["scope"] or q["conditional"] or q["question"] or q["epistemic_absence"] or q["unresolved"]):
            return None
    if set(source["roles"])-{"patient"} or set(target["roles"])-{"owner"}:
        return None
    def participle(frame):
        proof = frame["predicate_proof"]
        a, b = proof["start"]-frame["start"], proof["end"]-frame["start"]
        part = engine.parse(frame["quote"]).char_span(a,b,alignment_mode="strict")
        return part is not None and len(part) == 1 and part.root.tag_ == "VBN"
    if not participle(target) or not participle(source):
        return None
    result = deepcopy(source)
    result.update(kind="PROPERTY", copula=None, roles=dict(owner=deepcopy(source["roles"].get("patient", []))))
    result["qualifiers"]["modality"] = []
    result["v6_disposition"] = dict(kind="CAN_EASILY_PASSIVE_DISPOSITION",
        source_modal="can", original_qualifiers=deepcopy(s), original_predicate=deepcopy(source["predicate_proof"]),
        scope="EASE_ABILITY_PROPERTY_ONLY_NOT_ACTUAL_EVENT", modality_erased_from_raw_source=False)
    return result


def compare_frames(target, source, *, engine=None):
    engine = engine or _Engine()
    projected, speech = _report_specialization(target, source)
    ability = _disposition_source(target, projected, engine)
    compared = ability or projected
    _, functions = clone(old, dict(_diagnostics=_diagnostics))
    result = functions["compare_frames"](target, compared, engine=engine)
    if result is None:
        return None
    # Keep V5's anti-identity-loosening discriminator gate.
    if result["direction"] in {"SUPPORT", "COUNTER"}:
        gaps = []
        for row in result["bindings"]["argument_matches"]:
            if row["status"] != "EXACT_SCOPED_ARGUMENT" or row["role"] == "property":
                continue
            def terms(p, path=()):
                value = {(path,old._term(x)) for x in p["proofs"] if x["pos"] in {"NOUN", "PROPN", "ADJ", "NUM"}}
                for modifier in p.get("modifiers",[]):
                    value |= terms(modifier["phrase"],path+(modifier["relation"],))
                return value
            extra = terms(row["source"])-terms(row["target"])
            if extra:
                gaps.append(dict(role=row["role"], extra_source_discriminators=[
                    dict(path=list(path),term=term) for path,term in sorted(extra)]))
        if gaps:
            result["direction"] = "PARTIAL"
            result["reasons"].append("SOURCE_ARGUMENT_DISCRIMINATORS_NOT_BOUND_IN_TARGET")
            result["identity_gaps"] = gaps
            actor = "owner" if target["kind"] in {"PROPERTY","NOMINAL_RELATION"} else "agent"
            affected = {"actor" if row["role"] == actor else "location"
                if row["role"].removeprefix("prep:") in previous.base._LOCATION_PREPS else "object" for row in gaps}
            for field in affected:
                if result["diagnostics"][field]["status"] == "MATCH":
                    result["diagnostics"][field].update(status="PARTIAL",identity_gaps=deepcopy(gaps))
    if speech:
        result["reporting_projection"] = dict(kind="ASSERTIVE_SPEECH_SPECIALIZATION_TO_SAY",
            original_predicates=speech, not_reverse=True, original_source_preserved=True)
    if ability:
        result["derived_disposition"] = ability["v6_disposition"]
    result["source_v6_binding"] = deepcopy(source.get("v6_binding"))
    return result


@lru_cache(maxsize=1024)
def _count_noun(lemma):
    # WordNet supplies only a conservative ordinary count-noun grammar cue,
    # never a person's identity, office, or historical proposition.
    try:
        senses = [s for s in old.lexicon().synsets(lemma,pos="n") if not s.instance_hypernyms()]
        kinds = {s.lexname() for s in senses}
        count = bool(kinds) and kinds <= {"noun.person","noun.animal","noun.plant","noun.artifact"}
        return dict(verified=count,resource="WordNet",ordinary_lexical_classes=sorted(kinds))
    except LookupError:
        return dict(verified=False,resource="WordNet",status="RESOURCE_UNAVAILABLE")


def _grammar_admission(case, reading, fill, parse, bounds):
    result = previous._grammar_admission(case, reading, fill, parse, bounds)
    left, right = case["query"].split(case["focal_marker"])
    completed = result["completed_query"]
    doc = parse(completed)
    a, b = len(left), len(left)+len(fill)
    part = doc.char_span(a,b,alignment_mode="strict")
    if part is None:
        return result
    content = [t for t in part if not t.is_space]
    head = part.root
    compound = (head.pos_ == "NOUN" and head.dep_ == "compound" and head.head not in part
        and head.head.idx >= b and head.head.pos_ in {"NOUN", "PROPN"}
        and all(t.pos_ in {"NOUN", "ADJ", "NUM"} or t.is_punct for t in content))
    if reading.get("form") == "modifier" and compound:
        result["reasons"] = [r for r in result["reasons"] if r != "NOMINAL_OR_FINITE_FILL_IS_NOT_A_MODIFIER"]
        result["compound_modifier"] = dict(licensed=True, dependency="compound",
            modifier=head.text, visible_carrier=head.head.text, source_semantics_certified=False)
    if reading.get("form") == "unknown" and head.tag_ in {"VBN", "VBG"}:
        result["reasons"].append("UNTYPED_PARTICIPLE_SLOT_FORM_NOT_LICENSED")
    possessors = [t for t in content if any(c.tag_ == "POS" for c in t.children)]
    if re.match(r"['\u2019]s\b", right):
        possessors.append(head)
    for possessor in possessors:
        subtree = [t for t in possessor.subtree if a <= t.idx < b]
        count_noun = _count_noun(possessor.lemma_.casefold()) if possessor.pos_ == "NOUN" and possessor.tag_ == "NN" else {}
        if (possessor.pos_ == "NOUN" and possessor.tag_ == "NN"
                and count_noun.get("verified")
                and not any(t != possessor and (t.dep_ in {"det", "poss", "nmod:poss"} or t.pos_ == "PROPN") for t in subtree)
                and not re.search(r"\b(?:a|an|the|this|that)\s*$", left, re.I)):
            result["reasons"].append("SINGULAR_COMMON_NOUN_POSSESSOR_REQUIRES_DETERMINER")
            result["count_noun_grammar"] = count_noun
        if (possessor.tag_ in {"NNS", "NNPS"} and re.match(r"(?:['\u2019]s)?\s*\w+\s*[;,]\s*(?:he|she)\b", right, re.I)
                and not any(t.pos_ in {"PROPN", "PRON"} for t in doc[:part.start])):
            result["reasons"].append("PLURAL_POSSESSOR_WITH_SINGULAR_PERSON_ANAPHOR")
    result["reasons"] = list(dict.fromkeys(result["reasons"]))
    result["admissible"] = not result["reasons"]
    return result


def grammar_admission(case, reading, fill, *, parse=None):
    case = public_case(case)
    engine = _Engine(parse)
    return _grammar_admission(case, reading, fill, engine.parse, old._focal_sentence_bounds(case, engine.parse))


def effective_proposal(proposal):
    """Replay the original occurrence before using its contained grammar span."""
    if not proposal.get("fitted_source_span"):
        return proposal
    source = proposal["sources"][0]
    a, b = proposal["source_span"]
    c, d = proposal["fitted_source_span"]
    origin = source["start"]
    if (not all(type(x) is int for x in (a,b,c,d,origin))
            or not origin <= a <= c < d <= b <= source["end"]
            or source["text"][a-origin:b-origin] != proposal["source_wording"]):
        raise ValueError("Fitted source span does not replay inside original occurrence")
    return dict(proposal, source_span=[c,d], source_wording=source["text"][c-origin:d-origin])


def _source_grammar_admission(case, proposal, engine):
    return old._source_grammar_admission(case,effective_proposal(proposal),engine)


def _construction_constraints(case, reading, proposal, grammar, engine):
    result = old._construction_constraints(case,reading,effective_proposal(proposal),grammar,engine)
    result["original_source_span"] = deepcopy(proposal.get("source_span"))
    result["fitted_source_span"] = deepcopy(proposal.get("fitted_source_span"))
    return result


def _literal_sentence_proofs(atom, pages, engine):
    """Whole source units only; initials/layout never erase assertion scope."""
    from .planning import sentences
    text = atom["source_quote"]
    fixture = dict(id="self",document_id="self",date="1900-01-01",text=text,source_sha256=digest(text))
    # Retain the original stable-subject, date and pronoun safety checks.
    seeds = old._literal_sentence_proofs(atom,[fixture],engine)
    if not seeds:
        return []
    normalize = lambda s: " ".join(initialism_view(s)[0].casefold().split())
    target = normalize(text)
    result = []
    for page in pages:
        units = list(sentences(page["text"]))
        for i,unit in enumerate(units):
            a,b = unit["start"],unit["end"]
            label = re.match(r"[A-Z]\.\s{2,}(?=(?:the|a|an|this|these|those|we|they|it)\b)",unit["text"],re.I)
            if label and (a == 0 or page["text"][a-1] == "\n"):
                a += label.end()
            if normalize(page["text"][a:b]) != target:
                continue
            paragraph = page["text"].rfind("\n\n",0,a)
            if _reporting_block(page["text"][0 if paragraph < 0 else paragraph+2:a],engine.parse):
                continue
            proof = deepcopy(seeds[0])
            proof["citation"] = dict(document_id=page["document_id"],canonical_page_id=page["id"],
                date=page["date"],document_date=page["date"],start=a,end=b,text=page["text"][a:b],
                page_sha256=page["source_sha256"])
            proof["source_binding"].update(kind="EXACT_WHOLE_SOURCE_UNIT_V6",source_sentence_start=a,
                source_sentence_end=b,case_whitespace_only=False,initialism_whitespace_only=True,
                original_source_text_preserved=True,source_unit_index=i)
            result.append(proof)
    return result


def _functions(**overrides):
    from . import planning
    context, _ = clone(previous.base, dict(sentences=planning.sentences,
        _validate_plan=lambda case, plan: planning.validate_plan(plan, case)))
    base = ModuleType(previous.base.__name__)
    base.__dict__.update(context)
    bindings = dict(base=base, _Engine=_Engine, compare_frames=compare_frames,
        _diagnostics=_diagnostics, _grammar_admission=_grammar_admission,
        _source_grammar_admission=_source_grammar_admission, _construction_constraints=_construction_constraints,
        _unclear_reporting_block=_reporting_block, _literal_sentence_proofs=_literal_sentence_proofs, VERSION=VERSION)
    bindings.update(overrides)
    _, functions = clone(old, bindings)
    return functions


def execute(case, plan, retrieval, passage_budget=100, parse=None):
    from .planning import validate_plan
    validate_plan(plan, case)
    result = _functions()["execute_v3"](case, plan, retrieval, passage_budget=passage_budget, parse=parse)
    result["factual_support"] = dict(status=previous._factual(result["status"]),
        missing_support_is_counterevidence=False, basis="CITED_RAW_TEXT_AND_STRUCTURED_GATES", generated_labels_are_proof=False)
    result["execution_policy"] = dict(version=VERSION, frozen_engine_modified=False, source_text_modified=False,
        general_entailment_certified=False, eligibility_rechecked=True)
    for atom in result["atoms"]:
        atom["factual_support"] = previous._factual(atom["status"])
    return result


def _support_assessment(case, candidate, engine, *, source_index=None, bounds=None):
    reading = candidate.get("v6_reading", {})
    prior = engine.disposition_reading
    engine.disposition_reading = (reading.get("form") == "modifier" and reading.get("role") == "nominal_property"
        and reading.get("target_kind") == "property")
    try:
        result = _assess_focal(case,candidate,engine,source_index=source_index,bounds=bounds)
    finally:
        engine.disposition_reading = prior
    ds = [e["direction"] for e in result["evidence"]]
    result["factual_status"] = ("MIXED" if "COUNTER" in ds and "SUPPORT" in ds else "COUNTER" if "COUNTER" in ds else
        "SUPPORT" if result["substantive_support"] else "PARTIAL" if any(d in {"SUPPORT", "PARTIAL"} for d in ds) else "UNSUPPORTED")
    result["absence_is_counterevidence"] = False
    result["source_integrity"] = "RAW_ELIGIBLE_PAGES_REPLAYED"
    if any(e.get("derived_disposition") for e in result["evidence"]):
        result["scope"] = "FOCAL_DISPOSITION_ONLY_NOT_ACTUAL_EVENT"
        result["supports_whole_event"] = False
    return result


def _assess_focal(case, candidate, engine, *, source_index=None, bounds=None):
    assessment = dict(status="Inferred", scope="FOCAL_CONTRIBUTION_ONLY", substantive_support=False,
        supports_completed_slot=False, supports_whole_event=False,
        partial_clue=candidate.get("support") == "LOCAL_PROPERTY_ATTESTED",
        absence_is_counterevidence=False, evidence=[])
    targets, reason = old._focal_frames(case,candidate["fill"],engine,bounds)
    assessment["reason"] = reason
    index = source_index if source_index is not None else old._assessment_sources(case,candidate.get("sources",[]),engine)
    states = []
    for target in targets:
        records = []
        sources = list(index.get(target["predicate"],[]))
        if target["predicate"] == "say":
            sources += [pair for predicate in _ASSERTIVE_REPORTS-{"say"} for pair in index.get(predicate,[])]
        for citation, source in sources:
            match = compare_frames(target,source,engine=engine)
            if match is None or match["direction"] not in {"SUPPORT","COUNTER","PARTIAL"}:
                continue
            local = span(citation["text"],source["start"],source["end"])
            record = dict(direction=match["direction"], diagnostics=match["diagnostics"], reasons=match["reasons"],
                citation=dict(citation,start=citation["start"]+local["start"],end=citation["start"]+local["end"],text=local["text"]))
            for key in ("derived_disposition","reporting_projection","source_v6_binding","identity_gaps"):
                if match.get(key):
                    record[key] = deepcopy(match[key])
            records.append(record)
        states.append(previous.base._status(r["direction"] for r in records))
        assessment["evidence"].extend(records)
    if states and all(s == "SUPPORT" for s in states):
        assessment.update(status="Supported",substantive_support=True,supports_completed_slot=True,
            reason="ALL_FOCAL_STRUCTURED_REQUIREMENTS_SOURCE_SUPPORTED",
            scope="FOCAL_PROPERTY_ONLY" if all(f["kind"] == "PROPERTY" for f in targets) else "FOCAL_CONTRIBUTION_ONLY",
            supports_whole_event=all(f["kind"] == "EVENT" for f in targets))
    else:
        assessment["reason"] = "FOCAL_EVENT_OR_PROPERTY_NOT_ESTABLISHED"
    assessment["same_scoped_counterevidence"] = any(e["direction"] == "COUNTER" for e in assessment["evidence"])
    if assessment["same_scoped_counterevidence"]:
        assessment["reason"] = "EXPLICIT_COUNTEREVIDENCE_TO_FOCAL_REQUIREMENT"
    return assessment


def filter_redaction(case, result, top_k=5, *, retrieval=None, passage_budget=100, parse=None):
    case = public_case(case)
    compatible, duplicates = previous._validated_candidate_views(result)
    compatible = deepcopy(compatible)
    for row in compatible["_candidate_audit"]["readings"]:
        for candidate in row["proposals"]:
            candidate["v6_reading"] = deepcopy(row["reading"])
    replay = None
    full = None
    if retrieval is not None:
        pages, replay = previous._citation_replay(case, compatible["_candidate_audit"], retrieval, passage_budget)
        full = [dict(canonical_page_id=p["id"], document_id=p["document_id"], date=p["date"],
            start=0,end=len(p["text"]),text=p["text"],page_sha256=p["source_sha256"]) for p in pages]
    def assessment_sources(c, citations, engine):
        return old._assessment_sources(c, full if full is not None else citations, engine)
    output = _functions(_Engine=lambda: _Engine(parse), _support_assessment=_support_assessment,
        _assessment_sources=assessment_sources)["filter_redaction"](case, compatible, top_k=top_k)
    summary = output.pop("task_execution_v3")
    summary.update(version=VERSION, candidate_feasibility_is_factual_support=False, source_replay=replay,
        repeated_id_occurrences=duplicates, source_integrity="RAW_ELIGIBLE_PAGES_REPLAYED" if retrieval else "CALLER_REPLAYS_RAW_PAGES")
    output["task_execution_v6"] = summary
    output["_candidate_audit"]["task_execution_v6"] = output["_candidate_audit"].pop("task_execution_v3")
    for row in output["readings"]:
        for c in row["candidates"]:
            c["disposition"] = previous._disposition(c, contextual=bool(c.get("sources")))
            c["candidate_feasibility"] = dict(status="FEASIBLE", basis="LOCAL_INSERTION_AND_SOURCE_BOUND_CHECKS")
            c["support_dimensions"] = dict(wording="Source-attested", identity=c.get("v6_identity_binding", {}).get("status", "Unresolved"),
                factual=c["disposition"]["evidence_label"], property_scope=c["support_assessment"]["scope"],
                absence_is_counterevidence=False)
        row["exploratory_candidates"] = deepcopy(row["candidates"])
        row["evidence_candidates"] = [deepcopy(c) for c in row["candidates"] if c["support_assessment"]["substantive_support"]]
    return output


execute_v6 = execute
filter_redaction_v6 = filter_redaction
