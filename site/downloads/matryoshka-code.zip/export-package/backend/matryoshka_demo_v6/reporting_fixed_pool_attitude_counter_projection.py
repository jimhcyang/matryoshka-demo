"""Additive universal-attitude counter observer, not frozen native inference.

An actual named holder's positive BELIEVE/SAY THAT P can contradict that same
holder NEVER having that attitude to P. P is an opaque, completely retained
content constraint: neither its truth nor any inner event is established.
Only literal dependency structure and two checked comparative spellings match;
there are no aliases, synonym sets, entity lists, scores or saved verdict reads.
"""
from collections import Counter, defaultdict
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_demo_v61 import scope_matching as scoped
from matryoshka_demo_v6 import planning as literal
from . import reporting_local_decisions_v65 as policy

VERSION = "raw-universal-attitude-counter-observer/1"
KIND = "UNBOUNDED_NEVER_ATTITUDE_COUNTEREXAMPLE"
PARENTS = {"believe", "say"}
_OPAQUE = re.compile(r'''[\[\]"\u201c\u201d?]|(?<!\w)['\u2018]|['\u2019](?!\w)|\b(?:qte|quote|unqte|unquote)\b''', re.I)
_MARKER = re.compile(r"(?:(?P<letter>[A-Z])\.[ \t]{2,}|\d{1,2}[.)][ \t]+)")


def _proof(text, lo, hi):
    return dict(start=lo, end=hi, text=text[lo:hi])


def _span(token):
    words = [t for t in token.subtree if not t.is_space]
    return min(t.idx for t in words), max(t.idx + len(t) for t in words)


def _words(token):
    return [t.text.casefold() for t in token.subtree if not t.is_space and not t.is_punct]


def _phrase(value):
    return dict(words=[p["text"].casefold() for p in value["proofs"]],
        quantifiers=value.get("quantifiers", []), unresolved=value.get("unresolved"),
        modifiers=[dict(relation=m["relation"], phrase=_phrase(m["phrase"]))
            for m in value.get("modifiers", [])])


def _tree(token, omitted):
    # Dependency labels retain agency, attachment and polarity. Order within
    # each dependency class is retained, including compound names/conjuncts.
    children = defaultdict(list)
    for child in token.children:
        if child.i not in omitted and not child.is_space and not child.is_punct:
            children[child.dep_].append(_tree(child, omitted))
    return [token.text.casefold(), [[key, children[key]] for key in sorted(children)]]


def _comparative(content):
    """Normalize only MORE/LESS ADV ... THAN (same modal) NP ellipsis.

    The optional copied modal must equal the sole main-clause modal. The
    comparator is one complete subject NP, not a lexical subordinate event.
    This does not resolve an omitted argument or an omitted main predicate.
    """
    thans = [t for t in content.subtree if t.lower_ == "than"]
    if not thans:
        return {}, set(), None
    if len(thans) != 1:
        return None
    than = thans[0]
    modals = [t for t in content.children if t.dep_ == "aux" and t.tag_ == "MD"]
    manners = [t for t in content.children if t.dep_ == "advmod" and t.pos_ == "ADV"
        and any(c.dep_ == "advmod" and c.lower_ in {"more", "less"} for c in t.children)]
    if len(modals) != 1 or len(manners) != 1 or content.pos_ != "VERB":
        return None
    manner, modal = manners[0], modals[0]
    copied_modal = None
    if than.dep_ == "prep" and than.head == manner:
        objects = [t for t in than.children if t.dep_ == "pobj"]
        if len(objects) != 1 or len(list(than.children)) != 1:
            return None
        noun = objects[0]
        omitted = {t.i for t in than.subtree}
    elif than.dep_ == "mark" and than.head.dep_ == "advcl" and than.head.head == content:
        auxiliary = than.head
        subjects = [t for t in auxiliary.children if t.dep_ == "nsubj"]
        children = [t for t in auxiliary.children if not t.is_space and not t.is_punct]
        if (auxiliary.pos_ != "AUX" or auxiliary.tag_ != "MD"
                or auxiliary.lower_ != modal.lower_ or len(subjects) != 1
                or set(children) != {than, subjects[0]}):
            return None
        noun = subjects[0]
        omitted = {t.i for t in auxiliary.subtree}
        copied_modal = auxiliary.i
    else:
        return None
    if (noun.pos_ not in {"NOUN", "PROPN"}
            or any(t.pos_ in {"VERB", "AUX", "PRON"} or t.dep_ in {"conj", "relcl", "advcl"}
                for t in noun.subtree)):
        return None
    return dict(kind="EXACT_SUBJECT_COMPARATIVE_WITH_OPTIONAL_COPIED_MODAL",
        manner=_tree(manner, omitted), comparator_np=_words(noun),
        modality=modal.lower_), omitted, copied_modal


def _content_signature(content, frames, parent):
    subjects = [t for t in content.children if t.dep_ in {"nsubj", "nsubjpass"}]
    if len(subjects) != 1 or any(t.pos_ == "PRON" for t in content.subtree):
        return None
    comparative = _comparative(content)
    if comparative is None:
        return None
    comparison, omitted, copied = comparative
    marks = [t for t in content.children if t.dep_ == "mark" and t.lower_ == "that"]
    if len(marks) != 1:
        return None
    omitted = omitted | {marks[0].i}
    matches = [f for f in frames if f["predicate_proof"]["start"] == content.idx]
    if len(matches) != 1:
        return None
    frame = matches[0]
    if frame["qualifiers"].get("unresolved"):
        return None
    scopes = frame["qualifiers"]["scope"]
    if (len(scopes) != 1 or scopes[0]["relation"] != "ccomp"
            or scopes[0]["predicate"] != parent.lemma_.casefold()):
        return None
    signature = dict(tree=_tree(content, omitted), comparative=comparison,
        typed_frame=dict(kind=frame["kind"], predicate=frame["predicate"],
            roles={r:[_phrase(p) for p in ps] for r, ps in frame["roles"].items()},
            inner_negated=frame["qualifiers"]["negated"],
            inner_modality=frame["qualifiers"]["modality"],
            inner_conditional=frame["qualifiers"]["conditional"]))
    # A token-conservation check supplements, but never replaces, the typed
    # tree. Only the repeated comparative modal and the required THAT are
    # excluded. Articles, quantities, dates, NOT and all other auxiliaries stay.
    signature["complete_tokens"] = sorted(Counter(t.text.casefold() for t in content.subtree
        if not t.is_space and not t.is_punct and t.i not in {marks[0].i, copied}).items())
    return signature


def _attitude(text, engine, *, universal):
    if _OPAQUE.search(text):
        return None
    doc = engine.parse(text)
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1:
        return None
    parent = roots[0]
    if (parent.lemma_.casefold() not in PARENTS or parent.pos_ != "VERB"
            or parent.tag_ not in ({"VBD"} if universal else {"VBD", "VBP", "VBZ"})):
        return None
    subjects = [t for t in parent.children if t.dep_ == "nsubj"]
    contents = [t for t in parent.children if t.dep_ == "ccomp" and t.pos_ in {"VERB", "AUX"}]
    nevers = [t for t in parent.children if t.lower_ == "never" and t.dep_ == "neg"]
    if len(subjects) != 1 or len(contents) != 1 or len(nevers) != int(universal):
        return None
    holder, content = subjects[0], contents[0]
    name = [t for t in holder.subtree if not t.is_space and not t.is_punct]
    if (not any(t.pos_ == "PROPN" for t in name)
            or any(t.pos_ != "PROPN" and not (t.dep_ == "det" and t.lower_ == "the") for t in name)
            or any(t.dep_ == "conj" for t in name)):
        return None
    consumed = {t.i for t in [*holder.subtree, *content.subtree, parent, *nevers]}
    if any(t.i not in consumed and not t.is_space and not t.is_punct for t in doc):
        return None
    frames = engine.frames(text)
    parents = [f for f in frames if f["predicate_proof"]["start"] == parent.idx and f["kind"] == "EVENT"]
    if len(parents) != 1:
        return None
    frame = parents[0]
    qualifiers = frame["qualifiers"]
    if (bool(qualifiers["negated"]) != universal or frame.get("event_dates") or frame.get("deictic_time")
            or any(value for key, value in qualifiers.items() if key not in {"negated", "negation_proofs"})
            or [p["text"].casefold() for p in qualifiers["negation_proofs"]] != (["never"] if universal else [])
            or any(p["start"] != content.idx for p in frame["unbound_arguments"])):
        return None
    signature = _content_signature(content, frames, parent)
    if signature is None:
        return None
    return dict(parent_predicate=parent.lemma_.casefold(), holder_tokens=_words(holder),
        holder=_proof(text, *_span(holder)), parent=_proof(text, parent.idx, parent.idx + len(parent)),
        content=_proof(text, *_span(content)), content_signature=signature,
        parent_scope=deepcopy(qualifiers), universal_never=universal)


def query_spec(case, plan, atom_id, *, engine):
    """Require every atom's exact bytes and all whole-query context first."""
    atoms = plan.get("atoms", [])
    if (case["task"] != "hypothesis" or case.get("focal_marker")
            or plan.get("query_sha256") != digest(case["query"])
            or len({a["id"] for a in atoms}) != len(atoms)):
        return None
    found = [a for a in atoms if a["id"] == atom_id]
    if len(found) != 1:
        return None
    prior = 0
    for atom in sorted(atoms, key=lambda a:a["start"]):
        lo, hi = atom["start"], atom["end"]
        if (type(lo) is not int or type(hi) is not int or not prior <= lo < hi <= len(case["query"])
                or case["query"][prior:lo].strip() or atom.get("required") is not True
                or atom["text"] != case["query"][lo:hi] or atom["source_quote"] != atom["text"]):
            return None
        atom_view, _, _ = scoped._layout(engine, atom["text"])
        roots = [t for t in engine.parse(atom_view) if t.dep_ == "ROOT"]
        if (len(roots) != 1 or roots[0].pos_ not in {"VERB", "AUX"}
                or not any(t.tag_ in {"VBD", "VBP", "VBZ"} for t in [roots[0], *roots[0].children])):
            return None
        prior = hi
    if case["query"][prior:].strip():
        return None
    atom = found[0]
    view, _, _ = scoped._layout(engine, atom["text"])
    attitude = _attitude(view, engine, universal=True)
    if attitude is None:
        return None
    contexts = [s for s in _source_attitudes(case["query"], engine) if s["universal_never"]
        and s["sentence"]["start"] == atom["start"] and s["sentence"]["end"] == atom["end"]]
    if len(contexts) != 1 or contexts[0]["content_signature"] != attitude["content_signature"]:
        return None
    return dict(atom=deepcopy(atom), attitude=attitude, query_sha256=digest(case["query"]))


def _source_attitudes(raw, engine):
    previous = None
    for unit in literal.sentences(raw):
        prefix = raw[:unit["start"]]
        blocked = literal._open_reporting_context(prefix)
        # A list item cannot close a pending conditional header. Conservatively
        # keep such a header open through the remainder of this source page.
        for colon in re.finditer(":", prefix):
            before = re.split(r"[.!?]\s+|\n\s*\n", prefix[:colon.start()])[-1]
            blocked = blocked or bool(re.match(r"\s*(?:if|unless|suppose|assuming)\b", before, re.I))
        if previous is not None:
            prior = previous["text"]
            markers = list(re.finditer(r"(?m)^[ \t]*(?:[A-Z]|\d+)[.)][ \t]+", prior))
            if markers:
                prior = prior[markers[-1].end():]
            prior, _, _ = scoped._layout(engine, prior)
            prior_doc = engine.parse(prior)
            if (prior.strip() and not re.fullmatch(r"\d{1,2}[.)]", prior.strip())
                    and not any(t.pos_ in {"VERB", "AUX"} and t.tag_ in {"VBD", "VBP", "VBZ"} for t in prior_doc)):
                blocked = True
            blocked = blocked or scoped.native._reporting_block(prior, engine.parse) or any(
                t.dep_ == "ROOT" and scoped.matching.lemma(t) in scoped.matching.parent._REPORTING
                and any(c.lower_ in {"following", "quotation", "quote"}
                    for c in t.subtree) for t in prior_doc)
            blocked = blocked or bool(re.match(r"\s*(?:if|unless|suppose|assuming)\b", prior, re.I))
        previous = unit
        if blocked:
            continue
        text, shift = unit["text"], unit["start"]
        marker = _MARKER.match(text)
        if marker:
            # A list marker is typography only when it starts a physical line.
            if raw[raw.rfind("\n", 0, shift) + 1:shift].strip():
                continue
            if marker["letter"]:
                # A lone personal initial is not a removable section marker.
                # Require a neighboring, consecutively lettered physical line.
                letters = list(re.finditer(r"(?m)^[ \t]*([A-Z])\.[ \t]{2,}", raw))
                positions = [i for i, m in enumerate(letters) if m.start(1) == shift]
                if len(positions) != 1 or not any(0 <= j < len(letters)
                        and ord(letters[j][1]) - ord(marker["letter"]) == j - positions[0]
                        for j in (positions[0] - 1, positions[0] + 1)):
                    continue
            text, shift = text[marker.end():], shift + marker.end()
        view, offsets, edits = scoped._layout(engine, text)
        for universal in (False, True):
            value = _attitude(view, engine, universal=universal)
            if value is None:
                continue
            for key in ("holder", "parent", "content"):
                span = value[key]
                lo, hi = span["start"], span["end"]
                if offsets is not None:
                    lo, hi = offsets[lo], offsets[hi - 1] + 1
                value[key] = _proof(raw, shift + lo, shift + hi)
            value["sentence"] = _proof(raw, unit["start"], unit["end"])
            value["literal_boundary_replay"] = dict(complete_printed_sentence=True,
                abbreviation_guard=True, open_reporting_context_rejected=True,
                source_text_modified=False, enumerated_line_marker=marker.group() if marker else None,
                analysis_layout_edits=edits)
            yield value


def observe(case, plan, atom_id, admitted, index, *, engine):
    """Inspect only supplied saved pages; index MUST include veto siblings."""
    result = dict(version=VERSION, atom_id=atom_id, status="UNRESOLVED", certificates=[],
        signed_conflict_citations=[], absence_is_counterevidence=False,
        native_or_gate_verdict_rewritten=False, keys_read=False, grades_read=False,
        model_calls=0, actual_inner_event_established=False)
    spec = query_spec(case, plan, atom_id, engine=engine)
    if spec is None:
        result["reason"] = "Outside whole-atom unbounded past NEVER BELIEVE/SAY THAT scope"
        return result
    wanted = spec["attitude"]
    pages, masks, veto = index
    for page in admitted.values():
        policy._quote(policy._citation(page, 0, len(page["text"])), pages, masks, veto, case)
        for offered in _source_attitudes(page["text"], engine):
            if any(wanted[key] != offered[key] for key in ("parent_predicate", "holder_tokens", "content_signature")):
                continue
            sentence = offered["sentence"]
            citation = policy._citation(page, sentence["start"], sentence["end"])
            policy._quote(citation, pages, masks, veto, case)
            if offered["universal_never"]:
                result["signed_conflict_citations"].append(citation)
                continue
            certificate = dict(version=VERSION, kind=KIND, atom_id=atom_id,
                atom_binding=deepcopy(spec["atom"]), query_sha256=spec["query_sha256"],
                direction="Counterevidence", citation=citation,
                parent_predicate=offered["parent_predicate"], holder_binding="EXACT_COMPLETE_LITERAL_NAMED_HOLDER",
                complete_content_signature=deepcopy(offered["content_signature"]),
                source_parent_scope=offered["parent_scope"],
                literal_boundary_replay=offered["literal_boundary_replay"],
                universal_scope="UNBOUNDED_PAST_NEVER_AS_OF_QUERY_CUTOFF",
                outer_attitude_only=True, actual_inner_event_established=False,
                source_assertion_not_world_truth=True, source_publication_is_not_inferred_event_date=True,
                inner_polarity_modality_condition_and_all_content_preserved=True,
                new_retrieval=False)
            for key in ("holder", "parent", "content"):
                span = offered[key]
                certificate[key] = policy._citation(page, span["start"], span["end"])
                policy._quote(certificate[key], pages, masks, veto, case)
            result["certificates"].append(certificate)
    if result["signed_conflict_citations"]:
        result["certificates"] = []
        result["reason"] = "Same-content explicit NEVER claim also occurs in this inspected pool"
    elif result["certificates"]:
        result["status"] = "ATTITUDE_COUNTER_ONLY"
    else:
        result["reason"] = "No actual same-holder same-complete-content counterexample in saved inspected pages"
    return result
