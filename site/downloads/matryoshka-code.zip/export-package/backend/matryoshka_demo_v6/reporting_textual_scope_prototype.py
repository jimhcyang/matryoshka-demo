"""Unpromoted exact source-text completion, explicitly not world-event support.

No candidate generation, ranking, semantic equivalence or inference mutation.
Quoted/reporting text conservatively retains its complete literal paragraph;
cross-paragraph or unresolved source scope abstains. This intentionally has
lower recall than a general source-content or discourse interpretation system.
"""
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from . import planning as literal
from . import reporting_local_decisions_v65 as provenance

VERSION = "literal-source-text-completion-prototype/1"
_QUOTE = re.compile(r'"|[\u201c\u201d\u2018\u2019]|(?<!\w)\'|\'(?!\w)|\b(?:qte|quote|unqte|unquote|end\s+quote)\b', re.I)
_QUOTE_WORD = re.compile(r"\b(?:qte|quote|unqte|unquote|end\s+quote)\b", re.I)
_HYPHEN_WRAP = re.compile(r"(?<=[A-Za-z]-)[ \t]*\r?\n[ \t]*(?=[A-Za-z])")
_CONTEXT = re.compile(r"\b(?:following|forecast|prediction|quotation|statement|allegation|belief)\b", re.I)
_SCOPE_MARKS = frozenset("if unless when while before after until although though because provided assuming".split())


class Abstain(ValueError):
    pass


def normalize(text):
    """One-to-one lowercasing and offset-audited whitespace/layout edits only.

    A printed hyphen is never deleted. `peace-\\nkeeping` can match
    `peace-keeping`; `inter-\\nvene` cannot match `intervene`.
    """
    omitted = {i for m in _HYPHEN_WRAP.finditer(text) for i in range(*m.span())}
    chars, offsets, edits = [], [], []
    for match in _HYPHEN_WRAP.finditer(text):
        edits.append(dict(kind="WHITESPACE_AFTER_PRINTED_HYPHEN", start=match.start(), end=match.end(),
            raw=text[match.start():match.end()], printed_hyphen_retained=True))
    i = 0
    while i < len(text):
        if i in omitted:
            i += 1; continue
        if text[i].isspace():
            end = i + 1
            while end < len(text) and (text[end].isspace() or end in omitted): end += 1
            if chars and end < len(text):
                chars.append(" "); offsets.append([i, end])
            i = end; continue
        lowered = text[i].lower()
        if len(lowered) != 1:
            raise Abstain("UNICODE_CASE_EXPANSION_NOT_LICENSED")
        chars.append(lowered); offsets.append([i, i + 1]); i += 1
    return dict(text="".join(chars), raw_offsets=offsets, layout_edits=edits,
        policy="CASE_ONE_TO_ONE_WHITESPACE_COLLAPSE_PRINTED_HYPHEN_RETAINED",
        aliases_synonyms_articles_numbers_punctuation_rewritten=False)


def _balanced(text):
    if text.count('"') % 2 or text.count("\u201c") != text.count("\u201d"):
        return False
    # Apostrophes inside words are not quotation delimiters.
    singles = re.findall(r"(?<!\w)'|'(?!\w)", text)
    if len(singles) % 2 or text.count("\u2018") != len(re.findall(r"\u2019(?!\w)", text)):
        return False
    depth = 0
    for match in _QUOTE_WORD.finditer(text):
        word = " ".join(match.group().lower().split())
        if word in {"qte", "quote"}: depth += 1
        else:
            depth -= 1
            if depth < 0: return False
    return depth == 0 and text.count("(") == text.count(")")


def _scope_sensitive(text):
    if _QUOTE.search(text) or _CONTEXT.search(text): return True
    doc = literal.wire.offset_safe_parser(literal.wire.nlp())(text)
    return any(literal.wire.matching.lemma(t) in literal.wire.matching.parent._REPORTING
        or t.lower_ in _SCOPE_MARKS for t in doc)


def _complete(text):
    if not re.search(r"[.!?](?:[\"'\u201d\u2019)]|\s)*$", text) or not _balanced(text): return False
    if MASK.search(text): return False
    doc = literal.wire.offset_safe_parser(literal.wire.nlp())(text)
    return any(t.tag_ in {"VBD", "VBP", "VBZ", "MD"}
        and not any(c.dep_ == "mark" and c.lower_ in _SCOPE_MARKS for c in (t.head if t.dep_ in {"aux", "auxpass"} else t).children) and
        (any(c.dep_ in {"nsubj", "nsubjpass", "csubj", "expl"} for c in t.children)
         or t.dep_ in {"aux", "auxpass"} and any(c.dep_ in {"nsubj", "nsubjpass", "csubj", "expl"} for c in t.head.children))
        for t in doc)


def statement_units(text):
    """Never trim an attribution, quotation, conditional or opaque prefix.

    Reporting/quoted paragraphs are indivisible conservative scope envelopes,
    not claims that a paragraph is a single grammatical sentence. A pending
    external operator or a prior opaque scope cannot be silently dropped.
    """
    previous = None
    for paragraph in re.finditer(r"\S[\s\S]*?(?=\n[ \t]*\n|\Z)", text):
        start, end = paragraph.span(); raw = paragraph.group()
        prefix = text[:start]
        blocked = literal._open_reporting_context(prefix)
        if previous is not None and (_scope_sensitive(previous) or MASK.search(previous)
                or previous.rstrip().endswith(":") or not _complete(previous)):
            blocked = True
        previous = raw
        if blocked: continue
        if _scope_sensitive(raw):
            if _complete(raw):
                yield dict(start=start, end=end, text=raw, kind="CONSERVATIVE_OPERATOR_PARAGRAPH",
                    complete_scope_envelope=True, wider_than_focal_sentence=True)
            continue
        units = list(literal.sentences(raw)); pending = None
        for unit in units:
            lo = pending if pending is not None else unit["start"]
            candidate = raw[lo:unit["end"]]
            if not _complete(candidate):
                pending = lo; continue
            yield dict(start=start + lo, end=start + unit["end"], text=candidate,
                kind="COMPLETE_LITERAL_SOURCE_SENTENCE", complete_scope_envelope=True,
                wider_than_focal_sentence=False)
            pending = None


def observe(record, case, candidate, eligible_index):
    """Check ONLY saved inspected pages from a complete native eligible index.

    Candidate is caller-supplied. Oracle status belongs to the experimental
    wrapper; no answer key, assessment, candidate score or source label is read.
    Invalid provenance is an integrity error, not missing textual evidence.
    """
    case = public_case(case)
    if case["task"] != "redaction" or public_case(record["case"]) != case:
        raise ValueError("One exact public redaction/native case is required")
    fill = candidate.get("fill")
    if not isinstance(fill, str) or not fill or fill != fill.strip() or MASK.search(fill):
        raise ValueError("Supply an exact nonempty, unpadded, mask-free fill")
    if record.get("plan", {}).get("query_sha256", digest(case["query"])) != digest(case["query"]):
        raise ValueError("Saved plan belongs to a different public query")
    ids = record.get("inspected_page_ids")
    if not isinstance(ids, list) or not ids or len(ids) != len(set(ids)):
        raise ValueError("Exact nonempty saved inspected pool required")
    result_meta = record["result"]
    if result_meta.get("source_pages_inspected", len(ids)) != len(ids): raise ValueError("Inspected count differs")
    budget = result_meta.get("passage_budget", result_meta.get("retrieval", {}).get("construction_passage_budget"))
    if type(budget) is not int or budget < len(ids): raise ValueError("Saved pool exceeds its passage budget")
    index = provenance._pages(eligible_index, case)
    pages, masks, veto = index
    veto = set(veto) | set(record.get("handling_veto_documents", []))
    admitted = {}
    for pid in ids:
        if pid not in pages: raise ValueError("Saved source is absent from bound source index")
        page = pages[pid]
        provenance._quote(provenance._citation(page, 0, len(page["text"])), pages, masks, veto, case)
        admitted[pid] = page
    at = case["query"].index(case["focal_marker"])
    filled = case["query"][:at] + fill + case["query"][at + len(case["focal_marker"]):]
    fill_end = at + len(fill)
    output = dict(version=VERSION, case_id=case["case_id"], query_sha256=digest(case["query"]),
        candidate_id=candidate.get("id"), candidate_fill=fill, candidate_sha256=digest(fill),
        original_masked_query=case["query"], completed_query=filled, completed_query_sha256=digest(filled),
        focal_span=[at, fill_end], nonfocal_unknown_masks_preserved=True,
        unknown_masks_after_insertion=[m.group() for m in MASK.finditer(filled)],
        textual_completion_status="ABSTAIN", textual_completion_certified=False, certificates=[],
        world_support=dict(status="NOT_ASSESSED", inner_world_event_established=False,
            source_claim_truth_certified=False), source_scope="SAVED_INSPECTED_POOL_TEXT_ONLY",
        inspected_page_ids=deepcopy(ids), candidate_generation_performed=False, ranking_changed=False,
        native_or_active_gate_changed=False, keys_read=False, grades_read=False, api_calls=0,
        limitations=["Exact source-text restoration only, not answer-key correctness or world-event support.",
            "Quoted/reporting paragraphs retain wider literal context; unresolved boundaries, opaque content, cross-page or cross-paragraph operators can over-abstain.",
            "Sentence completeness uses the pinned local parser as a conservative boundary guard, not semantic entailment."])
    with offline():
        units = [u for u in statement_units(filled) if u["start"] <= at < fill_end <= u["end"]]
        if len(units) != 1:
            output["reason"] = "NO_UNIQUE_COMPLETE_FOCAL_STATEMENT_WITH_ALL_SCOPE_AND_UNKNOWNS_RETAINED"
            return output
        wanted = units[0]
        try: normalized = normalize(wanted["text"])
        except Abstain as error:
            output["reason"] = str(error); return output
        output["focal_statement"] = deepcopy(wanted)
        candidate_positions = [i for i, (lo, hi) in enumerate(normalized["raw_offsets"])
            if max(lo + wanted["start"], at) < min(hi + wanted["start"], fill_end)]
        if not candidate_positions: raise ValueError("Focal insertion lost during normalization")
        first, last = min(candidate_positions), max(candidate_positions)
        for page in admitted.values():
            for offered in statement_units(page["text"]):
                try: source = normalize(offered["text"])
                except Abstain: continue
                if source["text"] != normalized["text"]: continue
                quote = provenance._citation(page, offered["start"], offered["end"])
                provenance._quote(quote, pages, masks, veto, case)
                lo = offered["start"] + source["raw_offsets"][first][0]
                hi = offered["start"] + source["raw_offsets"][last][1]
                focal_quote = provenance._citation(page, lo, hi)
                provenance._quote(focal_quote, pages, masks, veto, case)
                if normalize(focal_quote["text"])["text"] != normalize(fill)["text"]:
                    raise ValueError("Exact focal source boundary did not replay")
                certificate = dict(kind="LITERAL_SOURCE_TEXT_COMPLETION_NOT_WORLD_SUPPORT",
                    query_statement=deepcopy(wanted), query_normalized_sha256=digest(normalized["text"]),
                    citation=quote, raw_quote_sha256=digest(quote["text"]), source_statement_kind=offered["kind"],
                    focal_source_citation=focal_quote, source_normalized_sha256=digest(source["text"]),
                    query_layout_edits=normalized["layout_edits"], source_layout_edits=source["layout_edits"],
                    normalization=normalized["policy"], full_statement_equal_not_substring=True,
                    all_nonwhitespace_words_numbers_operators_and_punctuation_preserved=True,
                    adjacent_unknowns_not_resolved=True, original_raw_quote_unchanged=True,
                    aliases_synonyms_or_protected_token_deletion=False,
                    strict_cutoff_whole_origin_classification_sibling_veto_checked=True,
                    inner_world_event_established=False, source_claim_truth_certified=False)
                certificate["sha256"] = digest(certificate)
                output["certificates"].append(certificate)
    if output["certificates"]:
        output.update(textual_completion_status="LITERAL_SOURCE_TEXT_ATTESTED", textual_completion_certified=True)
    else:
        output["reason"] = "NO_FULL_SCOPE_STATEMENT_LITERAL_MATCH_UNDER_STRICT_NORMALIZATION"
    return output
