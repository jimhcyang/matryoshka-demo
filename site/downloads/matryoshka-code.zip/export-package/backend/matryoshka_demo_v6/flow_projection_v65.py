"""Bounded all-result reverse-cone observer; no native computation is changed."""
from collections import OrderedDict, deque
from copy import deepcopy
import importlib
import json
import math
from pathlib import Path
import re
from threading import RLock

import numpy as np
from scipy.sparse.csgraph import dijkstra

from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.corpus_policy_v5 import scoped_page_view
from matryoshka_demo.io import digest
from . import flow as accounting
from . import flow_projection as native
from . import flow_projection_v64 as previous
from .flow_projection_v63 import with_solver_stopping
from .flow_projection_statistics import CategoryReference


VERSION = "all-result-reverse-cone-replay/6.5.2"
_CACHE = OrderedDict()
_LOCK = RLock()
_REQUEST_LOCKS = {}
_STOP = set("a an the be been being is are was were can could of to and or with for in on by as".split())
_NAME_TITLES = set("former president minister general admiral colonel captain doctor professor chairman chief mr mrs ms dr sir".split())
_NAME_PARTICLES = {"de", "del", "da", "di", "du", "van", "von", "of", "the"}


def _full_name_pattern(label):
    words = str(label).split()
    if not 2 <= len(words) <= 6 or any(word.casefold() in _NAME_TITLES for word in words):
        return None
    names = [word for word in words if word.casefold() not in _NAME_PARTICLES]
    if len(names) < 2 or any(not re.fullmatch(r"[^\W\d_]+(?:[-'][^\W\d_]+)*", word)
            or len(word) < 2 or not word[0].isupper() or word.isupper() for word in names):
        return None
    return re.compile(r"(?<!\w)" + r"\s+".join(re.escape(word) for word in words) + r"(?!\w)", re.I)


def source_identity_representative(db, candidate, case, indices, earliest, horizon):
    """Literal full-name identity context, not a source-owned native answer endpoint."""
    missing = dict(status="SOURCE_READOUT_ONLY", node_ids=[], answer_identity=False,
        factual_support_implied=False,
        note="No unique eligible full observed named-entity label with a verified other-page source unit and finite native walk was found. The original source readout is retained; no identity, edge or mass is invented.")
    fill = " ".join(str(candidate.get("fill", "")).split())
    originals = []
    for proof in candidate.get("sources", []):
        native._verify_quote(db, proof, case)
        page = json.loads(db.execute("SELECT payload FROM page WHERE id=?", (proof["canonical_page_id"],)).fetchone()[0])
        if page.get("visibility", "both") == "both":
            originals.append(proof)
    if not originals or len(fill.split()) < 2:
        return missing
    # Search observed labels, never aliases or a guessed name extracted from context.
    rows = db.execute("SELECT DISTINCT n.id,m.label,p.id,p.payload FROM node n "
        "JOIN mention m ON m.node=n.id JOIN page p ON p.id=m.page "
        "WHERE lower(n.kind)='entity' AND instr(lower(?),lower(m.label))>0 "
        "AND p.date<? AND p.doc!=? AND json_extract(p.payload,'$.permitted')=1 "
        "ORDER BY n.id,m.label,p.id", (fill, case["date"], case["document_id"])).fetchall()
    matched, units = {}, []
    for identity, label, page_id, payload in rows:
        pattern = _full_name_pattern(label)
        literal = pattern.search(fill) if pattern else None
        if not literal or not any(word[0].isupper() for word in literal.group().split()):
            continue
        original = next((p for p in originals if pattern.search(p["text"])), None)
        if original is None:
            continue
        page = json.loads(payload)
        if page.get("visibility", "both") != "both" or not pattern.search(page["text"]):
            continue
        proof = dict(canonical_page_id=page_id, document_id=page["document_id"], date=page["date"],
            start=0, end=len(page["text"]), text=page["text"], page_sha256=page["source_sha256"], earlier_page=page.get("earlier_page"))
        try:
            native._verify_quote(db, proof, case)
        except ValueError:
            continue
        # Count eligible same-name identities BEFORE kernel/horizon/unit filtering.
        matched.setdefault(identity, set()).add(page_id)
        original = next((p for p in originals if p["canonical_page_id"] != page_id and pattern.search(p["text"])), None)
        if original is None:
            continue
        for unit_id, start, end in db.execute("SELECT DISTINCT u.id,u.start,u.end FROM edge e "
                "JOIN unit u ON u.id=e.unit AND u.page=e.page "
                "WHERE e.page=? AND (e.a=? OR e.b=?) ORDER BY u.id", (page_id, identity, identity)):
            text = page["text"][start:end]
            occurrence = pattern.search(text)
            if occurrence is None:
                continue
            unit = dict(proof, start=start, end=end, text=text)
            try:
                native._verify_quote(db, unit, case)
            except ValueError:
                continue
            units.append((identity, label, unit_id, unit, original))
    if len(matched) != 1:
        missing["eligible_matching_identity_count"] = len(matched)
        return missing
    identity = next(iter(matched))
    choices = [u for u in units if u[0] == identity]
    if identity not in indices or earliest[indices[identity]] > horizon or not choices:
        return missing
    choices.sort(key=lambda u: (len(u[3]["text"]), u[3]["date"], u[3]["canonical_page_id"], u[2], u[1]))
    _, label, unit_id, unit, original = choices[0]
    owned = db.execute("SELECT count(*) FROM mention WHERE node=? AND page=?",
        (identity, original["canonical_page_id"])).fetchone()[0]
    return dict(status="SOURCE_IDENTITY_REPRESENTATIVE", node_ids=[identity], label=label,
        proof=deepcopy(original), unit_proof=unit, identity_unit_id=unit_id,
        identity_proofs=[deepcopy(u[3]) for u in choices[:3]], eligible_observed_page_ids=sorted(matched[identity]),
        eligible_matching_identity_count=1, named_actor_identity_only=True, answer_identity=False,
        native_answer_endpoint=False, factual_support_implied=False, original_source_readout_preserved=True,
        native_inspected_construction_evidence=False,
        identity_handoff=dict(kind="NON_NUMERICAL_IDENTITY_HANDOFF", source_page_id=original["canonical_page_id"],
            target_id=identity, numerical_transition=False, creates_edge=False,
            source_page_native_mention_row_count=int(owned), native_source_owned_mention=False),
        alignment="The literal multiword full observed Entity label occurs in the candidate fill, original source quote, and an eligible other-page extraction unit. Uniqueness is within the eligible source index, not a new historical identity or entailment certification. No alias/acronym or contextual owner inference is used.",
        note="Existing named-actor identity context from another eligible source page, not a native answer endpoint or an added mention on the original quote page. The quote-to-identity handoff is non-numerical: it creates no graph edge, transported mass, factual support or native inspected construction evidence. Identity-state relevance is separate from the unchanged native source readout.")


def _terms(text):
    return set(re.findall(r"[^\W_]+", str(text).casefold(), re.UNICODE)) - _STOP


def _owner_head(owner):
    if isinstance(owner, dict):
        owner = owner.get("core_head") or owner.get("head")
    if not isinstance(owner, str):
        return None
    words = re.findall(r"[^\W_]+", owner.casefold(), re.UNICODE)
    if set(words) & {"of", "from", "for", "with", "in", "at", "by", "and", "or"}:
        return None
    words = [word for word in words if word not in _STOP and word != "s"]
    return words[-1] if words else None


def _has_owner(head, text):
    if not head:
        return False
    forms = {head, head+"s", head+"es"}
    if head.endswith("y"):
        forms.add(head[:-1]+"ies")
    return bool(forms & _terms(text))


def source_representative(db, candidate, case, indices, earliest, horizon):
    """An extracted source-local claim/event, never a constructed fill identity."""
    terms = _terms(candidate.get("source_wording") or candidate.get("fill", ""))
    owner_supplied = candidate.get("source_owner") not in (None, "")
    owner_head = _owner_head(candidate.get("source_owner"))
    choices = []
    for proof in candidate.get("sources", []):
        native._verify_quote(db, proof, case)
        if not terms or not terms <= _terms(proof["text"]):
            continue
        if owner_supplied and not _has_owner(owner_head, proof["text"]):
            continue
        rows = db.execute(
            "SELECT DISTINCT n.id,n.kind,m.label,u.start,u.end FROM mention m "
            "JOIN node n ON n.id=m.node JOIN edge e ON e.page=m.page AND (e.a=n.id OR e.b=n.id) "
            "JOIN unit u ON u.id=e.unit AND u.page=e.page "
            "WHERE m.page=? AND lower(n.kind) IN ('claim','event') AND u.start<? AND u.end>?",
            (proof["canonical_page_id"], proof["end"], proof["start"])).fetchall()
        page = json.loads(db.execute("SELECT payload FROM page WHERE id=?", (proof["canonical_page_id"],)).fetchone()[0])
        for identity, kind, label, start, end in rows:
            if identity not in indices or earliest[indices[identity]] > horizon or not terms <= _terms(label):
                continue
            if owner_supplied and not _has_owner(owner_head, label):
                continue
            text = page["text"][start:end]
            unit = dict(proof, start=start, end=end, text=text)
            native._verify_quote(db, unit, case)
            overlap = len(_terms(label) & _terms(proof["text"])) / max(1, len(_terms(label) | _terms(proof["text"])))
            choices.append((-overlap, kind.lower() != "claim", identity, label, unit, proof))
    if not choices:
        return dict(status="SOURCE_READOUT_ONLY", node_ids=[], answer_identity=False,
            factual_support_implied=False, supplied_source_owner=candidate.get("source_owner"), source_owner_head=owner_head,
            note="No eligible extracted claim/event matches the saved quotation, fill terms and supplied source owner when present. No substitute entity or solver mass is invented.")
    _, _, identity, label, unit, proof = min(choices, key=lambda v: v[:4])
    return dict(status="SOURCE_QUOTE_ALIGNED_SEMANTIC_REPRESENTATIVE", node_ids=[identity],
        label=label, proof=deepcopy(proof), unit_proof=unit, answer_identity=False,
        alignment="Extracted label and verified quotation match fill terms and the supplied owner core head when present; the extraction unit only overlaps the quotation. The index has no claim mention offsets, so this is not claim-specific span, primary-quotation or entailment certification.",
        supplied_source_owner=candidate.get("source_owner"), source_owner_head=owner_head,
        owner_alignment="SUPPLIED_OWNER_CORE_HEAD_LEXICAL_MATCH_NOT_IDENTITY_OR_ROLE_CERTIFICATION" if owner_supplied else "OWNER_NOT_SUPPLIED_NOT_INFERRED_FROM_CONTEXT",
        unit_contains_fill_terms=terms <= _terms(unit["text"]),
        factual_support_implied=False,
        note="Existing quotation-aligned extracted claim/event, not an answer identity, primary quote or an upgraded support/entailment verdict.")


def _earliest(matrix, prior, horizon):
    starts = np.flatnonzero(prior > 0)
    if not len(starts):
        return np.full(len(prior), np.inf)
    return dijkstra(matrix, directed=True, indices=starts, min_only=True, unweighted=True, limit=horizon)


def _kind(source, target, nodes):
    if source == target:
        return "NUMERICAL_SELF_LOOP"
    left, right = source.startswith("hierarchy:"), target.startswith("hierarchy:")
    if left and right:
        return "SOURCE_AGGREGATE" if nodes[source]["type"].lower() == nodes[target]["type"].lower() else "NAVIGATION"
    return "NAVIGATION" if left or right else "SOURCE"


def recover_union_drawing(flow, expanded, candidates, node_lookup, parent_lookup, source_proof,
                          *, limit=1024, numerical=None, earliest=None):
    """Exact full-kernel replay observed at a bounded union of reverse BFS states."""
    if type(limit) is not int or not 32 <= limit <= 1024:
        raise ValueError("Drawing limit must be between 32 and 1024")
    snap = expanded["walk_snapshot"]
    if flow.get("walk_snapshot_sha256") != snap["sha256"]:
        raise ValueError("Drawing and native kernel bindings differ")
    matrix, prior, final, indices = numerical or accounting.read_snapshot(snap)
    earliest = _earliest(matrix, prior, snap["iterations"]) if earliest is None else earliest
    ids, horizon, alpha = snap["state_ids"], snap["iterations"], snap["alpha"]
    incoming = matrix.tocsc()
    old_nodes = {n["id"]: n for n in expanded["nodes"]}
    nodes, parent_ids, selected, order = {}, {}, set(), []
    capacity = limit - len(flow.get("starters", [])) - 1
    if capacity < 1:
        raise ValueError("Query inputs exceed the drawing budget")

    def metadata(identity):
        if identity not in nodes:
            value = node_lookup(identity)
            if not value or value.get("id") != identity:
                return None
            nodes[identity] = dict(value)
            parent_ids[identity] = parent_lookup(identity)
        return nodes[identity]

    def admit(identity):
        chain, seen, at = [], set(), identity
        while at:
            if at in seen:
                raise ValueError("Cyclic hierarchy parent closure")
            seen.add(at)
            if metadata(at) is None:
                return False
            chain.append(at); at = parent_ids[at]
        if len(selected | set(chain)) > capacity:
            return False
        for at in chain:
            if at not in selected:
                selected.add(at); order.append(at)
        return True

    def predecessors(identity):
        j = indices[identity]
        result = [(int(i), float(w)) for i, w in zip(
            incoming.indices[incoming.indptr[j]:incoming.indptr[j+1]],
            incoming.data[incoming.indptr[j]:incoming.indptr[j+1]]) if w > 0]
        return sorted(result, key=lambda row: (-final[row[0]] * row[1], ids[row[0]]))

    targets = list(dict.fromkeys(identity for c in candidates[:5]
        for identity in c.get("presentation_target_ids", c.get("endpoint_ids") or c.get("source_contributor_ids") or [])))
    for identity in targets:
        if identity not in indices or earliest[indices[identity]] > horizon or not admit(identity):
            raise ValueError("Selected real result targets do not fit or have no finite native walk")
    # Protect a visible direct match for every A/Q input, not just the strongest global input.
    for starter in flow.get("starters", []):
        for target in sorted(starter.get("targets", []), key=lambda t: (-t["mass"], t["id"])):
            if target["mass"] > 0 and target["id"] in indices and admit(target["id"]):
                break
    # Preserve existing numerical witness states, including native readout-only audit routes.
    for c in candidates:
        cf = flow.get("candidate_flows", {}).get(c["id"], {})
        for identity in cf.get("endpoint_ids") or cf.get("source_contributor_ids") or []:
            if not admit(identity):
                raise ValueError("Native audit readout does not fit the drawing budget")
        for route in cf.get("represented_routes", []):
            if route.get("route_kind") != "LEXICAL_SOURCE_READOUT":
                for node in route.get("nodes", []):
                    admit(node["id"])
    # A shortest positive-prior corridor protects connectivity before a large community fan-in.
    for identity in targets:
        at = identity
        while earliest[indices[at]] > 0:
            before = [(i, w) for i, w in predecessors(at) if earliest[i] + 1 == earliest[indices[at]]]
            found = next((ids[i] for i, _ in before if admit(ids[i])), None)
            if found is None:
                break
            at = found
    right, queue = {n: 0 for n in targets}, deque(targets)
    bfs_order, rejected = [], 0
    while queue:
        level = [queue.popleft() for _ in range(len(queue))]
        rows = [iter(predecessors(n)) for n in level]
        active = list(range(len(rows)))
        while active:
            following = []
            for k in active:
                row = next(rows[k], None)
                if row is None:
                    continue
                following.append(k); i, _ = row; identity = ids[i]; depth = right[level[k]] + 1
                if identity in right or earliest[i] + depth > horizon:
                    continue
                if admit(identity):
                    right[identity] = depth; queue.append(identity); bfs_order.append(identity)
                else:
                    rejected += 1
            active = following
            if len(selected) >= capacity:
                break
        if len(selected) >= capacity:
            break
    # Additional query matches use leftover capacity; no unrelated highest-mass filler.
    for starter in flow.get("starters", []):
        for target in sorted(starter.get("targets", []), key=lambda t: (-t["mass"], t["id"])):
            if target["mass"] > 0 and target["id"] in indices:
                admit(target["id"])
    numerical_ids = [n for n in order if n in indices]
    raw = [dict(nodes[n], final_mass=float(final[indices[n]])) for n in numerical_ids]
    edges, proof_omissions = [], 0
    raw_map = {n["id"]: n for n in raw}
    old_edges = {(e["source"], e["target"]) for e in expanded.get("edges", [])}
    for source in numerical_ids:
        i = indices[source]
        for j, transition in zip(matrix.indices[matrix.indptr[i]:matrix.indptr[i+1]], matrix.data[matrix.indptr[i]:matrix.indptr[i+1]]):
            target = ids[j]
            if target not in raw_map or transition <= 0 or earliest[i] + 1 > horizon:
                continue
            kind = _kind(source, target, raw_map)
            edge = dict(source=source, target=target, transition=float(transition), kind=kind,
                numerical_transition=True, recovered_from_native_kernel=(source, target) not in old_edges)
            if kind == "SOURCE":
                try:
                    edge["citations"] = [source_proof(source, target)]
                except ValueError:
                    proof_omissions += 1
                    continue
            edges.append(edge)
    source_indices = np.array([indices[e["source"]] for e in edges], dtype=int)
    transitions = np.array([e["transition"] for e in edges])
    projected = [indices[n] for n in numerical_ids]
    transpose, values, frames = matrix.T.tocsr(), prior.copy(), []
    category_reference = CategoryReference(matrix, prior, ids)
    balances = {c["id"]: dict(target_ids=c.get("presentation_target_ids", []), endpoint_ids=c.get("presentation_target_ids", []),
        binding="source_identity_context" if c.get("source_identity_representative") else
            "source_semantic_representative" if c.get("source_semantic_representative") else c.get("binding"), incoming_frames=[]) for c in candidates}
    for t in range(horizon + 1):
        before = values
        if t:
            values = (1-alpha) * prior + alpha * (transpose @ before)
        weights = values[projected]
        transported = alpha * before[source_indices] * transitions if t else np.zeros(len(edges))
        frames.append(dict(iteration=t, weights=weights.tolist(), total_mass=float(values.sum()),
            other_mass=max(0., float(values.sum()-weights.sum())), restart_mass=float((1-alpha)*prior.sum()) if t else 0.,
            flows=[dict(source=e["source"], target=e["target"], mass=float(m)) for e, m in zip(edges, transported) if m > 0],
            category_reference=category_reference.frame(values)))
        for c in candidates:
            balance = balances[c["id"]]; ends = [indices[n] for n in balance["target_ids"]]
            if not ends:
                continue
            incoming_mass = float(alpha * (transpose[ends] @ before).sum()) if t else 0.
            restart = float((1-alpha)*prior[ends].sum()) if t else float(prior[ends].sum())
            parts = [dict(source=e["source"], target=e["target"], kind=e["kind"], mass=float(m))
                for e, m in zip(edges, transported) if e["target"] in balance["target_ids"]]
            mass, shown = float(values[ends].sum()), math.fsum(p["mass"] for p in parts)
            if not math.isclose(mass, restart+incoming_mass, rel_tol=1e-10, abs_tol=1e-14):
                raise ValueError("Observed native balance does not close")
            balance["incoming_frames"].append(dict(iteration=t, endpoint_mass=mass, restart_mass=restart,
                incoming_mass=incoming_mass, shown_incoming_mass=shown,
                remainder_incoming_mass=max(0., incoming_mass-shown), contributions=parts))
        for old in expanded["frames"][t:t+1]:
            expected = [values[indices[n["id"]]] for n in expanded["nodes"]]
            if not np.allclose(old["weights"], expected, rtol=1e-11, atol=1e-13):
                raise ValueError("Original drawing history differs from native replay")
    if not np.array_equal(values, final):
        if not np.allclose(values, final, rtol=1e-13, atol=1e-15):
            raise ValueError("Observer does not reproduce native final")
    drawing = dict(nodes=raw, edges=edges, frames=frames, walk_snapshot=snap)
    return drawing, balances, dict(version=VERSION, target_ids=targets, reverse_bfs_order=bfs_order,
        selected_node_ids=order, rejected_capacity_count=rejected, source_edge_proof_omissions=proof_omissions,
        recovered_node_ids=[n for n in numerical_ids if n not in old_nodes],
        native_snapshot_sha256=snap["sha256"], inference_changed=False,
        scope="Bounded reverse BFS from all five real result targets, protected A/Q matches, true ancestors and saved native paths; not the full kernel.")


def _routes(value, candidate, snapshot, selector=None):
    if selector is None:
        try:
            selector = importlib.import_module(".guide_route_selection_v65", __package__).candidate_routes
        except ModuleNotFoundError as error:
            if error.name != __package__ + ".guide_route_selection_v65":
                raise
            candidate["route_selection_status"] = "V65_ROUTE_HELPER_NOT_AVAILABLE"
            return
    target = deepcopy(candidate)
    target.update(endpoint_ids=list(candidate["presentation_target_ids"]), source_contributor_ids=[])
    result = selector(value, target, snapshot, route_count=3)
    if not isinstance(result, list):
        raise ValueError("V6.5 candidate_routes must return a detached route list")
    pairs = {(e["source"], e["target"]) for e in value["edges"]}
    for route in result:
        if candidate.get("source_identity_representative"):
            route["target_role"] = "SOURCE_IDENTITY_CONTEXT_NOT_NATIVE_ANSWER_ENDPOINT"
            route["meaning"] = route.get("meaning", "") + " This numerical route ends at existing named-actor identity context. The original quote-to-identity handoff is not an edge or transported contribution, and the other-page identity proof is not native inspected construction evidence or proof of the queried action."
        for edge in route.get("hops", []):
            if edge.get("numerical_transition") is not False and (edge["source"], edge["target"]) not in pairs:
                raise ValueError("Route selector introduced a missing drawing edge")
    candidate.update(represented_routes=deepcopy(result), routes=deepcopy(result), influence_corridors=[],
        route_selection_status="BOUNDED_PROJECTION_ROUTES")
    if "native_route_diversity" not in candidate:
        candidate["native_route_diversity"] = deepcopy(candidate.get("diversity"))
    pairs = [set((e["source"], e["target"]) for e in route.get("hops", []) if e.get("numerical_transition") is not False) for route in result]
    candidate["diversity"] = dict(selected_count=len(result), requested_count=3,
        selection_basis="V65_BOUNDED_PROJECTION", independent_explanations=False,
        unavailable_reason=None if len(result)==3 else "FEWER_DISTINCT_ELIGIBLE_WALKS_FOUND_IN_BOUNDED_PROJECTION",
        pairwise_overlap=[dict(left=i, right=j, shared_edge_count=len(pairs[i] & pairs[j]), independent_explanations=False)
            for i in range(len(result)) for j in range(i+1,len(result))])
    if not candidate["presentation_target_ids"]:
        candidate["selected_walk_metrics"] = accounting.unknown_metrics("NO_NUMERICAL_SOURCE_REPRESENTATIVE")
        return
    matrix, prior, final, indices = accounting.read_snapshot(snapshot)
    paths = [[indices[n["id"]] for n in route["nodes"]] for route in result if route["route_kind"] != "LEXICAL_SOURCE_READOUT"]
    denominator = float(final[[indices[n] for n in candidate["presentation_target_ids"]]].sum())
    candidate["selected_walk_metrics"] = accounting.selected_walk_mass(paths, matrix, prior,
        iterations=snapshot["iterations"], alpha=snapshot["alpha"], endpoint_mass=denominator)


def presentation(root, report, case_id, arm, *, reading=None, limit=1024, route_selector=None):
    # Coalesce identical cold requests, rather than replaying the same kernel concurrently.
    request = (str(Path(root).resolve()), digest(report), case_id, arm, reading, limit, id(route_selector))
    with _LOCK:
        entry = _REQUEST_LOCKS.setdefault(request, [RLock(), 0])
        entry[1] += 1
    try:
        with entry[0]:
            return _presentation(root, report, case_id, arm, reading=reading, limit=limit, route_selector=route_selector)
    finally:
        with _LOCK:
            entry[1] -= 1
            if not entry[1]:
                _REQUEST_LOCKS.pop(request, None)


def _presentation(root, report, case_id, arm, *, reading=None, limit=1024, route_selector=None):
    root = Path(root).resolve()
    original = native.presentation(root, report, case_id, arm, reading=reading, limit=limit)
    selected = native.condition(root, report, case_id, arm)
    if selected.get("status") == "PENDING":
        return original
    record = next(iter(selected["configurations"].values())); result, case = record["result"], selected["case"]
    flow = result.get("flow", {})
    if flow.get("status") != "RECORDED":
        return with_solver_stopping(original, result)
    key = (str(root), original["source_case_sha256"], original["source_expanded_sha256"],
        digest(report["graph_indexes"][case["corpus"]]), arm, reading, limit)
    with _LOCK:
        if route_selector is None and key in _CACHE:
            return deepcopy(_CACHE[key])
    path, stamp = native._bound_path(root, flow["expanded_ref"], "web/data/flows-v6")
    expanded = native._read(str(path), stamp, flow["expanded_ref"]["sha256"])
    numerical = accounting.read_snapshot(expanded["walk_snapshot"])
    matrix, prior, final, indices = numerical
    earliest = _earliest(matrix, prior, flow["iterations"])
    candidates = native.targets(result, reading)
    db = _connection(root, report["graph_indexes"][case["corpus"]])
    try:
        scoped_page_view(db, flow.get("handling_veto_documents", []))
        parents, assignments = native.hierarchy_catalog(db), {}
        group_ids = {(n.split(":", 2)[1], n.split(":", 2)[2]): n for n in indices if n.startswith("hierarchy:")}
        old = {n["id"]: n for n in expanded["nodes"]}
        source_labels = {}
        for candidate in candidates:
            cf = flow["candidate_flows"].get(candidate["id"], {})
            candidate["native_readout"] = {k: deepcopy(cf.get(k)) for k in ("binding", "endpoint_ids", "source_contributor_ids", "endpoint_mass", "selected_walk_metrics")}
            candidate["presentation_target_ids"] = list(cf.get("endpoint_ids") or cf.get("source_contributor_ids") or [])
            if not cf.get("endpoint_ids") and not candidate.get("atom_id"):
                rep = source_identity_representative(db, candidate, case, indices, earliest, flow["iterations"])
                if rep["node_ids"]:
                    rep["kernel_state_final_mass"] = float(final[indices[rep["node_ids"][0]]])
                    candidate["source_identity_representative"] = rep
                else:
                    candidate["source_identity_lookup"] = rep
                    if rep.get("eligible_matching_identity_count", 0) <= 1:
                        rep = source_representative(db, candidate, case, indices, earliest, flow["iterations"])
                    candidate["source_semantic_representative"] = rep
                candidate["presentation_target_ids"] = rep["node_ids"]
                for identity in rep["node_ids"]:
                    source_labels[identity] = rep["label"]

        def metadata(identity):
            if identity.startswith("layout:"):
                return dict(id=identity, type=identity.split(":", 2)[1], label=identity.split(":", 2)[1].capitalize()+" group / layout only")
            value = previous._metadata(db, identity, case)
            if value and identity in source_labels:
                value["label"] = source_labels[identity]
            elif value and identity in old and identity.startswith("hierarchy:"):
                value["label"] = old[identity]["label"]
            return value

        def parent(identity):
            if identity.startswith(("hierarchy:", "layout:")):
                key = tuple(identity.split(":", 2)[1:]); above = parents.get(key)
                return group_ids.get(above, "layout:" + ":".join(above)) if above else None
            if identity not in assignments:
                row = db.execute("SELECT hierarchy FROM node WHERE id=?", (identity,)).fetchone()
                assignments[identity] = json.loads(row[0]) if row else {}
            community = assignments[identity].get("community_id")
            return group_ids.get(("community", community), "layout:community:"+community) if community else None

        source_proofs = {}
        def proof(source, target):
            pair = tuple(sorted((source, target)))
            if pair not in source_proofs:
                source_proofs[pair] = previous._proof(db, source, target, case)
            return deepcopy(source_proofs[pair])

        drawing, balances, selection = recover_union_drawing(flow, expanded, candidates, metadata, parent,
            proof, limit=limit, numerical=numerical, earliest=earliest)
        semantic = [n["id"] for n in drawing["nodes"] if n["type"].lower() not in native.LEVELS]
        for identity in semantic:
            parent(identity)
        value = native.project(flow, drawing, assignments, parents, candidates, limit=limit)
        if len(value["frames"]) != len(drawing["frames"]):
            raise ValueError("Category reference frame inventory differs from the saved replay")
        for frame, full in zip(value["frames"], drawing["frames"]):
            if frame["iteration"] != full["iteration"]:
                raise ValueError("Category reference iteration differs from the saved replay")
            frame["category_reference"] = deepcopy(full["category_reference"])
        native.certify_readout_receipts(value, record)
        native.attach_documents(db, value, case, result)
        native.attach_route_sources(db, value, case)
        native.attach_readouts(db, value, case)
        native.decorate(value, case["task"])
        for field in ("case_id", "config", "reading_id", "scope", "source_case_sha256", "source_expanded_sha256"):
            value[field] = deepcopy(original[field])
        value["native_snapshot_sha256"] = expanded["walk_snapshot"]["sha256"]
        value["handling_veto_documents"] = deepcopy(flow.get("handling_veto_documents", []))
        for candidate in value["candidates"]:
            candidate["native_represented_routes"] = deepcopy(candidate.get("represented_routes", []))
            if candidate.get("source_identity_representative") or candidate.get("source_semantic_representative"):
                candidate.update(represented_routes=[], routes=[], influence_corridors=[],
                    selected_walk_metrics=accounting.unknown_metrics("PRESENTATION_REPRESENTATIVE_IS_NOT_NATIVE_FILL_ENDPOINT"))
            _routes(value, candidate, expanded["walk_snapshot"], route_selector)
            observed = dict(candidate, endpoint_ids=candidate["presentation_target_ids"], source_contributor_ids=[])
            explanation = previous.contributor_cone(value, observed, flow["iterations"])
            explanation.update(balances[candidate["id"]], version=VERSION,
                native_readout_unchanged=True, mass_basis="Existing identity-context states only, not native answer/source-readout mass or factual support" if candidate.get("source_identity_representative") else
                "presentation_target_ids, not constructed fill identity or factual support")
            candidate["contributor_explanation"] = explanation
        value.update(version=VERSION, flow_ui_presentation_version=VERSION, union_drawing=selection,
            overview_limit=256, recovered_drawing=dict(node_ids=selection["recovered_node_ids"],
                edges=[dict(source=e["source"], target=e["target"]) for e in value["edges"] if e["recovered_from_native_kernel"]],
                native_snapshot_sha256=selection["native_snapshot_sha256"], inference_changed=False))
        value = with_solver_stopping(value, result)
        with _LOCK:
            if route_selector is None and all(c.get("route_selection_status") != "V65_ROUTE_HELPER_NOT_AVAILABLE" for c in value["candidates"]):
                _CACHE[key] = deepcopy(value)
                while len(_CACHE) > 3:
                    _CACHE.popitem(last=False)
        return value
    finally:
        db.close()
