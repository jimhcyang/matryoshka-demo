"""Read-only verification of frozen V6 outputs, including explicit case order.

This is a reporting compatibility layer. It never edits native manifests,
checkpoint pins, archives, source bindings, or completion records.
"""
from contextlib import ExitStack
import fcntl
from pathlib import Path

from matryoshka_demo.io import digest, load, sha
from . import study

VERSION = "ordered-selection-native-reporting-gate/6.1"


def _inputs(root, directory):
    if not directory.is_relative_to(root / "data/runs_v6"):
        raise ValueError("Unbound native run directory")
    if not (directory / "run.lock").is_file():
        raise ValueError("Missing native run lock")
    manifest = load(directory / "manifest.json")
    study._public_flags(manifest)
    if manifest["version"] != study.VERSION or directory.name != "demo_v6_"+digest(manifest)[:20]:
        raise ValueError("Frozen native run identity changed")
    study.check_code(root, manifest["code"])
    study._verify_archive(directory, manifest["code"])
    path = study._bound(root, manifest["release_ref"]["path"])
    if sha(path) != manifest["release_ref"]["sha256"]:
        raise ValueError("Native planning release changed")
    _, release = study.load_release(root, path)
    by_id = {case["case_id"]: case for case in release["cases"]}
    ids = [case["case_id"] for case in manifest["cases"]]
    arms = manifest["settings"]["arms"]
    # Selection order belongs to the hashed manifest, not benchmark membership.
    # Each selected question must still exactly equal its released source input.
    if (not ids or len(set(ids)) != len(ids) or set(ids)-set(by_id)
            or manifest["cases"] != [by_id[i] for i in ids]
            or not arms or len(set(arms)) != len(arms) or any(a not in study.ARMS for a in arms)
            or set(manifest["graph_indexes"]) != {c["corpus"] for c in manifest["cases"]}
            or manifest.get("checkpoint_contract") != study.CHECKPOINT_VERSION
            or manifest.get("original_reference_code") != {k: v for k, v in manifest["code"].items()
                if k.startswith(study.ORIGINAL_PREFIX)}):
        raise ValueError("Native release/condition/code membership changed")
    binding = load(root / "data/bindings.json")
    if binding["sha256"] != manifest["source_binding_sha256"]:
        raise ValueError("Native source binding changed")
    study.verify_sources(root.parent, binding, set(manifest["graph_indexes"]))
    if study._handling(root, binding, manifest["graph_indexes"]) != manifest["handling_veto_documents"]:
        raise ValueError("Native handling policy changed")
    for corpus, ref in manifest["graph_indexes"].items():
        study._graph_reference(root, ref, binding["corpora"][corpus])
    return manifest, release, binding


def committed_case(root, directory, case_id):
    """Observe only complete atomic checkpoint pins, not an unsealed run.

    A writer holds the whole-run lock, but never edits a committed condition.
    Double-reading each pin and the manifest detects a concurrent replacement.
    This cannot certify the unfinished run or authorize publication of it.
    """
    root, directory = Path(root).resolve(), Path(directory).resolve()
    manifest, release, binding = _inputs(root, directory)
    matches = [c for c in manifest["cases"] if c["case_id"] == case_id]
    if len(matches) != 1:
        raise ValueError("Unknown committed question")
    case = matches[0]
    plans = study._plans(root, release, [case])
    records = {}
    with ExitStack() as stack:
        replay = study._SourceReplay(root, manifest, binding, stack)
        for arm in manifest["settings"]["arms"]:
            target = directory / "cases" / (case_id+"__"+arm+".json.gz")
            pin = directory / "checkpoint_pins" / (case_id+"__"+arm+".json")
            before = sha(pin)
            record = study._read_checkpoint(directory, target, manifest)
            study._verify_record(root, directory, record, case, arm, manifest, plans, replay)
            if sha(pin) != before:
                raise ValueError("Checkpoint pin changed during read-only assessment audit")
            records[arm] = record
    if load(directory / "manifest.json") != manifest:
        raise ValueError("Native manifest changed during checkpoint audit")
    return case, records, manifest


def verified_run(root, directory=None):
    root = Path(root).resolve()
    pointer = load(root / "data/latest_run_v6.json") if directory is None else None
    directory = Path(directory).resolve() if directory is not None else study._bound(root, pointer["path"])
    if not directory.is_relative_to(root / "data/runs_v6"):
        raise ValueError("Unbound native run directory")
    with (directory / "run.lock").open("r") as lock, ExitStack() as stack:
        fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        manifest, release, binding = _inputs(root, directory)
        if pointer is not None and (sha(directory / "manifest.json") != pointer["manifest_sha256"]
                or sha(directory / "checkpoint_manifest.json") != pointer["checkpoint_manifest_sha256"]):
            raise ValueError("Native run pointer changed")
        expected = len(manifest["cases"])*len(manifest["settings"]["arms"])
        progress = load(directory / "progress.json")
        if (progress.get("run_id") != directory.name or progress["status"] != "COMPLETE"
                or progress["completed"] != expected or progress["expected"] != expected or progress["failures"]):
            raise ValueError("Native conditions are not complete or have active failures")
        study._condition_files(directory, manifest["cases"], manifest["settings"]["arms"], complete=True)
        plans = study._plans(root, release, manifest["cases"])
        replay = study._SourceReplay(root, manifest, binding, stack)
        grouped = {}
        for case in manifest["cases"]:
            records = {}
            for arm in manifest["settings"]["arms"]:
                target = directory / "cases" / (case["case_id"]+"__"+arm+".json.gz")
                record = study._read_checkpoint(directory, target, manifest)
                study._verify_record(root, directory, record, case, arm, manifest, plans, replay)
                records[arm] = record
            grouped[case["case_id"]] = records
        if load(directory / "checkpoint_manifest.json") != study._completion(directory, manifest, grouped):
            raise ValueError("Native completion/checkpoint seal changed")
        study._audit_files(directory, grouped)
        return directory, manifest, grouped, binding
