"""Consistent V65 flow/guide route indices without mutating frozen globals."""
from copy import deepcopy
from types import FunctionType

from . import flow_projection as native


def _presentation(*args, **kwargs):
    from .flow_projection_v65 import presentation
    return presentation(*args, **kwargs)


def _guide_function():
    context = dict(native.guide.__globals__, presentation=_presentation)
    function = FunctionType(native.guide.__code__, context, native.guide.__name__, native.guide.__defaults__)
    function.__kwdefaults__ = deepcopy(native.guide.__kwdefaults__)
    return function


def guide(root, report, case_id, arm, candidate_id, route_index=0, reading=None):
    packet = _guide_function()(root, report, case_id, arm, candidate_id, route_index, reading)
    route = packet["route"]
    lexical = route.get("route_kind") == "LEXICAL_SOURCE_READOUT"
    derived = bool(route.get("derived_witness")) or route.get("route_kind") == "DERIVED_BOUNDED_PROJECTION_WITNESS"
    native_saved = bool(route.get("native_witness")) and not derived and not lexical
    packet["route_provenance"] = dict(
        label="Source readout" if lexical else "Derived projection witness" if derived else "Native-saved witness" if native_saved else "Saved positive walk",
        native_saved=native_saved, derived_witness=derived,
        route_kind=route["route_kind"], route_index=route_index,
        selection=deepcopy(route.get("route_selection")), correctness_probability=False)
    return packet
