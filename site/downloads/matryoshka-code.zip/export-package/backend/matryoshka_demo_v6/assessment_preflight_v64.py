"""Assessment-role input checks; no answer is returned to native inference."""
from pathlib import Path

from matryoshka_demo.io import load, sha


def validate(root, planning):
    root = Path(root).resolve()
    catalog = root / planning["catalog_ref"]["path"]
    path = catalog.parent / "private/evaluation_keys.json"
    if not path.is_relative_to(root) or path.resolve() != path or any(p.is_symlink() for p in path.parents):
        raise ValueError("Assessment key path must remain inside the sealed source release")
    seal = load(catalog.parent / "release_manifest.json")
    if sha(path) != seal["artifacts"]["private/evaluation_keys.json"]:
        raise ValueError("Assessment key bytes differ from the source commitment")
    keys = load(path)
    redactions = [c for c in planning["cases"] if c["task"] == "redaction"]
    if not isinstance(keys, dict) or any(not isinstance(keys.get(c["case_id"]), dict)
            or not isinstance(keys[c["case_id"]].get("answer"), str)
            or not keys[c["case_id"]]["answer"].strip() for c in redactions):
        raise ValueError("Missing sealed redaction reference answer; stop before expensive native execution")
    return dict(role="ASSESSMENT_PREFLIGHT_ONLY", redaction_keys_checked=len(redactions),
        answer_values_returned=False, inference_inputs_changed=False)
