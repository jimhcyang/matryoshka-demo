"""Opt-in structural ranking experiment. Never a native or factual decision.

An unverified/missing/different attachment receives no positive signal. Existing
fit/grammar admission and original order are retained; no score is a probability.
"""
from copy import deepcopy
from datetime import date
import re

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline

VERSION = "source-query-attachment-ranking-prototype/1.3"
BINDING_VERSION = "exact-saved-pool-binding/1"
PRECEDENCE = (
    "complete_attachment_with_explicit_owner",
    "complete_attachment",
    "attachment_with_explicit_owner",
    "attachment_only",
    "neutral_original_order",
)
_NOUNS = {"NOUN", "PROPN", "PRON"}
_IDENTITY_CHILDREN = {"compound", "amod", "poss", "nmod:poss"}
_NEGATIVE = {"no", "not", "neither", "never", "nor"}
_HANDLING_VETO = re.compile(r"\bNOFORN\b|NO\s+FOREIGN\s+DISSEMINATION", re.I)
_ARGUMENTS = {"nsubj": "actor", "nsubjpass": "patient", "nsubj:pass": "patient",
              "dobj": "object", "obj": "object", "iobj": "recipient", "attr": "attribute"}
_CONSTRAINTS = {"prep", "xcomp", "ccomp", "acl", "relcl", "advcl", "appos"}
_QUANTITY_ATTACHMENTS = {"nummod", "quantmod", "predet", "det"}


def _lemma(token):
    return (token.lemma_ or token.text).casefold()


def _proof(token, raw):
    a, b = token.idx, token.idx + len(token)
    return dict(start=a, end=b, text=raw[a:b], lemma=_lemma(token),
                dependency=token.dep_, pos=token.pos_, tag=token.tag_)


def _words(text):
    return tuple(re.findall(r"[^\W_]+(?:['\u2019][^\W_]+)*", text.casefold()))


def _identity(head, raw, excluded=()):
    def kept(token):
        return not any(a <= token.idx < b for a, b in excluded)
    tokens = [head]
    for child in head.children:
        if child.dep_ in _IDENTITY_CHILDREN and child.pos_ in _NOUNS | {"ADJ"}:
            tokens.extend(t for t in child.subtree if t.pos_ in _NOUNS | {"ADJ"} and kept(t))
        if child.dep_ in {"prep", "agent"}:
            tokens.extend(t for t in child.subtree if not t.is_space and not t.is_punct and kept(t))
    quantities = []
    for owner in list({t.i:t for t in tokens if kept(t)}.values()):
        for child in owner.children:
            if (child.dep_ not in _QUANTITY_ATTACHMENTS
                    or child.dep_ == "det" and "Art" in child.morph.get("PronType")):
                continue
            literal = [t for t in child.subtree if not t.is_space and kept(t)]
            if not literal:
                continue
            # Bind the literal constraint to its owner-relative attachment,
            # not to other arguments, and never convert written numerals.
            path, cursor = [], child
            while cursor != head and cursor.head != cursor:
                path.append((cursor.dep_, _lemma(cursor.head)))
                cursor = cursor.head
            if cursor != head:
                continue
            quantities.append((tuple(reversed(path)), tuple(raw[t.idx:t.idx + len(t)].casefold() for t in literal)))
            tokens.extend(literal)
    tokens = sorted({t.i:t for t in tokens if kept(t)}.values(), key=lambda t:t.i)
    definite = any(c.dep_ == "det" and c.lower_ in {"the", "this", "that", "these", "those"}
                   or c.dep_ in {"poss", "nmod:poss"} for c in head.children)
    named = any(t.pos_ == "PROPN" or t.ent_type_ in {"PERSON", "ORG", "GPE", "NORP", "LOC", "FAC"} for t in tokens)
    signature = tuple(w for t in tokens for w in _words(raw[t.idx:t.idx + len(t)]))
    return dict(signature=signature, explicit=bool(signature and (named or definite)),
                tokens=[_proof(t, raw) for t in tokens], literal_phrase_only=True,
                quantity_constraints=tuple(sorted(quantities)), number_or_quantifier_conversion_used=False,
                prepositional_constraints=[(c.dep_, _fingerprint(c)) for c in head.children if c.dep_ in {"prep", "agent"}],
                aliases_or_coreference_used=False)


def _possessors(head, raw):
    return [_identity(c, raw) for c in head.children if c.dep_ in {"poss", "nmod:poss"}]


def _operators(head, raw):
    tokens = [head, *head.children]
    negative = [t for t in tokens if t.dep_ == "neg" or t.lower_ in _NEGATIVE and t.dep_ in {"det", "preconj", "cc", "advmod"}]
    modals = [t for t in tokens if t.tag_ == "MD"]
    adverbs = [t for t in tokens if t.dep_ == "advmod" and t not in negative]
    return dict(negative=sorted(_lemma(t) for t in negative), modals=sorted(_lemma(t) for t in modals),
                adverbs=sorted(_lemma(t) for t in adverbs),
                tokens=[_proof(t, raw) for t in sorted({t.i:t for t in [*negative, *modals, *adverbs]}.values(), key=lambda t:t.i)])


def _fingerprint(head, depth=0):
    if depth > 4:
        return None
    children = []
    for child in head.children:
        if child.dep_ in _CONSTRAINTS | _QUANTITY_ATTACHMENTS | {"pobj", "pcomp", "dobj", "obj", "conj", "cc", "mark", "neg", "aux", "auxpass"}:
            value = _fingerprint(child, depth + 1)
            if value is None:
                return None
            children.append((child.dep_, value))
    qualifiers = sorted((c.dep_, _lemma(c)) for c in head.children if c.dep_ in {"compound", "amod", "det"})
    return _lemma(head), tuple(qualifiers), tuple(sorted(children))


def _complements(head):
    values = []
    for child in head.children:
        if child.dep_ in _CONSTRAINTS:
            value = _fingerprint(child)
            if value is None:
                return None
            values.append((child.dep_, value))
    return tuple(sorted(values))


def _complete(head, bounds):
    a, b = bounds
    required = [t for child in head.children if child.dep_ in _CONSTRAINTS | {"neg", "advmod", "det", "poss"}
                for t in child.subtree if not t.is_space and not t.is_punct]
    return all(a <= t.idx and t.idx + len(t) <= b for t in required)


def _binding(part, form, raw):
    head = part.root
    parent = head.head
    if form == "modifier":
        if head.dep_ in {"amod", "compound"} and parent not in part and parent.pos_ in _NOUNS:
            return dict(kind="modifier", carrier=parent, head=head, scope_anchor=head, projection="DIRECT_SOURCE_ATTACHMENT")
        # A passive/copular property can supply an owner attachment, never a
        # completed active event or a factual capability certificate.
        passive = any(c.dep_ in {"auxpass", "nsubjpass", "nsubj:pass"} for c in head.children)
        copular = head.dep_ in {"acomp", "attr"} and parent.pos_ in {"VERB", "AUX"} and _lemma(parent) == "be"
        governor = parent if copular else head
        owners = [c for c in governor.children if c.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"}]
        if len(owners) == 1 and owners[0] not in part and (passive or copular):
            return dict(kind="modifier", carrier=owners[0], head=head, scope_anchor=governor,
                        projection="PASSIVE_OR_COPULAR_OWNER_ATTACHMENT_ONLY")
        return None
    if form == "possessive":
        if head.dep_ in {"poss", "nmod:poss"} and parent not in part and parent.pos_ in _NOUNS:
            return dict(kind="possessor", carrier=parent, head=head, projection="DIRECT_POSSESSOR_ATTACHMENT")
        return None
    if form not in {"nominal", "quantity", "unknown"}:
        return None
    if head.dep_ in _ARGUMENTS and parent not in part and parent.pos_ in {"VERB", "AUX"}:
        return dict(kind="argument", governor=parent, role=_ARGUMENTS[head.dep_], head=head)
    if head.dep_ == "pobj" and parent.pos_ == "ADP" and parent.head not in part and parent.head.pos_ in {"VERB", "AUX"}:
        return dict(kind="argument", governor=parent.head, role="preposition:" + _lemma(parent), head=head)
    return None


def _scope(binding, raw):
    from matryoshka_demo.vendor import matching
    anchor = binding.get("scope_anchor", binding.get("governor", binding["head"]))
    q = matching.qualifiers(anchor)
    normalized = dict(negated=q["negated"], modality=q["modality"], conditional=q["conditional"],
        question=q["question"], epistemic_absence=q["epistemic_absence"], unresolved=q["unresolved"],
        scope=[dict(relation=s["relation"], predicate=s["predicate"], negated=s["negated"], modality=s["modality"],
                    speakers=[(p.get("head"), tuple(p.get("names", [])), tuple(p.get("terms", []))) for p in s["speakers"]])
               for s in q["scope"]])
    ancestors = []
    # Retain operators on all governing ancestors, not just the inserted head.
    for token in [anchor, *anchor.ancestors]:
        if token.pos_ not in {"VERB", "AUX"}:
            continue
        operators = _operators(token, raw)
        if operators["negative"] or operators["modals"]:
            ancestors.append(dict(predicate=_lemma(token), negative=operators["negative"], modals=operators["modals"]))
    return dict(signature=dict(normalized, governing_operators=ancestors), qualifiers=q,
                anchor=_proof(anchor, raw), resolved=not q["unresolved"])


def make_pool_binding(case, plan, audit, pages):
    """Producer-side seal. Callers must pin this separately from mutable inputs."""
    value = dict(version=BINDING_VERSION, case=public_case(case), plan_sha256=digest(plan),
                 audit_sha256=digest(audit), pages_sha256=digest(pages))
    return dict(value, sha256=digest(value))


def _check_binding(case, plan, audit, pages, binding):
    if not isinstance(binding, dict):
        raise ValueError("EXACT_POOL_BINDING_REQUIRED")
    if binding != make_pool_binding(case, plan, audit, pages):
        raise ValueError("EXACT_CASE_PLAN_AUDIT_SOURCE_BINDING_CHANGED")


class _NativeCounter:
    """The unchanged local assessor, on the complete inherited source scope."""
    def __init__(self, case, pages):
        from matryoshka_demo_v61.candidates import _admission as native
        self.case, self.native = case, native
        self.engine = native._Engine()
        self.bounds = native.old._focal_sentence_bounds(case, self.engine.parse)
        citations = []
        for pid, page in pages.items():
            if (page["id"] != pid or not page["permitted"] or page["document_id"] == case["document_id"]
                    or page["date"] >= case["date"] or digest(page["text"]) != page["source_sha256"]):
                raise ValueError("COUNTER_SOURCE_SCOPE_NOT_BOUND")
            citations.append(dict(canonical_page_id=pid, document_id=page["document_id"], date=page["date"],
                start=0, end=len(page["text"]), text=page["text"], page_sha256=page["source_sha256"]))
        self.source_index = native.old._assessment_sources(case, citations, self.engine)

    def assess(self, candidate, reading):
        value = dict(candidate, v6_reading=reading)
        assessment = self.native._support_assessment(self.case, value, self.engine,
            source_index=self.source_index, bounds=self.bounds)
        return dict(same_scoped_counterevidence=bool(assessment.get("same_scoped_counterevidence")),
                    assessment=assessment, unchanged_native_assessor=True, support_not_upgraded=True)


class Alignment:
    def __init__(self, case, pages, *, parse=None):
        from matryoshka_demo_v6 import task_execution
        from matryoshka_demo_v61.candidates import quoted_nominal_view
        self.case = public_case(case)
        if self.case["task"] != "redaction":
            raise ValueError("REDACTION_ALIGNMENT_ONLY")
        self.pages, self.parse = pages, parse or task_execution._raw_parser()
        self.docs, self.query_parts, self.source_spans = {}, {}, {}
        view = quoted_nominal_view(self.case)
        self.query_template = view["case"]["query"] if view else self.case["query"]
        self.quote_layout = deepcopy(view["proof"]) if view else None

    def part(self, raw, a, b):
        if not (type(a) is int and type(b) is int and 0 <= a < b <= len(raw)):
            return None
        if raw not in self.docs:
            lower = raw.lower()
            analysis = lower if raw.isupper() and len(lower) == len(raw) else raw
            self.docs[raw] = self.parse(analysis)
        return self.docs[raw].char_span(a, b, alignment_mode="strict")

    def source(self, candidate):
        sources = candidate.get("sources", [])
        if not sources:
            raise ValueError("NO_PRIMARY_SOURCE")
        citation = sources[0]
        page = self.pages[citation["canonical_page_id"]]
        c = self.case
        if (page["id"] != citation["canonical_page_id"] or page["permitted"] is not True
                or page["corpus"] != c["corpus"] or page["date"] >= c["date"]
                or page["document_id"] == c["document_id"] or page.get("visibility") not in {None, "both", "earlier"}
                or c["corpus"] != "cib" and (page.get("classification") != "CONFIDENTIAL" or "NOFORN" in page.get("handling", []))):
            raise ValueError("INELIGIBLE_SOURCE")
        text = page["text"]
        if _HANDLING_VETO.search(text) or any(_HANDLING_VETO.search(str(h)) for h in page.get("handling", [])):
            raise ValueError("PAGE_LEVEL_HANDLING_VETO")
        if date.fromisoformat(page["date"]).isoformat() != page["date"]:
            raise ValueError("INVALID_SOURCE_DATE")
        if digest(text) != page["source_sha256"] or citation["page_sha256"] != page["source_sha256"]:
            raise ValueError("SOURCE_HASH_MISMATCH")
        a, b = candidate["source_span"]
        start, end = citation["start"], citation["end"]
        if (not all(type(x) is int for x in (a,b,start,end)) or not 0 <= start <= a < b <= end <= len(text)
                or text[start:end] != citation["text"] or text[a:b] != candidate["source_wording"]
                or citation["document_id"] != page["document_id"] or citation["date"] != page["date"]):
            raise ValueError("SOURCE_SPAN_MISMATCH")
        x, y = candidate.get("fitted_source_span") or [a,b]
        if not a <= x < y <= b:
            raise ValueError("FITTED_SPAN_ESCAPES_SOURCE")
        part = self.part(text, x, y)
        if part is None:
            raise ValueError("UNALIGNED_SOURCE_TOKENS")
        return page, part, (a,b)

    def replay_fill(self, reading, candidate, page):
        from matryoshka_demo_v61 import candidates as current
        from matryoshka_demo.fill_wording_v23 import modifier_wording
        from . import reporting_source_constituent_prototype as source_constructor
        pid = page["id"]
        if pid not in self.source_spans:
            doc, rows = source_constructor.proposal_spans(page["text"], self.parse)
            by_span = {}
            for row in rows:
                by_span.setdefault((row["start"], row["end"]), []).append(row)
            self.source_spans[pid] = doc, by_span
        doc, rows = self.source_spans[pid]
        a, b = candidate["source_span"]
        for row in rows.get((a,b), []):
            value = row["edited"]
            part = doc.char_span(a,b,alignment_mode="strict")
            if reading["form"] == "modifier":
                value, _ = modifier_wording(value, part)
            fitted = current.boundary_fit(self.case, value)
            if not fitted["admissible"]:
                continue
            aligned = current.native_candidates.source_alignment(page, doc, [a,b], row["text"],
                current.native_candidates._raw_subspan(row["text"], fitted["fill"], a))
            if not aligned["admissible"]:
                continue
            if candidate.get("fitted_source_span") and candidate["fitted_source_span"] != aligned["fitted_source_span"]:
                continue
            if candidate.get("v6_boundary_fit") and candidate["v6_boundary_fit"] != fitted:
                continue
            fill = fitted["fill"]
            if reading["form"] == "possessive":
                fill = fill.rstrip(" ,.")
                if not fill.endswith(("'s", "\u2019s")):
                    fill += "'s"
                if re.match(r"['\u2019]s\b", self.case["query"].split(self.case["focal_marker"])[1], re.I):
                    fill = fill[:-2]
            if reading["form"] in {"possessive", "member_example"}:
                fill = re.sub(r"^(?:both|neither|either)\s+", "", fill, flags=re.I)
            if reading["form"] == "member_example":
                fill = "like " + fill
            if fill == candidate["fill"]:
                return dict(replayed=True, policy="UNCHANGED_SOURCE_ENUMERATION_WORDING_BOUNDARY_AND_FUNCTION_WORD_RULES",
                            source_span=[a,b], query_sha256=digest(self.case["query"]),
                            fill_sha256=digest(fill), reading_sha256=digest(reading))
        raise ValueError("CANDIDATE_FILL_OR_EDIT_PROOF_DOES_NOT_REPLAY")

    def evaluate(self, reading, candidate):
        value = dict(version=VERSION, relation_agreement=False, complete_source_structure=False,
            explicit_owner_agreement=False, priority=PRECEDENCE[-1], neutral=True,
            factual_support_certified=False, absence_is_counterevidence=False,
            query_sha256=digest(self.case["query"]), source_words_modified=False,
            full_document_or_sibling_policy_replayed=False)
        try:
            page, source_part, original_bounds = self.source(candidate)
            fill_replay = self.replay_fill(reading, candidate, page)
            value["fill_derivation"] = fill_replay
            source_binding = _binding(source_part, reading["form"], page["text"])
            if source_binding is None:
                return dict(value, reason="NO_SOURCE_ATTACHMENT_FOR_THIS_READING")
            fill = candidate["fill"]
            if not fill.strip() or MASK.search(fill):
                return dict(value, reason="NO_COMPLETE_INSERTION")
            left, right = self.query_template.split(self.case["focal_marker"])
            completed = left + fill + right
            raw_left, raw_right = self.case["query"].split(self.case["focal_marker"])
            raw_query = raw_left + fill + raw_right
            part = self.part(completed, len(left), len(left) + len(fill))
            if part is None:
                return dict(value, reason="UNALIGNED_INSERTION_TOKENS")
            query_binding = _binding(part, reading["form"], raw_query)
            value.update(source_id=page["id"], source_span=list(original_bounds),
                fitted_source_span=[source_part.start_char, source_part.end_char],
                source_head=_proof(source_part.root, page["text"]), query_head=_proof(part.root, raw_query),
                completed_query_sha256=digest(raw_query), paired_query_quote_layout=self.quote_layout,
                source_operators=_operators(source_part.root, page["text"]), query_operators=_operators(part.root, raw_query))
            if query_binding is None or source_binding["kind"] != query_binding["kind"]:
                return dict(value, reason="NO_SAME_TYPED_ATTACHMENT")
            s, q = source_binding, query_binding
            source_scope, query_scope = _scope(s, page["text"]), _scope(q, raw_query)
            value.update(source_scope=source_scope, query_scope=query_scope)
            if (not source_scope["resolved"] or not query_scope["resolved"]
                    or source_scope["signature"] != query_scope["signature"]):
                return dict(value, reason="GOVERNING_OR_ANCESTOR_SCOPE_NOT_ALIGNED_NEUTRAL")
            if value["source_operators"]["negative"] != value["query_operators"]["negative"]:
                return dict(value, reason="LOCAL_NEGATION_NOT_ALIGNED_NEUTRAL")
            if s["kind"] == "argument":
                sg, qg = s["governor"], q["governor"]
                value.update(source_parent=_proof(sg, page["text"]), query_parent=_proof(qg, raw_query),
                             source_argument_role=s["role"], query_argument_role=q["role"])
                if _lemma(sg) != _lemma(qg) or s["role"] != q["role"]:
                    return dict(value, reason="PREDICATE_OR_ARGUMENT_ROLE_NOT_ALIGNED_NEUTRAL")
                so, qo = _operators(sg, page["text"]), _operators(qg, raw_query)
                value.update(source_parent_operators=so, query_parent_operators=qo)
                if so["negative"] != qo["negative"] or so["modals"] != qo["modals"]:
                    return dict(value, reason="PARENT_OPERATOR_SCOPE_NOT_ALIGNED_NEUTRAL")
                actors = []
                for binding, raw in ((s, page["text"]), (q, raw_query)):
                    owners = [t for t in binding["governor"].children if t.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"}]
                    actors.append(_identity(owners[0], raw) if len(owners) == 1 else None)
                source_owner, query_owner = actors
                if (source_owner and query_owner
                        and source_owner["quantity_constraints"] != query_owner["quantity_constraints"]):
                    return dict(value, reason="OWNER_QUANTITY_CONSTRAINT_NOT_ALIGNED_NEUTRAL",
                                source_owner=source_owner, query_owner=query_owner)
                if source_owner and query_owner and source_owner["explicit"] and query_owner["explicit"]:
                    if source_owner["signature"] != query_owner["signature"]:
                        return dict(value, reason="DIFFERENT_EXPLICIT_ACTOR_NEUTRAL", source_owner=source_owner, query_owner=query_owner)
                    value["explicit_owner_agreement"] = True
                value.update(source_owner=source_owner, query_owner=query_owner)
            else:
                sc, qc = s["carrier"], q["carrier"]
                value.update(source_carrier=_proof(sc, page["text"]), query_carrier=_proof(qc, raw_query),
                             source_projection=s["projection"], query_projection=q["projection"])
                if _lemma(sc) != _lemma(qc):
                    return dict(value, reason="CARRIER_LEMMA_NOT_ALIGNED_NEUTRAL")
                source_before, query_before = s["head"].idx < sc.idx, q["head"].idx < qc.idx
                value.update(source_modifier_before_carrier=source_before, query_modifier_before_carrier=query_before)
                if (s["kind"] == "modifier" and s["projection"] == q["projection"] == "DIRECT_SOURCE_ATTACHMENT"
                        and source_before != query_before):
                    return dict(value, reason="DIRECT_ATTACHMENT_DIRECTION_NOT_ALIGNED_NEUTRAL")
                sp, qp = _possessors(sc, page["text"]), _possessors(qc, raw_query)
                value.update(source_possessors=sp, query_possessors=qp)
                if sp and qp and [p["signature"] for p in sp] != [p["signature"] for p in qp]:
                    return dict(value, reason="DIFFERENT_EXPLICIT_POSSESSOR_NEUTRAL")
                si = _identity(sc, page["text"], [original_bounds])
                qi = _identity(qc, raw_query, [(part.start_char, part.end_char)])
                value.update(source_owner=si, query_owner=qi)
                if si["quantity_constraints"] != qi["quantity_constraints"]:
                    return dict(value, reason="OWNER_QUANTITY_CONSTRAINT_NOT_ALIGNED_NEUTRAL")
                if si["prepositional_constraints"] != qi["prepositional_constraints"]:
                    return dict(value, reason="OWNER_PREPOSITIONAL_CONSTRAINT_NOT_ALIGNED_NEUTRAL")
                same_possessor = bool(sp and qp and all(p["explicit"] for p in [*sp, *qp])
                                      and [p["signature"] for p in sp] == [p["signature"] for p in qp])
                value["explicit_owner_agreement"] = bool(same_possessor or
                    si["explicit"] and qi["explicit"] and si["signature"] == qi["signature"])
            value["relation_agreement"] = True
            source_complements, query_complements = _complements(s["head"]), _complements(q["head"])
            value.update(source_complement_structure=source_complements, query_complement_structure=query_complements)
            value["complete_source_structure"] = bool(source_complements is not None and source_complements == query_complements
                and _complete(s["head"], original_bounds)
                and value["source_operators"]["modals"] == value["query_operators"]["modals"]
                and value["source_operators"]["adverbs"] == value["query_operators"]["adverbs"])
            complete, owner = value["complete_source_structure"], value["explicit_owner_agreement"]
            tier = 0 if complete and owner else 1 if complete else 2 if owner else 3
            return dict(value, priority=PRECEDENCE[tier], neutral=False,
                        reason="POSITIVE_STRUCTURAL_AGREEMENT_ONLY_NOT_FACTUAL_SUPPORT")
        except (KeyError, ValueError, TypeError, IndexError) as error:
            return dict(value, reason="UNVERIFIED_ATTACHMENT_NEUTRAL", verification_error=str(error))


def rerank(case, plan, audit, pages, *, pool_binding=None, parse=None, top_k=5):
    """Rank the full previously admitted pool; never rehabilitate a rejection."""
    from matryoshka_demo.candidates_v24 import display_selection
    case = public_case(case)
    _check_binding(case, plan, audit, pages, pool_binding)
    if plan["query_sha256"] != digest(case["query"]) or type(top_k) is not int or not 1 <= top_k <= 5:
        raise ValueError("Bound public A plan and one-to-five display budget required")
    if not audit or not audit.get("v21") or not audit.get("task_execution_v6"):
        raise ValueError("FULL_ADMITTED_POOL_AUDIT_REQUIRED_NOT_TOP_FIVE")
    if audit.get("keys_read") is not False or audit.get("grades_read") is not False:
        raise ValueError("PRIVATE_EVALUATION_INPUTS_NOT_ALLOWED")
    scorer = Alignment(case, pages, parse=parse)
    results = []
    with offline():
        counter = _NativeCounter(case, pages)
        for row in audit["readings"]:
            pool, reading = row["proposals"], row["reading"]
            declared = [r for r in plan.get("slot_readings", []) if r["id"] == reading["id"]]
            expected = {k:v for k,v in declared[0].items() if k not in {"explanation", "origin"}} if len(declared) == 1 else None
            if plan.get("slot_readings") and expected != reading:
                raise ValueError("ACTUAL_PLAN_READING_CHANGED")
            ledger, = [r for r in audit["v21"]["readings"] if r["reading_id"] == reading["id"]]
            admitted, = [r for r in audit["task_execution_v6"]["readings"] if r["reading_id"] == reading["id"]]
            features = ledger["all_features"]
            if len(features) != len(pool) or any(f["pool_index"] != i or f["candidate_id"] != pool[i]["id"] for i,f in enumerate(features)):
                raise ValueError("FULL_POOL_FEATURE_BINDING_CHANGED")
            old = admitted["accepted_ranked_pool_indices"]
            if len(old) != len(set(old)) or any(type(i) is not int or not 0 <= i < len(pool) or not features[i]["joint_fit"]["admissible"] for i in old):
                raise ValueError("ADMITTED_POOL_ORDER_CHANGED")
            counters = {r["pool_index"] for r in admitted.get("counterevidence_rejections", [])}
            old = [i for i in old if i not in counters]
            alignments = {i:scorer.evaluate(reading, pool[i]) for i in old}
            original_rank = {i:r for r,i in enumerate(old,1)}
            order = sorted(old, key=lambda i:(PRECEDENCE.index(alignments[i]["priority"]), original_rank[i]))
            selected, suppressed = display_selection(pool, features, order)
            displayed, counter_checks, counter_rejected, errors = [], [], [], []
            for i in selected:
                if len(displayed) == top_k:
                    break
                try:
                    page, _, _ = scorer.source(pool[i])
                    scorer.replay_fill(reading, pool[i], page)
                    checked = counter.assess(pool[i], reading)
                    counter_checks.append(dict(pool_index=i, candidate_id=pool[i]["id"], **checked))
                    if checked["same_scoped_counterevidence"]:
                        counter_rejected.append(i)
                        continue
                    displayed.append(i)
                except (ValueError, KeyError, TypeError, IndexError) as error:
                    errors.append(dict(pool_index=i, candidate_id=pool[i]["id"], error=str(error),
                                       unresolved_not_counter=True))
            results.append(dict(reading=deepcopy(reading), pool_size=len(pool), admitted_pool_size=len(old),
                original_ranked_pool_indices=old, ranked_pool_indices=order,
                all_alignment=[dict(pool_index=i, candidate_id=pool[i]["id"], original_rank=original_rank[i],
                                    rank=r, **alignments[i]) for r,i in enumerate(order,1)],
                top_five=[dict(pool_index=i, candidate_id=pool[i]["id"], fill=pool[i]["fill"], rank=r,
                               original_rank=original_rank[i], source_span=deepcopy(pool[i]["source_span"]),
                               alignment=alignments[i], factual_support_upgraded=False)
                          for r,i in enumerate(displayed,1)], display_suppressions=suppressed,
                counter_checks=counter_checks, newly_checked_counter_rejections=counter_rejected,
                unresolved_display_exclusions=errors, prospective_display_candidates_all_reassessed=True))
    return dict(version=VERSION, prototype_only=True, precedence=list(PRECEDENCE),
        order_meaning="Explicit positive structural tiers, then unchanged original admitted rank; not probabilities or support.",
        query_sha256=digest(case["query"]), readings=results, original_native_audit_unchanged=True,
        eligibility_and_grammar_not_relaxed=True, missing_or_different_is_neutral=True,
        inherited_pool_sha256=digest(audit), source_admission_inherited_from_caller_bound_pool=True,
        pool_binding_sha256=pool_binding["sha256"], exact_case_plan_audit_binding_checked=True,
        counter_assessor="UNCHANGED_V61_LOCAL_FOCAL_ASSESSOR_EVERY_PROSPECTIVE_DISPLAY_UNTIL_FIVE",
        source_check_scope="Selected-page hash/quote/date/origin/handling replay only; whole-document and sibling-policy vetoes are inherited from the caller's pinned admitted pool, not recomputed.",
        full_document_or_sibling_policy_replayed=False, outside_admitted_pool_candidates_added=False,
        model_calls=0, keys_read=False, grades_read=False, new_factual_decision=False,
        promotion_requires_runtime_profile_and_full_matched_regressions=True)
