"""Pure presentation moments over the active eligible native diffusion cohort."""
import numpy as np


VERSION = "active-eligible-category-moments/1"
CATEGORIES = ("semantic", "community", "theme", "domain", "other")


def state_category(identity):
    if not isinstance(identity, str):
        raise ValueError("A native state identity must be a string")
    value = identity.lower()
    if value.startswith("hierarchy:"):
        level = value.split(":", 2)[1]
        return level if level in CATEGORIES[1:4] else "other"
    if value.startswith(("document:", "document_", "doc:", "doc_", "source:", "source_", "page:", "page_", "layout:")):
        return "other"
    return "semantic"


class CategoryReference:
    """No replay or input mutation; retain only the cohort indices/category codes."""
    def __init__(self, matrix, prior, state_ids):
        prior = np.asarray(prior, dtype=float)
        count = len(state_ids)
        if matrix.shape != (count, count) or prior.shape != (count,) or len(set(state_ids)) != count:
            raise ValueError("Category reference dimensions or identities differ")
        if not np.all(np.isfinite(matrix.data)) or np.any(matrix.data < 0) or not np.all(np.isfinite(prior)) or np.any(prior < 0):
            raise ValueError("Category reference requires finite nonnegative native values")
        # Nonnegative sums ignore explicitly stored zero entries without altering the CSR.
        active = (np.asarray(matrix.sum(axis=1)).ravel() > 0) | (np.asarray(matrix.sum(axis=0)).ravel() > 0) | (prior > 0)
        self.indices = np.flatnonzero(active)
        self.codes = np.array([CATEGORIES.index(state_category(state_ids[i])) for i in self.indices], dtype=np.int8)
        self.counts = np.bincount(self.codes, minlength=len(CATEGORIES))
        self.excluded = count - len(self.indices)
        self.state_count = count

    def frame(self, values):
        values = np.asarray(values, dtype=float)
        if values.shape != (self.state_count,) or not np.all(np.isfinite(values)) or np.any(values < 0):
            raise ValueError("Category frame requires finite nonnegative native state values")
        masses = values[self.indices]
        maxima = np.zeros(len(CATEGORIES))
        np.maximum.at(maxima, self.codes, masses)
        # Scaled two-pass population moments avoid overflow and uniform-vector cancellation.
        scaled = np.divide(masses, maxima[self.codes], out=np.zeros_like(masses), where=maxima[self.codes] > 0)
        means = np.divide(np.bincount(self.codes, weights=scaled, minlength=len(CATEGORIES)), self.counts,
                          out=np.zeros(len(CATEGORIES)), where=self.counts > 0)
        deviations = scaled - means[self.codes]
        variances = np.divide(np.bincount(self.codes, weights=deviations * deviations, minlength=len(CATEGORIES)), self.counts,
                              out=np.zeros(len(CATEGORIES)), where=self.counts > 0)
        return dict(version=VERSION, scope="active eligible diffusion states",
                    cohort_rule="native kernel row or column nonzero, or prior positive; fixed across iterations",
                    cohort_count=len(self.indices), excluded_inactive_count=self.excluded,
                    zero_mass_members_included=True, std_definition="population (ddof=0)",
                    semantic_scope="Non-navigation native states; unexpected document/source/page prefixes are other, not semantic. Query input boxes are not native states.",
                    categories={name: dict(count=int(self.counts[i]), mean=float(maxima[i] * means[i]),
                                           std=float(maxima[i] * np.sqrt(variances[i])),
                                           mean_log2=float(np.log2(maxima[i]) + np.log2(means[i])) if maxima[i] > 0 and means[i] > 0 else None)
                                for i, name in enumerate(CATEGORIES)})
