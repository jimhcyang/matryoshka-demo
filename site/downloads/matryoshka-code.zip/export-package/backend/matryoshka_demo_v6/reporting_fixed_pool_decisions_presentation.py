"""Separately versioned role/request observers over the saved inspected pool.

The immutable V6.5 decision is the parent, not rewritten inference. Support is
added only after a raw-source observer proves one complete, scoped public atom.
No keys, grades, saved native support or global identity aggregates are read.
"""
from copy import deepcopy
from pathlib import Path

from matryoshka_demo.io import digest, load, offline, sha
from matryoshka_demo_v61 import scope_matching as scoped
from . import reporting_fixed_pool_decisions_v65 as frozen
from . import reporting_fixed_pool_role_projection as roles
from . import reporting_fixed_pool_request_projection as requests

VERSION = "local-evidence-sufficiency/6.5.7-presentation-role-request"
ENGINE_VERSION = "fixed-inspected-pool-with-raw-role-and-request/2"
parent = frozen.parent


def _read_binding(root, expected):
    path = root / "data/bindings.json"
    byte_sha = sha(path)
    binding = load(path)
    # Native records commit the canonical manifest CONTENT hash, not its
    # pretty-printed JSON bytes. File bytes are a separate read-stability pin.
    if (binding.get("sha256") != expected
            or digest({k:v for k,v in binding.items() if k != "sha256"}) != expected):
        raise ValueError("Presentation role source binding changed")
    if sha(path) != byte_sha:
        raise ValueError("Presentation role binding changed during read")
    return binding, byte_sha


def _local_groups(root, record, case, admitted):
    expected = record.get("source_binding_sha256")
    if expected is None:
        return {}  # No identity proof is invented for unbound fixtures.
    binding, byte_sha = _read_binding(root, expected)
    result = roles.load_local_groups(root, binding["corpora"][case["corpus"]], case, admitted)
    if sha(root / "data/bindings.json") != byte_sha:
        raise ValueError("Presentation role binding changed during read")
    return result


def _supplement(unit, observation):
    result = deepcopy(unit)
    fact = result["requirements"][0]
    fact["presentation_parent_decision"] = deepcopy(fact)
    witnesses = []
    for certificate in observation["certificates"]:
        checks = [parent._check(k, parent.FIELD_LABELS[k], "pass",
            "One raw unqualified past-role apposition and its exact source-local identity binding establish this bounded role only.")
            for k in parent.FIELDS]
        checks.append(parent._check("integral_evidence", "Integral role evidence", "pass",
            "Owner, role and complete organization occur in the same literal apposition; no witness fields are spliced."))
        witnesses.append(dict(direction="Support", citations=[certificate["citation"], certificate["apposition"]],
            checks=checks, adapter=roles.VERSION, certificate=certificate, supplemental_source_evidence=True,
            numerical_transport_claim=False, surrounding_event_established=False,
            derivation_note="Raw role only; no action or current tenure is inferred."))
    fact.update(coverage="Established", direction="Support", checks=deepcopy(witnesses[0]["checks"]),
        evidence=[*fact["evidence"], *witnesses], projection="RAW_ROLE_APPOSITION")
    result.update(status=parent.BACKED, label=parent.LABELS[parent.BACKED], coverage="Established",
        role_projection=deepcopy(observation), derivation="NEW_PRESENTATION_ROLE_OBSERVER_NOT_NATIVE")
    for check in result["checklist"]:
        if check["id"] == "facts":
            check.update(state="pass", detail="The complete bounded role is independently replayed against inspected raw source and source-local identity proofs.")
    result["what_would_suffice"] = ["The historical source role is established; other atoms and world-truth accuracy are not certified by this projection."]
    return result


def _request_supplement(unit, spec, observation):
    """New whole-request requirement, not a renamed infinitival event fact."""
    result = deepcopy(unit)
    wanted = spec["request"]
    checks = [parent._check(k, parent.FIELD_LABELS[k], "pass",
        "One eligible literal witness establishes the complete positive past request, its addressee and unchanged nonfactive goal content.")
        for k in parent.FIELDS]
    checks.append(parent._check("nonfactive_goal", "Requested content is not a completed event", "pass",
        "The infinitive is content of the request; its polarity, arguments and modifiers are retained, but its occurrence is not established."))
    witnesses = []
    for certificate in observation["certificates"]:
        citations = [certificate["citation"]]
        if certificate.get("requester_identity_citation"):
            citations.append(certificate["requester_identity_citation"])
        witnesses.append(dict(direction="Support", citations=citations, checks=deepcopy(checks),
            adapter=requests.VERSION, certificate=deepcopy(certificate), supplemental_source_evidence=True,
            numerical_transport_claim=False, surrounding_event_established=False,
            request_event_established=True, actual_goal_event_established=False,
            derivation_note="The complete request is source-backed; the requested inner action is not asserted to have occurred."))
    assertion = dict(parent_predicate=wanted["parent_frame"]["predicate"],
        requester=deepcopy(wanted["requester"]), addressee=deepcopy(wanted["recipient"]),
        goal=dict(predicate=wanted["goal_frame"]["predicate"], **deepcopy(wanted["goal"]),
            tokens=deepcopy(wanted["goal_tokens"]), negated=wanted["goal_frame"]["qualifiers"]["negated"],
            actual_event_established=False), request_event_only=True)
    # Keep the original f1/organize (or other leaf fact) intact in a distinct
    # comparison container. A new ID/kind/text makes the changed interpretation
    # explicit, rather than falsely relabelling a missing organize event.
    requirement = dict(id="request:" + unit["id"], kind="REQUEST_ASSERTION", predicate=assertion["parent_predicate"],
        text=unit["text"], actors=[wanted["requester"]["text"]], request_assertion=assertion,
        coverage="Established", counterevidence=False, direction="Support", checks=checks, evidence=witnesses,
        context_citations=[], context_comparisons=[], projection=requests.KIND,
        aggregation="Complete request and nonfactive content from one witness; no goal completion or cross-witness field splicing.")
    result.update(requirements=[requirement], presentation_parent_unit=deepcopy(unit),
        request_projection=deepcopy(observation), request_assertion=assertion,
        status=parent.BACKED, label=parent.LABELS[parent.BACKED], coverage="Established",
        derivation="NEW_PRESENTATION_REQUEST_ASSERTION_NOT_NATIVE_OR_GOAL_EVENT")
    for check in result["checklist"]:
        if check["id"] == "facts":
            check.update(state="pass", detail="A complete raw request and its exact nonfactive complement establish the new request assertion, not completion of the goal.")
    result["what_would_suffice"] = ["This source establishes that the request was made. Evidence of the requested action's completion would be a separate requirement and is not supplied by this observer."]
    return result


def _overall(packet, task):
    units = [u for u in packet["decisions"] if u["required"]]
    overall = packet["overall"]
    query_ok = all(c["state"] == "pass" for c in overall["checklist"] if c["id"] == "query_coverage")
    complete = bool(units) and query_ok and all(u["status"] == parent.BACKED for u in units)
    status = parent.BACKED if complete else parent.PARTIAL if any(u["coverage"] in {"Established", "Partial"} for u in units) else parent.CONTEXT
    if any(u["status"] == parent.INCOMPATIBLE and u["counterevidence"] for u in units):
        status = parent.INCOMPATIBLE
    overall.update(status=status, label=parent.LABELS[status],
        coverage="Established" if units and query_ok and all(u["coverage"] == "Established" for u in units)
        else "Partial" if any(u["coverage"] in {"Established", "Partial"} for u in units) else "Missing",
        counterevidence=any(u["counterevidence"] for u in units),
        established_components=[u["id"] for u in units if u["coverage"] == "Established"],
        missing_components=[u["id"] for u in units if u["coverage"] != "Established"])
    for check in overall["checklist"]:
        if check["id"] == "required_units":
            check.update(state="pass" if complete else "missing")
    if complete:
        overall["what_would_suffice"] = ["Every required component has an inspected eligible witness under the separately versioned observer, not frozen native inference."]
    frozen._task_labels(packet, task)


def derive(record, case, eligible_index, *, root=None):
    """Pure replay, with pinned source ledgers read only for local identity gaps.

When source_binding_sha256 is absent, only exact raw full-name appositions
can be projected. A declared but changed/missing binding is an integrity error.
"""
    case = parent._case(case)
    packet = frozen.derive(record, case, eligible_index)
    parent_identity = digest(packet)
    observations, changed, request_observations, request_changed = [], [], [], []
    if case["task"] != "redaction" and packet["pool_replay"]["applied"]:
        with offline():
            index = parent._pages(eligible_index, case)
            admitted = {pid: index[0][pid] for pid in record["inspected_page_ids"]}
            engine = frozen.Engine(admitted)
            groups = None
            for i, unit in enumerate(packet["decisions"]):
                spec = roles.query_spec(case, record["plan"], unit["id"])
                if spec is not None:
                    if groups is None:
                        groups = _local_groups(Path(root) if root else Path(__file__).resolve().parents[1], record, case, admitted)
                    observation = roles.observe(case, record["plan"], unit["id"], admitted, index, engine=engine, local_groups=groups)
                    observations.append(observation)
                    # A certificate cannot erase another requirement, counterexample,
                    # invalid atom binding, provenance failure or insertion grammar.
                    if (observation["status"] == "ROLE_ONLY" and unit["status"] != parent.BACKED
                            and not unit["counterevidence"] and len(unit["requirements"]) == 1
                            and all(c["state"] == "pass" for c in unit["checklist"] if c["id"] != "facts")
                            and not any(f["counterevidence"] for f in unit["requirements"])):
                        target_atom = next(a for a in record["plan"]["atoms"] if a["id"] == unit["id"])
                        targets, issues = scoped._bind(target_atom, case["query"], engine)
                        if (not issues and len(targets) == 1 and targets[0]["kind"] == "PROPERTY"
                                and targets[0]["predicate"].casefold() == spec["role"].casefold()):
                            packet["decisions"][i] = _supplement(unit, observation)
                            changed.append(unit["id"])
                request_spec = requests.query_spec(case, record["plan"], unit["id"], engine=engine)
                if request_spec is not None:
                    observation = requests.observe(case, record["plan"], unit["id"], admitted, index, engine=engine)
                    request_observations.append(observation)
                    if (observation["status"] == "REQUEST_ONLY"
                            and not unit["counterevidence"] and not any(f["counterevidence"] for f in unit["requirements"])
                            and all(c["state"] == "pass" for c in unit["checklist"] if c["id"] != "facts")):
                        packet["decisions"][i] = _request_supplement(unit, request_spec, observation)
                        request_changed.append(unit["id"])
            packet["atoms"] = {u["id"]: u for u in packet["decisions"]}
            if changed or request_changed:
                _overall(packet, case["task"])
    packet.update(version=VERSION, decision_engine=ENGINE_VERSION, field=parent.FIELD,
        observer_field="local_decisions_presentation",
        parent_gate_version=frozen.VERSION, parent_gate_sha256=parent_identity,
        role_observer=dict(version=roles.VERSION, observations=observations, changed_atom_ids=changed,
            raw_source_rechecked=True, native_labels_read=False, inherited_label_as_evidence=False,
            global_aliases_read=False, new_retrieval=False),
        request_observer=dict(version=requests.VERSION, observations=request_observations, changed_atom_ids=request_changed,
            raw_source_rechecked=True, native_labels_read=False, whole_request_atom_required=True,
            prior_leaf_requirements_preserved=True, actual_goal_event_established=False, new_retrieval=False))
    packet["limitations"].append("RAW_ROLE_APPOSITION is a narrow additional reporting observer, not a native repair, external identity lookup, action proof or present-tenure certificate.")
    packet["limitations"].append("REQUEST_WITH_NONFACTIVE_COMPLEMENT establishes only a complete, source-backed request. The new request requirement is not a relabelled infinitive or a certificate that its goal occurred; prior parent requirements remain separately preserved.")
    return packet


def evaluate(root, report, record):
    """Published-query/source-index checks are unchanged; output is additive."""
    from matryoshka_demo.corpus_explorer_v3 import _connection
    root = Path(root)
    case = parent._case(record["case"])
    rows = [r for r in report["cases"] if r["case"]["case_id"] == case["case_id"]]
    if len(rows) != 1 or parent._case(rows[0]["case"]) != case:
        raise ValueError("Presentation fixed-pool case differs from published query")
    reference = report["graph_indexes"][case["corpus"]]
    binding, byte_sha = _read_binding(root, report["source_binding"]["sha256"])
    if (record.get("exploration_index_ref") != reference
            or record.get("source_binding_sha256") != report["source_binding"]["sha256"]
            or binding != report["source_binding"]):
        raise ValueError("Presentation source index or binding changed")
    with offline():
        db = _connection(root, reference)
        try:
            packet = derive(record, case, db, root=root)
        finally:
            db.close()
    packet["binding"].update(source_index_sha256=reference["sha256"], source_binding_sha256=report["source_binding"]["sha256"])
    if sha(root / "data/bindings.json") != byte_sha:
        raise ValueError("Presentation source binding changed during evaluation")
    return packet
