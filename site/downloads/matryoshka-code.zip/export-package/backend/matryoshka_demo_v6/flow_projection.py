"""V6 read-only flow and guide projection over bound publication artifacts."""
from collections import OrderedDict
from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
import re
from threading import RLock

from matryoshka_demo.corpus_explorer_v3 import _connection
from matryoshka_demo.corpus_policy_v5 import scoped_page_view
from matryoshka_demo.flow_projection_v4 import (
    LEVELS, _bound_path, hierarchy_catalog, project as _project, attach_documents, attach_route_sources,
)
from matryoshka_demo.flow_projection_v5 import decorate
from matryoshka_demo.io import digest, load, load_gzip
from . import flow as accounting


VERSION = "source-routes-exact-inspection/6"
ARMS = {"A": "llm_readings", "B": "llm_atoms", "C": "llm_local"}
_PRESENTATIONS = OrderedDict()
_LOCK = RLock()


def clear_cache():
    with _LOCK:
        _PRESENTATIONS.clear()
        _read.cache_clear()


@lru_cache(maxsize=3)
def _read(path, stamp, expected):
    return load_gzip(path) if path.endswith(".gz") else load(path)


def condition(root, report, case_id, arm):
    root = Path(root).resolve()
    arm = ARMS.get(arm, arm)
    if arm not in ARMS.values():
        raise ValueError("Unknown active v6 comparison arm; D is retired")
    row = next((r for r in report["cases"] if r["case"]["case_id"] == case_id), None)
    if row is None:
        raise ValueError("Unknown saved question")
    if row.get("status") == "PENDING":
        return dict(case=deepcopy(row["case"]), status="PENDING", reason=row["reason"],
            configurations={}, selected_arm=arm)
    ref = row["case_detail_ref"]
    path, stamp = _bound_path(root, ref, "web/data/report-v6-cases")
    value = _read(str(path), stamp, ref["sha256"])
    if value["case"] != row["case"] or arm not in value["configurations"]:
        raise ValueError("Question or condition binding changed")
    saved = value["configurations"][arm]
    published = row["configurations"][arm]
    expected_run = published.get("native_run_id")
    if expected_run is not None and saved.get("run_id") != expected_run:
        raise ValueError("Native run differs from exact published condition")
    if saved["native_checkpoint"] != published["native_checkpoint"]:
        raise ValueError("Native checkpoint binding changed")
    _bound_path(root, saved["native_checkpoint"], "data/runs_v6")
    return dict({k: deepcopy(v) for k, v in value.items() if k != "configurations"},
        configurations={arm: deepcopy(saved)}, selected_arm=arm)


def targets(result, reading=None):
    rows = []
    seen = set()
    found_reading = reading is None
    for row in result.get("readings", []):
        rid = row.get("reading_id") or row.get("reading", {}).get("id") or row.get("id")
        if rid == reading:
            found_reading = True
        for i, candidate in enumerate(row.get("candidates", []), 1):
            if candidate["id"] in seen:
                raise ValueError("V6 candidate IDs are not globally unique")
            seen.add(candidate["id"])
            if reading is not None and rid != reading:
                continue
            if reading is None and result["readings"] and row is not result["readings"][0]:
                continue
            value = deepcopy(candidate)
            value.update(reading_id=rid, rank=candidate.get("rank", i),
                support=candidate.get("disposition", {}).get("evidence_label")
                    or candidate.get("support_assessment", {}).get("status") or "Unresolved")
            rows.append(value)
    if not found_reading:
        raise ValueError("Unknown saved slot reading")
    if result.get("readings"):
        return rows
    if reading:
        raise ValueError("A reading was requested for a non-redaction result")
    return [dict(deepcopy(t), rank=i) for i, t in enumerate(result.get("flow_targets", []), 1)]


def _apply_routes(candidate, saved, numerical=None):
    for key in ("binding", "endpoint_ids", "source_contributor_ids", "endpoint_mass", "explained_projection_mass",
                "omitted_projection_mass", "readout_explanation", "identity_source_attested", "factual_support_implied",
                "diversity", "starter_endpoint_shares", "starter_attribution_status", "lexical_routes"):
        if key in saved:
            candidate[key] = deepcopy(saved[key])
    routes = deepcopy(saved.get("represented_routes", []))
    matrix, prior, final, indices = numerical if numerical is not None else (None, None, None, None)
    endpoint_ids = saved.get("endpoint_ids", []) + saved.get("source_contributor_ids", [])
    denominator = float(final[[indices[n] for n in endpoint_ids]].sum()) if numerical is not None else None
    paths = []
    for route in routes:
        if route["route_kind"] == "LEXICAL_SOURCE_READOUT":
            route["walk_metrics"] = accounting.unknown_metrics("LEXICAL_READOUT_NOT_A_KERNEL_WALK")
            if any(h.get("numerical_transition") or "transition" in h for h in route.get("hops", [])):
                raise ValueError("A lexical readout was relabeled as numerical transport")
            continue
        route["source_quotes"] = deepcopy(candidate.get("sources", []))
        route["document_ids"] = sorted({p["document_id"] for p in route["source_quotes"]})
        route["constructed_fill_readout"] = dict(candidate_id=candidate["id"], fill=candidate["fill"],
            solver_state=False, numerical_transition=False, identity_source_attested=saved.get("identity_source_attested", False),
            factual_support_implied=False, source_binding=saved.get("binding"),
            meaning="Source quote to constructed fill is a provenance readout after the numerical endpoint, never an additional kernel edge.")
        if numerical is None:
            route["walk_metrics"] = accounting.unknown_metrics("NATIVE_SNAPSHOT_UNAVAILABLE")
            continue
        path = [indices[n["id"]] for n in route["nodes"]]
        if not path or route["nodes"][-1]["id"] not in endpoint_ids:
            raise ValueError("Saved route is not a complete candidate-endpoint walk")
        transitions = [float(matrix[a, b]) for a, b in zip(path, path[1:])]
        if len(route["hops"]) != len(transitions):
            raise ValueError("Saved route hop count changed")
        for hop, transition, left, right in zip(route["hops"], transitions, route["nodes"], route["nodes"][1:]):
            if (hop["source"] != left["id"] or hop["target"] != right["id"] or transition <= 0
                    or hop.get("transition") != transition):
                raise ValueError("Saved route transition differs from actual native kernel")
        route["_path_indices"] = path
        paths.append(path)
    candidate["represented_routes"] = routes
    candidate["routes"] = [r for r in routes if r.get("native_witness") or r["route_kind"] == "LEXICAL_SOURCE_READOUT"]
    candidate["influence_corridors"] = [r for r in routes if not r.get("native_witness") and r["route_kind"] != "LEXICAL_SOURCE_READOUT"]
    candidate["selected_walk_metrics"] = deepcopy(saved.get("selected_walk_metrics", accounting.unknown_metrics("NO_SAVED_WALKS")))
    if numerical is None:
        candidate["selected_walk_metrics"] = accounting.unknown_metrics("NATIVE_SNAPSHOT_UNAVAILABLE")
        candidate["starter_endpoint_shares"] = []
        candidate["starter_attribution_status"] = "UNKNOWN"
    return paths, denominator


def project(flow, expanded, assignments, parents, candidates, *, limit=1024):
    """Preserve native drawing values; attach routes without synthetic KG edges."""
    if type(limit) is not int or not 32 <= limit <= 1024:
        raise ValueError("Drawing limit must be between 32 and 1024")
    if flow.get("status") == "RECORDED":
        value = _project(flow, expanded, assignments, parents, candidates, limit=limit)
    else:
        value = dict(version=VERSION, status="LEXICAL_ONLY", nodes=[], edges=[], frames=[], starters=[],
            candidates=deepcopy(candidates), documents=[], disclosures=[],
            ranking_changed=False, answer_key_used=False, correctness_probability=False)
    native = expanded.get("walk_snapshot")
    numerical = accounting.read_snapshot(native) if native is not None else None
    if native is not None and flow.get("walk_snapshot_sha256") != native["sha256"]:
        raise ValueError("Flow and expanded native snapshot bindings differ")
    for candidate in value["candidates"]:
        saved = flow.get("candidate_flows", {}).get(candidate["id"], {})
        paths, denominator = _apply_routes(candidate, saved, numerical)
        if numerical is not None:
            matrix, prior, _, _ = numerical
            for route in candidate["represented_routes"]:
                path = route.pop("_path_indices", None)
                if path is not None:
                    metrics = accounting._walk_component(path, matrix, prior, native["iterations"], native["alpha"], denominator)
                    if metrics["component_mass"] <= 0:
                        raise ValueError("Represented numerical route has no positive finite component")
                    if route.get("walk_metrics") != metrics:
                        raise ValueError("Saved path arithmetic differs from exact native replay")
                    route["walk_metrics"] = metrics
            candidate["selected_walk_metrics"] = accounting.selected_walk_mass(paths, matrix, prior,
                iterations=native["iterations"], alpha=native["alpha"], endpoint_mass=denominator)
        drawn = {n["id"] for n in value["nodes"]}
        for route in candidate["represented_routes"]:
            route["node_ids_outside_drawing"] = [n["id"] for n in route["nodes"]
                if n["id"] not in drawn and n.get("solver_state", True)]
    value.update(version=VERSION, walk_definitions=deepcopy(flow.get("walk_definitions", accounting.WALK_DEFINITION)),
        starter_superposition=deepcopy(flow.get("starter_superposition", {})), correctness_probability=False)
    value["disclosures"].extend([
        "A path percentage is one exact complete last-restart walk component divided by actual endpoint final mass; it is usually tiny.",
        "Starter endpoint share sums every native walk from one additive starter prior and is not a selected path percentage.",
        "Shared edges and shared-tail groups are disclosed, not sold as independent explanations.",
        "Lexical document/quote/fill readouts are not numerical transitions, historical KG edges, or answer states."])
    return value


def _verify_quote(db, proof, case):
    found = db.execute("SELECT payload FROM page WHERE id=?", (proof["canonical_page_id"],)).fetchone()
    if found is None:
        raise ValueError("Readout source is outside the scoped source index")
    page = json.loads(found[0])
    if (page["document_id"] != proof["document_id"] or page["date"] != proof["date"]
            or page["date"] >= case["date"] or page["document_id"] == case["document_id"]
            or page.get("permitted") is not True or page.get("corpus", case["corpus"]) != case["corpus"]):
        raise ValueError("Readout source violates exact case scope")
    if case["corpus"] != "cib" and (page.get("classification") != "CONFIDENTIAL"
            or any("NOFORN" in str(h).upper() for h in page.get("handling", []))
            or re.search(r"\bNOFORN\b", page["text"], re.I)):
        raise ValueError("Readout cable handling/classification is not eligible")
    a, b = proof["start"], proof["end"]
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != proof["text"] or digest(page["text"]) != proof["page_sha256"]
            or page["source_sha256"] != proof["page_sha256"]):
        raise ValueError("Readout quotation/hash changed")


def attach_readouts(db, value, case):
    known = {d["id"] for d in value["documents"]}
    for candidate in value["candidates"]:
        for proof in candidate.get("sources", []):
            _verify_quote(db, proof, case)
            if proof["document_id"] not in known:
                known.add(proof["document_id"])
                value["documents"].append(dict(id=proof["document_id"], title=proof["document_id"], date=proof["date"],
                    visible_node_ids=[], eligible_node_count=None, visible_final_member_mass=None,
                    candidate_ids=[candidate["id"]], source=deepcopy(proof), lexical_only=True,
                    meaning="Actual eligible source quote; no entity binding, document visit mass, or historical fact is inferred."))
            else:
                document = next(d for d in value["documents"] if d["id"] == proof["document_id"])
                if candidate["id"] not in document["candidate_ids"]:
                    document["candidate_ids"].append(candidate["id"])
        for route in routes_for(candidate) + candidate.get("lexical_routes", []):
            for proof in route.get("source_quotes", []):
                _verify_quote(db, proof, case)
            for hop in route["hops"]:
                for proof in hop.get("citations", []):
                    _verify_quote(db, proof, case)
                if hop["kind"] == "SOURCE":
                    hop["source_proof_status"] = "ELIGIBLE_CANONICAL_SOURCE_UNIT_ATTACHED" if hop.get("citations") else "NO_ELIGIBLE_SOURCE_UNIT_ATTACHED"
                elif hop["kind"] == "NAVIGATION":
                    hop["source_proof_status"] = "KERNEL_NAVIGATION_NOT_SOURCE_ASSERTION"
                elif hop["kind"] == "SOURCE_AGGREGATE":
                    hop["source_proof_status"] = "KERNEL_SOURCE_AGGREGATE_NOT_GROUP_FACT"
                elif route["route_kind"] == "LEXICAL_SOURCE_READOUT":
                    hop["source_proof_status"] = "READOUT_NOT_A_KERNEL_OR_HISTORICAL_EDGE"
            route["source_quotes_verified"] = bool(route.get("source_quotes"))


def certify_readout_receipts(value, record):
    """An admitted page is not necessarily one parsed under the source budget."""
    inspected = record.get("inspected_page_ids")
    for candidate in value["candidates"]:
        for route in routes_for(candidate) + candidate.get("lexical_routes", []):
            if route["route_kind"] != "LEXICAL_SOURCE_READOUT":
                continue
            receipt = route["source_receipt"]
            receipt["native_admitted_page_flag"] = receipt.get("primary_construction_page")
            receipt["primary_construction_page"] = receipt["canonical_page_id"] in inspected if inspected is not None else None
            receipt["primary_page_certification"] = "EXACT_NATIVE_INSPECTED_PAGE_IDS" if inspected is not None else "UNAVAILABLE"
            if not receipt["matched_searches"]:
                receipt["method"] = ("SAVED_CANDIDATE_SOURCE_CITATION" if inspected is None else
                    "NATIVE_CONSTRUCTION_SOURCE_READOUT" if receipt["primary_construction_page"] else "SAVED_CANDIDATE_DOSSIER_CITATION")
            for node in route["nodes"]:
                if node["type"] == "document_receipt":
                    node["receipt"] = deepcopy(receipt)


def presentation(root, report, case_id, arm, *, reading=None, limit=1024):
    root = Path(root).resolve()
    selected = condition(root, report, case_id, arm)
    case = selected["case"]
    if selected.get("status") == "PENDING":
        return dict(version=VERSION, status="PENDING", reason=selected["reason"], task=case["task"],
            nodes=[], edges=[], frames=[], starters=[], candidates=[], documents=[])
    record = next(iter(selected["configurations"].values()))
    result = record["result"]; flow = result.get("flow", {})
    if flow.get("case_binding_sha256") != digest(case):
        raise ValueError("Saved flow belongs to another public case")
    if any(s.get("kind") == "context" for s in flow.get("starters", [])):
        raise ValueError("A whole-query restart cannot be relabeled atomic-only")
    expanded = {}
    ref = flow.get("expanded_ref")
    if ref is not None:
        path, stamp = _bound_path(root, ref, "web/data/flows-v6")
        expanded = _read(str(path), stamp, ref["sha256"])
    elif flow.get("status") == "RECORDED":
        raise ValueError("Recorded flow lacks its bound expanded artifact")
    reference = report["graph_indexes"][case["corpus"]]
    case_sha = next(r["case_detail_ref"]["sha256"] for r in report["cases"] if r["case"]["case_id"] == case_id)
    excluded = report.get("handling_veto_documents", {}).get(case["corpus"], [])
    if sorted(excluded) != sorted(flow.get("handling_veto_documents", [])):
        raise ValueError("Published source handling veto differs from native flow scope")
    db = _connection(root, reference)
    try:
        key = (VERSION, str(root), case_sha, record["config"], reading, limit,
            ref["sha256"] if ref else None, reference["sha256"], digest(reference["binding"]), digest(excluded))
        with _LOCK:
            if key in _PRESENTATIONS:
                _PRESENTATIONS.move_to_end(key)
                return deepcopy(_PRESENTATIONS[key])
        if case["corpus"] in {"iran", "vietnam"}:
            db.create_function("flow_noforn", 1, lambda s: bool(re.search(r"\bNOFORN\b", s or "", re.I)), deterministic=True)
            internal = {r[0] for r in db.execute(
                "SELECT DISTINCT doc FROM main.page WHERE flow_noforn(json_extract(payload,'$.text'))")}
            if internal - set(excluded):
                raise ValueError("Whole-cable internal NOFORN veto is missing from published native scope")
        scoped_page_view(db, excluded)
        parents = hierarchy_catalog(db)
        semantic = [n["id"] for n in expanded.get("nodes", []) if n["type"].lower() not in LEVELS]
        assignments = {}
        if semantic:
            placeholders = ",".join("?" for _ in semantic)
            assignments = {r[0]: json.loads(r[1]) for r in db.execute(
                "SELECT id,hierarchy FROM node WHERE id IN (" + placeholders + ")", semantic)}
        value = project(flow, expanded, assignments, parents, targets(result, reading), limit=limit)
        certify_readout_receipts(value, record)
        attach_documents(db, value, case, result)
        attach_route_sources(db, value, case)
        attach_readouts(db, value, case)
        decorate(value, case["task"])
        value.update(version=VERSION, case_id=case_id, config=record["config"], reading_id=reading,
            scope=dict(corpus=case["corpus"], strictly_before=case["date"], whole_origin_excluded=case["document_id"],
                binding=reference["binding"], retrospective_hierarchy=True),
            source_case_sha256=case_sha, source_expanded_sha256=ref["sha256"] if ref else None)
        with _LOCK:
            _PRESENTATIONS[key] = deepcopy(value)
            while len(_PRESENTATIONS) > 4:
                _PRESENTATIONS.popitem(last=False)
        return value
    finally:
        db.close()


def routes_for(candidate):
    routes, seen = [], set()
    for route in candidate.get("represented_routes", candidate.get("routes", [])):
        key = route.get("route_kind"), tuple(n["id"] for n in route.get("nodes", []))
        if key not in seen:
            seen.add(key); routes.append(route)
        if len(routes) == 3:
            break
    return routes


def guide(root, report, case_id, arm, candidate_id, route_index=0, reading=None):
    if type(route_index) is not int or not 0 <= route_index < 3:
        raise ValueError("Unknown saved route")
    value = presentation(root, report, case_id, arm, reading=reading)
    candidates = [c for c in value["candidates"] if c["id"] == candidate_id]
    if len(candidates) != 1:
        raise ValueError("Unknown or ambiguous proposed result in this case/reading")
    candidate = candidates[0]; routes = routes_for(candidate)
    if route_index >= len(routes):
        raise ValueError("No route was recorded for this result")
    route = deepcopy(routes[route_index])
    return dict(case_id=case_id, corpus=value["scope"]["corpus"], scope=deepcopy(value["scope"]), route=route,
        candidate={k: deepcopy(candidate.get(k)) for k in
            ("id", "fill", "binding", "direction", "atom_id", "reading_id", "identity_source_attested", "support_assessment",
             "sources", "source_entity_binding", "v6_identity_binding", "source_span", "fitted_source_span")},
        graph_binding=value["scope"]["binding"], source_version=value["source_case_sha256"],
        guidance_is_entailment=False)
