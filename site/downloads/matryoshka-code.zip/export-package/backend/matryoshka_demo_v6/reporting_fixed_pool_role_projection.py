"""Narrow, raw-source role observer, independent of saved support decisions.

Only a literal positive past-role atom is eligible. A shortened person label
requires a complete pinned source-local object group, never surname overlap.
Generated descriptions locate a candidate name; the raw apposition proves the
role. No action, current tenure, global alias or whole-query truth is certified.
"""
from collections import defaultdict
from copy import deepcopy
from types import SimpleNamespace
import hashlib
import re

from matryoshka_demo.io import digest
from matryoshka_demo_v61 import role_alignment as local
from matryoshka_demo_v61 import role_sources as sources
from . import reporting_local_decisions_v65 as policy

VERSION = "raw-role-apposition-observer/1"
QUERY = local.ROLE_QUERY
NAME_WORD = r"[A-Za-z]+(?:[-'][A-Za-z]+)*"
APPOSITION = re.compile(r"(?P<name>" + NAME_WORD + r"(?:[ \t\n]+" + NAME_WORD + r")*),\s*"
    r"(?P<role>[A-Za-z]+)\s+of\s+(?:the\s+)?(?P<organization>[^,;.!?\[\]]+),", re.I)
# This deliberately refuses scope instead of deleting modifiers to get a match.
OPAQUE = re.compile(r"\b(?:alleged|allegedly|former|interim|acting|possible|possibly|purported|"
    r"purportedly|suspected|apparently|reportedly|probably|perhaps|may|might|could|would|"
    r"should|must|can|cannot|not|no|nor|neither|never|if|unless|whether|denied|rumored|rumoured)\b", re.I)


def _normal(text):
    return local.normalized(text)


def _proper(text):
    return (bool(text.split()) and text.casefold() not in {"he", "she", "it", "they", "we", "i", "you", "who"}
        and all(re.fullmatch(NAME_WORD, w) and w[0].isupper() for w in text.split()))


def query_spec(case, plan, atom_id):
    """Literal whole-atom grammar, without replacing or narrowing public scope."""
    atoms = plan.get("atoms", [])
    if (case["task"] not in {"hypothesis", "reconstruction"} or case.get("focal_marker")
            or plan.get("query_sha256") != digest(case["query"])
            or len({a["id"] for a in atoms}) != len(atoms)):
        return None
    found = [a for a in atoms if a["id"] == atom_id]
    if len(found) != 1:
        return None
    atom = found[0]
    a, b = atom["start"], atom["end"]
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(case["query"])
            or atom.get("required") is not True or case["query"][a:b] != atom["text"]
            or atom["source_quote"] != atom["text"]):
        return None
    # Do not project an atom cut out of a conditional, reported or dated clause.
    ordered = sorted(atoms, key=lambda value: value["start"])
    prior = 0
    for item in ordered:
        lo, hi = item["start"], item["end"]
        if (type(lo) is not int or type(hi) is not int or not prior <= lo < hi <= len(case["query"])
                or case["query"][prior:lo].strip() or item.get("required") is not True
                or case["query"][lo:hi] != item["source_quote"] or item["text"] != item["source_quote"]):
            return None
        prior = hi
    if case["query"][prior:].strip():
        return None
    match = QUERY.fullmatch(atom["text"])
    if (not match or match["role"].casefold() not in local.ROLES or not _proper(match["person"])
            or not _proper(match["organization"]) or OPAQUE.search(atom["text"])):
        return None
    return dict(atom=deepcopy(atom), **match.groupdict())


def _section(text, start):
    """Only a literal paragraph or numbered-section lead licenses apposition."""
    blank = list(re.finditer(r"\n[ \t]*\n", text[:start]))
    numbers = list(re.finditer(r"(?m)^\s*\d+\.[ \t]*", text[:start]))
    begin = max([0, *[m.end() for m in blank], *[m.end() for m in numbers]])
    prefix = text[begin:start]
    if prefix.strip():
        return None
    before = text[:begin].strip()
    # A number at the new boundary must not hide an open reporting clause.
    before = re.sub(r"\s*\d+\.$", "", before).rstrip()
    if before and not before.endswith((".", "!", "?")):
        return None
    if sum(text[:start].count(c) for c in ('"', '\u201c', '\u201d')) % 2:
        return None
    end = re.search(r"[.!?](?=\s|$)|\n[ \t]*\n", text[start:])
    return start, len(text) if end is None else start + end.end()


def _binding(spec, page, match, groups):
    if _normal(spec["person"]) == _normal(match["name"]):
        return dict(kind="EXACT_RAW_COMPLETE_NAME", person_label=match["name"], suffix_matching=False)
    candidates = []
    for group in groups:
        objects, scope = group["objects"], group["scope"]
        # This validates EVERY object, including duplicate/ambiguous records.
        local._source_context(page, objects, scope, group["case"])
        people = [o for o in objects if _normal(o["record"]["label"]) == _normal(spec["person"])]
        organizations = [o for o in objects if _normal(o["record"]["label"]) == _normal(spec["organization"])]
        if (len(people) != 1 or len(organizations) != 1 or people[0]["record"]["type"] != "Person"
                or organizations[0]["record"]["type"] not in local.ORGANIZATION_TYPES):
            continue
        person, organization = people[0], organizations[0]
        row = person["record"]
        locator = re.fullmatch(r"(?P<name>[^,]+),\s*(?:described as|identified as)\s+(?:the\s+)?"
            + local.literal_pattern(spec["role"]) + r"\s+of\s+(?:the\s+)?"
            + local.literal_pattern(spec["organization"]) + r"\.", row.get("description", ""), re.I)
        if not locator or _normal(locator["name"]) != _normal(match["name"]):
            continue
        label = list(re.finditer(r"(?<!\w)" + local.literal_pattern(row["label"]) + r"(?!\w)", match["name"], re.I))
        if len(label) != 1:
            continue
        for obj in (person, organization):
            record, citation = obj["record"], obj["citation"]
            if (record.get("char_start") != citation["start"] or record.get("char_end") != citation["end"]
                    or record.get("evidence_quote") != citation["text"]):
                raise ValueError("Role local-object offsets differ from original row")
        if not (person["citation"]["start"] <= match.start() < match.end() <= person["citation"]["end"]
                and organization["citation"]["start"] <= match.start("organization")
                < match.end("organization") <= organization["citation"]["end"]):
            continue
        # A second same-label referent anywhere in this job is not discarded.
        conflicting = [o for o in objects if o["record"]["type"] == "Person" and o is not person
            and re.search(r"(?<!\w)" + local.literal_pattern(spec["person"]) + r"(?!\w)", o["record"].get("label", ""), re.I)]
        if conflicting:
            continue
        candidates.append(dict(kind="PINNED_SOURCE_LOCAL_LABEL_AND_RAW_APPOSITION", suffix_matching=False,
            person=local.pointer(person), organization=local.pointer(organization),
            person_label_span=[match.start("name") + label[0].start(), match.start("name") + label[0].end()],
            object_set_sha256=digest(scope["source_objects"]), source_ledger_ref=group["ledger_ref"],
            description_is_evidence=False, description_used_only_as_locator=True))
    # Distinct extraction jobs making the same short-label assertion are not
    # silently combined into one identity decision.
    return candidates[0] if len(candidates) == 1 else None


def observe(case, plan, atom_id, admitted, index, *, engine, local_groups=None):
    """Return raw role certificates only from the current inspected source pool."""
    spec = query_spec(case, plan, atom_id)
    if spec is None:
        return dict(version=VERSION, atom_id=atom_id, status="UNRESOLVED", certificates=[],
            reason="Outside literal positive past-role scope", absence_is_counterevidence=False)
    pages, masks, veto = index
    certificates, rejected = [], []
    for page in admitted.values():
        policy._quote(policy._citation(page, 0, len(page["text"])), pages, masks, veto, case)
        groups = (local_groups or {}).get(page["id"], [])
        for group in groups:
            if group["case"] != policy._case(case):
                raise ValueError("Role source group belongs to another public question")
        hits = [m for m in APPOSITION.finditer(page["text"]) if _normal(m["role"]) == _normal(spec["role"])
            and _normal(m["organization"]) == _normal(spec["organization"])]
        valid = []
        for match in hits:
            context = _section(page["text"], match.start())
            if context is None or not _proper(match["name"]):
                rejected.append("UNLICENSED_HEAD_OR_GOVERNING_CONTEXT"); continue
            lo, hi = context
            raw_context = page["text"][lo:hi]
            if OPAQUE.search(raw_context) or re.search(r"\[[^\]]*\]|[\"\u201c\u201d]", raw_context):
                rejected.append("QUALIFIED_NEGATED_CONDITIONAL_OR_MASKED_CONTEXT"); continue
            binding = _binding(spec, page, match, groups)
            if binding is None:
                rejected.append("NO_UNIQUE_SOURCE_LOCAL_PERSON_BINDING"); continue
            # Recheck the current parser's apposition qualifiers independently
            # of the frozen native support or a generated entity description.
            role_frames = [f for f in engine.frames(page["text"], antecedents=True)
                if f["kind"] == "PROPERTY" and f["predicate_proof"]["start"] == match.start("role")
                and _normal(f["predicate"]) == _normal(spec["role"])]
            if len(role_frames) != 1 or any(bool(value) for value in role_frames[0]["qualifiers"].values()):
                rejected.append("UNRESOLVED_RAW_ROLE_SCOPE"); continue
            proof = dict(version=VERSION, kind="RAW_ROLE_APPOSITION", atom_id=atom_id,
                query_sha256=digest(case["query"]), atom_binding=deepcopy(spec["atom"]),
                citation=policy._citation(page, lo, hi), apposition=policy._citation(page, match.start(), match.end()),
                person=policy._citation(page, *match.span("name")), role=policy._citation(page, *match.span("role")),
                organization=policy._citation(page, *match.span("organization")), identity_binding=binding,
                checked_qualifiers=deepcopy(role_frames[0]["qualifiers"]), role_only=True,
                current_role_persistence=False, other_predicates_certified=False, generated_label_as_evidence=False,
                source_assertion_not_world_truth=True, numerical_transport_claim=False)
            proof["sha256"] = digest(proof)
            valid.append(proof)
        if len(valid) == 1:
            certificates.extend(valid)
        elif valid:
            rejected.append("MULTIPLE_RAW_APPOSITIONS_AMBIGUOUS")
    return dict(version=VERSION, atom_id=atom_id, status="ROLE_ONLY" if certificates else "UNRESOLVED",
        certificates=certificates, rejected=rejected, absence_is_counterevidence=False)


def load_local_groups(root, binding, case, admitted):
    """Read immutable local entity rows; no global alias or node-label lookup."""
    corpus = SimpleNamespace(binding=binding, workspace=root.parent, corpus=case["corpus"])
    if binding["corpus"] != case["corpus"]:
        raise ValueError("Role source corpus binding differs")
    pins = {key: sources._pinned(corpus, key) for key in ("entities", "pages")}
    if case["corpus"] != "cib":
        pins["projection"] = sources._pinned(corpus, "projection")
        path, stamp = pins["projection"]
        metadata = sources._metadata(str(path), stamp, binding["files"]["projection"]["sha256"])
        for page in admitted.values():
            row = metadata.get(page["document_id"], {})
            if (row.get("classification") != "CONFIDENTIAL" or row.get("policy_role") != "confidential_evidence"
                    or row.get("date_iso") != page["date"]
                    or any("NOFORN" in str(h).upper() for h in row.get("handling", []))):
                raise ValueError("Role source projection metadata does not replay")
    docs = {p["document_id"] for p in admitted.values()}
    audits, seen = defaultdict(list), set()
    for row in sources._rows(pins["pages"][0]):
        if row["document_id"] not in docs:
            continue
        text = sources._canonical_text(row, case["corpus"])
        pid = row.get("canonical_page_id", row.get("segment_id"))
        audits[row["document_id"]].append(dict(canonical_page_id=pid,
            raw_text_utf8_sha256=hashlib.sha256(text.encode()).hexdigest(),
            standalone_noforn=bool(re.search(r"\bNOFORN\b", text, re.I))))
        if pid in admitted:
            if text != admitted[pid]["text"]:
                raise ValueError("Role inspected page differs from pinned prepared source")
            seen.add(pid)
    if seen != set(admitted):
        raise ValueError("Role inspected source absent from pinned prepared pages")
    groups = defaultdict(list)
    for row in sources._rows(pins["entities"][0]):
        if row.get("canonical_page_id") in admitted:
            groups[row["job_id"], row["canonical_page_id"]].append(row)
    result = defaultdict(list)
    for (job, pid), rows in groups.items():
        page = admitted[pid]
        # Never remove a non-shared or malformed duplicate to make a unique
        # identity appear. The entire job must be eligible and replayable.
        objects = [dict(row_id=r["mention_id"], record=r, citation=sources._quote(page, r)) for r in rows]
        if any(o["citation"] is None for o in objects):
            continue
        scope = dict(kind="SOURCE_LOCAL_ENTITY_RECORDS", corpus=case["corpus"], canonical_page_id=pid,
            document_id=page["document_id"], date=page["date"], page_sha256=page["source_sha256"], job_id=job,
            source_objects={o["row_id"]: local.pointer(o) for o in objects}, whole_document_audit=audits[page["document_id"]])
        try:
            local._source_context(page, objects, scope, case)
        except (local.Refusal, KeyError, TypeError, ValueError):
            continue
        result[pid].append(dict(objects=objects, scope=scope, case=policy._case(case),
            ledger_ref=deepcopy(binding["files"]["entities"])))
    for path, stamp in pins.values():
        if sources._stamp(path) != stamp:
            raise ValueError("Role source changed during ledger read")
    return dict(result)
