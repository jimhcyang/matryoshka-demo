"""V6 source-owned construction with reversible minimal insertion fitting."""
from __future__ import annotations

from copy import deepcopy
import re

from matryoshka_demo import candidates as legacy
from matryoshka_demo import candidates_v3 as base
from matryoshka_demo import candidates_v24 as previous
from matryoshka_demo import source_constituents_v23 as constituents
from matryoshka_demo.candidates_v5 import adapt as possessive_boundary
from matryoshka_demo.fill_wording_v23 import modifier_wording
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import clone
from . import task_execution

VERSION = "source-owned-candidates/6.0.1"
BASE_VERSION = "source-owned-candidates/3.2"
RANK_TIERS = ("source_visible_carrier_binding", "boundary_duplication", *base.RANK_TIERS)
_TOKENS = re.compile(r"[^\W_]+(?:['\u2019][^\W_]+)*|[^\s]")


def _tokens(text):
    return [(m.group().casefold().replace("\u2019", "'").replace("\u2011", "-"), m.start(), m.end())
        for m in _TOKENS.finditer(text)]


def _layout_safe(values):
    for i, (word, _, _) in enumerate(values):
        if word in {";", ":", "!", "?"}:
            return False
        if word == ".":
            # Initialism punctuation is reversible layout, not a sentence cut.
            if i == 0 or len(values[i-1][0]) != 1 or not values[i-1][0].isalpha():
                return False
            if not any(j != i and values[j][0] == "." for j in range(len(values))):
                return False
    return True


def boundary_fit(case, fill):
    """Share exactly adjacent prefix/suffix tokens, never infer missing words."""
    left, right = case["query"].split(case["focal_marker"])
    before, after, source = _tokens(left), _tokens(right), _tokens(fill)
    start, stop = 0, len(source)
    edits = []
    for size in range(min(len(before), len(source)), 0, -1):
        if ([x[0] for x in before[-size:]] == [x[0] for x in source[:size]]
                and _layout_safe(source[:size])):
            start = size
            edits.append(dict(kind="EXACT_VISIBLE_LEFT_SUFFIX_SHARED", source_fill_start=0,
                source_fill_end=source[size-1][2], removed=fill[:source[size-1][2]],
                visible_query_start=before[-size][1], visible_query_end=len(left),
                visible_text=left[before[-size][1]:], source_words_preserved_in_visible_query=True))
            break
    for size in range(min(len(after), len(source)-start), 0, -1):
        if ([x[0] for x in source[-size:]] == [x[0] for x in after[:size]]
                and _layout_safe(source[-size:])):
            stop = len(source)-size
            edits.append(dict(kind="EXACT_VISIBLE_RIGHT_PREFIX_SHARED", source_fill_start=source[-size][1],
                source_fill_end=len(fill), removed=fill[source[-size][1]:], visible_query_start=len(left)+len(case["focal_marker"]),
                visible_query_end=len(left)+len(case["focal_marker"])+after[size-1][2],
                visible_text=right[:after[size-1][2]], source_words_preserved_in_visible_query=True))
            break
    if start >= stop:
        return dict(fill="", admissible=False, reason="SOURCE_PHRASE_ALREADY_VISIBLE_NO_MISSING_PORTION", edits=edits,
            original_fill=fill, source_text_modified=False)
    a, b = source[start][1], source[stop-1][2]
    value = fill[a:b]
    return dict(fill=value, admissible=bool(value.strip()), original_fill=fill,
        remaining_fill_span=[a,b], edits=edits, source_text_modified=False,
        token_alignment="EXACT_CASEFOLDED_PUNCTUATION_AND_WHITESPACE_LAYOUT")


def _raw_subspan(wording, fitted, start):
    raw, target = _tokens(wording), _tokens(fitted)
    matches = []
    if not target:
        return None
    for i in range(len(raw)-len(target)+1):
        if [t[0] for t in raw[i:i+len(target)]] == [t[0] for t in target]:
            matches.append([start+raw[i][1], start+raw[i+len(target)-1][2]])
    return matches[0] if len(matches) == 1 else None


def source_alignment(page, doc, source_span, source_wording, fitted_span):
    """Keep raw replay strict; parser alignment is proposal-level admission."""
    a,b = source_span
    if (doc.text != page["text"] or not all(type(x) is int for x in (a,b))
            or not 0 <= a < b <= len(page["text"]) or page["text"][a:b] != source_wording):
        raise ValueError("Source alignment input does not replay against raw page")
    result = dict(admissible=True,source_span=list(source_span),requested_fitted_span=deepcopy(fitted_span),
        fitted_source_span=deepcopy(fitted_span),edits=[],source_text_modified=False,
        policy="STRICT_RAW_REPLAY_THEN_CONTAINED_TOKEN_ALIGNMENT")
    if doc.char_span(a,b,alignment_mode="strict") is None:
        return dict(result,admissible=False,reason="ORIGINAL_SOURCE_ANALYSIS_TOKEN_BOUNDARY_UNALIGNED")
    if fitted_span is None:
        return result
    c,d = fitted_span
    if not all(type(x) is int for x in (c,d)) or not a <= c < d <= b:
        raise ValueError("Fitted source interval escapes its original raw occurrence")
    if doc.char_span(c,d,alignment_mode="strict") is not None:
        return result
    expanded = doc.char_span(c,d,alignment_mode="expand")
    if expanded is not None and a <= expanded.start_char <= c < d <= expanded.end_char <= b:
        extras = page["text"][expanded.start_char:c]+page["text"][d:expanded.end_char]
        # Abbreviation/quote punctuation may belong to an indivisible parser
        # token. Never recover an omitted word, clitic letter, or other content.
        if re.fullmatch(r"[\s.'\u2019]*",extras):
            aligned = [expanded.start_char,expanded.end_char]
            result.update(fitted_source_span=aligned,edits=[dict(
                kind="SOURCE_GRAMMAR_TOKEN_PUNCTUATION_RETAINED",requested_span=[c,d],analysis_span=aligned,
                retained_punctuation=extras,fill_modified=False,source_text_modified=False)])
            return result
    return dict(result,admissible=False,reason="FITTED_SOURCE_ANALYSIS_TOKEN_BOUNDARY_UNALIGNED",
        expanded_token_text=expanded.text if expanded is not None else None)


class Context(base.Context):
    def phrase(self, proposal):
        if proposal.get("fitted_source_span"):
            super().phrase(proposal)
            local = task_execution.effective_proposal(proposal)
            return super().phrase(local)
        return super().phrase(proposal)

    def grammar_phrase(self, proposal):
        if proposal.get("fitted_source_span"):
            self.phrase(proposal)
            return super().grammar_phrase(task_execution.effective_proposal(proposal))
        return super().grammar_phrase(proposal)

    def source_facts(self, proposal):
        pid = proposal["sources"][0]["canonical_page_id"]
        bounds = proposal.get("fitted_source_span") or proposal["source_span"]
        key = pid, tuple(bounds), "v6_exact_identity"
        if key not in self.source_fact_cache:
            page = self.page(pid)
            original_a, original_b = proposal["source_span"]
            if (not 0 <= original_a <= bounds[0] < bounds[1] <= original_b <= len(page["text"])
                    or page["text"][original_a:original_b] != proposal["source_wording"]):
                raise ValueError("Identity witness does not replay inside original literal occurrence")
            a, b = bounds
            found = []
            pi = self.c.page_index[pid]
            for j in self.c.occurrences_by_page.get(pi, []):
                row = self.c.occurrences[j]
                if (row.get("source_type") != "entities" or not self.e.page_mask[pi]
                        or row["page_index"] != pi or row["node_id"] not in self.c.nodes
                        or self.c.nodes[row["node_id"]].get("kind") != "Entity"):
                    continue
                # Existing raw-backed mention intervals, not a graph label or
                # global alias frequency, must own this very occurrence.
                ra, rb = row.get("start"), row.get("end")
                if type(ra) is not int or type(rb) is not int or not 0 <= ra < rb <= len(page["text"]):
                    continue
                label = row.get("label", "")
                if not label:
                    continue
                for m in self.pattern(label).finditer(page["text"], max(a,ra), min(b,rb)):
                    if m.start() < a or m.end() > b:
                        continue
                    found.append(dict(occurrence_index=j, node_id=row["node_id"], label=page["text"][m.start():m.end()],
                        source_entity_type=row.get("entity_type"), start=m.start(), end=m.end(),
                        canonical_page_id=pid, page_sha256=page["source_sha256"], raw_quote_attested=True))
            self.source_fact_cache[key] = found
        return deepcopy(self.source_fact_cache[key])

    def bind(self, proposal):
        facts = self.source_facts(proposal)
        ids = {f["node_id"] for f in facts}
        assigned = next(iter(ids)) if len(ids) == 1 else None
        return assigned, dict(status="UNIQUE_EXACT_ELIGIBLE_OCCURRENCE" if assigned else "UNBOUND_OR_AMBIGUOUS",
            original_node_id=proposal.get("node_id"), node_id=assigned, witnesses=facts,
            graph_identity_retrospective=True, fuzzy_alias_join=False, invented_node_id=False,
            generated_label_alone_is_proof=False)


def _grammar(case, reading, fill, context):
    key = (reading["form"], fill)
    cache = getattr(context, "v6_grammar", None)
    if cache is None:
        context.v6_grammar = cache = {}
    if key not in cache:
        cache[key] = task_execution.grammar_admission(case, reading, fill, parse=context.parse)
    return deepcopy(cache[key])


def joint_fit(proposal, reading, context):
    fit = previous.joint_fit(proposal, reading, context)
    grammar = _grammar(context.case, reading, proposal["fill"], context)
    if grammar.get("compound_modifier", {}).get("licensed"):
        fit["reasons"] = [r for r in fit["reasons"] if r != "NOMINAL_LABEL_IS_NOT_A_PROPERTY_MODIFIER"]
    fit["reasons"] = list(dict.fromkeys(fit["reasons"]+grammar["reasons"]))
    fit["admissible"] = not fit["reasons"]
    fit["v6_completed_insertion"] = grammar
    return fit


def features(proposal, context, *, reading=None, source_fit=None):
    value = base.features(proposal, context, reading=reading, source_fit=source_fit)
    grammar = (source_fit or {}).get("v6_completed_insertion", {})
    carrier = grammar.get("compound_modifier", {}).get("visible_carrier", "").casefold()
    part, _ = context.grammar_phrase(proposal)
    source_carrier = part.root.head
    value["source_visible_carrier_binding"] = bool(carrier and source_carrier not in part
        and source_carrier.text.casefold() == carrier)
    # Exact overlap was already removed. An unshared duplicate is a ranking
    # defect, not a known-answer signal or a semantic support judgment.
    overlap = boundary_fit(context.case, proposal["fill"])
    value["boundary_duplication"] = len(overlap["edits"])
    return value


def rank_key(proposal, f, index):
    return (not f.get("source_visible_carrier_binding",False), f.get("boundary_duplication",0),
        *base.rank_key(proposal,f,index))


def _source_pool(case, plan, retrieval, context, passage_budget):
    corpus = retrieval["eligible"].corpus
    ordered = sorted(retrieval["pages"], key=lambda i: retrieval["page_ranks"].get(i,10**9))[:passage_budget]
    all_rows, excluded, alignment_rejections, occurrence_maps = [], [], [], []
    for reading in plan["slot_readings"]:
        pages = iter(corpus.pages[i] for i in ordered)
        records = {}

        def spans(text, parse):
            page = next(pages)
            context.page(page["id"])
            assert text == page["text"]
            doc, values = constituents.proposal_spans(text, parse)
            kept = []
            for raw in values:
                if raw.get("source_format_rejection"):
                    excluded.append(dict(canonical_page_id=page["id"], source_span=[raw["start"],raw["end"]],
                        source_wording=raw["text"], reason=raw["source_format_rejection"]))
                    continue
                item = dict(raw)
                fill = item["edited"]
                transforms = []
                part = doc.char_span(item["start"],item["end"],alignment_mode="strict")
                if reading["form"] == "modifier" and part is not None:
                    fill, transforms = modifier_wording(fill,part)
                fitted = boundary_fit(case,fill)
                if not fitted["admissible"]:
                    continue
                alignment = source_alignment(page,doc,[item["start"],item["end"]],item["text"],
                    _raw_subspan(item["text"],fitted["fill"],item["start"]))
                if not alignment["admissible"]:
                    alignment_rejections.append(dict(canonical_page_id=page["id"],page_sha256=page["source_sha256"],
                        document_id=page["document_id"],reading_id=reading["id"],source_span=[item["start"],item["end"]],
                        source_wording=item["text"],fill=fitted["fill"],alignment=alignment,
                        scope="PROPOSAL_ANALYSIS_NOT_RAW_SOURCE_INTEGRITY",substantive_counterevidence=False))
                    continue
                item["edited"] = fitted["fill"]
                if reading["form"] == "modifier" and item["kind"] == "nominal":
                    grammar = _grammar(case,reading,item["edited"],context)
                    if not grammar.get("compound_modifier",{}).get("licensed"):
                        continue
                    item["kind"] = "modifier"
                records[page["id"],item["start"],item["end"]] = dict(boundary=fitted, transforms=transforms,
                    fitted_source_span=alignment["fitted_source_span"],alignment=alignment)
                kept.append(item)
            return doc,kept

        def fit(public, fill, form, parse, *, source_kind=None):
            # Existing construction-form/finite gates remain. The compound
            # exception needs a completed dependency, not a blanket NN license.
            if form == "modifier" and _grammar(public,reading,fill,context).get("compound_modifier",{}).get("licensed"):
                return True
            return legacy.fit(public,fill,form,parse,source_kind=source_kind)

        _, funcs = clone(legacy, dict(parser=lambda:context.parse, proposal_spans=spans, fit=fit,
            candidate_route=lambda *a,**k:None, focal_requirements=previous.deferred_focal_requirements))
        local = dict(plan,slot_readings=[reading])
        raw = funcs["construct"](case,local,dict(retrieval,kernel=None),passage_budget=passage_budget)
        row = raw["_candidate_audit"]["readings"][0]
        for candidate in row["proposals"]:
            key = candidate["sources"][0]["canonical_page_id"],*candidate["source_span"]
            proof = records[key]
            candidate["v6_boundary_fit"] = deepcopy(proof["boundary"])
            candidate["source_analysis_alignment"] = deepcopy(proof["alignment"])
            candidate["insertion_edits"] = deepcopy(proof["transforms"]+proof["boundary"]["edits"]+proof["alignment"]["edits"])
            if proof["fitted_source_span"]:
                candidate["fitted_source_span"] = proof["fitted_source_span"]
            candidate["v6_reading"] = deepcopy(reading)
        all_rows.append(row)
    value = dict(task="redaction", readings=[dict(reading=r["reading"],candidates=[]) for r in all_rows],
        retrieval=deepcopy(retrieval.get("receipt",{})), _candidate_audit=dict(readings=all_rows,
            keys_read=False, grades_read=False, version="source-owned-candidate-pool/6", inspected_page_ids=[corpus.pages[i]["id"] for i in ordered]),
        api_calls=0, keys_read=False, grades_read=False,
        construction=dict(source_pages_inspected=len(ordered),passage_budget=passage_budget))
    value = possessive_boundary(case,value)
    seen_ids = set()
    for row in value["_candidate_audit"]["readings"]:
        retained = {}
        for p in row["proposals"]:
            old_id = p["id"]
            p["node_id"], binding = context.bind(p)
            p["v6_identity_binding"] = binding
            p["owner"] = deepcopy(context.owner(p))
            p["source_function_match"] = base.owned_role_context(p,case["query"],context.parse)
            p["visible_actor_reuse"] = context.reused_actor(p["node_id"])
            p["ranking"]["fused_rrf"] = p["ranking"]["rrf"]
            identity = digest([row["reading"]["id"],p["sources"][0]["canonical_page_id"],p["sources"][0]["page_sha256"],
                p["source_span"],p["source_wording"],p["fill"],p["node_id"]])
            p["id"] = "candidate_v6_"+identity[:28]
            p["legacy_id"] = old_id
            p["legacy_ids"] = [old_id]
            p["source_attestation"] = dict(literal_wording=True, entity_identity=binding,
                property_clue=p["support"] == "LOCAL_PROPERTY_ATTESTED", full_missing_action_established=False,
                generated_label_is_proof=False, original_source_span_preserved=True)
            occurrence_maps.append(dict(reading_id=row["reading"]["id"],legacy_id=old_id,id=p["id"],source_span=p["source_span"]))
            if p["id"] in retained:
                retained[p["id"]]["legacy_ids"].append(old_id)
            else:
                assert p["id"] not in seen_ids
                seen_ids.add(p["id"])
                retained[p["id"]] = p
        row["proposals"] = list(retained.values())
    value["_candidate_audit"]["v6_identity"] = dict(rekeyed_before_ranking=True, occurrence_map=occurrence_maps,
        cross_occurrence_merges=False, entity_ids_invented=False)
    value["_candidate_audit"]["source_constituents_v6"] = dict(source_format_rejections=excluded,
        analysis_token_rejections=alignment_rejections,analysis_token_rejections_before_rerank=True,
        full_pool_boundary_fitted=True, original_quotes_modified=False)
    return value


def construct(case, plan, retrieval, *, passage_budget=100, top_k=5):
    from .planning import validate_plan
    validate_plan(plan,case)
    if type(top_k) is not int or not 1 <= top_k <= 5:
        raise ValueError("Display budget must be one to five")
    with offline():
        compiled = base._execution_plan(plan,case)
        context = Context(case,compiled,retrieval)
        output = _source_pool(case,compiled,retrieval,context,passage_budget)
        _, functions = clone(previous,dict(Context=Context,joint_fit=joint_fit,features=features,
            rank_key=rank_key,RANK_TIERS=RANK_TIERS,VERSION=VERSION))
        result = functions["_rerank"](case,compiled,retrieval,output,top_k=top_k,context=context,
            execution_kind="FRESH_SOURCE_BOUND_CONSTRUCTION")
        result.update(constructor_version=VERSION,base_constructor_version=BASE_VERSION,
            planning_arm=plan["arm"],execution_plan_sha256=digest(compiled),
            construction_policy="Exact eligible source phrases, minimal visible-boundary sharing, completed-parse grammar, no answer bonus")
        if not plan.get("slot_readings"):
            result["untyped_pool"] = True
        return result


filter_redaction = task_execution.filter_redaction


def finalize_untyped(result, *, top_k=5):
    _, functions = clone(base,dict(rank_key=rank_key))
    return functions["finalize_untyped"](result,top_k=top_k)
