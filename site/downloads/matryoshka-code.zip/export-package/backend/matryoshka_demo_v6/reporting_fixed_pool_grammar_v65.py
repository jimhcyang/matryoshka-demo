"""Additional source-owned insertion checks, not frozen syntax admission."""
from copy import deepcopy
import re

from matryoshka_demo_v61 import scope_matching as scoped

VERSION = "source-owned-slot-sanity/6.5.5"


def check(identity, label, state, detail):
    return dict(id=identity, label=label, state=state, detail=detail)


def _source_part(candidate, pages, parse):
    span, wording = candidate.get("source_span"), candidate.get("source_wording")
    if not (isinstance(span, list) and len(span) == 2 and all(type(x) is int for x in span) and isinstance(wording, str)):
        return None
    found = []
    for page in pages.values():
        a, b = span
        if not 0 <= a < b <= len(page["text"]) or page["text"][a:b] != wording:
            continue
        part = parse(page["text"]).char_span(a, b, alignment_mode="strict")
        if part is not None:
            found.append(part)
    return found[0] if len(found) == 1 else None


def _complemented_postmodifier(candidate, pages, parse, part):
    head = part.root
    before = next((t for t in reversed(part.doc[:part.start]) if not t.is_space and not t.is_punct), None)
    if (before is None or before.pos_ not in {"NOUN", "PROPN"} or head.tag_ != "VBN"
            or any(t.pos_ == "AUX" or t.tag_ in {"VBD", "VBP", "VBZ", "MD"} for t in part)
            or not any(c.dep_ == "prep" and c in part and any(o.dep_ == "pobj" and o in part for o in c.children) for c in head.children)
            or any(t != head and t.dep_ in {"ccomp", "advcl", "relcl"} for t in part)):
        return False
    source = _source_part(candidate, pages, parse)
    if source is None and "source_span" not in candidate:
        hits = []
        pattern = r"(?<!\w)" + r"\s+".join(re.escape(w) for w in candidate["fill"].split()) + r"(?!\w)"
        for page in pages.values():
            for match in re.finditer(pattern, page["text"], re.I):
                found = parse(page["text"]).char_span(*match.span(), alignment_mode="strict")
                if found is not None:
                    hits.append(found)
        source = hits[0] if len(hits) == 1 else None
    if source is None or source.root.tag_ != "VBN" or source.root.lemma_ != head.lemma_:
        return False
    root = source.root
    patients = [c for c in root.children if c.dep_ in {"nsubjpass", "nsubj:pass"}]
    if root.dep_ in {"amod", "acl"} and root.head not in source:
        patients.append(root.head)
    wanted = scoped.matching.phrase(before)
    # The property is absent from the visible owner's source-independent NP.
    wanted["proofs"] = [p for p in wanted["proofs"] if not part.start_char <= p["start"] < part.end_char]
    terms = {p["lemma"] for p in wanted["proofs"]}
    return any(owner.lemma_ == before.lemma_ and terms <= {p["lemma"] for p in scoped.matching.phrase(owner)["proofs"]}
               and owner.morph.get("Number") == before.morph.get("Number") for owner in patients)


def evaluate(case, reading, candidate, pages, parse):
    """No grades/keys/statuses are read. Pages must already pass raw replay."""
    fill = candidate["fill"]
    left, right = case["query"].split(case["focal_marker"])
    doc = parse(left + fill + right)
    a, b = len(left), len(left) + len(fill)
    part = doc.char_span(a, b, alignment_mode="strict")
    if part is None or not fill.strip():
        return [check("slot_tokens", "Exact insertion token boundary", "conflict", "The unchanged fill does not occupy a complete token span.")]
    head = part.root
    tokens = [t for t in part if not t.is_space]
    form = reading.get("form")
    result = [check("slot_tokens", "Exact insertion token boundary", "pass", "The literal fill replays without padding or rewritten text.")]
    number_bad = []
    for number in tokens:
        group = [number, *number.conjuncts]
        numeric = [t for t in group if t in part and t.like_num and t.pos_ == "NUM"]
        coordinated = len(numeric) > 1 and any(c.dep_ == "cc" and c in part for t in numeric for c in t.children)
        plural_alternative = any(t in part and t.pos_ in {"ADJ", "DET", "PRON"}
            and t.lemma_.casefold() in {"more", "several", "many", "few"} for t in number.conjuncts)
        quantified_or = plural_alternative and any(c.dep_ == "cc" and c in part and c.lower_ == "or"
            for t in group for c in t.children)
        carrier = number.head
        if (number.like_num and number.lemma_.casefold() in {"one", "1"} and number.dep_ == "nummod"
                and not (coordinated or quantified_or) and carrier not in part and carrier.dep_ != "compound"
                and (carrier.tag_ in {"NNS", "NNPS"} or "Plur" in carrier.morph.get("Number"))):
            number_bad.append((number.text, carrier.text))
    result.append(check("slot_number", "Inserted count / visible noun agreement", "conflict" if number_bad else "pass",
        "A directly attached singular count conflicts with the visible plural carrier: " + str(number_bad)
        if number_bad else "No explicit singular-count/plural-carrier conflict; partitives and coordinated counts are not flattened."))
    if form != "modifier":
        return result
    nominal = head.head if head.head not in part and head.head.pos_ in {"NOUN", "PROPN"} else None
    repaired = _complemented_postmodifier(candidate, pages, parse, part)
    wrong_role = (not repaired and reading.get("role") == "nominal_property" and head.dep_ in {"advcl", "advmod", "ccomp"}
                  and head.head not in part and head.head.pos_ in {"VERB", "AUX"})
    result.append(check("slot_attachment", "Declared modifier / attachment role", "conflict" if wrong_role else "pass",
        "The inserted head attaches as a clause-level adjunct, not as the declared nominal property."
        if wrong_role else "No clause-level adjunct has been substituted for the declared nominal modifier."))
    if repaired:
        result.append(check("slot_reduced_relative", "Source-attached complemented postmodifier", "pass",
            "A unique rechecked source occurrence licenses the same owner's nonfinite passive property with its complete prepositional complement; this is syntax evidence, not factual endorsement."))
    source = _source_part(candidate, pages, parse)
    role_state, role_detail = "pass", "No finite-active source phrase is being certified as a passive property of a different owner."
    if source is None and "source_span" in candidate and nominal is not None and head.tag_ == "VBN":
        role_state, role_detail = "missing", "The committed source-part interval does not replay uniquely; no full source-to-slot participle license is claimed."
    if (source is not None and nominal is not None and head.tag_ == "VBN"
            and (source.root.tag_ == "VBD" or source.root.tag_ == "VBN" and any(c.dep_ == "aux" and c.lemma_ == "have" for c in source.root.children))
            and not any(c.dep_ in {"auxpass", "nsubjpass", "nsubj:pass"} for c in source.root.children)):
        root = source.root
        subjects = [c for c in root.children if c.dep_ == "nsubj"]
        patients = [c for c in root.children if c.dep_ in {"dobj", "obj"}]
        same_owner = lambda token: token.lemma_.casefold() == nominal.lemma_.casefold()
        if subjects and not any(same_owner(t) for t in [*subjects, *patients]):
            role_state = "conflict"
            role_detail = "The exact source phrase is a finite active event with a different participant; it supplies no actor/patient-to-carrier license for this participial insertion."
    result.append(check("slot_source_role", "Source phrase / participle argument role", role_state, role_detail))
    following = next((t for t in doc[part.end:] if not t.is_space), None)
    bare_post = (nominal is not None and nominal.idx < a and head.tag_ in {"VBN", "VBG"}
                 and following is not None and following.tag_ in {"WP", "WP$", "WDT"}
                 and not any(c.dep_ in {"prep", "dobj", "obj", "xcomp", "agent", "nsubj"} for c in head.children))
    if bare_post:
        licensed = (source is not None and source.root.dep_ in {"amod", "acl"} and source.root.head not in source
                    and source.root.head.pos_ in {"NOUN", "PROPN"} and source.root.head.idx < source.start_char
                    and source.root.head.lemma_.casefold() == nominal.lemma_.casefold())
        result.append(check("slot_postnominal", "Bare postnominal participle before relative clause", "pass" if licensed else "missing",
            "The exact source occurrence supplies the same postnominal carrier attachment." if licensed else
            "A second bare participle before the visible relative clause has no source-local postnominal attachment license. Syntax-only admission is insufficient; this is not a universal English ungrammaticality claim."))
    return result


def apply(packet, record, case, index, engine, parent):
    from matryoshka_demo_v61 import candidates
    rows = {c["id"]: (r.get("reading", {}), c) for r in record["result"].get("readings", []) for c in r.get("candidates", [])}
    for unit in packet["decisions"]:
        reading, candidate = rows[unit["id"]]
        admitted = {}
        for reference in parent._references(candidate):
            try:
                page = parent._quote(reference, *index, case)
                admitted[page["id"]] = page
            except (ValueError, KeyError, TypeError):
                pass  # The parent's provenance conflict remains in the decision.
        extra = evaluate(case, reading, candidate, admitted, engine.parse)
        prior = [c for c in unit["checklist"] if c["id"] == "grammar"]
        unit["syntax_only_recheck_v654"] = deepcopy(prior)
        try:
            fit = candidates.grammar_admission(case, reading, candidate["fill"], parse=engine.parse)
        except (ValueError, KeyError, TypeError):
            fit = dict(reasons=["UNRESOLVED_INSERTION_CONTRACT"])
        repaired = (fit.get("reasons") == ["MODIFIER_CONTAINS_A_CLAUSE"]
                    and any(c["id"] == "slot_reduced_relative" and c["state"] == "pass" for c in extra))
        if repaired:
            unit["checklist"] = [c for c in unit["checklist"] if c not in prior]
            prior = []
            unit["grammar_analysis_repair"] = "SOURCE_OWNED_COMPLEMENTED_REDUCED_RELATIVE_NOT_FINITE_CLAUSE"
        for item in prior:
            item.update(id="legacy_syntax", label="Syntax-only admission / not a full insertion certificate")
        failed = any(c["state"] == "conflict" for c in extra)
        missing = any(c["state"] == "missing" for c in extra)
        state = "conflict" if failed or any(c["state"] == "conflict" for c in prior) else "missing" if missing or any(c["state"] != "pass" for c in prior) else "pass"
        extra.append(check("grammar", "Local insertion criteria", state,
            "All applicable bounded token, attachment, number and source-role checks pass." if state == "pass" else
            "An explicit insertion conflict is present." if state == "conflict" else "A targeted construction license remains unestablished; no full grammar pass is claimed."))
        unit["checklist"].extend(extra)
        incompatible = bool(unit["source_failures"]) or state == "conflict" or unit["counterevidence"] and not any(f["coverage"] == "Established" for f in unit["requirements"])
        status = (parent.BACKED if all(c["state"] == "pass" for c in unit["checklist"]) else parent.INCOMPATIBLE if incompatible
                  else parent.PARTIAL if unit["coverage"] in {"Established", "Partial"} else parent.CONTEXT)
        unit.update(status=status, label=parent.LABELS[status])
        unit["what_would_suffice"] = [c["detail"] for c in unit["checklist"] if c["state"] != "pass"] or ["These bounded criteria pass; no general syntax or answer-key correctness certificate is implied."]
        unit["grammar_supplement_version"] = VERSION
    for overview, units in [(packet["overall"], packet["decisions"]), *[(value, [u for u in packet["decisions"] if u["reading_id"] == rid]) for rid, value in packet["reading_overviews"].items()]]:
        status = (parent.BACKED if any(u["status"] == parent.BACKED for u in units) else parent.PARTIAL
                  if any(u["status"] == parent.PARTIAL for u in units) else parent.INCOMPATIBLE
                  if units and all(u["status"] == parent.INCOMPATIBLE for u in units) else parent.CONTEXT)
        overview.update(status=status, label=parent.LABELS[status])
        for item in overview.get("checklist", []):
            if item["id"] == "required_units":
                item.update(state="pass" if status == parent.BACKED else "missing")
    return packet
