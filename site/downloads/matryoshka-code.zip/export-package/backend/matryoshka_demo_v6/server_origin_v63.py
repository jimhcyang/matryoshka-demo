"""Privileged query provenance only. Never import this helper into inference.

The server_* filename is excluded by the frozen native binding rules. The lead
can compose OriginV63Mixin before the current Handler without modifying native
or evidence routes. The module CLI is a local-only workbench staging overlay.
"""
from pathlib import Path
import json
import re
from urllib.parse import parse_qs, unquote, urlsplit

from matryoshka_demo.io import digest, load, sha


RELEASE_ROOTS = ("experiments/palette_v61/releases", "experiments/bench_v62/releases",
                 "experiments/curation_v63/releases", "experiments/curation_v63_vietnam_independent/releases")
ASSETS = {"workbench-v6.html", "workbench-v6.js", "workbench-v6.css", "app-theme-v6.css"}
NOTICE = ("Privileged query-origin provenance, not eligible evidence. The entire "
          "origin remains excluded from inference, retrieval and support counts.")


def _bound_file(root, relative, expected, *, directory=None):
    root = Path(root).resolve()
    rel = Path(relative)
    if rel.is_absolute() or ".." in rel.parts or not re.fullmatch(r"[0-9a-f]{64}", expected or ""):
        raise ValueError("Invalid provenance binding")
    path = root / rel
    resolved = path.resolve(strict=True)
    # Symlinks must not turn a sealed relative reference into private file access.
    if resolved != path or not resolved.is_relative_to(directory or root):
        raise ValueError("Provenance path escapes its sealed release")
    if sha(resolved) != expected:
        raise ValueError("Provenance artifact changed")
    return resolved


def _bound_json(root, relative, expected, *, directory=None):
    return load(_bound_file(root, relative, expected, directory=directory))


def _proof(root, row):
    ref = row["source_manifest_ref"]
    relative = Path(ref["path"])
    if (relative.name != "release_manifest.json" or len(relative.parts) != 5
            or relative.parent.parent.as_posix() not in RELEASE_ROOTS):
        raise ValueError("Unsupported provenance release")
    directory = Path(root).resolve() / relative.parent
    manifest = _bound_json(root, str(relative), ref["sha256"], directory=directory)
    artifacts = manifest["artifacts"]
    catalog = _bound_json(root, str(relative.parent / "candidate_public_catalog.json"),
                          artifacts["candidate_public_catalog.json"], directory=directory)
    case = row["case"]
    if [c for c in catalog["cases"] if c["case_id"] == case["case_id"]] != [case]:
        raise ValueError("Published query differs from its sealed source catalog")
    proofs = _bound_json(root, str(relative.parent / "private/source_proofs.json"),
                         artifacts["private/source_proofs.json"], directory=directory)
    if manifest.get("source_proofs_sha256") != artifacts["private/source_proofs.json"]:
        raise ValueError("Source proof commitments disagree")
    return proofs["cases"][case["case_id"]], artifacts["private/source_proofs.json"]


def _anchor(anchor, text, origin):
    start, end = anchor["start"], anchor["end"]
    if type(start) is not int or type(end) is not int:
        raise ValueError("Invalid origin quote offsets")
    start -= origin.get("start", 0)
    end -= origin.get("start", 0)
    if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text)
            or text[start:end] != anchor["text"]):
        raise ValueError("Origin quote offsets do not replay")
    for key in ("source_id", "document_id", "date", "source_text_sha256"):
        if key in anchor and anchor[key] != origin.get(key):
            raise ValueError("Origin anchor has another source binding")
    if anchor.get("quote_sha256") and digest(anchor["text"]) != anchor["quote_sha256"]:
        raise ValueError("Origin quotation hash changed")
    return {"start": start, "end": end, "text": anchor["text"]}


def _source_mapping_summary(row, audit):
    mapping = row.get("source_mapping", {})
    if mapping.get("kind") != "withholding_notice_block":
        return None
    def page(value):
        return value if type(value) is int and value > 0 else None
    def label(value):
        return value if isinstance(value, str) and len(value) <= 256 else None
    alignment = audit.get("paired_record", {}).get("alignment_evidence", {})
    anchors = {}
    for side in ("left", "right"):
        boundary = mapping.get("boundary_anchors", {}).get(side, {})
        accepted = alignment.get(side + "_anchor", {}).get("accepted")
        anchors[side] = dict(earlier_page=page(boundary.get("earlier_page")),
                             later_page=page(boundary.get("later_page")),
                             accepted=accepted if type(accepted) is bool else None)
    pending = row.get("source_annotation_pending")
    # Never forward the nested notice/OCR/tooling records or full private audit.
    return dict(kind="withholding_notice_block", policy=label(mapping.get("policy")),
        earlier_source_role=label(row.get("earlier_source_role")),
        earlier_notice_page=page(mapping.get("notice_page")),
        later_content_page=page(audit.get("later_physical_pdf_page", row.get("later_source_page"))),
        notice_quote=label(mapping.get("notice", {}).get("notice_quote")),
        declared_page_count=page(mapping.get("declared_page_count")),
        covered_page_count=page(mapping.get("covered_page_count")),
        later_pages=[p for p in mapping.get("later_pages", []) if page(p) is not None],
        count_interpretation=label(mapping.get("count_interpretation")),
        boundary_anchors=anchors, source_annotation_pending=pending if type(pending) is bool else None)


def _source_category(root, report, case, proof, source):
    audit = proof.get("source_origin_audit", {})
    if case["corpus"] != "cib":
        return dict(source_category="CABLE_CLASSIFICATION_IN_SEALED_PROOF", unit_verified=False,
                    secret_derived=None, units=[], warning="SECRET is recorded in the sealed source proof. This release does not expose a separately verified full original-body audit.")
    ref = audit.get("canonical_ref") or report.get("source_binding", {}).get("corpora", {}).get("cib", {}).get("files", {}).get("pages")
    if not ref:
        if case["task"] != "redaction":
            raise ValueError("CIB origin text requires a pinned canonical unit binding")
        return dict(source_category="CIB_UNIT_UNVERIFIED", unit_verified=False, secret_derived=False,
                    units=[], warning="A later-release page alone does not establish a secret-derived query. Canonical unit membership is unverified.")
    workspace = Path(root).resolve().parent
    relative = Path(ref["path"])
    directory = workspace / "src-redaction/data/preparation_refresh/runs"
    if relative.name != "canonical_pages.jsonl":
        raise ValueError("Only pinned canonical CIB units may verify origin category")
    path = _bound_file(workspace, str(relative), ref["sha256"], directory=directory)
    row = None
    with path.open() as stream:
        for line in stream:
            candidate = json.loads(line)
            if candidate.get("canonical_page_id") == source["source_id"]:
                row = candidate
                break
    if row is None or row["document_id"] != case["document_id"] or row.get("projection_status") != "ready":
        raise ValueError("No ready canonical origin unit")
    if audit.get("canonical_row") and audit["canonical_row"] != row:
        raise ValueError("Audited canonical origin row changed")
    memberships = []
    for anchor in proof.get("origin_anchors", []):
        hits = []
        for index, unit in enumerate(row["units"]):
            text = unit.get("text", "") if unit["unit_type"] == "shared_text" else unit.get("later_text", "")
            if anchor["text"] in text:
                hits.append(dict(unit_index=index, unit_type=unit["unit_type"], unique_in_unit=text.count(anchor["text"]) == 1,
                                 slot_ids=unit.get("slot_ids", []), reveal_states=unit.get("reveal_states", [])))
        memberships.append(hits)
    verified = bool(memberships) and all(len(hits) == 1 and hits[0]["unique_in_unit"] for hits in memberships)
    units = [hits[0] for hits in memberships] if verified else []
    shared = verified and all(u["unit_type"] == "shared_text" for u in units)
    revealed = verified and all(u["unit_type"] == "redaction_zone" and u["slot_ids"] and
                               any(s in {"revealed", "partially_revealed"} for s in u["reveal_states"]) for u in units)
    # New sealed source audits also preserve the earlier text. A reveal cannot
    # be certified merely by repeating visible text inside a redaction zone.
    pair = audit.get("paired_record")
    if pair:
        if pair.get("canonical_page_id") != source["source_id"] or pair.get("document_id") != case["document_id"]:
            raise ValueError("Paired origin audit belongs to another page")
        earlier = " ".join(pair["earlier_text"].split()).casefold()
        revealed = revealed and all(" ".join(a["text"].split()).casefold() not in earlier for a in proof["origin_anchors"])
    elif case["task"] != "redaction":
        revealed = False
    category = "CIB_VERIFIED_REVEAL" if revealed else "CIB_SHARED_VISIBLE_TEXT" if shared else "CIB_MIXED_OR_UNVERIFIED_UNITS"
    warning = "" if revealed else ("Shared-visible origin text, not an authentic reveal; this case does not meet the secret-derived query requirement. Preserve its original native result as a reserve." if shared else "Origin units do not certify an entirely secret-derived query. A later-release PDF is not a secret-origin certificate.")
    value = dict(source_category=category, unit_verified=verified, secret_derived=bool(revealed), units=units, warning=warning,
                 source_mapping=_source_mapping_summary(row, audit))
    if case["task"] != "redaction":
        selected = {u["unit_index"] for u in units}
        parts, mapped, cursor = [], [], 0
        for index, unit in enumerate(row["units"]):
            part = unit.get("text", "") if unit["unit_type"] == "shared_text" else unit.get("later_text", "") if index in selected else "[REDACTED]"
            for anchor, membership in zip(proof.get("origin_anchors", []), units):
                if membership["unit_index"] == index:
                    start = cursor + part.index(anchor["text"])
                    mapped.append(dict(start=start, end=start + len(anchor["text"]), text=anchor["text"]))
            parts.append(part)
            cursor += len(part)
        value["_projection"] = dict(text="".join(parts), anchors=mapped)
    return value


def _full_cable_transcription(case, proof, source, anchors, hidden, reveal):
    audit = proof.get("source_origin_audit", {})
    raw = audit.get("original_raw_documents", {}).get(case["document_id"])
    if case["corpus"] == "cib" or raw is None:
        return None
    checks = [c for c in audit.get("document_checks", []) if c["document_id"] == case["document_id"]]
    body = raw.get("body")
    if (len(checks) != 1 or not checks[0].get("valid") or checks[0].get("whole_body_noforn") is not False
            or checks[0].get("classification") != "SECRET" or source["classification"] != "SECRET"
            or raw.get("id") != case["document_id"] or raw.get("date") != case["date"]
            or not isinstance(body, str) or digest(body) != checks[0].get("raw_body_sha256")
            or re.search(r"\bNOFORN\b", body, re.I) or "NOFORN" in checks[0].get("handling", [])):
        raise ValueError("Full original cable body audit does not replay")
    if body.count(source["text"]) != 1:
        raise ValueError("Audited origin segment does not map uniquely into its original cable")
    offset = body.index(source["text"])
    spans = [dict(a, start=a["start"] + offset, end=a["end"] + offset) for a in anchors]
    if hidden is not None:
        start, end = hidden["start"] + offset, hidden["end"] + offset
        if not reveal:
            body = body[:start] + case["focal_marker"] + body[end:]
            end = start + len(case["focal_marker"])
        spans = [dict(start=start, end=end, text=body[start:end])]
    return dict(text=body, text_sha256=digest(body), anchors=spans,
                scope="Full original cable body / sealed raw-document and classification audit verified")


def origin(root, report, case_id, *, reveal_focal=False):
    """Return an allowlisted projection, never the private proof object itself."""
    if type(reveal_focal) is not bool:
        raise ValueError("Focal reveal must be explicit")
    matches = [row for row in report["cases"] if row["case"]["case_id"] == case_id]
    if len(matches) != 1:
        raise ValueError("Unknown published origin")
    row = matches[0]
    case = row["case"]
    proof, proof_hash = _proof(root, row)
    source = proof["origin"]
    text = source["text"]
    if (source["document_id"] != case["document_id"] or source["date"] != case["date"]
            or not isinstance(text, str) or digest(text) != source.get("quote_sha256", source["source_text_sha256"])):
        raise ValueError("Origin text/document/date does not replay")
    redaction = case["task"] == "redaction"
    anchors = [_anchor(a, text, source) for a in proof.get("origin_anchors", [])]
    category = _source_category(root, report, case, proof, source)
    projection = category.pop("_projection", None)
    mapping = category.pop("source_mapping", None)
    if projection is not None:
        text, anchors = projection["text"], projection["anchors"]
    hidden = None
    kind = proof.get("query_kind", "UNRECORDED_DERIVATION")
    derivation = "Rephrased / source-scoped analyst construction"
    if "SYNTHETIC_ANALYST_COUNTERHYPOTHESIS" in kind:
        derivation = "Synthetic negative / analyst-authored alternative to the origin assertion"
    elif kind.startswith("ANALYST_ALTERNATIVE_"):
        derivation = "Analyst-authored alternative / source assertion altered, not verbatim"
    elif "LITERAL_PAIRED_LATER" in kind:
        derivation = "Verbatim later-release assertions / assembled into an analyst query"
    if category["source_category"] == "CIB_SHARED_VISIBLE_TEXT":
        derivation = "Verbatim shared-visible assertion / not a secret-derived query"
    if redaction:
        if case["corpus"] == "cib":
            if source.get("projection_policy") != "focal_reveal_only_all_other_nonshared_units_remain_opaque":
                raise ValueError("No safe CIB focal-only projection")
            focal = [a for a in proof.get("origin_anchors", []) if a.get("focal") is True]
            if len(focal) != 1:
                raise ValueError("No unique audited focal interval")
            hidden = _anchor(focal[0], text, source)
            derivation = "Authentic paired-release mask / focal source paragraph selected"
        else:
            hidden = _anchor(proof["hidden_span"], text, source)
            derivation = "Synthetic literal source-span mask / not an observed release redaction"
        if not case["focal_marker"] or case["query"].count(case["focal_marker"]) != 1:
            raise ValueError("No unique public focal marker")
        if not reveal_focal:
            text = text[:hidden["start"]] + case["focal_marker"] + text[hidden["end"]:]
        # Return no unmasked anchors, lengths or offsets from the hidden projection.
        marker_end = hidden["end"] if reveal_focal else hidden["start"] + len(case["focal_marker"])
        anchors = [{"start": hidden["start"], "end": marker_end,
                    "text": text[hidden["start"]:marker_end]}]
    elif reveal_focal:
        raise ValueError("Only redaction has a focal reveal")
    full = _full_cable_transcription(case, proof, source, anchors, hidden, reveal_focal)
    if full is not None:
        category.update(source_category="SECRET_CABLE_RAW_BODY_VERIFIED", unit_verified=True, secret_derived=True)
    pdf = None
    if case["corpus"] == "cib":
        release = "earlier" if redaction else "later"
        audit = proof.get("source_origin_audit", {})
        page = proof.get("physical_" + release + "_pdf_page")
        if page is None:
            page = audit.get(release + "_physical_pdf_page")
        if page is not None and (type(page) is not int or page <= 0):
            raise ValueError("Invalid physical PDF page")
        pdf = {"release": release, "page": page}
    return dict(version="privileged-query-origin/6.3", case_id=case_id,
        query_sha256=digest(case["query"]), query=case["query"], document_id=source["document_id"],
        date=source["date"], corpus=case["corpus"], task=case["task"], source_id=source["source_id"],
        classification=source["classification"], eligible_evidence=False, notice=NOTICE,
        query_kind=kind, derivation=derivation, source_review=proof.get("source_review", ""),
        **category,
        text=text, text_sha256=digest(text), anchors=anchors, focal_revealed=redaction and reveal_focal,
        scope=("Audited canonical page projection; other nonshared units remain opaque" if case["corpus"] == "cib"
               else "Audited source segment only; not asserted to be the full original document"),
        full_transcription=full, pdf=pdf, source_mapping=mapping, proof_sha256=proof_hash,
        metadata_gaps=["Per-claim derivation operations/precise quote mappings are not uniformly recorded",
                       "Cable transcription offsets are not physical PDF pages"])


class OriginV63Mixin:
    """Compose before the existing server Handler; does not override study_api."""

    def end_headers(self):
        if unquote(urlsplit(self.path).path) == "/api/origin-v63":
            self.send_header("Cache-Control", "private, no-store")
            self.send_header("Cross-Origin-Resource-Policy", "same-origin")
            self.send_header("X-Content-Type-Options", "nosniff")
        return super().end_headers()

    def do_GET(self):
        parsed = urlsplit(self.path)
        if unquote(parsed.path) != "/api/origin-v63":
            return super().do_GET()
        try:
            params = parse_qs(parsed.query, keep_blank_values=True, strict_parsing=True)
            if (set(params) - {"case_id", "reveal_focal"} or len(params.get("case_id", [])) != 1
                    or any(len(v) != 1 for v in params.values())
                    or params.get("reveal_focal", ["0"])[0] not in {"0", "1"}):
                raise ValueError("Only a published case and explicit focal reveal are accepted")
            packet = origin(self.root, self.published_report(6), params["case_id"][0],
                            reveal_focal=params.get("reveal_focal", ["0"])[0] == "1")
            self.json_response(packet, compress=True)
        except (OSError, ValueError, KeyError, TypeError, IndexError):
            self.send_error(409, "No unchanged audited query provenance matches this request")


def staging_handler():
    from .server import Handler

    base = Handler if issubclass(Handler, OriginV63Mixin) else type(
        "OriginEnabledHandler", (OriginV63Mixin, Handler), {})

    class StagingHandler(base):
        def do_GET(self):
            path = unquote(urlsplit(self.path).path)
            name = "workbench-v6.html" if path in {"/", "/index.html"} else path.removeprefix("/")
            if name in ASSETS:
                directory = self.root / "experiments/ui_v63/workbench"
                return self.file(directory / name, directory)
            return super().do_GET()

    return StagingHandler


if __name__ == "__main__":
    import argparse
    from functools import partial
    from http.server import ThreadingHTTPServer

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8935)
    args = parser.parse_args()
    if args.port == 8930:
        parser.error("The live 8930 service is not a staging target")
    root = Path(__file__).resolve().parents[1]
    with ThreadingHTTPServer(("127.0.0.1", args.port),
            partial(staging_handler(), root=root, workspace=root.parent)) as server:
        print(f"V6.3 workbench staging: http://127.0.0.1:{args.port}/", flush=True)
        server.serve_forever()
