"""Diverse presentation witnesses over an already scoped, bounded projection.

No inference, new graph edges, weighted score or correctness probability.
Source quotations must already be attached by the source-verifying projector.
The full hash-bound snapshot supplies arithmetic, not permission to invent
missing drawing edges or to infer source proof from two eligible endpoints.
"""
from collections import Counter, deque
from copy import deepcopy
from datetime import date
from heapq import heappop, heappush
import math
import re

from matryoshka_demo.io import digest
from . import flow as accounting


VERSION = "diverse-bounded-route-selection/6.6"
RULES = (
    "readable_three_or_four_edges_within_origin_mode_budget",
    "unused_origin", "unused_recorded_starter", "unused_route_mode",
    "minimal_extra_ascent", "least_shared_intermediates", "least_shared_edges",
    "fewest_non_source_hops", "fewest_source_aggregate_hops", "shortest_within_band",
    "unchanged_native_witness_tie", "canonical_id_tie",
)
DISPLAY_EXTRA_HOPS = 2
PATHS_PER_ORIGIN_MODE = 12
EXPANSIONS_PER_ORIGIN_MODE = 512
TOTAL_EXPANSIONS = 8192
MAX_FRONTIER = 4096
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_GROUPS = {"domain", "theme", "community"}


def _hash(value):
    return isinstance(value, str) and bool(_HASH.fullmatch(value))


def _scope(projection):
    scope = projection.get("scope")
    if not isinstance(scope, dict) or not scope.get("corpus") or not scope.get("whole_origin_excluded"):
        raise ValueError("Route selection requires the original case scope")
    date.fromisoformat(scope["strictly_before"])
    if any(not _hash(projection.get(k)) for k in ("source_case_sha256", "source_expanded_sha256")):
        raise ValueError("Route selection requires bound case and expanded sources")
    return scope


def _quote(proof, scope, veto):
    if not isinstance(proof, dict):
        return False
    a, b, text = proof.get("start"), proof.get("end"), proof.get("text")
    try:
        date.fromisoformat(proof.get("date", ""))
    except (TypeError, ValueError):
        return False
    return bool(proof.get("canonical_page_id") and proof.get("document_id")
        and proof["date"] < scope["strictly_before"]
        and proof["document_id"] != scope["whole_origin_excluded"]
        and proof["document_id"] not in veto and _hash(proof.get("page_sha256"))
        and type(a) is int and type(b) is int and 0 <= a < b
        and isinstance(text, str) and b-a == len(text)
        and proof.get("permitted", True) is True
        and proof.get("corpus", scope["corpus"]) == scope["corpus"]
        and (scope["corpus"] == "cib" or
             (proof.get("classification", "CONFIDENTIAL") == "CONFIDENTIAL"
              and not any("NOFORN" in str(h).upper() for h in proof.get("handling", []))
              and not re.search(r"\bNOFORN\b", text, re.I))))


def _kind(left, right):
    a, b = left["id"].startswith("hierarchy:"), right["id"].startswith("hierarchy:")
    if a and b:
        return "SOURCE_AGGREGATE" if left["type"].lower() == right["type"].lower() else "NAVIGATION"
    return "NAVIGATION" if a or b else "SOURCE"


def _movement(edge):
    return (int(edge["kind"] != "SOURCE"),
            int(not edge["source"].startswith("hierarchy:") and edge["target"].startswith("hierarchy:")),
            int(edge["kind"] == "SOURCE_AGGREGATE"), 1)


def _plus(left, right):
    return tuple(a+b for a, b in zip(left, right))


def _efficient(sequence, edges):
    # A real source continuation is not padding merely because a direct source
    # edge exists too. Navigation detours still need to justify their movement.
    for i in range(len(sequence)-2):
        cost = (0, 0, 0, 0)
        for j in range(i+1, len(sequence)):
            cost = _plus(cost, _movement(edges[sequence[j-1], sequence[j]]))
            shortcut = edges.get((sequence[i], sequence[j]))
            if j > i+1 and cost[0] and shortcut and _movement(shortcut) < cost:
                return False
    return True


def _level(node):
    return {"community": 1, "theme": 2, "domain": 3}.get(str(node.get("type", "")).lower(), 0)


def _shape(sequence, nodes):
    """A simple source itinerary, with at most one hierarchy rise then fall."""
    if len(set(sequence)) != len(sequence):
        return None
    communities, last, seen = [], None, set()
    up = down = entries = blocks = 0
    falling = False
    for i, identity in enumerate(sequence):
        node = nodes[identity]
        level = _level(node)
        if level and (not i or not _level(nodes[sequence[i-1]])):
            blocks += 1
        if blocks > 1:
            return None
        if i:
            previous = _level(nodes[sequence[i-1]])
            delta = level - previous
            if delta > 0:
                if falling:
                    return None
                up += delta
            elif delta < 0:
                falling = True
                down -= delta
            entries += int(level > 0 and previous == 0)
        community = identity if level == 1 else node.get("parent_id") if not level else None
        if community not in nodes or _level(nodes[community]) != 1:
            community = None
        if level > 1:
            last = None  # Leaving a community through its parent is not a new alias.
        if community and community != last:
            if community in seen:
                return None
            communities.append(community)
            seen.add(community)
            last = community
    return dict(community_itinerary=communities, ascent=up, descent=down,
                hierarchy_entries=entries, hierarchy_blocks=blocks)


def _mode(sequence, nodes):
    return "hierarchy_bridge" if any(_level(nodes[n]) for n in sequence) else "source_only"


def _family(sequence, nodes, edges):
    """Equivalent source-unit/itinerary witnesses are one display family.

    Labels, alias strings and starter IDs cannot manufacture distinct families.
    Native state identities are not merged or changed by this presentation key.
    """
    shape = _shape(sequence, nodes)
    units = []
    for pair in zip(sequence, sequence[1:]):
        edge = edges[pair]
        if edge["kind"] == "SOURCE":
            unit = tuple(sorted((p["canonical_page_id"], p["start"], p["end"], p["page_sha256"])
                                for p in edge["citations"]))
            if not units or unit != units[-1]:
                units.append(unit)
    return digest((_mode(sequence, nodes), sequence[0], sequence[-1], shape["community_itinerary"], units))


def _distances(nodes, edges, ends, source_only=False):
    reverse = {}
    for (a, b), edge in edges.items():
        if a not in ends and (not source_only or edge["kind"] == "SOURCE"):
            reverse.setdefault(b, []).append(a)
    distances = {n: 0 for n in ends if n in nodes}
    queue = deque(distances)
    while queue:
        current = queue.popleft()
        for previous in reverse.get(current, []):
            if previous not in distances:
                distances[previous] = distances[current] + 1
                queue.append(previous)
    return distances


def _near_paths(nodes, edges, ends, origins, horizon):
    """Bounded A* enumeration, not solver execution or exhaustive graph search.

    The consistent reverse-distance lower bound makes spent slack monotone.
    At most two extra hops beyond the first valid path in an origin/mode are
    explored. This allows genuine parallel source continuations, not cycles.
    All limits below are deterministic display budgets, never kernel parameters.
    """
    distances = _distances(nodes, edges, ends)
    source_distances = _distances(nodes, edges, ends, True)
    adjacency = {}
    for a, b in sorted(edges):
        adjacency.setdefault(a, []).append(b)
    searches = [(origin, mode) for origin in sorted(origins) for mode in ("source_only", "hierarchy_bridge")
                if origin in distances and (mode != "source_only" or origin in source_distances)]
    budget = max(1, min(EXPANSIONS_PER_ORIGIN_MODE, TOTAL_EXPANSIONS // max(1, len(searches))))
    stats = dict(expansions=0, truncated_searches=0, frontier_truncations=0,
                 paths_per_origin_mode=PATHS_PER_ORIGIN_MODE, expansions_per_origin_mode=budget,
                 total_expansion_budget=TOTAL_EXPANSIONS, frontier_limit=MAX_FRONTIER,
                 display_extra_hops=DISPLAY_EXTRA_HOPS, rejections=Counter())
    paths, minima = set(), {}
    for origin, mode in searches:
        lower = source_distances if mode == "source_only" else distances
        frontier = [(lower[origin], 0, (origin,))]
        minimum, found, expanded = None, set(), 0
        while frontier and expanded < budget and len(found) < PATHS_PER_ORIGIN_MODE:
            bound, hops, sequence = heappop(frontier)
            if bound > min(horizon, minimum + DISPLAY_EXTRA_HOPS if minimum is not None else horizon):
                break
            expanded += 1
            current = sequence[-1]
            if current in ends:
                if _mode(sequence, nodes) == mode and _efficient(sequence, edges):
                    minimum = hops if minimum is None else minimum
                    paths.add(sequence)
                    found.add(_family(sequence, nodes, edges))
                elif _mode(sequence, nodes) == mode:
                    stats["rejections"]["AVOIDABLE_NAVIGATION_SHORTCUT"] += 1
                continue  # Readout endpoints stay absorbing in the display search.
            for nxt in adjacency.get(current, []):
                if nxt in sequence or nxt not in lower:
                    stats["rejections"]["REVISIT_OR_UNREACHABLE"] += 1
                    continue
                if mode == "source_only" and edges[current, nxt]["kind"] != "SOURCE":
                    continue
                value = sequence + (nxt,)
                if _shape(value, nodes) is None:
                    stats["rejections"]["REPEATED_COMMUNITY_OR_VERTICAL_OSCILLATION"] += 1
                    continue
                estimate = hops + 1 + lower[nxt]
                if estimate > min(horizon, minimum + DISPLAY_EXTRA_HOPS if minimum is not None else horizon):
                    continue
                if len(frontier) >= MAX_FRONTIER:
                    stats["frontier_truncations"] += 1
                    continue
                heappush(frontier, (estimate, hops + 1, value))
        stats["expansions"] += expanded
        if frontier and (expanded >= budget or len(found) >= PATHS_PER_ORIGIN_MODE):
            stats["truncated_searches"] += 1
        if minimum is not None:
            minima[origin, mode] = minimum
    stats["rejections"] = dict(stats["rejections"])
    return paths, minima, stats


def _best_paths(nodes, edges, ends, horizon, used_interiors, used_edges):
    """Best-at-most-horizon Bellman relaxation over every eligible bounded edge.

    Every cost is a nonnegative count, including a strictly positive hop count.
    Cycles cannot improve a suffix; a globally unchanged mapping is a fixed
    point, so stopping there loses no later improvement or canonical-ID tie.
    Endpoints are absorbing for this presentation search only, not the kernel.
    """
    best = {n: ((0,)*6, (n,)) for n in ends if n in nodes}
    for _ in range(horizon):
        current = dict(best)
        for (a, b), edge in edges.items():
            if a in ends or b not in best:
                continue
            suffix_cost, suffix = best[b]
            cost = _plus((int(b in used_interiors and b not in ends), int((a, b) in used_edges),
                          *_movement(edge)), suffix_cost)
            value = cost, (a,)+suffix
            if a not in current or value < current[a]:
                current[a] = value
        if current == best:
            break
        best = current
    return best


def candidate_routes(projection, candidate, snapshot, route_count=3):
    """Return up to three detached, old-compatible ``represented_routes``.

    Candidate order/rank, endpoint binding and source scope are never changed.
    The caller must recompute its selected-walk aggregate for the returned list.
    Citations are exact inherited edge proofs, not a replacement for DB replay;
    guide/overlay source endpoints still independently revalidate them.
    """
    if type(route_count) is not int or not 1 <= route_count <= 3:
        raise ValueError("Route count must be an integer from one to three")
    saved = candidate.get("represented_routes", candidate.get("routes", []))
    lexical = [deepcopy(r) for r in saved if r.get("route_kind") == "LEXICAL_SOURCE_READOUT"]
    numerical = [r for r in saved if r.get("route_kind") != "LEXICAL_SOURCE_READOUT"]
    if snapshot is None:
        if numerical:
            raise ValueError("Numerical witnesses require a bound full snapshot")
        return lexical[:route_count]
    scope = _scope(projection)
    pins = [projection.get("native_snapshot_sha256"),
            projection.get("recovered_drawing", {}).get("native_snapshot_sha256")]
    pins = [p for p in pins if p is not None]
    if not pins or any(p != snapshot.get("sha256") for p in pins):
        raise ValueError("Projection and full snapshot bindings differ")
    matrix, prior, final, indices = accounting.read_snapshot(snapshot)
    if projection.get("iterations", snapshot["iterations"]) != snapshot["iterations"] or projection.get("alpha", snapshot["alpha"]) != snapshot["alpha"]:
        raise ValueError("Projection and native finite horizon differ")
    ends = list(dict.fromkeys((candidate.get("endpoint_ids") or []) + (candidate.get("source_contributor_ids") or [])))
    if any(n not in indices for n in ends):
        raise ValueError("Candidate endpoint is absent from the bound full snapshot")
    if not ends:
        return lexical[:route_count]
    denominator = float(final[[indices[n] for n in ends]].sum())
    nodes = {}
    for node in projection.get("nodes", []):
        identity = node["id"]
        if identity in nodes:
            raise ValueError("Repeated bounded projection identity")
        if not node.get("layout_only"):
            if identity not in indices:
                raise ValueError("Projection node is absent from the bound native snapshot")
            nodes[identity] = node
    bounded_nodes = dict(nodes)
    horizon = min(snapshot["iterations"], max(0, len(bounded_nodes)-1))
    for identity, node in nodes.items():
        group = str(node.get("type", "")).lower() in _GROUPS
        if identity.startswith("hierarchy:") != group:
            raise ValueError("Canonical state type disagrees with its native identity")
        if group and identity.split(":", 2)[1] != node["type"].lower():
            raise ValueError("Native hierarchy level differs")

    inputs = {}
    starter_ids = set()
    for starter in projection.get("starters", []):
        if starter["id"] in starter_ids or starter.get("kind") == "context":
            raise ValueError("Repeated or whole-query synthetic starter")
        starter_ids.add(starter["id"])
        seen = set()
        for target in starter.get("targets", []):
            identity, mass = target["id"], target["mass"]
            if identity in seen or identity not in indices or not accounting._number(mass):
                raise ValueError("Invalid recorded starter target")
            seen.add(identity)
            if mass > 0:
                inputs.setdefault(identity, []).append(dict(id=starter["id"], kind=starter["kind"],
                    text=starter.get("label", starter["id"]), initial_component_mass=mass))
    for identity, records in inputs.items():
        if not math.isclose(math.fsum(r["initial_component_mass"] for r in records), float(prior[indices[identity]]), rel_tol=1e-11, abs_tol=1e-14):
            raise ValueError("Recorded origin components do not reproduce native prior")
        records.sort(key=lambda r: r["id"])
    veto = set(projection.get("handling_veto_documents", [])) | set(scope.get("handling_veto_documents", []))

    def edge_record(edge):
        a, b = edge.get("source"), edge.get("target")
        if a == b or a not in nodes or b not in nodes or edge.get("kind") not in {"SOURCE", "NAVIGATION", "SOURCE_AGGREGATE"}:
            return None
        transition = float(matrix[indices[a], indices[b]])
        if (not accounting._number(edge.get("transition"), True) or transition <= 0
                or edge["transition"] != transition or edge["kind"] != _kind(nodes[a], nodes[b])):
            raise ValueError("Route hop differs from the actual native transition/type")
        result = deepcopy(edge)
        result["citations"] = [deepcopy(p) for p in edge.get("citations", []) if _quote(p, scope, veto)]
        if result["kind"] == "SOURCE" and not result["citations"]:
            return None
        result["numerical_transition"] = True
        result["source_proof_status"] = ("ELIGIBLE_CANONICAL_SOURCE_UNIT_ATTACHED" if result["kind"] == "SOURCE"
            else "KERNEL_NAVIGATION_NOT_SOURCE_ASSERTION" if result["kind"] == "NAVIGATION"
            else "KERNEL_SOURCE_AGGREGATE_NOT_GROUP_FACT")
        return result

    saved_edges = {}
    for route in numerical:
        for hop in route.get("hops", []):
            record = edge_record(hop)
            if record:
                saved_edges.setdefault((record["source"], record["target"]), record)
    edges = {}
    for edge in projection.get("edges", []):
        pair = edge.get("source"), edge.get("target")
        if pair[0] not in bounded_nodes or pair[1] not in bounded_nodes:
            continue
        # Reuse an already replayed exact pair/type proof, never a node label.
        raw = edge
        if not edge.get("citations") and pair in saved_edges and edge.get("kind") == saved_edges[pair]["kind"]:
            raw = dict(edge, citations=deepcopy(saved_edges[pair]["citations"]))
        record = edge_record(raw)
        if record:
            if pair in edges:
                raise ValueError("Repeated bounded projection edge")
            edges[pair] = record
    pool = {}
    for route in numerical:
        seq = tuple(n["id"] for n in route.get("nodes", []))
        hops = route.get("hops", [])
        if (not seq or len(set(seq)) != len(seq) or len(seq)-1 > snapshot["iterations"]
                or seq[0] not in inputs or seq[-1] not in ends or any(n not in nodes for n in seq)
                or len(hops) != len(seq)-1):
            continue
        if any(h.get("source") != a or h.get("target") != b or (a, b) not in saved_edges or (a, b) not in edges
               for h, a, b in zip(hops, seq, seq[1:])):
            continue
        if _shape(seq, nodes) is not None and _efficient(seq, edges):
            pool.setdefault(seq, route)

    alternatives, minima, search = _near_paths(bounded_nodes, edges, set(ends), inputs.keys() & bounded_nodes.keys(), horizon)
    for seq in alternatives:
        pool.setdefault(seq, None)
    for seq in pool:
        key = seq[0], _mode(seq, nodes)
        minima[key] = min(minima.get(key, len(seq)-1), len(seq)-1)
    pool = {seq: route for seq, route in pool.items()
            if len(seq)-1 <= minima[seq[0], _mode(seq, nodes)] + DISPLAY_EXTRA_HOPS}
    origin_minima = {origin: min(hops for (start, _), hops in minima.items() if start == origin)
                     for origin, _ in minima}
    minimum_ascent = {}
    for seq in pool:
        key = seq[0], _mode(seq, nodes)
        ascent = _shape(seq, nodes)["ascent"]
        minimum_ascent[key] = min(minimum_ascent.get(key, ascent), ascent)
    families = {seq: _family(seq, nodes, edges) for seq in pool}
    available_hops = sorted({len(seq)-1 for seq in pool})
    chosen, used_origins, used_starters, used_interiors, used_edges = [], set(), set(), set(), set()
    seen_sequences, used_families, used_modes = set(), set(), set()
    for _ in range(route_count):
        candidates = {seq: (route, edges) for seq, route in pool.items()
                      if seq not in seen_sequences and families[seq] not in used_families}
        candidates = {seq: record for seq, record in candidates.items() if accounting._walk_component(
            [indices[n] for n in seq], matrix, prior, snapshot["iterations"], snapshot["alpha"], denominator)["component_mass"] > 0}
        if not candidates:
            break

        def order(item):
            seq, (saved_route, edge_map) = item
            starter = min(inputs[seq[0]], key=lambda r: (r["id"] in used_starters, r["id"]))
            pairs = set(zip(seq, seq[1:]))
            movement = (0, 0, 0, 0)
            for pair in zip(seq, seq[1:]):
                movement = _plus(movement, _movement(edge_map[pair]))
            hops, mode = len(seq)-1, _mode(seq, nodes)
            shape = _shape(seq, nodes)
            readable = 0 if 3 <= hops <= 4 else 1 if hops > 4 else 2
            return (readable,
                seq[0] in used_origins, starter["id"] in used_starters, mode in used_modes,
                shape["ascent"]-minimum_ascent[seq[0], mode],
                len(set(seq[1:-1]) & used_interiors), len(pairs & used_edges), movement[0], movement[2], hops,
                not bool(saved_route and saved_route.get("native_witness")), seq)

        seq, (original, edge_map) = min(candidates.items(), key=order)
        selection_key = order((seq, (original, edge_map)))
        path = [indices[n] for n in seq]
        metrics = accounting._walk_component(path, matrix, prior, snapshot["iterations"], snapshot["alpha"], denominator)
        route = deepcopy(original) if original is not None else dict(id="derived-walk:"+digest(seq)[:24],
            route_kind="DERIVED_BOUNDED_PROJECTION_WITNESS", native_witness=False, derived_witness=True)
        native_saved = bool(original is not None and original.get("native_witness"))
        shape, mode, hops = _shape(seq, nodes), _mode(seq, nodes), len(seq)-1
        short_reason = None
        if hops < 3:
            short_reason = ("RECORDED_PRIOR_ALREADY_AT_READOUT_ENDPOINT" if not hops else
                "DISPLAY_SEARCH_BUDGET_EXHAUSTED_NO_COMPARABLE_DISTINCT_LONG_FAMILY" if search["truncated_searches"] or search["frontier_truncations"] else
                "NO_COMPARABLE_DISTINCT_THREE_EDGE_FAMILY_IN_BOUNDED_PROJECTION")
        route.pop("shared_tail_group", None)
        route.update(nodes=[deepcopy(nodes[n]) for n in seq], hops=[deepcopy(edge_map[p]) for p in zip(seq, seq[1:])],
            walk_metrics=metrics, query_inputs=deepcopy(inputs[seq[0]]),
            starter_id=min(inputs[seq[0]], key=lambda r: (r["id"] in used_starters, r["id"]))["id"],
            starter_target_id=seq[0], source_readout_binding=candidate.get("binding"),
            time_consistency_certified=True, saved_native=native_saved,
            provenance_label="Native-saved witness" if native_saved else "Saved positive walk" if original is not None else "Derived projection witness",
            node_ids_outside_drawing=[n for n in seq if n not in bounded_nodes],
            walk_endpoint_ids=list(ends),
            route_selection=dict(version=VERSION, ordered_rules=list(RULES), selection_key=list(selection_key[:-1]),
                family_id="route-family:"+families[seq][:24], family_mode=mode,
                family_basis="NATIVE_ORIGIN_ENDPOINT_COMMUNITY_ITINERARY_AND_CANONICAL_SOURCE_UNITS_NOT_ALIAS_LABELS",
                hops=hops, minimum_hops=minima[seq[0], mode], minimum_hops_basis="SHORTEST_VALID_DISCOVERED_ORIGIN_MODE",
                minimum_hops_any_mode=origin_minima[seq[0]], extra_hops=hops-minima[seq[0], mode],
                extra_hops_any_mode=hops-origin_minima[seq[0]], extra_paths_found=max(0, len(pool)-1),
                vertical_movement=shape, extra_ascent=shape["ascent"]-minimum_ascent[seq[0], mode],
                distinctness=dict(unused_origin=seq[0] not in used_origins, unused_family=True,
                    unused_mode=mode not in used_modes, shared_intermediates=len(set(seq[1:-1]) & used_interiors),
                    shared_edges=len(set(zip(seq, seq[1:])) & used_edges)),
                available_hop_lengths=available_hops, short_reason=short_reason, search_budget=deepcopy(search),
                monotone_progress="SIMPLE_SOURCE_ITINERARY_AND_NONDECREASING_SPENT_SHORTEST_PATH_SLACK_SINGLE_HIERARCHY_RISE_THEN_FALL",
                source_hops=sum(edge_map[p]["kind"] == "SOURCE" for p in zip(seq, seq[1:])),
                native_snapshot_sha256=snapshot["sha256"], source_case_sha256=projection["source_case_sha256"],
                source_expanded_sha256=projection["source_expanded_sha256"], scope=deepcopy(scope),
                metric_endpoint_ids=list(ends), prior_basis="TOTAL_NATIVE_PRIOR_AT_ORIGIN",
                selected_starter_is_attribution=False,
                derived_from_bounded_projection=original is None, max_derived_hops=snapshot["iterations"],
                effective_simple_path_hops=horizon, route_count_is_display_limit=True,
                full_graph_search=False, enumeration_complete=False, independent_explanations=False,
                correctness_probability=False, ranking_changed=False))
        starter = next(r for r in inputs[seq[0]] if r["id"] == route["starter_id"])
        route["starter_target_mass"] = starter["initial_component_mass"]
        proofs = list(route.get("source_quotes", [])) + [p for h in route["hops"] for p in h["citations"]]
        proofs = [p for p in proofs if _quote(p, scope, veto)]
        route["source_quotes"] = list({digest(p): deepcopy(p) for p in proofs}.values())
        route["document_ids"] = sorted({p["document_id"] for p in route["source_quotes"]})
        route["source_quotes_verified"] = bool(route["source_quotes"])
        chosen.append(route); seen_sequences.add(seq); used_origins.add(seq[0]); used_starters.add(route["starter_id"])
        used_families.add(families[seq]); used_modes.add(mode)
        used_interiors.update(seq[1:-1]); used_edges.update(zip(seq, seq[1:]))
    for route in chosen:
        route["route_selection"].update(selected_count=len(chosen), requested_count=route_count,
            unavailable_reason=None if len(chosen) == route_count else "FEWER_DISTINCT_ELIGIBLE_WALKS_FOUND_IN_BOUNDED_PROJECTION")
    return chosen or lexical[:route_count]
