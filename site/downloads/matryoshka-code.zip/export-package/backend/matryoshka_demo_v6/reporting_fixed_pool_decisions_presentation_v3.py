"""New coalesced observer: bounded role, request and outer-attitude decisions.

Native inference and earlier observer versions remain immutable. A counterexample
to NEVER BELIEVE/SAY P establishes the positive attitude, never the truth of P.
"""
from copy import deepcopy
from pathlib import Path

from matryoshka_demo.io import digest, offline, sha
from . import reporting_fixed_pool_decisions_presentation_v2 as previous
from . import reporting_fixed_pool_attitude_counter_projection as attitudes

VERSION = "local-evidence-sufficiency/6.5.9-presentation-role-request-attitude"
ENGINE_VERSION = "fixed-inspected-pool-role-request-outer-attitude/4"
parent = previous.parent
frozen = previous.frozen
roles = previous.roles
requests = previous.requests
_read_binding = previous._read_binding


def _counter_unit(unit, observation):
    result = deepcopy(unit)
    certificates = observation["certificates"]
    assertion = dict(parent_predicate=certificates[0]["parent_predicate"], queried_unbounded_never=True,
        complete_content_signature=deepcopy(certificates[0]["complete_content_signature"]),
        source_positive_attitude_established=True, queried_universal_opposed=True,
        actual_inner_event_established=False)
    checks = [parent._check(key, parent.FIELD_LABELS[key], "conflict" if key == "polarity" else "pass",
        "A complete literal same-holder positive attitude is a counterexample to this unbounded NEVER attitude; inner content remains opaque.")
        for key in parent.FIELDS]
    evidence = [dict(direction="Counterevidence", checks=deepcopy(checks),
        citations=[certificate["citation"]], adapter=attitudes.VERSION,
        certificate=deepcopy(certificate), supplemental_source_evidence=True,
        numerical_transport_claim=False, outer_attitude_only=True,
        actual_inner_event_established=False, surrounding_event_established=False)
        for certificate in certificates]
    requirement = dict(id="attitude:" + unit["id"], kind="OUTER_ATTITUDE_ASSERTION",
        predicate=assertion["parent_predicate"], text=unit["text"],
        actors=[certificates[0]["holder"]["text"]], attitude_assertion=assertion,
        coverage="Missing", direction="Counterevidence", counterevidence=True,
        checks=checks, evidence=evidence, context_citations=[], context_comparisons=[],
        projection=attitudes.KIND,
        aggregation="One actual same-holder attitude with completely retained content defeats the unbounded NEVER claim; no inner event or cross-source fields are certified.")
    result.update(requirements=[requirement], presentation_parent_unit=deepcopy(unit),
        attitude_projection=deepcopy(observation), attitude_assertion=assertion,
        status=parent.INCOMPATIBLE, label="Opposed by eligible evidence", coverage="Missing",
        counterevidence=True, direction="Counterevidence", hypothesis_direction="Opposed",
        derivation="NEW_OUTER_ATTITUDE_COUNTER_ASSERTION_NOT_NATIVE_OR_INNER_EVENT")
    for check in result["checklist"]:
        if check["id"] in {"facts", "conflicts"}:
            check.update(state="conflict", detail="An eligible actual positive outer attitude contradicts the same holder's unbounded NEVER claim; this is not missing inner-event proof.")
    result["what_would_suffice"] = ["This required hypothesis assertion is opposed by a complete eligible source counterexample. The truth or occurrence of the content is not assessed by this certificate."]
    return result


def derive(record, case, eligible_index, *, root=None):
    packet = previous.derive(record, case, eligible_index, root=root)
    previous_identity = digest(packet)
    observations, changed = [], []
    if case["task"] == "hypothesis" and packet["pool_replay"]["applied"]:
        with offline():
            index = parent._pages(eligible_index, case)
            admitted = {pid: index[0][pid] for pid in record["inspected_page_ids"]}
            engine = frozen.Engine(admitted)
            for i, unit in enumerate(packet["decisions"]):
                if not unit["required"]:
                    continue
                # Whole-query and source scope are checked again by the worker.
                # No native status, generated annotation or old leaf match is proof.
                if attitudes.query_spec(case, record["plan"], unit["id"], engine=engine) is None:
                    continue
                observation = attitudes.observe(case, record["plan"], unit["id"], admitted, index, engine=engine)
                observations.append(observation)
                if (observation["status"] == "ATTITUDE_COUNTER_ONLY" and observation["certificates"]
                        and not observation["signed_conflict_citations"] and not unit["source_failures"]
                        and all(c["state"] == "pass" for c in unit["checklist"] if c["id"] in {"provenance", "binding"})):
                    packet["decisions"][i] = _counter_unit(unit, observation)
                    changed.append(unit["id"])
            if changed:
                packet["atoms"] = {u["id"]: u for u in packet["decisions"]}
                previous.previous._overall(packet, case["task"])
                units = [u for u in packet["decisions"] if u["required"]]
                opposed = [u["id"] for u in units if u["decisive_counter"]]
                packet["overall"].update(opposed_components=opposed,
                    supported_components=[u["id"] for u in units if u["status"] == parent.BACKED],
                    unresolved_components=[u["id"] for u in units if not u["decisive_counter"] and u["status"] != parent.BACKED],
                    opposition_is_not_positive_coverage=True)
    packet.update(version=VERSION, decision_engine=ENGINE_VERSION,
        presentation_parent_version=previous.VERSION, presentation_parent_sha256=previous_identity,
        attitude_counter_observer=dict(version=attitudes.VERSION, observations=observations,
            changed_atom_ids=changed, raw_source_rechecked=True, native_labels_read=False,
            whole_attitude_requirement=True, prior_leaf_requirements_preserved=True,
            actual_inner_event_established=False, new_retrieval=False))
    packet["limitations"].append("A positive literal outer BELIEVE/SAY assertion can oppose the same holder's unbounded NEVER claim only within the observer's complete scoped-content grammar. Opposed is not Established positive coverage and never establishes the inner event.")
    return packet


def evaluate(root, report, record):
    from matryoshka_demo.corpus_explorer_v3 import _connection
    root = Path(root); case = parent._case(record["case"])
    rows = [r for r in report["cases"] if r["case"]["case_id"] == case["case_id"]]
    if len(rows) != 1 or parent._case(rows[0]["case"]) != case:
        raise ValueError("Coalesced presentation case differs from published query")
    reference = report["graph_indexes"][case["corpus"]]
    binding, byte_sha = _read_binding(root, report["source_binding"]["sha256"])
    if (record.get("exploration_index_ref") != reference
            or record.get("source_binding_sha256") != report["source_binding"]["sha256"]
            or binding != report["source_binding"]):
        raise ValueError("Coalesced presentation source index or binding changed")
    with offline():
        db = _connection(root, reference)
        try: packet = derive(record, case, db, root=root)
        finally: db.close()
    packet["binding"].update(source_index_sha256=reference["sha256"], source_binding_sha256=report["source_binding"]["sha256"])
    if sha(root / "data/bindings.json") != byte_sha: raise ValueError("Source binding changed during derivation")
    return packet
