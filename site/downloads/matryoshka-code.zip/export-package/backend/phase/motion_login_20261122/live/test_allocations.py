"""API0 operator-allocation checks; never changes real state or receipts."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from allocations import allocate, inspect_allocations


class AllocationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.state = Path(self.temporary.name) / 'state'
        self.api = Path(self.temporary.name) / 'api'
        self.state.mkdir(mode=0o700)
        self.api.mkdir()
        self.base = self.state / 'paid-envelope.json'
        self.base.write_text(json.dumps(dict(version='matryoshka-live-paid-envelope/1', baseline_usd=10, max_spend_usd=1)))
        (self.api / 'authorization.json').write_text('{"ceiling_usd":50}')
        self.original = self.base.read_bytes()

    def inspect(self, total=12):
        return inspect_allocations(self.state, self.api, total, 11)[0]

    def test_no_grant_preserves_exhausted_original(self):
        self.assertEqual(self.inspect(), 11)

    def test_explicit_grant_survives_restart_without_rebasing(self):
        allocate(self.state, self.api, 1, lambda: 12)
        self.assertEqual(self.inspect(), 13)
        self.assertEqual(self.inspect(12.9), 13)
        self.assertEqual(self.base.read_bytes(), self.original)

    def test_additional_records_preserve_chain_and_private_modes(self):
        allocate(self.state, self.api, 1, lambda: 12)
        allocate(self.state, self.api, .5, lambda: 13)
        self.assertEqual(self.inspect(13), 13.5)
        rows = sorted((self.state / 'additional-allocations').iterdir())
        self.assertEqual(len(rows), 2)
        self.assertEqual(json.loads(rows[1].read_bytes())['previous_sha256'], hashlib.sha256(rows[0].read_bytes()).hexdigest())
        self.assertTrue(all(p.stat().st_mode & 0o777 == 0o600 for p in rows))

    def test_rejects_unbounded_or_invalid_amounts(self):
        for amount in (0, -1, 1.01, float('nan'), float('inf'), True):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                allocate(self.state, self.api, amount, lambda: 12)
        with self.assertRaises(ValueError):
            allocate(self.state, self.api, 1, lambda: 49.5)

    def test_rejects_ledger_reset_and_tampered_chain(self):
        allocate(self.state, self.api, 1, lambda: 12)
        with self.assertRaises(ValueError):
            self.inspect(11)
        path = next((self.state / 'additional-allocations').iterdir())
        value = json.loads(path.read_bytes())
        value['previous_sha256'] = '0' * 64
        path.write_text(json.dumps(value))
        with self.assertRaises(ValueError):
            self.inspect()

    def test_rejects_changed_envelope_or_authorization(self):
        allocate(self.state, self.api, 1, lambda: 12)
        self.base.write_text(self.original.decode() + '\n')
        with self.assertRaises(ValueError):
            self.inspect()
        self.base.write_bytes(self.original)
        (self.api / 'authorization.json').write_text('{"ceiling_usd":51}')
        with self.assertRaises(ValueError):
            self.inspect()

    def test_rejects_nonprivate_or_symlink_grants(self):
        allocate(self.state, self.api, 1, lambda: 12)
        path = next((self.state / 'additional-allocations').iterdir())
        path.chmod(0o644)
        with self.assertRaises(ValueError):
            self.inspect()
        path.chmod(0o600)
        target = self.state / 'moved.json'
        path.rename(target)
        path.symlink_to(target)
        with self.assertRaises(ValueError):
            self.inspect()

    def test_server_enforces_existing_and_new_allocations_without_rebasing(self):
        import server
        from types import SimpleNamespace
        session = object()
        authentication = SimpleNamespace(describe=lambda _: {'expires_in_seconds': 900})
        total = [12.0]
        with patch.object(server, 'STATE', self.state), patch.object(server, 'API_ROOT', self.api), \
                patch.object(server, 'ledger_total', side_effect=lambda: total[0]), \
                patch('scope_defaults.corpus_defaults', return_value=None), \
                patch.object(server, 'headroom'), patch.dict(os.environ, {'OPENAI_API_KEY': 'synthetic-test-only'}):
            config = server.Config(state=self.state, execute_paid=True)
            jobs = server.Jobs(config, authentication)
            self.assertEqual(jobs.absolute_cap, 11)
            self.assertFalse(jobs.health(session)['ready'])
            jobs.close()
            allocate(self.state, self.api, 1, lambda: total[0])
            jobs = server.Jobs(config, authentication)
            self.assertEqual(jobs.absolute_cap, 13)
            self.assertTrue(jobs.health(session)['ready'])
            self.assertEqual(jobs.health(session)['remaining_live_allowance_usd'], 1)
            jobs.close()
            total[0] = 12.75
            jobs = server.Jobs(config, authentication)
            self.assertEqual(jobs.absolute_cap, 13)
            self.assertEqual(jobs.health(session)['remaining_live_allowance_usd'], .25)
            jobs.close()


if __name__ == '__main__':
    unittest.main()
