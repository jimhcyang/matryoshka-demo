"""Explicit local Live grants; the original envelope and API receipts stay intact."""
from datetime import datetime, timezone
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import secrets
import stat

VERSION = 'matryoshka-live-additional-allocation/1'
FIELDS = {'version', 'baseline_usd', 'amount_usd', 'base_envelope_sha256',
          'authorization_sha256', 'previous_sha256', 'created_utc'}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value):
    return type(value) in (int, float) and math.isfinite(value)


def inspect_allocations(state, api_root, total, retained_ceiling):
    state, api_root = Path(state), Path(api_root)
    envelope_hash = sha(state / 'paid-envelope.json')
    authorization_hash = sha(api_root / 'authorization.json')
    ceiling, previous, baseline = retained_ceiling, envelope_hash, 0.0
    directory = state / 'additional-allocations'
    if directory.is_symlink():
        raise ValueError('Unsafe allocation directory')
    if not directory.exists():
        return ceiling, previous
    if not directory.is_dir() or directory.stat().st_mode & 0o077:
        raise ValueError('Allocation directory must be private')
    for path in sorted(directory.iterdir()):
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_mode & 0o077
                or info.st_uid != os.getuid() or info.st_size > 2048
                or path.suffix != '.json'):
            raise ValueError('Unsafe allocation file')
        value = json.loads(path.read_bytes())
        if (set(value) != FIELDS or value['version'] != VERSION
                or value['base_envelope_sha256'] != envelope_hash
                or value['authorization_sha256'] != authorization_hash
                or value['previous_sha256'] != previous
                or not number(value['baseline_usd']) or not baseline <= value['baseline_usd'] <= total
                or not number(value['amount_usd']) or not 0 < value['amount_usd'] <= 1
                or value['baseline_usd'] + value['amount_usd'] > 50
                or not isinstance(value['created_utc'], str)):
            raise ValueError('Invalid retained Live allocation')
        datetime.fromisoformat(value['created_utc'])
        ceiling = max(ceiling, value['baseline_usd'] + value['amount_usd'])
        previous, baseline = sha(path), value['baseline_usd']
    return min(50.0, ceiling), previous


def allocate(state, api_root, amount, total_reader):
    """Called only by an explicit operator CLI flag, never login or startup."""
    if not number(amount) or not 0 < amount <= 1:
        raise ValueError('Additional Live allocation must be positive and at most $1')
    state, api_root = Path(state), Path(api_root)
    if not state.is_dir() or state.is_symlink():
        raise ValueError('Existing private Live state required')
    with (state / 'allocation.lock').open('a+') as lock, (state / 'server.lock').open('a+') as server_lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        fcntl.flock(server_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        total = total_reader()
        base = json.loads((state / 'paid-envelope.json').read_bytes())
        if (base.get('version') != 'matryoshka-live-paid-envelope/1'
                or not number(base.get('baseline_usd')) or not 0 <= base['baseline_usd'] <= total
                or not number(base.get('max_spend_usd')) or not 0 < base['max_spend_usd'] <= 1
                or total + amount > 50):
            raise ValueError('Invalid envelope or insufficient cumulative allowance')
        _, previous = inspect_allocations(state, api_root, total, base['baseline_usd'] + base['max_spend_usd'])
        directory = state / 'additional-allocations'
        directory.mkdir(mode=0o700, exist_ok=True)
        value = dict(version=VERSION, baseline_usd=total, amount_usd=amount,
                     base_envelope_sha256=sha(state / 'paid-envelope.json'),
                     authorization_sha256=sha(api_root / 'authorization.json'),
                     previous_sha256=previous, created_utc=datetime.now(timezone.utc).isoformat())
        name = f'{len(list(directory.iterdir())):06d}-{secrets.token_hex(8)}.json'
        descriptor = os.open(directory / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(descriptor, 'w') as stream:
            json.dump(value, stream, sort_keys=True, allow_nan=False)
            stream.flush()
            os.fsync(stream.fileno())
        return value
