# Live Execution Contract

Scope: private password sessions, the closed analyst request, explicitly bound
source admission, deterministic local execution and a separate post-run digest.
Historical outputs, production state, paid authorization and corpus-resource
bindings are not replaced or copied.

## Login And Sessions

`POST /live-api/session/login` accepts exactly `{ "password": "..." }`,
`Content-Type: application/json` and `X-Live-Request: 1`. No bearer/cookie is
accepted on login. Body <=1024 bytes; password <=256 UTF-8 bytes. Origin and
Host must be exact approved values, and the HTTP/HTTPS proxy boundary must pass
BEFORE password work. Success is HTTP 200 with:

```json
{"version":"matryoshka-live-session/1","access_token":"<random URL-safe token>","token_type":"Bearer","expires_in_seconds":900}
```

No response contains an API key, password or password verifier. Login failure
is a fixed 400/401/403/429/503 code, never an echoed password. HTTP 429 includes
bounded `Retry-After`. Rate limits precede scrypt: five attempts/peer/minute,
12 global/minute, one concurrent verification and at most eight active sessions.
Failures use bounded exponential backoff without sleeping request threads.

Bearers are random 256-bit values, server-stored by hash, bound to the exact
Origin and expire absolutely after at most 900 seconds. There is no cookie,
refresh endpoint or browser persistent login. `GET /live-api/session` returns
authentication/expiry state with the bearer. `POST /live-api/session/logout`
takes bearer plus `{}` and revokes that session, cancelling unfinished owned
jobs without refunding incurred/uncertain provider billing.

Provisioning uses a private `LIVE_PASSWORD_VERIFIER` OR `LIVE_LOGIN_PASSWORD`
server environment, never both. No default exists. Blank, control/format,
low-variety/repeating and known-demo passwords are rejected; serialized
verifiers reject the same finite known-default list. Strong password whitespace
is significant and preserved. The interactive generator requires hidden input
and captured output rather than printing a private verifier to the terminal.
The local operator launcher stores only a private salted verifier. Its legacy
configuration migration removes the recoverable password, preserving the same
verifier and login. First-time initialization requires hidden terminal input.

## Existing Live API Is Preserved

Health and all existing job routes still require `Authorization: Bearer ...`,
`X-Live-Request: 1`, exact Origin/Host admission and JSON-only bounded writes.
Jobs additionally belong to their authenticating session. Another session gets
404 for status, result, cancel and retry, even if it knows the opaque job ID.
Logout/expiry do not erase jobs or billing receipts; they revoke API access.
There is no cross-session account recovery or global job listing.

Existing `LIVE_SESSION_TOKEN` compatibility is optional and advanced-only. It
has the same short maximum lifetime, binds to the first approved Origin, and
logout revokes it for this server process. It never bypasses job ownership.

All original arbitrary-query field restrictions, task/corpus allowlists,
resource pins, one-worker/resource limits, exact
model cache, query-only planning and Redaction-only model readings remain.
Authentication does not enable paid execution: explicit `--execute-paid` and
the existing key/resource/budget checks are still required.

## Analyst-Written Questions

The Live request may omit `as_of` and `excluded_origin`, or send either as an
empty string. The other four fields remain mandatory and unknown fields are
rejected. Blank dates use the selected corpus's pinned eligible-source range.
The UI labels its date **Evidence through**, includes that selected day, and
sends the following day as the API's unchanged strict `as_of` boundary. An API
caller supplying a nonempty `as_of` still means strictly before that day.

Blank document exclusion is normalized to a deterministic
`live-analyst-origin:<digest>` bookkeeping ID. It is not a historical document;
the snapshot generator verifies that no bound source document uses this reserved
namespace. This keeps native case/cache/verifier contracts complete without
asking the analyst to invent a source ID. `source_scope.origin_kind` is then
`analyst_authored` and both `document_exclusion` and `excluded_whole_origin`
are null. The canonical request/native case retains the internal ID for exact
DTO/cache binding; it never claims to be a historical source.

A supplied cable source ID excludes all pages of that document. A CIB source
ID does not exclude its earlier/both release: the trusted server-only policy
`live_before_with_earlier_origin` admits that version through the displayed day,
while later/SECRET pages remain ineligible. The full descriptor is bound in
native configuration, result and source-scope metadata; a client cannot submit
or replace it. The exclusive API `as_of` date is not incremented a second time.
Missing historical policy metadata still means the old strict-prior policy.
Visibility/classification/handling vetoes and source/citation/rank verification
remain independent checks. Default ranges come from the
actual `SourcePolicy` over the complete hash-verified page indexes, not wall-clock
dates or a manually chosen historical endpoint. Metadata has a content pin and
exact execution-resource binding; stale or missing defaults fail closed.

## Transport Boundary

Default server bind remains 127.0.0.1. Password login over direct HTTP is allowed
only from a loopback frontend; public Pages must use an explicitly configured
HTTPS backend or open the local companion. Remote mode requires an exact
`--public-origin https://...` plus `--trusted-proxy 127.0.0.1`, a matching public
Host and one trusted `X-Forwarded-Proto: https`. The proxy must overwrite/remove
client forwarding headers. Client IP rate identity remains the TCP peer, not
untrusted forwarded text. Plain remote HTTP and unconfigured forwarded headers
fail closed. TLS certificates and hosting are operator responsibilities.

Originless same-origin browser GETs still require the bearer, custom header,
`Sec-Fetch-Site: same-origin`, `Sec-Fetch-Mode: cors|same-origin` and no cookie.
After validating the trusted TLS proxy and public Host, the inferred Origin is
the exact HTTPS public origin, not an invented HTTP origin. No-Origin POSTs are
not admitted. CORS has no wildcard or credentialed cookie permission.

## Frontend Hooks And Expected Behavior

- Primary: `#login-form`, `#login-password`, `#login-submit`, `#logout`.
- Status: `#availability`, `#session-status`; input/result hooks are unchanged.
- Closed `#connection`: nonsecret `#backend` URL. Closed nested
  `#legacy-connection`: optional `#capability`, `#connect` advanced flow.
- Public `meta[name=live-backend]` is blank by default. No backend request or
  password transmission occurs until configuration and a deliberate login.
- A password login returns only authentication state to UI; the raw bearer
  stays private inside `LiveClient`. Password fields clear immediately.
- `sk-...`, `OPENAI_API_KEY=...`, Bearer/Authorization forms, including within
  whitespace/backticks or elsewhere in the field, are rejected BEFORE transport
  for BOTH password and legacy forms. The server independently rejects them.
  This is detection, not trimming or rewriting a legitimate password.
- Password POST uses native fetch with `credentials: omit`, `redirect: error`,
  `referrerPolicy: no-referrer`; the Live page does not load the replay shim.
  Protected job APIs keep scoped XHR compatibility. No global fetch override.
- `#question-fields`/`#run` stay disabled until logged in AND execution-ready.
  Synthetic fixture mode and disabled inference remain explicitly labeled.
- Explicit logout clears displayed result/session state and revokes server
  access. Expiry returns to login; reload does not restore a secret from storage.

No key reconstruction, encrypted/public fragments, public model credentials,
anonymous paid endpoint or browser-hosted inference is implemented. GitHub
Pages cannot host the Python engine; a 128 MiB frontend worker is not a backend
for a 4+ GiB engine. Remote hosting is not provisioned by this patch.

## State, Evidence And Review

Production state remains the original
`src-demo-day/phase/interactive_release_20261122/live/state/`. Existing stored
paid-envelope baseline and the shared narrative API $50 ledger are read in place;
missing state/envelope fails closed, never initializes a new authorization.
Fixture state MUST be separate and temporary. No old QA/state/raw job is copied.

The verifier checks the declared source policy against both native configuration
and result, as well as exact source hashes, spans and inspected-page inventory.
All direction/unit/candidate/source/rank and invented-route guards remain.
The existing real smoke envelope is used ONLY as
an API0 verification/display fixture, not an input to a new inference request.
The separate 50-100 word digest is generated only after a sealed local result.
Its source labels, quotations, native checksum and resource binding are verified;
it cannot revise the decision or ranking. A failed digest leaves local results
intact and explicitly unavailable rather than substituting generated commentary.
Terminal evidence/fit v2 scores are saved by the native executor, never inferred
from display rank. Owner tests and hashes are a handoff for independent review,
not final frozen clearance or publication.
