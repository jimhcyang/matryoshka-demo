"""Typed source-policy extension of unchanged V7 transformation/review algorithms.

Only a trusted prepared intake + SourcePolicy can authorize a non-ordinary edition.
No source field is rewritten and no historical V7 artifact is upgraded.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

from contract import ROOT, sha
from source_runtime import require

VERSION = "source-realized-fill-proposals/scoped-policy-3"
CURRENT_VERSION = "source-realized-fill-proposals/current-readings-2"


def project_page(base, native, policy, page, position):
    """Optional metadata projection, never a new eligibility/absence certificate."""
    from matryoshka_next.facts import SourcePolicy
    require(type(policy) is SourcePolicy and policy.case == native["case"], "TRUSTED_PROJECTION_POLICY_REQUIRED")
    ids = native["result"]["inspected_page_ids"]
    require(type(position) is int and 0 <= position < len(ids) and ids[position] == page["id"],
        "PROJECTION_PAGE_NOT_INSPECTED")
    pi = policy.corpus.page_index.get(page["id"])
    require(pi is not None and policy.corpus.pages[pi] == page and policy.bound_pages.get(page["id"]) == page
        and sha(page["text"]) == page["source_sha256"], "PROJECTION_CANONICAL_PAGE_CHANGED")
    require(policy.allowed(pi), "PROJECTION_SOURCE_INELIGIBLE")
    handling = page.get("handling", [])
    require(isinstance(handling, list) and all(isinstance(h, str) for h in handling), "PROJECTION_HANDLING_MALFORMED")
    return base.W.V2.project_page(dict(page, handling=deepcopy(handling)), position)


def current_namespace(base):
    from source_readings import project, schema
    spec = importlib.util.spec_from_file_location("_live_current_v7_algorithm", base.__file__)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    value.P = SimpleNamespace(READING_SCHEMA=schema(), project_readings=project)
    return value


def current_protocol(base, native, policy):
    from matryoshka_demo.source_view_policy import LATER_RELEASE_INCLUSIVE, SUPPLIED_DOCUMENTS_INCLUSIVE
    from source_readings import project
    if policy.source_view_policy in {LATER_RELEASE_INCLUSIVE, SUPPLIED_DOCUMENTS_INCLUSIVE}:
        return ScopedProtocol(base, native, policy)
    value = current_namespace(base)
    declared, checksum = project(native["plan"]["readings_packet"], native["public_case"]), sha(native)
    original = value.verify_packet
    value.VERSION = CURRENT_VERSION
    def verify(packet):
        require(sha(native) == checksum, "CURRENT_READING_INTAKE_CHANGED")
        data, binding = original(packet)
        require(data["case"] == native["public_case"] and data["reading"] in declared,
            "CURRENT_DECLARED_READING_CHANGED")
        ids = native["result"]["inspected_page_ids"]
        for source in data["sources"]:
            position = source["inspected_position"]
            require(type(position) is int and 0 <= position < len(ids), "CURRENT_SOURCE_POSITION_CHANGED")
            pid = ids[position]
            pi = policy.corpus.page_index.get(pid)
            require(pi is not None and source == project_page(value, native, policy, policy.corpus.pages[pi], position),
                "CURRENT_SOURCE_PROJECTION_CHANGED")
        return data, binding
    value.verify_packet = verify
    return value


class ScopedProtocol:
    def __init__(self, base, native, policy):
        from matryoshka_next.facts import SourcePolicy
        from matryoshka_demo.source_view_policy import (packet_policy, descriptor,
            LATER_RELEASE_INCLUSIVE, SUPPLIED_DOCUMENTS_INCLUSIVE)
        require(type(policy) is SourcePolicy and policy.case == native["case"], "TRUSTED_SCOPED_SOURCE_POLICY_REQUIRED")
        view = packet_policy(native)
        require(view is policy.source_view_policy and view in {LATER_RELEASE_INCLUSIVE, SUPPLIED_DOCUMENTS_INCLUSIVE},
            "EXPLICIT_NONORDINARY_POLICY_REQUIRED")
        context = native["execution_context"]
        require(context["version"] == "pinned-execution-context/1" and context["index_ref"] == native["binding"],
            "SCOPED_INDEX_BINDING_CHANGED")
        for ref in (context["registry_ref"], context["index_ref"]):
            path = Path(ref["path"])
            path = ROOT.parent / path if path.parts[0] == ROOT.name else ROOT / path
            require(path.resolve() == path and path.is_relative_to(ROOT) and path.is_file(), "SCOPED_RESOURCE_PATH")
            with path.open("rb") as stream:
                require(hashlib.file_digest(stream, "sha256").hexdigest() == ref["sha256"], "SCOPED_RESOURCE_HASH_CHANGED")
        require(native["native_checksum"] == sha(native["result"]) and native["answers_read"] is False
            and native["grades_read"] is False and native["query_only_inference"] is True, "SCOPED_INTAKE_SEAL")
        self.native, self.policy, self.native_sha = native, policy, sha(native)
        self.authority = dict(version="trusted-source-proposal-policy-binding/1",
            source_view_policy=descriptor(view), execution_context=deepcopy(context),
            intake_sha256=self.native_sha, query_sha256=sha(native["public_case"]["query"]))
        # An isolated algorithm namespace prevents policy hooks leaking across jobs.
        # The original module/file and every original V7 packet remain untouched.
        self.impl = current_namespace(base)
        self.impl.VERSION = VERSION
        self.original_packet = self.impl.packet
        self.impl.packet, self.impl.verify_packet = self.packet, self.verify_packet
        self.VERSION, self.W, self.P = VERSION, self.impl.W, self.impl.P
        self.declared = self.P.project_readings(native["plan"]["readings_packet"], native["public_case"])
        for key in ("PROMPT", "REVIEW_PROMPT", "RESPONSE_SCHEMA", "REVIEW_SCHEMA"):
            setattr(self, key, getattr(self.impl, key))

    def packet(self, payload, partition):
        require("source_authority" not in payload or payload["source_authority"] == self.authority,
            "PROPOSAL_AUTHORITY_CHANGED")
        return self.original_packet(dict(payload, source_authority=deepcopy(self.authority)), partition)

    def verify_packet(self, value):
        from matryoshka_demo.source_view_policy import descriptor
        W = self.W
        require(sha(self.native) == self.native_sha and value.get("version") == VERSION, "SCOPED_INTAKE_CHANGED")
        data = deepcopy(value["model_input"])
        binding = data.pop("binding")
        require(set(data) == {"version", "case", "reading", "query_only_facts", "sources", "partition", "source_authority"}
            and data["version"] == VERSION and data["source_authority"] == self.authority
            and data["case"] == self.native["public_case"] and set(data["case"]) == W.V1.PUBLIC,
            "SCOPED_PUBLIC_PACKET_CHANGED")
        require(self.authority["source_view_policy"] == descriptor(self.policy.source_view_policy), "SCOPED_POLICY_CHANGED")
        W.V1.Draft202012Validator(self.P.READING_SCHEMA).validate(data["reading"])
        require(data["reading"] in self.declared, "SCOPED_DECLARED_READING_CHANGED")
        allowed = {"id", "text", "kind", "required", "polarity", "modality", "query_spans"}
        for fact in data["query_only_facts"]:
            require(set(fact) <= allowed, "NONPUBLIC_FACT_FIELD")
            for span in fact.get("query_spans", []):
                W.V1.literal_span(span, data["case"]["query"])
        require(bool(data["sources"]) and len({p["page_id"] for p in data["sources"]}) == len(data["sources"]),
            "SCOPED_SOURCE_POOL_EMPTY_OR_DUPLICATE")
        ids = self.native["result"]["inspected_page_ids"]
        for page in data["sources"]:
            pid, position = page["page_id"], page["inspected_position"]
            require(type(position) is int and 0 <= position < len(ids) and ids[position] == pid,
                "SCOPED_SOURCE_NOT_INSPECTED")
            pi = self.policy.corpus.page_index.get(pid)
            require(pi is not None and self.policy.allowed(pi), "SCOPED_SOURCE_INELIGIBLE")
            actual = self.policy.corpus.pages[pi]
            require(self.policy.bound_pages.get(pid) == actual and sha(actual["text"]) == actual["source_sha256"],
                "SCOPED_CANONICAL_SOURCE_CHANGED")
            require(page == project_page(self.impl, self.native, self.policy, actual, position), "SCOPED_RAW_EDITION_OR_METADATA_CHANGED")
        require(binding == dict(case_id=data["case"]["case_id"], reading_id=data["reading"]["id"],
            input_sha256=W.digest(data), partition_index=data["partition"]["index"], partition_count=data["partition"]["count"])
            and value["input_sha256"] == binding["input_sha256"]
            and value["body_sha256"] == hashlib.sha256(W.encoded(self.impl.body(value["model_input"]))).hexdigest(),
            "SCOPED_PACKET_DIGEST_CHANGED")
        return data, binding

    def validate_response(self, packet, response):
        return dict(self.impl.validate_response(packet, response),
            version="source-realized-proposal-validation/scoped-policy-1", source_authority=deepcopy(self.authority))

    def review_packet(self, packet, response):
        return self.impl.review_packet(packet, response)

    def validate_review(self, packet, response):
        return dict(self.impl.validate_review(packet, response),
            version="reviewed-contextual-realized-fill-proposals/scoped-policy-1", source_authority=deepcopy(self.authority))
