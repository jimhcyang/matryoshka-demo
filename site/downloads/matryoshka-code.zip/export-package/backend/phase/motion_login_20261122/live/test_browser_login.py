"""Managed shell API0: password UX, replay-safe transport and retained R7 evidence."""
import hashlib
import json
from pathlib import Path
import tempfile
import threading

from playwright.sync_api import expect, sync_playwright

from auth import PasswordVerifier
from contract import HERE, PHASE, ROOT, STATE, read_json, write_json
from server import Config, create_server
from test_auth import PASSWORD, LEGACY


def main():
    checks, blocked = [], []
    old = ROOT / 'phase/interactive_release_20261122/live'
    old_files = [old / name for name in ('server.py', 'contract.py', 'worker.py')]
    old_files += [STATE / 'paid-envelope.json']
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in old_files}
    site = PHASE / 'stage/site'
    # Authentication is allowed to change; the reviewed evidence verifier is not.
    baseline_adapter = (ROOT / 'phase/interactive_release_20261122/stage/site/live-result-adapter.js').read_text()
    adapter = (site / 'live-result-adapter.js').read_text()
    assert adapter.split('async function textDigest', 1)[1] == baseline_adapter.split('async function textDigest', 1)[1]
    checks.append('R7 evidence/native/source verifier and handoff tail remain byte-identical')
    with tempfile.TemporaryDirectory(prefix='browser-login-', dir=HERE) as folder:
        service = create_server(Config(fixture=True, state=Path(folder)), LEGACY,
                                verifier=PasswordVerifier.make(PASSWORD), port=0)
        thread = threading.Thread(target=service.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(service.server_port) + '/matryoshka-demo/'
        origin = base.split('/matryoshka-demo/')[0]
        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(headless=True)
                context = browser.new_context(viewport={'width': 1440, 'height': 1000}, reduced_motion='reduce')
                def route(request):
                    if request.request.url.startswith(origin + '/'):
                        request.continue_()
                    else:
                        blocked.append(request.request.url.split('?')[0]); request.abort()
                context.route('**/*', route)
                page = context.new_page()
                errors, requests = [], []
                page.on('pageerror', lambda error: errors.append(str(error)))
                page.on('request', lambda request: requests.append((request.method, request.url.split('?')[0])))
                page.goto(base + 'live.html', wait_until='networkidle')
                expect(page.locator('#availability')).to_contain_text('unavailable')
                assert not page.locator('#connection').evaluate('n=>n.open')
                assert page.locator('#run').is_disabled()
                assert not any('/live-api/' in url for _, url in requests)
                assert not page.evaluate('()=>Boolean(window.PublicReplay)||localStorage.length||sessionStorage.length')
                checks.append('no automatic auth/backend requests, private storage or expanded connection settings')
                count = len(requests)
                credential_forms = ['sk-fixture-not-a-real-provider-key-123456', ' sk-fixture-not-real ',
                    '`sk-fixture-not-real`', 'OPENAI_API_KEY=sk-fixture-not-real',
                    'prefix OPENAI_API_KEY="sk-fixture-not-real" suffix', 'prefix `sk-fixture-not-real` suffix']
                for value in credential_forms:
                    page.locator('#login-password').fill(value)
                    page.locator('#login-submit').click()
                    expect(page.locator('#availability')).to_contain_text('not a model API key')
                    assert page.locator('#login-password').input_value() == '' and len(requests) == count
                page.locator('#connection > summary').click()
                page.locator('#legacy-connection > summary').click()
                for value in credential_forms:
                    page.locator('#capability').fill(value)
                    page.locator('#connect').click()
                    expect(page.locator('#availability')).to_contain_text('not a model API key')
                    assert page.locator('#capability').input_value() == '' and len(requests) == count
                checks.append('primary password and advanced capability reject provider-shaped keys before transport')
                page.locator('#login-password').fill(PASSWORD)
                page.locator('#login-submit').click()
                page.locator('#question-fields:not([disabled])').wait_for(state='visible')
                assert page.locator('#login-password').input_value() == ''
                assert not page.locator('#connection').evaluate('n=>n.open')
                assert not page.evaluate('()=>localStorage.length||sessionStorage.length')
                expect(page.locator('#availability')).to_contain_text('NOT inference')
                checks.append('real scrypt password login returns a memory-only session; fixture mode remains explicit')
                page.locator('#query').fill('The council discussed trade.')
                page.locator('#as-of').fill('1965-07-02')
                page.locator('#excluded-origin').fill('fixture-analyst-origin')
                page.locator('#run').click()
                page.locator('#result').wait_for(state='visible', timeout=15000)
                expect(page.locator('#result-status')).to_have_text('FIXTURE_ONLY')
                checks.append('password-authenticated fixture submit/status/result is API0, not historical inference')
                for width in (1440, 390):
                    page.set_viewport_size({'width': width, 'height': 1000})
                    assert page.evaluate('()=>document.documentElement.scrollWidth<=innerWidth+2')
                checks.append('1440 desktop and 390 mobile have no outer horizontal overflow')

                # A retained actual envelope is only a verifier/display fixture,
                # never submitted to an inference job or copied into this phase.
                smoke = read_json(old / 'qa/real-smoke.json')
                envelope = read_json(STATE / 'jobs' / smoke['job']['job_id'] / 'result.json')
                with page.expect_popup() as popup:
                    page.evaluate("""async value=>{
                      const {sendToWorkbench}=await import('./live-result-adapter.js');
                      sendToWorkbench(window.open('workbench-v6.html?live_run='+value.run_id,'_blank'),value);
                    }""", envelope)
                receiver = popup.value
                receiver.locator('[data-testid=evidence-map]').wait_for(state='visible', timeout=60000)
                assert receiver.locator('#page-error').is_hidden()
                quotes = receiver.locator('[data-testid=used-source-quote]')
                assert quotes.count() > 0
                quotes.first.click()
                receiver.locator('#detail-drawer[open] [data-testid=source-document]').wait_for(state='visible')
                assert receiver.locator('#detail-drawer .source-document mark').count() > 0
                checks.append('existing real envelope handoff mounts the real workbench and verified source highlights without a paid run')
                attacks = receiver.evaluate("""async original=>{
                  const {verifyEnvelope}=await import('./live-result-adapter.js');
                  const outcomes={};
                  for(const name of ['direction_promotion','cross_candidate_support','native_rank_reorder','invented_route']){
                    const v=structuredClone(original);
                    if(name==='direction_promotion'||name==='cross_candidate_support'){
                      const p=v.trace.paths.find(path=>path.direction==='CONTEXT');
                      if(!p)throw Error('The real smoke has no context path');
                      p.direction='SUPPORT';p.endpoint_kind='DECISION_EVIDENCE';
                      if(name==='cross_candidate_support')p.accepted_evidence_ids=[v.selected_evidence.find(e=>e.purpose==='FINAL_DECISION_EVIDENCE'&&e.item_id!==p.candidate_or_atom_id).id];
                      v.trace.paths=[p];
                    }
                    if(name==='native_rank_reorder'){
                      const a=v.native.result.readings[0].candidates,b=v.condition.result.readings[0].candidates;
                      [a[0],a[1]]=[a[1],a[0]];[b[0],b[1]]=[b[1],b[0]];
                    }
                    if(name==='invented_route'){
                      const p=v.trace.paths[0],citation=p.source_refs[0];
                      p.route_mode='RECORDED_SOURCE_ROUTE';p.graph_hops=1;p.original_traversal_claimed=true;
                      p.candidate_or_atom_id=p.candidate_or_atom_id.split('/').at(-1);
                      const step={id:'review_forged_step',kind:'RECORDED_GRAPH_ROUTE',source_refs:[citation],nodes:[
                        {id:'review_node_a',label:'Review injected A',is_graph_node:true,type:'Entity'},
                        {id:'review_node_b',label:'Review injected B',is_graph_node:true,type:'Entity'}],
                        edges:[{id:'review_forged_edge',source:'review_node_a',target:'review_node_b',kind:'REVIEW_UNRECORDED_EDGE'}]};
                      v.trace.steps.push(step);p.steps.splice(1,0,step.id);
                    }
                    try{await verifyEnvelope(v,original.run_id);outcomes[name]=true;}catch{outcomes[name]=false;}
                  }
                  return outcomes;
                }""", envelope)
                assert not any(attacks.values()), 'Reviewed native/route attacks must remain rejected'
                checks.append('unchanged review direction/foreign-unit/rank/graph attacks remain rejected')
                receiver.close()

                page.locator('#logout').click()
                expect(page.locator('#session-status')).to_contain_text('revoked')
                assert page.locator('#run').is_disabled() and page.locator('#result').is_hidden()
                assert not page.evaluate('()=>localStorage.length||sessionStorage.length')
                checks.append('logout revokes the server session and clears local result/token state')
                page.locator('#connection > summary').click()
                if not page.locator('#legacy-connection').evaluate('n=>n.open'):
                    page.locator('#legacy-connection > summary').click()
                page.locator('#capability').fill(LEGACY)
                page.locator('#connect').click()
                page.locator('#question-fields:not([disabled])').wait_for(state='visible')
                page.locator('#logout').click()
                expect(page.locator('#session-status')).to_contain_text('revoked')
                checks.append('legacy capability is advanced-only, origin-bound and server-revocable')

                # Do not forward a password if a configured endpoint redirects.
                context.route('**/live-api/session/login', lambda request: request.fulfill(status=307, headers={'Location': 'https://password-leak.invalid/'}))
                page.locator('#login-password').fill(PASSWORD)
                page.locator('#login-submit').click()
                expect(page.locator('#availability')).to_contain_text('redirect blocked')
                assert not any('password-leak' in url for url in blocked)
                context.unroute('**/live-api/session/login')
                checks.append('password POST redirects are blocked before any destination request')
                service.auth.seconds = 2
                page.locator('#login-password').fill(PASSWORD)
                page.locator('#login-submit').click()
                expect(page.locator('#session-status')).to_contain_text('Logged in')
                expect(page.locator('#session-status')).to_contain_text('expired', timeout=5000)
                assert page.locator('#run').is_disabled()
                checks.append('short expiry returns to logged-out UI without token/password restoration')
                context.close()

                # Virtual public origin, fulfilled locally. No remote service,
                # provider request or hosting setup is contacted.
                public = browser.new_context(viewport={'width': 390, 'height': 844})
                public_requests = []
                def public_route(route):
                    path = route.request.url.split('?')[0].rsplit('/', 1)[-1]
                    public_requests.append(path)
                    target = site / path
                    if path in {'live.html', 'live.js', 'live.css', 'live-result-adapter.js', 'app-navigation.js', 'app-navigation.css'}:
                        mime = 'text/html' if path.endswith('.html') else 'text/javascript' if path.endswith('.js') else 'text/css'
                        route.fulfill(content_type=mime, body=target.read_bytes())
                    else: route.abort()
                public.route('**/*', public_route)
                pub = public.new_page(); pub.goto('https://pages.example/matryoshka-demo/live.html', wait_until='networkidle')
                assert pub.locator('#backend').input_value() == ''
                initial = len(public_requests)
                pub.locator('#login-password').fill(PASSWORD); pub.locator('#login-submit').click()
                expect(pub.locator('#availability')).to_contain_text('not configured')
                assert pub.locator('#login-password').input_value() == '' and len(public_requests) == initial
                assert not pub.evaluate('()=>localStorage.length||sessionStorage.length')
                checks.append('unconfigured public Pages never sends a password or claims to host inference')
                assert not blocked and not errors, 'Unexpected external requests or page errors'
                public.close(); browser.close()
        finally:
            service.jobs.close(); service.shutdown(); service.server_close(); thread.join(timeout=5)
    assert before == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in old_files}
    write_json(HERE / 'qa/browser-login.json', dict(status='PASS', checks=checks, paid_calls=0,
        managed_chromium_headless_shell=True, old_source_and_paid_envelope_unchanged=True))
    print(json.dumps(dict(status='PASS', checks=checks, paid_calls=0), indent=2))


if __name__ == '__main__':
    main()
