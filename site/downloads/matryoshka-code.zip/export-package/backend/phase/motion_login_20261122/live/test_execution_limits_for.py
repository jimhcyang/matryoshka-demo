"""Pure Live settings contract tests: no jobs, inference, providers or servers."""
import ast
from copy import deepcopy
from pathlib import Path
import sys
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from worker import LIMITS, execution_limits_for

TASKS = ('redaction', 'mosaic', 'hypothesis')
CORPORA = ('cib', 'iran', 'vietnam')
LEGACY = dict(method='current_hierarchy', passage_budget=32, document_budget=16,
              construction_pages=8, draft_budget=12, terminal_ranking='evidence_fit_v6')
PROFILE = dict(page_focal_fraction=.5, candidate_focal_fraction=.5, scan_pages=512,
               identity_first=True, supplemental_mode='source_form_opportunities',
               counter_policy='positive_support', cue_order_mode='source_alignment',
               constructor_family_mode='first_class_adjuncts', source_phrase_mode='scoped')
REDACTION_MODES = dict(coordinate_member_mode='literal_source', focal_argument_mode='source_roles')


def saved_defaults():
    # Execute only the pure default-settings function, not phase/native imports.
    source = HERE.parents[1] / 'source_showcase_20261125/common.py'
    tree = ast.parse(source.read_text(), filename=str(source))
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                    and node.name == 'default_settings')
    namespace = {}
    exec(compile(ast.Module(body=[function], type_ignores=[]), str(source), 'exec'), namespace)
    return namespace['default_settings']


class ExecutionLimitsTests(unittest.TestCase):
    def test_exact_saved_default_settings_for_all_nine_pairs(self):
        defaults = saved_defaults()
        for task in TASKS:
            expected = defaults(task)
            if task == 'redaction':
                expected['selection_profile'].update(REDACTION_MODES)
            for corpus in CORPORA:
                with self.subTest(task=task, corpus=corpus):
                    self.assertEqual(execution_limits_for(task, corpus), expected)

    def test_every_limit_and_profile_value_independent_of_saved_helper(self):
        for task in TASKS:
            expected = dict(method='current_hierarchy', passage_budget=80 if task == 'redaction' else 48,
                            document_budget=40 if task == 'redaction' else 32,
                            construction_pages=32, draft_budget=64, terminal_ranking='evidence_fit_v7',
                            selection_profile=dict(PROFILE, **(REDACTION_MODES if task == 'redaction' else {})))
            for corpus in CORPORA:
                with self.subTest(task=task, corpus=corpus):
                    result = execution_limits_for(task, corpus)
                    self.assertEqual(result, expected)
                    self.assertIs(result['selection_profile']['identity_first'], True)
                    for key in ('passage_budget', 'document_budget', 'construction_pages', 'draft_budget'):
                        self.assertIs(type(result[key]), int)
                    self.assertIs(type(result['selection_profile']['scan_pages']), int)

    def test_redaction_modes_do_not_leak_into_mosaic_or_hypothesis(self):
        for corpus in CORPORA:
            for task in ('mosaic', 'hypothesis'):
                with self.subTest(task=task, corpus=corpus):
                    profile = execution_limits_for(task, corpus)['selection_profile']
                    self.assertEqual(set(profile), set(PROFILE))
                    self.assertNotIn('coordinate_member_mode', profile)
                    self.assertNotIn('focal_argument_mode', profile)

    def test_unknown_task_rejected_with_every_supported_corpus(self):
        for task in ('unknown', 'reconstruction', 'Mosaic', '', None, True, [], {}):
            for corpus in CORPORA:
                with self.subTest(task=task, corpus=corpus), self.assertRaisesRegex(ValueError, 'Unknown task'):
                    execution_limits_for(task, corpus)

    def test_unknown_corpus_rejected_without_normalization_or_type_error(self):
        for corpus in ('unknown', 'CIB', 'iran ', '', 0, False, [], {}):
            for task in TASKS:
                with self.subTest(task=task, corpus=corpus), self.assertRaisesRegex(ValueError, 'Unknown corpus'):
                    execution_limits_for(task, corpus)

    def test_no_corpus_non_redaction_behavior_is_byte_for_byte_legacy_shape(self):
        for task in ('mosaic', 'hypothesis', 'reconstruction', 'unknown', None, [], {}):
            with self.subTest(task=task):
                self.assertEqual(execution_limits_for(task), LEGACY)
                self.assertEqual(execution_limits_for(task, None), LEGACY)
        self.assertEqual(LIMITS, LEGACY)

    def test_no_corpus_redaction_fixture_profile_is_unchanged(self):
        expected = dict(LEGACY, construction_pages=16, draft_budget=32, selection_profile=dict(
            page_focal_fraction=.5, candidate_focal_fraction=.5, scan_pages=256,
            identity_first=True, supplemental_mode='source_head_opportunities'))
        self.assertEqual(execution_limits_for('redaction'), expected)
        self.assertEqual(execution_limits_for('redaction', None), expected)

    def test_each_new_profile_is_independent_and_cannot_mutate_limits(self):
        before = deepcopy(LIMITS)
        first = execution_limits_for('redaction', 'iran')
        first['draft_budget'] = -1
        first['selection_profile']['scan_pages'] = -1
        first['selection_profile']['counter_policy'] = 'tampered'
        first['selection_profile']['extra'] = []
        for task in TASKS:
            for corpus in CORPORA:
                result = execution_limits_for(task, corpus)
                self.assertEqual(result['draft_budget'], 64)
                self.assertEqual(result['selection_profile']['scan_pages'], 512)
                self.assertEqual(result['selection_profile']['counter_policy'], 'positive_support')
                self.assertNotIn('extra', result['selection_profile'])
        self.assertEqual(LIMITS, before)

    def test_legacy_profiles_are_independent_of_new_and_legacy_calls(self):
        first = execution_limits_for('redaction')
        first['selection_profile']['scan_pages'] = -1
        self.assertEqual(execution_limits_for('redaction')['selection_profile']['scan_pages'], 256)
        self.assertEqual(execution_limits_for('redaction', 'cib')['selection_profile']['scan_pages'], 512)
        self.assertEqual(LIMITS, LEGACY)

    def test_live_run_supplies_validated_case_task_and_corpus(self):
        tree = ast.parse((HERE / 'worker.py').read_text())
        calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Name) and node.func.id == 'execution_limits_for']
        self.assertEqual(len(calls), 1)
        self.assertEqual([ast.unparse(arg) for arg in calls[0].args], ["case['task']", "case['corpus']"])


if __name__ == '__main__':
    unittest.main(verbosity=2)
