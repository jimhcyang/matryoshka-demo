"""Generic Live source method. Models appraise; local code binds, checks and ranks.

The native packet is an unchanged retrieval/inspection record, never relabeled as
this method. There is no saved-case registry, answer input or input nomination.
"""
from collections import Counter
from copy import deepcopy
import re
import time
from math import ceil

from contract import ROOT, sha
from source_runtime import engines, identity, independent, require, safe_error, h_assessment_schema
from source_readings import project as project_readings

VERSION = "private-live-reviewed-source-pipeline/1"
INTAKE_VERSION = "private-live-source-intake/1"
SETTINGS = dict(processing_profile_version="shared-source-eight-pages/5",
    proposal_version="source-realized-fill-proposals/current-readings-2", scoped_proposal_version="source-realized-fill-proposals/scoped-policy-3",
    max_fills_per_reading=8, displayed_fills=5, maximum_readings=3,
    reading_selection="FIRST_LOCALLY_NONEMPTY_IN_DECLARED_ORDER", maximum_required_atoms=8,
    assessment_pages_per_batch=2, preferred_fact_page_rows=4, maximum_fact_page_rows=8, maximum_source_calls=17,
    source_page_budget=8, source_full_text_utf8_budget=32000,
    m_grounding="model-source-anchor-observer/4", h_appraisal="reviewed-H-source-views/5",
    r_focal="source-ascribed-redaction-fill-constraints/1", rank_formula="(source_class+.99*(.75*alignment+.25*lexical))/3",
    BM25_in_final_source_score=False, model="gpt-6.1-sol", source_pool="BOUNDED_RETRIEVAL_ORDER_COMPLETE_ELIGIBLE_PAGES",
    truncation=False, automatic_retries=0)


def pipeline_identity():
    return dict(version=VERSION, settings=deepcopy(SETTINGS), engines=identity())


def intake_settings(limits, pipeline):
    from matryoshka_demo.source_view_policy import descriptor
    return dict(method=limits["method"], retrieval_passage_budget=limits["passage_budget"],
        retrieval_document_budget=limits["document_budget"], source_view_policy=descriptor(limits["source_view_policy"]),
        source_pipeline_sha256=sha(pipeline), source_pipeline_version=VERSION,
        legacy_constructor_executed=False, legacy_matcher_executed=False, terminal_ranking=None,
        source_check_budgets=deepcopy(SETTINGS))


def intake_plan(case, base, selected):
    from matryoshka_narrative.contracts import engine_case, public_query
    from matryoshka_narrative.planning import validate_plan
    public_query(case)
    validate_plan(base, engine_case(case))
    plan = deepcopy(base)
    if case["task"] == "redaction":
        from matryoshka_next.readings import validate_readings
        validate_readings(selected, engine_case(case))
        plan["readings_packet"] = deepcopy(selected)
    else:
        require(selected is None, "M_H_CANNOT_ACQUIRE_SLOT_READINGS")
    return plan


def schedule_sources(policy, positions):
    selected, held, used = [], [], 0
    for pi in positions:
        require(policy.allowed(pi), "SCHEDULE_CANNOT_ADMIT_INELIGIBLE_PAGE")
        page = policy.corpus.pages[pi]
        require(policy.bound_pages.get(page["id"]) == page and sha(page["text"]) == page["source_sha256"], "SCHEDULE_SOURCE_BINDING")
        size = len(page["text"].encode("utf-8"))
        if len(selected) >= SETTINGS["source_page_budget"]:
            reason = "DECLARED_SOURCE_PAGE_BUDGET"
        elif not page["text"].strip() or used+size > SETTINGS["source_full_text_utf8_budget"]:
            reason = "WHOLE_PAGE_BYTE_BUDGET_NO_TRUNCATION"
        else:
            selected.append(pi)
            used += size
            continue
        held.append(dict(page_id=page["id"], source_sha256=page["source_sha256"], reason=reason, status="UNPROCESSED"))
    return selected, dict(version="private-live-source-schedule/1", ordering="RECORDED_RETRIEVAL_FACT_FAIR_PAGE_ORDER",
        original_page_ids=[policy.corpus.pages[pi]["id"] for pi in positions], original_pages=len(positions),
        selected_page_ids=[policy.corpus.pages[pi]["id"] for pi in selected], selected_pages=len(selected),
        unprocessed_pages=held, selected_utf8_bytes=used, page_budget=SETTINGS["source_page_budget"],
        full_text_utf8_budget=SETTINGS["source_full_text_utf8_budget"], raw_pages_clipped=False,
        no_evidence_claim_for_unprocessed=True, gold_or_saved_ranks_used=False)


def validate_intake(packet, case, base, selected, *, pins, binding, environment, settings, registry_ref):
    from matryoshka_narrative.contracts import engine_case
    expected = dict(version=INTAKE_VERSION, public_case=case, case=engine_case(case), plan=intake_plan(case, base, selected),
        code_pins=pins, binding=binding, environment=environment, configuration=settings,
        query_sha256=sha(case["query"]), query_only_inference=True, answers_read=False, grades_read=False,
        native_decisions_executed=False, source_pipeline_required=True,
        execution_context=dict(version="pinned-execution-context/1", registry_ref=registry_ref, index_ref=binding))
    require(all(packet.get(k) == v for k, v in expected.items()), "LIVE_SOURCE_INTAKE_BINDING_CHANGED")
    result = packet["result"]
    require(set(result) == {"status", "atoms", "readings", "inspected_page_ids", "provided_plan_sha256", "query_sha256", "source_view_policy", "inspection_means", "api_calls"}
        and packet["native_checksum"] == sha(result) and result["query_sha256"] == sha(case["query"])
        and result["provided_plan_sha256"] == sha(expected["plan"]) and result["atoms"] == [] and result["readings"] == []
        and result["status"] == "SOURCE_INTAKE_ONLY_NOT_A_NATIVE_VERDICT"
        and result["source_view_policy"] == settings["source_view_policy"]
        and packet["retrieval"]["source_view_policy"] == settings["source_view_policy"], "LIVE_SOURCE_INTAKE_RESULT_CHANGED")
    return packet


def intake(session, case, base, selected, limits, pipeline):
    """Run native public planning bindings/retrieval, NOT its old task engines."""
    from matryoshka_narrative import workflow, retrieval
    from matryoshka_narrative.contracts import engine_case
    from matryoshka_demo.source_view_policy import apply_source_view
    from matryoshka_demo.runner_v2 import environment_binding
    from matryoshka_narrative.guards import remaining_seconds
    require(workflow.code_pins() == session.narrative_pins, "INTAKE_ENGINE_CHANGED")
    remaining_seconds(new_work=True)
    plan = intake_plan(case, base, selected)
    context = apply_source_view(session.context(case["corpus"]), limits["source_view_policy"])
    started = time.monotonic()
    found = retrieval.retrieve(context.corpus, engine_case(case), plan, method=limits["method"],
        passage_budget=limits["passage_budget"], document_budget=limits["document_budget"],
        source_index=context.source_index, discovery_profile=limits.get("discovery_profile"))
    admitted_pages = found["pages"][:limits["passage_budget"]]
    policy = found["source_policy"]
    require(len(admitted_pages) == len(set(admitted_pages)) and all(policy.allowed(pi) for pi in admitted_pages),
        "INTAKE_SELECTED_AN_INELIGIBLE_SOURCE")
    selected_pages, schedule = schedule_sources(policy, admitted_pages)
    ids = [policy.corpus.pages[pi]["id"] for pi in selected_pages]
    settings = intake_settings(limits, pipeline)
    result = dict(status="SOURCE_INTAKE_ONLY_NOT_A_NATIVE_VERDICT", atoms=[], readings=[], inspected_page_ids=ids,
        provided_plan_sha256=sha(plan), query_sha256=sha(case["query"]), source_view_policy=settings["source_view_policy"],
        inspection_means="FULL_PAGES_ADMITTED_TO_SOURCE_METHOD; SEE_PROCESSED_REVIEW_SCOPE", api_calls=0)
    packet = dict(version=INTAKE_VERSION, public_case=deepcopy(case), case=engine_case(case), plan=plan, result=result,
        native_checksum=sha(result), query_sha256=sha(case["query"]), retrieval=deepcopy(found["receipt"]),
        binding=deepcopy(session.refs["index_refs"][case["corpus"]]), code_pins=deepcopy(session.narrative_pins),
        environment=deepcopy(session.environment), configuration=settings, query_only_inference=True, answers_read=False,
        grades_read=False, native_decisions_executed=False, source_pipeline_required=True,
        execution_context=dict(version="pinned-execution-context/1", registry_ref=deepcopy(session.refs["registry_ref"]),
            index_ref=deepcopy(session.refs["index_refs"][case["corpus"]])),
        timings=dict(retrieval_seconds=time.monotonic()-started, legacy_constructor_seconds=0., legacy_matcher_seconds=0.))
    packet["retrieval"]["live_source_schedule"] = schedule
    require(workflow.code_pins() == session.narrative_pins and environment_binding(session.root) == session.environment,
        "INTAKE_CODE_OR_LANGUAGE_RESOURCES_CHANGED")
    validate_intake(packet, case, base, selected, pins=session.narrative_pins, binding=packet["binding"],
        environment=session.environment, settings=settings, registry_ref=session.refs["registry_ref"])
    return packet, context


def source_input(native, policy):
    """The authoritative bound policy, not a UI/caller supplied page collection."""
    from matryoshka_next.facts import SourcePolicy, public_plan
    from matryoshka_demo.source_view_policy import descriptor, packet_policy
    require(type(policy) is SourcePolicy and policy.case == native["case"], "TRUSTED_NATIVE_SOURCE_POLICY_REQUIRED")
    require(native["native_checksum"] == sha(native["result"]) and native["answers_read"] is False
        and native["grades_read"] is False and native["query_only_inference"] is True,
        "SEALED_QUERY_ONLY_NATIVE_REQUIRED")
    public_plan(native["case"], native["plan"])
    plan = native["plan"]
    require(plan["query_only"] is True and plan["corpus_read"] is False and plan["hidden_answers_read"] is False,
        "PUBLIC_QUERY_PLAN_REQUIRED")
    require(packet_policy(native) is policy.source_view_policy, "SOURCE_POLICY_CHANGED")
    ids = native["result"]["inspected_page_ids"]
    require(isinstance(ids, list) and len(ids) <= 256 and len(ids) == len(set(ids)), "DISTINCT_BOUNDED_INSPECTED_POOL")
    pages = []
    for pid in ids:
        pi = policy.corpus.page_index.get(pid)
        require(pi is not None and policy.allowed(pi), "SOURCE_NOT_ELIGIBLE")
        page = policy.corpus.pages[pi]
        require(policy.bound_pages.get(pid) == page and sha(page["text"]) == page["source_sha256"], "CANONICAL_SOURCE_CHANGED")
        require(bool(page["text"].strip()) and len(page["text"]) <= 24000, "WHOLE_SOURCE_PAGE_BOUND_NO_TRUNCATION")
        pages.append(deepcopy(page))
    require(len(pages) <= SETTINGS["source_page_budget"] and sum(len(p["text"].encode("utf-8")) for p in pages)
        <= SETTINGS["source_full_text_utf8_budget"], "PREPARED_SOURCE_POOL_EXCEEDS_SHARED_PROFILE_NO_CLIPPING")
    return dict(case=deepcopy(native["public_case"]), atoms=deepcopy(plan["atoms"]),
        pages=pages, source_view_policy=descriptor(policy.source_view_policy))


def citation(policy, page_id, span):
    require(span is not None, "EXACT_SOURCE_SPAN_REQUIRED")
    value = policy.citation(policy.corpus.page_index[page_id], span["start"], span["end"])
    require(value["text"] == span["text"], "SOURCE_QUOTE_CHANGED")
    return value


def aggregate(facts, rows, *, hypothesis, original_pages):
    """No slot omission, score averaging or missing evidence can complete an atom."""
    atoms = []
    for fact in facts:
        own = [r for r in rows if r["fact_id"] == fact["id"]]
        signs = {sign: sorted({r["document_id"] for r in own if r["effective_direction"] == sign})
                 for sign in ("SUPPORT", "OPPOSE", "PARTIAL", "CONTEXT")}
        if hypothesis:
            status = "SOURCE_VIEWS_RECORDED" if signs["SUPPORT"] or signs["OPPOSE"] else "UNRESOLVED"
        else:
            status = ("CONFLICTED_SOURCE_ACCOUNTS" if signs["SUPPORT"] and signs["OPPOSE"] else
                "SOURCE_ASCRIBED" if signs["SUPPORT"] else "SOURCE_OPPOSED" if signs["OPPOSE"] else
                "PARTIAL_SOURCE_ACCOUNT" if signs["PARTIAL"] else "CONTEXT_ONLY" if signs["CONTEXT"] else "UNRESOLVED")
        # H bars sum the strongest index per document/direction, not independent votes.
        bars = {}
        for sign in ("SUPPORT", "OPPOSE", "CONTEXT"):
            per_doc = {}
            for row in own:
                if row["effective_direction"] == sign:
                    did = row["document_id"]
                    per_doc[did] = max(per_doc.get(did, 0.), row["context_priority_index"])
            bars[sign] = dict(value=sum(per_doc.values()), documents=len(per_doc), per_document=per_doc)
        atoms.append(dict(id=fact["id"], text=fact["text"], query_spans=deepcopy(fact["query_spans"]), status=status,
            authority="QUERIED_ASSESSMENT_ONLY" if hypothesis else "SOURCE_ASCRIPTION",
            complete_by_source_review=None if hypothesis else status == "SOURCE_ASCRIBED",
            supporting_source_documents=signs["SUPPORT"], opposing_source_documents=signs["OPPOSE"],
            directional_indices=bars, evidence=own, world_truth_verdict="NOT_ASSESSED",
            inner_execution=False, event_join_authority=False))
    counts = Counter(r["effective_direction"] for r in rows)
    expected = len(facts) * original_pages
    assessed = len(rows)
    require(assessed <= expected and len({(r["fact_id"], r["page_id"]) for r in rows}) == assessed, "DUPLICATE_SOURCE_MATRIX_SLOT")
    held = counts["HOLD"] + counts["REJECTED_ROW"]
    scope = dict(original_pages=original_pages, required_facts=len(facts), original_slots=expected,
        processed_slots=assessed, provider_reviewed_slots=sum(r.get("review") is not None for r in rows),
        accepted_slots=sum(r.get("unanimous_model_accept") is True for r in rows), held_slots=held,
        rejected_slots=counts["REJECTED_ROW"], unprocessed_slots=expected-assessed,
        inspected_pool_completely_processed=assessed == expected,
        inspected_pool_completely_assessed=assessed == expected and held == 0, partial_search=True)
    return dict(atoms=atoms, source_judgments=rows, assessment_scope=scope,
        coverage=None if hypothesis else sum(a["complete_by_source_review"] for a in atoms) / len(atoms),
        status="SOURCE_VIEWS_RECORDED" if hypothesis and any(a["status"] == "SOURCE_VIEWS_RECORDED" for a in atoms) else
            "SOURCE_COMPONENTS_COMPLETE" if not hypothesis and all(a["complete_by_source_review"] for a in atoms) else "PARTIAL_SEARCH_UNRESOLVED",
        counts_are_independent_votes=False, native_history_modified=False, world_truth_certified=False)


def score_account(row, fact, e):
    raw = row["raw_model_row"]
    weights = {k: e.v3.WEIGHTS[k] for k, v in e.v3.requested_fields(fact["text"]).items() if v["required"]}
    denominator = sum(weights.values())
    matched = sum(w for k, w in weights.items() if raw["fields"][k]["state"] == "MATCHED") / denominator
    states = {"MATCHED", "CONFLICTING"} if row["effective_direction"] == "OPPOSE" and row["unanimous_model_accept"] else {"MATCHED"}
    alignment = sum(w for k, w in weights.items() if raw["fields"][k]["state"] in states) / denominator
    envelope = row.get("qualification_envelope")
    local = e.v3.P.lexical_fit(fact["text"], envelope["paragraph"]["text"] if envelope else "")
    index = .75*alignment + .25*local["value"] if row["effective_direction"] not in {"HOLD", "NONE", "REJECTED_ROW"} else 0.
    row.update(requested_facet_weights=weights, literal_agreement_coverage=matched,
        evidence_alignment_coverage=alignment, local_lexical_fit=local, context_priority_index=index,
        formula=".75*evidence_alignment_coverage+.25*local_lexical_fit; HOLD/NONE/REJECTED=0",
        calibrated_probability=False, inner_execution=False, event_join_authority=False, world_truth=False)
    return row


def mh(native, policy, data, invoke, e):
    inspection = dict(pages=data["pages"], source_view_policy=data["source_view_policy"])
    pf = e.v3.P._preflight(native, inspection, policy,
        native_ref=dict(path="private-live-native", sha256=sha(native)),
        inspection_ref=dict(path="private-live-inspected-source-input", sha256=sha(inspection)))
    hypothesis = data["case"]["task"] == "hypothesis"
    facts = pf.export()["required_facts"]
    rows, failures = [], []
    pages_per_batch = min(SETTINGS["assessment_pages_per_batch"], max(1, SETTINGS["preferred_fact_page_rows"] // len(facts)))
    for wire in e.v3.assessment_wires(pf, pages_per_batch=pages_per_batch):
        review_pending = True
        checked = None
        fact_map = {f["id"]: f for f in facts}
        def record(row):
            page = next(p for p in wire["pages"] if p["id"] == row["page_id"])
            row.update(document_id=page["document_id"], date=page["date"], page_sha256=page["source_sha256"])
            if row["effective_direction"] == "REJECTED_ROW":
                row.update(context_priority_index=0., inner_execution=False, event_join_authority=False, world_truth=False)
            else:
                score_account(row, fact_map[row["fact_id"]], e)
            if row.get("qualification_envelope"):
                env = row["qualification_envelope"]
                row.update(citation=citation(policy, page["id"], env["raw_quote_span"]),
                    qualification_citation=citation(policy, page["id"], env["paragraph"]))
            rows.append(row)
        try:
            if hypothesis:
                hwire = e.h.wire_from_v3(pf, wire)
                schema = h_assessment_schema(e.h.response_schema())
                schema["properties"]["judgments"].update(minItems=len(facts)*len(wire["pages"]), maxItems=len(facts)*len(wire["pages"]))
                response, first = invoke("live_h_assessment_v1", hwire, e.h.PROMPT, schema)
                checked = e.h.validate_assessment(pf, hwire, response, first, root=ROOT)
                reviewable = any(r["status"] == "REVIEWABLE" for r in checked.export()["rows"])
                if reviewable:
                    rw = e.h.review_wire(checked)
                    review_pending = False
                    response, second = invoke("live_h_review_v1", rw, e.h.REVIEW_PROMPT, e.h.review_schema())
                    independent(first, second)
                    reviewed = e.h.validate_review(checked, response, second, root=ROOT).export()["rows"]
                else:
                    getattr(invoke, "skip_review", lambda: None)()
                    review_pending = False
                    reviewed = [dict(r, effective_direction="REJECTED_ROW" if r["status"] == "REJECTED_ROW" else "HOLD",
                        unanimous_model_accept=False, review=None) for r in checked.export()["rows"]]
            else:
                response, first = invoke("live_m_assessment_v1", wire, e.v3.PROMPT, e.v3.response_schema("mosaic"))
                checked = e.m.observe_v3(pf, wire, response, first, root=ROOT)
                reviewable = any(r["status"] == "REVIEWABLE_AWAITING_FRESH_V4_REVIEW" for r in checked.export()["rows"])
                resolutions = {}
                if reviewable:
                    rw = e.m.review_wire(checked)
                    schema = e.m.review_schema()
                    schema["properties"]["reviews"]["items"]["properties"]["directional_stance_supported"] = dict(type="boolean", enum=[False])
                    review_pending = False
                    response, second = invoke("live_m_review_v1", rw, e.m.REVIEW_PROMPT, schema)
                    independent(first, second)
                    result = e.m.validate_review(checked, response, second, root=ROOT)
                    resolutions = {r["observation_row_id"]: r for r in result["rows"]}
                else:
                    getattr(invoke, "skip_review", lambda: None)()
                    review_pending = False
                reviewed = []
                for original in checked.export()["rows"]:
                    row = deepcopy(original)
                    resolution = resolutions.get(row["observation_row_id"], {})
                    row.update(review=resolution.get("review"), unanimous_model_accept=resolution.get("unanimous_model_accept", False),
                        effective_direction=resolution.get("effective_label", "REJECTED_ROW" if row["status"] == "REJECTED_ROW" else "HOLD"))
                    reviewed.append(row)
            for row in reviewed:
                record(row)
        except Exception as error:
            if review_pending:
                getattr(invoke, "skip_review", lambda: None)()
            if checked is not None:
                seen = {(r["fact_id"],r["page_id"]) for r in rows}
                for row in checked.export()["rows"]:
                    if (row["fact_id"],row["page_id"]) not in seen:
                        record(dict(row, effective_direction="REJECTED_ROW" if row["status"] == "REJECTED_ROW" else "HOLD",
                            unanimous_model_accept=False, review=None, semantic_credit=0,
                            review_failure=safe_error(error)))
            # Valid first passes survive review holds, but can never gain credit.
            failures.append(dict(batch_index=wire["batch_index"], page_ids=[p["id"] for p in wire["pages"]],
                fact_ids=[f["id"] for f in facts], status="REVIEW_HOLD_FIRST_PASS_RETAINED" if checked is not None else "UNPROCESSED_BATCH_HOLD", error_type=type(error).__name__,
                private_error_reason=safe_error(error)))
    original_pages = native.get("retrieval", {}).get("live_source_schedule", {}).get("original_pages", len(data["pages"]))
    return dict(aggregate(facts, rows, hypothesis=hypothesis, original_pages=original_pages),
        readings=[], failures=failures, method_family="REVIEWED_H_SOURCE_VIEWS_V5" if hypothesis else "REVIEWED_M_SOURCE_ACCOUNTS_V3_V4")


def focal_packet(case, atoms, items, sources, e):
    payload = dict(version=e.focal.VERSION, case=case, query_only_facts=atoms, items=items, sources=sources)
    key = sha(payload)
    payload["binding"] = dict(batch_sha256=key)
    body = e.focal.body(payload)
    return dict(version=e.focal.VERSION, model_input=payload, body=body,
        body_sha256=sha(body), batch_sha256=key)


def r_focal(case, atoms, candidates, projected, invoke, e):
    items = [dict(candidate_id=c["id"], reading=c["reading"], fill=c["fill"],
        completed_input=c["completed_input"], completed_input_sha256=sha(c["completed_input"]),
        own_source_page_id=c["source"]["page_id"], original_phrase=c["source"]["phrase"]["text"],
        original_quote=c["source"]["quote"]["text"], transformation=c["transformation"]) for c in candidates]
    items.sort(key=lambda r: (r["reading"]["id"], r["candidate_id"]))
    packet = focal_packet(case, atoms, items, projected, e)
    response, first = invoke("live_r_focal_assessment_v1", packet["model_input"], e.focal.PROMPT, e.focal.SCHEMA)
    validated = e.focal.validate_assessment(packet, response)
    signed = [r for r in validated["rows"] if r["semantic_review_required"]]
    accepted = set()
    if signed:
        rw = e.focal.prepare_review(packet, response)
        review, second = invoke("live_r_focal_review_v1", rw["model_input"], e.focal.REVIEW_PROMPT, e.focal.REVIEW_SCHEMA)
        independent(first, second)
        require(review["batch_sha256"] == rw["batch_sha256"] and
            [r["candidate_id"] for r in review["reviews"]] == [r["candidate_id"] for r in signed], "COMPLETE_R_FOCAL_REVIEW_REQUIRED")
        flags = ("complete_inserted_contribution", "correct_focal_scope", "same_owner_issue_bound",
            "roles_time_qualifications_preserved", "citations_exact", "no_private_event_or_cross_document_join")
        accepted = {r["candidate_id"] for r in review["reviews"] if r["decision"] == "ACCEPT_SOURCE_ASCRIPTION" and all(r[k] is True for k in flags)}
    by_id = {r["candidate_id"]: r for r in validated["rows"]}
    quarantined = {r["candidate_id"]: r for r in validated["quarantined"]}
    for candidate in candidates:
        row = by_id.get(candidate["id"])
        label = row["assessment"]["decision"] if row else "REJECTED_ROW"
        reviewed = row is not None and (not row["semantic_review_required"] or candidate["id"] in accepted)
        local = max((e.v3.P.lexical_fit(candidate["fill"], a["quote"])["value"] for a in row["bound_source_anchors"]), default=0.) if row else 0.
        index = .75*row["alignment"] + .25*local if reviewed and label != "NOINFO" else 0.
        cls = 2 if reviewed and label == "DIRECT_TARGET_SOURCE" else 1 if reviewed and label == "INFERENTIAL_CONTEXT" else 0
        candidate.update(source_focal_class=label if reviewed else "HOLD", source_supported_fill_approved=cls == 2,
            evidence_class=cls, priority_index=(cls+.99*index)/3, source_alignment_index=index,
            alignment=row["alignment"] if row else 0., local_lexical_fit=local, raw_focal_assessment=row,
            quarantine=quarantined.get(candidate["id"]), whole_visible_event_certified=False,
            score_formula=SETTINGS["rank_formula"], calibrated_probability=False)


def redaction(native, policy, data, invoke, parse, e):
    from source_proposal_policy import current_protocol, project_page
    proposal_engine = current_protocol(e.proposal, native, policy)
    case, atoms = data["case"], public_atoms(data["atoms"])
    readings = project_readings(native["plan"]["readings_packet"], case)
    projected = [project_page(e.proposal, native, policy, p, i) for i, p in enumerate(data["pages"])]
    pages = {p["id"]: p for p in data["pages"]}
    branches, failures, primary_found = [], [], False
    for position, reading in enumerate(readings):
        if position >= SETTINGS["maximum_readings"] or primary_found:
            branches.append(dict(reading=reading, candidates=[], top5_ids=[], held=[], status="UNPROCESSED_READING_BUDGET"))
            continue
        base = dict(version=proposal_engine.VERSION, case=case, reading=reading, query_only_facts=atoms)
        chunks, chunk = [], []
        for page in projected:
            try:
                proposal_engine.packet(dict(base, sources=chunk+[page]), dict(index=255, count=256))
            except ValueError:
                require(bool(chunk), "SINGLE_WHOLE_PAGE_OVERSIZE_NO_CLIPPING")
                chunks.append(chunk)
                chunk = []
            proposal_engine.packet(dict(base, sources=[page]), dict(index=255, count=256))
            chunk.append(page)
        if chunk:
            chunks.append(chunk)
        candidates, held, seen = [], [], set()
        for i, chunk in enumerate(chunks):
            packet = proposal_engine.packet(dict(base, sources=chunk), dict(index=i, count=len(chunks)))
            try:
                response, first = invoke("live_r_proposal_v1", packet["model_input"], proposal_engine.PROMPT, proposal_engine.RESPONSE_SCHEMA)
                valid = proposal_engine.validate_response(packet, response)
                held.extend(valid["invalid_rows"])
                if not valid["valid_rows"]:
                    continue
                rw = proposal_engine.review_packet(packet, response)
                review, second = invoke("live_r_proposal_review_v1", rw["model_input"], proposal_engine.REVIEW_PROMPT, proposal_engine.REVIEW_SCHEMA)
                independent(first, second)
                checked = proposal_engine.validate_review(rw, review)
                proofs = {r["proposal"]["proposal_id"]: r["proof"] for r in valid["valid_rows"]}
                for row in checked["rows"]:
                    if not row["accepted_contextual_nomination"]:
                        held.append(row)
                        continue
                    proposal = row["proposal"]
                    key = " ".join(proposal["fill"].casefold().split())
                    if key in seen or len(candidates) >= SETTINGS["max_fills_per_reading"]:
                        held.append(dict(row, reason="RECORDED_SURFACE_DEDUP_OR_EIGHT_PER_READING_BOUND"))
                        continue
                    proof = proofs[proposal["proposal_id"]]
                    page = pages[proposal["page_id"]]
                    grammar = e.grammar.evaluate(case, reading, proposal, proof, page, row["review"], parse)
                    if not grammar["eligible"]:
                        held.append(dict(row, grammar=grammar))
                        continue
                    seen.add(key)
                    candidates.append(dict(id="live_source_"+sha([reading["id"], proposal, proof])[:32],
                        reading=reading, reading_id=reading["id"], fill=proposal["fill"], completed_input=proof["completed_input"],
                        transformation=proposal["transformation"], source=dict(page_id=page["id"], document_id=page["document_id"],
                            page_sha256=page["source_sha256"], quote=proof["quote_span"], phrase=proof["phrase_span"],
                            qualification=proof["qualification_paragraph"], citation=citation(policy, page["id"], proof["quote_span"])),
                        grammar=grammar, contextual_proposal_review=row["review"], provenance="CORPUS", native_candidate_created=False))
            except Exception as error:
                failures.append(dict(reading_id=reading["id"], partition=i, page_ids=[p["page_id"] for p in chunk],
                    status="UNPROCESSED_PARTITION_HOLD", error_type=type(error).__name__, private_error_reason=safe_error(error)))
        if candidates:
            primary_found = True
            try:
                r_focal(case, atoms, candidates, projected, invoke, e)
            except Exception as error:
                failures.append(dict(reading_id=reading["id"], status="FOCAL_APPRAISAL_HOLD", error_type=type(error).__name__, private_error_reason=safe_error(error)))
                for c in candidates:
                    c.update(source_focal_class="HOLD", source_supported_fill_approved=False, evidence_class=0,
                        priority_index=0., source_alignment_index=0., calibrated_probability=False)
        candidates.sort(key=lambda c: (-c["priority_index"], c["id"]))
        for rank, c in enumerate(candidates, 1):
            c["rank"] = rank
        branches.append(dict(reading=reading, candidates=candidates, top5_ids=[c["id"] for c in candidates[:5]], held=held,
            proposal_protocol_version=proposal_engine.VERSION))
    selected = next((b["reading"]["id"] for b in branches if b["candidates"]), readings[0]["id"] if readings else None)
    return dict(method_family="SOURCE_REALIZED_REDACTION_V1", readings=branches, atoms=atoms,
        selected_reading_id=selected, selection_rule="FIRST_NONEMPTY_DECLARED_READING_NOT_QA_ORACLE",
        failures=failures, status="SOURCE_SUGGESTIONS_RECORDED" if any(b["candidates"] for b in branches) else "UNRESOLVED",
        native_history_modified=False, source_page_union_used_for_candidate_support=False, world_truth_certified=False)


def public_atoms(atoms):
    allowed = {"id", "text", "kind", "required", "polarity", "modality", "query_spans"}
    return [{k: deepcopy(v) for k, v in atom.items() if k in allowed} for atom in atoms]


def digest_input(method, policy):
    """Same selected-source digest DTO: S/C references, own quotes, no old native ranks."""
    sources, by_page = [], {}
    def cite(ref):
        pid = ref["canonical_page_id"]
        actual = citation(policy, pid, ref)
        if pid not in by_page:
            by_page[pid] = len(sources)
            sources.append(dict(id="S"+str(len(sources)+1), **{k: actual[k] for k in
                ("corpus", "document_id", "date", "canonical_page_id", "page_sha256", "earlier_page", "physical_page", "source_edition") if k in actual}, citations=[]))
        source = sources[by_page[pid]]
        prior = next((c for c in source["citations"] if c["citation"] == actual), None)
        if prior is None:
            prior = dict(id="C"+str(len(source["citations"])+1), citation=actual)
            source["citations"].append(prior)
        return dict(source_id=source["id"], citation_id=prior["id"])
    scope = deepcopy(method.get("assessment_scope", {}))
    base = dict(version="live-selected-reviewed-source-digest/1/input", public_case=method["public_case"],
        method=dict(id=VERSION, label=method["method_family"], native_method=False), source_policy=method["source_view_policy"],
        assessment_scope=scope, source_scope_notes=[], method_caveat="Source-model accounts, not certified world truth; partial search remains.",
        postrun=True, used_for_inference=False, unchanged_native_is_not_primary_method=True,
        distinct_documents_are_not_independent_votes=True, source_dates_not_automatically_event_dates=True,
        indices_are_source_context_not_probabilities=True)
    if method["public_case"]["task"] == "redaction":
        branches = []
        for branch in method["readings"]:
            rows = []
            for c in branch["candidates"]:
                source = c["source"]
                contexts = []
                for a in (c.get("raw_focal_assessment") or {}).get("bound_source_anchors", []):
                    contexts.append(cite(citation(policy, source["page_id"], dict(start=a["start"], end=a["end"], text=a["quote"]))))
                rows.append(dict(id=c["id"], fill=c["fill"], completed_input=c["completed_input"], rank=c["rank"],
                    transformation=c["transformation"], evidence_state=c["source_focal_class"],
                    source_ascribed_fill_approved=c["source_supported_fill_approved"], priority_index=f"{c['priority_index']:.4f}",
                    quote=cite(source["citation"]), phrase=cite(citation(policy, source["page_id"], source["phrase"])),
                    full_qualification=cite(citation(policy, source["page_id"], source["qualification"])), focal_sources=contexts,
                    whole_visible_event_certified=False))
            branches.append(dict(reading=branch["reading"], candidates=rows, top5_ids=branch["top5_ids"]))
        base.update(kind="SOURCE_REALIZED_REDACTION", facts=method["atoms"],
            selection=dict(reading_id=method["selected_reading_id"], rule=method["selection_rule"]), readings=branches)
    else:
        components = []
        for atom in method["atoms"]:
            accounts = []
            for row in atom["evidence"]:
                if row["effective_direction"] in {"HOLD", "REJECTED_ROW", "NONE"} or not row.get("citation"):
                    continue
                raw = row["raw_model_row"]
                accounts.append(dict(judgment_id=row.get("appraisal_id", row.get("observation_row_id")), direction=row["effective_direction"],
                    quote=cite(row["citation"]), qualification=cite(row["qualification_citation"]),
                    attribution=raw.get("attribution"), kind=raw.get("kind"), mode=raw.get("mode"),
                    qualifier_quotes=raw.get("qualifier_quotes", []), argument_quote=raw.get("argument_quote"),
                    facet_states={k: v["state"] for k, v in raw["fields"].items()},
                    source_alignment_index=f"{row['context_priority_index']:.4f}", review_reason=row["review"]["reason"]))
            components.append(dict(id=atom["id"], text=atom["text"], query_spans=atom["query_spans"],
                decision=atom["status"], source_component_complete=atom["complete_by_source_review"], accounts=accounts))
        base.update(kind="REVIEWED_SOURCE_METHOD", current_result=dict(components=components, required=len(components),
            source_components_complete=None if method["coverage"] is None else sum(a["complete_by_source_review"] for a in method["atoms"]),
            source_account_coverage=method["coverage"]), recorded_slot_labels=dict(Counter(r["effective_direction"] for r in method["source_judgments"])))
    base.update(sources=sources, binding=dict(case_sha256=sha(method["public_case"]), native_checksum=method["native_checksum"],
        resource_binding_sha256=sha(method["resource_binding"]), pipeline_sha256=method["pipeline_sha256"],
        source_policy_sha256=sha(method["source_view_policy"]), citation_map_sha256=sha(sources)))
    return base


def source_trace(result):
    """Document-to-excerpt paths only: no invented semantic KG edge or event join."""
    paths = []
    for branch in result.get("readings", []):
        for c in branch["candidates"]:
            paths.append(dict(id="source_path_"+sha(c["id"])[:24], reading_id=c["reading_id"], candidate_id=c["id"],
                source_refs=[c["source"]["citation"]], route_mode="SOURCE_DOCUMENT_EXCERPT_TRANSFORMATION_FILL",
                transformation=c["transformation"], semantic_graph_edge_inferred=False))
    for row in result.get("source_judgments", []):
        if row.get("citation"):
            paths.append(dict(id="source_path_"+sha([row["fact_id"], row["page_id"]])[:24], atom_id=row["fact_id"],
                source_refs=[row["citation"], row["qualification_citation"]], direction=row["effective_direction"],
                route_mode="SOURCE_DOCUMENT_EXCERPT_REVIEWED_ACCOUNT", semantic_graph_edge_inferred=False))
    return dict(version="private-live-source-account-trace/1", paths=paths,
        source_only_paths=True, native_graph_trace_unchanged=True, world_event_or_identity_authority=False)


def execute(native, policy, runtime, *, parse, emit=lambda stage: None, pipeline=None):
    # Bind one immutable manifest through intake, assessments, digest and view.
    # Lazy imports must neither change the closure nor hide actual file edits.
    pipeline = deepcopy(pipeline if pipeline is not None else pipeline_identity())
    def check_pipeline():
        require(sha(pipeline_identity()) == sha(pipeline), "LIVE_SOURCE_CODE_OR_SETTINGS_CHANGED_DURING_JOB")
    check_pipeline()
    if native.get("source_pipeline_required") is True or native.get("version") == INTAKE_VERSION:
        require(native["configuration"]["source_pipeline_sha256"] == sha(pipeline), "INTAKE_EXECUTION_PIPELINE_IDENTITY_MISMATCH")
    e = engines()
    data = source_input(native, policy)
    facts = [a for a in data["atoms"] if a.get("required") and a["kind"] == "proposition"]
    if data["case"]["task"] == "redaction":
        reading_count = min(len(project_readings(native["plan"]["readings_packet"], data["case"])), SETTINGS["maximum_readings"])
        # A full-page partition may split further at the wire bound; the global
        # ceiling remains explicit and failed partitions stay UNPROCESSED.
        call_limit, matrix_rows = min(SETTINGS["maximum_source_calls"], 2*reading_count+3), 0
    else:
        require(1 <= len(facts) <= SETTINGS["maximum_required_atoms"], "BOUNDED_REQUIRED_FACTS_NO_TRUNCATION")
        pages_per_batch = min(SETTINGS["assessment_pages_per_batch"], max(1, SETTINGS["preferred_fact_page_rows"] // len(facts)))
        call_limit = 2*ceil(len(data["pages"])/pages_per_batch)+1
        matrix_rows = len(facts)*min(pages_per_batch, len(data["pages"]))
    before = sha(native)
    calls = 0
    def invoke(stage, payload, prompt, schema):
        nonlocal calls
        check_pipeline()
        require(calls < call_limit and calls < SETTINGS["maximum_source_calls"], "LIVE_SOURCE_CALL_BOUND")
        calls += 1
        emit("construction" if "proposal" in stage else "task_decisions")
        return runtime.invoke(stage, payload, prompt, schema)
    processing_budget = runtime.configure(data["case"]["task"], maximum_source_calls=call_limit, matrix_rows=matrix_rows)
    invoke.skip_review = lambda: setattr(runtime, "completed_stages", runtime.completed_stages+1)
    if not data["pages"]:
        original_pages = native.get("retrieval", {}).get("live_source_schedule", {}).get("original_pages", 0)
        if data["case"]["task"] == "redaction":
            declared = project_readings(native["plan"]["readings_packet"], data["case"])
            result = dict(method_family="SOURCE_REALIZED_REDACTION_V1", atoms=public_atoms(data["atoms"]),
                readings=[dict(reading=r, candidates=[], top5_ids=[], held=[], status="UNPROCESSED_SOURCE_BUDGET") for r in declared],
                selected_reading_id=None, selection_rule="FIRST_NONEMPTY_DECLARED_READING_NOT_QA_ORACLE", source_judgments=[])
        else:
            facts = [a for a in data["atoms"] if a.get("required") and a["kind"] == "proposition"]
            result = dict(aggregate(facts, [], hypothesis=data["case"]["task"] == "hypothesis", original_pages=original_pages),
                method_family="REVIEWED_SOURCE_ACCOUNTS", readings=[])
        result.update(status="SOURCE_BUDGET_HOLD_UNPROCESSED" if original_pages else "NO_ELIGIBLE_INSPECTED_SOURCES",
            failures=[], source_search_complete=False)
    elif data["case"]["task"] == "redaction":
        result = redaction(native, policy, data, invoke, parse, e)
    else:
        result = mh(native, policy, data, invoke, e)
    check_pipeline()
    result.update(version=VERSION, public_case=data["case"], source_view_policy=data["source_view_policy"],
        query_sha256=sha(data["case"]["query"]),
        native_checksum=native["native_checksum"], native_record_sha256=before, resource_binding=deepcopy(native["binding"]),
        atoms_full=public_atoms(data["atoms"]), source_pages=data["pages"], pipeline=pipeline, pipeline_sha256=sha(pipeline),
        fixed_model_outputs_deterministic=True, uncached_model_outputs_bit_reproducible=False,
        no_answer_or_grade_inputs=True, no_native_verdict_upgrade=True)
    result["processing_budget"] = processing_budget
    result["source_metadata_presence"] = [dict(page_id=p["id"], page_sha256=p["source_sha256"],
        handling_recorded="handling" in p, transport_handling_defaulted=data["case"]["task"] == "redaction" and "handling" not in p,
        absence_is_not_clearance=True) for p in data["pages"]]
    result["source_pool_scope"] = deepcopy(native.get("retrieval", {}).get("live_source_schedule", dict(
        original_pages=len(data["pages"]), selected_pages=len(data["pages"]),
        selected_page_ids=[p["id"] for p in data["pages"]], unprocessed_pages=[])))
    result["source_pool_scope"]["unprocessed_reading_ids"] = [b["reading"]["id"] for b in result.get("readings", []) if b.get("status", "").startswith("UNPROCESSED_")]
    result["trace"] = source_trace(result)
    result["digest"] = dict(available=False, used_for_inference=False,
        reason="SOURCE_BUDGET_HOLD_UNPROCESSED" if result["source_pool_scope"]["original_pages"] else "NO_ELIGIBLE_INSPECTED_SOURCES")
    if data["pages"]:
        try:
            payload = digest_input(result, policy)
            prompt = e.r_digest_prompt if data["case"]["task"] == "redaction" else e.digest_prompt
            output, receipt = invoke("live_selected_source_digest_v1", payload, prompt, e.digest_schema)
            text = output["digest"]
            require(50 <= len(text.split()) <= 100, "SOURCE_DIGEST_WORD_BOUND")
            require(all(1 <= int(m) <= len(payload["sources"]) for m in re.findall(r"\bS(\d+)\b", text)), "SOURCE_DIGEST_UNKNOWN_CITATION")
            result["digest"] = dict(available=True, version="live-selected-reviewed-source-digest/1", text=text,
                input=payload, input_sha256=sha(payload), receipt=receipt, sources=payload["sources"], used_for_inference=False)
        except Exception as error:
            result["digest"] = dict(available=False, used_for_inference=False, reason="SOURCE_DIGEST_HELD", error_type=type(error).__name__, private_error_reason=safe_error(error))
    require(sha(native) == before, "SOURCE_METHOD_MUTATED_NATIVE")
    result.update(provider_receipts=deepcopy(runtime.receipts), source_call_attempts=calls,
        digest_input_is_same_selected_source_DTO_family=True, partial_source_search=True)
    normalized_pages = [dict(page_id=p["id"], canonical_page_id=p["id"], document_id=p["document_id"], corpus=p["corpus"],
        date=p["date"], page_sha256=p["source_sha256"], windows=[dict(start=0, end=len(p["text"]), text=p["text"])],
        original_page_metadata={k: deepcopy(p[k]) for k in ("earlier_page", "later_page", "physical_page", "source_page", "native_page", "view") if k in p},
        clipped=False) for p in data["pages"]]
    result["view"] = dict(version="private-live-source-workbench-view/1", case=data["case"], query_sha256=sha(data["case"]["query"]),
        source_view_policy=data["source_view_policy"], native_checksum=native["native_checksum"], pipeline_sha256=result["pipeline_sha256"],
        atoms=result["atoms"], atoms_full=result["atoms_full"], readings=result["readings"], source_pages=normalized_pages,
        selected_reading_id=result.get("selected_reading_id"), assessment_scope=result.get("assessment_scope"),
        source_pool_scope=result["source_pool_scope"], processing_budget=processing_budget,
        source_metadata_presence=result["source_metadata_presence"],
        trace=result["trace"], digest=result["digest"], native_method=False, world_truth_certified=False)
    check_pipeline()
    result["sha256"] = sha(result)
    return result
