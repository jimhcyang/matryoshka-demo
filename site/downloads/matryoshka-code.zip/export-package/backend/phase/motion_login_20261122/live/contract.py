"""Closed browser contract. No client-selected files, models or source policies."""
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import re
import shutil

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
ROOT = PHASE.parents[1]
WORKSPACE = ROOT.parent
STATE = ROOT / "phase/interactive_release_20261122/live/state"
API_ROOT = ROOT / "experiments/narrative_demo/api"
REFS = ROOT / "experiments/current_refresh/resource_handoff/registries/db09a0bd26047428e9350b57/execution_refs_v01.json"
MODEL = "gpt-6.1-sol"
ANALYST_ORIGIN_PREFIX = 'live-analyst-origin:'
MIN_FREE = 3 * 1024**3
MAX_BODY = 8192
MAX_QUERY = 2000
TERMINAL = {"completed", "failed", "cancelled", "timed_out", "resource_limited"}
STAGES = {"queued", "validating", "planning", "model_readings", "opening_resources",
          "retrieval", "construction", "task_decisions", "projection", "saving"} | TERMINAL


class Reject(Exception):
    def __init__(self, code, status=400):
        self.code, self.status = code, status


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                      separators=(",", ":")).encode()


def sha(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def headroom(path=HERE):
    if shutil.disk_usage(path).free < MIN_FREE:
        raise Reject("DISK_FLOOR_3_GIB", 507)


def validate(value):
    required = {"task", "corpus", "query", "as_of", "excluded_origin", "focal_marker"}
    optional = {'as_of', 'excluded_origin'}
    if not isinstance(value, dict) or set(value) - required or required - optional - set(value):
        raise Reject("EXACT_REQUEST_FIELDS_REQUIRED")
    value = {key: value.get(key, '') for key in required}
    if not all(isinstance(value[k], str) for k in required):
        raise Reject("STRING_FIELDS_REQUIRED")
    if value["task"] not in {"mosaic", "hypothesis", "redaction"}:
        raise Reject("TASK_NOT_ALLOWED")
    if value["corpus"] not in {"cib", "iran", "vietnam"}:
        raise Reject("CORPUS_NOT_ALLOWED")
    query = value["query"]
    if (not query.strip() or query != query.strip() or len(query.encode()) > MAX_QUERY
            or any(ord(c) < 32 and c not in "\n\t" for c in query)):
        raise Reject("QUERY_SIZE_OR_FORMAT")
    if re.search(r"\bsk-[A-Za-z0-9_-]{12,}|\bBearer\s+\S{12,}|OPENAI_API_KEY\s*=",
                 query + '\n' + value['excluded_origin'], re.I):
        raise Reject("DO_NOT_SUBMIT_CREDENTIALS")
    if not value['as_of']:
        from scope_defaults import corpus_defaults
        try:
            value['as_of'] = corpus_defaults()['corpora'][value['corpus']]['last_date']
        except (OSError, ValueError, KeyError):
            raise Reject('CORPUS_DATE_DEFAULT_UNAVAILABLE', 503) from None
    try:
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value["as_of"]):
            raise ValueError()
        day = date.fromisoformat(value["as_of"])
        if not date(1900, 1, 1) <= day <= date.today():
            raise ValueError()
    except ValueError:
        raise Reject("AS_OF_DATE_REQUIRED") from None
    value['excluded_origin'] = value['excluded_origin'].strip()
    analyst_id = ANALYST_ORIGIN_PREFIX + sha(dict(value, excluded_origin=''))[:32]
    if not value['excluded_origin']:
        value['excluded_origin'] = analyst_id
    if (not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,159}", value["excluded_origin"])
            or value['excluded_origin'].startswith(ANALYST_ORIGIN_PREFIX) and value['excluded_origin'] != analyst_id):
        raise Reject("WHOLE_ORIGIN_ID_REQUIRED")
    # Blank origin means no document exclusion. The reserved internal ID keeps
    # the native case/cache contract intact; it is not a historical document.
    if value["task"] == "redaction":
        marker = value["focal_marker"]
        if (not re.fullmatch(r"\[\[REDACTION_SLOT:[A-Za-z0-9_-]{1,64}\]\]|\[(?:REDACTION(?:[ _]\d+)?|REDACTED|STILL REDACTED|MASKED|MASK)\]", marker, re.I)
                or query.count(marker) != 1):
            raise Reject("UNIQUE_FOCAL_MASK_REQUIRED")
    elif value["focal_marker"] or re.search(r"\[\[REDACTION_SLOT:|\[(?:REDACT|MASK|STILL REDACTED)", query, re.I):
        raise Reject("COMPLETE_CLAUSE_CANNOT_HAVE_MASK")
    if query.endswith("?") or re.match(r"^(assess|reconstruct|identify|determine|evaluate|trace|provide|summarize|explain|describe|test)\b", query, re.I):
        raise Reject("DECLARATIVE_CLAUSE_REQUIRED")
    return dict(value)


def case_for(request):
    return dict(case_id="live_" + sha(request)[:24], task=request["task"], corpus=request["corpus"],
                query=request["query"], date=request["as_of"], document_id=request["excluded_origin"],
                focal_marker=request["focal_marker"])


def scope_for(request):
    import sys
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    from matryoshka_demo.source_view_policy import descriptor, LIVE_THROUGH_WITH_EARLIER_ORIGIN
    analyst = request['excluded_origin'].startswith(ANALYST_ORIGIN_PREFIX)
    excluded = None if analyst or request['corpus'] == 'cib' else request['excluded_origin']
    return dict(corpus=request["corpus"], on_or_before=request["as_of"],
                excluded_whole_origin=excluded, origin_is_analyst_declared=True,
                origin_document=None if analyst else request['excluded_origin'],
                origin_kind='analyst_authored' if analyst else 'source_document' if request['corpus'] == 'cib' else 'document_exclusion',
                source_view_policy=descriptor(LIVE_THROUGH_WITH_EARLIER_ORIGIN),
                document_exclusion=excluded,
                evidence_through=request['as_of'],
                release_visibility=["earlier", "both"], permitted_only=True,
                handling_policy="CIB paired earlier; cables CONFIDENTIAL, document-wide NOFORN veto",
                resource_status="SOURCE_ONLY_CURRENT" if request["corpus"] == "cib" else "INCUMBENT_NOT_MIGRATED",
                supplied_pages_scope="INSPECTED_REFERENCED_PAGES_ONLY",
                document_pages_scope="ALL_POLICY_ELIGIBLE_BOUND_PAGES_FOR_REFERENCED_DOCUMENTS; PROVENANCE_ONLY; NOT_EXTRA_EVIDENCE",
                full_documents_supplied=False)


def read_json(path):
    return json.loads(Path(path).read_bytes())


def write_json(path, value):
    headroom()
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    raw = encoded(value)
    if len(raw) > 24 * 1024**2:
        raise Reject("ARTIFACT_SIZE_LIMIT", 507)
    if shutil.disk_usage(HERE).free - len(raw) < MIN_FREE:
        raise Reject("DISK_FLOOR_3_GIB", 507)
    temporary = path.with_suffix(path.suffix + ".writing")
    with temporary.open("wb") as stream:
        stream.write(raw)
    temporary.chmod(0o600)
    temporary.replace(path)


def ledger_total():
    # Refuse a missing/reset/foreign ledger rather than starting another one.
    auth = read_json(API_ROOT / "authorization.json")
    if auth != dict(version="narrative-development-api/1", authorization="narrative-demo-new-phase-50-usd", ceiling_usd=50.0):
        raise Reject("SHARED_LEDGER_NOT_READY", 503)
    import math
    total = 0.0
    for path in (API_ROOT / "receipts").glob("*.json"):
        record = read_json(path)
        amount = record.get("charged_or_reserved_usd")
        if (record.get("authorization") != auth["authorization"] or type(amount) not in (int, float)
                or not math.isfinite(amount) or not 0 <= amount <= 50):
            raise Reject("SHARED_LEDGER_INVALID", 503)
        total += amount
    if total > 50:
        raise Reject("SHARED_LEDGER_LIMIT", 503)
    return total
