"""API0 verifier-only local setup and legacy migration."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from auth import PasswordVerifier

SCRIPT = Path(__file__).resolve().parents[3] / 'scripts/start_live_local.py'
spec = importlib.util.spec_from_file_location('local_live_operator', SCRIPT)
operator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(operator)
PASSWORD = 'local-fixture-only-J7u5tP9w2z'


class OperatorTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.verifier = PasswordVerifier.make(PASSWORD)

    def test_legacy_migration_preserves_login_and_removes_plaintext(self):
        with tempfile.TemporaryDirectory() as root:
            directory = Path(root)
            path = directory / 'credentials.json'
            path.write_text(json.dumps(dict(version='matryoshka-local-access/1', password=PASSWORD,
                                           verifier=self.verifier.export())))
            path.chmod(0o600)
            verifier, actual = operator.private_credentials(directory)
            self.assertEqual(actual, path)
            self.assertEqual(verifier.export(), self.verifier.export())
            self.assertTrue(verifier.verify(PASSWORD))
            self.assertEqual(set(json.loads(path.read_bytes())), {'version', 'verifier'})
            self.assertNotIn(PASSWORD, path.read_text())
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            self.assertEqual(list(directory.iterdir()), [path])
            before = path.read_bytes()
            operator.private_credentials(directory)
            self.assertEqual(path.read_bytes(), before)

    def test_new_configuration_uses_hidden_input_and_no_plaintext(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(operator.sys.stdin, 'isatty', return_value=True), \
                 patch.object(operator.getpass, 'getpass', side_effect=[PASSWORD, PASSWORD]):
                verifier, path = operator.private_credentials(Path(root))
            self.assertTrue(verifier.verify(PASSWORD))
            self.assertEqual(set(json.loads(path.read_bytes())), {'version', 'verifier'})
            self.assertNotIn(PASSWORD, path.read_text())

    def test_noninteractive_missing_configuration_fails_without_creating_secret(self):
        with tempfile.TemporaryDirectory() as root:
            with patch.object(operator.sys.stdin, 'isatty', return_value=False):
                with self.assertRaises(ValueError):
                    operator.private_credentials(Path(root))
            self.assertFalse(list(Path(root).iterdir()))

    def test_unsafe_file_permissions_and_symlinks_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            directory = Path(root)
            target = directory / 'elsewhere'
            target.write_text('{}')
            path = directory / 'credentials.json'
            path.symlink_to(target)
            with self.assertRaises(ValueError):
                operator.private_credentials(directory)
            path.unlink()
            path.write_text('{}')
            path.chmod(0o644)
            with self.assertRaises(ValueError):
                operator.private_credentials(directory)


if __name__ == '__main__':
    unittest.main()
