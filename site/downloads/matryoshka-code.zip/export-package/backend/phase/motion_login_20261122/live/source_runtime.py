"""Private Live bridge to saved source engines and the EXISTING Live $50 ledger.

No credential loading, ledger initialization, saved-case selection or calls on import.
"""
from copy import deepcopy
from functools import lru_cache
import ast
import hashlib
import importlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
from types import SimpleNamespace

from contract import API_ROOT, MODEL, ROOT, encoded, ledger_total, read_json, sha, write_json

PHASE = ROOT / "phase/demo_refinement_20261126"
VERSION = "private-live-source-runtime/1"
MAX_INPUT = 262144
DECLARED_PHASE_FILES = (
    "digests_v3/v4/builder.py", "semantic_assessment/producer.py",
    "semantic_assessment_v3/producer_v3.py", "semantic_assessment_v3/coverage_review_v1/adapter.py",
    "semantic_assessment_v3/coverage_review_v1/runtime.py", "semantic_assessment_v4/producer_v4.py",
    "semantic_assessment_v5/producer_v5.py", "source_nominations/wire.py",
    "source_nominations_v2/wire_v2.py", "source_nominations_v3/wire_v3.py",
    "source_nominations_v4/dependency.py", "source_nominations_v5/loader.py", "source_nominations_v5/projector.py",
    "source_proposals_v7/corpus_loader.py", "source_proposals_v7/protocol.py",
    "source_proposal_admission_v1/admission.py", "source_proposal_admission_v1/common.py",
    "source_proposal_admission_v1/executor_adapter.py", "source_proposal_admission_v1/focal_constraints.py",
    "source_proposal_admission_v1/grammar.py", "source_proposal_admission_v1/scoring.py",
    "source_realized_digest_v1/adapter.py")
DECLARED_LIVE_FILES = ("worker.py", "packing.py", "source_inference.py", "source_runtime.py", "source_proposal_policy.py",
    "source_readings.py", "contract.py", "scope_defaults.py", "server.py", "auth.py", "allocations.py")
DIGEST_RESERVE_USD = .07
DIGEST_SECONDS = 25
DIGEST_BODY_LIMIT = 65536
OUTPUT_LIMITS = dict(live_r_proposal_v1=6144, live_r_proposal_review_v1=4096,
    live_r_focal_assessment_v1=16384, live_r_focal_review_v1=4096,
    live_m_assessment_v1=16384, live_m_review_v1=16384,
    live_h_assessment_v1=16384, live_h_review_v1=16384, live_selected_source_digest_v1=1024)


def specialize_response(payload, schema):
    """Strict metadata-only output subsets; never modify a provider response."""
    value = json.loads(json.dumps(schema, allow_nan=False))
    props = value.get("properties", {})
    for key, expected in (("request_sha256", payload.get("request_sha256")),
                          ("batch_sha256", payload.get("binding", {}).get("batch_sha256"))):
        if key in props and expected is not None:
            require(isinstance(expected, str) and re.fullmatch(r"[a-f0-9]{64}", expected), "INVALID_TRUSTED_OUTPUT_BINDING")
            props[key]["enum"] = [expected]
    if "items" in payload:
        ids = [item["candidate_id"] for item in payload["items"]]
        require(ids and len(ids) <= 8 and all(isinstance(i,str) and i for i in ids)
            and len(ids) == len(set(ids)), "INVALID_TRUSTED_CANDIDATE_MATRIX")
        for key in ("rows", "reviews"):
            array = props.get(key)
            if array and "candidate_id" in array.get("items", {}).get("properties", {}):
                require(len(ids) <= array.get("maxItems", 8), "DECLARED_OUTPUT_BOUND_EXCEEDED")
                array.update(minItems=len(ids), maxItems=len(ids))
                array["items"]["properties"]["candidate_id"]["enum"] = ids
    return value


def bounded_schema(stage, schema):
    """Strict output subsets, not rewritten/truncated model responses or sources."""
    # deepcopy preserves shared child identities in historical schema builders.
    # JSON copies each occurrence independently before applying per-field limits.
    value = json.loads(json.dumps(schema, allow_nan=False))
    def walk(node):
        if not isinstance(node, dict):
            return
        for key, prop in node.get("properties", {}).items():
            if key in {"proposals", "rows", "reviews"} and stage.startswith("live_r_"):
                prop["maxItems"] = min(prop.get("maxItems", 8), 8)
            if key in {"query_quotes", "source_quotes", "fill_quotes", "public_scope_quotes", "qualifier_quotes"}:
                prop["maxItems"] = min(prop.get("maxItems", 2), 2)
                prop["items"]["maxLength"] = min(prop["items"].get("maxLength", 512), 512)
            if key == "source_anchors":
                prop["maxItems"] = min(prop.get("maxItems", 3), 3)
            if key in {"fill", "source_phrase", "description"}:
                prop["maxLength"] = min(prop.get("maxLength", 256), 256)
            if key in {"quote", "argument_quote", "speaker_quote", "reason"}:
                if prop.get("type") == "null":
                    continue
                bound = 512 if stage.startswith("live_r_") and key == "quote" else 2048 if key == "quote" else 1024 if key == "argument_quote" else 256 if key == "speaker_quote" else 500
                prop["maxLength"] = min(prop.get("maxLength", bound), bound)
        for item in node.values():
            if isinstance(item, dict):
                walk(item)
            elif isinstance(item, list):
                for child in item:
                    walk(child)
    walk(value)
    return value


def h_assessment_schema(base):
    """Strict wire subsets of V5; grounding/review rules remain unchanged."""
    value = json.loads(json.dumps(base, allow_nan=False))
    row = value["properties"]["judgments"]["items"]
    variants = []
    for kind in ("NONE", "CONTEXT", "DIRECTIONAL"):
        item = json.loads(json.dumps(row))
        p = item["properties"]
        p["direction"]["enum"] = ["SUPPORT", "OPPOSE"] if kind == "DIRECTIONAL" else [kind]
        p["kind"]["enum"] = ["DIRECT_STANCE", "REASONED_ARGUMENT"] if kind == "DIRECTIONAL" else [kind]
        p["quote"] = dict(type="null") if kind == "NONE" else dict(type="string", minLength=1)
        if kind == "NONE":
            p["argument_quote"] = dict(type="null")
            p["qualifier_quotes"]["maxItems"] = 0
            p["attribution"]["properties"]["kind"]["enum"] = ["UNRESOLVED"]
            p["attribution"]["properties"]["speaker_quote"] = dict(type="null")
            p["mode"]["enum"] = ["NONE"]
            p["issue"]["properties"]["source_quotes"]["maxItems"] = 0
            for facet in p["fields"]["properties"].values():
                facet["properties"]["state"]["enum"] = ["MISSING", "NOT_REQUESTED"]
                facet["properties"]["source_quotes"]["maxItems"] = 0
        variants.append(item)
    value["properties"]["judgments"]["items"] = dict(anyOf=variants)
    return value


def safe_error(error):
    text = str(error)
    key = os.environ.get("OPENAI_API_KEY", "").strip()
    if key:
        text = text.replace(key, "[REDACTED_CREDENTIAL]")
    return re.sub(r"(?i)\bBearer\s+\S+|\bsk-[A-Za-z0-9_-]{12,}", "[REDACTED_CREDENTIAL]", text)[:2000]


def require(value, code):
    if not value:
        raise ValueError(code)


@lru_cache(maxsize=1)
def engines():
    """Import reusable algorithms, NEVER their cohort loaders/executors' run methods."""
    def module(name, folder):
        path = PHASE / folder / (name + ".py")
        prior = sys.modules.get(name)
        require(prior is None or Path(prior.__file__).resolve() == path, "SOURCE_ENGINE_MODULE_COLLISION")
        sys.path.insert(0, str(path.parent))
        return importlib.import_module(name)
    proposal = module("protocol", "source_proposals_v7")
    module("common", "source_proposal_admission_v1")
    grammar = module("grammar", "source_proposal_admission_v1")
    focal = module("focal_constraints", "source_proposal_admission_v1")
    module("runtime", "semantic_assessment_v3/coverage_review_v1")
    m = module("producer_v4", "semantic_assessment_v4")
    historical_h = module("producer_v5", "semantic_assessment_v5")
    spec = importlib.util.spec_from_file_location("_private_live_h_v5", historical_h.__file__)
    h = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = h
    spec.loader.exec_module(h)
    h.PROMPT += (" Wire consistency: NONE has quote=null, kind=NONE, mode=NONE, attribution "
        "UNRESOLVED with speaker_quote=null, argument_quote=null, no qualifier quotes and NO source "
        "quotes in ANY issue/facet field. Explain irrelevance in reason, not source anchors. "
        "CONTEXT must carry a UNIQUE exact nonempty main quote, kind=CONTEXT, and literal source "
        "qualifications/attribution; CONTEXT is not SUPPORT or OPPOSE. Never omit a main quote "
        "merely because a related account is not directional evidence.")
    # Separate module globals preserve historical provenance and schema contracts.
    # The R focal validator needs only these codecs. Its saved executor/authority
    # functions remain uncalled; Live attests its OWN ledger rather than that ledger.
    focal.backend = lambda: SimpleNamespace(Q=proposal, W=proposal.W, encoded=proposal.W.encoded)
    digest_path = PHASE / "digests_v3/v4/builder.py"
    constants = {}
    for node in ast.parse(digest_path.read_text()).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {"PROMPT", "SCHEMA"} for t in node.targets):
            constants[node.targets[0].id] = ast.literal_eval(node.value)
    r_digest_path = PHASE / "source_realized_digest_v1/adapter.py"
    for node in ast.parse(r_digest_path.read_text()).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PROMPT" for t in node.targets):
            require(isinstance(node.value, ast.BinOp) and isinstance(node.value.op, ast.Add), "R_DIGEST_PROMPT_SHAPE_CHANGED")
            constants["R_PROMPT"] = constants["PROMPT"] + ast.literal_eval(node.value.right)
    return SimpleNamespace(proposal=proposal, grammar=grammar, focal=focal, m=m, h=h, v3=m.V3,
        digest_prompt=constants["PROMPT"], r_digest_prompt=constants["R_PROMPT"], digest_schema=constants["SCHEMA"])


def identity():
    """Declared code closure, independent of which modules a stage has imported."""
    engines()
    from matryoshka_narrative.workflow import code_pins
    native = code_pins()
    paths = {ROOT / name for name in native}
    paths.update(PHASE / name for name in DECLARED_PHASE_FILES)
    paths.update(ROOT / "phase/motion_login_20261122/live" / name for name in DECLARED_LIVE_FILES)
    paths.add(ROOT / "scripts/start_live_local.py")
    files = []
    for path in sorted(paths):
        require(path.resolve() == path and path.is_relative_to(ROOT) and not path.is_symlink(), "UNSAFE_DECLARED_CODE_PATH")
        checksum = hashlib.sha256(path.read_bytes()).hexdigest()
        name = path.relative_to(ROOT).as_posix()
        require(name not in native or native[name] == checksum, "NATIVE_CODE_CHANGED_DURING_IDENTITY")
        files.append(dict(path=name, sha256=checksum))
    return dict(version=VERSION, files=files)


class Runtime:
    def __init__(self, directory, *, cap, execution_epoch=None):
        require(execution_epoch is None or isinstance(execution_epoch, str) and re.fullmatch(r"[a-f0-9]{8}", execution_epoch),
            "CLOSED_EXECUTION_EPOCH_REQUIRED")
        self.directory = Path(directory)
        self.api_root = API_ROOT
        self.cap = cap
        self.receipts = []
        self.provider_ids = set()
        self.budget_plan = None
        self.source_attempts = 0
        self.output_limits = deepcopy(OUTPUT_LIMITS)
        self.execution_epoch = execution_epoch
        self.call_events = []

    def available(self):
        ceiling = self.cap
        baseline = os.environ.get("NARRATIVE_INCREMENTAL_BASELINE_USD")
        increment = os.environ.get("NARRATIVE_INCREMENTAL_CEILING_USD")
        require((baseline is None) == (increment is None), "INCOMPLETE_LIVE_JOB_ENVELOPE")
        if baseline is not None:
            ceiling = min(ceiling, float(baseline)+float(increment))
        return max(0., ceiling-ledger_total())

    def configure(self, task, *, maximum_source_calls=None, matrix_rows=4):
        from matryoshka_narrative import api
        if matrix_rows <= 4:
            for name in ("live_m_assessment_v1", "live_m_review_v1", "live_h_assessment_v1", "live_h_review_v1"):
                self.output_limits[name] = 8192
        self.budget_plan = dict(version="private-live-source-processing-budget/4", task=task,
            available_after_planning_usd=self.available(), digest_earmark_usd=DIGEST_RESERVE_USD,
            digest_time_earmark_seconds=DIGEST_SECONDS,
            maximum_model_stages=maximum_source_calls if maximum_source_calls is not None else 5 if task=="redaction" else 3,
            maximum_fact_page_rows=matrix_rows, output_token_limits=deepcopy(self.output_limits), digest_body_bytes_limit=DIGEST_BODY_LIMIT,
            existing_job_and_shared_caps_unchanged=True, earmark_is_not_a_paid_ledger_reservation=True,
            full_completion_guaranteed=False)
        self.budget_plan["model_cache_epoch"] = self.execution_epoch
        self.budget_plan["review_body_bytes_limit"] = MAX_INPUT-2048 if task in {"mosaic", "hypothesis"} else None
        self.budget_plan["assessment_review_digest_preflight"] = task in {"mosaic", "hypothesis"}
        self.budget_plan["source_timeout_policy"] = "PER_CALL_MIN_90_REMAINING_MINUS_DIGEST"
        self.budget_plan["maximum_response_seconds"] = 90
        self.budget_plan["digest_reservation_policy"] = "ACTUAL_RESERVATION_WITHIN_EXISTING_CAPS_MINIMUM_EARMARK_ONLY"
        self.budget_plan["review_reservation_policy"] = "MINIMUM_EARMARK_FULL_ACTUAL_REVIEW_RESERVATION_REQUIRED"
        review_stage = "live_h_review_v1" if task == "hypothesis" else "live_m_review_v1"
        rates = api.RATES[MODEL]
        self.budget_plan["review_minimum_earmark_usd"] = max(.10, (4096*rates[0]+self.output_limits[review_stage]*rates[1])/1e6) if task in {"mosaic", "hypothesis"} else None
        self.budget_plan["review_completion_guaranteed"] = False
        self.completed_stages = 0
        return deepcopy(self.budget_plan)

    def invoke(self, stage, payload, prompt, schema, *, max_output_tokens=16384):
        from matryoshka_narrative import api
        # Check before api.Budget could create anything. This bridge NEVER creates
        # or adopts an authorization and cannot expand the existing job envelope.
        require(bool(os.environ.get("OPENAI_API_KEY", "").strip()), "LIVE_SOURCE_KEY_UNCONFIGURED")
        ledger_total()
        max_output_tokens = min(max_output_tokens, self.output_limits.get(stage, max_output_tokens))
        schema = bounded_schema(stage, specialize_response(payload, schema))
        call_stage = "p_"+self.execution_epoch+"_"+stage if self.execution_epoch else stage
        require(len(call_stage) <= 64, "SOURCE_STAGE_NAME_BOUND")
        body = api.request(call_stage, payload, prompt, schema, model=MODEL, max_output_tokens=max_output_tokens)
        require(len(encoded(body)) + 2048 <= MAX_INPUT, "SOURCE_BODY_OVERSIZE_NO_CLIPPING")
        mh_review = stage in {"live_m_review_v1", "live_h_review_v1"}
        mh_assessment = stage in {"live_m_assessment_v1", "live_h_assessment_v1"}
        if self.budget_plan is not None and mh_review:
            require(len(encoded(body)) <= self.budget_plan["review_body_bytes_limit"], "SOURCE_REVIEW_BODY_OVERSIZE_NO_CLIPPING")
        key = sha(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=call_stage, request=body))
        cached = (self.api_root / "cache" / (key+".json")).is_file()
        digest_stage = stage == "live_selected_source_digest_v1"
        if self.budget_plan is not None and not cached:
            rates = api.RATES[MODEL]
            reserve = ((len(json.dumps(body, ensure_ascii=True).encode())+4096)*rates[0] + max_output_tokens*rates[1])/1e6
            if digest_stage:
                require(len(encoded(body)) <= DIGEST_BODY_LIMIT, "DIGEST_BODY_BOUND_NO_CLIPPING")
            else:
                self.source_attempts += 1
            review_reserve = 0.
            if mh_assessment:
                review_reserve = self.budget_plan["review_minimum_earmark_usd"]
            if reserve+review_reserve+(0. if digest_stage else DIGEST_RESERVE_USD) > self.available()+1e-10:
                raise RuntimeError("Live source budget preserves the digest earmark")
        old_timeout = os.environ.get("MATRYOSHKA_API_RESPONSE_SECONDS")
        if self.budget_plan is not None and not cached:
            from matryoshka_narrative.guards import remaining_seconds
            remaining = remaining_seconds(new_work=True)
            seconds = 90.
            if remaining is not None:
                if not digest_stage and remaining <= DIGEST_SECONDS+2:
                    raise RuntimeError("Live source time preserves the digest earmark")
                seconds = remaining if digest_stage else remaining-DIGEST_SECONDS
            os.environ["MATRYOSHKA_API_RESPONSE_SECONDS"] = str(min(90., float(old_timeout or 90), max(1., seconds)))
        try:
            output, meta = api.call(self.api_root, call_stage, payload, prompt, schema, model=MODEL,
                max_output_tokens=max_output_tokens, cap=self.cap)
            self.call_events.append(dict(stage=stage, cache_stage=call_stage,
                cache_hit=meta.get("cache") is True, receipt=meta.get("receipt")))
        finally:
            if self.budget_plan is not None and not digest_stage:
                self.completed_stages += 1
            if old_timeout is None:
                os.environ.pop("MATRYOSHKA_API_RESPONSE_SECONDS", None)
            else:
                os.environ["MATRYOSHKA_API_RESPONSE_SECONDS"] = old_timeout
        receipt = self.attest(body, output, meta)
        self.receipts.append(receipt)
        return output, receipt

    def attest(self, body, output, meta):
        from matryoshka_narrative import api
        from matryoshka_demo.api_v2 import RATES
        import math
        def unique_object(pairs):
            value = {}
            for key, child in pairs:
                require(key not in value, "DUPLICATE_PROVIDER_OUTPUT_KEY")
                value[key] = child
            return value
        def finite_number(value):
            number = float(value)
            require(math.isfinite(number), "NONFINITE_PROVIDER_OUTPUT_NUMBER")
            return number
        relative = meta.get("receipt")
        require(isinstance(relative, str) and re.fullmatch(r"receipts/[a-f0-9]{32}\.json", relative), "SOURCE_RECEIPT_PATH")
        call_id = Path(relative).stem
        attempt = self.api_root / "attempts" / call_id
        key = sha(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=body["text"]["format"]["name"], request=body))
        paths = dict(request=attempt / "request.json", response=attempt / "response.json",
            receipt=self.api_root / relative, cache=self.api_root / "cache" / (key + ".json"))
        require(all(not p.is_symlink() and p.resolve().is_relative_to(self.api_root.resolve()) for p in paths.values()), "UNSAFE_SOURCE_CALL_PATH")
        values = {k: read_json(p) for k, p in paths.items()}
        raw, record, cache = values["response"], values["receipt"], values["cache"]
        texts = [part["text"] for item in raw.get("output", []) if item.get("type") == "message"
                 for part in item.get("content", []) if part.get("type") == "output_text"]
        require(raw.get("status") == "completed" and len(texts) == 1 and isinstance(texts[0], str), "ONE_COMPLETED_SOURCE_OUTPUT_REQUIRED")
        strict_output = json.loads(texts[0], object_pairs_hook=unique_object,
            parse_float=finite_number, parse_constant=finite_number)
        usage = api._usage(raw)
        rates = RATES[MODEL]
        cost = (usage["input_tokens"] * rates[0] + usage["output_tokens"] * rates[1]) / 1e6
        require(values["request"] == body and record.get("status") == "PASS"
            and record.get("authorization") == api.AUTHORIZATION and record.get("model") == MODEL
            and record.get("request_sha256") == sha(body) and record.get("response_sha256") == sha(raw)
            and record.get("usage") == usage and record.get("charged_or_reserved_usd") == cost
            and record.get("rates") == list(rates)
            and record.get("response_id") == raw.get("id") and isinstance(raw.get("id"), str) and bool(raw["id"])
            and strict_output == output and cache == dict(version=api.VERSION, request=body,
                output=output, output_sha256=sha(output), receipt_path=relative), "SOURCE_PROVIDER_ARTIFACTS_DIFFER")
        import jsonschema
        jsonschema.validate(output, body["text"]["format"]["schema"])
        require(raw["id"] not in self.provider_ids, "SOURCE_STAGES_REUSE_PROVIDER_RESPONSE")
        self.provider_ids.add(raw["id"])
        def reference(path):
            return dict(path=str(path.relative_to(ROOT)), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        proof = dict(kind="MODEL_SEMANTIC_JUDGMENT", call_id=call_id, model=MODEL,
            receipt=relative, provider_response_id=raw["id"],
            actual_request_ref=reference(paths["request"]), actual_response_ref=reference(paths["response"]),
            actual_api_receipt_ref=reference(paths["receipt"]), actual_cache_ref=reference(paths["cache"]))
        # Saved M/H validators require these normalized wrappers, all tied to the
        # actual four retained provider artifacts, not a caller-supplied trust flag.
        # Stable across different jobs: job-local wrapper references in a review
        # payload would defeat exact-cache reuse despite identical model inputs.
        folder = self.api_root / "live-source-proofs" / call_id
        require(not folder.is_symlink() and folder.resolve().is_relative_to(self.api_root.resolve()), "UNSAFE_SOURCE_PROOF_PATH")
        for name, value in (("request", dict(instructions=body["instructions"], input=json.loads(body["input"][0]["content"][0]["text"]))),
                            ("response", output), ("provider", proof)):
            path = folder / (name + ".json")
            require(not path.is_symlink(), "UNSAFE_SOURCE_PROOF_PATH")
            if path.exists():
                require(read_json(path) == value, "IMMUTABLE_SOURCE_STAGE_DIFFERS")
            else:
                write_json(path, value)
        return dict(kind=proof["kind"], stage="review" if "review" in body["text"]["format"]["name"] else "assessment",
            model=MODEL, call_id=call_id, request_ref=reference(folder / "request.json"),
            response_ref=reference(folder / "response.json"), provider_receipt_ref=reference(folder / "provider.json"))


def independent(first, second):
    require(first["call_id"] != second["call_id"], "SEPARATE_SOURCE_REVIEW_CALL_REQUIRED")
    a, b = read_json(ROOT / first["provider_receipt_ref"]["path"]), read_json(ROOT / second["provider_receipt_ref"]["path"])
    require(a["provider_response_id"] != b["provider_response_id"], "SEPARATE_SOURCE_REVIEW_RESPONSE_REQUIRED")
