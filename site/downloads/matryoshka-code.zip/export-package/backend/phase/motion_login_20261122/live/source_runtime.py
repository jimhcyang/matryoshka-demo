"""Private Live bridge to saved source engines and the EXISTING Live $50 ledger.

No credential loading, ledger initialization, saved-case selection or calls on import.
"""
from copy import deepcopy
from functools import lru_cache
import ast
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import sys
from types import SimpleNamespace

from contract import API_ROOT, MODEL, ROOT, encoded, ledger_total, read_json, sha, write_json

PHASE = ROOT / "phase/demo_refinement_20261126"
VERSION = "private-live-source-runtime/1"
MAX_INPUT = 262144
DECLARED_PHASE_FILES = (
    "digests_v3/v4/builder.py", "semantic_assessment/producer.py",
    "semantic_assessment_v3/producer_v3.py", "semantic_assessment_v3/coverage_review_v1/adapter.py",
    "semantic_assessment_v3/coverage_review_v1/runtime.py", "semantic_assessment_v4/producer_v4.py",
    "semantic_assessment_v5/producer_v5.py", "source_nominations/wire.py",
    "source_nominations_v2/wire_v2.py", "source_nominations_v3/wire_v3.py",
    "source_nominations_v4/dependency.py", "source_nominations_v5/loader.py", "source_nominations_v5/projector.py",
    "source_proposals_v7/corpus_loader.py", "source_proposals_v7/protocol.py",
    "source_proposal_admission_v1/admission.py", "source_proposal_admission_v1/common.py",
    "source_proposal_admission_v1/executor_adapter.py", "source_proposal_admission_v1/focal_constraints.py",
    "source_proposal_admission_v1/grammar.py", "source_proposal_admission_v1/scoring.py",
    "source_realized_digest_v1/adapter.py")
DECLARED_LIVE_FILES = ("worker.py", "packing.py", "source_inference.py", "source_runtime.py",
    "contract.py", "scope_defaults.py", "server.py", "auth.py", "allocations.py")
DIGEST_RESERVE_USD = .07
DIGEST_SECONDS = 25
OUTPUT_LIMITS = dict(live_r_proposal_v1=2048, live_r_proposal_review_v1=1536,
    live_r_focal_assessment_v1=4096, live_r_focal_review_v1=1536,
    live_m_assessment_v1=8192, live_m_review_v1=8192,
    live_h_assessment_v1=8192, live_h_review_v1=8192, live_selected_source_digest_v1=1024)


def bounded_schema(stage, schema):
    """Strict output subsets, not rewritten/truncated model responses or sources."""
    value = deepcopy(schema)
    def walk(node):
        if not isinstance(node, dict):
            return
        for key, prop in node.get("properties", {}).items():
            if key in {"proposals", "rows", "reviews"} and stage.startswith("live_r_"):
                prop["maxItems"] = min(prop.get("maxItems", 5), 5)
            if key in {"query_quotes", "source_quotes", "fill_quotes", "public_scope_quotes", "qualifier_quotes"}:
                prop["maxItems"] = min(prop.get("maxItems", 2), 2)
                prop["items"]["maxLength"] = min(prop["items"].get("maxLength", 512), 512)
            if key == "source_anchors":
                prop["maxItems"] = min(prop.get("maxItems", 3), 3)
            if key in {"fill", "source_phrase", "description"}:
                prop["maxLength"] = min(prop.get("maxLength", 256), 256)
            if key in {"quote", "argument_quote", "speaker_quote", "reason"}:
                bound = 512 if stage.startswith("live_r_") and key == "quote" else 2048 if key == "quote" else 1024 if key == "argument_quote" else 256 if key == "speaker_quote" else 500
                prop["maxLength"] = min(prop.get("maxLength", bound), bound)
        for item in node.values():
            if isinstance(item, dict):
                walk(item)
            elif isinstance(item, list):
                for child in item:
                    walk(child)
    walk(value)
    return value


def require(value, code):
    if not value:
        raise ValueError(code)


@lru_cache(maxsize=1)
def engines():
    """Import reusable algorithms, NEVER their cohort loaders/executors' run methods."""
    def module(name, folder):
        path = PHASE / folder / (name + ".py")
        prior = sys.modules.get(name)
        require(prior is None or Path(prior.__file__).resolve() == path, "SOURCE_ENGINE_MODULE_COLLISION")
        sys.path.insert(0, str(path.parent))
        return importlib.import_module(name)
    proposal = module("protocol", "source_proposals_v7")
    module("common", "source_proposal_admission_v1")
    grammar = module("grammar", "source_proposal_admission_v1")
    focal = module("focal_constraints", "source_proposal_admission_v1")
    module("runtime", "semantic_assessment_v3/coverage_review_v1")
    m = module("producer_v4", "semantic_assessment_v4")
    h = module("producer_v5", "semantic_assessment_v5")
    # The R focal validator needs only these codecs. Its saved executor/authority
    # functions remain uncalled; Live attests its OWN ledger rather than that ledger.
    focal.backend = lambda: SimpleNamespace(Q=proposal, W=proposal.W, encoded=proposal.W.encoded)
    digest_path = PHASE / "digests_v3/v4/builder.py"
    constants = {}
    for node in ast.parse(digest_path.read_text()).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id in {"PROMPT", "SCHEMA"} for t in node.targets):
            constants[node.targets[0].id] = ast.literal_eval(node.value)
    r_digest_path = PHASE / "source_realized_digest_v1/adapter.py"
    for node in ast.parse(r_digest_path.read_text()).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PROMPT" for t in node.targets):
            require(isinstance(node.value, ast.BinOp) and isinstance(node.value.op, ast.Add), "R_DIGEST_PROMPT_SHAPE_CHANGED")
            constants["R_PROMPT"] = constants["PROMPT"] + ast.literal_eval(node.value.right)
    return SimpleNamespace(proposal=proposal, grammar=grammar, focal=focal, m=m, h=h, v3=m.V3,
        digest_prompt=constants["PROMPT"], r_digest_prompt=constants["R_PROMPT"], digest_schema=constants["SCHEMA"])


def identity():
    """Declared code closure, independent of which modules a stage has imported."""
    engines()
    from matryoshka_narrative.workflow import code_pins
    native = code_pins()
    paths = {ROOT / name for name in native}
    paths.update(PHASE / name for name in DECLARED_PHASE_FILES)
    paths.update(ROOT / "phase/motion_login_20261122/live" / name for name in DECLARED_LIVE_FILES)
    paths.add(ROOT / "scripts/start_live_local.py")
    files = []
    for path in sorted(paths):
        require(path.resolve() == path and path.is_relative_to(ROOT) and not path.is_symlink(), "UNSAFE_DECLARED_CODE_PATH")
        checksum = hashlib.sha256(path.read_bytes()).hexdigest()
        name = path.relative_to(ROOT).as_posix()
        require(name not in native or native[name] == checksum, "NATIVE_CODE_CHANGED_DURING_IDENTITY")
        files.append(dict(path=name, sha256=checksum))
    return dict(version=VERSION, files=files)


class Runtime:
    def __init__(self, directory, *, cap):
        self.directory = Path(directory)
        self.api_root = API_ROOT
        self.cap = cap
        self.receipts = []
        self.provider_ids = set()
        self.budget_plan = None
        self.source_attempts = 0

    def available(self):
        ceiling = self.cap
        baseline = os.environ.get("NARRATIVE_INCREMENTAL_BASELINE_USD")
        increment = os.environ.get("NARRATIVE_INCREMENTAL_CEILING_USD")
        require((baseline is None) == (increment is None), "INCOMPLETE_LIVE_JOB_ENVELOPE")
        if baseline is not None:
            ceiling = min(ceiling, float(baseline)+float(increment))
        return max(0., ceiling-ledger_total())

    def configure(self, task):
        self.budget_plan = dict(version="private-live-source-processing-budget/1", task=task,
            available_after_planning_usd=self.available(), digest_earmark_usd=DIGEST_RESERVE_USD,
            digest_time_earmark_seconds=DIGEST_SECONDS, maximum_model_stages=5 if task=="redaction" else 3,
            output_token_limits=deepcopy(OUTPUT_LIMITS), digest_body_bytes_limit=24576,
            existing_job_and_shared_caps_unchanged=True, earmark_is_not_a_paid_ledger_reservation=True,
            full_completion_guaranteed=False)
        return deepcopy(self.budget_plan)

    def invoke(self, stage, payload, prompt, schema, *, max_output_tokens=16384):
        from matryoshka_narrative import api
        # Check before api.Budget could create anything. This bridge NEVER creates
        # or adopts an authorization and cannot expand the existing job envelope.
        require(bool(os.environ.get("OPENAI_API_KEY", "").strip()), "LIVE_SOURCE_KEY_UNCONFIGURED")
        ledger_total()
        max_output_tokens = min(max_output_tokens, OUTPUT_LIMITS.get(stage, max_output_tokens))
        schema = bounded_schema(stage, schema)
        body = api.request(stage, payload, prompt, schema, model=MODEL, max_output_tokens=max_output_tokens)
        require(len(encoded(body)) + 2048 <= MAX_INPUT, "SOURCE_BODY_OVERSIZE_NO_CLIPPING")
        key = sha(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=stage, request=body))
        cached = (self.api_root / "cache" / (key+".json")).is_file()
        digest_stage = stage == "live_selected_source_digest_v1"
        if self.budget_plan is not None and not cached:
            rates = api.RATES[MODEL]
            reserve = ((len(json.dumps(body, ensure_ascii=True).encode())+4096)*rates[0] + max_output_tokens*rates[1])/1e6
            if digest_stage:
                require(len(encoded(body)) <= 24576 and reserve <= DIGEST_RESERVE_USD, "DIGEST_DECLARED_RESERVATION_BOUND")
            else:
                self.source_attempts += 1
            if reserve+(0. if digest_stage else DIGEST_RESERVE_USD) > self.available()+1e-10:
                raise RuntimeError("Live source budget preserves the digest earmark")
        old_timeout = os.environ.get("MATRYOSHKA_API_RESPONSE_SECONDS")
        if self.budget_plan is not None and not cached:
            from matryoshka_narrative.guards import remaining_seconds
            remaining = remaining_seconds(new_work=True)
            if remaining is not None:
                if not digest_stage and remaining <= DIGEST_SECONDS+2:
                    raise RuntimeError("Live source time preserves the digest earmark")
                stages = max(1, self.budget_plan["maximum_model_stages"]-self.source_attempts)
                seconds = remaining if digest_stage else (remaining-DIGEST_SECONDS)/stages
                os.environ["MATRYOSHKA_API_RESPONSE_SECONDS"] = str(min(float(old_timeout or 90), max(1., seconds)))
        try:
            output, meta = api.call(self.api_root, stage, payload, prompt, schema, model=MODEL,
                max_output_tokens=max_output_tokens, cap=self.cap)
        finally:
            if old_timeout is None:
                os.environ.pop("MATRYOSHKA_API_RESPONSE_SECONDS", None)
            else:
                os.environ["MATRYOSHKA_API_RESPONSE_SECONDS"] = old_timeout
        receipt = self.attest(body, output, meta)
        self.receipts.append(receipt)
        return output, receipt

    def attest(self, body, output, meta):
        from matryoshka_narrative import api
        from matryoshka_demo.api_v2 import RATES
        import math
        def unique_object(pairs):
            value = {}
            for key, child in pairs:
                require(key not in value, "DUPLICATE_PROVIDER_OUTPUT_KEY")
                value[key] = child
            return value
        def finite_number(value):
            number = float(value)
            require(math.isfinite(number), "NONFINITE_PROVIDER_OUTPUT_NUMBER")
            return number
        relative = meta.get("receipt")
        require(isinstance(relative, str) and re.fullmatch(r"receipts/[a-f0-9]{32}\.json", relative), "SOURCE_RECEIPT_PATH")
        call_id = Path(relative).stem
        attempt = self.api_root / "attempts" / call_id
        key = sha(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=body["text"]["format"]["name"], request=body))
        paths = dict(request=attempt / "request.json", response=attempt / "response.json",
            receipt=self.api_root / relative, cache=self.api_root / "cache" / (key + ".json"))
        require(all(not p.is_symlink() and p.resolve().is_relative_to(self.api_root.resolve()) for p in paths.values()), "UNSAFE_SOURCE_CALL_PATH")
        values = {k: read_json(p) for k, p in paths.items()}
        raw, record, cache = values["response"], values["receipt"], values["cache"]
        texts = [part["text"] for item in raw.get("output", []) if item.get("type") == "message"
                 for part in item.get("content", []) if part.get("type") == "output_text"]
        require(raw.get("status") == "completed" and len(texts) == 1 and isinstance(texts[0], str), "ONE_COMPLETED_SOURCE_OUTPUT_REQUIRED")
        strict_output = json.loads(texts[0], object_pairs_hook=unique_object,
            parse_float=finite_number, parse_constant=finite_number)
        usage = api._usage(raw)
        rates = RATES[MODEL]
        cost = (usage["input_tokens"] * rates[0] + usage["output_tokens"] * rates[1]) / 1e6
        require(values["request"] == body and record.get("status") == "PASS"
            and record.get("authorization") == api.AUTHORIZATION and record.get("model") == MODEL
            and record.get("request_sha256") == sha(body) and record.get("response_sha256") == sha(raw)
            and record.get("usage") == usage and record.get("charged_or_reserved_usd") == cost
            and record.get("rates") == list(rates)
            and record.get("response_id") == raw.get("id") and isinstance(raw.get("id"), str) and bool(raw["id"])
            and strict_output == output and cache == dict(version=api.VERSION, request=body,
                output=output, output_sha256=sha(output), receipt_path=relative), "SOURCE_PROVIDER_ARTIFACTS_DIFFER")
        import jsonschema
        jsonschema.validate(output, body["text"]["format"]["schema"])
        require(raw["id"] not in self.provider_ids, "SOURCE_STAGES_REUSE_PROVIDER_RESPONSE")
        self.provider_ids.add(raw["id"])
        def reference(path):
            return dict(path=str(path.relative_to(ROOT)), sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        proof = dict(kind="MODEL_SEMANTIC_JUDGMENT", call_id=call_id, model=MODEL,
            receipt=relative, provider_response_id=raw["id"],
            actual_request_ref=reference(paths["request"]), actual_response_ref=reference(paths["response"]),
            actual_api_receipt_ref=reference(paths["receipt"]), actual_cache_ref=reference(paths["cache"]))
        # Saved M/H validators require these normalized wrappers, all tied to the
        # actual four retained provider artifacts, not a caller-supplied trust flag.
        # Stable across different jobs: job-local wrapper references in a review
        # payload would defeat exact-cache reuse despite identical model inputs.
        folder = self.api_root / "live-source-proofs" / call_id
        require(not folder.is_symlink() and folder.resolve().is_relative_to(self.api_root.resolve()), "UNSAFE_SOURCE_PROOF_PATH")
        for name, value in (("request", dict(instructions=body["instructions"], input=json.loads(body["input"][0]["content"][0]["text"]))),
                            ("response", output), ("provider", proof)):
            path = folder / (name + ".json")
            require(not path.is_symlink(), "UNSAFE_SOURCE_PROOF_PATH")
            if path.exists():
                require(read_json(path) == value, "IMMUTABLE_SOURCE_STAGE_DIFFERS")
            else:
                write_json(path, value)
        return dict(kind=proof["kind"], stage="review" if "review" in body["text"]["format"]["name"] else "assessment",
            model=MODEL, call_id=call_id, request_ref=reference(folder / "request.json"),
            response_ref=reference(folder / "response.json"), provider_receipt_ref=reference(folder / "provider.json"))


def independent(first, second):
    require(first["call_id"] != second["call_id"], "SEPARATE_SOURCE_REVIEW_CALL_REQUIRED")
    a, b = read_json(ROOT / first["provider_receipt_ref"]["path"]), read_json(ROOT / second["provider_receipt_ref"]["path"])
    require(a["provider_response_id"] != b["provider_response_id"], "SEPARATE_SOURCE_REVIEW_RESPONSE_REQUIRED")
