"""Owner API0 gate; receipts contain test names/counts and hashes, never secrets."""
import hashlib
import unittest
from unittest.mock import patch

from contract import HERE, ROOT, STATE, write_json
import test_auth
import test_engine_fixture


def main():
    old = ROOT / 'phase/interactive_release_20261122/live'
    protected = [old / name for name in ('auth.py', 'server.py', 'contract.py', 'worker.py') if (old / name).is_file()]
    protected += [STATE / 'paid-envelope.json', ROOT / 'experiments/narrative_demo/api/authorization.json']
    before = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
    suite = unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromModule(module)
                               for module in (test_auth, test_engine_fixture))
    with patch('matryoshka_narrative.api.Budget.reserve', side_effect=AssertionError('API0 verification forbids paid reservations')):
        result = unittest.TextTestRunner(verbosity=2).run(suite)
    after = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
    unchanged = before == after
    receipt = dict(version='motion-login-owner-api0/1', status='PASS' if result.wasSuccessful() and unchanged else 'FAIL',
                   tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
                   paid_calls=0, paid_reservations_forbidden=True, original_source_and_envelope_unchanged=unchanged,
                   protected_files=after, fixture_state_separate=not (HERE / 'state').exists(),
                   independent_clearance=False, freeze_requested=False)
    write_json(HERE / 'qa/auth-api0.json', receipt)
    if receipt['status'] != 'PASS': raise SystemExit(1)


if __name__ == '__main__':
    main()
