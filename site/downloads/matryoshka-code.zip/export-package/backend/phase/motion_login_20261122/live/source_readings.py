"""Current native reading contract, detached from historical V5 projection."""
from copy import deepcopy

from matryoshka_next import readings
from source_runtime import require

VERSION = "private-source-current-reading-registry/1"


def schema():
    value = deepcopy(readings.MODEL_VALIDATION_SCHEMA["$defs"]["reading"])
    value["$defs"] = deepcopy(readings.MODEL_VALIDATION_SCHEMA["$defs"])
    extra = dict(id=dict(type="string"), form=dict(type="string"),
        constructor_form=dict(type=["string", "null"]), constructor_status=dict(type="string"),
        constructor_routing=dict(type="object"), explanation=dict(type="string"))
    value["properties"].update(extra)
    value["required"] += list(extra)
    return value


def project(packet, case):
    checked = readings.validate_readings(packet, case)
    require(checked["status"] == "ready" and checked["readings"], "CURRENT_READINGS_NOT_READY")
    require(checked["query_only"] is True and checked["source_access"] is False
        and checked["answer_text_supplied"] is False, "CURRENT_READINGS_NOT_QUERY_ONLY")
    return deepcopy(checked["readings"])
