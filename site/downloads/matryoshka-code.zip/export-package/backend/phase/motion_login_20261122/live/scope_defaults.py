"""Small source-policy snapshot; no question text, answers or model decisions."""
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path

SNAPSHOT = Path(__file__).with_name('scope-defaults.json')
SNAPSHOT_SHA256 = '9fc1d47fb4d957f80298a81f09bb9495c2958a228568faebbf1ec0ccb008dbec'


def corpus_defaults():
    from contract import REFS
    raw = SNAPSHOT.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SNAPSHOT_SHA256:
        raise ValueError('Live corpus-date snapshot changed')
    value = json.loads(raw)
    refs_raw = REFS.read_bytes()
    refs = json.loads(refs_raw)
    if (value.get('version') != 'matryoshka-live-corpus-scopes/1'
            or value.get('execution_refs_sha256') != hashlib.sha256(refs_raw).hexdigest()
            or set(value.get('corpora', {})) != {'cib', 'iran', 'vietnam'}):
        raise ValueError('Live corpus-date snapshot has a different source binding')
    for corpus, bounds in value['corpora'].items():
        first, last = date.fromisoformat(bounds['first_date']), date.fromisoformat(bounds['last_date'])
        if (first > last or last > date.today()
                or bounds['default_before'] != (last + timedelta(days=1)).isoformat()
                or bounds['index_sha256'] != refs['index_refs'][corpus]['sha256']
                or bounds['source_binding_sha256'] != refs['index_refs'][corpus]['source_binding_sha256']):
            raise ValueError('Invalid Live corpus-date range')
    return value
