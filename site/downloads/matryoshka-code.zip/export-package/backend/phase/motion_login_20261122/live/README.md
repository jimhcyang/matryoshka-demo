# Private Password Access To Live

The initial password patch changed authentication and the Live login interface. It does
not distribute, split, encrypt for browser reconstruction, or otherwise publish
an OpenAI API key. A password authenticates to an already operated backend; it
does not turn GitHub Pages into a Python inference host. No hosting, Git action,
publication or paid model call is performed by this patch.

## Configure And Launch

The current local operator launcher serves the installed, latest interface:

```sh
.venv/bin/python -B src-demo-day/scripts/start_live_local.py --execute-paid --port 8977
```

It reuses a private salted password verifier at
`~/Library/Application Support/Matryoshka Live/credentials.json` (directory 0700,
file 0600). First-time initialization asks for a password through hidden terminal
input; the password is never stored. Legacy local configurations are migrated
atomically to verifier-only storage without changing the login password. The
model key is inherited from the server environment and is never written to that
file. No password or model key is put in command arguments, source files, logs,
the public site or GitHub. No model request is made at startup.

An explicit operator `--allocate-usd 1` can create a separate, immutable Live
allocation within the existing cumulative $50 authorization. This is not
automatic on restart: the original `paid-envelope.json`, authorization and
provider receipts remain unchanged. The private chained allocation records bind
the original envelope, cumulative authorization and current receipt total.
Restarting never rebases an allocation, and the $0.40 per-query limit remains.
The November 22 local setup has already allocated $1; do not repeat this flag
merely to restart. Local setup verification is in
`phase/live_setup_20261122/verification.json`.

Open `http://127.0.0.1:8977/matryoshka-demo/live.html`. This is local access,
not a hosted HTTPS backend for GitHub Pages. A computer restart stops the local
process; run the command above again with the private model-key environment.

For an analyst-written question, no document ID is needed. The date defaults to
the last eligible day in the chosen corpus, inclusive; clearing it uses the same
full-corpus default. For Iran/Vietnam, a supplied document ID excludes that
entire document. For CIB it identifies the source document; its earlier/both
release remains eligible through the chosen day, never its later release.
The API normalizes these optional inputs into an explicit canonical scope
before planning or execution. Historical saved cases keep their original
policy; new saved experiments carry a separate native-bound source policy.
Final evidence/fit scores and a separate post-run digest follow local execution.
See `CONTRACT.md` for wire semantics.

For manual private credential provisioning instead of the launcher:

Use a strong private password of at least 16 UTF-8 bytes. There is no default.
The public word `matryoshka` is not a password option. Provider-key-shaped text
and credential assignments are rejected, including within whitespace/backticks.
Legitimate password whitespace is significant and is never silently trimmed.
Blank, control/format-character, low-variety and exactly repeating passwords
are rejected at provisioning and cannot authenticate. Serialized verifiers
reject the same finite known-default blacklist. An external hash cannot prove
arbitrary password strength; provision through the reviewed generator or private
password environment rather than importing a weak external hash.

Prefer a private server-environment `LIVE_PASSWORD_VERIFIER`. Generate it in an
interactive terminal; the helper reads the password without echo and outputs
only a salted verifier, which can be captured directly into the environment:

```sh
export LIVE_PASSWORD_VERIFIER="$(.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/auth.py --make-verifier)"
```

Alternatively configure `LIVE_LOGIN_PASSWORD` privately in the server environment,
not both. Do not put either value in tracked files, command arguments, URLs or
logs. The verifier is scrypt with a random 32-byte salt, N=131072/r=8/p=1 and a
32-byte output; comparison uses `hmac.compare_digest`. Parameter parsing is
closed and bounded. The API key remains exclusively in server environment
`OPENAI_API_KEY`; neither login secret is forwarded to the inference worker.

```sh
.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/server.py --port 8977
```

Open `http://127.0.0.1:8977/matryoshka-demo/live.html`. A successful login does
NOT enable inference. Paid execution still requires the existing explicit
`--execute-paid` flag, configured model environment, resource checks and budgets.
This patch's tests do not use that flag to run a provider request.

API0 synthetic transport fixture (temporary state automatically removed):

```sh
.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/server.py --fixture --port 8977 --allow-origin http://127.0.0.1:8978
```

For main's staging preview on 8978, open Connection settings and use
`http://127.0.0.1:8977/live-api/`. A frontend on an unrelated public origin cannot
send a password to the plain-HTTP loopback service; open the local companion
instead. This avoids pretending public-to-local browser transport is dependable.

## HTTPS Backend Boundary

For a separately operated remote backend, terminate TLS in a trusted reverse
proxy on the same host, keep the Python server bound to loopback, preserve the
configured public Host, and set exactly one `X-Forwarded-Proto: https` header.
Remove client-supplied forwarding headers at the proxy. Explicit configuration:

```sh
.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/server.py --public-origin https://backend.example.org --trusted-proxy 127.0.0.1 --allow-origin https://frontend.example.org
```

Those are illustrative origins, not provisioned services. The server does not
trust `X-Forwarded-For` as client identity: rate limiting conservatively applies
to the TCP peer, including a shared proxy peer. Remote access without the exact
Host/Origin/TLS-proxy boundary fails closed. Password login on direct HTTP is
restricted to local loopback frontends. Arbitrary forwarded headers are rejected
outside the explicit proxy mode. No wildcard CORS or credentialed cookies exist.

On public Pages, the operator must set the nonsecret `meta[name=live-backend]`
URL and add its exact HTTPS origin to the Live page's CSP `connect-src`. The
backend must allow that frontend's exact origin. With no configuration, the
page stays unavailable and never sends a password to GitHub Pages. A 4+ GiB
Python engine needs an appropriate server; a 128 MiB frontend worker is not an
engine-hosting solution. No remote server or paid hosting is provisioned here.

## Existing State And Spending

Production state remains EXACTLY:
`src-demo-day/phase/interactive_release_20261122/live/state/`.
There is no new production `motion_login_20261122/live/state/`. Startup requires
the existing directory and paid envelope; a missing envelope fails closed and
is NEVER recreated. The exact existing stored baseline and retained Live $1
envelope are read in place, not reset to today's balance. The shared cumulative
`src-demo-day/experiments/narrative_demo/api` $50 ledger and exact request cache
remain authoritative. Per-job $0.40 limits and any tighter inherited envelope
remain in force. Fixture tests always use separate temporary state and cannot
write to production state. No raw historical jobs, state or QA were copied.

One worker, four queued jobs, 32 retained jobs/process, resource/deadline limits,
fixed source refs, query-only planning and Redaction-only model readings remain
unchanged. Job lookup/status/result/cancel/retry additionally require the owning
session. Another session receives 404 even if it knows a job ID. Logout and
absolute expiry revoke access and cancel unfinished work; incurred/uncertain
provider billing is retained. A shared password is not a multi-user account
system; this patch does not provide cross-session account recovery of jobs.

## Session And Login Limits

Bearer sessions use 256-bit random values, expire absolutely after 15 minutes,
are bound to the exact frontend Origin, and are stored server-side only by hash.
At most eight sessions exist. There is no refresh endpoint or persistent login.
The page holds its bearer only in JavaScript memory and clears login fields
immediately. It does not use cookies, URLs, local/session storage or IndexedDB
for secrets. Explicit logout revokes server access. Closing/reloading the page
clears browser memory; server sessions expire, rather than being silently renewed.

Before scrypt: JSON <=1024 bytes, password <=256 UTF-8 bytes, strict field set,
Origin/Host/custom-header checks, five attempts per TCP peer/minute, 12 global
attempts/minute, bounded peer table and a one-check semaphore. Failures apply
exponential 1-60 second backoff; 429 includes bounded `Retry-After`. No sleeping
request threads or password echo, provider error text or request-body logging.

Legacy `LIVE_SESSION_TOKEN` is optional, advanced-only, 32+ URL-safe characters,
origin-bound on first use, limited to the same short lifetime and revocable by
logout. It is neither a browser API key nor a way to bypass job ownership.

## API And Frontend Handoff

- `POST /live-api/session/login`: exact JSON `{password: string}` and
  `X-Live-Request: 1`, no bearer/cookie. Returns `matryoshka-live-session/1`,
  `access_token`, `token_type: Bearer`, and bounded `expires_in_seconds`.
- `GET /live-api/session`: bearer-authenticated session state, no secret echo.
- `POST /live-api/session/logout`: bearer plus JSON `{}`; revokes and cancels
  that session's unfinished jobs. Other sessions are unaffected.
- All existing `/live-api/health` and job APIs still require the bearer and
  exact source/request contracts. Login is the ONLY unauthenticated POST and
  cannot run inference. OPTIONS permits only the exact required headers/methods.

Primary frontend hooks: `#login-form`, `#login-password`, `#login-submit`,
`#logout`, `#session-status`, `#availability`. Closed `#connection` contains
`#backend`; nested closed `#legacy-connection` contains `#capability`/`#connect`.
`#question-fields`/`#run` remain disabled until authenticated AND execution-ready.
Public unconfigured startup sends no backend request. Both primary and advanced
forms reject obvious credential forms BEFORE transport and clear the input.
Password POST uses native fetch with `redirect: error`, no cookies and no
referrer; it cannot forward a password through a redirect. Other Live API calls
retain the scoped XHR adapter to bypass saved replay, with no global override.

All code from `async function textDigest` onward in `live-result-adapter.js`
remains byte-identical to the reviewed R7 baseline. Native evidence, direction,
candidate/unit, rank, source, provenance, graph, handoff and workbench packet
guards are preserved. The detached analyst digest remains explicitly unavailable.

## API0 Verification

```sh
.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/test_auth.py
.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/test_engine_fixture.py
.venv/bin/python -B src-demo-day/phase/motion_login_20261122/live/test_browser_login.py
```

Managed Playwright Chromium headless shell only. Browser QA verifies real scrypt
login, password/key-form rejection without requests, synthetic API0 job flow,
mobile/desktop, logout/expiry, redirects, public-unconfigured behavior, and the
existing actual smoke envelope as a DISPLAY/VERIFIER fixture. That envelope is
read in place; it is never copied into this phase, fed to inference, or presented
as a fresh execution. R7 mutation probes stay rejected. Old source files and the
real paid envelope are hash-checked unchanged. No provider requests are made.
