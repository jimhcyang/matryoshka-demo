"""API0 password/session/transport attacks. Never uses the shared paid state."""
import base64
import hashlib
import http.client
import json
import os
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

from auth import Auth, PasswordVerifier, Throttled, derive, password_shape, KNOWN_WEAK
from contract import HERE, ROOT, STATE, Reject, encoded
from server import Config, Jobs, create_server

PASSWORD = 'fixture-only-private-access-938475'
WRONG_PASSWORD = 'wrong-fixture-private-password'
LEGACY = 'fixture-legacy-' + 'x' * 48
REQUEST = dict(task='hypothesis', corpus='cib', query='The council discussed trade.',
               as_of='1965-07-02', excluded_origin='fixture-analyst-origin', focal_marker='')


class CountingVerifier:
    def __init__(self):
        self.calls = 0

    def verify(self, password):
        self.calls += 1
        return password == PASSWORD


class VerifierTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.verifier = PasswordVerifier.make(PASSWORD)

    def test_real_scrypt_round_trip(self):
        parsed = PasswordVerifier.parse(self.verifier.export())
        self.assertTrue(parsed.verify(PASSWORD))
        self.assertFalse(parsed.verify('not-the-private-password'))

    def test_no_demo_default_or_provider_key(self):
        for value in ('matryoshka', '', 'passwordpassword', 'sk-' + 'x' * 48,
                      ' \tsk-fixture-not-real\n', '`sk-fixture-not-real`', 'OPENAI_API_KEY=sk-fixture-not-real',
                      'prefix OPENAI_API_KEY="sk-fixture-not-real" suffix'):
            with self.assertRaises(ValueError):
                PasswordVerifier.make(value)
        salt = b'x' * 32
        weak = PasswordVerifier(salt, derive('matryoshka', salt)).export()
        with self.assertRaises(ValueError):
            PasswordVerifier.parse(weak)

    def test_verifier_cost_parameters_are_closed(self):
        for value in ('scrypt$v1$999999999$8$1$x$x', 'plaintext$password', self.verifier.export() + '$extra'):
            with self.assertRaises(ValueError):
                PasswordVerifier.parse(value)

    def test_no_environment_default_and_exclusive_configuration(self):
        with patch.dict(os.environ, {'LIVE_PASSWORD_VERIFIER': '', 'LIVE_LOGIN_PASSWORD': ''}):
            self.assertIsNone(PasswordVerifier.environment())
        with patch.dict(os.environ, {'LIVE_PASSWORD_VERIFIER': 'x', 'LIVE_LOGIN_PASSWORD': PASSWORD}):
            with self.assertRaises(ValueError):
                PasswordVerifier.environment()

    def test_password_whitespace_is_not_trimmed(self):
        padded = ' ' + PASSWORD + ' '
        verifier = PasswordVerifier.make(padded)
        self.assertTrue(verifier.verify(padded))
        self.assertFalse(verifier.verify(PASSWORD))

    def test_review_AUTH_01_trivial_and_control_provisioning(self):
        values = [' ' * 16, 'a' * 16, '\t' * 16, 'review-fixture\x00password-long',
                  'passwordpassword', 'matryoshka', 'abcd' * 4, 'privateword' * 2,
                  ' privatewordprivateword ', 'fixture-password\ncontrol', 'fixture\u200bpassword-long']
        for value in values:
            with self.subTest(kind='weak/control/repetition'):
                self.assertFalse(password_shape(value))
                with self.assertRaises(ValueError): PasswordVerifier.make(value)
        self.assertTrue(password_shape(' ' + PASSWORD + ' '))

    def test_review_AUTH_02_serialized_known_weak_verifier(self):
        salt = b'x' * 32
        value = PasswordVerifier(salt, derive('passwordpassword', salt)).export()
        with self.assertRaises(ValueError): PasswordVerifier.parse(value)


class SessionTests(unittest.TestCase):
    def setUp(self):
        self.now = [100.0]
        self.verifier = CountingVerifier()
        self.auth = Auth(self.verifier, seconds=10, clock=lambda: self.now[0])

    def login(self, peer='one'):
        return self.auth.login(PASSWORD, 'https://frontend.example', peer)

    def test_random_origin_bound_short_session_and_revoke(self):
        one, two = self.login(), self.login()
        self.assertTrue(one['access_token'] != two['access_token'], 'Independent sessions need independent tokens')
        self.assertEqual(one['expires_in_seconds'], 10)
        session = self.auth.authenticate('Bearer ' + one['access_token'], 'https://frontend.example')
        with self.assertRaises(Reject):
            self.auth.authenticate('Bearer ' + one['access_token'], 'https://other.example')
        self.auth.revoke(session)
        with self.assertRaises(Reject):
            self.auth.authenticate('Bearer ' + one['access_token'], session.origin)

    def test_absolute_expiry_does_not_slide(self):
        response = self.login()
        self.now[0] += 9
        self.auth.authenticate('Bearer ' + response['access_token'], 'https://frontend.example')
        self.now[0] += 1
        with self.assertRaises(Reject):
            self.auth.authenticate('Bearer ' + response['access_token'], 'https://frontend.example')

    def test_backoff_precedes_expensive_verification(self):
        with self.assertRaises(Reject):
            self.auth.login(WRONG_PASSWORD, 'https://frontend.example', 'one')
        calls = self.verifier.calls
        with self.assertRaises(Throttled):
            self.login()
        self.assertEqual(self.verifier.calls, calls)
        self.now[0] += 2
        self.login()

    def test_capacity_precedes_password_work(self):
        for i in range(8):
            self.login(str(i))
        calls = self.verifier.calls
        with self.assertRaises(Throttled):
            self.login('ninth')
        self.assertEqual(len(self.auth.sessions), 8)
        self.assertEqual(self.verifier.calls, calls)

    def test_global_attempt_limit_precedes_password_work(self):
        for i in range(12):
            with self.assertRaises(Reject):
                self.auth.login(WRONG_PASSWORD, 'https://frontend.example', str(i))
        with self.assertRaises(Throttled):
            self.login('thirteenth')
        self.assertEqual(self.verifier.calls, 12)

    def test_password_check_concurrency_is_bounded(self):
        self.auth.check_slot.acquire()
        try:
            with self.assertRaises(Throttled):
                self.login()
            self.assertEqual(self.verifier.calls, 0)
        finally:
            self.auth.check_slot.release()

    def test_no_plain_bearer_or_password_in_session_registry(self):
        result = self.login()
        raw = repr(self.auth.sessions)
        self.assertNotIn(PASSWORD, raw)
        self.assertNotIn(result['access_token'], raw)

    def test_legacy_capability_logout_cannot_reauthenticate(self):
        auth = Auth(None, LEGACY, clock=lambda: self.now[0])
        session = auth.authenticate('Bearer ' + LEGACY, 'https://frontend.example')
        with self.assertRaises(Reject):
            auth.authenticate('Bearer ' + LEGACY, 'https://other.example')
        auth.revoke(session)
        with self.assertRaises(Reject):
            auth.authenticate('Bearer ' + LEGACY, session.origin)


class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='auth-http-', dir=HERE)
        self.verifier = CountingVerifier()
        self.http = create_server(Config(state=Path(self.temp.name), fixture=True,
                                  allowed_origins=('https://frontend.example', 'http://127.0.0.1:8978')),
                                  LEGACY, verifier=self.verifier, port=0)
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        self.origin = 'http://127.0.0.1:' + str(self.http.server_port)

    def tearDown(self):
        self.http.jobs.close()
        self.http.shutdown()
        self.http.server_close()
        self.thread.join(timeout=5)
        self.temp.cleanup()

    def request(self, path, method='GET', body=None, token=None, headers=None, raw=None):
        connection = http.client.HTTPConnection('127.0.0.1', self.http.server_port, timeout=10)
        supplied = {'Origin': self.origin, 'X-Live-Request': '1'}
        if token: supplied['Authorization'] = 'Bearer ' + token
        if body is not None: supplied['Content-Type'] = 'application/json'
        supplied.update(headers or {})
        supplied = {k: v for k, v in supplied.items() if v is not None}
        connection.request(method, '/live-api/' + path, body=raw if raw is not None else encoded(body) if body is not None else None, headers=supplied)
        response = connection.getresponse()
        data = response.read()
        result = response.status, dict(response.getheaders()), json.loads(data) if data else {}
        connection.close()
        return result

    def login(self):
        status, headers, value = self.request('session/login', 'POST', {'password': PASSWORD})
        self.assertEqual(status, 200)
        self.assertEqual(headers['Cache-Control'], 'no-store')
        self.assertNotIn('Set-Cookie', headers)
        return value['access_token']

    def test_login_logout_and_expiry(self):
        token = self.login()
        self.assertEqual(self.request('health', token=token)[0], 200)
        self.assertEqual(self.request('session/logout', 'POST', {}, token=token)[0], 200)
        self.assertEqual(self.request('health', token=token)[0], 401)

    def test_unauthenticated_paid_routes_are_closed(self):
        self.assertEqual(self.request('health')[0], 401)
        self.assertEqual(self.request('jobs', 'POST', REQUEST)[0], 401)
        self.assertEqual(len(self.http.jobs.jobs), 0)

    def test_login_origin_host_cookie_query_and_forwarding(self):
        for headers in ({'Origin': 'https://evil.example'}, {'Origin': 'null'}, {'Origin': None},
                        {'Host': 'evil.example'}, {'Cookie': 'session=ambient'}, {'X-Live-Request': None},
                        {'X-Forwarded-Proto': 'https'}, {'X-Forwarded-For': '192.0.2.1'}):
            self.assertEqual(self.request('session/login', 'POST', {'password': PASSWORD}, headers=headers)[0], 403)
        self.assertEqual(self.request('session/login?password=bad', 'POST', {'password': PASSWORD})[0], 400)
        self.assertEqual(self.verifier.calls, 0)

    def test_body_bounds_before_hashing(self):
        for body, status in (({'password': 'x' * 257}, 400), ({'password': 'x' * 1200}, 413),
                             ({'password': 123}, 400), ({'password': '\ud800'}, 400), ({'api_key': 'not-accepted'}, 400)):
            self.assertEqual(self.request('session/login', 'POST', body)[0], status)
        self.assertEqual(self.request('session/login', 'POST', {}, raw=b'{"password":"one","password":"two"}')[0], 400)
        self.assertEqual(self.request('session/login', 'POST', {}, headers={'Content-Type': 'text/plain'})[0], 415)
        self.assertEqual(self.verifier.calls, 0)

    def test_provider_forms_are_rejected_before_password_work(self):
        for value in (' sk-fixture-not-real ', '`sk-fixture-not-real`', 'OPENAI_API_KEY=sk-fixture-not-real',
                      'export OPENAI_API_KEY="sk-fixture-not-real"', 'prefix `sk-fixture-not-real` suffix',
                      'Authorization: Bearer fixture-not-a-token'):
            self.assertEqual(self.request('session/login', 'POST', {'password': value})[0], 400)
        self.assertEqual(self.verifier.calls, 0)

    def test_failed_login_backoff_has_retry_after(self):
        self.assertEqual(self.request('session/login', 'POST', {'password': WRONG_PASSWORD})[0], 401)
        status, headers, _ = self.request('session/login', 'POST', {'password': PASSWORD})
        self.assertEqual(status, 429)
        self.assertIn('Retry-After', headers)
        self.assertEqual(self.verifier.calls, 1)

    def test_login_preflight_does_not_require_bearer(self):
        status, headers, _ = self.request('session/login', 'OPTIONS', headers={
            'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'content-type, x-live-request'})
        self.assertEqual(status, 204)
        self.assertEqual(headers['Access-Control-Allow-Origin'], self.origin)
        self.assertNotIn('Access-Control-Allow-Credentials', headers)
        self.assertEqual(self.verifier.calls, 0)

    def test_public_password_does_not_use_plain_http_loopback(self):
        status, _, _ = self.request('session/login', 'POST', {'password': PASSWORD}, headers={'Origin': 'https://frontend.example'})
        self.assertEqual(status, 403)
        self.assertEqual(self.verifier.calls, 0)

    def test_job_ids_are_not_cross_session_authorization(self):
        first, second = self.login(), self.login()
        status, _, job = self.request('jobs', 'POST', REQUEST, token=first)
        self.assertEqual(status, 202)
        path = 'jobs/' + job['job_id']
        for suffix, method, body in (('', 'GET', None), ('/result', 'GET', None), ('/cancel', 'POST', {}), ('/retry', 'POST', {})):
            self.assertEqual(self.request(path + suffix, method, body, token=second)[0], 404)
        self.assertEqual(self.request(path, token=first)[0], 200)
        self.assertEqual(self.request(path, token=first, headers={'Origin': 'http://127.0.0.1:8978'})[0], 401)

    def test_logout_cancels_unfinished_own_jobs(self):
        token = self.login()
        # Hold the job lock so the worker cannot take this queued fixture yet.
        session = self.http.auth.authenticate('Bearer ' + token, self.origin)
        with self.http.jobs.lock:
            job = self.http.jobs.submit(REQUEST, session)
            self.http.jobs.logout(session)
            self.assertEqual(self.http.jobs.jobs[job['job_id']]['status'], 'cancelled')
        self.assertEqual(self.request('health', token=token)[0], 401)


class UpgradeAndTransportTests(unittest.TestCase):
    def test_real_default_state_is_original_not_new_phase(self):
        self.assertEqual(STATE, ROOT / 'phase/interactive_release_20261122/live/state')
        self.assertEqual(Config().state, STATE)
        self.assertFalse((HERE / 'state').exists())

    def test_fixture_cannot_write_production_state(self):
        with self.assertRaises(ValueError):
            Jobs(Config(fixture=True), Auth())

    def test_upgrade_never_initializes_missing_envelope(self):
        with tempfile.TemporaryDirectory(prefix='missing-envelope-', dir=HERE) as folder:
            state = Path(folder)
            with patch('server.STATE', state), patch('server.ledger_total', return_value=13.7):
                with self.assertRaises(ValueError):
                    Jobs(Config(state=state, execute_paid=True), Auth())
            self.assertFalse((state / 'paid-envelope.json').exists())

    def test_retained_envelope_is_not_reset(self):
        with tempfile.TemporaryDirectory(prefix='retained-envelope-', dir=HERE) as folder:
            state = Path(folder)
            original = encoded(dict(version='matryoshka-live-paid-envelope/1', baseline_usd=12.8310141, max_spend_usd=1))
            (state / 'paid-envelope.json').write_bytes(original)
            with patch('server.STATE', state), patch('server.ledger_total', return_value=13.7):
                jobs = Jobs(Config(state=state, execute_paid=True), Auth())
                try: self.assertAlmostEqual(jobs.absolute_cap, 13.8310141)
                finally: jobs.close()
            self.assertEqual((state / 'paid-envelope.json').read_bytes(), original)

    def test_remote_transport_requires_explicit_tls_proxy(self):
        with self.assertRaises(ValueError):
            create_server(Config(public_origin='https://backend.example'), verifier=CountingVerifier(), port=0)
        with tempfile.TemporaryDirectory(prefix='proxy-tests-', dir=HERE) as folder:
            verifier = CountingVerifier()
            service = create_server(Config(fixture=True, state=Path(folder), public_origin='https://backend.example',
                trusted_proxy='127.0.0.1', allowed_origins=('https://frontend.example',)), verifier=verifier, port=0)
            thread = threading.Thread(target=service.serve_forever, daemon=True); thread.start()
            try:
                def send(proto):
                    connection = http.client.HTTPConnection('127.0.0.1', service.server_port)
                    headers = {'Host': 'backend.example', 'Origin': 'https://frontend.example', 'X-Live-Request': '1', 'Content-Type': 'application/json'}
                    if proto: headers['X-Forwarded-Proto'] = proto
                    connection.request('POST', '/live-api/session/login', encoded({'password': PASSWORD}), headers)
                    response = connection.getresponse(); response.read(); status = response.status; connection.close(); return status
                self.assertEqual(send(None), 403)
                self.assertEqual(send('http'), 403)
                self.assertEqual(send('https'), 200)
                self.assertEqual(verifier.calls, 1)

                connection = http.client.HTTPConnection('127.0.0.1', service.server_port)
                remote = {'Host': 'backend.example', 'Origin': 'https://backend.example', 'X-Forwarded-Proto': 'https',
                          'X-Live-Request': '1', 'Content-Type': 'application/json'}
                connection.request('POST', '/live-api/session/login', encoded({'password': PASSWORD}), remote)
                response = connection.getresponse(); token = json.loads(response.read())['access_token']; connection.close()
                # Exact AUTH-03 probe: browsers omit Origin on same-origin GET.
                def get_health(site='same-origin', proto='https', mode='cors', bearer=token, custom=True, cookie=False):
                    connection = http.client.HTTPConnection('127.0.0.1', service.server_port)
                    headers = {'Host': 'backend.example', 'X-Forwarded-Proto': proto,
                               'Sec-Fetch-Site': site, 'Sec-Fetch-Mode': mode}
                    if custom: headers['X-Live-Request'] = '1'
                    if bearer: headers['Authorization'] = 'Bearer ' + bearer
                    if cookie: headers['Cookie'] = 'ambient=1'
                    connection.request('GET', '/live-api/health', headers=headers)
                    response = connection.getresponse(); response.read(); status = response.status; connection.close(); return status
                self.assertEqual(get_health(), 200)
                self.assertEqual(get_health(site='cross-site'), 403)
                self.assertEqual(get_health(proto='http'), 403)
                self.assertEqual(get_health(mode='no-cors'), 403)
                self.assertEqual(get_health(bearer=None), 401)
                self.assertEqual(get_health(custom=False), 403)
                self.assertEqual(get_health(cookie=True), 403)
            finally:
                service.jobs.close(); service.shutdown(); service.server_close(); thread.join(timeout=5)


if __name__ == '__main__':
    unittest.main(verbosity=2)
