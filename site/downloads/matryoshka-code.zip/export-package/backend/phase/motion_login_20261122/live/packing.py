"""Lossless bounded transport. Logical seals never stand in for stored-byte seals."""
import base64
import gzip
import hashlib
import json
from pathlib import Path
import re
import zlib

from contract import Reject, encoded, sha, write_json

VERSION = "matryoshka-live-packed/1"
ENCODING = "gzip+base64"
WIRE_LIMIT = 24 * 1024**2
DECODED_LIMIT = 64 * 1024**2
MAX_SAFE_INTEGER = 2**53 - 1
FIELDS = {"version", "encoding", "decoded_bytes", "decoded_sha256", "components", "payload", "payload_sha256"}
HASH = re.compile(r"[a-f0-9]{64}\Z")
ARTIFACTS = {"native.json": "native", "condition.json": "condition", "trace.json": "trace",
    "sources.json": "sources", "document-pages.json": "document_pages",
    "selected-evidence.json": "selected_evidence", "receipt.json": "receipt",
    "analyst-digest.json": "analyst_digest"}


def reject():
    raise Reject("RESULT_INTEGRITY_FAILED", 409)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def components(value):
    return {key: sha(child) for key, child in value.items()} if isinstance(value, dict) else {"$": sha(value)}


def safe_integers(value):
    if type(value) is int:
        if not -MAX_SAFE_INTEGER <= value <= MAX_SAFE_INTEGER:
            reject()
    elif isinstance(value, dict):
        for item in value.values():
            safe_integers(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            safe_integers(item)


def pack(value):
    safe_integers(value)
    raw = encoded(value)
    if len(raw) > DECODED_LIMIT:
        raise Reject("ARTIFACT_DECODED_SIZE_LIMIT", 507)
    compressed = gzip.compress(raw, mtime=0)
    result = dict(version=VERSION, encoding=ENCODING, decoded_bytes=len(raw),
        decoded_sha256=digest(raw), components=components(value),
        payload=base64.b64encode(compressed).decode("ascii"), payload_sha256=digest(compressed))
    if len(encoded(result)) > WIRE_LIMIT:
        raise Reject("ARTIFACT_SIZE_LIMIT", 507)
    return result


def unpack(value):
    if not isinstance(value, dict) or value.get("version") != VERSION:
        # Legacy artifacts remain readable, never silently accept future codecs.
        if (isinstance(value, dict) and (str(value.get("version", "")).startswith("matryoshka-live-packed/")
                or "payload_sha256" in value or "decoded_sha256" in value)):
            reject()
        if len(encoded(value)) > WIRE_LIMIT:
            reject()
        return value
    length, payload = value.get("decoded_bytes"), value.get("payload")
    manifest = value.get("components")
    if (set(value) != FIELDS or value.get("encoding") != ENCODING
            or type(length) is not int or not 0 < length <= DECODED_LIMIT
            or not isinstance(payload, str) or len(payload) > WIRE_LIMIT
            or not isinstance(manifest, dict) or len(manifest) > 4096
            or any(not isinstance(v, str) or not HASH.fullmatch(v) for v in manifest.values())
            or any(not isinstance(value.get(k), str) or not HASH.fullmatch(value[k])
                   for k in ("decoded_sha256", "payload_sha256"))):
        reject()
    if len(encoded(value)) > WIRE_LIMIT:
        reject()
    try:
        compressed = base64.b64decode(payload, validate=True)
        if base64.b64encode(compressed).decode("ascii") != payload or digest(compressed) != value["payload_sha256"]:
            reject()
        decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
        raw = decoder.decompress(compressed, length + 1)
        if (len(raw) != length or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail
                or digest(raw) != value["decoded_sha256"]):
            reject()
        decoded = json.loads(raw)
        safe_integers(decoded)
        if encoded(decoded) != raw or components(decoded) != manifest:
            reject()
        return decoded
    except (ValueError, TypeError, UnicodeError, zlib.error, RecursionError):
        reject()


def read_transport(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file() or path.stat().st_size > WIRE_LIMIT:
        reject()
    with path.open("rb") as stream:
        raw = stream.read(WIRE_LIMIT + 1)
    if len(raw) > WIRE_LIMIT:
        reject()
    try:
        wire = json.loads(raw)
        return wire, unpack(wire), digest(raw)
    except (ValueError, TypeError, UnicodeError, RecursionError):
        reject()


def write_transport(path, value):
    wire = pack(value)
    write_json(path, wire)
    return transport_ref(wire)


def transport_ref(wire):
    return dict(sha256=sha(wire), decoded_sha256=wire["decoded_sha256"], encoding=ENCODING,
        wire_bytes=len(encoded(wire)), decoded_bytes=wire["decoded_bytes"])


def validate_result(value, request, run_id):
    if (not isinstance(value, dict) or value.get("version") != "matryoshka-live-result/1"
            or value.get("run_id") != run_id or value.get("request") != request):
        reject()
    native, condition, receipt = (value.get(k) for k in ("native", "condition", "receipt"))
    if not all(isinstance(v, dict) for v in (native, condition, receipt)):
        reject()
    fields = {"task": "task", "corpus": "corpus", "query": "query", "as_of": "date",
        "excluded_origin": "document_id", "focal_marker": "focal_marker"}
    case = native.get("public_case", {})
    if (any(case.get(field) != request.get(key) for key, field in fields.items())
            or condition.get("case") != case or type(receipt.get("execution_cache_hit")) is not bool):
        reject()
    if value.get("execution_kind") == "live":
        checksum = native.get("native_checksum")
        if (checksum != sha(native.get("result")) or checksum != condition.get("native_checksum")
                or native.get("binding") != condition.get("index_ref")
                or receipt.get("no_answer_or_grade_inputs") is not True
                or receipt.get("no_chain_of_thought") is not True
                or value.get("source_scope", {}).get("source_view_policy") != native.get("configuration", {}).get("source_view_policy")
                or native.get("result", {}).get("source_view_policy") != native.get("configuration", {}).get("source_view_policy")
                or receipt.get("configuration") != native.get("configuration")):
            reject()
    elif value.get("execution_kind") != "fixture":
        reject()
    refs = value.get("artifacts")
    expected = {name for name, key in ARTIFACTS.items() if key in value}
    if not isinstance(refs, dict) or set(refs) != expected:
        reject()
    for name in expected:
        ref = refs[name]
        if not isinstance(ref, dict) or not isinstance(ref.get("sha256"), str) or not HASH.fullmatch(ref["sha256"]):
            reject()
        logical = sha(value[ARTIFACTS[name]])
        if "encoding" in ref:
            if (ref["encoding"] != ENCODING or ref.get("decoded_sha256") != logical
                    or type(ref.get("wire_bytes")) is not int or not 0 < ref["wire_bytes"] <= WIRE_LIMIT
                    or ref.get("decoded_bytes") != len(encoded(value[ARTIFACTS[name]]))):
                reject()
        elif ref["sha256"] != logical:
            reject()
    return value


def validate_artifact_files(directory, value):
    for name, ref in value["artifacts"].items():
        path = Path(directory) / name
        if ref.get("path") != "jobs/" + Path(directory).name + "/" + name:
            reject()
        wire, decoded, wire_sha = read_transport(path)
        if (wire_sha != ref["sha256"] or sha(decoded) != sha(value[ARTIFACTS[name]])
                or "encoding" in ref and (wire.get("version") != VERSION
                    or wire.get("decoded_sha256") != ref["decoded_sha256"]
                    or path.stat().st_size != ref["wire_bytes"])):
            reject()
