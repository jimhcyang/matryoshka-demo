"""Authenticated loopback companion. Static replay and real Live never alias."""
import argparse
from collections import deque
from dataclasses import dataclass
import hashlib
import hmac
import fcntl
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import time
import tempfile
from urllib.parse import urlsplit

from contract import (API_ROOT, HERE, MAX_BODY, MODEL, PHASE, REFS, ROOT, STATE, STAGES,
                      TERMINAL, WORKSPACE, Reject, encoded, headroom, ledger_total,
                      read_json, scope_for, sha, validate, write_json)
from auth import Auth, PasswordVerifier, SESSION_SECONDS
from allocations import inspect_allocations
from packing import (read_transport, validate_result, validate_artifact_files,
                     WIRE_LIMIT)

PREFIX = "/matryoshka-demo/"
MAX_PATH_LENGTH = 512
MAX_NAVIGATION_TARGET_LENGTH = 8192
PINNED_NAVIGATION_PAGES = frozenset({PREFIX + "graph-full-v6.html", PREFIX + "workbench-v6.html", PREFIX + "runtime/replay.html"})


def validate_request_target(target, method):
    if (not isinstance(target, str) or not target.startswith("/") or target.startswith("//")
            or any(ord(c) < 32 or ord(c) == 127 for c in target)):
        raise Reject("PATH_NOT_ALLOWED", 400)
    path = target.partition("?")[0]
    # Saved KG guides carry source spans, return state and three resource pins.
    # This permits longer GET query strings, never longer file/API paths.
    limit = MAX_NAVIGATION_TARGET_LENGTH if method == "GET" and path in PINNED_NAVIGATION_PAGES else MAX_PATH_LENGTH
    if len(path) > MAX_PATH_LENGTH or len(target) > limit:
        raise Reject("PATH_NOT_ALLOWED", 400)


def origin(value):
    parsed = urlsplit(value)
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username
            or parsed.password or parsed.path or parsed.query or parsed.fragment
            or (parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1"})):
        raise ValueError("An exact HTTPS or loopback origin is required")
    _ = parsed.port
    return value


@dataclass
class Config:
    site: Path = WORKSPACE / "matryoshka_demo_site/site"
    state: Path = STATE
    fixture: bool = False
    execute_paid: bool = False
    max_seconds: float = 360
    max_rss_mib: int = 8192
    max_spend_usd: float = 1.0
    job_spend_usd: float = 0.40
    session_seconds: float = SESSION_SECONDS
    allowed_origins: tuple = ()
    public_origin: str | None = None
    trusted_proxy: str | None = None


class Jobs:
    def __init__(self, config, authentication):
        self.config = config
        if (not 1 <= config.max_seconds <= 600 or not 128 <= config.max_rss_mib <= 8192
                or not 0 < config.max_spend_usd <= 1 or not 0 < config.job_spend_usd <= config.max_spend_usd
                or not 1 <= config.session_seconds <= SESSION_SECONDS):
            raise ValueError("Invalid session capability or fixed server limits")
        if not config.fixture and config.state.resolve() != STATE.resolve():
            raise ValueError("Upgrades must reuse the existing Live state and paid envelope")
        if config.fixture and config.state.resolve() == STATE.resolve():
            raise ValueError('Fixture execution must use a separate temporary state')
        if not config.fixture and (not config.state.is_dir() or not (config.state / 'paid-envelope.json').is_file()):
            raise ValueError('Existing Live state/envelope required; never initialize a fresh authorization')
        self.auth = authentication
        self.lock = threading.RLock()
        self.jobs, self.cache = {}, {}
        self.submissions = deque()
        self.stop = threading.Event()
        self.active = None
        self.start_total = 0 if config.fixture else ledger_total()
        self.absolute_cap = min(50.0, self.start_total + config.max_spend_usd)
        self.ready = config.fixture or (config.execute_paid and bool(os.environ.get("OPENAI_API_KEY")))
        headroom()
        config.state.mkdir(parents=True, exist_ok=True, mode=0o700)
        config.state.chmod(0o700)
        self.process_lock = (config.state / "server.lock").open("a+")
        try:
            fcntl.flock(self.process_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.process_lock.close()
            raise ValueError("One companion process per state directory is allowed") from None
        if not config.fixture and config.execute_paid:
            authorization = config.state / "paid-envelope.json"
            if authorization.exists():
                saved = read_json(authorization)
                if (saved.get("version") != "matryoshka-live-paid-envelope/1"
                        or not math.isfinite(saved.get("baseline_usd", float("nan")))
                        or not 0 <= saved["baseline_usd"] <= self.start_total
                        or not 0 < saved.get("max_spend_usd", 0) <= 1):
                    raise ValueError("Invalid retained Live authorization")
                retained = saved["baseline_usd"] + min(config.max_spend_usd, saved["max_spend_usd"])
                try:
                    authorized, _ = inspect_allocations(config.state, API_ROOT, self.start_total, retained)
                except Exception:
                    self.process_lock.close()
                    raise
                self.absolute_cap = min(self.absolute_cap, authorized)
            else:
                self.process_lock.close()
                raise ValueError("Existing paid envelope missing; never initialize or reset it during upgrade")
        self.thread = threading.Thread(target=self.work, name="live-single-worker", daemon=True)
        self.thread.start()

    def status(self, job):
        return {k: v for k, v in job.items() if k not in {"cancel", "directory", "request_key", "owner"}}

    def persist(self, job):
        write_json(job["directory"] / "job.json", self.status(job))

    def event(self, job, stage, code=None):
        if stage not in STAGES:
            return
        if job["events"] and job["events"][-1]["stage"] == stage:
            return
        job["status"] = stage if stage in TERMINAL else ("queued" if stage == "queued" else "running")
        job["stage"] = stage
        job["updated_at"] = time.time()
        job["events"].append(dict(sequence=len(job["events"]), stage=stage, at=job["updated_at"]))
        if code:
            job["error_code"] = code
        self.persist(job)

    def get(self, identity, session):
        if (not re.fullmatch(r"[a-f0-9]{32}", identity) or identity not in self.jobs
                or self.jobs[identity]["owner"] != session.owner):
            raise Reject("JOB_NOT_FOUND", 404)
        return self.jobs[identity]

    def submit(self, request, session, *, previous=None):
        request = validate(request)
        if not self.ready:
            raise Reject("PAID_EXECUTION_DISABLED_OR_KEY_UNCONFIGURED", 503)
        headroom()
        now = time.monotonic()
        with self.lock:
            if len(self.jobs) >= 32:
                raise Reject("SESSION_JOB_LIMIT", 429)
            while self.submissions and now - self.submissions[0] > 60:
                self.submissions.popleft()
            if len(self.submissions) >= 12:
                raise Reject("SUBMISSION_RATE_LIMIT", 429)
            if sum(j["status"] not in TERMINAL for j in self.jobs.values()) >= 4:
                raise Reject("QUEUE_FULL", 429)
            if previous and previous["attempt"] >= 3:
                raise Reject("RETRY_LIMIT", 409)
            if not self.config.fixture and ledger_total() >= self.absolute_cap:
                raise Reject("LIVE_BUDGET_EXHAUSTED", 402)
            identity = secrets.token_hex(16)
            job = dict(job_id=identity, run_id="live_" + identity, status="queued", stage="queued",
                       request=request, source_scope=scope_for(request), created_at=time.time(),
                       events=[], execution_kind="fixture" if self.config.fixture else "live",
                       attempt=previous["attempt"] + 1 if previous else 1,
                       retry_of=previous["job_id"] if previous else None,
                       cancel=False, directory=self.config.state / "jobs" / identity,
                       request_key=sha(request), cached_result=False, owner=session.owner)
            self.jobs[identity] = job
            self.submissions.append(now)
            self.event(job, "queued")
            return self.status(job)

    def cancel(self, identity, session):
        with self.lock:
            job = self.get(identity, session)
            if job["status"] in TERMINAL:
                return self.status(job)
            job["cancel"] = True
            if job["status"] == "queued":
                self.event(job, "cancelled", "CANCELLED_BY_ANALYST")
            return self.status(job)

    def retry(self, identity, session):
        with self.lock:
            previous = self.get(identity, session)
            if previous["status"] not in TERMINAL - {"completed"}:
                raise Reject("ONLY_UNSUCCESSFUL_JOBS_CAN_RETRY", 409)
            if previous.get("retry_job"):
                return self.status(self.get(previous["retry_job"], session))
            result = self.submit(previous["request"], session, previous=previous)
            previous["retry_job"] = result["job_id"]
            self.persist(previous)
            return result

    def result(self, identity, session):
        job = self.get(identity, session)
        if job["status"] != "completed":
            raise Reject("RESULT_NOT_READY", 409)
        wire, value, wire_sha = read_transport(job["directory"] / "result.json")
        validate_result(value, job["request"], job["run_id"])
        if (wire_sha != job.get("result_sha256")
                or sha(value) != job.get("result_decoded_sha256")):
            raise Reject("RESULT_INTEGRITY_FAILED", 409)
        validate_artifact_files(job["directory"], value)
        return wire

    def health(self, session):
        remaining = self.config.max_spend_usd if self.config.fixture else max(0.0, self.absolute_cap - ledger_total())
        from scope_defaults import corpus_defaults
        return dict(version="matryoshka-live-api/1", ready=self.ready and remaining > 0,
                    mode="fixture" if self.config.fixture else "live", paid_enabled=self.config.execute_paid,
                    model=MODEL, scope="query-only planning; Redaction-only model readings; deterministic execution",
                    limits=dict(max_query_bytes=2000, max_body_bytes=MAX_BODY, workers=1,
                                max_seconds=self.config.max_seconds, max_rss_mib=self.config.max_rss_mib,
                                max_session_spend_usd=self.config.max_spend_usd, job_spend_usd=self.config.job_spend_usd,
                                cumulative_cap_usd=50, session_jobs=32, queue=4, attempts=3),
                    remaining_live_allowance_usd=round(remaining, 6),
                    corpus_scopes=None if self.config.fixture else corpus_defaults(),
                    session_expires_in_seconds=self.auth.describe(session)["expires_in_seconds"])

    def logout(self, session):
        self.auth.revoke(session)
        for job in self.jobs.values():
            if job["owner"] == session.owner and job["status"] not in TERMINAL:
                self.cancel(job["job_id"], session)
        return dict(authenticated=False, revoked=True)

    def work(self):
        while not self.stop.wait(0.1):
            with self.lock:
                pending = next((j for j in self.jobs.values() if j["status"] == "queued"), None)
                if pending is None:
                    continue
            try:
                with self.lock:
                    if not self.auth.active(pending["owner"]):
                        self.event(pending, "cancelled", "SESSION_EXPIRED_OR_REVOKED")
                        continue
                    self.event(pending, "validating")
                self.run(pending)
            except Exception:
                # Never retain/return exception messages, environment or tracebacks.
                with self.lock:
                    if pending["status"] not in TERMINAL:
                        try:
                            self.event(pending, "failed", "WORKER_FAILED_CLOSED")
                        except Exception:
                            pending.update(status="failed", stage="failed", error_code="STORAGE_UNAVAILABLE")

    def run(self, job):
        cfg = self.config
        directory = job["directory"]
        payload = dict(request=job["request"], run_id=job["run_id"], fixture=cfg.fixture,
                       max_seconds=cfg.max_seconds, absolute_cap_usd=self.absolute_cap,
                       job_spend_usd=cfg.job_spend_usd)
        write_json(directory / "input.json", payload)
        # Child has only the environment needed by Python, NLP and the provider.
        environment = {k: v for k, v in os.environ.items() if k in {
            "PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "VIRTUAL_ENV", "OPENAI_API_KEY"}}
        if cfg.fixture:
            environment.pop("OPENAI_API_KEY", None)
        environment.update(PYTHONPATH=str(ROOT), PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1",
                           OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1",
                           TOKENIZERS_PARALLELISM="false")
        # Preserve any tighter caller-supplied shared envelope without copying secrets.
        if not cfg.fixture:
            ceiling = min(self.absolute_cap, ledger_total() + cfg.job_spend_usd)
            if os.environ.get("NARRATIVE_INCREMENTAL_BASELINE_USD") is not None:
                ceiling = min(ceiling, float(os.environ["NARRATIVE_INCREMENTAL_BASELINE_USD"])
                              + float(os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"]))
            environment.update(NARRATIVE_INCREMENTAL_BASELINE_USD="0",
                               NARRATIVE_INCREMENTAL_CEILING_USD=str(ceiling))
        process = subprocess.Popen([sys.executable, "-B", str(HERE / "worker.py"), str(directory)],
                                   env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, start_new_session=True)
        self.active = process
        start = time.monotonic()
        reason = None
        try:
            while process.poll() is None:
                if self.stop.is_set() or job["cancel"]:
                    reason = ("cancelled", "CANCELLED_BY_ANALYST")
                elif not self.auth.active(job['owner']):
                    reason = ('cancelled', 'SESSION_EXPIRED_OR_REVOKED')
                elif time.monotonic() - start > cfg.max_seconds:
                    reason = ("timed_out", "WALL_TIME_LIMIT")
                else:
                    try:
                        headroom()
                    except Reject:
                        reason = ("resource_limited", "DISK_FLOOR_3_GIB")
                    rss = subprocess.run(["/bin/ps", "-o", "rss=", "-p", str(process.pid)],
                                         capture_output=True, timeout=2, text=True)
                    if rss.returncode == 0 and rss.stdout.strip():
                        job["peak_rss_mib"] = max(job.get("peak_rss_mib", 0), int(rss.stdout.strip()) / 1024)
                        if job["peak_rss_mib"] > cfg.max_rss_mib:
                            reason = ("resource_limited", "MEMORY_LIMIT")
                if reason:
                    process.kill()
                    break
                progress = directory / "progress.json"
                if progress.is_file():
                    try:
                        value = read_json(progress)
                        stages = value.get("stages", [])
                        if len(stages) <= 16:
                            with self.lock:
                                for stage in stages[len(job["events"]) - 2:]:
                                    if stage in STAGES - TERMINAL and stage != "queued":
                                        self.event(job, stage)
                    except (ValueError, OSError):
                        pass
                time.sleep(0.15)
            process.wait(timeout=5)
            with self.lock:
                if reason or job["cancel"]:
                    self.event(job, *(reason or ("cancelled", "CANCELLED_BY_ANALYST")))
                elif process.returncode != 0 or not (directory / "result.json").is_file():
                    failure = read_json(directory / "failure.json") if (directory / "failure.json").is_file() else {}
                    safe = failure.get("code")
                    if safe not in {"QUERY_VALIDATION_FAILED", "BUDGET_LIMIT", "SOURCE_OR_RUNTIME_VALIDATION_FAILED", "DISK_FLOOR_3_GIB"}:
                        safe = "SOURCE_OR_RUNTIME_VALIDATION_FAILED"
                    self.event(job, "failed", safe)
                else:
                    try:
                        wire, value, wire_sha = read_transport(directory / "result.json")
                        validate_result(value, job["request"], job["run_id"])
                        validate_artifact_files(directory, value)
                    except (Reject, OSError, ValueError, TypeError):
                        self.event(job, "failed", "SOURCE_OR_RUNTIME_VALIDATION_FAILED")
                        return
                    job["result_sha256"] = wire_sha
                    job["result_decoded_sha256"] = sha(value)
                    job["result_encoding"] = wire.get("encoding", "json")
                    job["cached_result"] = value["receipt"]["execution_cache_hit"]
                    self.event(job, "completed")
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)
            self.active = None

    def close(self):
        self.stop.set()
        if self.active and self.active.poll() is None:
            self.active.kill()
        self.thread.join(timeout=8)
        self.process_lock.close()


def load_static_mirror():
    root = WORKSPACE / 'matryoshka_demo_site/release-tools'
    dependency = root / 'source_pdfs.py'
    loaded = sys.modules.get('source_pdfs')
    if loaded is not None:
        if Path(getattr(loaded, '__file__', '')).resolve() != dependency.resolve():
            raise ValueError('The static PDF dependency comes from another checkout')
    else:
        spec = importlib.util.spec_from_file_location('source_pdfs', dependency)
        loaded = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(loaded)
        sys.modules['source_pdfs'] = loaded
    spec = importlib.util.spec_from_file_location('live_static_mirror', root / 'serve_static.py')
    mirror = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mirror)
    return mirror


def create_server(config, token=None, *, port=8977, verifier=None):
    if not config.fixture and not token and verifier is None:
        raise ValueError('Private password or advanced capability required')
    for value in config.allowed_origins:
        origin(value)
    if config.public_origin:
        origin(config.public_origin)
        if not config.public_origin.startswith('https://') or config.trusted_proxy != '127.0.0.1':
            raise ValueError('Remote mode requires an explicit HTTPS origin and a trusted loopback TLS proxy')
    elif config.trusted_proxy:
        raise ValueError('A trusted proxy requires an explicit HTTPS public origin')
    authentication = Auth(verifier, token, seconds=config.session_seconds)
    mirror = load_static_mirror()
    http = mirror.server(config.site, port=port, prefix=PREFIX,
                         datasets_root=WORKSPACE / "matryoshka_demo_site/datasets")
    try:
        jobs = Jobs(config, authentication)
    except BaseException:
        http.server_close()
        raise
    allowed_hosts = {"127.0.0.1:" + str(http.server_port), "localhost:" + str(http.server_port)}
    allowed_origins = {"http://" + host for host in allowed_hosts} | set(config.allowed_origins)
    if config.public_origin:
        allowed_hosts.add(urlsplit(config.public_origin).netloc)
        allowed_origins.add(config.public_origin)
    base_handler = http.RequestHandlerClass.func

    class Handler(base_handler):
        server_version = "MatryoshkaLive/1"
        sys_version = ""

        def setup(self):
            super().setup()
            self.connection.settimeout(5)

        def log_message(self, *_):
            pass

        def list_directory(self, _):
            self.send_error(404)

        def send_error(self, code, message=None, explain=None):
            self.reply(code, dict(error="REQUEST_REJECTED"))

        def reply(self, status, value, *, retry_after=None):
            raw = encoded(value)
            if len(raw) > WIRE_LIMIT:
                status, raw = 507, encoded(dict(error="ARTIFACT_SIZE_LIMIT"))
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Vary", "Origin")
            self.send_header("Connection", "close")
            if retry_after is not None:
                self.send_header('Retry-After', str(max(1, min(60, int(retry_after)))))
            request_origin = self.headers.get("Origin")
            if request_origin in allowed_origins:
                self.send_header("Access-Control-Allow-Origin", request_origin)
            self.end_headers()
            self.close_connection = True
            if self.command != "HEAD":
                self.wfile.write(raw)

        def host_check(self):
            if len(self.headers.get_all("Host", [])) != 1 or self.headers["Host"] not in allowed_hosts:
                raise Reject("HOST_NOT_ALLOWED", 403)
            validate_request_target(self.path, self.command)

        def access(self, *, preflight=False, login=False):
            self.host_check()
            forwarded = any(self.headers.get(name) for name in ('Forwarded', 'X-Forwarded-Host', 'X-Forwarded-Proto', 'X-Forwarded-For'))
            public_host = config.public_origin and self.headers['Host'] == urlsplit(config.public_origin).netloc
            if public_host:
                if (self.client_address[0] != config.trusted_proxy or self.headers.get('X-Forwarded-Proto') != 'https'
                        or len(self.headers.get_all('X-Forwarded-Proto', [])) != 1):
                    raise Reject('HTTPS_PROXY_REQUIRED', 403)
            elif forwarded:
                raise Reject('UNTRUSTED_FORWARDED_HEADERS', 403)
            if len(self.headers.get_all("Origin", [])) > 1:
                raise Reject("ORIGIN_NOT_ALLOWED", 403)
            request_origin = self.headers.get("Origin")
            if not request_origin:
                # Same-origin browser GETs may omit Origin, and the Live page
                # deliberately sends no Referer. Browser-controlled Fetch
                # Metadata plus the explicit bearer/header bind this exception.
                request_origin = config.public_origin if public_host else "http://" + self.headers["Host"]
                if (preflight or self.command != "GET" or self.headers.get("Sec-Fetch-Site") != "same-origin"
                        or self.headers.get("Sec-Fetch-Mode") not in {"cors", "same-origin"}):
                    raise Reject("ORIGIN_REQUIRED", 403)
            if request_origin not in allowed_origins:
                raise Reject("ORIGIN_NOT_ALLOWED", 403)
            if not public_host and not preflight and login and urlsplit(request_origin).hostname not in {'127.0.0.1', 'localhost'}:
                raise Reject('USE_LOCAL_COMPANION_OR_HTTPS_BACKEND', 403)
            if urlsplit(self.path).query or "%" in self.path or "\\" in self.path:
                raise Reject("EXACT_API_PATH_REQUIRED")
            if not preflight:
                if self.headers.get("X-Live-Request") != "1" or self.headers.get("Cookie"):
                    raise Reject("EXPLICIT_NONCOOKIE_REQUEST_REQUIRED", 403)
                if login:
                    if self.headers.get_all('Authorization'):
                        raise Reject('LOGIN_REQUEST_INVALID')
                else:
                    if len(self.headers.get_all('Authorization', [])) != 1:
                        raise Reject('SESSION_CAPABILITY_REQUIRED', 401)
                    self.session = authentication.authenticate(self.headers.get('Authorization'), request_origin)
            return request_origin

        def body(self, limit=MAX_BODY):
            if (self.headers.get("Transfer-Encoding") or self.headers.get("Content-Encoding")
                    or len(self.headers.get_all("Content-Length", [])) != 1):
                raise Reject("FIXED_BODY_LENGTH_REQUIRED", 411)
            length = self.headers.get("Content-Length", "")
            if not re.fullmatch(r"[0-9]{1,5}", length) or not 0 < int(length) <= limit:
                raise Reject("BODY_TOO_LARGE", 413)
            if self.headers.get("Content-Type") != "application/json":
                raise Reject("JSON_REQUIRED", 415)
            def pairs(items):
                result = {}
                for key, value in items:
                    if key in result:
                        raise Reject("DUPLICATE_JSON_FIELD")
                    result[key] = value
                return result
            try:
                return json.loads(self.rfile.read(int(length)), object_pairs_hook=pairs,
                                  parse_constant=lambda _: (_ for _ in ()).throw(Reject("INVALID_JSON")))
            except (ValueError, UnicodeError, RecursionError):
                raise Reject("INVALID_JSON") from None

        def do_OPTIONS(self):
            try:
                self.access(preflight=True)
                headers = {h.strip().lower() for h in self.headers.get("Access-Control-Request-Headers", "").split(",") if h.strip()}
                login = self.path == '/live-api/session/login'
                required = {'content-type', 'x-live-request'} if login else {'authorization'}
                if (not self.path.startswith('/live-api/') or self.headers.get('Access-Control-Request-Method') not in {'GET', 'POST'}
                        or login and self.headers.get('Access-Control-Request-Method') != 'POST'
                        or not headers <= {'authorization', 'content-type', 'x-live-request'} or not required <= headers):
                    raise Reject("PREFLIGHT_NOT_ALLOWED", 403)
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", self.headers["Origin"])
                self.send_header("Access-Control-Allow-Methods", "GET, POST")
                self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Live-Request")
                self.send_header("Access-Control-Max-Age", "60")
                self.send_header("Vary", "Origin")
                self.send_header("Content-Length", "0")
                self.end_headers()
            except Reject as error:
                self.reply(error.status, dict(error=error.code), retry_after=getattr(error, 'retry_after', None))

        def dispatch(self):
            try:
                login = self.path == '/live-api/session/login' and self.command == 'POST'
                request_origin = self.access(login=login)
                if login:
                    value = self.body(limit=1024)
                    if not isinstance(value, dict) or set(value) != {'password'}:
                        raise Reject('LOGIN_REQUEST_INVALID')
                    result = authentication.login(value['password'], request_origin, self.client_address[0])
                    return self.reply(200, result)
                with jobs.lock:
                    if self.path == '/live-api/session' and self.command == 'GET':
                        value, status = authentication.describe(self.session), 200
                    elif self.path == '/live-api/session/logout' and self.command == 'POST':
                        if self.body() != {}:
                            raise Reject('EMPTY_ACTION_BODY_REQUIRED')
                        value, status = jobs.logout(self.session), 200
                    elif self.path == "/live-api/health" and self.command == "GET":
                        value, status = jobs.health(self.session), 200
                    elif self.path == "/live-api/jobs" and self.command == "POST":
                        value, status = jobs.submit(self.body(), self.session), 202
                    else:
                        match = re.fullmatch(r"/live-api/jobs/([a-f0-9]{32})(?:/(result|cancel|retry))?", self.path)
                        if not match:
                            raise Reject("ENDPOINT_NOT_FOUND", 404)
                        identity, action = match.groups()
                        job = jobs.get(identity, self.session)
                        if self.command == "GET" and action is None:
                            value, status = jobs.status(job), 200
                        elif self.command == "GET" and action == "result":
                            value, status = jobs.result(identity, self.session), 200
                        elif self.command == "POST" and action in {"cancel", "retry"}:
                            if self.body() != {}:
                                raise Reject("EMPTY_ACTION_BODY_REQUIRED")
                            value, status = (jobs.cancel(identity, self.session) if action == "cancel" else jobs.retry(identity, self.session)), 202
                        else:
                            raise Reject("METHOD_NOT_ALLOWED", 405)
                self.reply(status, value)
            except Reject as error:
                self.reply(error.status, dict(error=error.code), retry_after=getattr(error, 'retry_after', None))
            except Exception:
                self.reply(503, dict(error="SERVICE_UNAVAILABLE"))

        def do_GET(self):
            if self.path.startswith("/live-api"):
                return self.dispatch()
            try:
                self.host_check()
                request_origin = self.headers.get("Origin")
                if request_origin and request_origin not in allowed_origins:
                    raise Reject("ORIGIN_NOT_ALLOWED", 403)
                return super().do_GET()
            except Reject as error:
                self.reply(error.status, dict(error=error.code))

        def do_POST(self):
            return self.dispatch()

        def do_HEAD(self):
            # The inherited HEAD path bypasses the static mirror's path guard.
            self.reply(405, dict(error="METHOD_NOT_ALLOWED"))

    from functools import partial
    http.RequestHandlerClass = partial(Handler, directory=str(config.site))
    # Bound HTTP thread/socket resources independently from the single job worker.
    connections = threading.BoundedSemaphore(16)
    original_process = http.process_request
    original_thread = http.process_request_thread
    def process_request(request, address):
        if not connections.acquire(blocking=False):
            http.shutdown_request(request)
            return
        try:
            original_process(request, address)
        except BaseException:
            connections.release()
            raise
    def process_request_thread(request, address):
        try:
            original_thread(request, address)
        finally:
            connections.release()
    http.process_request = process_request
    http.process_request_thread = process_request_thread
    http.jobs = jobs
    http.auth = authentication
    return http


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8977)
    parser.add_argument("--execute-paid", action="store_true", help="Explicitly enable server-side paid planning/readings")
    parser.add_argument("--fixture", action="store_true", help="Synthetic API0 transport fixture, never inference")
    parser.add_argument("--allow-origin", action="append", default=[], help="Exact extra frontend origin, HTTPS only except loopback")
    parser.add_argument("--max-seconds", type=int, default=360)
    parser.add_argument("--max-spend-usd", type=float, default=1.0)
    parser.add_argument('--public-origin', help='Exact HTTPS backend origin behind a trusted TLS reverse proxy')
    parser.add_argument('--trusted-proxy', choices=('127.0.0.1',), help='Explicit TLS-terminating loopback proxy; never trust arbitrary forwarding headers')
    args = parser.parse_args()
    if args.fixture and args.execute_paid:
        parser.error("Fixture and paid execution are mutually exclusive")
    token = os.environ.get("LIVE_SESSION_TOKEN", "")
    try:
        verifier = PasswordVerifier.environment()
    except Exception:
        parser.exit(2, 'Invalid private password configuration. No credentials were printed.\n')
    if not verifier and not token:
        parser.error('Configure a private LIVE_PASSWORD_VERIFIER or LIVE_LOGIN_PASSWORD in the server environment')
    temporary = tempfile.TemporaryDirectory(prefix='fixture-server-', dir=HERE) if args.fixture else None
    config = Config(fixture=args.fixture, state=Path(temporary.name) if temporary else STATE, execute_paid=args.execute_paid,
                    max_seconds=args.max_seconds, max_spend_usd=args.max_spend_usd,
                    job_spend_usd=min(0.4, args.max_spend_usd), allowed_origins=tuple(args.allow_origin),
                    public_origin=args.public_origin, trusted_proxy=args.trusted_proxy)
    os.umask(0o077)
    try:
        http = create_server(config, token, port=args.port, verifier=verifier)
    except Exception:
        if temporary: temporary.cleanup()
        parser.exit(2, "Live startup failed closed: check capability, shared ledger, disk floor and limits.\n")
    del token
    print("http://127.0.0.1:" + str(http.server_port) + PREFIX + "live.html", flush=True)
    print("Mode: " + ("fixture (API0, not inference)" if args.fixture else
                       "paid opt-in" if args.execute_paid else "paid execution disabled"), flush=True)
    try:
        http.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        http.jobs.close()
        http.server_close()
        if temporary: temporary.cleanup()


if __name__ == "__main__":
    main()
