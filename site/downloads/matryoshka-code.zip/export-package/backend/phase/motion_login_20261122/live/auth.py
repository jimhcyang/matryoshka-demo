"""Server-only password verification and bounded, origin-bound bearer sessions."""
from collections import deque
from dataclasses import dataclass
import base64
import hashlib
import hmac
import os
import re
import secrets
import threading
import time
import unicodedata

from contract import Reject

N, R, P = 2**17, 8, 1
MAX_PASSWORD_BYTES = 256
MAX_SESSIONS = 8
SESSION_SECONDS = 900
CREDENTIAL_FORM = re.compile(r'\bsk-[A-Za-z0-9_-]+|\bOPENAI_API_KEY\s*=|\bBearer\s+\S+|\bAuthorization\s*:', re.I)
KNOWN_WEAK = ('matryoshka', 'matryoshka123456', 'passwordpassword', 'changemechangeme')


def credential_like(value):
    return isinstance(value, str) and CREDENTIAL_FORM.search(value) is not None


def derive(password, salt):
    return hashlib.scrypt(password.encode('utf-8'), salt=salt, n=N, r=R, p=P,
                          dklen=32, maxmem=256 * 1024**2)


def password_shape(password):
    if not isinstance(password, str) or any(unicodedata.category(char).startswith('C') for char in password):
        return False
    if not 16 <= len(password.encode('utf-8')) <= MAX_PASSWORD_BYTES or credential_like(password):
        return False
    # Inspect a trimmed view only for weakness; hashing always uses the exact
    # original password, including intentional leading/trailing spaces.
    visible = password.strip()
    if len(set(visible)) < 4 or visible.casefold() in KNOWN_WEAK:
        return False
    if any(len(visible) % width == 0 and visible == visible[:width] * (len(visible) // width)
           for width in range(1, len(visible) // 2 + 1)):
        return False
    return True


@dataclass(frozen=True)
class PasswordVerifier:
    salt: bytes
    expected: bytes

    @classmethod
    def make(cls, password):
        if not password_shape(password):
            raise ValueError('Configure a private password of at least 16 UTF-8 bytes, not a public/demo password or API key')
        salt = secrets.token_bytes(32)
        return cls(salt, derive(password, salt))

    @classmethod
    def parse(cls, value):
        fields = value.split('$')
        if len(fields) != 7 or fields[:5] != ['scrypt', 'v1', str(N), str(R), str(P)]:
            raise ValueError('Unsupported password-verifier parameters')
        try:
            salt, expected = (base64.b64decode(v, validate=True) for v in fields[5:])
        except Exception:
            raise ValueError('Invalid password verifier') from None
        if len(salt) != 32 or len(expected) != 32:
            raise ValueError('Invalid password-verifier lengths')
        verifier = cls(salt, expected)
        if any(hmac.compare_digest(derive(weak, salt), expected) for weak in KNOWN_WEAK):
            raise ValueError('A public/demo password is not an authentication secret')
        return verifier

    @classmethod
    def environment(cls):
        verifier = os.environ.get('LIVE_PASSWORD_VERIFIER')
        password = os.environ.get('LIVE_LOGIN_PASSWORD')
        if verifier and password:
            raise ValueError('Configure either a verifier or a private server-environment password, not both')
        return cls.parse(verifier) if verifier else cls.make(password) if password else None

    def export(self):
        return '$'.join(['scrypt', 'v1', str(N), str(R), str(P),
                         base64.b64encode(self.salt).decode(), base64.b64encode(self.expected).decode()])

    def verify(self, password):
        return password_shape(password) and hmac.compare_digest(derive(password, self.salt), self.expected)


class Throttled(Reject):
    def __init__(self, seconds=1, code='LOGIN_RATE_LIMIT'):
        super().__init__(code, 429)
        self.retry_after = max(1, min(60, int(seconds) + 1))


@dataclass(frozen=True)
class Session:
    owner: str
    origin: str
    expires: float
    token_hash: bytes
    legacy: bool = False


class Auth:
    def __init__(self, verifier=None, legacy_token=None, *, seconds=SESSION_SECONDS,
                 max_sessions=MAX_SESSIONS, clock=time.monotonic):
        if not 1 <= seconds <= SESSION_SECONDS or not 1 <= max_sessions <= MAX_SESSIONS:
            raise ValueError('Session bounds exceed the fixed authentication limits')
        if legacy_token and (not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', legacy_token) or credential_like(legacy_token)):
            raise ValueError('Invalid advanced capability')
        self.verifier, self.seconds, self.max_sessions, self.clock = verifier, seconds, max_sessions, clock
        self.legacy_hash = hashlib.sha256(legacy_token.encode()).digest() if legacy_token else None
        self.legacy_expires = clock() + seconds
        self.legacy_session = None
        self.sessions = {}
        self.attempts = deque()
        self.peers = {}
        self.lock = threading.RLock()
        self.check_slot = threading.BoundedSemaphore(1)

    def prune(self, now):
        for key, session in list(self.sessions.items()):
            if now >= session.expires:
                del self.sessions[key]
        while self.attempts and now - self.attempts[0] >= 60:
            self.attempts.popleft()
        for key, record in list(self.peers.items()):
            if now - record['last'] > 600:
                del self.peers[key]

    def login(self, password, request_origin, peer):
        if not self.verifier:
            raise Reject('PASSWORD_LOGIN_NOT_CONFIGURED', 503)
        try:
            valid_shape = isinstance(password, str) and 1 <= len(password.encode('utf-8')) <= MAX_PASSWORD_BYTES
        except UnicodeError:
            valid_shape = False
        if not valid_shape:
            raise Reject('LOGIN_REQUEST_INVALID')
        if credential_like(password):
            raise Reject('DO_NOT_SUBMIT_PROVIDER_CREDENTIALS')
        now = self.clock()
        with self.lock:
            self.prune(now)
            record = self.peers.get(peer)
            if record and now < record['blocked_until']:
                raise Throttled(record['blocked_until'] - now)
            if len(self.sessions) >= self.max_sessions:
                raise Throttled(30, 'SESSION_CAPACITY')
            if len(self.attempts) >= 12:
                raise Throttled(60 - (now - self.attempts[0]))
            if not record:
                if len(self.peers) >= 128:
                    raise Throttled(60)
                record = dict(last=now, blocked_until=0, failures=0, attempts=deque())
                self.peers[peer] = record
            while record['attempts'] and now - record['attempts'][0] >= 60:
                record['attempts'].popleft()
            if len(record['attempts']) >= 5:
                raise Throttled(60 - (now - record['attempts'][0]))
            if not self.check_slot.acquire(blocking=False):
                raise Throttled(1)
            self.attempts.append(now)
            record['attempts'].append(now)
            record['last'] = now
        try:
            valid = password_shape(password) and self.verifier.verify(password)
        finally:
            self.check_slot.release()
        with self.lock:
            now = self.clock()
            if not valid:
                record['failures'] = min(record['failures'] + 1, 7)
                record['blocked_until'] = now + min(60, 2 ** (record['failures'] - 1))
                raise Reject('LOGIN_FAILED', 401)
            self.prune(now)
            if len(self.sessions) >= self.max_sessions:
                raise Throttled(30, 'SESSION_CAPACITY')
            record['failures'] = 0
            token = secrets.token_urlsafe(32)
            while credential_like(token):
                token = secrets.token_urlsafe(32)
            key = hashlib.sha256(token.encode()).digest()
            self.sessions[key] = Session(secrets.token_hex(16), request_origin, now + self.seconds, key)
            return dict(version='matryoshka-live-session/1', access_token=token,
                        token_type='Bearer', expires_in_seconds=self.seconds)

    def authenticate(self, header, request_origin):
        if (not isinstance(header, str) or not header.startswith('Bearer ')
                or not re.fullmatch(r'[A-Za-z0-9_-]{32,256}', header[7:])):
            raise Reject('SESSION_CAPABILITY_REQUIRED', 401)
        key = hashlib.sha256(header[7:].encode()).digest()
        with self.lock:
            now = self.clock()
            self.prune(now)
            session = self.sessions.get(key)
            if session and session.origin == request_origin:
                return session
            if self.legacy_hash and hmac.compare_digest(key, self.legacy_hash) and now < self.legacy_expires:
                if self.legacy_session is None:
                    if len(self.sessions) >= self.max_sessions:
                        raise Throttled(30, 'SESSION_CAPACITY')
                    self.legacy_session = Session(secrets.token_hex(16), request_origin, self.legacy_expires, key, True)
                    self.sessions[key] = self.legacy_session
                if self.legacy_session.origin == request_origin:
                    return self.legacy_session
            raise Reject('SESSION_CAPABILITY_REQUIRED', 401)

    def active(self, owner):
        with self.lock:
            self.prune(self.clock())
            return any(session.owner == owner for session in self.sessions.values())

    def revoke(self, session):
        with self.lock:
            self.sessions.pop(session.token_hash, None)
            if session.legacy:
                self.legacy_hash = None
                self.legacy_session = None

    def describe(self, session):
        return dict(authenticated=True, expires_in_seconds=max(0, int(session.expires - self.clock())),
                    legacy_capability=session.legacy)


def main():
    import getpass
    import sys
    if len(sys.argv) != 2 or sys.argv[1] != '--make-verifier':
        raise SystemExit('Use --make-verifier interactively; no passwords in command arguments')
    if not sys.stdin.isatty():
        raise SystemExit('An interactive terminal is required; do not pass passwords through arguments or logged input')
    if sys.stdout.isatty():
        raise SystemExit('Capture the verifier directly into the server environment; do not print it to the terminal')
    password = getpass.getpass('Private Live access password: ')
    if password != getpass.getpass('Repeat password: '):
        raise SystemExit('Passwords differ')
    print(PasswordVerifier.make(password).export())


if __name__ == '__main__':
    main()
