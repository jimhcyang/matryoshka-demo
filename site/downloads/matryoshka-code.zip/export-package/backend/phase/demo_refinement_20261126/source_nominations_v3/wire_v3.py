"""Active overlap-safe validation of immutable V2 source-only request bodies."""
from copy import deepcopy
import hashlib
import importlib.util
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"source_nominations_v2"
V2_WIRE_SHA="84557d7bb2d404e1eb13088c912b1d8d0fa7a1ed71e0fbf2f0ba4ada96d24e93"
V2_FREEZE_SHA="8406ae86b5c5347917bae325e56627f737c7711964fc2ae72105950473a1a73e"
if hashlib.sha256((BASE/"wire_v2.py").read_bytes()).hexdigest()!=V2_WIRE_SHA:
    raise RuntimeError("PINNED_V2_WIRE_CHANGED")
if hashlib.sha256((BASE/"FREEZE_V2.json").read_bytes()).hexdigest()!=V2_FREEZE_SHA:
    raise RuntimeError("PINNED_V2_FREEZE_CHANGED")
spec=importlib.util.spec_from_file_location("pinned_source_partitions_v2",BASE/"wire_v2.py")
V2=importlib.util.module_from_spec(spec)
_old_bytecode=sys.dont_write_bytecode
try:
    sys.dont_write_bytecode=True
    spec.loader.exec_module(V2)
finally: sys.dont_write_bytecode=_old_bytecode
V1=V2.V1
DEMO=V2.DEMO
EPOCH=V2.EPOCH
WireError=V2.WireError
require=V2.require
encoded=V2.encoded
digest=V2.digest
strict_json=V2.strict_json
file_ref=V2.file_ref
LIMITS=deepcopy(V2.LIMITS)
PROMPT=V2.PROMPT
RESPONSE_SCHEMA=deepcopy(V2.RESPONSE_SCHEMA)
MODEL_INPUT_SCHEMA=deepcopy(V2.MODEL_INPUT_SCHEMA)
verify_packet=V2.verify_packet
build_partitions=V2.build_partitions
request_for_packet=V2.request_for_packet


def unique_start(text,needle,code):
    require(isinstance(text,str) and isinstance(needle,str) and bool(needle),code)
    first=text.find(needle)
    # Advancing ONE codepoint, not len(needle), includes overlapping matches.
    require(first>=0 and text.find(needle,first+1)<0,code)
    return first


def validate_response(packet,response,replay=True):
    checked=V2.validate_response(packet,response,replay=replay)
    if isinstance(response,(bytes,str)): response=strict_json(response)
    sources={p["page_id"]:p for p in packet["model_input"]["sources"]}
    for nomination,locator in zip(response["nominations"],checked["locators"]):
        text=sources[nomination["page_id"]]["windows"][0]["text"]
        start=unique_start(text,nomination["quote"],"SOURCE_QUOTE_NOT_EXACT_UNIQUE_OVERLAP_INCLUSIVE")
        phrase=start+unique_start(nomination["quote"],nomination["source_phrase"],"SOURCE_PHRASE_NOT_EXACT_UNIQUE_OVERLAP_INCLUSIVE")
        require((start,phrase)==(locator["quote_start"],locator["source_phrase_start"]),"RAW_LOCATOR_DISAGREEMENT")
    return dict(checked,version="source-nomination-partition-validation/3",
        active_validator="OVERLAP_INCLUSIVE_RAW_START_POSITION_UNIQUENESS",
        overlap_inclusive_uniqueness_validated=True)


def merge_responses(packets,responses,max_unique=20,replay=True):
    require(isinstance(packets,list) and bool(packets),"NO_PARTITION_SET")
    if replay:
        ordered=sorted(packets,key=lambda p:p["partition"]["index"])
        actual,_=build_partitions(ordered[0]["model_input"]["case"]["case_id"])
        require(encoded(actual)==encoded(ordered),"EXACT_PARTITION_SET_REPLAY_MISMATCH")
    require(isinstance(responses,list) and len(packets)==len(responses),"INCOMPLETE_RESPONSE_SET")
    by_index={}
    for response in responses:
        require(isinstance(response,dict) and type(response.get("partition_index")) is int
            and response["partition_index"] not in by_index,"DUPLICATE_OR_INVALID_RESPONSE_PARTITION")
        by_index[response["partition_index"]]=response
    for packet in packets:
        require(packet["partition"]["index"] in by_index,"INCOMPLETE_RESPONSE_SET")
        validate_response(packet,by_index[packet["partition"]["index"]],replay=False)
    result=V2.merge_responses(packets,responses,max_unique=max_unique,replay=False)
    return dict(result,version="source-nomination-partition-merge/3",overlap_inclusive_uniqueness_validated=True)


def verify_frozen_dependencies():
    refs=[]
    for folder,name in ((V2.BASE,"FREEZE_V1.json"),(BASE,"FREEZE_V2.json")):
        freeze=strict_json((folder/name).read_bytes())
        for ref in freeze["files"]:
            require(file_ref(DEMO/ref["path"])==ref,"FROZEN_DEPENDENCY_FILE_CHANGED")
        refs.append(file_ref(folder/name))
    return refs


def write_new(path,value):
    import json
    path=Path(path).absolute()
    require(path.resolve()==path and path.is_relative_to(HERE),"OUTPUT_OUTSIDE_V3_OWNERSHIP")
    raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
    if path.exists(): require(path.read_bytes()==raw,"IMMUTABLE_V3_OUTPUT_DIFFERS"); return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("xb") as stream: stream.write(raw)
