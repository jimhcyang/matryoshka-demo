"""Explicit V3/V4 reviewed model method; never a native/certificate adapter."""
from copy import deepcopy
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from review_lineage import V3,V4,V4Approval
from adapter import inventory
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import descriptor
from matryoshka_next.facts import SourcePolicy

VERSION = "mixed-reviewed-source-accounts/1"
METHOD_ID = "reviewed_source_model_accounts_v3_v4_explicit_composite1"


def _replacement(fact,page,observed,reviewed,receipt):
    raw = deepcopy(observed["raw_model_row"])
    anchors = {g["anchor_id"]:g for g in observed["anchors"]}
    selections = {s["anchor_id"]:s["candidate_ids"] for s in reviewed["review"]["anchor_resolutions"]}
    grounded = {}
    for field,value in raw["fields"].items():
        def selected(part):
            found = {}
            for gid,g in anchors.items():
                if not g["key"].startswith("fields."+field+"."+part+"."):
                    continue
                for c in g["candidates"]:
                    if c["candidate_id"] in selections.get(gid,[]):
                        s = {k:c[k] for k in ("start","end","text")}
                        found[digest(s)] = s
            return list(found.values())
        grounded[field] = dict(state=value["state"],query_spans=selected("query"),source_spans=selected("source"),
            query_coordinate_system="BOUND_FACT_TEXT",bound_public_query_spans=deepcopy(fact["query_spans"]))
    contracts = V3.requested_fields(fact["text"])
    weights = {k:V3.WEIGHTS[k] for k,c in contracts.items() if c["required"]}
    matched = sum(w for k,w in weights.items() if raw["fields"][k]["state"]=="MATCHED")
    denominator = sum(weights.values())
    coverage = matched/denominator
    env = observed["qualification_envelope"]
    lexical = V3.P.lexical_fit(fact["text"],env["paragraph"]["text"] if env else "")
    label = reviewed["effective_label"]
    return dict(**raw,judgment_id=digest([VERSION,observed["observation_row_id"],receipt["call_id"]]),
        effective_label=label,document_id=page["document_id"],date=page["date"],page_sha256=page["source_sha256"],
        review=deepcopy(reviewed["review"]),unanimous_accept=reviewed["unanimous_model_accept"],grounded_fields=grounded,
        qualification_envelope=deepcopy(env),grounded_hypothesis_relation=deepcopy(raw["hypothesis_relation"]),
        v4_all_anchor_candidates=deepcopy(observed["anchors"]),v4_observation_row_id=observed["observation_row_id"],
        local_scope_guards=deepcopy(observed["local_scope_guards"]),method="V4_REVIEWED_MODEL_SOURCE_ACCOUNT_NOT_DETERMINISTIC_PROOF",
        requested_facet_weights=weights,matched_weight=matched,requested_weight=denominator,facet_coverage=coverage,
        local_lexical_fit=lexical,context_priority_index=.75*coverage+.25*lexical["value"] if label not in {"HOLD","NONE"} else 0.,
        calibrated_probability=False,factual_world_execution_certified=False,inner_execution=False,event_join_authority=False,
        reviewed_method_version="V4",first_pass_receipt_unchanged=True)


def results(preflight,v3_batches,v4_approvals,*,allow_test_fixtures=False):
    base = V3.results_adapter(preflight,v3_batches,allow_partial_pool=True,allow_test_fixtures=allow_test_fixtures)
    pf = preflight.export()
    facts,pages = {f["id"]:f for f in pf["required_facts"]},{p["id"]:p for p in pf["pages"]}
    rows = {(r["fact_id"],r["page_id"]):deepcopy(r) for r in base["source_judgments"]}
    first_pass = {b.export()["wire"]["request_sha256"]:b.export() for b in v3_batches}
    replaced,lineage,receipts = set(),[],deepcopy(base["model_provenance"])
    for approval in v4_approvals:
        V4.require(type(approval) is V4Approval,"Only fresh source/provider-validated V4 approvals may enter this method")
        a = approval.export()
        obs,review = a["observation"],a["review"]
        V4.require(allow_test_fixtures or not review["test_only"],"Fixture cannot authorize actual source-model credit")
        V4.require(obs["preflight_sha256"]==pf["sha256"] and review["observation_sha256"]==obs["sha256"],"Different case/native/source policy observation")
        wire = obs["original_assessment_wire"]
        V3._wire(preflight,wire)
        prior = first_pass.get(wire["request_sha256"])
        V4.require(prior is not None and prior["wire"]==wire and prior["assessment_receipt"]==obs["original_model_receipt"],"V4 has another or unprocessed first-pass provider chain")
        observed = {r["observation_row_id"]:r for r in obs["rows"]}
        for record in review["rows"]:
            row = observed[record["observation_row_id"]]
            key = row["fact_id"],row["page_id"]
            V4.require(key in rows and key not in replaced,"Duplicate, unknown or previously unprocessed V4 slot")
            replaced.add(key)
            previous = rows[key]
            old_raw = previous["raw_model_row"] if "raw_model_row" in previous else {k:previous[k] for k in row["raw_model_row"]}
            V4.require(old_raw==row["raw_model_row"],"V4 cannot repair/change an original model quote, field or label")
            replacement = _replacement(facts[key[0]],pages[key[1]],row,record,review["new_review_receipt"])
            rows[key] = replacement
            lineage.append(dict(fact_id=key[0],page_id=key[1],policy="EXPLICIT_V4_SLOT_REPLACEMENT_INCLUDING_HOLD_NOT_BEST_LABEL_SELECTION",
                prior_V3_row=previous,selected_V4_judgment_id=replacement["judgment_id"],
                observation_sha256=obs["sha256"],review_receipt=review["new_review_receipt"],
                unchanged_first_pass_receipt=obs["original_model_receipt"]))
        receipts.append(deepcopy(review["new_review_receipt"]))
    evidence = list(rows.values())
    h = pf["public_case"]["task"]=="hypothesis"
    atoms = []
    for fid,fact in facts.items():
        best = {}
        for row in evidence:
            if row["fact_id"]!=fid or row["effective_label"] in {"REJECTED_ROW","HOLD","NONE"}:
                continue
            key = row["document_id"],row["effective_label"]
            if key not in best or row["context_priority_index"]>best[key]["context_priority_index"]:
                best[key]=row
        labels = {r["effective_label"] for r in best.values()}
        status = ("CONTESTED_SOURCE_ACCOUNTS" if {"SUPPORT","OPPOSE"}<=labels else "SOURCE_ASCRIBED" if "SUPPORT" in labels else
            "OPPOSING_SOURCE_ACCOUNT" if "OPPOSE" in labels else "PARTIAL_SOURCE_ASCRIPTION" if "PARTIAL" in labels else
            "CONTEXT_ONLY" if "CONTEXT" in labels else "UNRESOLVED")
        groups = {}
        for row in best.values():
            key = row["effective_label"],digest(" ".join(row["qualification_envelope"]["paragraph"]["text"].casefold().split()))
            groups.setdefault(key,[]).append(row)
        atoms.append(dict(id=fid,text=fact["text"],status="SOURCE_VIEWS_RECORDED" if h and labels&{"SUPPORT","OPPOSE"} else status,
            complete_source_component=None if h else "SUPPORT" in labels and "OPPOSE" not in labels,
            supporting_source_account_present="SUPPORT" in labels,opposing_source_account_present="OPPOSE" in labels,
            authority="QUERIED_ASSESSMENT_ONLY" if h else "SOURCE_ASCRIPTION",world_truth_verdict="NOT_ASSESSED",
            inner_execution=False,event_join_authority=False,
            source_groups=[dict(label=k[0],quote_group_sha256=k[1],document_ids=sorted({r["document_id"] for r in rs}),
                context_priority_index=max(r["context_priority_index"] for r in rs),independence_claimed=False) for k,rs in sorted(groups.items())]))
        if h:
            atoms[-1]["source_balance"]={sign:dict(report_groups=sum(g["label"]==sign for g in atoms[-1]["source_groups"]),
                context_index_sum=sum(g["context_priority_index"] for g in atoms[-1]["source_groups"] if g["label"]==sign),independent_votes=False) for sign in ("SUPPORT","OPPOSE")}
    result = dict(version=VERSION,method_id=METHOD_ID,method="EXPLICIT_MIXED_REVIEWED_MODEL_SOURCE_ACCOUNTS_NOT_NATIVE",
        public_case=pf["public_case"],preflight_sha256=pf["sha256"],inspection_authority=pf["inspection_authority"],source_view_policy=pf["source_view_policy"],
        atoms=atoms,source_judgments=evidence,model_provenance=receipts,method_lineage=lineage,
        baseline_V3_result_sha256=base["sha256"],baseline_V3_result=base,
        coverage=None if h else sum(a["complete_source_component"] for a in atoms)/len(atoms),
        all_required_components_source_ascribed=None if h else all(a["complete_source_component"] for a in atoms),
        original_pool_slots=base["original_pool_slots"],processed_slots=base["processed_slots"],
        rejected_slots=sum(r["effective_label"]=="REJECTED_ROW" for r in evidence),
        original_pool_completely_processed=base["original_pool_completely_processed"],unassessed_slots=base["unassessed_slots"],
        final_score_formula="0.75*matched_requested_facet_fraction+0.25*local_lexical_fit; HOLD/NONE=0; context priority not confidence",
        bm25_used_in_final_score=False,calibrated_probability=False,whole_query_world_truth_established=False,
        source_independence_certified=False,inner_execution=False,event_join_authority=False,native_history_modified=False,
        test_only=allow_test_fixtures,unanimous_model_agreement_is_not_deterministic_proof=True)
    result["sha256"]=digest(result)
    return result


def project(preflight,v3_batches,v4_approvals,source_policy,*,allow_test_fixtures=False):
    """Return METHOD/VIEW with existing reader shapes and an explicit NEW method ID."""
    pf = preflight.export()
    V4.require(type(source_policy) is SourcePolicy and source_policy.case==V3.P.engine_case(pf["public_case"])
        and descriptor(source_policy.source_view_policy)==pf["source_view_policy"],"Same trusted source policy required")
    result = results(preflight,v3_batches,v4_approvals,allow_test_fixtures=allow_test_fixtures)
    pages = {p["id"]:p for p in pf["pages"]}
    nodes,edges,endpoints = {},[],[]
    for fact in pf["required_facts"]:
        key="input-component:"+digest([pf["sha256"],fact["id"]])
        nodes[key]=dict(id=key,kind="REQUIRED_INPUT_COMPONENT",atom_id=fact["id"],text=fact["text"],query_spans=fact["query_spans"])
    def bind(row,s):
        page=pages[row["page_id"]]
        pi=source_policy.corpus.page_index[page["id"]]
        original=source_policy.corpus.pages[pi]
        V4.require(all(original[k]==page[k] for k in page),"Source inspection/canonical page differs")
        citation=source_policy.citation(pi,s["start"],s["end"])
        V4.require(citation["text"]==s["text"] and citation["page_sha256"]==page["source_sha256"],"Exact source citation failed")
        did,pid,eid="source-document:"+digest([page["corpus"],page["document_id"]]),"source-page:"+digest([page["id"],page["source_sha256"]]),"source-excerpt:"+digest(citation)
        nodes[did]=dict(id=did,kind="SOURCE_DOCUMENT",document_id=page["document_id"],corpus=page["corpus"])
        nodes[pid]=dict(id=pid,kind="SOURCE_PAGE",canonical_page_id=page["id"],document_id=page["document_id"],date=page["date"],page_sha256=page["source_sha256"],raw_text=page["text"])
        nodes[eid]=dict(id=eid,kind="EXACT_RAW_SOURCE_EXCERPT",citation=citation,ordinary_KG_node_id=None)
        for a,b,kind in ((did,pid,"RECORDED_DOCUMENT_PAGE"),(pid,eid,"EXACT_RAW_SPAN_CONTAINMENT")):
            edge=dict(source=a,target=b,kind=kind,historical_relation_certified=False,event_join_authority=False)
            if edge not in edges: edges.append(edge)
        return eid,citation
    for row in result["source_judgments"]:
        if row["effective_label"]=="REJECTED_ROW" or not row.get("qualification_envelope"): continue
        env=row["qualification_envelope"]
        eid,citation=bind(row,env["raw_quote_span"])
        context_id,context=bind(row,env["paragraph"])
        account="model-source-account:"+row["judgment_id"]
        target="input-component:"+digest([pf["sha256"],row["fact_id"]])
        nodes[account]=dict(id=account,kind="REVIEWED_MODEL_SOURCE_ACCOUNT",judgment_id=row["judgment_id"],effective_label=row["effective_label"],
            authority=row["authority"],reviewed_method_version=row.get("reviewed_method_version","V3"),deterministic_proof=False,inner_execution=False)
        edges += [dict(source=eid,target=account,kind="QUOTED_MODEL_INPUT",historical_relation_certified=False),
            dict(source=context_id,target=account,kind="FULL_QUALIFICATION_CONTEXT",historical_relation_certified=False),
            dict(source=account,target=target,kind="MODEL_ASSESSES_COMPONENT",label=row["effective_label"],deterministic_support=False,event_join_authority=False)]
        endpoints.append(dict(atom_id=row["fact_id"],judgment_id=row["judgment_id"],endpoint_id=eid,qualification_endpoint_id=context_id,
            quote=citation,qualification_quote=context,source_edition=citation.get("source_edition"),physical_page=citation.get("physical_page"),
            native_KG_node_id=None,native_semantic_route=None,inspection_only=True,input_to_source_world_edge_invented=False))
    old_scope=inventory(preflight,v3_batches,V3,allow_test_fixtures=allow_test_fixtures)
    scope=deepcopy(old_scope)
    active={(r["fact_id"],r["page_id"]):r for r in result["source_judgments"]}
    for item in scope["grid"]:
        row=active.get((item["fact_id"],item["page_id"]))
        if row:
            item.update(label=row["effective_label"],state="ROW_REJECTED" if row["effective_label"]=="REJECTED_ROW" else "REVIEW_HOLD" if row["effective_label"]=="HOLD" else "REVIEWED_"+row["effective_label"],error=row.get("error"))
    scope.update(version="explicit-mixed-source-method-scope/1",baseline_V3_scope=old_scope,rejected_slots=result["rejected_slots"],
        reviewed_slots=sum(r["effective_label"]!="REJECTED_ROW" for r in active.values()),
        inspected_pool_completely_assessed=scope["inspected_pool_completely_processed"] and result["rejected_slots"]==0,
        mixed_method_declared=True)
    packet=dict(version="reviewed-source-model-pipeline-projection/1",method_id=METHOD_ID,method_label="Reviewed model source accounts (V3 + V4)",
        incumbent_native_method=False,producer_version=VERSION,public_case=pf["public_case"],query_sha256=digest(pf["public_case"]["query"]),
        preflight_sha256=pf["sha256"],inspection_authority=pf["inspection_authority"],source_view_policy=pf["source_view_policy"],
        source_origin=dict(document_id=pf["public_case"]["document_id"],date=pf["public_case"]["date"],inherited_binding="ORIGINAL_PUBLIC_CASE_AND_PINNED_NATIVE",origin_body_used=False,origin_packet_ref_not_invented=True),
        atom_refs=[dict(atom_id=f["id"],text=f["text"],query_spans=f["query_spans"]) for f in pf["required_facts"]],
        reviewed_model_result=result,assessment_scope=scope,source_endpoints=endpoints,
        graph=dict(version="semantic-source-containment-inspection-graph/1",nodes=list(nodes.values()),edges=edges,native_semantic_edges_created=0,actual_KG_edges_inferred=False),
        native_history_modified=False,native_gates_modified=False,deterministic_semantic_proof=False,world_truth_certified=False,
        inner_execution=False,event_join_authority=False,unseen_sources_are_not_NONE=True,source_independence_claimed=False,test_only=allow_test_fixtures)
    packet["sha256"]=digest(packet)
    evidence_by_id={e["judgment_id"]:e for e in endpoints}
    atoms=[]
    for a in result["atoms"]:
        evidence=[]
        for r in result["source_judgments"]:
            if r["fact_id"]!=a["id"] or r["effective_label"] in {"REJECTED_ROW","HOLD","NONE"}: continue
            e=evidence_by_id[r["judgment_id"]]
            evidence.append(dict(judgment_id=r["judgment_id"],direction=r["effective_label"],citation=e["quote"],qualification_citation=e["qualification_quote"],
                source_endpoint_id=e["endpoint_id"],qualification_endpoint_id=e["qualification_endpoint_id"],model_quote_unchanged=r["quote"],
                grounded_fields=r["grounded_fields"],qualifications=r.get("grounded_hypothesis_relation"),context_priority_index=r["context_priority_index"],
                facet_coverage=r["facet_coverage"],local_lexical_fit=r["local_lexical_fit"],review=r["review"],authority=r["authority"],
                reviewed_method_version=r.get("reviewed_method_version","V3"),model_reviewed=True,deterministic_proof=False,inner_execution=False,event_join_authority=False))
        atoms.append(dict(id=a["id"],text=a["text"],status=a["status"],label="Source-account supported" if a["status"]=="SOURCE_ASCRIBED" else a["status"],
            authority=a["authority"],query_spans=next(f["query_spans"] for f in pf["required_facts"] if f["id"]==a["id"]),
            complete_by_model_source_review=a["complete_source_component"],evidence=evidence,
            source_counts={sign:len({r["citation"]["document_id"] for r in evidence if r["direction"]==sign}) for sign in ("SUPPORT","OPPOSE","PARTIAL","CONTEXT")},
            counts_are_independent_votes=False,world_truth_verdict="NOT_ASSESSED"))
    view=dict(version="reviewed-source-workbench-view/1",method_id=METHOD_ID,method_label=packet["method_label"],incumbent_native_method=False,
        case=pf["public_case"],query_sha256=packet["query_sha256"],original_native_ref=pf["inspection_authority"]["native_ref"],
        original_inspection_ref=pf["inspection_authority"]["inspection_ref"],execution_context=pf["inspection_authority"]["execution_context"],
        source_origin=packet["source_origin"],source_view_policy=pf["source_view_policy"],method_packet_sha256=packet["sha256"],
        atoms=atoms,coverage=result["coverage"],caveat="Explicit V3/V4 reviewed MODEL source accounts, not deterministic event proof. Unprocessed/rejected source slots remain unresolved.",
        review_pending_disclosure=None,assessment_scope=scope,source_endpoints=endpoints,trace=packet["graph"],model_provenance=result["model_provenance"],
        method_lineage=result["method_lineage"],native_status_or_gates_rewritten=False,source_drawer_reuses_exact_citations=True,
        origin_drawer_binding_unchanged=True,synthetic_native_ESTABLISHED_labels_created=False,deterministic_event_join_authority=False)
    view["sha256"]=digest(view)
    return packet,view
