"""Conservative source eligibility/disclosure projection; no model/native edits."""
from copy import deepcopy
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent/"method_adapter_v1"),str(HERE.parent)]
import mixed_accounts as V1
from review_lineage import V4
from matryoshka_demo.io import digest

VERSION="source-account-disclosure/2"
H_METHOD_ID="reviewed_source_model_accounts_v3_temporal_qualified1"
BLOCKED={"HOLD","REJECTED_ROW","REVIEW_PENDING","UNPROCESSED"}


def rehash(value):
    value.pop("sha256",None)
    value["sha256"]=digest(value)
    return value


def recount_scope(scope,rows):
    """Count adjudication states, never equate a reviewed HOLD with acceptance."""
    result=deepcopy(scope)
    active={(r["fact_id"],r["page_id"]):r for r in rows}
    V4.require(len(active)==len(rows),"Duplicate active source slots")
    keys={(r["fact_id"],r["page_id"]) for r in result["grid"]}
    V4.require(len(keys)==len(result["grid"]) and set(active)<=keys,"Unknown/duplicate source grid slots")
    total=len(keys)
    V4.require(total==result["original_slots"],"Inspected-pool denominator changed")
    counts=dict(processed_slots=0,provider_reviewed_slots=0,model_accepted_slots=0,accepted_slots=0,
        held_slots=0,review_hold_slots=0,eligibility_hold_slots=0,rejected_slots=0,review_pending_slots=0,unprocessed_slots=0)
    for item in result["grid"]:
        row=active.get((item["fact_id"],item["page_id"]))
        if row is None:
            V4.require(item["state"]=="UNPROCESSED","Processed grid slot has no bound source row")
            counts["unprocessed_slots"]+=1
            item.update(provider_reviewed=False,model_accepted=False,eligible_accepted=False)
            continue
        counts["processed_slots"]+=1
        label=row["effective_label"]
        reviewed=isinstance(row.get("review"),dict)
        accepted=row.get("unanimous_accept") is True
        temporal=bool(row.get("temporal_eligibility_hold"))
        counts["provider_reviewed_slots"]+=int(reviewed)
        counts["model_accepted_slots"]+=int(accepted)
        item.update(label=label,provider_reviewed=reviewed,model_accepted=accepted,eligible_accepted=False)
        if label=="REJECTED_ROW":
            counts["rejected_slots"]+=1;item["state"]="ROW_REJECTED"
        elif label=="REVIEW_PENDING" or item["state"]=="REVIEW_PENDING":
            counts["review_pending_slots"]+=1;item["state"]="REVIEW_PENDING"
        elif temporal:
            counts["held_slots"]+=1;counts["eligibility_hold_slots"]+=1
            item["state"]="SOURCE_ELIGIBILITY_HOLD"
            item["temporal_eligibility_hold"]=deepcopy(row["temporal_eligibility_hold"])
        elif label=="HOLD" or not (reviewed and accepted):
            counts["held_slots"]+=1;counts["review_hold_slots"]+=1;item["state"]="REVIEW_HOLD"
        else:
            counts["accepted_slots"]+=1;item.update(state="REVIEWED_"+label,eligible_accepted=True)
    V4.require(counts["accepted_slots"]+counts["held_slots"]+counts["rejected_slots"]+counts["review_pending_slots"]==counts["processed_slots"],"Scope states do not partition processed slots")
    complete=counts["accepted_slots"]==total
    result.update(counts)
    result.update(version=VERSION,reviewed_slots=counts["provider_reviewed_slots"],
        eligible_accepted_slots=counts["accepted_slots"],reviewed_slots_meaning="PROVIDER_REVIEWED_INCLUDING_HOLD_NOT_ACCEPTED",
        inspected_pool_completely_processed=counts["processed_slots"]==total,
        inspected_pool_completely_assessed=complete,all_slots_resolved_by_eligible_review=complete,
        partial_inspected_pool_processing=counts["unprocessed_slots"]>0,partial_assessment=not complete,
        partial_search=True,search_scope="RECORDED_INSPECTED_PAGES_NOT_WHOLE_ELIGIBLE_CORPUS",whole_corpus_search_claimed=False)
    return result


def _warning_for(row,pages,warnings,cutoff):
    matches=[w for w in warnings if w["page_id"]==row["page_id"]]
    V4.require(len(matches)<=1,"Duplicate source-date warning")
    if not matches: return None
    warning=deepcopy(matches[0]);page=pages[row["page_id"]]
    V4.require(warning["document_id"]==page["document_id"]==row["document_id"]
        and warning["page_sha256"]==page["source_sha256"]==digest(page["text"])
        and warning["canonical_source_date"]==page["date"]==row["date"]
        and warning["origin_cutoff"]==cutoff,"Source warning/cutoff/hash binding differs")
    V4.require(bool(warning["exact_page_spans"]),"A source conflict needs actual literal spans")
    for s in warning["exact_page_spans"]:
        V4.require(type(s["start"]) is int and type(s["end"]) is int and 0<=s["start"]<s["end"]<=len(page["text"])
            and page["text"][s["start"]:s["end"]]==s["text"],"Source warning quote/span differs")
    warning.update(temporal_eligibility_hold=True,internal_date_conflict=True,
        eligible_directional_vote=False,source_date_rewritten=False,date_resolution="UNRESOLVED_SOURCE_OWNER_REVIEW_REQUIRED")
    return warning


def _aggregate_h(result):
    """Aggregate the declared eligibility projection, not new semantic judgments."""
    for atom in result["atoms"]:
        best={}
        for row in result["source_judgments"]:
            if row["fact_id"]!=atom["id"] or row["effective_label"] in {"REJECTED_ROW","HOLD","NONE"}: continue
            key=row["document_id"],row["effective_label"]
            if key not in best or row["context_priority_index"]>best[key]["context_priority_index"]: best[key]=row
        groups={}
        for row in best.values():
            key=row["effective_label"],digest(" ".join(row["qualification_envelope"]["paragraph"]["text"].casefold().split()))
            groups.setdefault(key,[]).append(row)
        atom["source_groups"]=[dict(label=k[0],quote_group_sha256=k[1],document_ids=sorted({r["document_id"] for r in rs}),
            context_priority_index=max(r["context_priority_index"] for r in rs),independence_claimed=False) for k,rs in sorted(groups.items())]
        signs={r["effective_label"] for r in best.values() if not r.get("temporal_eligibility_hold")}
        atom.update(supporting_source_account_present="SUPPORT" in signs,opposing_source_account_present="OPPOSE" in signs,
            status="SOURCE_VIEWS_RECORDED" if signs&{"SUPPORT","OPPOSE"} else "CONTEXT_ONLY" if "CONTEXT" in signs else "UNRESOLVED")
        atom["source_balance"]={sign:dict(report_groups=sum(g["label"]==sign for g in atom["source_groups"]),
            context_index_sum=sum(g["context_priority_index"] for g in atom["source_groups"] if g["label"]==sign),independent_votes=False) for sign in ("SUPPORT","OPPOSE")}


def revise(method,view,*,source_pages=(),temporal_warnings=()):
    """New immutable publication revision. Original model reviews remain verbatim."""
    V4.require(view["method_packet_sha256"]==method["sha256"]==digest({k:v for k,v in method.items() if k!="sha256"}),"Original METHOD/VIEW binding differs")
    V4.require(view["sha256"]==digest({k:v for k,v in view.items() if k!="sha256"}),"Original VIEW digest differs")
    m,v=deepcopy(method),deepcopy(view)
    original_result=deepcopy(method["reviewed_model_result"])
    result=m["reviewed_model_result"]
    warnings_by_id={}
    if temporal_warnings:
        V4.require(m["public_case"]["task"]=="hypothesis","Temporal warning projection in this revision is H-only")
        pages={p["id"]:p for p in source_pages}
        V4.require(len({w["page_id"] for w in temporal_warnings})==len(temporal_warnings),"Duplicate date warnings")
        for row in result["source_judgments"]:
            warning=_warning_for(row,pages,temporal_warnings,m["public_case"]["date"])
            if warning is None: continue
            warnings_by_id[row["judgment_id"]]=warning
            row.update(original_model_effective_label=row["effective_label"],original_model_context_priority_index=row["context_priority_index"],
                eligibility_effective_label="CONTEXT",effective_label="CONTEXT",context_priority_index=0.,
                temporal_eligibility_hold=warning,internal_date_conflict=True,eligible_directional_vote=False,
                eligibility_projection_not_new_model_review=True)
        V4.require({w["page_id"] for w in temporal_warnings}=={r["page_id"] for r in result["source_judgments"] if r.get("temporal_eligibility_hold")},"Date warning did not bind a recorded source account")
        result.update(version="temporally-qualified-source-model-projection/1",method="ELIGIBILITY_PROJECTION_NOT_NEW_MODEL_JUDGMENT",
            original_reviewed_model_result=original_result,original_reviewed_model_result_sha256=original_result["sha256"],
            original_model_reviews_unchanged=True,temporal_source_warnings=deepcopy(temporal_warnings))
        _aggregate_h(result);rehash(result)
        m.update(method_id=H_METHOD_ID,producer_version="source-account-publication-qualification/1",
            original_method_id=method["method_id"],original_producer_version=method["producer_version"])
        v.update(method_id=H_METHOD_ID,original_method_id=view["method_id"])
        for a in v["atoms"]:
            projected=next(x for x in result["atoms"] if x["id"]==a["id"])
            a["status"]=projected["status"]
            for e in a["evidence"]:
                warning=warnings_by_id.get(e["judgment_id"])
                if warning:
                    e.update(original_model_direction=e["direction"],direction="CONTEXT",original_model_context_priority_index=e["context_priority_index"],
                        context_priority_index=0.,temporal_eligibility_hold=warning,internal_date_conflict=True,eligible_directional_vote=False,
                        eligibility_projection_not_new_model_review=True)
            a["source_counts"]={sign:len({e["citation"]["document_id"] for e in a["evidence"] if e["direction"]==sign and (sign not in {"SUPPORT","OPPOSE"} or not e.get("temporal_eligibility_hold"))}) for sign in ("SUPPORT","OPPOSE","PARTIAL","CONTEXT")}
            a["source_balance"]=deepcopy(projected["source_balance"])
        for e in m["source_endpoints"]:
            if e["judgment_id"] in warnings_by_id:
                e.update(temporal_eligibility_hold=warnings_by_id[e["judgment_id"]],eligible_directional_vote=False)
        for node in m["graph"]["nodes"]:
            if node.get("judgment_id") in warnings_by_id:
                node.update(original_model_effective_label=node["effective_label"],effective_label="CONTEXT",
                    temporal_eligibility_hold=warnings_by_id[node["judgment_id"]],eligible_directional_vote=False)
        accounts={n["id"]:n for n in m["graph"]["nodes"] if n.get("judgment_id") in warnings_by_id}
        for edge in m["graph"]["edges"]:
            if edge["source"] in accounts and edge.get("kind")=="MODEL_ASSESSES_COMPONENT":
                edge.update(original_model_label=edge["label"],label="CONTEXT",eligible_directional_vote=False,
                    temporal_eligibility_hold=accounts[edge["source"]]["temporal_eligibility_hold"])
    scope=recount_scope(m["assessment_scope"],result["source_judgments"])
    m.update(assessment_scope=scope,projection_revision=VERSION,supersedes_method_sha256=method["sha256"],
        source_integrity_warnings=list(warnings_by_id.values()))
    rehash(m)
    counts="Processed {processed_slots}/{original_slots}; provider-reviewed {provider_reviewed_slots}; eligible accepted {accepted_slots}; held {held_slots}; rejected {rejected_slots}; unprocessed {unprocessed_slots}.".format(**scope)
    v.update(assessment_scope=deepcopy(scope),projection_revision=VERSION,method_packet_sha256=m["sha256"],
        source_endpoints=deepcopy(m["source_endpoints"]),trace=deepcopy(m["graph"]),source_integrity_warnings=list(warnings_by_id.values()),
        caveat="Reviewed MODEL source accounts, not world-event proof. "+counts+" Partial source search/assessment; the inspected pool is not the whole eligible corpus.",
        supersedes_view_sha256=view["sha256"])
    return m,rehash(v)


def project(*args,**kwargs):
    """Generic fixed shared adapter, preserving V1 result math/method semantics."""
    return revise(*V1.project(*args,**kwargs))
