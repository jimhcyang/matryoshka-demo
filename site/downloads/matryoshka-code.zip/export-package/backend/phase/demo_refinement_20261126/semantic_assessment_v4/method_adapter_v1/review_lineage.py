"""Replay explicit old-first-pass/new-review lineages without changing V3/V4."""
from dataclasses import dataclass
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path[:0] = [str(ROOT),str(HERE.parent),str(HERE.parent.parent/"semantic_assessment_v3/coverage_review_v1")]
import producer_v4 as V4
from adapter import REVIEW_VERSION,validate_compact_review
from runtime import provider_chain,ref,verified_path

V3 = V4.V3
_TOKEN = object()


@dataclass(frozen=True,init=False)
class V4Approval:
    _snapshot: str
    def __init__(self,data,token=None):
        V4.require(token is _TOKEN,"Source-replayed new V4 approval required")
        object.__setattr__(self,"_snapshot",json.dumps(data,sort_keys=True))
    def export(self):
        return json.loads(self._snapshot)


def approve_v4(observation,response,receipt,*,root,allow_test_fixtures=False):
    review = V4.validate_review(observation,response,receipt,root=root,allow_test_fixtures=allow_test_fixtures)
    return V4Approval(dict(observation=observation.export(),review=review),_TOKEN)


def replay_rereview(root,original_folder,rereview_folder,preflight):
    """Return V3 sealed capsules only after complete mixed provider/source replay."""
    root,original_folder,rereview_folder = Path(root),Path(original_folder),Path(rereview_folder)
    refs,chains,reviewed,selected = [],[],[],[]
    def read(path):
        reference = ref(root,path)
        refs.append(reference)
        return V3.checked(root,reference)
    summary = read(rereview_folder/"RESULTS.json")
    V4.require(not summary["errors"],"Rereview errors cannot be silently omitted")
    expected = V3.checked(root,summary["result_ref"])
    prior = read(original_folder/"preflight.json")
    V4.require(prior==preflight.export(),"Rereview differs from exact native/index source preflight")
    auth = read(rereview_folder/"AUTHORIZATION.json")
    V4.require(auth["native_ref"]==prior["inspection_authority"]["native_ref"] and auth["inspection_ref"]==prior["inspection_authority"]["inspection_ref"],"Rereview native/inspection authority differs")
    order = []
    for receipt in expected["model_provenance"]:
        if receipt["stage"]=="assessment":
            batch = verified_path(root,receipt["request_ref"]).parents[1]
            V4.require(batch.parent==original_folder and batch not in order,"Unknown/duplicate original first-pass batch")
            order.append(batch)
    V4.require(set(order)=={p for p in original_folder.glob("batch_*") if (p/"reviewed.json").exists()},"Mixed result omitted an original completed batch")
    for batch in order:
        prepared = read(batch/"prepared-request.json")
        V4.require(prepared["instructions"]==V3.PROMPT,"First-pass prompt changed")
        raw,receipt = read(batch/"assessment/response.json"),read(batch/"assessment/receipt.json")
        chains.append(provider_chain(root,V3,receipt))
        assessment = V3.validate_assessment_quarantine(preflight,prepared["input"],raw,receipt,root=root)
        V4.require(assessment.export()==read(batch/"validated.json"),"Original assessment does not replay")
        fresh = rereview_folder/batch.name
        current = fresh if (fresh/"reviewed.json").exists() else batch
        if current==fresh:
            selected.append(batch.name)
        if assessment.export()["rows"]:
            request = read(current/"review/request.json")
            response,rreceipt = read(current/"review/response.json"),read(current/"review/receipt.json")
            chains.append(provider_chain(root,V3,rreceipt))
            value = (validate_compact_review(assessment,response,rreceipt,root=root,producer=V3)
                if request["input"].get("version")==REVIEW_VERSION else V3.validate_review(assessment,response,rreceipt,root=root))
        else:
            value = V3.close_rejected_batch(assessment)
        V4.require(value.export()==read(current/"reviewed.json"),"Selected old/new review does not replay")
        reviewed.append(value)
    selection = read(rereview_folder/"SELECTION.json")
    V4.require(set(selection["selected_batches"])=={int(name.removeprefix("batch_")) for name in selected},"Fresh review selection differs")
    aggregate = V3.results_adapter(preflight,reviewed,allow_partial_pool=True)
    V4.require(aggregate==expected,"Mixed old/new review aggregate differs")
    for reference in refs:
        verified_path(root,reference)
    return reviewed,dict(version="replayed-V3-original-first-pass-explicit-rereview-lineage/1",provider_chains=chains,
        inputs=refs,recorded_aggregate_batch_order=[p.name for p in order],fresh_review_batches=selected,
        original_result_ref=summary["result_ref"],aggregate_replayed_exactly=True,
        processed_slots=aggregate["processed_slots"],original_pool_slots=aggregate["original_pool_slots"],
        old_responses_or_native_changed=False,new_API_calls=0,native_executions=0)
