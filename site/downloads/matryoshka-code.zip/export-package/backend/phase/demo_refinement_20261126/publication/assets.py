"""Small current-report guide and code-only archive; no source corpus copying."""
from copy import deepcopy
from io import BytesIO
import sys
from xml.sax.saxutils import escape

import build as b


def make_guide(bindings):
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
    report=b.checked(bindings["report_ref"])
    styles=getSampleStyleSheet()
    styles["BodyText"].fontName="Times-Roman"
    styles["BodyText"].fontSize=10
    styles["BodyText"].leading=13
    stream=BytesIO()
    story=[]
    text=[]
    def section(title,body):
        text.append(title+"\n"+body)
        story.extend((Paragraph(escape(title),styles["Heading2"]),Paragraph(escape(body).replace("\n","<br/>"),styles["BodyText"]),Spacer(1,10)))
    section("Matryoshka: A Source-Linked Field Guide",
        "These saved examples are curated historical demonstrations, not a blind benchmark or a claim that every case is solved. "
        "The workbench preserves the exact input, saved assessment, quotations and available source-ending graph walks.")
    section("Reading Evidence",
        "Mosaic assembles facts; Hypothesis retains attributed assessments and opposition; Redaction proposes visible source-grounded fills. "
        "A high-ranked contextual candidate is not an evidence-backed recommendation. Grammar, graph navigation and overlapping names do not establish a historical action. "
        "Scores are deterministic evidence-and-fit indices, not probabilities. Different saved executions retain their own scoring contracts.")
    section("Sources and Originals",
        "Evidence is dated on or before the input source day. CIB permits earlier or shared text, including eligible earlier-origin text. "
        "Iran and Vietnam require eligible confidential cables, handling guards and exclusion of the entire secret origin. "
        "The visiting-delegation study uses later-release CIB pages dated on or before its source day, including its own source document. "
        "Other original input displays and later PDFs are inspection material, not automatically eligible evidence. Source cards preserve raw wording, ownership, attribution and uncertainty.")
    section("From Facts to Sources",
        "Each input is separated into Facts with exact links to its original wording. Redaction also declares the grammatical role of the missing text. "
        "Fact searches nominate eligible documents and graph states. Graph connections expand discovery; hierarchy membership supplies navigation, not factual proof. "
        "Within an admitted document, each Fact can nominate its own best-matching page. Every inspected page is checked against every Fact, so one useful passage need not displace another. "
        "Displayed routes end at saved source quotations. Input origins, source quotations and extracted graph observations remain distinct and independently inspectable.")
    section("Decision Arithmetic",
        "For a source at retrieval rank r, the relevance weight is 0.5 + 0.5 / (1 + log2(r)); an unrecorded rank receives 0.5. "
        "A contribution is that weight multiplied by the recorded fit. Only the largest contribution per document and direction is retained. "
        "Each Fact displays separate support, opposition and context totals; its signed index is support minus opposition. "
        "A complete decision additionally requires the source to establish the requested actor, action, arguments, attribution, polarity and qualifications. "
        "A large lexical score cannot repair a missing condition. Absence of evidence is not opposition, and repeated pages from one document do not become multiple independent votes.")
    section("Redaction Ranking",
        "Candidates must pass their declared insertion checks and retain exact source wording or an explicitly recorded grammatical transformation. "
        "The main ranking combines evidence-tier points, source-function points and 35u/(1+u), where u = (support + fit + 0.5 context)/(1 + opposition). "
        "Fit includes source-local form checks, visible argument overlap and an equal balance of focal and best-background Fact overlap. "
        "Source-relative and adjunct suggestions use a separate contextual scale: 100 times (0.75 coverage + 0.25 Jaccard similarity), with document-frequency weighting where recorded. "
        "These contextual families do not certify the missing action or attribution. Charts preserve the executed scale and descending saved order, not a probability of correctness.")
    section("Reading a Source Account",
        "A report that someone had to make a written statement can establish that the statement was made when the passage narrates the completed episode. "
        "A recommendation that someone should make it cannot. Likewise, reporting a possible negotiation result is not evidence that the result occurred. "
        "The workbench retains these distinctions in both the verdict and the highlighted source text. CIB sources offer earlier and later original PDF pages; cable sources retain their original numbered sections.")
    section("Context Priority",
        "The visiting-delegation search retains the same insertion, source and evidence-class checks. Its context priority is "
        "(tier + 0.99 times (0.55p + 0.25l + 0.20n)) / 3. Here p is focal-Fact content coverage on a candidate's own cited source page, "
        "l is bounded local insertion fit, and n is the fraction of candidate content not repeated in the visible input. "
        "The largest own-page contribution is used; unrelated pages are not pooled. Evidence tiers stay separate from contextual fit. "
        "This is a search priority, not a probability or confirmation of a still-withheld identity.")
    section("Source Assessment Scores",
        "Source-model assessments check each requested fact against an exact quotation and its complete qualification context, followed by a separate review. "
        "The evidence-fit index is 0.75 times requested-facet coverage plus 0.25 times lexical fit. "
        "Facet weights are actor18, action20, arguments15, event identity15, time6, quantity8, polarity6, modality5, attribution3 and conditions4; "
        "only requested facets enter the denominator. Lexical fit equally combines containment and Jaccard similarity. "
        "Per-document maxima prevent repeated passages from accumulating additional weight. A complete Mosaic component needs a sufficient accepted source account; "
        "Hypothesis records directional source views with their speakers and conditions. These judgments do not certify implementation of a plan or independent historical truth.")
    section("Hypothesis Arguments",
        "For a hypothesis, first establish that a source addresses the same issue and owns the stated assessment. "
        "Then record whether its argument supports, opposes or only contextualizes the input, preserving any conditions. "
        "An opposing source can align with the issue while disagreeing with the input's polarity or modality. "
        "The directional evidence alignment includes matched facets and explicitly conflicting operator facets for accepted opposition; "
        "literal agreement coverage includes only matched facets. The source alignment index is0.75 times directional alignment plus0.25 times lexical fit. "
        "Source totals use one maximum per document and direction. They summarize the retrieved arguments, not a probability or a count of independent witnesses.")
    section("Source Age And Context",
        "A tested contextual possessor ranking compares human-category fit, focal overlap in the candidate's own quotation and source age. "
        "Its recency multiplier is 2 to the power of minus source age in days divided by90, measured from the input cutoff. "
        "Recency changes search priority, never source eligibility or factual support. The executed Burma example places Brigadier Aung Gyi third at0.2054; "
        "that is a contextual possibility, not evidence that he performed the concealed action.")
    section("Source-Realized Redaction Candidates",
        "A source-only proposal records its original phrase, exact quotation, full qualification paragraph and any grammatical transformation. "
        "Complete-insertion checks test the declared reading; a separate source review tests the contribution introduced by the fill. "
        "Raw source alignment is0.75 times requested-facet agreement plus0.25 times own-quotation lexical fit. "
        "Evidence classes are2 for separately reviewed direct source support,1 for inferential context and0 for unresolved or conflicting results. "
        "Final priority is(class +0.99 times raw source alignment)/3. The same value determines order and the four-decimal display. "
        "This is an ordering index, not a probability. Partial corroboration does not establish every condition in the input. "
        "Duplicate surfaces retain their variants without summing repeated quotations or treating different spellings as independent support.")
    cases=[]
    labels={"EVIDENCE_BACKED_RECONSTRUCTION":"Evidence-backed mosaic","PARTIAL_RECONSTRUCTION":"Partially reconstructable mosaic","ESTABLISHED":"Established"}
    for row in report["cases"]:
        case=row["case"]
        assessments=[]
        for arm,item in row["configurations"].items():
            native=b.checked(item["native_checkpoint"])
            require_case=(native["public_case"]==case and native["native_checksum"]==b.sha(b.encoded(native["result"])))
            b.require(require_case,"Guide input/native binding changed")
            assessments.append(dict(config=arm,native_checkpoint=item["native_checkpoint"],native_checksum=native["native_checksum"],
                status=native["result"].get("status"),readings=[dict(reading_id=x["reading"]["id"],
                    candidates=[dict(rank=c["rank"],fill=c["fill"],status=c["local_decision"]["status"]) for c in x["candidates"]])
                    for x in native["result"].get("readings",[])]))
        statuses="; ".join(labels.get(str(a["status"]),str(a["status"])) for a in assessments)
        source_assessment=None
        if row.get("reviewed_source_assessment"):
            source_refs=bindings.get('source_realized_artifacts',{}).get(case['case_id'],row['reviewed_source_assessment'])
            view=b.checked(source_refs["view_ref"])
            if view.get('method_id')=='source_realized_redaction_v1':
                source_assessment=dict(method_id=view['method_id'],
                    display_reading_id=view['selection']['display_reading_id'],
                    readings=[dict(reading_id=branch['reading']['id'], candidates=[dict(
                        rank=c['rank'], fill=c['fill'], priority=c['priority']['value'],
                        evidence_state=c['priority']['evidence_state']) for c in branch['candidates']])
                        for branch in view['readings']],
                    source_documents=sorted({p['document_id'] for p in view['source_pages']}))
                chosen=next((branch for branch in view['readings']
                    if branch['reading']['id']==view['selection']['display_reading_id']),None)
                if chosen and chosen['candidates']:
                    top=chosen['candidates'][0]
                    statuses='Source-realized candidate: '+top['fill']+' / '+format(top['priority']['value'],'.4f')
                else:
                    statuses='No admitted source-realized candidate'
            else:
                source_assessment=dict(method_id=view["method_id"],
                    atoms=[dict(id=a["id"],text=a["text"],status=a["status"],
                        complete=a.get("complete_by_model_source_review") if case['task']=='mosaic' else None,
                        source_counts=a.get('source_counts')) for a in view["atoms"]],
                    source_documents=sorted({e["citation"]["document_id"] for a in view["atoms"] for e in a["evidence"]}))
                statuses=(str(sum(a["complete"] is True for a in source_assessment["atoms"]))+"/"+str(len(view["atoms"]))+
                    " source-backed Mosaic") if case["task"]=="mosaic" else "Reviewed source views"
        section(case["corpus"].upper()+" / "+case["task"].title(),
            row.get("presentation_title",case["query"])+"\n"+"Input: "+case["query"]+"\n"
            +"Assessment: "+statuses+". Inspect the selected facts, reading and source cards.\n"
            +"Input origin: "+case["document_id"]+" / "+case["date"]+". Original and paired-PDF controls remain in the workbench.")
        cases.append(dict(case_id=case["case_id"],task=case["task"],corpus=case["corpus"],query=case["query"],
            query_utf8_sha256=b.sha(case["query"].encode()),document_id=case["document_id"],date=case["date"],
            origin_refs=deepcopy(row["origin_refs"]),assessments=assessments,source_assessment=source_assessment))
    SimpleDocTemplate(stream,pagesize=(8.5*inch,11*inch),leftMargin=48,rightMargin=48,topMargin=40,bottomMargin=40,
        title="Matryoshka: A Source-Linked Field Guide",author="Matryoshka").build(story)
    pdf=stream.getvalue()
    plain=("\n\n".join(text)+"\n").encode()
    folder=bindings["records"]/"guide"
    b.write(folder/"field-guide.pdf",pdf)
    b.write(folder/"field-guide.txt",plain)
    guide=dict(version="evidence-field-guide/1",mode="saved_report_snapshot",report_byte_sha256=bindings["report_ref"]["sha256"],
        files={"field-guide.pdf":b.sha(pdf),"field-guide.txt":b.sha(plain)},cases=cases)
    b.write(folder/"guide-public.json",guide)
    assets=[dict(target=target,source_ref=b.ref(folder/name),public_sha256=b.sha((folder/name).read_bytes()))
        for name,target in (("field-guide.pdf","docs/matryoshka-guide.pdf"),("field-guide.txt","docs/matryoshka-guide.txt"),("guide-public.json","docs/guide-public.json"))]
    binding=dict(version="source-bound-field-guide/1",source_report_ref=bindings["report_ref"],assets=assets,
        guide_public_ref=b.ref(folder/"guide-public.json"),source_mode="saved_report_snapshot",publication_qualification_inferred=False)
    b.write(folder/"binding.json",binding)
    return binding


def make_backend_bundle(bindings):
    import sys
    sys.path.insert(0,str(b.ROOT/"phase/kg_patch_20261122/release"))
    snapshot=b.module("breakthrough_code_snapshot",b.ROOT/"phase/kg_patch_20261122/release/code_snapshot.py")
    site=bindings["target"]/"site"
    manifest_path=site/"downloads/matryoshka-code-manifest.json"
    prior=b.read(manifest_path)
    files=snapshot.unpack((site/"downloads/matryoshka-code.zip").read_bytes(),prior)
    b.require(snapshot.tree_sha(files,prior.get("excluded_corpus_derived_inputs",[]))==prior["backend_tree_sha256"],"Prior code archive changed")
    report=b.checked(bindings["report_ref"])
    witness=b.HERE/"backend_snapshot_ref.json"
    if bindings["selection"].get("backend_snapshot_native_ref"):
        native_ref=bindings["selection"]["backend_snapshot_native_ref"]
    elif witness.exists():
        native_ref=b.read(witness)
    else:
        selected=next(r for r in report["cases"] if r["case"]["case_id"] in bindings["changed_case_ids"])
        native_ref=selected["configurations"]["llm_readings"]["native_checkpoint"]
    native=b.checked(native_ref)
    b.require(native["native_checksum"]==b.sha(b.encoded(native["result"])),"Code snapshot execution witness changed")
    pins=native["code_pins"]
    runtime_pins=dict(pins)
    postrun_overlays=[]
    for name,expected in pins.items():
        path=b.ROOT/name
        b.require(path.resolve()==path and path.is_relative_to(b.ROOT) and path.is_file(),"Unsafe frozen code path")
        raw=path.read_bytes()
        if b.sha(raw)!=expected:
            # This closed postrun projection cannot alter retrieval or native
            # decisions. Preserve the executed preimage in the snapshot history.
            allowed=(name=="matryoshka_narrative/postrun_digest.py"
                and expected=="ffc6fb438ce680f8244953d54397cd38c199463d51dca480b04846fb32e325fb"
                and b.sha(raw)=="7254ee76b4d1bb3f6a52e9cf82b87e24098ad8a7fed8d2d08ca4df698a961b08")
            old=files.get("backend/"+name)
            archived=files.get("history/pre-kg/"+expected+"/backend/"+name)
            has_preimage=(isinstance(old,bytes) and b.sha(old)==expected) or (
                isinstance(old,bytes) and old==raw and isinstance(archived,bytes) and b.sha(archived)==expected)
            b.require(allowed and has_preimage,
                "Production changed after selected native freeze: "+name)
            postrun_overlays.append(dict(path=name,executed_sha256=expected,
                runtime_sha256=b.sha(raw),purpose="POSTRUN_SCORE_READING_ID_COMPATIBILITY_ONLY",
                native_rerun=False,native_result_changed=False))
            runtime_pins[name]=b.sha(raw)
        snapshot.replace(files,"backend/"+name,raw)
    live = b.ROOT / "phase/motion_login_20261122/live"
    for path in live.iterdir():
        if path.is_file() and not path.is_symlink() and (
                path.suffix in {".py", ".md"} or path.name == "scope-defaults.json"):
            snapshot.replace(files, "backend/" + str(path.relative_to(b.ROOT)), path.read_bytes())
    launcher = b.ROOT / "scripts/start_live_local.py"
    snapshot.replace(files, "backend/scripts/start_live_local.py", launcher.read_bytes())
    for path in site.iterdir():
        if path.is_file() and path.suffix in {".html",".css",".js"}:
            snapshot.replace(files,"interactive/site/"+path.name,path.read_bytes())
    for path in (site/"vendor/pdfjs").glob("*"):
        b.require(path.is_file() and not path.is_symlink() and path.name in {"pdf.mjs","pdf.worker.mjs","LICENSE"},
            "Only the explicitly vendored PDF renderer may enter the code bundle")
        snapshot.replace(files,"interactive/site/vendor/pdfjs/"+path.name,path.read_bytes())
    for name in ("site/runtime/public-runtime.js", "runtime/public-runtime.js",
            "release-tools/source_pdfs.py", "release-tools/same_repo.py",
            "release-tools/serve_static.py", "release-tools/ci/validate_manifest.py",
            "tools/validate_publication.py"):
        path=bindings["target"]/name
        if path.is_file():
            b.require(path.resolve()==path and not path.is_symlink(),"Unsafe runtime transport snapshot")
            snapshot.replace(files,"interactive/"+name,path.read_bytes())
    method_code=[]
    for reference in bindings['selection'].get('method_code_refs',[]):
        path=b.ROOT/reference['path']
        b.require(path.resolve()==path and path.is_relative_to(b.ROOT/'phase/demo_refinement_20261126')
            and path.suffix=='.py' and b.ref(path)==reference,
            'Explicit unchanged source-assessment implementation reference required')
        snapshot.replace(files,'backend/'+reference['path'],path.read_bytes())
        method_code.append(reference)
    raw,rows=snapshot.make_zip(files)
    tree=snapshot.tree_sha(files,prior.get("excluded_corpus_derived_inputs",[]))
    manifest=dict(prior,files=rows,backend_tree_sha256=tree,all_saved_natives_use_current_code=False,
        mixed_saved_native_versions=True,credentials_included=False,private_live_state_included=False,
        current_code_pins=runtime_pins,current_code_native_ref=native_ref,
        execution_witness_code_pins=pins,postrun_runtime_overlays=postrun_overlays,
        runtime_overlays_executed_as_native=False,
        separate_source_assessment_code_refs=method_code,
        separate_source_assessment_is_not_the_native_execution_witness=bool(method_code))
    b.write(site/"downloads/matryoshka-code.zip",raw)
    b.write(manifest_path,manifest)
    return dict(path="downloads/matryoshka-code.zip",sha256=b.sha(raw),bytes=len(raw),code_only=True,
        manifest_path="downloads/matryoshka-code-manifest.json",manifest_sha256=b.sha(manifest_path.read_bytes()),
        source_backend_tree_sha256=tree,all_saved_natives_use_current_code=False,mixed_saved_native_versions=True)
