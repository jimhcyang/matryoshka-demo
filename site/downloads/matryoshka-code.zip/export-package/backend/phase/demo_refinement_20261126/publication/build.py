"""Staging-only publication assembly over the existing saved-narrative renderer."""
import argparse
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from urllib.parse import parse_qs,urlsplit,urlencode

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REPO=ROOT.parent/"matryoshka_demo_site"
RESERVE=8*1024**3
PUBLIC={"case_id","task","corpus","query","date","document_id","focal_marker"}
R_METHOD='source_realized_redaction_v1'
R_PUBLISHER_READY=None
R_PUBLISHER_FREEZE=dict(path='phase/demo_refinement_20261126/publication_r_v1/FREEZE.json',
    sha256='353dc813458feefc5475b3136648ccc0dfa3f6dbce0195c29563ab0c2835d505')


def require(value,message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode()


def read(path):
    raw=Path(path).read_bytes()
    return json.loads(gzip.decompress(raw) if str(path).endswith(".gz") else raw)


def ref(path):
    path=Path(path).resolve()
    require(path.is_relative_to(ROOT),"Reference outside src-demo-day")
    return dict(path=str(path.relative_to(ROOT)),sha256=sha(path.read_bytes()))


def checked(reference):
    require(set(reference)=={"path","sha256"},"Explicit path/hash reference required")
    path=ROOT/reference["path"]
    require(not Path(reference["path"]).is_absolute() and path.resolve()==path and path.is_relative_to(ROOT)
        and ref(path)==reference,"Unsafe or changed source reference")
    return read(path)


def write(path,raw):
    path=Path(path).absolute()
    require(path.resolve()==path and path.is_relative_to(HERE) and "datasets" not in path.relative_to(HERE).parts,
        "Writes are confined to owned publication files, never datasets")
    raw=raw if isinstance(raw,bytes) else encoded(raw)
    require(shutil.disk_usage(HERE).free-len(raw)>=RESERVE,"8GiB free-disk reserve")
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_name(path.name+".new")
    with temporary.open("xb") as stream:
        stream.write(raw)
    os.replace(temporary,path)


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def stage_path(tag):
    require(bool(re.fullmatch(r"[A-Za-z0-9_-]+",tag)),"Unsafe stage tag")
    return HERE/"stage"/tag


def init(tag="candidate_v1"):
    target=stage_path(tag)
    if (target/"BASELINE.json").exists():
        return read(target/"BASELINE.json")
    require(not target.exists(),"Unsealed stage already exists; choose a new tag")
    size=sum(p.stat().st_size for p in (REPO/"site").rglob("*") if p.is_file())
    require(shutil.disk_usage(HERE).free-size>=RESERVE,"Insufficient space to copy site and retain8GiB")
    target.mkdir(parents=True)
    shutil.copytree(REPO/"site",target/"site")
    linked=0
    for path in (REPO/"datasets").rglob("*"):
        require(not path.is_symlink(),"Dataset links may not follow symlinks")
        destination=target/path.relative_to(REPO)
        if path.is_dir():
            destination.mkdir(parents=True,exist_ok=True)
        elif path.is_file():
            destination.parent.mkdir(parents=True,exist_ok=True)
            if re.fullmatch(r"[a-f0-9]{64}\.json\.gz",path.name):
                os.link(path,destination)
                linked+=path.stat().st_size
            else:
                shutil.copyfile(path,destination)
    for directory in ("release-tools","runtime","docs"):
        shutil.copytree(REPO/directory,target/directory,ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
    for name in ("README.md","AGENTS.md","requirements-dev.txt"):
        shutil.copyfile(REPO/name,target/name)
    baseline=dict(version="breakthrough-publication-stage-baseline/1",tag=tag,
        live_manifest_sha256=sha((REPO/"site/release-manifest.json").read_bytes()),
        live_index_sha256=sha((REPO/"site/data/api-index.json").read_bytes()),
        live_lineage_sha256=sha((REPO/"site/export-lineage.json").read_bytes()),
        source_lineage=read(REPO/"site/export-lineage.json"),site_copy_bytes=size,
        immutable_dataset_hardlink_bytes=linked,dataset_writes_permitted=False,
        api_calls=0,native_runs=0,live_repository_modified=False)
    write(target/"BASELINE.json",baseline)
    return baseline


def casebook_entry(row,prior=None,extra=None):
    value=deepcopy(prior if prior and prior["case_id"]==row["case"]["case_id"] else {})
    value.update(case_id=row["case"]["case_id"],corpus=row["case"]["corpus"],task=row["case"]["task"],
        case=deepcopy(row["case"]),resource_binding=deepcopy(row["resource_binding"]),
        configurations=deepcopy(row["configurations"]),decision_summary_by_arm=deepcopy(row["decision_summary_by_arm"]),
        narrative_id=row.get("narrative_id"),title=row["presentation_title"])
    if prior and prior["case_id"]!=row["case"]["case_id"]:
        value["source_label"]=row["presentation_title"]
    if extra:
        require(set(extra)<={"source_label"},"Only outward source label may supplement casebook identity")
        value.update(extra)
    return value


def append_new_specials(book,changed,extra_entries):
    """Refreshed saved extras are already in the rewritten collection."""
    seen={entry["case_id"] for entry in book["special_redactions"]}
    require(len(seen)==len(book["special_redactions"]),"Repeated saved special case")
    for row in changed:
        cid=row["case"]["case_id"]
        if row.get("selected_additional") and cid not in seen:
            book["special_redactions"].append(casebook_entry(row,extra=extra_entries.get(cid)))
            seen.add(cid)


def merge_export_entries(original,exported):
    entries=dict(original)
    for key,entry in exported.items():
        previous=original.get(key,{})
        if key.startswith("/api/cib-pdf?") and "external_url" in previous:
            require(all(previous.get(field)==entry.get(field) for field in
                ("sha256","wire_sha256","mime","encoding")),
                "Export changed an immutable source PDF")
            # Keep the already catalog-validated, immutable delivery binding.
            continue
        entries[key]=entry
    return entries


def story_contract(cases,previous=None):
    """Bind reveal ordering to this exact inventory, never an inherited ID list."""
    require(isinstance(cases,list) and bool(cases),"Story access needs published cases")
    if previous is not None:
        require(isinstance(previous,dict) and previous.get("version")=="narrative-story-attempts/1"
            and previous.get("require_story_attempts_before_privileged_sources") is True,
            "Unsupported inherited story access policy")
    groups={}
    seen=set()
    for row in cases:
        cid=row.get("case",{}).get("case_id")
        story=row.get("narrative_id")
        require(isinstance(cid,str) and bool(cid.strip()) and cid not in seen,
            "Story access needs unique nonempty case IDs")
        require(isinstance(story,str) and bool(story.strip()),"Story access needs a narrative ID")
        seen.add(cid)
        groups.setdefault(story,[]).append(cid)
    contract=deepcopy(previous or {})
    contract.update(version="narrative-story-attempts/1",
        require_story_attempts_before_privileged_sources=True,story_case_ids=groups)
    return contract


def primary_availability(primary):
    """Derive completed slots from their published cases, not retired requests."""
    require(isinstance(primary,list) and len(primary)==9,"Nine primary cases required")
    ids=set()
    cells=set()
    slots=[]
    for entry in primary:
        case=entry.get("case",{})
        require(set(case)==PUBLIC and entry.get("case_id")==case["case_id"],
            "A completed primary needs its exact public case")
        cell=(case["corpus"],"mosaic" if case["task"]=="reconstruction" else case["task"])
        require(case["case_id"] not in ids and cell not in cells,"Repeated primary case or cell")
        ids.add(case["case_id"])
        cells.add(cell)
        slots.append(dict(public_case=deepcopy(case),execution_state="COMPLETED"))
    require(cells=={(c,t) for c in ("cib","iran","vietnam") for t in ("mosaic","hypothesis","redaction")},
        "Primary availability must cover all corpus/task cells")
    return dict(requested_primary_count=9,completed_primary_count=9,pending_primary=[],requested_primary_slots=slots)


def checked_retirements(prior,book,selection):
    """Retire display entries only, retaining their exact saved-native lineage."""
    proposals=selection.get("retirements",[])
    require(isinstance(proposals,list),"Explicit retirement list required")
    old={row["case"]["case_id"]:row for row in prior["cases"]}
    primary={entry["case_id"] for entry in book["primary"]}
    replacements={entry["replaces"] for entry in selection["replacements"]}
    seen=set()
    result=[]
    for proposal in proposals:
        require(isinstance(proposal,dict) and set(proposal)=={"case_id","reason","native_ref"},
            "Retirement needs exactly case_id, reason and diagnostic native_ref")
        cid=proposal["case_id"]
        require(isinstance(cid,str) and cid in old and cid not in seen,"Unknown or repeated retirement")
        require(isinstance(proposal["reason"],str) and bool(proposal["reason"].strip()),"Retirement reason required")
        require(cid not in primary or cid in replacements,"Primary retirement requires an explicit same-cell replacement")
        require(proposal["native_ref"] in [item["native_checkpoint"] for item in old[cid]["configurations"].values()],
            "Retirement diagnostic must bind the retired case's original native")
        checked(proposal["native_ref"])
        seen.add(cid)
        result.append(deepcopy(proposal))
    return result


def without_case_routes(entries,retired):
    retired=set(retired)
    return {key:value for key,value in entries.items() if not retired.intersection(
        parse_qs(urlsplit(key).query).get("case_id",[])+parse_qs(urlsplit(key).query).get("case",[]))}


def source_realized_publisher():
    require(R_PUBLISHER_READY==R_PUBLISHER_FREEZE,'The exact stopped R publication receiver is required')
    directory=HERE.parent/'publication_r_v1'
    frozen=checked(R_PUBLISHER_READY)
    require(frozen.get('version')=='source-realized-R-publication-helper-freeze/1'
        and frozen.get('status')=='FROZEN_OWNER_STOPPED_REVIEW_REQUIRED'
        and frozen.get('receiver_version')=='source-realized-publication-receiver/2'
        and frozen.get('envelope_version')=='source-realized-redaction-envelope/1'
        and frozen.get('projection_version')=='source-realized-location-redaction/1',
        'The R publication freeze contract differs')
    critical={str((directory/name).relative_to(ROOT)) for name in ('publisher.py','replay.py','metadata_protocol.py')}
    require(critical<={r['path'] for r in frozen['files']},'Critical R receiver code is not frozen')
    for reference in frozen['files']+frozen['dependency_refs']:
        path=ROOT/reference['path']
        require(path.resolve()==path and path.is_relative_to(ROOT)
            and ref(path)=={k:reference[k] for k in ('path','sha256')},
            'The selected R publication receiver changed')
        if 'bytes' in reference:
            require(type(reference['bytes']) is int and reference['bytes']==path.stat().st_size,
                'The R receiver dependency size differs')
    publisher=module('source_realized_publication_receiver',directory/'publisher.py')
    metadata=module('source_realized_publication_metadata',directory/'metadata_protocol.py')
    return publisher,metadata


def verify_source_realized_response(publisher,prepared,source_id,response):
    """Typed transport closure in addition to the frozen receiver's source checks."""
    require(publisher.verify_source_response(prepared,source_id,response) is True,
        'The R source response failed canonical correspondence')
    requests={r['canonical_page_id']:r for r in prepared['source_requests']}
    expected=requests[source_id]['expected_page']
    wanted=dict(id=source_id,canonical_page_id=source_id,text=expected['windows'][0]['text'],
        source_sha256=expected['page_sha256'],permitted=True,
        **{k:expected[k] for k in ('document_id','corpus','date','classification','visibility','handling')},
        **expected['original_page_metadata'])
    require(encoded({key:response.get(key) for key in wanted})==encoded(wanted),
        'The R source metadata differs in type or value')
    pins=prepared['metadata']['resource_binding']
    require(encoded({key:response.get('resource_binding',{}).get(key)
        for key in ('resource_id','registry_sha256','index_sha256')})==encoded({key:pins[key]
        for key in ('resource_id','registry_sha256','index_sha256')}),
        'The R source resource pins differ in type or value')
    case,policy=prepared['public_view']['case'],prepared['public_view']['source_view_policy']
    origin=case['document_id'] if case['corpus']!='cib' or policy['id']=='strict_prior' else None
    require(encoded([response.get('source_view_policy'),response.get('cutoff'),response.get('whole_origin_excluded')])
        ==encoded([policy,case['date'],origin]),'The R source scope differs in type or value')
    return True


def source_realized_transport(publisher,prepared,source_id,response):
    """Expose an omitted empty cable field, never infer a handling permission."""
    requests={r['canonical_page_id']:r for r in prepared['source_requests']}
    require(source_id in requests,'The R source is not a declared canonical page')
    result=deepcopy(response)
    if 'handling' not in result:
        require(requests[source_id]['expected_page']['handling']==[],
            'Only a canonically empty handling list may be made explicit')
        result['handling']=[]
    verify_source_realized_response(publisher,prepared,source_id,result)
    return result


def attach(entry,old=None):
    sys.path.insert(0,str(ROOT))
    from matryoshka_demo.io import digest
    from matryoshka_narrative import presentation
    from matryoshka_narrative.sidebar import summarize
    case=entry["case"]
    require(set(case)==PUBLIC,"Exact seven-field public case required")
    outputs=entry["outputs"]
    native=checked(outputs["native_checkpoint"])
    condition=checked(outputs["condition_ref"])
    saved=condition["configurations"]["llm_readings"]
    source_policy=native["configuration"]["source_view_policy"]
    registered_study=False
    later_study=source_policy.get("id")=="later_release_inclusive"
    if later_study:
        from matryoshka_demo.source_view_policy import descriptor,LATER_RELEASE_INCLUSIVE
        require(source_policy==descriptor(LATER_RELEASE_INCLUSIVE)
            and (case["corpus"],case["task"])==("cib","redaction")
            and entry.get("study_slot") in {"first","last"}
            and entry.get("reference_answer_kind")=="unknown_still_withheld"
            and entry.get("reference_answer_available") is False
            and entry.get("reference_answer") is None and entry.get("gold") is None
            and "revealed" not in entry["origin_refs"],
            "The later-edition study must retain its unknown answer and explicit source scope")
        from matryoshka_current import resources
        refs=native["execution_context"]
        context=resources.open_context(ROOT,refs["registry_ref"],refs["index_ref"],"cib")
        try:
            from matryoshka_demo.source_view_policy import apply_source_view
            from matryoshka_next.facts import SourcePolicy
            scoped=apply_source_view(context,source_policy)
            policy=SourcePolicy(scoped.corpus,native["case"],scoped.source_index)
            require(bool(native["result"].get("inspected_page_ids")),"The study has no inspected source pages")
            for pid in native["result"]["inspected_page_ids"]:
                page=policy.bound_pages[pid]
                require(policy.allowed(scoped.corpus.page_index[pid])
                    and page.get("view")==page.get("visibility")=="later"
                    and page.get("native_page",{}).get("view")=="later",
                    "The study inspected a page outside its bound later-only scope")
        finally:
            context.close()
        registered_study=True
    if source_policy.get("id")=="supplied_documents_inclusive":
        require(old is not None and old.get("study_slot") in {"first","last"}
            and old["case"]==case and (case["corpus"],case["task"])==("cib","redaction")
            and old.get("reference_answer_kind")=="unknown_still_withheld"
            and old.get("reference_answer_available") is not True
            and old.get("reference_answer") is None and old.get("gold") is None
            and entry.get("reference_answer_kind")=="unknown_still_withheld"
            and entry.get("reference_answer_available") is not True
            and entry.get("reference_answer") is None and entry.get("gold") is None
            and entry.get("query_kind",old.get("query_kind"))==old.get("query_kind"),
            "Only an existing unknown-truth registered study may retain its special view")
        previous=checked(old["configurations"]["llm_readings"]["native_checkpoint"])
        require(source_policy==previous["configuration"]["source_view_policy"]
            and native["binding"]==previous["binding"]
            and all(native["execution_context"][key]==previous["execution_context"][key]
                for key in ("registry_ref","index_ref"))
            and entry["origin_refs"]==old["origin_refs"],
            "The registered study's source view, resources or origin changed")
        registered_study=True
    binding=presentation._native_public_case_binding(case,native,outputs["native_checkpoint"])
    require(binding["state"]=="PASS" and condition["case"]==case and saved["case"]==case
        and saved["native_checkpoint"]==outputs["native_checkpoint"] and saved["native_record_sha256"]==digest(native)
        and saved["native_checksum"]==native["native_checksum"]==digest(native["result"]),"Native/condition/public input mismatch")
    require(native["answers_read"] is False and native["grades_read"] is False
        and (source_policy["id"]=="source_day_inclusive" or registered_study),"QA or eligibility boundary changed")
    require(outputs.get("config","llm_readings")=="llm_readings" and outputs.get("trace_refs"),
        "An actual native-bound saved source/graph trace is required")
    require("masked" in entry["origin_refs"] and (case["task"]!="redaction" or registered_study or "revealed" in entry["origin_refs"]),
        "Actual masked/revealed origin records required")
    for origin in entry["origin_refs"].values():
        checked(origin)
    for trace in outputs["trace_refs"].values():
        checked(trace)
    row={k:deepcopy(v) for k,v in (old or {}).items() if k in {"narrative_id","collection","selected_demo","selected_bench","selected_additional"}}
    if registered_study and not later_study:
        row.update({key:deepcopy(old[key]) for key in ("study_slot","study_companion_case_id","query_kind",
            "reference_answer_available","reference_answer","gold") if key in old})
    if later_study:
        row.update({key:deepcopy(entry[key]) for key in ("study_slot","reference_answer_available","reference_answer","gold")})
        require(old is not None and old.get('study_slot')==entry['study_slot']
            and old['case']['document_id']==case['document_id'] and old['case']['date']==case['date'],
            'A replacement study must retain its exact physical source episode')
        row['study_companion_case_id']=old['study_companion_case_id']
        row.pop('reference_answer',None)
        row.pop('gold',None)
    for key in ("case","origin_refs","presentation_title","query_kind","reference_answer_kind","source_target_id","family_id",
        "source_origin","source_query_spans","presentation_caveats","narrative_id","presentation_selection"):
        if key in entry:
            row[key]=deepcopy(entry[key])
    row.setdefault("presentation_title",case["query"])
    row.setdefault("query_kind","source_derived_proposition" if case["task"]!="redaction" else "source_window")
    row.setdefault("presentation_caveats",[])
    item={k:deepcopy(v) for k,v in outputs.items() if k in {"condition_ref","trace_refs","native_checkpoint","run_id"}}
    item.update(config="llm_readings",flow_refs={},compact_flow_refs={},source_view_policy=deepcopy(native["configuration"]["source_view_policy"]))
    row.update(configurations={"llm_readings":item},resource_binding=deepcopy(condition["resource_binding"]),
        native_public_case_binding=binding,current_resource_execution=True,
        reporting_profile=dict(version="breakthrough-actual-native-display/1",native_version=native["version"],
            native_configuration=deepcopy(native["configuration"]),native_code_epoch_sha256=digest(native["code_pins"]),
            original_native_unchanged=True,graph_inspection_is_postrun=True),
        decision_summary_by_arm={"llm_readings":summarize(ROOT,[(case,saved)])[0]})
    if entry.get("reviewed_source_artifacts"):
        artifacts=entry["reviewed_source_artifacts"]
        require(set(artifacts)=={"view_ref","method_ref","producer_ready_ref"},"Exact reviewed source artifacts required")
        view=checked(artifacts["view_ref"])
        method=checked(artifacts["method_ref"])
        producer_ready=checked(artifacts["producer_ready_ref"])
        if view.get('method_id')==R_METHOD:
            require(case['task']=='redaction' and method.get('method_id')==R_METHOD,
                'The source-realized method is redaction-only')
            publisher,metadata=source_realized_publisher()
            prepared=publisher.prepare(case=case,native_ref=outputs['native_checkpoint'],
                resource_binding=row['resource_binding'],artifacts=artifacts)
            row['reviewed_source_assessment']=metadata.private_metadata(prepared,artifacts)
            return row
        ready_versions={
            "actual-cib-reviewed-model-materialization-freeze/1": {
                ("mosaic", "PASS_SOURCE_MODEL_M_2_OF_2", "reviewed_source_model_accounts_v3_coverage1")},
            "actual-vietnam-reviewed-source-materialization-freeze/1": {
                ("mosaic", "PASS_REVIEWED_SOURCE_MODEL_2_OF_2", "reviewed_source_model_accounts_v3_coverage1")},
            "actual-reviewed-source-method-output-freeze/1": {
                ("mosaic", "PASS_M_2_OF_2_SOURCE_MODEL", "reviewed_source_model_accounts_v3_v4_explicit_composite1"),
                ("hypothesis", "PASS_H_QUALIFIED_SOURCE_VIEWS", "reviewed_source_model_accounts_v3_coverage1")},
            "qualified-source-view-ready/2": {
                ("mosaic", "M_BOUNDED_GO_UNCHANGED_SCOPE_REPAIRED", "reviewed_source_model_accounts_v3_v4_explicit_composite1"),
                ("hypothesis", "H_TWO_ELIGIBLE_VIEWS_DATE_CONFLICT_HELD", "reviewed_source_model_accounts_v3_temporal_qualified1")},
        }
        typed_h=producer_ready.get('version') in {'H-V5-source-view-case-ready/1','H-V5-source-view-case-ready/2'}
        if typed_h:
            directory=HERE.parent/'semantic_assessment_v5/view_method_v1'
            receiver_v2=producer_ready['version']=='H-V5-source-view-case-ready/2'
            guard_name='reader_guard_v2.py' if receiver_v2 else 'reader_guard.py'
            require(case['task']=='hypothesis'
                and producer_ready.get('state')==('RECEIVER_V2_PASS_REVIEW_REQUIRED' if receiver_v2 else 'FROZEN_FOR_INDEPENDENT_REVIEW')
                and producer_ready.get('VIEW')==artifacts['view_ref']
                and producer_ready.get('METHOD')==artifacts['method_ref']
                and producer_ready.get('VIEW_version')==view['version']=='reviewed-H-source-workbench-view/5'
                and producer_ready.get('METHOD_version')==method['version']=='reviewed-H-source-view-method/1'
                and producer_ready.get('method_id')==view.get('method_id')=='reviewed_h_source_views_issue_direction_document_voice5'
                and producer_ready.get('adapter_ref')==ref(directory/'source_views.py')
                and (producer_ready.get('source_provider_replay_inherited_unchanged') if receiver_v2
                    else producer_ready.get('actual_provider_source_replayed')) is True,
                'Typed H view is not an exact replayed case output')
            if receiver_v2:
                require(producer_ready.get('guard_ref')==ref(directory/guard_name)
                    and producer_ready.get('reader_contract_ref')==ref(directory/'READER_CONTRACT_V2.json'),
                    'Typed H V2 receiver code/contract differs')
            frozen=read(directory/('READY_V2.json' if receiver_v2 else 'READY.json'))
            references=frozen['files']+frozen.get('dependency_refs',[])
            if receiver_v2:
                inherited=checked(frozen['inherited_adapter_ready_ref'])
                references+=inherited['files']+inherited['dependency_refs']
            for reference in references:
                require(ref(ROOT/reference['path'])=={k:reference[k] for k in ('path','sha256')},
                    'Typed H reader dependency changed')
            sys.path.insert(0,str(directory))
            guard=module('publication_typed_h_reader_guard',directory/guard_name)
            guard.validate_pair(method,view)
            import importlib
            replay=importlib.import_module('source_views')
            require(Path(replay.__file__).resolve()==directory/'source_views.py',
                'Typed H replay module belongs to another source method')
            replayed_method,replayed_view,_,_=replay.replay_case(ROOT,checked(producer_ready['inputs_ref']))
            require(encoded(replayed_method)==encoded(method) and encoded(replayed_view)==encoded(view),
                'Typed H output differs from actual source/provider replay')
        else:
            ready_key=(case["task"], producer_ready.get("status"), view.get("method_id"))
            require(ready_key in ready_versions.get(producer_ready.get("version"), set())
                and producer_ready.get("state")=="FROZEN_STOPPED"
                and producer_ready.get("VIEW_ref")==artifacts["view_ref"]
                and producer_ready.get("METHOD_ref")==artifacts["method_ref"]
                and producer_ready.get("method_id",view["method_id"])==view["method_id"],
                "Reviewed source artifacts are not bound to the producer freeze")
        require(case["task"] in {"mosaic","hypothesis"}
            and view["version"]==('reviewed-H-source-workbench-view/5' if typed_h else 'reviewed-source-workbench-view/1')
            and view["method_id"]==method["method_id"]
            and view["case"]==case and method["public_case"]==case
            and view["query_sha256"]==digest(case["query"])
            and view["original_native_ref"]==outputs["native_checkpoint"]
            and view["execution_context"]==native["execution_context"]
            and view["source_view_policy"]==source_policy
            and view["method_packet_sha256"]==method["sha256"]==digest({k:v for k,v in method.items() if k!="sha256"})
            and view["sha256"]==digest({k:v for k,v in view.items() if k!="sha256"})
            and view["incumbent_native_method"] is False and view["native_status_or_gates_rewritten"] is False,
            "Reviewed method input/native/source bindings differ")
        projected=public_reviewed_view(view)
        params=dict(case_id=case["case_id"],config="llm_readings",
            **{k:row["resource_binding"][k] for k in ("resource_id","registry_sha256","index_sha256")})
        row["reviewed_source_assessment"]=dict(method_id=view["method_id"],
            endpoint="/api/current/reviewed-source-accounts?"+urlencode(sorted(params.items())),
            original_view_sha256=view["sha256"],public_view_sha256=projected["sha256"],
            original_native_sha256=outputs["native_checkpoint"]["sha256"],query_sha256=view["query_sha256"],
            source_view_policy=deepcopy(source_policy),**deepcopy(artifacts))
    return row


def public_reviewed_view(view):
    """Versioned presentation projection; never reissue a changed native record."""
    convention=module("reviewed_source_public_metadata",REPO/"tools/export_current_replays.py")
    projected=convention.public_metadata(view)
    for provenance in projected["model_provenance"]:
        for key in ("request_ref","response_ref","provider_receipt_ref"):
            provenance[key]["path"]=None
            provenance[key]["publication_availability"]="Unpublished audit artifact; content hash retained"
    projected.pop("sha256")
    projected.update(publication_projection_version="reviewed-source-location-redaction/1",
        original_view_sha256=view["sha256"])
    projected["sha256"]=sha(encoded(projected))
    return projected


def patch_reviewed_source_runtime(target):
    anchor='  routes["/api/current/analyst-digest"] = {defaults: {config: "llm_readings"}, required: currentPins};'
    addition='  routes["/api/current/reviewed-source-accounts"] = {defaults: {config: "llm_readings"}, required: currentPins};'
    r_addition='  routes["/api/current/source-realized-redaction"] = {defaults: {config: "llm_readings"}, required: currentPins};'
    for relative in ("runtime/public-runtime.js","site/runtime/public-runtime.js"):
        path=target/relative
        text=path.read_text()
        require(text.count(anchor)==1,"Reviewed runtime route patch preimage differs")
        require(text.count(addition)<=1,"Duplicate reviewed source runtime route")
        if addition not in text:text=text.replace(anchor,anchor+'\n'+addition)
        require(text.count(r_addition)<=1,'Duplicate source-realized redaction route')
        if r_addition not in text:text=text.replace(anchor,anchor+'\n'+r_addition)
        text=text.replace('Saved public research demo only. No model, live query API, inference, or new ranking is available. Export coverage is finite, not all local archives.',
            'Saved examples. Connect a backend for Live analysis.')
        write(path,text.encode())


def compose(selection_ref,tag):
    global R_PUBLISHER_READY
    target=stage_path(tag)
    baseline=init(tag)
    selection=checked(selection_ref)
    R_PUBLISHER_READY=selection.get('source_realized_publication_ready_ref')
    revised=selection["version"]=="source-showcase-publication-selection/1"
    require(revised or selection["version"]=="breakthrough-publication-selection/1","Unknown selection contract")
    prior_ref=selection["base_report_ref"] if revised else baseline["source_lineage"]["source_report_ref"]
    book_ref=selection["base_casebook_ref"] if revised else baseline["source_lineage"]["casebook_ref"]
    prior=checked(prior_ref)
    report=deepcopy(prior)
    prior_book=checked(book_ref)
    require(prior_book["source_report_sha256"]==prior_ref["sha256"] and
        prior_book["source_report_run"]==prior["run_id"],"Base casebook and report differ")
    retirements=checked_retirements(prior,prior_book,selection)
    retired_ids={row["case_id"] for row in retirements}
    old={r["case"]["case_id"]:r for r in report["cases"]}
    replacements={}
    roles=set()
    extra_entries={}
    changed=[]
    for proposal in selection["replacements"]:
        previous=old[proposal["replaces"]]
        require(proposal["replaces"] not in replacements,"Repeated replacement")
        entry=checked(proposal["entry_ref"])
        role=(entry["case"]["corpus"],entry["case"]["task"])
        require(role==(previous["case"]["corpus"],previous["case"]["task"]) and
            role[1] in ({"mosaic","hypothesis","redaction"} if revised else {"mosaic","hypothesis"}),
            "Replacement must preserve its primary corpus/task role")
        replacements[proposal["replaces"]]=attach(entry,previous)
        roles.add(role)
        extra_entries[entry["case"]["case_id"]]=entry.get("casebook_entry")
        changed.append(replacements[proposal["replaces"]])
    if revised:
        require(bool(replacements) or bool(retirements),"An explicit saved replacement or retirement is required")
    else:
        require(len(replacements)==6 and roles=={(c,t) for c in ("cib","iran","vietnam") for t in ("mosaic","hypothesis")},
            "Six exact Mosaic/Hypothesis replacement roles required")
    report["cases"]=[replacements.get(r["case"]["case_id"],r) for r in report["cases"]
        if r["case"]["case_id"] not in retired_ids or r["case"]["case_id"] in replacements]
    for proposal in selection["additions"]:
        entry=checked(proposal["entry_ref"])
        require((entry["case"]["corpus"],entry["case"]["task"])==("cib","redaction")
            and all(entry.get(k) for k in ("source_target_id","family_id")),"Additional CIB redaction needs authentic target/family provenance")
        row=attach(entry)
        require(row["case"]["case_id"] not in retired_ids,"An addition cannot resurrect an explicitly retired case")
        collection=proposal.get('collection','additional_real_redaction')
        require(collection in {'additional_real_redaction','bench'},'Unknown additional-case display collection')
        row.update(collection=collection,selected_additional=collection=='additional_real_redaction',
            selected_demo=False,selected_bench=collection=='bench')
        if not row.get("narrative_id"):
            row["narrative_id"]="additional_real_redaction"
        report["cases"].append(row)
        changed.append(row)
        extra_entries[row["case"]["case_id"]]=entry.get("casebook_entry")
    ids=[r["case"]["case_id"] for r in report["cases"]]
    require(len(ids)==len(set(ids)) and ids==selection["expected_active_case_ids"],"Complete dynamic active inventory differs")
    if "ordered_case_ids" in selection:
        require(ids==selection["ordered_case_ids"],"Ordered selection inventory differs")
    if retirements:
        require(not retired_ids.intersection(ids),"A retired case remains active")
        report.update(retirements=deepcopy(retirements),ordered_case_ids=ids[:])
    elif "ordered_case_ids" in report:
        report["ordered_case_ids"]=ids[:]
    if not revised:
        require(len(selection["additions"])>=1,"At least one tested real CIB addition required")
    # Seal the public metadata, retaining canonical private refs only in the
    # private build bindings used by export and the field-guide producer.
    source_realized_artifacts={}
    for row in report['cases']:
        pin=row.get('reviewed_source_assessment')
        if pin and pin.get('method_id')==R_METHOD:
            publisher,metadata=source_realized_publisher()
            source_realized_artifacts[row['case']['case_id']]={key:deepcopy(pin[key])
                for key in ('view_ref','method_ref','producer_ready_ref')}
            row['reviewed_source_assessment']=metadata.public_metadata(pin)
    report["privacy_contract"]=story_contract(report["cases"],prior.get("privacy_contract"))
    report.update(completed_cases=len(ids),pending_cases=[],complete_execution_grid=True,local_execution_after_planning=True,
        native_outputs_modified=False,outcome_informed_demo=True,benchmark_accuracy=False,full_benchmark_launched=False,
        showcase_ready=False,qualified_release_ready=False,qualified_narratives=[],
        release_scope="diagnostic_demo_with_declared_limitations",release_profile="breakthrough_saved_native_selection",
        collection_counts=dict(Counter(r.get("collection","primary") for r in report["cases"])),
        quality_blockers=["Fresh source, privacy, licensing and publication authorization are required; qualification is not inherited."],
        presentation_context={},presentation_context_sources_ref=None)
    report["investigations"]=deepcopy(selection.get("investigations",[
        dict(id=r["id"],narrative_id=r["narrative_id"],corpus=r["corpus"],collection="starter",
            title=r["corpus"].upper()+" source-linked examples",status="SOURCE_BOUND_DEMONSTRATION_NOT_BENCHMARK",
            qualified_case_count=0,trio_qualified=False) for r in prior["investigations"]]))
    if selection.get("pdf_catalog_ref"):
        checked(selection["pdf_catalog_ref"])
        report["pdf_catalog_ref"]=selection["pdf_catalog_ref"]
    report.pop("sha256",None)
    digest_config=selection.get('source_digest_publication')
    if digest_config:
        digest_hooks=module('saved_summary_publication_hooks',HERE/'digest_hooks.py')
        report=digest_hooks.attach(report,digest_config)
    report["publication_metadata_version"]="source-showcase-casebook-binding/2"
    identity=dict(cases=report["cases"],pdf_catalog_ref=report["pdf_catalog_ref"],privacy_contract=report["privacy_contract"],
        publication_metadata_version=report["publication_metadata_version"])
    if retirements:
        identity["retirements"]=retirements
    report["run_id"]="breakthrough_"+sha(encoded(identity))[:24]
    report["sha256"]=sha(encoded(report))
    records=HERE/"records"/report["run_id"]
    write(records/"report.json",report)
    report_ref=ref(records/"report.json")
    digest_indexes=(digest_hooks.bind(report_ref,digest_config) if digest_config else None)
    book=deepcopy(prior_book)
    lookup={r["case"]["case_id"]:r for r in report["cases"]}
    replace_ids={k:v["case"]["case_id"] for k,v in replacements.items()}
    for group in ("primary","special_redactions"):
        book[group]=[casebook_entry(lookup[replace_ids.get(e["case_id"],e["case_id"])],e,
            extra_entries.get(replace_ids.get(e["case_id"],e["case_id"]))) for e in book[group]
            if e["case_id"] not in retired_ids or e["case_id"] in replacements]
    append_new_specials(book,changed,extra_entries)
    book.update(source_report_sha256=report_ref["sha256"],source_report_run=report["run_id"],
        notice="Saved source-bound examples; native statuses and historical scope are preserved.")
    if retirements or "source_report_ref" in book or "ordered_case_ids" in book:
        book.update(source_report_ref=deepcopy(report_ref),ordered_case_ids=ids[:])
    book.update(primary_availability(book["primary"]))
    book["backgrounds"]=deepcopy(selection.get("backgrounds",{c:[] for c in ("cib","iran","vietnam")}))
    casebook_path=records/("casebook_"+sha(encoded(book))[:24]+".json")
    write(casebook_path,book)
    return dict(report_ref=report_ref,casebook_ref=ref(casebook_path),selection_ref=selection_ref,
        changed_case_ids=[r["case"]["case_id"] for r in changed],
        retired_case_ids=list(dict.fromkeys([*replacements,*[row["case_id"] for row in retirements]])),active_case_ids=ids,
        records=records,target=target,baseline=baseline,selection=selection,
        source_realized_artifacts=source_realized_artifacts,source_digest_indexes=digest_indexes)


class Writer:
    def __init__(self,target):
        self.output=target
        self.limits=dict(max_bytes=900_000_000,max_seconds=1800,max_requests=100000,max_sources=10000,max_nodes=50000,max_packet_bytes=210000000)
        self.bytes,self.files,self.resuming,self.started=0,{},False,time.monotonic()
    def guard(self,extra=0):
        require(shutil.disk_usage(HERE).free-extra>=RESERVE and self.bytes+extra<350_000_000
            and time.monotonic()-self.started<1800,"Stage disk/byte/time guard")
    def write(self,relative,raw):
        require(relative.startswith("site/data/") and len(raw)<100_000_000,"Finite replay writes only")
        path=self.output/relative
        if path.exists():
            require(path.read_bytes()==raw,"Content-addressed replay collision")
            return
        self.guard(len(raw))
        write(path,raw)
        self.bytes+=len(raw)
        self.files[relative]=dict(path=relative,sha256=sha(raw),bytes=len(raw))


def export(bindings):
    sys.path.insert(0,str(ROOT))
    deploy=ROOT/"phase/release_finish_20261121/deploy"
    sys.path.insert(0,str(deploy))
    import export_narrative as transport
    from matryoshka_narrative.server import Viewer
    from matryoshka_current.map_transport import SavedMaps
    from matryoshka_current.local_pdfs import LocalPDFs
    convention=module("breakthrough_export_convention",REPO/"tools/export_current_replays.py")
    report=checked(bindings["report_ref"])
    pdfs=LocalPDFs(ROOT.parent,ROOT,report["pdf_catalog_ref"])
    maps=SavedMaps(REPO,bindings["baseline"]["live_index_sha256"],pdfs=pdfs)
    viewer=Viewer(ROOT,bindings["report_ref"],maps,casebook_ref=bindings["casebook_ref"],
        digest_ref=bindings["selection"].get("digest_ref"))
    inputs=transport.Inputs()
    reader=transport.SavedReader(viewer,inputs)
    class Exporter(transport.Exporter):
        def get(self,name,params):
            if name=='analyst-digest' and params.get('case_id') in self.source_digest_rows:
                row=self.source_digest_rows[params['case_id']]
                expected=dict(case_id=row['case']['case_id'],config='llm_readings',
                    **{field:row['resource_binding'][field] for field in
                        ('resource_id','registry_sha256','index_sha256')})
                require(set(params)==set(expected) and all(type(value) is str for value in params.values())
                    and params==expected,'The saved summary route differs from its exact case, arm or resource')
                key=transport.route('/api/current/analyst-digest',params)
                if key not in self.entries:
                    value=self.source_digest_hooks.response(bindings['report_ref'],self.source_digest_indexes,
                        row)
                    convention.GUARD.scan_json(value,None)
                    self.requests+=1
                    require(self.requests<=self.stage.limits['max_requests'],'Finite request limit')
                    self.stage.guard()
                    self.put(key,None,raw=encoded(value))
                    return value
                return super().get(name,params)
            if name=='source-v6' and params.get('case_id') in self.r_sources:
                publisher,prepared=self.r_sources[params['case_id']]
                source_id=params.get('source_id')
                if source_id in prepared['source_page_ids']:
                    key=transport.route('/api/current/'+name,params)
                    if key not in self.entries:
                        value=source_realized_transport(publisher,prepared,source_id,self.reader.api(name,params))
                        self.requests+=1
                        require(self.requests<=self.stage.limits['max_requests'],'Finite request limit')
                        self.stage.guard()
                        self.put(key,value)
                        return value
                    return super().get(name,params)
            if name=="native-v6":
                key=transport.route("/api/current/"+name,params)
                if key not in self.entries:
                    value=self.reader.api(name,params)
                    if value.get("native",{}).get("result",{}).get("terminal_scores",{}).get("version") in {"terminal-evidence-fit/8", "terminal-context-priority/10"}:
                        self.requests+=1
                        require(self.requests<=self.stage.limits["max_requests"],"Finite request limit")
                        self.stage.guard()
                        # The closed v8 projection replaces, rather than nests,
                        # the older public-native location annotation.
                        self.put(key,value)
                        return value
            return super().get(name,params)
        def _guide(self,selection,path,source_ids):
            guide=self.get("guide-v6",selection)
            source_ids.update(transport.citations(guide))
            require(set(transport.citations(path["decision_source_refs"]))<=set(transport.citations(guide)),"Guide loses actual used-source ending")
            if guide.get("route") is None:
                require(path["graph_hops"]==0,"An actual graph path disappeared")
                return
            for node in guide.get("route",{}).get("nodes",[]):
                if node.get("is_graph_node") is False:
                    continue
                self.get("node-v6",dict(**{k:selection[k] for k in ("case_id","config",*transport.PINS)},node_id=node["id"]))
    stage=Writer(bindings["target"])
    transport_path=HERE.parent/"ui_scores_v10_v2/native_transport.py"
    require(ref(transport_path)["sha256"]=="14a10c2c4922ba3266817604ac9f2a706bec28405c30627d73226af4deb7e5ba",
        "Native publication transform differs from the reviewed exact-byte helper")
    native_transport=module("reviewed_v8_v10_public_native_projection_v3",transport_path)
    def public_metadata(value):
        return native_transport.project_context_native_receipt_identities(value,convention.public_metadata(value))
    worker=Exporter(stage,viewer,reader,public_metadata,convention.GUARD.scan_json)
    worker.r_sources={}
    worker.source_digest_indexes=bindings.get('source_digest_indexes')
    worker.source_digest_rows=({row['case']['case_id']:row for row in report['cases']
        if row.get('reviewed_source_assessment')} if worker.source_digest_indexes else {})
    worker.source_digest_hooks=(module('saved_summary_export_hooks',HERE/'digest_hooks.py')
        if worker.source_digest_indexes else None)
    try:
        viewer.casebook()
        if bindings['selection'].get('native_digest_publication'):
            native_hooks=module('retained_native_summary_hooks',HERE/'native_digest_hooks.py')
            native_hooks.install(worker,bindings['selection']['native_digest_publication'])
        for row in report["cases"]:
            if row["case"]["case_id"] not in bindings["changed_case_ids"]:
                continue
            pin=row.get('reviewed_source_assessment')
            if pin and pin['method_id']==R_METHOD:
                publisher,_=source_realized_publisher()
                artifacts=bindings['source_realized_artifacts'][row['case']['case_id']]
                prepared=publisher.prepare(case=row['case'],native_ref=row['configurations']['llm_readings']['native_checkpoint'],
                    resource_binding=row['resource_binding'],artifacts=artifacts)
                require(encoded(prepared['metadata'])==encoded(pin),'The current R metadata differs from canonical replay')
                worker.r_sources[row['case']['case_id']]=(publisher,prepared)
            worker.one_case(row)
            if row.get("reviewed_source_assessment"):
                pin=row["reviewed_source_assessment"]
                if pin['method_id']==R_METHOD:
                    publisher,prepared=worker.r_sources[row['case']['case_id']]
                    for relative,raw in prepared['public_assets'].items():
                        convention.GUARD.scan_json(json.loads(raw),None)
                        stage.write('site/'+relative,raw)
                    convention.GUARD.scan_json(prepared['envelope'],None)
                    worker.put(pin['endpoint'],None,raw=encoded(prepared['envelope']))
                    for request in prepared['source_requests']:
                        packet=worker.get('source-v6',request['params'])
                        verify_source_realized_response(publisher,prepared,request['canonical_page_id'],packet)
                else:
                    view=public_reviewed_view(checked(pin["view_ref"]))
                    require(view["sha256"]==pin["public_view_sha256"],"Public reviewed method changed after selection")
                    worker.put(pin["endpoint"],view)
                    params=dict(case_id=row["case"]["case_id"],config="llm_readings",
                        **{k:row["resource_binding"][k] for k in transport.PINS})
                    for pid in sorted({e["quote"]["canonical_page_id"] for e in view["source_endpoints"]}):
                        worker.get("source-v6",dict(params,source_id=pid))
            print("EXPORTED",row["case"]["case_id"],stage.bytes,flush=True)
        if bindings.get('source_digest_indexes'):
            for row in report['cases']:
                if not row.get('reviewed_source_assessment'): continue
                params=dict(case_id=row['case']['case_id'],config='llm_readings',
                    **{key:row['resource_binding'][key] for key in transport.PINS})
                worker.get('analyst-digest',params)
        if bindings["selection"].get("digest_ref"):
            for row in report["cases"]:
                for config in row["configurations"]:
                    params=dict(case_id=row["case"]["case_id"],config=config,
                        **{k:row["resource_binding"][k] for k in transport.PINS})
                    worker.get("analyst-digest",params)
        worker.put("/api/narrative-v1/manifest",viewer.manifest())
        worker.put("/api/current/casebook",None,raw=(ROOT/bindings["casebook_ref"]["path"]).read_bytes())
        for key in ("/api/current/report-v6","/data/report-v6.json"):
            worker.put(key,None,raw=(ROOT/bindings["report_ref"]["path"]).read_bytes())
        worker.put("/api/health",dict(status="ok",service="narrative-resource-workbench",report_ref=bindings["report_ref"],
            cases=len(report["cases"]),api_calls=0,live_inference=False,execution_kind="saved_narrative"))
        worker.packet_pack.finish(worker.entries)
        inputs.unchanged()
        original=read(bindings["target"]/"site/data/api-index.json")
        retired=set(bindings["retired_case_ids"])
        active=set(bindings["active_case_ids"])
        entries=merge_export_entries(without_case_routes(original["entries"],retired),worker.entries)
        for key in entries:
            selected=parse_qs(urlsplit(key).query).get("case_id",[])+parse_qs(urlsplit(key).query).get("case",[])
            require(not retired.intersection(selected) or set(selected)<=active,"Retired active case route remains")
        require(all(row["case_id"] in active for row in worker.coverage),"Inactive case remains in export coverage")
        index=dict(original,entries=entries)
        write(bindings["target"]/"site/data/api-index.json",index)
        write(bindings["target"]/"site/data/report-v6.json",(ROOT/bindings["report_ref"]["path"]).read_bytes())
        write(bindings["records"]/"export.json",dict(coverage=worker.coverage,new_routes=len(worker.entries),new_bytes=stage.bytes,
            source_report_ref=bindings["report_ref"],native_outputs_modified=False,graphs_rebuilt=False,api_calls=0))
    finally:
        reader.close_case()
        worker.packet_pack.close()
        viewer.close()


def patch_score_reader(score_text):
    old_score="for (const reading of record.result.readings) for (const native of reading.candidates)"
    new_score="for (const reading of record.result.readings || []) for (const native of reading.candidates)"
    require((score_text.count(old_score),score_text.count(new_score)) in {(1,0),(0,1)},
        "Task-aware score-binding patch preimage changed")
    score_text=score_text.replace(old_score,new_score)
    score_patches=[
        ("/* The final arithmetic is saved by the native executor, never invented from rank. */",
         "/* The final arithmetic is saved by the native executor, never invented from rank. */\nimport {ADJUNCT_SCORE_VERSION,validateAdjunctScore,verifyAdjunctScoreBindings} from './adjunct-score-bindings.js';"),
        ("      if ([EVIDENCE_SCORE_VERSION, POINTS_SCORE_VERSION, SOURCE_POINTS_VERSION, CONTEXTUAL_POINTS_VERSION].includes(score.version) &&",
         "      if(candidate.version===ADJUNCT_SCORE_VERSION){\n        if(reading.candidates.some(c=>c.version!==ADJUNCT_SCORE_VERSION))throw Error('Different candidate score scales share one reading.');\n        validateAdjunctScore(candidate,nativeCandidates.get(candidate.id));\n        continue;\n      }\n      if ([EVIDENCE_SCORE_VERSION, POINTS_SCORE_VERSION, SOURCE_POINTS_VERSION, CONTEXTUAL_POINTS_VERSION].includes(score.version) &&"),
        ("    const card = native.terminal_scorecard, license = card.realized_form_license;",
         "    if(native.terminal_scorecard?.version===ADJUNCT_SCORE_VERSION){\n      await verifyAdjunctScoreBindings(native,record,caseInfo,digest);\n      continue;\n    }\n    const card = native.terminal_scorecard, license = card.realized_form_license;")]
    # Normalize only the two known adapter editions before recognizing prior patches.
    score_text=score_text.replace("ADJUNCT_SCORE_VERSION,ADJUNCT_SCORE_VERSIONS,validateAdjunctScore,verifyAdjunctScoreBindings}",
        "ADJUNCT_SCORE_VERSION,validateAdjunctScore,verifyAdjunctScoreBindings}")
    score_text=score_text.replace("ADJUNCT_SCORE_VERSIONS.includes(candidate.version)","candidate.version===ADJUNCT_SCORE_VERSION")
    score_text=score_text.replace("c.version!==candidate.version","c.version!==ADJUNCT_SCORE_VERSION")
    score_text=score_text.replace("ADJUNCT_SCORE_VERSIONS.includes(native.terminal_scorecard?.version)",
        "native.terminal_scorecard?.version===ADJUNCT_SCORE_VERSION")
    for old,new in score_patches:
        addition=new.replace(old,"",1) if new.startswith(old) else new.removesuffix(old)
        count=score_text.count(addition)
        require(count<=4,"Unexpected repeated score adapter patches")
        score_text=score_text.replace(addition,"")
    require(not any(token in score_text for token in (
        "ADJUNCT_SCORE_", "validateAdjunctScore", "verifyAdjunctScoreBindings", "adjunct-score-bindings.js")),
        "Unrecognized score adapter code remains after removing the known patches")
    for old,new in score_patches:
        require(score_text.count(old)==1,"Score-family reader patch preimage changed")
        score_text=score_text.replace(old,new)
    return score_text


def finish(bindings):
    target,selection=bindings["target"],bindings["selection"]
    site=target/"site"
    baseline=bindings["baseline"]
    for asset in selection.get("ui_assets",[]):
        name=asset["target"]
        require(re.fullmatch(r"(?:graph-|workbench-|swedish-study|source-pdf-canvas)[A-Za-z0-9_.-]*\.(?:js|css|html)",name)
            or re.fullmatch(r"graph-source-proofs/(?:(?:cib|iran|vietnam)/[a-f0-9]{2}\.json\.gz|manifest\.json)",name)
            or name in {"vendor/pdfjs/pdf.mjs","vendor/pdfjs/pdf.worker.mjs","vendor/pdfjs/LICENSE",
                "source-inspection.js", "saved-source-policy.js", "decision-scores.js", "legacy-decision-scores.js", "context-priority-v8.js", "context-priority-v10.js", "context-priority-v10-math.js", "v8-json-wire.js", "narrative-collections-v1.js", "narrative-trace-v1.js",
                "narrative-catalog-v1.js", "r-contract.js"},
            "UI assets must be explicitly named root presentation files")
        source=ROOT/asset["source_ref"]["path"]
        require(source.resolve()==source and source.is_relative_to(ROOT) and
            ref(source)==asset["source_ref"],"UI source asset changed after its selection")
        write(site/name,source.read_bytes())
    from patch_ci import main as patch_ci
    patch_ci(target.name)
    patch_reviewed_source_runtime(target)
    score_ui=site/"decision-scores.js"
    adapter=selection.get("adjunct_score_adapter_ref")
    context_ready_ref=selection.get('context_reader_ready_ref')
    if context_ready_ref:
        ready=checked(context_ready_ref)
        require(ready.get('version') in {'native-context-priority-reader-lifecycle-freeze/2',
                'native-context-priority-reader-resource-envelope-freeze/3'}
            and ready.get('state')=='FROZEN_OWNER_STOPPED' and not adapter,
            'An explicit frozen contextual reader family with its unchanged adjunct guard is required')
        assets={row['target']:row['source_ref'] for row in selection['ui_assets']}
        base=(ROOT/context_ready_ref['path']).parent
        for row in ready['assets']:
            source=base/row['path']
            require(ref(source)==assets.get(row['path']) and sha(source.read_bytes())==row['sha256']
                and (site/row['path']).read_bytes()==source.read_bytes(),
                'All six reviewed reader assets must be selected and copied without further patches')
        strict=HERE/'ui/adjunct-score-bindings.js'
        require(sha(strict.read_bytes())=='1463ead9dfa0873b14b27f73df468d6322c2c9bcf3828a98b919385a42c220a4',
            'The reviewed reader requires its original strict adjunct authority guard')
        write(site/'adjunct-score-bindings.js',strict.read_bytes())
    else:
        score_text=patch_score_reader(score_ui.read_text())
        write(score_ui,score_text.encode())
    if adapter and not context_ready_ref:
        source=ROOT/adapter["path"]
        require(ref(source)==adapter,"The explicit score adapter changed")
        write(site/"adjunct-score-bindings.js",source.read_bytes())
        score_text=score_ui.read_text()
        score_text=score_text.replace("ADJUNCT_SCORE_VERSION,validateAdjunctScore,verifyAdjunctScoreBindings}",
            "ADJUNCT_SCORE_VERSION,ADJUNCT_SCORE_VERSIONS,validateAdjunctScore,verifyAdjunctScoreBindings}")
        score_text=score_text.replace("candidate.version===ADJUNCT_SCORE_VERSION","ADJUNCT_SCORE_VERSIONS.includes(candidate.version)")
        score_text=score_text.replace("c.version!==ADJUNCT_SCORE_VERSION","c.version!==candidate.version")
        score_text=score_text.replace("native.terminal_scorecard?.version===ADJUNCT_SCORE_VERSION",
            "ADJUNCT_SCORE_VERSIONS.includes(native.terminal_scorecard?.version)")
        write(score_ui,score_text.encode())
    elif not context_ready_ref:
        write(site/"adjunct-score-bindings.js",(HERE/"ui/adjunct-score-bindings.js").read_bytes())
    require(sha((REPO/"site/release-manifest.json").read_bytes())==baseline["live_manifest_sha256"]
        and sha((REPO/"site/data/api-index.json").read_bytes())==baseline["live_index_sha256"],"Live publication changed during stage")
    ui=site/"workbench-v6.js"
    text=ui.read_text()
    old="manifest.special_redactions.length>5"
    new="manifest.special_redactions.length>rows.length"
    require((text.count(old),text.count(new)) in {(1,0),(0,1)},"Dynamic extras-cap patch preimage changed")
    if old in text:write(ui,text.replace(old,new).encode())
    text=ui.read_text()
    old_choice='return preferredProposalReading(record,caseInfo,{pool:proposalPoolCache.get(record)?.view,inputView:inputContextCache.get(record)?.view});'
    new_choice='return curatedDisplayReading(record,caseInfo,row,options)||'+old_choice[len('return '):]
    grouped_choice='const preferred=curatedDisplayReading(record,caseInfo,row,options)||'+old_choice[len('return '):]
    require((text.count(old_choice),text.count(new_choice),text.count(grouped_choice)) in {(1,0,0),(0,1,0),(0,0,1)},
        "Curated reading presentation patch preimage changed")
    if old_choice in text:write(ui,text.replace(old_choice,new_choice).encode())
    study_path=site/"swedish-study-native.json"
    if study_path.exists():
        study=read(study_path)
        if "source_report_ref" in study:
            study["source_report_ref"]=bindings["report_ref"]
            write(study_path,study)
            html=site/"swedish-study.html"
            if html.exists():
                write(html,re.sub(r'(<meta name="study-data-sha256"[^>]*content=")[a-f0-9]{64}',
                    lambda m:m[1]+sha(study_path.read_bytes()),html.read_text()).encode())
    index_sha=sha((site/"data/api-index.json").read_bytes())
    for path in site.rglob("*.html"):
        value=path.read_text()
        value=re.sub(r'(data-index-sha256=")[a-f0-9]{64}',lambda m:m[1]+index_sha,value)
        value=re.sub(r'(<meta name="source-api-index-sha256"[^>]*content=")[a-f0-9]{64}',lambda m:m[1]+index_sha,value)
        write(path,value.encode())
    subprocess.run(["node",str(HERE/"rebuild_lookups.mjs"),target.name],check=True,cwd=ROOT)
    from assets import make_guide,make_backend_bundle
    guide=(checked(selection["field_guide_binding_ref"]) if selection.get("field_guide_binding_ref")
        else make_guide(bindings))
    bundle=make_backend_bundle(bindings)
    report=checked(bindings["report_ref"])
    coverage=[]
    versions=Counter()
    source_policies=Counter(item['source_view_policy']['id'] for row in report['cases']
        for item in row['configurations'].values())
    replay_n=0
    for row in report["cases"]:
        for arm,item in row["configurations"].items():
            native=checked(item["native_checkpoint"])
            require(native["native_checksum"]==sha(encoded(native["result"])),"Native changed before manifest sealing")
            versions[native["version"]]+=1
            replay_n+=bool(native.get("terminal_stage_replay"))
            coverage.append(dict(case_id=row["case"]["case_id"],config=arm,native_checkpoint=item["native_checkpoint"],
                native_version=native["version"],native_result_sha256=native["native_checksum"]))
    lineage=deepcopy(baseline["source_lineage"])
    if selection.get("dataset_delivery_ref"):
        delivery=selection["dataset_delivery_ref"]
        require(delivery.get("path")=="data/dataset-delivery.json" and
            sha((site/delivery["path"]).read_bytes())==delivery.get("sha256"),
            "The selected source dataset delivery changed")
        lineage.update(graph_delivery="same-repository",dataset_delivery_ref=deepcopy(delivery))
    lineage.update(source_report_ref=bindings["report_ref"],casebook_ref=bindings["casebook_ref"],
        digest_ref=selection.get("digest_ref"),
        publish_authorized=False,privacy_approval_inherited=False,release_qualified=False,
        field_guide=guide,code_bundle=bundle,backend_code_sha256=bundle["source_backend_tree_sha256"],
        all_saved_natives_use_current_code=False,archived_code_bundle_is_current_engine=True,
        mixed_saved_native_versions=True,coverage=coverage,
        source_day_and_terminal_release=dict(version="breakthrough-saved-release/1",selected_native_executions=len(coverage),
            full_native_executions=len(coverage)-replay_n,terminal_stage_replays=replay_n,
            historical_results_unchanged=True,
            source_policy=(next(iter(source_policies)) if len(source_policies)==1 else "EXPLICIT_PER_CASE"),
            source_policies=dict(source_policies),native_versions=dict(versions),
            research_accuracy_claimed=False,case_qualification_inherited=False))
    if lineage["field_guide"]:
        require(lineage["field_guide"]["source_report_ref"]==bindings["report_ref"],"Guide is not bound to new report")
        for asset in lineage["field_guide"]["assets"]:
            raw=(ROOT/asset["source_ref"]["path"]).read_bytes()
            require(sha(raw)==asset["public_sha256"]==asset["source_ref"]["sha256"],"Guide bytes changed")
            write(site/asset["target"],raw)
    write(site/"export-lineage.json",lineage)
    sys.path.insert(0,str(target/"release-tools"))
    sys.path.insert(0,str(target/"release-tools/ci"))
    gate=module("breakthrough_active_validator",target/"release-tools/ci/validate_manifest.py")
    publication=read(site/"publication.json")
    if selection.get("dataset_delivery_ref"):
        publication["source_pdf_delivery_ref"]=deepcopy(selection["dataset_delivery_ref"])
    publication.update(source_report_ref=bindings["report_ref"],casebook_ref=bindings["casebook_ref"],digest_ref=selection.get("digest_ref"),
        backend_code_sha256=lineage["backend_code_sha256"],source_day_and_terminal_release=lineage["source_day_and_terminal_release"],
        publish_authorized=False,privacy_approval_inherited=False,release_qualified=False)
    publication["files"]=[r for r in gate.inventory(site) if r["path"]!="publication.json"]
    write(site/"publication.json",publication)
    manifest=gate.make(site,lineage)
    require(manifest["case_ids"]==bindings["active_case_ids"],"Manifest dynamic inventory differs")
    receipt=dict(version="breakthrough-publication-stage/1",status="STAGED_AWAIT_FRESH_REVIEW_AND_AUTHORIZATION",
        report_ref=bindings["report_ref"],casebook_ref=bindings["casebook_ref"],active_case_ids=bindings["active_case_ids"],
        new_case_ids=bindings["changed_case_ids"],manifest_sha256=sha((site/"release-manifest.json").read_bytes()),
        api_index_sha256=index_sha,stage_site=str(site),live_manifest_preimage_sha256=baseline["live_manifest_sha256"],
        fresh_field_guide_bound=lineage["field_guide"] is not None,publish_authorized=False,api_calls=0,native_runs=0,
        live_repository_modified=False,datasets_copied=False,source_quotes_native_verdicts_modified=False)
    write(target/"STAGE_RECEIPT.json",receipt)
    return receipt


def build(selection_ref,tag="candidate_v1"):
    bindings=compose(selection_ref,tag)
    export(bindings)
    return finish(bindings)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action",choices=("init","compose","build"))
    parser.add_argument("--tag",default="candidate_v1")
    parser.add_argument("--selection-ref",type=Path)
    args=parser.parse_args()
    if args.action=="init":
        value=init(args.tag)
        result={k:value[k] for k in ("tag","live_manifest_sha256","site_copy_bytes","immutable_dataset_hardlink_bytes","live_repository_modified")}
    else:
        require(args.selection_ref is not None,"Explicit selection ref required")
        if args.action=="compose":
            value=compose(read(args.selection_ref),args.tag)
            result={k:value[k] for k in ("report_ref","casebook_ref","active_case_ids","changed_case_ids")}
        else:
            result=build(read(args.selection_ref),args.tag)
    print(json.dumps(result,sort_keys=True))
