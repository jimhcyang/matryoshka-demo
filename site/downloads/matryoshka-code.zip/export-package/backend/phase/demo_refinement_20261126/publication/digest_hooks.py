"""API0 publication glue for exact saved source-method summaries."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
PHASE=HERE.parent
FROZEN={
    'mh':('publication_digests_v4/FREEZE.json','70f13a91b8e14c56ffcdbdc4d20979edb1ed149c4ed4420dbd0aad4f893a4a32'),
    'r':('source_realized_digest_v1/FREEZE_RUNNER_V1.json','ff1214be798157a8f8fe7a60a939243655d1560887d645ee32fefcfc73dd0d15'),
}
R_METHOD='source_realized_redaction_v1'


def require(value,message):
    if not value: raise ValueError(message)


def encoded(value):
    return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def checked(reference):
    require(set(reference)<={'path','sha256','bytes'} and {'path','sha256'}<=set(reference),'Closed artifact reference required')
    path=ROOT/reference['path']
    require(not Path(reference['path']).is_absolute() and path.resolve()==path and path.is_relative_to(ROOT),'Unsafe artifact path')
    raw=path.read_bytes()
    require(hashlib.sha256(raw).hexdigest()==reference['sha256'],'Saved digest artifact changed')
    if 'bytes' in reference:
        require(type(reference['bytes']) is int and len(raw)==reference['bytes'],'Saved artifact length changed')
    return json.loads(raw)


def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def glue(kind):
    name,sha=FROZEN[kind]
    freeze=checked(dict(path=str((PHASE/name).relative_to(ROOT)),sha256=sha))
    for reference in freeze['files']+freeze.get('dependency_refs',[]):
        checked(reference) if str(reference['path']).endswith('.json') else _bytes(reference)
    path=PHASE/('publication_digests_v4/helper.py' if kind=='mh' else 'source_realized_digest_v1/publication_glue.py')
    require(any(row['path']==str(path.relative_to(ROOT)) for row in freeze['files']),'Critical publisher missing from freeze')
    return module('_saved_summary_'+kind,path)


def _bytes(reference):
    path=ROOT/reference['path']
    require(path.resolve()==path and path.is_relative_to(ROOT) and
        hashlib.sha256(path.read_bytes()).hexdigest()==reference['sha256'],'Frozen summary dependency changed')


def enrich_r_pins(report,results_ref):
    """Derive client commitments from artifacts just validated by the R publisher."""
    result=deepcopy(report)
    runs=checked(results_ref)
    for row in result['cases']:
        if row.get('reviewed_source_assessment',{}).get('method_id')!=R_METHOD: continue
        item=runs['cases'][row['case']['case_id']+'/llm_readings']
        prep,generation=checked(item['preparation_ref']),checked(item['generation_ref'])
        pin=row['source_realized_digest']
        require(pin['input_sha256']==prep['input_sha256']==generation['input_sha256'] and
            pin['generation_sha256']==generation['sha256'] and pin['body_sha256']==generation['body_sha256'] and
            encoded(prep['binding'])==encoded(generation['binding']),'R summary pin differs from validated generation')
        pin.update(condition_ref_sha256=row['configurations']['llm_readings']['condition_ref']['sha256'],
            condition_record_sha256=prep['binding']['condition_record_sha256'],text_sha256=digest(generation['text']),
            **{key:generation[key] for key in ('raw_response_wire_sha256','response_value_sha256','api_receipt_wire_sha256')})
    return result


def verify_r_presentation(response,row):
    pin=row['source_realized_digest']
    require(pin['condition_ref_sha256']==row['configurations']['llm_readings']['condition_ref']['sha256'] and
        pin['condition_record_sha256']==response['binding']['condition_record_sha256'] and
        pin['text_sha256']==digest(response['text']) and all(pin[key]==response[key] for key in
        ('raw_response_wire_sha256','response_value_sha256','api_receipt_wire_sha256')),'R summary presentation commitments differ')


def invoke(operation,**payload):
    process=subprocess.run([sys.executable,'-B',str(Path(__file__).resolve())],
        input=encoded(dict(operation=operation,**payload)),capture_output=True,cwd=ROOT,timeout=1800)
    require(process.returncode==0,'Saved-summary publication held: '+process.stderr.decode(errors='replace')[-3000:])
    return json.loads(process.stdout)


def attach(report,config):
    return invoke('attach',report=report,config=config)


def bind(report_ref,config):
    return invoke('bind',report_ref=report_ref,config=config)


def response(report_ref,index_refs,row):
    return invoke('response',report_ref=report_ref,index_refs=index_refs,row=row)


def run(value):
    operation=value['operation']
    if operation in {'attach','bind'}:
        config=value['config']
        require(set(config)=={'version','mh_results_ref','r_results_ref'} and
            config['version']=='saved-source-summary-publication/1','Explicit MH and R summary results required')
        mh,r=glue('mh'),glue('r')
        if operation=='attach':
            report=mh.attach_pins(value['report'],config['mh_results_ref'])
            report=r.attach_pins(report,config['r_results_ref'])
            return enrich_r_pins(report,config['r_results_ref'])
        return dict(mh=mh.bind_report(value['report_ref'],config['mh_results_ref']),
            r=r.bind_report(value['report_ref'],config['r_results_ref']))
    require(operation=='response','Unknown saved-summary operation')
    row=value['row']
    if row.get('reviewed_source_assessment',{}).get('method_id')==R_METHOD:
        result=glue('r').public_response(value['index_refs']['r'],value['report_ref'],row)
        verify_r_presentation(result,row)
        return result
    return glue('mh').public_response(value['index_refs']['mh'],value['report_ref'],row)


if __name__=='__main__':
    import socket
    def blocked(*args,**kwargs): raise RuntimeError('Network disabled for API0 summary publication')
    socket.create_connection=blocked
    original=socket.socket
    class LocalSocket(original):
        connect=blocked
        connect_ex=blocked
    socket.socket=LocalSocket
    print(encoded(run(json.loads(sys.stdin.buffer.read()))).decode(),flush=True)
