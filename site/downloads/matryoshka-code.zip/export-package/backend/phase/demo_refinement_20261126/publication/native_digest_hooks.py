"""Attach the retained, verified native postrun response without a new model call."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import build as B

READY=dict(path='phase/demo_refinement_20261126/Aungnative_digest_capture_v3/READY.json',
    sha256='38f8b4a9e0f61ca6e56e72eb3678726539d136b77085ee40456f8a20491ecbf8')


def install(worker,config):
    B.require(set(config)=={'version','generation_ref'} and
        config['version']=='retained-native-summary-publication/1','Explicit retained native summary required')
    ready=B.checked(READY)
    B.require(ready['version']=='actual-native-postrun-capture-freeze/3' and
        ready['state']=='FROZEN_OWNER_STOPPED','Exact stopped native summary publisher required')
    references=ready['files']+ready['dependencies']+ready['retained_refs']
    for reference in references:
        actual=B.ref(B.ROOT/reference['path'])
        B.require(actual=={key:reference[key] for key in ('path','sha256')},'Native summary publisher dependency changed')
        if 'bytes' in reference:
            B.require(type(reference['bytes']) is int and (B.ROOT/reference['path']).stat().st_size==reference['bytes'],
                'Native summary dependency length changed')
    path=(B.ROOT/READY['path']).parent/'publisher.py'
    B.require(any(reference['path']==str(path.relative_to(B.ROOT)) for reference in ready['files']),
        'Native summary publisher is not part of the reviewed freeze')
    spec=importlib.util.spec_from_file_location('_retained_native_summary_publisher',path)
    publisher=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(publisher)
    def select_flat(params):
        selectors={'case_id','config','resource_id','registry_sha256','index_sha256'}
        B.require(type(params) is dict and set(params)==selectors and
            all(type(value) is str and value for value in params.values()),
            'Native summary requires five exact flat string selectors')
        return worker.viewer.select({key:[value] for key,value in params.items()})

    # Publisher selectors are flat; the actual SavedReader Viewer uses parse_qs.
    # Keep the original reader and its normal source-page requests untouched.
    bridge=SimpleNamespace(viewer=SimpleNamespace(report_ref=worker.viewer.report_ref,select=select_flat),
        entries=worker.entries,put=worker.put,get=worker.get)
    return publisher.install_on_exporter(bridge,config['generation_ref'])
