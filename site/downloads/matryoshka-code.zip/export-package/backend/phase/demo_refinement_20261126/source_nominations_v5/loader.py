"""Additive checked-ref loader for an explicit separate three-case cohort."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sqlite3
import sys
import zlib
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
PHASE=HERE.parent
BASE=PHASE/"source_nominations_v4"
if hashlib.sha256((BASE/"FREEZE_V4.json").read_bytes()).hexdigest()!="74155ae2d4eff673f98a195c3c0780a6edcc6977b3091390fcf5f7d4c46ebf7e":
    raise RuntimeError("FROZEN_V4_CHANGED")
spec=importlib.util.spec_from_file_location("supplemental_v5_dependency",BASE/"dependency.py")
D=importlib.util.module_from_spec(spec)
old=sys.dont_write_bytecode
try:
    sys.dont_write_bytecode=True; spec.loader.exec_module(D)
finally: sys.dont_write_bytecode=old
W=D.W
COHORT=(
    ("profile_pilot_v1","narrative_cib_revision_ac4fb499beb4b345b5384ae6"),
    ("showcase_attempts_v1","refine_vietnam_r_existing_garrison_referent_v1"),
    ("showcase_attempts_v1","iran_refine_r_emami_appraisal_short_v2"),
)


def checked(ref,root=None,*,parse=True):
    root=Path(root or W.DEMO).absolute(); rel=Path(ref["path"])
    W.require(not rel.is_absolute() and ".." not in rel.parts,"UNSAFE_CHECKED_REFERENCE")
    path=root/rel
    W.require(path.resolve()==path and path.is_relative_to(root),"NONCANONICAL_CHECKED_REFERENCE")
    W.require(path.stat().st_size<=32*1024*1024 if path.suffix==".gz" else path.stat().st_size<=64*1024*1024,"ARCHIVE_OR_METADATA_INPUT_BOUND")
    W.require(path.is_file() and W.V1.sha(path.read_bytes())==ref["sha256"],"CHECKED_REFERENCE_HASH_MISMATCH")
    return W.strict_json(path.read_bytes()) if parse else path


def archived_native(path):
    # Historical Namyit input is 26,291,795 compressed bytes. This is a new
    # read-only archive bound, never an outgoing wire/artifact limit change.
    W.require(path.stat().st_size<=32*1024*1024,"ARCHIVED_NATIVE_COMPRESSED_BOUND")
    cap=W.LIMITS["max_native_decoded_bytes"]; result=io.BytesIO(); decoder=zlib.decompressobj(31)
    with path.open("rb") as stream:
        while chunk:=stream.read(262144):
            W.require(not decoder.eof,"TRAILING_GZIP_DATA")
            while chunk:
                part=decoder.decompress(chunk,cap-result.tell()+1)
                W.require(len(part)<=cap-result.tell(),"DECODED_ARTIFACT_BOUND")
                result.write(part); W.require(not decoder.unused_data,"TRAILING_GZIP_DATA"); chunk=decoder.unconsumed_tail
    W.require(decoder.eof,"TRUNCATED_GZIP"); result.seek(0)
    return result


def stream_projection(stream,roots,scalars):
    out={}; active=None; builder=None; depth=0
    for prefix,event,value in W.V1.parse_events(stream):
        if active:
            builder.event(event,value)
            depth+=int(event in {"start_map","start_array"})-int(event in {"end_map","end_array"})
            if depth==0: out[active]=builder.value; active=None
        elif prefix in roots and event in {"start_map","start_array"}:
            active=prefix; builder=W.V1.ObjectBuilder(); depth=1; builder.event(event,value)
        elif prefix in scalars and event in {"string","number","boolean","null"}: out[prefix]=value
    return out


def native_projection(stream):
    # Same query/source whitelist as V1, plus binding metadata for resource proof.
    return stream_projection(stream,{"public_case","plan.readings_packet","configuration.source_view_policy",
        "retrieval.source_view_policy","result.inspected_page_ids","code_pins","binding"},
        {"version","native_checksum","query_sha256","query_only_inference","answers_read","grades_read",
         "plan.query_only","plan.corpus_read","plan.hidden_answers_read","plan.query_sha256"})


def public_matrix_rows(path):
    rows=[]; current={}; active=None; builder=None; depth=0
    roots={"cases.item.case","cases.item.readings","cases.item.execution_refs_ref"}
    for prefix,event,value in W.V1.parse_events(path.open("rb")):
        if active:
            builder.event(event,value); depth+=int(event in {"start_map","start_array"})-int(event in {"end_map","end_array"})
            if depth==0: current[active.rsplit(".",1)[1]]=builder.value; active=None
        elif prefix=="cases.item" and event=="start_map": current={}
        elif prefix in roots and event in {"start_map","start_array"}:
            active=prefix; builder=W.V1.ObjectBuilder(); depth=1; builder.event(event,value)
        elif prefix=="cases.item" and event=="end_map": rows.append(current)
    return rows


def make_authority():
    cases=[]
    for epoch,case_id in COHORT:
        folder=PHASE/"epochs"/epoch/case_id; freeze=PHASE/"epochs"/epoch/"code_freeze.json"
        cases.append(dict(case_id=case_id,epoch=epoch,refs={key:W.file_ref(folder/name) for key,name in
            dict(native="native.json.gz",sources="inspected_sources.json.gz",summary="summary.json",completion="completion.json").items()},
            freeze_ref=W.file_ref(freeze)))
    return dict(version="source-nomination-checked-ref-authority/5",cohort="SUPPLEMENTAL_THREE_NOT_ORIGINAL31",cases=cases,
        case_denominator=3,ordinary_policy=W.V1.POLICY,QA_or_answer_selection=False,api_calls=0,native_runs=0)


def load_case(authority,case_id):
    W.require(authority.get("version")=="source-nomination-checked-ref-authority/5"
        and W.encoded(authority.get("ordinary_policy"))==W.encoded(W.V1.POLICY),"UNKNOWN_GENERIC_AUTHORITY_OR_POLICY")
    rows=[r for r in authority["cases"] if r["case_id"]==case_id]
    W.require(len(rows)==1,"UNKNOWN_OR_DUPLICATE_AUTHORITY_CASE")
    row=rows[0]
    W.require((row["epoch"],case_id) in COHORT,"UNAUTHORIZED_SUPPLEMENTAL_COHORT")
    expected=PHASE/"epochs"/row["epoch"]
    freeze=checked(row["freeze_ref"])
    W.require(W.DEMO/row["freeze_ref"]["path"]==expected/"code_freeze.json","EPOCH_FREEZE_PATH_MISMATCH")
    W.require(freeze.get("production_owners_stopped") is True and freeze.get("api_calls_authorized")==0,"UNFROZEN_SOURCE_NATIVE")
    paths={k:checked(ref,parse=False) for k,ref in row["refs"].items()}
    names=dict(native="native.json.gz",sources="inspected_sources.json.gz",summary="summary.json",completion="completion.json")
    W.require(set(paths)==set(names) and all(p==expected/case_id/names[k] for k,p in paths.items()),"GENERIC_ARTIFACT_PATH_MISMATCH")
    completion=W.strict_json(paths["completion"].read_bytes())
    W.require(completion.get("version")=="narrative-native-completion/1"
        and completion.get("packet_sha256")==row["refs"]["native"]["sha256"],"GENERIC_NATIVE_WIRE_HASH_MISMATCH")
    with paths["summary"].open("rb") as stream:
        summary=stream_projection(stream,{"case","native_ref","source_pages_ref"},{"status"})
    W.require(summary.get("status")=="COMPLETE","GENERIC_NATIVE_NOT_COMPLETE")
    for key,field in (("native","native_ref"),("sources","source_pages_ref")):
        W.require(all(summary[field].get(k)==row["refs"][key][k] for k in ("path","sha256")),"GENERIC_SUMMARY_REF_MISMATCH")
    with archived_native(paths["native"]) as stream: n=native_projection(stream)
    with W.V1.decompress(paths["sources"],W.LIMITS["max_sources_decoded_bytes"]) as stream: s=W.V1.sources_projection(stream)
    W.require(n.get("native_checksum")==completion.get("native_checksum") and n.get("code_pins")==freeze.get("code_pins"),"GENERIC_NATIVE_PIN_OR_RECEIPT_MISMATCH")
    W.require(n.get("public_case")==summary.get("case") and n["public_case"].get("case_id")==case_id,"GENERIC_PUBLIC_CASE_MISMATCH")
    matrix_path=checked(freeze["matrix_ref"],parse=False)
    entries=[r for r in public_matrix_rows(matrix_path) if r.get("case")==n["public_case"]]
    W.require(len(entries)==1 and entries[0].get("readings")==n["plan.readings_packet"],"FROZEN_PUBLIC_MATRIX_OR_READING_MISMATCH")
    eref=entries[0].get("execution_refs_ref",freeze["execution_refs"]); execution=checked(eref)
    W.require(n["binding"]==execution["index_refs"][n["public_case"]["corpus"]],"GENERIC_EXECUTION_BINDING_MISMATCH")
    from projector import validate_native
    validate_native(n,s)
    seal=dict(version="generic-source-native-input-seal/5",authority_sha256=W.digest(authority),authority_case=row,
        execution_refs_ref=eref,source_matrix_ref=freeze["matrix_ref"],native_wire_integrity_checked=True,
        logical_result_checksum_recomputed=False,only_query_inspected_sources_and_binding_extracted=True)
    return n,s,seal,execution


def canonical_preflight(n,s,execution,hash_cache):
    # Reopen source rows only; never instantiate full KG/alias/candidate arrays.
    sys.path.insert(0,str(W.DEMO))
    old=sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode=True
        from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE,source_page_allowed
    finally: sys.dont_write_bytecode=old
    case=n["public_case"]; corpus=case["corpus"]; ref=execution["index_refs"][corpus]
    registry=checked(execution["registry_ref"])
    W.require(registry.get("version")=="matryoshka-current-execution-registry/1"
        and registry["sha256"]==W.digest({k:v for k,v in registry.items() if k!="sha256"}),"GENERIC_REGISTRY_CANONICAL_HASH_MISMATCH")
    binding=registry["corpora"][corpus]
    W.require(ref["registry_sha256"]==registry["sha256"] and ref["source_binding_sha256"]==W.digest(binding)
        and ref["native_index_ref"]["sha256"]==ref["sha256"],"GENERIC_RESOURCE_BINDING_MISMATCH")
    path=W.DEMO/ref["path"]
    W.require(path.resolve()==path and path.is_relative_to(W.DEMO),"UNSAFE_CANONICAL_INDEX_PATH")
    if str(path) not in hash_cache:
        with path.open("rb") as stream: actual=hashlib.file_digest(stream,"sha256").hexdigest()
        W.require(actual==ref["sha256"],"CANONICAL_INDEX_WIRE_HASH_MISMATCH"); hash_cache[str(path)]=actual
    W.require(hash_cache[str(path)]==ref["sha256"],"MIXED_CANONICAL_INDEX")
    manifest_path=path.with_name("manifest.json"); manifest=W.strict_json(manifest_path.read_bytes())
    if corpus=="cib":
        native=ref["native_index_ref"]
        checked(native["manifest"],W.DEMO.parent,parse=False)
        W.require(manifest.get("index_sha256")==ref["sha256"] and manifest.get("registry_digest")==binding["native_registry_digest"],"CIB_INDEX_MANIFEST_MISMATCH")
    else:
        W.require(manifest.get("sha256")==ref["sha256"] and manifest.get("binding")==binding["incumbent_binding"],"CABLE_INDEX_MANIFEST_MISMATCH")
    db=sqlite3.connect(path.as_uri()+"?mode=ro&immutable=1",uri=True)
    try:
        fields=("id","document_id","corpus","date","text","source_sha256","visibility","permitted","classification")
        docs=set(); canonical=[]
        for page in s["pages"]:
            found=db.execute("SELECT payload FROM page WHERE id=?",(page["id"],)).fetchone()
            W.require(found is not None,"INSPECTED_PAGE_MISSING_FROM_CANONICAL_INDEX")
            raw=W.strict_json(found[0]); W.require(all(raw.get(k)==page.get(k) for k in fields),"CAPTURE_CANONICAL_SOURCE_MISMATCH")
            W.require(source_page_allowed(raw,case,SOURCE_DAY_INCLUSIVE),"CANONICAL_ORDINARY_SOURCE_NOT_ALLOWED")
            canonical.append(raw); docs.add(raw["document_id"])
        origin_dates={r[0] for r in db.execute("SELECT DISTINCT date FROM page WHERE doc=?",(case["document_id"],))}
        W.require(not origin_dates or origin_dates=={case["date"]},"CANONICAL_ORIGIN_DATE_MISMATCH")
        sibling_pages=0
        if corpus!="cib":
            projection=checked(binding["incumbent_binding"]["files"]["projection"],W.DEMO.parent)
            metadata=projection["document_metadata"]
            for doc in docs:
                W.require(not W.V1.NOFORN.search(" ".join(map(str,metadata.get(doc,{}).get("handling",[])))),"CANONICAL_DOCUMENT_METADATA_HANDLING_VETO")
                for payload, in db.execute("SELECT payload FROM page WHERE doc=?",(doc,)):
                    raw=W.strict_json(payload); sibling_pages+=1
                    W.require(not W.V1.NOFORN.search(raw["text"]) and not W.V1.NOFORN.search(" ".join(map(str,raw.get("handling",[])))),"CANONICAL_SIBLING_DOCUMENT_HANDLING_VETO")
        return dict(version="canonical-inspected-source-preflight/5",case_id=case["case_id"],canonical_index_ref=ref,
            execution_registry_ref=execution["registry_ref"],index_file_sha256_checked=True,canonical_page_checks=len(canonical),
            complete_relevant_document_sibling_pages_checked=sibling_pages,whole_origin_excluded=corpus!="cib",
            ordinary_source_policy=W.V1.POLICY,new_retrieval=False,new_pages_in_payload=False,api_calls=0,native_runs=0)
    finally: db.close()


def write_new(path,value):
    path=Path(path).absolute(); W.require(path.resolve()==path and path.is_relative_to(HERE),"OUTPUT_OUTSIDE_V5")
    raw=(json.dumps(value,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+"\n").encode()
    if path.exists(): W.require(path.read_bytes()==raw,"IMMUTABLE_V5_OUTPUT_DIFFERS"); return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("xb") as stream: stream.write(raw)
