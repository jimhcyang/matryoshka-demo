"""V5 input schema: preserve two additional actual public reading enums."""
from copy import deepcopy
import re
import unicodedata

from loader import W

READING_SCHEMA=deepcopy(W.V1.READING_SCHEMA)
for key in ("form","outer_family"):
    READING_SCHEMA["properties"][key]["enum"].append("verbal_predicate")
READING_SCHEMA["properties"]["role"]["enum"].append("predicative_complement")
INPUT_SCHEMA=deepcopy(W.MODEL_INPUT_SCHEMA)
INPUT_SCHEMA["properties"]["version"]["enum"]=["source-conditioned-partition-input/5"]
INPUT_SCHEMA["properties"]["declared_readings"]["items"]=READING_SCHEMA


def project_readings(packet,case):
    W.require(packet.get("version")=="next-slot-readings/3" and packet.get("status")=="ready"
        and packet.get("query_only") is True and packet.get("source_access") is False
        and packet.get("answer_text_supplied") is False,"V5_READINGS_NOT_PUBLIC_ONLY")
    W.require(packet.get("query_sha256")==W.digest(case["query"]) and packet.get("case_sha256")==W.digest(case),"V5_READING_BINDING")
    readings=packet.get("readings"); W.require(isinstance(readings,list) and 1<=len(readings)<=16,"V5_READING_BOUND")
    result=[]; seen=set()
    for r in readings:
        row={k:deepcopy(r[k]) for k in READING_SCHEMA["properties"] if k in r}
        try: W.V1.Draft202012Validator(READING_SCHEMA).validate(row)
        except Exception: raise W.WireError("V5_READING_SCHEMA") from None
        W.require(row["id"] not in seen,"V5_DUPLICATE_READING"); seen.add(row["id"])
        spans=row["attachment_spans"]+[c["span"] for c in row["cues"]]
        spans += [op[k] for op in row["operators"] for k in ("cue","scope") if op[k] is not None]
        spans += [span for wrap in row["wrappers"] for span in wrap["spans"]]
        for span in spans: W.V1.literal_span(span,case["query"])
        W.V1.assert_safe(row); result.append(row)
    return result


def validate_native(n,s):
    case=n.get("public_case")
    W.require(n.get("version")=="narrative-local-execution/4" and isinstance(case,dict) and set(case)==W.V1.PUBLIC,"V5_EXACT_PUBLIC_NATIVE")
    W.require(case["task"]=="redaction" and W.V1.iso_day(case["date"]) and case["corpus"] in {"cib","iran","vietnam"},"V5_PUBLIC_CASE_CONTRACT")
    W.require(isinstance(case["query"],str) and 0<len(case["query"])<=16000 and case["query"].count(case["focal_marker"])==1,"V5_QUERY_BOUND_OR_MASK")
    for key,value in (("query_only_inference",True),("answers_read",False),("grades_read",False),("plan.query_only",True),("plan.corpus_read",False),("plan.hidden_answers_read",False)):
        W.require(n.get(key) is value,"V5_NONPUBLIC_FLAG")
    W.require(n.get("query_sha256")==n.get("plan.query_sha256")==W.digest(case["query"]),"V5_QUERY_HASH")
    W.require(all(W.encoded(v)==W.encoded(W.V1.POLICY) for v in (n.get("configuration.source_view_policy"),n.get("retrieval.source_view_policy"),s.get("source_view_policy"))),"V5_NONORDINARY_POLICY")
    ids=n["result.inspected_page_ids"]
    W.require(isinstance(ids,list) and len(ids)<=256 and len(set(ids))==len(ids),"V5_INSPECTED_IDS")
    W.require({p["id"] for p in s["pages"]}==set(ids) and len(s["pages"])==len(ids),"V5_CAPTURE_SET")
    W.V1.assert_safe(case)
    for p in s["pages"]:
        W.require(p.get("canonical_page_id",p["id"])==p["id"] and W.digest(p["text"])==p["source_sha256"],"V5_CAPTURE_HASH_OR_ID")
        if p.get("raw_text_sha256") is not None: W.require(p["raw_text_sha256"]==W.V1.sha(p["text"].encode()),"V5_CAPTURE_UTF8_HASH")
        W.V1.assert_safe(p)
    return project_readings(n["plan.readings_packet"],case)


def api_body(payload,partition,model):
    W.require(model in {"gpt-6-luna","gpt-6.1-sol"},"V5_UNKNOWN_MODEL")
    W.V1.assert_safe(payload)
    try: W.V1.Draft202012Validator(INPUT_SCHEMA).validate(payload)
    except Exception: raise W.WireError("V5_INPUT_SCHEMA") from None
    binding=dict(case_id=payload["case"]["case_id"],packet_sha256=W.V2.partition_hash(payload,partition),partition_index=partition["index"],partition_count=partition["count"])
    return dict(model=model,instructions=W.PROMPT,input=[dict(role="user",content=[dict(type="input_text",text=W.encoded(dict(binding=binding,**payload)).decode())])],
        text=dict(format=dict(type="json_schema",name="source_nominations_partition_v2",strict=True,schema=W.RESPONSE_SCHEMA)),
        max_output_tokens=1536 if model=="gpt-6-luna" else 4096,reasoning=dict(effort="none" if model=="gpt-6-luna" else "low"),
        **({"temperature":0} if model=="gpt-6-luna" else {}),store=False)


def bound(payload):
    return max(len(W.encoded(api_body(payload,dict(index=255,count=256),model)))+2048 for model in ("gpt-6-luna","gpt-6.1-sol"))


def partition(n,s,seal):
    readings=validate_native(n,s); case=n["public_case"]; by_id={p["id"]:p for p in s["pages"]}
    base=dict(version="source-conditioned-partition-input/5",case=case,declared_readings=readings,sources=[])
    W.require(bound(base)<=32768,"V5_BASE_BODY_BOUND")
    chunks=[]; chunk=[]; vetoes=[]
    for pos,pid in enumerate(n["result.inspected_page_ids"]):
        p=by_id[pid]
        if len(p["text"])>6000 or not p["text"].strip():
            vetoes.append(dict(page_id=pid,inspected_position=pos,reason="OVERSIZE_OR_EMPTY_NO_CLIPPING")); continue
        page=W.V2.project_page(p,pos)
        if len(chunk)==12 or bound(dict(base,sources=chunk+[page]))>32768:
            W.require(bool(chunk),"V5_SINGLE_PAGE_BODY_BOUND"); chunks.append(chunk); chunk=[]
        W.require(bound(dict(base,sources=[page]))<=32768,"V5_SINGLE_PAGE_BODY_BOUND"); chunk.append(page)
    if chunk: chunks.append(chunk)
    coverage=dict(version="supplemental-source-coverage/5",case_id=case["case_id"],inspected_page_order=n["result.inspected_page_ids"],
        inspected_pages=len(by_id),eligible_pages=sum(map(len,chunks)),captured_pages=sum(map(len,chunks)),
        partition_page_ids=[[p["page_id"] for p in c] for c in chunks],vetoes=vetoes,capacity_omissions=0)
    captured=[p for group in coverage["partition_page_ids"] for p in group]
    W.require(len(set(captured))==len(captured) and len(captured)+len(vetoes)==len(by_id),"V5_EXACT_ONCE_ACCOUNTING")
    packets=[]
    for index,source in enumerate(chunks):
        payload=dict(base,sources=source); part=dict(index=index,count=len(chunks))
        packets.append(dict(version="source-nomination-generic-packet/5",model_input=payload,partition=part,
            packet_sha256=W.V2.partition_hash(payload,part),input_seal=seal,case_coverage_digest=W.digest(coverage),
            known_answers_used=False,candidate_admission_approved=False))
    return packets,coverage


def validate_response(packet,response):
    payload=packet["model_input"]; part=packet["partition"]
    W.require(packet["version"]=="source-nomination-generic-packet/5" and packet["packet_sha256"]==W.V2.partition_hash(payload,part),"V5_PACKET_HASH")
    W.V1.Draft202012Validator(INPUT_SCHEMA).validate(payload)
    if isinstance(response,(bytes,str)):
        W.require(len(response.encode() if isinstance(response,str) else response)<=16384,"RESPONSE_BYTE_BOUND"); response=W.strict_json(response)
    try: W.V1.Draft202012Validator(W.RESPONSE_SCHEMA).validate(response)
    except Exception: raise W.WireError("V5_RESPONSE_SCHEMA") from None
    W.require(len(W.encoded(response))<=16384,"RESPONSE_BYTE_BOUND"); W.V1.assert_safe(response)
    W.require(response["case_id"]==payload["case"]["case_id"] and response["packet_sha256"]==packet["packet_sha256"]
        and response["partition_index"]==part["index"] and response["partition_count"]==part["count"],"RESPONSE_PARTITION_BINDING_MISMATCH")
    pages={p["page_id"]:p for p in payload["sources"]}; readings={r["id"] for r in payload["declared_readings"]}; seen=set(); locators=[]
    for row in response["nominations"]:
        W.require(row["reading_id"] in readings and row["page_id"] in pages,"UNKNOWN_READING_OR_SOURCE")
        W.require(row["fill"].strip()==row["fill"] and not W.V1.OPAQUE.search(row["fill"]),"INVALID_FILL_SURFACE")
        W.require(not W.V1.OPAQUE.search(row["quote"]) and not W.V1.OPAQUE.search(row["source_phrase"]),"OPAQUE_SOURCE_QUOTATION")
        raw=pages[row["page_id"]]["windows"][0]["text"]
        W.require(W.digest(raw)==pages[row["page_id"]]["page_sha256"] and W.V1.sha(raw.encode())==pages[row["page_id"]]["page_utf8_sha256"],"RAW_WINDOW_OR_PAGE_HASH_MISMATCH")
        start=W.unique_start(raw,row["quote"],"SOURCE_QUOTE_NOT_EXACT_UNIQUE_OVERLAP_INCLUSIVE")
        phrase=start+W.unique_start(row["quote"],row["source_phrase"],"SOURCE_PHRASE_NOT_EXACT_UNIQUE_OVERLAP_INCLUSIVE")
        if row["transformation"]=="LITERAL": W.require(row["fill"]==row["source_phrase"],"LITERAL_FILL_NOT_LITERAL")
        key=(row["reading_id"],row["fill"].casefold()); W.require(key not in seen,"DUPLICATE_FILL_FOR_READING"); seen.add(key)
        locators.append(dict(reading_id=row["reading_id"],page_id=row["page_id"],quote_start=start,quote_end=start+len(row["quote"]),source_phrase_start=phrase,
            source_phrase_end=phrase+len(row["source_phrase"]),raw_quote_validated=True,contextual_proposal_only=True,factual_support_validated=False,
            nonliteral_transformation_validated=False,source_inference_unvalidated=row["transformation"]=="SOURCE_INFERENCE",candidate_admission_approved=False))
    return dict(version="generic-source-nomination-validation/5",case_id=response["case_id"],partition_index=part["index"],partition_count=part["count"],
        packet_sha256=packet["packet_sha256"],response_sha256=W.digest(response),locators=locators,factual_support_validated=False,candidate_admission_approved=False)
