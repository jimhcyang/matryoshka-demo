"""Full-coverage fresh31 source partitions; no calls, scores or admission."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import unicodedata

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"source_nominations"
BASE_WIRE_SHA="0ccc5450ac2459a1a60f623798050ffd5fdebd82c3c1aaecde807e1a62b35ce1"
BASE_FREEZE_SHA="de3e72426bfe01d5779233a8d93c8983e1f69f7c08ef4e246b4eb46ad56948fa"
if hashlib.sha256((BASE/"wire.py").read_bytes()).hexdigest()!=BASE_WIRE_SHA:
    raise RuntimeError("PINNED_V1_WIRE_CHANGED")
if hashlib.sha256((BASE/"FREEZE_V1.json").read_bytes()).hexdigest()!=BASE_FREEZE_SHA:
    raise RuntimeError("PINNED_V1_FREEZE_CHANGED")
spec=importlib.util.spec_from_file_location("pinned_fresh31_source_wire_v1",BASE/"wire.py")
V1=importlib.util.module_from_spec(spec)
_old_bytecode=sys.dont_write_bytecode
try:
    sys.dont_write_bytecode=True
    spec.loader.exec_module(V1)
finally:
    sys.dont_write_bytecode=_old_bytecode
DEMO=V1.DEMO
EPOCH=V1.EPOCH
WireError=V1.WireError
require=V1.require
encoded=V1.encoded
digest=V1.digest
strict_json=V1.strict_json
file_ref=V1.file_ref
LIMITS=dict(V1.LIMITS,max_partitions_per_case=256,max_merge_nominations=20,max_merge_bytes=65536)
PROMPT=V1.PROMPT+"\n\nThis is one source partition, not the entire case source pool. Nominate at most FIVE TOTAL for this pack, not five per reading. Echo the partition index/count and exact packet hash in binding. Other partitions are unavailable in this request; do not invent their contents."
RESPONSE_SCHEMA=deepcopy(V1.RESPONSE_SCHEMA)
RESPONSE_SCHEMA["properties"]["version"]["enum"]=["source-conditioned-partition-nominations/2"]
RESPONSE_SCHEMA["properties"].update(partition_index=dict(type="integer",minimum=0,maximum=255),partition_count=dict(type="integer",minimum=1,maximum=256))
RESPONSE_SCHEMA["required"]=list(RESPONSE_SCHEMA["properties"])
MODEL_INPUT_SCHEMA=deepcopy(V1.MODEL_INPUT_SCHEMA)
MODEL_INPUT_SCHEMA["properties"]["version"]["enum"]=["source-conditioned-partition-input/2"]


def partition_hash(payload,partition):
    return digest(dict(model_input=payload,partition=partition))


def body(payload,partition,model):
    require(isinstance(model,str) and re.fullmatch(r"[A-Za-z0-9_.-]{1,100}",model),"INVALID_MODEL_IDENTIFIER")
    V1.assert_safe(payload)
    try: V1.Draft202012Validator(MODEL_INPUT_SCHEMA).validate(payload)
    except Exception: raise WireError("V2_INPUT_SCHEMA_MISMATCH") from None
    binding=dict(case_id=payload["case"]["case_id"],packet_sha256=partition_hash(payload,partition),
        partition_index=partition["index"],partition_count=partition["count"])
    return dict(model=model,instructions=PROMPT,input=[dict(role="user",content=[dict(type="input_text",text=encoded(dict(binding=binding,**payload)).decode())])],
        text=dict(format=dict(type="json_schema",name="source_nominations_partition_v2",strict=True,schema=RESPONSE_SCHEMA)),
        max_output_tokens=LIMITS["max_output_tokens"],store=False)


def token_upper_bound(payload):
    # Reserve the largest permitted partition descriptor, avoiding a circular
    # partition-count estimate while packing pages.
    return len(encoded(body(payload,dict(index=255,count=256),"m"*100)))+LIMITS["framing_token_allowance"]


def project_page(page,position):
    raw=page["text"]
    return dict(page_id=page["id"],document_id=page["document_id"],corpus=page["corpus"],date=page["date"],
        visibility=page["visibility"],classification=page.get("classification"),handling=page["handling"],
        page_sha256=page["source_sha256"],page_utf8_sha256=V1.sha(raw.encode()),inspected_position=position,
        source_scope="COMPLETE_INSPECTED_PAGE_NOT_WHOLE_DOCUMENT",clipped=False,windows=[dict(start=0,end=len(raw),text=raw)])


def partition_projected(native,sources,input_seal):
    # The pinned V1 loader/projector rechecks every inspected source hash,
    # credential, policy, date/class and document-wide handling declaration.
    # Its capacity exclusions are re-admitted below, never silently dropped.
    checked,audit=V1.model_input(native,sources)
    base=dict(checked,version="source-conditioned-partition-input/2",sources=[])
    require(token_upper_bound(base)<=LIMITS["max_input_token_upper_bound"],"V2_BASE_INPUT_TOKEN_BOUND")
    order=native["result.inspected_page_ids"]
    pages={p["id"]:p for p in sources["pages"]}
    exclusions={r["page_id"]:r for r in audit["excluded"]}
    selected={p["page_id"] for p in checked["sources"]}
    capacity={"PAGE_COUNT_BOUND","INPUT_TOKEN_UPPER_BOUND"}
    eligible=[]; vetoes=[]
    for position,pid in enumerate(order):
        if pid in selected or exclusions.get(pid,{}).get("reason") in capacity:
            eligible.append(project_page(pages[pid],position))
        else:
            require(pid in exclusions,"UNACCOUNTED_INSPECTED_SOURCE")
            vetoes.append(exclusions[pid])
    chunks=[]; current=[]
    for page in eligible:
        trial=dict(base,sources=current+[page])
        if len(current)>=LIMITS["max_pages"] or token_upper_bound(trial)>LIMITS["max_input_token_upper_bound"]:
            require(bool(current),"SINGLE_ELIGIBLE_PAGE_CANNOT_FIT")
            chunks.append(current); current=[]
            require(token_upper_bound(dict(base,sources=[page]))<=LIMITS["max_input_token_upper_bound"],"SINGLE_ELIGIBLE_PAGE_CANNOT_FIT")
        current.append(page)
    if current: chunks.append(current)
    require(len(chunks)<=LIMITS["max_partitions_per_case"],"PARTITION_COUNT_BOUND")
    flattened=[p["page_id"] for chunk in chunks for p in chunk]
    eligible_ids=[p["page_id"] for p in eligible]
    require(flattened==eligible_ids and len(set(flattened))==len(flattened),"PARTITION_COVERAGE_MISMATCH")
    require(set(flattened).isdisjoint(r["page_id"] for r in vetoes),"VETOED_SOURCE_INCLUDED")
    require(len(flattened)+len(vetoes)==len(order),"INSPECTED_ACCOUNTING_MISMATCH")
    case_id=base["case"]["case_id"]
    coverage=dict(version="fresh31-source-case-coverage/2",case_id=case_id,inspected_page_order=order,
        eligible_page_order=eligible_ids,partition_page_ids=[[p["page_id"] for p in chunk] for chunk in chunks],vetoes=vetoes,
        inspected_pages=len(order),eligible_pages=len(eligible),captured_pages=len(flattened),
        captured_exactly_once=True,source_order_preserved=True,capacity_omissions=0,
        eligibility_basis="Pinned V1 ordinary-source checks. Page-count/input-budget exclusions become later partitions, not vetoes.",
        api_calls=0,native_runs=0)
    packets=[]
    for index,chunk in enumerate(chunks):
        payload=dict(base,sources=chunk); partition=dict(index=index,count=len(chunks))
        packets.append(dict(version="fresh31-source-nomination-partition/2",model_input=payload,partition=partition,
            packet_sha256=partition_hash(payload,partition),packet_sha256_contract="CANONICAL_COMPACT_ASCII_JSON_OF_MODEL_INPUT_AND_PARTITION",
            input_seal=input_seal,case_coverage_digest=digest(coverage),case_coverage_digest_contract="CANONICAL_COMPACT_ASCII_JSON_VALUE",
            input_token_upper_bound=token_upper_bound(payload),limits=LIMITS,known_answers_used=False,
            old_candidates_or_ranks_used=False,api_calls=0,native_runs=0,candidate_admission_approved=False))
    return packets,coverage


def build_partitions(case_id):
    native,sources,seal=V1.load_fresh(case_id)
    return partition_projected(native,sources,seal)


def v1_facade(packet):
    payload=dict(packet["model_input"],version="source-conditioned-input/1")
    return dict(version="fresh31-source-nomination-packet/1",model_input=payload,packet_sha256=digest(payload),input_seal={},
        selection_audit={},limits=V1.LIMITS,known_answers_used=False,old_candidates_or_ranks_used=False,
        api_calls=0,native_runs=0,candidate_admission_approved=False)


def verify_packet(packet,replay=True):
    keys={"version","model_input","partition","packet_sha256","packet_sha256_contract","input_seal","case_coverage_digest",
          "case_coverage_digest_contract","input_token_upper_bound","limits","known_answers_used","old_candidates_or_ranks_used",
          "api_calls","native_runs","candidate_admission_approved"}
    require(set(packet)==keys and packet["version"]=="fresh31-source-nomination-partition/2","UNKNOWN_V2_PACKET")
    require(encoded(packet["limits"])==encoded(LIMITS),"UNKNOWN_V2_LIMITS")
    part=packet["partition"]
    require(isinstance(part,dict) and set(part)=={"index","count"} and type(part["index"]) is int and type(part["count"]) is int
        and 0<=part["index"]<part["count"]<=256,"INVALID_PARTITION_DESCRIPTOR")
    require(packet["packet_sha256"]==partition_hash(packet["model_input"],part),"V2_PACKET_HASH_MISMATCH")
    require(packet["packet_sha256_contract"]=="CANONICAL_COMPACT_ASCII_JSON_OF_MODEL_INPUT_AND_PARTITION" and packet["case_coverage_digest_contract"]=="CANONICAL_COMPACT_ASCII_JSON_VALUE","UNKNOWN_HASH_CONTRACT")
    require(packet["model_input"]["version"]=="source-conditioned-partition-input/2","UNKNOWN_V2_INPUT")
    require(packet["input_token_upper_bound"]==token_upper_bound(packet["model_input"])<=LIMITS["max_input_token_upper_bound"],"V2_TOKEN_BOUND")
    require(packet["known_answers_used"] is False and packet["old_candidates_or_ranks_used"] is False and packet["candidate_admission_approved"] is False
        and type(packet["api_calls"]) is int and packet["api_calls"]==0 and type(packet["native_runs"]) is int and packet["native_runs"]==0,"UNAPPROVED_V2_MODE")
    V1.verify_packet(v1_facade(packet),replay=False)
    if replay:
        actual,_=build_partitions(packet["model_input"]["case"]["case_id"])
        require(part["index"]<len(actual) and encoded(actual[part["index"]])==encoded(packet),"EXACT_PARTITION_REPLAY_MISMATCH")
    return True


def request_for_packet(packet,model,replay=True):
    verify_packet(packet,replay=replay)
    require(bool(packet["model_input"]["sources"]),"NO_SOURCE_PAGES_FOR_CALL")
    request=body(packet["model_input"],packet["partition"],model)
    require(len(encoded(request))+LIMITS["framing_token_allowance"]<=LIMITS["max_input_token_upper_bound"],"BOUND_REQUEST_TOKEN_LIMIT")
    return request


def validate_response(packet,response,replay=True):
    verify_packet(packet,replay=replay)
    if isinstance(response,(bytes,str)):
        require(len(response.encode() if isinstance(response,str) else response)<=LIMITS["max_response_bytes"],"RESPONSE_BYTE_BOUND")
        response=strict_json(response)
    try: V1.Draft202012Validator(RESPONSE_SCHEMA).validate(response)
    except Exception: raise WireError("V2_RESPONSE_SCHEMA_MISMATCH") from None
    require(len(encoded(response))<=LIMITS["max_response_bytes"],"RESPONSE_BYTE_BOUND")
    V1.assert_safe(response)
    require(response["case_id"]==packet["model_input"]["case"]["case_id"] and response["packet_sha256"]==packet["packet_sha256"]
        and response["partition_index"]==packet["partition"]["index"] and response["partition_count"]==packet["partition"]["count"],"RESPONSE_PARTITION_BINDING_MISMATCH")
    facade=v1_facade(packet)
    local=dict(version="source-conditioned-nominations/1",case_id=response["case_id"],packet_sha256=facade["packet_sha256"],nominations=response["nominations"])
    receipt=V1.validate_response(facade,local,replay=False)
    return dict(version="source-nomination-partition-validation/2",case_id=response["case_id"],partition_index=response["partition_index"],
        partition_count=response["partition_count"],packet_sha256=packet["packet_sha256"],response_sha256=digest(response),
        locators=receipt["locators"],candidate_admission_approved=False,factual_support_validated=False,api_calls=0,native_runs=0)


def merge_responses(packets,responses,max_unique=20,replay=True):
    require(type(max_unique) is int and 15<=max_unique<=20,"MERGE_UNIQUE_BOUND")
    require(isinstance(packets,list) and packets,"NO_PARTITION_SET")
    ordered=sorted(packets,key=lambda p:p["partition"]["index"])
    case_id=ordered[0]["model_input"]["case"]["case_id"]
    count=ordered[0]["partition"]["count"]
    require(len(ordered)==count and [p["partition"]["index"] for p in ordered]==list(range(count)),"INCOMPLETE_PARTITION_SET")
    require(all(p["model_input"]["case"]["case_id"]==case_id and p["partition"]["count"]==count for p in ordered),"MIXED_PARTITION_CASES")
    if replay:
        actual,_=build_partitions(case_id)
        require(encoded(actual)==encoded(ordered),"EXACT_PARTITION_SET_REPLAY_MISMATCH")
    require(isinstance(responses,list) and len(responses)==count,"INCOMPLETE_RESPONSE_SET")
    by_index={}
    for r in responses:
        require(isinstance(r,dict) and type(r.get("partition_index")) is int and r["partition_index"] not in by_index,"DUPLICATE_OR_INVALID_RESPONSE_PARTITION")
        by_index[r["partition_index"]]=r
    require(set(by_index)==set(range(count)),"INCOMPLETE_RESPONSE_SET")
    merged=[]; identities={}; omitted=[]; response_refs=[]
    for packet in ordered:
        index=packet["partition"]["index"]; response=by_index[index]
        checked=validate_response(packet,response,replay=False)
        response_refs.append(dict(partition_index=index,packet_sha256=packet["packet_sha256"],response_sha256=digest(response)))
        for offset,(nomination,locator) in enumerate(zip(response["nominations"],checked["locators"])):
            identity=" ".join(unicodedata.normalize("NFKC",nomination["fill"]).casefold().split())
            if identity not in identities:
                if len(merged)>=max_unique:
                    omitted.append(dict(partition_index=index,nomination_index=offset,reason="MERGE_UNIQUE_BOUND",response_sha256=digest(response)))
                    continue
                identities[identity]=len(merged)
                merged.append(dict(fill=nomination["fill"],reading_ids=[],provenance=[],contextual_proposal_only=True,
                    candidate_admission_approved=False,factual_support_validated=False))
            entry=merged[identities[identity]]
            if nomination["reading_id"] not in entry["reading_ids"]: entry["reading_ids"].append(nomination["reading_id"])
            entry["provenance"].append(dict(partition_index=index,nomination_index=offset,reading_id=nomination["reading_id"],
                page_id=nomination["page_id"],quote=nomination["quote"],source_phrase=nomination["source_phrase"],
                transformation=nomination["transformation"],raw_locator=locator))
    result=dict(version="source-nomination-partition-merge/2",case_id=case_id,partition_count=count,max_unique=max_unique,
        nominations=merged,response_refs=response_refs,omitted=omitted,
        merge_order="PARTITION_INDEX_THEN_MODEL_ARRAY_ORDER_NOT_A_SCORE_OR_RANK",deduplication="NFKC_CASEFOLD_WHITESPACE_FILL_IDENTITY_WITH_ALL_READING_AND_SOURCE_PROVENANCE_RETAINED",
        candidate_admission_approved=False,factual_support_validated=False,api_calls=0,native_runs=0)
    require(len(encoded(result))<=LIMITS["max_merge_bytes"],"MERGE_BYTE_BOUND")
    return result


def write_new(path,value):
    path=Path(path).absolute()
    require(path.resolve()==path and path.is_relative_to(HERE),"OUTPUT_OUTSIDE_V2_OWNERSHIP")
    raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
    if path.exists(): require(path.read_bytes()==raw,"IMMUTABLE_V2_OUTPUT_DIFFERS"); return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("xb") as stream: stream.write(raw)
