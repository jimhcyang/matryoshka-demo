"""Pinned V3 validation; no mutation of any frozen module globals."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
BASE=HERE.parent/"source_nominations_v3"
V3_FREEZE_SHA="cb68320cab60df923226d57a79063a64f93e4dfec6bb52dab348b27056650178"
V3_WIRE_SHA="84d3398007b3a5f76285cb0b0af0e9e69976e9732907a2c13b38ed7dbe9bcac6"
if hashlib.sha256((BASE/"FREEZE_V3.json").read_bytes()).hexdigest()!=V3_FREEZE_SHA:
    raise RuntimeError("PINNED_V3_FREEZE_CHANGED")
if hashlib.sha256((BASE/"wire_v3.py").read_bytes()).hexdigest()!=V3_WIRE_SHA:
    raise RuntimeError("PINNED_V3_VALIDATOR_CHANGED")
spec=importlib.util.spec_from_file_location("pinned_source_validator_v3",BASE/"wire_v3.py")
W=importlib.util.module_from_spec(spec)
_old=sys.dont_write_bytecode
try:
    sys.dont_write_bytecode=True
    spec.loader.exec_module(W)
finally: sys.dont_write_bytecode=_old


def verify_dependencies():
    refs=W.verify_frozen_dependencies()
    freeze=W.strict_json((BASE/"FREEZE_V3.json").read_bytes())
    for ref in freeze["files"]:
        W.require(W.file_ref(W.DEMO/ref["path"])==ref,"FROZEN_V3_FILE_CHANGED")
    return refs+[W.file_ref(BASE/"FREEZE_V3.json")]


def write_new(path,value):
    path=Path(path).absolute()
    W.require(path.resolve()==path and path.is_relative_to(HERE),"OUTPUT_OUTSIDE_V4_OWNERSHIP")
    raw=(json.dumps(value,ensure_ascii=True,sort_keys=True,indent=2,allow_nan=False)+"\n").encode()
    if path.exists(): W.require(path.read_bytes()==raw,"IMMUTABLE_V4_OUTPUT_DIFFERS"); return
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("xb") as stream: stream.write(raw)
