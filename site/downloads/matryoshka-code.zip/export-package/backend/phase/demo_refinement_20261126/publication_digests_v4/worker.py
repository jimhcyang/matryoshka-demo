"""Fresh network-disabled canonical D3V4 replay; output storage is isolated here."""
from contextlib import redirect_stdout
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import socket
import sys
from types import FunctionType, SimpleNamespace

import helper as H

PHASE = H.HERE.parent
OWNER = PHASE / "digests_v3/v4"
FREEZE_REF = dict(path="phase/demo_refinement_20261126/digests_v3/v4/FREEZE_D3_V4.json",
    sha256="6a9dada46156325edb582011fefd4830c2688ff135776dd612724cc6138808c4")
REVIEW_REF = dict(path="phase/demo_refinement_20261126/review/digests_v3_v4/REVIEW.json",
    sha256="0ae6929555cd1142cb653cbbb61069a851421afe2e826dc2b80829ca78c557b3")
PIN_VERSION = "selected-reviewed-source-digest-public-pin/2"
R_METHOD = "source_realized_redaction_v1"
CONFIG = "llm_readings"
PIN_FIELDS = ("input_sha256", "generation_sha256", "body_sha256", "raw_response_wire_sha256",
              "response_value_sha256", "api_receipt_wire_sha256")


def runtime():
    freeze, review = H.checked(FREEZE_REF), H.checked(REVIEW_REF)
    H.require(review["version"] == "source-method-digest-parent-independent-review/4"
        and review["status"] == "GO" and review["paid_source_digest_boundary_cleared"] is True
        and review["source_freeze_ref"] == FREEZE_REF, "EXACT_D3V4_INDEPENDENT_BOUNDARY_REQUIRED")
    for ref in review["owner_code_refs"] + freeze["files"]:
        H.require(H.reference(H.ROOT / ref["path"]) == ref, "FROZEN_DIGEST_CODE_CHANGED")
    sys.path[:0] = [str(OWNER), str(H.ROOT)]
    import boundary
    D = boundary.D
    H.require(Path(D.__file__).resolve() == OWNER / "builder.py" and D.VERSION == "selected-reviewed-source-digest/3.4",
        "EXPLICIT_D3V4_RUNTIME_REQUIRED")
    return SimpleNamespace(D=D, W=write_adapter(D), trusted_guard=boundary.trusted_guard,
        freeze=freeze, review=review, ready=H.checked(freeze["actual_preparation_ref"]))


def write_adapter(D):
    """Reuse exact writer bytecode in a PRIVATE namespace; never mutate D globals.

    Only storage HERE and the three write entry points differ. All source,
    provider, funding, hashing and read validators remain original callables.
    """
    scope = dict(D.__dict__, HERE=H.HERE)
    for name in ("put", "prepare", "capture_generation"):
        original = getattr(D, name)
        scope[name] = FunctionType(original.__code__, scope, name, original.__defaults__, original.__closure__)
        scope[name].__kwdefaults__ = original.__kwdefaults__
    return SimpleNamespace(**{name: scope[name] for name in ("put", "prepare", "capture_generation")})


def same(actual, expected, code):
    H.require(H.encoded(actual) == H.encoded(expected), code)


def pin(response, row):
    H.require(response.get("version") == "selected-reviewed-source-digest/3.4/public"
        and response.get("available") is True and response.get("used_for_inference") is False,
        "ACTUAL_D3V4_PUBLIC_RESPONSE_REQUIRED")
    return dict(version=PIN_VERSION, digest_version="selected-reviewed-source-digest/3.4/public",
        condition_ref_sha256=row["configurations"][CONFIG]["condition_ref"]["sha256"],
        text_sha256=H.digest(response["text"]),
        binding={key: deepcopy(value) for key, value in response["binding"].items() if key != "report_sha256"},
        **{key: response[key] for key in PIN_FIELDS})


def population(report, keys, methods):
    H.require(report.get("version") == "narrative-workbench-publication/1"
        and 1 <= len(report["cases"]) <= 32, "REPORT_VERSION_OR_POPULATION_CHANGED")
    by_id = {row["case"]["case_id"]: row for row in report["cases"]}
    H.require(len(by_id) == len(report["cases"]), "DUPLICATE_REPORT_CASE")
    supported, unsupported = set(), set()
    for cid, row in by_id.items():
        source = row.get("reviewed_source_assessment")
        if not source:
            H.require("reviewed_source_digest" not in row, "DIGEST_WITHOUT_SUPPORTED_SOURCE_METHOD")
            continue
        if source["method_id"] in methods:
            H.require(row["case"]["task"] in {"mosaic", "hypothesis"}
                and CONFIG in row["configurations"], "SUPPORTED_SOURCE_TASK_OR_CONFIG_CHANGED")
            supported.add(cid + "/" + CONFIG)
        else:
            H.require(source["method_id"] == R_METHOD and row["case"]["task"] == "redaction"
                and "reviewed_source_digest" not in row, "UNSUPPORTED_SOURCE_METHOD_HAS_DIGEST_OR_UNKNOWN_TYPE")
            unsupported.update(cid + "/" + config for config in row["configurations"])
    H.require(supported == set(keys) and len(supported) == 6, "ALL_SIX_SUPPORTED_SOURCE_METHODS_REQUIRED")
    return by_id, unsupported


def load_results(R, results_ref, guard, contexts):
    D = R.D
    results = H.checked(results_ref)
    path = H.ROOT / results_ref["path"]
    H.require(path.name == "RESULTS.json" and path.parent.parent == PHASE / "source_digest_runs_v4",
        "EXPLICIT_PARENT_V4_RESULTS_PATH_REQUIRED")
    auth = H.checked(H.reference(path.parent / "AUTHORIZATION.json"))
    H.require(auth["version"] == "parent-source-digest-authorization/4"
        and auth["preparation_ready_ref"] == R.freeze["actual_preparation_ref"]
        and auth["review_ref"] == REVIEW_REF and auth["runner_ref"] == R.review["runner_ref"]
        and type(auth["maximum_calls"]) is int and auth["maximum_calls"] == 6
        and type(auth["incremental_ceiling_usd"]) in {int, float} and auth["incremental_ceiling_usd"] == 4.
        and type(auth["aggregate_ceiling_usd"]) in {int, float} and auth["aggregate_ceiling_usd"] == 50.
        and auth["no_native_fallback"] is True and auth["postrun"] is True,
        "PARENT_FUNDING_AND_EXACT_REVIEW_BINDING_REQUIRED")
    keys = set(R.ready["entries"])
    H.require(results["version"] == "parent-source-digest-results/4" and results["complete"] is True
        and results["no_native_fallback"] is True and set(results["cases"]) == keys
        and len(keys) == 6 and results["index_ref"] is not None, "COMPLETE_SIX_ACTUAL_DIGESTS_REQUIRED_NO_FAILURE_DROP")
    index = D.read(results["index_ref"])
    D.check_seal(index, D.VERSION + "/index")
    same(index["report_ref"], R.ready["report_ref"], "ORIGINAL_INDEX_REPORT_CHANGED")
    H.require(index["complete_selected_source_methods"] is True and set(index["entries"]) == keys,
        "COMPLETE_ORIGINAL_SOURCE_INDEX_REQUIRED")
    generations = {}
    for key in sorted(keys):
        item = results["cases"][key]
        H.require(item["status"] == "SAVED_SOURCE_METHOD_DIGEST", "RETAINED_FAILED_GENERATION_CANNOT_BE_EXCLUDED")
        same(item["preparation_ref"], R.ready["entries"][key]["preparation_ref"], "ORIGINAL_PREPARATION_CHANGED")
        envelope = D.read(index["entries"][key])
        D.check_seal(envelope, D.VERSION + "/attachment")
        same(envelope["generation_ref"], item["generation_ref"], "ORIGINAL_GENERATION_CHANGED")
        same(envelope["preparation_ref"], item["preparation_ref"], "ORIGINAL_ATTACHMENT_PREPARATION_CHANGED")
        # This is only intake. No pin/index can return until prepare_and_capture
        # runs the ORIGINAL complete source + raw-provider validators below.
        generation = D.read(item["generation_ref"])
        D.check_seal(generation, D.VERSION + "/generation")
        same(item["actual_output"], dict(digest=generation["text"]), "RESULT_OUTPUT_DIFFERS_FROM_ACTUAL_PROVIDER")
        H.require(generation["sha256"] == envelope["generation_sha256"], "ORIGINAL_ATTACHMENT_GENERATION_HASH_CHANGED")
        generations[key] = generation
    return results, generations


def same_request(D, request, generation, original_preparation):
    raw_request = D.read(generation["request_ref"])
    same(request["body"], raw_request, "SAME_SAVED_REQUEST_BODY_REQUIRED_NO_PAY_OR_FALLBACK")
    H.require(D.digest(request["body"]) == generation["body_sha256"] == original_preparation["actual_http_sha256"]
        and len(D.encoded(request["body"])) == original_preparation["actual_http_bytes"]
        and request["max_input_upper"] == 262144
        and request["exact_call_profile"] == "source_assessment_fullpool_v2"
        and request["execution_contract"] == "phase-exact-api/2", "EXACT_SAVED_HTTP_BYTES_AND_PROFILE_REQUIRED")


def prepare_and_capture(R, report_ref, results, generations, guard, contexts):
    D, W = R.D, R.W
    report = D.N.load_report(report_ref)
    by_id, unsupported = population(report, results["cases"], D.METHODS)
    preparations, rebound, pin_values = {}, {}, {}
    for key in sorted(results["cases"]):
        cid, config = key.rsplit("/", 1)
        old = D.read(results["cases"][key]["preparation_ref"])
        prep = W.prepare(report_ref, cid, config, public_view_ref=old["public_view_ref"],
            guard=guard, contexts=contexts, profile=old["transport_profile"])
        prepared = D.read(prep)
        D.check_seal(prepared, D.VERSION + "/preparation")
        same(prepared["report_ref"], report_ref, "FRESH_PREPARATION_REPORT_CHANGED")
        # prepare() just fully replayed the source authority. Its sealed input is
        # read by byte ref, not accepted as an external flags-only source proof.
        payload = D.read(prepared["input_ref"])
        H.require(D.digest(payload) == prepared["input_sha256"], "FRESH_PREPARATION_INPUT_CHANGED")
        body = D.api_body(payload, model=generations[key]["model"], profile=prepared["transport_profile"])
        request = dict(body=body, max_input_upper=prepared["max_input_upper"],
            exact_call_profile=D.EXACT_PROFILES[prepared["transport_profile"]][0],
            execution_contract=D.EXACT_PROFILES[prepared["transport_profile"]][1])
        generation = generations[key]
        same_request(D, request, generation, R.ready["entries"][key])
        new = W.capture_generation(report_ref, prep, guard=guard, contexts=contexts,
            **{name: generation[name] for name in ("request_ref", "raw_response_ref", "api_receipt_ref")})
        same(D.read(new), generation, "REPORT_INDEPENDENT_GENERATION_CHANGED")
        preparations[key], rebound[key] = prep, new
        pin_values[key] = dict(version=D.VERSION + "/public", available=True, used_for_inference=False,
            text=generation["text"], binding=dict(prepared["binding"], **prepared["presentation"]),
            **{name: prepared["input_sha256"] if name == "input_sha256" else
                generation["sha256"] if name == "generation_sha256" else generation[name] for name in PIN_FIELDS})
    return report, preparations, rebound, pin_values, unsupported


def emit_index(R, report_ref, preparations, generations, unsupported):
    """Transport bookkeeping from fully validated local values, not new authority.

    Exact original D3 attachment/index schema. Public reads still invoke the
    unchanged full read_for_case source/provider validation, never this helper
    as a support certificate.
    """
    D, W = R.D, R.W
    H.require(set(preparations) == set(generations) and len(preparations) == 6, "COMPLETE_VALIDATED_SIX_BEFORE_INDEX")
    entries = {}
    for key, prep_ref in preparations.items():
        prep, generation = D.read(prep_ref), D.read(generations[key])
        D.check_seal(prep, D.VERSION + "/preparation")
        D.check_seal(generation, D.VERSION + "/generation")
        same(prep["binding"], generation["binding"], "VALIDATED_GENERATION_BINDING_CHANGED")
        envelope = D.seal(dict(version=D.VERSION + "/attachment", kind=D.KIND, report_ref=deepcopy(report_ref),
            preparation_ref=prep_ref, generation_ref=generations[key], binding=prep["binding"],
            presentation=prep["presentation"], generation_sha256=generation["sha256"], postrun=True, used_for_inference=False))
        entries[key] = W.put(H.HERE / "attachments" / report_ref["sha256"] / (envelope["sha256"] + ".json"), envelope)
    index = D.seal(dict(version=D.VERSION + "/index", kind=D.KIND, report_ref=deepcopy(report_ref), entries=entries,
        complete_selected_source_methods=not unsupported, omitted_selected_keys=sorted(unsupported),
        no_native_fallback=True, postrun=True, used_for_inference=False))
    return W.put(H.HERE / "indexes" / report_ref["sha256"] / (index["sha256"] + ".json"), index)


def set_as_list(value):
    return sorted(set(value))


def dispatch(args):
    R = runtime()
    D = R.D
    operation = args["operation"]
    with D.D2.SourceContexts() as contexts:
        with R.trusted_guard(contexts) as (guard, replay):
            if operation in {"attach", "bind"}:
                results, generations = load_results(R, args["results_ref"], guard, contexts)
                if operation == "attach":
                    report = deepcopy(args["report"])
                    H.require("sha256" not in report, "ATTACH_BEFORE_REPORT_SEAL")
                    population(report, results["cases"], D.METHODS)
                    provisional = D.N.sealed(report)
                    provisional_ref = H.save(H.HERE / "provisional_reports" / (H.digest(provisional) + ".json"), provisional)
                    _, _, _, responses, _ = prepare_and_capture(R, provisional_ref, results, generations, guard, contexts)
                    for row in report["cases"]:
                        key = row["case"]["case_id"] + "/" + CONFIG
                        if key in responses:
                            row["reviewed_source_digest"] = pin(responses[key], row)
                    return report
                report, preparations, rebound, responses, unsupported = prepare_and_capture(
                    R, args["report_ref"], results, generations, guard, contexts)
                for row in report["cases"]:
                    key = row["case"]["case_id"] + "/" + CONFIG
                    if key in responses:
                        same(row.get("reviewed_source_digest"), pin(responses[key], row), "SEALED_REPORT_PIN_CHANGED_NO_POSTSEAL_REPAIR")
                return emit_index(R, args["report_ref"], preparations, rebound, unsupported)
            H.require(operation == "public", "CLOSED_HELPER_OPERATION")
            report = D.N.load_report(args["report_ref"])
            population(report, R.ready["entries"], D.METHODS)
            row = next((row for row in report["cases"] if row["case"]["case_id"] == args["row"]["case"]["case_id"]), None)
            same(args["row"], row, "EXACT_SEALED_REPORT_ROW_REQUIRED")
            source = row["reviewed_source_assessment"]
            H.require(source["method_id"] in D.METHODS and row["case"]["task"] in {"mosaic", "hypothesis"},
                "NO_R_OR_NATIVE_DIGEST_FALLBACK")
            value = D.read_for_case(args["index_ref"], args["report_ref"], row["case"]["case_id"], CONFIG,
                method_id=source["method_id"], original_view_sha256=source["original_view_sha256"],
                public_view_sha256=source["public_view_sha256"], guard=guard, contexts=contexts)
            expected_request = R.ready["entries"][row["case"]["case_id"] + "/" + CONFIG]
            H.require(value["body_sha256"] == expected_request["actual_http_sha256"], "PUBLIC_RESPONSE_NOT_THE_EXACT_APPROVED_BODY")
            same(row.get("reviewed_source_digest"), pin(value, row), "CURRENT_PUBLIC_DIGEST_PIN_CHANGED")
            return value


def main():
    def forbidden(*args, **kwargs):
        raise RuntimeError("DIGEST_PUBLICATION_API_AND_NETWORK_FORBIDDEN")
    for owner, key in ((socket, "create_connection"), (socket, "getaddrinfo"),
                       (socket.socket, "connect"), (socket.socket, "connect_ex")):
        setattr(owner, key, forbidden)
    args = H.parse(sys.stdin.buffer.read())
    with redirect_stdout(sys.stderr):
        value = dispatch(args)
    sys.stdout.buffer.write(H.encoded(value))


if __name__ == "__main__":
    main()
