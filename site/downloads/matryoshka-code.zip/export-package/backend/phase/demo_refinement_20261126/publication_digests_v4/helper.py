"""API0 D3V4 report pinning/rebinding. No parent, UI, stage or native writes."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def require(condition, code):
    if not condition:
        raise ValueError(code)


def _unique(rows):
    result = {}
    for key, value in rows:
        require(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=_unique,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("NONFINITE_JSON")))


def reference(path):
    path = Path(path)
    return dict(path=path.relative_to(ROOT).as_posix(), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def checked(ref):
    require(isinstance(ref, dict) and set(ref) == {"path", "sha256"}, "CLOSED_REFERENCE_REQUIRED")
    relative = ref["path"]
    require(isinstance(relative, str) and relative and "\\" not in relative
        and not Path(relative).is_absolute() and all(p not in {"", ".", ".."} for p in relative.split("/")), "UNSAFE_REFERENCE")
    path = ROOT / relative
    require(path.resolve(strict=True) == path and reference(path) == ref, "REFERENCE_CHANGED_OR_LINKED")
    return parse(path.read_bytes())


def save(path, value):
    path = Path(path)
    require(path.resolve() == path and path.is_relative_to(HERE), "HELPER_OWNED_WRITES_ONLY")
    raw = encoded(value)
    if path.exists():
        require(path.read_bytes() == raw, "IMMUTABLE_HELPER_OUTPUT_DIFFERS")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(raw)
    return reference(path)


def _worker(operation, **kwargs):
    result = subprocess.run([sys.executable, "-B", str(HERE / "worker.py")],
        input=encoded(dict(operation=operation, **kwargs)), capture_output=True, cwd=ROOT, timeout=900)
    require(result.returncode == 0, "DIGEST_REBIND_HELD: " + result.stderr.decode(errors="replace")[-3000:])
    return parse(result.stdout)


def attach_pins(report, results_ref):
    """Return an unsealed COPY with exact report-independent pins on all six M/H rows."""
    require("sha256" not in report, "ATTACH_BEFORE_REPORT_SEAL_REMOVE_INHERITED_HASH_FIRST")
    return _worker("attach", report=report, results_ref=results_ref)


def bind_report(report_ref, results_ref):
    """API0 canonical reprepare/rebind of existing generation bytes; return fresh index ref."""
    return _worker("bind", report_ref=report_ref, results_ref=results_ref)


def public_response(index_ref, report_ref, row):
    """Return exact D3V4 read_for_case JSON for this exact sealed report row, no fallback."""
    return _worker("public", index_ref=index_ref, report_ref=report_ref, row=row)
