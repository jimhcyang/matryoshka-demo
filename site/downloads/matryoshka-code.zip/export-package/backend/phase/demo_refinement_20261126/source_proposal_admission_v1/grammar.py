"""Bounded local syntax diagnostics, not fabricated legacy source certificates."""
from copy import deepcopy

from common import digest,require
from matryoshka_narrative import construction as C,controller_role
from matryoshka_next import readings

SUPPORTED_FINAL={'nominal','adjectival','prepositional','nominal_specifier'}


def evaluate(case,reading,proposal,proof,page,review,parse):
    fill=proposal['fill'];left,right=case['query'].split(case['focal_marker']);completed=left+fill+right
    require(proof['completed_input']==completed and proof['completed_input_sha256']==digest(completed),
        'FULL_COMPLETED_PUBLIC_INPUT_CHANGED')
    checks=[];diagnostics=[];holds=[]
    def check(name,passed,details):
        checks.append(dict(name=name,state='pass'if passed else 'hold',details=deepcopy(details)))
        if not passed:holds.append(name)
    check('separate_review_grammar_and_category',review['grammar']==review['category']=='FITS',review)
    doc=parse(completed)
    require(doc.text==completed,'GRAMMAR_PARSER_REWROTE_PUBLIC_INPUT')
    span=doc.char_span(len(left),len(left)+len(fill),alignment_mode='strict')
    boundary=bool(span is not None and fill and fill.strip()==fill)
    check('literal_completed_insertion_boundaries',boundary,dict(inserted_span=[len(left),len(left)+len(fill)],
        completed_input_sha256=digest(completed),outside_slot_bytes_unchanged=True))
    legacy=None
    if boundary:
        if reading.get('constructor_form')is not None and reading['outer_family']in SUPPORTED_FINAL:
            try:
                value=C.final_form_fit(case,reading,fill,parse)
                check('applicable_existing_final_form_fit',value['state']=='pass',value)
            except (KeyError,ValueError,LookupError,OSError,TypeError)as error:
                check('applicable_existing_final_form_fit',False,dict(error_type=type(error).__name__,reason='RESOURCE_OR_EXACT_READING_UNAVAILABLE'))
        else:diagnostics.append(dict(helper='final_form_fit',state='unsupported',pos_proof_claimed=False,
            reason='NEW_METHOD_FAMILY_REQUIRES_SEPARATE_REVIEW_AND_LITERAL_BOUNDARIES'))
        try:legacy=readings.constructor_view(reading,case)
        except (KeyError,ValueError):
            diagnostics.append(dict(helper='completed_slot_fit',state='unsupported',reason='NO_EXACT_LEGACY_CONSTRUCTOR_VIEW',
                native_source_frame_or_certificate_created=False))
        if legacy is not None:
            if legacy['form']=='modifier':
                diagnostics.append(dict(helper='completed_slot_fit',state='unsupported',
                    reason='NATIVE_SOURCE_PROPERTY_FRAME_NOT_AVAILABLE_FOR_NEW_METHOD',positive_source_frame_invented=False))
            else:
                # Only literal fill arguments: no fake native ID, score, type or source-frame DTO.
                try:
                    value=C.completed_slot_fit(case,legacy,{'fill':fill},parse)
                    check('applicable_existing_completed_slot_fit',value['state']=='pass',value)
                except (KeyError,ValueError,LookupError,OSError,TypeError)as error:
                    check('applicable_existing_completed_slot_fit',False,dict(error_type=type(error).__name__))
        if reading.get('outer_family')=='nominal'and reading.get('role')=='patient_argument':
            try:
                wordnet=C.shared.roles.lexicon()
                frame=controller_role.query_controller_frame(case,reading,parse=parse,wordnet=wordnet)
                if frame.state=='not_applicable':diagnostics.append(dict(helper='controller',state='not_applicable',reason=frame.reason))
                elif proposal['transformation']['kind']!='UNCHANGED':
                    check('literal_controller_binding',False,dict(state='hold',reason='TRANSFORMED_FILL_HAS_NO_LITERAL_CONTROLLER_LICENSE'))
                else:
                    a,b=proof['phrase_span']['start'],proof['phrase_span']['end']
                    insertion=controller_role.SourceInsertion(fill=fill,text=page['text'],start=a,end=b,
                        canonical_page_id=page['id'],document_id=page['document_id'],source_sha256=page['source_sha256'])
                    value=controller_role.check_completed_insertion(case,reading,insertion,parse=parse,
                        wordnet=wordnet,noun_resource=parse.noun_resource).as_dict()
                    check('applicable_literal_controller',value['state']in{'compatible','not_applicable'},value)
            except (KeyError,ValueError,LookupError,OSError,TypeError,AttributeError)as error:
                check('applicable_literal_controller',False,dict(state='hold',error_type=type(error).__name__))
        else:diagnostics.append(dict(helper='controller',state='not_applicable',reason='NOT_DECLARED_NOMINAL_PATIENT_ARGUMENT'))
    return dict(version='reviewed-source-proposal-local-grammar/1',eligible=not holds,holds=holds,
        applicable_checks=checks,unsupported_diagnostics=diagnostics,
        local_grammatical_fit=sum(c['state']=='pass'for c in checks)/len(checks),
        completed_input_sha256=digest(completed),reading_sha256=digest(reading),
        local_fit_is_not_native_fit=True,native_DTO_or_POS_license_created=False,
        full_grammar_basis='SEPARATE_REVIEW_PLUS_LITERAL_BOUNDARIES_AND_APPLICABLE_LOCAL_CHECKS',factual_support_certified=False)
