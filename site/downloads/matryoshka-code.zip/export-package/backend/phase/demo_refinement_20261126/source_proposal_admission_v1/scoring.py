"""V8-style own-page/novelty content features; separate new-method grammar fit."""
import math

from common import digest,require
from matryoshka_narrative.context_rank_v8 import Ranker
from matryoshka_narrative.context_relevance import focal_sentence

VERSION='source-proposal-context-priority/1'
WEIGHTS=(.55,.25,.20)


def score(case,reading,fill,page,grammar,parse,*,bindings):
    require(grammar['eligible']is True and grammar['factual_support_certified']is False,'LOCAL_GRAMMAR_HOLD')
    ranker=Ranker(parse)
    focal=focal_sentence(case['query'],case['focal_marker'],parse)
    wanted=set(ranker.terms(focal['text']));source=set(ranker.terms(page['text']))
    content=set(ranker.terms(fill));visible=set(ranker.terms(case['query']));matched=source&wanted;repeated=content&visible
    local=grammar['local_grammatical_fit']
    coverage=len(matched)/len(wanted)if wanted else 0.
    novelty=len(content-repeated)/len(content)if content else 0.
    components=dict(own_page_focal=.55*coverage,local_grammatical_fit=.25*local,lexical_novelty=.20*novelty)
    card=dict(version=VERSION,weights=list(WEIGHTS),score=sum(components.values()),score_units='CONTEXT_PRIORITY_NOT_PROBABILITY',
        raw_features=dict(own_page_focal_coverage=coverage,local_grammatical_fit=local,nonrepeated_content_fraction=novelty),
        components=components,focal_query_span=focal,focal_terms=sorted(wanted),matched_focal_terms=sorted(matched),
        candidate_content_terms=sorted(content),visible_content_terms=sorted(visible),repeated_visible_content_terms=sorted(repeated),
        own_page=dict(canonical_page_id=page['id'],document_id=page['document_id'],date=page['date'],page_sha256=page['source_sha256']),
        bindings=dict(bindings,query_sha256=digest(case['query']),reading_sha256=digest(reading),
            completed_input_sha256=digest(case['query'].replace(case['focal_marker'],fill)),grammar_sha256=digest(grammar)),
        probability=False,native_tier_assigned=False,source_positive_B_added=False,support_or_event_or_identity_certified=False,
        formula='.55*own_page_focal_coverage + .25*local_grammatical_fit + .20*nonrepeated_content_fraction',
        local_fit_origin='NEW_METHOD_APPLICABLE_GRAMMAR_CHECKS_NOT_FABRICATED_OLD_NATIVE_FIT',source_page_union_used=False)
    replay(card,grammar)
    return card


def replay(card,grammar):
    require(set(card)=={'version','weights','score','score_units','raw_features','components','focal_query_span','focal_terms',
        'matched_focal_terms','candidate_content_terms','visible_content_terms','repeated_visible_content_terms','own_page','bindings',
        'probability','native_tier_assigned','source_positive_B_added','support_or_event_or_identity_certified','formula',
        'local_fit_origin','source_page_union_used'},'CLOSED_CONTEXT_SCORECARD')
    require(card['version']==VERSION and card['weights']==list(WEIGHTS)and card['score_units']=='CONTEXT_PRIORITY_NOT_PROBABILITY',
        'CONTEXT_PRIORITY_VERSION_OR_WEIGHTS')
    require(card['probability']is False and card['native_tier_assigned']is False and card['source_positive_B_added']is False
        and card['support_or_event_or_identity_certified']is False and card['source_page_union_used']is False,'NO_EVIDENCE_OR_PROBABILITY_AUTHORITY')
    raw=card['raw_features']
    require(set(raw)=={'own_page_focal_coverage','local_grammatical_fit','nonrepeated_content_fraction'},'CLOSED_CONTEXT_FEATURES')
    require(all(type(v)in(int,float)and math.isfinite(v)and 0<=v<=1 for v in raw.values()),'FINITE_BOUNDED_CONTEXT_FEATURES')
    require(grammar['eligible']is True and digest(grammar)==card['bindings']['grammar_sha256'],'EXACT_LOCAL_GRAMMAR_BINDING')
    checks=grammar['applicable_checks']
    names=[c['name']for c in checks]
    require(len(set(names))==len(names)and{'separate_review_grammar_and_category','literal_completed_insertion_boundaries'}<=set(names)
        and not grammar['holds']and all(c['state']=='pass'for c in checks)
        and raw['local_grammatical_fit']==grammar['local_grammatical_fit']==sum(c['state']=='pass'for c in checks)/len(checks),
        'GRAMMAR_FEATURE_NOT_REVIEW_AND_BOUNDARY_BOUND')
    wanted=card['focal_terms'];matched=card['matched_focal_terms'];content=card['candidate_content_terms'];repeated=card['repeated_visible_content_terms']
    require(all(v==sorted(set(v))for v in(wanted,matched,content,repeated,card['visible_content_terms']))
        and set(matched)<=set(wanted)and set(repeated)==set(content)&set(card['visible_content_terms']),'EXACT_CONTENT_TERM_SETS')
    expected_raw=dict(own_page_focal_coverage=len(matched)/len(wanted)if wanted else 0.,
        local_grammatical_fit=grammar['local_grammatical_fit'],nonrepeated_content_fraction=(len(content)-len(repeated))/len(content)if content else 0.)
    require(raw==expected_raw,'CONTEXT_FEATURE_ARITHMETIC')
    components=dict(own_page_focal=.55*raw['own_page_focal_coverage'],local_grammatical_fit=.25*raw['local_grammatical_fit'],
        lexical_novelty=.20*raw['nonrepeated_content_fraction'])
    require(set(card['components'])==set(components)and all(type(card['components'][k])in(int,float)
        and math.isfinite(card['components'][k])and abs(card['components'][k]-v)<=1e-12 for k,v in components.items())
        and type(card['score'])in(int,float)and math.isfinite(card['score'])and abs(card['score']-sum(components.values()))<=1e-12,
        'CONTEXT_PRIORITY_COMPONENT_MATH')
    return sum(components.values())
