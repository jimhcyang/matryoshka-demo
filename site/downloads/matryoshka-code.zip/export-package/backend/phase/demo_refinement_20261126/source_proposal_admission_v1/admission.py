"""New reviewed-context candidate packets; never a native result/legacy DTO."""
from copy import deepcopy

from common import digest,require,sha
from executor_adapter import backend
import grammar as G
import scoring as S

VERSION='source-reviewed-realized-admission/1'


def admit_observation(observation,*,parser):
    observation.validate();R=backend();Q=R.Q
    case,plan=observation.case,observation.plan
    readings=plan['readings_packet']['readings'];known={r['id']:r for r in readings}
    projected={r['id']:r for r in Q.P.project_readings(plan['readings_packet'],case)}
    require(len(known)==len(readings),'DISTINCT_ORIGINAL_READINGS_REQUIRED')
    before=observation.seal;by_reading={rid:[]for rid in known}
    for request in observation.requests:
        data,binding=Q.verify_packet(request['packet']);rid=data['reading']['id']
        require(data['case']==case and projected.get(rid)==data['reading'],'EXACT_CASE_READING_REQUIRED')
        for page in data['sources']:
            actual=observation.pages.get(page['page_id'])
            ids=observation.bindings['inspected_page_ids']
            require(actual is not None and page['page_id']in ids
                and page==R.W.V2.project_page(actual,ids.index(page['page_id'])),
                'REQUEST_SOURCE_NOT_ACTUAL_CANONICAL_CAPTURE')
        by_reading[rid].append(request)
    outputs=[];all_admitted=[]
    for rid,reading in known.items():
        requests=sorted(by_reading[rid],key=lambda r:r['ticket']['partition_index'])
        held=[];duplicates=[];deferred=[];admitted=[];seen=set();checked=0
        counts=[r['ticket']['partition_count']for r in requests]
        complete=bool(requests)and len(set(counts))==1 and len(requests)==counts[0]
        complete=complete and[r['ticket']['partition_index']for r in requests]==list(range(len(requests)))
        complete=complete and all(r['status']=='REVIEWED_CONTEXTUAL_ONLY'for r in requests)
        if not complete:
            outputs.append(dict(reading=deepcopy(reading),status='HOLD_INCOMPLETE_READING_REVIEWS',candidates=[],
                request_states=[dict(request_key=r['request_key'],status=r['status'])for r in requests]))
            continue
        for request in requests:
            packet=request['packet'];data,_=Q.verify_packet(packet)
            local=Q.validate_response(packet,request['proposal_response'])
            reviewed=Q.validate_review(Q.review_packet(packet,request['proposal_response']),request['review_response'])
            require(local==request['local_validation']and reviewed==request['review_validation'],'SOURCE_REVIEW_REPLAY_CHANGED')
            held.extend(dict(request_key=request['request_key'],reason='INVALID_SOURCE_PROPOSAL_ROW',detail=r)for r in local['invalid_rows'])
            valid={r['proposal']['proposal_id']:r for r in local['valid_rows']}
            for row in reviewed['rows']:
                proposal=row['proposal'];identity=' '.join(proposal['fill'].casefold().split())
                if not row['accepted_contextual_nomination']:
                    held.append(dict(request_key=request['request_key'],proposal=deepcopy(proposal),reason='SEPARATE_REVIEW_HOLD_OR_REJECT',review=row['review']));continue
                if identity in seen:
                    duplicates.append(dict(request_key=request['request_key'],proposal=deepcopy(proposal),
                        reason='SAME_SURFACE_ONLY_NO_IDENTITY_OR_EVIDENCE_MERGE'));continue
                seen.add(identity)
                if checked==8:
                    deferred.append(dict(request_key=request['request_key'],proposal=deepcopy(proposal),reason='EIGHT_DISTINCT_LOCAL_CHECK_CAP'));continue
                checked+=1;proof=valid[proposal['proposal_id']]['proof'];page=observation.pages[proposal['page_id']]
                try:
                    fit=G.evaluate(case,reading,proposal,proof,page,row['review'],parser)
                    if not fit['eligible']:
                        held.append(dict(request_key=request['request_key'],proposal=deepcopy(proposal),reason='LOCAL_GRAMMAR_OR_CONTROLLER_HOLD',grammar=fit));continue
                    provenance=dict(request_key=request['request_key'],ticket=deepcopy(request['ticket']),
                        proposal_id=proposal['proposal_id'],proposal_response_sha256=digest(request['proposal_response']),
                        review_response_sha256=digest(request['review_response']),attestations=deepcopy(request['attestations']),
                        source_proof_ref=observation.bindings['source_proof_ref'],source_index_ref=observation.bindings['source_index_ref'],
                        source_view_policy=observation.bindings['source_view_policy'],native_ref=observation.bindings['native_ref'])
                    cid='source_reviewed_fill_'+digest([VERSION,case,rid,proposal,provenance])[:28]
                    card=S.score(case,reading,proposal['fill'],page,fit,parser,bindings=dict(candidate_id=cid,
                        observation_sha256=before,plan_sha256=digest(plan),source_phrase_sha256=digest(proof['phrase_span']),
                        exact_quote_sha256=digest(proof['quote_span']),provenance_sha256=digest(provenance)))
                    candidate=dict(id=cid,method=VERSION,reading_id=rid,fill=proposal['fill'],
                        state='REVIEWED_CONTEXTUAL_SOURCE_CANDIDATE_NOT_NATIVE_EVIDENCE',
                        declared_reading=deepcopy(reading),completed_input=proof['completed_input'],
                        completed_input_sha256=proof['completed_input_sha256'],
                        completed_input_utf8_sha256=sha(proof['completed_input'].encode()),
                        source=dict(page_id=page['id'],document_id=page['document_id'],date=page['date'],page_sha256=page['source_sha256'],
                            exact_quote=proof['quote_span'],original_phrase=proof['phrase_span'],qualification_paragraph=proof['qualification_paragraph']),
                        transformation=deepcopy(proposal['transformation']),source_review=deepcopy(row['review']),
                        grammar=fit,context_priority=card,provenance=provenance,
                        native_DTO_or_certificate_created=False,legacy_source_license_claimed=False,
                        source_positive_B_added=False,factual_support_certified=False,native_tier_assigned=False)
                    admitted.append(candidate)
                except (ValueError,LookupError,OSError,KeyError,TypeError)as error:
                    held.append(dict(request_key=request['request_key'],proposal=deepcopy(proposal),reason='LOCAL_CHECK_UNAVAILABLE_OR_HOLD',
                        error_type=type(error).__name__,error=str(error)[:180]))
        admitted.sort(key=lambda c:(-c['context_priority']['score'],c['id']))
        for rank,c in enumerate(admitted,1):c['rank_within_new_method']=rank
        outputs.append(dict(reading=deepcopy(reading),status='CONTEXTUAL_CANDIDATES'if admitted else 'NO_ADMITTED_CONTEXTUAL_CANDIDATES',
            candidates=admitted,holds=held,duplicate_surface_variants=duplicates,deferred=deferred,
            distinct_local_checks=checked,maximum_candidates=8,missing_candidate_is_not_factual_rejection=True))
        all_admitted.extend(admitted)
    observation.validate();require(before==observation.seal,'SOURCE_INPUT_CHANGED_DURING_ADMISSION')
    return dict(version=VERSION,scope='NEW_SOURCE_REALIZED_CONTEXT_METHOD_NOT_NATIVE_INFERENCE',case=deepcopy(case),
        source_bindings=deepcopy(observation.bindings),observation_sha256=before,readings=outputs,
        admitted_count=len(all_admitted),actual_executor_receipts=observation.bindings['actual_receipts_replayed'],
        legacy_native=dict(native_ref=observation.bindings['native_ref'],native_checksum=observation.bindings['native_checksum'],
            preserved_whole_by_reference=True,candidates_or_tiers_modified=False,merged_with_new_method=False),
        native_runs=0,API_calls=0,source_positive_B_added=False,factual_support_certified=False,
        existing_native_success_or_recovery_claim=False,context_priority_is_not_confidence=True)


def verify_packet(packet,observation,*,parser):
    """Deep semantic replay, including every field, with no fixed-subset waiver."""
    expected=admit_observation(observation,parser=parser)
    require(digest(packet)==digest(expected),'ADMISSION_PACKET_SEMANTIC_REPLAY_DIFFERS')
    return True
