"""Read-only exact V7 executor/result/source attestation, never its sender."""
from copy import deepcopy
from dataclasses import dataclass
import importlib.util
from pathlib import Path
import sys
from types import SimpleNamespace

from common import HERE,SRC,require,file_sha,digest

EXECUTOR=HERE.parent/'source_proposals_v7/executor_v1'
EXECUTOR_FREEZE_SHA='6d960eaec421d50a10acb999b4376e7a4d531908680f0ecb2e63f3ccf932877c'
RUNNER_SHA='d617cf5010e54c4c0411a8765f62afa1f689d457f717edc0b336742135e4aac7'


def backend():
    require(file_sha(EXECUTOR/'runner.py')==RUNNER_SHA
        and file_sha(EXECUTOR/'FREEZE_EXECUTOR_V2.json')==EXECUTOR_FREEZE_SHA,'PINNED_V7_EXECUTOR_CHANGED')
    name='_source_admission_readonly_v7_executor'
    if name in sys.modules:return sys.modules[name]
    for module,path in(('protocol',EXECUTOR.parent/'protocol.py'),('corpus_loader',EXECUTOR.parent/'corpus_loader.py')):
        require(module not in sys.modules or Path(sys.modules[module].__file__).resolve()==path,'V7_MODULE_COLLISION')
    spec=importlib.util.spec_from_file_location(name,EXECUTOR/'runner.py')
    result=importlib.util.module_from_spec(spec);sys.modules[name]=result;spec.loader.exec_module(result)
    return result


def attest_stage(R,stage,body):
    """Replay the REAL original/retained caller artifacts; no trusted output flag."""
    require(stage.get('status')=='ATTESTED_PROVIDER_OUTPUT'and stage.get('caller_invoked')is True,'STAGE_NOT_ATTESTED')
    runtime=SimpleNamespace(api_root=R.API_ROOT,mocked=False)
    location=R.locate(runtime,body)
    require(location is not None,'ACTUAL_EXACT_CACHE_AND_CALL_ARTIFACTS_REQUIRED')
    for name in('receipt','request','response','cache_path'):
        artifact=stage['artifacts'][name]
        original=R.checked(artifact['original_ref'],parse=False)
        retained=R.checked(artifact['retained_ref'],parse=False)
        require(original==retained==location[name].read_bytes()
            and R.sha(original)==artifact['stored_bytes_sha256'],'ORIGINAL_RETAINED_CALL_BYTES_DIFFER')
        require(R.reference(location[name])==artifact['original_ref'],'CALL_ARTIFACT_PATH_REBOUND')
    require(R.checked(stage['request_http_ref'],parse=False)==R.encoded(body),'EXACT_EXECUTOR_HTTP_BODY_CHANGED')
    raw=location['response'].read_bytes();output=R.Q.provider_output(raw)
    proof=R.attest(runtime,body,output,dict(cache=stage['attestation']['cache_reuse']),location)
    require(R.encoded(proof)==R.encoded(stage['attestation']),'ACTUAL_ATTESTATION_DIFFERS')
    return raw,proof


@dataclass(frozen=True)
class Observation:
    case:dict
    plan:dict
    pages:dict
    requests:tuple
    bindings:dict
    seal:str

    def validate(self):
        require(self.seal==digest(dict(case=self.case,plan=self.plan,pages=self.pages,
            requests=self.requests,bindings=self.bindings)),'VERIFIED_OBSERVATION_MUTATED')


def observation(case,plan,pages,requests,bindings):
    data=deepcopy(dict(case=case,plan=plan,pages=pages,requests=tuple(requests),bindings=bindings))
    return Observation(**data,seal=digest(data))


def load_observation(results_ref,*,cohort,case_id):
    R=backend();Q=R.Q
    result=R.checked(results_ref)
    require(result.get('version')=='source-proposals-v7-six-parent-results/1'and R.is_sealed(result)
        and result.get('provider_mode')=='ACTUAL_PHASE_EXACT_CALLER_V2'
        and result.get('all_request_records_persisted')is True,'COMPLETE_ACTUAL_EXECUTOR_RESULTS_REQUIRED')
    auth=R.checked(result['authorization_ref'])
    require(auth.get('version')==R.AUTH_VERSION and R.is_sealed(auth)and auth.get('mocked_test')is False
        and auth.get('state')=='PARENT_AUTHORIZED_NOT_EXECUTED','ACTUAL_PARENT_AUTHORIZATION_REQUIRED')
    folder=EXECUTOR/'runs'/auth['run_id']
    require(R.ROOT/results_ref['path']==folder/'RESULTS.json'
        and R.ROOT/result['authorization_ref']['path']==folder/'AUTHORIZATION.json','EXECUTOR_RUN_PATH_BINDING')
    deps=R.dependencies()
    require(auth['dependencies']==deps and auth['executor_freeze_ref']==R.self_freeze(SimpleNamespace(mocked=False)),
        'EXECUTOR_DEPENDENCIES_OR_AUTH_FREEZE_CHANGED')
    boundary=R.ParentBoundary(deps['matrix_ref'])
    require(R.selected_plan(auth['plan']['selection_ref'],boundary)==auth['plan'],'PARENT_SELECTION_CHANGED')
    keys=auth['plan']['request_keys']
    require([r['request_key']for r in result['records']]==keys
        and result['requested']==result['recorded']==len(keys),'COMPLETE_ORDERED_EXECUTOR_RECORDS_REQUIRED')
    selected=next((r for r in auth['plan']['observations']if(r['cohort'],r['case_id'])==(cohort,case_id)),None)
    require(selected is not None,'UNDECLARED_OBSERVATION')
    manifest_row=next(r for r in boundary.manifest['cases']if(r['cohort'],r['case_id'])==(cohort,case_id))
    source_proof=R.L.checked(manifest_row['source_proof_ref'])
    n,s,source_seal,execution=__import__('corpus_loader').load(source_proof['seal']['authority_case'])
    require(source_seal==source_proof['seal'],'SOURCE_NATIVE_AUTHORITY_CHANGED')
    preflight=R.L.canonical_preflight(n,s,execution,{})
    require(preflight==source_proof['canonical_preflight'],'CANONICAL_INSPECTED_SOURCE_PREFLIGHT_CHANGED')
    native_ref=source_seal['authority_case']['refs']['native']
    with R.L.archived_native(R.L.checked(native_ref,parse=False))as stream:
        extra=R.L.stream_projection(stream,{'plan'},{'result.provided_plan_sha256','result.query_sha256','native_checksum'})
    plan=extra['plan'];case=n['public_case']
    require(digest(plan)==extra['result.provided_plan_sha256']and extra['result.query_sha256']==digest(case['query'])
        and plan['readings_packet']==n['plan.readings_packet']and plan['atoms']==n['plan.atoms'],
        'ACTUAL_FULL_QUERY_PLAN_READING_BINDING_CHANGED')
    packets,_=Q.partition(n,s);packets={p['input_sha256']:p for p in packets}
    settled={r['request_key']:r for r in result['records']};requests=[]
    for key in selected['request_keys']:
        record=settled[key];ticket=boundary.requests[key]
        require(R.checked(R.reference(folder/'requests'/(key+'.json')))==record,'REQUEST_RECORD_CHANGED')
        packet=boundary._packets[key]
        expected=packets.get(packet['input_sha256'])
        require(expected is not None and all(packet[k]==v for k,v in expected.items()),'PUBLIC_SOURCE_PACKET_NOT_ACTUAL_NATIVE_PROJECTION')
        item=dict(request_key=key,ticket=deepcopy(ticket),packet=deepcopy(packet),status=record['status'],
            executor_record_ref=R.reference(folder/'requests'/(key+'.json')))
        if record['status']!='REVIEWED_CONTEXTUAL_ONLY':
            item['hold_reason']='EXECUTOR_REQUEST_NOT_REVIEWED';requests.append(item);continue
        attestations={};raws={}
        for stage in('proposal','review'):
            value=record[stage]
            require(R.checked(R.reference(folder/'stages'/key/stage/'RESULT.json'))==value,'STAGE_RESULT_CHANGED')
            claim=R.checked(value['claim_ref'])
            require(claim['authorization_ref']==result['authorization_ref']and claim['request_key']==key
                and claim['stage']==stage and claim['max_attempts']==1,'EXECUTOR_STAGE_CLAIM_REBOUND')
            request=boundary.proposal(key)if stage=='proposal'else boundary.review(key,raws['proposal'])
            require(claim['http_body_sha256']==R.sha(request['http_bytes']),'STAGE_CLAIM_HTTP_BINDING')
            raws[stage],attestations[stage]=attest_stage(R,value,request['body'])
        require(attestations['proposal']['call_id']!=attestations['review']['call_id']
            and attestations['proposal']['provider_response_id']!=attestations['review']['provider_response_id'],
            'REVIEW_REUSES_PROPOSAL_CALL')
        local=boundary.validate_proposal(key,raws['proposal'],actual_request_body_sha256=attestations['proposal']['actual_http_body_sha256'])
        reviewed=boundary.validate_review(key,raws['proposal'],raws['review'],actual_request_body_sha256=attestations['review']['actual_http_body_sha256'])
        require(local==R.checked(record['proposal_validation_ref'])and reviewed==R.checked(record['review_validation_ref'])
            and record['accepted_contextual']==[r for r in reviewed['rows']if r['accepted_contextual_nomination']],
            'SAVED_ACCEPTANCE_DOES_NOT_REPLAY')
        item.update(local_validation=local,review_validation=reviewed,proposal_response=Q.provider_output(raws['proposal']),
            review_response=Q.provider_output(raws['review']),attestations=attestations,
            proposal_validation_ref=record['proposal_validation_ref'],review_validation_ref=record['review_validation_ref'])
        requests.append(item)
    bindings=dict(version='verified-v7-observation-source-input/1',cohort=cohort,case_id=case_id,
        results_ref=deepcopy(results_ref),authorization_ref=result['authorization_ref'],executor_freeze_ref=auth['executor_freeze_ref'],
        matrix_ref=deps['matrix_ref'],source_proof_ref=manifest_row['source_proof_ref'],source_seal=source_seal,
        canonical_source_preflight=preflight,source_index_ref=n['binding'],source_view_policy=n['configuration.source_view_policy'],
        native_ref=native_ref,native_checksum=n['native_checksum'],full_plan_sha256=digest(plan),
        inspected_page_ids=deepcopy(n['result.inspected_page_ids']),
        native_candidates_read_for_scoring=False,actual_receipts_replayed=True,
        review_kind='SEPARATE_ACTUAL_CALL_NOT_INDEPENDENT_HUMAN_OR_TRUTH_CERTIFICATE')
    return observation(case,plan,{p['id']:p for p in s['pages']},requests,bindings)
