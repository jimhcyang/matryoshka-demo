"""Owned immutable output helpers; no transport or credential reads."""
import hashlib
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
SRC=HERE.parents[2]
sys.dont_write_bytecode=True
sys.path.insert(0,str(SRC))
from matryoshka_demo.io import digest


def require(ok,code):
    if not ok:raise ValueError(code)


def sha(raw):return hashlib.sha256(raw).hexdigest()


def file_sha(path):
    with Path(path).open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def save(path,value):
    path=Path(path).resolve()
    require(path.is_relative_to(HERE)and not path.exists(),'NEW_OWNED_OUTPUT_ONLY')
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+'\n')
    return dict(path=str(path.relative_to(SRC)),sha256=file_sha(path))
