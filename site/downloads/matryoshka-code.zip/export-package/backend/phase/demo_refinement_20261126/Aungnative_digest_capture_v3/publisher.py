"""Explicit real-provider native postrun attachment; not a legacy D1 manifest."""
from copy import deepcopy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlencode

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
ROOT = PHASE.parents[1]
API = PHASE / 'api'
PRIOR = PHASE / 'Aungnative_digest_v1'
PRIOR_READY_SHA = '6284cb352754bcbee45e5103dbb1df594b1e96efdc797a3981e9012100445df5'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('_frozen_short_native_digest_preparation', PRIOR / 'prepare.py')
N = importlib.util.module_from_spec(spec)
spec.loader.exec_module(N)
from phase.demo_refinement_20261126 import exact_call as E
from matryoshka_narrative.api import AUTHORIZATION
from matryoshka_narrative import api as NativeAPI

GEN_VERSION = 'actual-native-postrun-provider-generation/2'
ATTACHMENT_VERSION = 'actual-native-postrun-publication-attachment/2'
USAGE_API_REF = dict(path='matryoshka_narrative/api.py',sha256='e06995c0433149be0dc3478a770b058e9fd5483aa485535978087ff74f58d425')
PROOF_KEYS = {'request_ref', 'raw_response_ref', 'api_receipt_ref'}
ENVELOPE_KEYS = {'version', 'available', 'text', 'sources', 'source_count', 'input_sha256',
    'receipt', 'native_checksum', 'query_sha256', 'resource_binding', 'scoring_version', 'postrun', 'used_for_inference'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def raw(value):
    return N.encoded(value)


def ref(path):
    return N.D1.ref(path)


def read(reference):
    require(isinstance(reference, dict) and set(reference) == {'path', 'sha256'}, 'EXACT_FILE_REFERENCE_REQUIRED')
    path = N.D1.safe_path(ROOT, reference['path'])
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == reference['sha256'], 'ACTUAL_ARTIFACT_HASH_CHANGED')
    return E.strict_json((gzip.decompress(data) if path.suffix == '.gz' else data).decode('utf-8'))


def put(path, value):
    path = Path(path).absolute()
    require(path.resolve() == path and path.is_relative_to(HERE), 'WRITE_OUTSIDE_NEW_ATTACHMENT_NAMESPACE')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(raw(value) + b'\n')
    return ref(path)


def canonical(report_ref=None):
    body = N.load_body(PRIOR_READY_SHA)
    preparation = read(ref(PRIOR / 'PREPARATION.json'))
    grant = read(preparation['parent_call_plan']['existing_budget_authorization_ref'])
    require(grant['phase'] == PHASE.name and grant['ceiling_usd'] == 50
        and grant['api_root'] == 'phase/demo_refinement_20261126/api'
        and grant['paid_executor'] == 'parent_only', 'PINNED_SHARED_PHASE_AUTHORIZATION_CHANGED')
    payload = read(preparation['payload_ref'])
    report_ref = report_ref or preparation['report_ref']
    report = N.D1.load_report(report_ref)
    rows = [r for r in report['cases'] if r['case']['case_id'] == preparation['case_id']]
    require(len(rows) == 1, 'CURRENT_REPORT_NATIVE_CASE_REQUIRED')
    row = rows[0]
    require(not row.get('reviewed_source_assessment'), 'NATIVE_ATTACHMENT_NOT_CROSS_METHOD')
    item = row['configurations'][preparation['config']]
    binding = preparation['binding']
    require(item['native_checkpoint'] == binding['native_checkpoint'] and item['condition_ref'] == binding['condition_ref']
        and N.D1.digest(row['case']['query']) == binding['query_sha256']
        and N.D1.digest(row['resource_binding']) == binding['resource_binding_sha256'], 'CURRENT_NATIVE_QUERY_RESOURCE_BINDING_CHANGED')
    native = read(item['native_checkpoint'])
    condition = read(item['condition_ref'])
    record = condition['configurations'][preparation['config']]
    require(native['public_case'] == row['case'] == condition['case'] == record['case']
        and N.D1.digest(native) == binding['native_packet_sha256']
        and native['native_checksum'] == record['native_checksum'] == binding['native_checksum']
        and N.D1.digest(record) == binding['condition_record_sha256']
        and condition['resource_binding'] == record['resource_binding'] == row['resource_binding'], 'EXACT_CURRENT_NATIVE_CONDITION_CHANGED')
    require(item['config'] == record['config'] == preparation['config']
        and record['index_ref'] == native['binding'] and record['registry_ref'] == native['execution_context']['registry_ref']
        and all(raw(v) == raw(payload['source_view']) for v in (item['source_view_policy'],
            record['configuration']['source_view_policy'], native['configuration']['source_view_policy'],
            native['retrieval']['source_view_policy'], native['result']['source_view_policy'])), 'CURRENT_NATIVE_SOURCE_POLICY_CHANGED')
    notes = N.scope_notes(row.get('presentation_caveats', []))
    require(notes == payload.get('source_scope_notes', {}).get('notes', []), 'PUBLIC_SCOPE_QUALIFIER_CHANGED')
    return dict(body=body, preparation=preparation, payload=payload, row=row,
        native=native, record=record, report_ref=report_ref)


def verify_provider(proof, body):
    require(isinstance(proof, dict) and set(proof) == PROOF_KEYS, 'CLOSED_ACTUAL_PROVIDER_PROOF_REQUIRED')
    receipt_path = N.D1.safe_path(ROOT, proof['api_receipt_ref']['path'])
    call_id = receipt_path.stem
    require(re.fullmatch('[a-f0-9]{32}', call_id) and receipt_path == API / 'receipts' / (call_id + '.json'), 'ACTUAL_PHASE_RECEIPT_REQUIRED')
    attempt = API / 'attempts' / call_id
    require(N.D1.safe_path(ROOT, proof['request_ref']['path']) == attempt / 'request.json'
        and N.D1.safe_path(ROOT, proof['raw_response_ref']['path']) == attempt / 'response.json', 'PROVIDER_CHAIN_CALL_ID_MISMATCH')
    request, response, receipt = (read(proof[k]) for k in ('request_ref', 'raw_response_ref', 'api_receipt_ref'))
    require(raw(request) == raw(body), 'PROVIDER_REQUEST_IS_NOT_PREPARED_NATIVE_BODY')
    require(receipt.get('status') == 'PASS' and receipt.get('execution_contract') == 'phase-exact-api/2'
        and receipt.get('authorization') == AUTHORIZATION and receipt.get('cap_usd') == 50
        and receipt.get('model') == body['model']
        and receipt.get('request_sha256') == N.D1.digest(request)
        and receipt.get('response_sha256') == N.D1.digest(response), 'EXACT_REAL_PROVIDER_RECEIPT_MISMATCH')
    require(response.get('status') == 'completed' and isinstance(response.get('id'), str) and response['id'], 'COMPLETE_PROVIDER_RESPONSE_REQUIRED')
    require(receipt.get('response_id') == response['id'], 'PROVIDER_RESPONSE_ID_MISMATCH')
    usage = response.get('usage', {})
    require(all(type(usage.get(k)) is int and usage[k] >= 0 for k in ('input_tokens', 'output_tokens')), 'ACTUAL_PROVIDER_USAGE_REQUIRED')
    require(ref(ROOT / USAGE_API_REF['path']) == USAGE_API_REF, 'PINNED_CANONICAL_USAGE_HELPER_CHANGED')
    expected_usage = deepcopy(NativeAPI._usage(response))
    rates = N.RATES[body['model']]
    charge = (usage['input_tokens'] * rates[0] + usage['output_tokens'] * rates[1]) / 1e6
    reserve = ((len(raw(body)) + 4096) * rates[0] + body['max_output_tokens'] * rates[1]) / 1e6
    require(raw(receipt.get('usage')) == raw(expected_usage) and receipt.get('rates') == list(rates)
        and type(receipt.get('charged_or_reserved_usd')) in (int, float)
        and receipt['charged_or_reserved_usd'] == charge <= reserve <= 1, 'PROVIDER_USAGE_OR_FUNDING_MISMATCH')
    text = E.response_text(response)
    output = E.strict_json(text)
    from jsonschema import validate
    validate(output, N.P.SCHEMA)
    N.D1.public_safe(output)
    preparation = read(ref(PRIOR / 'PREPARATION.json'))
    N.D1.validate_text(output['digest'], preparation['source_count'])
    key = N.D1.digest(dict(version='phase-exact-api/2', request=body))
    cache = read(ref(API / 'exact_cache' / (key + '.json')))
    require(cache.get('version') == 'phase-exact-api/2' and cache.get('receipt') == 'receipts/' + call_id + '.json'
        and cache.get('output_sha256') == N.D1.digest(output)
        and cache.get('exact_body_unchanged') is True and cache.get('raw_json_strictly_parsed') is True, 'ACTUAL_EXACT_CALL_CACHE_PROOF_CHANGED')
    return dict(text=output['digest'], call_id=call_id, provider_response_id=response['id'],
        request_sha256=N.D1.digest(request), raw_response_sha256=N.D1.digest(response),
        usage=expected_usage, charged_usd=charge, receipt_sha256=proof['api_receipt_ref']['sha256'])


def generation_value(state, proof, actual):
    p = state['preparation']
    return N.D1.sealed(dict(version=GEN_VERSION, prior_preparation_ready_ref=ref(PRIOR / 'READY.json'),
        preparation_ref=ref(PRIOR / 'PREPARATION.json'), binding=p['binding'], input_ref=p['payload_ref'],
        input_sha256=p['input_sha256'], body_ref=p['body_ref'], actual_http_sha256=p['actual_http_sha256'],
        source_labels_ref=p['source_labels_ref'], source_count=p['source_count'],
        original_source_scope_notes=deepcopy(state['payload'].get('source_scope_notes')), provider_proof=deepcopy(proof),
        actual_provider=actual, native_method='SAVED_LOCAL_NATIVE_POSTRUN', report_independent=True,
        world_truth_certified=False, native_verdict_changed=False, used_for_inference=False, postrun=True))


def capture(proof, output):
    state = canonical()
    actual = verify_provider(proof, state['body'])
    return put(output, generation_value(state, proof, actual))


def prepare_attachment(generation_ref, report_ref):
    state = canonical(report_ref)
    generation = read(generation_ref)
    require(generation.get('version') == GEN_VERSION and N.D1.d.sealed(generation), 'EXPLICIT_NATIVE_GENERATION_REQUIRED_NOT_LEGACY_D1')
    actual = verify_provider(generation['provider_proof'], state['body'])
    require(raw(generation) == raw(generation_value(state, generation['provider_proof'], actual)), 'GENERATION_FULL_REPLAY_CHANGED')
    p, payload = state['preparation'], state['payload']
    # Exactly the established native producer's envelope version and fields.
    # Its generate() output does not carry source_scope_notes; the complete
    # qualifiers remain in the verified input and report, not silently erased.
    envelope = dict(version=N.P.VERSION, available=True, text=actual['text'], sources=deepcopy(payload['sources']),
        source_count=len(payload['sources']), input_sha256=p['input_sha256'],
        receipt=dict(execution_contract='phase-exact-api/2', provider_response_id=actual['provider_response_id'],
            request_sha256=actual['request_sha256'], response_sha256=actual['raw_response_sha256'],
            receipt_sha256=actual['receipt_sha256']),
        native_checksum=p['binding']['native_checksum'], query_sha256=p['binding']['query_sha256'],
        resource_binding=deepcopy(state['row']['resource_binding']), scoring_version=payload['scores']['version'],
        postrun=True, used_for_inference=False)
    require(set(envelope) == ENVELOPE_KEYS and envelope['version'] == 'source-bound-postrun-digest/2', 'NATIVE_END_READER_CONTRACT_CHANGED')
    N.D1.public_safe(envelope)
    params = dict(case_id=p['case_id'], config=p['config'], **{k: state['row']['resource_binding'][k]
        for k in ('resource_id', 'registry_sha256', 'index_sha256')})
    return dict(version=ATTACHMENT_VERSION, report_ref=report_ref, generation_ref=generation_ref,
        endpoint='/api/current/analyst-digest', params=params,
        route='/api/current/analyst-digest?' + urlencode(sorted(params.items())), envelope=envelope,
        envelope_sha256=hashlib.sha256(raw(envelope)).hexdigest(),
        preserved_input_source_scope_notes=deepcopy(payload.get('source_scope_notes')),
        native_binding=deepcopy(p['binding']), legacy_D1_manifest=False,
        source_page_ids=sorted({s['canonical_page_id'] for s in envelope['sources']}),
        API_calls=0, native_runs=0, publication_authorized=False)


def install_on_exporter(worker, generation_ref):
    """Parent callsite BEFORE ordinary export caches this route; no runtime patch."""
    prepared = prepare_attachment(generation_ref, worker.viewer.report_ref)
    require(prepared['route'] not in worker.entries, 'EXISTING_ROUTE_REQUIRES_EXPLICIT_NEW_STAGE_NOT_OVERWRITE')
    row, config, item, condition, native = worker.viewer.select(prepared['params'])
    require(row['case']['case_id'] == prepared['params']['case_id'] and config == prepared['params']['config']
        and item['native_checkpoint'] == prepared['native_binding']['native_checkpoint']
        and native['native_checksum'] == prepared['native_binding']['native_checksum'], 'EXPORTER_ACTUAL_SELECTION_CHANGED')
    worker.put(prepared['route'], prepared['envelope'])
    for page_id in prepared['source_page_ids']:
        worker.get('source-v6', dict(prepared['params'], source_id=page_id))
    return prepared
