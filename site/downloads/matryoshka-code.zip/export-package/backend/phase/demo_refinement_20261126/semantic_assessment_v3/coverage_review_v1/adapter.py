"""Bounded complete-pool scheduling and versioned reviewed-model provenance."""
from copy import deepcopy
import json
from types import FunctionType

from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import descriptor
from matryoshka_next.facts import SourcePolicy

PLAN_VERSION = "semantic-inspected-pool-all-fact-coverage/1"
METHOD_VERSION = "reviewed-source-model-pipeline-projection/1"
REVIEW_VERSION = "semantic-lossless-full-context-review-wire/1"


def require(value,message):
    if not value:
        raise ValueError(message)


def _bound(preflight,producer):
    require(type(preflight) is producer.P.Preflight,"Original source-owner Preflight required")
    data = preflight.export()
    require(data["sha256"]==digest({k:v for k,v in data.items() if k!="sha256"}),"Preflight snapshot changed")
    return data


def inventory(preflight,reviewed_batches,producer,*,pending_assessments=(),allow_test_fixtures=False):
    data = _bound(preflight,producer)
    facts,pages = {f["id"]:f for f in data["required_facts"]},{p["id"]:p for p in data["pages"]}
    expected = {(f,p) for f in facts for p in pages}
    seen,rows,requests = set(),{},[]
    for batch in [*reviewed_batches,*pending_assessments]:
        pending = type(batch) is producer.Assessment
        require(type(batch) is (producer.Assessment if pending else producer.Reviewed),"Replayed source capsules, not result dictionaries, required")
        b = batch.export()
        require(b["preflight_sha256"]==data["sha256"],"Another case/policy/source pool")
        producer._wire(preflight,b["wire"])
        requests.append(b["wire"]["request_sha256"])
        for name in (("receipt",) if pending else ("assessment_receipt","review_receipt")):
            r = b[name]
            if r is not None:
                require(allow_test_fixtures or r["kind"]=="MODEL_SEMANTIC_JUDGMENT","Fixture is not actual model evidence")
        keys = set()
        for row in [*b["rows"],*b["rejected_rows"]]:
            k = row["fact_id"],row["page_id"]
            require(k in expected and k not in seen and k not in keys,"Duplicate/unknown processed slot")
            keys.add(k)
            label = row.get("effective_label","REVIEW_PENDING" if pending else None)
            state = ("ROW_REJECTED" if label=="REJECTED_ROW" else "REVIEW_PENDING" if pending else
                "REVIEW_HOLD" if label=="HOLD" else "REVIEWED_"+label)
            rows[k] = dict(fact_id=k[0],page_id=k[1],state=state,document_id=pages[k[1]]["document_id"],
                label=label,error=row.get("error"),request_sha256=b["wire"]["request_sha256"])
        require(keys=={(f,p["id"]) for f in facts for p in b["wire"]["pages"]},"Incomplete reviewed matrix")
        seen.update(keys)
    grid = [rows.get((f,p),dict(fact_id=f,page_id=p,document_id=pages[p]["document_id"],
        state="UNPROCESSED",label=None,error=None,request_sha256=None)) for p in pages for f in facts]
    page_state = {}
    for p in pages:
        present = {(f,p) for f in facts}&seen
        require(not present or len(present)==len(facts),"Mixed fact coverage on a page requires explicit repair, not omission")
        page_state[p] = "PROCESSED_ALL_FACTS" if present else "UNPROCESSED_ALL_FACTS"
    return dict(version=PLAN_VERSION,preflight_sha256=data["sha256"],grid=grid,page_states=page_state,
        original_pages=len(pages),required_facts=len(facts),original_slots=len(expected),processed_slots=len(seen),
        reviewed_slots=sum(r["state"] not in {"UNPROCESSED","ROW_REJECTED","REVIEW_PENDING"} for r in grid),
        review_pending_slots=sum(r["state"]=="REVIEW_PENDING" for r in grid),
        rejected_slots=sum(r["state"]=="ROW_REJECTED" for r in grid),unprocessed_slots=len(expected-seen),
        prior_request_hashes=requests,unknown_is_NONE=False,
        inspected_pool_completely_processed=seen==expected,
        inspected_pool_completely_assessed=seen==expected and not any(r["state"] in {"ROW_REJECTED","REVIEW_PENDING"} for r in grid))


def _priority(wires,producer):
    if not wires:
        return []
    facts = sorted(wires[0]["required_facts"],key=lambda f:(min(s["start"] for s in f["query_spans"]),f["id"]))
    values = {w["request_sha256"]:{f["id"]:max(producer.P.lexical_fit(f["text"],p["text"])["value"] for p in w["pages"])
        for f in facts} for w in wires}
    queues = {f["id"]:sorted(wires,key=lambda w:(-values[w["request_sha256"]][f["id"]],w["request_sha256"])) for f in facts}
    ordered,seen = [],set()
    while len(seen)<len(wires):
        for f in facts:
            selected = next((w for w in queues[f["id"]] if w["request_sha256"] not in seen),None)
            if selected is not None:
                seen.add(selected["request_sha256"])
                ordered.append(dict(request_sha256=selected["request_sha256"],nominated_by_atom=f["id"],
                    priority=len(ordered)+1,page_ids=[p["id"] for p in selected["pages"]],
                    per_fact_max_single_page_lexical=values[selected["request_sha256"]]))
    return ordered


def coverage_plan(preflight,producer,projector,*,reviewed_batches=(),pending_assessments=(),pages_per_batch=4,
                  max_pages=64,max_wire_bytes=65536,allow_test_fixtures=False):
    data = _bound(preflight,producer)
    require(type(max_pages) is int and 1<=max_pages<=128 and len(data["pages"])<=max_pages,"Explicit inspected-page bound exceeded; never truncate")
    require(type(pages_per_batch) is int and 1<=pages_per_batch<=4,"One to four complete pages per source batch")
    require(type(max_wire_bytes) is int and 8192<=max_wire_bytes<=65536,"Bounded request envelope required")
    state = inventory(preflight,reviewed_batches,producer,pending_assessments=pending_assessments,allow_test_fixtures=allow_test_fixtures)
    full = projector.project_preflight(preflight,producer,pages_per_batch=pages_per_batch)
    templates = producer.P.assessment_wires(preflight,pages_per_batch=pages_per_batch)
    wires,changed = [],False
    # Only processed PAGE identity, not label, answer, rank or source-doc ID,
    # controls resume. All required facts remain in every residual request.
    def append_pages(pages,index):
        nonlocal changed
        base = deepcopy(templates[0])
        base.update(pages=deepcopy(pages),batch_index=index)
        base["request_sha256"] = digest({k:v for k,v in base.items() if k!="request_sha256"})
        producer.P._wire(preflight,base)
        wire = producer.convert_selected_wire(preflight,base)
        producer._wire(preflight,wire)
        envelope = dict(instructions=producer.PROMPT,input=wire)
        # Leave room for provider schema/profile overhead, not just source text.
        from matryoshka_demo.api_v2 import request
        body = request("semantic_v3_assessment",wire,producer.PROMPT,producer.response_schema(data["public_case"]["task"]),
            model="gpt-6.1-sol",max_output_tokens=10000)
        size = len(json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode())+2048
        if size>max_wire_bytes:
            require(len(pages)>1,"A complete single page exceeds request bound; HOLD, never truncate")
            changed = True
            middle = len(pages)//2
            append_pages(pages[:middle],index*2)
            append_pages(pages[middle:],index*2+1)
            return
        wires.append((envelope,size))
    if not reviewed_batches and not pending_assessments:
        for row in full["ranked_batches"]:
            wire = full["model_requests"][row["request_sha256"]]["input"]
            # Retain the exact source-owner body when it fits, including index.
            append_pages(wire["pages"],wire["batch_index"])
    else:
        remaining = [p for p in data["pages"] if state["page_states"][p["id"]]=="UNPROCESSED_ALL_FACTS"]
        changed = bool(remaining)
        for i in range(0,len(remaining),pages_per_batch):
            append_pages(remaining[i:i+pages_per_batch],i//pages_per_batch)
    payloads = {w["input"]["request_sha256"]:w for w,_ in wires}
    require(len(payloads)==len(wires),"Duplicate residual requests")
    scheduled = [(f["id"],p["id"]) for w,_ in wires for p in w["input"]["pages"] for f in w["input"]["required_facts"]]
    expected = {(r["fact_id"],r["page_id"]) for r in state["grid"] if r["state"]=="UNPROCESSED"}
    require(len(scheduled)==len(set(scheduled)) and set(scheduled)==expected,"All-fact inspected-pool coverage changed")
    plan = dict(version=PLAN_VERSION,preflight_sha256=data["sha256"],public_case=data["public_case"],
        source_view_policy=data["source_view_policy"],inspection_authority=data["inspection_authority"],
        required_facts=deepcopy(data["required_facts"]),inventory=state,
        source_origin=dict(document_id=data["public_case"]["document_id"],date=data["public_case"]["date"],origin_body_used=False),
        full_pool_batches=len(full["ranked_batches"]),remaining_batches=len(wires),remaining_slots=len(scheduled),
        ranked_batches=_priority([w["input"] for w,_ in wires],producer),model_requests=payloads,
        exact_assessment_request_bounds={w["input"]["request_sha256"]:size for w,size in wires},
        existing_reviewed_responses_rebound=False,source_batches_repartitioned=changed,
        rejected_rows_retry_queue=[r for r in state["grid"] if r["state"]=="ROW_REJECTED"],
        pending_review_requests=[dict(assessment_request_sha256=a.export()["wire"]["request_sha256"],
            source_assessment_receipt=a.export()["receipt"],transport=review_transport(a,producer)) for a in pending_assessments],
        retries_auto_authorized=False,omitted_unprocessed_pages=[],all_remaining_fact_page_slots_scheduled=True,
        full_raw_pages_and_all_facts_retained=True,priority_is_not_semantic_support=True,
        model_calls_authorized=0,model_calls_executed=0,native_executions=0,source_policy_changed=False)
    plan["sha256"] = digest(plan)
    return plan


def compact_review_prompt(producer):
    return producer.REVIEW_PROMPT+"\nFull-page text_ref values refer to the unchanged assessment_request.pages entry with that ID/hash. A paragraph text_ref means that entire raw page is its paragraph. Read that FULL text once; no source or qualification has been removed."


def expand_review_wire(wire):
    require(wire.get("version")==REVIEW_VERSION,"Unknown context projection")
    require(wire["request_sha256"]==digest({k:v for k,v in wire.items() if k!="request_sha256"}),"Projected review hash differs")
    value = deepcopy(wire)
    old = value.pop("expanded_wire_sha256")
    value["version"]="semantic-source-review-wire/3"
    pages = {p["id"]:p for p in value["assessment_request"]["pages"]}
    for row in value["proposed_judgments"]:
        envelope = row.get("qualification_envelope")
        if not envelope:
            continue
        page = pages[row["page_id"]]
        require(digest(page["text"])==page["source_sha256"],"Full review page hash differs")
        for key in ("full_page","paragraph"):
            part = envelope[key]
            if "text_ref" in part:
                target = part.pop("text_ref")
                require(target==dict(page_id=page["id"],page_sha256=page["source_sha256"])
                    and part["start"]==0 and part["end"]==len(page["text"]),"Review context reference is not the full actual page")
                part["text"]=page["text"]
    value["request_sha256"]=old
    require(old==digest({k:v for k,v in value.items() if k!="request_sha256"}),"Projection loses or changes original review context")
    return value


def compact_review_wire(assessment,producer):
    original = producer.review_wire(assessment)
    wire = deepcopy(original)
    wire.update(version=REVIEW_VERSION,expanded_wire_sha256=original["request_sha256"])
    pages = {p["id"]:p for p in wire["assessment_request"]["pages"]}
    for row in wire["proposed_judgments"]:
        envelope = row.get("qualification_envelope")
        if not envelope:
            continue
        page = pages[row["page_id"]]
        for key in ("full_page","paragraph"):
            part = envelope[key]
            if part["start"]==0 and part["end"]==len(page["text"]):
                require(part["text"]==page["text"],"Context copy differs from source")
                part.pop("text")
                part["text_ref"]=dict(page_id=page["id"],page_sha256=page["source_sha256"])
    wire["request_sha256"]=digest({k:v for k,v in wire.items() if k!="request_sha256"})
    require(expand_review_wire(wire)==original,"Review projection must be exactly lossless")
    return wire


def validate_compact_review(assessment,response,receipt,*,root,producer):
    """Isolate only transport dependencies; reuse ALL frozen review checks.

    The real projected prompt/body/response/receipt are verified. No normalized
    fake request or response artifact is created, and no globals are patched.
    """
    projected = compact_review_wire(assessment,producer)
    def bound_wire(value):
        require(value is assessment,"Another assessment cannot use this context projection")
        return projected
    provenance = FunctionType(producer._provenance.__code__,
        dict(producer._provenance.__globals__,REVIEW_PROMPT=compact_review_prompt(producer)),
        producer._provenance.__name__,producer._provenance.__defaults__,producer._provenance.__closure__)
    validate = FunctionType(producer.validate_review.__code__,
        dict(producer.validate_review.__globals__,review_wire=bound_wire,_provenance=provenance),
        producer.validate_review.__name__,producer.validate_review.__defaults__,producer.validate_review.__closure__)
    return validate(assessment,response,receipt,root=root)


def bounded_schema(producer,task,*,review=False):
    """A provider-only limit equal to the unchanged local reason bound."""
    value = deepcopy(producer.review_schema(task) if review else producer.response_schema(task))
    def visit(node):
        if isinstance(node,dict):
            if node.get("type")=="object" and "reason" in node.get("properties",{}):
                node["properties"]["reason"].update(minLength=1,maxLength=500)
            for item in node.values(): visit(item)
        elif isinstance(node,list):
            for item in node: visit(item)
    visit(value)
    return value


def review_transport(assessment,producer,*,max_input_bytes=65536):
    from matryoshka_demo.api_v2 import request
    task = assessment.export()["wire"]["public_case"]["task"]
    schema = bounded_schema(producer,task,review=True)
    choices = []
    for mode,wire,prompt in (("ORIGINAL_V3",producer.review_wire(assessment),producer.REVIEW_PROMPT),
            ("LOSSLESS_CONTEXT_PROJECTION_V1",compact_review_wire(assessment,producer),compact_review_prompt(producer))):
        body = request("semantic_v3_review",wire,prompt,schema,model="gpt-6.1-sol",max_output_tokens=10000)
        size = len(json.dumps(body,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode())+2048
        choices.append(dict(mode=mode,request=dict(instructions=prompt,input=wire),schema=schema,
            conservative_input_bytes=size,source_or_semantic_content_changed=False))
    best = min(choices,key=lambda c:c["conservative_input_bytes"])
    return dict(status="READY_PARENT_AUTHORIZATION_REQUIRED" if best["conservative_input_bytes"]<=max_input_bytes else "HOLD_REVIEW_EXCEEDS_EXACT_BODY_BOUND",
        selected=best,alternative_bounds={c["mode"]:c["conservative_input_bytes"] for c in choices},
        prior_response_rebound=False,prior_reason_truncated=False,model_calls_authorized=0)


def method_packet(preflight,reviewed_batches,producer,source_policy,*,pending_assessments=(),allow_test_fixtures=False):
    """A distinct model method and source-containment graph, never native edits."""
    data = _bound(preflight,producer)
    require(type(source_policy) is SourcePolicy and source_policy.case==producer.P.engine_case(data["public_case"])
        and descriptor(source_policy.source_view_policy)==data["source_view_policy"],"Same complete source policy required")
    state = inventory(preflight,reviewed_batches,producer,pending_assessments=pending_assessments,allow_test_fixtures=allow_test_fixtures)
    result = producer.results_adapter(preflight,reviewed_batches,allow_test_fixtures=allow_test_fixtures,allow_partial_pool=True)
    pages = {p["id"]:p for p in data["pages"]}
    nodes,edges,endpoints = {},[],[]
    for fact in data["required_facts"]:
        key = "input-component:"+digest([data["sha256"],fact["id"]])
        nodes[key] = dict(id=key,kind="REQUIRED_INPUT_COMPONENT",atom_id=fact["id"],text=fact["text"],query_spans=fact["query_spans"])
    def bind(row,span):
        page = pages[row["page_id"]]
        pi = source_policy.corpus.page_index.get(page["id"])
        require(pi is not None,"Source page absent from trusted corpus")
        original = source_policy.corpus.pages[pi]
        require(all(original[k]==page[k] for k in page),"Inspection and canonical source differ")
        ref = source_policy.citation(pi,span["start"],span["end"])
        require(ref["text"]==span["text"] and ref["page_sha256"]==page["source_sha256"],"Semantic excerpt does not replay canonical raw source")
        did,pid = "source-document:"+digest([page["corpus"],page["document_id"]]),"source-page:"+digest([page["id"],page["source_sha256"]])
        eid = "source-excerpt:"+digest(ref)
        nodes[did] = dict(id=did,kind="SOURCE_DOCUMENT",document_id=page["document_id"],corpus=page["corpus"])
        nodes[pid] = dict(id=pid,kind="SOURCE_PAGE",canonical_page_id=page["id"],document_id=page["document_id"],
            date=page["date"],page_sha256=page["source_sha256"],raw_text=page["text"])
        nodes[eid] = dict(id=eid,kind="EXACT_RAW_SOURCE_EXCERPT",citation=ref,ordinary_KG_node_id=None)
        for a,b,kind in ((did,pid,"RECORDED_DOCUMENT_PAGE"),(pid,eid,"EXACT_RAW_SPAN_CONTAINMENT")):
            edge = dict(source=a,target=b,kind=kind,historical_relation_certified=False,event_join_authority=False)
            if edge not in edges:
                edges.append(edge)
        return eid,ref
    for row in result["source_judgments"]:
        if row["effective_label"]=="REJECTED_ROW" or not row.get("qualification_envelope"):
            continue
        env = row["qualification_envelope"]
        eid,ref = bind(row,env["raw_quote_span"])
        context_id,context_ref = bind(row,env["paragraph"])
        target = "input-component:"+digest([data["sha256"],row["fact_id"]])
        account = "model-source-account:"+row["judgment_id"]
        nodes[account] = dict(id=account,kind="REVIEWED_MODEL_SOURCE_ACCOUNT",effective_label=row["effective_label"],
            judgment_id=row["judgment_id"],authority=row["authority"],deterministic_proof=False,inner_execution=False)
        edges.extend([dict(source=eid,target=account,kind="QUOTED_MODEL_INPUT",historical_relation_certified=False),
            dict(source=context_id,target=account,kind="FULL_QUALIFICATION_CONTEXT",historical_relation_certified=False),
            dict(source=account,target=target,kind="MODEL_ASSESSES_COMPONENT",label=row["effective_label"],
                deterministic_support=False,event_join_authority=False)])
        endpoints.append(dict(atom_id=row["fact_id"],judgment_id=row["judgment_id"],endpoint_id=eid,
            qualification_endpoint_id=context_id,quote=ref,qualification_quote=context_ref,
            source_edition=ref.get("source_edition"),physical_page=ref.get("physical_page"),
            native_KG_node_id=None,native_semantic_route=None,inspection_only=True,
            input_to_source_world_edge_invented=False))
    packet = dict(version=METHOD_VERSION,method_id="reviewed_source_model_accounts_v3_coverage1",
        method_label="Reviewed model source accounts",incumbent_native_method=False,
        producer_version=producer.VERSION,public_case=data["public_case"],query_sha256=digest(data["public_case"]["query"]),
        preflight_sha256=data["sha256"],inspection_authority=data["inspection_authority"],source_view_policy=data["source_view_policy"],
        source_origin=dict(document_id=data["public_case"]["document_id"],date=data["public_case"]["date"],
            inherited_binding="ORIGINAL_PUBLIC_CASE_AND_PINNED_NATIVE",origin_body_used=False,origin_packet_ref_not_invented=True),
        atom_refs=[dict(atom_id=f["id"],text=f["text"],query_spans=f["query_spans"]) for f in data["required_facts"]],
        reviewed_model_result=result,assessment_scope=state,source_endpoints=endpoints,
        graph=dict(version="semantic-source-containment-inspection-graph/1",nodes=list(nodes.values()),edges=edges,
            native_semantic_edges_created=0,actual_KG_edges_inferred=False),
        native_history_modified=False,native_gates_modified=False,deterministic_semantic_proof=False,
        world_truth_certified=False,inner_execution=False,event_join_authority=False,
        unseen_sources_are_not_NONE=True,source_independence_claimed=False,test_only=allow_test_fixtures)
    packet["sha256"] = digest(packet)
    return packet


def reader_projection(preflight,reviewed_batches,producer,source_policy,*,pending_assessments=(),allow_test_fixtures=False):
    """Direct Workbench view model from replayed capsules, not unsigned JSON."""
    packet = method_packet(preflight,reviewed_batches,producer,source_policy,pending_assessments=pending_assessments,allow_test_fixtures=allow_test_fixtures)
    result = packet["reviewed_model_result"]
    hypothesis = packet["public_case"]["task"]=="hypothesis"
    endpoints = {e["judgment_id"]:e for e in packet["source_endpoints"]}
    labels = ({"SOURCE_VIEWS_RECORDED":"Qualified source views recorded","CONTESTED_SOURCE_ACCOUNTS":"Conflicting source views",
        "CONTEXT_ONLY":"Related source context only","UNRESOLVED":"No accepted source view in assessed pages"} if hypothesis else
        {"SOURCE_ASCRIBED":"Source-account supported","PARTIAL_SOURCE_ASCRIPTION":"Partial source account",
        "OPPOSING_SOURCE_ACCOUNT":"Opposing source account","CONTESTED_SOURCE_ACCOUNTS":"Conflicting source accounts",
        "CONTEXT_ONLY":"Related source context only","UNRESOLVED":"No accepted source account in assessed pages"})
    atoms = []
    for atom in result["atoms"]:
        evidence = []
        for row in result["source_judgments"]:
            if row["fact_id"]!=atom["id"] or row["effective_label"] in {"REJECTED_ROW","HOLD","NONE"}:
                continue
            endpoint = endpoints[row["judgment_id"]]
            evidence.append(dict(judgment_id=row["judgment_id"],direction=row["effective_label"],
                citation=endpoint["quote"],qualification_citation=endpoint["qualification_quote"],
                source_endpoint_id=endpoint["endpoint_id"],qualification_endpoint_id=endpoint["qualification_endpoint_id"],
                model_quote_unchanged=row["quote"],grounded_fields=row["grounded_fields"],
                qualifications=row.get("grounded_hypothesis_relation"),context_priority_index=row["context_priority_index"],
                facet_coverage=row["facet_coverage"],local_lexical_fit=row["local_lexical_fit"],
                review=row["review"],authority=row["authority"],model_reviewed=True,
                deterministic_proof=False,inner_execution=False,event_join_authority=False))
        atoms.append(dict(id=atom["id"],text=atom["text"],status=atom["status"],
            label=labels.get(atom["status"],atom["status"]),authority=atom["authority"],
            query_spans=next(f["query_spans"] for f in packet["atom_refs"] if f["atom_id"]==atom["id"]),
            complete_by_model_source_review=atom["complete_source_component"],evidence=evidence,
            source_counts={sign:len({r["citation"]["document_id"] for r in evidence if r["direction"]==sign})
                for sign in ("SUPPORT","OPPOSE","PARTIAL","CONTEXT")},
            counts_are_independent_votes=False,world_truth_verdict="NOT_ASSESSED"))
    state = packet["assessment_scope"]
    view = dict(version="reviewed-source-workbench-view/1",method_id=packet["method_id"],
        method_label=packet["method_label"],incumbent_native_method=False,case=packet["public_case"],
        query_sha256=packet["query_sha256"],original_native_ref=packet["inspection_authority"]["native_ref"],
        original_inspection_ref=packet["inspection_authority"]["inspection_ref"],
        execution_context=packet["inspection_authority"]["execution_context"],source_origin=packet["source_origin"],
        source_view_policy=packet["source_view_policy"],method_packet_sha256=packet["sha256"],
        atoms=atoms,coverage=None if hypothesis else result["coverage"],
        caveat=("Reviewed model source assessments, not deterministic event proof. "
            +("The full inspected pool was processed." if state["inspected_pool_completely_processed"] else
              "Only part of the inspected pool has been processed; omitted pages are unassessed.")
            +(" Rejected rows remain unresolved." if state["rejected_slots"] else "")),
        review_pending_disclosure="Valid first-pass rows still await independent review." if state["review_pending_slots"] else None,
        assessment_scope=state,source_endpoints=packet["source_endpoints"],trace=packet["graph"],
        model_provenance=result["model_provenance"],native_status_or_gates_rewritten=False,
        source_drawer_reuses_exact_citations=True,origin_drawer_binding_unchanged=True,
        synthetic_native_ESTABLISHED_labels_created=False,deterministic_event_join_authority=False)
    view["sha256"] = digest(view)
    return view
