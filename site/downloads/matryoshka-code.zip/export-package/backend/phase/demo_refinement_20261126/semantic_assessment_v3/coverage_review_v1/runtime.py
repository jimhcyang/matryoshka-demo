"""Read-only replay of actual saved model calls and their original source policy."""
from contextlib import contextmanager
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import apply_source_view,packet_policy
from matryoshka_current import resources
from matryoshka_next.facts import SourcePolicy
from adapter import REVIEW_VERSION,require,validate_compact_review


def ref(root,path):
    root,path = Path(root).resolve(),Path(path).resolve()
    require(path.is_relative_to(root),"Artifact outside source root")
    return dict(path=str(path.relative_to(root)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def verified_path(root,reference):
    root = Path(root).resolve()
    relative = Path(reference["path"])
    path = root/relative
    require(not relative.is_absolute() and ".." not in relative.parts and path.resolve()==path
        and path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest()==reference["sha256"],"Changed or unsafe pinned file")
    return path


def load_module(root,reference,name):
    path = verified_path(root,reference)
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    verified_path(root,reference)
    return module


@contextmanager
def source_context(root,native_ref,inspection_ref,producer):
    """Same complete-resource preflight factory, retaining its live policy."""
    native,inspection = producer.checked(root,native_ref),producer.checked(root,inspection_ref)
    c = native["public_case"]
    ex = native["execution_context"]
    with resources.open_context(root,ex["registry_ref"],ex["index_ref"],c["corpus"]) as owner:
        context = apply_source_view(owner,packet_policy(native))
        policy = SourcePolicy(context.corpus,native["case"],context.source_index)
        pf = producer.P._preflight(native,inspection,policy,native_ref=native_ref,inspection_ref=inspection_ref)
        yield pf,policy,native,inspection


def _strict(text):
    def pairs(items):
        d = {}
        for k,v in items:
            require(k not in d,"Duplicate actual provider JSON key")
            d[k]=v
        return d
    def invalid(value):
        raise ValueError("Nonfinite provider JSON literal")
    def number(value):
        n = float(value)
        require(math.isfinite(n),"Nonfinite provider JSON number")
        return n
    return json.loads(text,object_pairs_hook=pairs,parse_constant=invalid,parse_float=number)


def provider_chain(root,producer,receipt):
    public = producer.checked(root,receipt["provider_receipt_ref"])
    request = producer.checked(root,receipt["request_ref"])
    normalized = producer.checked(root,receipt["response_ref"])
    raw_request = producer.checked(root,public["actual_request_ref"])
    raw_response = producer.checked(root,public["actual_response_ref"])
    api = producer.checked(root,public["actual_api_receipt_ref"])
    require(api["status"]=="PASS" and api["request_sha256"]==digest(raw_request)
        and api["response_sha256"]==digest(raw_response) and raw_response["status"]=="completed","Actual provider call does not replay")
    require(raw_request["model"]==receipt["model"]==public["model"]==api["model"]
        and Path(public["actual_api_receipt_ref"]["path"]).stem==receipt["call_id"]==public["call_id"],"Provider call identity differs")
    inputs = raw_request["input"]
    require(raw_request["instructions"]==request["instructions"] and len(inputs)==1
        and inputs[0]["role"]=="user" and len(inputs[0]["content"])==1
        and inputs[0]["content"][0]["type"]=="input_text"
        and _strict(inputs[0]["content"][0]["text"])==request["input"],"Actual model received a different source request")
    texts = [c["text"] for item in raw_response["output"] if item.get("type")=="message"
        for c in item.get("content",[]) if c.get("type")=="output_text"]
    require(len(texts)==1 and _strict(texts[0])==normalized,"Normalized model result differs from provider bytes")
    return dict(receipt_ref=receipt["provider_receipt_ref"],actual_request_ref=public["actual_request_ref"],
        actual_response_ref=public["actual_response_ref"],actual_api_receipt_ref=public["actual_api_receipt_ref"])


def replay_case(root,folder,preflight,producer,*,allow_test_fixtures=False):
    """Never trust reviewed.json/result.json merely because it hashes itself."""
    folder = Path(folder)
    snapshots,reviewed,pending,failures,chains = [],[],[],[],[]
    def read(path):
        reference = ref(root,path)
        value = producer.checked(root,reference)
        snapshots.append(reference)
        return value
    require(read(folder/"preflight.json")==preflight.export(),"Saved preflight differs from trusted source replay")
    for batch in sorted(folder.glob("batch_*")):
        if not batch.is_dir():
            continue
        settled = (batch/"reviewed.json").is_file()
        if not settled:
            failures.append(dict(batch=batch.name,status="FAILED_OR_PENDING_UNPROCESSED",
                failure_ref=ref(root,batch/"FAILURE.json") if (batch/"FAILURE.json").exists() else None))
            if not (batch/"validated.json").is_file():
                continue
        prepared = read(batch/"prepared-request.json")
        require(prepared["instructions"]==producer.PROMPT,"First-pass source prompt changed")
        wire = prepared["input"]
        producer._wire(preflight,wire)
        raw,receipt = read(batch/"assessment/response.json"),read(batch/"assessment/receipt.json")
        if receipt["kind"]=="MODEL_SEMANTIC_JUDGMENT":
            chains.append(provider_chain(root,producer,receipt))
        else:
            require(allow_test_fixtures,"Fixture cannot be reclassified as actual")
        assessment = producer.validate_assessment_quarantine(preflight,wire,raw,receipt,root=root)
        require(assessment.export()==read(batch/"validated.json"),"Saved assessment no longer matches raw/source replay")
        if not settled:
            pending.append(assessment)
            failures[-1]["status"]="VALIDATED_ASSESSMENT_REVIEW_PENDING"
            continue
        if assessment.export()["rows"]:
            request = read(batch/"review/request.json")
            response,rreceipt = read(batch/"review/response.json"),read(batch/"review/receipt.json")
            if rreceipt["kind"]=="MODEL_SEMANTIC_JUDGMENT":
                chains.append(provider_chain(root,producer,rreceipt))
            else:
                require(allow_test_fixtures,"Fixture cannot be reclassified as actual")
            if request["input"].get("version")==REVIEW_VERSION:
                value = validate_compact_review(assessment,response,rreceipt,root=root,producer=producer)
            else:
                value = producer.validate_review(assessment,response,rreceipt,root=root)
        else:
            value = producer.close_rejected_batch(assessment)
        require(value.export()==read(batch/"reviewed.json"),"Saved reviewed rows differ from rederived two-pass result")
        reviewed.append(value)
    require(bool(reviewed or pending),"No source-replayed assessment batch")
    if reviewed:
        result = producer.results_adapter(preflight,reviewed,allow_partial_pool=True,allow_test_fixtures=allow_test_fixtures)
        require(result==read(folder/"result.json"),"Actual case aggregate differs from source/provider replay")
    for r in snapshots:
        verified_path(root,r)
    return reviewed,pending,dict(version="semantic-actual-provider-source-replay/1",inputs=snapshots,
        provider_chains=chains,failed_or_pending_batches=failures,raw_results_replayed=True,
        actual_model_calls_reexecuted=0,native_executions=0,original_result_ref=ref(root,folder/"result.json") if (folder/"result.json").exists() else None)
