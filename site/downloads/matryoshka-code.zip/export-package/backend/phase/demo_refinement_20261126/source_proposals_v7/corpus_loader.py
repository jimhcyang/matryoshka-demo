"""Archive-only V7 codec bridge. No cohort authority, packets or freeze data.

The original algorithm files remain byte-pinned. Only the declarations needed
by the private Live caller are evaluated; saved-cohort loaders are unavailable.
This file replaces corpus_loader.py in the CODE DOWNLOAD ONLY, not production.
"""
import ast
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def require(value, code):
    if not value:
        raise ValueError(code)


def checked(row):
    path = ROOT / row["path"]
    require(path.resolve() == path and path.is_relative_to(ROOT) and not path.is_symlink(), "CAPSULE_CODE_PATH")
    require(hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"], "CAPSULE_CODEC_SOURCE_CHANGED")
    return path


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def root_name(node):
    while isinstance(node, (ast.Attribute, ast.Subscript)):
        node = node.value
    return node.id if isinstance(node, ast.Name) else None


def declarations(path, names, namespace):
    """Exact original AST statements; no hand-copied semantic/eligibility rules."""
    chosen = []
    for node in ast.parse(path.read_bytes(), filename=str(path)).body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names:
            chosen.append(node)
        elif isinstance(node, ast.Assign) and any(root_name(t) in names for t in node.targets):
            chosen.append(node)
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and root_name(node.value.func) in names:
            chosen.append(node)
    require(bool(chosen), "CAPSULE_CODEC_DECLARATION_MISSING")
    exec(compile(ast.Module(body=chosen, type_ignores=[]), str(path), "exec"), namespace)


inputs = json.loads((HERE / "code-only-loader-inputs.json").read_bytes())
require(inputs["version"] == "code-only-v7-codec-inputs/1", "CAPSULE_CODEC_INPUT_VERSION")
paths = {key: checked(row) for key, row in inputs["sources"].items()}
V1 = load("_capsule_v7_public_base_wire", paths["base_wire"])
v2 = dict(__file__=str(paths["partition_wire"]), V1=V1, deepcopy=deepcopy)
aliases = {"DEMO", "EPOCH", "WireError", "require", "encoded", "digest", "strict_json", "file_ref",
    "LIMITS", "PROMPT", "RESPONSE_SCHEMA", "MODEL_INPUT_SCHEMA", "project_page"}
declarations(paths["partition_wire"], aliases, v2)
require(aliases <= v2.keys(), "CAPSULE_PARTITION_CODEC_INCOMPLETE")
V2 = SimpleNamespace(**{k:v2[k] for k in aliases})
overlap = dict(require=V1.require)
declarations(paths["overlap_wire"], {"unique_start"}, overlap)
W = SimpleNamespace(V1=V1, V2=V2, unique_start=overlap["unique_start"],
    **{key:deepcopy(v2[key]) if isinstance(v2[key], (dict, list)) else v2[key]
       for key in aliases - {"project_page"}})

# projector.py needs only loader.W at import. The saved loader itself hashes
# historical model/source packets, so it is deliberately NOT imported here.
prior = sys.modules.get("loader")
public_loader = ModuleType("loader")
public_loader.W = W
sys.modules["loader"] = public_loader
try:
    P = load("_capsule_v7_public_projector", paths["projector"])
finally:
    if prior is None:
        sys.modules.pop("loader", None)
    else:
        sys.modules["loader"] = prior


def unavailable(*args, **kwargs):
    raise ValueError("SAVED_COHORT_AUTHORITY_REQUIRES_SEPARATE_PRIVATE_ARTIFACTS_NOT_IN_CODE_CAPSULE")


L = SimpleNamespace(W=W, checked=unavailable)
authority = load_saved_case = unavailable
