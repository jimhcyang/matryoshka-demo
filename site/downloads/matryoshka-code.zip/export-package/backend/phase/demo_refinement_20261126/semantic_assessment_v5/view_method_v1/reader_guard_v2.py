"""V2 adds complete atom/state fidelity to the unchanged V1 source/math guard."""
from reader_guard import validate_pair as validate_pair_v1
from source_views import V

VERSION = "H-V5-reader-guard/2"
LABELS = {
    "SOURCE_VIEWS_RECORDED": "Qualified source views recorded",
    "CONTEXT_ONLY": "Related source context only",
    "UNRESOLVED": "No accepted source view in assessed pages",
}
SIGNS = ("SUPPORT", "OPPOSE", "CONTEXT")


def validate_pair(method, view):
    validate_pair_v1(method, view)
    refs = method["atom_refs"]
    ids = [r["atom_id"] for r in refs]
    V.require(bool(ids) and len(ids) == len(set(ids))
        and [a["id"] for a in view["atoms"]] == ids,
        "Complete ordered unique public atom inventory required")
    V.require(view["assessment_scope"]["counts_are_not_independent_votes"] is True
        and method["source_independence_claimed"] is False,
        "Document counts cannot become independent votes")
    endpoints = {e["appraisal_id"]: e for e in method["source_endpoints"]}
    for atom, bound in zip(view["atoms"], refs, strict=True):
        V.require(atom["text"] == bound["text"] and atom["query_spans"] == bound["query_spans"]
            and atom["authority"] == "QUERIED_ASSESSMENT_ONLY", "Public atom text/spans/authority differ")
        V.require(atom["counts_are_independent_votes"] is False,
            "Atom document counts are not independent votes")
        eligible = [r for r in method["reviewed_model_result"]["source_judgments"]
            if r["fact_id"] == atom["id"] and r["effective_direction"] in SIGNS
            and r["unanimous_model_accept"] is True
            and endpoints[r["appraisal_id"]]["temporal_eligibility_hold"] is None]
        expected_ids = [r["appraisal_id"] for r in eligible]
        supplied_ids = [e["appraisal_id"] for e in atom["evidence"]]
        V.require(len(expected_ids) == len(set(expected_ids))
            and len(supplied_ids) == len(set(supplied_ids)) and set(supplied_ids) == set(expected_ids),
            "Complete eligible source evidence inventory required")
        counts = {sign: len({r["document_id"] for r in eligible if r["effective_direction"] == sign}) for sign in SIGNS}
        V.require(atom["source_counts"] == counts
            and all(type(atom["source_counts"][sign]) is int for sign in SIGNS),
            "Source counts must derive from eligible METHOD accounts")
        status = ("SOURCE_VIEWS_RECORDED" if counts["SUPPORT"] or counts["OPPOSE"] else
            "CONTEXT_ONLY" if counts["CONTEXT"] else "UNRESOLVED")
        V.require(atom["status"] == status and atom["label"] == LABELS[status],
            "Atom state/label must derive from eligible source directions")
    return True
