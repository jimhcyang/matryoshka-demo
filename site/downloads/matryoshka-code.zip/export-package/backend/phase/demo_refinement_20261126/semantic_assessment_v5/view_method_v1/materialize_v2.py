"""Frozen V1 replay/materialization with only the V2 receiver guard substituted."""
import argparse
import json
from pathlib import Path
from types import FunctionType

import materialize as V1
from reader_guard_v2 import VERSION, validate_pair
from source_views import HERE, ROOT, V
from runtime import ref, verified_path

OLD_READY_SHA256 = "5a1cd4f61c7212bae39549883826a4591975cd5c96d4a80c1077ce1e64fedb90"


def _old_ready():
    reference = ref(ROOT, HERE / "READY.json")
    V.require(reference["sha256"] == OLD_READY_SHA256, "Frozen V1 READY changed")
    ready = V.V3.checked(ROOT, reference)
    for item in ready["files"] + ready["dependency_refs"]:
        verified_path(ROOT, item)
    return reference, ready


def certify_existing(materialization_ref, *, _fresh_replay=False):
    old_ref, old = _old_ready()
    V.require(_fresh_replay or materialization_ref == old["actual_materialization_ref"],
        "Existing certification requires the exact frozen actual materialization; use fresh replay for a new run")
    materialization = V.V3.checked(ROOT, materialization_ref)
    V.require(materialization["version"] == "H-V5-source-view-materialization/1",
        "Unchanged V1 source-replay materialization required")
    guard_ref = ref(ROOT, HERE / "reader_guard_v2.py")
    contract_ref = ref(ROOT, HERE / "READER_CONTRACT_V2.json")
    case_refs = []
    for case in materialization["outputs"]:
        method = V.V3.checked(ROOT, case["outputs"]["METHOD"])
        view = V.V3.checked(ROOT, case["outputs"]["VIEW"])
        validate_pair(method, view)
        folder = verified_path(ROOT, case["outputs"]["VIEW"]).parent
        ready = dict(version="H-V5-source-view-case-ready/2", state="RECEIVER_V2_PASS_REVIEW_REQUIRED",
            case_id=case["case_id"], method_id=view["method_id"], VIEW_version=view["version"], METHOD_version=method["version"],
            producer_ready_ref=old["producer_ready_ref"], adapter_ref=old["adapter_ref"],
            guard_ref=guard_ref, reader_contract_ref=contract_ref, source_replay_materialization_ref=materialization_ref,
            inputs_ref=case["inputs_ref"], **case["outputs"],
            original_native_ref=view["original_native_ref"], original_inspection_ref=view["original_inspection_ref"],
            source_provider_replay_inherited_unchanged=True, METHOD_VIEW_bytes_changed=False,
            new_API_calls=0, native_executions=0, UI_or_publication_clearance=False)
        if (folder / "READY.json").is_file():
            ready["supersedes_ready_ref"] = ref(ROOT, folder / "READY.json")
        case_refs.append(V1.save(folder / "READY_V2.json", ready))
    output = dict(version="H-V5-source-view-materialization/2", guard_version=VERSION,
        original_materialization_ref=materialization_ref, inherited_adapter_ready_ref=old_ref,
        guard_ref=guard_ref, reader_contract_ref=contract_ref, case_ready_refs=case_refs,
        original_outputs=materialization["outputs"], METHOD_VIEW_bytes_changed=False,
        new_API_calls=0, native_executions=0, UI_or_publication_clearance=False)
    folder = verified_path(ROOT, materialization_ref).parent
    for item in materialization["original_refs_verified_unchanged"]:
        verified_path(ROOT, item)
    return V1.save(folder / "MATERIALIZATION_V2.json", output)


def materialize(run_dir, out):
    # Isolate the one replaced dependency; do not patch V1 module globals.
    _old_ready()
    function = V1.materialize
    upgraded = FunctionType(function.__code__, dict(function.__globals__, validate_pair=validate_pair),
        function.__name__, function.__defaults__, function.__closure__)
    receipt_ref = upgraded(run_dir, out)
    return certify_existing(receipt_ref, _fresh_replay=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--existing-materialization", type=Path)
    mode.add_argument("--run-dir", type=Path)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    if args.existing_materialization:
        result = certify_existing(ref(ROOT, args.existing_materialization))
    else:
        V.require(args.out is not None, "New immutable output label required")
        result = materialize(args.run_dir, args.out)
    print(json.dumps(result, indent=2))
