"""API0 materialization of an exact settled parent H V5 source-view run."""
import argparse
import json
from pathlib import Path

from source_views import HERE, ROOT, V, bind_case, replay_case, validate_authorization
from reader_guard import validate_pair
from runtime import ref, verified_path
from matryoshka_demo.io import offline


def save(path, value):
    V.require(path.resolve().is_relative_to(HERE), "Only new view-method namespace writes allowed")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, sort_keys=True, ensure_ascii=True, allow_nan=False, indent=2)
        stream.write("\n")
    return ref(ROOT, path)


def materialize(run_dir, out):
    run_dir = run_dir.resolve()
    V.require(run_dir.is_relative_to(ROOT) and not out.exists(), "Exact project run and new immutable output required")
    authorization_ref = ref(ROOT, run_dir / "AUTHORIZATION.json")
    results_ref = ref(ROOT, run_dir / "RESULTS.json")
    summary = V.V3.checked(ROOT, results_ref)
    authorization = V.V3.checked(ROOT, authorization_ref)
    validate_authorization(ROOT, authorization, summary_version=summary["version"])
    V.require(summary["native_rewritten"] is False,
        "Settled H V5 run required")
    outputs, protected = [], [authorization_ref, results_ref]
    with offline():
        for case in summary["cases"]:
            manifest = bind_case(ROOT, authorization_ref, case["result_ref"])
            V.require(manifest["case_id"] == case["case_id"], "Summary case/result differs")
            target = out / case["case_id"]
            manifest_ref = save(target / "INPUT_REFS.json", manifest)
            method, view, replay, qa = replay_case(ROOT, manifest)
            validate_pair(method, view)
            refs = {name: save(target / (name + ".json"), value)
                for name, value in (("METHOD", method), ("VIEW", view), ("REPLAY", replay), ("QA", qa))}
            protected.extend(replay["input_refs"])
            protected += [view["original_native_ref"], view["original_inspection_ref"]]
            outputs.append(dict(case_id=case["case_id"], inputs_ref=manifest_ref, outputs=refs,
                source_view_atoms=qa["source_view_atoms"], assessment_scope=view["assessment_scope"],
                provider_chains_replayed=qa["provider_chains_replayed"]))
            print(json.dumps(dict(case_id=case["case_id"], outputs=refs,
                source_view_atoms=qa["source_view_atoms"])), flush=True)
    for reference in protected:
        verified_path(ROOT, reference)
    receipt = dict(version="H-V5-source-view-materialization/1", status="SOURCE_PROVIDER_REPLAY_PASS_NOT_RELEASE_CLEARANCE",
        actual_parent_results_ref=results_ref, outputs=outputs, original_refs_verified_unchanged=protected,
        new_API_calls=0, native_executions=0, source_producer_changed=False,
        original_model_or_native_outputs_changed=False, production_files_edited=[], UI_or_publication_clearance=False)
    return save(out / "MATERIALIZATION.json", receipt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, default=HERE / "actual_regional_v1")
    args = parser.parse_args()
    print(json.dumps(materialize(args.run_dir, args.out), indent=2))
