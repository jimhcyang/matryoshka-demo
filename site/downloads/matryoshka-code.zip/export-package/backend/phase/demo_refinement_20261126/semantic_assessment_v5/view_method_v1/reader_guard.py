"""API0 receiver contract checks for the explicit H V5 VIEW/METHOD pair."""
import math

from source_views import V, METHOD_ID, METHOD_VERSION, VIEW_VERSION, digest


def validate_pair(method, view):
    V.require(method["version"] == METHOD_VERSION and view["version"] == VIEW_VERSION
        and method["method_id"] == view["method_id"] == METHOD_ID, "Explicit H V5 route required")
    for value in (method, view):
        V.require(value["sha256"] == digest({k: v for k, v in value.items() if k != "sha256"}),
            "Source-view content digest differs")
    V.require(view["method_packet_sha256"] == method["sha256"]
        and view["case"] == method["public_case"] and view["case"]["task"] == "hypothesis"
        and view["query_sha256"] == method["query_sha256"] == digest(view["case"]["query"])
        and view["original_native_ref"] == method["inspection_authority"]["native_ref"]
        and view["original_inspection_ref"] == method["inspection_authority"]["inspection_ref"]
        and view["execution_context"] == method["inspection_authority"]["execution_context"]
        and view["source_view_policy"] == method["source_view_policy"]
        and view["assessment_scope"] == method["assessment_scope"]
        and view["trace"] == method["graph"]
        and view["source_endpoints"] == method["source_endpoints"], "VIEW/METHOD/source binding differs")
    V.require(not view["incumbent_native_method"] and view["coverage"] is None
        and not view["native_status_or_gates_rewritten"] and not view["world_truth_certified"]
        and not view["synthetic_native_ESTABLISHED_labels_created"]
        and not view["deterministic_event_join_authority"] and not view["identity_authority"],
        "Source method cannot gain native/world authority")
    scope = view["assessment_scope"]
    V.require(scope["processed_slots"] + scope["unprocessed_slots"] == scope["original_slots"]
        and sum(scope[k] for k in ("accepted_slots", "held_slots", "rejected_slots", "review_pending_slots"))
            == scope["processed_slots"]
        and scope["inspected_pool_completely_assessed"] == (scope["accepted_slots"] == scope["original_slots"])
        and scope["partial_source_search"] and not scope["whole_corpus_search_claimed"], "Source scope disclosure differs")
    nodes = {n["id"]: n for n in view["trace"]["nodes"]}
    raw_pages = [n for n in nodes.values() if n["kind"] == "SOURCE_PAGE"]
    endpoints = {e["appraisal_id"]: e for e in view["source_endpoints"]}
    model_rows = {r["appraisal_id"]: r for r in method["reviewed_model_result"]["source_judgments"]}
    V.require(view["trace"]["native_semantic_edges_created"] == 0
        and not view["trace"]["actual_KG_edges_inferred"], "No invented KG route")
    for atom in view["atoms"]:
        V.require(atom["coverage"] is None and atom["world_truth_verdict"] == "NOT_ASSESSED"
            and not atom["whole_query_entailed"], "H direction is not whole-query entailment")
        counts = {sign: len({e["citation"]["document_id"] for e in atom["evidence"] if e["direction"] == sign})
            for sign in ("SUPPORT", "OPPOSE", "CONTEXT")}
        V.require(atom["source_counts"] == counts, "Directional document counts differ")
        for evidence in atom["evidence"]:
            original = model_rows[evidence["appraisal_id"]]
            raw = original["raw_model_row"]
            V.require(original["fact_id"] == atom["id"]
                and original["effective_direction"] == evidence["direction"]
                and original["unanimous_model_accept"] is True
                and all(evidence[k] == original[k] for k in ("review", "source_attribution", "requested_facet_weights",
                    "literal_agreement_coverage", "evidence_alignment_coverage", "context_priority_index", "local_lexical_fit"))
                and all(evidence[k] == raw[k] for k in ("kind", "mode", "qualifier_quotes", "argument_quote", "issue", "fields")),
                "Reader evidence differs from replayed V5 model row")
            endpoint = endpoints[evidence["appraisal_id"]]
            V.require(endpoint["native_KG_node_id"] is None and endpoint["native_semantic_route"] is None
                and evidence["citation"] == endpoint["quote"]
                and evidence["qualification_citation"] == endpoint["qualification_quote"], "Inspection endpoint differs")
            V.require(endpoint["temporal_eligibility_hold"] is None, "Held source cannot enter eligible evidence")
            for key, node_key in (("citation", "source_endpoint_id"), ("qualification_citation", "qualification_endpoint_id")):
                citation = evidence[key]
                V.require(nodes[evidence[node_key]]["citation"] == citation
                    and any(p["document_id"] == citation["document_id"] and p["page_sha256"] == citation["page_sha256"]
                        == digest(p["raw_text"]) and p["raw_text"][citation["start"]:citation["end"]] == citation["text"]
                        for p in raw_pages), "Exact raw source excerpt differs")
            V.require(evidence["model_quote_unchanged"] == evidence["citation"]["text"]
                and evidence["model_reviewed"] and evidence["review"]["decision"] == "ACCEPT"
                and evidence["review"]["direction"] == evidence["direction"], "Fresh source review differs")
            voice = evidence["source_attribution"]
            V.require(voice["canonical_document_id"] == evidence["citation"]["document_id"]
                and voice["page_sha256"] == evidence["citation"]["page_sha256"]
                and not voice["person_identity_inferred"]
                and (voice["kind"] != "DOCUMENT_REPORTING_VOICE" or voice["speaker_quote"] is None),
                "Document voice cannot invent a speaker")
            weights, fields = evidence["requested_facet_weights"], evidence["fields"]
            total = sum(weights.values())
            V.require(total > 0 and weights == {k: V.V3.WEIGHTS[k] for k in weights}, "Facet weights differ")
            literal = sum(w for k, w in weights.items() if fields[k]["state"] == "MATCHED") / total
            states = {"MATCHED", "CONFLICTING"} if evidence["direction"] == "OPPOSE" else {"MATCHED"}
            alignment = sum(w for k, w in weights.items() if fields[k]["state"] in states) / total
            priority = .75 * alignment + .25 * evidence["local_lexical_fit"]["value"]
            for actual, expected in ((evidence["literal_agreement_coverage"], literal),
                    (evidence["facet_coverage"], literal), (evidence["evidence_alignment_coverage"], alignment),
                    (evidence["context_priority_index"], priority)):
                V.require(type(actual) in {int, float} and math.isfinite(actual)
                    and math.isclose(actual, expected, rel_tol=0., abs_tol=1e-12), "Source alignment arithmetic differs")
            V.require(not any(evidence[k] for k in ("world_truth", "inner_execution", "event_join_authority",
                "identity_authority", "calibrated_probability", "deterministic_proof")), "Unexpected source-view authority")
    return True
