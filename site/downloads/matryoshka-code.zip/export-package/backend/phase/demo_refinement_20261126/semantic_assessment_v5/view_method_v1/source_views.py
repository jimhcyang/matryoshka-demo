"""Typed H V5 source-view projection from source/provider-replayed capsules."""
from copy import deepcopy
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(HERE.parent))
import producer_v5 as V
from runtime import source_context, verified_path, ref
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import descriptor
from matryoshka_next.facts import SourcePolicy

METHOD_VERSION = "reviewed-H-source-view-method/1"
VIEW_VERSION = "reviewed-H-source-workbench-view/5"
MANIFEST_VERSION = "H-V5-source-view-replay-input/1"
METHOD_ID = V.METHOD_ID
BASE_READY_SHA256 = "d10a1ac5d574dd0bb848d5bbbb02e002a46f5f37f4a68bec9b07844a33316c48"
RUN_VERSIONS = {"parent-H-v5-source-pilot/1": "actual-H-source-view-pilot/5",
    "parent-typed-H-source-pilot/2": "actual-typed-H-source-pilot/2"}


def rehash(value):
    value.pop("sha256", None)
    value["sha256"] = digest(value)
    return value


def _read(root, reference):
    return V.V3.checked(root, reference)


def validate_authorization(root, authorization, *, summary_version=None):
    """Closed legacy/typed run bindings, not permission for any new API call."""
    version = authorization["version"]
    V.require(version in RUN_VERSIONS and (summary_version is None or summary_version == RUN_VERSIONS[version]),
        "Unsupported or mismatched parent H run versions")
    V.require(authorization["producer_ready_ref"]["sha256"] == BASE_READY_SHA256,
        "Different frozen V5 producer authority")
    review = _read(root, authorization["independent_review_ref"])
    V.require(review["producer_ready_ref"] == authorization["producer_ready_ref"], "Independent producer binding differs")
    verified_path(root, authorization["runner_ref"])
    if version == "parent-typed-H-source-pilot/2":
        typed_ref = authorization["typed_wire_ready_ref"]
        typed = _read(root, typed_ref)
        V.require(review["status"] == "SCOPED_GO_FRESH_TYPED_H_V5_APPRAISAL_AND_SEPARATE_REVIEW_ONLY"
            and review["paid_source_boundary_cleared"] is True
            and review["typed_wire_ready_ref"] == typed_ref
            and review["runner_ref"] == authorization["runner_ref"]
            and review["preflight_ref"] == authorization["preflight_ref"]
            and typed["producer_ready_ref"] == authorization["producer_ready_ref"]
            and typed["preflight_ref"] == authorization["preflight_ref"]
            and authorization["appraisal_packets"] == 24 and authorization["max_calls"] == 48,
            "Exact typed READY/producer/preflight/runner/independent review binding required")
        for reference in typed["files"] + typed["dependency_refs"]:
            verified_path(root, reference)
    else:
        V.require(review["status"] == "SCOPED_GO_FRESH_H_APPRAISAL_AND_SEPARATE_REVIEW_ONLY"
            and authorization["appraisal_packets"] == 16 and authorization["max_calls"] == 32,
            "Original legacy V5 run binding differs")
    matrix = _read(root, authorization["preflight_ref"])
    V.require(len(matrix["packets"]) == authorization["appraisal_packets"]
        and len(matrix["cases"]) == (4 if version == "parent-typed-H-source-pilot/2" else 3),
        "Exact declared full run matrix differs")
    return matrix


def bind_case(root, authorization_ref, result_ref, *, temporal_warnings_ref=None):
    """Collect exact refs from the declared parent layout; no provider call."""
    root = Path(root).resolve()
    authorization, result = _read(root, authorization_ref), _read(root, result_ref)
    matrix_ref = authorization["preflight_ref"]
    matrix = validate_authorization(root, authorization)
    cid = result["public_case"]["case_id"]
    cases = [c for c in matrix["cases"] if c["case_id"] == cid]
    V.require(len(cases) == 1, "Case not uniquely declared in actual parent matrix")
    selected = [r for r in matrix["packets"] if Path(r["path"]).parent.name == cid]
    V.require(bool(selected), "No declared source packets")
    folder = verified_path(root, result_ref).parent
    expected = {f"batch_{i:02d}" for i in range(len(selected))}
    V.require({p.name for p in folder.glob("batch_*") if p.is_dir()} == expected,
        "Declared batches differ from actual retained case folders")
    batches = []
    names = dict(assessment_request_ref="assessment/request.json",
        assessment_response_ref="assessment/response.json", assessment_receipt_ref="assessment/receipt.json",
        validated_ref="validated.json", review_response_ref="review/response.json",
        review_receipt_ref="review/receipt.json", reviewed_ref="reviewed.json", error_ref="ERROR.json")
    for index, packet_ref in enumerate(selected):
        batch = folder / f"batch_{index:02d}"
        refs = {key: ref(root, batch / name) if (batch / name).is_file() else None
            for key, name in names.items()}
        batches.append(dict(id=batch.name, packet_ref=packet_ref, **refs))
    return rehash(dict(version=MANIFEST_VERSION, authorization_ref=authorization_ref,
        matrix_ref=matrix_ref, producer_ready_ref=authorization["producer_ready_ref"],
        case_id=cid, result_ref=result_ref, inspection_authority=cases[0]["inspection_authority"],
        batches=batches, temporal_warnings_ref=temporal_warnings_ref,
        actual_model_calls_reexecuted=0, native_executions=0))


def inventory(preflight, reviewed, pending=(), *, eligibility_holds=(), allow_test_fixtures=False):
    """Partition actual processing states; reviewed HOLD is not accepted evidence."""
    V.require(type(preflight) is V.V3.P.Preflight, "Trusted source Preflight required")
    data = preflight.export()
    facts, pages = {f["id"]: f for f in data["required_facts"]}, {p["id"]: p for p in data["pages"]}
    seen, rows = set(), []
    for capsule in [*reviewed, *pending]:
        is_reviewed = type(capsule) is V.Reviewed
        V.require(is_reviewed or type(capsule) is V.Assessment, "Trusted V5 source capsule required")
        d = capsule.export()
        V.require(d["preflight_sha256"] == data["sha256"] and (allow_test_fixtures or not d["test_only"]),
            "Different or fixture source assessment")
        V.checked_wire(preflight, d["wire"])
        expected = {(f, p["id"]) for f in facts for p in d["wire"]["pages"]}
        V.require({(r["fact_id"], r["page_id"]) for r in d["rows"]} == expected
            and len(d["rows"]) == len(expected), "Incomplete or duplicate fact/page matrix")
        for row in d["rows"]:
            key = row["fact_id"], row["page_id"]
            V.require(key not in seen and key[0] in facts and key[1] in pages, "Duplicate or unknown source slot")
            seen.add(key)
            provider_reviewed = is_reviewed and isinstance(row.get("review"), dict)
            accepted = provider_reviewed and row["unanimous_model_accept"] is True
            state = ("ROW_REJECTED" if row["status"] == "REJECTED_ROW" else
                "FIRST_PASS_HOLD" if row["status"] == "HOLD" else
                "REVIEW_PENDING" if not provider_reviewed else
                "REVIEW_HOLD" if not accepted else "ACCEPTED_" + row["effective_direction"])
            if row["appraisal_id"] in eligibility_holds and state != "ROW_REJECTED":
                state = "SOURCE_ELIGIBILITY_HOLD"
            rows.append(dict(fact_id=key[0], page_id=key[1], document_id=pages[key[1]]["document_id"],
                appraisal_id=row["appraisal_id"], state=state, provider_reviewed=provider_reviewed,
                model_accepted=accepted, source_view_credit=bool(accepted and row.get("source_view_credit")
                    and row["appraisal_id"] not in eligibility_holds),
                error=row.get("error"), issues=deepcopy(row.get("issues", [])),
                request_sha256=d["wire"]["request_sha256"]))
    by_key = {(r["fact_id"], r["page_id"]): r for r in rows}
    grid = [by_key.get((f, p), dict(fact_id=f, page_id=p, document_id=pages[p]["document_id"],
        appraisal_id=None, state="UNPROCESSED", provider_reviewed=False, model_accepted=False,
        source_view_credit=False, error=None, issues=[], request_sha256=None)) for p in pages for f in facts]
    counts = dict(original_slots=len(grid), processed_slots=len(seen),
        provider_reviewed_slots=sum(r["provider_reviewed"] for r in grid),
        model_accepted_slots=sum(r["model_accepted"] for r in grid),
        accepted_slots=sum(r["model_accepted"] and r["state"] != "SOURCE_ELIGIBILITY_HOLD" for r in grid),
        directional_source_view_slots=sum(r["source_view_credit"] for r in grid),
        held_slots=sum(r["state"] in {"FIRST_PASS_HOLD", "REVIEW_HOLD", "SOURCE_ELIGIBILITY_HOLD"} for r in grid),
        eligibility_hold_slots=sum(r["state"] == "SOURCE_ELIGIBILITY_HOLD" for r in grid),
        rejected_slots=sum(r["state"] == "ROW_REJECTED" for r in grid),
        review_pending_slots=sum(r["state"] == "REVIEW_PENDING" for r in grid),
        unprocessed_slots=sum(r["state"] == "UNPROCESSED" for r in grid))
    V.require(sum(counts[k] for k in ("accepted_slots", "held_slots", "rejected_slots", "review_pending_slots"))
        == counts["processed_slots"], "Processed state partition differs")
    complete = counts["accepted_slots"] == counts["original_slots"]
    return dict(version="H-V5-source-assessment-scope/1", grid=grid, **counts,
        original_pages=len(pages), required_facts=len(facts),
        inspected_pool_completely_processed=counts["unprocessed_slots"] == 0,
        inspected_pool_completely_assessed=complete, partial_assessment=not complete,
        partial_source_search=True, whole_corpus_search_claimed=False,
        scope="RECORDED_NATIVE_INSPECTED_PAGES_NOT_WHOLE_ELIGIBLE_CORPUS",
        accepted_NONE_is_page_local_not_absence_elsewhere=True, unprocessed_is_NOT_NONE=True,
        counts_are_not_independent_votes=True)


def _temporal_warnings(data, warnings):
    pages = {p["id"]: p for p in data["pages"]}
    V.require(len({w["page_id"] for w in warnings}) == len(warnings), "Duplicate source-date warning")
    bound = {}
    for warning in warnings:
        page = pages[warning["page_id"]]
        V.require(warning["document_id"] == page["document_id"]
            and warning["page_sha256"] == page["source_sha256"] == digest(page["text"])
            and warning["canonical_source_date"] == page["date"]
            and warning["origin_cutoff"] == data["public_case"]["date"]
            and bool(warning["exact_page_spans"]), "Source-date warning authority differs")
        for s in warning["exact_page_spans"]:
            V.require(type(s["start"]) is int and type(s["end"]) is int
                and 0 <= s["start"] < s["end"] <= len(page["text"])
                and page["text"][s["start"]:s["end"]] == s["text"], "Source warning raw span differs")
        bound[page["id"]] = dict(deepcopy(warning), temporal_eligibility_hold=True,
            eligible_directional_vote=False, source_date_rewritten=False,
            date_resolution="UNRESOLVED_SOURCE_OWNER_REVIEW_REQUIRED")
    return bound


def project(preflight, policy, native, reviewed, *, pending=(), original_result=None,
        replay=None, temporal_warnings=(), allow_test_fixtures=False):
    """New H reader method, not a native DTO or historical world-proof upgrade."""
    data = preflight.export()
    V.require(type(policy) is SourcePolicy and policy.case == V.V3.P.engine_case(data["public_case"])
        and descriptor(policy.source_view_policy) == data["source_view_policy"], "Same canonical source policy required")
    V.require(native["public_case"] == data["public_case"] and data["public_case"]["task"] == "hypothesis",
        "Same unchanged public H native required")
    result = V.results(preflight, reviewed, allow_partial_pool=True, allow_test_fixtures=allow_test_fixtures)
    if original_result is not None:
        V.require(result == original_result, "Actual original V5 aggregate differs from rederived capsules")
    pages = {p["id"]: p for p in data["pages"]}
    scored = {r["appraisal_id"]: r for r in result["source_judgments"]}
    audit = [deepcopy(scored[r["appraisal_id"]]) if r["appraisal_id"] in scored else deepcopy(r)
        for capsule in [*reviewed, *pending] for r in capsule.export()["rows"]]
    warnings = _temporal_warnings(data, temporal_warnings)
    holds = {r["appraisal_id"] for r in audit if r["page_id"] in warnings}
    scope = inventory(preflight, reviewed, pending, eligibility_holds=holds,
        allow_test_fixtures=allow_test_fixtures)
    for row in audit:
        if row["page_id"] in warnings:
            row.update(temporal_eligibility_hold=warnings[row["page_id"]], eligible_directional_vote=False,
                eligibility_projection_not_new_model_review=True)
    nodes, edges, endpoints = {}, [], []
    facts = {f["id"]: f for f in data["required_facts"]}
    for fact in facts.values():
        key = "input-assessment:" + digest([data["sha256"], fact["id"]])
        nodes[key] = dict(id=key, kind="REQUIRED_PUBLIC_H_ASSESSMENT", atom_id=fact["id"],
            text=fact["text"], query_spans=fact["query_spans"])

    def bind(row, span):
        page = pages[row["page_id"]]
        pi = policy.corpus.page_index[page["id"]]
        actual = policy.corpus.pages[pi]
        V.require(policy.allowed(pi) and all(actual[k] == page[k] for k in page),
            "Canonical source page/policy differs")
        citation = policy.citation(pi, span["start"], span["end"])
        V.require(citation["text"] == span["text"] and citation["page_sha256"] == page["source_sha256"],
            "Exact source citation/span/hash differs")
        did = "source-document:" + digest([page["corpus"], page["document_id"]])
        pid = "source-page:" + digest([page["id"], page["source_sha256"]])
        eid = "source-excerpt:" + digest(citation)
        nodes[did] = dict(id=did, kind="SOURCE_DOCUMENT", document_id=page["document_id"], corpus=page["corpus"])
        nodes[pid] = dict(id=pid, kind="SOURCE_PAGE", canonical_page_id=page["id"],
            document_id=page["document_id"], date=page["date"], page_sha256=page["source_sha256"], raw_text=page["text"])
        nodes[eid] = dict(id=eid, kind="EXACT_RAW_SOURCE_EXCERPT", citation=citation, ordinary_KG_node_id=None)
        for a, b, kind in ((did, pid, "RECORDED_DOCUMENT_PAGE"), (pid, eid, "EXACT_RAW_SPAN_CONTAINMENT")):
            edge = dict(source=a, target=b, kind=kind, historical_relation_certified=False,
                event_join_authority=False)
            if edge not in edges:
                edges.append(edge)
        return eid, citation

    for row in audit:
        if not row.get("qualification_envelope"):
            continue
        env = row["qualification_envelope"]
        eid, citation = bind(row, env["raw_quote_span"])
        qid, qualification = bind(row, env["paragraph"])
        account = "model-H-source-view:" + row["appraisal_id"]
        direction = row.get("effective_direction", "REVIEW_PENDING" if row["status"] == "REVIEWABLE" else "HOLD")
        eligible_vote = bool(row.get("source_view_credit")) and row["appraisal_id"] not in holds
        nodes[account] = dict(id=account, kind="MODEL_H_SOURCE_VIEW", appraisal_id=row["appraisal_id"],
            direction=direction, eligible_directional_vote=eligible_vote,
            deterministic_proof=False, inner_execution=False, world_truth=False)
        target = "input-assessment:" + digest([data["sha256"], row["fact_id"]])
        edges += [dict(source=eid, target=account, kind="QUOTED_MODEL_INPUT", historical_relation_certified=False),
            dict(source=qid, target=account, kind="FULL_QUALIFICATION_CONTEXT", historical_relation_certified=False),
            dict(source=account, target=target, kind="MODEL_APPRAISES_H_ISSUE", direction=direction,
                deterministic_support=False, event_join_authority=False)]
        endpoints.append(dict(atom_id=row["fact_id"], appraisal_id=row["appraisal_id"], endpoint_id=eid,
            qualification_endpoint_id=qid, quote=citation, qualification_quote=qualification,
            source_edition=citation.get("source_edition"), physical_page=citation.get("physical_page"),
            native_KG_node_id=None, native_semantic_route=None, inspection_only=True,
            input_to_source_world_edge_invented=False, eligible_directional_vote=eligible_vote,
            temporal_eligibility_hold=warnings.get(row["page_id"])))
    graph = dict(version="H-source-containment-inspection-graph/1", nodes=list(nodes.values()), edges=edges,
        native_semantic_edges_created=0, actual_KG_edges_inferred=False)
    origin = dict(document_id=data["public_case"]["document_id"], date=data["public_case"]["date"],
        inherited_binding="ORIGINAL_PUBLIC_CASE_AND_PINNED_NATIVE", origin_body_used=False,
        origin_packet_ref_not_invented=True)
    method = rehash(dict(version=METHOD_VERSION, method_id=METHOD_ID, method_label="Reviewed source views",
        producer_version=V.VERSION, incumbent_native_method=False, public_case=data["public_case"],
        query_sha256=digest(data["public_case"]["query"]), preflight_sha256=data["sha256"],
        inspection_authority=data["inspection_authority"], source_view_policy=data["source_view_policy"],
        source_origin=origin, atom_refs=[dict(atom_id=f["id"], text=f["text"], query_spans=f["query_spans"]) for f in facts.values()],
        reviewed_model_result=result, audit_accounts=audit, assessment_scope=scope,
        source_integrity_warnings=list(warnings.values()),
        source_endpoints=endpoints, graph=graph, replay=deepcopy(replay),
        receiver_labels=result["receiver_labels"], score_formula=result["score_formula"], score_units=result["score_units"],
        native_history_modified=False, native_gates_modified=False, deterministic_semantic_proof=False,
        world_truth_certified=False, inner_execution=False, event_join_authority=False,
        identity_authority=False, source_independence_claimed=False, test_only=allow_test_fixtures))
    by_endpoint = {e["appraisal_id"]: e for e in endpoints}
    atoms = []
    for atom in result["atoms"]:
        evidence = []
        for row in result["source_judgments"]:
            if row["fact_id"] != atom["id"] or row["effective_direction"] not in {"SUPPORT", "OPPOSE", "CONTEXT"} or row["appraisal_id"] in holds:
                continue
            V.require(row["unanimous_model_accept"] is True, "Unreviewed source row cannot enter reader evidence")
            endpoint = by_endpoint[row["appraisal_id"]]
            raw = row["raw_model_row"]
            evidence.append(dict(appraisal_id=row["appraisal_id"], direction=row["effective_direction"],
                kind=raw["kind"], citation=endpoint["quote"], qualification_citation=endpoint["qualification_quote"],
                source_endpoint_id=endpoint["endpoint_id"], qualification_endpoint_id=endpoint["qualification_endpoint_id"],
                model_quote_unchanged=raw["quote"], source_attribution=row["source_attribution"],
                mode=raw["mode"], qualifier_quotes=raw["qualifier_quotes"], argument_quote=raw["argument_quote"],
                issue=raw["issue"], fields=raw["fields"], requested_facet_weights=row["requested_facet_weights"],
                query_anchor_candidates=row["query_anchor_candidates"], source_anchor_candidates=row["source_anchor_candidates"],
                literal_agreement_coverage=row["literal_agreement_coverage"], evidence_alignment_coverage=row["evidence_alignment_coverage"],
                alignment_states=row["alignment_states"], facet_coverage=row["facet_coverage"],
                local_lexical_fit=row["local_lexical_fit"], context_priority_index=row["context_priority_index"],
                review=row["review"], authority="QUERIED_ASSESSMENT_ONLY", source_view_credit=row["source_view_credit"],
                model_reviewed=True, partial_coverage_is_not_full_entailment=True,
                deterministic_proof=False, calibrated_probability=False, world_truth=False,
                inner_execution=False, event_join_authority=False, identity_authority=False))
        evidence.sort(key=lambda e: (-e["context_priority_index"], e["appraisal_id"]))
        counts = {sign: len({e["citation"]["document_id"] for e in evidence if e["direction"] == sign})
            for sign in ("SUPPORT", "OPPOSE", "CONTEXT")}
        status = "SOURCE_VIEWS_RECORDED" if counts["SUPPORT"] or counts["OPPOSE"] else "CONTEXT_ONLY" if counts["CONTEXT"] else "UNRESOLVED"
        held_sources = [dict(appraisal_id=r["appraisal_id"], original_model_direction=r.get("effective_direction"),
            reader_class="INSPECTED_CONTEXT_WITH_SOURCE_ELIGIBILITY_HOLD", context_priority_index=0.,
            citation=by_endpoint[r["appraisal_id"]]["quote"] if r["appraisal_id"] in by_endpoint else None,
            temporal_eligibility_hold=r["temporal_eligibility_hold"], eligible_directional_vote=False)
            for r in audit if r["fact_id"] == atom["id"] and r["appraisal_id"] in holds]
        atoms.append(dict(id=atom["id"], text=atom["text"], query_spans=facts[atom["id"]]["query_spans"], status=status,
            label="Qualified source views recorded" if status == "SOURCE_VIEWS_RECORDED" else
                "Related source context only" if status == "CONTEXT_ONLY" else "No accepted source view in assessed pages",
            authority="QUERIED_ASSESSMENT_ONLY", evidence=evidence, source_counts=counts, held_source_context=held_sources,
            counts_are_independent_votes=False, coverage=None, whole_query_entailed=False,
            world_truth_verdict="NOT_ASSESSED"))
    counts_text = ("Processed {processed_slots}/{original_slots}; provider-reviewed {provider_reviewed_slots}; "
        "accepted {accepted_slots}; held {held_slots}; rejected {rejected_slots}; "
        "review-pending {review_pending_slots}; unprocessed {unprocessed_slots}.").format(**scope)
    view = rehash(dict(version=VIEW_VERSION, method_id=METHOD_ID, method_label=method["method_label"],
        incumbent_native_method=False, producer_version=V.VERSION, case=data["public_case"],
        query_sha256=method["query_sha256"], original_native_ref=data["inspection_authority"]["native_ref"],
        original_inspection_ref=data["inspection_authority"]["inspection_ref"],
        execution_context=data["inspection_authority"]["execution_context"], source_origin=origin,
        source_view_policy=data["source_view_policy"], method_packet_sha256=method["sha256"],
        atoms=atoms, coverage=None, assessment_scope=scope, source_endpoints=endpoints, trace=graph,
        receiver_labels=result["receiver_labels"], score_formula=result["score_formula"], score_units=result["score_units"],
        source_integrity_warnings=list(warnings.values()),
        model_provenance=result["model_provenance"],
        caveat="Reviewed MODEL source views, not world-event proof. " + counts_text
            + " Partial source search/assessment; inspected pages are not the whole eligible corpus.",
        review_pending_disclosure="First-pass rows await valid independent review." if scope["review_pending_slots"] else None,
        native_status_or_gates_rewritten=False, source_drawer_reuses_exact_citations=True,
        origin_drawer_binding_unchanged=True, synthetic_native_ESTABLISHED_labels_created=False,
        deterministic_event_join_authority=False, identity_authority=False, world_truth_certified=False))
    return method, view


def replay_case(root, manifest):
    """Replay exact fresh V5 provider chains and sources before materialization."""
    root = Path(root).resolve()
    V.require(manifest["version"] == MANIFEST_VERSION and manifest["sha256"] ==
        digest({k: v for k, v in manifest.items() if k != "sha256"}), "Replay input changed")
    ready_ref = manifest["producer_ready_ref"]
    V.require(ready_ref["sha256"] == BASE_READY_SHA256, "Different frozen V5 producer")
    ready = _read(root, ready_ref)
    for reference in ready["files"]:
        verified_path(root, reference)
    authorization = _read(root, manifest["authorization_ref"])
    V.require(authorization["preflight_ref"] == manifest["matrix_ref"]
        and authorization["producer_ready_ref"] == ready_ref, "Parent authorization binding differs")
    matrix = validate_authorization(root, authorization)
    case = [c for c in matrix["cases"] if c["case_id"] == manifest["case_id"]]
    V.require(len(case) == 1 and case[0]["inspection_authority"] == manifest["inspection_authority"],
        "Case/native/source authority differs")
    packet_refs = [r for r in matrix["packets"] if Path(r["path"]).parent.name == manifest["case_id"]]
    V.require([b["packet_ref"] for b in manifest["batches"]] == packet_refs,
        "Replay omitted or reordered declared source packets")
    original = _read(root, manifest["result_ref"])
    V.require(original["version"] == V.VERSION and original["method_id"] == METHOD_ID,
        "Not an actual V5 source-view result")
    authority = manifest["inspection_authority"]
    snapshots = [manifest["authorization_ref"], manifest["matrix_ref"], ready_ref, manifest["result_ref"]]
    warnings = []
    if manifest.get("temporal_warnings_ref") is not None:
        snapshots.append(manifest["temporal_warnings_ref"])
        warnings = _read(root, manifest["temporal_warnings_ref"])["warnings"]
    chains, reviewed, pending, failures = [], [], [], []
    def read(reference):
        V.require(reference is not None, "Required actual replay artifact missing")
        snapshots.append(reference)
        return _read(root, reference)
    with source_context(root, authority["native_ref"], authority["inspection_ref"], V.V3) as (pf, policy, native, _):
        for batch in manifest["batches"]:
            packet = read(batch["packet_ref"])
            request = packet["request"]
            V.require(request["instructions"] == V.PROMPT, "Fresh V5 appraisal prompt differs")
            V.checked_wire(pf, request["input"])
            if batch["assessment_request_ref"]:
                V.require(read(batch["assessment_request_ref"]) == request, "Actual normalized source request differs")
            error = read(batch["error_ref"]) if batch["error_ref"] else None
            if not batch["assessment_response_ref"]:
                V.require(error is not None and not batch["validated_ref"] and not batch["reviewed_ref"],
                    "Missing appraisal requires retained failure, not an invented NONE")
                failures.append(dict(batch=batch["id"], state="APPRAISAL_FAILED_UNPROCESSED", error=error))
                continue
            raw, receipt = read(batch["assessment_response_ref"]), read(batch["assessment_receipt_ref"])
            assessment = V.validate_assessment(pf, request["input"], raw, receipt, root=root)
            chains.append(assessment.export()["provider_chain"])
            actual_body = _read(root, assessment.export()["provider_chain"]["actual_request_ref"])
            V.require(actual_body == packet["api_body_template"], "Actual appraisal API body differs from declared packet")
            V.require(assessment.export() == read(batch["validated_ref"]), "Saved appraisal differs from actual replay")
            if batch["reviewed_ref"]:
                response, review_receipt = read(batch["review_response_ref"]), read(batch["review_receipt_ref"])
                value = V.validate_review(assessment, response, review_receipt, root=root)
                V.require(value.export() == read(batch["reviewed_ref"]), "Saved independent review differs from actual replay")
                reviewed.append(value)
                chains.append(value.export()["new_review_provider_chain"])
            else:
                V.require(error is not None, "Unsettled appraisal needs retained failure/pending disclosure")
                pending.append(assessment)
                failures.append(dict(batch=batch["id"], state="FIRST_PASS_RETAINED_WITHOUT_VALIDATED_REVIEW", error=error))
                if batch["review_response_ref"] or batch["review_receipt_ref"]:
                    response, review_receipt = read(batch["review_response_ref"]), read(batch["review_receipt_ref"])
                    chains.append(V.provenance(root, review_receipt, V.review_wire(assessment), response, "review"))
        # The collector records completion order, not packet order. Reproduce it.
        by_call = {r.export()["assessment_receipt"]["call_id"]: r for r in reviewed}
        provenance = original["model_provenance"]
        V.require(len(provenance) == 2 * len(reviewed) and len(by_call) == len(reviewed),
            "Original completion-order receipt count differs")
        ordered = []
        for i in range(0, len(provenance), 2):
            capsule = by_call.pop(provenance[i]["call_id"], None)
            V.require(capsule is not None, "Unknown or duplicate original provider receipt")
            d = capsule.export()
            V.require(provenance[i:i + 2] == [d["assessment_receipt"], d["new_review_receipt"]],
                "Original independent provider pair differs")
            ordered.append(capsule)
        V.require(not by_call, "A reviewed source batch was omitted")
        replay = dict(version="H-V5-actual-provider-source-replay/1", manifest_sha256=manifest["sha256"],
            original_result_ref=manifest["result_ref"], input_refs=snapshots,
            provider_chains=chains, failed_or_pending_batches=failures,
            completion_order=[r.export()["assessment_receipt"]["call_id"] for r in ordered],
            original_result_rederived=True, actual_model_calls_reexecuted=0, native_executions=0)
        method, view = project(pf, policy, native, ordered, pending=pending,
            original_result=original, replay=replay, temporal_warnings=warnings)
        qa = dict(version="H-V5-source-view-QA/1", public_case=native["public_case"],
            original_native_ref=authority["native_ref"], original_inspection_ref=authority["inspection_ref"],
            original_native_atoms=[dict(id=a["id"], text=a["text"], status=a["status"]) for a in native["result"]["atoms"]],
            source_view_atoms=[dict(id=a["id"], status=a["status"], source_counts=a["source_counts"]) for a in view["atoms"]],
            assessment_scope=view["assessment_scope"], provider_chains_replayed=len(chains),
            native_unchanged=True, world_truth_or_event_join_claimed=False,
            new_API_calls=0, native_executions=0, UI_or_publication_clearance=False)
    for reference in snapshots + [authority["native_ref"], authority["inspection_ref"]]:
        verified_path(root, reference)
    return method, view, replay, qa
