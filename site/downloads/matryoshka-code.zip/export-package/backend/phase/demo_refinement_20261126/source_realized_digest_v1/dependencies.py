"""Pinned safe R receiver and existing D3 V4 receipt/privacy utilities. API0."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
ROOT = PHASE.parents[1]
sys.dont_write_bytecode = True
PINS = {
    "digests_v3/v4/FREEZE_D3_V4.json": "6a9dada46156325edb582011fefd4830c2688ff135776dd612724cc6138808c4",
    "publication_r_v1/FREEZE.json": "353dc813458feefc5475b3136648ccc0dfa3f6dbce0195c29563ab0c2835d505",
    "source_realized_materializations_v1/READY_REFS.json": "d8c533be982bbb41440b13fb94dcf386d3231098d7cb9a132cc18a6b41ed56fb",
    "publication/source_showcase_entries/R_NATIVE_ENTRIES_V2.json": "0541cf89a4e78b26d532bfd6a77191082a445ee7cc4ee3d42136078f992aeff0",
}


def check_ref(reference):
    path = ROOT / reference["path"]
    if path.resolve() != path or not path.is_relative_to(ROOT) or hashlib.sha256(path.read_bytes()).hexdigest() != reference["sha256"]:
        raise ValueError("R_DIGEST_FROZEN_DEPENDENCY_CHANGED")


def verify_dependencies():
    for relative, expected in PINS.items():
        path = PHASE / relative
        check_ref(dict(path=str(path.relative_to(ROOT)), sha256=expected))
        value = json.loads(path.read_bytes())
        for field in ("files", "dependency_refs"):
            for reference in value.get(field, []) if isinstance(value, dict) else []:
                check_ref(reference)


def load(name, path):
    if name in sys.modules:
        value = sys.modules[name]
        if Path(value.__file__).resolve() != path:
            raise ValueError("R_DIGEST_MODULE_COLLISION")
        return value
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


verify_dependencies()
sys.path.insert(0, str(PHASE / "digests_v3/v4"))
B = load("_r_digest_frozen_d3v4_boundary", PHASE / "digests_v3/v4/boundary.py").D
P = load("_r_digest_safe_publisher", PHASE / "publication_r_v1/publisher.py")
M = load("_r_digest_metadata_protocol", PHASE / "publication_r_v1/metadata_protocol.py")
