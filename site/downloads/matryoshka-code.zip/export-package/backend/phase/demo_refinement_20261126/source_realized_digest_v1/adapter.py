"""Typed R source-only digest preparation, exact-report capture and read boundary."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

_dependency_path = Path(__file__).resolve().with_name("dependencies.py")
_name = "_source_realized_digest_v1_pinned_dependencies"
if _name not in sys.modules:
    _spec = importlib.util.spec_from_file_location(_name, _dependency_path)
    _dependencies = importlib.util.module_from_spec(_spec)
    sys.modules[_name] = _dependencies
    _spec.loader.exec_module(_dependencies)
_dependencies = sys.modules[_name]
if Path(_dependencies.__file__).resolve() != _dependency_path:
    raise ValueError("R_DIGEST_DEPENDENCY_MODULE_COLLISION")
B, P, M = _dependencies.B, _dependencies.P, _dependencies.M
PHASE, ROOT, HERE = _dependencies.PHASE, _dependencies.ROOT, _dependencies.HERE
PINS, verify_dependencies = _dependencies.PINS, _dependencies.verify_dependencies

VERSION = "source-realized-redaction-analyst-digest/1"
KIND = "SOURCE_REALIZED_REDACTION"
CONFIG = "llm_readings"
MAX_INPUT = 262144
PHASE_API = B.PHASE_API
PROMPT = B.PROMPT + """
This is a source-derived redaction-suggestion brief. Lead with the leading suggestion in the recorded display reading and what its own report actually says.
Use the other readings or alternatives only when material. Preserve the supplied order; do not choose a different winner or merge source accounts.
An approved source-ascribed insertion is not certification of the whole visible episode or a known literal recovery.
Contextual, partially corroborated, held or quarantined suggestions are not directly supported fills. State the material missing connection naturally where relevant.
Do not turn a related name or background property into proof of the concealed action. Do not supply a new fill or consult hidden answers."""
SCHEMA = deepcopy(B.SCHEMA)
encoded, digest, seal, check_seal, fixed4 = B.encoded, B.digest, B.seal, B.check_seal, B.fixed4
require, read, ref, N = B.require, B.read, B.ref, B.N
REGISTRY_REF = dict(path=str((PHASE / "source_realized_materializations_v1/READY_REFS.json").relative_to(ROOT)),
    sha256=PINS["source_realized_materializations_v1/READY_REFS.json"])
ENTRIES_REF = dict(path=str((PHASE / "publication/source_showcase_entries/R_NATIVE_ENTRIES_V2.json").relative_to(ROOT)),
    sha256=PINS["publication/source_showcase_entries/R_NATIVE_ENTRIES_V2.json"])


def put(path, value):
    path = Path(path).absolute()
    require(path.resolve() == path and path.is_relative_to(HERE), "WRITE_OUTSIDE_R_DIGEST")
    raw = encoded(value) + b"\n"
    if path.exists():
        require(path.read_bytes() == raw, "IMMUTABLE_R_DIGEST_ARTIFACT_DIFFERS")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as stream:
            stream.write(raw)
    return ref(path)


def exact(a, b, reason):
    require(P.encoded(a) == P.encoded(b), reason)


def catalog(case_id):
    verify_dependencies()
    registry = read(REGISTRY_REF)
    require(case_id in registry, "EXACT_FOUR_READY_REGISTRY_CASE_REQUIRED")
    ready_ref = registry[case_id]
    ready = P.checked(ready_ref)
    matches = []
    for entry_ref in read(ENTRIES_REF).values():
        entry = P.checked(entry_ref)
        if entry["case"]["case_id"] == case_id:
            matches.append(entry)
    require(len(matches) == 1, "EXACT_NATIVE_ENTRY_REQUIRED")
    entry = matches[0]
    native_ref = entry["outputs"]["native_checkpoint"]
    native = P.checked(native_ref)
    resource = P.native_resource_binding(native_ref)
    row = dict(case=entry["case"], resource_binding=resource, configurations={CONFIG: dict(
        deepcopy(entry["outputs"]), source_view_policy=deepcopy(native["configuration"]["source_view_policy"]))})
    return row, dict(view_ref=ready["view_ref"], method_ref=ready["method_ref"], producer_ready_ref=ready_ref)


def project(row, native, method, view, prepared):
    """All recorded slates/variants and own quotes; never old native ranks or QA."""
    pages = {p["page_id"]: p for p in view["source_pages"]}
    source_ids, sources = {}, []
    def cite(pid, span):
        page = pages[pid]
        text = page["windows"][0]["text"]
        P._span(text, span)
        key = (page["corpus"], page["document_id"], page["date"], pid, page["page_sha256"])
        if key not in source_ids:
            source_ids[key] = len(sources)
            source = dict(id="S" + str(len(sources) + 1), corpus=page["corpus"], document_id=page["document_id"],
                date=page["date"], canonical_page_id=pid, page_sha256=page["page_sha256"], citations=[])
            for field in ("earlier_page", "later_page", "physical_page"):
                if page["original_page_metadata"].get(field) is not None:
                    source[field] = page["original_page_metadata"][field]
            sources.append(source)
        source = sources[source_ids[key]]
        # Exact R UI callback shape, not a synthetic certificate or D1 citation.
        citation = dict(corpus=page["corpus"], canonical_page_id=pid, document_id=page["document_id"], date=page["date"],
            page_sha256=page["page_sha256"], start=span["start"], end=span["end"], text=span["text"])
        for field in ("earlier_page", "later_page"):
            if page["original_page_metadata"].get(field) is not None:
                citation[field] = page["original_page_metadata"][field]
        found = next((c for c in source["citations"] if c["citation"] == citation), None)
        if found is None:
            found = dict(id="C" + str(len(source["citations"]) + 1), citation=citation)
            source["citations"].append(found)
        return dict(source_id=source["id"], citation_id=found["id"])
    readings = []
    for branch in view["readings"]:
        groups = []
        for group in branch["candidates"]:
            variants = []
            for candidate in group["variants"]:
                p, reader = candidate["priority"], candidate["source_reader"]
                focal = p.get("focal_row")
                contexts = reader["focal_source_contexts"]
                require(isinstance(contexts, list) and (focal is not None or not contexts), "QUARANTINED_CONTEXT_NOT_CALLBACK_AUTHORITY")
                pid = reader["canonical_page_id"]
                focal_sources = []
                for context in contexts:
                    anchor = context["anchor"]
                    focal_sources.append(dict(anchor_id=anchor["id"], quote=cite(pid, dict(start=anchor["start"], end=anchor["end"], text=anchor["quote"])),
                        qualification=cite(pid, context["qualification_span"])))
                facets = focal["raw_focal_assessment"]["assessment"]["facets"] if focal else {}
                states = [x["status"] for x in facets.values()]
                label = "SOURCE_ASCRIBED" if p["source_supported_fill_approved"] else "PARTIAL_CONTEXT" if "MATCHED" in states and "INFERRED" in states else p["evidence_state"]
                variants.append(dict(id=candidate["id"], fill=candidate["fill"], completed_input=candidate["completed_input"],
                    transformation=deepcopy(candidate["transformation"]), evidence_state=p["evidence_state"], display_class=label,
                    source_ascribed_fill_approved=p["source_supported_fill_approved"], whole_visible_event_certified=False,
                    priority_index=fixed4(p["value"]), evidence_class=p["evidence_class"],
                    quote=cite(pid, reader["quote_span"]), phrase=cite(pid, reader["phrase_span"]),
                    full_qualification=cite(pid, reader["qualification_span"]), focal_sources=focal_sources,
                    facets={k: deepcopy(v) for k, v in facets.items()},
                    valid_focal_row=focal is not None, quarantined=p.get("quarantine") is not None))
            groups.append(dict(id=group["id"], rank=group["rank"], fill=group["fill"], representative_id=group["representative_id"],
                priority_index=fixed4(group["priority"]["value"]), evidence_state=group["priority"]["evidence_state"], variants=variants))
        readings.append(dict(reading=deepcopy(branch["reading"]), candidates=groups,
            top5_ids=deepcopy(branch["top5_ids"]), reserve_ids=deepcopy(branch["reserve_ids"])))
    value = dict(version=VERSION + "/input", kind=KIND, public_case=deepcopy(row["case"]),
        facts=[{k: deepcopy(a[k]) for k in ("id", "text", "query_spans")} for a in native["plan"]["atoms"]],
        method=dict(id=P.METHOD_ID, label="Source-derived redaction suggestions", native_method=False),
        selection=deepcopy(view["selection"]), readings=readings, sources=sources,
        source_policy=deepcopy(view["source_view_policy"]),
        scope=dict(source_approved_variants=view["focal_summary"]["source_approved"], valid_focal_rows=view["focal_summary"]["valid_rows"],
            quarantined_variants=view["focal_summary"]["quarantined"], candidate_source_union_used=False,
            source_ascription_not_world_truth=True, unchanged_native_not_primary_method=True),
        postrun=True, used_for_inference=False)
    N.public_safe(value)
    encoded(value)
    return value


def source_packet(case_id, contexts):
    row, artifacts = catalog(case_id)
    native, _context, base = B.D2.native_binding(row, CONFIG, contexts)
    prepared = P.prepare(case=row["case"], native_ref=row["configurations"][CONFIG]["native_checkpoint"],
        resource_binding=row["resource_binding"], artifacts=artifacts)
    method, view = P.checked(artifacts["method_ref"]), P.checked(artifacts["view_ref"])
    payload = project(row, native, method, view, prepared)
    binding = dict(case_id=case_id, config=CONFIG, method_id=P.METHOD_ID,
        case_sha256=digest(row["case"]), query_sha256=P.digest(row["case"]["query"]),
        native_checkpoint_sha256=artifacts_native_sha(view), native_checksum=native["native_checksum"],
        condition_record_sha256=base["condition_record_sha256"], resource_binding_sha256=base["resource_binding_sha256"],
        original_method_sha256=method["sha256"], method_file_sha256=artifacts["method_ref"]["sha256"],
        original_view_sha256=view["sha256"], original_view_file_sha256=artifacts["view_ref"]["sha256"],
        source_policy_sha256=digest(payload["source_policy"]), citation_map_sha256=digest(payload["sources"]),
        selected_reading_sha256=digest(payload["selection"]), ready_sha256=artifacts["producer_ready_ref"]["sha256"])
    payload["binding"] = binding
    return payload, prepared, row, artifacts


def artifacts_native_sha(view):
    return view["original_native"]["native_ref"]["sha256"]


def prepare_source(case_id, *, contexts=None):
    with B._contexts(contexts) as owner:
        payload, prepared, _row, _artifacts = source_packet(case_id, owner)
    input_ref = put(HERE / "payloads" / (digest(payload) + ".json"), payload)
    value = seal(dict(version=VERSION + "/preparation", kind=KIND, binding=payload["binding"], input_ref=input_ref,
        input_sha256=digest(payload), prompt_sha256=digest(PROMPT), schema_sha256=digest(SCHEMA),
        transport_profile="source_assessment_fullpool_v2", max_input_upper=MAX_INPUT,
        canonical_receiver=prepared["canonical_replay"], selected_report_required_before_paid_request=True,
        postrun=True, used_for_inference=False, api_calls=0))
    return put(HERE / "preparations" / (value["sha256"] + ".json"), value)


def api_body(payload, model="gpt-6.1-sol"):
    require(set(payload) == {"version", "kind", "public_case", "facts", "method", "selection", "readings", "sources", "source_policy", "scope", "postrun", "used_for_inference", "binding"}
        and payload["version"] == VERSION + "/input" and payload["kind"] == KIND and set(payload["public_case"]) == N.PUBLIC_FIELDS
        and payload["public_case"]["task"] == "redaction" and payload["postrun"] is True and payload["used_for_inference"] is False,
        "CLOSED_TYPED_R_SOURCE_INPUT_REQUIRED")
    binding = payload["binding"]
    require(binding.get("case_id") == payload["public_case"]["case_id"]
        and binding.get("config") == CONFIG and binding.get("method_id") == P.METHOD_ID
        and binding.get("case_sha256") == digest(payload["public_case"])
        and binding.get("query_sha256") == P.digest(payload["public_case"]["query"])
        and binding.get("citation_map_sha256") == digest(payload["sources"])
        and binding.get("source_policy_sha256") == digest(payload["source_policy"])
        and binding.get("selected_reading_sha256") == digest(payload["selection"])
        and all(isinstance(binding.get(k), str) and re.fullmatch("[a-f0-9]{64}", binding[k]) for k in (
            "native_checkpoint_sha256", "native_checksum", "condition_record_sha256", "resource_binding_sha256",
            "original_method_sha256", "method_file_sha256", "original_view_sha256", "original_view_file_sha256", "ready_sha256")),
        "R_INPUT_EXACT_NATIVE_METHOD_SELECTION_SOURCE_BINDING_REQUIRED")
    N.public_safe(payload)
    require(model in {"gpt-6.1-sol", "gpt-6-luna"}, "DECLARED_DIGEST_MODEL_REQUIRED")
    body = dict(model=model, store=False, instructions=PROMPT,
        input=[dict(role="user", content=[dict(type="input_text", text=encoded(payload).decode("ascii"))])],
        text=dict(format=dict(type="json_schema", name="source_realized_redaction_digest_v1", strict=True, schema=deepcopy(SCHEMA))),
        reasoning=dict(effort="low" if model == "gpt-6.1-sol" else "none"), max_output_tokens=4096 if model == "gpt-6.1-sol" else 1536,
        **({} if model == "gpt-6.1-sol" else {"temperature": 0}))
    require(len(encoded(body)) + 2048 <= MAX_INPUT, "R_DIGEST_FULL_BODY_OVERSIZE_NO_TRUNCATION")
    return body


def selected(report_ref, case_id, prepared, row, artifacts):
    report = N.load_report(report_ref)
    matches = [r for r in report["cases"] if r["case"]["case_id"] == case_id]
    require(len(matches) == 1 and CONFIG in matches[0]["configurations"], "R_CASE_CONFIG_NOT_SELECTED_IN_REPORT")
    current = matches[0]
    exact(current["case"], row["case"], "CURRENT_PUBLIC_CASE_CHANGED")
    exact(current["resource_binding"], row["resource_binding"], "CURRENT_RESOURCE_BINDING_CHANGED")
    item = current["configurations"][CONFIG]
    require(item.get("config") == CONFIG, "CURRENT_R_CONFIGURATION_CHANGED")
    exact(item["source_view_policy"], row["configurations"][CONFIG]["source_view_policy"], "CURRENT_R_ITEM_SOURCE_POLICY_CHANGED")
    exact(item["native_checkpoint"], row["configurations"][CONFIG]["native_checkpoint"], "CURRENT_NATIVE_CHANGED")
    exact(item["condition_ref"], row["configurations"][CONFIG]["condition_ref"], "CURRENT_CONDITION_CHANGED")
    pin = current.get("reviewed_source_assessment")
    require(isinstance(pin, dict) and pin.get("method_id") == P.METHOD_ID, "EXACT_SELECTED_R_METHOD_REQUIRED_NO_NATIVE_FALLBACK")
    # Resolve only registry-approved artifact locations; never trust a private
    # path supplied in a public report. The full projected metadata still matches.
    for key, known in artifacts.items():
        given = pin.get(key)
        require(isinstance(given, dict) and given.get("sha256") == known["sha256"]
                and given.get("path") in (None, known["path"]), "UNKNOWN_OR_CHANGED_R_ARTIFACT_REFERENCE")
    exact(M.public_metadata(pin), prepared["metadata"], "CURRENT_R_METADATA_PROJECTION_CHANGED")
    return dict(report_sha256=report_ref["sha256"], public_view_sha256=prepared["public_view"]["sha256"],
        public_method_sha256=prepared["public_method"]["sha256"],
        public_view_file_sha256=prepared["metadata"]["public_view_ref"]["sha256"])


def load_model_input(report_ref, preparation_ref, *, model="gpt-6.1-sol", contexts=None):
    prep = read(preparation_ref)
    check_seal(prep, VERSION + "/preparation")
    require(prep["kind"] == KIND and prep["prompt_sha256"] == digest(PROMPT) and prep["schema_sha256"] == digest(SCHEMA)
        and prep["transport_profile"] == "source_assessment_fullpool_v2" and prep["max_input_upper"] == MAX_INPUT
        and prep["postrun"] is True and prep["used_for_inference"] is False
        and type(prep["api_calls"]) is int and prep["api_calls"] == 0, "R_PREPARATION_CHANGED")
    with B._contexts(contexts) as owner:
        payload, prepared, row, artifacts = source_packet(prep["binding"]["case_id"], owner)
    exact(prep["binding"], payload["binding"], "R_SOURCE_NATIVE_METHOD_BINDING_CHANGED")
    exact(prep["canonical_receiver"], prepared["canonical_replay"], "R_CANONICAL_RECEIVER_RECEIPT_CHANGED")
    require(prep["input_sha256"] == digest(payload), "R_SOURCE_PACKET_CHANGED")
    exact(read(prep["input_ref"]), payload, "R_SAVED_PACKET_CHANGED")
    presentation = selected(report_ref, payload["public_case"]["case_id"], prepared, row, artifacts)
    body = api_body(payload, model)
    return dict(entry=prep, payload=payload, presentation=presentation, body=body, http_bytes=encoded(body),
        body_sha256=digest(body), max_input_upper=MAX_INPUT, exact_call_profile="source_assessment_fullpool_v2",
        execution_contract="phase-exact-api/2")


def validate_generation(report_ref, preparation_ref, *, request_ref, raw_response_ref, api_receipt_ref, contexts=None):
    request, response, receipt = (read(r) for r in (request_ref, raw_response_ref, api_receipt_ref))
    B.validate_funding(receipt)
    current = load_model_input(report_ref, preparation_ref, model=request.get("model"), contexts=contexts)
    receipt_path = N.safe_path(ROOT, api_receipt_ref["path"])
    attempt = PHASE_API / "attempts" / receipt_path.stem
    require(receipt_path.parent == PHASE_API / "receipts" and N.safe_path(ROOT, request_ref["path"]) == attempt / "request.json"
        and N.safe_path(ROOT, raw_response_ref["path"]) == attempt / "response.json", "CURRENT_PHASE_PROVIDER_PATHS_REQUIRED")
    require(digest(request) == current["body_sha256"] and receipt.get("execution_contract") == "phase-exact-api/2"
        and receipt.get("status") == "PASS" and receipt.get("model") == request["model"]
        and receipt.get("request_sha256") == current["body_sha256"] and receipt.get("response_sha256") == N.digest(response)
        and response.get("status") == "completed", "ACTUAL_R_DIGEST_PROVIDER_RECEIPT_CHANGED")
    texts = [c["text"] for item in response.get("output", []) if item.get("type") == "message"
        for c in item.get("content", []) if c.get("type") == "output_text"]
    require(len(texts) == 1, "ONE_COMPLETED_R_DIGEST_REQUIRED")
    output = N.strict_json(texts[0])
    from jsonschema import validate
    validate(output, SCHEMA)
    N.validate_text(output["digest"], len(current["payload"]["sources"]))
    allowed = {s["id"] for s in current["payload"]["sources"]}
    require(all(s in allowed for s in re.findall(r"\[(S[^\]]*)\]", output["digest"]))
        and bool(re.search(r"\[S[1-9]\d*\]", output["digest"])), "ACTUAL_R_DIGEST_SOURCE_LABELS_REQUIRED")
    return seal(dict(version=VERSION + "/generation", kind=KIND, binding=current["entry"]["binding"],
        input_sha256=current["entry"]["input_sha256"], text=output["digest"], model=request["model"],
        body_sha256=current["body_sha256"], raw_response_wire_sha256=raw_response_ref["sha256"],
        response_value_sha256=N.digest(response), api_receipt_wire_sha256=api_receipt_ref["sha256"],
        request_ref=request_ref, raw_response_ref=raw_response_ref, api_receipt_ref=api_receipt_ref,
        prompt_sha256=digest(PROMPT), schema_sha256=digest(SCHEMA), report_independent=True,
        postrun=True, used_for_inference=False, source_support_reassessed=False, prose_semantics_reviewed=False))


def capture_generation(report_ref, preparation_ref, **kwargs):
    value = validate_generation(report_ref, preparation_ref, **kwargs)
    return put(HERE / "generations" / (value["sha256"] + ".json"), value)


def saved_generation(report_ref, prep_ref, generation_ref, contexts=None):
    value = read(generation_ref)
    check_seal(value, VERSION + "/generation")
    actual = validate_generation(report_ref, prep_ref, contexts=contexts,
        **{k: value[k] for k in ("request_ref", "raw_response_ref", "api_receipt_ref")})
    exact(value, actual, "SAVED_R_GENERATION_PROVENANCE_CHANGED")
    return actual


def build_index(report_ref, preparation_refs, generation_refs, *, contexts=None):
    report = N.load_report(report_ref)
    expected = {r["case"]["case_id"] + "/" + CONFIG for r in report["cases"]
        if r.get("reviewed_source_assessment", {}).get("method_id") == P.METHOD_ID}
    require(set(preparation_refs) == set(generation_refs) == expected and expected, "EXACT_SELECTED_R_DIGEST_POPULATION_REQUIRED")
    entries = {}
    with B._contexts(contexts) as owner:
        for key, prep_ref in preparation_refs.items():
            current = load_model_input(report_ref, prep_ref, contexts=owner)
            require(key == current["entry"]["binding"]["case_id"] + "/" + CONFIG, "R_DIGEST_CASE_CONFIG_CHANGED")
            generation = saved_generation(report_ref, prep_ref, generation_refs[key], owner)
            envelope = seal(dict(version=VERSION + "/attachment", kind=KIND, report_ref=report_ref, preparation_ref=prep_ref,
                generation_ref=generation_refs[key], binding=current["entry"]["binding"], presentation=current["presentation"],
                generation_sha256=generation["sha256"], postrun=True, used_for_inference=False))
            entries[key] = put(HERE / "attachments" / report_ref["sha256"] / (envelope["sha256"] + ".json"), envelope)
    index = seal(dict(version=VERSION + "/index", kind=KIND, report_ref=report_ref, entries=entries,
        no_native_fallback=True, postrun=True, used_for_inference=False))
    return put(HERE / "indexes" / report_ref["sha256"] / (index["sha256"] + ".json"), index)


def read_for_case(index_ref, report_ref, case_id, config, *, method_id, original_view_sha256, public_view_sha256, contexts=None):
    require(config == CONFIG and method_id == P.METHOD_ID, "TYPED_R_DIGEST_ONLY_NO_D1_FALLBACK")
    require(index_ref is not None, "NO_SAVED_TYPED_R_DIGEST")
    index = read(index_ref)
    check_seal(index, VERSION + "/index")
    exact(index["report_ref"], report_ref, "R_DIGEST_REPORT_CHANGED")
    key = case_id + "/" + config
    require(index["kind"] == KIND and key in index["entries"], "NO_OTHER_R_DIGEST_FALLBACK")
    envelope = read(index["entries"][key])
    check_seal(envelope, VERSION + "/attachment")
    require(envelope["kind"] == KIND and envelope["postrun"] is True and envelope["used_for_inference"] is False,
        "TYPED_POSTRUN_R_ATTACHMENT_REQUIRED")
    exact(envelope["report_ref"], report_ref, "R_DIGEST_ATTACHMENT_REPORT_CHANGED")
    with B._contexts(contexts) as owner:
        current = load_model_input(report_ref, envelope["preparation_ref"], contexts=owner)
        generation = saved_generation(report_ref, envelope["preparation_ref"], envelope["generation_ref"], owner)
    exact(envelope["binding"], current["entry"]["binding"], "R_DIGEST_NATIVE_METHOD_BINDING_CHANGED")
    exact(envelope["presentation"], current["presentation"], "R_DIGEST_PUBLIC_VIEW_BINDING_CHANGED")
    require(current["entry"]["binding"]["case_id"] == case_id and current["entry"]["binding"]["config"] == config
        and current["entry"]["binding"]["original_view_sha256"] == original_view_sha256
        and current["presentation"]["public_view_sha256"] == public_view_sha256
        and envelope["generation_sha256"] == generation["sha256"], "CURRENT_R_DIGEST_SELECTION_CHANGED")
    payload = current["payload"]
    binding = dict(current["entry"]["binding"], **current["presentation"], source_view_policy=deepcopy(payload["source_policy"]))
    value = dict(version=VERSION + "/public", kind=KIND, available=True, status="SAVED_R_SOURCE_DIGEST", text=generation["text"],
        binding=binding, input_sha256=current["entry"]["input_sha256"], generation_sha256=generation["sha256"],
        body_sha256=generation["body_sha256"], raw_response_wire_sha256=generation["raw_response_wire_sha256"],
        api_receipt_wire_sha256=generation["api_receipt_wire_sha256"], response_value_sha256=generation["response_value_sha256"],
        sources=payload["sources"], method=payload["method"], source_policy=payload["source_policy"],
        selection=payload["selection"], source_support_reassessed=False, prose_semantics_reviewed=False,
        placement="AFTER_RESULTS", native_method=False, world_truth_certified=False, postrun=True, used_for_inference=False)
    N.public_safe(value)
    return seal(value)
