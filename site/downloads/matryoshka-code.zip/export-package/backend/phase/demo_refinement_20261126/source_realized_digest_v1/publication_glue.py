"""New report copies, report-bound R indexes and finite exports; no paid calls."""
from copy import deepcopy
import importlib.util
from pathlib import Path
from urllib.parse import urlencode

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("_typed_R_digest_publication_v1", HERE / "adapter.py")
D = importlib.util.module_from_spec(spec)
spec.loader.exec_module(D)


def completed(results_ref):
    results = D.read(results_ref)
    D.require(results.get("version") == "parent-four-R-digest-results/1" and results.get("complete") is True
        and len(results["cases"]) == 4 and all(r.get("status") == "SAVED_R_SOURCE_DIGEST" for r in results["cases"].values()),
        "FOUR_COMPLETE_SAVED_R_DIGESTS_REQUIRED")
    return results


def mappings(results):
    return ({k: r["preparation_ref"] for k, r in results["cases"].items()},
            {k: r["generation_ref"] for k, r in results["cases"].items()})


def rebind_report(report_ref, results_ref, *, contexts=None):
    preps, generations = mappings(completed(results_ref))
    return D.build_index(report_ref, preps, generations, contexts=contexts)


def _attach_rows(report, report_ref, results, contexts):
    revised = deepcopy(report)
    with D.B._contexts(contexts) as owner:
        for row in revised["cases"]:
            key = row["case"]["case_id"] + "/" + D.CONFIG
            if key not in results["cases"]:
                continue
            item = results["cases"][key]
            current = D.load_model_input(report_ref, item["preparation_ref"], contexts=owner)
            generation = D.saved_generation(report_ref, item["preparation_ref"], item["generation_ref"], owner)
            binding = current["entry"]["binding"]
            pin = dict(version="source-realized-redaction-digest-pin/1", kind=D.KIND,
                method_id=D.P.METHOD_ID, native_checkpoint_sha256=binding["native_checkpoint_sha256"],
                native_checksum=binding["native_checksum"], original_view_sha256=binding["original_view_sha256"],
                public_view_sha256=current["presentation"]["public_view_sha256"],
                input_sha256=current["entry"]["input_sha256"], generation_sha256=generation["sha256"],
                body_sha256=generation["body_sha256"], endpoint="/api/current/analyst-digest",
                postrun=True, used_for_inference=False, placement="AFTER_RESULTS")
            D.require("source_realized_digest" not in row or row["source_realized_digest"] == pin,
                "DO_NOT_OVERWRITE_EXISTING_R_DIGEST_PIN")
            row["source_realized_digest"] = pin
    revised.pop("sha256", None)
    return revised


def _store_report(report, folder):
    revised = deepcopy(report)
    revised.pop("sha256", None)
    revised = D.N.sealed(revised)  # Original report floats/types remain unchanged.
    raw = D.P.encoded(revised) + b"\n"
    path = HERE / folder / revised["sha256"] / "report.json"
    D.require(path.resolve() == path and path.is_relative_to(HERE), "REPORT_WRITE_OUTSIDE_R_DIGEST_GLUE")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        D.require(path.read_bytes() == raw, "IMMUTABLE_DECORATED_R_REPORT_DIFFERS")
    else:
        with path.open("xb") as stream:
            stream.write(raw)
    return D.ref(path)


def attach_pins(report, results_ref, *, contexts=None):
    """Parent compose hook: only R-row pins change; result stays UNSEALED."""
    results = completed(results_ref)
    temporary = _store_report(report, "temporary_reports")
    return _attach_rows(report, temporary, results, contexts)


def bind_report(report_ref, results_ref, *, contexts=None):
    """Bind only AFTER the parent has sealed its complete final report."""
    return rebind_report(report_ref, results_ref, contexts=contexts)


def attach_report_pins(report_ref, results_ref, *, contexts=None):
    """Optional stand-alone copy helper, not the parent's compose hook."""
    revised = attach_pins(D.N.load_report(report_ref), results_ref, contexts=contexts)
    target = _store_report(revised, "reports")
    return dict(report_ref=target, index_ref=rebind_report(target, results_ref, contexts=contexts),
        original_report_ref=report_ref, original_report_modified=False, API_calls=0)


def public_response(index_ref, report_ref, row, *, contexts=None):
    pin = row.get("reviewed_source_assessment", {})
    D.require(pin.get("method_id") == D.P.METHOD_ID and "source_realized_digest" in row, "EXACT_R_ROW_AND_DIGEST_PIN_REQUIRED")
    response = D.read_for_case(index_ref, report_ref, row["case"]["case_id"], D.CONFIG,
        method_id=D.P.METHOD_ID, original_view_sha256=pin["original_view_sha256"],
        public_view_sha256=pin["public_view_sha256"], contexts=contexts)
    D.require(response.get("version") == D.VERSION + "/public" and response.get("kind") == D.KIND
        and response.get("available") is True, "EXACT_TYPED_R_PUBLIC_RESPONSE_REQUIRED")
    actual = row["source_realized_digest"]
    D.require(actual.get("version") == "source-realized-redaction-digest-pin/1" and actual.get("kind") == D.KIND
        and actual.get("method_id") == D.P.METHOD_ID and actual.get("placement") == "AFTER_RESULTS"
        and actual.get("postrun") is True and actual.get("used_for_inference") is False,
        "TYPED_R_ROW_DIGEST_PIN_CHANGED")
    for field in ("native_checkpoint_sha256", "native_checksum", "original_view_sha256", "public_view_sha256"):
        D.require(actual[field] == response["binding"][field], "R_ROW_DIGEST_BINDING_CHANGED")
    for field in ("input_sha256", "generation_sha256", "body_sha256"):
        D.require(actual[field] == response[field], "R_ROW_DIGEST_GENERATION_CHANGED")
    return response


def export_responses(report_ref, index_ref, *, contexts=None):
    """Return exact response refs for the parent's existing finite API exporter."""
    report = D.N.load_report(report_ref)
    routes = {}
    with D.B._contexts(contexts) as owner:
        for row in report["cases"]:
            pin = row.get("reviewed_source_assessment", {})
            if pin.get("method_id") != D.P.METHOD_ID:
                continue
            cid = row["case"]["case_id"]
            response = public_response(index_ref, report_ref, row, contexts=owner)
            response_ref = D.put(HERE / "exports" / report_ref["sha256"] / (response["sha256"] + ".json"), response)
            params = dict(case_id=cid, config=D.CONFIG,
                **{key: row["resource_binding"][key] for key in ("resource_id", "registry_sha256", "index_sha256")})
            endpoint = "/api/current/analyst-digest?" + urlencode(sorted(params.items()))
            routes[endpoint] = dict(response_ref=response_ref, envelope_self_sha256=response["sha256"],
                decoded_value_sha256=D.digest(response), stored_wire_sha256=response_ref["sha256"],
                public_version=D.VERSION + "/public", kind=D.KIND)
    D.require(bool(routes), "NO_SELECTED_R_DIGEST_EXPORTS")
    value = D.seal(dict(version="typed-R-digest-finite-export/1", report_ref=report_ref, index_ref=index_ref,
        routes=routes, native_D1_unchanged=True, D3_MH_unchanged=True, API_calls=0))
    return D.put(HERE / "exports" / report_ref["sha256"] / "ROUTES.json", value)
