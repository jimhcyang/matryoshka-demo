"""Explicit private-row/public-report location split; not canonical authority."""
from copy import deepcopy
import json
import re

ARTIFACT_KEYS = ("view_ref", "method_ref", "producer_ready_ref")
AVAILABILITY = "Unpublished audit artifact; content hash retained; not a public fetch target"


def public_metadata(private_metadata):
    """Project ONLY three internal refs, preserving every other value and hash.

    This precedes the generic report serializer. Export independently calls
    publisher.prepare() with the original refs. This is not source authority.
    """
    result = deepcopy(private_metadata)
    for key in ARTIFACT_KEYS:
        ref = result[key]
        if not (isinstance(ref, dict) and {"path", "sha256"} <= ref.keys()
                and set(ref) <= {"path", "sha256", "bytes", "publication_availability"}
                and isinstance(ref["sha256"], str) and re.fullmatch("[a-f0-9]{64}", ref["sha256"])):
            raise ValueError("CLOSED_PRIVATE_OR_PROJECTED_ARTIFACT_REF_REQUIRED")
        if ref["path"] is not None and not isinstance(ref["path"], str):
            raise ValueError("REFERENCE_LOCATION_TYPE_CHANGED")
        if "bytes" in ref and (type(ref["bytes"]) is not int or ref["bytes"] < 0):
            raise ValueError("REFERENCE_BYTES_TYPE_CHANGED")
        if "publication_availability" in ref and ref["publication_availability"] != AVAILABILITY:
            raise ValueError("REFERENCE_AVAILABILITY_CHANGED")
        ref["path"] = None
        ref["publication_availability"] = AVAILABILITY
    return result


def private_metadata(prepared, artifacts):
    """Return private report metadata retaining authenticated original locations."""
    if set(artifacts) != set(ARTIFACT_KEYS):
        raise ValueError("CLOSED_ARTIFACTS_REQUIRED")
    result = dict(deepcopy(prepared["metadata"]), **deepcopy(artifacts))
    def encode(value):
        return json.dumps(value, sort_keys=True, ensure_ascii=True,
            separators=(",", ":"), allow_nan=False).encode()
    if encode(public_metadata(result)) != encode(prepared["metadata"]):
        raise ValueError("PRIVATE_ARTIFACT_COMMITMENT_DIFFERS")
    return result
