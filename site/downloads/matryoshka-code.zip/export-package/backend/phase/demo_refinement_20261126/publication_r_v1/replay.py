"""Isolated, network-disabled invocation of the unchanged canonical R builder."""
import importlib.util
from contextlib import redirect_stdout
from pathlib import Path
import socket
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import publisher as P


def forbidden(*args, **kwargs):
    raise RuntimeError("PUBLICATION_CANONICAL_REPLAY_NETWORK_DISABLED")


def main():
    ready_ref = P.parse(sys.stdin.buffer.read())
    P.verify_code()
    P.checked(ready_ref)
    for owner, key in ((socket, "getaddrinfo"), (socket, "create_connection"),
                       (socket.socket, "connect"), (socket.socket, "connect_ex")):
        setattr(owner, key, forbidden)
    sys.path.insert(0, str(P.ROOT))
    sys.path.insert(0, str(P.OWNER))
    with redirect_stdout(sys.stderr):
        spec = importlib.util.spec_from_file_location("_canonical_source_realized_builder", P.OWNER / "builder.py")
        builder = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(builder)
        import binding
        P.require(Path(binding.__file__).resolve() == P.OWNER / "binding.py", "CANONICAL_BINDING_MODULE_COLLISION")
        ready = P.checked(ready_ref)
        P.require(type(ready["API_calls"]) is type(ready["native_runs"]) is int
            and ready["API_calls"] == ready["native_runs"] == 0
            and ready["publication_authorized"] is False, "READY_BOOLEAN_OR_INTEGER_TYPE_CHANGED")
        method, view = P.checked(ready["method_ref"]), P.checked(ready["view_ref"])
        P._sealed(method, "source-realized-redaction-method/1")
        P._sealed(view, "source-realized-redaction-view/1")
        P._receiver_types(method, view)
        P.require(builder.R.is_sealed(method) and builder.R.is_sealed(view), "CANONICAL_R_LOGICAL_SEALS_REQUIRED")
        from matryoshka_next.construction import SourceParses
        parser = SourceParses()
        P.require(builder.verify_ready(ready_ref, parser=parser) is True, "CANONICAL_READY_REJECTED")
        observation, admitted, final = builder.inputs(P.checked(ready["spec_ref"]), parser)
        replayed_method, replayed_view = builder.compose(observation, admitted, final,
            P.checked(ready["spec_ref"]), ready["producer"])
        P.verify_typed_outputs(method, view, replayed_method, replayed_view)
    P.verify_code()
    print(P.encoded(dict(version=P.RECEIVER, ready_ref=ready_ref,
        code_freeze_ref=P.CODE_FREEZE, canonical_verify_ready=True, network_disabled=True,
        loaded_logical_seals_verified=True, canonical_encoded_replay_equal=True,
        API_calls=0, native_runs=0)).decode())


if __name__ == "__main__":
    main()
