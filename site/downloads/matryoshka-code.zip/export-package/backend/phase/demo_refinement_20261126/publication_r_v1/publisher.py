"""Write-free typed R publication binding, canonical replay and location projection."""
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
from urllib.parse import urlencode

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OWNER = HERE.parent / "source_realized_workbench_v1"
METHOD_ID = "source_realized_redaction_v1"
PROJECTION = "source-realized-location-redaction/1"
RECEIVER = "source-realized-publication-receiver/2"
ENVELOPE = "source-realized-redaction-envelope/1"
ENDPOINT = "/api/current/source-realized-redaction"
PUBLIC = {"case_id", "task", "corpus", "date", "document_id", "query", "focal_marker"}
PINS = ("resource_id", "registry_sha256", "index_sha256")
CODE_FREEZE = dict(path="phase/demo_refinement_20261126/source_realized_workbench_v1/CODE_FREEZE.json",
    sha256="ceda77020fcc821de1376cce2351779931a13e750b585f9aec17c4eff10f9a8c")
AVAILABILITY = "Unpublished audit artifact; content hash retained; not a public fetch target"


def require(condition, code):
    if not condition:
        raise ValueError(code)


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def digest(value):
    return sha(encoded(value))


def _pairs(rows):
    result = {}
    for key, value in rows:
        require(key not in result, "DUPLICATE_JSON_KEY")
        result[key] = value
    return result


def parse(raw):
    return json.loads(raw, object_pairs_hook=_pairs,
        parse_constant=lambda _: (_ for _ in ()).throw(ValueError("NONFINITE_JSON")))


def reference(path):
    path = Path(path)
    return dict(path=path.relative_to(ROOT).as_posix(), sha256=sha(path.read_bytes()))


def checked(ref, *, raw=False):
    require(isinstance(ref, dict) and {"path", "sha256"} <= ref.keys()
        and set(ref) <= {"path", "sha256", "bytes"}, "CLOSED_ARTIFACT_REF_REQUIRED")
    relative = ref["path"]
    require(isinstance(relative, str) and relative and "\\" not in relative
        and not PurePosixPath(relative).is_absolute()
        and all(part not in {"", ".", ".."} for part in relative.split("/")), "UNSAFE_ARTIFACT_PATH")
    require(isinstance(ref["sha256"], str) and re.fullmatch("[a-f0-9]{64}", ref["sha256"]), "BAD_ARTIFACT_HASH")
    path = ROOT / relative
    require(path.resolve(strict=True) == path, "SYMLINK_ARTIFACT_PATH")
    value = path.read_bytes()
    require(sha(value) == ref["sha256"], "ARTIFACT_BYTES_CHANGED")
    if "bytes" in ref:
        require(type(ref["bytes"]) is int and ref["bytes"] == len(value), "ARTIFACT_LENGTH_CHANGED")
    if raw:
        return value
    return parse(gzip.decompress(value) if relative.endswith(".gz") else value)


def verify_code():
    freeze = checked(CODE_FREEZE)
    require(freeze["status"] == "CODE_STOPPED_FOR_READER_AND_PACKET_REVIEW", "CODE_NOT_FROZEN")
    for ref in freeze["files"]:
        checked(ref, raw=True)
    return freeze


def _canonical_replay(ready_ref):
    """Fresh interpreter isolates the canonical builder's unqualified module names."""
    result = subprocess.run([sys.executable, "-B", str(HERE / "replay.py")],
        input=encoded(ready_ref), capture_output=True, timeout=300, cwd=ROOT)
    require(result.returncode == 0, "CANONICAL_READY_REPLAY_FAILED: " + result.stderr.decode(errors="replace")[-2000:])
    proof = parse(result.stdout)
    require(encoded(proof) == encoded(dict(version=RECEIVER, ready_ref=ready_ref,
        code_freeze_ref=CODE_FREEZE, canonical_verify_ready=True, network_disabled=True,
        loaded_logical_seals_verified=True, canonical_encoded_replay_equal=True,
        API_calls=0, native_runs=0)), "CANONICAL_REPLAY_RECEIPT_DIFFERS")
    return proof


def _sealed(value, version):
    require(value.get("version") == version and value.get("sha256") ==
        digest({k: v for k, v in value.items() if k != "sha256"}), "CANONICAL_SELFHASH_OR_VERSION_CHANGED")


def verify_typed_outputs(actual_method, actual_view, replayed_method, replayed_view):
    """V2 receiver: logical seals AND type-sensitive full canonical-byte equality."""
    _receiver_types(actual_method, actual_view)
    _receiver_types(replayed_method, replayed_view)
    for actual, replayed, kind in ((actual_method, replayed_method, "method"),
                                   (actual_view, replayed_view, "view")):
        _sealed(actual, "source-realized-redaction-" + kind + "/1")
        _sealed(replayed, "source-realized-redaction-" + kind + "/1")
        require(encoded(actual) == encoded(replayed), "TYPED_COMPLETE_CANONICAL_REPLAY_DIFFERS")
    return True


def _receiver_types(method, view):
    for key in ("API_calls", "native_runs"):
        require(type(method[key]) is int and method[key] == 0, "METHOD_INTEGER_TYPE_CHANGED")
    for obj, expected in ((method, dict(source_ascription_not_world_truth=True,
            native_B_licenses_or_tiers_created=False, publication_authorized=False)),
            (view, dict(source_ascription_not_world_truth=True, graph_paths_fabricated=False,
                native_status_or_gates_rewritten=False, publication_authorized=False))):
        require(all(obj.get(key) is value for key, value in expected.items()), "AUTHORITY_BOOLEAN_TYPE_CHANGED")
        original = obj["original_native"]
        require(original["preserved_whole_by_reference"] is True
            and original["candidates_or_tiers_modified"] is False
            and original["merged_with_new_method"] is False, "NATIVE_CONTEXT_BOOLEAN_TYPE_CHANGED")
    require(type(view["nomination_only"]) is bool, "NOMINATION_BOOLEAN_TYPE_CHANGED")
    for branch in view["readings"]:
        require(type(branch["raw_candidate_count"]) is int and branch["raw_candidate_count"] >= 0,
            "CANDIDATE_COUNT_INTEGER_TYPE_CHANGED")
        for group in branch["candidates"]:
            require(type(group["rank"]) is int and group["rank"] > 0, "RANK_INTEGER_TYPE_CHANGED")
    def intervals(node):
        if isinstance(node, dict):
            if {"start", "end"} <= node.keys():
                require(type(node["start"]) is type(node["end"]) is int, "SOURCE_OR_QUERY_OFFSET_INTEGER_TYPE_CHANGED")
            for child in node.values(): intervals(child)
        elif isinstance(node, list):
            for child in node: intervals(child)
    intervals(method)
    intervals(view)


def project(value, *, kind, original_file_sha256):
    """Only hash-bound artifact location fields are nulled; text/numbers stay exact.

    This is a deterministic transformation, NOT an admission/authority API.
    prepare() must authenticate the private original before publication.
    """
    require(kind in {"view", "method"}, "UNKNOWN_PROJECTION_KIND")
    require("publication_projection_version" not in value, "ALREADY_PROJECTED_PACKET")
    _sealed(value, "source-realized-redaction-" + kind + "/1")
    require(re.fullmatch("[a-f0-9]{64}", original_file_sha256 or ""), "ORIGINAL_FILE_HASH_REQUIRED")
    redacted = []

    def scrub(node, pointer=""):
        if isinstance(node, list):
            return [scrub(v, pointer + "/" + str(i)) for i, v in enumerate(node)]
        if not isinstance(node, dict):
            return deepcopy(node)
        out = {}
        for key, child in node.items():
            at = pointer + "/" + key.replace("~", "~0").replace("/", "~1")
            if key in {"path", "receipt"} and isinstance(child, str):
                require(re.fullmatch("[a-f0-9]{64}", str(node.get("sha256", ""))),
                    "UNCOMMITTED_ARTIFACT_LOCATION: " + at)
                require("publication_availability" not in node, "ALREADY_PROJECTED_REFERENCE")
                out[key] = None
                out["publication_availability"] = AVAILABILITY
                redacted.append(dict(pointer=at, reference_sha256=node["sha256"]))
            else:
                out[key] = scrub(child, at)
        return out

    projected = scrub(value)
    projected.pop("sha256")
    projected.update(publication_projection_version=PROJECTION,
        **{"original_" + kind + "_sha256": value["sha256"]},
        publication_lineage=dict(version=PROJECTION, artifact_kind=kind,
            original_canonical_sha256=value["sha256"], original_file_sha256=original_file_sha256,
            transformation="HASH_BOUND_ARTIFACT_LOCATIONS_TO_NULL_ONLY", redacted_locations=redacted,
            original_nested_commitments_not_reissued=True, source_text_or_scores_changed=False,
            native_baseline_rewritten=False))
    projected["sha256"] = digest(projected)
    return projected


def _public_ref(ref):
    return dict(path=None, sha256=ref["sha256"], publication_availability=AVAILABILITY,
        **({"bytes": ref["bytes"]} if "bytes" in ref else {}))


def _params(case, resource_binding):
    return dict(case_id=case["case_id"], config="llm_readings",
        **{key: resource_binding[key] for key in PINS})


def _endpoint(name, params):
    return "/api/current/" + name + "?" + urlencode(sorted(params.items()))


def _span(text, span, *, text_key="text"):
    require(isinstance(span, dict) and type(span.get("start")) is int and type(span.get("end")) is int
        and 0 <= span["start"] < span["end"] <= len(text)
        and text[span["start"]:span["end"]] == span.get(text_key), "SOURCE_INTERVAL_OR_TEXT_CHANGED")


def _sources(view, params):
    pages = {}
    for page in view["source_pages"]:
        pid = page["page_id"]
        require(pid not in pages and page["corpus"] == view["case"]["corpus"]
            and page["clipped"] is False and len(page["windows"]) == 1, "COMPLETE_UNIQUE_SOURCE_PAGES_REQUIRED")
        window = page["windows"][0]
        text = window["text"]
        require(window["start"] == 0 and window["end"] == len(text)
            and page["page_sha256"] == digest(text) and page["page_utf8_sha256"] == sha(text.encode()),
            "SOURCE_PAGE_HASH_OR_WINDOW_CHANGED")
        pages[pid] = dict(page=page, text=text, citations=[])
    used = set()
    for branch in view["readings"]:
        reading_id = branch["reading"]["id"]
        for group in branch["candidates"]:
            for candidate in group["variants"]:
                reader = candidate["source_reader"]
                pid = reader["canonical_page_id"]
                require(pid in pages, "CANDIDATE_SOURCE_PAGE_NOT_PROJECTED")
                page, text = pages[pid]["page"], pages[pid]["text"]
                require(candidate["reading_id"] == reading_id and candidate["source"]["page_id"] == pid
                    and candidate["source"]["document_id"] == reader["document_id"] == page["document_id"]
                    and reader["corpus"] == page["corpus"] and reader["date"] == page["date"]
                    and reader["source_sha256"] == page["page_sha256"]
                    and candidate["source"]["page_sha256"] == page["page_sha256"]
                    and candidate["source"]["date"] == page["date"]
                    and reader["source_index_ref"] == view["source_index_ref"], "SOURCE_READER_BINDING_CHANGED")
                spans = [("quote", reader["quote_span"]), ("phrase", reader["phrase_span"]),
                         ("qualification", reader["qualification_span"])]
                require(reader["quote_span"] == candidate["source"]["exact_quote"]
                    and reader["phrase_span"] == candidate["source"]["original_phrase"]
                    and reader["qualification_span"] == candidate["source"]["qualification_paragraph"],
                    "SOURCE_READER_COPY_CHANGED")
                for context in reader["focal_source_contexts"]:
                    anchor = context["anchor"]
                    require(anchor["page_id"] == pid, "FOCAL_CONTEXT_NOT_OWN_SOURCE")
                    spans += [("focal_anchor", dict(start=anchor["start"], end=anchor["end"], text=anchor["quote"])),
                              ("focal_qualification", context["qualification_span"])]
                for role, span in spans:
                    _span(text, span)
                    pages[pid]["citations"].append(dict(reading_id=reading_id, candidate_id=candidate["id"],
                        role=role, start=span["start"], end=span["end"], text=span["text"]))
                used.add(pid)
    require(used == set(pages), "UNUSED_OR_MISSING_CANONICAL_SOURCE_PAGE")
    return [dict(canonical_page_id=pid, endpoint=_endpoint("source-v6", dict(params, source_id=pid)),
        params=dict(params, source_id=pid), expected_page=deepcopy(value["page"]),
        citations=value["citations"]) for pid, value in pages.items()]


def _bind(case, native_ref, resource_binding, method, view, native):
    require(set(case) == PUBLIC and all(type(value) is str for value in case.values())
        and case["task"] == "redaction", "EXACT_SEVEN_FIELD_REDACTION_CASE_REQUIRED")
    require(case == native["public_case"] == native["case"] == view["case"], "PUBLIC_CASE_NATIVE_VIEW_MISMATCH")
    require(native["query_sha256"] == native["result"]["query_sha256"] == view["query_sha256"]
        == method["query_sha256"] == digest(case["query"]) and method["case_sha256"] == digest(case), "EXACT_QUERY_BINDING_REQUIRED")
    require(native["native_checksum"] == digest(native["result"]), "ORIGINAL_NATIVE_RESULT_CHECKSUM_CHANGED")
    require(type(native["api_calls"]) is int and native["api_calls"] == 0
        and native["answers_read"] is False and native["grades_read"] is False
        and native["query_only_inference"] is True, "NATIVE_BOOLEAN_OR_INTEGER_TYPE_CHANGED")
    for key in ("completed_drafts_per_reading", "construction_pages", "retrieval_document_budget",
                "retrieval_passage_budget", "top_k"):
        value = native["configuration"][key]
        require(type(value) is int and value > 0, "NATIVE_BUDGET_INTEGER_TYPE_CHANGED")
    original = view["original_native"]
    require(original == method["original_native"]
        and encoded({k: original["native_ref"][k] for k in ("path", "sha256")})
            == encoded({k: native_ref[k] for k in ("path", "sha256")})
        and original["native_checksum"] == native["native_checksum"]
        and original["preserved_whole_by_reference"] is True
        and original["candidates_or_tiers_modified"] is False
        and original["merged_with_new_method"] is False, "EXACT_UNCHANGED_NATIVE_REQUIRED")
    checked(original["native_ref"], raw=True)  # Optional recorded byte count is still strict.
    require(method["method_id"] == view["method_id"] == METHOD_ID
        and view["method_packet_sha256"] == method["sha256"], "TYPED_METHOD_BINDING_CHANGED")
    index = native["execution_context"]["index_ref"]
    require(native["execution_context"]["version"] == "pinned-execution-context/1", "EXACT_NATIVE_EXECUTION_CONTEXT_REQUIRED")
    require(native["binding"] == index == method["source_index_ref"] == view["source_index_ref"]
        == method["authority_bindings"]["source_index_ref"], "EXACT_NATIVE_EXECUTION_INDEX_REQUIRED")
    full_binding = native_resource_binding(native_ref)
    require(set(PINS) <= resource_binding.keys() <= full_binding.keys()
        and all(type(value) is str and value == full_binding[key] for key, value in resource_binding.items()),
        "RESOURCE_ROUTE_PINS_CHANGED")
    policy = native["configuration"]["source_view_policy"]
    require(policy == native["result"]["source_view_policy"] == view["source_view_policy"]
        == method["source_view_policy"] == method["authority_bindings"]["source_view_policy"], "SOURCE_POLICY_CHANGED")
    require(method["reading_ids"] == [r["id"] for r in native["plan"]["readings_packet"]["readings"]]
        == [b["reading"]["id"] for b in view["readings"]], "ORIGINAL_READING_INVENTORY_CHANGED")
    require(view["native_status_or_gates_rewritten"] is False and view["graph_paths_fabricated"] is False
        and view["source_ascription_not_world_truth"] is True and method["source_ascription_not_world_truth"] is True
        and method["native_B_licenses_or_tiers_created"] is False
        and view["publication_authorized"] is False and method["publication_authorized"] is False,
        "SOURCE_METHOD_AUTHORITY_BOUNDARY_CHANGED")


def native_resource_binding(native_ref):
    """Exact existing Viewer binding, including incumbent cable graph fallback."""
    native = checked(native_ref)
    index = native["execution_context"]["index_ref"]
    registry = checked(native["execution_context"]["registry_ref"])
    require(registry["sha256"] == index["registry_sha256"], "EXECUTION_REGISTRY_BINDING_CHANGED")
    corpus = native["public_case"]["corpus"]
    registered = registry["corpora"][corpus]
    if index["resource_id"] is None:
        require(index["source_status"] == registered["status"] == "INCUMBENT_NOT_MIGRATED"
            and not registered.get("resource_id")
            and encoded(index["native_index_ref"]) == encoded(dict(registered["incumbent_index_ref"],
                binding=registered["incumbent_binding"]))
            and index["native_index_ref"]["binding"]["corpus"] == corpus
            and index["native_index_ref"]["binding"]["graph_id"] == registered["graph_id"]
            and index["native_index_ref"]["binding"]["hierarchy_id"] == registered["hierarchy_id"]
            and index["path"] == index["native_index_ref"]["path"]
            and index["sha256"] == index["native_index_ref"]["sha256"], "EXACT_LEGACY_NATIVE_RESOURCE_SHAPE_REQUIRED")
        resource_id = index["native_index_ref"]["binding"]["graph_id"]
    else:
        resource_id = index["resource_id"]
        require(type(resource_id) is str and resource_id == registered.get("resource_id")
            == index["native_index_ref"].get("resource_id")
            and index["source_status"] == registered["status"] == "CURRENT_NATIVE_RESOURCE_EXPLICIT",
            "REGISTERED_NATIVE_RESOURCE_ID_CHANGED")
    return dict(corpus=corpus, resource_id=resource_id,
        registry_sha256=index["registry_sha256"], index_sha256=index["sha256"],
        graph_id=registered["graph_id"], hierarchy_id=registered["hierarchy_id"], source_status=registered["status"])


def prepare(*, case, native_ref, resource_binding, artifacts):
    """Authenticate exact private artifacts; return data only, never write/export.

    artifacts is {view_ref, method_ref, producer_ready_ref}. No caller waiver,
    parser, prevalidated boolean or replay-skipping option is accepted.
    """
    require(set(artifacts) == {"view_ref", "method_ref", "producer_ready_ref"}, "CLOSED_REVIEWED_SOURCE_ARTIFACTS_REQUIRED")
    verify_code()
    ready = checked(artifacts["producer_ready_ref"])
    require(type(ready["API_calls"]) is type(ready["native_runs"]) is int
        and ready["API_calls"] == ready["native_runs"] == 0
        and ready["publication_authorized"] is False, "READY_BOOLEAN_OR_INTEGER_TYPE_CHANGED")
    require(ready["view_ref"] == artifacts["view_ref"] and ready["method_ref"] == artifacts["method_ref"],
        "READY_OUTPUT_REFS_DIFFER")
    before = {key: checked(ref, raw=True) for key, ref in artifacts.items()}
    replay = _canonical_replay(artifacts["producer_ready_ref"])
    require(all(checked(artifacts[key], raw=True) == raw for key, raw in before.items()), "ARTIFACT_CHANGED_DURING_REPLAY")
    method, view, native = checked(artifacts["method_ref"]), checked(artifacts["view_ref"]), checked(native_ref)
    _sealed(method, "source-realized-redaction-method/1")
    _sealed(view, "source-realized-redaction-view/1")
    _bind(case, native_ref, resource_binding, method, view, native)
    params = _params(case, resource_binding)
    sources = _sources(view, params)
    public_method = project(method, kind="method", original_file_sha256=artifacts["method_ref"]["sha256"])
    public_view = project(view, kind="view", original_file_sha256=artifacts["view_ref"]["sha256"])
    require(re.fullmatch(r"[A-Za-z0-9_-]+", case["case_id"]), "SAFE_PUBLIC_ASSET_CASE_ID_REQUIRED")
    assets, asset_refs = {}, {}
    for kind, value in (("method", public_method), ("view", public_view)):
        raw = encoded(value)
        ref = dict(path="data/source-realized/" + case["case_id"] + "/" + sha(raw) + ".json", sha256=sha(raw))
        assets[ref["path"]] = raw
        asset_refs["public_" + kind + "_ref"] = ref
    metadata = dict(receiver_version=RECEIVER, method_id=METHOD_ID, endpoint=_endpoint("source-realized-redaction", params),
        original_view_sha256=view["sha256"], public_view_sha256=public_view["sha256"],
        original_method_sha256=method["sha256"], public_method_sha256=public_method["sha256"],
        original_native_sha256=native_ref["sha256"], native_checksum=native["native_checksum"],
        query_sha256=view["query_sha256"], case_sha256=digest(case),
        source_view_policy=deepcopy(view["source_view_policy"]), resource_binding=deepcopy(resource_binding),
        execution_context=_scrub_execution(native["execution_context"]),
        publication_projection_version=PROJECTION, envelope_version=ENVELOPE, **deepcopy(asset_refs),
        **{key: _public_ref(ref) for key, ref in artifacts.items()})
    envelope = dict(version=ENVELOPE, case_id=case["case_id"], config="llm_readings",
        resource_binding=deepcopy(resource_binding), method=public_method, view=public_view, **deepcopy(asset_refs))
    return dict(metadata=metadata, public_view=public_view, public_method=public_method,
        source_page_ids=[r["canonical_page_id"] for r in sources], source_requests=sources,
        canonical_replay=replay, envelope=envelope, public_assets=assets)


def _scrub_execution(execution):
    # Reuse the exact path-only projection on a temporary sealed metadata record.
    wrapper = dict(version="source-realized-redaction-method/1", execution_context=execution)
    wrapper["sha256"] = digest(wrapper)
    return project(wrapper, kind="method", original_file_sha256=digest(execution))["execution_context"]


def verify_public(*, case, native_ref, resource_binding, artifacts, public_view, metadata, public_method,
                  envelope, public_assets):
    """Reopen/replay canonical originals, then compare the ENTIRE public transport."""
    expected = prepare(case=case, native_ref=native_ref, resource_binding=resource_binding, artifacts=artifacts)
    for name, actual in (("public_view", public_view), ("metadata", metadata), ("public_method", public_method),
                         ("envelope", envelope)):
        require(encoded(actual) == encoded(expected[name]), "PUBLIC_TRANSPORT_REPLAY_DIFFERS: " + name)
    require(set(public_assets) == set(expected["public_assets"]) and all(type(raw) is bytes
        and raw == expected["public_assets"][path] for path, raw in public_assets.items()), "PUBLIC_ASSET_BYTES_DIFFER")
    return True


def attach(entry, ready_ref):
    """Return a PRIVATE selection-entry copy with canonical R artifact bindings.

    Parent must use prepare() at compose/export; never serve this private entry.
    """
    ready = checked(ready_ref)
    require(ready.get("version") == "source-realized-redaction-ready/1", "TYPED_R_READY_REQUIRED")
    result = deepcopy(entry)
    require("reviewed_source_artifacts" not in result, "DO_NOT_OVERWRITE_EXISTING_SOURCE_METHOD")
    result["reviewed_source_artifacts"] = dict(view_ref=ready["view_ref"], method_ref=ready["method_ref"],
        producer_ready_ref=deepcopy(ready_ref))
    # Full replay occurs now, not merely when the parent later serializes it.
    prepare(case=result["case"], native_ref=result["outputs"]["native_checkpoint"],
        resource_binding=native_resource_binding(result["outputs"]["native_checkpoint"]),
        artifacts=result["reviewed_source_artifacts"])
    return result


def verify_source_response(prepared, source_id, response):
    """Check a normal source-v6 response against this authenticated VIEW's bytes.

    Call on prepare() output in the same trusted exporter, never an unsigned
    client-supplied object. This checks transport correspondence, not new support.
    """
    requests = {r["canonical_page_id"]: r for r in prepared["source_requests"]}
    require(source_id in requests, "UNDECLARED_SOURCE_ROUTE")
    expected = requests[source_id]["expected_page"]
    text = expected["windows"][0]["text"]
    require(response.get("id") == response.get("canonical_page_id") == source_id
        and response.get("text") == text and response.get("source_sha256") == expected["page_sha256"]
        and response.get("permitted") is True, "SOURCE_V6_BODY_OR_PERMISSION_CHANGED")
    for key in ("document_id", "corpus", "date", "classification", "visibility", "handling"):
        require(response.get(key) == expected[key], "SOURCE_V6_METADATA_CHANGED: " + key)
    for key, value in expected["original_page_metadata"].items():
        require(response.get(key) == value, "SOURCE_V6_ORIGINAL_PAGE_METADATA_CHANGED")
    pins = prepared["metadata"]["resource_binding"]
    require(all(response.get("resource_binding", {}).get(key) == pins[key] for key in PINS), "SOURCE_V6_RESOURCE_PINS_CHANGED")
    case = prepared["public_view"]["case"]
    policy = prepared["public_view"]["source_view_policy"]
    origin = case["document_id"] if case["corpus"] != "cib" or policy["id"] == "strict_prior" else None
    require(response.get("source_view_policy") == policy and response.get("cutoff") == case["date"]
        and response.get("whole_origin_excluded") == origin, "SOURCE_V6_SCOPE_CHANGED")
    for citation in requests[source_id]["citations"]:
        _span(text, citation)
    return True
