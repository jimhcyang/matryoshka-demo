"""API0 METHOD/VIEW projection from reopened canonical actual source records."""
from copy import deepcopy
import json
import math
from pathlib import Path
import re

from binding import HERE, SRC, R, dependencies, inputs

METHOD_ID = 'source_realized_redaction_v1'
CLASS_FORMULA = '(evidence_class + .99*raw_source_alignment)/3'
ALIGNMENT_FORMULA = '.75*facet_alignment + .25*own_quote_lexical_fit'


def save(path, value):
    path = R.safe(path, HERE)
    R.require(not path.exists(), 'NEW_OWNED_ARTIFACT_ONLY')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, ensure_ascii=True, indent=2, allow_nan=False)
        stream.write('\n')
    return R.reference(path)


def bounded(value):
    R.require(type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1, 'FINITE_BOUNDED_PRIORITY_FEATURE')
    return value


def source_alignment(row):
    raw = row['raw_focal_assessment']
    requested = raw['requested_weight']
    R.require(type(requested) in (int, float) and 0 < requested <= 1 + 1e-12, 'FOCAL_REQUESTED_WEIGHT')
    facet = bounded(raw['aligned_requested_weight'] / requested)
    R.require(abs(facet - raw['alignment']) <= 1e-12, 'FOCAL_ALIGNMENT_ARITHMETIC')
    def terms(text):
        return set(re.findall(r"[a-z0-9]+(?:['-][a-z0-9]+)*", text.casefold()))
    # The caller supplies fill solely from the immutable admitted variant.
    fill_terms = terms(row['_fill'])
    quotes = raw['bound_source_anchors']
    scores = []
    for anchor in quotes:
        target = terms(anchor['quote'])
        overlap = fill_terms & target
        value = .5 * len(overlap) / len(fill_terms) if fill_terms else 0.
        value += .5 * len(overlap) / len(fill_terms | target) if fill_terms | target else 0.
        scores.append(value)
    local = max(scores, default=0.)
    R.require(abs(local - row['context_priority']['local_lexical_fit']) <= 1e-12
        and abs(facet - row['context_priority']['alignment']) <= 1e-12, 'FOCAL_OWN_QUOTE_LEXICAL_REPLAY')
    return dict(facet_alignment=facet, own_quote_lexical_fit=local,
        value=.75 * facet + .25 * local, formula=ALIGNMENT_FORMULA,
        winning_quote=deepcopy(quotes[scores.index(local)]) if quotes else None,
        per_quote_scores=[dict(anchor_id=a['id'], value=v) for a, v in zip(quotes, scores, strict=True)],
        source_quote_union_used=False)


def priority(candidate, final, quarantined=None):
    if final is None:
        return dict(mode='NOMINATION_ONLY', evidence_state='NOMINATION_ONLY', evidence_class=None,
            source_supported_fill_approved=False, value=bounded(candidate['context_priority']['score']),
            raw_source_alignment=None, formula=candidate['context_priority']['formula'],
            units='NOMINATION_CONTEXT_PRIORITY_INDEX', probability=False)
    row = final.get(candidate['id'])
    state, band, approved, alignment = 'UNRESOLVED', 0, False, None
    if row is not None:
        enriched = dict(row, _fill=candidate['fill'])
        alignment = source_alignment(enriched)
        label = row['source_focal_class']
        approved = row['source_supported_fill_approved'] is True
        R.require(not approved or label == 'DIRECT_TARGET_SOURCE', 'DIRECT_APPROVAL_CLASS_MISMATCH')
        if label == 'DIRECT_TARGET_SOURCE' and approved:
            state, band = 'DIRECT_SOURCE_APPROVED', 2
        elif label == 'INFERENTIAL_CONTEXT':
            state, band = 'INFERENTIAL_CONTEXT', 1
        elif label == 'EXPLICIT_CONFLICT':
            state = 'EXPLICIT_CONFLICT'
        elif label == 'HOLD_SEMANTIC_REVIEW':
            state = 'HOLD_SEMANTIC_REVIEW'
        else:
            R.require(label in {'NOINFO', 'DIRECT_TARGET_SOURCE'}, 'UNKNOWN_FOCAL_STATE')
    raw = alignment['value'] if alignment else 0.
    value = (band + .99 * raw) / 3
    return dict(mode='ACTUAL_FOCAL_REPLAY', evidence_state=state, evidence_class=band,
        source_supported_fill_approved=approved, value=bounded(value), raw_source_alignment=alignment,
        formula=CLASS_FORMULA, units='EVIDENCE_CLASS_PRIORITY_INDEX', probability=False,
        focal_row=deepcopy(row), quarantine=deepcopy((quarantined or {}).get(candidate['id'])))


def groups(variants, reading_id):
    R.require(len(variants) <= 8, 'MAX_EIGHT_ADMITTED_VARIANTS_PER_READING')
    buckets = {}
    for candidate in variants:
        R.require(candidate['reading_id'] == reading_id, 'EXACT_SAME_READING_DEDUP_ONLY')
        key = ' '.join(candidate['fill'].casefold().split())
        buckets.setdefault(key, []).append(candidate)
    result = []
    for key, values in buckets.items():
        values = sorted(values, key=lambda c: (-c['priority']['value'], c['id']))
        head = values[0]
        by_doc = {}
        for c in values:
            by_doc.setdefault(c['source']['document_id'], []).append(c)
        maxima = [dict(document_id=doc, value=max(c['priority']['value'] for c in rows),
            variant_ids=[c['id'] for c in rows]) for doc, rows in sorted(by_doc.items())]
        result.append(dict(id='source_surface_' + R.W.digest([METHOD_ID, reading_id, key])[:24],
            fill=head['fill'], representative_id=head['id'], priority=deepcopy(head['priority']), variants=deepcopy(values),
            document_maxima=maxima, dedup_rule='SAME_SURFACE_DISPLAY_ONLY_NO_IDENTITY_OR_FACT_UNION',
            source_votes_added=0, aliases_merged=False, proof_requirements_unioned=False))
    result.sort(key=lambda c: (-c['priority']['value'], c['id']))
    for rank, c in enumerate(result, 1):
        c['rank'] = rank
    return result


def focal_source_contexts(candidate, row, observation):
    if row is None:
        return []
    page = observation.pages[candidate['source']['page_id']]
    text = page['text']
    result = []
    for anchor in row['raw_focal_assessment']['bound_source_anchors']:
        start, end = anchor['start'], anchor['end']
        R.require(anchor['page_id'] == page['id'] and text[start:end] == anchor['quote'], 'FOCAL_ANCHOR_NOT_OWN_RAW_PAGE')
        lo = text.rfind('\n\n', 0, start) + 2 if '\n\n' in text[:start] else 0
        hi = text.find('\n\n', end)
        hi = len(text) if hi < 0 else hi
        result.append(dict(anchor=deepcopy(anchor), qualification_span=dict(start=lo, end=hi, text=text[lo:hi]),
            qualification_contains_opaque=bool(R.W.V1.OPAQUE.search(text[lo:hi]))))
    return result


def raw_duplicates(branch, observation):
    requests = {r['request_key']: r for r in observation.requests}
    result = []
    for duplicate in branch.get('duplicate_surface_variants', []):
        request = requests[duplicate['request_key']]
        proposal = duplicate['proposal']
        proof = next(r['proof'] for r in request['local_validation']['valid_rows'] if r['proposal'] == proposal)
        reviewed = next(r for r in request['review_validation']['rows'] if r['proposal'] == proposal)
        result.append(dict(original_duplicate=deepcopy(duplicate), source_proof=deepcopy(proof),
            separate_nomination_review=deepcopy(reviewed), actual_request_ref=request['executor_record_ref'],
            scored=False, locally_grammar_checked=False, factual_support_approved=False,
            reason='RAW_DUPLICATE_RETAINED_NOT_NEW_ADMITTED_VARIANT'))
    return result


def compose(observation, admitted, finalized, spec, producer):
    """Projection only; build()/verify_ready() ALWAYS authenticate inputs first."""
    readings = observation.plan['readings_packet']['readings']
    expected_ids = [r['id'] for r in readings]
    R.require([b['reading']['id'] for b in admitted['readings']] == expected_ids, 'ORIGINAL_READING_INVENTORY_REQUIRED')
    known = {c['id'] for b in admitted['readings'] for c in b['candidates']}
    focal = None if finalized is None else {r['candidate_id']: r for r in finalized['rows']}
    quarantine = {} if finalized is None else {r['candidate_id']: r for r in finalized['quarantined']}
    if finalized is not None:
        R.require(len(focal) == len(finalized['rows']) and len(quarantine) == len(finalized['quarantined'])
            and set(focal).isdisjoint(quarantine) and set(focal) | set(quarantine) == known,
            'COMPLETE_EXACT_FOCAL_CANDIDATE_INVENTORY')
    branches, used = [], set()
    for reading, branch in zip(readings, admitted['readings'], strict=True):
        variants = []
        for c in branch['candidates']:
            page = observation.pages[c['source']['page_id']]
            for field in ('exact_quote', 'original_phrase', 'qualification_paragraph'):
                span = c['source'][field]
                R.require(page['text'][span['start']:span['end']] == span['text'], 'SOURCE_SPAN_CHANGED')
            R.require(c['completed_input'] == observation.case['query'].replace(observation.case['focal_marker'], c['fill'])
                and R.W.digest(c['completed_input']) == c['completed_input_sha256'], 'COMPLETE_INSERTION_CHANGED')
            variant = deepcopy(c)
            variant['priority'] = priority(c, focal, quarantine)
            variant['source_reader'] = dict(canonical_page_id=page['id'], document_id=page['document_id'], corpus=page['corpus'],
                source_index_ref=deepcopy(observation.bindings['source_index_ref']),
                quote_span=deepcopy(c['source']['exact_quote']), phrase_span=deepcopy(c['source']['original_phrase']),
                qualification_span=deepcopy(c['source']['qualification_paragraph']),
                date=page['date'], source_sha256=page['source_sha256'])
            variant['source_reader']['focal_source_contexts'] = focal_source_contexts(c, None if focal is None else focal.get(c['id']), observation)
            variants.append(variant)
            used.add(page['id'])
        slate = groups(variants, reading['id'])
        branches.append(dict(reading=deepcopy(reading), admission_status=branch['status'],
            raw_candidate_count=len(variants), candidates=slate, top5_ids=[c['id'] for c in slate[:5]],
            reserve_ids=[c['id'] for c in slate[5:8]], holds=deepcopy(branch.get('holds', [])),
            deferred=deepcopy(branch.get('deferred', [])), duplicate_surface_variants=deepcopy(branch.get('duplicate_surface_variants', []))))
        branches[-1]['unscored_raw_surface_observations'] = raw_duplicates(branch, observation)
    primary = next((b['reading']['id'] for b in branches if b['candidates']), None)
    presentation = spec['presentation_reading_id']
    R.require(presentation is None or any(b['reading']['id'] == presentation and b['candidates'] for b in branches),
        'EXPLICIT_NONEMPTY_PRESENTATION_READING_REQUIRED')
    method = R.sealed(dict(version='source-realized-redaction-method/1', method_id=METHOD_ID, task='redaction',
        label='Source-realized redaction candidates', state='NOMINATION_ONLY' if finalized is None else 'ACTUAL_FOCAL_REVIEWED',
        input_refs=deepcopy(spec), producer=deepcopy(producer), case_sha256=R.W.digest(observation.case),
        query_sha256=R.W.digest(observation.case['query']), reading_ids=expected_ids,
        original_native=deepcopy(admitted['legacy_native']), source_view_policy=deepcopy(observation.bindings['source_view_policy']),
        source_index_ref=deepcopy(observation.bindings['source_index_ref']), authority_bindings=deepcopy(observation.bindings),
        maximum_variants_per_reading=8, top5_visible_reserve6_to8_retained=True,
        score_rules=dict(final_formula=CLASS_FORMULA, raw_alignment_formula=ALIGNMENT_FORMULA,
            nomination_formula='.55*own_page_focal_coverage + .25*local_grammatical_fit + .20*nonrepeated_content_fraction',
            classes=dict(DIRECT_SOURCE_APPROVED=2, INFERENTIAL_CONTEXT=1, UNRESOLVED=0, EXPLICIT_CONFLICT=0),
            same_score_used_for_ranking_and_display=True, probability=False),
        alias_identity_merge_enabled=False, native_B_licenses_or_tiers_created=False,
        source_ascription_not_world_truth=True, whole_visible_query_event_certified=False,
        native_runs=0, API_calls=0, publication_authorized=False))
    pages = []
    for position, pid in enumerate(observation.bindings['inspected_page_ids']):
        if pid in used:
            page = observation.pages[pid]
            pages.append(dict(R.W.V2.project_page(page, position), original_page_metadata={k: deepcopy(page[k])
                for k in ('earlier_page', 'later_page', 'canonical_sequence', 'raw_text_sha256', 'source_hash_contract') if k in page}))
    view = R.sealed(dict(version='source-realized-redaction-view/1', method_id=METHOD_ID, method_packet_sha256=method['sha256'],
        case=deepcopy(observation.case), query_sha256=R.W.digest(observation.case['query']),
        original_native=deepcopy(admitted['legacy_native']), source_view_policy=deepcopy(observation.bindings['source_view_policy']),
        source_index_ref=deepcopy(observation.bindings['source_index_ref']), source_pages=pages, readings=branches,
        selection=dict(primary_reading_id=primary, display_reading_id=presentation or primary,
            rule='FIRST_NONEMPTY_NEW_METHOD_SLATE_OR_NULL', presentation_reading_id=presentation,
            presentation_only=presentation is not None, native_or_QA_reading_selection_changed=False),
        focal_summary=None if finalized is None else dict(valid_rows=len(focal), quarantined=len(quarantine),
            source_approved=sum(r['source_supported_fill_approved'] is True for r in finalized['rows']),
            quarantined_rows=deepcopy(finalized['quarantined']), assessment_receipt=deepcopy(finalized['assessment_receipt']),
            semantic_review_receipt=deepcopy(finalized['semantic_review_receipt'])),
        nomination_only=finalized is None, native_status_or_gates_rewritten=False,
        source_ascription_not_world_truth=True, graph_paths_fabricated=False, publication_authorized=False))
    return method, view


def producer():
    return dict(dependencies=dependencies(), code_pins={p.name: R.sha(p.read_bytes()) for p in sorted(HERE.glob('*.py'))},
        reader_contract_ref=R.reference(HERE / 'CONTRACT.md'))


def build(spec_ref, output, *, parser=None):
    out = R.safe(HERE / output, HERE)
    R.require(not out.exists(), 'NEW_OUTPUT_ONLY')
    if parser is None:
        from matryoshka_next.construction import SourceParses
        parser = SourceParses()
    spec = R.checked(spec_ref)
    origin = producer()
    observation, admitted, final = inputs(spec, parser)
    method, view = compose(observation, admitted, final, spec, origin)
    R.require(origin == producer(), 'PRODUCER_CHANGED_DURING_BUILD')
    mref, vref = save(out / 'METHOD.json', method), save(out / 'VIEW.json', view)
    return save(out / 'READY.json', dict(version='source-realized-redaction-ready/1', status='READY_FOR_READER_AND_INDEPENDENT_REVIEW',
        spec_ref=spec_ref, method_ref=mref, view_ref=vref, producer=origin,
        native_runs=0, API_calls=0, publication_authorized=False))


def verify_ready(ready_ref, *, parser=None):
    ready = R.checked(ready_ref)
    R.require(set(ready) == {'version', 'status', 'spec_ref', 'method_ref', 'view_ref', 'producer',
        'native_runs', 'API_calls', 'publication_authorized'}
        and ready['version'] == 'source-realized-redaction-ready/1'
        and ready['status'] == 'READY_FOR_READER_AND_INDEPENDENT_REVIEW'
        and ready['native_runs'] == ready['API_calls'] == 0 and ready['publication_authorized'] is False
        and ready['producer'] == producer(), 'READY_PRODUCER_OR_SEMANTIC_FIELDS_CHANGED')
    if parser is None:
        from matryoshka_next.construction import SourceParses
        parser = SourceParses()
    spec = R.checked(ready['spec_ref'])
    observation, admitted, final = inputs(spec, parser)
    method, view = compose(observation, admitted, final, spec, ready['producer'])
    R.require(R.checked(ready['method_ref']) == method and R.checked(ready['view_ref']) == view,
        'COMPLETE_METHOD_VIEW_REPLAY_DIFFERS')
    return True


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec-ref', required=True)
    parser.add_argument('--spec-sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(build(dict(path=args.spec_ref, sha256=args.spec_sha256), args.output)))
