"""Frozen canonical admission and actual focal replay; no sender or waiver."""
import importlib
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
SRC = HERE.parents[2]
EXECUTOR = PHASE / 'source_proposals_extension_v8_executor_v1'
sys.dont_write_bytecode = True
sys.path.insert(0, str(EXECUTOR))
for name in ('executor_v8', 'actual_adapter', 'admission_adapter'):
    if name in sys.modules and Path(sys.modules[name].__file__).resolve() != EXECUTOR / (name + '.py'):
        raise ValueError('SOURCE_REALIZED_MODULE_COLLISION')
import executor_v8 as R
import admission_adapter as X

EXECUTOR_PIN = '75ae58021fb92d67a12dc2552d6ee858da0b31ea177cec266d84a4d994a49b41'
ADMISSION_REVIEW = dict(path='phase/demo_refinement_20261126/review/source_proposal_admission_v2/REVIEW.json',
    sha256='1105b84056fb9d452ecfea00732263e2cc433c17b3b73d6813879df5dc74172e')


def dependencies():
    path = EXECUTOR / 'FREEZE_EXECUTOR_V1.json'
    R.require(R.sha(path.read_bytes()) == EXECUTOR_PIN, 'FROZEN_READONLY_EXECUTOR_HELPERS_CHANGED')
    for ref in R.Q.strict_json(path.read_bytes())['files']:
        R.checked(ref, parse=False)
    X.backend()
    review = R.checked(ADMISSION_REVIEW)
    R.require(review['decision'] == 'GO_EXACT_CANONICAL_V2_ENTRY_POINTS'
        and review['owner_freeze_ref']['sha256'] == X.FREEZE_PIN, 'CANONICAL_ADMISSION_V2_REVIEW_REQUIRED')
    return dict(executor_helpers_freeze_ref=R.reference(path), admission_v2_freeze_ref=R.reference(X.OWNER / 'FREEZE_V2.json'),
        admission_independent_review_ref=ADMISSION_REVIEW)


def backend(issuer):
    dependencies()
    if issuer == 'v7_six':
        source = importlib.import_module('executor_adapter')
        admitted, focal = X.backend()
    elif issuer == 'v8_extension':
        source, admitted, focal = X, X, X
    else:
        raise ValueError('EXPLICIT_CANONICAL_ISSUER_REQUIRED')
    return source, admitted, focal


def inputs(spec, parser):
    R.require(set(spec) == {'issuer', 'results_ref', 'cohort', 'case_id', 'admission_ref',
        'focal_bundle_ref', 'presentation_reading_id'}, 'CLOSED_SOURCE_REALIZED_INPUT')
    source, admit, focal = backend(spec['issuer'])
    observation = source.load_observation(spec['results_ref'], cohort=spec['cohort'], case_id=spec['case_id'])
    expected = admit.admit_observation(observation, parser=parser)
    admitted = R.checked(spec['admission_ref'])
    R.require(R.encoded(admitted) == R.encoded(expected), 'CANONICAL_ADMISSION_COMPLETE_REPLAY_DIFFERS')
    R.require(admitted['actual_executor_receipts'] is True and admitted['factual_support_certified'] is False
        and admitted['legacy_native']['candidates_or_tiers_modified'] is False, 'NO_SYNTHETIC_OR_NATIVE_PROMOTION')
    final = None
    if spec['focal_bundle_ref'] is not None:
        bundle = R.checked(spec['focal_bundle_ref'])
        R.require(set(bundle) == {'version', 'request_ref', 'assessment_response_ref', 'assessment_stage_ref',
            'review_response_ref', 'review_stage_ref', 'finalized_ref'}
            and bundle['version'] == 'source-realized-focal-input/1', 'CLOSED_ACTUAL_FOCAL_BUNDLE_REQUIRED')
        packet = R.checked(bundle['request_ref'])
        R.require(R.encoded(packet) == R.encoded(focal.prepare(observation, admitted, parser=parser)),
            'FOCAL_REQUEST_NOT_CANONICAL_ADMISSION')
        response = R.Q.provider_output(R.checked(bundle['assessment_response_ref'], parse=False))
        stage = R.checked(bundle['assessment_stage_ref'])
        review = None if bundle['review_response_ref'] is None else R.Q.provider_output(R.checked(bundle['review_response_ref'], parse=False))
        review_stage = None if bundle['review_stage_ref'] is None else R.checked(bundle['review_stage_ref'])
        expected = focal.finalize(packet, response, observation=observation, admitted=admitted, parser=parser,
            assessment_stage=stage, review_response=review, review_stage=review_stage)
        final = R.checked(bundle['finalized_ref'])
        R.require(R.encoded(final) == R.encoded(expected), 'ACTUAL_FOCAL_FINALIZATION_COMPLETE_REPLAY_DIFFERS')
    return observation, admitted, final
