"""Authenticated loopback companion. Static replay and real Live never alias."""
import argparse
from collections import deque
from dataclasses import dataclass
import hashlib
import hmac
import fcntl
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import threading
import time
from urllib.parse import urlsplit

from contract import (API_ROOT, HERE, MAX_BODY, MODEL, PHASE, REFS, ROOT, STATE, STAGES,
                      TERMINAL, WORKSPACE, Reject, encoded, headroom, ledger_total,
                      read_json, scope_for, sha, validate, write_json)

PREFIX = "/matryoshka-demo/"


def origin(value):
    parsed = urlsplit(value)
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username
            or parsed.password or parsed.path or parsed.query or parsed.fragment
            or (parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1"})):
        raise ValueError("An exact HTTPS or loopback origin is required")
    _ = parsed.port
    return value


@dataclass
class Config:
    site: Path = PHASE / "stage/site"
    state: Path = STATE
    fixture: bool = False
    execute_paid: bool = False
    max_seconds: float = 240
    max_rss_mib: int = 8192
    max_spend_usd: float = 1.0
    job_spend_usd: float = 0.40
    session_seconds: float = 3600
    allowed_origins: tuple = ()


class Jobs:
    def __init__(self, config, token):
        self.config = config
        if (not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", token) or token.startswith("sk-")
                or not 1 <= config.max_seconds <= 600 or not 128 <= config.max_rss_mib <= 8192
                or not 0 < config.max_spend_usd <= 1 or not 0 < config.job_spend_usd <= config.max_spend_usd
                or not 1 <= config.session_seconds <= 28800):
            raise ValueError("Invalid session capability or fixed server limits")
        self.token_hash = hashlib.sha256(token.encode()).digest()
        self.expires = time.monotonic() + config.session_seconds
        self.lock = threading.RLock()
        self.jobs, self.cache = {}, {}
        self.submissions = deque()
        self.stop = threading.Event()
        self.active = None
        self.start_total = 0 if config.fixture else ledger_total()
        self.absolute_cap = min(50.0, self.start_total + config.max_spend_usd)
        self.ready = config.fixture or (config.execute_paid and bool(os.environ.get("OPENAI_API_KEY")))
        headroom()
        config.state.mkdir(parents=True, exist_ok=True, mode=0o700)
        config.state.chmod(0o700)
        self.process_lock = (config.state / "server.lock").open("a+")
        try:
            fcntl.flock(self.process_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.process_lock.close()
            raise ValueError("One companion process per state directory is allowed") from None
        if not config.fixture and config.execute_paid:
            authorization = config.state / "paid-envelope.json"
            if authorization.exists():
                saved = read_json(authorization)
                if (saved.get("version") != "matryoshka-live-paid-envelope/1"
                        or not math.isfinite(saved.get("baseline_usd", float("nan")))
                        or not 0 <= saved["baseline_usd"] <= self.start_total
                        or not 0 < saved.get("max_spend_usd", 0) <= 1):
                    raise ValueError("Invalid retained Live authorization")
                self.absolute_cap = min(self.absolute_cap, saved["baseline_usd"]
                                        + min(config.max_spend_usd, saved["max_spend_usd"]))
            else:
                write_json(authorization, dict(version="matryoshka-live-paid-envelope/1",
                           baseline_usd=self.start_total, max_spend_usd=config.max_spend_usd))
        self.thread = threading.Thread(target=self.work, name="live-single-worker", daemon=True)
        self.thread.start()

    def authenticate(self, header):
        return (time.monotonic() < self.expires and isinstance(header, str)
                and header.startswith("Bearer ") and hmac.compare_digest(
                    hashlib.sha256(header[7:].encode()).digest(), self.token_hash))

    def status(self, job):
        return {k: v for k, v in job.items() if k not in {"cancel", "directory", "request_key"}}

    def persist(self, job):
        write_json(job["directory"] / "job.json", self.status(job))

    def event(self, job, stage, code=None):
        if stage not in STAGES:
            return
        if job["events"] and job["events"][-1]["stage"] == stage:
            return
        job["status"] = stage if stage in TERMINAL else ("queued" if stage == "queued" else "running")
        job["stage"] = stage
        job["updated_at"] = time.time()
        job["events"].append(dict(sequence=len(job["events"]), stage=stage, at=job["updated_at"]))
        if code:
            job["error_code"] = code
        self.persist(job)

    def get(self, identity):
        if not re.fullmatch(r"[a-f0-9]{32}", identity) or identity not in self.jobs:
            raise Reject("JOB_NOT_FOUND", 404)
        return self.jobs[identity]

    def submit(self, request, *, previous=None):
        request = validate(request)
        if not self.ready:
            raise Reject("PAID_EXECUTION_DISABLED_OR_KEY_UNCONFIGURED", 503)
        headroom()
        now = time.monotonic()
        with self.lock:
            if len(self.jobs) >= 32:
                raise Reject("SESSION_JOB_LIMIT", 429)
            while self.submissions and now - self.submissions[0] > 60:
                self.submissions.popleft()
            if len(self.submissions) >= 12:
                raise Reject("SUBMISSION_RATE_LIMIT", 429)
            if sum(j["status"] not in TERMINAL for j in self.jobs.values()) >= 4:
                raise Reject("QUEUE_FULL", 429)
            if previous and previous["attempt"] >= 3:
                raise Reject("RETRY_LIMIT", 409)
            if not self.config.fixture and ledger_total() >= self.absolute_cap:
                raise Reject("LIVE_BUDGET_EXHAUSTED", 402)
            identity = secrets.token_hex(16)
            job = dict(job_id=identity, run_id="live_" + identity, status="queued", stage="queued",
                       request=request, source_scope=scope_for(request), created_at=time.time(),
                       events=[], execution_kind="fixture" if self.config.fixture else "live",
                       attempt=previous["attempt"] + 1 if previous else 1,
                       retry_of=previous["job_id"] if previous else None,
                       cancel=False, directory=self.config.state / "jobs" / identity,
                       request_key=sha(request), cached_result=False)
            self.jobs[identity] = job
            self.submissions.append(now)
            self.event(job, "queued")
            return self.status(job)

    def cancel(self, identity):
        with self.lock:
            job = self.get(identity)
            if job["status"] in TERMINAL:
                return self.status(job)
            job["cancel"] = True
            if job["status"] == "queued":
                self.event(job, "cancelled", "CANCELLED_BY_ANALYST")
            return self.status(job)

    def retry(self, identity):
        with self.lock:
            previous = self.get(identity)
            if previous["status"] not in TERMINAL - {"completed"}:
                raise Reject("ONLY_UNSUCCESSFUL_JOBS_CAN_RETRY", 409)
            if previous.get("retry_job"):
                return self.status(self.get(previous["retry_job"]))
            result = self.submit(previous["request"], previous=previous)
            previous["retry_job"] = result["job_id"]
            self.persist(previous)
            return result

    def result(self, identity):
        job = self.get(identity)
        if job["status"] != "completed":
            raise Reject("RESULT_NOT_READY", 409)
        value = read_json(job["directory"] / "result.json")
        if (value.get("run_id") != job["run_id"] or value.get("request") != job["request"]
                or sha(value) != job.get("result_sha256")):
            raise Reject("RESULT_INTEGRITY_FAILED", 409)
        return value

    def health(self):
        return dict(version="matryoshka-live-api/1", ready=self.ready,
                    mode="fixture" if self.config.fixture else "live", paid_enabled=self.config.execute_paid,
                    model=MODEL, scope="query-only planning; Redaction-only model readings; deterministic execution",
                    limits=dict(max_query_bytes=2000, max_body_bytes=MAX_BODY, workers=1,
                                max_seconds=self.config.max_seconds, max_rss_mib=self.config.max_rss_mib,
                                max_session_spend_usd=self.config.max_spend_usd, job_spend_usd=self.config.job_spend_usd,
                                cumulative_cap_usd=50, session_jobs=32, queue=4, attempts=3),
                    session_expires_in_seconds=max(0, int(self.expires - time.monotonic())))

    def work(self):
        while not self.stop.wait(0.1):
            with self.lock:
                pending = next((j for j in self.jobs.values() if j["status"] == "queued"), None)
                if pending is None:
                    continue
            try:
                with self.lock:
                    self.event(pending, "validating")
                self.run(pending)
            except Exception:
                # Never retain/return exception messages, environment or tracebacks.
                with self.lock:
                    if pending["status"] not in TERMINAL:
                        try:
                            self.event(pending, "failed", "WORKER_FAILED_CLOSED")
                        except Exception:
                            pending.update(status="failed", stage="failed", error_code="STORAGE_UNAVAILABLE")

    def run(self, job):
        cfg = self.config
        directory = job["directory"]
        payload = dict(request=job["request"], run_id=job["run_id"], fixture=cfg.fixture,
                       max_seconds=cfg.max_seconds, absolute_cap_usd=self.absolute_cap,
                       job_spend_usd=cfg.job_spend_usd)
        write_json(directory / "input.json", payload)
        # Child has only the environment needed by Python, NLP and the provider.
        environment = {k: v for k, v in os.environ.items() if k in {
            "PATH", "HOME", "TMPDIR", "LANG", "LC_ALL", "VIRTUAL_ENV", "OPENAI_API_KEY"}}
        if cfg.fixture:
            environment.pop("OPENAI_API_KEY", None)
        environment.update(PYTHONPATH=str(ROOT), PYTHONUNBUFFERED="1", PYTHONDONTWRITEBYTECODE="1",
                           OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1",
                           TOKENIZERS_PARALLELISM="false")
        # Preserve any tighter caller-supplied shared envelope without copying secrets.
        if not cfg.fixture:
            ceiling = min(self.absolute_cap, ledger_total() + cfg.job_spend_usd)
            if os.environ.get("NARRATIVE_INCREMENTAL_BASELINE_USD") is not None:
                ceiling = min(ceiling, float(os.environ["NARRATIVE_INCREMENTAL_BASELINE_USD"])
                              + float(os.environ["NARRATIVE_INCREMENTAL_CEILING_USD"]))
            environment.update(NARRATIVE_INCREMENTAL_BASELINE_USD="0",
                               NARRATIVE_INCREMENTAL_CEILING_USD=str(ceiling))
        process = subprocess.Popen([sys.executable, "-B", str(HERE / "worker.py"), str(directory)],
                                   env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, start_new_session=True)
        self.active = process
        start = time.monotonic()
        reason = None
        try:
            while process.poll() is None:
                if self.stop.is_set() or job["cancel"]:
                    reason = ("cancelled", "CANCELLED_BY_ANALYST")
                elif time.monotonic() - start > cfg.max_seconds:
                    reason = ("timed_out", "WALL_TIME_LIMIT")
                else:
                    try:
                        headroom()
                    except Reject:
                        reason = ("resource_limited", "DISK_FLOOR_3_GIB")
                    rss = subprocess.run(["/bin/ps", "-o", "rss=", "-p", str(process.pid)],
                                         capture_output=True, timeout=2, text=True)
                    if rss.returncode == 0 and rss.stdout.strip():
                        job["peak_rss_mib"] = max(job.get("peak_rss_mib", 0), int(rss.stdout.strip()) / 1024)
                        if job["peak_rss_mib"] > cfg.max_rss_mib:
                            reason = ("resource_limited", "MEMORY_LIMIT")
                if reason:
                    process.kill()
                    break
                progress = directory / "progress.json"
                if progress.is_file():
                    try:
                        value = read_json(progress)
                        stages = value.get("stages", [])
                        if len(stages) <= 16:
                            with self.lock:
                                for stage in stages[len(job["events"]) - 2:]:
                                    if stage in STAGES - TERMINAL and stage != "queued":
                                        self.event(job, stage)
                    except (ValueError, OSError):
                        pass
                time.sleep(0.15)
            process.wait(timeout=5)
            with self.lock:
                if reason or job["cancel"]:
                    self.event(job, *(reason or ("cancelled", "CANCELLED_BY_ANALYST")))
                elif process.returncode != 0 or not (directory / "result.json").is_file():
                    failure = read_json(directory / "failure.json") if (directory / "failure.json").is_file() else {}
                    safe = failure.get("code")
                    if safe not in {"QUERY_VALIDATION_FAILED", "BUDGET_LIMIT", "SOURCE_OR_RUNTIME_VALIDATION_FAILED", "DISK_FLOOR_3_GIB"}:
                        safe = "SOURCE_OR_RUNTIME_VALIDATION_FAILED"
                    self.event(job, "failed", safe)
                else:
                    value = read_json(directory / "result.json")
                    if value.get("run_id") != job["run_id"] or value.get("request") != job["request"]:
                        raise Reject("WORKER_IDENTITY_CHANGED", 409)
                    job["result_sha256"] = sha(value)
                    job["cached_result"] = value["receipt"]["execution_cache_hit"]
                    self.event(job, "completed")
        finally:
            if process.poll() is None:
                process.kill()
                process.wait(timeout=5)
            self.active = None

    def close(self):
        self.stop.set()
        if self.active and self.active.poll() is None:
            self.active.kill()
        self.thread.join(timeout=8)
        self.process_lock.close()


def create_server(config, token, *, port=8977):
    for value in config.allowed_origins:
        origin(value)
    spec = importlib.util.spec_from_file_location("live_static_mirror", WORKSPACE / "matryoshka_demo_site/release-tools/serve_static.py")
    mirror = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mirror)
    http = mirror.server(config.site, port=port, prefix=PREFIX,
                         datasets_root=WORKSPACE / "matryoshka_demo_site/datasets")
    try:
        jobs = Jobs(config, token)
    except BaseException:
        http.server_close()
        raise
    allowed_hosts = {"127.0.0.1:" + str(http.server_port), "localhost:" + str(http.server_port)}
    allowed_origins = {"http://" + host for host in allowed_hosts} | set(config.allowed_origins)
    base_handler = http.RequestHandlerClass.func

    class Handler(base_handler):
        server_version = "MatryoshkaLive/1"
        sys_version = ""

        def setup(self):
            super().setup()
            self.connection.settimeout(5)

        def log_message(self, *_):
            pass

        def list_directory(self, _):
            self.send_error(404)

        def send_error(self, code, message=None, explain=None):
            self.reply(code, dict(error="REQUEST_REJECTED"))

        def reply(self, status, value):
            raw = encoded(value)
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Vary", "Origin")
            self.send_header("Connection", "close")
            request_origin = self.headers.get("Origin")
            if request_origin in allowed_origins:
                self.send_header("Access-Control-Allow-Origin", request_origin)
            self.end_headers()
            self.close_connection = True
            if self.command != "HEAD":
                self.wfile.write(raw)

        def host_check(self):
            if len(self.headers.get_all("Host", [])) != 1 or self.headers["Host"] not in allowed_hosts:
                raise Reject("HOST_NOT_ALLOWED", 403)
            if len(self.path) > 512 or not self.path.startswith("/") or self.path.startswith("//"):
                raise Reject("PATH_NOT_ALLOWED", 400)

        def access(self, *, preflight=False):
            self.host_check()
            if len(self.headers.get_all("Origin", [])) > 1:
                raise Reject("ORIGIN_NOT_ALLOWED", 403)
            request_origin = self.headers.get("Origin")
            if not request_origin:
                # Same-origin browser GETs may omit Origin, and the Live page
                # deliberately sends no Referer. Browser-controlled Fetch
                # Metadata plus the explicit bearer/header bind this exception.
                request_origin = "http://" + self.headers["Host"]
                if (preflight or self.command != "GET" or self.headers.get("Sec-Fetch-Site") != "same-origin"
                        or self.headers.get("Sec-Fetch-Mode") not in {"cors", "same-origin"}):
                    raise Reject("ORIGIN_REQUIRED", 403)
            if request_origin not in allowed_origins:
                raise Reject("ORIGIN_NOT_ALLOWED", 403)
            if urlsplit(self.path).query or "%" in self.path or "\\" in self.path:
                raise Reject("EXACT_API_PATH_REQUIRED")
            if not preflight:
                if (len(self.headers.get_all("Authorization", [])) != 1
                        or not jobs.authenticate(self.headers.get("Authorization"))):
                    raise Reject("SESSION_CAPABILITY_REQUIRED", 401)
                if self.headers.get("X-Live-Request") != "1" or self.headers.get("Cookie"):
                    raise Reject("EXPLICIT_NONCOOKIE_REQUEST_REQUIRED", 403)

        def body(self):
            if (self.headers.get("Transfer-Encoding") or self.headers.get("Content-Encoding")
                    or len(self.headers.get_all("Content-Length", [])) != 1):
                raise Reject("FIXED_BODY_LENGTH_REQUIRED", 411)
            length = self.headers.get("Content-Length", "")
            if not re.fullmatch(r"[0-9]{1,5}", length) or not 0 < int(length) <= MAX_BODY:
                raise Reject("BODY_TOO_LARGE", 413)
            if self.headers.get("Content-Type") != "application/json":
                raise Reject("JSON_REQUIRED", 415)
            def pairs(items):
                result = {}
                for key, value in items:
                    if key in result:
                        raise Reject("DUPLICATE_JSON_FIELD")
                    result[key] = value
                return result
            try:
                return json.loads(self.rfile.read(int(length)), object_pairs_hook=pairs,
                                  parse_constant=lambda _: (_ for _ in ()).throw(Reject("INVALID_JSON")))
            except (ValueError, UnicodeError, RecursionError):
                raise Reject("INVALID_JSON") from None

        def do_OPTIONS(self):
            try:
                self.access(preflight=True)
                headers = {h.strip().lower() for h in self.headers.get("Access-Control-Request-Headers", "").split(",") if h.strip()}
                if (not self.path.startswith("/live-api/") or self.headers.get("Access-Control-Request-Method") not in {"GET", "POST"}
                        or not headers <= {"authorization", "content-type", "x-live-request"}
                        or "authorization" not in headers):
                    raise Reject("PREFLIGHT_NOT_ALLOWED", 403)
                self.send_response(204)
                self.send_header("Access-Control-Allow-Origin", self.headers["Origin"])
                self.send_header("Access-Control-Allow-Methods", "GET, POST")
                self.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type, X-Live-Request")
                self.send_header("Access-Control-Max-Age", "60")
                self.send_header("Vary", "Origin")
                self.send_header("Content-Length", "0")
                self.end_headers()
            except Reject as error:
                self.reply(error.status, dict(error=error.code))

        def dispatch(self):
            try:
                self.access()
                with jobs.lock:
                    if self.path == "/live-api/health" and self.command == "GET":
                        value, status = jobs.health(), 200
                    elif self.path == "/live-api/jobs" and self.command == "POST":
                        value, status = jobs.submit(self.body()), 202
                    else:
                        match = re.fullmatch(r"/live-api/jobs/([a-f0-9]{32})(?:/(result|cancel|retry))?", self.path)
                        if not match:
                            raise Reject("ENDPOINT_NOT_FOUND", 404)
                        identity, action = match.groups()
                        job = jobs.get(identity)
                        if self.command == "GET" and action is None:
                            value, status = jobs.status(job), 200
                        elif self.command == "GET" and action == "result":
                            value, status = jobs.result(identity), 200
                        elif self.command == "POST" and action in {"cancel", "retry"}:
                            if self.body() != {}:
                                raise Reject("EMPTY_ACTION_BODY_REQUIRED")
                            value, status = (jobs.cancel(identity) if action == "cancel" else jobs.retry(identity)), 202
                        else:
                            raise Reject("METHOD_NOT_ALLOWED", 405)
                self.reply(status, value)
            except Reject as error:
                self.reply(error.status, dict(error=error.code))
            except Exception:
                self.reply(503, dict(error="SERVICE_UNAVAILABLE"))

        def do_GET(self):
            if self.path.startswith("/live-api"):
                return self.dispatch()
            try:
                self.host_check()
                request_origin = self.headers.get("Origin")
                if request_origin and request_origin not in allowed_origins:
                    raise Reject("ORIGIN_NOT_ALLOWED", 403)
                return super().do_GET()
            except Reject as error:
                self.reply(error.status, dict(error=error.code))

        def do_POST(self):
            return self.dispatch()

        def do_HEAD(self):
            # The inherited HEAD path bypasses the static mirror's path guard.
            self.reply(405, dict(error="METHOD_NOT_ALLOWED"))

    from functools import partial
    http.RequestHandlerClass = partial(Handler, directory=str(config.site))
    # Bound HTTP thread/socket resources independently from the single job worker.
    connections = threading.BoundedSemaphore(16)
    original_process = http.process_request
    original_thread = http.process_request_thread
    def process_request(request, address):
        if not connections.acquire(blocking=False):
            http.shutdown_request(request)
            return
        try:
            original_process(request, address)
        except BaseException:
            connections.release()
            raise
    def process_request_thread(request, address):
        try:
            original_thread(request, address)
        finally:
            connections.release()
    http.process_request = process_request
    http.process_request_thread = process_request_thread
    http.jobs = jobs
    return http


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8977)
    parser.add_argument("--execute-paid", action="store_true", help="Explicitly enable server-side paid planning/readings")
    parser.add_argument("--fixture", action="store_true", help="Synthetic API0 transport fixture, never inference")
    parser.add_argument("--allow-origin", action="append", default=[], help="Exact extra frontend origin, HTTPS only except loopback")
    parser.add_argument("--max-seconds", type=int, default=240)
    parser.add_argument("--max-spend-usd", type=float, default=1.0)
    args = parser.parse_args()
    if args.fixture and args.execute_paid:
        parser.error("Fixture and paid execution are mutually exclusive")
    token = os.environ.get("LIVE_SESSION_TOKEN", "")
    if not token:
        parser.error("Configure a fresh random LIVE_SESSION_TOKEN in the server environment (32+ URL-safe characters)")
    config = Config(fixture=args.fixture, execute_paid=args.execute_paid,
                    max_seconds=args.max_seconds, max_spend_usd=args.max_spend_usd,
                    job_spend_usd=min(0.4, args.max_spend_usd), allowed_origins=tuple(args.allow_origin))
    os.umask(0o077)
    try:
        http = create_server(config, token, port=args.port)
    except Exception:
        parser.exit(2, "Live startup failed closed: check capability, shared ledger, disk floor and limits.\n")
    del token
    print("http://127.0.0.1:" + str(http.server_port) + PREFIX + "live.html", flush=True)
    print("Mode: " + ("fixture (API0, not inference)" if args.fixture else
                       "paid opt-in" if args.execute_paid else "paid execution disabled"), flush=True)
    try:
        http.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        http.jobs.close()
        http.server_close()


if __name__ == "__main__":
    main()
