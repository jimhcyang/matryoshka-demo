"""Actual deterministic engine on synthetic evidence; no bank or provider input."""
from collections import defaultdict
from copy import deepcopy
from pathlib import Path
import socket
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from matryoshka_demo.io import digest
from matryoshka_narrative.contracts import engine_case
from matryoshka_narrative.planning import bind
from matryoshka_narrative.decisions import execute
from matryoshka_next.facts import SourcePolicy
from matryoshka_narrative.traces import build_trace


def fixture(task="hypothesis", **page_changes):
    query = "Oren Vale opened the gate."
    case = dict(case_id="arbitrary_live_fixture", task=task, corpus="iran", query=query,
                document_id="analyst-origin", date="1971-06-02", focal_marker="")
    case = engine_case(case)
    raw = dict(atoms=[dict(id="a1", text=query, kind="proposition", query_quotes=[query], subject=None,
                          predicate=None, object=None, polarity="unknown", modality="unknown", required=True)],
               extractions=dict(entities=[], events=[], claims=[], relations=[]))
    plan = bind(case, raw)
    page = dict(id="fictional-page", canonical_page_id="fictional-page", document_id="fictional-prior",
                corpus="iran", date="1971-06-01", classification="CONFIDENTIAL", permitted=True,
                visibility="earlier", handling=[], text=query, source_sha256=digest(query), earlier_page=1)
    page.update(page_changes)
    corpus = SimpleNamespace(corpus="iran", pages=[page], page_index={page["id"]: 0}, classification={},
                             nodes={}, node_ids=[], units=[], occurrences=[], edge_rows=[], hierarchy={},
                             binding=dict(fixture_only=True), occurrences_by_page=defaultdict(list))
    index = {page["id"]: deepcopy(page)}
    found = dict(eligible=SimpleNamespace(corpus=corpus, page_mask=[True]), pages=[0], passage_budget=1,
                 page_ranks={0: 1}, page_scores={}, node_ranks={}, receipt=dict(inspected_page_ids=[page["id"]]),
                 source_policy=SourcePolicy(corpus, case, index))
    return corpus, case, plan, found, index


class EngineFixtureTests(unittest.TestCase):
    def test_document_inventory_is_complete_within_policy_but_not_evidence(self):
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from worker import document_inventory
        corpus, case, plan, found, index = fixture()
        original = deepcopy(index["fictional-page"])
        sibling = dict(original, id="uninspected-sibling", text="Separate provenance page.",
                       source_sha256=digest("Separate provenance page."), earlier_page=2)
        later = dict(sibling, id="same-day-ineligible", date=case["date"])
        other_doc = dict(sibling, id="other-document", document_id="not-referenced")
        index.update({p["id"]: p for p in (sibling, later, other_doc)})
        policy = SourcePolicy(corpus, case, index)
        sources = {original["id"]: original}
        before = deepcopy(sources)
        inventory = document_inventory(policy, sources)
        pages = inventory[original["document_id"]]
        self.assertEqual([p["id"] for p in pages], ["fictional-page", "uninspected-sibling"])
        self.assertTrue(all(p["provenance_only"] and p["inspection_not_implied"] for p in pages))
        self.assertEqual(sources, before)
        self.assertEqual(found["pages"], [0])
        self.assertNotIn("not-referenced", inventory)
        index["uninspected-sibling"]["source_sha256"] = "0" * 64
        with self.assertRaises(ValueError):
            document_inventory(SourcePolicy(corpus, case, index), sources)

    def test_actual_decisions_and_trace_api0(self):
        with patch.object(socket.socket, "connect", side_effect=AssertionError("No network in fixture")):
            for task in ("mosaic", "hypothesis"):
                corpus, case, plan, found, index = fixture(task)
                result = execute(case, plan, found, source_index=index)
                self.assertEqual(result["atoms"][0]["criterion_state"], "SUPPORTED")
                self.assertEqual(result["api_calls"], 0)
                trace = build_trace(corpus, case, plan, result, found["receipt"], source_index=index)
                self.assertTrue(trace["paths"])
                self.assertEqual(trace["paths"][0]["graph_hops"], 0)
                self.assertEqual(trace["paths"][0]["route_mode"], "DIRECT_SOURCE_HANDOFF")
                self.assertEqual(trace["paths"][0]["decision_source_refs"][0]["text"], case["query"])

    def test_current_source_policy_vetoes_adversarial_admission(self):
        for change in (dict(document_id="analyst-origin"), dict(date="1971-06-02"), dict(date="1971-06-03"),
                       dict(permitted=False), dict(visibility="later_only"), dict(classification="SECRET"),
                       dict(handling=["NOFORN"])):
            corpus, case, plan, found, index = fixture(**change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                execute(case, plan, found, source_index=index)


if __name__ == "__main__":
    unittest.main(verbosity=2)
