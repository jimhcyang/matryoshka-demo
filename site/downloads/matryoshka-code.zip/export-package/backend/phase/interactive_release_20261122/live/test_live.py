"""API0 adversarial tests. All writes stay below this owned live directory."""
from copy import deepcopy
import hashlib
import http.client
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from contract import HERE, PHASE, ROOT, Reject, case_for, encoded, scope_for, sha, validate
from server import Config, create_server, origin

TOKEN = "fixture-session-capability-" + "a" * 32
REQUEST = dict(task="hypothesis", corpus="iran", query="Oren Vale opened the gate.",
               as_of="1971-06-02", excluded_origin="analyst-authored-test", focal_marker="")


class ContractTests(unittest.TestCase):
    def test_valid_arbitrary_inputs(self):
        for task in ("mosaic", "hypothesis", "redaction"):
            for corpus in ("cib", "iran", "vietnam"):
                request = dict(REQUEST, task=task, corpus=corpus)
                if task == "redaction":
                    request.update(query="Oren Vale opened the [MASK].", focal_marker="[MASK]")
                self.assertEqual(validate(request), request)
                self.assertEqual(case_for(request)["document_id"], request["excluded_origin"])

    def test_disallowed_inputs(self):
        probes = [dict(REQUEST, task="shell"), dict(REQUEST, corpus="../../etc/passwd"),
                  dict(REQUEST, date="1971-01-01"), dict(REQUEST, source_policy={"permitted": True}),
                  dict(REQUEST, model="other"), dict(REQUEST, api_root="/tmp"),
                  dict(REQUEST, query="x" * 2001), dict(REQUEST, query="\u00e9" * 1001),
                  dict(REQUEST, as_of="1971-02-30"), dict(REQUEST, as_of="9999-01-01"),
                  dict(REQUEST, excluded_origin=""), dict(REQUEST, excluded_origin="https://localhost/secret"),
                  dict(REQUEST, query="Who opened the gate?"), dict(REQUEST, query="Explain the gate."),
                  dict(REQUEST, query="sk-" + "x" * 24), dict(REQUEST, query="Bearer " + "b" * 32),
                  dict(REQUEST, task="redaction", focal_marker="[MASK]"),
                  dict(REQUEST, query="[MASK] opened the gate."), dict(REQUEST, query=["a"])]
        for probe in probes:
            with self.subTest(probe=probe), self.assertRaises(Reject):
                validate(probe)

    def test_exact_origin(self):
        self.assertEqual(origin("https://example.org"), "https://example.org")
        for value in ("*", "null", "http://example.org", "https://example.org/", "https://u:p@example.org", "https://example.org?x=1"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                origin(value)


class HTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix="fixture-tests-", dir=HERE)
        cls.http = create_server(Config(state=Path(cls.temporary.name), fixture=True,
                                       allowed_origins=("https://example.org",)), TOKEN, port=0)
        cls.thread = threading.Thread(target=cls.http.serve_forever, daemon=True)
        cls.thread.start()
        cls.port = cls.http.server_port
        cls.origin = "http://127.0.0.1:" + str(cls.port)

    @classmethod
    def tearDownClass(cls):
        cls.http.jobs.close()
        cls.http.shutdown()
        cls.http.server_close()
        cls.thread.join(timeout=5)
        cls.temporary.cleanup()

    def request(self, path="/live-api/health", method="GET", body=None, headers=None, raw=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        supplied = {"Origin": self.origin, "Authorization": "Bearer " + TOKEN, "X-Live-Request": "1"}
        if body is not None:
            supplied["Content-Type"] = "application/json"
        supplied.update(headers or {})
        supplied = {k: v for k, v in supplied.items() if v is not None}
        connection.request(method, path, body=raw if raw is not None else encoded(body) if body is not None else None, headers=supplied)
        response = connection.getresponse()
        data = response.read()
        result = response.status, dict(response.getheaders()), data
        connection.close()
        return result

    def submit(self, request=None):
        status, _, raw = self.request("/live-api/jobs", "POST", request or REQUEST)
        self.assertEqual(status, 202, raw)
        return json.loads(raw)

    def wait(self, job):
        for _ in range(150):
            status, _, raw = self.request("/live-api/jobs/" + job["job_id"])
            self.assertEqual(status, 200)
            value = json.loads(raw)
            if value["status"] in {"completed", "failed", "cancelled", "timed_out", "resource_limited"}:
                return value
            time.sleep(.05)
        self.fail("Fixture job did not finish")

    def test_health_requires_authentication(self):
        for headers in ({"Authorization": None}, {"Authorization": "Bearer wrong"}, {"Authorization": "Basic nope"}):
            self.assertEqual(self.request(headers=headers)[0], 401)
        status, headers, data = self.request()
        self.assertEqual(status, 200)
        self.assertNotIn(TOKEN.encode(), data)
        self.assertNotIn(b"OPENAI_API_KEY", data)
        self.assertEqual(headers["Cache-Control"], "no-store")

    def test_origin_host_csrf_and_queries(self):
        for headers in ({"Origin": "https://evil.example"}, {"Origin": "null"}, {"Origin": None},
                        {"Host": "evil.example"}, {"Host": "127.0.0.1"},
                        {"X-Live-Request": None}, {"Cookie": "session=ambient"}):
            self.assertEqual(self.request(headers=headers)[0], 403)
        self.assertEqual(self.request("/live-api/health?token=x")[0], 400)
        self.assertEqual(self.request("/live-api/jobs/%2e%2e/result")[0], 400)
        status, headers, _ = self.request(headers={"Origin": "https://evil.example"})
        self.assertNotIn("Access-Control-Allow-Origin", headers)
        self.assertNotIn("Access-Control-Allow-Credentials", headers)
        self.assertEqual(self.request(headers={"Origin": "https://example.org"})[0], 200)
        self.assertEqual(self.request(headers={"Origin": None, "Sec-Fetch-Site": "same-origin", "Sec-Fetch-Mode": "cors"})[0], 200)
        self.assertEqual(self.request(headers={"Origin": None, "Sec-Fetch-Site": "cross-site", "Sec-Fetch-Mode": "cors"})[0], 403)

    def test_preflight_is_exact_and_not_a_paid_endpoint(self):
        headers = {"Authorization": None, "Access-Control-Request-Method": "POST",
                   "Access-Control-Request-Headers": "authorization, content-type, x-live-request"}
        status, response_headers, _ = self.request("/live-api/jobs", "OPTIONS", headers=headers)
        self.assertEqual(status, 204)
        self.assertEqual(response_headers["Access-Control-Allow-Origin"], self.origin)
        headers["Access-Control-Request-Headers"] = "authorization, x-api-key"
        self.assertEqual(self.request("/live-api/jobs", "OPTIONS", headers=headers)[0], 403)

    def test_body_and_policy_bounds(self):
        for body in (dict(REQUEST, source_policy="all"), dict(REQUEST, api_key="not-allowed"),
                     dict(REQUEST, query="x" * 2001), {"task": "hypothesis"}):
            self.assertEqual(self.request("/live-api/jobs", "POST", body)[0], 400)
        self.assertEqual(self.request("/live-api/jobs", "POST", {}, raw=b"x" * 8193)[0], 413)
        self.assertEqual(self.request("/live-api/jobs", "POST", {}, headers={"Content-Type": "text/plain"})[0], 415)
        self.assertEqual(self.request("/live-api/jobs", "POST", {}, raw=b'{"task":"a","task":"b"}')[0], 400)
        self.assertEqual(self.request("/live-api/jobs", "POST", {}, raw=b'{"x":NaN}')[0], 400)

    def test_fixture_end_to_end_and_artifact_seals(self):
        initial = self.submit()
        job = self.wait(initial)
        self.assertEqual(job["status"], "completed", job)
        status, _, raw = self.request("/live-api/jobs/" + job["job_id"] + "/result")
        self.assertEqual(status, 200)
        value = json.loads(raw)
        self.assertEqual(value["execution_kind"], "fixture")
        self.assertEqual(value["native"]["result"]["status"], "FIXTURE_ONLY")
        self.assertEqual(value["request"], REQUEST)
        self.assertEqual(value["receipt"]["provider_calls"], 0)
        self.assertNotIn(TOKEN.encode(), raw)
        for ref in value["artifacts"].values():
            path = Path(self.temporary.name) / ref["path"]
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), ref["sha256"])
        self.assertIn("planning", [e["stage"] for e in job["events"]])

    def test_cancel_retry_and_idempotent_retry(self):
        job = self.submit(dict(REQUEST, query="Taren closed the gate."))
        self.assertEqual(self.request("/live-api/jobs/" + job["job_id"] + "/cancel", "POST", {})[0], 202)
        self.assertEqual(self.wait(job)["status"], "cancelled")
        status, _, raw = self.request("/live-api/jobs/" + job["job_id"] + "/retry", "POST", {})
        self.assertEqual(status, 202)
        retried = json.loads(raw)
        self.assertEqual(retried["attempt"], 2)
        self.assertEqual(self.request("/live-api/jobs/" + job["job_id"] + "/retry", "POST", {})[2], raw)
        self.wait(retried)

    def test_unknown_job_and_static_mirror(self):
        self.assertEqual(self.request("/live-api/jobs/" + "0" * 32)[0], 404)
        for path in ("/matryoshka-demo/live.html", "/matryoshka-demo/live-result-adapter.js", "/matryoshka-demo/runtime/public-runtime.js"):
            self.assertEqual(self.request(path)[0], 200)
        for path in ("/matryoshka-demo/../PLAN.md", "/matryoshka-demo/%2e%2e/PLAN.md", "/matryoshka-demo/data/"):
            self.assertEqual(self.request(path)[0], 404)
        self.assertEqual(self.request("/matryoshka-demo/live.html", "HEAD")[0], 405)

    def test_session_expiry(self):
        prior = self.http.jobs.expires
        try:
            self.http.jobs.expires = time.monotonic() - 1
            self.assertEqual(self.request()[0], 401)
        finally:
            self.http.jobs.expires = prior


class SupervisorTests(unittest.TestCase):
    def test_disabled_paid_mode_and_single_process_lock(self):
        from server import Jobs
        with tempfile.TemporaryDirectory(prefix="disabled-tests-", dir=HERE) as folder:
            config = Config(state=Path(folder), execute_paid=False)
            with patch("server.ledger_total", return_value=12.831):
                jobs = Jobs(config, TOKEN)
                try:
                    self.assertFalse(jobs.ready)
                    with self.assertRaises(Reject) as caught:
                        jobs.submit(REQUEST)
                    self.assertEqual(caught.exception.status, 503)
                    with self.assertRaises(ValueError):
                        Jobs(config, TOKEN)
                finally:
                    jobs.close()

    def test_budget_envelope_does_not_reset_on_restart(self):
        from server import Jobs
        with tempfile.TemporaryDirectory(prefix="envelope-tests-", dir=HERE) as folder:
            config = Config(state=Path(folder), execute_paid=True)
            with patch("server.ledger_total", return_value=12.831):
                first = Jobs(config, TOKEN)
                first.close()
            with patch("server.ledger_total", return_value=13.2):
                second = Jobs(config, TOKEN)
                try:
                    self.assertAlmostEqual(second.absolute_cap, 13.831)
                finally:
                    second.close()

    def test_shared_budget_reservation_limits_without_calls(self):
        sys.path.insert(0, str(ROOT))
        from matryoshka_narrative.api import Budget
        with tempfile.TemporaryDirectory(prefix="budget-tests-", dir=HERE) as folder:
            budget = Budget(Path(folder))
            with patch.dict(os.environ, {"NARRATIVE_INCREMENTAL_BASELINE_USD": "0",
                                         "NARRATIVE_INCREMENTAL_CEILING_USD": "0.2"}):
                with self.assertRaises(RuntimeError):
                    budget.reserve(dict(model="gpt-6.1-sol"), .21)
                budget.reserve(dict(model="gpt-6.1-sol"), .10)
                self.assertAlmostEqual(budget.total(), .10)
                with self.assertRaises(RuntimeError):
                    budget.reserve(dict(model="gpt-6.1-sol"), .11)
            self.assertAlmostEqual(budget.total(), .10)

    def test_limits_fail_closed(self):
        for kwargs in (dict(max_seconds=601), dict(max_spend_usd=1.01), dict(max_rss_mib=9000),
                       dict(session_seconds=0), dict(max_spend_usd=float("nan"))):
            with self.assertRaises(ValueError):
                from server import Jobs
                Jobs(Config(fixture=True, **kwargs), TOKEN)

    def test_timeout_and_retry_cap(self):
        with tempfile.TemporaryDirectory(prefix="timeout-tests-", dir=HERE) as folder:
            from server import Jobs
            jobs = Jobs(Config(state=Path(folder), fixture=True, max_seconds=1), TOKEN)
            # A controlled process sleeps instead of executing any provider code.
            actual_popen = __import__("subprocess").Popen
            def slow(*args, **kwargs):
                if str(HERE / "worker.py") in args[0]:
                    return actual_popen([sys.executable, "-B", "-c", "import time; time.sleep(10)"], **kwargs)
                return actual_popen(*args, **kwargs)
            try:
                with patch("server.subprocess.Popen", side_effect=slow):
                    job = jobs.submit(REQUEST)
                    for _ in range(60):
                        if jobs.jobs[job["job_id"]]["status"] == "timed_out":
                            break
                        time.sleep(.05)
                    self.assertEqual(jobs.jobs[job["job_id"]]["status"], "timed_out")
                previous = jobs.jobs[job["job_id"]]
                previous["attempt"] = 3
                with self.assertRaises(Reject):
                    jobs.retry(previous["job_id"])
            finally:
                jobs.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
