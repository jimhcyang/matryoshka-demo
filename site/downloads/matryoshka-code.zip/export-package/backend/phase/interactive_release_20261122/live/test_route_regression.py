"""Independent review's invented_route attack, unchanged, plus direct variants."""
import json
from pathlib import Path
import tempfile
import threading

from contract import HERE, read_json, write_json
from server import Config, create_server
from playwright.sync_api import sync_playwright


def main():
    summary = read_json(HERE / 'qa/real-smoke.json')
    envelope = read_json(HERE / 'state/jobs' / summary['job']['job_id'] / 'result.json')
    with tempfile.TemporaryDirectory(prefix='route-regression-', dir=HERE) as folder:
        service = create_server(Config(state=Path(folder), fixture=True), 'fixture-' + 'x' * 48, port=0)
        thread = threading.Thread(target=service.serve_forever, daemon=True)
        thread.start()
        try:
            with sync_playwright() as pw:
                browser = pw.chromium.launch(headless=True)
                page = browser.new_page()
                page.goto('http://127.0.0.1:' + str(service.server_port) + '/matryoshka-demo/live.html')
                result = page.evaluate("""async original => {
                  const {verifyEnvelope}=await import('./live-result-adapter.js');
                  const {buildEvidenceMap}=await import('./evidence-map.js');
                  await verifyEnvelope(original,original.run_id);
                  const outcomes={};
                  for(const name of ['invented_route','direct_edge','direct_graph_node','direct_graph_edges','orphan_graph_step','recorded_route_without_native','recorded_nomination_without_native',
                    'direction_promotion','cross_candidate_support','native_rank_reorder','cross_candidate_location','context_inventory_promotion','context_FOR','readout_direction']){
                    const v=structuredClone(original);
                    // Exact R7 attack body from review/review_live_mount.py.
                    if(name==='direction_promotion'||name==='cross_candidate_support'){
                      const p=v.trace.paths.find(path=>path.direction==='CONTEXT');
                      if(!p)throw Error('The real smoke has no context path');
                      p.direction='SUPPORT';p.endpoint_kind='DECISION_EVIDENCE';
                      if(name==='cross_candidate_support')p.accepted_evidence_ids=[v.selected_evidence.find(e=>e.purpose==='FINAL_DECISION_EVIDENCE'&&e.item_id!==p.candidate_or_atom_id).id];
                      v.trace.paths=[p];
                    }
                    if(name==='native_rank_reorder'){
                      const a=v.native.result.readings[0].candidates,b=v.condition.result.readings[0].candidates;
                      [a[0],a[1]]=[a[1],a[0]];[b[0],b[1]]=[b[1],b[0]];
                    }
                    if(name==='cross_candidate_location'){
                      const item=v.selected_evidence.find(e=>e.direction==='CONTEXT');
                      item.recorded_locations=v.selected_evidence.find(e=>e.purpose==='FINAL_DECISION_EVIDENCE'&&e.item_id!==item.item_id).recorded_locations;
                      v.trace.evidence_inventory=structuredClone(v.selected_evidence);
                    }
                    if(name==='context_inventory_promotion'){
                      const p=v.trace.paths.find(path=>path.direction==='CONTEXT');
                      const item=v.selected_evidence.find(e=>e.item_id===p.candidate_or_atom_id&&e.direction==='CONTEXT');
                      item.purpose='FINAL_DECISION_EVIDENCE';item.direction='SUPPORT';
                      v.trace.evidence_inventory=structuredClone(v.selected_evidence);
                      p.direction='SUPPORT';p.endpoint_kind='DECISION_EVIDENCE';p.accepted_evidence_ids=[item.id];
                    }
                    if(name==='context_FOR')v.trace.paths.find(path=>path.direction==='CONTEXT').direction='FOR';
                    if(name==='readout_direction')v.trace.steps.find(step=>step.kind==='SOURCE_READOUT'&&step.direction==='CONTEXT').direction='SUPPORT';
                    // Exact attack body from review/review_live_mount.py.
                    if(name==='invented_route'){
                      const p=v.trace.paths[0],citation=p.source_refs[0];
                      p.route_mode='RECORDED_SOURCE_ROUTE';p.graph_hops=1;p.original_traversal_claimed=true;
                      p.candidate_or_atom_id=p.candidate_or_atom_id.split('/').at(-1);
                      const step={id:'review_forged_step',kind:'RECORDED_GRAPH_ROUTE',source_refs:[citation],nodes:[
                        {id:'review_node_a',label:'Review injected A',is_graph_node:true,type:'Entity'},
                        {id:'review_node_b',label:'Review injected B',is_graph_node:true,type:'Entity'}],
                        edges:[{id:'review_forged_edge',source:'review_node_a',target:'review_node_b',kind:'REVIEW_UNRECORDED_EDGE'}]};
                      v.trace.steps.push(step);p.steps.splice(1,0,step.id);
                    }
                    if(['direct_edge','direct_graph_node','direct_graph_edges','orphan_graph_step','recorded_route_without_native','recorded_nomination_without_native'].includes(name)){
                      const p=v.trace.paths[0],citation=p.source_refs[0];
                      const step={id:'direct_forged',kind:'SOURCE_GRAPH_NAVIGATION',source_refs:[citation],nodes:[
                        {id:'a',label:'Injected A',is_graph_node:true},
                        {id:'b',label:'Injected B',is_graph_node:true}],
                        edges:[{id:'fake',source:'a',target:'b',kind:'SOURCE_ASSERTION'}]};
                      if(name==='direct_graph_node')step.edges=[];
                      if(name==='direct_graph_edges'){step.graph_edges=step.edges;step.edges=[];step.nodes=[];}
                      v.trace.steps.push(step);
                      if(name!=='orphan_graph_step')p.steps.splice(1,0,step.id);
                      if(name.startsWith('recorded_')){
                        p.route_mode=name==='recorded_route_without_native'?'RECORDED_SOURCE_ROUTE':'RECORDED_RELATION_NOMINATION';
                        p.graph_hops=1;p.original_traversal_claimed=p.route_mode==='RECORDED_SOURCE_ROUTE';
                        step.route_mode=p.route_mode;step.original_traversal_claimed=p.original_traversal_claimed;step.factual_support_implied=false;
                      }
                    }
                    const graph=buildEvidenceMap({trace:v.trace,plan:v.condition.plan,items:null});
                    let accepted=false,message='';
                    try{await verifyEnvelope(v,original.run_id);accepted=true;}catch(error){message=error.message;}
                    outcomes[name]={accepted,message,unvalidated_graph_edges:graph.edges.filter(e=>['REVIEW_UNRECORDED_EDGE','SOURCE_ASSERTION'].includes(e.kind)).length,
                      displayedSupportWithoutVerification:graph.nodes.filter(n=>n.type==='excerpt'&&n.tones.includes('support')).length,
                      nativeContextUnchanged:v.selected_evidence.some(e=>e.direction==='CONTEXT'&&e.purpose==='CANDIDATE_ORIGINAL_CONTEXT_NOT_ASSERTED_SUPPORT')};
                  }
                  return {original_accepted:true,outcomes};
                }""", envelope)
                assert result['outcomes']['invented_route']['unvalidated_graph_edges'] > 0, 'Attack no longer exercises the reported renderer path'
                for name in ('direction_promotion', 'cross_candidate_support'):
                    assert result['outcomes'][name]['displayedSupportWithoutVerification'] > 0
                    assert result['outcomes'][name]['nativeContextUnchanged'] is True
                assert all(not value['accepted'] for value in result['outcomes'].values()), result
                browser.close()
        finally:
            service.jobs.close()
            service.shutdown()
            service.server_close()
            thread.join(timeout=5)
    result.update(status='PASS', paid_calls=0, managed_chromium_headless_shell=True,
                  unchanged_review_attack='review/review_live_mount.py invented_route, direction_promotion and cross_candidate_support bodies')
    write_json(HERE / 'qa/route-regression.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
