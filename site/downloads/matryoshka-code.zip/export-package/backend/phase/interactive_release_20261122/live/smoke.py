"""Explicitly opted-in, <=$1 shared-ledger smoke; no credential values printed."""
import argparse
import http.client
import json
import os
from pathlib import Path
import secrets
import threading
import time

from contract import HERE, encoded, ledger_total, write_json
from server import Config, create_server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute-paid", action="store_true")
    parser.add_argument("--source-smoke", action="store_true", help="New source-anchored CIB cloze; no expected fill is supplied")
    args = parser.parse_args()
    if not args.execute_paid:
        parser.error("A real smoke requires explicit --execute-paid; fixture tests never call the provider")
    if not os.environ.get("OPENAI_API_KEY"):
        parser.exit(2, "Server API environment is not configured.\n")
    token = secrets.token_urlsafe(48)
    baseline = ledger_total()
    service = create_server(Config(execute_paid=True, max_spend_usd=1.0), token, port=0)
    thread = threading.Thread(target=service.serve_forever, daemon=True)
    thread.start()
    port = service.server_port

    def request(path, body=None):
        connection = http.client.HTTPConnection("127.0.0.1", port, timeout=15)
        headers = {"Origin": "http://127.0.0.1:" + str(port), "Authorization": "Bearer " + token,
                   "X-Live-Request": "1"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        connection.request("GET" if body is None else "POST", "/live-api/" + path,
                           body=encoded(body) if body is not None else None, headers=headers)
        response = connection.getresponse()
        value = json.loads(response.read())
        connection.close()
        if response.status not in {200, 202}:
            raise RuntimeError("Live smoke request failed: " + str(response.status))
        return value

    try:
        submitted_request = dict(task="hypothesis", corpus="cib",
            query="The council discussed trade.", as_of="1965-07-02",
            excluded_origin="analyst-live-smoke-20261122", focal_marker="")
        if args.source_smoke:
            submitted_request.update(task="redaction", as_of="1951-03-07", focal_marker="[MASK]",
                query="Goker stated that the USSR had made no approaches to [MASK] concerning the Straits since 1946.",
                excluded_origin="analyst-authored-source-cloze-smoke-20261122")
        submitted = request("jobs", submitted_request)
        print("Submitted bounded CIB Live smoke; no expected answer is supplied.", flush=True)
        job = submitted
        last_stage = None
        deadline = time.monotonic() + 260
        while time.monotonic() < deadline:
            job = request("jobs/" + submitted["job_id"])
            if job["stage"] != last_stage:
                print("stage: " + job["stage"], flush=True)
                last_stage = job["stage"]
            if job["status"] in {"completed", "failed", "cancelled", "timed_out", "resource_limited"}:
                break
            time.sleep(.8)
        after = ledger_total()
        summary = dict(job=job, ledger_before_usd=baseline, ledger_after_usd=after,
                       fresh_charged_or_reserved_usd=after - baseline, cap_usd=50,
                       configured_fresh_envelope_usd=1, credential_values_retained=False)
        if job["status"] == "completed":
            output = request("jobs/" + job["job_id"] + "/result")
            summary.update(result_status=output["native"]["result"].get("status"),
                           paths=len(output["trace"]["paths"]), evidence=len(output["selected_evidence"]),
                           receipt=output["receipt"], artifacts=output["artifacts"])
        write_json(HERE / ("qa/real-smoke-" + job["job_id"] + ".json"), summary)
        write_json(HERE / "qa/real-smoke.json", summary)
        print(json.dumps({k: summary[k] for k in ("ledger_before_usd", "ledger_after_usd", "fresh_charged_or_reserved_usd")}, sort_keys=True), flush=True)
        print("smoke status: " + job["status"] + (" / " + job["error_code"] if "error_code" in job else ""), flush=True)
        if job["status"] != "completed":
            raise SystemExit(1)
    finally:
        service.jobs.close()
        service.shutdown()
        service.server_close()
        thread.join(timeout=5)


if __name__ == "__main__":
    main()
