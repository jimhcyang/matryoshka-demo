"""Managed Chromium shell: responsive UI, API0 E2E, replay-safe handoff, evidence attacks."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import threading

from playwright.sync_api import sync_playwright

from contract import HERE, case_for, scope_for, write_json
from server import Config, create_server
from test_live import REQUEST, TOKEN


def main():
    results = []
    with tempfile.TemporaryDirectory(prefix="browser-tests-", dir=HERE) as folder:
        service = create_server(Config(state=Path(folder), fixture=True), TOKEN, port=0)
        thread = threading.Thread(target=service.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(service.server_port) + "/matryoshka-demo/"
        try:
            with sync_playwright() as playwright:
                # No installed Chrome channel, user profile or executable override.
                browser = playwright.chromium.launch(headless=True)
                context = browser.new_context(viewport=dict(width=1440, height=1000))
                page = context.new_page()
                page.goto(base + "live.html", wait_until="networkidle")
                assert page.locator("#run").is_disabled()
                assert "unavailable" in page.locator("#availability").inner_text()
                assert not page.evaluate("Boolean(window.PublicReplay)")
                assert not page.evaluate("localStorage.length || sessionStorage.length")
                results.append("honest disconnected state; no replay or credential storage")
                page.locator("#capability").fill(TOKEN)
                page.locator("#connect").click()
                page.locator("#question-fields:not([disabled])").wait_for(state="visible")
                assert page.locator("#capability").input_value() == ""
                page.locator("#query").fill(REQUEST["query"])
                page.locator("#corpus").select_option("iran")
                page.locator("#as-of").fill(REQUEST["as_of"])
                page.locator("#excluded-origin").fill(REQUEST["excluded_origin"])
                page.locator("#run").click()
                page.locator("#result").wait_for(state="visible", timeout=20000)
                assert page.locator("#result-status").inner_text() == "FIXTURE_ONLY"
                assert "NOT inference" in page.locator("#availability").inner_text()
                assert "No selected source evidence" in page.locator("#evidence").inner_text()
                assert not page.evaluate("localStorage.length || sessionStorage.length")
                results.append("fixture UI submit/status/result API0 end-to-end")
                for width in (1440, 390):
                    page.set_viewport_size(dict(width=width, height=1000))
                    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth"), width
                page.screenshot(path=str(HERE / "qa/live-mobile.png"), full_page=True)
                results.append("desktop 1440 and mobile 390 without horizontal overflow")

                # Exercise a normal workbench URL without modifying its owner:
                # the stand-in simply imports the real adapter from this origin.
                context.route("**/workbench-v6.html?live_run=*", lambda route: route.fulfill(
                    content_type="text/html", body="<!doctype html><meta charset=utf-8><title>Handoff receiver</title>"))
                with page.expect_popup() as popup:
                    page.locator("#open-workbench").click()
                receiver = popup.value
                receiver.wait_for_load_state()
                packet = receiver.evaluate("""async () => {
                  const adapter = await import('./live-result-adapter.js');
                  const run = new URLSearchParams(location.search).get('live_run');
                  return adapter.loadWorkbenchRun(run);
                }""")
                assert packet["condition"]["result"]["status"] == "FIXTURE_ONLY"
                assert packet["origins"] is None and packet["report"]["saved_replay"] is False
                assert TOKEN not in json.dumps(packet)
                results.append("same-origin opaque-run workbench handshake without credentials")

                direct = receiver.evaluate("""async ({backend, capability, run}) => {
                  window.fetch = () => {throw Error('Saved replay must not transport Live');};
                  const {loadWorkbenchRun} = await import('./live-result-adapter.js');
                  const packet = await loadWorkbenchRun(run, {backend, capability});
                  return packet.execution_kind;
                }""", dict(backend=base.split("/matryoshka-demo/")[0] + "/live-api/", capability=TOKEN, run=packet["run_id"]))
                assert direct == "fixture"
                results.append("direct authenticated XHR loader bypasses global saved fetch shim")

                # Fully synthetic source/result: neither saved cases nor gold inputs.
                sys.path.insert(0, str(HERE.parents[2]))
                from matryoshka_demo.io import digest
                text = "Oren Vale opened the gate."
                source = dict(id="p1", document_id="prior", corpus="iran", date="1971-06-01",
                              text=text, permitted=True, visibility="earlier", classification="CONFIDENTIAL",
                              source_sha256=digest(text))
                citation = dict(canonical_page_id="p1", document_id="prior", date="1971-06-01", text=text,
                                start=0, end=len(text), page_sha256=digest(text))
                native_result = dict(task="hypothesis", atoms=[dict(id="a1", status="SUPPORT", text=text,
                                     evidence=[dict(direction="SUPPORT", citation=citation)])],
                                     inspected_page_ids=["p1"])
                native = dict(public_case=case_for(REQUEST), result=native_result, retrieval={}, query_only_inference=True,
                              grades_read=False, answers_read=False, native_checksum=digest(native_result),
                              binding=dict(sha256="a" * 64))
                evidence = [dict(id="e1", item_id="a1", query_atom_id="a1", source_refs=[citation], purpose="FINAL_DECISION_EVIDENCE", direction="SUPPORT",
                                 recorded_locations=["/result/atoms/0/evidence/0"])]
                trace = dict(paths=[dict(id="path1", candidate_or_atom_id="a1", query_atom_id="a1", direction="SUPPORT", endpoint_kind="DECISION_EVIDENCE",
                                        steps=["s1"], source_refs=[citation], decision_source_refs=[citation],
                                        route_mode="DIRECT_SOURCE_HANDOFF", graph_hops=0, accepted_evidence_ids=["e1"])],
                             steps=[dict(id="s1", kind="SOURCE_READOUT", query_atom_id="a1", direction="SUPPORT", purpose="FINAL_DECISION_EVIDENCE",
                                         nodes=[], edges=[], source_refs=[citation], accepted_evidence_ids=["e1"])],
                             evidence_inventory=evidence, native_decisions_or_ranks_modified=False)
                envelope = dict(version="matryoshka-live-result/1", run_id="live_" + "1" * 32, execution_kind="live",
                                request=REQUEST, native=native, condition=dict(case=native["public_case"],
                                result=dict(deepcopy(native_result), retrieval={}), native_checksum=native["native_checksum"],
                                index_ref=native["binding"], resource_binding=dict(corpus="iran", index_sha256="a" * 64)),
                                trace=trace, sources=dict(p1=source), selected_evidence=evidence,
                                source_scope=scope_for(REQUEST), receipt=dict(no_answer_or_grade_inputs=True, no_chain_of_thought=True))
                provenance = dict(source, id="p2", text="A separately eligible provenance-only page.",
                                  source_sha256=digest("A separately eligible provenance-only page."),
                                  provenance_only=True, inspection_not_implied=True)
                envelope["document_pages"] = dict(prior=[dict(source, provenance_only=True, inspection_not_implied=True), provenance])
                probes = {"valid": envelope}
                for name in ("future", "origin", "quote", "hash", "display", "fake_hop", "context_as_support", "run", "uninspected", "binding",
                             "provenance_future", "provenance_hash", "provenance_class", "provenance_handling", "provenance_promoted", "native_location"):
                    changed = deepcopy(envelope)
                    if name == "future": changed["sources"]["p1"]["date"] = REQUEST["as_of"]
                    if name == "origin": changed["sources"]["p1"]["document_id"] = REQUEST["excluded_origin"]
                    if name == "quote": changed["selected_evidence"][0]["source_refs"][0]["text"] = "forged support"
                    if name == "hash": changed["sources"]["p1"]["source_sha256"] = "0" * 64
                    if name == "display": changed["condition"]["result"]["atoms"][0]["status"] = "FORGED"
                    if name == "fake_hop": changed["trace"]["paths"][0]["graph_hops"] = 1
                    if name == "context_as_support": changed["selected_evidence"][0]["purpose"] = "CANDIDATE_SOURCE_CONTEXT"
                    if name == "run": changed["run_id"] = "live_" + "2" * 32
                    if name == "uninspected": changed["native"]["result"]["inspected_page_ids"] = []
                    if name == "binding": changed["condition"]["index_ref"]["sha256"] = "f" * 64
                    if name == "provenance_future": changed["document_pages"]["prior"][1]["date"] = REQUEST["as_of"]
                    if name == "provenance_hash": changed["document_pages"]["prior"][1]["source_sha256"] = "0" * 64
                    if name == "provenance_class": changed["document_pages"]["prior"][1]["classification"] = "SECRET"
                    if name == "provenance_handling": changed["document_pages"]["prior"][1]["handling"] = ["NOFORN"]
                    if name == "provenance_promoted": changed["selected_evidence"][0]["source_refs"][0]["canonical_page_id"] = "p2"
                    if name == "native_location": changed["selected_evidence"][0]["recorded_locations"] = ["/result/atoms/0/does_not_exist"]
                    probes[name] = changed
                outcomes = receiver.evaluate("""async ({probes, run}) => {
                  const {verifyEnvelope} = await import('./live-result-adapter.js');
                  const outcomes = {};
                  for (const [name, value] of Object.entries(probes)) {
                    try { await verifyEnvelope(value, run); outcomes[name] = true; }
                    catch (_) { outcomes[name] = false; }
                  }
                  return outcomes;
                }""", dict(probes=probes, run=envelope["run_id"]))
                assert outcomes.pop("valid"), outcomes
                assert not any(outcomes.values()), outcomes
                results.append("adapter accepts separate uninspected provenance but rejects 16 forged evidence/provenance/decision/resource/run/path variants")
                page.locator("#connection > summary").click()
                page.locator("#disconnect").click()
                assert page.locator("#run").is_disabled()
                assert not page.evaluate("localStorage.length || sessionStorage.length")
                results.append("disconnect clears the memory-only client and disables submissions")
                # Validate the actual paid result, when available, without any
                # provider call or browser-held provider credential.
                smoke = HERE / "qa/real-smoke.json"
                if smoke.is_file():
                    record = json.loads(smoke.read_bytes())
                    if record["job"]["status"] == "completed":
                        actual = json.loads((HERE / "state/jobs" / record["job"]["job_id"] / "result.json").read_bytes())
                        receiver.evaluate("""async value => {
                          const {toWorkbenchPacket} = await import('./live-result-adapter.js');
                          return (await toWorkbenchPacket(value, value.run_id)).run_id;
                        }""", actual)
                        results.append("actual paid native/condition/trace envelope validates in browser without new calls")
                browser.close()
        finally:
            service.jobs.close()
            service.shutdown()
            service.server_close()
            thread.join(timeout=5)
    write_json(HERE / "qa/browser-tests.json", dict(status="PASS", browser="managed Chromium headless shell", checks=results, paid_calls=0))
    print(json.dumps(dict(status="PASS", checks=results, paid_calls=0), indent=2))


if __name__ == "__main__":
    main()
