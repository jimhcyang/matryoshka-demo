"""One killable, bounded attempt. Never prints provider errors or reasoning."""
from copy import copy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import logging
import os
from pathlib import Path
import resource
import re
import sys
import time
from types import SimpleNamespace

from contract import (API_ROOT, HERE, MODEL, REFS, ROOT, Reject, case_for, encoded,
                      headroom, ledger_total, read_json, scope_for, sha, validate, write_json)

LIMITS = dict(method="current_hierarchy", passage_budget=32, document_budget=16,
              construction_pages=8, draft_budget=12)
PAGE_FIELDS = ("id", "document_id", "corpus", "date", "text", "source_sha256",
               "classification", "visibility", "permitted", "earlier_page", "handling")


def document_inventory(policy, sources):
    """Read-only provenance expansion, never fed back into inference or evidence."""
    from matryoshka_demo.io import digest
    documents = {p["document_id"] for p in sources.values()}
    inventory = {identity: [] for identity in sorted(documents)}
    count, size = 0, 0
    bound_policy = copy(policy)
    # Apply the SAME native admission predicate to the complete bound source
    # index, including eligible pages outside the retrieval materialization.
    bound_policy.corpus = SimpleNamespace(pages=[None])
    for page in policy.bound_pages.values():
        if page["document_id"] not in documents:
            continue
        bound_policy.corpus.pages[0] = page
        if not bound_policy.allowed(0):
            continue
        if digest(page["text"]) != page["source_sha256"]:
            raise ValueError("Document provenance page hash changed")
        value = {key: page.get(key) for key in PAGE_FIELDS}
        value.update(provenance_only=True, inspection_not_implied=True)
        count += 1
        size += len(encoded(value))
        if count > 1024 or size > 8 * 1024**2:
            raise ValueError("Document provenance inventory exceeds server resource limit")
        inventory[page["document_id"]].append(value)
    for pages in inventory.values():
        pages.sort(key=lambda p: (p["earlier_page"] if type(p["earlier_page"]) is int else 10**9, p["id"]))
    return inventory


def fixture_result(request, run_id):
    """Synthetic transport fixture. Intentionally not a historical inference."""
    case = case_for(request)
    result = dict(status="FIXTURE_ONLY", task=request["task"], atoms=[], readings=[],
                  inspected_page_ids=[], api_calls=0)
    condition = dict(case=case, config="llm_readings", run_id=run_id, result=result,
                     plan=dict(atoms=[], slot_readings=[], leads=[]),
                     local_decisions_v65=dict(overall=dict(status="fixture_only"), atoms={}, candidates={}),
                     current_resource_execution=False, fixture_only=True)
    return dict(version="matryoshka-live-result/1", run_id=run_id, request=request,
                execution_kind="fixture", source_scope=scope_for(request),
                native=dict(public_case=case, result=result, query_only_inference=False, fixture_only=True),
                condition=condition, trace=dict(paths=[], steps=[], evidence_inventory=[],
                                                fixture_only=True, native_decisions_or_ranks_modified=False),
                selected_evidence=[], sources={}, document_pages={}, origins=None,
                receipt=dict(execution_cache_hit=False, provider_calls=0, charged_or_reserved_usd=0,
                             fixture_only=True, model=None), artifacts={})


def run(directory):
    started = time.monotonic()
    payload = read_json(directory / "input.json")
    request = validate(payload["request"])
    run_id = payload["run_id"]
    stages = []

    def emit(stage):
        stages.append(stage)
        write_json(directory / "progress.json", dict(stages=stages))

    headroom()
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (int(payload["max_seconds"]), int(payload["max_seconds"]) + 1))
    resource.setrlimit(resource.RLIMIT_FSIZE, (32 * 1024**2, 32 * 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (256, 256))
    logging.disable(logging.CRITICAL)
    if payload["fixture"]:
        for stage in ("planning", "opening_resources", "retrieval", "projection", "saving"):
            emit(stage)
            time.sleep(0.03)
        result = fixture_result(request, run_id)
        seal(directory, result)
        return

    deadline = datetime.now(timezone.utc) + timedelta(seconds=payload["max_seconds"] - 1)
    os.environ.update(NARRATIVE_DEADLINE_UTC=deadline.isoformat(),
                      NARRATIVE_NO_NEW_WORK_UTC=deadline.isoformat(),
                      MATRYOSHKA_API_CONNECT_SECONDS="10",
                      MATRYOSHKA_API_RESPONSE_SECONDS=str(min(90, payload["max_seconds"])))
    sys.path.insert(0, str(ROOT))
    from matryoshka_narrative import guards
    # This phase explicitly authorizes a 3 GiB floor; shared source is unchanged.
    guards.MINIMUM_FREE_BYTES = 3 * 1024**3
    from matryoshka_narrative import workflow, planning, retrieval, api
    from matryoshka_narrative.presentation import display_record
    from matryoshka_narrative.traces import build_trace
    from matryoshka_demo.io import digest
    from matryoshka_next.facts import SourcePolicy

    state = directory.parents[1]
    workflow.OUTPUT = state / "checkpoints"
    case = case_for(request)
    initial_total = ledger_total()
    initial_receipts = {p.name for p in (API_ROOT / "receipts").glob("*.json")}
    reserved_refs = []
    original_reserve = api.Budget.reserve
    def tracked_reserve(budget, wire, amount):
        path, record = original_reserve(budget, wire, amount)
        reserved_refs.append("receipts/" + path.name)
        write_json(directory / "provider-refs.json", dict(receipts=reserved_refs))
        return path, record
    api.Budget.reserve = tracked_reserve
    emit("planning")
    saved = workflow.plan_case(case, api_root=API_ROOT, model=MODEL)
    selected, readings_audit = None, None
    if case["task"] == "redaction":
        emit("model_readings")
        selected, readings_audit = planning.model_readings(case, API_ROOT, model=MODEL)
    write_json(directory / "planning.json", dict(plan=saved, readings=selected, readings_audit=readings_audit))
    emit("opening_resources")
    with workflow.Session(root=ROOT, refs_path=REFS) as session:
        context = session.context(case["corpus"])
        cache_key = sha(dict(request=request, plan=saved, readings=selected,
                             pins=session.narrative_pins, binding=session.refs, environment=session.environment,
                             limits=LIMITS, worker=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                             contract=hashlib.sha256((HERE / "contract.py").read_bytes()).hexdigest()))
        cache = state / "cache" / (cache_key + ".json")
        expected = dict(pins=session.narrative_pins, binding=session.refs["index_refs"][case["corpus"]],
                        environment=session.environment, settings=workflow.configuration(**LIMITS))
        cached = False
        # The current source context was reopened and its hashes verified above.
        if cache.is_file() and not cache.is_symlink():
            entry = read_json(cache)
            if entry.get("sha256") != sha(entry.get("value")):
                raise ValueError("Cache seal mismatch")
            value = entry["value"]
            packet = workflow.validate_packet(value["native"], case, saved["native_plan"], selected, **expected)
            condition, trace, sources = value["condition"], value["trace"], value["sources"]
            document_pages = value["document_pages"]
            cached = True
        else:
            original_retrieve = retrieval.retrieve

            def staged_retrieve(*args, **kwargs):
                emit("retrieval")
                found = original_retrieve(*args, **kwargs)
                emit("construction" if case["task"] == "redaction" else "task_decisions")
                return found

            retrieval.retrieve = staged_retrieve
            try:
                packet = session.execute(case, saved["native_plan"], readings_packet=selected, **LIMITS)
            finally:
                retrieval.retrieve = original_retrieve
            workflow.validate_packet(packet, case, saved["native_plan"], selected, **expected)
            emit("projection")
            native_ref = dict(path="native.json", sha256=hashlib.sha256(encoded(packet)).hexdigest())
            display = display_record(packet, native_ref, context)
            condition = display["configurations"]["llm_readings"]
            policy = SourcePolicy(context.corpus, packet["case"], context.source_index)
            trace = build_trace(context.corpus, packet["case"], packet["plan"], packet["result"],
                                packet["retrieval"], source_index=policy.bound_pages,
                                max_paths=24, max_hops=3, postrun_graph=False)
            sources = {}
            inspected = set(packet["result"]["inspected_page_ids"])
            for item in [*trace["evidence_inventory"], *trace["paths"], *trace["steps"]]:
                for citation in item.get("source_refs", []):
                    page_id = citation["canonical_page_id"]
                    pi = context.corpus.page_index[page_id]
                    replayed = policy.citation(pi, citation["start"], citation["end"])
                    if page_id not in inspected or replayed["text"] != citation["text"]:
                        raise ValueError("Selected citation is not inspected evidence")
                    page = policy.bound_pages[page_id]
                    sources[page_id] = {k: page.get(k) for k in PAGE_FIELDS}
            document_pages = document_inventory(policy, sources)
            cache_value = dict(native=packet, condition=condition, trace=trace, sources=sources,
                               document_pages=document_pages)
            write_json(cache, dict(sha256=sha(cache_value), value=cache_value))

        emit("saving")
        used_refs = set(reserved_refs)
        def collect_refs(value):
            if isinstance(value, dict):
                for item in value.values():
                    collect_refs(item)
            elif isinstance(value, (list, tuple)):
                for item in value:
                    collect_refs(item)
            elif isinstance(value, str) and re.fullmatch(r"receipts/[a-f0-9]{32}\.json", value):
                used_refs.add(value)
        collect_refs(saved)
        collect_refs(readings_audit)
        provider_receipts = []
        for relative in sorted(used_refs):
            path = API_ROOT / relative
            record = read_json(path)
            provider_receipts.append({k: record.get(k) for k in (
                "request_sha256", "status", "model", "usage", "charged_or_reserved_usd")})
            provider_receipts[-1].update(ref=relative, new_in_this_attempt=path.name not in initial_receipts)
        final_total = ledger_total()
        envelope = dict(version="matryoshka-live-result/1", run_id=run_id,
                        execution_kind="live", request=request, native=packet, condition=condition,
                        source_scope=scope_for(request), trace=trace,
                        selected_evidence=trace["evidence_inventory"], sources=sources,
                        document_pages=document_pages, origins=None,
                        receipt=dict(model=MODEL, query_only_planning=True,
                                     model_readings_only_redaction=True, deterministic_execution=True,
                                     execution_cache_hit=cached, exact_provider_cache_retained=True,
                                     provider_calls=sum(r["new_in_this_attempt"] for r in provider_receipts),
                                     provider_receipts=provider_receipts,
                                     charged_or_reserved_usd=sum(r["charged_or_reserved_usd"] for r in provider_receipts if r["new_in_this_attempt"]),
                                     ledger_before_usd=initial_total, ledger_after_usd=final_total,
                                     shared_ledger_delta_may_include_other_workers=True,
                                     cumulative_cap_usd=50, live_absolute_cap_usd=payload["absolute_cap_usd"],
                                     job_budget_usd=payload["job_spend_usd"], wall_seconds=time.monotonic() - started,
                                     api_root="experiments/narrative_demo/api", configuration=LIMITS,
                                     no_answer_or_grade_inputs=True, no_chain_of_thought=True), artifacts={})
        seal(directory, envelope)


def seal(directory, envelope):
    refs = {}
    for filename, value in (("native.json", envelope["native"]), ("condition.json", envelope["condition"]),
                            ("trace.json", envelope["trace"]), ("sources.json", envelope["sources"]),
                            ("document-pages.json", envelope["document_pages"]),
                            ("selected-evidence.json", envelope["selected_evidence"]), ("receipt.json", envelope["receipt"])):
        write_json(directory / filename, value)
        refs[filename] = dict(path="jobs/" + directory.name + "/" + filename,
                              sha256=hashlib.sha256(encoded(value)).hexdigest())
    envelope["artifacts"] = refs
    write_json(directory / "result.json", envelope)


if __name__ == "__main__":
    os.umask(0o077)
    directory = Path(sys.argv[1]).resolve()
    try:
        run(directory)
    except BaseException as error:
        # Error types/messages can contain URLs, bearer headers or provider text.
        # Only fixed public codes cross the process boundary.
        code = "SOURCE_OR_RUNTIME_VALIDATION_FAILED"
        if isinstance(error, Reject):
            code = error.code if error.code == "DISK_FLOOR_3_GIB" else "QUERY_VALIDATION_FAILED"
        elif isinstance(error, RuntimeError) and "budget" in str(error).lower():
            code = "BUDGET_LIMIT"
        try:
            write_json(directory / "failure.json", dict(code=code))
        except BaseException:
            pass
        sys.exit(1)
