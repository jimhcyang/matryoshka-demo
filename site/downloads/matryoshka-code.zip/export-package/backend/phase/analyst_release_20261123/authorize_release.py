"""Authorize only the exact release that passed its fresh bounded QA gates."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
SITE=HERE/'stage/site'


def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def pinned(reference):
    relative=Path(reference['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise ValueError('Unsafe review reference')
    # Native receipts are relative to src-demo-day; external reviews explicitly
    # include that directory in their workspace-relative reference.
    root=HERE.parents[2] if relative.parts[0] in {'src-demo-day','matryoshka_demo_site'} else HERE.parents[1]
    path=root/relative
    assert path.resolve()==path and sha(path)==reference['sha256']
    return read(path)


def main(browser_path=None,output_directory=None):
    browser_path=(browser_path or HERE/'qa/browser/receipt.json').resolve()
    if not browser_path.is_relative_to(HERE):
        raise ValueError('Browser receipt must belong to this release')
    prepared=read(HERE/'prepared.json')
    manifest=read(SITE/'release-manifest.json')
    pin=sha(SITE/'release-manifest.json')
    assert pin==prepared['manifest_sha256']
    integrity=read(HERE/'qa/integrity.json')
    browser=read(browser_path)
    native=pinned(read(HERE/'native_audit_ref.json'))
    privacy_ref=read(HERE/'privacy_review_ref.json')
    privacy=pinned(privacy_ref)
    feature_ref=read(HERE/'feature_review_ref.json')
    features=pinned(feature_ref)
    assert integrity['status']=='PASS' and integrity['manifest_sha256']==pin
    assert integrity['all_logical_roots_reconstructed'] and len(integrity['native'])==16
    assert browser['candidate_manifest_sha256']==pin and browser['success'] and browser['full_release_matrix']
    assert all(cell['pass'] for cell in browser['cells']) and len(browser['cells'])>=25
    assert not browser['external_requests'] and not browser['leaked_api_requests'] and browser['model_api_calls']==0
    assert native['status']=='PASS' and len(native['cases'])==16
    assert native['report_ref']==manifest['source_report_ref']
    assert privacy['manifest_sha256']==pin and privacy['final_attestation'] and not privacy['blockers']
    assert not privacy['source_errors'] and not privacy['unmatched_privacy_findings'] and not privacy['broad_exclusions_used']
    assert features['status']=='PASS' and features['candidate_manifest_sha256']==pin
    directory=(output_directory or HERE/'release-approval').resolve()
    if not directory.is_relative_to(HERE):
        raise ValueError('Authorization artifacts must remain within this release')
    directory.mkdir(exist_ok=True)
    def write(name,value):
        target=directory/name
        raw=(json.dumps(value,indent=2,ensure_ascii=True)+'\n').encode()
        assert shutil.disk_usage(HERE).free-len(raw)>3*1024**3
        if target.exists():assert target.read_bytes()==raw
        else:target.write_bytes(raw)
        return dict(path=name,sha256=sha(target))
    qa=write('data-qa-analyst-2026-11-23.json',dict(version='analyst-native-release-data-qa/1',date='2026-11-23',
        candidate_manifest_sha256=pin,source_report_sha256=manifest['source_report_ref']['sha256'],
        status='PASS_DIAGNOSTIC_PRESENTATION_DATA',native_ref=read(HERE/'native_audit_ref.json'),
        browser_sha256=sha(browser_path),integrity_sha256=sha(HERE/'qa/integrity.json'),
        feature_ref=feature_ref,native_packets=16,historical_packets_modified=False,
        terminal_stage_reuse_explicit=True,delegation_reference_unknown=True,
        delegation_advisory_swedish_recovered=False,scientific_case_qualification=False))
    rights=write('privacy-and-rights-analyst-2026-11-23.json',dict(version='analyst-release-privacy-notices/1',
        date='2026-11-23',candidate_manifest_sha256=pin,status='PASS_SCOPED_INDICATOR_AND_SOURCE_REVIEW',
        independent_review_ref=privacy_ref,scan_counts=privacy['scan_counts'],
        unresolved_indicator_findings=[],broad_exclusions_used=False,
        private_credentials_state_provider_keys_or_attempts_published=False,
        rights_scope='Public historical-source notices and exact source-PDF continuity; authored code and selected source-grounded outputs. Not legal certification or declassification.'))
    approval=write('authorization-analyst-2026-11-23.json',dict(version='source-bound-release-authorization/1',
        date='2026-11-23',candidate_manifest_sha256=pin,source_report_sha256=manifest['source_report_ref']['sha256'],
        backend_code_sha256=manifest['backend_snapshot']['tree_sha256'],publish_authorized=True,
        new_data_qa_accepted=True,privacy_review_accepted=True,licensing_review_accepted=True,
        scope='diagnostic_demo_with_declared_limitations',qualified_data_qa_ref=qa,privacy_and_rights_ref=rights,
        new_scientific_performance_claimed=False))
    write('approval_ref.json',approval)
    print('AUTHORIZED_EXACT_DIAGNOSTIC_RELEASE',pin)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--browser-receipt',type=Path)
    parser.add_argument('--output-directory',type=Path)
    args=parser.parse_args()
    main(args.browser_receipt,args.output_directory)
