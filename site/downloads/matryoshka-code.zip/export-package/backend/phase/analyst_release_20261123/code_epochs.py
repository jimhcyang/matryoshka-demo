"""Require one explicit frozen source-code epoch for all selected executions."""
from copy import deepcopy

from integrate import HERE, pinned, read


def active_epoch():
    pointer = HERE / "backend/ACTIVE_CODE_EPOCH.json"
    if pointer.exists():
        return pinned(read(pointer))
    return read(HERE / "backend/BACKEND_FROZEN_FINAL.json")


def current_epoch(pins):
    epoch = active_epoch()
    if epoch["code_pins"] != pins:
        raise ValueError("Current engine differs from the explicitly frozen epoch")
    return epoch


def native_epoch(reference, packet, pins):
    current_epoch(pins)
    if packet["code_pins"] != pins:
        raise ValueError("Selected native execution belongs to another code epoch")
    return dict(kind="CURRENT_FROZEN_CODE", native_ref=reference, code_pins=deepcopy(pins))
