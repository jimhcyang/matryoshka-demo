"""Replay selected seals, policies, arithmetic and selected source spans offline."""
from copy import deepcopy
import sys

from integrate import HERE, ROOT, pinned, read, ref, write
from code_epochs import current_epoch, native_epoch
sys.path.insert(0,str(ROOT))
from matryoshka_demo.io import digest, offline
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, descriptor
from matryoshka_narrative import workflow
from matryoshka_narrative.postrun_digest import prepare
from matryoshka_narrative.terminal_scores import annotate_result, candidate_score


def main():
    binding=read(HERE/'publication_refs.json')
    report=pinned(binding['report_ref'])
    records=[]
    with offline():
        current_pins = workflow.code_pins()
        current_epoch(current_pins)
        for corpus in ('cib','iran','vietnam'):
            with workflow.Session() as session:
                for row in [r for r in report['cases'] if r['case']['corpus']==corpus]:
                    cfg=row['configurations']['llm_readings']
                    native=pinned(cfg['native_checkpoint'])
                    condition=pinned(cfg['condition_ref'])['configurations']['llm_readings']
                    assert native['native_checksum']==digest(native['result'])
                    assert native['public_case']==row['case']
                    assert native['configuration']['source_view_policy']==descriptor(SOURCE_DAY_INCLUSIVE)
                    epoch_authority = native_epoch(cfg['native_checkpoint'], native, current_pins)
                    assert native['query_only_inference'] and not native['answers_read'] and not native['grades_read']
                    assert native['retrieval'].get('whole_query_search_executed') is not True
                    result=native['result']
                    rescored=annotate_result(result,native['retrieval'],rerank=False,plan=native['plan'])
                    expected=deepcopy(result['terminal_scores']);expected['ranking_applied']=False
                    assert rescored['terminal_scores']==expected
                    for branch in result.get('readings',[]):
                        for candidate in branch['candidates']:
                            assert candidate['terminal_scorecard']==candidate_score(candidate,native['retrieval'],plan=native['plan'])
                        values=[c['terminal_scorecard']['score'] for c in branch['candidates']]
                        assert values==sorted(values,reverse=True)
                        surfaces=[(' '.join(c['fill'].casefold().split()),c['local_decision'].get('scope')) for c in branch['candidates']]
                        assert len(set(surfaces))==len(surfaces)
                    payload=prepare(native,condition,session.context(corpus))
                    for trace_ref in cfg['trace_refs'].values():
                        trace=pinned(trace_ref)
                        seal=deepcopy(trace);actual=seal.pop('sha256')
                        assert digest(seal)==actual
                        assert trace['query_sha256']==digest(row['case']['query'])
                        assert trace['native_checkpoint']==cfg['native_checkpoint']
                    records.append(dict(case_id=row['case']['case_id'],corpus=corpus,task=row['case']['task'],
                        native_ref=cfg['native_checkpoint'],native_status=result['status'],
                        code_epoch_authority=epoch_authority,
                        verified_selected_quotations=len(payload['sources']),
                        source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE),
                        score_version=result['terminal_scores']['version'],rank_descending=True,
                        unknown_reference=bool(row.get('study_slot'))))
                    print('SELECTED_AUDIT_PASS',row['case']['case_id'],len(payload['sources']),flush=True)
    receipt=dict(version='analyst-selected-native-audit/1',status='PASS',report_ref=binding['report_ref'],
                 cases=records,paid_calls=0,confidence_or_research_accuracy_claimed=False)
    path=HERE/'qa'/('native-'+digest(receipt)[:24]+'.json')
    write(path,receipt)
    from matryoshka_next.workflow import put
    put(HERE/'native_audit_ref.json',ref(path))
    print('NATIVE_AUDIT_COMPLETE',len(records))


if __name__=='__main__':main()
