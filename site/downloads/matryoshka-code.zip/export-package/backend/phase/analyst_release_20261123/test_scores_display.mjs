import assert from 'node:assert/strict';
import {computeDecisionScores,formatDecisionScore,SCORE_VERSION} from './stage/site/decision-scores.js';

function fixture(){
  const candidates=['a','b'].map(id=>({id,local_decision:{status:'exploratory_contextual'}}));
  return {result:{readings:[{reading:{id:'r'},candidates}],atoms:[],terminal_scores:{
    version:SCORE_VERSION,probability:false,ranking_applied:true,judgments_unchanged:true,
    readings:[{id:'r',candidates:candidates.map((c,i)=>({id:c.id,native_status:c.local_decision.status,
      score:2-i,support:0,oppose:0,context:.5,fit:.5,criteria_coverage:0}))}],atoms:[],overall:{}}}};
}
assert.ok(computeDecisionScores(fixture()));
for(const mutate of [
  x=>x.result.terminal_scores.readings[0].candidates.reverse(),
  x=>x.result.terminal_scores.readings[0].id='other',
  x=>x.result.terminal_scores.readings.push(x.result.terminal_scores.readings[0]),
  x=>x.result.terminal_scores.readings[0].candidates.pop(),
  x=>x.result.terminal_scores.atoms.push({id:'injected'}),
  x=>x.result.terminal_scores.judgments_unchanged=false]){
  const value=fixture();mutate(value);assert.throws(()=>computeDecisionScores(value));
}
for(const value of [.001,.0049,.00001,-.001])assert.notEqual(Number(formatDecisionScore(value)),0);
assert.equal(formatDecisionScore(0),'0.00');
assert.equal(formatDecisionScore(1.123456),'1.12');
console.log(JSON.stringify({checks:13,passed:13,paid_calls:0}));
