"""Readable inventory of the selected native results; never a new verdict."""
import json

from integrate import HERE, pinned, read, ref, current_reference


def main():
    binding=read(HERE/'publication_refs.json')
    report=pinned(binding['report_ref'])
    rows=[]
    lines=['# Local Release Results','',
        'These are source-aware demonstration selections, not benchmark accuracy.',
        'Native decisions are reported unchanged. A numerical relevance score is not a correctness probability.',
        '',f"Report: `{binding['report_ref']['path']}`",'']
    for row in report['cases']:
        case=row['case']
        native=pinned(row['configurations']['llm_readings']['native_checkpoint'])
        result=native['result']
        item=dict(case=case,native_status=result['status'],native_checkpoint=row['configurations']['llm_readings']['native_checkpoint'],
            terminal_stage_replay=bool(native.get('terminal_stage_replay')),
            reference_unknown=bool(row.get('study_slot')),
            readings=[],atoms=[])
        lines.extend([f"## {case['corpus'].upper()} / {case['task'].title()}",'',case['query'],'',
            f"Origin: `{case['document_id']}` / {case['date']}",
            f"Native result: **{result['status']}**",''])
        if item['reference_unknown']:
            lines.extend(['The historical fill remains unknown; this is not a verified recovery.',''])
        for reading in result.get('readings',[]):
            values=[]
            for candidate in reading['candidates']:
                decision=candidate.get('local_decision',{})
                values.append(dict(rank=candidate['rank'],fill=candidate['fill'],status=decision.get('status'),
                    score=candidate.get('terminal_scorecard',{}).get('score')))
            item['readings'].append(dict(id=reading['reading']['id'],candidates=values))
            lines.append(f"Reading `{reading['reading']['id']}`:")
            lines.extend(f"- {c['rank']}. {c['fill']} ({c['status']})" for c in values)
            lines.append('')
        for atom in result.get('atoms',[]):
            item['atoms'].append(dict(id=atom['id'],text=atom['text'],status=atom['status']))
            lines.append(f"- {atom['id']}: {atom['text']} ({atom['status']})")
        lines.extend(['',f"Native receipt: `{item['native_checkpoint']['path']}`",''])
        rows.append(item)
    current_reference(HERE/'RESULTS.json',dict(report_ref=binding['report_ref'],cases=rows,
        judgments_modified=False,benchmark_accuracy_claimed=False))
    (HERE/'RESULTS.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(cases=len(rows),results_ref=ref(HERE/'RESULTS.json'))))


if __name__=='__main__':main()
