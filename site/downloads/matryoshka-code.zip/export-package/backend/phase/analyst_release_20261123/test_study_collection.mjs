import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {validateAdditionalCollection} from './stage/site/narrative-collections-v1.js';
const report=JSON.parse(readFileSync(new URL('./stage/site/data/report-v6.json',import.meta.url)));
const manifest={additional_real_redaction:report.cases.filter(r=>r.collection==='additional_real_redaction').map(r=>r.case.case_id)};
validateAdditionalCollection(manifest,report);
for(const mutate of [
  r=>r.study_slot='other',r=>r.reference_answer='invented',r=>r.reference_answer_kind='known',
  r=>r.selected_demo=true,r=>r.case.corpus='iran',r=>r.case.task='hypothesis',
  r=>r.study_companion_case_id='other',r=>r.case.date='1900-01-01',r=>r.collection='arbitrary']){
  const copy=structuredClone(report),row=copy.cases.find(r=>r.collection==='withheld_delegation');
  mutate(row);assert.throws(()=>validateAdditionalCollection(manifest,copy));
}
const old=structuredClone(report);old.cases=old.cases.filter(r=>r.collection!=='withheld_delegation');
validateAdditionalCollection(manifest,old);
console.log(JSON.stringify({checks:11,passed:11}));
