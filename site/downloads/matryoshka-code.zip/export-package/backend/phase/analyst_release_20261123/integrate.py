"""Build a new publication from actual sealed executions, never relabel history."""
import argparse
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
REPO = ROOT.parent / 'matryoshka_demo_site'
SITE = HERE / 'stage/site'
DEPLOY = ROOT / 'phase/release_finish_20261121/deploy'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(DEPLOY))
from matryoshka_demo.io import digest
from matryoshka_next.workflow import read, put_immutable, put
from matryoshka_narrative import presentation


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def ref(path):
    return dict(path=str(path.relative_to(ROOT)), sha256=sha(path.read_bytes()))


def pinned(reference):
    path = ROOT / reference['path']
    if ref(path) != reference:
        raise ValueError('Immutable reference changed: '+reference['path'])
    return read(path)


def write(path, value):
    return put_immutable(path, value)


def current_reference(path, value):
    if path.exists():
        prior=path.read_bytes()
        archive=HERE/'reference-history'/sha(prior)/path.name
        archive.parent.mkdir(parents=True,exist_ok=True)
        if archive.exists() and archive.read_bytes()!=prior:raise ValueError('Reference history collision')
        archive.write_bytes(prior)
    return put(path,value)


def amend_report():
    """Install explicitly selected new cases without changing any native output."""
    bindings=read(HERE/'publication_refs.json')
    report=deepcopy(pinned(bindings['report_ref']))
    book=deepcopy(pinned(bindings['casebook_ref']))
    proposals=read(HERE/'selected_case_revisions.json')['replacements']
    old_ids={r['case']['case_id']:r for r in report['cases']}
    revisions={}
    for proposal in proposals:
        if proposal['replaces'] in revisions:
            raise ValueError('A source case can only be replaced once')
        old=old_ids[proposal['replaces']]
        fresh=pinned(proposal['entry_ref']) if 'entry_ref' in proposal else proposal['entry']
        case=fresh['case']
        if (case['corpus'],case['task'])!=(old['case']['corpus'],old['case']['task']):
            raise ValueError('A replacement must retain its corpus/task role')
        if 'masked' not in fresh.get('origin_refs',{}):raise ValueError('Exact query origin is required')
        for reference in fresh['origin_refs'].values():pinned(reference)
        # A new execution of the same input keeps its source-display metadata;
        # a different input inherits only the corpus/task presentation slot.
        row=(deepcopy(old) if case['case_id']==old['case']['case_id'] else
             {k:deepcopy(old[k]) for k in ('narrative_id','collection','selected_demo',
                 'selected_bench','selected_additional') if k in old})
        for key in ('case','origin_refs','presentation_title','query_kind','reference_answer_kind',
                    'source_target_id','family_id','source_origin','source_query_spans',
                    'plan_rebind_ref','exact_saved_plan_replication','parent_native_ref',
                    'frozen_backend','runner_contract_ref','new_full_native_execution'):
            if key in fresh:row[key]=deepcopy(fresh[key])
        row.setdefault('presentation_title',case['query'])
        row.setdefault('query_kind','source_derived_proposition' if case['task']!='redaction' else 'synthetic_source_span')
        row['presentation_caveats']=deepcopy(fresh.get('presentation_caveats',
            old.get('presentation_caveats',[]) if case['case_id']==old['case']['case_id'] else []))
        attach(row,fresh['outputs'])
        native=pinned(fresh['outputs']['native_checkpoint'])
        if native['answers_read'] or native['grades_read'] or native['configuration']['source_view_policy']['id']!='source_day_inclusive':
            raise ValueError('New cases must retain the declared source-only boundary')
        revisions[old['case']['case_id']]=(row,fresh)
    report['cases']=[revisions.get(r['case']['case_id'],(r,None))[0] for r in report['cases']]
    if len({r['case']['case_id'] for r in report['cases']})!=16:raise ValueError('Case inventory must remain 16 distinct cases')
    groups={}
    for row in report['cases']:groups.setdefault(row['narrative_id'],[]).append(row['case']['case_id'])
    report['privacy_contract']['story_case_ids']=groups
    for story in report.get('investigations',[]):
        story.update(qualified_case_count=0,trio_qualified=False,status='SOURCE_BOUND_DEMONSTRATION_NOT_BENCHMARK')
    report['selection_rule']='Source-bound outcome-informed narrative curation; superseded cases and all native outputs retained.'
    report['run_id']='analyst_resume_'+digest(dict(cases=report['cases'],amendment=ref(HERE/'selected_case_revisions.json')))[:24]
    report.pop('sha256',None);report['sha256']=digest(report)
    directory=HERE/'publication'/report['run_id'];write(directory/'report.json',report)
    report_ref=ref(directory/'report.json')
    for field in ('primary','special_redactions'):
        for i,entry in enumerate(book[field]):
            identity=entry['case_id']
            if identity in revisions:
                row,fresh=revisions[identity]
                book[field][i]={k:deepcopy(row[k]) for k in ('case','resource_binding','narrative_id','configurations','decision_summary_by_arm')}
                book[field][i].update(case_id=row['case']['case_id'],corpus=row['case']['corpus'],task=row['case']['task'],title=row['presentation_title'])
            else:
                row=old_ids[identity]
                entry.update(configurations=deepcopy(row['configurations']),decision_summary_by_arm=deepcopy(row['decision_summary_by_arm']))
    for corpus,backgrounds in book.get('backgrounds',{}).items():
        summaries=[fresh.get('narrative_summary') for row,fresh in revisions.values() if row['case']['corpus']==corpus and fresh.get('narrative_summary')]
        summary_sources=[fresh.get('narrative_summary_sources') for row,fresh in revisions.values()
                         if row['case']['corpus']==corpus and fresh.get('narrative_summary_sources')]
        for background in backgrounds:
            if background.get('case_id') in revisions:background['case_id']=revisions[background['case_id']][0]['case']['case_id']
            if summaries:
                if not summary_sources:raise ValueError('New narrative background has no source references')
                background['historical_setup']=summaries[0]
                background['background_sources']=deepcopy(summary_sources[0])
    book.update(source_report_ref=report_ref,source_report_run=report['run_id'],source_report_sha256=report_ref['sha256'],
        requested_primary_slots=[dict(execution_state='COMPLETED',public_case=deepcopy(e['case'])) for e in book['primary']])
    write(directory/'casebook.json',book)
    bindings.update(report_ref=report_ref,casebook_ref=ref(directory/'casebook.json'),
        amendment_ref=ref(HERE/'selected_case_revisions.json'),prior_active_report_ref=bindings['report_ref'],
        replacement_cases=len(revisions),
        export_map_index_sha256=sha((REPO/'site/data/api-index.json').read_bytes()),
        export_map_release_manifest_sha256=sha((REPO/'site/release-manifest.json').read_bytes()))
    # Original experiment metadata cannot describe the replacement planners.
    bindings.pop('ordinary_new_planning_calls',None)
    current_reference(HERE/'publication_refs.json',bindings)
    print('AMENDED',report['run_id'],len(revisions),flush=True)


def prepare_report():
    baseline = read(REPO / 'site/data/report-v6.json')
    inputs = read(HERE / 'native_release_inputs.json')
    if set(inputs) != {'ordinary_ref','selected_ref'}:
        raise ValueError('Explicit pinned ordinary and delegation executions are required')
    results = pinned(inputs['ordinary_ref'])
    if results['status'] != 'COMPLETE' or results['completed'] != 14:
        raise ValueError('All fourteen new native executions are required')
    updates = {r['case']['case_id']:r for r in results['cases']}
    report = deepcopy(baseline)
    rows = []
    from matryoshka_narrative.sidebar import summarize
    for old in report['cases']:
        fresh = updates[old['case']['case_id']]
        if fresh['case'] != old['case']:
            raise ValueError('The regression changed a question')
        row = deepcopy(old)
        attach(row, fresh['outputs'])
        row['exact_saved_plan_replication'] = fresh['exact_saved_plan_replication']
        if fresh.get('plan_rebind_ref'):
            row['plan_rebind_ref'] = deepcopy(fresh['plan_rebind_ref'])
        rows.append(row)
    selected = pinned(inputs['selected_ref'])
    study = selected['cases'] if isinstance(selected, dict) else selected
    if len(study) != 2 or {r['study_slot'] for r in study} != {'first','last'}:
        raise ValueError('Two independently executed delegation slots are required')
    for item in study:
        row = dict(case=deepcopy(item['case']), current_resource_execution=True,
            narrative_id='cib_withheld_delegation', collection='withheld_delegation',
            selected_demo=False, selected_bench=False, selected_additional=False,
            presentation_title='Visiting delegation', query_kind='authentic_still_withheld',
            reference_answer_kind='unknown_still_withheld', presentation_caveats=[],
            study_slot=item['study_slot'], origin_refs=deepcopy(item['origin_refs']))
        row['study_companion_case_id'] = next(r['case']['case_id'] for r in study if r['study_slot'] != item['study_slot'])
        attach(row, item['outputs'])
        rows.append(row)
    report['cases'] = rows
    run = 'analyst_release_' + digest([r['configurations'] for r in rows])[:24]
    report.update(run_id=run, status='SAVED_NATIVE_EXPERIMENTS', completed_cases=len(rows), pending_cases=[],
        qualified_narratives=[], qualified_release_ready=False, showcase_ready=False,
        release_scope='Nine primary cases, five additional real redactions, two unknown-delegation inputs',
        release_profile='SOURCE_DAY_INCLUSIVE_ATOMIC_RETRIEVAL_TERMINAL_EVIDENCE_FIT',
        quality_blockers=[], collection_wide_pending_gates=[], collection_wide_requirements_pending=[],
        full_benchmark_launched=False, benchmark_accuracy=None, outcome_informed_demo=True,
        selection_rule='Original fourteen questions retained; delegation paragraph selection is an explicitly exploratory context experiment.',
        native_outputs_modified=False, no_live_api=True, local_execution_after_planning=True,
        complete_execution_grid=True)
    report['collection_counts'] = dict(primary=9,additional_real_redaction=5,withheld_delegation=2)
    contract = report.get('privacy_contract')
    if contract:
        contract['story_case_ids']['cib_withheld_delegation'] = [r['case']['case_id'] for r in rows if r.get('study_slot')]
    report.pop('sha256',None)
    report['sha256'] = digest(report)
    directory = HERE / 'publication' / run
    write(directory / 'report.json', report)
    report_ref = ref(directory / 'report.json')
    old_lineage = read(REPO / 'site/export-lineage.json')
    book = deepcopy(pinned(old_lineage['casebook_ref']))
    book.update(source_report_sha256=report_ref['sha256'], source_report_run=run)
    # Casebook membership and historical origin proofs are unchanged.
    for field in ('primary','special_redactions'):
        for entry in book[field]:
            row = next(r for r in rows if r['case']['case_id'] == entry['case_id'])
            if 'case' in entry: entry['case'] = deepcopy(row['case'])
            if 'resource_binding' in entry: entry['resource_binding'] = deepcopy(row['resource_binding'])
    write(directory / 'casebook.json', book)
    bindings = dict(report_ref=report_ref,casebook_ref=ref(directory/'casebook.json'),
        prior_report_ref=old_lineage['source_report_ref'],prior_index_sha256=sha((REPO/'site/data/api-index.json').read_bytes()),
        native_executions=16, terminal_stage_replay=True, ordinary_new_planning_calls=0,
        original_saved_packets_modified=False, selected_native_inputs=deepcopy(inputs))
    write(HERE / 'publication_refs.json', bindings)
    print(json.dumps(bindings), flush=True)


def attach(row, outputs):
    from matryoshka_narrative.sidebar import summarize
    native = pinned(outputs['native_checkpoint'])
    condition = pinned(outputs['condition_ref'])
    record = condition['configurations']['llm_readings']
    if native['public_case'] != row['case'] or native['native_checksum'] != digest(native['result']):
        raise ValueError('Native identity or result checksum changed')
    item = {k:deepcopy(v) for k,v in outputs.items() if k in {
        'condition_ref','trace_refs','config','native_checkpoint','run_id'}}
    item.update(flow_refs={},compact_flow_refs={},source_view_policy=deepcopy(native['configuration']['source_view_policy']))
    row.update(configurations={'llm_readings':item}, resource_binding=deepcopy(record['resource_binding']),
        current_resource_execution=True,
        native_public_case_binding=presentation._native_public_case_binding(row['case'],native,outputs['native_checkpoint']),
        reporting_profile=dict(version='analyst-native-display/1',native_version=native['version'],
            native_configuration=deepcopy(native['configuration']),graph_inspection_is_postrun=True,
            native_code_epoch_sha256=digest(native['code_pins']),original_native_unchanged=True),
        decision_summary_by_arm={'llm_readings':summarize(ROOT,[(row['case'],record)])[0]})
    row.pop('showcase_review',None)


def digests(case_ids=None):
    from dotenv import load_dotenv
    load_dotenv(ROOT.parent/'.env')
    load_dotenv(ROOT.parent/'src-redaction/.env')
    from matryoshka_narrative.workflow import Session
    from matryoshka_narrative.postrun_digest import generate, prepare
    bindings = read(HERE/'publication_refs.json')
    report = pinned(bindings['report_ref'])
    selected = set(case_ids or [])
    known = {row['case']['case_id'] for row in report['cases']}
    if selected - known:
        raise ValueError('Unknown digest case selection')
    entries = {}
    if selected:
        previous = read(HERE/'digest_refs.json')
        if previous['report_ref'] != bindings['report_ref'] or set(previous['entries']) != known:
            raise ValueError('A single-summary revision requires a complete matching prior set')
        entries = deepcopy(previous['entries'])
    for corpus in ('cib','iran','vietnam'):
        with Session() as session:
            for row in [r for r in report['cases'] if r['case']['corpus']==corpus]:
                if selected and row['case']['case_id'] not in selected:
                    continue
                item = row['configurations']['llm_readings']
                native = pinned(item['native_checkpoint'])
                condition = pinned(item['condition_ref'])['configurations']['llm_readings']
                context = session.context(corpus)
                input_sha=digest(prepare(native,condition,context))
                path = HERE/'digests'/input_sha/(row['case']['case_id']+'.json')
                if path.exists():
                    value = read(path)
                    if value['input_sha256'] != input_sha:
                        raise ValueError('A saved digest belongs to another local result')
                else:
                    value = generate(native,condition,context,ROOT/'experiments/narrative_demo/api')
                    write(path,value)
                entries[row['case']['case_id']] = ref(path)
                print('DIGEST_READY',row['case']['case_id'],len(value['text'].split()),flush=True)
    current_reference(HERE/'digest_refs.json',dict(report_ref=bindings['report_ref'],entries=entries,
        used_for_inference=False,local_outputs_changed=False))


class Stage:
    """A bounded writer over our cloned stage, not a second corpus export."""
    def __init__(self):
        self.output = SITE.parent
        self.limits = dict(max_bytes=900_000_000,max_seconds=3600,max_requests=100_000,
            max_sources=10_000,max_nodes=50_000,max_packet_bytes=210_000_000)
        self.started,self.bytes,self.files,self.resuming = time.monotonic(),0,{},False
    def guard(self,extra=0):
        if (self.bytes+extra > self.limits['max_bytes'] or time.monotonic()-self.started > self.limits['max_seconds']
                or shutil.disk_usage(HERE).free-extra < 3*1024**3):
            raise RuntimeError('Bounded export resource limit; prior publication unchanged')
    def write(self,relative,raw):
        path = self.output/relative
        if not relative.startswith('site/data/') or path.resolve()!=path or len(raw)>=100_000_000:
            raise ValueError('Unsafe finite replay target')
        if path.exists():
            if path.read_bytes()!=raw:raise ValueError('Content-addressed replay collision')
            return
        self.guard(len(raw))
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(raw)
        self.bytes+=len(raw)
        self.files[relative]=dict(path=relative,sha256=sha(raw),bytes=len(raw))


def export():
    import export_narrative as transport
    from matryoshka_narrative.server import Viewer
    from matryoshka_current.map_transport import SavedMaps
    from matryoshka_current.local_pdfs import LocalPDFs
    bindings = read(HERE/'publication_refs.json')
    report = pinned(bindings['report_ref'])
    digest_refs = read(HERE/'digest_refs.json')
    if digest_refs['report_ref'] != bindings['report_ref']:raise ValueError('Digest report mismatch')
    inputs = transport.Inputs()
    convention = transport.module('analyst_export_privacy', DEPLOY/'vendor/tools/export_current_replays.py')
    pdfs = LocalPDFs(ROOT.parent,ROOT,report['pdf_catalog_ref'])
    map_index_sha=bindings.get('export_map_index_sha256',bindings['prior_index_sha256'])
    map_manifest_sha=bindings.get('export_map_release_manifest_sha256')
    if map_manifest_sha and sha((REPO/'site/release-manifest.json').read_bytes())!=map_manifest_sha:
        raise ValueError('Installed map release changed after publication selection')
    maps = SavedMaps(REPO,map_index_sha,pdfs=pdfs)
    viewer = Viewer(ROOT,bindings['report_ref'],maps,casebook_ref=bindings['casebook_ref'])
    class Reader(transport.SavedReader):
        def api(self,name,params):
            if name=='analyst-digest':
                row,arm,item,condition,native=self.select({k:[str(v)] for k,v in params.items()})
                value=pinned(digest_refs['entries'][row['case']['case_id']])
                if value['native_checksum']!=native['native_checksum']:raise ValueError('Digest native mismatch')
                return value
            if name=='origin-v63' and params.get('reveal_focal')=='1':
                row,_,_,_,_=self.select({k:[str(v)] for k,v in params.items()})
                if row.get('reference_answer_kind')=='unknown_still_withheld':
                    return super().api(name,dict(params,reveal_focal='0'))
            return super().api(name,params)
    class Exporter(transport.Exporter):
        def _guide(self,selection,path,source_ids):
            guide=self.get('guide-v6',selection)
            source_ids.update(transport.citations(guide))
            final=set(transport.citations(path['decision_source_refs']))
            if not final<=set(transport.citations(guide)):raise ValueError('Guide lost final selected quotation')
            if guide.get('route') is None:
                if path['graph_hops']!=0:raise ValueError('A saved graph route lost its actual nodes')
                return
            # The active navigator uses the original full corpus canvas, not
            # eager replicas of every legacy guide phase and 2048-node view.
            for node in guide.get('route',{}).get('nodes',[]):
                if node.get('is_graph_node') is False:continue
                value=self.get('node-v6',dict(**{k:selection[k] for k in ('case_id','config',*transport.PINS)},node_id=node['id']))
                source_ids.update(transport.citations(value))
    stage=Stage()
    reader=Reader(viewer,inputs)
    worker=Exporter(stage,viewer,reader,convention.public_metadata,convention.GUARD.scan_json)
    try:
        for row in report['cases']:
            worker.one_case(row)
            print('EXPORTED',row['case']['case_id'],worker.requests,stage.bytes,flush=True)
        book=viewer.casebook()
        for key,value in [('/api/narrative-v1/manifest',viewer.manifest()),
                          ('/api/health',dict(status='ok',service='narrative-resource-workbench',report_ref=bindings['report_ref'],
                            cases=len(report['cases']),api_calls=0,live_inference=False,execution_kind='saved_narrative',
                            current_native_execution=False,narrative_display_assets='/narrative-assets/',display_modules_only=True))]:
            worker.put(key,value)
        for key in ('/api/current/report-v6','/data/report-v6.json'):
            worker.put(key,None,raw=(ROOT/bindings['report_ref']['path']).read_bytes())
        worker.put('/api/current/casebook',None,raw=(ROOT/bindings['casebook_ref']['path']).read_bytes())
        worker.packet_pack.finish(worker.entries)
        inputs.unchanged()
        if sha((REPO/'site/data/api-index.json').read_bytes())!=map_index_sha:
            raise ValueError('Installed map index changed during export')
        if map_manifest_sha and sha((REPO/'site/release-manifest.json').read_bytes())!=map_manifest_sha:
            raise ValueError('Installed map release changed during export')
        old=read(REPO/'site/data/api-index.json')
        # Remove old active case routes, retaining graph assets, corpus-wide
        # slots and immutable historical transport files on disk.
        from urllib.parse import urlsplit,parse_qs
        active={r['case']['case_id'] for r in report['cases']}
        entries={k:v for k,v in old['entries'].items()
                 if not active.intersection(parse_qs(urlsplit(k).query).get('case_id',[]))}
        entries.update(worker.entries)
        new_index=dict(old,entries=entries)
        put(SITE/'data/api-index.json',new_index)
        (SITE/'data/report-v6.json').write_bytes((ROOT/bindings['report_ref']['path']).read_bytes())
        current_reference(HERE/'export_results.json',dict(report_ref=bindings['report_ref'],casebook_ref=bindings['casebook_ref'],
            api_index_sha256=sha((SITE/'data/api-index.json').read_bytes()),new_routes=len(worker.entries),
            export_map_index_sha256=map_index_sha,export_map_release_manifest_sha256=map_manifest_sha,
            coverage=worker.coverage,new_bytes=stage.bytes,requests=worker.requests,
            prior_native_files_modified=False,graphs_or_aliases_rebuilt=False,
            metadata_projections=worker.metadata_projections))
    finally:
        reader.close_case()
        worker.packet_pack.close()
        viewer.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['report','amend','digests','export'])
    parser.add_argument('--case',action='append',dest='case_ids')
    args=parser.parse_args()
    if args.case_ids and args.action!='digests':
        parser.error('--case only applies to digests')
    if args.action=='digests':
        digests(args.case_ids)
    else:
        {'report':prepare_report,'amend':amend_report,'export':export}[args.action]()
