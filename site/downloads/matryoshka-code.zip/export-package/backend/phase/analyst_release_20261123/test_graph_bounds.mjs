import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {performance} from 'node:perf_hooks';

const require=createRequire(import.meta.url);
const graph=require('./stage/site/graph-kg-v1.js');
const nodes=Array.from({length:128},(_,i)=>({id:`entity_${i}`,type:'Entity',
  community_id:`community_${i%8}`,theme_id:`theme_${i%4}`,domain_id:`domain_${i%2}`}));
const edges=nodes.slice(1).map((node,i)=>({id:`edge_${i}`,source:nodes[i].id,target:node.id,weight:.7}));
for(let i=0;i<1024;i++){
  const id=`slot_${i}`;
  nodes.push({id,type:'RedactionSlot',overlay_slot:true,canonical_page_id:`page_${i}`});
  edges.push({id:`nav_${i}`,source:id,target:`entity_${i%128}`,slot_navigation:true,weight:1000000});
}
const before=JSON.stringify({nodes,edges});
const picked=graph.selectCoverage(nodes,edges,{limit:32});
assert.equal(picked.nodes.length,32);
assert.ok(picked.audit.contextSelected<=4);
assert.ok(picked.audit.semanticReachCount>=32);
assert.deepEqual(picked.audit.selectedIds,graph.selectCoverage([...nodes].reverse(),[...edges].reverse(),{limit:32}).audit.selectedIds);
assert.equal(JSON.stringify({nodes,edges}),before);
const pinned=graph.selectCoverage(nodes,edges,{limit:32,pinned:['slot_999']});
assert.equal(pinned.nodes[0].id,'slot_999');
assert.ok(pinned.audit.contextSelected<=4);

const points=Array.from({length:2048},(_,i)=>({id:`n${i}`,r:1+i%5}));
const start=performance.now();
const packed=graph.packed(points,{gap:2,aspect:1.6}).points;
packed.forEach(p=>Object.assign(p,{homeX:p.x,homeY:p.y}));
const prior=packed.map(p=>({x:p.x,y:p.y}));
graph.relax(packed,{steps:1,passes:2,pull:0,maxStep:4});
for(let i=0;i<packed.length;i++){
  assert.ok(Number.isFinite(packed[i].x)&&Number.isFinite(packed[i].y));
  assert.ok(Math.hypot(packed[i].x-prior[i].x,packed[i].y-prior[i].y)<=8.001);
}
assert.equal(packed.length,2048);
assert.ok(performance.now()-start<5000,'A bounded 2048-node display pass should not stall for seconds');
console.log(JSON.stringify({status:'PASS',selected:picked.nodes.length,slots:picked.audit.contextSelected,
  large_display_nodes:packed.length,layout_ms:Math.round(performance.now()-start),native_data_modified:false}));
