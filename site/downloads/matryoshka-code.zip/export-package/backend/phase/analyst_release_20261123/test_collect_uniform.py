"""Keep publication selection separate from native judgments and source policy."""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import collect_uniform as selection


class SelectionTests(unittest.TestCase):
    def setUp(self):
        self.old = [dict(case=dict(case_id=f"case-{i}", corpus="iran", task="mosaic"))
                    for i in range(16)]
        self.rows = []
        self.objects = {"report": dict(cases=self.old)}
        for old in self.old:
            identity = old["case"]["case_id"]
            native = dict(public_case=deepcopy(old["case"]),
                          configuration=dict(source_view_policy=dict(id="source_day_inclusive")),
                          answers_read=False, grades_read=False,
                          result=dict(status="PARTIAL_RECONSTRUCTION"))
            self.objects[identity] = native
            self.rows.append(dict(case=deepcopy(old["case"]),
                                  outputs=dict(native_checkpoint=dict(path=identity, sha256=identity))))
        self.objects["run"] = dict(status="COMPLETE", completed=16, requested=16, cases=self.rows)
        self.writes = []
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.patches = [
            patch.object(selection, "HERE", Path(self.directory.name)),
            patch.object(selection, "read", side_effect=self.read),
            patch.object(selection, "pinned", side_effect=lambda r: self.objects[r["path"]]),
            patch.object(selection, "code_pins", return_value={"module": "hash"}),
            patch.object(selection, "current_epoch"),
            patch.object(selection, "native_epoch"),
            patch.object(selection, "write", side_effect=lambda p, v: self.writes.append((p, deepcopy(v)))),
            patch.object(selection, "ref", side_effect=lambda p: dict(path=str(p), sha256="written")),
            patch.object(selection, "current_reference", side_effect=lambda p, v: self.writes.append((p, deepcopy(v)))),
        ]
        for item in self.patches:
            item.start()
            self.addCleanup(item.stop)

    def read(self, path):
        if path.name == "publication_refs.json":
            return dict(report_ref=dict(path="report", sha256="report"))
        return dict(replacements=[])

    def run_selection(self, **kwargs):
        return selection.collect([dict(path="run", sha256="run")], **kwargs)

    def test_complete_batch_does_not_rewrite_native_verdicts(self):
        before = deepcopy(self.objects)
        self.run_selection()
        self.assertEqual(self.objects, before)
        self.assertEqual(len(self.writes), 17)
        self.assertEqual(self.writes[-1][1]["decisions_modified"], False)

    def test_incomplete_batch_rejected(self):
        self.objects["run"]["completed"] = 15
        with self.assertRaisesRegex(ValueError, "must complete"):
            self.run_selection()
        self.assertEqual(self.writes, [])

    def test_missing_presentation_slot_rejected(self):
        self.objects["run"]["cases"] = self.rows[:-1]
        with self.assertRaisesRegex(ValueError, "Exactly sixteen"):
            self.run_selection()
        self.assertEqual(self.writes, [])

    def test_duplicate_presentation_slot_rejected(self):
        self.objects["run"]["cases"] = self.rows[:-1] + [self.rows[0]]
        with self.assertRaisesRegex(ValueError, "duplicate"):
            self.run_selection()

    def test_terminal_replay_rejected(self):
        self.objects["case-0"]["terminal_stage_replay"] = True
        with self.assertRaisesRegex(ValueError, "fresh full native"):
            self.run_selection()

    def test_cross_corpus_override_rejected(self):
        override = deepcopy(self.rows[0])
        override["case"]["corpus"] = "cib"
        self.objects["override"] = override
        with self.assertRaisesRegex(ValueError, "Corpus and task"):
            self.run_selection(overrides=[dict(replaces="case-0", entry_ref=dict(path="override"))])

    def test_answer_contamination_and_policy_rejected(self):
        for field in ("answers_read", "grades_read"):
            with self.subTest(field=field):
                self.objects["case-0"][field] = True
                with self.assertRaisesRegex(ValueError, "contamination"):
                    self.run_selection()
                self.objects["case-0"][field] = False
        self.objects["case-0"]["configuration"]["source_view_policy"]["id"] = "later_release"
        with self.assertRaisesRegex(ValueError, "source boundary"):
            self.run_selection()

    def test_new_background_requires_sources(self):
        with self.assertRaisesRegex(ValueError, "source references"):
            self.run_selection(backgrounds=dict(iran=dict(text="An unbound narrative.")))


if __name__ == "__main__":
    unittest.main()
