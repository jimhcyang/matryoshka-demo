import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';

const source=readFileSync(new URL('./stage/site/workbench-v6.js',import.meta.url),'utf8');
const quoteCode=source.slice(source.indexOf('function quoteCard('),source.indexOf('function renderDiffusion('));
const guideCode=source.slice(source.indexOf('function guidePath('),source.indexOf('function selectCandidate('));
const proof={canonical_page_id:'page',page_sha256:'a'.repeat(64),start:0,end:5,text:'Exact',document_id:'doc'};
const path={id:'path_fixture',candidate_or_atom_id:'candidate',query_atom_id:'a1',decision_source_refs:[proof],direction:'SUPPORT'};
const links=[],guides=[],drawers=[];
const context={
  state:{row:{case:{corpus:'cib'}},trace:{paths:[path]}},livePacket:null,
  list:value=>Array.isArray(value)?value:[],readable:value=>value,
  el:(tag,text,attrs={})=>({tag,text,attrs,dataset:{},children:[],append(...rows){this.children.push(...rows);}}),
  button:(label,fn,kind,attrs)=>({label,fn,kind,attrs,children:[],append(...rows){this.children.push(...rows);}}),
  link:(label,url,kind)=>{const result={label,url,kind};links.push(result);return result;},
  fullGraphURL:corpus=>'graph-full-v6.html?corpus='+corpus,
  guidePath:value=>guides.push(value),sourceDrawer:value=>drawers.push(value),
  allowPrivileged:()=>{throw Error('A Live source must not enter saved-guide authorization');},
};
vm.createContext(context);vm.runInContext(quoteCode,context);
const saved=context.quoteCard(proof);
const savedAction=saved.children[0].children.find(row=>row.label==='View on KG');
assert(savedAction);savedAction.fn();assert.equal(guides.length,1);
context.livePacket={run_id:'live-run'};
const live=context.quoteCard(proof);
assert(!live.children[0].children.some(row=>row.label==='View on KG'));
assert.equal(links.at(-1).label,'Open corpus map');
assert.equal(links.at(-1).url,'graph-full-v6.html?corpus=cib');
const inspect=live.children.find(row=>row.kind==='excerpt-text');
inspect.fn();assert.equal(drawers.at(-1),proof);
vm.runInContext(guideCode,context);
context.guidePath({candidate:{id:'candidate'},route:path,proof});
assert.equal(drawers.at(-1),proof);
assert.equal(guides.length,1);
console.log('PASS: saved guides remain bound; Live opens its source or independent corpus map, never an unavailable saved guide.');
