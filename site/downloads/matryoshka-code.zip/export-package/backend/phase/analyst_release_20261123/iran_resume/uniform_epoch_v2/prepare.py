"""Read-only parent preparation; creates no model calls or native executions."""
import argparse
from copy import deepcopy
from pathlib import Path

from protocol import (HERE, PHASE, VERSION, digest, immutable, load_pinned,
    presentation, project_row, read, ref, validate_inputs)


def build(report_ref, revisions_ref=None):
    report = load_pinned(report_ref)
    rows = [project_row(r) for r in report['cases']]
    if len(rows) != 16:
        raise ValueError('Expected sixteen current report rows')
    replacements = []
    if revisions_ref:
        for change in load_pinned(revisions_ref)['replacements']:
            replacement = load_pinned(change['entry_ref'])
            found = [i for i, row in enumerate(rows) if row['case']['case_id'] == change['replaces']]
            if len(found) != 1:
                raise ValueError('Replacement does not identify exactly one report row')
            rows[found[0]] = project_row(replacement)
            replacements.append(deepcopy(change))
    manifest = dict(version=VERSION, status='PROVISIONAL_AWAITING_MAIN_FINAL_SELECTION',
        source_report_ref=report_ref, source_revisions_ref=revisions_ref,
        replacements=replacements, cases=rows, api_calls=0, native_executions=0,
        scientific_case_qualification=False, old_result_labels_not_used=True)
    validate_inputs(manifest)
    parents = []
    for row in rows:
        packet = load_pinned(row['parent_native_ref'])
        if packet['public_case'] != row['case']:
            raise ValueError('Parent public case differs from selected row')
        # No old result is consulted in preparation or inference.
        base = deepcopy(packet['plan'])
        readings = base.pop('readings_packet', None)
        completion = ref(Path(row['parent_native_ref']['path']).with_name('completion.json'))
        row['parent_completion_ref'] = completion
        row['configuration'] = deepcopy(packet['configuration'])
        parents.append(dict(case_id=row['case']['case_id'], parent=row['parent_native_ref'],
            saved_plan_sha256=digest(base), saved_readings_sha256=digest(readings),
            saved_plan_version=base['version'], code_pins_sha256=digest(packet['code_pins']),
            source_binding=deepcopy(packet['binding']), environment=deepcopy(packet['environment'])))
    manifest['parent_headers'] = parents
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path)
    parser.add_argument('--report-sha256')
    parser.add_argument('--revisions', type=Path)
    parser.add_argument('--revisions-sha256')
    parser.add_argument('--output', type=Path, default=HERE / 'provisional_inputs.json')
    args = parser.parse_args()
    if args.report:
        report_ref = ref(args.report)
        if report_ref['sha256'] != args.report_sha256:
            raise ValueError('An explicit report requires its expected hash')
    else:
        report_ref = read(PHASE / 'publication_refs.json')['report_ref']
    revisions_ref = None
    if args.revisions:
        revisions_ref = ref(args.revisions)
        if revisions_ref['sha256'] != args.revisions_sha256:
            raise ValueError('An explicit revision input requires its expected hash')
    manifest = build(report_ref, revisions_ref)
    immutable(args.output, manifest)
    print(ref(args.output))
    print('PREPARED', len(manifest['cases']), 'API0; native execution not started')


if __name__ == '__main__':
    main()
