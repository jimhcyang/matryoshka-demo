"""Pure, pinned-input contracts for the shared full-native epoch runner."""
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
PHASE = HERE.parents[1]
VERSION = 'uniform-full-native-epoch/2'
PUBLIC_FIELDS = {'case_id', 'corpus', 'task', 'query', 'document_id', 'date', 'focal_marker'}
CORE_ATOM_FIELDS = ('id', 'text', 'required', 'polarity')
PRESENTATION_FIELDS = ('origin_refs', 'presentation_title', 'query_kind',
    'reference_answer_kind', 'source_target_id', 'family_id', 'source_target_family_id',
    'narrative_id', 'narrative_summary', 'presentation_caveats', 'collection', 'scope_note')


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def safe_path(path):
    value = Path(path)
    value = (value if value.is_absolute() else ROOT / value).resolve()
    if not value.is_relative_to(ROOT.resolve()):
        raise ValueError('Reference escapes src-demo-day')
    return value


def ref(path):
    path = safe_path(path)
    return dict(path=str(path.relative_to(ROOT)),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def read(path):
    path = safe_path(path)
    if path.suffix == '.gz':
        wrapped = json.loads(gzip.decompress(path.read_bytes()))
        if set(wrapped) == {'payload', 'sha256'}:
            if digest(wrapped['payload']) != wrapped['sha256']:
                raise ValueError('Compressed payload checksum changed')
            return wrapped['payload']
        return wrapped
    return json.loads(path.read_text())


def load_pinned(reference):
    if set(reference) != {'path', 'sha256'} or ref(reference['path']) != reference:
        raise ValueError('Pinned artifact changed: ' + str(reference.get('path')))
    return read(reference['path'])


def immutable(path, value):
    path = safe_path(path)
    if not path.is_relative_to(HERE):
        raise ValueError('Runner writes are restricted to uniform_epoch')
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if read(path) != value:
            raise ValueError('Immutable artifact differs: ' + str(path))
        return
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def public_case(case):
    if set(case) != PUBLIC_FIELDS:
        raise ValueError('Exactly seven public case fields are required')
    if case['corpus'] not in {'iran', 'vietnam', 'cib'} or case['task'] not in {
            'redaction', 'mosaic', 'hypothesis'}:
        raise ValueError('Unknown public corpus/task')
    if any(not isinstance(case[k], str) or not case[k] for k in
            ('case_id', 'query', 'document_id', 'date')):
        raise ValueError('Missing public identity')
    if case['focal_marker'] is not None and not isinstance(case['focal_marker'], str):
        raise ValueError('Invalid focal marker')
    return deepcopy(case)


def presentation(row):
    value = {k: deepcopy(row[k]) for k in PRESENTATION_FIELDS if k in row}
    if not value.get('origin_refs') or not value.get('query_kind'):
        raise ValueError('Existing exact origin and query kind required; never synthesize origins')
    for reference in value['origin_refs'].values():
        load_pinned(reference)
    if row['case']['task'] == 'redaction' and value.get('source_target_family_id'):
        if value.get('family_id', value['source_target_family_id']) != value['source_target_family_id']:
            raise ValueError('Conflicting source family identities')
        value['family_id'] = value['source_target_family_id']
    return value


def native_reference(row):
    options = [row.get('parent_native_ref'), row.get('native_ref'),
        row.get('outputs', {}).get('native_checkpoint'),
        row.get('configurations', {}).get('llm_readings', {}).get('native_checkpoint')]
    for reference in options:
        if reference:
            return deepcopy(reference)
    raise ValueError('Missing explicit native parent')


def project_row(row):
    return dict(case=public_case(row['case']), parent_native_ref=native_reference(row),
        **presentation(row))


def validate_inputs(manifest):
    rows = manifest.get('cases')
    if not isinstance(rows, list) or not rows:
        raise ValueError('Input manifest requires cases')
    ids = []
    for row in rows:
        public_case(row['case'])
        presentation(row)
        if not row.get('parent_native_ref'):
            raise ValueError('Each selected row requires parent_native_ref')
        ids.append(row['case']['case_id'])
    if len(ids) != len(set(ids)):
        raise ValueError('Duplicate selected public case identity')
    return rows


def configuration_options(config):
    from matryoshka_demo.source_view_policy import from_descriptor
    if config.get('top_k') != 5:
        raise ValueError('Do not change the original top-k')
    value = dict(method=config['method'], passage_budget=config['retrieval_passage_budget'],
        document_budget=config['retrieval_document_budget'], construction_pages=config['construction_pages'],
        draft_budget=config['completed_drafts_per_reading'],
        source_view_policy=from_descriptor(config['source_view_policy']), terminal_ranking=config['terminal_ranking'])
    for key in ('selection_profile', 'discovery_profile'):
        if key in config:
            value[key] = deepcopy(config[key])
    return value


def selected_configuration(row, parent):
    original = parent['configuration']
    selected = deepcopy(row.get('configuration', original))
    changes = {k: dict(before=original.get(k), after=selected.get(k))
        for k in set(original) | set(selected) if original.get(k) != selected.get(k)}
    if changes:
        audit = row.get('configuration_override', {})
        if (set(changes) != {'completed_drafts_per_reading'} or
                audit.get('changes') != changes or not audit.get('reason') or
                not isinstance(selected['completed_drafts_per_reading'], int) or
                selected['completed_drafts_per_reading'] < original['completed_drafts_per_reading']):
            raise ValueError('Only an explicitly pinned increased draft-budget override is accepted')
    return selected


def schema_projection(plan, schema):
    atom_fields = schema['properties']['atoms']['items']['properties']
    return dict(atoms=[{k: deepcopy(v) for k, v in atom.items() if k in atom_fields}
        for atom in plan['atoms']], extractions={key: [
            {k: deepcopy(v) for k, v in row.items() if k not in {'query_spans', 'contains_unknown_slot'}}
            for row in rows] for key, rows in plan['extractions'].items()})


def rebind_plan(plan, case, *, schema, bind, validate):
    """Rebind retained public schema, retaining all recoverable scope loss."""
    before = deepcopy(plan)
    raw = schema_projection(plan, schema)
    same_version_valid = False
    try:
        validate(plan, case)
        same_version_valid = True
    except ValueError:
        pass
    if same_version_valid:
        current = deepcopy(plan)
    else:
        current = bind(case, raw, receipt=deepcopy(plan.get('receipt')))
        atoms = {a['id']: a for a in current['atoms']}
        for record in plan.get('projection_qc', []):
            if record.get('reason') != 'PUBLIC_METADATA_OUTSIDE_SELECTED_FIELD_WITHHELD':
                continue
            atom = atoms.get(record.get('local_id'))
            field = record.get('field')
            if (record.get('table') != 'atoms' or atom is None or not atom.get('field_intent') or
                    field not in {'subject', 'predicate', 'object'} or atom.get(field) is not None or
                    not re.fullmatch(r'[a-f0-9]{64}', record.get('supplied_sha256', ''))):
                raise ValueError('Invalid preserved nominal scope-loss record')
            atom['field_intent']['unresolved_scope'] = sorted(set(
                atom['field_intent']['unresolved_scope'] + [field]))
            if record not in current.setdefault('projection_qc', []):
                current['projection_qc'].append(deepcopy(record))
        validate(current, case)
    if [{k: a[k] for k in CORE_ATOM_FIELDS} for a in before['atoms']] != [
            {k: a[k] for k in CORE_ATOM_FIELDS} for a in current['atoms']]:
        raise ValueError('Rebind changed core atom identity/text/required/polarity')
    if current.get('receipt') != before.get('receipt'):
        raise ValueError('Original paid planning receipt changed')
    for old, new in zip(before['atoms'], current['atoms']):
        old_scope = set(old.get('field_intent', {}).get('unresolved_scope', []))
        new_scope = set(new.get('field_intent', {}).get('unresolved_scope', []))
        if not old_scope <= new_scope:
            raise ValueError('Rebind dropped an unresolved public scope constraint')
    if before != plan:
        raise ValueError('Rebind mutated its saved input')
    audit = dict(version='saved-public-schema-rebind/1', api_calls=0,
        method='EXACT_VALIDATED_PLAN_REUSE' if same_version_valid else 'CURRENT_BIND_RETAINED_PUBLIC_SCHEMA',
        saved_version=before['version'], current_version=current['version'],
        saved_plan_sha256=digest(before), rebound_plan_sha256=digest(current),
        exact_saved_plan_replication=current == before, raw_schema_sha256=digest(raw),
        original_raw_output_sha256=before.get('raw_output_sha256'),
        original_receipt=deepcopy(before.get('receipt')),
        original_projection_qc=deepcopy(before.get('projection_qc', [])),
        current_projection_qc=deepcopy(current.get('projection_qc', [])),
        original_provider_wire_recovered=False, source_or_answer_fields_added=False,
        core_atom_fields_preserved=list(CORE_ATOM_FIELDS), unresolved_scope_not_dropped=True)
    return current, raw, audit


def review_snapshot(result):
    """Called only after a fresh native packet has been sealed."""
    branches = []
    for branch in result.get('readings', []):
        branches.append(dict(reading_id=branch['reading']['id'], candidates=[dict(
            id=c['id'], fill=c.get('fill'), rank=c.get('rank'),
            status=c.get('local_decision', {}).get('status'), support=c.get('support_assessment'))
            for c in branch['candidates']]))
    atoms = [dict(id=a.get('id'), status=a.get('status'), criterion_state=a.get('criterion_state'),
        evidence=[dict(direction=e.get('direction'), citation=e.get('citation'),
            support_scope=e.get('support_scope'), potential_counter=e.get('potential_counter'))
            for e in a.get('evidence', [])]) for a in result.get('atoms', [])]
    return dict(status=result.get('status'), readings=branches, atoms=atoms)


def verify_freeze(freeze, contract_ref, pins):
    if freeze.get('status') != 'BACKEND_FROZEN' or freeze.get('code_pins') != pins:
        raise ValueError('Current engine is not the explicitly pinned frozen epoch')
    if freeze.get('uniform_runner_contract') != contract_ref:
        raise ValueError('Freeze must pin this shared runner contract')
    contract = load_pinned(contract_ref)
    if contract.get('version') != VERSION:
        raise ValueError('Wrong shared runner protocol')
    for dependency in contract['files']:
        if ref(dependency['path']) != dependency:
            raise ValueError('Shared runner/helper changed')
    return contract
