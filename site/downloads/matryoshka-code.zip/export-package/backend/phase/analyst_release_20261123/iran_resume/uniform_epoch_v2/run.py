"""One common, offline full-native runner. No launch without explicit frozen pins."""
import argparse
from copy import deepcopy
import fcntl
import gc
import os
from pathlib import Path
import sys
import time
import traceback

from protocol import (HERE, PHASE, ROOT, VERSION, configuration_options, digest,
    immutable, load_pinned, presentation, read, rebind_plan, ref, review_snapshot,
    safe_path, selected_configuration, validate_inputs, verify_freeze)


def pinned_argument(path, expected):
    actual = ref(path)
    if actual['sha256'] != expected:
        raise ValueError('Command-line input hash changed: ' + str(path))
    return actual


def preflight_inputs(rows, *, freeze_ref, inputs_ref, contract_ref):
    """Validate every real input before the execution opt-in; no corpus opens."""
    from matryoshka_narrative import workflow, planning
    from matryoshka_narrative.contracts import engine_case
    from matryoshka_next import planning as legacy_planning
    from matryoshka_next.readings import validate_readings
    from matryoshka_next.workflow import put_immutable
    from matryoshka_demo.io import offline
    key = digest(dict(version=VERSION, freeze=freeze_ref, inputs=inputs_ref, runner=contract_ref))
    directory = HERE / 'preflight' / key
    checks = []
    with offline(), workflow.Session() as session:
        for row in rows:
            case = row['case']
            result = dict(case_id=case['case_id'], parent_native_ref=row['parent_native_ref'])
            try:
                parent = load_pinned(row['parent_native_ref'])
                path = safe_path(row['parent_native_ref']['path'])
                completion_ref = row.get('parent_completion_ref', ref(path.with_name('completion.json')))
                seal = load_pinned(completion_ref)
                if seal != workflow._completion(path, parent, seal['execution_key']):
                    raise ValueError('Parent completion seal changed')
                if parent['public_case'] != case or parent['case'] != engine_case(case):
                    raise ValueError('Parent public/engine case differs')
                corpus = case['corpus']
                if (parent['binding'] != session.refs['index_refs'][corpus] or
                        parent['environment'] != session.environment):
                    raise ValueError('Normal source index or language resources changed')
                settings = selected_configuration(row, parent)
                options = configuration_options(settings)
                if workflow.configuration(**options) != settings:
                    raise ValueError('Actual configuration does not round-trip')
                # Only plain settings and type names enter the saved audit, not enum objects.
                result.update(configuration=settings, configuration_roundtrip=True,
                    runtime_source_policy_type=type(options['source_view_policy']).__name__,
                    parent_completion_ref=completion_ref, dataset_binding=parent['binding'])
                base = deepcopy(parent['plan'])
                readings = base.pop('readings_packet', None)
                rebound, raw, audit = rebind_plan(base, engine_case(case),
                    schema=legacy_planning.schema(), bind=planning.bind, validate=planning.validate_plan)
                if case['task'] == 'redaction':
                    validate_readings(readings, engine_case(case))
                elif readings is not None:
                    raise ValueError('Non-redaction parent has slot readings')
                audit.update(parent_native_ref=row['parent_native_ref'],
                    parent_completion_ref=completion_ref, saved_readings_sha256=digest(readings))
                case_dir = directory / 'cases' / digest(case)
                put_immutable(case_dir / 'raw_schema.json', raw)
                put_immutable(case_dir / 'plan.json.gz', rebound)
                put_immutable(case_dir / 'plan_rebind.json', audit)
                result.update(status='PASS', plan_rebind_ref=ref(case_dir / 'plan_rebind.json'),
                    plan_ref=ref(case_dir / 'plan.json.gz'),
                    exact_saved_plan_replication=audit['exact_saved_plan_replication'],
                    saved_readings_sha256=digest(readings), saved_readings_valid=True)
            except Exception as error:
                result.update(status='ERROR', error_type=type(error).__name__, error=str(error),
                    traceback=traceback.format_exc())
            checks.append(result)
            print('PREFLIGHT', case['case_id'], result['status'], result.get('error', ''), flush=True)
    audit = dict(version=VERSION, status='PASS' if all(c['status'] == 'PASS' for c in checks) else 'FAIL',
        checked=len(checks), checks=checks, freeze_ref=freeze_ref, inputs_ref=inputs_ref,
        runner_contract_ref=contract_ref, api_calls=0, native_executions=0,
        old_result_decisions_read=False, runtime_enums_serialized=False)
    path = directory / 'preflight.json'
    put_immutable(path, audit)
    if audit['status'] != 'PASS':
        raise ValueError('Pre-execution real-input validation failed; inspect ' + str(path))
    return ref(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', required=True, type=Path)
    parser.add_argument('--freeze-sha256', required=True)
    parser.add_argument('--inputs', required=True, type=Path)
    parser.add_argument('--inputs-sha256', required=True)
    parser.add_argument('--corpus', nargs='+', choices=['cib', 'iran', 'vietnam'], required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true', help='Explicitly authorize native execution')
    args = parser.parse_args()
    freeze_ref = pinned_argument(args.freeze, args.freeze_sha256)
    inputs_ref = pinned_argument(args.inputs, args.inputs_sha256)
    freeze, inputs = load_pinned(freeze_ref), load_pinned(inputs_ref)
    all_rows = validate_inputs(inputs)
    selected = [r for r in all_rows if r['case']['corpus'] in args.corpus]
    if not selected:
        raise ValueError('No selected rows for requested corpora')
    contract_ref = ref(HERE / 'runner_contract.json')
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(PHASE / 'backend'))
    from matryoshka_narrative import workflow, planning
    from matryoshka_narrative.contracts import engine_case
    from matryoshka_narrative.guards import require_headroom, remaining_seconds
    from matryoshka_next import planning as legacy_planning
    from matryoshka_next.readings import validate_readings
    from matryoshka_next.workflow import put, put_immutable
    from matryoshka_demo.io import offline
    from matryoshka_demo.source_view_policy import apply_source_view
    from run_final import final_export, verify_viewer_outputs
    from run_regression import source_audit
    verify_freeze(freeze, contract_ref, workflow.code_pins())
    preflight_ref = preflight_inputs(all_rows, freeze_ref=freeze_ref,
        inputs_ref=inputs_ref, contract_ref=contract_ref)
    print('FROZEN_INPUTS_VALIDATED', len(selected), sorted(set(args.corpus)), flush=True)
    if not args.execute:
        print('NOT_STARTED: add --execute only after Main launch authorization', flush=True)
        return
    os.environ.setdefault('NARRATIVE_NO_NEW_WORK_UTC', '2026-11-23T20:04:59Z')
    os.environ.setdefault('NARRATIVE_DEADLINE_UTC', '2026-11-23T20:14:59Z')
    output = safe_path(args.output or HERE / 'epochs' / args.freeze_sha256[:20] /
        '_'.join(sorted(set(args.corpus))))
    if not output.is_relative_to(HERE):
        raise ValueError('Output must stay inside uniform_epoch')
    output.mkdir(parents=True, exist_ok=True)
    lock = (output / 'execution.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    workflow.OUTPUT = output / 'execution'
    identity = dict(version=VERSION, freeze_ref=freeze_ref, inputs_ref=inputs_ref,
        runner_contract_ref=contract_ref, corpora=sorted(set(args.corpus)),
        case_ids=[r['case']['case_id'] for r in selected], preflight_ref=preflight_ref, api_calls=0)
    immutable(output / 'launch.json', identity)
    rows = []

    def check_pins():
        if ref(args.freeze) != freeze_ref or ref(args.inputs) != inputs_ref:
            raise RuntimeError('Frozen execution inputs changed')
        verify_freeze(freeze, contract_ref, workflow.code_pins())

    def progress(active=None):
        put(output / 'progress.json', dict(identity, status='RUNNING',
            completed=len(rows), requested=len(selected), active=active, cases=rows))

    with offline():
        for corpus in ('cib', 'iran', 'vietnam'):
            group = [r for r in selected if r['case']['corpus'] == corpus]
            if not group:
                continue
            with workflow.Session() as session:
                for item in group:
                    check_pins()
                    remaining_seconds(new_work=True)
                    require_headroom(output)
                    case = item['case']
                    started = time.perf_counter()
                    key = digest(dict(identity, case=case, parent=item['parent_native_ref'],
                        configuration=item.get('configuration'),
                        configuration_override=item.get('configuration_override')))
                    directory = output / 'runs' / key
                    target = directory / 'native.json.gz'
                    entry_path = directory / 'entry.json'
                    if entry_path.exists() and read(entry_path).get('status') == 'ERROR':
                        raise RuntimeError('Retained failed entry: choose a new --output directory for a retry')
                    phase = 'parent_header_and_plan_rebind'
                    progress(dict(case_id=case['case_id'], phase=phase))
                    try:
                        # The result subtree is not consulted until after the new seal.
                        parent = load_pinned(item['parent_native_ref'])
                        parent_path = safe_path(item['parent_native_ref']['path'])
                        completion_ref = item.get('parent_completion_ref', ref(parent_path.with_name('completion.json')))
                        seal = load_pinned(completion_ref)
                        if seal != workflow._completion(parent_path, parent, seal['execution_key']):
                            raise ValueError('Parent completion seal changed')
                        if parent['public_case'] != case:
                            raise ValueError('Parent public case changed')
                        if (parent['binding'] != session.refs['index_refs'][corpus] or
                                parent['environment'] != session.environment):
                            raise ValueError('Normal source index or language-resource binding changed')
                        old_plan = deepcopy(parent['plan'])
                        readings = old_plan.pop('readings_packet', None)
                        base, raw, audit = rebind_plan(old_plan, engine_case(case),
                            schema=legacy_planning.schema(), bind=planning.bind,
                            validate=planning.validate_plan)
                        if case['task'] == 'redaction':
                            validate_readings(readings, engine_case(case))
                        elif readings is not None:
                            raise ValueError('Non-redaction parent unexpectedly has readings')
                        audit.update(parent_native_ref=item['parent_native_ref'],
                            parent_completion_ref=completion_ref,
                            saved_readings_sha256=digest(readings), readings_reused_exactly=True,
                            query_sha256=digest(case['query']))
                        put_immutable(directory / 'raw_schema.json', raw)
                        put_immutable(directory / 'plan.json.gz', base)
                        put_immutable(directory / 'plan_rebind.json', audit)
                        settings = selected_configuration(item, parent)
                        options = configuration_options(settings)
                        if workflow.configuration(**options) != settings:
                            raise ValueError('Configuration cannot round-trip without changing budgets/policy')
                        expected = dict(pins=freeze['code_pins'], binding=parent['binding'],
                            environment=parent['environment'], settings=settings)
                        phase = 'fresh_full_native_execution'
                        progress(dict(case_id=case['case_id'], phase=phase))
                        if target.exists():
                            packet = read(target)
                            workflow.validate_packet(packet, case, base, readings, **expected)
                            if read(target.with_name('completion.json')) != workflow._completion(target, packet, key):
                                raise ValueError('New epoch cache completion changed')
                            cached = True
                        else:
                            packet = session.execute(case, base, readings_packet=readings, **options)
                            workflow.validate_packet(packet, case, base, readings, **expected)
                            put_immutable(target, packet)
                            put_immutable(target.with_name('completion.json'), workflow._completion(target, packet, key))
                            cached = False
                        native_ref = ref(target)
                        phase = 'source_audit_and_normal_viewer_export'
                        progress(dict(case_id=case['case_id'], phase=phase))
                        context = session.context(corpus)
                        scoped = apply_source_view(context, settings['source_view_policy'])
                        source_check = source_audit(packet, scoped)
                        quote_check = workflow._terminal_source_replay(packet, scoped)
                        quote_check.pop('gates_reexecuted', None)
                        quote_check.pop('sealed_native_sufficiency_decisions_reused', None)
                        source_check['exact_quote_replay'] = quote_check
                        source_check['fresh_native_sufficiency_gates_executed'] = True
                        put_immutable(directory / 'source_audit.json', source_check)
                        outputs = final_export(packet, native_ref, context, directory)
                        put_immutable(directory / 'normal_viewer_audit.json', verify_viewer_outputs(packet, outputs))
                        phase = 'post_execution_readonly_comparison'
                        if parent['native_checksum'] != digest(parent['result']):
                            raise ValueError('Baseline result checksum changed')
                        before, after = review_snapshot(parent['result']), review_snapshot(packet['result'])
                        comparison = dict(parent_native_ref=item['parent_native_ref'], native_ref=native_ref,
                            before=before, after=after, changed=before != after,
                            review_only=True, source_of_candidate_admission='FRESH_NATIVE_GATES',
                            baseline_result_consulted_only_after_new_native_seal=True,
                            automatic_qualification=False)
                        put_immutable(directory / 'comparison.json', comparison)
                        put_immutable(directory / 'candidate_pool.json.gz', dict(
                            assessed_candidates=packet['result'].get('assessed_candidates', []),
                            pre_terminal_candidate_order=packet['result'].get('pre_terminal_candidate_order', [])))
                        row = dict(case=case, **presentation(item), outputs=outputs,
                            status='NATIVE_COMPLETE_REVIEW_PENDING', native_status=packet['result']['status'],
                            native_ref=native_ref, configuration=settings,
                            configuration_override=item.get('configuration_override'),
                            plan_rebind_ref=ref(directory / 'plan_rebind.json'),
                            exact_saved_plan_replication=audit['exact_saved_plan_replication'],
                            new_full_native_execution=True, cached_new_execution=cached,
                            completion_ref=ref(target.with_name('completion.json')),
                            source_audit_ref=ref(directory / 'source_audit.json'),
                            normal_viewer_audit_ref=ref(directory / 'normal_viewer_audit.json'),
                            candidate_pool_ref=ref(directory / 'candidate_pool.json.gz'),
                            comparison_ref=ref(directory / 'comparison.json'),
                            parent_native_ref=item['parent_native_ref'], frozen_backend=freeze_ref,
                            runner_contract_ref=contract_ref, api_calls=0,
                            qualification_inherited=False)
                        print('UNIFORM_NATIVE_READY', case['case_id'], row['native_status'], flush=True)
                    except Exception as error:
                        row = dict(case=case, status='ERROR', failed_stage=phase,
                            error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc(),
                            parent_native_ref=item['parent_native_ref'], api_calls=0,
                            native_ref=ref(target) if target.exists() else None,
                            new_full_native_execution=target.exists(), qualification_inherited=False)
                        print('UNIFORM_EXPLICIT_ERROR', case['case_id'], phase, str(error), flush=True)
                    row['wall_seconds'] = time.perf_counter() - started
                    if entry_path.exists():
                        prior_row = read(entry_path)
                        if any(prior_row.get(k) != row.get(k) for k in (
                                'case', 'native_ref', 'outputs', 'plan_rebind_ref', 'comparison_ref',
                                'configuration', 'frozen_backend', 'runner_contract_ref', 'status')):
                            raise ValueError('Saved successful entry binding differs')
                        row = prior_row
                    put_immutable(entry_path, row)
                    rows.append(row)
                    progress()
                    check_pins()
                    parent = packet = context = scoped = None
            gc.collect()
    result = dict(identity, status='COMPLETE' if all(r['status'] != 'ERROR' for r in rows)
        else 'COMPLETE_WITH_EXPLICIT_ERRORS', requested=len(selected), completed=len(rows), cases=rows,
        new_full_native_execution=True, scientific_case_qualification=False,
        historical_packets_modified=False)
    put_immutable(output / 'results.json', result)
    put(output / 'progress.json', result)
    print('UNIFORM_DONE', result['status'], ref(output / 'results.json'), flush=True)


if __name__ == '__main__':
    main()
