"""API0 contract tests; no native constructor is executed."""
from copy import deepcopy
import gzip
import json
from pathlib import Path
import sys

import pytest

import protocol as p
sys.path.insert(0, str(p.ROOT))


FIELDS = ('id', 'text', 'required', 'polarity', 'subject', 'predicate', 'object', 'kind')
SCHEMA = {'properties': {'atoms': {'items': {'properties': dict.fromkeys(FIELDS)}}}}


def plan():
    return dict(version='old', atoms=[dict(id='a1', text='A left.', required=True,
        polarity='positive', subject='A', predicate='left', object=None, kind='proposition',
        query_spans=[[0, 7]], derived='not model input')],
        extractions={'entities': [dict(local_id='e1', label='A', query_spans=[[0, 1]],
            contains_unknown_slot=False)]}, receipt={'paid': 'original'},
        raw_output_sha256='1' * 64, projection_qc=[])


def bind(case, raw, *, receipt):
    return dict(version='new', **deepcopy(raw), receipt=deepcopy(receipt),
        raw_output_sha256=p.digest(raw), projection_qc=[])


def validate(value, case):
    if value['version'] != 'new':
        raise ValueError('old version')


def rebind(value, binder=bind, validator=validate):
    return p.rebind_plan(value, {}, schema=SCHEMA, bind=binder, validate=validator)


def test_schema_strips_only_derived_fields():
    raw = p.schema_projection(plan(), SCHEMA)
    assert set(raw['atoms'][0]) == set(FIELDS)
    assert raw['extractions']['entities'] == [dict(local_id='e1', label='A')]
    assert 'receipt' not in raw and 'result' not in raw


def test_version_rebind_preserves_input_and_receipt():
    old = plan()
    before = deepcopy(old)
    new, raw, audit = rebind(old)
    assert old == before and new['receipt'] == old['receipt']
    assert not audit['exact_saved_plan_replication']
    assert audit['saved_plan_sha256'] == p.digest(old)
    assert audit['raw_schema_sha256'] == p.digest(raw)
    assert audit['original_raw_output_sha256'] == old['raw_output_sha256']
    assert audit['api_calls'] == 0


def test_valid_same_version_reuses_exact_bytes_value():
    old = plan()
    old['version'] = 'new'
    new, _, audit = rebind(old, binder=lambda *a, **k: pytest.fail('unneeded bind'))
    assert new == old and audit['exact_saved_plan_replication']


@pytest.mark.parametrize('field,value', [('id', 'other'), ('text', 'Changed.'),
    ('required', False), ('polarity', 'negative')])
def test_rebind_cannot_change_core_atom(field, value):
    def changed(*a, **k):
        result = bind(*a, **k)
        result['atoms'][0][field] = value
        return result
    with pytest.raises(ValueError, match='core atom'):
        rebind(plan(), changed)


def test_failed_bind_is_rejected_not_repaired():
    def fails(*a, **k):
        raise ValueError('scope failure')
    with pytest.raises(ValueError, match='scope failure'):
        rebind(plan(), fails)


def test_receipt_change_rejected():
    def changed(*a, **k):
        value = bind(*a, **k)
        value['receipt'] = {}
        return value
    with pytest.raises(ValueError, match='receipt'):
        rebind(plan(), changed)


def test_scope_loss_not_silently_dropped():
    old = plan()
    old['atoms'][0]['field_intent'] = dict(unresolved_scope=['subject'])
    with pytest.raises(ValueError, match='scope constraint'):
        rebind(old)


def test_loss_record_recovered_and_preserved():
    old = plan()
    old['atoms'][0]['field_intent'] = dict(unresolved_scope=['object'])
    loss = dict(reason='PUBLIC_METADATA_OUTSIDE_SELECTED_FIELD_WITHHELD', table='atoms',
        local_id='a1', field='object', supplied_sha256='a' * 64)
    old['projection_qc'] = [loss]
    def scoped(*a, **k):
        value = bind(*a, **k)
        value['atoms'][0]['field_intent'] = dict(unresolved_scope=[])
        return value
    new, _, audit = rebind(old, scoped)
    assert new['atoms'][0]['field_intent']['unresolved_scope'] == ['object']
    assert loss in new['projection_qc']
    assert audit['original_projection_qc'] == [loss]


@pytest.mark.parametrize('field,value', [('supplied_sha256', 'bad'), ('table', 'events'),
    ('local_id', 'missing'), ('field', 'unsupported')])
def test_invalid_scope_loss_rejected(field, value):
    old = plan()
    loss = dict(reason='PUBLIC_METADATA_OUTSIDE_SELECTED_FIELD_WITHHELD', table='atoms',
        local_id='a1', field='object', supplied_sha256='a' * 64)
    loss[field] = value
    old['projection_qc'] = [loss]
    with pytest.raises(ValueError, match='scope-loss'):
        rebind(old)


def config():
    from matryoshka_demo.source_view_policy import descriptor, SOURCE_DAY_INCLUSIVE
    return dict(method='current_hierarchy', retrieval_passage_budget=80,
        retrieval_document_budget=40, construction_pages=16, completed_drafts_per_reading=24,
        top_k=5, source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE), terminal_ranking='evidence_fit_v3',
        selection_profile={'identity_first': True}, discovery_profile={'alpha': .85})


def test_config_preserves_all_budgets_profiles():
    from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE
    cfg = config()
    options = p.configuration_options(cfg)
    assert options['passage_budget'] == 80 and options['document_budget'] == 40
    assert options['construction_pages'] == 16 and options['draft_budget'] == 24
    assert options['selection_profile'] == cfg['selection_profile']
    assert options['discovery_profile'] == cfg['discovery_profile']
    assert options['source_view_policy'] is SOURCE_DAY_INCLUSIVE


ACTUAL_INPUTS = p.read(p.HERE.parent / 'uniform_epoch/provisional_inputs_v2.json')['cases']


@pytest.mark.parametrize('row', ACTUAL_INPUTS, ids=lambda row: row['case']['case_id'])
def test_all_16_actual_parent_configuration_roundtrips(row):
    from matryoshka_narrative import workflow
    from matryoshka_demo.source_view_policy import SourceViewPolicy, from_descriptor
    parent = p.load_pinned(row['parent_native_ref'])
    actual = p.selected_configuration(row, parent)
    kwargs = p.configuration_options(actual)
    assert type(kwargs['source_view_policy']) is SourceViewPolicy
    assert kwargs['source_view_policy'] is from_descriptor(actual['source_view_policy'])
    saved = workflow.configuration(**kwargs)
    assert saved == actual
    assert json.loads(json.dumps(saved)) == actual


def test_policy_descriptor_cannot_be_weakened():
    cfg = config()
    cfg['source_view_policy']['later_or_secret_version_admitted'] = True
    with pytest.raises(ValueError, match='descriptor changed'):
        p.configuration_options(cfg)


def test_id_string_is_not_an_engine_policy():
    from matryoshka_narrative import workflow
    kwargs = p.configuration_options(config())
    kwargs['source_view_policy'] = 'source_day_inclusive'
    with pytest.raises(TypeError, match='trusted SourceViewPolicy enum'):
        workflow.configuration(**kwargs)


def test_explicit_draft_override():
    cfg = config()
    changed = dict(cfg, completed_drafts_per_reading=64)
    row = dict(configuration=changed, configuration_override=dict(reason='uniform draft floor',
        changes={'completed_drafts_per_reading': {'before': 24, 'after': 64}}))
    assert p.selected_configuration(row, {'configuration': cfg}) == changed


@pytest.mark.parametrize('field,value', [('completed_drafts_per_reading', 12),
    ('construction_pages', 32), ('retrieval_document_budget', 60), ('top_k', 8)])
def test_unauthorized_budget_or_profile_override_rejected(field, value):
    cfg = config()
    changed = dict(cfg, **{field: value})
    row = dict(configuration=changed, configuration_override=dict(reason='bad',
        changes={field: {'before': cfg[field], 'after': value}}))
    with pytest.raises(ValueError, match='override'):
        p.selected_configuration(row, {'configuration': cfg})


def test_freeze_required(monkeypatch):
    with pytest.raises(ValueError, match='frozen epoch'):
        p.verify_freeze({'status': 'DRAFT', 'code_pins': {}}, {}, {})
    with pytest.raises(ValueError, match='runner contract'):
        p.verify_freeze({'status': 'BACKEND_FROZEN', 'code_pins': {}}, {'x': 1}, {})


def test_review_preserves_signed_evidence_not_vote_counts():
    result = {'status': 'CONFLICTED', 'atoms': [{'id': 'a1', 'status': 'CONFLICTED',
        'evidence': [{'direction': 'SUPPORT', 'citation': {'document_id': 'one'}},
            {'direction': 'COUNTER', 'citation': {'document_id': 'two'}}]}]}
    snapshot = p.review_snapshot(result)
    assert [e['direction'] for e in snapshot['atoms'][0]['evidence']] == ['SUPPORT', 'COUNTER']


def test_runner_is_full_execution_not_terminal_replay():
    source = (p.HERE / 'run.py').read_text()
    assert 'session.execute(case, base' in source
    assert 'session.replay_terminal' not in source
    assert 'with offline():' in source
    assert source.index('workflow._completion(target, packet, key)') < source.index("review_snapshot(parent['result'])")
    assert 'final_export(packet' in source and 'verify_viewer_outputs(packet' in source


def test_dryrun_validates_inputs_before_execution_gate():
    source = (p.HERE / 'run.py').read_text()
    assert source.index('preflight_ref = preflight_inputs(all_rows') < source.index('if not args.execute:')
    helper = source[source.index('def preflight_inputs('):source.index('\ndef main():')]
    assert 'workflow.configuration(**options)' in helper
    assert 'planning.validate_plan' in helper
    assert 'validate_readings(readings' in helper
    assert '.execute(' not in helper and '.context(' not in helper


def test_artifact_settings_do_not_serialize_runtime_enum():
    source = (p.HERE / 'run.py').read_text()
    assert 'configuration=settings' in source
    assert 'configuration=options' not in source


def test_read_native_gzip_and_envelope(tmp_path, monkeypatch):
    monkeypatch.setattr(p, 'ROOT', tmp_path)
    value = {'test': True}
    for name, data in [('native.gz', value), ('envelope.gz', {'payload': value, 'sha256': p.digest(value)})]:
        path = tmp_path / name
        path.write_bytes(gzip.compress(json.dumps(data).encode()))
        assert p.read(path) == value


def test_path_cannot_escape_root():
    with pytest.raises(ValueError, match='escapes'):
        p.safe_path('/tmp/not-our-work')
