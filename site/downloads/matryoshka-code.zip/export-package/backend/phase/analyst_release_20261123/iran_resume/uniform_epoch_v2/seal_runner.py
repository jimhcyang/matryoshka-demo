"""Pin only this runner and its reused, unchanged export helpers."""
from protocol import HERE, PHASE, VERSION, immutable, ref


def main():
    files = [HERE / name for name in ('run.py', 'protocol.py', 'prepare.py', 'seal_runner.py',
        'inputs.schema.json')]
    files += [PHASE / 'backend' / name for name in ('run_final.py', 'run_regression.py')]
    contract = dict(version=VERSION, files=[ref(p) for p in files],
        execution='FRESH_SESSION_EXECUTE_NOT_TERMINAL_REPLAY', api_calls=0,
        tests_ref=ref(HERE / 'tests.xml'), automatic_launch=False)
    immutable(HERE / 'runner_contract.json', contract)
    print(ref(HERE / 'runner_contract.json'))


if __name__ == '__main__':
    main()
