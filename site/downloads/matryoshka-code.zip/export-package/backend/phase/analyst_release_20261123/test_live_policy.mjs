import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
const dataURL = code => 'data:text/javascript;base64,'+Buffer.from(code).toString('base64');
const policyURL = dataURL(await readFile(new URL('./stage/site/source-policy-contract.js',import.meta.url),'utf8'));
const {LIVE_SOURCE_POLICY: policy, verifyLiveSourcePolicy, usesLiveSourcePolicy} = await import(policyURL);
const controls = await readFile(new URL('./stage/site/live-scope-controls.js',import.meta.url),'utf8');
const {displayedScope} = await import(dataURL(controls.replace("'./source-policy-contract.js'",JSON.stringify(policyURL))));

let checks = 0;
const run = fn => { fn(); checks++; };
const request = {corpus:'cib', as_of:'1959-02-18', excluded_origin:'CIA-RDP79T00975A004300220001-9'};
const native = {configuration:{source_view_policy:{...policy}}, result:{source_view_policy:{...policy}}};
const scope = {corpus:'cib', strict_before:request.as_of, evidence_through:'1959-02-17',
  excluded_whole_origin:null, origin_document:request.excluded_origin,
  origin_kind:'source_document', document_exclusion:null, source_view_policy:{...policy}};
run(() => assert.deepEqual(verifyLiveSourcePolicy(scope,native,request),{current:true,excludeOrigin:false}));
run(() => assert.equal(displayedScope(request,scope).earlierOriginAllowed,true));
run(() => assert.equal(displayedScope(request,scope).originDocument,request.excluded_origin));
for (const change of [{date_relation:'<='},{later_or_secret_version_admitted:true},{cable_origin:'ADMIT'}, {extra:true}]) {
  run(() => assert.throws(() => usesLiveSourcePolicy({...scope,source_view_policy:{...policy,...change}})));
}
run(() => assert.throws(() => verifyLiveSourcePolicy({...scope,excluded_whole_origin:request.excluded_origin},native,request)));
run(() => assert.throws(() => verifyLiveSourcePolicy({...scope,origin_document:'another'},native,request)));
run(() => assert.throws(() => verifyLiveSourcePolicy(scope,{...native,result:{source_view_policy:{...policy,date_relation:'<='}}},request)));
run(() => assert.throws(() => verifyLiveSourcePolicy(scope,{result:{},configuration:{}},request)));
const cableRequest = {...request,corpus:'iran',excluded_origin:'1979TEHRAN123'};
const cableScope = {...scope,corpus:'iran',excluded_whole_origin:cableRequest.excluded_origin,
  document_exclusion:cableRequest.excluded_origin,origin_document:cableRequest.excluded_origin,origin_kind:'document_exclusion'};
run(() => assert.deepEqual(verifyLiveSourcePolicy(cableScope,native,cableRequest),{current:true,excludeOrigin:true}));
run(() => assert.throws(() => verifyLiveSourcePolicy({...cableScope,excluded_whole_origin:null},native,cableRequest)));
const legacy = {...scope,excluded_whole_origin:request.excluded_origin};
delete legacy.source_view_policy;
run(() => assert.deepEqual(verifyLiveSourcePolicy(legacy,{},request),{current:false,excludeOrigin:true}));
const analystRequest = {...request,excluded_origin:'live-analyst-origin:'+'a'.repeat(32)};
const analystScope = {...scope,origin_document:null,origin_kind:'analyst_authored'};
run(() => assert.deepEqual(verifyLiveSourcePolicy(analystScope,native,analystRequest),{current:true,excludeOrigin:false}));
run(() => assert.equal(displayedScope(analystRequest,analystScope).originDocument,null));
console.log(JSON.stringify({checks,passed:checks,paid_calls:0}));
