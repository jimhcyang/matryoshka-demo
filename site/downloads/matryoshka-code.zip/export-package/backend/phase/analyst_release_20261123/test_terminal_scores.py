"""API0 arithmetic, independence, ranking and source-sufficiency regressions."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from matryoshka_narrative.terminal_scores import annotate_result, atom_score, candidate_score, source_weight


def quote(document='d1', page='p1'):
    return dict(document_id=document, canonical_page_id=page, start=0, end=8,
                text='The fact', page_sha256='a' * 64, date='1959-01-01')


def candidate(identity='c1', relation=False, status='exploratory_contextual'):
    return dict(id=identity, reading_id='r1', fill=identity, alternative_family=identity,
        source_rank_position=1, sources=[quote()],context_rank_key=[True]*9+[None]*11,
        ranking=dict(features=dict(source_owned_relation_match=relation,
            source_owned_role_context=dict(matched=False), source_type_match=True,
            focal_context_coverage=1, focal_term_count=4, retrieval_page_rank=2)),
        local_decision=dict(status=status, requirements=[]))


class Scores(unittest.TestCase):
    def test_document_repetitions_add_no_credit(self):
        c = candidate()
        before = candidate_score(c)
        c['sources'] *= 100
        self.assertEqual(candidate_score(c), before)

    def test_independent_document_adds_credit(self):
        c = candidate()
        before = candidate_score(c)['score']
        c['sources'].append(quote('d2', 'p2'))
        self.assertGreater(candidate_score(c)['score'], before)

    def test_owned_relation_beats_unbound_context(self):
        self.assertGreater(candidate_score(candidate(relation=True))['score'], candidate_score(candidate())['score'])

    def test_relevance_cannot_promote_a_support_gate(self):
        contextual = candidate(relation=True)
        contextual['sources'] = [quote(str(i), str(i)) for i in range(200)]
        self.assertLess(candidate_score(contextual)['score'], candidate_score(candidate(status='evidence_backed_suggestion'))['score'])
        self.assertEqual(contextual['local_decision']['status'], 'exploratory_contextual')

    def test_signed_support_and_opposition_remain_separate(self):
        atom = dict(id='f1', status='CONFLICTED', evidence=[dict(direction='SUPPORT', citation=quote()),
            dict(direction='COUNTER', citation=quote('d2', 'p2'))])
        score = atom_score(atom)
        self.assertGreater(score['support'], 0)
        self.assertGreater(score['oppose'], 0)
        self.assertEqual(score['native_status'], 'CONFLICTED')

    def test_no_support_threshold_of_one(self):
        score = atom_score(dict(id='f1', status='SUPPORT', evidence=[dict(direction='SUPPORT', citation=quote())]))
        self.assertEqual(score['support'], .5)
        self.assertEqual(score['native_status'], 'SUPPORT')

    def test_new_ranking_descends_without_changing_input(self):
        a, b = candidate('a'), candidate('b', relation=True)
        result = dict(task='redaction', readings=[dict(reading=dict(id='r1'), candidates=[a, b])], assessed_candidates=[a, b])
        before = deepcopy(result)
        revised = annotate_result(result, rerank=True)
        self.assertEqual(result, before)
        self.assertEqual([c['id'] for c in revised['readings'][0]['candidates']], ['b', 'a'])
        self.assertGreater(revised['readings'][0]['candidates'][0]['terminal_scorecard']['score'], revised['readings'][0]['candidates'][1]['terminal_scorecard']['score'])

    def test_duplicate_surfaces_do_not_occupy_two_top_positions(self):
        a, b = candidate('a'), candidate('b', relation=True)
        a['fill'] = b['fill'] = 'The same fill'
        result = dict(task='redaction', readings=[dict(reading=dict(id='r1'), candidates=[a, b])], assessed_candidates=[a, b])
        self.assertEqual(len(annotate_result(result, rerank=True)['readings'][0]['candidates']), 1)

    def test_unestablished_partial_is_not_promoted(self):
        score = candidate_score(candidate(status='partial_grounding'))
        self.assertEqual(score['evidence_tier'], 0)

    def test_rank_weight_is_bounded_and_missing_is_explicit(self):
        self.assertEqual(source_weight(quote(), {}, None), (.5, None))
        self.assertEqual(source_weight(quote(), {'p1': 1}), (1., 1))
        self.assertLess(source_weight(quote(), {'p1': 100})[0], 1)

    def test_visible_scope_is_soft_literal_and_never_an_action_certificate(self):
        c = candidate()
        text = 'Minister Oren Vale spoke with the council.'
        c['sources'] = [dict(quote(),text=text,end=len(text))]
        plan = dict(extractions=dict(entities=[dict(local_id='e1',type='person',label='Minister Oren Vale',
            evidence_quote='Minister Oren Vale',contains_unknown_slot=False,attributes=[dict(key='title',value='Minister')])]))
        score = candidate_score(c,plan=plan)
        self.assertEqual(score['visible_scope']['value'],1.)
        self.assertTrue(all(not x['source_owned_action_certified'] for x in score['visible_scope']['matches']))
        self.assertEqual(score['support'],0)
        self.assertEqual(score['native_status'],'exploratory_contextual')
        for match in score['visible_scope']['matches']:
            self.assertEqual(text[match['start']:match['end']],match['text'])
        c['sources'] *= 50
        self.assertEqual(candidate_score(c,plan=plan),score)

    def test_unknown_or_unquoted_entity_cannot_supply_a_scope_anchor(self):
        c = candidate()
        text = 'Oren Vale opened the gate.'
        c['sources'] = [dict(quote(),text=text,end=len(text))]
        for changes in (dict(contains_unknown_slot=True),dict(evidence_quote='Other visible material.'),dict(label='oren vale')):
            entity=dict(local_id='e1',type='person',label='Oren Vale',evidence_quote='Oren Vale',contains_unknown_slot=False)
            entity.update(changes)
            score=candidate_score(c,plan=dict(extractions=dict(entities=[entity])))
            self.assertEqual(score['visible_scope']['value'],0.)

    def test_source_function_band_precedes_background_quantity(self):
        actor, background = candidate('actor'), candidate('background')
        actor['context_rank_key'] = [True, False] + [True]*7+[None]*11
        background['context_rank_key'] = [True]*9+[None]*11
        background['sources'] = [quote(str(i),str(i)) for i in range(1000)]
        self.assertGreater(candidate_score(actor)['score'],candidate_score(background)['score'])
        self.assertEqual(candidate_score(actor)['source_function_band']['value'],128)

    def test_score_not_derived_from_rank_or_population(self):
        c = candidate()
        c['context_rank_key'] = [False] + [True]*8+[None]*11
        before = candidate_score(c)
        c.update(rank=900,source_rank_position=10**9)
        self.assertEqual(candidate_score(c),before)

    def test_invalid_native_feature_band_is_rejected(self):
        c = candidate()
        c['context_rank_key'] = [0]*9
        with self.assertRaises(ValueError):candidate_score(c)

    def test_v2_diagnostic_arithmetic_remains_explicitly_replayable(self):
        c = candidate()
        score = candidate_score(c,version='terminal-evidence-fit/2')
        self.assertEqual(score['version'],'terminal-evidence-fit/2')
        self.assertIsNone(score['source_function_band'])

    def test_distinct_decision_scopes_are_not_collapsed(self):
        a,b=candidate('a'),candidate('b')
        a['alternative_family']=b['alternative_family']='one-family'
        a['fill']=b['fill']='One wording'
        a['local_decision']['scope']='FOCAL_CONTRIBUTION_ONLY'
        b['local_decision']['scope']='WHOLE_ASSERTION'
        result=dict(task='redaction',readings=[dict(reading=dict(id='r1'),candidates=[a,b])],assessed_candidates=[a,b])
        self.assertEqual(len(annotate_result(result,rerank=True)['readings'][0]['candidates']),2)

    def test_missing_key_or_unverified_attachment_cannot_gain_band(self):
        c=candidate();c.pop('context_rank_key')
        with self.assertRaises(ValueError):candidate_score(c)
        c=candidate();c['focal_visible_attachment_priority']=dict(matched=True,producer_replayed=False)
        with self.assertRaises(ValueError):candidate_score(c)


if __name__ == '__main__':
    unittest.main()
