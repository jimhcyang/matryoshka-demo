"""Select complete, same-epoch native executions without changing their decisions."""
import argparse
from copy import deepcopy
from pathlib import Path

from integrate import HERE, current_reference, pinned, read, ref, write
from code_epochs import current_epoch, native_epoch
from matryoshka_narrative.workflow import code_pins


def collect(result_refs, overrides=(), backgrounds=None):
    backgrounds=backgrounds or {}
    bindings=read(HERE/'publication_refs.json')
    baseline=pinned(bindings['report_ref'])
    old={row['case']['case_id']:row for row in baseline['cases']}
    aliases={row['entry']['case']['case_id']:row['replaces']
             for row in read(HERE/'selected_case_revisions.json')['replacements']
             if 'entry' in row}
    for row in read(HERE/'selected_case_revisions.json')['replacements']:
        if 'entry_ref' in row:
            aliases[pinned(row['entry_ref'])['case']['case_id']]=row['replaces']
    selected={}
    pins=code_pins()
    current_epoch(pins)
    for reference in result_refs:
        result=pinned(reference)
        if result.get('status')!='COMPLETE' or result['completed']!=result['requested']:
            raise ValueError('Every declared native run must complete before selection')
        for row in result['cases']:
            identity=row['case']['case_id']
            replaces=identity if identity in old else aliases.get(identity)
            if replaces not in old or replaces in selected:
                raise ValueError('Unknown or duplicate presentation slot: '+identity)
            selected[replaces]=deepcopy(row)
    for override in overrides:
        if override['replaces'] not in old:
            raise ValueError('Override must name an existing presentation slot')
        selected[override['replaces']]=pinned(override['entry_ref'])
    if set(selected)!=set(old):
        raise ValueError('Exactly sixteen current presentation slots are required')
    proposals=[]
    for replaces,row in selected.items():
        case=row['case']
        if (case['corpus'],case['task'])!=(old[replaces]['case']['corpus'],old[replaces]['case']['task']):
            raise ValueError('Corpus and task must match the presentation slot')
        native_ref=row['outputs']['native_checkpoint']
        packet=pinned(native_ref)
        native_epoch(native_ref,packet,pins)
        if packet['public_case']!=case or packet.get('terminal_stage_replay'):
            raise ValueError('A fresh full native execution of this exact input is required')
        if packet['configuration']['source_view_policy']['id']!='source_day_inclusive':
            raise ValueError('The source boundary must remain unchanged')
        if packet.get('answers_read') or packet.get('grades_read'):
            raise ValueError('Reference-answer contamination is not permitted')
        if case['corpus'] in backgrounds:
            background=backgrounds[case['corpus']]
            if not background.get('text') or not background.get('sources'):
                raise ValueError('A new background requires its source references')
            for source in background['sources']:
                pinned(source['reference'])
            row['narrative_summary']=background['text']
            row['narrative_summary_sources']=deepcopy(background['sources'])
        path=HERE/'reviewed_selections'/native_ref['sha256']/(case['case_id']+'.json')
        write(path,row)
        proposals.append(dict(replaces=replaces,entry_ref=ref(path)))
    value=dict(version='uniform-native-presentation-selection/1',
        previous_report_ref=bindings['report_ref'],result_refs=result_refs,
        replacements=proposals,code_pins=pins,decisions_modified=False)
    current_reference(HERE/'selected_case_revisions.json',value)
    print('SELECTED_UNIFORM_NATIVE_CASES',len(proposals),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',required=True,type=Path)
    args=parser.parse_args()
    manifest=read(args.inputs)
    collect(manifest['result_refs'],manifest.get('overrides',[]),manifest.get('backgrounds'))
