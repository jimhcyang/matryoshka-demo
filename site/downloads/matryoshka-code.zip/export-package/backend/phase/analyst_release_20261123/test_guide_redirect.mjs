import assert from 'node:assert/strict';
import {savedGuideWalkURL} from './stage/site/saved-guide-redirect.js';
let checks=0;const check=fn=>{fn();checks++;};
const row={case:{case_id:'fixture',corpus:'cib'},configurations:{llm_readings:{}},
  resource_binding:{resource_id:'fixture-resource',registry_sha256:'a'.repeat(64),index_sha256:'b'.repeat(64)}};
const quote={canonical_page_id:'p1',document_id:'d1',date:'1959-02-17',start:2,end:7,text:'Exact',page_sha256:'c'.repeat(64)};
const path={id:'path-a',candidate_or_atom_id:'reading/candidate',decision_source_refs:[quote]};
const trace={case_id:'fixture',config:'llm_readings',reading_id:'reading',paths:[path]};
const selection={case_id:'fixture',config:'llm_readings',reading:'reading',candidate_id:'candidate',route_index:'0'};
const base='http://127.0.0.1:8978/matryoshka-demo/graph-full-v6.html?corpus=cib&guide_case=fixture&guide_step=3';
check(()=>{const url=new URL(savedGuideWalkURL(selection,row,trace,base));assert.equal(url.searchParams.get('walk_path'),'path-a');assert.equal(url.searchParams.get('walk_case'),'fixture');assert.equal(url.searchParams.has('guide_case'),false);assert.equal(url.searchParams.has('guide_step'),false);});
for(const candidate of ['candidate','reading/candidate','path-a'])check(()=>assert(new URL(savedGuideWalkURL({...selection,candidate_id:candidate},row,trace,base)).searchParams.get('walk_path')==='path-a'));
for(const change of [{case_id:'other'},{config:'llm_local'},{reading:'other'},{route_index:'1'},{route_index:'-1'},{candidate_id:'missing'}])check(()=>assert.throws(()=>savedGuideWalkURL({...selection,...change},row,trace,base)));
const handoff=base+'&guide_source=p1&guide_start=2&guide_end=7&guide_hash='+quote.page_sha256;
check(()=>{const url=new URL(savedGuideWalkURL(selection,row,trace,handoff));assert.equal(url.searchParams.get('walk_source'),'p1');assert.equal(url.searchParams.get('walk_start'),'2');});
for(const url of [handoff.replace('guide_start=2','guide_start=3'),handoff+'&guide_source=p2',base+'&guide_source=p1'])check(()=>assert.throws(()=>savedGuideWalkURL(selection,row,trace,url)));
console.log(JSON.stringify({checks,passed:checks,paid_calls:0}));
