"""Release review references must resolve only within their declared roots."""
import hashlib
from pathlib import Path
import tempfile

import authorize_release as api


def main():
    original=api.HERE
    with tempfile.TemporaryDirectory() as temporary:
        root=Path(temporary).resolve()
        api.HERE=root/'src-demo-day/phase/release'
        api.HERE.mkdir(parents=True)
        receipt=api.HERE/'receipt.json'
        receipt.write_text('{"status":"PASS"}')
        checksum=hashlib.sha256(receipt.read_bytes()).hexdigest()
        for path in ('phase/release/receipt.json','src-demo-day/phase/release/receipt.json'):
            assert api.pinned(dict(path=path,sha256=checksum))=={'status':'PASS'}
        for path,sha in (('../receipt.json',checksum),(str(receipt),checksum),('phase/release/receipt.json','0'*64)):
            try:api.pinned(dict(path=path,sha256=sha))
            except (ValueError,AssertionError):pass
            else:raise AssertionError('Invalid reference accepted')
    api.HERE=original
    print('RELEASE_REFERENCE_CHECKS_PASS')


if __name__=='__main__':main()
