"""Pin completed runs and presentation-only backgrounds before collection."""
import argparse
from copy import deepcopy
from pathlib import Path

from integrate import HERE, pinned, read, ref, write


IRAN = (
    "In early 1979, Iran's institutions were being pulled in different directions. "
    "Parliamentary approval could give a government a formal mandate, while religious "
    "opposition challenged the legitimacy of the political order. Reports discussed "
    "the Regency Council after the Shah's departure, its chairman's resignation, and "
    "competing claims about which institutions could legitimately govern. After the "
    "revolution, the new government's relationship with revolutionary committees raised "
    "a related problem: holding an office did not necessarily mean controlling the "
    "people who acted in its name. These cases follow the distinction between formal "
    "authority and practical influence. Each question uses its own source date; the "
    "reports describe a developing crisis, not one meeting or coordinated event."
)
VIETNAM = (
    "The ceasefire did not remove military tension from South Vietnam. Cables "
    "described renewed North Vietnamese attacks in eastern Military Region 3 and "
    "heavy activity in the Mekong Delta. A different report discussed attempted "
    "low-level contacts between opposing forces and identified the officer who "
    "confirmed them. An analyst needed to distinguish military pressure from "
    "communication, and a commander's role from evidence of a particular action. "
    "These cases examine those questions at their respective source dates. "
    "Reports from different regions and periods are not accounts of one operation; "
    "each claim needs its own evidence before the pieces can form a wider picture."
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", action="append", type=Path, required=True)
    parser.add_argument("--override", action="append", default=[], help="Existing case ID=absolute entry path")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    bindings = read(HERE / "publication_refs.json")
    report = pinned(bindings["report_ref"])
    book = pinned(bindings["casebook_ref"])
    overrides = []
    for value in args.override:
        identity, name = value.split("=", 1)
        overrides.append(dict(replaces=identity, entry_ref=ref(Path(name))))
    old_ids = {row["case"]["case_id"] for row in report["cases"]}
    aliases = {}
    for row in read(HERE / "selected_case_revisions.json")["replacements"]:
        entry = pinned(row["entry_ref"]) if "entry_ref" in row else row["entry"]
        aliases[entry["case"]["case_id"]] = row["replaces"]
    selected = {}
    references = [ref(path) for path in args.result]
    for reference in references:
        for row in pinned(reference)["cases"]:
            identity = row["case"]["case_id"]
            slot = identity if identity in old_ids else aliases[identity]
            if slot in selected:
                raise ValueError("Duplicate presentation slot")
            selected[slot] = row
    for override in overrides:
        selected[override["replaces"]] = pinned(override["entry_ref"])
    if set(selected) != old_ids:
        raise ValueError("The background must describe the complete selected casebook")
    origins = {corpus: [] for corpus in ("iran", "vietnam")}
    for chosen in selected.values():
        corpus = chosen["case"]["corpus"]
        if corpus not in origins:
            continue
        source = chosen["origin_refs"]["masked"]
        pinned(source)
        origins[corpus].append(dict(kind="SELECTED_QUERY_ORIGIN", reference=source))
    cib = book["backgrounds"]["cib"][0]
    data = dict(result_refs=references, overrides=overrides,
        backgrounds=dict(
            cib=dict(text=cib["historical_setup"], sources=deepcopy(cib["background_sources"])),
            iran=dict(text=IRAN, sources=origins["iran"]),
            vietnam=dict(text=VIETNAM, sources=origins["vietnam"])),
        presentation_only_backgrounds=True, inference_inputs_modified=False)
    write(args.output, data)
    print(ref(args.output))


if __name__ == "__main__":
    main()
