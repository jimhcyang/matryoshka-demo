"""Post-run digest input must replay inspected, eligible native evidence."""
from copy import deepcopy
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'phase/motion_login_20261122/live'))
from test_engine_fixture import fixture
from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy
from matryoshka_narrative.postrun_digest import prepare


def packet():
    corpus, case, plan, found, index = fixture()
    citation = SourcePolicy(corpus, case, index).citation(0, 0, len(corpus.pages[0]['text']))
    result = dict(status='SUPPORTED', inspected_page_ids=['fictional-page'],
                  atoms=[dict(id='a1', text=case['query'], status='SUPPORTED',
                              evidence=[dict(direction='SUPPORT', citation=citation)])])
    native = dict(case=case, plan=plan, result=result, native_checksum=digest(result))
    condition = dict(native_checksum=native['native_checksum'], native_record_sha256=digest(native))
    return native, condition, SimpleNamespace(corpus=corpus, source_index=index)


class DigestTests(unittest.TestCase):
    def test_payload_replays_and_never_changes_native(self):
        native, condition, context = packet()
        prior = deepcopy(native)
        value = prepare(native, condition, context)
        self.assertEqual(native, prior)
        self.assertEqual(value['sources'][0]['text'], native['case']['query'])
        self.assertEqual(value['sources'][0]['id'], 'S1')
        self.assertEqual(value['local_verdict'], 'SUPPORTED')

    def test_scope_identifies_only_the_excluded_origin(self):
        native, condition, context = packet()
        value = prepare(native, condition, context)
        self.assertEqual(value['digest_input_version'], 'source-bound-digest-input/3')
        self.assertEqual(value['evidence_scope']['origin_document_id'], native['case']['document_id'])
        self.assertTrue(value['evidence_scope']['every_listed_source_passed_admission'])
        self.assertTrue(value['evidence_scope']['origin_exclusion_does_not_apply_to_other_documents'])
        self.assertTrue(value['evidence_scope']['source_dates_are_publication_dates_not_automatically_event_dates'])
        self.assertNotEqual(value['sources'][0]['document_id'], value['evidence_scope']['origin_document_id'])

    def test_native_and_condition_bindings_are_required(self):
        native, condition, context = packet()
        for field in ('native_checksum', 'native_record_sha256'):
            with self.subTest(field=field), self.assertRaises(ValueError):
                prepare(native, dict(condition, **{field:'0'*64}), context)

    def test_uninspected_citation_cannot_enter_digest(self):
        native, _, context = packet()
        native['result']['inspected_page_ids'] = []
        native['native_checksum'] = digest(native['result'])
        condition = dict(native_checksum=native['native_checksum'], native_record_sha256=digest(native))
        with self.assertRaisesRegex(ValueError, 'not inspected'):
            prepare(native, condition, context)

    def test_quotation_tampering_and_ineligible_sources_fail(self):
        for mode in ('text', 'date', 'release'):
            native, condition, context = packet()
            if mode == 'text':
                native['result']['atoms'][0]['evidence'][0]['citation']['text'] = 'Invented support.'
                native['native_checksum'] = digest(native['result'])
                condition = dict(native_checksum=native['native_checksum'], native_record_sha256=digest(native))
            elif mode == 'date':
                context.corpus.pages[0]['date'] = native['case']['date']
            else:
                context.corpus.pages[0]['visibility'] = 'later'
            with self.subTest(mode=mode), self.assertRaises((ValueError, KeyError)):
                prepare(native, condition, context)

    def test_candidate_requirements_are_replayed_before_forwarding(self):
        native, _, context = packet()
        proof=deepcopy(native['result']['atoms'][0]['evidence'][0]['citation'])
        proof['canonical_page_id']='uninspected'
        native['result']['readings']=[dict(reading=dict(id='r1'),candidates=[dict(fill='Oren Vale',rank=1,
            local_decision=dict(status='exploratory_contextual',requirements=[dict(id='r',evidence=[dict(citation=proof)])]))])]
        native['native_checksum']=digest(native['result'])
        condition=dict(native_checksum=native['native_checksum'],native_record_sha256=digest(native))
        with self.assertRaisesRegex(ValueError,'not inspected'):
            prepare(native,condition,context)

    def test_score_comparison_trees_are_not_forwarded_as_source_text(self):
        native, _, context = packet()
        native['result']['terminal_scores']=dict(version='test',readings=[],overall={},atoms=[dict(id='a1',score=.5,
            contributions=[dict(citation=dict(text='not a supplied source'))])])
        native['native_checksum']=digest(native['result'])
        condition=dict(native_checksum=native['native_checksum'],native_record_sha256=digest(native))
        value=prepare(native,condition,context)
        self.assertNotIn('contributions',value['scores']['atoms'][0])


if __name__ == '__main__':
    unittest.main(verbosity=2)
