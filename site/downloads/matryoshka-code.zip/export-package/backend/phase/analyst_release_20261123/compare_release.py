"""Compare sealed outputs after execution; never use this in candidate selection."""
from integrate import HERE,pinned,read,ref,write,current_reference


def snapshot(row):
    native=pinned(row['configurations']['llm_readings']['native_checkpoint'])
    result=native['result']
    return dict(status=result['status'],
        atoms=[dict(text=a['text'],status=a['status']) for a in result.get('atoms',[])],
        readings=[dict(id=b['reading']['id'],candidates=[dict(fill=c['fill'],rank=c['rank'],
            status=c.get('local_decision',{}).get('status')) for c in b['candidates']])
            for b in result.get('readings',[])])


def description(value):
    if value['atoms']:
        return value['status']+' ('+', '.join(a['status'] for a in value['atoms'])+')'
    branches=[r for r in value['readings'] if r['candidates']]
    return '; '.join(r['candidates'][0]['fill']+' ['+str(r['candidates'][0]['status'])+']'
                     for r in branches) or value['status']


def main():
    bindings=read(HERE/'publication_refs.json')
    selection=read(HERE/'selected_case_revisions.json')
    before=pinned(selection['previous_report_ref'])
    after=pinned(bindings['report_ref'])
    old={r['case']['case_id']:r for r in before['cases']}
    new={r['case']['case_id']:r for r in after['cases']}
    rows=[]
    lines=['# Sealed Release Comparison','',
        'Changed questions are new demonstrations, not matched accuracy comparisons. ',
        'These are actual local decisions; contextual suggestions are not evidence-backed recoveries.','',
        '| Corpus / Task | Input | Previous Result | New Result |',
        '| --- | --- | --- | --- |']
    clean=lambda value:str(value).replace('|','/').replace('\n',' ')
    for replacement in selection['replacements']:
        prior=old[replacement['replaces']]
        fresh_entry=pinned(replacement['entry_ref'])
        fresh=new[fresh_entry['case']['case_id']]
        a,b=snapshot(prior),snapshot(fresh)
        same=prior['case']['query']==fresh['case']['query']
        row=dict(before_case=prior['case'],after_case=fresh['case'],same_query=same,
                 before=a,after=b,changed=a!=b)
        rows.append(row)
        lines.append('| '+' | '.join(map(clean,[fresh['case']['corpus']+' / '+fresh['case']['task'],
            'Same' if same else 'Replaced',description(a),description(b)]))+' |')
    target=HERE/'regressions'/bindings['report_ref']['sha256'][:24]
    write(target/'comparison.json',dict(rows=rows,previous_report_ref=selection['previous_report_ref'],
        report_ref=bindings['report_ref'],postrun_only=True,answers_or_gold_read=False))
    text=target/'comparison.md';text.write_text('\n'.join(lines)+'\n')
    current_reference(HERE/'regression_comparison_ref.json',ref(target/'comparison.json'))
    print(text)


if __name__=='__main__':main()
