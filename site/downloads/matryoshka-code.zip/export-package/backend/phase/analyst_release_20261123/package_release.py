"""Prepare or install only the new explicitly checked static publication."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

from integrate import HERE,ROOT,REPO,SITE,pinned,read,ref,sha,write
from code_epochs import active_epoch
sys.path.insert(0,str(ROOT/'phase/kg_patch_20261122/release'))
from code_snapshot import unpack,replace,make_zip,tree_sha
sys.path.insert(0,str(REPO/'release-tools/ci'))
import validate_manifest as gate


def save(path,value):
    from matryoshka_next.workflow import put
    return put(path,value)


def study_entry(report,report_ref):
    rows=[r for r in report['cases'] if r.get('study_slot')]
    value=dict(version='delegation-native-workbench/1',source_report_ref=report_ref,gold=None,
        native_results_modified=False,source_view_policy=rows[0]['configurations']['llm_readings']['source_view_policy'],
        cases=[dict(case_id=r['case']['case_id'],position=r['study_slot'],
                    native_checkpoint=r['configurations']['llm_readings']['native_checkpoint']) for r in rows])
    save(SITE/'swedish-study-native.json',value)
    html=(SITE/'swedish-study.html').read_text()
    html=re.sub(r'(<meta name="study-data-sha256"[^>]*content=")[a-f0-9]{64}',
        lambda m:m[1]+sha((SITE/'swedish-study-native.json').read_bytes()),html)
    (SITE/'swedish-study.html').write_text(html)


def bundle():
    old=REPO/'site'
    prior=read(old/'downloads/matryoshka-code-manifest.json')
    files=unpack((old/'downloads/matryoshka-code.zip').read_bytes(),prior)
    if tree_sha(files,prior.get('excluded_corpus_derived_inputs',[]))!=prior['backend_tree_sha256']:
        raise ValueError('Original code archive changed')
    freeze=active_epoch()
    for name,expected in freeze['code_pins'].items():
        raw=(ROOT/name).read_bytes()
        if sha(raw)!=expected:raise ValueError('Engine changed after native freeze: '+name)
        replace(files,'backend/'+name,raw)
    for name in ('test_query_analysis_port.py','test_query_analysis_entities.py',
                 'test_query_analysis_correlative.py','test_narrative_matching.py'):
        path=ROOT/'tests'/name
        if path.exists():replace(files,'backend/tests/'+name,path.read_bytes())
    replace(files,'backend/matryoshka_narrative/postrun_digest.py',(ROOT/'matryoshka_narrative/postrun_digest.py').read_bytes())
    live=ROOT/'phase/motion_login_20261122/live'
    for path in sorted(live.iterdir()):
        if path.suffix in {'.py','.md'} or path.name=='scope-defaults.json':
            replace(files,'backend/phase/motion_login_20261122/live/'+path.name,path.read_bytes())
    replace(files,'backend/scripts/start_live_local.py',(ROOT/'scripts/start_live_local.py').read_bytes())
    for path in sorted(SITE.iterdir()):
        if path.is_file() and path.suffix in {'.html','.js','.css'}:
            replace(files,'interactive/site/'+path.name,path.read_bytes())
    replace(files,'interactive/site/data/live-corpus-scopes.json',(SITE/'data/live-corpus-scopes.json').read_bytes())
    # Select authored executable sources only. No source body, credentials,
    # private state, model attempts, receipts or generated case catalog is added.
    for name in ('integrate.py','package_release.py','code_epochs.py','collect_uniform.py','compare_release.py',
                 'select_revision.py','prepare_selection.py','build_guide.py','audit_selected.py','authorize_release.py',
                 'test_terminal_scores.py','test_digest.py','test_scores_display.mjs',
                 'test_live_policy.mjs','test_live_map_links.mjs','test_saved_scope.mjs','test_guide_redirect.mjs',
                 'test_study_collection.mjs','test_graph_bounds.mjs',
                 'test_canvas_resize.mjs',
                 'test_release_references.py','test_collect_uniform.py','test_code_epochs.py','test_amend.py',
                 'summarize_release.py'):
        replace(files,'backend/phase/analyst_release_20261123/'+name,(HERE/name).read_bytes())
    for path in sorted((HERE/'backend').iterdir()):
        if path.is_file() and path.suffix in {'.py','.md'}:
            replace(files,'backend/phase/analyst_release_20261123/backend/'+path.name,path.read_bytes())
    for name in ('run.py','protocol.py','prepare.py','seal_runner.py','test_protocol.py','inputs.schema.json'):
        path=HERE/'iran_resume/uniform_epoch_v2'/name
        replace(files,'backend/phase/analyst_release_20261123/iran_resume/uniform_epoch_v2/'+name,path.read_bytes())
    for name in ('browser_smoke.py','validate_manifest.py'):
        raw=(REPO/'release-tools/ci'/name).read_bytes()
        replace(files,'ci/'+name,raw)
        replace(files,'installed/release-tools/ci/'+name,raw)
    replace(files,'CODE_BUNDLE_README.md',(HERE/'CODE_SNAPSHOT_README.md').read_bytes())
    replace(files,'installed/README.md',(REPO/'README.md').read_bytes())
    replace(files,'installed/docs/CORPUS_RELEASES.md',(REPO/'docs/CORPUS_RELEASES.md').read_bytes())
    raw,rows=make_zip(files)
    tree=tree_sha(files,prior.get('excluded_corpus_derived_inputs',[]))
    manifest=dict(prior,files=rows,backend_tree_sha256=tree,
        prior_bundle_sha256=sha((old/'downloads/matryoshka-code.zip').read_bytes()),
        original_backend_code_modified=True,native_execution_versions_rewritten=False,
        historical_outputs_modified=False,new_source_policy_and_terminal_scores=True,
        credentials_included=False,private_live_state_included=False)
    (SITE/'downloads/matryoshka-code.zip').write_bytes(raw)
    save(SITE/'downloads/matryoshka-code-manifest.json',manifest)
    return dict(path='downloads/matryoshka-code.zip',sha256=sha(raw),bytes=len(raw),code_only=True,
        manifest_path='downloads/matryoshka-code-manifest.json',
        manifest_sha256=sha((SITE/'downloads/matryoshka-code-manifest.json').read_bytes()),source_backend_tree_sha256=tree)


def prepare():
    refs=read(HERE/'publication_refs.json');export=read(HERE/'export_results.json')
    report=pinned(refs['report_ref'])
    if len(report['cases'])!=16 or export['report_ref']!=refs['report_ref']:
        raise ValueError('The complete selected native publication is required')
    if sha((SITE/'data/report-v6.json').read_bytes())!=refs['report_ref']['sha256']:
        raise ValueError('Published report bytes differ')
    selected_native=[pinned(row['configurations']['llm_readings']['native_checkpoint']) for row in report['cases']]
    replay_count=sum(bool(native.get('terminal_stage_replay')) for native in selected_native)
    saved_plan_count=sum(row.get('exact_saved_plan_replication') is True for row in report['cases'])
    rebound_plan_count=sum(bool(row.get('plan_rebind_ref')) for row in report['cases'])
    study_entry(report,refs['report_ref'])
    index_sha=sha((SITE/'data/api-index.json').read_bytes())
    for path in sorted(SITE.rglob('*.html')):
        text=path.read_text()
        text=re.sub(r'(data-index-sha256=")[a-f0-9]{64}',lambda m:m[1]+index_sha,text)
        if 'source-api-index-sha256' in text:
            text=re.sub(r'(<meta name="source-api-index-sha256"[^>]*content=")[a-f0-9]{64}',lambda m:m[1]+index_sha,text)
        else:
            text=text.replace('</head>',f'<meta name="source-api-index-sha256" content="{index_sha}"></head>')
        if path.name in {'workbench-v6.html','graph-full-v6.html','live.html'}:
            if 'frame-src' in text:
                text=re.sub(r"frame-src [^;\"]+", "frame-src 'self' blob:",text)
            else:text=text.replace("object-src 'none';","object-src 'none'; frame-src 'self' blob:;")
        path.write_text(text)
    if (SITE/'release-manifest.json').exists():
        original=(SITE/'release-manifest.json').read_bytes()
        history=HERE/'prepared-history'/sha(original);history.mkdir(parents=True,exist_ok=True)
        target=history/'release-manifest.json'
        if target.exists() and target.read_bytes()!=original:raise ValueError('Manifest archive collision')
        target.write_bytes(original)
        (SITE/'release-manifest.json').unlink()
    prior_lineage=read(REPO/'site/export-lineage.json')
    lineage=dict(version='analyst-native-static-export/1',source_report_ref=refs['report_ref'],casebook_ref=refs['casebook_ref'],digest_ref=None,
        field_guide=pinned(read(HERE/'field_guide_binding_ref.json')),publish_authorized=False,
        privacy_approval_inherited=False,release_qualified=False,
        graph_delivery=prior_lineage['graph_delivery'],dataset_delivery_ref=prior_lineage['dataset_delivery_ref'],
        pdf_catalog_ref=report['pdf_catalog_ref'],prior_source_report_ref=refs['prior_report_ref'],
        historical_source_packets_modified=False,static_export_API_calls=0,
        coverage=export['coverage'],source_day_and_terminal_release=dict(version='analyst-release/1',
            historical_results_unchanged=True,selected_native_executions=len(selected_native),
            full_native_executions=len(selected_native)-replay_count,terminal_stage_replays=replay_count,
            ordinary_query_plans_reused=saved_plan_count,old_plans_conservatively_rebound=rebound_plan_count,
            source_policy='source_day_inclusive',scoring='terminal-evidence-fit/3',
            terminal_stage_replay=bool(replay_count),research_accuracy_claimed=False,
            delegation_reference_unknown=True,case_qualification_inherited=False))
    lineage['code_bundle']=bundle()
    lineage['backend_code_sha256']=lineage['code_bundle']['source_backend_tree_sha256']
    save(SITE/'export-lineage.json',lineage)
    publication=read(SITE/'publication.json')
    publication.update(source_report_ref=refs['report_ref'],casebook_ref=refs['casebook_ref'],digest_ref=None,
        backend_code_sha256=lineage['backend_code_sha256'],publish_authorized=False,
        privacy_approval_inherited=False,release_qualified=False,
        source_day_and_terminal_release=lineage['source_day_and_terminal_release'])
    publication['files']=[r for r in gate.inventory(SITE) if r['path']!='publication.json']
    save(SITE/'publication.json',publication)
    for path in SITE.rglob('*.html'):gate.Dependencies(SITE,path).feed(path.read_text())
    manifest=gate.make(SITE,lineage)
    save(HERE/'prepared.json',dict(version='analyst-release-prepared/1',
        manifest_sha256=sha((SITE/'release-manifest.json').read_bytes()),source_report_ref=manifest['source_report_ref'],
        source_data_index_sha256=manifest['api_index']['sha256'],backend_tree_sha256=manifest['backend_snapshot']['tree_sha256'],
        expected_installed_manifest_sha256=sha((REPO/'site/release-manifest.json').read_bytes()),
        case_ids=manifest['case_ids'],datasets_copied=False))
    print('PREPARED',len(manifest['case_ids']),len(manifest['files']))


def install(approval_ref=None):
    import fcntl
    with (REPO/'.graph-refresh.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        install_locked(approval_ref)


def install_locked(approval_ref=None):
    prepared=read(HERE/'prepared.json')
    if sha((SITE/'release-manifest.json').read_bytes())!=prepared['manifest_sha256']:
        raise ValueError('The checked manifest changed')
    approval_ref=(approval_ref or HERE/'release-approval/approval_ref.json').resolve()
    if not approval_ref.is_relative_to(HERE):raise ValueError('Unrelated authorization path')
    gate.authorize(SITE,approval_ref)
    baseline=prepared['expected_installed_manifest_sha256']
    if sha((REPO/'site/release-manifest.json').read_bytes())!=baseline:
        raise ValueError('Installed release changed during preparation')
    for path in SITE.rglob('*'):
        if path.is_file():
            target=REPO/'site'/path.relative_to(SITE)
            if not target.exists() or sha(target.read_bytes())!=sha(path.read_bytes()):
                target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,target)
    for path in approval_ref.parent.iterdir():
        if path.is_file():shutil.copyfile(path,REPO/'release'/path.name)
    print('INSTALLED_EXACT_AUTHORIZED_ANALYST_RELEASE')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['prepare','install'])
    parser.add_argument('--approval-ref',type=Path)
    args=parser.parse_args()
    if args.action=='prepare':
        if args.approval_ref:parser.error('--approval-ref applies only to install')
        prepare()
    else:install(args.approval_ref)
