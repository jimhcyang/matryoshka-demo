"""Exercise publication replacement bookkeeping without touching the active stage."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile

import integrate as api


def main():
    original=api.HERE
    bindings=api.read(original/'publication_refs.json')
    report=api.pinned(bindings['report_ref'])
    old_bytes=(api.ROOT/bindings['report_ref']['path']).read_bytes()
    examples=[next(r for r in report['cases'] if r['case']['corpus']=='iran' and r['case']['task']=='mosaic'),
              next(r for r in report['cases'] if r.get('study_slot'))]
    for old in examples:
        fresh={k:deepcopy(old[k]) for k in ('case','origin_refs','query_kind','presentation_title') if k in old}
        fresh['presentation_title']='Verified replacement bookkeeping'
        fresh['outputs']=deepcopy(old['configurations']['llm_readings'])
        fresh['narrative_summary']='A source-bound narrative summary used only by this bookkeeping test.'
        fresh['narrative_summary_sources']=[dict(kind='SELECTED_QUERY_ORIGIN',reference=deepcopy(old['origin_refs']['masked']))]
        fresh['exact_saved_plan_replication']=False
        fresh['new_full_native_execution']=True
        fresh['parent_native_ref']=deepcopy(fresh['outputs']['native_checkpoint'])
        with tempfile.TemporaryDirectory(dir=original/'qa') as temporary:
            api.HERE=Path(temporary)
            api.write(api.HERE/'publication_refs.json',bindings)
            api.write(api.HERE/'selected_case_revisions.json',dict(replacements=[dict(replaces=old['case']['case_id'],entry=fresh)]))
            api.amend_report()
            current=api.read(api.HERE/'publication_refs.json')
            updated=api.pinned(current['report_ref']);book=api.pinned(current['casebook_ref'])
            assert len(updated['cases'])==16 and len(book['primary'])==9
            assert len(book['special_redactions'])==5
            row=next(r for r in updated['cases'] if r['case']['case_id']==old['case']['case_id'])
            assert row['presentation_title']==fresh['presentation_title']
            assert row['case']==old['case'] and row['origin_refs']==old['origin_refs']
            assert row['configurations']['llm_readings']['native_checkpoint']==fresh['outputs']['native_checkpoint']
            assert row['exact_saved_plan_replication'] is False
            assert row['new_full_native_execution'] is True
            assert row['parent_native_ref']==fresh['parent_native_ref']
            assert row['presentation_caveats']==old.get('presentation_caveats',[])
            assert 'showcase_review' not in row
            assert book['source_report_ref']==current['report_ref']
            assert current['export_map_index_sha256']==api.sha((api.REPO/'site/data/api-index.json').read_bytes())
            assert current['export_map_release_manifest_sha256']==api.sha((api.REPO/'site/release-manifest.json').read_bytes())
            assert all(s['public_case']==e['case'] for s,e in zip(book['requested_primary_slots'],book['primary']))
            if old.get('study_slot'):
                assert row['study_slot']==old['study_slot']
                assert row['study_companion_case_id']==old['study_companion_case_id']
            assert (api.ROOT/bindings['report_ref']['path']).read_bytes()==old_bytes
    api.HERE=original
    print('AMEND_BOOKKEEPING_PASS')


if __name__=='__main__':main()
