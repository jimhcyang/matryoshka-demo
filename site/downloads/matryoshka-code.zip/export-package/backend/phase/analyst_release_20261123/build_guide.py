"""Render a compact public guide bound to the actual selected native results."""
import hashlib
import io
import json
from pathlib import Path
import textwrap

from integrate import HERE,ROOT,SITE,pinned,read,ref,write

SECTIONS = [
    ('Matryoshka: Source To Decision',
     'Read the input and its local verdict first. Facts express the requirements of the input, not historical conclusions. Follow a selected source, inspect its exact quotation and original document, then compare the evidence with the final decision. The model digest is a separate summary written after the deterministic local result has been sealed.'),
    ('The Evidence Boundary',
     'The active saved experiments admit eligible documents dated on or before the input source date. CIB admits the earlier release of the originating document, but not its later release. Iran and Vietnam use CONFIDENTIAL evidence and exclude the entire originating SECRET cable; a document-wide NOFORN restriction remains a veto. Later PDFs may be inspected as originals, but inspection does not admit their contents as evidence. Historical results retain their original policy and are not relabeled.'),
    ('Facts And Retrieval',
     'The initial query-only model call extracts the visible input and splits it into facts. Redaction additionally has grammatical slot readings. Local search matches these facts to eligible source pages and source-grounded graph states; there is no whole-query lookup. Each displayed lookup identifies the fact, executed search and selected source it actually matched. A shared document does not prove that every fact matched.'),
    ('Graph Navigation',
     'Facts to evidence shows retained source matches and their exact endpoints. Compact view hides facts without a retained connection; it does not discard evidence. Zoom and pan change the display only. View on KG navigates the existing corpus map, using actual source-backed connections and hierarchy membership. A post-run inspection path is not represented as the original search chronology or as a chain of historical entailment. Community membership is navigation, not evidence that an event occurred.'),
    ('Evidence Accumulation',
     'All three tasks use the same document-deduplicated evidence calculation within each fact or candidate. A page at saved retrieval rank r has weight w(r) = 0.5 + 0.5/(1 + log2(r)); an unrecorded rank receives 0.5. Multiply that weight by the applicable recorded evidence fit. Within each unit and direction, keep the largest contribution per document, then sum distinct-document contributions. Support, opposition and context stay separate. Repeating a passage or citing another page of the same document does not create another contribution to that unit. Overall totals add fact-wise indices, not independent document votes: one document may address several different facts.'),
    ('Final Redaction Score',
     'Final redaction ranking preserves evidence sufficiency first and source-owned function priorities next. Nine existing source/function checks form a binary band B: a satisfied check at position i contributes 2^(8-i). A verified visible-role attachment, when the selected constructor declares it, contributes another 512. These are actual source features, not candidate positions. Fit F combines owned relation (0.32), owned role (0.16), source type (0.16), focal overlap (up to 0.16) and a literal visible-context anchor (0.20). With document-deduplicated S, O and C, compute u=(S+F+0.5C)/(1+O) and score=T+(B+u/(1+u))/1024. T is 2 for evidence-backed, 1 for partial grounding with an established requirement, otherwise 0. Evidence quantity cannot outweigh a higher source-function band or create support. Source position breaks exact ties; repeated surface/family alternatives are collapsed. The banded score is not a probability or a confidence margin.'),
    ('Hypothesis And Mosaic Scores',
     'Each fact shows its support, opposition and context sums. Hypothesis net evidence is S - O; the signed sums remain visible so conflict is not hidden by cancellation. Mosaic also shows the fraction of applicable recorded criteria that passed. A complete source-owned certificate may establish a fact even with a numerical score below 1. Conversely, a large relevance or context score cannot establish it. These are deterministic evidence indices, not calibrated probabilities or cross-case confidence estimates. The logical decision gates are not relaxed to manufacture a supported answer.'),
    ('Inspecting Sources',
     'Click a quotation to open the full available transcription at its exact highlighted span. Highlight coordinates replay against the source text and hash; repeated words are not guessed. CIB offers both original PDF releases at recorded physical pages after the text. Click an input redaction to reveal a supplied reference, and click again to remask it. A still-withheld reference remains unknown. Reference reveals and later originals are inspection material, never model answer inputs.'),
    ('Live Analysis',
     'Live uses the same query-only planning, local evidence processing and final scoring contract, with a bounded interactive search: 16 documents, 32 passages, 8 construction pages and 12 completed drafts per reading. These limits can yield different results from the larger saved experiments. Leave the source document blank for an analyst-authored input. The date defaults to the last eligible corpus day; its displayed inclusive date is converted to an exclusive next-day engine boundary exactly once. A private authenticated backend holds the OpenAI key and enforces the spending limit. The static website contains no provider credential. The final digest cannot change the saved local decision. Completed public result envelopes can be reopened from the current browser tab without another model call; passwords and session tokens are not stored with them.'),
    ('Visiting Delegation: Context Comparison',
     'Five paragraph-window pairs were attempted for the two authentic still-withheld delegation slots. Nine inputs produced valid executions; the last input in the full five-paragraph pair did not pass the visible-text planning contract. The nine completed viable pools did not contain Swedish or Swedes. One shorter first-gap input nominated Swedish, but it did not clear the recorded construction checks. This is a diagnostic of the suggested spelling, not measured correctness: no historical answer key is available. The final workbench uses the preferred P1+P3+P4 context for both gaps, without the final Swedes paragraph. The earlier release of the 17 February 1959 origin is eligible; its later text is not retrieved evidence.'),
]


def pdf(blocks):
    pages=[]
    lines=[]
    for title,body in blocks:
        needed=3+len(textwrap.wrap(body,92))
        if lines and len(lines)+min(needed,18)>43:
            pages.append(lines);lines=[]
        lines.extend([(title,True),('',False)])
        for line in textwrap.wrap(body,92,replace_whitespace=False):
            if len(lines)>=43:pages.append(lines);lines=[]
            lines.append((line,False))
        lines.append(('',False))
    if lines:pages.append(lines)
    objects=[b'<< /Type /Catalog /Pages 2 0 R >>',b'',
        b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
        b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>']
    page_ids=[]
    for number,items in enumerate(pages,1):
        cmds=['0.97 0.98 0.97 rg 0 0 612 792 re f','0.10 0.28 0.30 rg 0 714 612 78 re f',
              '1 1 1 rg BT /F2 20 Tf 1 0 0 1 42 747 Tm (Matryoshka / Evidence Guide) Tj ET']
        for i,(text,bold) in enumerate(items):
            literal=text.replace('\\','\\\\').replace('(','\\(').replace(')','\\)')
            cmds.append(f'0.10 0.20 0.23 rg BT /F{2 if bold else 1} {13 if bold else 10.5} Tf 1 0 0 1 42 {684-i*14} Tm ({literal}) Tj ET')
        cmds.append(f'0.30 0.40 0.42 rg BT /F1 9 Tf 1 0 0 1 42 28 Tm (23 November 2026 / {number}) Tj ET')
        content=('\n'.join(cmds)+'\n').encode('cp1252','replace');stream=len(objects)+1
        objects.append(b'<< /Length '+str(len(content)).encode()+b' >>\nstream\n'+content+b'endstream')
        page_ids.append(len(objects)+1)
        objects.append(f'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents {stream} 0 R >>'.encode())
    objects[1]=f'<< /Type /Pages /Count {len(pages)} /Kids [{" ".join(str(n)+" 0 R" for n in page_ids)}] >>'.encode()
    out=io.BytesIO();out.write(b'%PDF-1.4\n');offsets=[0]
    for i,raw in enumerate(objects,1):offsets.append(out.tell());out.write(f'{i} 0 obj\n'.encode()+raw+b'\nendobj\n')
    xref=out.tell();out.write(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:out.write(f'{offset:010d} 00000 n \n'.encode())
    out.write(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    return out.getvalue(),len(pages)


def main():
    refs=read(HERE/'publication_refs.json');report=pinned(refs['report_ref'])
    blocks=list(SECTIONS);cases=[]
    for row in report['cases']:
        native=pinned(row['configurations']['llm_readings']['native_checkpoint'])
        result=native['result'];title=row.get('presentation_title',row['case']['task'].title())
        label={'SUPPORTED':'Supported by eligible evidence','OPPOSED':'Opposed by eligible evidence',
            'EVIDENCE_BACKED_RECONSTRUCTION':'Evidence-backed mosaic',
            'CANDIDATE_SUGGESTIONS':'Ranked source-grounded suggestions'}.get(result['status'],result['status'].replace('_',' ').lower())
        text='Input: '+row['case']['query']+'\nLocal result: '+label+'. '
        if row['case']['task']=='redaction':
            for branch in result.get('readings',[]):
                if branch['candidates']:
                    def display_score(candidate):
                        score=candidate.get('terminal_scorecard',{}).get('score',0)
                        return f'{score:.2e}' if score and abs(score)<.005 else f'{score:.2f}'
                    def support_label(candidate):
                        return {'evidence_backed_suggestion':'evidence-backed','partial_grounding':'partial grounding',
                            'exploratory_contextual':'contextual'}.get(candidate['local_decision']['status'],'unresolved')
                    text+='Candidates: '+'; '.join(f'{c["rank"]}. {c["fill"]} ({display_score(c)}, {support_label(c)})' for c in branch['candidates'])+'. '
                    break
        else:
            text+='Facts: '+'; '.join(a['text']+' - '+a['status'].replace('_',' ').lower() for a in result.get('atoms',[]))+'. '
        if row.get('study_slot'):text+='The reference remains withheld; candidate rank is not an exact-recovery measurement. '
        text+='Evidence source date: '+row['case']['date']+'.'
        blocks.append((row['case']['corpus'].upper()+' / '+title,text))
        cases.append(dict(case_id=row['case']['case_id'],corpus=row['case']['corpus'],task=row['case']['task'],
            query_utf8_sha256=hashlib.sha256(row['case']['query'].encode()).hexdigest(),local_status=result['status']))
    from matryoshka_demo.io import digest
    target=HERE/'guide'/digest(dict(report=refs['report_ref'],blocks=blocks))[:24];target.mkdir(parents=True,exist_ok=True)
    raw,count=pdf(blocks)
    text=('\n\n'.join(title+'\n'+body for title,body in blocks)+'\n').encode()
    for name,data in [('field-guide.pdf',raw),('field-guide.txt',text)]:
        path=target/name
        if path.exists() and path.read_bytes()!=data:raise ValueError('Immutable guide bytes changed')
        if not path.exists():path.write_bytes(data)
    files={name:hashlib.sha256((target/name).read_bytes()).hexdigest() for name in ('field-guide.pdf','field-guide.txt')}
    write(target/'guide-public.json',dict(version='evidence-field-guide/1',mode='saved_report_snapshot',
        report_byte_sha256=refs['report_ref']['sha256'],files=files,cases=cases))
    assets=[]
    for source,destination in [('field-guide.pdf','matryoshka-guide.pdf'),('field-guide.txt','matryoshka-guide.txt'),('guide-public.json','guide-public.json')]:
        path=target/source;raw=path.read_bytes()
        assets.append(dict(target='docs/'+destination,source_ref=ref(path),public_sha256=hashlib.sha256(raw).hexdigest()))
    binding=dict(version='source-bound-field-guide/1',source_report_ref=refs['report_ref'],assets=assets,
        guide_public_ref=ref(target/'guide-public.json'),source_mode='saved_report_snapshot',pdf_pages=count,
        cases=[r['case_id'] for r in cases],publication_qualification_inferred=False,bytes_modified=False)
    write(target/'binding.json',binding)
    for item in assets:
        (SITE/item['target']).write_bytes((ROOT/item['source_ref']['path']).read_bytes())
    for name in ('interactive-release.pdf','interactive-release.txt'):
        (SITE/'docs'/name).write_bytes((target/('field-guide.pdf' if name.endswith('.pdf') else 'field-guide.txt')).read_bytes())
    from matryoshka_next.workflow import put
    put(HERE/'field_guide_binding_ref.json',ref(target/'binding.json'))
    print('GUIDE_READY',count,len(cases))


if __name__=='__main__':main()
