"""Record an explicitly reviewed handoff entry without changing its result."""
import argparse
from copy import deepcopy
from pathlib import Path
import re

from integrate import HERE, ROOT, current_reference, pinned, read, ref, write


def select(handoff, expected_sha, field, case_id, replaces):
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,200}", case_id):
        raise ValueError("Unsafe case identifier")
    handoff = handoff.resolve()
    if not handoff.is_relative_to(HERE):
        raise ValueError("Handoff must belong to this release")
    source_ref = ref(handoff)
    if source_ref["sha256"] != expected_sha:
        raise ValueError("Reviewed handoff bytes changed")
    source = pinned(source_ref)
    entries = [source] if field is None else source[field]
    matches = [row for row in entries if row["case"]["case_id"] == case_id]
    if len(matches) != 1:
        raise ValueError("Exactly one reviewed entry is required")
    entry = deepcopy(matches[0])
    native = pinned(entry["outputs"]["native_checkpoint"])
    if native["public_case"] != entry["case"] or native["answers_read"] or native["grades_read"]:
        raise ValueError("Unbound or answer-assisted native execution")
    report = pinned(read(HERE / "publication_refs.json")["report_ref"])
    old = [row for row in report["cases"] if row["case"]["case_id"] == replaces]
    if len(old) != 1 or any(old[0]["case"][k] != entry["case"][k] for k in ("task", "corpus")):
        raise ValueError("Replacement must preserve the selected corpus/task slot")
    directory = HERE / "reviewed_selections" / source_ref["sha256"]
    target = directory / (case_id + ".json")
    write(target, entry)
    selection_path = HERE / "selected_case_revisions.json"
    selection = read(selection_path) if selection_path.exists() else dict(version="reviewed-revisions/1", replacements=[])
    if any(row["replaces"] == replaces for row in selection["replacements"]):
        raise ValueError("This slot already has an explicit selection")
    selection["replacements"].append(dict(replaces=replaces, entry_ref=ref(target),
        reviewed_handoff_ref=source_ref, native_status=native["result"]["status"]))
    current_reference(selection_path, selection)
    print("SELECTED", case_id, "FOR", replaces, "STATUS", native["result"]["status"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--handoff", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--field", default="qualified_cases")
    group.add_argument("--single-entry", action="store_true")
    parser.add_argument("--case-id", required=True)
    parser.add_argument("--replaces", required=True)
    args = parser.parse_args()
    select(args.handoff, args.sha256, None if args.single_entry else args.field, args.case_id, args.replaces)
