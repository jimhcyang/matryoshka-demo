"""Seal only the independently checked minimal coordination-parser delta."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PHASE = HERE.parent
sys.path.insert(0, str(PHASE))
from integrate import ROOT, current_reference, pinned, read, ref, write
from matryoshka_demo.io import digest
from matryoshka_narrative.workflow import code_pins


def main():
    parent_ref = dict(path="phase/analyst_release_20261123/backend/BACKEND_FROZEN_ANALYSIS3.json",
        sha256="5d8e1894d682673ef17b2649baeabef4e9a0cdfbc4f1cdcf598cbfd06745208c")
    parent = pinned(parent_ref)
    review_ref = ref(PHASE / "diagnostics/both_review/POST_PORT_CHECK_V01.json")
    review = pinned(review_ref)
    handoff_ref = ref(PHASE / "frame_probe/correlative_port/POST_PORT_HANDOFF.json")
    handoff = pinned(handoff_ref)
    expected = "fb1683efadadf75b7c2d673a798b26e8ea28e8702c2947162d73211868167e7c"
    name = "matryoshka_narrative/query_analysis.py"
    pins = code_pins()
    changed = {key for key in pins if pins[key] != parent["code_pins"].get(key)}
    assert pins.keys() == parent["code_pins"].keys() and changed == {name}
    assert pins[name] == expected == review["actual_production"]["sha256"]
    assert review["status"] == "PASS_EXACT_POST_PORT" and review["byte_identical"]
    assert not review["new_false_positives_in_checked_delta"]
    assert handoff["production_query_analysis_sha256"] == expected
    assert handoff["regression"] == dict(tests=417, failures=0, errors=0, skipped=0)
    result = deepcopy(parent)
    result.update(created_utc=datetime.now(timezone.utc).isoformat(),
        parent_backend_freeze=parent_ref, code_pins=pins, code_pins_digest=digest(pins),
        changed_modules=[name], native_code_unchanged_from_parent=False,
        correlative_original_parse_retention=True, correlative_post_port_review=review_ref,
        correlative_port_handoff=handoff_ref,
        preserved_baseline_scope_failures=review["preserved_baseline_failures"],
        general_negative_controls_pass=False,
        selected_positive_scope_audit_required=True,
        uniform_inputs=ref(PHASE / "iran_resume/uniform_epoch_v2/provisional_inputs_v3.json"))
    path = HERE / "BACKEND_FROZEN_ANALYSIS4.json"
    write(path, result)
    current_reference(HERE / "ACTIVE_CODE_EPOCH.json", ref(path))
    print(ref(path))


if __name__ == "__main__":
    main()
