# Backend Interface (Implementation Under Test)

No native execution while backend edits/tests continue. BACKEND_FROZEN is a separate explicit handoff.

```python
from matryoshka_demo.source_view_policy import (
    STRICT_PRIOR, SOURCE_DAY_INCLUSIVE, LIVE_BEFORE_WITH_EARLIER_ORIGIN,
    apply_source_view, descriptor, packet_policy,
)

packet = session.execute(
    public_case, exact_saved_native_plan,
    readings_packet=exact_saved_readings_packet,
    source_view_policy=SOURCE_DAY_INCLUSIVE,
    terminal_ranking="evidence_fit_v1",
    # Same original method/passage/document/construction/draft/profile budgets.
)
policy = packet_policy(packet)  # Verifies result/configuration declarations agree.
view_context = apply_source_view(context, packet["configuration"]["source_view_policy"])
```

Policy is an enum supplied by trusted execution, not a public query field, date shift or document-ID substitution. Strings are rejected by execution. Configuration stores the full canonical descriptor with version/id/date relation/cutoff role/origin rules. The result repeats it inside the native checksum. Cache keys bind it, optional terminal ranking and current code pins including `terminal_scores.py`.

- STRICT_PRIOR (default): `< case.date`, whole origin excluded for all corpora.
- SOURCE_DAY_INCLUSIVE: `<= case.date`; CIB admits source-document EARLIER/BOTH pages, not later/SECRET. Cables still exclude their entire origin and require CONFIDENTIAL with document-wide NOFORN veto. Saved case date must equal its pinned original source date when known.
- LIVE_BEFORE_WITH_EARLIER_ORIGIN: `< canonical request.as_of` (already exclusive), with CIB EARLIER-origin admission. Never add another day. Canonical Live verifier/request schema stays unchanged.

`apply_source_view` is shallow: shared corpus arrays and actual immutable source index are referenced, not rebuilt/copied. Viewer uses it only after selecting the exact native and checking policy binding. Missing policy metadata on historical packets means strict policy. Callers must retain native byte/checksum verification; this helper is not a query-controlled policy switch.

Terminal ranking defaults to None: no scoring import/call or candidate-order change. Opt-in annotation runs after normal execution and before checksum/sealing. It uses postfiltered native viable candidates, not rejected source proposals. The regression runner retains full native pools and baseline order without changing terminal scoring code.

Execution plan: exact saved baseline 14 remains historical control; strict atom-only retrieval is mechanically compared for all 14; real full new inclusive/scored construction runs once per case with the original budgets and exact saved plans/readings, API0. Missing source/index/plan errors remain explicit; no baseline outcome or qualification is inherited.
