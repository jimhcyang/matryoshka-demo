"""Retry the unchanged frozen terminal run into a new immutable output epoch."""
from pathlib import Path
import shutil
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import run_final
from run_regression import ref
from matryoshka_next.workflow import put_immutable


def main():
    if shutil.disk_usage(HERE).free < 11*1024**3:
        raise OSError('Retry requires room for the unchanged 8 GiB guard plus a warm source context')
    output=HERE/'final_retry1'
    selected=HERE.parent/'delegation/final_retry1'
    if output.exists() or selected.exists():
        raise ValueError('Retry epoch already exists; inspect it rather than overwrite')
    put_immutable(output/'retry_authority.json',dict(version='output-only-terminal-retry/1',
        previous_failed_manifest=ref(HERE/'final/results.json'),
        frozen_engine=ref(HERE/'BACKEND_FROZEN_FINAL.json'),
        runner=ref(HERE/'run_final.py'),wrapper=ref(Path(__file__)),
        overrides=dict(ordinary_output='backend/final_retry1',selected_output='delegation/final_retry1'),
        query_config_source_code_and_gate_changes=False,api_calls=0))
    run_final.OUT=output
    run_final.DELEGATION=selected
    run_final.main()


if __name__=='__main__':main()
