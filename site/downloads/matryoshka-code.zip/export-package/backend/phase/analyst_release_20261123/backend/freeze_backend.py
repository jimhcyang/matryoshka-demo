"""Seal the tested backend/interface before any native regression execution."""
import hashlib
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT))
from matryoshka_demo.io import digest,offline
from matryoshka_next.workflow import put_immutable
from matryoshka_narrative.workflow import code_pins
from matryoshka_demo.source_view_policy import SourceViewPolicy,descriptor


def ref(path):
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    tests=ET.parse(HERE/'frozen-tests.xml').getroot()
    suites=list(tests.iter('testsuite'))
    assert sum(int(s.get('tests',0)) for s in suites)==270
    assert all(int(s.get('failures',0))==int(s.get('errors',0))==0 for s in suites)
    assert shutil.disk_usage(HERE).free>=8*1024**3
    with offline():
        pins=code_pins()
        result=dict(status='BACKEND_FROZEN',version='analyst-release-backend-freeze/1',
            code_pins=pins,code_pins_digest=digest(pins),
            interface=ref(HERE/'INTERFACE.md'),tests=ref(HERE/'frozen-tests.xml'),tests_passed=270,
            regression_runner=ref(HERE/'run_regression.py'),baseline_catalog=ref(HERE/'baseline_catalog.json'),
            source_policy_descriptors={p.value:descriptor(p) for p in SourceViewPolicy},
            terminal_scoring=ref(ROOT/'matryoshka_narrative/terminal_scores.py'),
            native_runs_before_freeze=0,api_calls=0,engine_edits_after_freeze_forbidden=True,
            execution_plan='Saved exact baseline14; strict atom-only retrieval control; full fresh inclusive/scored14; no baseline constructor reruns',
            fresh_native_qualification_inherited=False,original_packets_modified=False,
            actual_indexes_reused_not_copied=True,free_gib=shutil.disk_usage(HERE).free/1024**3)
        pin=put_immutable(HERE/'BACKEND_FROZEN.json',result)
        print('BACKEND_FROZEN',pin['sha256'])
        print('CODE_PINS_DIGEST',result['code_pins_digest'])
        print('TERMINAL_SCORING',result['terminal_scoring']['sha256'])


if __name__=='__main__':main()
