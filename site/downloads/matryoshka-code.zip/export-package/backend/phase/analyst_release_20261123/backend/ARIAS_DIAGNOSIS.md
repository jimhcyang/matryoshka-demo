# Arias Regression Diagnosis

This is a saved-output diagnostic, not a qualification or a proposed named-case repair.
Engine pins remain those of BACKEND_FROZEN.json; no engine edits during native work.

- Historical and current strict atom-only retrieval have the identical complete
  saved source order. All eight executed query texts are identical, already
  atom-only in the historical packet. Removing whole-query fallback did not
  remove Panama/de la Guardia search atoms in this case.
- Inclusive admission adds 19 eligible CIB pages. The origin page
  `page_ecb0ea5ca13ba08d0d4d` becomes retrieval rank1 and replaces one page in
  the bounded 32-page inspected set. The earlier Arias source remains inspected:
  `page_f4e91be8f65a8efcc32b`, CIA-RDP79T00975A003600250001-4,
  1958-03-29, earlier page14, quote454:705, candidate name623:654.
- Three Arias wordings remain in the fresh postfiltered viable pool. The full
  wording is fifth in the new pre-terminal order, but absent from the scored
  displayed five. The pool did not lose this source or this candidate.
- The historical selection cue is helper1.7; current is1.12. On the same quoted
  source, historical `source_owned_role_context` matched common-word
  `politico` to `politician`; current matching reports no match. A fixed-old-pool
  scoring result therefore does not establish behavior on the newly executed
  pool. These historical/current comparisons are not pure policy ablations.
- Current frozen scoring gives the old full-wording candidate0.3673823 and
  the new candidate0.2438241: source-owned role contributes0.2 vs0.0, fit0.45
  vs0.25. The new Colonel Monzon candidate scores0.2518768. Every candidate
  here remains exploratory/contextual, with no substantive support promotion.

Exact candidate features, primary occurrence cues and citations are retained in
`arias_score_diagnostic.json`; packet/control references are in
`regression_progress.json` and `baseline_catalog.json`.

## Recommendation

Finish the bounded real experiment with unchanged pins. Do not automatically
adopt its new ranking or claim broad improvement. Keep source-policy opt-in and
legacy/default terminal_ranking=None available. Any additional native strict vs
inclusive construction ablation requires a separately authorized, pinned run;
the cheap strict retrieval control alone cannot isolate constructor-version effects.

If a later generic ranking experiment is authorized, evaluate source-owned
visible actor/geographic anchors and context consistency across all cases, as
soft fit only. Do not reintroduce the old lexical match or named boosts just to
recover Arias. No such repair has been made in this frozen backend.
