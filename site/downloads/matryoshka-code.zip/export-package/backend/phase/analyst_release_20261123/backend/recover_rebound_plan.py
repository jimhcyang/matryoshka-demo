"""One auditable derived-plan recovery; the original 14-attempt record is immutable."""
from copy import deepcopy
import hashlib
from pathlib import Path
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from matryoshka_demo.io import digest, offline
from matryoshka_narrative import workflow, planning
from matryoshka_narrative.contracts import engine_case
from matryoshka_next.workflow import read, put_immutable
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, apply_source_view
from run_regression import ref, load_pinned, options, orders, source_audit, export, retrieval_control
from matryoshka_narrative.retrieval import retrieve


def checked_rebind(entry, audit):
    old = load_pinned(entry["baseline_native"])
    base = deepcopy(old["plan"])
    selected = base.pop("readings_packet", None)
    rebound = deepcopy(audit["rebound_plan"])
    if audit["original_valid"] or not audit["rebound_valid"] or not audit["original_raw_model_response_recovered"]:
        raise ValueError("Recovery requires an explicitly invalid original and its exact retained model response")
    if digest(base) != audit["original_plan_sha256"] or digest(rebound) != audit["rebound_plan_sha256"]:
        raise ValueError("Original/rebound plan bytes changed")
    for reference in audit["saved_raw_refs"]:
        load_pinned(reference)
    if (base["atoms"] != rebound["atoms"] or base["receipt"] != rebound["receipt"]
            or base["projection_qc"] != rebound["projection_qc"]
            or base["raw_output_sha256"] != rebound["raw_output_sha256"]):
        raise ValueError("Original atoms, model provenance or projection losses changed")
    if not audit["differences"] or any(not d["path"].endswith("/contains_unknown_slot")
            or d["before"] is not False or d["after"] is not True for d in audit["differences"]):
        raise ValueError("Unreviewed non-conservative derived-plan change")
    planning.validate_plan(rebound, engine_case(entry["case"]))
    return old, rebound, selected


def main():
    freeze = read(HERE / "BACKEND_FROZEN.json")
    recovery = read(HERE / "RECOVERY_FROZEN.json")
    if ref(HERE / "BACKEND_FROZEN.json") != recovery["backend_freeze"]:
        raise ValueError("Original backend freeze changed")
    if ref(Path(__file__)) != recovery["runner"] or workflow.code_pins() != freeze["code_pins"]:
        raise ValueError("Recovery runner or frozen engine changed")
    if ref(HERE / "run_regression.py") != freeze["regression_runner"]:
        raise ValueError("Shared exact-14 helper changed")
    if ref(HERE / "plan_compatibility.json") != recovery["compatibility"]:
        raise ValueError("Reviewed rebind audit changed")
    previous = read(HERE / "regression_results.json")
    if previous["completed"] != 14:
        raise ValueError("Do not run a second large native context alongside the original batch")
    catalog = read(HERE / "baseline_catalog.json")
    audits = [r for r in read(HERE / "plan_compatibility.json")["cases"] if not r["original_valid"]]
    if len(audits) != 1:
        raise ValueError("This bounded recovery covers exactly the one reviewed failure")
    audit = audits[0]
    entry = next(e for e in catalog["cases"] if e["case"]["case_id"] == audit["case_id"])
    failed = next(r for r in previous["cases"] if r["case"]["case_id"] == audit["case_id"])
    if failed["status"] != "ERROR" or failed["error"] != "Derived query annotation changed":
        raise ValueError("Recovery no longer matches the preserved original failure")
    if shutil.disk_usage(HERE).free < 3 * 1024**3:
        raise OSError("Agreed 3 GiB floor; canonical workflow independently retains its 8 GiB guard")
    workflow.OUTPUT = HERE / "execution"
    with offline(), workflow.Session() as session:
        old, base, selected = checked_rebind(entry, audit)
        opts = options(entry["configuration"])
        settings = workflow.configuration(**opts, source_view_policy=SOURCE_DAY_INCLUSIVE,
            terminal_ranking="evidence_fit_v1")
        full_plan = deepcopy(base)
        full_plan["readings_packet"] = deepcopy(selected)
        key = digest(dict(version="analyst-release-reviewed-derived-plan/1", case=entry["case"],
            original_plan_sha256=entry["original_plan_sha256"], new_plan_sha256=digest(full_plan),
            configuration=settings, recovery_freeze=ref(HERE / "RECOVERY_FROZEN.json")))
        directory = HERE / "rebound_runs" / key
        rebind = dict(audit, historical_baseline_native=entry["baseline_native"],
            exact_saved_plan_replication=False, exact_saved_raw_output_rebound=True,
            original_failed_attempt=failed, queries_or_readings_changed=False)
        put_immutable(directory / "plan_rebind.json", rebind)
        context = session.context(entry["case"]["corpus"])
        if old["binding"] != session.refs["index_refs"][entry["case"]["corpus"]]:
            raise ValueError("Normal native source index differs from historical binding")
        strict = retrieve(context.corpus, old["case"], full_plan, source_index=context.source_index,
            method=opts["method"], passage_budget=opts["passage_budget"],
            document_budget=opts["document_budget"], discovery_profile=opts.get("discovery_profile"))
        control = retrieval_control(old, strict)
        control["derived_plan_rebind_ref"] = ref(directory / "plan_rebind.json")
        put_immutable(directory / "strict_atomic_retrieval.json.gz", control)
        del strict
        target = directory / "native.json.gz"
        expected = dict(pins=freeze["code_pins"], binding=session.refs["index_refs"][entry["case"]["corpus"]],
            environment=session.environment, settings=settings)
        begin = time.perf_counter()
        if target.exists():
            packet = read(target)
            workflow.validate_packet(packet, entry["case"], base, selected, **expected)
            if read(target.with_name("completion.json")) != workflow._completion(target, packet, key):
                raise ValueError("Recovered completion seal changed")
        else:
            packet = session.execute(entry["case"], base, readings_packet=selected, **opts,
                source_view_policy=SOURCE_DAY_INCLUSIVE, terminal_ranking="evidence_fit_v1")
            workflow.validate_packet(packet, entry["case"], base, selected, **expected)
            put_immutable(target, packet)
            put_immutable(target.with_name("completion.json"), workflow._completion(target, packet, key))
        native_ref = ref(target)
        scoped = apply_source_view(context, settings["source_view_policy"])
        put_immutable(directory / "source_audit.json", source_audit(packet, scoped))
        put_immutable(directory / "candidate_pools.json.gz", dict(
            scope="POSTFILTERED_NATIVE_VIABLE_ONLY_NOT_REJECTED_PROPOSALS",
            baseline_native=entry["baseline_native"], baseline_order=entry["baseline_order"],
            baseline_pool=old["result"].get("assessed_candidates", []), new_native=native_ref,
            new_pool=packet["result"].get("assessed_candidates", []),
            pre_terminal_candidate_order=packet["result"].get("pre_terminal_candidate_order", []),
            new_display_order=orders(packet["result"]), support_or_pool_membership_relabelled=False))
        output = export(packet, native_ref, context, directory)
        output["plan_rebind_ref"] = ref(directory / "plan_rebind.json")
        row = dict(case=entry["case"], status="NATIVE_COMPLETE_REVIEW_PENDING", api_calls=0,
            native_status=packet["result"]["status"], baseline_native_status=entry["baseline_status"],
            native_ref=native_ref, configuration=packet["configuration"], outputs=output,
            source_audit=ref(directory / "source_audit.json"),
            candidate_pools_ref=ref(directory / "candidate_pools.json.gz"),
            strict_atomic_control_ref=ref(directory / "strict_atomic_retrieval.json.gz"),
            strict_atomic_order_unchanged=control["identical_order"], baseline_order=entry["baseline_order"],
            new_order=orders(packet["result"]), qualification_inherited=False,
            exact_saved_plan_replication=False, plan_rebind_ref=ref(directory / "plan_rebind.json"),
            wall_seconds=time.perf_counter() - begin)
        put_immutable(HERE / "recovered_case.json", row)
        rows = [row if r["case"]["case_id"] == audit["case_id"] else r for r in previous["cases"]]
        final = dict(previous, status="COMPLETE" if all(r["status"] != "ERROR" for r in rows)
            else "COMPLETE_WITH_EXPLICIT_ERRORS", cases=rows,
            original_batch=ref(HERE / "regression_results.json"),
            recovery_freeze=ref(HERE / "RECOVERY_FROZEN.json"),
            plan_rebind_cases=[audit["case_id"]], exact_saved_plan_cases=13,
            interpretation="13 original plans plus one exact retained-raw-output rebind with three conservative unknown-mask annotations. "
                "All are actual fresh executions; no old qualification inherited.")
        put_immutable(HERE / "final_regression_results.json", final)
        print("RECOVERED_NATIVE_READY", entry["case"]["case_id"], native_ref["path"], flush=True)


if __name__ == "__main__":
    main()
