"""Final 14+2 terminal-stage execution; no parent/native constructor relabelling."""
from copy import deepcopy
import gc
from pathlib import Path
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'final'
DELEGATION = HERE.parent / 'delegation'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from matryoshka_demo.io import digest, offline
from matryoshka_next.workflow import read, put, put_immutable
from matryoshka_narrative import workflow, presentation
from matryoshka_narrative.traces import build_trace
from matryoshka_demo.source_view_policy import apply_source_view
from run_regression import ref, load_pinned, orders, source_audit


def final_export(packet, native_ref, context, directory):
    scoped = apply_source_view(context, packet['configuration']['source_view_policy'])
    condition = presentation.display_record(packet, native_ref, scoped, config='llm_readings')
    condition_path = directory / 'condition.json.gz'
    put_immutable(condition_path, condition)
    trace_refs = {}
    branches = packet['result'].get('readings', []) if packet['public_task'] == 'redaction' else [None]
    for branch in branches:
        result = deepcopy(packet['result'])
        identity = 'assertions'
        if branch is not None:
            identity = branch['reading']['id']
            result['readings'] = [deepcopy(branch)]
            result['candidates'] = deepcopy(branch['candidates'])
        trace = build_trace(scoped.corpus, packet['case'], packet['plan'], result, packet['retrieval'],
            {p['id']: p for p in scoped.corpus.pages}, postrun_graph=True)
        trace.update(query_sha256=digest(packet['public_case']['query']),
            reading_id='' if branch is None else identity, config='llm_readings',
            native_checkpoint=deepcopy(native_ref), resource_binding=deepcopy(condition['resource_binding']))
        trace.pop('sha256', None)
        trace['sha256'] = digest(trace)
        path = directory / ('trace_' + identity + '.json.gz')
        put_immutable(path, trace)
        trace_refs['' if branch is None else identity] = ref(path)
    return dict(condition_ref=ref(condition_path), trace_refs=trace_refs,
        resource_binding=deepcopy(condition['resource_binding']), config='llm_readings',
        native_checkpoint=deepcopy(native_ref), run_id=condition['configurations']['llm_readings']['run_id'])


def verify_viewer_outputs(packet, outputs):
    from matryoshka_narrative.server import Viewer
    viewer = Viewer.__new__(Viewer)
    viewer.root = ROOT
    row = dict(case=packet['public_case'], resource_binding=outputs['resource_binding'])
    for reading in outputs['trace_refs']:
        trace = viewer.trace(row, 'llm_readings', outputs, packet, reading)
        flow = viewer.saved_flow(row, 'llm_readings', outputs, packet,
            dict(reading=[reading], limit=['512']))
        if flow['trace'] != trace or flow['query_sha256'] != digest(packet['public_case']['query']):
            raise ValueError('Normal Viewer trace/flow query binding changed')
    return dict(status='PASS', trace_readings=len(outputs['trace_refs']), api_calls=0,
        scope='NORMAL_VIEWER_TRACE_AND_SAVED_FLOW_ONLY_NOT_FULL_SITE_QA')


def main():
    freeze = read(HERE / 'BACKEND_FROZEN_FINAL.json')
    if freeze['status'] != 'BACKEND_FROZEN' or workflow.code_pins() != freeze['code_pins']:
        raise ValueError('Final worker is not on its explicitly frozen code')
    if ref(Path(__file__)) != freeze['final_runner']:
        raise ValueError('Final runner pin changed')
    for dependency in freeze['runner_dependencies']:
        if ref(ROOT / dependency['path']) != dependency:
            raise ValueError('Final helper changed')
    epoch2_freeze = load_pinned(freeze['parent_backend_freeze'])
    ordinary = load_pinned(freeze['ordinary_parent_manifest'])
    selected = load_pinned(freeze['selected_parent_manifest'])
    if ordinary['completed'] != 14 or len(selected['cases']) != 2:
        raise ValueError('Exactly fourteen ordinary and two selected parents required')
    if selected['frozen_backend'] != freeze['parent_backend_freeze']:
        raise ValueError('Delegation parents use another backend freeze')
    work = [dict(kind='ordinary', original=r, case=r['case'], parent=r['native_ref']) for r in ordinary['cases']]
    work += [dict(kind='selected', original=r, case=r['case'], parent=r['outputs']['native_checkpoint'])
        for r in selected['cases']]
    if len({w['case']['case_id'] for w in work}) != 16:
        raise ValueError('Duplicate final public case identity')
    workflow.OUTPUT = OUT / 'execution'
    rows, active = {}, {}

    def progress():
        put(OUT / 'progress.json', dict(status='RUNNING', requested=16, completed=len(rows),
            current=deepcopy(active), cases=list(rows.values()), api_calls=0,
            frozen_backend=ref(HERE / 'BACKEND_FROZEN_FINAL.json'), constructor_reexecuted=False))

    with offline():
        for corpus_id in ['cib', 'iran', 'vietnam']:
            with workflow.Session() as session:
                packet = context = scoped = None
                for item in [w for w in work if w['case']['corpus'] == corpus_id]:
                    case = item['case']
                    target = None
                    begin = time.perf_counter()
                    active.clear()
                    active.update(case_id=case['case_id'], stage='verifying_parent_and_terminal_execution')
                    progress()
                    try:
                        key = digest(dict(version='final-native-terminal-stage/1', parent=item['parent'],
                            terminal_ranking='evidence_fit_v3', final_freeze=ref(HERE / 'BACKEND_FROZEN_FINAL.json')))
                        directory = OUT / 'runs' / key
                        target = directory / 'native.json.gz'
                        if target.exists():
                            parent = load_pinned(item['parent'])
                            packet = read(target)
                            base = deepcopy(parent['plan'])
                            selected_readings = base.pop('readings_packet', None)
                            workflow.validate_packet(packet, case, base, selected_readings,
                                pins=freeze['code_pins'], binding=session.refs['index_refs'][corpus_id],
                                environment=session.environment,
                                settings=dict(parent['configuration'], terminal_ranking='evidence_fit_v3'))
                            if (read(target.with_name('completion.json')) != workflow._completion(target, packet, key)
                                    or packet['terminal_stage_replay']['parent_checkpoint'] != item['parent']
                                    or workflow._restore_terminal_prefix(packet['result'])
                                        != workflow._restore_terminal_prefix(parent['result'])):
                                raise ValueError('Final terminal-stage cache or parent binding changed')
                        else:
                            packet = session.replay_terminal(item['parent'],
                                trusted_parent_pins=epoch2_freeze['code_pins'])
                            put_immutable(target, packet)
                            put_immutable(target.with_name('completion.json'), workflow._completion(target, packet, key))
                        native_ref = ref(target)
                        active['stage'] = 'fresh_source_audit_and_viewer_exports'
                        progress()
                        context = session.context(corpus_id)
                        scoped = apply_source_view(context, packet['configuration']['source_view_policy'])
                        workflow._terminal_source_replay(packet, scoped)
                        audit = source_audit(packet, scoped)
                        audit['terminal_prefix_source_replay'] = deepcopy(packet['terminal_stage_replay']['source_audit'])
                        put_immutable(directory / 'source_audit.json', audit)
                        put_immutable(directory / 'candidate_pools.json.gz', dict(parent_native=item['parent'],
                            native_ref=native_ref, assessed_candidates=packet['result'].get('assessed_candidates', []),
                            pre_terminal_candidate_order=packet['result'].get('pre_terminal_candidate_order', []),
                            final_order=orders(packet['result']), new_candidates_constructed=False,
                            source_or_sufficiency_overrides=False))
                        outputs = final_export(packet, native_ref, context, directory)
                        put_immutable(directory / 'normal_viewer_audit.json', verify_viewer_outputs(packet, outputs))
                        row = dict(item['original'], case=case, status='NATIVE_COMPLETE_REVIEW_PENDING',
                            native_ref=native_ref, native_status=packet['result']['status'],
                            configuration=packet['configuration'], outputs=outputs,
                            source_audit=ref(directory / 'source_audit.json'),
                            source_audit_ref=ref(directory / 'source_audit.json'),
                            candidate_pools_ref=ref(directory / 'candidate_pools.json.gz'),
                            candidate_pool_ref=ref(directory / 'candidate_pools.json.gz'),
                            completion_ref=ref(target.with_name('completion.json')),
                            normal_viewer_api0_receipt_ref=ref(directory / 'normal_viewer_audit.json'),
                            parent_native_ref=deepcopy(item['parent']), terminal_stage_replay=True,
                            stage_reuse=deepcopy(packet['terminal_stage_replay']),
                            new_order=orders(packet['result']), orders=orders(packet['result']),
                            terminal_ranking='evidence_fit_v3', terminal_epoch='FINAL_V3',
                            final_terminal_replay_required=False, qualification_inherited=False,
                            cached_new_execution=False,
                            constructor_reexecuted=False, whole_fresh_constructor_run=False, api_calls=0)
                        print('FINAL_TERMINAL_READY', case['case_id'], native_ref['path'], flush=True)
                    except Exception as error:
                        row = dict(case=case, status='ERROR', error_type=type(error).__name__, error=str(error),
                            traceback=traceback.format_exc(), parent_native_ref=item['parent'],
                            native_ref=ref(target) if target is not None and target.exists() else None,
                            api_calls=0, qualification_inherited=False, failed_stage=active['stage'])
                        print('FINAL_EXPLICIT_ERROR', case['case_id'], str(error), flush=True)
                    row['wall_seconds'] = time.perf_counter() - begin
                    rows[case['case_id']] = row
                    progress()
                    if workflow.code_pins() != freeze['code_pins']:
                        raise ValueError('Final engine drift; preserve checkpoints and stop')
            del session
            packet = context = scoped = None
            gc.collect()
    ordinary_rows = [rows[w['case']['case_id']] for w in work if w['kind'] == 'ordinary']
    selected_rows = [rows[w['case']['case_id']] for w in work if w['kind'] == 'selected']
    result = dict(status='COMPLETE' if all(r['status'] != 'ERROR' for r in ordinary_rows)
        else 'COMPLETE_WITH_EXPLICIT_ERRORS', requested=14, completed=len(ordinary_rows), cases=ordinary_rows,
        api_calls=0, frozen_backend=ref(HERE / 'BACKEND_FROZEN_FINAL.json'),
        terminal_ranking='evidence_fit_v3', terminal_stage_actually_executed=True,
        constructor_reexecuted=False, whole_fresh_constructor_run=False,
        ordinary_parent_manifest=freeze['ordinary_parent_manifest'], original_packets_modified=False,
        qualified_new_cases=[], scientific_case_qualification=False)
    put_immutable(OUT / 'results.json', result)
    selected_result = dict(selected, cases=selected_rows,
        status='COMPLETE' if all(r['status'] != 'ERROR' for r in selected_rows) else 'COMPLETE_WITH_EXPLICIT_ERRORS',
        frozen_backend=ref(HERE / 'BACKEND_FROZEN_FINAL.json'), terminal_ranking='evidence_fit_v3',
        final_terminal_replay_required=False, final_terminal_stage_actually_executed=True,
        parent_selection_manifest=freeze['selected_parent_manifest'],
        constructor_reexecuted=False, whole_fresh_constructor_run=False, scientific_case_qualification=False)
    put_immutable(DELEGATION / 'selected_cases.json', selected_result)
    active.clear()
    put(OUT / 'progress.json', dict(status='COMPLETE' if all(r['status'] != 'ERROR' for r in rows.values())
        else 'COMPLETE_WITH_EXPLICIT_ERRORS', completed=16, requested=16, cases=list(rows.values()),
        api_calls=0, frozen_backend=ref(HERE / 'BACKEND_FROZEN_FINAL.json')))
    print('FINAL_DONE', result['status'], selected_result['status'], flush=True)


if __name__ == '__main__':
    main()
