"""Pin the published 14 controls without reading their reference answers."""
from copy import deepcopy
import hashlib
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT))
from matryoshka_demo.io import digest
from matryoshka_next.workflow import read,put_immutable


def ref(path):
    return dict(root='src-demo-day',path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def candidates(result):
    return [dict(reading_id=r['reading']['id'],order=[dict(id=c['id'],fill=c['fill'],rank=c['rank'],
        native_status=c.get('local_decision',{}).get('status'),support=c.get('support_assessment')) for c in r['candidates']])
        for r in result.get('readings',[])]


def main():
    report_path=ROOT.parent/'matryoshka_demo_site/site/data/report-v6.json'
    report=read(report_path)
    assert len(report['cases'])==14
    public_fields={'case_id','corpus','task','query','document_id','date','focal_marker'}
    cases=[]
    for row in report['cases']:
        case={k:deepcopy(row['case'][k]) for k in public_fields}
        native_ref=deepcopy(row['configurations']['llm_readings']['native_checkpoint'])
        native_path=ROOT/native_ref['path'];assert hashlib.sha256(native_path.read_bytes()).hexdigest()==native_ref['sha256']
        native=read(native_path)
        assert native['public_case']==case and native['native_checksum']==digest(native['result'])
        plan=deepcopy(native['plan']);readings=plan.pop('readings_packet',None)
        cases.append(dict(case=case,baseline_native=native_ref,baseline_status=native['result']['status'],
            configuration=deepcopy(native['configuration']),binding=deepcopy(native['binding']),
            original_plan_sha256=digest(native['plan']),base_plan_sha256=digest(plan),
            reading_packet_sha256=digest(readings),baseline_order=candidates(native['result'])))
    baseline=dict(version='analyst-release-exact-14-baseline/1',
        report=dict(root='IARPA',path=str(report_path.relative_to(ROOT.parent)),sha256=hashlib.sha256(report_path.read_bytes()).hexdigest()),
        cases=cases,ordinary_planning_API_calls=0,reference_answers_or_assessment_labels_used=False,
        historical_packets_modified=False)
    put_immutable(HERE/'baseline_catalog.json',baseline)
    print('BASELINE_PINNED',len(cases))
    for row in cases:
        print(row['case']['case_id'],row['case']['task'],row['configuration'])


if __name__=='__main__':main()
