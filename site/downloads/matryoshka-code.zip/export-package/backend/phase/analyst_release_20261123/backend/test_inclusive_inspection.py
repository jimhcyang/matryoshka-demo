"""Scoped reader/guide checks against the existing real index implementation."""
from copy import deepcopy
from pathlib import Path
import sys

import pytest

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from test_current_inspection import context  # noqa: F401, synthetic index, built under scoped pytest temp.
from matryoshka_current import inspection
from matryoshka_demo.io import digest,offline
from matryoshka_demo.source_view_policy import (
    STRICT_PRIOR,SOURCE_DAY_INCLUSIVE,LIVE_BEFORE_WITH_EARLIER_ORIGIN,
    apply_source_view,descriptor,policy_of)
from matryoshka_narrative.traces import build_trace,guide_packet


@pytest.fixture(autouse=True)
def no_network():
    with offline():yield


def query(date='1962-06-01'):
    return dict(case_id='scoped_synthetic',task='hypothesis',corpus='cib',document_id='doc',date=date,
        query='Mira Soren met the board.',focal_marker='')


def test_reader_same_origin_earlier_view_only_and_no_corpus_rebuild(context):
    scoped=apply_source_view(context,descriptor(SOURCE_DAY_INCLUSIVE))
    assert scoped.corpus.pages is context.corpus.pages
    assert scoped.index is context.index
    assert policy_of(context.corpus) is STRICT_PRIOR
    result=inspection.source(scoped,query(),'page')
    assert result['source_view_policy']==descriptor(SOURCE_DAY_INCLUSIVE)
    assert result['whole_origin_excluded'] is None
    assert [p['id'] for p in result['document_pages']]==['page','page2']
    assert all(p['visibility']=='earlier' and p['document_id']=='doc' for p in result['document_pages'])
    node=inspection.node(scoped,query(),'entity')
    assert node['edges'] and node['scope']['date_relation']=='<='
    with pytest.raises(ValueError):inspection.source(context,query(),'page')


def test_live_exclusive_as_of_does_not_admit_one_extra_day(context):
    scoped=apply_source_view(context,descriptor(LIVE_BEFORE_WITH_EARLIER_ORIGIN))
    result=inspection.source(scoped,query('1962-06-02'),'page')
    assert result['source_view_policy']['date_relation']=='<'
    assert result['date']=='1962-06-01'
    with pytest.raises(ValueError):inspection.source(scoped,query('1962-06-01'),'page')


def test_trace_and_all_native_guide_phases_keep_inclusive_source_scope(context):
    c=query();scoped=apply_source_view(context,descriptor(SOURCE_DAY_INCLUSIVE))
    page=next(p for p in scoped.corpus.pages if p['id']=='page')
    ref=dict(canonical_page_id='page',document_id='doc',date=c['date'],start=0,end=len(page['text']),
        text=page['text'],page_sha256=page['source_sha256'])
    plan=dict(query_sha256=digest(c['query']),atoms=[dict(id='a1',text=c['query'],kind='proposition',required=True)])
    result=dict(task='hypothesis',status='SUPPORT',source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE),
        atoms=[dict(id='a1',text=c['query'],kind='proposition',required=True,status='SUPPORT',
            evidence=[dict(direction='SUPPORT',citation=ref)])],inspected_page_ids=['page'])
    receipt=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE),source_edges=[],search_queries=[])
    trace=build_trace(context.corpus,c,plan,result,receipt,{'page':page})
    guide=guide_packet(trace,trace['paths'][0]['id'],context)
    assert guide['scope']['whole_origin_excluded'] is None
    assert guide['scope']['strictly_before'] is None
    assert guide['scope']['source_view_policy']==descriptor(SOURCE_DAY_INCLUSIVE)
    for phase in ['start_community','start_connections']:
        assert inspection.guide_view(scoped,c,guide,dict(phase=phase))
    assert inspection.guide_view(scoped,c,guide,dict(phase='source',source_id='page'))
    for phase in ['relation','target_reveal','target_connections','target_community']:
        with pytest.raises(ValueError):inspection.guide_view(scoped,c,guide,dict(phase=phase))
    altered=deepcopy(guide);altered['scope']['source_view_policy']=descriptor(STRICT_PRIOR)
    with pytest.raises(ValueError):inspection.guide_view(scoped,c,altered,dict(phase='target_reveal'))


def test_viewer_context_uses_verified_packet_policy_without_mutating_base(context,monkeypatch):
    from matryoshka_narrative.server import Viewer
    from matryoshka_next import workflow
    viewer=Viewer.__new__(Viewer);viewer.root=context.corpus.workspace/'src-demo-day';viewer.contexts={'cib':context}
    monkeypatch.setattr(workflow,'read',lambda path:dict(index_refs={'cib':context.index_ref},registry_ref=context.registry_ref))
    packet=dict(case=query(),binding=context.index_ref,
        configuration=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE)),
        result=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE)))
    selected=viewer.context(packet)
    assert selected.corpus.pages is context.corpus.pages
    assert policy_of(selected.corpus) is SOURCE_DAY_INCLUSIVE
    assert policy_of(context.corpus) is STRICT_PRIOR
    packet['configuration']['source_view_policy']=descriptor(STRICT_PRIOR)
    with pytest.raises(ValueError):viewer.context(packet)
