# Backend Epoch 2

Epoch 1 freeze, four ordinary sealed outputs, two failures, delegation outputs,
original native packets and original runner remain immutable. Epoch 2 requires
`BACKEND_FROZEN_EPOCH2.json` and fresh worker processes; no epoch-1 native is an
epoch-2 result. Neither epoch inherits historical qualification.

```python
from matryoshka_demo.source_view_policy import (
    SOURCE_DAY_INCLUSIVE, LIVE_BEFORE_WITH_EARLIER_ORIGIN,
    apply_source_view, packet_policy,
)

packet = session.execute(
    public_case, validated_native_plan, readings_packet=saved_readings,
    source_view_policy=SOURCE_DAY_INCLUSIVE,
    terminal_ranking="evidence_fit_v2",
    # Exact original per-case method and retrieval/construction/draft/profile budgets.
)
policy = packet_policy(packet)
view_context = apply_source_view(context, packet["configuration"]["source_view_policy"])
```

Both workflow entry points now bind the corpus AND real source index together.
Independent retained historical-role and reconstruction certificates therefore
inherit the typed scope; no quote/date/origin/handling guard is bypassed.

Policy enums/descriptors are unchanged from the original interface. Strict is
still default. Historical source-day opt-in means `<= case.date`; CIB permits
only EARLIER/BOTH origin pages, never later/SECRET. Cables remain CONFIDENTIAL,
whole-origin excluded, with complete-document NOFORN veto. Live must explicitly
use `LIVE_BEFORE_WITH_EARLIER_ORIGIN`, `< canonical request.as_of` with no added
day and unchanged original source IDs/dates.

Terminal ranking defaults to None. New runs opt into `evidence_fit_v2`, not v1;
the exact validated plan is passed to the frozen scorer. V2 fit is .32 owned
relation + .16 owned role + .16 kind + .16 focal overlap + .20 literal visible
query-anchor cooccurrence. Anchor fit is context only, never action support.
Within-unit document deduplication is not a cross-fact vote-count claim.

The ordinary-14 runner uses 13 saved plans byte-for-byte. One saved Diem plan
requires rebinding its EXACT retained original model output: three neighboring
unknown-mask flags change false to true. Atoms, source spans, raw model hash,
receipt, projection-loss records and readings remain identical. That case gets
an explicit plan_rebind_ref and a new derived-plan identity, never an exact-plan
replication label. Unknown incompatibilities still fail; validation is not weakened.

Run `backend/run_regression_epoch2.py` only after the explicit epoch-2 freeze.
Outputs/progress are under `backend/epoch2/`. Every case receives real strict
atom-only retrieval control and one new inclusive/scored native construction.
Full viable pools, pre-score order, native seals, condition/trace refs, source
audits and failures are retained. API0; actual normal-engine indexes only.

Arias and Aung Gyi diagnostics are not qualification: in epoch 1 both prior
source pages survive inspection. Current helper/constructor versions differ
from the historical packets, so this experiment is not a clean policy-only
construction ablation. Do not automatically adopt new order or support labels.

Storage floor is 3 GiB. The unchanged canonical workflow additionally enforces
its older 8 GiB headroom guard; an 8 GiB stop must be reported, not hidden.
