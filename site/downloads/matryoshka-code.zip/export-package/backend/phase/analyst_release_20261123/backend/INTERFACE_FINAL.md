# Trusted Final Terminal Stage

Final execution is new v3 terminal arithmetic on a validated sealed native
prefix. It is NOT a new whole retrieval/construction run. No prior native,
plan, source text, source ID/date, graph edge, gate or classification is edited.

`Session.replay_terminal(parent_ref, trusted_parent_pins=epoch2_pins)` verifies
the exact checkpoint byte hash, full completion seal/native checksum, seven-field
public case, validated plan/readings, canonical configuration, environment and
actual current resource binding. Every nonterminal code pin must be identical.
Only workflow.py and terminal_scores.py may differ; the helper is inside the
pinned workflow.py, not an unpinned runtime adapter.

Saved pre_terminal_candidate_order restores selections only from the complete
postfiltered assessed_candidates pool. Missing/duplicate/foreign IDs and rejected
candidates fail closed. Source/raw citation replay validates every inspected
page and all complete viable-pool/fact references against the actual normal
source index, trusted policy and full-document handling veto. The new scorer
runs locally; prefix normalization must prove all nonterminal content unchanged.

Each new packet/configuration/checksum/run identity declares evidence_fit_v3,
its exact parent, parent pins/configuration/timings, semantic-prefix digest,
reused stages, source audit and actually executed terminal stage. Independent
sufficiency decisions are reused, never promoted by a score. V2 explicit
execution uses terminal-evidence-fit/2; the unscored default remains None.

Fresh conditions and traces refer to the new checkpoint. Every final trace gets
the exact public query_sha256 before its new seal. Actual normal Viewer.trace
and saved_flow methods check the generated outputs. Graph links remain postrun
inspection, not newly invented original retrieval chronology.

Inputs: epoch2/regression_results.json (14) and
delegation/selected_cases_epoch2.json (2), both pinned in BACKEND_FROZEN_FINAL.json.
Outputs: backend/final/results.json (ordinary14), and the explicitly requested
delegation/selected_cases.json (2). Per-case errors retain any sealed native
checkpoint; no historical qualification or unknown Swedish answer is inferred.

The failed 32-page floor remains immutable. No selection profile or constructor
guard is changed. Optional uniform draft64 expansion requires a separate actual
construction run; terminal replay cannot expand an unchecked candidate pool.
