"""Frozen, API0 exact-14 reruns; historical control is never rewritten."""
from copy import deepcopy
import gc
import hashlib
from pathlib import Path
import shutil
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT))
from matryoshka_demo.io import digest,offline
from matryoshka_next.workflow import read,put,put_immutable
from matryoshka_narrative import workflow,presentation
from matryoshka_narrative.retrieval import retrieve
from matryoshka_narrative.traces import build_trace
from matryoshka_next.facts import SourcePolicy
from matryoshka_demo.source_view_policy import (
    SOURCE_DAY_INCLUSIVE,descriptor,apply_source_view,packet_policy)


def ref(path):
    return dict(path=str(path.relative_to(ROOT)),sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def load_pinned(reference):
    path=ROOT/reference['path']
    if ref(path)!=reference:raise ValueError('Saved artifact bytes changed: '+reference['path'])
    return read(path)


def options(config):
    result=dict(method=config['method'],passage_budget=config['retrieval_passage_budget'],
        document_budget=config['retrieval_document_budget'],construction_pages=config['construction_pages'],
        draft_budget=config['completed_drafts_per_reading'])
    for name in ['selection_profile','discovery_profile']:
        if name in config:result[name]=deepcopy(config[name])
    if config['top_k']!=5:raise ValueError('Do not silently change an original candidate budget')
    return result


def orders(result):
    return [dict(reading_id=r['reading']['id'],candidates=[dict(id=c['id'],fill=c['fill'],rank=c['rank'],
        native_status=c.get('local_decision',{}).get('status'),support=c.get('support_assessment'),
        terminal_scorecard=c.get('terminal_scorecard')) for c in r['candidates']]) for r in result.get('readings',[])]


def retrieval_control(old,actual):
    before=[p['page_id'] for p in old['retrieval'].get('top_sources',[])]
    after=[p['page_id'] for p in actual['receipt'].get('top_sources',[])]
    return dict(control='REAL_STRICT_ATOM_ONLY_RETRIEVAL_NOT_CONSTRUCTION',api_calls=0,
        saved_order=before,strict_atomic_order=after,identical_order=before==after,
        new_pages=[p for p in after if p not in before],lost_pages=[p for p in before if p not in after],
        complete_new_receipt=deepcopy(actual['receipt']),baseline_native_unchanged=True)


def source_audit(packet,context):
    policy=SourcePolicy(context.corpus,packet['case'],context.source_index)
    positions={p['id']:i for i,p in enumerate(context.corpus.pages)}
    for pid in packet['result']['inspected_page_ids']:
        if pid not in positions or not policy.allowed(positions[pid]):
            raise ValueError('Actual inspected source is missing or violates the explicit new policy: '+pid)
    return dict(status='PASS',inspected_pages=len(packet['result']['inspected_page_ids']),
        policy=descriptor(packet_policy(packet)),later_or_secret_admitted=False,
        whole_cable_origin_excluded=True,cable_document_wide_veto=True)


def export(packet,native_ref,context,directory):
    scoped=apply_source_view(context,packet['configuration']['source_view_policy'])
    condition=presentation.display_record(packet,native_ref,scoped,config='llm_readings')
    condition_path=directory/'condition.json.gz';put_immutable(condition_path,condition)
    trace_refs={}
    branches=packet['result'].get('readings',[]) if packet['public_case']['task']=='redaction' else [None]
    for branch in branches:
        result=deepcopy(packet['result'])
        identity='assertions'
        if branch is not None:
            identity=branch['reading']['id'];result['readings']=[deepcopy(branch)]
            result['candidates']=deepcopy(branch['candidates'])
        trace=build_trace(scoped.corpus,packet['case'],packet['plan'],result,packet['retrieval'],
            scoped.source_index if isinstance(scoped.source_index,dict) else
                {p['id']:p for p in scoped.corpus.pages},postrun_graph=True)
        trace.update(reading_id='' if branch is None else identity,config='llm_readings',
            native_checkpoint=deepcopy(native_ref),resource_binding=deepcopy(condition['resource_binding']))
        trace.pop('sha256',None);trace['sha256']=digest(trace)
        trace_path=directory/('trace_'+identity+'.json.gz');put_immutable(trace_path,trace)
        trace_refs['' if branch is None else identity]=ref(trace_path)
    return dict(condition_ref=ref(condition_path),trace_refs=trace_refs,
        resource_binding=deepcopy(condition['resource_binding']),config='llm_readings',
        native_checkpoint=deepcopy(native_ref),run_id=condition['configurations']['llm_readings']['run_id'])


def main():
    freeze=read(HERE/'BACKEND_FROZEN.json')
    if freeze['status']!='BACKEND_FROZEN' or workflow.code_pins()!=freeze['code_pins']:
        raise RuntimeError('Backend is not the exact frozen configuration')
    if ref(Path(__file__))!=freeze['regression_runner']:
        raise RuntimeError('Regression runner differs from its frozen pin')
    catalog=read(HERE/'baseline_catalog.json')
    if ref(HERE/'baseline_catalog.json')!=freeze['baseline_catalog']:
        raise ValueError('Baseline catalog changed')
    baseline_report=ROOT.parent/catalog['report']['path']
    if hashlib.sha256(baseline_report.read_bytes()).hexdigest()!=catalog['report']['sha256']:
        raise ValueError('Published baseline report changed')
    workflow.OUTPUT=HERE/'execution'
    started=time.time();rows=[]
    def progress():
        put(HERE/'regression_progress.json',dict(status='RUNNING',completed=len(rows),requested=14,
            source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE),terminal_ranking='evidence_fit_v1',
            api_calls=0,qualified_new_cases=[],cases=rows))
    with offline():
        for corpus_id in ['cib','iran','vietnam']:
            with workflow.Session() as session:
                for entry in [r for r in catalog['cases'] if r['case']['corpus']==corpus_id]:
                    begin=time.perf_counter();case=entry['case']
                    try:
                        if shutil.disk_usage(HERE).free<8*1024**3:
                            raise RuntimeError('Unchanged canonical 8 GiB guard; retain completed outputs')
                        if workflow.code_pins()!=freeze['code_pins']:
                            raise RuntimeError('Backend changed after freeze; stop before execution')
                        old=load_pinned(entry['baseline_native'])
                        base=deepcopy(old['plan']);selected=base.pop('readings_packet',None)
                        assert digest(base)==entry['base_plan_sha256'] and digest(selected)==entry['reading_packet_sha256']
                        opts=options(entry['configuration'])
                        settings=workflow.configuration(**opts,source_view_policy=SOURCE_DAY_INCLUSIVE,
                            terminal_ranking='evidence_fit_v1')
                        key=digest(dict(version='analyst-release-native-regression/1',case=case,
                            original_plan_sha256=entry['original_plan_sha256'],configuration=settings,
                            code_pins=freeze['code_pins'],runner=freeze['regression_runner']))
                        directory=HERE/'runs'/key;target=directory/'native.json.gz'
                        context=session.context(corpus_id)
                        if old['binding']!=session.refs['index_refs'][corpus_id]:
                            raise ValueError('Original case source binding is not the normal current engine index')
                        control_path=directory/'strict_atomic_retrieval.json.gz'
                        if not control_path.exists():
                            strict=retrieve(context.corpus,old['case'],old['plan'],source_index=context.source_index,
                                method=opts['method'],passage_budget=opts['passage_budget'],
                                document_budget=opts['document_budget'],discovery_profile=opts.get('discovery_profile'))
                            put_immutable(control_path,retrieval_control(old,strict));del strict
                        expected=dict(pins=freeze['code_pins'],binding=session.refs['index_refs'][corpus_id],
                            environment=session.environment,settings=settings)
                        if target.exists():
                            packet=read(target)
                            workflow.validate_packet(packet,case,base,selected,**expected)
                            if read(target.with_name('completion.json'))!=workflow._completion(target,packet,key):
                                raise ValueError('Fresh native completion seal changed')
                            cached=True
                        else:
                            packet=session.execute(case,base,readings_packet=selected,**opts,
                                source_view_policy=SOURCE_DAY_INCLUSIVE,terminal_ranking='evidence_fit_v1')
                            assert digest(packet['plan'])==entry['original_plan_sha256']
                            workflow.validate_packet(packet,case,base,selected,**expected)
                            put_immutable(target,packet)
                            put_immutable(target.with_name('completion.json'),workflow._completion(target,packet,key))
                            cached=False
                        native_ref=ref(target)
                        scoped=apply_source_view(context,settings['source_view_policy'])
                        audit=source_audit(packet,scoped)
                        put_immutable(directory/'source_audit.json',audit)
                        pools=dict(scope='POSTFILTERED_NATIVE_VIABLE_ONLY_NOT_REJECTED_PROPOSALS',
                            baseline_native=entry['baseline_native'],baseline_order=entry['baseline_order'],
                            baseline_pool=deepcopy(old['result'].get('assessed_candidates',[])),
                            new_native=native_ref,new_pool=deepcopy(packet['result'].get('assessed_candidates',[])),
                            pre_terminal_candidate_order=packet['result'].get('pre_terminal_candidate_order',[]),
                            new_display_order=orders(packet['result']),support_or_pool_membership_relabelled=False)
                        put_immutable(directory/'candidate_pools.json.gz',pools)
                        output=export(packet,native_ref,context,directory)
                        control=read(control_path)
                        row=dict(case=case,status='NATIVE_COMPLETE_REVIEW_PENDING',native_status=packet['result']['status'],
                            baseline_native_status=entry['baseline_status'],native_ref=native_ref,
                            configuration=packet['configuration'],outputs=output,source_audit=ref(directory/'source_audit.json'),
                            candidate_pools_ref=ref(directory/'candidate_pools.json.gz'),
                            strict_atomic_control_ref=ref(control_path),strict_atomic_order_unchanged=control['identical_order'],
                            baseline_order=entry['baseline_order'],new_order=orders(packet['result']),
                            cached_new_execution=cached,api_calls=0,qualification_inherited=False)
                        print('NEW_NATIVE_READY',case['case_id'],packet['result']['status'],native_ref['path'],flush=True)
                    except Exception as error:
                        row=dict(case=case,status='ERROR',error_type=type(error).__name__,error=str(error),
                            traceback=traceback.format_exc(),api_calls=0,qualification_inherited=False)
                        print('EXPLICIT_CASE_ERROR',case['case_id'],type(error).__name__,str(error),flush=True)
                    row['wall_seconds']=time.perf_counter()-begin;rows.append(row);progress()
                    if workflow.code_pins()!=freeze['code_pins']:
                        raise RuntimeError('Backend drift: preserve checkpoints and stop')
            del session;gc.collect()
    completed=dict(status='COMPLETE' if all(r['status']!='ERROR' for r in rows) else 'COMPLETE_WITH_EXPLICIT_ERRORS',
        requested=14,completed=len(rows),cases=rows,api_calls=0,started_at=started,ended_at=time.time(),
        frozen_backend=ref(HERE/'BACKEND_FROZEN.json'),qualified_new_cases=[],historical_baseline_not_modified=True,
        interpretation='New native statuses and rank/support deltas require independent review; no original qualification inherited.')
    put_immutable(HERE/'regression_results.json',completed)
    put(HERE/'regression_progress.json',completed)
    print(completed['status'],len(rows),flush=True)


if __name__=='__main__':main()
