# Aung Gyi Pool Loss (Epoch 1)

Diagnostic only; no candidate promotion, named boost or new qualification.
Exact packet and audit pointers are retained in aung_gyi_diagnostic.json.

- Case: narrative_cib_revision_ac4fb499beb4b345b5384ae6.
- Strict atom-only retrieval order is identical to the historical packet.
  Historical/new executed query strings are also identical and already atom-only.
- Prior candidate source page_b8e1fcd54ac2c3df7f63 remains retrieval rank5 AND
  remains in the newly inspected pool. Source name1189:1207 and native node
  entity_source_reference_78d32ae0a37a59dee95e survive nomination.
- This case's original limits are 60 retrieved passages / 30 documents /
  16 inspected construction pages / 24 completed drafts, not the 32/64 profile
  used for most other cases. The experiment retains those exact limits.
- Historical source-group position3 was checked and yielded the viable wording
  "Brigadier Aung Gyi's". New source-group position33 lies outside the bounded
  24-draft allocation. New result /unassessed_remainder/8 records NOT_ALLOCATED,
  not_rejected=true, source_group_position33.
- Therefore the source was not lost by retrieval or the inspected-page cap.
  It was nominated but never assessed in the bounded current constructor.
  Scoring on postfiltered assessed candidates cannot legitimately resurrect it.

This is an opportunity-scheduling limitation of the current executed pool, not
proof that removing whole-query supplement searches caused the loss. Historical
and current helper versions also differ. A clean scheduling/policy ablation
would require an additional explicitly authorized run; no such extra run or
engine repair has been made. Epoch 2 uses the same budget and records its actual
outcome, which must not be predicted from a fixed historical-pool scoring probe.
