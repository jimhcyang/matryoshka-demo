from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ROOT / 'tests'))
from test_current_inspection import context  # noqa: F401
from test_inclusive_inspection import query
import run_final
from matryoshka_demo.io import digest, offline
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, descriptor
from matryoshka_narrative.server import Viewer


def test_fresh_trace_query_binding_and_seal_accepted_by_normal_viewer(context, tmp_path, monkeypatch):
    c = query()
    p = next(p for p in context.corpus.pages if p['id'] == 'page')
    citation = dict(canonical_page_id='page', document_id='doc', date=c['date'], start=0,
        end=len(p['text']), text=p['text'], page_sha256=p['source_sha256'])
    plan = dict(query_sha256=digest(c['query']), atoms=[dict(id='a1', text=c['query'],
        kind='proposition', required=True)])
    result = dict(task='hypothesis', status='SUPPORT', source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE),
        atoms=[dict(id='a1', text=c['query'], kind='proposition', required=True, status='SUPPORT',
            evidence=[dict(direction='SUPPORT', citation=citation)])], inspected_page_ids=['page'])
    packet = dict(version=run_final.workflow.VERSION, case=c, public_case=c, public_task='hypothesis', plan=plan, result=result,
        configuration=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE)),
        retrieval=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE), source_edges=[], search_queries=[]))
    binding = dict(index_sha256='fixture-index')
    monkeypatch.setattr(run_final.presentation, 'display_record', lambda *a, **kw:
        dict(resource_binding=binding, configurations=dict(llm_readings=dict(run_id='fixture-run'))))
    monkeypatch.setattr(run_final, 'ref', lambda path: dict(path=str(path.relative_to(tmp_path)),
        sha256=run_final.workflow.hashlib.sha256(path.read_bytes()).hexdigest()))
    native_ref = dict(path='native.json.gz', sha256='fixture-native')
    with offline():
        outputs = run_final.final_export(packet, native_ref, context, tmp_path)
        monkeypatch.setattr(run_final, 'ROOT', tmp_path)
        assert run_final.verify_viewer_outputs(packet, outputs)['status'] == 'PASS'
        viewer = Viewer.__new__(Viewer)
        viewer.root = tmp_path
        row = dict(case=c, resource_binding=binding)
        trace = viewer.trace(row, 'llm_readings', outputs, packet, '')
    assert trace['query_sha256'] == digest(c['query'])
    assert trace['sha256'] == digest({k:v for k,v in trace.items() if k != 'sha256'})
    assert trace['native_checkpoint'] == native_ref
