"""Query-only local replay diagnosis; never executes retrieval or a native case."""
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from matryoshka_demo.io import digest, offline
from matryoshka_narrative import planning
from matryoshka_narrative.contracts import engine_case
from matryoshka_next import planning as legacy


def differences(before, after, path=""):
    if type(before) is not type(after):
        return [dict(path=path, before=before, after=after)]
    if isinstance(before, dict):
        result = []
        for key in sorted(before.keys() | after.keys()):
            pointer = path + "/" + key.replace("~", "~0").replace("/", "~1")
            if key not in before or key not in after:
                result.append(dict(path=pointer, before=before.get(key), after=after.get(key)))
            else:
                result.extend(differences(before[key], after[key], pointer))
        return result
    if isinstance(before, list) and len(before) == len(after):
        return [d for i, (a, b) in enumerate(zip(before, after))
            for d in differences(a, b, path + "/" + str(i))]
    return [] if before == after else [dict(path=path, before=before, after=after)]


def main():
    catalog = json.loads((HERE / "baseline_catalog.json").read_text())
    rows = []
    with offline():
        for entry in catalog["cases"]:
            target = ROOT / entry["baseline_native"]["path"]
            assert hashlib.sha256(target.read_bytes()).hexdigest() == entry["baseline_native"]["sha256"]
            with gzip.open(target, "rt") as stream:
                old = json.load(stream)
            base = deepcopy(old["plan"])
            base.pop("readings_packet", None)
            case = engine_case(entry["case"])
            row = dict(case_id=case["case_id"], original_plan_sha256=digest(base),
                api_calls=0, native_execution=False)
            try:
                planning.validate_plan(base, case)
                row["original_valid"] = True
            except ValueError as error:
                row.update(original_valid=False, original_validation_error=str(error))
                atom_keys = legacy.schema()["properties"]["atoms"]["items"]["properties"]
                raw = dict(atoms=[{k: v for k, v in a.items() if k in atom_keys} for a in base["atoms"]],
                    extractions={key: [{k: v for k, v in e.items()
                        if k not in {"query_spans", "contains_unknown_slot"}} for e in values]
                        for key, values in base["extractions"].items()})
                provenance = {}
                receipt = base.get("receipt", {})
                saved_receipt = ROOT / "experiments/narrative_demo/api" / receipt["receipt"]
                attempt = saved_receipt.parent.parent / "attempts" / saved_receipt.stem
                if saved_receipt.exists() and (attempt / "response.json").exists():
                    usage_receipt = json.loads(saved_receipt.read_text())
                    wire = json.loads((attempt / "request.json").read_text())
                    response = json.loads((attempt / "response.json").read_text())
                    assert usage_receipt["status"] == "PASS"
                    assert digest(wire) == usage_receipt["request_sha256"]
                    assert usage_receipt.get("response_sha256", digest(response)) == digest(response)
                    texts = [p["text"] for item in response["output"] if item.get("type") == "message"
                        for p in item.get("content", []) if p.get("type") == "output_text"]
                    assert len(texts) == 1
                    raw = json.loads(texts[0])
                    assert digest(raw) == base["raw_output_sha256"]
                    provenance = dict(original_raw_model_response_recovered=True,
                        reconstruction="Exact saved original model output; no new model call or raw-field reconstruction",
                        saved_raw_refs=[dict(path=str(p.relative_to(ROOT)),
                            sha256=hashlib.sha256(p.read_bytes()).hexdigest())
                            for p in [saved_receipt, attempt / "request.json", attempt / "response.json"]])
                row["retained_raw_fields_sha256"] = digest(raw)
                try:
                    rebound = planning.bind(case, raw, receipt=base.get("receipt"))
                    planning.validate_plan(rebound, case)
                    row.update(rebound_valid=True, rebound_plan_sha256=digest(rebound),
                        differences=differences(base, rebound), rebound_plan=rebound,
                        original_raw_model_response_recovered=False,
                        reconstruction="Only retained original schema fields; no inferred discarded model fields")
                    row.update(provenance)
                except ValueError as error:
                    row.update(rebound_valid=False, rebind_error=str(error))
            rows.append(row)
            print(row["case_id"], "original_valid", row["original_valid"],
                "rebound_valid", row.get("rebound_valid"), flush=True)
    result = dict(version="saved-query-plan-compatibility-diagnosis/1", api_calls=0,
        native_cases_run=0, queries_modified=False, original_packets_modified=False, cases=rows)
    (HERE / "plan_compatibility.json").write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")


if __name__ == "__main__":
    main()
