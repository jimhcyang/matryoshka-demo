from copy import deepcopy
from pathlib import Path
import sys
from types import SimpleNamespace

import pytest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from matryoshka_demo.io import digest, offline
from matryoshka_narrative import workflow, terminal_scores
from matryoshka_next.workflow import read, put_immutable
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, apply_source_view
from run_regression import ref
from test_source_scope import corpus_for, page, case


@pytest.fixture(autouse=True)
def no_network():
    with offline():
        yield


def parents():
    manifest = read(HERE / 'epoch2/regression_results.json')
    return [(r, read(ROOT / r['native_ref']['path'])) for r in manifest['cases']]


def test_all_fourteen_real_prefixes_are_recoverable_and_v3_preserves_nonterminal_content():
    for row, packet in parents():
        before = deepcopy(packet)
        prefix = workflow._restore_terminal_prefix(packet['result'])
        scored = terminal_scores.annotate_result(prefix, packet['retrieval'], plan=packet['plan'], rerank=True)
        scored['pre_terminal_candidate_order'] = prefix.get('pre_terminal_candidate_order', [])
        assert workflow._restore_terminal_prefix(scored) == prefix
        assert packet == before


@pytest.mark.parametrize('attack', ['missing_selection', 'unknown_id', 'duplicate_id', 'rejected_pool', 'changed_gate'])
def test_prefix_rejects_untrusted_or_resurrected_candidates(attack):
    _, packet = parents()[0]
    result = deepcopy(packet['result'])
    branch = next(r for r in result['readings'] if r['candidates'])
    selection = next(r for r in result['pre_terminal_candidate_order'] if r['candidate_ids'])
    if attack == 'missing_selection':
        result.pop('pre_terminal_candidate_order')
    elif attack == 'unknown_id':
        selection['candidate_ids'][0] = 'not-assessed'
    elif attack == 'duplicate_id':
        selection['candidate_ids'].append(selection['candidate_ids'][0])
    elif attack == 'rejected_pool':
        result['assessed_candidates'][0]['local_decision']['status'] = 'rejected'
    else:
        branch['candidates'][0]['local_decision']['coverage'] = 'tampered'
    with pytest.raises(ValueError):
        workflow._restore_terminal_prefix(result)


def test_bound_source_replay_checks_all_quotes_and_blocks_outside_or_forged_source():
    c = case(task='hypothesis')
    p = page('proof', date=c['date'])
    view = apply_source_view(SimpleNamespace(corpus=corpus_for([p]), source_index={'proof': p}), SOURCE_DAY_INCLUSIVE)
    quote = dict(canonical_page_id=p['id'], document_id=p['document_id'], date=p['date'], start=0,
        end=len(p['text']), text=p['text'], page_sha256=p['source_sha256'])
    packet = dict(case=c, configuration=dict(source_view_policy=workflow.descriptor(SOURCE_DAY_INCLUSIVE)),
        result=dict(source_view_policy=workflow.descriptor(SOURCE_DAY_INCLUSIVE),
            inspected_page_ids=['proof'], atoms=[dict(citation=quote)]))
    assert workflow._terminal_source_replay(packet, view)['unique_bound_quotes'] == 1
    for forged in [dict(quote, text='X' * len(quote['text'])), dict(quote, date='1999-01-01')]:
        bad = deepcopy(packet)
        bad['result']['atoms'][0]['citation'] = forged
        with pytest.raises(ValueError):
            workflow._terminal_source_replay(bad, view)
    packet['result']['inspected_page_ids'] = []
    with pytest.raises(ValueError):
        workflow._terminal_source_replay(packet, view)


def fake_session(monkeypatch, tmp_path, parent, pins):
    session = workflow.Session.__new__(workflow.Session)
    session.root = tmp_path
    session.narrative_pins = pins
    session.environment = parent['environment']
    session.refs = dict(index_refs={parent['case']['corpus']: parent['binding']})
    session.context = lambda corpus: pytest.fail('No native resource context should be opened on invalid input')
    monkeypatch.setattr(workflow, 'code_pins', lambda: pins)
    monkeypatch.setattr(workflow, 'require_headroom', lambda p: None)
    return session


def sealed_parent(tmp_path, parent):
    target = tmp_path / 'native.json.gz'
    put_immutable(target, parent)
    put_immutable(target.with_name('completion.json'), workflow._completion(target, parent, 'test-key'))
    return dict(path='native.json.gz', sha256=workflow.hashlib.sha256(target.read_bytes()).hexdigest())


@pytest.mark.parametrize('attack', ['nonterminal_pin', 'missing_pin', 'parent_hash', 'completion_seal', 'parent_config'])
def test_terminal_boundary_rejects_before_resource_open(monkeypatch, tmp_path, attack):
    _, parent = parents()[0]
    trusted = deepcopy(parent['code_pins'])
    pins = dict(trusted)
    pins['matryoshka_narrative/workflow.py'] = 'new-workflow'
    pins['matryoshka_narrative/terminal_scores.py'] = 'new-terminal'
    if attack == 'nonterminal_pin':
        pins['matryoshka_narrative/construction.py'] = 'changed-constructor'
    elif attack == 'missing_pin':
        pins.pop('matryoshka_narrative/construction.py')
    elif attack == 'parent_config':
        parent['configuration']['construction_pages'] += 1
    reference = sealed_parent(tmp_path, parent)
    if attack == 'parent_hash':
        reference['sha256'] = '0' * 64
    elif attack == 'completion_seal':
        seal = tmp_path / 'completion.json'
        value = read(seal)
        value['packet_digest'] = '0' * 64
        workflow.native.put(seal, value)
    session = fake_session(monkeypatch, tmp_path, parent, pins)
    if attack == 'parent_config':
        # A forged configuration is also independently bound by the caller's
        # trusted file reference; keep its original native-result policy intact.
        parent['result']['source_view_policy'] = workflow.descriptor(workflow.STRICT_PRIOR)
        workflow.native.put(tmp_path / 'native.json.gz', parent)
    with pytest.raises(ValueError):
        session.replay_terminal(reference, trusted_parent_pins=trusted)


def test_configuration_v2_and_v3_have_distinct_identities_and_legacy_default():
    a = workflow.configuration('current_hierarchy', 80, 40, 32, 64, terminal_ranking='evidence_fit_v2')
    b = workflow.configuration('current_hierarchy', 80, 40, 32, 64, terminal_ranking='evidence_fit_v3')
    assert digest(a) != digest(b)
    assert workflow.configuration('current_hierarchy', 80, 40, 32, 64)['terminal_ranking'] is None


def test_genuine_terminal_stage_reuses_prefix_without_constructor_or_parent_mutation(monkeypatch, tmp_path):
    from matryoshka_narrative import retrieval, construction
    _, parent = parents()[1]
    trusted = deepcopy(parent['code_pins'])
    pins = dict(trusted, **{'matryoshka_narrative/workflow.py': 'new-workflow',
        'matryoshka_narrative/terminal_scores.py': 'new-terminal'})
    reference = sealed_parent(tmp_path, parent)
    original_bytes = (tmp_path / reference['path']).read_bytes()
    session = fake_session(monkeypatch, tmp_path, parent, pins)
    session.context = lambda corpus: SimpleNamespace(corpus=SimpleNamespace(), source_index={})
    monkeypatch.setattr(workflow, '_terminal_source_replay', lambda packet, context: dict(status='PASS'))
    monkeypatch.setattr(retrieval, 'retrieve', lambda *a, **kw: pytest.fail('Retrieval must not execute'))
    monkeypatch.setattr(construction, 'construct', lambda *a, **kw: pytest.fail('Construction must not execute'))
    result = session.replay_terminal(reference, trusted_parent_pins=trusted)
    assert result['terminal_stage_replay']['constructor_reexecuted'] is False
    assert result['terminal_stage_replay']['parent_checkpoint'] == reference
    assert result['configuration']['terminal_ranking'] == 'evidence_fit_v3'
    assert result['result']['terminal_scores']['version'] == terminal_scores.VERSION
    assert workflow._restore_terminal_prefix(result['result']) == workflow._restore_terminal_prefix(parent['result'])
    assert result['native_checksum'] != parent['native_checksum']
    assert (tmp_path / reference['path']).read_bytes() == original_bytes
