from copy import deepcopy
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from run_redaction_floor import floor_options, needs_execution, read


@pytest.mark.parametrize('old_pages,old_drafts,want_pages,want_drafts', [
    (16, 24, 32, 64), (32, 64, 32, 64), (64, 128, 64, 128), (64, 24, 64, 64), (16, 128, 32, 128)])
def test_uniform_max_floor_never_lowers_any_budget(old_pages, old_drafts, want_pages, want_drafts):
    entry = dict(case=dict(task='redaction'), configuration=dict(method='current_hierarchy',
        construction_pages=old_pages, completed_drafts_per_reading=old_drafts,
        retrieval_passage_budget=60, retrieval_document_budget=30, top_k=5,
        selection_profile=dict(scan_pages=512)))
    before = deepcopy(entry)
    opts = floor_options(entry)
    assert (opts['construction_pages'], opts['draft_budget']) == (want_pages, want_drafts)
    assert opts['passage_budget'] == 60 and opts['document_budget'] == 30
    assert opts['selection_profile'] == entry['configuration']['selection_profile']
    assert entry == before


def test_all_public_redactions_selected_only_by_budget_not_case_or_query():
    entries = read(HERE / 'baseline_catalog.json')['cases']
    redactions = [e for e in entries if e['case']['task'] == 'redaction']
    assert len(redactions) == 8
    affected = [e for e in redactions if needs_execution(e)]
    assert len(affected) == 1
    for e in entries:
        changed = deepcopy(e)
        changed['case']['case_id'] = 'unrelated-id'
        changed['case']['query'] = 'unrelated visible query'
        assert needs_execution(changed) == needs_execution(e)
        assert floor_options(changed) == floor_options(e)


def test_non_redaction_native_budgets_do_not_change():
    for e in read(HERE / 'baseline_catalog.json')['cases']:
        if e['case']['task'] != 'redaction':
            assert not needs_execution(e)
            assert floor_options(e)['construction_pages'] == e['configuration']['construction_pages']
            assert floor_options(e)['draft_budget'] == e['configuration']['completed_drafts_per_reading']
