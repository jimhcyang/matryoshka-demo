"""Pin the separately tested second epoch without rewriting the first freeze."""
import argparse
import hashlib
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
from matryoshka_demo.io import digest, offline
from matryoshka_next.workflow import put_immutable
from matryoshka_narrative.workflow import code_pins
from matryoshka_demo.source_view_policy import SourceViewPolicy, descriptor


def ref(path):
    return dict(path=str(path.relative_to(ROOT)), sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--score-sha256', required=True)
    args = parser.parse_args()
    score = ref(ROOT / 'matryoshka_narrative/terminal_scores.py')
    if score['sha256'] != args.score_sha256:
        raise ValueError('Main frozen score bytes differ from the requested pin')
    suites = list(ET.parse(HERE / 'epoch2-final-tests.xml').getroot().iter('testsuite'))
    count = sum(int(s.get('tests', 0)) for s in suites)
    assert count >= 292 and all(int(s.get('failures', 0)) == int(s.get('errors', 0)) == 0 for s in suites)
    assert shutil.disk_usage(HERE).free >= 3 * 1024**3
    with offline():
        pins = code_pins()
        result = dict(status='BACKEND_FROZEN', version='analyst-release-backend-freeze/2', epoch=2,
            code_pins=pins, code_pins_digest=digest(pins),
            original_epoch_freeze=ref(HERE / 'BACKEND_FROZEN.json'),
            interface=ref(HERE / 'INTERFACE_EPOCH2.md'),
            tests=ref(HERE / 'epoch2-final-tests.xml'), tests_passed=count,
            regression_runner=ref(HERE / 'run_regression_epoch2.py'),
            runner_dependencies=[ref(HERE / p) for p in ['run_regression.py', 'recover_rebound_plan.py']],
            baseline_catalog=ref(HERE / 'baseline_catalog.json'),
            plan_compatibility=ref(HERE / 'plan_compatibility.json'), terminal_scoring=score,
            terminal_ranking='evidence_fit_v2', validated_plan_forwarded_to_scoring=True,
            source_policy_descriptors={p.value: descriptor(p) for p in SourceViewPolicy},
            corpus_and_source_index_share_trusted_policy=True, independent_quote_guards_preserved=True,
            exact_saved_plan_cases=13, exact_retained_raw_model_rebind_cases=1,
            native_runs_in_this_epoch_before_freeze=0, api_calls=0,
            engine_edits_after_freeze_forbidden=True, fresh_native_qualification_inherited=False,
            original_packets_and_epoch1_modified=False, actual_indexes_reused_not_copied=True,
            storage_floor_gib=3, unchanged_canonical_headroom_guard_gib=8,
            free_gib=shutil.disk_usage(HERE).free / 1024**3)
        pin = put_immutable(HERE / 'BACKEND_FROZEN_EPOCH2.json', result)
        print('BACKEND_FROZEN_EPOCH2', pin['sha256'])
        print('CODE_PINS_DIGEST', result['code_pins_digest'])
        print('SCORING', score['sha256'])
        print('TESTS', count)


if __name__ == '__main__':
    main()
