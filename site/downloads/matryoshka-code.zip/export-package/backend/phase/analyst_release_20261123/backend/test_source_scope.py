"""Policy/guard unit tests only; no paid calls or whole native execution."""
from copy import deepcopy
import json
from pathlib import Path
import sqlite3
import sys
from types import SimpleNamespace

import numpy as np
import pytest

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT))
from matryoshka_demo.io import digest, offline
from matryoshka_demo.source_view_policy import (
    STRICT_PRIOR, SOURCE_DAY_INCLUSIVE, LIVE_BEFORE_WITH_EARLIER_ORIGIN,
    SourceViewPolicy, SourcePages, apply_source_view, corpus_view, descriptor,
    from_descriptor, packet_policy, policy_of, source_page_allowed)
from matryoshka_demo.corpus import Corpus, BM25
from matryoshka_demo.corpus_policy_v5 import policy_view
from matryoshka_next.facts import SourcePolicy
from matryoshka_narrative.traces import SourceReplay


@pytest.fixture(autouse=True)
def no_network():
    with offline():yield


def case(corpus='cib',task='redaction',**changes):
    return dict(dict(case_id='scope-fixture',corpus=corpus,task=task,document_id='ORIGIN',date='2000-01-02',
        query='The council approved the [MASK] proposal.' if task=='redaction' else 'The council approved the proposal.',
        focal_marker='[MASK]' if task=='redaction' else ''),**changes)


def page(pid='early',corpus='cib',**changes):
    text='The council approved the proposal.'
    return dict(dict(id=pid,canonical_page_id=pid,corpus=corpus,document_id=pid,date='2000-01-01',
        text=text,source_sha256=digest(text),visibility='earlier',permitted=True,earlier_page=1,
        classification='unknown' if corpus=='cib' else 'CONFIDENTIAL',handling=[]),**changes)


def corpus_for(pages,corpus='cib'):
    value=Corpus.__new__(Corpus)
    value.corpus=corpus;value.pages=pages
    value.documents={'ORIGIN':dict(document_date_iso='2000-01-02')};value.classification={}
    value.page_ids=[p['id'] for p in pages];value.page_index={p['id']:i for i,p in enumerate(pages)}
    value.page_dates=np.asarray([p['date'] for p in pages]);value.page_docs=np.asarray([p['document_id'] for p in pages])
    value.allowed=np.asarray([p['permitted'] for p in pages],dtype=bool)
    value.units=[dict(id='q'+str(i),pi=i,start=0,end=len(p['text']),text=p['text'],nodes={0}) for i,p in enumerate(pages)]
    value.unit_pages=np.arange(len(pages));value.surfaces=[p['text'] for p in pages]
    value.surface_pages=np.arange(len(pages));value.surface_nodes=np.zeros(len(pages),dtype=int)
    value.nodes={'node':dict(id='node',kind='Claim')};value.node_ids=['node'];value.node_index={'node':0}
    value.edge_rows=[];value.membership=[(i,0) for i in range(len(pages))];value.hierarchy={}
    value.occurrences=[];value.occurrences_by_page={};value.occurrences_by_node={}
    value.page_bm25=BM25(value.surfaces);value.node_bm25=BM25(value.surfaces)
    return policy_view(value)


def sources(corpus='cib'):
    return [page('early',corpus),page('same-other',corpus,date='2000-01-02'),
        page('same-origin',corpus,date='2000-01-02',document_id='ORIGIN'),
        page('future',corpus,date='2000-01-03'),
        page('later',corpus,date='2000-01-02',document_id='ORIGIN',visibility='later',classification='SECRET'),
        page('quarantine',corpus,permitted=False),
        page('secret',corpus,classification='SECRET'),
        page('mislabelled-later',corpus,native_page=dict(view='later'))]


@pytest.mark.parametrize('task',['redaction','hypothesis','reconstruction'])
@pytest.mark.parametrize('corpus',['cib','iran','vietnam'])
@pytest.mark.parametrize('mode',[STRICT_PRIOR,SOURCE_DAY_INCLUSIVE,LIVE_BEFORE_WITH_EARLIER_ORIGIN])
def test_boundaries_and_no_later_secret_or_quarantine_leak(task,corpus,mode):
    pages=sources(corpus);base=corpus_for(pages,corpus);view=corpus_view(base,mode);c=case(corpus,task)
    eligible=view.eligible(c);policy=SourcePolicy(view,c,{p['id']:deepcopy(p) for p in pages})
    expected={'early'}
    if mode is SOURCE_DAY_INCLUSIVE:
        expected.add('same-other')
        if corpus=='cib':expected.add('same-origin')
    if corpus!='cib':expected.add('mislabelled-later')  # Native CIB release label is not a cable release.
    got={p['id'] for i,p in enumerate(pages) if policy.allowed(i)}
    assert got==expected
    assert {p['id'] for i,p in enumerate(pages) if eligible.page_mask[i]}==expected
    replay=SourceReplay(view,c,[p['id'] for p in pages],{p['id']:deepcopy(p) for p in pages})
    for i,p in enumerate(pages):
        ref=dict(canonical_page_id=p['id'],document_id=p['document_id'],date=p['date'],
            start=0,end=len(p['text']),text=p['text'],page_sha256=p['source_sha256'])
        if p['id'] in expected:
            assert policy.citation(i,0,len(p['text']))['text']==p['text']
            assert replay.quote(ref)['text']==p['text']
            assert eligible.citation(i)['canonical_page_id']==p['id']
        else:
            with pytest.raises(ValueError):policy.citation(i,0,len(p['text']))
            with pytest.raises(ValueError):replay.quote(ref)
            with pytest.raises(ValueError):eligible.citation(i)


@pytest.mark.parametrize('corpus',['iran','vietnam'])
@pytest.mark.parametrize('mode',[STRICT_PRIOR,SOURCE_DAY_INCLUSIVE,LIVE_BEFORE_WITH_EARLIER_ORIGIN])
def test_entire_cable_veto_from_hidden_or_future_sibling(corpus,mode):
    p=page('safe',corpus,document_id='VETO-DOC')
    hidden=page('hidden',corpus,document_id='VETO-DOC',date='2099-01-01',permitted=False,
        text='NO FOREIGN DISSEMINATION',source_sha256=digest('NO FOREIGN DISSEMINATION'))
    view=corpus_view(corpus_for([p,hidden],corpus),mode)
    policy=SourcePolicy(view,case(corpus),{'safe':p,'hidden':hidden})
    assert 'VETO-DOC' in policy.veto
    assert not policy.allowed(0) and not view.eligible(case(corpus)).page_mask[0]


def test_no_day_plus_one_and_live_origin_date_is_explicit_as_of_not_rewritten():
    base=corpus_for(sources())
    live=corpus_view(base,LIVE_BEFORE_WITH_EARLIER_ORIGIN)
    c=case(date='2000-01-03')
    eligible=live.eligible(c)
    assert eligible.page_mask[2]  # Earlier-origin on Jan 2, before exclusive Jan 3.
    assert not eligible.page_mask[3]  # Jan 3 itself remains excluded.
    assert c['date']=='2000-01-03' and c['document_id']=='ORIGIN'
    with pytest.raises(ValueError):corpus_view(base,SOURCE_DAY_INCLUSIVE).eligible(c)
    with pytest.raises(ValueError):base.eligible(c)


@pytest.mark.parametrize('bad',['source_day_inclusive',True,{},None])
def test_public_input_cannot_supply_typed_opt_in(bad):
    base=corpus_for(sources())
    with pytest.raises(TypeError):corpus_view(base,bad)
    poisoned=case(source_view_policy='source_day_inclusive',allow_same_day=True,exclude_origin=False)
    assert not SourcePolicy(base,poisoned,{'p':page()}).allowed(2)


def test_descriptor_is_complete_typed_and_cache_distinct():
    from matryoshka_narrative.workflow import configuration
    values=[]
    for mode in SourceViewPolicy:
        assert from_descriptor(descriptor(mode)) is mode
        settings=configuration('current_hierarchy',80,40,32,64,source_view_policy=mode)
        assert settings['terminal_ranking'] is None
        values.append(digest(settings))
    assert len(set(values))==3
    bad=dict(descriptor(SOURCE_DAY_INCLUSIVE),date_relation='<')
    with pytest.raises(ValueError):from_descriptor(bad)
    assert configuration('current_hierarchy',80,40,32,64,terminal_ranking='evidence_fit_v2')['terminal_ranking']=='evidence_fit_v2'
    with pytest.raises(ValueError):configuration('current_hierarchy',80,40,32,64,terminal_ranking='evidence_fit_v1')
    with pytest.raises(ValueError):configuration('current_hierarchy',80,40,32,64,terminal_ranking='invented')


def test_result_configuration_policy_must_agree_and_old_defaults_strict():
    assert packet_policy(dict(result={})) is STRICT_PRIOR
    packet=dict(configuration=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE)),
        result=dict(source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE)))
    assert packet_policy(packet) is SOURCE_DAY_INCLUSIVE
    packet['result']['source_view_policy']=descriptor(STRICT_PRIOR)
    with pytest.raises(ValueError):packet_policy(packet)


def test_apply_source_view_reuses_actual_corpus_and_sql_connection():
    base=corpus_for(sources());db=sqlite3.connect(':memory:')
    context=SimpleNamespace(corpus=base,source_index=db,index=object(),registry={})
    view=apply_source_view(context,descriptor(SOURCE_DAY_INCLUSIVE))
    assert view is not context and view.corpus.pages is base.pages
    assert view.source_index._index is db and view.index is context.index
    assert policy_of(context.corpus) is STRICT_PRIOR
    assert policy_of(view.corpus) is policy_of(view.source_index) is SOURCE_DAY_INCLUSIVE
    assert view.source_index.execute('SELECT 1').fetchone()[0]==1
    db.close()


@pytest.mark.parametrize('mode',[STRICT_PRIOR,SOURCE_DAY_INCLUSIVE,LIVE_BEFORE_WITH_EARLIER_ORIGIN])
def test_constructor_and_independent_reporting_quote_guards(mode):
    from matryoshka_current.arm_controls import _checked_page
    from matryoshka_next.construction import _pages
    from matryoshka_demo.task_execution_v3 import _source_pages
    from matryoshka_demo_v6.reporting_local_decisions_v65 import _pages as gate_pages,_quote
    pages=sources();view=corpus_view(corpus_for(pages),mode);c=case();eligible=view.eligible(c)
    for i,p in enumerate(pages):
        retrieval=dict(eligible=eligible,pages=[i],passage_budget=1,source_index={p['id']:p for p in pages})
        checked=SourcePages({p['id']:p},mode)
        indexes=gate_pages(checked,c)
        ref=dict(canonical_page_id=p['id'],document_id=p['document_id'],date=p['date'],
            start=0,end=len(p['text']),text=p['text'],page_sha256=p['source_sha256'])
        actions=[lambda:_pages(c,retrieval),lambda:_source_pages(c,retrieval,1),
            lambda:_checked_page(p,c,source_view_policy=mode),lambda:_quote(ref,*indexes,c)]
        if source_page_allowed(p,c,mode):
            for action in actions:action()
        else:
            for action in actions:
                with pytest.raises(ValueError):action()


def sql_index():
    from matryoshka_current.index import CorpusIndex
    index=CorpusIndex.__new__(CorpusIndex);index.db=sqlite3.connect(':memory:')
    index.registry={'resource_id':'R'};index.binding={'corpus':'cib'}
    index.db.executescript('CREATE TABLE document(id TEXT,date TEXT); CREATE TABLE page(id TEXT,doc TEXT,date TEXT,eligible INTEGER,payload TEXT);')
    index.db.execute('INSERT INTO document VALUES(?,?)',('ORIGIN','2000-01-02'))
    for p in sources():
        index.db.execute('INSERT INTO page VALUES(?,?,?,?,?)',(p['id'],p['document_id'],p['date'],int(p['permitted']),json.dumps(p)))
    return index


@pytest.mark.parametrize('mode',[STRICT_PRIOR,SOURCE_DAY_INCLUSIVE,LIVE_BEFORE_WITH_EARLIER_ORIGIN])
def test_real_sql_reader_scope_cannot_bypass_version_guard(mode):
    index=sql_index();c=case()
    try:
        assert {p['id'] for p in index.pages(c,source_view_policy=mode)}=={
            p['id'] for p in sources() if source_page_allowed(p,c,mode)}
        for p in sources():
            if source_page_allowed(p,c,mode):
                assert index.source(c,p['id'],source_view_policy=mode)['page']['id']==p['id']
            else:
                with pytest.raises(ValueError):index.source(c,p['id'],source_view_policy=mode)
    finally:index.db.close()


def test_atomic_searches_never_execute_whole_context_or_fallback():
    from matryoshka_demo.retrieval_v5 import searches
    from matryoshka_next.retrieval import searches as next_searches
    from matryoshka_narrative.focal_retrieval import grouped_searches
    c=case(query='BACKGROUND_ONLY. The council approved the [MASK] proposal.')
    text='The council approved the [MASK] proposal.';start=c['query'].index(text)
    plan=dict(atoms=[dict(id='a1',text=text,kind='proposition',query_spans=[dict(start=start,end=len(c['query']),text=text)]),
        dict(id='context',text='BACKGROUND_ONLY.',kind='context',query_spans=[dict(start=0,end=16,text=c['query'][:16])])],
        leads=[dict(id='lead',question=c['query'],atom_ids=['a1'])])
    assert [r['query'] for r in searches(plan,c)]==[text]
    assert [r['query'] for r in grouped_searches(plan,c)]==[text]
    assert next_searches(c,plan)==[' '.join(text.replace('[MASK]',' ').split())]
    for fn in [lambda:searches(dict(atoms=[]),c),lambda:next_searches(c,dict(atoms=[]))]:
        with pytest.raises(ValueError):fn()


def test_literal_reference_production_path_cannot_add_probes(monkeypatch):
    from matryoshka_narrative import literal_reference_retrieval as module
    c=case();atom=dict(id='a',kind='proposition',text=c['query'],query_spans=[dict(start=0,end=len(c['query']),text=c['query'])])
    monkeypatch.setattr(module,'compile_probes',lambda *a,**k:(_ for _ in ()).throw(AssertionError('must not run reference compiler')))
    monkeypatch.setattr(module.focal,'retrieve',lambda *a,**k:dict(receipt={}))
    result=module.retrieve(None,c,dict(atoms=[atom]),parse=lambda text:None)
    assert result['receipt']['reference_searches_executed'] is False
    assert result['receipt']['reference_probe_receipt']['probes']==[]
