# Uniform Public Redaction Resource Floor

This is a supplemental resource-coverage experiment, not a named scoring change.
The frozen epoch-2 engine, scoring, public query, validated plan, readings,
source policy, retrieval budgets and selection profiles remain unchanged.

For EVERY published Redaction case, use:

```
construction_pages = max(original construction_pages, 32)
completed_drafts_per_reading = max(original completed_drafts_per_reading, 64)
```

The pinned original catalog has eight Redaction cases. Seven already satisfy
32/64. One CIB case has16/24 and therefore requires a real supplemental run.
Hypothesis/Mosaic budgets do not change. Larger existing budgets never shrink.
The rule has no candidate-name, query-word or expected-answer condition.

Exact-budget controls remain under backend/epoch2/ and are never rewritten or
relabelled. The supplemental native uses a new configuration/cache/run identity
and explicitly records its control native ref, full new viable pool, pre-score
and displayed orders, inspected source counts, audit, condition and trace refs.
Queries/readings are checked for exact equality with the epoch-2 control.

The supplemental runner waits for all14 epoch-2 attempts to finish before
opening a native source context. Only below-floor cases execute; cases already
at/above the floor keep their actual epoch-2 native refs in the uniform catalog.
API0; source/index bytes are referenced in place, not copied or rebuilt.

Artifacts:
- REDACTION_FLOOR_FROZEN.json: separately pinned phase runner, seven unit tests,
  generic floor rule and unchanged BACKEND_FROZEN_EPOCH2 engine binding.
- redaction_floor/uniform_floor_catalog.json: all eight case/control references
  and the exact public floor options, generated after epoch2 completes.
- redaction_floor/results.json: actual supplemental result plus exact native,
  display, trace, pool and source-audit refs; generated after execution.

Adoption remains PENDING_QUALITY_REVIEW. A nominated but unchecked candidate
cannot be resurrected by scoring. Native status, rank and sufficiency are
reported as observed; resource expansion does not itself qualify a case or
justify promotion. No site/report/publication file is modified by this worker.
