"""Exercise workflow transport through the real retained-certificate quote guard."""
from copy import deepcopy
import importlib
import json
from pathlib import Path
import sqlite3
import sys
from types import SimpleNamespace

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from test_source_scope import case, page, corpus_for
from matryoshka_demo.io import digest, offline
from matryoshka_demo.source_view_policy import (
    STRICT_PRIOR, SOURCE_DAY_INCLUSIVE, LIVE_BEFORE_WITH_EARLIER_ORIGIN,
    apply_source_view, policy_of, descriptor)
from matryoshka_next.facts import SourcePolicy
from matryoshka_narrative import decisions
from matryoshka_current import reconstruction, hypothesis_claims

MODES = [STRICT_PRIOR, SOURCE_DAY_INCLUSIVE, LIVE_BEFORE_WITH_EARLIER_ORIGIN]


@pytest.fixture(autouse=True)
def offline_only():
    with offline():
        yield


def context_for(sql):
    pages = [page(), page('early-origin', document_id='ORIGIN'),
        page('same-origin', date='2000-01-02', document_id='ORIGIN'),
        page('later', visibility='later'), page('secret', classification='SECRET'),
        page('future', date='2000-01-03')]
    corpus = corpus_for(pages)
    if sql:
        index = sqlite3.connect(':memory:')
        index.execute('CREATE TABLE page(id TEXT, payload TEXT)')
        index.executemany('INSERT INTO page VALUES(?,?)', [(p['id'], json.dumps(p)) for p in pages])
    else:
        index = {p['id']: p for p in pages}
    return SimpleNamespace(corpus=corpus, source_index=index)


def supplied_plan(c):
    return dict(task=c['task'], query_sha256=digest(c['query']), atoms=[dict(
        id='a1', text=c['query'], kind='proposition', required=True,
        query_spans=[dict(start=0, end=len(c['query']), text=c['query'])])])


@pytest.mark.parametrize('package', ['matryoshka_narrative', 'matryoshka_next'])
@pytest.mark.parametrize('mode', MODES)
@pytest.mark.parametrize('sql', [False, True])
def test_workflow_passes_trusted_index_to_real_historical_quote_guard(monkeypatch, package, mode, sql):
    workflow = importlib.import_module(package + '.workflow')
    retrieval_module = importlib.import_module(package + '.retrieval')
    decision_module = importlib.import_module(package + '.decisions')
    from matryoshka_demo import runner_v2
    c = case(task='hypothesis')
    plan = supplied_plan(c)
    context = context_for(sql)
    checked = []
    pins, environment = {'fixture': 'pin'}, {'fixture': 'language-resource'}
    monkeypatch.setattr(workflow, 'code_pins', lambda: pins)
    monkeypatch.setattr(runner_v2, 'environment_binding', lambda root: environment)
    if package == 'matryoshka_narrative':
        monkeypatch.setattr(workflow, 'validate_plan', lambda p, c: p)
        monkeypatch.setattr(workflow, 'require_headroom', lambda p: None)
    else:
        monkeypatch.setattr(workflow.planning, 'validate_plan', lambda p, c: p)

    def retrieve(corpus, actual_case, actual_plan, *, source_index, **kwargs):
        assert policy_of(corpus) is policy_of(source_index) is mode
        policy = SourcePolicy(corpus, actual_case, source_index)
        positions = [i for i in range(len(corpus.pages)) if policy.allowed(i)]
        return dict(eligible=corpus.eligible(actual_case), source_policy=policy, pages=positions,
            passage_budget=80, receipt=dict(source_view_policy=descriptor(mode)))

    def role_bindings(projected_case, projected_plan, admitted, index):
        assert policy_of(index[0]) is mode
        for p in admitted.values():
            reconstruction._citation(p, 0, len(p['text']), index, projected_case)
        checked.extend(admitted)
        return []

    def execute(actual_case, actual_plan, retrieval, *, source_index, **kwargs):
        assert policy_of(source_index) is mode
        ids = [retrieval['eligible'].corpus.pages[i]['id'] for i in retrieval['pages']]
        bounded = dict(retrieval, inspected_page_ids=ids, source_pages_inspected=len(ids))
        decisions._historical_role_certificates(actual_case, actual_plan, bounded,
            source_index, retrieval['source_policy'])
        return dict(task=actual_case['task'], status='UNRESOLVED', inspected_page_ids=ids,
            query_sha256=digest(actual_case['query']), provided_plan_sha256=digest(actual_plan))

    monkeypatch.setattr(retrieval_module, 'retrieve', retrieve)
    monkeypatch.setattr(decision_module, 'execute', execute)
    monkeypatch.setattr(hypothesis_claims, 'role_claim_bindings', role_bindings)
    session = workflow.Session.__new__(workflow.Session)
    session.pins = pins
    session.narrative_pins = pins
    session.root = HERE
    session.environment = environment
    session.refs = dict(index_refs={'cib': {'fixture': 'actual-index-reference'}})
    session.context = lambda corpus: context
    try:
        packet = session.execute(c, plan, source_view_policy=mode)
        expected = {'early'}
        if mode is not STRICT_PRIOR:
            expected.add('early-origin')
        if mode is SOURCE_DAY_INCLUSIVE:
            expected.add('same-origin')
        assert set(checked) == expected
        assert packet['result']['source_view_policy'] == descriptor(mode)
        if package == 'matryoshka_narrative':
            assert packet['native_checksum'] == digest(packet['result'])
        assert policy_of(context.corpus) is policy_of(context.source_index) is STRICT_PRIOR
    finally:
        if sql:
            context.source_index.close()


@pytest.mark.parametrize('mode', MODES)
def test_reconstruction_retains_same_typed_guard_and_rejects_later_secret_future(monkeypatch, mode):
    context = context_for(False)
    view = apply_source_view(context, mode)
    c = case(task='reconstruction')
    policy = SourcePolicy(view.corpus, c, view.source_index)
    ids = [p['id'] for i, p in enumerate(view.corpus.pages) if policy.allowed(i)]
    bounded = dict(passage_budget=80, inspected_page_ids=ids, source_pages_inspected=len(ids))

    def assemble(projected_case, projected_plan, retrieval, source_index):
        index, admitted, _, _ = reconstruction._sources(projected_case, retrieval, source_index)
        assert policy_of(index[0]) is mode
        assert set(admitted) == set(ids)
        return dict(version='fixture-assembly', atoms=[])

    monkeypatch.setattr(reconstruction, 'assemble', assemble)
    decisions._assembly_certificates(c, supplied_plan(c), bounded, view.source_index, policy)
    for pid in ['later', 'secret', 'future']:
        with pytest.raises(ValueError):
            reconstruction._sources(c, dict(passage_budget=1, inspected_page_ids=[pid],
                source_pages_inspected=1), view.source_index)


def test_v2_scoring_receives_exact_validated_plan(monkeypatch):
    from matryoshka_narrative import workflow, retrieval, terminal_scores
    from matryoshka_demo import runner_v2
    context = context_for(False)
    c = case(task='hypothesis')
    plan = supplied_plan(c)
    pins, environment = {'fixture': 'pin'}, {}
    monkeypatch.setattr(workflow, 'code_pins', lambda: pins)
    monkeypatch.setattr(workflow, 'validate_plan', lambda p, c: p)
    monkeypatch.setattr(workflow, 'require_headroom', lambda p: None)
    monkeypatch.setattr(runner_v2, 'environment_binding', lambda root: environment)
    monkeypatch.setattr(retrieval, 'retrieve', lambda *a, **kw: dict(receipt={}))
    monkeypatch.setattr(decisions, 'execute', lambda *a, **kw: dict(task='hypothesis',
        status='UNRESOLVED', query_sha256=digest(c['query']), provided_plan_sha256=digest(plan)))
    seen = []

    def annotate(result, receipt, *, rerank, top_k, plan, version):
        assert plan == supplied_plan(c) and rerank is True and top_k == 5
        assert version == terminal_scores.LEGACY_VERSION
        seen.append(deepcopy(plan))
        return deepcopy(result)

    monkeypatch.setattr(terminal_scores, 'annotate_result', annotate)
    session = workflow.Session.__new__(workflow.Session)
    session.narrative_pins = pins
    session.root = HERE
    session.environment = environment
    session.refs = dict(index_refs={'cib': {}})
    session.context = lambda corpus: context
    session.execute(c, plan, terminal_ranking='evidence_fit_v2')
    assert seen == [plan]
    session.execute(c, plan)
    assert seen == [plan]
