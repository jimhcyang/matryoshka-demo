from copy import deepcopy
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from recover_rebound_plan import checked_rebind, read


def fixture():
    audit = next(r for r in read(HERE / "plan_compatibility.json")["cases"] if not r["original_valid"])
    entry = next(e for e in read(HERE / "baseline_catalog.json")["cases"]
        if e["case"]["case_id"] == audit["case_id"])
    return entry, deepcopy(audit)


def test_exact_raw_rebind_preserves_atoms_receipt_and_projection_losses():
    entry, audit = fixture()
    old, rebound, readings = checked_rebind(entry, audit)
    assert old["plan"]["atoms"] == rebound["atoms"]
    assert old["plan"]["raw_output_sha256"] == rebound["raw_output_sha256"]
    assert old["plan"]["projection_qc"] == rebound["projection_qc"]
    assert old["plan"]["receipt"] == rebound["receipt"]
    assert old["plan"]["readings_packet"] == readings
    assert len(audit["differences"]) == 3


def test_no_atom_or_loss_rewrite():
    entry, audit = fixture()
    audit["rebound_plan"]["atoms"][0]["text"] += " changed"
    with pytest.raises(ValueError):
        checked_rebind(entry, audit)


def test_no_unreviewed_or_unknown_downgrade():
    entry, audit = fixture()
    audit["differences"][0]["after"] = False
    with pytest.raises(ValueError, match="non-conservative"):
        checked_rebind(entry, audit)
