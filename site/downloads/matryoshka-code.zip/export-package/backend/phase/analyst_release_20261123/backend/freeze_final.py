"""Freeze a final terminal-stage boundary and its exact trusted parents."""
import argparse
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from matryoshka_demo.io import digest, offline
from matryoshka_narrative import workflow
from matryoshka_next.workflow import read, put_immutable
from run_regression import ref


def passed(path, minimum):
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    count = sum(int(s.get('tests', 0)) for s in suites)
    assert count >= minimum and all(int(s.get('failures', 0)) == int(s.get('errors', 0)) == 0 for s in suites)
    return count


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--score-sha256', required=True)
    args = parser.parse_args()
    old = read(HERE / 'BACKEND_FROZEN_EPOCH2.json')
    tests = passed(HERE / 'final-confirm-tests.xml', 307)
    score_tests = passed(HERE / 'final-score-tests.xml', 18)
    passed(HERE / 'final-viewer-tests.xml', 1)
    score = ref(ROOT / 'matryoshka_narrative/terminal_scores.py')
    assert score['sha256'] == args.score_sha256
    with offline():
        pins = workflow.code_pins()
        assert set(pins) == set(old['code_pins'])
        assert all(pins[k] == old['code_pins'][k] for k in pins if k not in workflow.TERMINAL_STAGE_PINS)
        record = dict(status='BACKEND_FROZEN', version='analyst-release-terminal-freeze/1',
            code_pins=pins, code_pins_digest=digest(pins), terminal_scoring=score,
            allowed_parent_pin_differences=sorted(workflow.TERMINAL_STAGE_PINS),
            replay_helper_file='matryoshka_narrative/workflow.py',
            final_runner=ref(HERE / 'run_final.py'), runner_dependencies=[ref(HERE / 'run_regression.py')],
            parent_backend_freeze=ref(HERE / 'BACKEND_FROZEN_EPOCH2.json'),
            ordinary_parent_manifest=ref(HERE / 'epoch2/regression_results.json'),
            selected_parent_manifest=ref(HERE.parent / 'delegation/selected_cases_epoch2.json'),
            tests=ref(HERE / 'final-confirm-tests.xml'), tests_passed=tests,
            score_tests=ref(HERE / 'final-score-tests.xml'), score_tests_passed=score_tests,
            normal_viewer_tests=ref(HERE / 'final-viewer-tests.xml'),
            interface=ref(HERE / 'INTERFACE_FINAL.md'), terminal_ranking='evidence_fit_v3',
            terminal_stage_execution=True, constructor_reexecuted=False, api_calls=0,
            original_packets_modified=False, qualifications_inherited=False,
            code_edits_after_freeze_forbidden=True)
        pin = put_immutable(HERE / 'BACKEND_FROZEN_FINAL.json', record)
        print('BACKEND_FROZEN_FINAL', pin['sha256'])
        print('CODE_PINS_DIGEST', record['code_pins_digest'])
        print('TESTS', tests, 'SCORE_TESTS', score_tests)


if __name__ == '__main__':
    main()
