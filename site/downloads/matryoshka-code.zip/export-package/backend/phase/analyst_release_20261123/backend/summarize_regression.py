"""Read-only comparison of sealed native outputs; not case qualification."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def read(path):
    with (gzip.open(path, "rt") if path.suffix == ".gz" else path.open()) as stream:
        return json.load(stream)


def load_ref(reference):
    path = ROOT / reference["path"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != reference["sha256"]:
        raise ValueError("Artifact bytes changed: " + str(path))
    return read(path)


def gate(candidate):
    return dict(status=candidate.get("local_decision", {}).get("status"),
        support=candidate.get("support_assessment"))


def branch_delta(old, new, pre_terminal, pool):
    before = {c["id"]: c for c in old.get("candidates", [])}
    after = {c["id"]: c for c in new.get("candidates", [])}
    return dict(reading_id=new["reading"]["id"],
        historical=[dict(id=c["id"], fill=c["fill"], rank=c["rank"], **gate(c))
            for c in before.values()],
        fresh=[dict(id=c["id"], fill=c["fill"], rank=c["rank"], **gate(c),
            score=c.get("terminal_scorecard", {}).get("score")) for c in after.values()],
        pre_terminal=[dict(id=cid, fill=pool.get(cid, {}).get("fill")) for cid in pre_terminal],
        shared_id_changes=[dict(id=cid, fill=after[cid]["fill"],
            old_rank=before[cid]["rank"], new_rank=after[cid]["rank"],
            old_gate=gate(before[cid]), new_gate=gate(after[cid]))
            for cid in after if cid in before],
        new_display_ids=[cid for cid in after if cid not in before],
        no_longer_displayed_ids=[cid for cid in before if cid not in after])


def atom_summary(result):
    return [dict(id=a["id"], text=a["text"], status=a["status"],
        criterion_state=a.get("criterion_state"),
        evidence_rows=len(a.get("evidence", a.get("positive_evidence", []))),
        counter_rows=len(a.get("counterevidence", [])),
        partial_rows=len(a.get("partial_evidence", []))) for a in result.get("atoms", [])]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epoch2', action='store_true')
    args = parser.parse_args()
    directory = HERE / 'epoch2' if args.epoch2 else HERE
    source = directory / ('regression_results.json' if args.epoch2 else 'final_regression_results.json')
    progress = read(source if source.exists() else directory / "regression_progress.json")
    catalog = read(HERE / "baseline_catalog.json")
    baseline = {e["case"]["case_id"]: e for e in catalog["cases"]}
    rows = []
    for row in progress["cases"]:
        cid = row["case"]["case_id"]
        if row["status"] == "ERROR":
            rows.append(dict(case_id=cid, status="ERROR", error=row["error"],
                error_type=row["error_type"]))
            continue
        old = load_ref(baseline[cid]["baseline_native"])
        new = load_ref(row["native_ref"])
        pool = {c["id"]: c for c in new["result"].get("assessed_candidates", [])}
        old_branches = {r["reading"]["id"]: r for r in old["result"].get("readings", [])}
        pre = {r["reading_id"]: r["candidate_ids"]
            for r in new["result"].get("pre_terminal_candidate_order", [])}
        before = old["retrieval"]
        after = new["retrieval"]
        rows.append(dict(case_id=cid, corpus=row["case"]["corpus"], task=row["case"]["task"],
            status="OBSERVED_NATIVE_OUTPUT_NOT_QUALIFICATION", native_ref=row["native_ref"],
            plan_rebind_ref=row.get("plan_rebind_ref"),
            outputs=row["outputs"], native_status_before=old["result"]["status"],
            native_status_after=new["result"]["status"],
            strict_atomic_order_unchanged=row["strict_atomic_order_unchanged"],
            eligible_pages_before=before.get("eligible_pages"),
            eligible_pages_after=after.get("eligible_pages"),
            source_order_before=[p["page_id"] for p in before.get("top_sources", [])],
            source_order_after=[p["page_id"] for p in after.get("top_sources", [])],
            full_pool_size_before=len(old["result"].get("assessed_candidates", [])),
            full_pool_size_after=len(pool),
            branches=[branch_delta(old_branches.get(r["reading"]["id"], {}), r,
                pre.get(r["reading"]["id"], []), pool) for r in new["result"].get("readings", [])],
            atoms_before=atom_summary(old["result"]), atoms_after=atom_summary(new["result"]),
            timings=new["timings"], source_audit=load_ref(row["source_audit"])))
    output = dict(version="exact-native-regression-observation/1", status=progress["status"],
        requested=14, observed=len(rows), api_calls=0, reference_answers_read=False,
        old_qualification_inherited=False, cases=rows,
        interpretation="Joint atom-only/inclusive/scored experiment; only strict retrieval is a separate real control. "
            "Pre-terminal order isolates ranking on the new pool, not source-policy effects on construction.")
    target = directory / "observed_deltas.json"
    target.write_text(json.dumps(output, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    print(output["status"], "observed", len(rows), "errors", sum(r["status"] == "ERROR" for r in rows))
    for r in rows:
        print(r["case_id"], r.get("native_status_before"), "->", r.get("native_status_after"),
            "strict retrieval unchanged", r.get("strict_atomic_order_unchanged"))
        for b in r.get("branches", []):
            print(" ", b["reading_id"], "old", [(c["fill"], c["status"]) for c in b["historical"][:1]],
                "new", [(c["fill"], c["status"]) for c in b["fresh"][:1]])


if __name__ == "__main__":
    main()
