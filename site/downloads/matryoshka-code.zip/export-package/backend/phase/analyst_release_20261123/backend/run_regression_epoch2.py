"""Epoch-2 API0 native experiment; never rewrites an earlier epoch or baseline."""
from copy import deepcopy
import gc
from pathlib import Path
import shutil
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'epoch2'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from matryoshka_demo.io import digest, offline
from matryoshka_next.workflow import read, put, put_immutable
from matryoshka_narrative import workflow
from matryoshka_narrative.retrieval import retrieve
from matryoshka_narrative.planning import validate_plan
from matryoshka_narrative.contracts import engine_case
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, descriptor, apply_source_view
from run_regression import ref, load_pinned, options, orders, retrieval_control, source_audit, export
from recover_rebound_plan import checked_rebind


def saved_plan(entry, compatibility):
    old = load_pinned(entry['baseline_native'])
    base = deepcopy(old['plan'])
    selected = base.pop('readings_packet', None)
    rebind = None
    try:
        validate_plan(base, engine_case(entry['case']))
    except ValueError:
        audit = compatibility.get(entry['case']['case_id'])
        if audit is None:
            raise
        old, base, selected = checked_rebind(entry, audit)
        rebind = dict(audit, original_native=entry['baseline_native'],
            exact_saved_plan_replication=False, query_and_readings_changed=False)
    if rebind is None and digest(base) != entry['base_plan_sha256']:
        raise ValueError('A valid original plan must remain exactly unchanged')
    if digest(selected) != entry['reading_packet_sha256']:
        raise ValueError('Original saved reading packet changed')
    return old, base, selected, rebind


def main():
    freeze = read(HERE / 'BACKEND_FROZEN_EPOCH2.json')
    if freeze['status'] != 'BACKEND_FROZEN' or workflow.code_pins() != freeze['code_pins']:
        raise ValueError('Epoch2 is not the current explicitly frozen engine')
    if ref(Path(__file__)) != freeze['regression_runner']:
        raise ValueError('Epoch2 runner changed')
    for reference in freeze['runner_dependencies']:
        if ref(ROOT / reference['path']) != reference:
            raise ValueError('Pinned experiment helper changed')
    catalog = load_pinned(freeze['baseline_catalog'])
    compatibility = {r['case_id']: r for r in load_pinned(freeze['plan_compatibility'])['cases']
        if not r['original_valid']}
    plans = {e['case']['case_id']: saved_plan(e, compatibility) for e in catalog['cases']}
    workflow.OUTPUT = OUT / 'execution'
    rows, active = [], {}
    started = time.time()

    def progress(status='RUNNING'):
        put(OUT / 'regression_progress.json', dict(status=status, completed=len(rows), requested=14,
            current=deepcopy(active), cases=rows, api_calls=0, qualified_new_cases=[],
            source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE), terminal_ranking='evidence_fit_v2',
            frozen_backend=ref(HERE / 'BACKEND_FROZEN_EPOCH2.json')))

    progress()
    with offline():
        for corpus_id in ['cib', 'iran', 'vietnam']:
            with workflow.Session() as session:
                context = scoped = packet = None
                for entry in [e for e in catalog['cases'] if e['case']['corpus'] == corpus_id]:
                    case = entry['case']
                    active.clear()
                    active.update(case_id=case['case_id'], stage='opening_actual_source_context')
                    progress()
                    target = None
                    begin = time.perf_counter()
                    try:
                        if shutil.disk_usage(HERE).free < 3 * 1024**3:
                            raise OSError('Agreed 3 GiB minimum; canonical workflow separately retains 8 GiB guard')
                        if workflow.code_pins() != freeze['code_pins']:
                            raise ValueError('Backend drift before new execution')
                        old, base, selected, rebind = plans[case['case_id']]
                        opts = options(entry['configuration'])
                        settings = workflow.configuration(**opts, source_view_policy=SOURCE_DAY_INCLUSIVE,
                            terminal_ranking='evidence_fit_v2')
                        full_plan = deepcopy(base)
                        if selected is not None:
                            full_plan['readings_packet'] = deepcopy(selected)
                        key = digest(dict(version='exact14-epoch2-native-experiment/1', case=case,
                            original_plan_sha256=entry['original_plan_sha256'],
                            actual_plan_sha256=digest(full_plan), configuration=settings,
                            frozen_backend=ref(HERE / 'BACKEND_FROZEN_EPOCH2.json')))
                        directory = OUT / 'runs' / key
                        target = directory / 'native.json.gz'
                        if rebind is not None:
                            put_immutable(directory / 'plan_rebind.json', rebind)
                        context = session.context(corpus_id)
                        if old['binding'] != session.refs['index_refs'][corpus_id]:
                            raise ValueError('Original normal-engine source/index binding is unavailable or changed')
                        active['stage'] = 'strict_atom_only_retrieval_control'
                        progress()
                        control_path = directory / 'strict_atomic_retrieval.json.gz'
                        if not control_path.exists():
                            strict = retrieve(context.corpus, old['case'], full_plan, source_index=context.source_index,
                                method=opts['method'], passage_budget=opts['passage_budget'],
                                document_budget=opts['document_budget'], discovery_profile=opts.get('discovery_profile'))
                            control = retrieval_control(old, strict)
                            control['derived_plan_rebound'] = rebind is not None
                            put_immutable(control_path, control)
                            del strict
                        expected = dict(pins=freeze['code_pins'], binding=session.refs['index_refs'][corpus_id],
                            environment=session.environment, settings=settings)
                        active['stage'] = 'new_inclusive_v2_native_execution'
                        progress()
                        if target.exists():
                            packet = read(target)
                            workflow.validate_packet(packet, case, base, selected, **expected)
                            if read(target.with_name('completion.json')) != workflow._completion(target, packet, key):
                                raise ValueError('Epoch2 completion seal changed')
                            cached = True
                        else:
                            packet = session.execute(case, base, readings_packet=selected, **opts,
                                source_view_policy=SOURCE_DAY_INCLUSIVE, terminal_ranking='evidence_fit_v2')
                            workflow.validate_packet(packet, case, base, selected, **expected)
                            put_immutable(target, packet)
                            put_immutable(target.with_name('completion.json'), workflow._completion(target, packet, key))
                            cached = False
                        native_ref = ref(target)
                        active['stage'] = 'source_audit_and_ordinary_export'
                        progress()
                        scoped = apply_source_view(context, settings['source_view_policy'])
                        put_immutable(directory / 'source_audit.json', source_audit(packet, scoped))
                        put_immutable(directory / 'candidate_pools.json.gz', dict(
                            scope='POSTFILTERED_NATIVE_VIABLE_ONLY_NOT_REJECTED_PROPOSALS',
                            baseline_native=entry['baseline_native'], baseline_order=entry['baseline_order'],
                            baseline_pool=old['result'].get('assessed_candidates', []), new_native=native_ref,
                            new_pool=packet['result'].get('assessed_candidates', []),
                            pre_terminal_candidate_order=packet['result'].get('pre_terminal_candidate_order', []),
                            new_display_order=orders(packet['result']), support_or_pool_membership_relabelled=False))
                        output = export(packet, native_ref, context, directory)
                        if rebind is not None:
                            output['plan_rebind_ref'] = ref(directory / 'plan_rebind.json')
                        control = read(control_path)
                        row = dict(case=case, status='NATIVE_COMPLETE_REVIEW_PENDING', api_calls=0,
                            native_status=packet['result']['status'], baseline_native_status=entry['baseline_status'],
                            native_ref=native_ref, configuration=packet['configuration'], outputs=output,
                            source_audit=ref(directory / 'source_audit.json'),
                            candidate_pools_ref=ref(directory / 'candidate_pools.json.gz'),
                            strict_atomic_control_ref=ref(control_path),
                            strict_atomic_order_unchanged=control['identical_order'],
                            baseline_order=entry['baseline_order'], new_order=orders(packet['result']),
                            qualification_inherited=False, exact_saved_plan_replication=rebind is None,
                            plan_rebind_ref=output.get('plan_rebind_ref'), cached_new_execution=cached)
                        print('EPOCH2_NATIVE_READY', case['case_id'], packet['result']['status'],
                            native_ref['path'], flush=True)
                    except Exception as error:
                        row = dict(case=case, status='ERROR', failed_stage=active['stage'], api_calls=0,
                            error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc(),
                            native_ref=ref(target) if target is not None and target.exists() else None,
                            qualification_inherited=False)
                        print('EPOCH2_EXPLICIT_ERROR', case['case_id'], active['stage'], str(error), flush=True)
                    row['wall_seconds'] = time.perf_counter() - begin
                    rows.append(row)
                    progress()
                    if workflow.code_pins() != freeze['code_pins']:
                        raise ValueError('Engine changed: retain outputs and stop')
            del session
            context = scoped = packet = None
            gc.collect()
    active.clear()
    status = 'COMPLETE' if all(r['status'] != 'ERROR' for r in rows) else 'COMPLETE_WITH_EXPLICIT_ERRORS'
    progress(status)
    result = read(OUT / 'regression_progress.json')
    result.update(started_at=started, ended_at=time.time(), historical_baseline_not_modified=True,
        previous_epoch_not_modified=True, exact_saved_plan_cases=13,
        derived_plan_rebind_cases=list(compatibility),
        interpretation='Actual new native executions; one documented exact-retained-raw plan rebind. '
            'Joint policy/ranking/current-engine experiment, not a pure policy-only construction ablation; no qualification inherited.')
    put_immutable(OUT / 'regression_results.json', result)
    put(OUT / 'regression_progress.json', result)
    print('EPOCH2_' + status, len(rows), flush=True)


if __name__ == '__main__':
    main()
