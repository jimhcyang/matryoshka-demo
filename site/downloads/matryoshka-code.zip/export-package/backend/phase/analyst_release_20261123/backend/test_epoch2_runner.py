"""Preflight saved plans and original native budgets without native execution."""
from pathlib import Path
import sys

import pytest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import run_regression_epoch2 as runner
from matryoshka_demo.io import offline, digest


def inputs():
    entries = runner.read(HERE / 'baseline_catalog.json')['cases']
    audits = {r['case_id']: r for r in runner.read(HERE / 'plan_compatibility.json')['cases']
        if not r['original_valid']}
    return entries, audits


def test_fourteen_saved_plans_only_one_exact_raw_conservative_rebind():
    entries, audits = inputs()
    changed = []
    with offline():
        for entry in entries:
            old, plan, readings, rebind = runner.saved_plan(entry, audits)
            assert digest(readings) == entry['reading_packet_sha256']
            assert plan['atoms'] == old['plan']['atoms']
            assert plan['raw_output_sha256'] == old['plan']['raw_output_sha256']
            assert plan['projection_qc'] == old['plan']['projection_qc']
            if rebind is None:
                assert digest(plan) == entry['base_plan_sha256']
            else:
                changed.append(entry['case']['case_id'])
                assert rebind['exact_saved_plan_replication'] is False
    assert len(entries) == 14 and changed == list(audits)


def test_unreviewed_plan_failure_is_not_silently_rebound(monkeypatch):
    entries, _ = inputs()
    def invalid(*args):
        raise ValueError('Unreviewed derived annotation')
    monkeypatch.setattr(runner, 'validate_plan', invalid)
    with pytest.raises(ValueError, match='Unreviewed'):
        runner.saved_plan(entries[0], {})


def test_all_fourteen_budget_profiles_retained_exactly():
    entries, _ = inputs()
    for entry in entries:
        old = entry['configuration']
        opts = runner.options(old)
        assert opts['passage_budget'] == old['retrieval_passage_budget']
        assert opts['document_budget'] == old['retrieval_document_budget']
        assert opts['construction_pages'] == old['construction_pages']
        assert opts['draft_budget'] == old['completed_drafts_per_reading']
        assert opts.get('selection_profile') == old.get('selection_profile')
        assert opts.get('discovery_profile') == old.get('discovery_profile')
        assert old['top_k'] == 5
