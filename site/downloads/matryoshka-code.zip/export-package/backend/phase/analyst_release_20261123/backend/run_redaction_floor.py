"""Uniform public Redaction resource floor, separate from exact-budget controls."""
import argparse
from copy import deepcopy
from pathlib import Path
import shutil
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = HERE / 'redaction_floor'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
from matryoshka_demo.io import digest, offline
from matryoshka_next.workflow import read, put, put_immutable
from matryoshka_narrative import workflow
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, apply_source_view
from run_regression import ref, load_pinned, options, orders, source_audit, export
from run_regression_epoch2 import saved_plan

RULE = dict(version='uniform-public-redaction-resource-floor/1', task='redaction',
    construction_pages='max(original,32)', completed_drafts_per_reading='max(original,64)',
    other_budgets_profiles_query_plan_readings_policy_and_scoring_unchanged=True,
    named_case_or_candidate_conditions=False, substantive_support_gates_unchanged=True)


def floor_options(entry):
    opts = options(entry['configuration'])
    if entry['case']['task'] == 'redaction':
        opts['construction_pages'] = max(opts['construction_pages'], 32)
        opts['draft_budget'] = max(opts['draft_budget'], 64)
    return opts


def needs_execution(entry):
    return entry['case']['task'] == 'redaction' and floor_options(entry) != options(entry['configuration'])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--wait-for-epoch2', action='store_true')
    args = parser.parse_args()
    freeze = read(HERE / 'BACKEND_FROZEN_EPOCH2.json')
    receipt = read(HERE / 'REDACTION_FLOOR_FROZEN.json')
    if receipt['backend_freeze'] != ref(HERE / 'BACKEND_FROZEN_EPOCH2.json'):
        raise ValueError('Floor experiment backend binding changed')
    if receipt['runner'] != ref(Path(__file__)) or receipt['resource_floor'] != RULE:
        raise ValueError('Uniform resource-floor runner or rule changed')
    for dependency in receipt['dependencies']:
        if ref(ROOT / dependency['path']) != dependency:
            raise ValueError('Floor experiment dependency changed')
    result_path = HERE / 'epoch2/regression_results.json'
    deadline = time.monotonic() + 7200
    while not result_path.exists():
        if not args.wait_for_epoch2:
            raise ValueError('Exact-budget epoch2 must finish before the supplemental native workload')
        if time.monotonic() >= deadline:
            raise TimeoutError('Bounded two-hour wait ended; no supplemental native executed')
        time.sleep(5)
    control = read(result_path)
    if control['completed'] != 14 or len(control['cases']) != 14:
        raise ValueError('The ordinary exact-budget14 is incomplete')
    if workflow.code_pins() != freeze['code_pins']:
        raise ValueError('Frozen engine changed; no resource-floor execution allowed')
    catalog = load_pinned(freeze['baseline_catalog'])
    audits = {r['case_id']: r for r in load_pinned(freeze['plan_compatibility'])['cases']
        if not r['original_valid']}
    control_rows = {r['case']['case_id']: r for r in control['cases']}
    entries = [e for e in catalog['cases'] if e['case']['task'] == 'redaction']
    manifest = [dict(case_id=e['case']['case_id'], baseline_configuration=e['configuration'],
        floor_options=floor_options(e), supplemental_execution_required=needs_execution(e),
        control_native_ref=control_rows[e['case']['case_id']].get('native_ref')) for e in entries]
    put_immutable(OUT / 'uniform_floor_catalog.json', dict(resource_floor=RULE,
        exact_budget14_ref=ref(result_path), all_published_redaction_cases=manifest,
        missing_control_errors=[r['case']['case_id'] for r in control['cases'] if r['status'] == 'ERROR'],
        non_redaction_budgets_changed=False, public_records_modified=False))
    workflow.OUTPUT = OUT / 'execution'
    rows = []
    with offline():
        for entry in [e for e in entries if needs_execution(e)]:
            case = entry['case']
            target = None
            begin = time.perf_counter()
            try:
                if shutil.disk_usage(HERE).free < 3 * 1024**3:
                    raise OSError('Agreed 3 GiB floor; canonical workflow additionally retains 8 GiB guard')
                baseline = control_rows[case['case_id']]
                if baseline['status'] != 'NATIVE_COMPLETE_REVIEW_PENDING':
                    raise ValueError('Supplemental case lacks its completed exact-budget native control')
                before = load_pinned(baseline['native_ref'])
                _, base, selected, rebind = saved_plan(entry, audits)
                opts = floor_options(entry)
                settings = workflow.configuration(**opts, source_view_policy=SOURCE_DAY_INCLUSIVE,
                    terminal_ranking='evidence_fit_v2')
                key = digest(dict(resource_floor=RULE, control_native=baseline['native_ref'],
                    configuration=settings, code_pins=freeze['code_pins'], runner=receipt['runner']))
                directory = OUT / 'runs' / key
                target = directory / 'native.json.gz'
                with workflow.Session() as session:
                    context = session.context(case['corpus'])
                    expected = dict(pins=freeze['code_pins'], binding=session.refs['index_refs'][case['corpus']],
                        environment=session.environment, settings=settings)
                    if before['binding'] != expected['binding']:
                        raise ValueError('Actual normal-engine source binding differs from exact-budget control')
                    if target.exists():
                        packet = read(target)
                        workflow.validate_packet(packet, case, base, selected, **expected)
                        if read(target.with_name('completion.json')) != workflow._completion(target, packet, key):
                            raise ValueError('Supplemental completion seal changed')
                    else:
                        packet = session.execute(case, base, readings_packet=selected, **opts,
                            source_view_policy=SOURCE_DAY_INCLUSIVE, terminal_ranking='evidence_fit_v2')
                        workflow.validate_packet(packet, case, base, selected, **expected)
                        put_immutable(target, packet)
                        put_immutable(target.with_name('completion.json'), workflow._completion(target, packet, key))
                    if packet['plan'] != before['plan']:
                        raise ValueError('Resource-floor experiment altered original control plan/readings')
                    native_ref = ref(target)
                    scoped = apply_source_view(context, settings['source_view_policy'])
                    put_immutable(directory / 'source_audit.json', source_audit(packet, scoped))
                    put_immutable(directory / 'candidate_pools.json.gz', dict(control_native=baseline['native_ref'],
                        new_native=native_ref, new_pool=packet['result'].get('assessed_candidates', []),
                        pre_terminal_candidate_order=packet['result'].get('pre_terminal_candidate_order', []),
                        scope='POSTFILTERED_NATIVE_VIABLE_ONLY_NOT_REJECTED_PROPOSALS'))
                    outputs = export(packet, native_ref, context, directory)
                    row = dict(case=case, status='NATIVE_COMPLETE_REVIEW_PENDING', native_ref=native_ref,
                        outputs=outputs, control_native_ref=baseline['native_ref'], configuration=settings,
                        control_configuration=before['configuration'], resource_floor=RULE,
                        source_audit_ref=ref(directory / 'source_audit.json'),
                        candidate_pools_ref=ref(directory / 'candidate_pools.json.gz'),
                        control_order=orders(before['result']), new_order=orders(packet['result']),
                        control_pool_size=len(before['result'].get('assessed_candidates', [])),
                        new_pool_size=len(packet['result'].get('assessed_candidates', [])),
                        control_inspected_pages=len(before['result']['inspected_page_ids']),
                        new_inspected_pages=len(packet['result']['inspected_page_ids']),
                        retrieval_order_unchanged=[p['page_id'] for p in before['retrieval']['top_sources']]
                            == [p['page_id'] for p in packet['retrieval']['top_sources']],
                        plan_and_readings_unchanged=True, candidate_rank_forced=False,
                        native_status=packet['result']['status'], control_native_status=before['result']['status'],
                        api_calls=0, qualification_inherited=False, adoption='PENDING_QUALITY_REVIEW')
                    print('FLOOR_NATIVE_READY', case['case_id'], native_ref['path'], flush=True)
            except Exception as error:
                row = dict(case=case, status='ERROR', error_type=type(error).__name__, error=str(error),
                    traceback=traceback.format_exc(), api_calls=0,
                    native_ref=ref(target) if target is not None and target.exists() else None)
                print('FLOOR_EXPLICIT_ERROR', case['case_id'], str(error), flush=True)
            row['wall_seconds'] = time.perf_counter() - begin
            rows.append(row)
            put(OUT / 'progress.json', dict(status='RUNNING', resource_floor=RULE, cases=rows))
    result = dict(status='COMPLETE' if all(r['status'] != 'ERROR' for r in rows) else 'COMPLETE_WITH_EXPLICIT_ERRORS',
        api_calls=0, resource_floor=RULE, cases=rows, actual_supplemental_executions=len(rows),
        all_published_redaction_cases=manifest, redaction_cases_already_at_or_above_floor=len(entries)-len(rows),
        exact_budget14_ref=ref(result_path), backend_freeze=receipt['backend_freeze'],
        floor_experiment_freeze=ref(HERE / 'REDACTION_FLOOR_FROZEN.json'),
        public_records_modified=False, adoption='PENDING_QUALITY_REVIEW', qualified_new_cases=[])
    put_immutable(OUT / 'results.json', result)
    print('FLOOR_' + result['status'], len(rows), flush=True)


if __name__ == '__main__':
    main()
