"""No implicit upgrades of old results when the executable engine changes."""
import unittest
from unittest.mock import patch

import code_epochs


class CodeEpochTests(unittest.TestCase):
    def setUp(self):
        self.now = {"engine.py": "current"}
        self.old = {"engine.py": "earlier"}
        self.native_ref = {"path": "saved.json.gz", "sha256": "exact"}
        self.epoch = dict(code_pins=self.now)

    def verify(self, reference, packet):
        with patch.object(code_epochs, "active_epoch", return_value=self.epoch):
            return code_epochs.native_epoch(reference, packet, self.now)

    def test_current(self):
        self.assertEqual(self.verify(self.native_ref, dict(code_pins=self.now))["kind"], "CURRENT_FROZEN_CODE")

    def test_old_checkpoint_rejected(self):
        with self.assertRaises(ValueError):
            self.verify(dict(self.native_ref, sha256="changed"), dict(code_pins=self.old))

    def test_other_historical_code_rejected(self):
        with self.assertRaises(ValueError):
            self.verify(self.native_ref, dict(code_pins={"engine.py": "unreviewed"}))

    def test_current_code_must_be_frozen(self):
        with patch.object(code_epochs, "active_epoch", return_value=self.epoch):
            with self.assertRaises(ValueError):
                code_epochs.current_epoch(self.old)


if __name__ == "__main__":
    unittest.main()
