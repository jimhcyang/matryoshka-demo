"""Guard revision: ambiguous raw provider output must not mint proof wrappers."""
import importlib.util
import json
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("live_strict_json_fixture", HERE / "test_source_pipeline.py")
O = importlib.util.module_from_spec(spec)
spec.loader.exec_module(O)
environment, no_network = O.environment, O.no_network


@pytest.mark.parametrize("bad", ["NaN", "Infinity", "-Infinity", "1e99999"])
def test_nonfinite_discarded_duplicate_is_rejected_before_proof(environment, bad):
    runtime, fake = environment
    original = fake.create
    def create(**body):
        raw = original(**body)
        if body["text"]["format"]["name"] == "live_m_assessment_v1":
            part = raw["output"][0]["content"][0]
            part["text"] = part["text"].replace('"same_target": true',
                '"same_target": '+bad+', "same_target": true', 1)
        return raw
    fake.create = create
    native, policy = O.fixture()
    result = O.S.execute(native, policy, runtime, parse=O.SourceParses())
    assert result["coverage"] == 0. and result["atoms"][0]["status"] != "SOURCE_ASCRIBED"
    for path in (runtime.api_root / "receipts").glob("*.json"):
        request = json.loads((runtime.api_root / "attempts" / path.stem / "request.json").read_text())
        if request["text"]["format"]["name"] == "live_m_assessment_v1":
            assert not (runtime.api_root / "live-source-proofs" / path.stem).exists()
