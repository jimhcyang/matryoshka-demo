"""API0 only: fake provider, temporary ledger, real source/grammar/semantic validators."""
from copy import deepcopy
import json
from pathlib import Path
import socket
import sys
from types import SimpleNamespace

import pytest

SRC = Path(__file__).resolve().parents[3]
LIVE = SRC / "phase/motion_login_20261122/live"
sys.path[:0] = [str(SRC), str(LIVE)]
import source_inference as S
import source_runtime as R
from contract import sha
from matryoshka_demo.source_view_policy import LIVE_THROUGH_WITH_EARLIER_ORIGIN as VIEW, descriptor
from matryoshka_narrative import api
from matryoshka_narrative.contracts import engine_case
from matryoshka_next.construction import SourceParses
from matryoshka_next.facts import SourcePolicy


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    monkeypatch.setattr(socket.socket, "connect", lambda *a, **k: pytest.fail("API0: network forbidden"))


def fixture(task="mosaic", query="Mira opened the gate.", text=None, corpus="vietnam", **changes):
    case = dict(case_id="arbitrary_live_input", task=task, corpus=corpus, query=query,
        document_id="opaque_origin", date="1974-03-11", focal_marker="[REDACTION]" if task == "redaction" else "")
    page = dict(id="p1", canonical_page_id="p1", document_id="eligible_doc", corpus=corpus,
        date="1974-03-11", text=text or query, classification="CONFIDENTIAL", permitted=True,
        visibility="earlier", handling=[], earlier_page=1)
    page.update(changes)
    page["source_sha256"] = sha(page["text"])
    corpus_obj = SimpleNamespace(corpus=corpus, source_view_policy=VIEW, pages=[page],
        page_index={"p1": 0}, documents={}, classification={})
    policy = SourcePolicy(corpus_obj, engine_case(case), {"p1": page})
    atom = dict(id="a1", text=query, required=True, kind="proposition", polarity="positive", modality="asserted",
        query_spans=[dict(start=0, end=len(query), text=query)])
    plan = dict(query_sha256=sha(query), atoms=[atom], task=engine_case(case)["task"], query_only=True,
        corpus_read=False, hidden_answers_read=False)
    if task == "redaction":
        reading = dict(id="next_reading_"+"0"*24, form="clausal", outer_family="clausal", role="adjunct",
            function="modifier", target_kind="any", grammatical_number="unknown", variant="default", finite=True,
            attachment_spans=[], cues=[], operators=[], wrappers=[])
        plan["readings_packet"] = dict(version="next-slot-readings/3", status="ready", query_only=True,
            source_access=False, answer_text_supplied=False, query_sha256=sha(query), case_sha256=sha(case), readings=[reading])
    result = dict(inspected_page_ids=["p1"], source_view_policy=descriptor(VIEW), status="UNCHANGED_NATIVE_HOLD")
    native = dict(public_case=case, case=engine_case(case), plan=plan, result=result, native_checksum=sha(result),
        query_only_inference=True, answers_read=False, grades_read=False, query_sha256=sha(query),
        configuration=dict(source_view_policy=descriptor(VIEW)), execution_context=dict(fixture_only=True), binding=dict(fixture="index"))
    return native, policy


def facets(fact, text):
    return {k: dict(state="MATCHED" if c["required"] else "NOT_REQUESTED",
        query_quotes=[fact["text"]] if c["required"] else [], source_quotes=[text] if c["required"] else [])
        for k, c in fact["requested_fields"].items()}


class Responses:
    def __init__(self, mutate=None):
        self.calls = []
        self.mutate = mutate

    def create(self, **body):
        payload = json.loads(body["input"][0]["content"][0]["text"])
        stage = body["text"]["format"]["name"]
        self.calls.append((stage, deepcopy(payload)))
        if stage == "live_m_assessment_v1":
            rows = []
            for fact in payload["required_facts"]:
                for page in payload["pages"]:
                    rows.append(dict(fact_id=fact["id"], page_id=page["id"], label="SUPPORT", quote=page["text"],
                        fields=facets(fact, page["text"]), authority="SOURCE_ASCRIPTION", same_target=True,
                        qualifications_retained=True, operators_retained=True, explicit_exclusion=None,
                        hypothesis_relation=None, reason="Synthetic complete source-account assessment."))
            output = dict(version="semantic-source-judgments/3", request_sha256=payload["request_sha256"], judgments=rows)
        elif stage == "live_m_review_v1":
            rows = []
            for row in payload["proposed_observations"]:
                raw = row["raw_model_row"]
                rows.append(dict(observation_row_id=row["observation_row_id"], decision="ACCEPT", label=raw["label"],
                    field_states={k:v["state"] for k,v in raw["fields"].items()}, authority=raw["authority"],
                    independent_rederivation=True, same_target=True, qualifications_retained=True, operators_retained=True,
                    anchor_binding_verified=True, whole_component_sufficient=True, directional_stance_supported=False,
                    anchor_resolutions=[dict(anchor_id=a["anchor_id"], candidate_ids=a["eligible_candidate_ids"]) for a in row["anchors"]],
                    reason="Separate full-page fixture review."))
            output = dict(version="semantic-anchor-reviews/4", request_sha256=payload["request_sha256"], reviews=rows)
        elif stage == "live_h_assessment_v1":
            rows = []
            for fact in payload["required_facts"]:
                for page in payload["pages"]:
                    rows.append(dict(fact_id=fact["id"], page_id=page["id"], direction="SUPPORT", kind="DIRECT_STANCE",
                        issue=dict(state="BOUND", owner_role_aligned=True, causal_role_compatible=True, time_scope_compatible=True,
                            query_quotes=[fact["text"]], source_quotes=[page["text"]]),
                        attribution=dict(kind="DOCUMENT_REPORTING_VOICE", speaker_quote=None), quote=page["text"],
                        argument_quote=None, qualifier_quotes=[], mode="UNQUALIFIED", fields=facets(fact, page["text"]),
                        qualifications_retained=True, operators_retained=True, reason="Synthetic source-view appraisal."))
            output = dict(version="H-source-view-appraisals/5", request_sha256=payload["request_sha256"], judgments=rows)
        elif stage == "live_h_review_v1":
            output = dict(version="H-source-view-reviews/5", request_sha256=payload["request_sha256"], reviews=[dict(
                appraisal_id=row["appraisal_id"], decision="ACCEPT", direction=row["raw_model_row"]["direction"],
                field_states={k:v["state"] for k,v in row["raw_model_row"]["fields"].items()}, issue_state="BOUND",
                independent_rederivation=True, same_issue_verified=True, owner_role_aligned=True, causal_role_compatible=True,
                time_scope_compatible=True, attribution_verified=True, document_voice_not_embedded=True,
                source_argument_explicit=True, qualifications_retained=True, operators_retained=True,
                reason="Separate full-page fixture review.") for row in payload["proposed_rows"]])
        elif stage == "live_r_proposal_v1":
            output = dict(payload["binding"], proposals=[dict(proposal_id="p1", fill="which the Bay Council discussed",
                page_id="p1", quote=payload["sources"][0]["windows"][0]["text"], source_phrase="discussed the move",
                transformation=dict(kind="PARAPHRASE", description="Source-owned relative-clause realization."))])
        elif stage == "live_r_proposal_review_v1":
            output = dict(payload["binding"], reviews=[dict(proposal_id="p1", decision="ACCEPT_CONTEXTUAL", source_fidelity="FAITHFUL",
                category="FITS", grammar="FITS", context="RELEVANT", unknown_mask_inferred=False, qualifications_preserved=True,
                reason="Separate contextual nomination review, not factual support.")])
        elif stage == "live_r_focal_assessment_v1":
            rows = []
            for item in payload["items"]:
                rows.append(dict(candidate_id=item["candidate_id"], decision="DIRECT_TARGET_SOURCE", material_fill_constraints_complete=True,
                    source_ascription_only=True, visible_query_event_certified=False, cross_document_event_join_used=False,
                    facets={k:dict(status="MATCHED", fill_quotes=[item["fill"]], public_scope_quotes=[], source_anchor_ids=["s1"],
                        reason="Synthetic bound contribution.") for k in S.engines().focal.WEIGHTS},
                    source_anchors=[dict(id="s1", page_id="p1", quote=item["original_quote"])], reason="Synthetic focal appraisal."))
            output = dict(batch_sha256=payload["binding"]["batch_sha256"], rows=rows)
        elif stage == "live_r_focal_review_v1":
            output = dict(batch_sha256=payload["binding"]["batch_sha256"], reviews=[dict(candidate_id=item["candidate_id"],
                decision="ACCEPT_SOURCE_ASCRIPTION", complete_inserted_contribution=True, correct_focal_scope=True,
                same_owner_issue_bound=True, roles_time_qualifications_preserved=True, citations_exact=True,
                no_private_event_or_cross_document_join=True, reason="Separate focal constraint review.") for item in payload["items"]])
        elif stage == "live_selected_source_digest_v1":
            output = dict(digest=" ".join(["The supplied report records a qualified source account with its original context and attribution [S1].",
                "The separately reviewed account concerns the requested issue and retains its reported limitations rather than certifying a physical event.",
                "Other inspected material provides context only where the requested connection remains unresolved, and the original native result is kept separately for inspection."]))
        else:
            raise AssertionError(stage)
        if self.mutate:
            self.mutate(stage, output)
        return dict(id="resp_mock_"+str(len(self.calls)), status="completed", output=[dict(type="message", content=[dict(
            type="output_text", text=json.dumps(output))])], usage=dict(input_tokens=10, output_tokens=10,
            total_tokens=20, input_tokens_details=dict(cached_tokens=0), output_tokens_details=dict(reasoning_tokens=0)))


@pytest.fixture
def environment(tmp_path, monkeypatch):
    # Explicitly fake ledger and provider: the real shared ledger is never opened.
    fake = Responses()
    root = tmp_path
    api_root = root / "api"
    monkeypatch.setenv("OPENAI_API_KEY", "fixture-not-a-real-key")
    monkeypatch.setattr(R, "ROOT", root)
    monkeypatch.setattr(S, "ROOT", root)
    monkeypatch.setattr(R, "ledger_total", lambda: 0.)
    monkeypatch.setattr(S, "pipeline_identity", lambda: dict(version=S.VERSION, settings=deepcopy(S.SETTINGS), engines=dict(fixture=True)))
    actual = api.call
    monkeypatch.setattr(api, "call", lambda *a, **k: actual(*a, **k, client=SimpleNamespace(responses=fake)))
    runtime = R.Runtime(root / "job", cap=1.)
    runtime.api_root = api_root
    return runtime, fake


@pytest.mark.parametrize("task", ["mosaic", "hypothesis", "redaction"])
def test_actual_shared_validators_full_pipeline_api0(environment, task):
    runtime, fake = environment
    kwargs = dict(query="The council considered a move [REDACTION].", text="The Bay Council discussed the move.", corpus="cib") if task == "redaction" else {}
    native, policy = fixture(task, **kwargs)
    before = deepcopy(native)
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert native == before
    assert result["version"] == S.VERSION and result["digest"]["available"], result.get("failures")
    assert not result["uncached_model_outputs_bit_reproducible"] and result["fixed_model_outputs_deterministic"]
    assert result["digest"]["input"]["method"]["native_method"] is False
    if task == "redaction":
        c = result["readings"][0]["candidates"][0]
        assert c["source_supported_fill_approved"] and c["provenance"] == "CORPUS", result["failures"]
        assert c["priority_index"] > 2/3 and not c["native_candidate_created"]
        assert c["completed_input"] == "The council considered a move which the Bay Council discussed."
        assert len(fake.calls) == 5
    else:
        assert result["atoms"][0]["status"] == ("SOURCE_ASCRIBED" if task == "mosaic" else "SOURCE_VIEWS_RECORDED"), result["failures"]
        assert result["assessment_scope"]["processed_slots"] == 1
        assert result["source_judgments"][0]["context_priority_index"] == 1.
        assert not result["atoms"][0]["inner_execution"] and not result["world_truth_certified"]
        assert len(fake.calls) == 3


@pytest.mark.parametrize("task", ["mosaic", "hypothesis", "redaction"])
@pytest.mark.parametrize("new_job", [False, True])
def test_exact_cached_fixed_outputs_and_math(environment, task, new_job):
    runtime, fake = environment
    kwargs = dict(query="The council considered a move [REDACTION].", text="The Bay Council discussed the move.", corpus="cib") if task == "redaction" else {}
    native, policy = fixture(task, **kwargs)
    first = S.execute(native, policy, runtime, parse=SourceParses())
    count = len(fake.calls)
    cached = R.Runtime(runtime.directory.with_name("another-job") if new_job else runtime.directory, cap=1.)
    cached.api_root = runtime.api_root
    second = S.execute(native, policy, cached, parse=SourceParses())
    assert len(fake.calls) == count
    # Cache-use telemetry is deliberately not claimed bit-identical to a first call.
    for result in (first, second):
        result.pop("provider_receipts")
        result.pop("sha256")
        if result["digest"]["available"]:
            result["digest"].pop("receipt")
    assert first == second


@pytest.mark.parametrize("change", [dict(date="1974-03-12"), dict(document_id="opaque_origin"),
    dict(classification="SECRET"), dict(permitted=False), dict(visibility="later_only"), dict(handling=["NOFORN"])])
def test_ineligible_source_rejected_before_models(environment, change):
    runtime, fake = environment
    native, policy = fixture(**change)
    with pytest.raises(ValueError):
        S.execute(native, policy, runtime, parse=SourceParses())
    assert not fake.calls


def test_earlier_origin_cib_same_day_and_cable_whole_document_veto(environment):
    runtime, _ = environment
    native, policy = fixture(corpus="cib", document_id="opaque_origin")
    assert len(S.source_input(native, policy)["pages"]) == 1
    native, policy = fixture()
    sibling = dict(policy.bound_pages["p1"], id="p2", text="NOFORN restricted sibling")
    sibling["source_sha256"] = sha(sibling["text"])
    complete = dict(policy.bound_pages, p2=sibling)
    vetoed = SourcePolicy(policy.corpus, policy.case, complete)
    with pytest.raises(ValueError):
        S.source_input(native, vetoed)


@pytest.mark.parametrize("mutation", ["quote", "operator", "review", "matrix", "flags"])
def test_m_positive_requires_grounding_whole_component_and_distinct_review(environment, mutation):
    runtime, fake = environment
    def mutate(stage, raw):
        if stage == "live_m_assessment_v1":
            if mutation == "quote": raw["judgments"][0]["quote"] = "Absent quotation."
            if mutation == "operator": raw["judgments"][0]["operators_retained"] = False
            if mutation == "matrix": raw["judgments"] = []
        if stage == "live_m_review_v1":
            if mutation == "review": raw["reviews"][0]["decision"] = "HOLD"
            if mutation == "flags": raw["reviews"][0]["whole_component_sufficient"] = False
    fake.mutate = mutate
    native, policy = fixture()
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert result["coverage"] == 0.
    assert result["atoms"][0]["status"] != "SOURCE_ASCRIBED"


def test_partial_matrix_is_not_no_evidence_or_complete(environment):
    runtime, fake = environment
    fake.mutate = lambda stage, raw: raw.update(judgments=[]) if stage == "live_m_assessment_v1" else None
    native, policy = fixture()
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert result["assessment_scope"]["unprocessed_slots"] == 1
    assert result["failures"] and not result["assessment_scope"]["inspected_pool_completely_assessed"]


def test_h_document_voice_does_not_swallow_embedded_named_speech(environment):
    runtime, fake = environment
    native, policy = fixture("hypothesis", query="The buildup could deter incursions.", text="Mira said the buildup could deter incursions.")
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert result["atoms"][0]["status"] == "UNRESOLVED"
    assert all(r["effective_direction"] == "HOLD" for r in result["source_judgments"])


def test_m_clock_and_modality_negative_remains_held(environment):
    runtime, fake = environment
    native, policy = fixture(query="Mira opened the gate.", text="Mira planned to open the gate.")
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert result["coverage"] == 0. and result["atoms"][0]["status"] != "SOURCE_ASCRIBED"


@pytest.mark.parametrize("asset", ["request", "response", "usage", "provider", "cache"])
def test_actual_four_artifact_mutation_detected(environment, asset):
    runtime, fake = environment
    native, policy = fixture()
    S.execute(native, policy, runtime, parse=SourceParses())
    proof = runtime.receipts[0]
    public = json.loads((R.ROOT / proof["provider_receipt_ref"]["path"]).read_text())
    actual = {k: R.ROOT / public["actual_"+k+"_ref"]["path"] for k in ("request", "response", "cache")}
    actual["receipt"] = R.ROOT / public["actual_api_receipt_ref"]["path"]
    body = json.loads(actual["request"].read_text())
    response = json.loads(actual["response"].read_text())
    output = api._output(response)
    meta = dict(receipt="receipts/"+proof["call_id"]+".json", cache=True)
    path = actual["receipt" if asset in {"usage", "provider"} else asset]
    raw = json.loads(path.read_text())
    if asset == "usage": raw["usage"]["total_tokens"] = 999
    elif asset == "provider": raw["response_id"] = "wrong_provider"
    else: raw["unbound_mutation"] = True
    path.write_text(json.dumps(raw))
    replay = R.Runtime(runtime.directory, cap=1.)
    replay.api_root = runtime.api_root
    with pytest.raises(ValueError): replay.attest(body, output, meta)


def test_missing_or_whitespace_key_before_any_claim(environment, monkeypatch):
    runtime, fake = environment
    monkeypatch.setenv("OPENAI_API_KEY", " \t\n")
    with pytest.raises(ValueError, match="KEY_UNCONFIGURED"):
        runtime.invoke("fixture", {}, "fixture", dict(type="object"))
    assert not runtime.api_root.exists() and not fake.calls


def test_finite_caps_and_job_envelope_not_enlarged(environment, monkeypatch):
    runtime, fake = environment
    monkeypatch.setenv("NARRATIVE_INCREMENTAL_BASELINE_USD", "0")
    monkeypatch.setenv("NARRATIVE_INCREMENTAL_CEILING_USD", "0.000001")
    native, policy = fixture()
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert not fake.calls and result["assessment_scope"]["unprocessed_slots"] == 1


def test_same_document_does_not_create_independent_votes():
    fact = dict(id="a", text="An assessment.", query_spans=[])
    rows = [dict(fact_id="a", page_id=p, document_id="doc", effective_direction="SUPPORT", context_priority_index=s,
        review={}, unanimous_model_accept=True) for p, s in (("p1", .4), ("p2", .9))]
    result = S.aggregate([fact], rows, hypothesis=True, original_pages=2)
    assert result["atoms"][0]["directional_indices"]["SUPPORT"]["value"] == .9
    assert result["coverage"] is None


@pytest.mark.parametrize("task", ["mosaic", "hypothesis", "redaction"])
def test_intake_never_runs_old_constructor_or_matcher(monkeypatch, task):
    from matryoshka_narrative import workflow, retrieval, construction, decisions, planning
    from matryoshka_demo import runner_v2
    kwargs = dict(query="The council considered a move [REDACTION].", text="The Bay Council discussed the move.", corpus="cib") if task == "redaction" else {}
    native, policy = fixture(task, **kwargs)
    query = native["case"]["query"]
    base = planning.bind(native["case"], dict(atoms=[dict(id="a1", text=query, kind="proposition", required=True,
        query_quotes=[query], subject=None, predicate=None, object=None, polarity="unknown", modality="unknown")],
        extractions=dict(entities=[], events=[], claims=[], relations=[])))
    if task == "redaction":
        from matryoshka_next.readings import compile_readings
        selected = compile_readings(native["case"])
    else:
        selected = None
    pins, environment = dict(fixture="code"), dict(fixture="language")
    context = SimpleNamespace(corpus=policy.corpus, source_index=policy.bound_pages)
    refs = dict(registry_ref=dict(path="registry", sha256="a"*64), index_refs={native["case"]["corpus"]: native["binding"]})
    session = SimpleNamespace(context=lambda _: context, narrative_pins=pins, environment=environment, refs=refs, root=SRC)
    monkeypatch.setattr(workflow, "code_pins", lambda: pins)
    monkeypatch.setattr(runner_v2, "environment_binding", lambda _: environment)
    monkeypatch.setattr(construction, "construct", lambda *a, **k: pytest.fail("old constructor must not run"))
    monkeypatch.setattr(decisions, "execute", lambda *a, **k: pytest.fail("old matcher must not run"))
    found = dict(pages=[0], source_policy=policy, receipt=dict(source_view_policy=descriptor(VIEW)))
    monkeypatch.setattr(retrieval, "retrieve", lambda *a, **k: found)
    limits = dict(method="current_hierarchy", passage_budget=48, document_budget=32, source_view_policy=VIEW)
    pipeline = dict(version=S.VERSION)
    packet, _ = S.intake(session, native["public_case"], base, selected, limits, pipeline)
    assert packet["version"] == S.INTAKE_VERSION and packet["native_decisions_executed"] is False
    assert packet["result"]["atoms"] == packet["result"]["readings"] == []
    assert packet["result"]["inspected_page_ids"] == ["p1"]
    assert packet["configuration"]["terminal_ranking"] is None
    assert S.source_input(packet, policy)["pages"][0]["text"] == policy.bound_pages["p1"]["text"]
    expected = dict(pins=pins, binding=native["binding"], environment=environment, settings=packet["configuration"], registry_ref=refs["registry_ref"])
    for field in ("plan", "binding", "environment", "native_decisions_executed", "native_checksum"):
        bad = deepcopy(packet)
        bad[field] = None
        with pytest.raises((ValueError, TypeError)):
            S.validate_intake(bad, native["public_case"], base, selected, **expected)


def test_no_full_session_execute_or_native_display_in_worker():
    import ast
    tree = ast.parse((LIVE / "worker.py").read_text())
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
        and isinstance(n.func.value, ast.Name) and n.func.value.id == "session" and n.func.attr == "execute" for n in ast.walk(tree))
    assert any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "source_intake" for n in ast.walk(tree))
    assert any(isinstance(n, ast.keyword) and n.arg == "source_pipeline" for n in ast.walk(tree))


@pytest.mark.parametrize("mutation", [None, "view", "policy", "case", "pipeline", "missing", "version"])
def test_packed_source_method_receiver_binding(environment, mutation):
    import packing
    runtime, _ = environment
    native, policy = fixture()
    method = S.execute(native, policy, runtime, parse=SourceParses())
    case = native["public_case"]
    envelope = dict(version="matryoshka-live-result/1", run_id="live_fixture", execution_kind="live",
        request=dict(task=case["task"], corpus=case["corpus"], query=case["query"], as_of=case["date"],
            excluded_origin=case["document_id"], focal_marker=case["focal_marker"]), native=native,
        condition=dict(case=case, native_checksum=native["native_checksum"], index_ref=native["binding"], source_method=method),
        source_scope=dict(source_view_policy=descriptor(VIEW)), trace={}, sources={}, document_pages={}, selected_evidence=[],
        receipt=dict(execution_cache_hit=False, no_answer_or_grade_inputs=True, no_chain_of_thought=True,
            configuration=native["configuration"], source_pipeline_version=method["version"],
            source_pipeline_sha256=method["pipeline_sha256"], selected_method=method["method_family"]))
    if mutation == "view": method["view"]["digest"] = {}
    if mutation == "policy": method["source_view_policy"] = {}
    if mutation == "case": method["public_case"] = dict(case, query="Other input.")
    if mutation == "pipeline": method["pipeline_sha256"] = "a"*64
    if mutation == "missing": envelope["condition"].pop("source_method")
    if mutation == "version": method["version"] = "unknown/1"
    if mutation:
        method["sha256"] = sha({k:v for k,v in method.items() if k != "sha256"})
    envelope["artifacts"] = {name:dict(sha256=sha(envelope[key])) for name,key in packing.ARTIFACTS.items() if key in envelope}
    if mutation:
        with pytest.raises(packing.Reject): packing.validate_result(envelope, envelope["request"], envelope["run_id"])
    else:
        assert packing.validate_result(packing.unpack(packing.pack(envelope)), envelope["request"], envelope["run_id"])


def test_opposition_alignment_is_not_literal_agreement():
    e = S.engines()
    fact = dict(text="The buildup is unlikely to deter incursions.")
    fields = facets(dict(text=fact["text"], requested_fields=e.v3.requested_fields(fact["text"])), "The buildup could deter incursions.")
    fields["modality"]["state"] = "CONFLICTING"
    row = dict(raw_model_row=dict(fields=fields), effective_direction="OPPOSE", unanimous_model_accept=True,
        qualification_envelope=dict(paragraph=dict(text="The buildup could deter incursions.")))
    scored = S.score_account(row, fact, e)
    assert scored["evidence_alignment_coverage"] == 1. and scored["literal_agreement_coverage"] < 1.
    assert not scored["world_truth"] and not scored["calibrated_probability"]


def test_component_average_does_not_complete_missing_atom():
    facts = [dict(id=i, text=i, query_spans=[]) for i in ("a1", "a2")]
    rows = [dict(fact_id=i, page_id="p", document_id="doc", effective_direction=s,
        context_priority_index=v, review={} if s=="SUPPORT" else None, unanimous_model_accept=s=="SUPPORT")
        for i,s,v in (("a1", "SUPPORT", 1.), ("a2", "HOLD", 0.))]
    result = S.aggregate(facts, rows, hypothesis=False, original_pages=1)
    assert result["coverage"] == .5 and result["status"] == "PARTIAL_SEARCH_UNRESOLVED"
    assert result["assessment_scope"]["held_slots"] == 1
    assert not result["assessment_scope"]["inspected_pool_completely_assessed"]


def test_generic_source_scheduler_keeps_whole_pages_and_explicit_unprocessed():
    native, original = fixture(text="a"*4000)
    pages = [dict(original.corpus.pages[0], id="p"+str(i), canonical_page_id="p"+str(i), text=t, source_sha256=sha(t))
        for i,t in enumerate(("a"*4000, "b"*4000, "c"*4000))]
    corpus = SimpleNamespace(**dict(vars(original.corpus), pages=pages, page_index={p["id"]:i for i,p in enumerate(pages)}))
    policy = SourcePolicy(corpus, original.case, {p["id"]:p for p in pages})
    selected, scope = S.schedule_sources(policy, [0,1,2])
    assert selected == [0,1] and scope["selected_utf8_bytes"] == 8000
    assert scope["unprocessed_pages"][0]["page_id"] == "p2" and scope["no_evidence_claim_for_unprocessed"]
    pages[0].update(text="z"*8001, source_sha256=sha("z"*8001))
    selected, scope = S.schedule_sources(policy, [0,1,2])
    assert selected == [1,2] and scope["unprocessed_pages"][0]["reason"] == "WHOLE_PAGE_BYTE_BUDGET_NO_TRUNCATION"
    assert len(pages[0]["text"]) == 8001 and not scope["raw_pages_clipped"]


def test_digest_dollar_earmark_precedes_source_claims(environment, monkeypatch):
    runtime, fake = environment
    runtime.cap = .40
    monkeypatch.setattr(R, "ledger_total", lambda: .31)
    plan = runtime.configure("redaction")
    assert plan["digest_earmark_usd"] == .07
    e = S.engines()
    with pytest.raises(RuntimeError, match="preserves the digest"):
        runtime.invoke("live_r_proposal_v1", {}, "Source-only fixture", e.proposal.RESPONSE_SCHEMA)
    assert not runtime.api_root.exists() and not fake.calls
    runtime.invoke("live_selected_source_digest_v1", {}, e.digest_prompt, e.digest_schema)
    assert len(fake.calls) == 1 and fake.calls[0][0] == "live_selected_source_digest_v1"


def test_digest_time_earmark_precedes_source_claims(environment, monkeypatch):
    from matryoshka_narrative import guards
    runtime, fake = environment
    runtime.configure("redaction")
    monkeypatch.setattr(guards, "remaining_seconds", lambda **kwargs: 20.)
    with pytest.raises(RuntimeError, match="time preserves"):
        runtime.invoke("live_r_proposal_v1", {}, "fixture", S.engines().proposal.RESPONSE_SCHEMA)
    assert not fake.calls and not runtime.api_root.exists()


def test_unprocessed_original_pool_never_becomes_no_evidence(environment):
    runtime, _ = environment
    native, policy = fixture()
    native["retrieval"] = dict(live_source_schedule=dict(original_pages=3, selected_pages=1,
        selected_page_ids=["p1"], unprocessed_pages=[dict(page_id="p2", status="UNPROCESSED"), dict(page_id="p3", status="UNPROCESSED")]))
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert result["assessment_scope"]["original_slots"] == 3
    assert result["assessment_scope"]["unprocessed_slots"] == 2
    assert not result["assessment_scope"]["inspected_pool_completely_assessed"]
    assert len(result["view"]["source_pool_scope"]["unprocessed_pages"]) == 2


def test_additional_declared_readings_remain_explicitly_unprocessed(environment):
    runtime, fake = environment
    native, policy = fixture("redaction", query="The council considered a move [REDACTION].", text="The Bay Council discussed the move.", corpus="cib")
    second = deepcopy(native["plan"]["readings_packet"]["readings"][0])
    second["id"] = "next_reading_"+"1"*24
    native["plan"]["readings_packet"]["readings"].append(second)
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert len(fake.calls) == 5 and len(result["view"]["readings"]) == 2
    assert result["readings"][1]["status"] == "UNPROCESSED_READING_BUDGET"
    assert result["source_pool_scope"]["unprocessed_reading_ids"] == [second["id"]]


@pytest.mark.parametrize("task", ["mosaic", "redaction"])
def test_zero_scheduled_pages_is_budget_hold_not_evidence_absence(environment, task):
    runtime, fake = environment
    kwargs = dict(query="The council considered a move [REDACTION].", text="The Bay Council discussed the move.", corpus="cib") if task == "redaction" else {}
    native, policy = fixture(task, **kwargs)
    native["result"]["inspected_page_ids"] = []
    native["native_checksum"] = sha(native["result"])
    native["retrieval"] = dict(live_source_schedule=dict(original_pages=1, selected_pages=0,
        selected_page_ids=[], unprocessed_pages=[dict(page_id="p1", status="UNPROCESSED")]))
    result = S.execute(native, policy, runtime, parse=SourceParses())
    assert not fake.calls and result["status"] == "SOURCE_BUDGET_HOLD_UNPROCESSED"
    assert result["digest"]["reason"] == "SOURCE_BUDGET_HOLD_UNPROCESSED"
    if task == "mosaic":
        assert result["atoms"][0]["status"] == "UNRESOLVED" and result["assessment_scope"]["unprocessed_slots"] == 1
    else:
        assert len(result["readings"]) == 1 and result["readings"][0]["status"] == "UNPROCESSED_SOURCE_BUDGET"
