"""Parent-only fresh source runs through the SAME private Live processor. API0 on import/prepare."""
import argparse
from contextlib import ExitStack
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
WORKSPACE = ROOT.parent
LIVE = ROOT / "phase/motion_login_20261122/live"
sys.path[:0] = [str(ROOT), str(LIVE)]
from contract import API_ROOT, MODEL, REFS, encoded, ledger_total, sha
import source_inference as S
from source_runtime import Runtime

VERSION = "parent-shared-source-fresh-run/1"


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def ref(path):
    path = Path(path).absolute()
    require(path.resolve() == path and path.is_relative_to(WORKSPACE), "SAFE_LOCAL_REFERENCE")
    with path.open("rb") as stream:
        return dict(path=str(path.relative_to(WORKSPACE)), sha256=hashlib.file_digest(stream,"sha256").hexdigest())


def checked(value):
    path = WORKSPACE / value["path"]
    require(ref(path) == {k:value[k] for k in ("path","sha256")}, "REFERENCE_HASH_CHANGED")
    return json.loads(path.read_bytes())


def put(path, value):
    path = Path(path).absolute()
    require(path.resolve() == path and path.is_relative_to(HERE), "PRIVATE_OUTPUT_ONLY")
    raw = encoded(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        require(path.read_bytes() == raw, "IMMUTABLE_OUTPUT_DIFFERS")
    else:
        with path.open("xb") as stream:
            stream.write(raw)
    return ref(path)


def seal(value):
    return dict(value, sha256=sha(value))


def frozen_ready(ready_ref, *, planned_pipeline=None, planned_code_refs=None):
    """The independently selected READY is the authority, not the current checkout."""
    ready = checked(ready_ref)
    require(ready.get("owner_stopped") is True and ready.get("production_frozen") is True
        and type(ready.get("API_calls")) is int and ready["API_calls"] == 0
        and ready.get("sha256") == sha({k:v for k,v in ready.items() if k!="sha256"}),
        "FROZEN_BACKEND_READY_REQUIRED")
    def pinned(row):
        path = ROOT / row["path"]
        require(path.resolve() == path and path.is_relative_to(ROOT), "SAFE_READY_REFERENCE")
        actual = ref(path)
        require(actual["sha256"] == row["sha256"], "READY_DEPENDENCY_CHANGED")
        return path, actual
    pipeline_path, _ = pinned(ready["pipeline_ref"])
    approved = json.loads(pipeline_path.read_bytes())
    require(sha(approved) == ready["pipeline_sha256"] and approved["settings"] == ready["settings"],
        "READY_PIPELINE_OR_SETTINGS_DIFFER")
    if "engines_sha256" in ready:
        require(sha(approved["engines"]) == ready["engines_sha256"], "READY_ENGINE_CLOSURE_DIFFERS")
    driver_path, driver_ref = pinned(ready["driver_ref"])
    require(driver_path == Path(__file__).resolve(), "READY_DRIVER_PATH_DIFFERS")
    for row in ready["code_files"] + ready["protected_files"] + ready["artifacts"]:
        pinned(row)
    code_refs = [pinned(row)[1] for row in approved["engines"]["files"]] + [driver_ref]
    require(len({r["path"] for r in code_refs}) == len(code_refs), "DUPLICATE_READY_CODE_PIN")
    require(S.pipeline_identity() == approved, "CURRENT_PIPELINE_DIFFERS_FROM_APPROVED_READY")
    require(planned_pipeline is None or planned_pipeline == approved, "PLAN_PIPELINE_DIFFERS_FROM_APPROVED_READY")
    require(planned_code_refs is None or planned_code_refs == code_refs, "PLAN_CODE_PINS_DIFFER_FROM_APPROVED_READY")
    return ready, approved, code_refs


def prepare(selection_ref, backend_ready_ref, output, *, epoch, case_ids=(), extras_ref=None,
            increment_usd=12., job_usd=1., max_seconds=600):
    from matryoshka_demo.source_view_policy import from_descriptor
    from matryoshka_narrative.contracts import public_query
    require(re.fullmatch(r"[a-f0-9]{8}",epoch) and type(job_usd) in (int,float) and type(increment_usd) in (int,float)
        and 0 < job_usd <= 1. and job_usd <= increment_usd <= 12
        and type(max_seconds) is int and 60 <= max_seconds <= 600, "DECLARED_RUN_BOUNDS")
    selection = checked(selection_ref)
    _, pipeline, code = frozen_ready(backend_ready_ref)
    rows = list(selection["inputs"])
    if extras_ref:
        rows += checked(extras_ref)["inputs"]
    if case_ids:
        rows = [r for r in rows if r["public_case"]["case_id"] in case_ids]
        require({r["public_case"]["case_id"] for r in rows} == set(case_ids), "EXACT_REQUESTED_CASES_REQUIRED")
    require(rows and len(rows) <= 32, "BOUNDED_NONEMPTY_SELECTION")
    items, seen, dependencies = [], set(), {}
    for row in rows:
        c = {k:row["public_case"][k] for k in ("case_id","task","corpus","query","document_id","date","focal_marker")}
        public_query(c)
        require(c["case_id"] not in seen, "DUPLICATE_CASE_ID")
        seen.add(c["case_id"])
        policy = from_descriptor(row["source_view_policy"])
        context_path = ROOT / REFS
        if policy.value == "later_release_inclusive":
            context_path = ROOT / "phase/demo_refinement_20261126/policy/v2/later-execution-refs.json"
        require(policy.value in {"source_day_inclusive","later_release_inclusive"}, "UNAPPROVED_BATCH_SOURCE_POLICY")
        context_ref = row.get("execution_refs_ref") or ref(context_path)
        context = checked(context_ref)
        index = context["index_refs"][c["corpus"]]
        expected = row.get("resource_binding") or {}
        require(not expected.get("index_sha256") or expected["index_sha256"] == index["sha256"], "DECLARED_SOURCE_INDEX_DIFFERS")
        # Hash actual resource files once, not source witnesses or old candidate pools.
        for v in (context["registry_ref"],index):
            p = ROOT / v["path"]
            key = str(p.relative_to(WORKSPACE))
            actual = dependencies.get(key) or ref(p)
            require(actual["sha256"] == v["sha256"], "RESOURCE_BYTES_CHANGED")
            dependencies[actual["path"]] = actual
        items.append(dict(public_case=c, source_view_policy=deepcopy(row["source_view_policy"]),
            execution_refs_ref=context_ref, origin_ref=row.get("origin_ref"),
            original_input_key=row.get("input_key"), saved_candidates_or_witnesses_supplied=False))
    frozen_ready(backend_ready_ref, planned_pipeline=pipeline, planned_code_refs=code)
    return put(Path(output)/"PLAN.json",seal(dict(version=VERSION, epoch=epoch,
        selection_ref=selection_ref, extras_ref=extras_ref, backend_ready_ref=backend_ready_ref,
        pipeline=pipeline, code_refs=code, resource_refs=list(dependencies.values()), cases=items,
        increment_usd=increment_usd, job_usd=job_usd, max_seconds=max_seconds, concurrency=1,
        authorization="narrative-demo-new-phase-50-usd", cumulative_cap_usd=50,
        fresh_model_stage_namespace=True, unchanged_public_queries=True, API_calls=0)))


def authorize(plan_ref, review_ref, *, parent_action):
    require(parent_action is True, "PARENT_EXECUTE_REQUIRED")
    require(bool(os.environ.get("OPENAI_API_KEY","").strip()), "PRIVATE_KEY_REQUIRED_BEFORE_CLAIM")
    plan, review = checked(plan_ref), checked(review_ref)
    require(plan.get("version") == VERSION and plan["sha256"] == sha({k:v for k,v in plan.items() if k!="sha256"}), "PLAN_SEAL")
    require(review.get("status") == "SCOPED_GO" and review.get("paid_fresh_run_boundary_cleared") is True
        and review.get("plan_ref") == plan_ref and review.get("backend_ready_ref") == plan["backend_ready_ref"], "EXACT_INDEPENDENT_GO_REQUIRED")
    frozen_ready(plan["backend_ready_ref"], planned_pipeline=plan["pipeline"], planned_code_refs=plan["code_refs"])
    for row in [plan["selection_ref"], *([plan["extras_ref"]] if plan.get("extras_ref") else []),
            *[item["execution_refs_ref"] for item in plan["cases"]],
            *[item["origin_ref"] for item in plan["cases"] if item.get("origin_ref")]]:
        checked(row)
    for r in plan["code_refs"] + plan["resource_refs"]:
        require(ref(WORKSPACE/r["path"])["sha256"] == r["sha256"], "FROZEN_CODE_OR_RESOURCE_CHANGED")
    require(S.pipeline_identity() == plan["pipeline"], "SHARED_PIPELINE_CHANGED")
    return plan


def one_case(item, plan, directory, session, baseline, cap, reserved_refs):
    from matryoshka_narrative import planning
    from matryoshka_current.planning import validate_registry
    from matryoshka_next.facts import SourcePolicy
    from matryoshka_next.construction import SourceParses
    from matryoshka_demo.source_view_policy import from_descriptor
    from packing import pack, transport_ref
    from worker import execution_limits_for, document_inventory, seal as seal_wire
    c, calls, started = deepcopy(item["public_case"]), [], time.monotonic()
    logical_call = planning.call
    def fresh_call(root, stage, payload, prompt, schema, **kwargs):
        result, meta = logical_call(root,"p_"+plan["epoch"]+"_"+stage,payload,prompt,schema,**dict(kwargs,cap=cap))
        calls.append(dict(stage=stage,meta=deepcopy(meta)))
        return result,meta
    planning.call = fresh_call
    try:
        parsed = planning.parse(c,API_ROOT,cap=cap,model=MODEL)
        readings, reading_audit = planning.model_readings(c,API_ROOT,cap=cap,model=MODEL) if c["task"]=="redaction" else (None,None)
    finally:
        planning.call = logical_call
    put(directory/"PLANNING.json",dict(plan=parsed,readings=readings,reading_audit=reading_audit,calls=calls))
    limits = dict(execution_limits_for(c["task"],c["corpus"]),source_view_policy=from_descriptor(item["source_view_policy"]))
    native, context = S.intake(session,c,parsed["native_plan"],readings,limits,plan["pipeline"])
    put(directory/"INTAKE.json",native)
    policy = SourcePolicy(context.corpus,native["case"],context.source_index)
    runtime = Runtime(directory,cap=cap,execution_epoch=plan["epoch"])
    method = S.execute(native,policy,runtime,parse=SourceParses(),pipeline=plan["pipeline"])
    put(directory/"SOURCE_METHOD.json",method)
    condition = dict(version="private-live-source-intake-condition/1",case=c,config="llm_readings",
        plan=native["plan"],result=native["result"],index_ref=native["binding"],registry_ref=context.registry_ref,
        resource_binding=validate_registry(context.registry,context.index_ref,native["case"]),
        native_checksum=native["native_checksum"],native_record_sha256=sha(native),
        native_checkpoint=dict(path="native.json",**transport_ref(pack(native))),configuration=native["configuration"],
        current_resource_execution=True,native_decisions_executed=False,source_method=method)
    scope = dict(corpus=c["corpus"],on_or_before=c["date"],evidence_through=c["date"],
        origin_document=c["document_id"],origin_is_analyst_declared=False,
        origin_kind="source_document",
        excluded_whole_origin=None if c["corpus"]=="cib" else c["document_id"],
        document_exclusion=None if c["corpus"]=="cib" else c["document_id"],
        source_view_policy=item["source_view_policy"],release_visibility=["later"] if limits["source_view_policy"].value=="later_release_inclusive" else ["earlier","both"],
        permitted_only=True,full_documents_supplied=False,supplied_pages_scope="INSPECTED_REFERENCED_PAGES_ONLY",
        document_pages_scope="ALL_POLICY_ELIGIBLE_BOUND_PAGES_FOR_REFERENCED_DOCUMENTS; PROVENANCE_ONLY; NOT_EXTRA_EVIDENCE",
        handling_policy="CIB declared edition; cables CONFIDENTIAL, document-wide NOFORN veto")
    ids = native["result"]["inspected_page_ids"]
    from worker import inspected_inventory
    sources = inspected_inventory(policy, ids)
    receipt_ids={p["call_id"] for p in runtime.receipts}
    receipt_ids.update(Path(x["meta"]["receipt"]).stem for x in calls)
    receipt_ids.update(Path(x).stem for x in reserved_refs)
    receipts=[]
    for rid in sorted(receipt_ids):
        record=json.loads((API_ROOT/"receipts"/(rid+".json")).read_bytes())
        receipts.append(dict(ref="receipts/"+rid+".json",**{k:record.get(k) for k in ("model","status","usage","request_sha256","charged_or_reserved_usd")}))
    new_ids={Path(x).stem for x in reserved_refs}
    stage_hits=sum(x["meta"].get("cache") is True for x in calls)+sum(x["cache_hit"] for x in runtime.call_events)
    for record,rid in zip(receipts,sorted(receipt_ids)):
        record["new_in_this_attempt"]=rid in new_ids
    receipt=dict(model=MODEL,invocation_kind="parent_fresh_source_batch",query_only_planning=True,
        provider_receipts=receipts,provider_calls=len(new_ids),new_provider_calls=len(new_ids),execution_cache_hit=False,
        model_stage_cache_hits=stage_hits,source_stage_cache_hits=sum(x["cache_hit"] for x in runtime.call_events),
        planning_stage_cache_hits=sum(x["meta"].get("cache") is True for x in calls),
        source_stage_events=runtime.call_events,model_cache_epoch=plan["epoch"],
        charged_or_reserved_usd=sum(r["charged_or_reserved_usd"] for r in receipts if r["new_in_this_attempt"]),
        ledger_before_usd=baseline,ledger_after_usd=ledger_total(),
        shared_ledger_delta_may_include_other_workers=True,cumulative_cap_usd=50,job_budget_usd=plan["job_usd"],
        wall_seconds=time.monotonic()-started,configuration=native["configuration"],selected_method=method["method_family"],
        source_pipeline_version=method["version"],source_pipeline_sha256=method["pipeline_sha256"],
        source_check_budgets=method["pipeline"]["settings"],source_processing_budget=method["processing_budget"],
        source_pool_scope=method["source_pool_scope"],native_decisions_executed=False,no_answer_or_grade_inputs=True,
        no_chain_of_thought=True,retrieval={k:native["configuration"][k] for k in ("method",)},
        fixed_model_outputs_deterministic=True,uncached_model_outputs_bit_reproducible=False)
    receipt["retrieval"].update(passage_budget=limits["passage_budget"],document_budget=limits["document_budget"])
    envelope=dict(version="matryoshka-live-result/1",run_id=directory.name,execution_kind="live",
        request=dict(task=c["task"],corpus=c["corpus"],query=c["query"],as_of=c["date"],excluded_origin=c["document_id"],focal_marker=c["focal_marker"]),
        native=native,condition=condition,source_scope=scope,
        trace=dict(version="private-live-source-intake-trace/1",paths=[],steps=[],evidence_inventory=[],native_decisions_executed=False,native_decisions_or_ranks_modified=False),
        selected_evidence=[],sources=sources,document_pages=document_inventory(policy,sources),origins=None,
        analyst_digest=dict(available=False,used_for_inference=False,reason="Selected source-method digest is in condition.source_method.digest."),receipt=receipt,artifacts={})
    validate_export(envelope)
    seal_wire(directory,envelope)
    put(directory/"WORKBENCH_EXPORT.json",dict(version="shared-source-workbench-export/1",wire_ref=ref(directory/"result.json"),
        renderer="workbench-live-source.js",verify="verifyLiveSourceMethod",normalize="normalizeLiveSourceMethod",
        source_view_sha256=sha(method["view"]),origin_ref=item.get("origin_ref"),
        native_decisions_rewritten=False,ranking_recomputed=False,publication_authorized=False))
    return dict(case_id=c["case_id"],status="COMPLETE_RETAIN_ALL_SOURCE_HOLDS",wire_ref=ref(directory/"result.json"),
        export_ref=ref(directory/"WORKBENCH_EXPORT.json"),method_status=method.get("status"),source_failures=len(method["failures"]))


def validate_export(envelope):
    """Mechanical API0 gate, not a substitute for the shared browser verifier."""
    from packing import pack, unpack
    require(unpack(pack(envelope)) == envelope, "WIRE_ROUNDTRIP")
    native,condition,receipt=envelope["native"],envelope["condition"],envelope["receipt"]
    method=condition["source_method"]
    require(native["public_case"] == condition["case"] == method["view"]["case"], "EXPORT_CASE_BINDING")
    require(native["native_checksum"] == sha(native["result"]) and method["native_record_sha256"] == sha(native), "EXPORT_NATIVE_BINDING")
    require(method["sha256"] == sha({k:v for k,v in method.items() if k!="sha256"}), "EXPORT_SOURCE_METHOD_SEAL")
    require(native["configuration"] == condition["configuration"] == receipt["configuration"]
        and native["configuration"]["source_pipeline_sha256"] == method["pipeline_sha256"], "EXPORT_PIPELINE_BINDING")
    require(receipt["provider_calls"] == receipt["new_provider_calls"]
        == sum(r["new_in_this_attempt"] for r in receipt["provider_receipts"]), "EXPORT_NEW_CALL_ATTRIBUTION")


def safe_reason(error):
    text=str(error)
    key=os.environ.get("OPENAI_API_KEY","").strip()
    if key:text=text.replace(key,"[REDACTED_CREDENTIAL]")
    text=re.sub(r"(?i)\bBearer\s+\S+|\bsk-[A-Za-z0-9_-]{12,}","[REDACTED_CREDENTIAL]",text)
    return text[:4000]


def execute(plan_ref, review_ref, *, parent_action=False):
    plan = authorize(plan_ref,review_ref,parent_action=parent_action)
    from matryoshka_narrative import workflow
    from matryoshka_narrative import api
    folder = WORKSPACE/plan_ref["path"]
    out = folder.parent/"execution"
    require(not (out/"CLAIM.json").exists(), "EXISTING_CLAIM_NO_AUTORETRY")
    initial=ledger_total(); cap=min(50.,initial+plan["increment_usd"])
    put(out/"CLAIM.json",dict(plan_ref=plan_ref,review_ref=review_ref,ledger_baseline=initial,absolute_cap_usd=cap))
    results=[]
    with ExitStack() as stack:
        sessions={}
        for item in plan["cases"]:
            c=item["public_case"]; baseline=ledger_total()
            if cap-baseline < .07:
                results.append(dict(case_id=c["case_id"],status="UNPROCESSED_PHASE_BUDGET"));continue
            directory=out/"jobs"/("live_"+uuid.uuid4().hex)
            put(directory/"CLAIM.json",dict(public_case=c,plan_ref=plan_ref,ledger_before_usd=baseline))
            before_env=dict(os.environ)
            reserved_refs=[]
            original_reserve=api.Budget.reserve
            def tracked_reserve(budget,wire,amount):
                path,record=original_reserve(budget,wire,amount)
                reserved_refs.append(str(path.relative_to(API_ROOT)))
                put(directory/("PROVIDER_REFS_"+str(len(reserved_refs))+".json"),dict(receipts=list(reserved_refs)))
                return path,record
            api.Budget.reserve=tracked_reserve
            try:
                require(S.pipeline_identity()==plan["pipeline"], "PIPELINE_CHANGED_BEFORE_CASE")
                deadline=datetime.now(timezone.utc)+timedelta(seconds=plan["max_seconds"])
                os.environ.update(NARRATIVE_DEADLINE_UTC=deadline.isoformat(),NARRATIVE_NO_NEW_WORK_UTC=deadline.isoformat(),
                    NARRATIVE_INCREMENTAL_BASELINE_USD=str(baseline),NARRATIVE_INCREMENTAL_CEILING_USD=str(plan["job_usd"]))
                context_ref=item["execution_refs_ref"]; key=context_ref["sha256"]
                if key not in sessions:
                    checked(context_ref)
                    sessions[key]=stack.enter_context(workflow.Session(root=ROOT,refs_path=WORKSPACE/context_ref["path"]))
                result=one_case(item,plan,directory,sessions[key],baseline,cap,reserved_refs)
            except Exception as error:
                result=dict(case_id=c["case_id"],status="FAILED_RETAINED",error_type=type(error).__name__,
                    private_error_reason=safe_reason(error),provider_refs=list(reserved_refs))
                put(directory/"FAILURE.json",result)
            finally:
                api.Budget.reserve=original_reserve
                for name in set(os.environ)-set(before_env):del os.environ[name]
                os.environ.update(before_env)
            results.append(result)
            put(out/(str(len(results))+"_RESULT.json"),result)
    return put(out/"RESULTS.json",seal(dict(version=VERSION,plan_ref=plan_ref,review_ref=review_ref,
        cases=results,all_requested_inputs_retained=len(results)==len(plan["cases"]),
        ledger_before_usd=initial,ledger_after_usd=ledger_total(),promotion_authorized=False)))


def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="mode",required=True)
    a=sub.add_parser("prepare");a.add_argument("--selection",type=Path,required=True);a.add_argument("--backend-ready",type=Path,required=True)
    a.add_argument("--extras",type=Path);a.add_argument("--case",action="append",default=[]);a.add_argument("--epoch",required=True)
    a.add_argument("--out",type=Path,required=True);a.add_argument("--increment-usd",type=float,default=12.)
    a.add_argument("--job-usd",type=float,default=1.);a.add_argument("--max-seconds",type=int,default=600)
    b=sub.add_parser("execute");b.add_argument("--plan",type=Path,required=True);b.add_argument("--review",type=Path,required=True);b.add_argument("--execute",action="store_true")
    args=p.parse_args()
    result=prepare(ref(args.selection),ref(args.backend_ready),args.out,epoch=args.epoch,case_ids=args.case,
        extras_ref=ref(args.extras) if args.extras else None,increment_usd=args.increment_usd,
        job_usd=args.job_usd,max_seconds=args.max_seconds) if args.mode=="prepare" else execute(ref(args.plan),ref(args.review),parent_action=args.execute)
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__":main()
