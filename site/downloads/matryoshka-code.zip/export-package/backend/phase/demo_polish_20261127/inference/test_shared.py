"""Fake-provider tests of the actual shared source processor; network forbidden."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1]/"workbench_unification_20261127/live/test_source_pipeline.py"
spec = importlib.util.spec_from_file_location("polish_shared_fixture", OLD)
O = importlib.util.module_from_spec(spec)
spec.loader.exec_module(O)
environment, no_network = O.environment, O.no_network
S, R, sha = O.S, O.R, O.sha

# Upgrade only our synthetic fixture boundary, not historical production packets.
old_fixture = O.fixture
def current_fixture(*args, **kwargs):
    from matryoshka_next import readings
    native, policy = old_fixture(*args, **kwargs)
    if native["public_case"]["task"] == "redaction":
        query = native["public_case"]["query"]
        span = dict(start=0, end=query.index(" "), text=query.split(" ")[0])
        row = dict(outer_family="clausal", function="adjunct", role="adjunct", variant="default",
            attachment_spans=[span], target_kind="any", grammatical_number="unknown", finite=None,
            wrappers=[], operators=[], cues=[dict(kind="attachment", span=span)])
        native["plan"]["readings_packet"] = readings.from_model_response(
            dict(status="ready", reason=None, readings=[row]), native["public_case"])
    return native, policy
O.fixture = current_fixture


def many_pages(native, old, texts):
    pages = [dict(old.corpus.pages[0], id="p"+str(i+1), canonical_page_id="p"+str(i+1),
        document_id="doc"+str(i+1), text=t, source_sha256=sha(t)) for i,t in enumerate(texts)]
    corpus = SimpleNamespace(**dict(vars(old.corpus), pages=pages,
        page_index={p["id"]:i for i,p in enumerate(pages)}))
    policy = O.SourcePolicy(corpus, old.case, {p["id"]:p for p in pages})
    native["result"]["inspected_page_ids"] = [p["id"] for p in pages]
    native["native_checksum"] = sha(native["result"])
    return native, policy


def test_shared_profile_not_offline_override():
    assert S.SETTINGS["processing_profile_version"] == "shared-source-eight-pages/2"
    assert (S.SETTINGS["source_page_budget"],S.SETTINGS["source_full_text_utf8_budget"]) == (8,32000)
    assert (S.SETTINGS["max_fills_per_reading"],S.SETTINGS["displayed_fills"]) == (8,5)
    assert R.bounded_schema("live_r_proposal_v1", S.engines().proposal.RESPONSE_SCHEMA)["properties"]["proposals"]["maxItems"] == 8


def test_actual_scheduler_32kb_boundary_unprocessed_not_none():
    n,p=O.fixture()
    n,p=many_pages(n,p,["x"*32001,"\u00e9"*16000,"tail"])
    selected,schedule=S.schedule_sources(p,[0,1,2])
    assert selected == [1] and schedule["selected_utf8_bytes"] == 32000
    assert len(schedule["unprocessed_pages"]) == 2
    assert all(x["status"] == "UNPROCESSED" for x in schedule["unprocessed_pages"])


def test_actual_scheduler_eight_whole_pages():
    n,p=O.fixture()
    n,p=many_pages(n,p,["x"*4000]*9)
    selected,schedule=S.schedule_sources(p,list(range(9)))
    assert selected == list(range(8)) and schedule["selected_utf8_bytes"] == 32000
    assert schedule["unprocessed_pages"][0]["page_id"] == "p9"


def test_eight_pages_two_facts_real_matrix_and_separate_reviews(environment):
    runtime,fake=environment
    query="Mira opened the gate. Oren closed the window."
    n,p=O.fixture(query=query)
    n["plan"]["atoms"] = [dict(n["plan"]["atoms"][0],id="a"+str(i+1),text=t,
        query_spans=[dict(start=query.index(t),end=query.index(t)+len(t),text=t)])
        for i,t in enumerate(("Mira opened the gate.","Oren closed the window."))]
    n,p=many_pages(n,p,[query]*8)
    before=deepcopy(n)
    result=S.execute(n,p,runtime,parse=O.SourceParses())
    assert not result["failures"] and n == before
    assert result["assessment_scope"]["processed_slots"] == 16
    assert len([x for x in fake.calls if x[0]=="live_m_assessment_v1"]) == 4
    assert len([x for x in fake.calls if x[0]=="live_m_review_v1"]) == 4
    assert len(fake.calls)==9 and result["processing_budget"]["maximum_model_stages"]==9
    assert all(len(w["pages"])*len(w["required_facts"])<=4 for st,w in fake.calls if st=="live_m_assessment_v1")


def test_prepared_pool_cannot_silently_exceed_profile(environment):
    n,p=O.fixture(); n,p=many_pages(n,p,["raw"]*9)
    with pytest.raises(ValueError,match="POOL_EXCEEDS"):
        S.execute(n,p,environment[0],parse=O.SourceParses())
    assert not environment[1].calls


def scoped_fixture(tmp_path,monkeypatch):
    import source_proposal_policy as Q
    from matryoshka_demo.source_view_policy import LATER_RELEASE_INCLUSIVE as VIEW,descriptor
    n,old=O.fixture("redaction",query="The council considered a move [REDACTION].",
        text="The Bay Council discussed the move.",corpus="cib")
    page=dict(old.corpus.pages[0],visibility="later",view="later",classification="SECRET",
        source_page=8,native_page=dict(view="later",canonical_page_id="original_canonical"))
    corpus=SimpleNamespace(**dict(vars(old.corpus),pages=[page],source_view_policy=VIEW))
    p=O.SourcePolicy(corpus,old.case,{"p1":page})
    n["configuration"]["source_view_policy"]=descriptor(VIEW)
    n["result"]["source_view_policy"]=descriptor(VIEW); n["native_checksum"]=sha(n["result"])
    refs=[]
    for name in ("registry.json","index.sqlite3"):
        path=tmp_path/name;path.write_bytes(b"synthetic fixture resource")
        refs.append(dict(path=name,sha256=R.hashlib.sha256(path.read_bytes()).hexdigest()))
    n["binding"]=refs[1]
    n["execution_context"]=dict(version="pinned-execution-context/1",registry_ref=refs[0],index_ref=refs[1])
    monkeypatch.setattr(Q,"ROOT",tmp_path)
    q=Q.ScopedProtocol(S.engines().proposal,n,p)
    reading=q.P.project_readings(n["plan"]["readings_packet"],n["public_case"])[0]
    value=q.packet(dict(version=q.VERSION,case=n["public_case"],reading=reading,
        query_only_facts=S.public_atoms(n["plan"]["atoms"]),sources=[q.W.V2.project_page(page,0)]),dict(index=0,count=1))
    return n,p,q,value


def test_real_scoped_later_pipeline_keeps_source_edition_and_physical_page(environment,tmp_path,monkeypatch):
    n,p,q,value=scoped_fixture(tmp_path,monkeypatch)
    assert q.verify_packet(value)[0]["sources"][0]["visibility"] == "later"
    with pytest.raises(ValueError):
        S.engines().proposal.verify_packet(value)
    result=S.execute(n,p,environment[0],parse=O.SourceParses())
    assert not result["failures"],result["failures"]
    candidate=result["readings"][0]["candidates"][0]
    assert candidate["source"]["citation"]["physical_page"] == 8
    assert candidate["source"]["citation"]["source_edition"] == "later"
    assert result["source_pages"][0]["visibility"] == "later"
    assert result["readings"][0]["proposal_protocol_version"] == q.VERSION


@pytest.mark.parametrize("change",["visibility","date","text","authority","index","inspection","policy"])
def test_scoped_metadata_cannot_be_relabeled_or_unbound(tmp_path,monkeypatch,change):
    n,p,q,value=scoped_fixture(tmp_path,monkeypatch)
    if change=="visibility":value["model_input"]["sources"][0]["visibility"]="earlier"
    elif change=="date":p.corpus.pages[0]["date"]="9999-01-01"
    elif change=="text":p.corpus.pages[0]["text"]+=" altered"
    elif change=="authority":value["model_input"]["source_authority"]["source_view_policy"]["id"]="source_day_inclusive"
    elif change=="index":n["binding"]["sha256"]="0"*64
    elif change=="inspection":value["model_input"]["sources"][0]["inspected_position"]=1
    elif change=="policy":p.source_view_policy=O.VIEW
    with pytest.raises(ValueError):q.verify_packet(value)


def test_scoped_resource_actual_bytes_must_match(tmp_path,monkeypatch):
    import source_proposal_policy as Q
    n,p,q,value=scoped_fixture(tmp_path,monkeypatch)
    (tmp_path/"index.sqlite3").write_bytes(b"different")
    with pytest.raises(ValueError,match="RESOURCE_HASH"):
        Q.ScopedProtocol(S.engines().proposal,n,p)


def test_ordinary_policy_still_rejects_later_secret():
    n,p=O.fixture("redaction",query="The [REDACTION] opened the gate.",corpus="cib",visibility="later",view="later",classification="SECRET")
    with pytest.raises(ValueError,match="NOT_ELIGIBLE"):S.source_input(n,p)


def test_epoch_control_is_closed_and_does_not_change_algorithm():
    with pytest.raises(ValueError):R.Runtime(Path("unused"),cap=.4,execution_epoch="bad epoch")
    a=R.Runtime(Path("unused"),cap=.4,execution_epoch="1234abcd")
    assert a.execution_epoch=="1234abcd" and a.output_limits==R.OUTPUT_LIMITS
