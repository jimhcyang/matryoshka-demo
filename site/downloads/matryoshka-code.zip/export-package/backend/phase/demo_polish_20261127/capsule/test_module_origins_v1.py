"""Virtual module classification without exempting project namespaces/files."""
import importlib.util
from pathlib import Path
from types import ModuleType
import pytest

HERE=Path(__file__).resolve().parent
path=HERE/'contained_probe_v7_2.py'
if not path.exists():path=HERE/'contained_probe.py'
spec=importlib.util.spec_from_file_location('_origin_guard_probe',path)
P=importlib.util.module_from_spec(spec);spec.loader.exec_module(P)


def test_actual_torch_ops_virtual_origin(tmp_path):
    import torch
    assert P.contained(tmp_path,tmp_path,{'torch.ops':torch.ops})==[]


def test_generic_relative_virtual_origin(tmp_path):
    module=ModuleType('generated');module.__file__='_nonexistent_runtime_generated.py'
    assert P.contained(tmp_path,tmp_path,{'generated':module})==[]


def test_dynamic_attributes_are_not_filesystem_origins(tmp_path):
    module=ModuleType('generated')
    def fail(name):raise AssertionError('Do not invoke dynamic module attributes')
    module.__getattr__=fail
    assert P.contained(tmp_path,tmp_path,{'generated':module})==[]


@pytest.mark.parametrize('name',['matryoshka_foreign','source_runtime'])
def test_project_virtual_origin_never_bypasses_guard(tmp_path,name):
    module=ModuleType(name);module.__file__='_nonexistent_runtime_generated.py'
    with pytest.raises(AssertionError,match='OUTSIDE_CONTAINED_SOURCE_IMPORT'):
        P.contained(tmp_path,tmp_path,{name:module})


@pytest.mark.parametrize('name',['matryoshka_foreign','innocent_alias'])
def test_real_foreign_checkout_source_rejected(tmp_path,name):
    checkout=tmp_path/'checkout';source=checkout/'src-demo-day/foreign.py';source.parent.mkdir(parents=True);source.write_text('x=1\n')
    root=checkout/'src-demo-day/extracted/backend';root.mkdir(parents=True)
    module=ModuleType(name);module.__file__=str(source)
    with pytest.raises(AssertionError,match='OUTSIDE_CONTAINED_SOURCE_IMPORT'):
        P.contained(root,checkout,{name:module})


def test_real_contained_project_source_retained(tmp_path):
    root=tmp_path/'backend';root.mkdir();source=root/'source_runtime.py';source.write_text('x=1\n')
    module=ModuleType('source_runtime');module.__file__=str(source)
    assert P.contained(root,tmp_path,{'source_runtime':module})==['source_runtime']


def test_real_contained_namespace_package(tmp_path):
    from importlib.machinery import ModuleSpec
    package=tmp_path/'backend/matryoshka_namespace';package.mkdir(parents=True)
    module=ModuleType('matryoshka_namespace');module.__path__=[str(package)]
    module.__spec__=ModuleSpec(module.__name__,loader=None,is_package=True)
    module.__spec__.submodule_search_locations=module.__path__
    assert P.contained(tmp_path/'backend',tmp_path,{module.__name__:module})==[module.__name__]


def test_foreign_namespace_package_rejects(tmp_path):
    from importlib.machinery import ModuleSpec
    package=tmp_path/'checkout/src-demo-day/foreign';package.mkdir(parents=True)
    root=tmp_path/'backend';root.mkdir()
    module=ModuleType('matryoshka_namespace');module.__path__=[str(package)]
    module.__spec__=ModuleSpec(module.__name__,loader=None,is_package=True)
    module.__spec__.submodule_search_locations=module.__path__
    with pytest.raises(AssertionError,match='OUTSIDE_CONTAINED_SOURCE_IMPORT'):
        P.contained(root,tmp_path/'checkout',{module.__name__:module})
