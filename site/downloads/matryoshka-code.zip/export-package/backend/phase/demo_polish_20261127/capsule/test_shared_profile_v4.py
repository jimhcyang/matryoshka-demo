"""V4 synthetic contained controls. No real cases, corpus DB or provider files."""
from copy import deepcopy
import importlib.util
import os
from pathlib import Path
import sys

import pytest

ROOT=Path(__file__).resolve().parents[3]
sys.path[:0]=[str(ROOT),str(ROOT/'phase/motion_login_20261122/live')]
spec=importlib.util.spec_from_file_location('_capsule_v4_shared_fixtures',ROOT/'phase/demo_polish_20261127/inference/test_shared.py')
T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
S,R,O=T.S,T.R,T.O
environment,no_network=T.environment,T.no_network
# Reuse unchanged controls, not the explicitly obsolete /2 version assertion.
for _name,_fn in vars(T).items():
    if _name.startswith('test_') and _name!='test_shared_profile_not_offline_override':globals()[_name]=_fn


def test_v4_exact_profile_and_unchanged_geometry_math():
    assert S.SETTINGS['processing_profile_version']=='shared-source-eight-pages/3'
    assert S.SETTINGS['proposal_version']=='source-realized-fill-proposals/current-readings-2'
    assert S.SETTINGS['scoped_proposal_version']=='source-realized-fill-proposals/scoped-policy-3'
    assert (S.SETTINGS['source_page_budget'],S.SETTINGS['source_full_text_utf8_budget'])==(8,32000)
    assert (S.SETTINGS['preferred_fact_page_rows'],S.SETTINGS['maximum_fact_page_rows'],S.SETTINGS['assessment_pages_per_batch'])==(4,8,2)
    assert (S.SETTINGS['maximum_required_atoms'],S.SETTINGS['maximum_source_calls'])==(8,17)
    assert (S.SETTINGS['max_fills_per_reading'],S.SETTINGS['displayed_fills'],S.SETTINGS['maximum_readings'])==(8,5,3)
    assert S.SETTINGS['rank_formula']=='(source_class+.99*(.75*alignment+.25*lexical))/3'
    assert S.SETTINGS['truncation'] is False and S.SETTINGS['automatic_retries']==0
    assert 'source_readings.py' in R.DECLARED_LIVE_FILES


@pytest.mark.parametrize('facts',range(1,9))
def test_all_required_facts_retained_with_unchanged_batch_geometry(environment,facts):
    runtime,fake=environment;texts=[f'Mira opened gate number {i+1}.' for i in range(facts)];query=' '.join(texts)
    n,p=O.fixture(query=query)
    n['plan']['atoms']=[dict(n['plan']['atoms'][0],id='a'+str(i),text=t,
        query_spans=[dict(start=query.index(t),end=query.index(t)+len(t),text=t)]) for i,t in enumerate(texts)]
    n,p=T.many_pages(n,p,[query]*3);before=deepcopy(n)
    method=S.execute(n,p,runtime,parse=O.SourceParses())
    assert not method['failures'] and n==before
    batches=[payload for stage,payload in fake.calls if stage=='live_m_assessment_v1'];pages=min(2,max(1,4//facts))
    assert all(len(w['required_facts'])==facts and len(w['pages'])<=pages for w in batches)
    assert method['assessment_scope']['processed_slots']==facts*3
    budget=method['processing_budget']
    assert budget['version']=='private-live-source-processing-budget/2'
    assert budget['maximum_model_stages']==2*len(batches)+1
    assert budget['review_body_bytes_limit']==(65536 if facts<=4 else 260096)
    assert budget['source_timeout_policy']=='PER_CALL_MIN_90_REMAINING_MINUS_DIGEST'
    assert type(budget['maximum_response_seconds']) is int and budget['maximum_response_seconds']==90


@pytest.mark.parametrize('task',['redaction','mosaic','hypothesis'])
@pytest.mark.parametrize('recorded',[False,True])
def test_metadata_presence_raw_page_unchanged_and_not_clearance(environment,task,recorded):
    runtime,_=environment
    kwargs=dict(query='The council considered a move [REDACTION].',text='The Bay Council discussed the move.',corpus='cib') if task=='redaction' else {}
    n,p=O.fixture(task,**kwargs);page=p.corpus.pages[0]
    if not recorded:page.pop('handling')
    before=deepcopy(page);native=deepcopy(n)
    method=S.execute(n,p,runtime,parse=O.SourceParses())
    assert not method['failures'],method['failures']
    assert n==native and page==before and method['source_pages']==[before]
    expected=[dict(page_id=page['id'],page_sha256=page['source_sha256'],handling_recorded=recorded,
        transport_handling_defaulted=task=='redaction' and not recorded,absence_is_not_clearance=True)]
    assert method['source_metadata_presence']==method['view']['source_metadata_presence']==expected


@pytest.mark.parametrize('bad',[None,'NOFORN',{},[1]])
def test_present_malformed_handling_cannot_be_defaulted(bad):
    from source_proposal_policy import project_page
    n,p=O.fixture('redaction',query='The council considered a move [REDACTION].')
    page=p.corpus.pages[0];page['handling']=bad;before=deepcopy(page)
    with pytest.raises((ValueError,TypeError)):project_page(S.engines().proposal,n,p,page,0)
    assert page==before


@pytest.mark.parametrize('where',['sibling_text','sibling_metadata','document_metadata'])
def test_missing_handling_still_applies_complete_document_noforn_veto(where):
    from source_proposal_policy import project_page
    n,p=O.fixture('redaction',query='The council considered a move [REDACTION].');page=p.corpus.pages[0];page.pop('handling')
    sibling=dict(page,id='sibling',text='NO FOREIGN DISSEM' if where=='sibling_text' else 'Unrelated sibling.')
    sibling['source_sha256']=S.sha(sibling['text'])
    if where=='sibling_metadata':sibling['handling']=['NOFORN']
    p.corpus.pages.append(sibling);p.corpus.page_index['sibling']=1
    if where=='document_metadata':p.corpus.classification[page['document_id']]=dict(handling=['NOFORN'])
    policy=O.SourcePolicy(p.corpus,n['case'],{r['id']:r for r in p.corpus.pages})
    with pytest.raises(ValueError,match='SOURCE_INELIGIBLE'):project_page(S.engines().proposal,n,policy,page,0)


def fake_runtime(monkeypatch,tmp_path,seconds):
    from matryoshka_narrative import api,guards
    monkeypatch.setenv('OPENAI_API_KEY','fixture-no-real-key');monkeypatch.delenv('MATRYOSHKA_API_RESPONSE_SECONDS',raising=False)
    monkeypatch.setattr(R,'ledger_total',lambda:0.);monkeypatch.setattr(guards,'remaining_seconds',lambda **k:seconds)
    runtime=R.Runtime(tmp_path,cap=10.);runtime.configure('hypothesis',maximum_source_calls=9,matrix_rows=4)
    captured=[]
    def call(*args,**kwargs):
        captured.append(float(os.environ['MATRYOSHKA_API_RESPONSE_SECONDS']));return {},dict(receipt='fixture',cache=False)
    monkeypatch.setattr(api,'call',call);monkeypatch.setattr(runtime,'attest',lambda *a:{})
    return runtime,captured


@pytest.mark.parametrize('seconds,expected',[(600,90),(150,90),(90,65),(28,3)])
def test_timeout_budget2_never_divides_by_stage_count(monkeypatch,tmp_path,seconds,expected):
    runtime,calls=fake_runtime(monkeypatch,tmp_path,seconds)
    runtime.invoke('live_h_assessment_v1',{},'fixture',dict(type='object'))
    assert calls==[float(expected)] and 'MATRYOSHKA_API_RESPONSE_SECONDS' not in os.environ


def test_operator_response_ceiling_and_digest_time_are_retained(monkeypatch,tmp_path):
    runtime,calls=fake_runtime(monkeypatch,tmp_path,600)
    monkeypatch.setenv('MATRYOSHKA_API_RESPONSE_SECONDS','45')
    runtime.invoke('live_h_assessment_v1',{},'fixture',dict(type='object'))
    assert calls==[45.] and os.environ['MATRYOSHKA_API_RESPONSE_SECONDS']=='45'
    runtime,calls=fake_runtime(monkeypatch,tmp_path,28)
    runtime.invoke('live_selected_source_digest_v1',{},'fixture',dict(type='object'),max_output_tokens=128)
    assert calls==[28.]


def test_current_readings_preserve_constructor_metadata():
    from source_readings import project
    n,_=O.fixture('redaction',query='The council considered a move [REDACTION].')
    result=project(n['plan']['readings_packet'],n['public_case'])
    assert result==n['plan']['readings_packet']['readings']
    assert all(k in result[0] for k in ('constructor_form','constructor_status','constructor_routing'))
