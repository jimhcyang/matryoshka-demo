"""V6 synthetic controls only; no real source, receipt or provider fixtures."""
from copy import deepcopy
import importlib.util
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_capsule_v6_v5_controls', HERE / 'test_shared_profile_v5.py')
V5 = importlib.util.module_from_spec(spec); spec.loader.exec_module(V5)
S, R, O, T = V5.S, V5.R, V5.O, V5.T
environment, no_network, captured = V5.environment, V5.no_network, V5.captured
for _name, _fn in vars(V5).items():
    if _name.startswith('test_') and _name not in {
        'test_exact_v5_profile_geometry_and_protocols',
        'test_v5_keeps_all_facts_and_unchanged_geometry_with_budget3',
    }:
        globals()[_name] = _fn


def test_exact_v6_profile_geometry_math_and_protocols():
    assert S.SETTINGS['processing_profile_version'] == 'shared-source-eight-pages/5'
    assert S.SETTINGS['proposal_version'] == 'source-realized-fill-proposals/current-readings-2'
    assert S.SETTINGS['scoped_proposal_version'] == 'source-realized-fill-proposals/scoped-policy-3'
    assert (S.SETTINGS['source_page_budget'], S.SETTINGS['source_full_text_utf8_budget']) == (8, 32000)
    assert (S.SETTINGS['preferred_fact_page_rows'], S.SETTINGS['maximum_fact_page_rows'], S.SETTINGS['assessment_pages_per_batch']) == (4, 8, 2)
    assert (S.SETTINGS['max_fills_per_reading'], S.SETTINGS['displayed_fills'], S.SETTINGS['maximum_readings']) == (8, 5, 3)
    assert S.SETTINGS['rank_formula'] == '(source_class+.99*(.75*alignment+.25*lexical))/3'
    assert S.SETTINGS['truncation'] is False and S.SETTINGS['automatic_retries'] == 0
    assert 'source_readings.py' in R.DECLARED_LIVE_FILES


@pytest.mark.parametrize('facts', range(1, 9))
def test_all_facts_geometry_retained_with_uniform_budget4(environment, facts):
    r, fake = environment; texts = [f'Mira opened gate number {i+1}.' for i in range(facts)]; query = ' '.join(texts)
    n, p = O.fixture(query=query)
    n['plan']['atoms'] = [dict(n['plan']['atoms'][0], id='a'+str(i), text=t,
        query_spans=[dict(start=query.index(t), end=query.index(t)+len(t), text=t)]) for i, t in enumerate(texts)]
    n, p = T.many_pages(n, p, [query]*3); before = deepcopy((n, p.corpus.pages))
    result = S.execute(n, p, r, parse=O.SourceParses()); assert not result['failures'], result['failures']
    assert (n, p.corpus.pages) == before
    budget = result['processing_budget']; batches = [w for stage, w in fake.calls if stage == 'live_m_assessment_v1']
    assert all(len(w['required_facts']) == facts and len(w['pages']) <= min(2, max(1, 4//facts)) for w in batches)
    assert result['assessment_scope']['processed_slots'] == facts*3
    assert budget['version'] == 'private-live-source-processing-budget/4'
    assert budget['maximum_model_stages'] == 2*len(batches)+1
    assert budget['digest_body_bytes_limit'] == 65536 and budget['digest_earmark_usd'] == .07
    assert budget['review_body_bytes_limit'] == 260096
    assert budget['review_minimum_earmark_usd'] == pytest.approx(.10 if facts <= 4 else .172032)
    assert budget['review_completion_guaranteed'] is False


@pytest.mark.parametrize('task', ['mosaic', 'hypothesis'])
@pytest.mark.parametrize('rows', [1, 2, 4, 5, 8])
def test_uniform_whole_review_bound_not_response_or_reservation_relaxation(monkeypatch, tmp_path, task, rows):
    r, _ = V5.runtime(monkeypatch, tmp_path, 1.)
    budget = r.configure(task, maximum_source_calls=17, matrix_rows=rows)
    assert budget['review_body_bytes_limit'] == 260096 and budget['maximum_fact_page_rows'] == rows
    stage = 'live_m_review_v1' if task == 'mosaic' else 'live_h_review_v1'
    assert budget['output_token_limits'][stage] == (8192 if rows <= 4 else 16384)
    assert budget['review_minimum_earmark_usd'] == pytest.approx(.10 if rows <= 4 else .172032)
    assert budget['maximum_response_seconds'] == 90 and budget['digest_time_earmark_seconds'] == 25
    assert budget['review_completion_guaranteed'] is False


@pytest.mark.parametrize('task', ['mosaic', 'hypothesis'])
def test_larger_small_matrix_review_still_requires_full_funding_and_no_clipping(monkeypatch, tmp_path, task):
    stage = 'live_m_review_v1' if task == 'mosaic' else 'live_h_review_v1'
    r, calls = V5.runtime(monkeypatch, tmp_path, 1.); r.configure(task, matrix_rows=4)
    payload = {'whole_qualification': 'x'*80000}; before = deepcopy(payload)
    r.invoke(stage, payload, 'fixture', dict(type='object'))
    assert calls[0]['payload'] == before == payload
    r, calls = V5.runtime(monkeypatch, tmp_path, .2); r.configure(task, matrix_rows=4)
    with pytest.raises(RuntimeError):
        r.invoke(stage, payload, 'fixture', dict(type='object'))
    with pytest.raises(ValueError):
        r.invoke(stage, {'whole_qualification': 'x'*260096}, 'fixture', dict(type='object'))
    assert not calls and payload == before


def test_redaction_has_no_mh_review_bound(monkeypatch, tmp_path):
    r, _ = V5.runtime(monkeypatch, tmp_path, 1.)
    assert r.configure('redaction')['review_body_bytes_limit'] is None


@pytest.mark.parametrize('locators', [{}, {'source_page': 8},
    {'view': 'later', 'native_page': {'view': 'later', 'source_page': 8, 'text': 'canonical raw'},
     'source_page': 8, 'later_page': 8, 'physical_page': 8, 'canonical_page_id': 'p1',
     'source_hash_contract': 'shared-json-string-ensure-ascii-true/sha256', 'raw_text_sha256': 'a'*64}])
def test_publication_locators_exact_only_when_present_and_never_inspection(locators):
    import worker
    _, policy = O.fixture('redaction', query='The council asked [REDACTION].', corpus='cib')
    page = policy.corpus.pages[0]
    fields = ('view', 'native_page', 'source_page', 'later_page', 'physical_page', 'canonical_page_id',
              'source_hash_contract', 'raw_text_sha256')
    for field in fields:
        page.pop(field, None)
    page.update(deepcopy(locators)); before = deepcopy(page)
    policy.allowed = lambda _: True
    got = worker.document_inventory(policy, {page['id']: page})[page['document_id']][0]
    for field in fields:
        assert (field in got) == (field in page)
        if field in page:
            assert got[field] == page[field]
    assert page == before and got['text'] == page['text'] and got['source_sha256'] == page['source_sha256']
    assert got['provenance_only'] is True and got['inspection_not_implied'] is True


def test_publication_provenance_hash_tamper_still_rejects():
    import worker
    _, policy = O.fixture('redaction', query='The council asked [REDACTION].', corpus='cib')
    page = policy.corpus.pages[0]; page['text'] += ' changed'
    with pytest.raises(ValueError, match='provenance page hash'):
        worker.document_inventory(policy, {page['id']: page})


@pytest.mark.parametrize('present', [False, True])
def test_publication_handling_presence_is_not_a_null_or_empty_default(present):
    import worker
    _, policy = O.fixture('redaction', query='The council asked [REDACTION].', corpus='cib')
    page = policy.corpus.pages[0]
    if present:
        page['handling'] = []
    else:
        page.pop('handling', None)
    before = deepcopy(page); policy.allowed = lambda _: True
    got = worker.document_inventory(policy, {page['id']: page})[page['document_id']][0]
    assert ('handling' in got) == present and page == before
    if present:
        assert got['handling'] == page['handling']
