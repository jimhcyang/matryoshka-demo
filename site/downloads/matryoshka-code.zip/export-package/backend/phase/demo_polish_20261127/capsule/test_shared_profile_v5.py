"""V5 synthetic processor/receipt controls. Never reads paid or corpus fixtures."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path

from jsonschema import Draft202012Validator,ValidationError
import pytest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_capsule_v5_v4_controls',HERE/'test_shared_profile_v4.py')
V4=importlib.util.module_from_spec(spec);spec.loader.exec_module(V4)
S,R,O,T=V4.S,V4.R,V4.O,V4.T
environment,no_network=V4.environment,V4.no_network
for _name,_fn in vars(V4).items():
    if _name.startswith('test_') and _name not in {'test_v4_exact_profile_and_unchanged_geometry_math','test_all_required_facts_retained_with_unchanged_batch_geometry'}:
        globals()[_name]=_fn


def test_exact_v5_profile_geometry_and_protocols():
    assert S.SETTINGS['processing_profile_version']=='shared-source-eight-pages/4'
    assert S.SETTINGS['proposal_version']=='source-realized-fill-proposals/current-readings-2'
    assert S.SETTINGS['scoped_proposal_version']=='source-realized-fill-proposals/scoped-policy-3'
    assert (S.SETTINGS['source_page_budget'],S.SETTINGS['source_full_text_utf8_budget'])==(8,32000)
    assert (S.SETTINGS['preferred_fact_page_rows'],S.SETTINGS['maximum_fact_page_rows'],S.SETTINGS['assessment_pages_per_batch'])==(4,8,2)
    assert (S.SETTINGS['max_fills_per_reading'],S.SETTINGS['displayed_fills'],S.SETTINGS['maximum_readings'])==(8,5,3)
    assert S.SETTINGS['rank_formula']=='(source_class+.99*(.75*alignment+.25*lexical))/3'
    assert S.SETTINGS['truncation'] is False and S.SETTINGS['automatic_retries']==0


@pytest.mark.parametrize('facts',range(1,9))
def test_v5_keeps_all_facts_and_unchanged_geometry_with_budget3(environment,facts):
    r,fake=environment;texts=[f'Mira opened gate number {i+1}.' for i in range(facts)];query=' '.join(texts)
    n,p=O.fixture(query=query)
    n['plan']['atoms']=[dict(n['plan']['atoms'][0],id='a'+str(i),text=t,
        query_spans=[dict(start=query.index(t),end=query.index(t)+len(t),text=t)]) for i,t in enumerate(texts)]
    n,p=T.many_pages(n,p,[query]*3);before=deepcopy((n,p.corpus.pages))
    result=S.execute(n,p,r,parse=O.SourceParses());assert not result['failures'],result['failures']
    assert (n,p.corpus.pages)==before
    budget=result['processing_budget'];batches=[w for stage,w in fake.calls if stage=='live_m_assessment_v1']
    assert all(len(w['required_facts'])==facts and len(w['pages'])<=min(2,max(1,4//facts)) for w in batches)
    assert result['assessment_scope']['processed_slots']==facts*3
    assert budget['version']=='private-live-source-processing-budget/3'
    assert budget['maximum_model_stages']==2*len(batches)+1
    assert budget['digest_body_bytes_limit']==65536 and budget['digest_earmark_usd']==.07
    assert budget['review_body_bytes_limit']==(65536 if facts<=4 else 260096)
    assert budget['review_minimum_earmark_usd']==pytest.approx(.10 if facts<=4 else .172032)
    assert budget['review_completion_guaranteed'] is False


def runtime(monkeypatch,tmp_path,available):
    from matryoshka_narrative import api,guards
    monkeypatch.setenv('OPENAI_API_KEY','fixture-no-real-key')
    monkeypatch.setattr(R,'ledger_total',lambda:0.);monkeypatch.setattr(guards,'remaining_seconds',lambda **k:600.)
    r=R.Runtime(tmp_path,cap=available);r.api_root=tmp_path/'fake-api';calls=[]
    def call(root,stage,payload,prompt,schema,**kwargs):
        calls.append(dict(stage=stage,payload=deepcopy(payload),schema=deepcopy(schema),cap=kwargs['cap']))
        return {},dict(receipt='fixture',cache=False)
    monkeypatch.setattr(api,'call',call);monkeypatch.setattr(r,'attest',lambda *a:{})
    return r,calls


def test_digest_earmark_is_minimum_not_actual_size_or_reservation_cap(monkeypatch,tmp_path):
    r,calls=runtime(monkeypatch,tmp_path,.25);budget=r.configure('redaction')
    payload=dict(qualification='x'*40000,decision='HOLD');before=deepcopy(payload)
    r.invoke('live_selected_source_digest_v1',payload,'fixture',dict(type='object'))
    assert calls[0]['payload']==before==payload and calls[0]['cap']==.25
    assert budget['digest_earmark_usd']==.07 and budget['digest_body_bytes_limit']==65536
    assert budget['digest_reservation_policy']=='ACTUAL_RESERVATION_WITHIN_EXISTING_CAPS_MINIMUM_EARMARK_ONLY'
    assert budget['review_minimum_earmark_usd'] is None


@pytest.mark.parametrize('available,chars,error',[(.08,40000,RuntimeError),(.8,65536,ValueError)])
def test_unfunded_or_oversized_digest_holds_without_clipping(monkeypatch,tmp_path,available,chars,error):
    r,calls=runtime(monkeypatch,tmp_path,available);r.configure('redaction');payload={'qualification':'x'*chars};before=deepcopy(payload)
    with pytest.raises(error):r.invoke('live_selected_source_digest_v1',payload,'fixture',dict(type='object'))
    assert calls==[] and payload==before


def test_full_actual_review_reservation_remains_required_after_minimum_preflight(monkeypatch,tmp_path):
    r,calls=runtime(monkeypatch,tmp_path,.8);r.configure('mosaic',maximum_source_calls=17,matrix_rows=8)
    r.invoke('live_m_assessment_v1',{},'fixture',dict(type='object'));assert len(calls)==1
    monkeypatch.setattr(r,'available',lambda:.30)
    payload=dict(qualification='x'*120000);before=deepcopy(payload)
    with pytest.raises(RuntimeError):r.invoke('live_m_review_v1',payload,'fixture',dict(type='object'))
    assert len(calls)==1 and payload==before and r.budget_plan['review_completion_guaranteed'] is False


@pytest.mark.parametrize('task',['mosaic','hypothesis'])
def test_review_failure_keeps_validated_source_rows_zero_credit(environment,monkeypatch,task):
    r,_=environment;n,p=O.fixture(task);before=deepcopy((n,p.corpus.pages));original=r.invoke
    def invoke(stage,*args,**kwargs):
        if stage in {'live_m_review_v1','live_h_review_v1'}:raise RuntimeError('Synthetic full-review reservation hold')
        return original(stage,*args,**kwargs)
    monkeypatch.setattr(r,'invoke',invoke);result=S.execute(n,p,r,parse=O.SourceParses())
    assert (n,p.corpus.pages)==before
    scope=result['assessment_scope']
    assert (scope['processed_slots'],scope['held_slots'],scope['accepted_slots'],scope['provider_reviewed_slots'],scope['unprocessed_slots'])==(1,1,0,0,0)
    row=result['source_judgments'][0]
    assert row['effective_direction']=='HOLD' and row['review'] is None and row['unanimous_model_accept'] is False
    assert row['semantic_credit']==0 and row['context_priority_index']==0
    assert row['raw_model_row'] and row['qualification_envelope']['full_page']['text']==p.corpus.pages[0]['text']
    assert result['failures'][0]['status']=='REVIEW_HOLD_FIRST_PASS_RETAINED'
    assert row['world_truth'] is False and row['inner_execution'] is False and row['event_join_authority'] is False


@pytest.mark.parametrize('task',['mosaic','hypothesis'])
def test_wrong_first_pass_hash_is_rejected_not_rebound_or_reported_as_absence(environment,task):
    r,fake=environment;n,p=O.fixture(task)
    def mutate(stage,output):
        if stage in {'live_m_assessment_v1','live_h_assessment_v1'}:output['request_sha256']='b'*64
    fake.mutate=mutate;result=S.execute(n,p,r,parse=O.SourceParses())
    assert result['failures'][0]['status']=='UNPROCESSED_BATCH_HOLD'
    assert result['assessment_scope']['processed_slots']==0 and result['assessment_scope']['unprocessed_slots']==1
    assert not result['source_judgments']


@pytest.mark.parametrize('field',['request_sha256','batch_sha256'])
def test_exact_hash_enum_is_strict_subset_and_does_not_change_input(field):
    payload={field:'a'*64} if field=='request_sha256' else dict(binding={field:'a'*64})
    schema=dict(type='object',properties={field:dict(type='string')},required=[field],additionalProperties=False)
    before=deepcopy((payload,schema));bound=R.specialize_response(payload,schema)
    assert (payload,schema)==before
    Draft202012Validator(bound).validate({field:'a'*64})
    with pytest.raises(ValidationError):Draft202012Validator(bound).validate({field:'b'*64})


@pytest.mark.parametrize('ids',[[],['c1','c1'],list(map(str,range(9))),[True]])
def test_bad_trusted_candidate_inventory_holds_before_call(ids):
    with pytest.raises(ValueError):R.specialize_response(dict(items=[dict(candidate_id=i) for i in ids]),{})


@pytest.mark.parametrize('order',[['c1','c1'],['c2','c1']])
def test_enum_and_count_never_replace_actual_ordered_unique_focal_guard(order):
    e=S.engines();case=dict(case_id='synthetic',corpus='cib',task='redaction',query='The [REDACTION] moved.',
        date='1960-01-01',document_id='synthetic_origin',focal_marker='[REDACTION]')
    packet=S.focal_packet(case,[],[dict(candidate_id=i) for i in ['c1','c2']],[],e)
    payload=packet['model_input'];schema=R.specialize_response(payload,e.focal.SCHEMA)
    def row(cid):return dict(candidate_id=cid,decision='NOINFO',material_fill_constraints_complete=False,
        source_ascription_only=True,visible_query_event_certified=False,cross_document_event_join_used=False,
        facets={k:dict(status='MISSING',fill_quotes=[],public_scope_quotes=[],source_anchor_ids=[],reason='Synthetic hold.') for k in e.focal.WEIGHTS},
        source_anchors=[],reason='Synthetic hold.')
    response=dict(batch_sha256=packet['batch_sha256'],rows=[row(cid) for cid in order])
    Draft202012Validator(schema).validate(response)
    with pytest.raises(ValueError,match='COMPLETE_ORDERED_FOCAL_MATRIX'):e.focal.validate_assessment(packet,response)
    with pytest.raises(ValidationError):Draft202012Validator(schema).validate(dict(response,rows=response['rows'][:1]))


@pytest.fixture
def captured(environment,monkeypatch):
    r,_=environment;n,p=O.fixture('mosaic');calls=[];original=r.attest
    def attest(*args):calls.append(deepcopy(args));return original(*args)
    monkeypatch.setattr(r,'attest',attest)
    result=S.execute(n,p,r,parse=O.SourceParses());assert not result['failures']
    r.provider_ids.clear();return r,original,calls[0]


@pytest.mark.parametrize('bad',['request','authorization','model','cost','rates','request_sha256','response_id','cache'])
def test_provider_four_artifact_binding_remains_strict(captured,bad):
    r,attest,(body,output,meta)=captured;receipt=r.api_root/meta['receipt'];record=json.loads(receipt.read_bytes());cid=receipt.stem
    if bad=='request':path=r.api_root/'attempts'/cid/'request.json';data=json.loads(path.read_bytes());data['model']='wrong'
    elif bad=='cache':
        from matryoshka_narrative import api
        key=R.sha(dict(version=api.VERSION,endpoint='https://api.openai.com/v1',stage=body['text']['format']['name'],request=body))
        path=r.api_root/'cache'/(key+'.json');data=json.loads(path.read_bytes());data['output_sha256']='0'*64
    else:
        path=receipt;data=record
        if bad=='cost':data['charged_or_reserved_usd']=99.
        elif bad=='rates':data['rates']=[0,0]
        elif bad=='request_sha256':data[bad]='0'*64
        else:data[bad]='wrong'
    path.write_text(json.dumps(data))
    with pytest.raises(ValueError,match='SOURCE_PROVIDER_ARTIFACTS_DIFFER'):attest(body,output,meta)
    assert not r.provider_ids


@pytest.mark.parametrize('bad',['duplicate','nonfinite'])
def test_raw_output_never_hides_duplicate_or_nonfinite_behind_same_effective_object(captured,bad):
    r,attest,(body,output,meta)=captured;path=r.api_root/'attempts'/Path(meta['receipt']).stem/'response.json'
    raw=json.loads(path.read_bytes());text=raw['output'][0]['content'][0]['text']
    insertion='"request_sha256":"discarded",' if bad=='duplicate' else '"request_sha256":1e99999,'
    raw['output'][0]['content'][0]['text']='{'+insertion+text[1:];path.write_text(json.dumps(raw))
    receipt=r.api_root/meta['receipt'];record=json.loads(receipt.read_bytes());record['response_sha256']=R.sha(raw);receipt.write_text(json.dumps(record))
    with pytest.raises(ValueError,match='DUPLICATE_PROVIDER_OUTPUT_KEY' if bad=='duplicate' else 'NONFINITE_PROVIDER_OUTPUT_NUMBER'):attest(body,output,meta)
    assert not r.provider_ids


def test_same_provider_response_cannot_be_reused_for_another_stage(captured):
    r,attest,args=captured;attest(*args)
    with pytest.raises(ValueError,match='SOURCE_STAGES_REUSE_PROVIDER_RESPONSE'):attest(*args)
