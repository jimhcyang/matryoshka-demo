"""Archive-only V7 import/test entrypoint; no checkout/data/provider fallback."""
import json
from importlib.machinery import ModuleSpec
from pathlib import Path
import socket
import sys


def contained(root,checkout,modules=None):
    names={'source_inference','source_runtime','source_readings','source_proposal_policy','contract','corpus_loader','protocol','producer_v4','producer_v5','run_fresh'}
    found=[]
    for name,module in list((sys.modules if modules is None else modules).items()):
        values=vars(module)
        file=values.get('__file__')
        # Runtime-generated modules can advertise nonexistent relative filenames.
        # Only real files imply a checkout location; project names still fail closed.
        path=Path(file).resolve() if isinstance(file,str) and Path(file).is_file() else None
        project=name.startswith('matryoshka_') or name in names
        if project and path is None:
            spec=values.get('__spec__');locations=values.get('__path__')
            namespace=isinstance(spec,ModuleSpec) and spec.origin is None and locations is not None and spec.submodule_search_locations is not None
            if namespace:
                locations=list(locations)
                namespace=bool(locations) and locations==list(spec.submodule_search_locations) and all(
                    isinstance(p,str) and Path(p).is_dir() and Path(p).resolve().is_relative_to(root) for p in locations)
            if namespace:found.append(name);continue
        source=project or path is not None and any(path.is_relative_to(checkout/repo) for repo in ('src-demo-day','matryoshka_demo_site'))
        if source and (path is None or not path.is_relative_to(root)):
            raise AssertionError('OUTSIDE_CONTAINED_SOURCE_IMPORT: '+name)
        if path is not None and path.is_relative_to(root):found.append(name)
    return found

def main():
    root,checkout,mode=Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve(),sys.argv[3]
    sys.path[:0]=[str(root),str(root/'phase/motion_login_20261122/live'),str(root/'phase/demo_polish_20261127/inference')]
    def forbidden(*args,**kwargs):raise AssertionError('API0_NETWORK_FORBIDDEN')
    socket.socket.connect=socket.socket.connect_ex=socket.create_connection=forbidden
    import source_runtime as runtime
    import source_inference as source
    import source_readings
    import run_fresh
    import worker
    assert callable(worker.source_record) and callable(worker.inspected_inventory)
    assert run_fresh.S is source
    import source_proposal_policy as policy
    e=runtime.engines()
    assert source.SETTINGS['processing_profile_version']=='shared-source-eight-pages/5'
    assert (source.SETTINGS['source_page_budget'],source.SETTINGS['source_full_text_utf8_budget'])==(8,32000)
    assert (source.SETTINGS['preferred_fact_page_rows'],source.SETTINGS['maximum_fact_page_rows'],source.SETTINGS['assessment_pages_per_batch'])==(4,8,2)
    assert source.SETTINGS['proposal_version']==policy.CURRENT_VERSION=='source-realized-fill-proposals/current-readings-2'
    assert source.SETTINGS['scoped_proposal_version']==policy.VERSION=='source-realized-fill-proposals/scoped-policy-3'
    assert runtime.DIGEST_BODY_LIMIT==65536 and runtime.DIGEST_RESERVE_USD==.07 and runtime.DIGEST_SECONDS==25
    assert runtime.MAX_INPUT-2048==260096
    assert 'source_readings.py' in runtime.DECLARED_LIVE_FILES
    assert e.proposal.VERSION=='source-realized-fill-proposals/7'
    assert e.m.VERSION=='model-source-anchor-observer/4' and e.h.VERSION=='reviewed-H-source-views/5'
    import corpus_loader
    try:corpus_loader.authority()
    except ValueError as error:assert 'SAVED_COHORT_AUTHORITY_REQUIRES_SEPARATE_PRIVATE_ARTIFACTS' in str(error)
    else:raise AssertionError('Saved cohort authority became available')
    assert contained(root,checkout)
    if mode=='tests':
        import pytest
        tests=[root/'phase/demo_polish_20261127/capsule/test_shared_profile.py',root/'phase/workbench_unification_20261127/live/test_strict_json.py',root/'phase/demo_polish_20261127/capsule/test_module_origins_v1.py']
        rc=pytest.main(['-q',*map(str,tests),'-p','no:cacheprovider','--basetemp',sys.argv[4],'--junitxml='+sys.argv[5]])
        assert rc==0,'CONTAINED_V7_TESTS_FAILED'
    elif mode!='imports':raise AssertionError('Unknown probe mode')
    print(json.dumps(dict(status='PASS',mode=mode,contained_modules=len(contained(root,checkout)),profile=source.SETTINGS['processing_profile_version'],
        source_code_only=True,outside_source_imports=False,API_calls=0,native_runs=0)))


if __name__=='__main__':main()
