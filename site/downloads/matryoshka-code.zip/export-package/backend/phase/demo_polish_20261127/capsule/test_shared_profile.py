"""V7 synthetic source-record parity; no source data or paid artifact imports."""
import ast
from copy import deepcopy
import importlib.util
import inspect
from pathlib import Path

import pytest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_capsule_v7_v6_controls', HERE/'test_shared_profile_v6.py')
V6 = importlib.util.module_from_spec(spec); spec.loader.exec_module(V6)
S, R, O, T = V6.S, V6.R, V6.O, V6.T
environment, no_network, captured = V6.environment, V6.no_network, V6.captured
for _name, _fn in vars(V6).items():
    if _name.startswith('test_'): globals()[_name] = _fn


@pytest.mark.parametrize('present,value', [(False, None), (True, {}), (True, None), (True, ['NOFORN'])])
def test_shared_source_record_preserves_presence_and_deepcopy_without_eligibility_claim(present, value):
    import worker
    _, policy = O.fixture('redaction', query='The council asked [REDACTION].', corpus='cib')
    page = policy.corpus.pages[0]; page.pop('handling', None)
    if present: page['handling'] = deepcopy(value)
    page.update(native_page={'view':'earlier','source_page':7}, source_hash_contract='canonical/1',
        raw_text_sha256='a'*64, internal_debug='not a source field', provenance_only=False, inspection_not_implied=False)
    before = deepcopy(page); policy.allowed = lambda _:True
    inspected = worker.inspected_inventory(policy, [page['id']])[page['id']]
    provenance = worker.document_inventory(policy, {page['id']:inspected})[page['document_id']][0]
    assert inspected == worker.source_record(page)
    assert {k:v for k,v in provenance.items() if k not in {'provenance_only','inspection_not_implied'}} == inspected
    assert ('handling' in inspected) is present
    if present: assert inspected['handling'] == value
    assert not {'internal_debug','provenance_only','inspection_not_implied'} & inspected.keys()
    assert provenance['provenance_only'] is True and provenance['inspection_not_implied'] is True
    inspected['native_page']['source_page'] = 99
    assert page == before and provenance['native_page']['source_page'] == 7


def test_shared_inspected_inventory_keeps_policy_and_raw_hash_rejections():
    import worker
    _, policy = O.fixture('redaction', query='The council asked [REDACTION].', corpus='cib')
    page = policy.corpus.pages[0]
    with pytest.raises(ValueError, match='absent or outside'): worker.inspected_inventory(policy, ['missing'])
    page['text'] += ' changed'
    with pytest.raises(ValueError, match='Inspected source hash changed'): worker.inspected_inventory(policy, [page['id']])
    policy.allowed = lambda _:False
    with pytest.raises(ValueError, match='absent or outside'): worker.inspected_inventory(policy, [page['id']])


def test_live_and_batch_share_the_same_inspected_projection_code():
    import worker
    root = HERE.parents[2]
    driver = root/'phase/demo_polish_20261127/inference/run_fresh.py'
    tree = ast.parse(driver.read_bytes())
    one_case = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'one_case')
    assert any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == 'inspected_inventory' for n in ast.walk(one_case))
    assert 'PAGE_FIELDS' not in ast.unparse(one_case)
    assert 'source_record(page)' in inspect.getsource(worker.inspected_inventory)
    assert 'source_record(page)' in inspect.getsource(worker.document_inventory)
    assert 'sources[page_id] = source_record(page)' in Path(worker.__file__).read_text()
