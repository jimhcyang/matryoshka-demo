"""Original release-v0421 task engines on a fixed, eligible source snapshot.

This is NOT the similarly named src-redaction matcher, a reproduction of the
original retrieval pipeline, or an entailment baseline. The release's parser,
QueryPackage.load, engines, thresholds, lexical normalization, score/authority
normalization and output contracts run without modification. Only corpus
loading is replaced: admitted raw pages become native sentence records and
locally inferred signatures, not historical KG extraction tables. No original
corpus/cache loader, graph retriever, matcher.main, or optional LLM is called.

ORIGINAL_QUERY_CONTRACT documents the real disk contract. A temporary package
is written by the original parser and read by the original QueryPackage.load;
we do not emulate its primary-target, placeholder or preflight filtering.
All filesystem writes are confined to that temporary directory. Native text
normalization remains visible in native outputs; citations separately quote
the unchanged source, with exact Python character offsets and source hashes.
Redaction also returns a separately labeled focal-marker-only adapted branch;
the literal control and its public case remain unchanged.
"""
from __future__ import annotations

from collections import defaultdict
from copy import deepcopy
from dataclasses import asdict
from datetime import date
from functools import lru_cache
import hashlib
import importlib
import importlib.util
import math
import operator
from pathlib import Path
import re
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

from .contracts import MASK, public_case
from .corpus import locate
from .io import digest


VERSION = "original-release-fixed-source-reference/2"
WORKSPACE = Path(__file__).resolve().parents[2]
ORIGINAL_ROOT = (WORKSPACE / "src/scripts/matryoshka_workbench/release_v0421/matryoshka_v0420")
_PACKAGE = "_matryoshka_original_release_v0421_reference_v2"
AUDIT_ROWS_PER_TARGET = 100
ORIGINAL_QUERY_CONTRACT = {
    "reader": "query.QueryPackage.load",
    "accepted_schemas": ["query_parse_schema_v0_4_6", "query_parse_schema_v0_4_7"],
    "manifest": "query_parse_manifest.json",
    "tables": ["query_fragments.csv", "query_entities.csv", "query_claims.csv",
               "query_events.csv", "query_relations.csv", "query_propositions.csv",
               "query_atomic_propositions.csv", "query_redaction_slots.csv",
               "query_sentence_redaction_slots.csv"],
    "construction": "parser.parse_query_text(use_openai=False), parser.write_parse_outputs",
    "primary_target_policy": "Original QueryPackage.load filtering and task-local preflight",
    "proof_target_policy": "Original atomic_proposition_records, with native proposition fallback",
    "parser_mode": "heuristic; not an API parse or a supplied v2 atomic plan",
    "hypothesis_engines": ["claims", "contradictions"],
    "marker_policy": "Unmodified query; only redaction markers recognized by the original parser",
    "native_value_marker_example": "[REDACT:R1 type=PERSON]",
    "demo_marker_compatibility": "[REDACTION 1] is not a native value slot; return the original blocked preflight",
}
CONTRACT_FUNCTIONS = {
    "parser.parse_query_text": "Original deterministic query parser; use_openai is always False",
    "parser.write_parse_outputs": "Original schema, primary tables, table hashes and frozen parse manifest",
    "query.QueryPackage.load": "Original schema, primary-target and task-local parser-preflight checks",
    "query.QueryPackage.atomic_proposition_records": "Original atomic proof-target projection, used by engines",
    "query.QueryPackage.proposition_records": "Original canonical proposition projection/fallback",
    "matcher._preflight": "Original task readiness checks",
    "matcher.ENGINE_TYPES": "Original task engine dispatch, not an adapter-defined score decision",
    "matcher._normalize_score_and_authority_contract": "Original authority selection and comparable-competitor margins",
    "matcher._bounded_audit_exports": "Original post-decision audit sampling; omission counts are returned",
    "contracts.task_row": "Original task decision/status/score schema, called inside native engines",
    "contracts.authoritative_digest": "Original deterministic decision digest; no LLM synthesis",
    "contracts.configuration_hash": "Original configuration fingerprint",
}
LIMITATIONS = [
    "Fixed-source matcher reference only: no original end-to-end retrieval or retrieval-superiority claim.",
    "The same admitted pages and page budget are used; native engines may rerank only that snapshot.",
    "Raw pages supply native sentence signatures and heuristic entity values, not the original extracted KG tables.",
    "Query parsing is the original offline heuristic mode, not the original optional API parser.",
    "Demo-only redaction markers are not rewritten into native slots; unsupported syntax retains its native block.",
    "Only packaged core semantic resources are loaded; no corpus-wide alias resources or graph are opened.",
    "Native classifications and numeric scores are returned unchanged, including any native matching limitations.",
    "Similarity, event identity, final scores and margins are heuristic ranking diagnostics, not entailment probabilities.",
    "Missing evidence is not counterevidence; results concern the inspected snapshot, not corpus-wide absence.",
    "Citation replay certifies source characters, not the correctness of a native semantic judgment.",
    "Document-only citation bindings are explicitly weaker than localized native-record/text bindings.",
]


@lru_cache(maxsize=1)
def load_original():
    """Load the actual release under a private package, refusing name collisions."""
    scripts_root = ORIGINAL_ROOT.parents[2]
    common_root = scripts_root / "common"
    for name in ("common", "common.document_eligibility", "common.retrieval_graph"):
        existing = sys.modules.get(name)
        if existing is not None:
            paths = list(getattr(existing, "__path__", ())) or [getattr(existing, "__file__", "")]
            if not paths or any(not Path(p).resolve().is_relative_to(common_root) for p in paths):
                raise ImportError("Refusing a non-original common module: " + name)
    saved_path, saved_bytecode = list(sys.path), sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(scripts_root))
        if _PACKAGE not in sys.modules:
            spec = importlib.util.spec_from_file_location(
                _PACKAGE, ORIGINAL_ROOT / "__init__.py", submodule_search_locations=[str(ORIGINAL_ROOT)])
            if spec is None or spec.loader is None:
                raise ImportError("Original Matryoshka release not found")
            package = importlib.util.module_from_spec(spec)
            sys.modules[_PACKAGE] = package
            spec.loader.exec_module(package)
        modules = {name: importlib.import_module(_PACKAGE + "." + name) for name in
                   ("matcher", "parser", "query", "corpus", "semantics", "contracts",
                    "decision", "retrieval", "semantic_resources", "progress", "engines.base")}
        for name, module in tuple(sys.modules.items()):
            if name == _PACKAGE or name.startswith(_PACKAGE + "."):
                if not Path(module.__file__).resolve().is_relative_to(ORIGINAL_ROOT):
                    raise ImportError("Original module lineage mismatch: " + name)
        return SimpleNamespace(**{name.replace(".", "_"): module for name, module in modules.items()})
    finally:
        sys.path[:] = saved_path
        sys.dont_write_bytecode = saved_bytecode


def _json(value):
    """Keep native floating-point precision; map pandas missing cells to null."""
    if isinstance(value, dict):
        return {str(k): _json(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return [_json(v) for v in sorted(value)]
    if hasattr(value, "item"):
        return _json(value.item())
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    import pandas as pd
    if value is pd.NA or value is pd.NaT:
        return None
    raise TypeError("Non-JSON native result: " + type(value).__name__)


def _snapshot(case, retrieval, passage_budget):
    corpus, mask = retrieval["eligible"].corpus, retrieval["eligible"].page_mask
    admitted = set()
    for value in retrieval["pages"]:
        pi = operator.index(value)
        if pi < 0 or pi >= len(corpus.pages):
            raise ValueError("Invalid retrieved page index")
        page = corpus.pages[pi]
        if (not mask[pi] or date.fromisoformat(page["date"]) >= date.fromisoformat(case["date"]) or
                page["document_id"].strip().casefold() == case["document_id"].strip().casefold()):
            raise ValueError("Reference refuses an ineligible, cutoff or origin source")
        admitted.add(pi)
    ranks = retrieval.get("page_ranks", {})
    chosen = sorted(admitted, key=lambda pi: (ranks.get(pi, 10**9), pi))[:passage_budget]
    # The original corpus and its paths, units, graph and excluded text never
    # cross the native-engine boundary.
    return [deepcopy(corpus.pages[pi]) for pi in chosen], len(admitted)


def _citation(page, native_doc, start, end, kind):
    raw = page["text"]
    return dict(id="citation_" + digest([page["id"], start, end, kind])[:24],
                document_id=page["document_id"], native_document_id=native_doc,
                canonical_page_id=page["id"], date=page["date"], start=start, end=end,
                text=raw[start:end], page_sha256=page["source_sha256"],
                raw_text_sha256=hashlib.sha256(raw.encode("utf-8")).hexdigest(), granularity=kind)


def _locate_native_sentence(raw, normalized_sentence, cursor):
    """Find the earliest forward whitespace-equivalent source occurrence.

    Do not prefer a later literal duplicate to an earlier line-wrapped match:
    doing so would advance the cursor past the following native sentence.
    All non-whitespace characters, including OCR errors, remain literal.
    """
    pattern = r"\s+".join(re.escape(part) for part in normalized_sentence.split())
    found = re.search(pattern, raw[cursor:]) if pattern else None
    return (cursor + found.start(), cursor + found.end()) if found else None


def _source_index(native, pages, root, task, origin):
    documents, dates, originals = defaultdict(list), {}, {}
    propositions, sentences, values = defaultdict(list), defaultdict(list), defaultdict(list)
    citations, record_citations = {}, {}
    for pi, page in enumerate(pages):
        doc_id = native.semantics.clean_text(page["document_id"]).upper()
        if doc_id in originals and originals[doc_id] != page["document_id"]:
            raise ValueError("Distinct source identities collide under original ID normalization")
        originals[doc_id] = page["document_id"]
        raw = page["text"]
        chunk_id = "fixed_page_" + str(pi)
        documents[doc_id].append(native.semantics.clean_text(raw))
        dates[doc_id] = max(dates.get(doc_id, ""), page["date"])
        page_cite = _citation(page, doc_id, 0, len(raw), "PAGE")
        citations[page_cite["id"]] = page_cite
        parts, cursor = native.corpus._sentences(raw), 0
        for si, text in enumerate(parts):
            interval = _locate_native_sentence(raw, text, cursor)
            if interval is None:
                raise ValueError("Native sentence normalization cannot be replayed in raw source: "
                                 + page["id"] + ", sentence " + str(si) + ", cursor " + str(cursor))
            start, end = interval
            cursor = end
            citation = _citation(page, doc_id, start, end, "SENTENCE")
            citations[citation["id"]] = citation
            row_id = chunk_id + "::sentence_" + str(si)
            record_citations[(doc_id, row_id)] = citation["id"]
            arguments = native.semantics.infer_simple_clause_arguments(text)
            signature = native.semantics.build_event_signature(
                text, actor=arguments.get("actor", ""), predicate=arguments.get("predicate", ""),
                obj=arguments.get("object", ""), location=arguments.get("location", ""), report_time=page["date"])
            propositions[doc_id].append(native.corpus.PropositionRecord(
                doc_id, "chunks.csv", row_id, text, signature, page["date"]))
            sentences[doc_id].append(native.corpus.SentenceRecord(
                doc_id, chunk_id, si, parts[si - 1] if si else "", text,
                parts[si + 1] if si + 1 < len(parts) else "", "text"))
        if task == "redaction":
            for ei, entity in enumerate(native.parser.extract_heuristic_entities(chunk_id, raw)):
                label = entity["label"]
                if locate(raw, label) is not None and not MASK.search(label):
                    values[doc_id].append(native.corpus.ValueRecord(
                        doc_id, "adapter_local_entities", chunk_id + ":E" + str(ei),
                        label, entity["type"], native.semantics.clean_text(raw)))
    texts = {doc: "\n".join(parts) for doc, parts in documents.items()}
    corpus = native.corpus.CorpusIndex(
        extraction_dir=root / "NO_CORPUS_FILES", excluded_doc_ids=frozenset({origin.strip().upper()}),
        requested_task=task, document_text=texts,
        document_tokens={doc: frozenset(native.semantics.semantic_tokens(text)) for doc, text in texts.items()},
        document_dates=dates, propositions_by_doc={doc: tuple(rows) for doc, rows in propositions.items()},
        values_by_doc={doc: tuple(rows) for doc, rows in values.items()},
        sentences_by_doc={doc: tuple(rows) for doc, rows in sentences.items()}, provenance_by_doc={},
        fingerprint=digest(pages), load_statistics={})
    return corpus, citations, record_citations, originals


def _references(row, citations, record_citations, native):
    docs = set()
    known = {c["native_document_id"] for c in citations.values()}
    for key, value in row.items():
        if isinstance(value, str) and (key in {"doc_id", "corpus_doc_id"} or key.endswith("_doc_id")):
            docs.update(part.strip() for part in re.split(r"[|,;]", value) if part.strip() in known)
    ids = {record_citations[(doc, value)] for doc in docs for value in row.values()
           if isinstance(value, str) and (doc, value) in record_citations}
    if ids:
        return dict(citation_ids=sorted(ids), binding="NATIVE_RECORD_ID")
    texts = {native.semantics.clean_text(value) for key, value in row.items()
             if isinstance(value, str) and ("text" in key or "sentence" in key or "passage" in key)}
    ids = {cid for cid, citation in citations.items() if citation["native_document_id"] in docs
           and native.semantics.clean_text(citation["text"]) in texts}
    if ids:
        return dict(citation_ids=sorted(ids), binding="LITERAL_TEXT_WITH_NATIVE_WHITESPACE_NORMALIZATION")
    return dict(citation_ids=sorted(cid for cid, c in citations.items()
                                   if c["native_document_id"] in docs and c["granularity"] == "PAGE"),
                binding="DOCUMENT_ONLY_NOT_LOCALIZED" if docs else "NO_NATIVE_SOURCE_SELECTED")


def _lineage(native, engines):
    modules = {name: module for name, module in tuple(sys.modules.items())
               if name == _PACKAGE or name.startswith(_PACKAGE + ".")}
    modules.update({name: sys.modules[name] for name in
                    ("common.document_eligibility", "common.retrieval_graph")})
    files = {}
    for module in modules.values():
        path = Path(module.__file__).resolve()
        files[str(path.relative_to(WORKSPACE))] = native.semantics.sha256_file(path)
    resource = native.semantic_resources.CORE_RESOURCE_PATH.resolve()
    files[str(resource.relative_to(WORKSPACE))] = native.semantics.sha256_file(resource)
    functions = dict(CONTRACT_FUNCTIONS)
    for task in engines:
        cls = native.matcher.ENGINE_TYPES[task]
        functions[cls.__module__.removeprefix(_PACKAGE + ".") + "." + cls.__name__ + ".run"] = "Native task decision engine"
    return dict(original_root=str(ORIGINAL_ROOT), module_namespace=_PACKAGE,
                matcher_module=str(Path(native.matcher.__file__).resolve()),
                files_sha256=dict(sorted(files.items())), contract_functions=functions,
                invoked_native_engines=list(engines),
                contract_function_scope="Workflow function documentation; task-dependent calls may be blocked by native preflight",
                source_representation_functions=["corpus._sentences", "semantics.infer_simple_clause_arguments",
                    "semantics.build_event_signature", "semantics.semantic_tokens"],
                retrieval_reproduced=False, scoped_matcher_substitution=False)


def _run_native(case, pages, admitted, receipt, passage_budget, native, *, native_query=None):
    """Run unchanged native contracts on a frozen snapshot and parser input."""
    query_text = case["query"] if native_query is None else native_query
    tasks = ["claims", "contradictions"] if case["task"] == "hypothesis" else [case["task"]]
    results, supports, diagnostics, executed = {}, [], {}, []
    resources = native.semantic_resources.load_semantic_resources()
    with TemporaryDirectory(prefix="matryoshka-original-fixed-sources-") as temporary:
        root = Path(temporary)
        query_file = root / "query.txt"
        query_file.write_text(query_text, encoding="utf-8")
        parsed, mode, warnings = native.parser.parse_query_text(query_text, use_openai=False)
        query_root = root / "query"
        native.parser.write_parse_outputs(parsed, query_root, str(query_file), mode, warnings)
        corpus, citations, record_citations, doc_map = _source_index(
            native, pages, root, case["task"], case["document_id"])
        config = native.engines_base.EngineConfig()
        manifest = native.contracts.safe_json(query_root / "query_parse_manifest.json")
        for task in tasks:
            try:
                query = native.query.QueryPackage.load(query_root, task=task)
            except ValueError as error:
                if "no executable primary target" not in str(error):
                    raise
                results[task] = dict(execution_status="BLOCKED_BY_ORIGINAL_QUERY_CONTRACT", error=str(error), evaluation=[])
                continue
            preflight = native.matcher._preflight(task, query)
            if any(row["status"].startswith("BLOCKED_") for row in preflight):
                results[task] = dict(execution_status="BLOCKED_BY_ORIGINAL_QUERY_CONTRACT", preflight=preflight, evaluation=[])
                continue
            control = native.progress.RunControl(root / task)
            context = native.engines_base.EngineContext(corpus, query, root / task, control, config, resources)
            result = native.matcher.ENGINE_TYPES[task]().run(context)
            executed.append(task)
            evaluation = native.matcher._normalize_score_and_authority_contract(result.evaluation)
            exported, audit = native.matcher._bounded_audit_exports(
                task, result.artifacts, evaluation, AUDIT_ROWS_PER_TARGET)
            rows = _json(evaluation.to_dict("records"))
            results[task] = dict(execution_status="EXECUTED", preflight=preflight,
                evaluation=rows, metadata=_json(result.metadata),
                authoritative_digest=native.contracts.authoritative_digest(evaluation),
                audit_export_summary=_json(audit.to_dict("records")))
            for index, row in enumerate(rows):
                supports.append(dict(task=task, native_evaluation_row=index,
                    native_semantic_status=row["semantic_status"],
                    **_references(row, citations, record_citations, native)))
            diagnostics[task] = {}
            for name, frame in exported.items():
                records = _json(frame.to_dict("records"))
                diagnostics[task][name] = dict(rows=records,
                    source_bindings=[_references(row, citations, record_citations, native) for row in records])
        configuration = dict(engine_config=asdict(config), fixed_source_fingerprint=corpus.fingerprint,
                             semantic_resource_fingerprint=resources.fingerprint, task=case["task"])
        query_contract = {key: manifest.get(key) for key in (
            "schema_version", "normalization_version", "parser_mode", "query_sha256",
            "query_parse_sha256", "table_sha256", "frozen_parse_contract")}
    return _json(dict(version=VERSION, task=case["task"], case_id=case["case_id"],
        reference_kind="ORIGINAL_NATIVE_ENGINES_FIXED_ELIGIBLE_SOURCES",
        native_results=results, support_results=supports, matching_diagnostics=diagnostics,
        citations=list(citations.values()), native_document_id_map=doc_map,
        original_query_contract=deepcopy(ORIGINAL_QUERY_CONTRACT), query_package=query_contract,
        lineage=_lineage(native, executed), native_configuration=configuration,
        configuration_sha256=native.contracts.configuration_hash(configuration),
        source_pages_inspected=len(pages), source_pages_admitted=admitted, passage_budget=passage_budget,
        budget_unit="whole_source_page", retrieval=deepcopy(receipt),
        limitations=list(LIMITATIONS), api_calls=0, retrieval_reproduced=False,
        retrieval_superiority_claim_permitted=False, scores_are_entailment=False,
        general_entailment_certified=False, missing_evidence_is_counterevidence=False))


def _marker_adaptation(case):
    """Replace only the focal opaque token; unchanged runs map characterwise."""
    raw, marker, replacement = case["query"], case["focal_marker"], "[REDACT:R1]"
    start = raw.index(marker)
    raw_end, transformed_end = start + len(marker), start + len(replacement)
    transformed = raw[:start] + replacement + raw[raw_end:]
    pieces = []
    if start:
        pieces.append(dict(kind="UNCHANGED", raw_start=0, raw_end=start,
                           transformed_start=0, transformed_end=start, mapping="EXACT_CHARACTER_OFFSET"))
    pieces.append(dict(kind="OPAQUE_MARKER_REPLACEMENT", raw_start=start, raw_end=raw_end,
                       transformed_start=start, transformed_end=transformed_end,
                       mapping="BOUNDARIES_ONLY", interior_inverse_defined=False))
    if raw_end < len(raw):
        pieces.append(dict(kind="UNCHANGED", raw_start=raw_end, raw_end=len(raw),
                           transformed_start=transformed_end, transformed_end=len(transformed),
                           mapping="EXACT_CHARACTER_OFFSET"))
    return transformed, dict(version="focal-native-marker-only/1", raw_query=raw,
        transformed_query=transformed, raw_query_sha256=hashlib.sha256(raw.encode("utf-8")).hexdigest(),
        transformed_query_sha256=hashlib.sha256(transformed.encode("utf-8")).hexdigest(),
        replacement=dict(raw_start=start, raw_end=raw_end, raw_text=marker,
                         transformed_start=start, transformed_end=transformed_end, transformed_text=replacement),
        piecewise_map=pieces, coordinate_unit="PYTHON_UNICODE_CODE_POINTS",
        native_parser_input_only=True, type_hints_supplied=False, slot_readings_used=False,
        answer_information_used=False, adjacent_masks_preserved=True)


def run(case, retrieval, passage_budget=100):
    """Return a literal native control plus a marker-only redaction reference.

    Validate only the original public case. Both branches consume the exact
    same admitted snapshot; the private parser-input override never goes back
    through public_case and never supplies an answer, type or reading hint.
    Original scoring, gates, task decisions and score normalization are intact.
    """
    case = public_case(case)
    if type(passage_budget) is not int or passage_budget < 0:
        raise ValueError("passage_budget must be a nonnegative integer")
    pages, admitted = _snapshot(case, retrieval, passage_budget)
    native = load_original()
    literal = _run_native(case, pages, admitted, retrieval["receipt"], passage_budget, native)
    if case["task"] == "redaction":
        transformed, audit = _marker_adaptation(case)
        adapted = _run_native(case, pages, admitted, retrieval["receipt"], passage_budget, native,
                              native_query=transformed)
        adapted["reference_kind"] = "ORIGINAL_NATIVE_ENGINES_MARKER_ONLY_ADAPTED_FIXED_ELIGIBLE_SOURCES"
        adapted["query_adaptation"] = audit
        adapted["original_query_contract"]["marker_policy"] = (
            "Only the focal marker is replaced by [REDACT:R1] in native parser input; all other query text is literal")
        adapted["original_query_contract"]["demo_marker_compatibility"] = "Focal-marker-only syntax adapter; no type hints"
        adapted["limitations"] = [item for item in adapted["limitations"] if not item.startswith("Demo-only redaction markers")]
        adapted["limitations"].append(
            "Separate marker-only adapted arm, not the literal control; only the focal opaque marker changes, with no answer or type hints.")
        literal["marker_adapted_reference"] = adapted
    return literal
