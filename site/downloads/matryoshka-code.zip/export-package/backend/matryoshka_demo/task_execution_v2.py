"""Deterministic, source-bound execution of an already supplied atomic plan.

Only the sentences anchoring planned atoms are used for query scope recovery.
Derived KG labels and generative assessments are never evidence. Verdicts are
bounded lexical/structural decisions, not general entailment certification.
Query-coverage auditing can withhold a complete positive verdict, but never
adds unplanned propositions to execution or searches evidence for them.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import re

from .contracts import MASK, public_case, span
from .io import digest
from .planning import sentences
from .tasks import decide, parser, target_frames
from .vendor import matching


VERSION = "source-bound-task-execution/2"
SLOTS = ("actor", "predicate", "object", "quantity", "event_date", "location",
         "polarity", "attribution", "modality")
_NUMBERS = dict(zip(
    "zero one two three four five six seven eight nine ten eleven twelve".split(),
    map(str, range(13))))
_LOCATION_PREPS = {"in", "at", "on", "near", "from", "to", "into", "outside", "inside", "around",
                   "across", "over", "under", "between", "within", "off", "through", "along"}
_QUANTITY_OPERATOR = re.compile(
    r"\b(no\s+more\s+than|no\s+fewer\s+than|at\s+least|at\s+most|more\s+than|less\s+than|"
    r"fewer\s+than|up\s+to|exactly|approximately|about|roughly|over|under|nearly)\s*$", re.I)
_QUESTIONS = {
    "actor": "Which named actor performed this action, rather than receiving it?",
    "predicate": "Does a source explicitly attest this action, not just the same participants?",
    "object": "Which object or recipient was involved in this action?",
    "quantity": "What quantity, unit and quantifier are explicitly attached to this event?",
    "event_date": "When did the event occur, independently of the document's publication date?",
    "location": "Where did this event occur, and is it the same event as the planned proposition?",
    "polarity": "Does the source assert or negate this exact scoped proposition?",
    "attribution": "Who made the assertion, and is there independent evidence for the reported event?",
    "modality": "Is the event asserted, merely possible, conditional, questioned, or unverified?",
}


def offset_safe_parser(parse):
    """Analyze all-uppercase text locally without changing source characters.

    Copy annotations only when token boundaries agree exactly. Unicode case
    expansion and changed tokenization fall back to the unmodified parser.
    Neither cached parser documents nor any caller-owned object are mutated.
    """
    @lru_cache(maxsize=512)
    def annotated(text):
        raw = parse(text)
        lowered = text.lower()
        if not text.isupper() or len(lowered) != len(text):
            return raw
        analysis = parse(lowered)
        if len(raw) != len(analysis) or any(
                (a.idx, len(a.text)) != (b.idx, len(b.text))
                for a, b in zip(raw, analysis)):
            return raw
        from spacy.attrs import DEP, ENT_IOB, ENT_TYPE, HEAD, LEMMA, POS, SENT_START, TAG
        attrs = [HEAD, DEP, POS, TAG, LEMMA, ENT_IOB, ENT_TYPE, SENT_START]
        restored = raw.copy()
        restored.from_array(attrs, analysis.to_array(attrs))
        return restored
    return annotated


def _row(target, source, status):
    return dict(target=deepcopy(target), source=deepcopy(source), status=status)


def _values(frame, roles):
    return [p for role, values in frame["roles"].items() if role in roles for p in values]


def _argument(target, source, roles, alignment):
    wanted, available = _values(target, roles), _values(source, roles)
    checks = [r for r in alignment if r["role"] in roles]
    if not available:
        available = [r["source"] for r in checks if r["source"] is not None]
    if not wanted:
        status = "UNSPECIFIED"
    elif not available:
        status = "MISSING"
    else:
        status = ("MATCH" if checks and all(r["status"] == "EXACT_SCOPED_ARGUMENT" for r in checks)
                  else "PARTIAL" if checks and all(r["status"] in {
                      "EXACT_SCOPED_ARGUMENT", "PARTIAL_ARGUMENT_QUALIFIER"} for r in checks)
                  else "MISSING" if any(r["status"] == "MISSING" for r in checks) else "MISMATCH")
    return _row(wanted, available, status)


def _walk_phrases(frame):
    def walk(role, phrase):
        yield role, phrase
        for item in phrase.get("modifiers", []):
            yield from walk(role + "/" + item["relation"], item["phrase"])
    for role, values in frame["roles"].items():
        for phrase in values:
            yield from walk(role, phrase)


def _quantities(frame):
    result = []
    for role, phrase in _walk_phrases(frame):
        amounts = [_NUMBERS.get(p["lemma"], p["lemma"].replace(",", ""))
                   for p in phrase["proofs"] if p["pos"] == "NUM"]
        operators, units = [], []
        for proof in phrase["proofs"]:
            if proof["pos"] != "NUM":
                continue
            prefix = frame["quote"][:max(0, proof["start"] - frame["start"])]
            suffix = frame["quote"][max(0, proof["end"] - frame["start"]):]
            operator = _QUANTITY_OPERATOR.search(prefix)
            operators.append(" ".join(operator[1].casefold().split()) if operator else "unspecified")
            currency = re.search(r"([$\u00a3\u20ac\u00a5])\s*$", prefix)
            units.append(currency[1] if currency else "%" if re.match(r"\s*%", suffix) else None)
        if amounts or phrase["quantifiers"]:
            result.append(dict(role=role, head=phrase["head"], values=amounts,
                               operators=operators, units=units, quantifiers=phrase["quantifiers"]))
    return result


def _locations(frame):
    result = []
    for role, phrase in _walk_phrases(frame):
        relation = role.removeprefix("prep:").split("/")[-1]
        if relation in _LOCATION_PREPS:
            result.append(dict(role=role, head=phrase["head"], terms=phrase["terms"]))
    return result


def _collection(wanted, available):
    status = ("UNSPECIFIED" if not wanted else "MISSING" if not available else
              "MATCH" if all(value in available for value in wanted) else "MISMATCH")
    return _row(wanted, available, status)


def _dates(target, source):
    wanted, available = target["event_dates"], source["event_dates"]
    a, b = [r["value"] for r in wanted], [r["value"] for r in available]
    if not wanted:
        status = "UNSPECIFIED"
    elif not available:
        status = "MISSING"
    elif None in a or None in b:
        status = "UNRESOLVED"
    elif all(any(value.startswith(w) for value in b) for w in a) and all(
            any(value.startswith(w) or w.startswith(value) for w in a) for value in b):
        status = "MATCH"
    elif all(any(value.startswith(w) or w.startswith(value) for value in b) for w in a):
        status = "PARTIAL"
    else:
        status = "MISMATCH"
    return _row(wanted, available, status)


def _modal(frame):
    q = frame["qualifiers"]
    return {key: deepcopy(q[key]) for key in
            ("modality", "conditional", "question", "epistemic_absence", "unresolved")}


def _embedded_actor_unresolved(frame):
    actors = frame["roles"].get("agent", [])
    return frame["kind"] == "EVENT" and bool(frame["qualifiers"]["scope"]) and (
        not actors or any(p["unresolved"] for p in actors))


def _governing_actor_constraint(frame):
    """Inspect actual subjects as constraints; never resolve control arguments."""
    direct = frame["roles"].get("agent", [])
    if direct and not any(p["unresolved"] for p in direct):
        return direct
    scopes = frame["qualifiers"]["scope"]
    if not scopes:
        return []
    nearest = scopes[0]
    # Do not interpret reporting subjects, nominal governors, or xcomp
    # object-control constructions as the actor of the embedded event.
    if nearest["relation"] != "advcl" or nearest["predicate"] in matching.parent._REPORTING:
        return []
    speakers = nearest["speakers"]
    if len(speakers) != 1 or speakers[0]["unresolved"]:
        return []
    return speakers if any(p["dependency"] == "nsubj" and p["lemma"] == speakers[0]["head"]
                           for p in speakers[0]["proofs"]) else []


def _diagnostics(target, source, alignment):
    actors = {"owner"} if target["kind"] == "PROPERTY" else {"agent"}
    objects = {r for r in target["roles"] if r not in actors and not r.startswith("prep:")}
    if target.get("focus_role"):
        objects.add(target["focus_role"])
    diagnostics = dict(
        actor=_argument(target, source, actors, alignment),
        predicate=_row(target["predicate"], source["predicate"],
                       "MATCH" if target["predicate"] == source["predicate"] else "MISMATCH"),
        object=_argument(target, source, objects, alignment),
        quantity=_collection(_quantities(target), _quantities(source)),
        event_date=_dates(target, source),
        location=_collection(_locations(target), _locations(source)),
        polarity=_row("negative" if target["qualifiers"]["negated"] else "positive",
                      "negative" if source["qualifiers"]["negated"] else "positive",
                      "MATCH" if target["qualifiers"]["negated"] == source["qualifiers"]["negated"] else "OPPOSED"))
    t, s = target["qualifiers"], source["qualifiers"]
    diagnostics["attribution"] = _row(t["scope"], s["scope"],
        "MATCH" if matching._scope_key(t["scope"]) == matching._scope_key(s["scope"]) else "MISMATCH")
    diagnostics["modality"] = _row(_modal(target), _modal(source),
        "MATCH" if _modal(target) == _modal(source) else "MISMATCH")
    if _embedded_actor_unresolved(target) or _embedded_actor_unresolved(source):
        wanted, available = _governing_actor_constraint(target), _governing_actor_constraint(source)
        incompatible = (len(wanted) == len(available) == 1 and wanted[0]["names"] and available[0]["names"]
                        and (wanted[0]["head"], wanted[0]["names"]) != (available[0]["head"], available[0]["names"]))
        diagnostics["actor"].update(status="MISMATCH" if incompatible else "UNRESOLVED",
            binding="EMBEDDED_EVENT_ACTOR_NOT_INHERITED", governing_subject_constraints=_row(
                wanted, available, "MISMATCH" if incompatible else "UNRESOLVED"),
            subject_control_certified=False)
    return diagnostics


def _compare(target, source):
    native = matching.compare(target, source)
    if native is None:
        return None
    diagnostics = _diagnostics(target, source, native["argument_matches"])
    direction, reasons = native["direction"], list(native["reasons"])
    # A different participant, quantity, place or date is not the same event
    # with opposite polarity. Never promote a matcher result in these guards.
    different = [k for k in SLOTS[:6] if diagnostics[k]["status"] == "MISMATCH"]
    incomplete = [k for k, row in diagnostics.items()
                  if row["status"] in {"MISSING", "PARTIAL", "UNRESOLVED"} or
                  (k in {"attribution", "modality"} and row["status"] == "MISMATCH")]
    if different:
        direction = "RELATED"
        reasons.extend("DIFFERENT_" + k.upper() + "_NOT_COUNTEREVIDENCE" for k in different)
    elif incomplete and direction in {"SUPPORT", "COUNTER"}:
        direction = "PARTIAL"
        reasons.extend("UNRESOLVED_" + k.upper() for k in incomplete)
    if _embedded_actor_unresolved(target) or _embedded_actor_unresolved(source):
        direction = "RELATED"
        reasons.append("EMBEDDED_EVENT_ACTOR_BINDING_UNRESOLVED_NOT_EVENT_EVIDENCE")
    return dict(direction=direction, local_direction_before_guards=native["direction"],
                reasons=list(dict.fromkeys(reasons)), diagnostics=diagnostics, bindings=native)


def _validate_plan(case, plan):
    if not isinstance(plan, dict) or not isinstance(plan.get("atoms"), list):
        raise ValueError("A supplied plan with atoms is required")
    if plan.get("task", case["task"]) != case["task"] or plan.get(
            "query_sha256", digest(case["query"])) != digest(case["query"]):
        raise ValueError("Plan belongs to a different task or query")
    seen = set()
    for atom in plan["atoms"]:
        if not isinstance(atom, dict) or not {"id", "text", "source_quote", "start", "end"} <= atom.keys():
            raise ValueError("Each atom requires identity, text and an exact query anchor")
        if not isinstance(atom["id"], str) or not atom["id"] or atom["id"] in seen:
            raise ValueError("Atom identities must be nonempty and unique")
        seen.add(atom["id"])
        anchor = span(case["query"], atom["start"], atom["end"])
        if anchor["text"] != atom["source_quote"] or MASK.search(anchor["text"]):
            raise ValueError("Atom source_quote must replay at its declared query offsets")
        if not isinstance(atom["text"], str) or not atom["text"].strip() or MASK.search(atom["text"]):
            raise ValueError("Atom text must be a nonempty visible proposition")


def _declared_issues(atom, frame, parse):
    """Structured annotations may constrain a reading, never replace its scope."""
    issues = []
    def terms(text):
        return {matching.lemma(t) for t in parse(str(text)) if t.pos_ in {"NOUN", "PROPN", "ADJ", "NUM", "PRON"}}
    if atom.get("actor"):
        actors = _values(frame, {"owner"} if frame["kind"] == "PROPERTY" else {"agent"})
        wanted = terms(atom["actor"])
        if not wanted or not any(wanted <= set(p["terms"]) for p in actors):
            issues.append("DECLARED_ACTOR_NOT_SOURCE_BOUND")
    if atom.get("location"):
        wanted = terms(atom["location"])
        if not wanted or not any(wanted <= set(p["terms"]) for p in _locations(frame)):
            issues.append("DECLARED_LOCATION_NOT_SOURCE_BOUND")
    if atom.get("quantity") not in (None, ""):
        wanted = [_NUMBERS.get(m.casefold(), m.casefold().replace(",", ""))
                  for m in re.findall(r"\d[\d,.]*|[A-Za-z]+", str(atom["quantity"]))]
        available = {v for row in _quantities(frame) for v in row["values"] + row["quantifiers"]}
        if not wanted or not set(wanted) <= available:
            issues.append("DECLARED_QUANTITY_NOT_SOURCE_BOUND")
    q = frame["qualifiers"]
    if atom.get("polarity") == "uncertain" and not (q["modality"] or q["scope"] or q["unresolved"]):
        issues.append("DECLARED_UNCERTAINTY_NOT_SOURCE_BOUND")
    if atom.get("modality") in {"asserted", "factual", "none", "observed"} and (
            q["modality"] or q["scope"] or q["conditional"] or q["question"] or q["epistemic_absence"]):
        issues.append("DECLARED_FACTUALITY_DROPS_SOURCE_SCOPE")
    if atom.get("attribution") in {"none", "unattributed"} and q["attribution"]:
        issues.append("DECLARED_ATTRIBUTION_DROPS_SOURCE_SCOPE")
    return issues


def _surface_issues(surface, bound):
    """Scope may be recovered from an anchor, but never invented by a rewrite."""
    t, s = surface["qualifiers"], bound["qualifiers"]
    issues = []
    if t["scope"] and matching._scope_key(t["scope"]) != matching._scope_key(s["scope"]):
        issues.append("ATOM_ADDS_OR_CHANGES_GOVERNING_SCOPE")
    if t["modality"] and t["modality"] != s["modality"]:
        issues.append("ATOM_ADDS_OR_CHANGES_MODALITY")
    if any(t[key] and not s[key] for key in ("conditional", "question", "epistemic_absence")):
        issues.append("ATOM_ADDS_UNANCHORED_QUALIFICATION")
    if not set(t["manner"]) <= set(s["manner"]):
        issues.append("ATOM_ADDS_UNANCHORED_MANNER")
    if surface["event_dates"] and _dates(surface, bound)["status"] != "MATCH":
        issues.append("ATOM_ADDS_OR_CHANGES_EVENT_DATE")
    if _quantities(surface) and _collection(_quantities(surface), _quantities(bound))["status"] != "MATCH":
        issues.append("ATOM_ADDS_OR_CHANGES_QUANTITY")
    return issues


def _bind_atom(atom, query, parse):
    # Recover only the physical sentence(s) intersecting this explicit anchor.
    # Full-query reparsing would quietly replace the supplied atomic plan.
    units = [u for u in sentences(query) if u["start"] < atom["end"] and atom["start"] < u["end"]]
    if not units:
        return [], ["NO_ANCHORED_SENTENCE"]
    start, end = units[0]["start"], units[-1]["end"]
    context = query[start:end]
    local = dict(atom, source_quotes=[atom["source_quote"]])
    candidates = target_frames(atom["text"], parse)
    if atom.get("predicate"):
        predicates = {matching.lemma(t) for t in parse(str(atom["predicate"]))}
        candidates = [f for f in candidates if f["predicate"] in predicates or f["copula"] in predicates]
    if not candidates:
        return [], ["NO_PLANNED_PREDICATE"]
    frames, issues = [], []
    for candidate in candidates:
        requested = dict(local, predicate=candidate["predicate"])
        frame, errors = matching.prepare_atom(requested, context, parse)
        if frame is None:
            issues.extend(errors)
            continue
        # Keep the complete source-scoped representation where no licensed
        # facet projection was needed. Its proofs all share context offsets.
        if not frame.get("projection"):
            originals = [f for f in target_frames(context, parse) if f["predicate"] == frame["predicate"] and all(
                r["status"] == "EXACT_SCOPED_ARGUMENT" for r in matching.role_alignment(frame, f))]
            if len(originals) != 1:
                issues.append("SOURCE_FRAME_BINDING_NOT_UNIQUE")
                continue
            frame = deepcopy(originals[0])
            proof = frame["predicate_proof"]
            if not (atom["start"] - start < proof["end"] and proof["start"] < atom["end"] - start):
                issues.append("PREDICATE_OUTSIDE_PLANNED_ANCHOR")
                continue
        errors = _declared_issues(atom, frame, parse)
        if not frame.get("projection"):
            errors.extend(_surface_issues(candidate, frame))
        if errors:
            issues.extend(errors)
            continue
        frame["query_context"] = dict(start=start, end=end, text=context)
        frames.append(frame)
    unique = {digest(f): f for f in frames}
    return list(unique.values()), list(dict.fromkeys(issues))


def _summary(frame):
    return dict(predicate=frame["predicate"], roles=deepcopy(frame["roles"]),
                qualifiers=deepcopy(frame["qualifiers"]), event_dates=deepcopy(frame["event_dates"]),
                kind=frame["kind"], projection=deepcopy(frame.get("projection")),
                query_context=deepcopy(frame.get("query_context")))


def _query_frame_id(frame, context_start):
    """Identify a source-scoped requirement at its original query offsets."""
    def absolute(value):
        if isinstance(value, list):
            return [absolute(v) for v in value]
        if isinstance(value, dict):
            return {k: v + context_start if k in {"start", "end"} and type(v) is int
                    else absolute(v) for k, v in value.items()}
        return value
    value = {k: frame[k] for k in ("kind", "predicate", "predicate_proof", "roles", "qualifiers",
                                   "event_dates", "predicate_phrase", "unbound_arguments")}
    return "query_frame_" + digest(absolute(value))[:24]


def _query_coverage(query, plan, bindings, parse):
    """Audit representation, not evidence, without parsing omitted sentences.

    Mere anchor overlap is insufficient: a whole-sentence anchor can name just
    one predicate. Check all scoped frames in contexts already used to bind
    atoms, while wholly unplanned physical query units remain unexecuted gaps.
    This is a bounded syntax audit, not a semantic-exhaustiveness certificate.
    """
    covered, contexts = {}, {}
    for atom_id, frame in bindings:
        context = frame["query_context"]
        contexts[(context["start"], context["end"])] = context
        if not frame.get("projection"):
            key = _query_frame_id(frame, context["start"])
            covered.setdefault(key, []).append(atom_id)
    requirements = {}
    for context in contexts.values():
        for frame in target_frames(context["text"], parse):
            key = _query_frame_id(frame, context["start"])
            proof = frame["predicate_proof"]
            start, end = context["start"] + proof["start"], context["start"] + proof["end"]
            requirements[key] = dict(id=key, predicate=frame["predicate"],
                start=start, end=end, source_quote=query[start:end],
                bound_atom_ids=list(dict.fromkeys(covered.get(key, []))),
                executed=key in covered)
    units = []
    for unit in sentences(query):
        if not any(c.isalnum() for c in unit["text"]):
            continue
        anchors = [a["id"] for a in plan["atoms"] if a["start"] < unit["end"] and unit["start"] < a["end"]]
        required = [r for r in requirements.values() if unit["start"] <= r["start"] < unit["end"]]
        represented = [r for r in required if r["executed"]]
        status = ("COVERED" if required and len(represented) == len(required) else
                  "PARTIAL" if represented else "UNBOUND" if anchors else "OMITTED")
        units.append(dict(id="query_unit_" + str(len(units) + 1), **unit,
            source_quote=unit["text"], status=status, anchored_atom_ids=anchors,
            requirements=deepcopy(required), missing_requirement_ids=[r["id"] for r in required if not r["executed"]]))
    complete = bool(units) and all(u["status"] == "COVERED" for u in units)
    return dict(status="COVERED_BY_BOUND_FRAMES" if complete else "INCOMPLETE", complete=complete,
        query_sha256=digest(query), units=units, required_units=len(units),
        covered_units=sum(u["status"] == "COVERED" for u in units),
        uncovered_unit_ids=[u["id"] for u in units if u["status"] != "COVERED"],
        required_frames_in_bound_contexts=len(requirements),
        covered_frames_in_bound_contexts=sum(r["executed"] for r in requirements.values()),
        audit_scope="Physical query units and source-scoped frames in already-bound contexts",
        semantic_exhaustiveness_certified=False, omitted_requirements_executed=False,
        missing_query_coverage_is_counterevidence=False)


def _coverage_gaps(coverage):
    return [dict(kind="QUERY_PLAN_COVERAGE_GAP", atom_id=None, query_unit_id=u["id"],
                 start=u["start"], end=u["end"], source_quote=u["source_quote"], proposition=u["text"],
                 coverage_status=u["status"], missing_requirement_ids=u["missing_requirement_ids"],
                 evidence_ids=[], omitted_requirements_executed=False, absence_is_counterevidence=False)
            for u in coverage["units"] if u["status"] != "COVERED"]


def _status(directions):
    directions = set(directions)
    if {"SUPPORT", "COUNTER"} <= directions:
        return "MIXED"
    return next((s for s in ("SUPPORT", "COUNTER", "PARTIAL", "RELATED") if s in directions), "INSUFFICIENT")


def _aggregate(states):
    if "MIXED" in states or {"SUPPORT", "COUNTER"} <= set(states):
        return "MIXED"
    if "COUNTER" in states:
        return "COUNTER"
    if states and all(s == "SUPPORT" for s in states):
        return "SUPPORT"
    return "PARTIAL" if any(s in {"SUPPORT", "PARTIAL"} for s in states) else "INSUFFICIENT"


def _citation(page, frame):
    source = span(page["text"], frame["start"], frame["end"])
    if source["text"] != frame["quote"]:
        raise ValueError("Source frame quotation does not replay")
    return dict(document_id=page["document_id"], canonical_page_id=page["id"],
                date=page["date"], document_date=page["date"],
                start=source["start"], end=source["end"], text=source["text"],
                page_sha256=page["source_sha256"])


def _questions(atoms):
    questions = []
    for atom in atoms:
        if atom["status"] == "SUPPORT":
            continue
        slots = {k for e in atom["evidence"] for k, row in e["diagnostics"].items()
                 if row["status"] not in {"MATCH", "UNSPECIFIED"}}
        for slot in SLOTS if not slots else [k for k in SLOTS if k in slots]:
            questions.append(dict(atom_id=atom["id"], field=slot, question=_QUESTIONS[slot]))
    return questions


def _gaps(atoms):
    return [dict(atom_id=a["id"], proposition=a["text"], state=a["state"],
                 binding_issues=a["binding_issues"],
                 unresolved_frames=[f["id"] for f in a["frames"] if f["status"] != "SUPPORT"],
                 evidence_ids=[e["id"] for e in a["evidence"]],
                 absence_is_counterevidence=False)
            for a in atoms if a["status"] != "SUPPORT"]


def _exploratory_components(atoms):
    """Expose actual related/partial quotations, never upgrade their meaning."""
    components = {}
    for atom in atoms:
        frame_states = {f["id"]: f["status"] for f in atom["frames"]}
        for evidence in atom["evidence"]:
            if evidence["direction"] not in {"PARTIAL", "RELATED"}:
                continue
            key = (atom["id"], evidence["frame_id"], evidence["canonical_page_id"],
                   evidence["start"], evidence["end"], evidence["direction"])
            if key not in components:
                components[key] = dict(id="exploratory_" + digest(key)[:24],
                    kind="SOURCE_CITED_EXPLORATORY_COMPONENT", atom_id=atom["id"],
                    frame_id=evidence["frame_id"], frame_status=frame_states[evidence["frame_id"]],
                    planned_proposition=atom["text"], account=evidence["text"], source_quote=evidence["text"],
                    evidence_direction=evidence["direction"], epistemic_status="EXPLORATORY_NOT_CERTIFIED_SUPPORT",
                    citations=[deepcopy(evidence["citation"])], evidence_ids=[], matching_diagnostics=[],
                    supports_planned_proposition=False, relation_to_planned_event_certified=False,
                    used_for_native_verdict=False)
            component = components[key]
            component["evidence_ids"].append(evidence["id"])
            component["matching_diagnostics"].append(dict(evidence_id=evidence["id"],
                reasons=deepcopy(evidence["reasons"]), fields=deepcopy(evidence["diagnostics"])))
    return list(components.values())


def _exploratory_account(components):
    # Do not join quotations with invented chronology, causes or paraphrases.
    return [dict(component_id=c["id"], text=c["account"], citations=deepcopy(c["citations"]),
                 evidence_direction=c["evidence_direction"], epistemic_status=c["epistemic_status"],
                 supports_planned_proposition=False, used_for_native_verdict=False) for c in components]


def _hypothesis(atoms):
    alternatives = []
    for atom in atoms:
        for e in atom["evidence"]:
            if e["direction"] == "SUPPORT":
                continue
            slots = [k for k in SLOTS if e["diagnostics"][k]["status"] not in {"MATCH", "UNSPECIFIED"}]
            if not slots:
                continue
            alternatives.append(dict(atom_id=atom["id"], evidence_id=e["id"], differing_fields=slots,
                observed_differences={k: deepcopy(e["diagnostics"][k]) for k in slots},
                kind=("OPPOSING_ACCOUNT" if e["direction"] == "COUNTER" else
                      "DIFFERENT_EVENT_CANDIDATE" if any(e["diagnostics"][k]["status"] == "MISMATCH"
                          for k in ("actor", "object", "quantity", "event_date", "location")) else
                      "QUALIFIED_OR_INCOMPLETE_ACCOUNT"),
                interpretation=("The cited account has opposing polarity." if e["direction"] == "COUNTER" else
                    "The cited account may concern a different event or a differently qualified proposition."),
                conditional=e["direction"] != "COUNTER", established_as_alternative_fact=False,
                source_quote=e["text"], citation=deepcopy(e["citation"]),
                discriminating_questions=[_QUESTIONS[k] for k in slots]))
    exploratory = _exploratory_components(atoms)
    return dict(atom_states=[dict(atom_id=a["id"], state=a["state"], status=a["status"]) for a in atoms],
                exploratory_components=exploratory, exploratory_source_cited_account=_exploratory_account(exploratory),
                alternative_interpretations=alternatives, discriminating_evidence_questions=_questions(atoms),
                gaps=_gaps(atoms), invented_facts=False)


def _reconstruction(atoms):
    components = []
    for atom in atoms:
        for frame in atom["frames"]:
            if frame["status"] != "SUPPORT":
                continue
            proofs = [e for e in atom["evidence"] if e["frame_id"] == frame["id"] and e["direction"] == "SUPPORT"]
            components.append(dict(id="component_" + digest([atom["id"], frame["id"]])[:20],
                atom_id=atom["id"], frame_id=frame["id"], planned_proposition=atom["text"],
                scoped_proposition=frame["target_frame"],
                # The account is deliberately extractive. No causal or temporal
                # connective is licensed merely by two supported components.
                account=proofs[0]["text"], evidence_ids=[e["id"] for e in proofs],
                citations=[deepcopy(e["citation"]) for e in proofs]))
    gaps = _gaps(atoms)
    bridges = [dict(atom_id=g["atom_id"], kind="CONDITIONAL_EVIDENCE_REQUIREMENT", conditional=True,
                    statement="If an eligible source establishes this exact scoped proposition, it could be added as a component.",
                    required_proposition=g["proposition"], asserted_as_fact=False,
                    evidence_ids=g["evidence_ids"]) for g in gaps]
    exploratory = _exploratory_components(atoms)
    return dict(assembled_components=components, exploratory_components=exploratory,
                exploratory_source_cited_account=_exploratory_account(exploratory),
                source_cited_account=[dict(component_id=c["id"], text=c["account"], citations=c["citations"])
                                      for c in components],
                gaps=gaps, hypothetical_bridges=bridges, discriminating_evidence_questions=_questions(atoms),
                cross_component_order_or_causation_certified=False, invented_facts=False)


def execute(case, plan, retrieval, passage_budget=100):
    """Execute hypothesis/reconstruction atoms against the existing retrieval API.

    ``passage_budget`` retains the existing API's whole-page inspection unit.
    All records are JSON-compatible; inputs, raw sources and parser caches are
    read-only. Optional structured atom fields are source-checked constraints.
    ``planned_atom_verdict`` retains the scoped native decision. Incomplete
    query coverage gates top-level SUPPORT/COMPLETE to PARTIAL; it never
    creates counterevidence or silently adds new atoms to the supplied plan.
    """
    case = public_case(case)
    if case["task"] not in {"hypothesis", "reconstruction"}:
        raise ValueError("Task execution v2 handles hypothesis and reconstruction only")
    if type(passage_budget) is not int or passage_budget < 0:
        raise ValueError("passage_budget must be a nonnegative integer")
    _validate_plan(case, plan)
    parse = offset_safe_parser(parser())
    eligible = retrieval["eligible"]
    corpus = eligible.corpus
    admitted = {int(pi) for pi in retrieval["pages"]}
    ranks = retrieval.get("page_ranks", {})
    pages = sorted(admitted, key=lambda pi: (ranks.get(pi, 10**9), pi))[:passage_budget]
    sources = []
    for pi in pages:
        page = corpus.pages[pi]
        if (page["document_id"] == case["document_id"] or page["date"] >= case["date"] or
                (hasattr(eligible, "page_mask") and not eligible.page_mask[pi])):
            raise ValueError("Retrieval admitted an ineligible source page")
        for frame in matching.frames(page["text"], parse):
            if not MASK.search(frame["quote"]):
                sources.append((page, frame))
    atoms, bindings = [], []
    for atom in plan["atoms"]:
        targets, issues = _bind_atom(atom, case["query"], parse)
        bindings.extend((atom["id"], target) for target in targets)
        evidence, frames = [], []
        for index, target in enumerate(targets, 1):
            frame_id = atom["id"] + ":F" + str(index)
            records = {}
            for page, source in sources:
                match = _compare(target, source)
                if match is None:
                    continue
                citation = _citation(page, source)
                key = digest([frame_id, citation, match])
                records[key] = dict(id="proof_" + key[:24], frame_id=frame_id,
                    **citation, citation=citation, **match,
                    match_representation="SOURCE_DEPENDENCY_FRAME", matched_statement=citation["text"])
            records = sorted(records.values(), key=lambda e: (
                {"SUPPORT": 0, "COUNTER": 1, "PARTIAL": 2, "RELATED": 3}[e["direction"]],
                e["canonical_page_id"], e["start"], e["id"]))
            frames.append(dict(id=frame_id, status=_status(e["direction"] for e in records),
                               target_frame=_summary(target), evidence_ids=[e["id"] for e in records]))
            evidence.extend(records)
        states = [f["status"] for f in frames] + (["INSUFFICIENT"] if issues else [])
        status = _aggregate(states)
        atoms.append(dict(id=atom["id"], text=atom["text"], source_quote=atom["source_quote"],
            start=atom["start"], end=atom["end"], planned_atom=deepcopy(atom),
            status=status, state={"SUPPORT": "supported", "COUNTER": "counter", "MIXED": "mixed",
                                  "PARTIAL": "partial", "INSUFFICIENT": "missing"}[status],
            binding_issues=issues, frames=frames, evidence=evidence, evidence_count=len(evidence)))
    result = decide(case["task"], atoms)
    planned_decision = deepcopy(result)
    planned_decision["verdict_scope"] = "SUPPLIED_PLANNED_ATOM_BINDINGS_ONLY"
    coverage = _query_coverage(case["query"], plan, bindings, parse)
    if not coverage["complete"] and result["status"] in {"SUPPORT", "COMPLETE"}:
        result["status"] = "PARTIAL"
    result.update(version=VERSION, case_id=case["case_id"], native_verdict=result["status"], atoms=atoms,
        planned_atom_verdict=planned_decision["status"], planned_atom_decision=planned_decision,
        verdict_scope="PLANNED_ATOMS_WITH_QUERY_COVERAGE_GUARD", query_coverage=coverage,
        whole_query_support_certified=False,
        query_sha256=digest(case["query"]), plan_sha256=digest(plan), api_calls=0,
        llm_assessment=dict(status="NOT_RUN", used_for_native_verdict=False, api_calls=0),
        source_pages_inspected=len(pages), source_pages_admitted=len(admitted), passage_budget=passage_budget,
        budget_unit="whole_source_page", retrieval=deepcopy(retrieval["receipt"]),
        derived_statement_control=False, source_only_evidence=True,
        diagnostics_fields=list(SLOTS))
    payload = _hypothesis(atoms) if case["task"] == "hypothesis" else _reconstruction(atoms)
    coverage_gaps = _coverage_gaps(coverage)
    payload["query_coverage_gaps"] = coverage_gaps
    payload["gaps"].extend(deepcopy(coverage_gaps))
    payload["discriminating_evidence_questions"].extend(dict(
        atom_id=None, query_unit_id=g["query_unit_id"], field="query_coverage",
        question="Which source-bound planned atoms should test this omitted or incompletely represented query content?")
        for g in coverage_gaps)
    if case["task"] == "reconstruction":
        payload["hypothetical_bridges"].extend(dict(
            atom_id=None, query_unit_id=g["query_unit_id"], kind="CONDITIONAL_PLAN_AND_EVIDENCE_REQUIREMENT",
            conditional=True, asserted_as_fact=False, required_proposition=g["proposition"], evidence_ids=[],
            statement="If a revised source-bound plan tests the omitted requirements and eligible evidence supports them, they could be considered for reconstruction.")
            for g in coverage_gaps)
    result[case["task"]] = payload
    return result
