"""Shared source-owned candidate pool, with one top-five list per reading."""
from collections import defaultdict
from copy import deepcopy
from functools import lru_cache
import math
import re

import numpy as np

from . import candidates as legacy
from .contracts import MASK
from .corpus import BM25,ordered,words
from .io import digest
from .retrieval import rrf
from .retrieval_v2 import candidate_route
from .task_execution_v2 import offset_safe_parser
from .tasks import parser
from .vendor.matching import clone
from .roles import compare as common_role_match
from .planning_v2 import focal_context


@lru_cache(maxsize=1)
def source_parser():return offset_safe_parser(parser())


def legacy_constructor():
    # Isolated function globals avoid monkey-patching a shared/legacy engine.
    _,functions=clone(legacy,dict(parser=source_parser,candidate_route=lambda *args:None))
    return functions["construct"]


def owner_view(proposal,corpus,parse):
    page=corpus.pages[corpus.page_index[proposal["sources"][0]["canonical_page_id"]]]
    doc=parse(page["text"]);a,b=proposal["source_span"]
    tokens=[t for t in doc if a<=t.idx<b]
    if not tokens:return dict(text=proposal["source_wording"],roles=[],actions=[],name_words=[])
    root=doc.char_span(a,b,alignment_mode="expand").root
    roles=[proposal["source_wording"]]
    for child in root.children:
        if child.dep_=="appos":
            subtree=list(child.subtree);roles.append(doc[min(t.i for t in subtree):max(t.i for t in subtree)+1].text)
    actions=[]
    if root.dep_ in {"nsubj","nsubjpass"}:
        governor=root.head
        if not any(t.dep_=="neg" for t in [governor,*governor.children]):
            actions=[t.text for t in governor.children if t.dep_ in {"dobj","pobj","prep","xcomp"}]
    names=[t.text.casefold() for t in tokens if t.pos_=="PROPN"]
    return dict(text=" ".join(roles+actions),roles=roles,actions=actions,name_words=names,
        role_is_not_event_support=True)


def named_anchors(case,plan,parse):
    q=focal_context(case);values=[]
    # Exact visible NER spans retain abbreviated mentions such as a surname
    # that the extraction grouped with a title. No alias or name is invented.
    values=[e.text for e in parse(MASK.sub(" ",q)).ents if e.label_ in {"PERSON","GPE","NORP","ORG","LOC"}]
    for entity in plan["extractions"]["entities"]:
        if entity["label"] in q and entity["type"] in {"Person","Country","Location","Organization","Government","Military","PoliticalGroup"}:
            value=entity["label"]
            if not MASK.search(value):values.append(value)
    values=list(dict.fromkeys(values))
    # Nested title/name variants are one anchor, not multiple votes.
    return [v for v in values if not any(v!=other and re.search(r"(?<!\w)"+re.escape(other)+r"(?!\w)",v,re.I)
        for other in values)]


def construct(case,plan,reading,*,passage_budget=100):
    parse=source_parser();corpus=reading["eligible"].corpus;e=reading["eligible"]
    shadow=dict(reading,kernel=None)
    original=legacy_constructor()(case,plan,shadow,passage_budget=passage_budget)
    audit=original.pop("_candidate_audit");anchors=named_anchors(case,plan,parse)
    n,df,_=e.page_stats;vocab=corpus.page_bm25.vocabulary
    idfs={anchor:sum(math.log1p((n-df[vocab[w]]+.5)/(df[vocab[w]]+.5)) for w in set(words(anchor)) if w in vocab)
        for anchor in anchors}
    at=case["query"].index(case["focal_marker"]);visible=MASK.sub(" ",case["query"])
    focal=focal_context(case)
    views={};all_outputs=[]
    for index,stored in enumerate(audit["readings"]):
        r=stored["reading"];proposals=stored["proposals"]
        # A competing nominal interpretation is not executable merely because
        # the planner suggested it. A human possessor before an un-determined
        # singular noun requires possessive morphology at insertion time.
        right=case["query"][at+len(case["focal_marker"]):].lstrip()
        following=list(parse(right))
        possessive_required=bool(r.get("target_kind")=="person" and following and
            following[0].pos_=="NOUN" and following[0].tag_=="NN")
        leads=[l for l in plan["leads"] if r["id"] in l["reading_ids"]]
        role_query=" ".join(t for l in leads for t in l["function_terms"])
        role_words={t.lemma_.casefold() for t in parse(role_query) if t.pos_ in {"NOUN","ADJ"} and not t.ent_type_}
        role_docs=[];accepted=[]
        for item in proposals:
            if possessive_required and r["form"]=="nominal" and not re.search(r"(?:['\u2019]s|s['\u2019])$",item["fill"]):
                continue
            key=(item["sources"][0]["canonical_page_id"],tuple(item["source_span"]))
            item=deepcopy(item)
            if not item["node_id"]:
                pi=corpus.page_index[key[0]];phrase=parse(corpus.pages[pi]["text"]).char_span(*key[1],alignment_mode="expand")
                bindings=set()
                for j in corpus.occurrences_by_page.get(pi,[]):
                    occurrence=corpus.occurrences[j]
                    if occurrence["source_type"]!="entities":continue
                    match=re.search(r"(?<!\w)"+re.escape(occurrence["label"])+r"(?!\w)",item["source_wording"],re.I)
                    if phrase and match and match.start()<=phrase.root.idx-key[1][0]<match.end():bindings.add(occurrence["node_id"])
                if len(bindings)==1:item["node_id"]=next(iter(bindings))
            if key not in views:views[key]=owner_view(item,corpus,parse)
            view=views[key]
            if item["source_wording"].strip().casefold() in {"he","she","it","they","them","him","her","we","you","i","which","that"}:continue
            if r.get("target_kind")=="person" and r["form"] in {"nominal","possessive","member_example"} and (not item["node_id"] or corpus.nodes[item["node_id"]].get("entity_type")!="Person"):continue
            source_page=corpus.pages[corpus.page_index[item["sources"][0]["canonical_page_id"]]]
            around=legacy.paragraph_context(source_page["text"],item["source_span"][0])
            matches=[a for a in anchors if re.search(r"(?<!\w)"+re.escape(a)+r"(?!\w)",around,re.I)]
            source_name_reused=False
            if item["node_id"]:
                labels={corpus.occurrences[j]["label"] for j in corpus.occurrences_by_node.get(item["node_id"],[])
                    if e.page_mask[corpus.occurrences[j]["page_index"]]}
                source_name_reused=any(label and re.search(r"(?<!\w)"+re.escape(label)+r"(?!\w)",focal,re.I) for label in labels)
            item["owner"]=view;item["matched_anchors"]=matches
            item["anchor_idf"]=sum(idfs[a] for a in matches);item["visible_actor_reuse"]=source_name_reused
            owned_words={t.lemma_.casefold() for t in parse(view["text"]) if t.pos_ in {"NOUN","ADJ"} and not t.ent_type_}
            item["source_function_match"]=common_role_match(role_words,owned_words) if role_words and item["node_id"] else dict(matched=False)
            item["ranking"]["calibrated_probability"]=False
            accepted.append(item);role_docs.append(view["text"])
        role_index=BM25(role_docs);scores=role_index.score(role_query,np.ones(len(role_docs),dtype=bool)) if role_query else np.zeros(len(role_docs))
        role_ranks={i:j for j,i in enumerate(ordered(scores,[p["id"] for p in accepted]),1)}
        for i,item in enumerate(accepted):
            role_rank=role_ranks.get(i);rank=item["ranking"]
            # One source-specific role view per occurrence; extra leads do not
            # count as repeated votes or assert the holder performed the act.
            relevance=rank["rrf"]+(1/(60+role_rank) if role_rank else 0)
            item["ranking"].update(source_role_bm25=float(scores[i]),source_role_rank=role_rank,
                source_function_match=item["source_function_match"],
                anchor_idf=item["anchor_idf"],visible_actor_reuse=item["visible_actor_reuse"],fused_rrf=relevance,
                ranking_policy="reuse, local carrier clue, visible-anchor IDF, source-owned functional match, role/passage/node RRF, source-fullness")
            item["_order"]=(item["visible_actor_reuse"],not rank["local_property_match"],-item["anchor_idf"],not item["source_function_match"]["matched"],-relevance,
                -len(item["source_wording"].split()),item["id"])
        accepted.sort(key=lambda p:p["_order"])
        final=[];seen=set();identities=set()
        for item in accepted:
            identity=item["node_id"];normal=" ".join(words(item["fill"]))
            if normal in seen or identity and identity in identities:continue
            seen.add(normal)
            if identity:identities.add(identity)
            value={k:v for k,v in item.items() if k!="_order"};value["rank"]=len(final)+1
            value["discovery_route"]=candidate_route(reading,identity) if identity else None
            value["support_label"]="Source-property clue" if value["support"]=="LOCAL_PROPERTY_ATTESTED" else "Exploratory source-grounded suggestion"
            final.append(value)
            if len(final)==5:break
        clean=[{k:v for k,v in item.items() if k!="_order"} for item in accepted]
        stored["proposals"]=clean
        all_outputs.append(dict(reading=r,candidates=final,evidence_candidates=[i for i in final if i["support"]=="LOCAL_PROPERTY_ATTESTED"],
            exploratory_candidates=final,generated_proposals=len(accepted),rejection_counts=original["readings"][index]["rejection_counts"]))
    original.update(version="source-owned-unified-candidates/2",readings=all_outputs,_candidate_audit=audit,
        native_verdict="Ranked source-grounded suggestions",
        selection="One shared top-five list per reading; evidence/context are labels, not separate retrieval routes",
        casing_policy="All-uppercase analysis annotations copied only with identical token offsets; raw text unchanged",
        score_meaning="Lexicographic priorities and RRF relevance, not calibrated correctness")
    return original
