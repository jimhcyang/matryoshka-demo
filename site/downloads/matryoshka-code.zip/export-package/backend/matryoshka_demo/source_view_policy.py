"""Trusted execution-only source views. Never inferred from query/page flags."""
from collections.abc import Mapping
from datetime import date
from enum import Enum
import re

VERSION = "trusted-corpus-source-view/1"


class SourceViewPolicy(Enum):
    STRICT_PRIOR = "strict_prior"
    SOURCE_DAY_INCLUSIVE = "source_day_inclusive"
    LIVE_BEFORE_WITH_EARLIER_ORIGIN = "live_before_with_earlier_origin"
    LIVE_THROUGH_WITH_EARLIER_ORIGIN = "live_through_with_earlier_origin"
    SUPPLIED_DOCUMENTS_INCLUSIVE = "supplied_documents_inclusive"


STRICT_PRIOR = SourceViewPolicy.STRICT_PRIOR
SOURCE_DAY_INCLUSIVE = SourceViewPolicy.SOURCE_DAY_INCLUSIVE
LIVE_BEFORE_WITH_EARLIER_ORIGIN = SourceViewPolicy.LIVE_BEFORE_WITH_EARLIER_ORIGIN
LIVE_THROUGH_WITH_EARLIER_ORIGIN = SourceViewPolicy.LIVE_THROUGH_WITH_EARLIER_ORIGIN
SUPPLIED_DOCUMENTS_INCLUSIVE = SourceViewPolicy.SUPPLIED_DOCUMENTS_INCLUSIVE
LIVE_POLICIES = frozenset({LIVE_BEFORE_WITH_EARLIER_ORIGIN, LIVE_THROUGH_WITH_EARLIER_ORIGIN})
HANDLING_VETO = re.compile(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM(?:INATION)?\b", re.I)


def require_policy(policy):
    if type(policy) is not SourceViewPolicy:
        raise TypeError("A trusted SourceViewPolicy enum is required, not query metadata")
    return policy


def policy_of(owner):
    value = getattr(owner, "source_view_policy", STRICT_PRIOR)
    return require_policy(value)


def descriptor(policy=STRICT_PRIOR):
    policy = require_policy(policy)
    if policy is SUPPLIED_DOCUMENTS_INCLUSIVE:
        value = descriptor(SOURCE_DAY_INCLUSIVE)
        value.update(id=policy.value,
            cib_source_document="EARLIER_OR_BOTH_OR_REGISTERED_PUBLIC_SUPPLIED_EDITION",
            later_or_secret_version_admitted=True,
            supplied_document_registration_required=True,
            supplied_document_scope="HASH_BOUND_REGISTERED_PUBLIC_CIB_EDITIONS_ONLY",
            ordinary_source_views_unchanged=True)
        return value
    inclusive = policy in {SOURCE_DAY_INCLUSIVE, LIVE_THROUGH_WITH_EARLIER_ORIGIN}
    return dict(version=VERSION, id=policy.value, date_relation="<=" if inclusive else "<",
        cutoff_role=("exclusive_live_as_of" if policy is LIVE_BEFORE_WITH_EARLIER_ORIGIN else
            "inclusive_live_as_of" if policy is LIVE_THROUGH_WITH_EARLIER_ORIGIN else "source_document_date"),
        cib_source_document="EXCLUDED" if policy is STRICT_PRIOR else "EARLIER_OR_BOTH_ONLY",
        cable_origin="WHOLE_DOCUMENT_EXCLUDED", cable_classification="CONFIDENTIAL",
        cable_document_wide_handling_veto=True, later_or_secret_version_admitted=False,
        source_dates_or_document_ids_rewritten=False)


def from_descriptor(value):
    if value is None:
        return STRICT_PRIOR
    if not isinstance(value, Mapping):
        raise ValueError("Malformed source-view policy binding")
    try:
        policy = SourceViewPolicy(value.get("id"))
    except (ValueError, TypeError) as error:
        raise ValueError("Unknown source-view policy binding") from error
    if dict(value) != descriptor(policy):
        raise ValueError("Source-view policy descriptor changed")
    return policy


def time_origin_allowed(page, case, policy=STRICT_PRIOR):
    policy = require_policy(policy)
    earlier = date.fromisoformat(page["date"])
    cutoff = date.fromisoformat(case["date"])
    if earlier > cutoff or descriptor(policy)["date_relation"] == "<" and earlier == cutoff:
        return False
    return page["document_id"] != case["document_id"] or (
        policy is not STRICT_PRIOR and case["corpus"] == "cib")


def source_page_allowed(page, case, policy=STRICT_PRIOR, *, allow_legacy_visibility=False):
    """Necessary local admission; complete-index sibling veto stays independent."""
    require_policy(policy)
    supplied = (page.get("visibility") == "supplied_registered" or "supplied_source" in page
        or str(page.get("id", "")).startswith("supplied_page_")
        or hasattr(page,"_registered_supplied_source"))
    if supplied:
        if policy is not SUPPLIED_DOCUMENTS_INCLUSIVE:
            return False
        from matryoshka_current.supplemental_sources import registered_page
        return (page.get("permitted") is True and page.get("corpus") == case.get("corpus") == "cib"
            and time_origin_allowed(page,case,policy) and registered_page(page))
    if (page.get("permitted") is not True or page.get("corpus") != case["corpus"]
            or (page.get("visibility") not in {"earlier", "both"} and not (
                policy is STRICT_PRIOR and allow_legacy_visibility and page.get("visibility") is None))
            or not time_origin_allowed(page, case, policy)):
        return False
    if case["corpus"] == "cib":
        classification = str(page.get("classification", "")).upper().replace(" ", "")
        native_view = page.get("native_page", {}).get("view")
        return (classification not in {"SECRET", "TOPSECRET"}
            and native_view not in {"later", "later_only", "secret"}
            and page.get("view") not in {"later", "later_only", "secret"})
    return (page.get("classification") == "CONFIDENTIAL"
        and not HANDLING_VETO.search(page.get("text", ""))
        and not any(HANDLING_VETO.search(str(h)) for h in page.get("handling", [])))


def validate_origin_date(corpus, case):
    if corpus.corpus != case["corpus"]:
        raise ValueError("Source view belongs to another corpus")
    index = getattr(corpus, "current_index", None)
    policy = policy_of(corpus)
    if index is not None:
        index._case(case, source_view_policy=policy)
    original = getattr(corpus, "documents", {}).get(case["document_id"], {})
    known = original.get("document_date_iso") or original.get("date_iso") or original.get("date")
    if known is not None and known != case["date"] and policy not in LIVE_POLICIES:
        raise ValueError("Case cutoff differs from its pinned source document date")


class CorpusView:
    """Read-only reference view; no corpus arrays, source text or IDs are copied."""
    def __init__(self, corpus, policy):
        self._corpus = corpus._corpus if isinstance(corpus, CorpusView) else corpus
        self._source_view_policy = require_policy(policy)

    @property
    def source_view_policy(self):
        return self._source_view_policy

    def __getattr__(self, name):
        return getattr(self._corpus, name)

    def eligible(self, case):
        from .corpus import Eligible
        validate_origin_date(self, case)
        return Eligible(self, case)


def corpus_view(corpus, policy=STRICT_PRIOR):
    require_policy(policy)
    return corpus if policy_of(corpus) is policy else CorpusView(corpus, policy)


class SourcePages(dict):
    """Trusted policy carrier for independently checked constructor page pools."""
    def __init__(self, pages, policy=STRICT_PRIOR, *, veto_documents=()):
        super().__init__(pages)
        self._source_view_policy = require_policy(policy)
        self.veto_documents = frozenset(veto_documents)

    @property
    def source_view_policy(self):
        return self._source_view_policy


def packet_policy(packet):
    """Read only a native-result-bound declaration, never public case fields."""
    result = packet.get("result", {})
    bound = from_descriptor(result.get("source_view_policy"))
    configured = from_descriptor(packet.get("configuration", {}).get("source_view_policy"))
    if bound is not configured:
        raise ValueError("Native result and configuration source policies differ")
    return bound


class SourceIndexView:
    """Policy-bound delegate to the real read-only SQLite source connection."""
    def __init__(self, index, policy):
        self._index = index._index if isinstance(index, SourceIndexView) else index
        self.source_view_policy = require_policy(policy)

    def execute(self, *args, **kwargs):
        return self._index.execute(*args, **kwargs)


def source_index_view(index, policy):
    require_policy(policy)
    if isinstance(index, Mapping):
        return SourcePages(index, policy, veto_documents=getattr(index, "veto_documents", ()))
    if hasattr(index, "execute"):
        return SourceIndexView(index, policy)
    raise TypeError("An actual complete source mapping or read-only SQL connection is required")


def apply_source_view(context, policy_descriptor):
    """Apply verified native configuration; never accept this from query input.

    The caller verifies the native outer/result binding with packet_policy.
    All corpus arrays and the actual source index are referenced, not rebuilt.
    """
    from types import SimpleNamespace
    policy = (require_policy(policy_descriptor) if type(policy_descriptor) is SourceViewPolicy
              else from_descriptor(policy_descriptor))
    values = dict(context) if isinstance(context, Mapping) else dict(vars(context))
    values["corpus"] = corpus_view(values["corpus"], policy)
    values["source_index"] = source_index_view(values["source_index"], policy)
    values["source_view_policy"] = policy
    return SimpleNamespace(**values)
