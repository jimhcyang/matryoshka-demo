"""Independent corpus exploration, never implicitly scoped to a selected case."""
from datetime import date, timedelta
import json
from pathlib import Path
import sqlite3

from .exploration_v2 import verified_hash, neighborhood, source_page


def _connection(root, reference):
    root = Path(root).resolve()
    path = (root / reference["path"]).resolve()
    if not path.is_relative_to(root / "data/graph_indexes_v2"):
        raise ValueError("Unbound corpus index")
    stat = path.stat()
    if verified_hash(str(path), stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino) != reference["sha256"]:
        raise ValueError("Corpus index changed")
    db = sqlite3.connect("file:" + str(path) + "?mode=ro", uri=True)
    db.row_factory = sqlite3.Row
    return db


def explorer_case(corpus, as_of=None):
    # Explorer date is inclusive, unlike the strictly-earlier query cutoff.
    cutoff = ((date.fromisoformat(as_of) + timedelta(days=1)).isoformat()
        if as_of else "9999-12-31")
    return dict(case_id="corpus_explorer", corpus=corpus, task="reconstruction",
        query="Explore source-grounded corpus connections.", document_id="__corpus_explorer_no_origin__", date=cutoff, focal_marker="")


def overview(root, reference, *, search="", as_of=None, limit=120, group_id=None):
    if not isinstance(search, str) or len(search) > 200 or type(limit) is not int or not 1 <= limit <= 1024:
        raise ValueError("Invalid explorer request")
    case = explorer_case(reference["binding"]["corpus"], as_of)
    cutoff = case["date"]
    db = _connection(root, reference)
    try:
        dates = db.execute("SELECT min(date),max(date),COUNT(*),COUNT(DISTINCT doc) FROM page").fetchone()
        pages = db.execute("SELECT COUNT(*),COUNT(DISTINCT doc) FROM page WHERE date<?", (cutoff,)).fetchone()
        count = db.execute("SELECT COUNT(DISTINCT m.node) FROM mention m JOIN page p ON p.id=m.page WHERE p.date<?", (cutoff,)).fetchone()[0]
        params = [cutoff]
        clause = ""
        if search:
            clause += " AND m.label LIKE ? ESCAPE '\\'"
            escaped = search.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            params.append("%" + escaped + "%")
        if group_id:
            if not isinstance(group_id, str) or len(group_id) > 200:
                raise ValueError("Invalid hierarchy group")
            clause += " AND (json_extract(n.hierarchy,'$.community_id')=? OR json_extract(n.hierarchy,'$.theme_id')=? OR json_extract(n.hierarchy,'$.domain_id')=?)"
            params.extend([group_id] * 3)
        rows = db.execute("SELECT n.id,n.kind,n.hierarchy,min(m.label) label,COUNT(DISTINCT m.page) frequency "
            "FROM node n JOIN mention m ON n.id=m.node JOIN page p ON p.id=m.page WHERE p.date<?" + clause +
            " GROUP BY n.id ORDER BY frequency DESC,n.id LIMIT ?", params + [limit]).fetchall()
        nodes = [dict(id=r["id"], label=r["label"], type=r["kind"], frequency=r["frequency"], hierarchy=json.loads(r["hierarchy"])) for r in rows]
        ids = [r["id"] for r in rows]
        edges = []
        if ids:
            placeholders = ",".join("?" for _ in ids)
            records = db.execute("SELECT e.a,e.b,COUNT(*) weight FROM edge e JOIN page p ON p.id=e.page WHERE p.date<? "
                f"AND e.a IN ({placeholders}) AND e.b IN ({placeholders}) GROUP BY e.a,e.b ORDER BY weight DESC,e.a,e.b LIMIT 4096",
                [cutoff] + ids + ids).fetchall()
            edges = [dict(source=r["a"], target=r["b"], weight=r["weight"], kind="SOURCE") for r in records]
        groups = {}
        for node in nodes:
            for kind in ("community", "theme", "domain"):
                identity = node["hierarchy"].get(kind + "_id")
                if identity:
                    key = kind, identity
                    item = groups.setdefault(key, dict(id=identity, type=kind, label=kind.capitalize() + ": " + node["label"][:65], displayed_members=0))
                    item["displayed_members"] += 1
        return dict(corpus=case["corpus"], nodes=nodes, edges=edges, groups=list(groups.values()),
            as_of=as_of, minimum_date=dates[0], maximum_date=dates[1], total_pages=dates[2], total_documents=dates[3],
            visible_pages=pages[0], visible_documents=pages[1], visible_nodes=count, displayed_nodes=len(nodes),
            hierarchy_retrospective=True, independent_of_workbench=True,
            scope="Permitted source projection of the bound corpus; no workbench-origin exclusion",
            binding=reference["binding"], edge_meaning="Source-backed connection; not proof of a new claim")
    finally:
        db.close()


def node(root, reference, node_id, *, as_of=None):
    return neighborhood(root, reference, explorer_case(reference["binding"]["corpus"], as_of), node_id, 30)


def page(root, reference, page_id, *, as_of=None):
    return source_page(root, reference, explorer_case(reference["binding"]["corpus"], as_of), page_id)
