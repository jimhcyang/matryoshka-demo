"""One integrated BM25/source-graph discovery pipeline for all planner arms."""
from collections import defaultdict
from types import SimpleNamespace

import numpy as np

from .contracts import public_case
from .corpus import ordered,words,ENGLISH_STOP_WORDS
from .graph_kernel import normalize_prior,transition,maximum_product_witness
from .hierarchy import HierarchyBundle,build_hierarchy,diffuse
from .planning_v2 import searches
from .retrieval import rrf


def node_matches(eligible,query,display=5):
    """Score every eligible surface; save only a small explanatory seed view."""
    c=eligible.corpus;content=" ".join(w for w in words(query) if w not in ENGLISH_STOP_WORDS)
    values=c.node_bm25.score(content,eligible.surface_mask,eligible.node_stats)
    scores=np.zeros(len(c.nodes));np.maximum.at(scores,c.surface_nodes,values);scores[~eligible.active]=0
    rows=[]
    for ni in ordered(scores,c.node_ids)[:display]:
        candidates=[j for j in c.occurrences_by_node.get(c.node_ids[ni],[]) if eligible.surface_mask[j]]
        if not candidates:continue
        j=min(candidates,key=lambda j:(-values[j],c.page_ids[c.occurrences[j]["page_index"]],c.occurrences[j]["source_row_id"]))
        o=c.occurrences[j]
        rows.append(dict(node_id=c.node_ids[ni],node_type=c.nodes[c.node_ids[ni]]["kind"],label=o["label"],
            bm25=float(scores[ni]),source_surface=c.surfaces[j],source_proof=eligible.citation(o["unit_index"]),
            meaning="Matched eligible extraction label/surface; quotation is evidence, label is not new testimony"))
    return scores,rows


def retrieve(corpus,case,plan,*,document_budget=100,passage_budget=100,hierarchy=True,graph=True):
    if any(type(v) is not int or v<1 for v in (document_budget,passage_budget)):
        raise ValueError("Positive integer document and source-page budgets are required")
    case=public_case(case);eligible=corpus.eligible(case);query_rows=searches(plan,case)
    families=defaultdict(list);priors=defaultdict(list);executed=[]
    for row in query_rows:
        values=corpus.page_bm25.score(row["query"],eligible.page_mask,eligible.page_stats)
        order=ordered(values,corpus.page_ids);families[row["kind"]].append(order)
        node_scores,seed_view=node_matches(eligible,row["query"]) if graph else (np.zeros(len(corpus.nodes)),[])
        prior=normalize_prior(node_scores,eligible.active)
        if prior.any():priors[row["kind"]].append(prior)
        executed.append(dict(row,pages_scored=int(eligible.page_mask.sum()),positive_pages=len(order),
            top_pages=[corpus.page_ids[i] for i in order[:5]],top_nodes=seed_view,
            positive_seed_nodes=int(np.count_nonzero(node_scores)),displayed_seeds_are_not_a_retrieval_cap=True))
    lexical,_=rrf([rrf(ranks)[0] for ranks in families.values()])
    groups=[normalize_prior(np.mean(values,axis=0),eligible.active) for values in priors.values()]
    prior=normalize_prior(np.mean(groups,axis=0),eligible.active) if groups else np.zeros(len(corpus.nodes))
    if not graph:bundle=None
    elif hierarchy:bundle=build_hierarchy(eligible,prior)
    else:
        kernel=transition(eligible.adjacency,prior,attention=0.,active=eligible.active)
        edges={(u,int(v)):dict(kind="SOURCE" if u!=v else "NUMERICAL_SELF_LOOP",weight=float(w),transition=float(w))
            for u in range(len(corpus.nodes)) for v,w in zip(kernel.indices[kernel.indptr[u]:kernel.indptr[u+1]],kernel.data[kernel.indptr[u]:kernel.indptr[u+1]])}
        bundle=HierarchyBundle(kernel,prior,len(prior),list(corpus.node_ids),["semantic"]*len(prior),edges,
            dict(version="eligible-flat/1",retrospective_hierarchy=False,hierarchy_membership_is_evidence=False,
                interpretation="Navigation relevance, not correctness probability"))
    walk=diffuse(bundle) if bundle else SimpleNamespace(node_mass=np.zeros(len(corpus.nodes)),
        trace=dict(status="NOT_USED_DOCUMENT_CONTROL",snapshots=[],metadata=dict(interpretation="No graph propagation in this matched ablation")))
    degree=np.zeros(len(corpus.nodes))
    for ui,ni in corpus.membership:
        if eligible.unit_mask[ui]:degree[ni]+=1
    mass=np.zeros(len(corpus.pages))
    for ui,ni in corpus.membership:
        if eligible.unit_mask[ui] and degree[ni]:mass[corpus.units[ui]["pi"]]+=walk.node_mass[ni]/degree[ni]
    graph_order=ordered(mass,corpus.page_ids)
    combined,scores=rrf([lexical,graph_order]);doc_order=list(dict.fromkeys(corpus.pages[i]["document_id"] for i in combined))
    admitted=set(doc_order[:document_budget]);pages=[i for i in combined if corpus.pages[i]["document_id"] in admitted]
    known=set(pages);pages.extend(i for i,p in enumerate(corpus.pages) if eligible.page_mask[i]
        and p["document_id"] in admitted and i not in known)
    page_ranks={p:i for i,p in enumerate(combined,1)};node_ranks={n:i for i,n in enumerate(ordered(walk.node_mass,corpus.node_ids),1)}
    for snapshot in walk.trace["snapshots"]:
        for state in snapshot["states"]:
            ni=state["index"]
            if ni<len(corpus.nodes):
                occurrence=next((corpus.occurrences[j] for j in corpus.occurrences_by_node.get(corpus.node_ids[ni],[])
                    if eligible.page_mask[corpus.occurrences[j]["page_index"]]),None)
                state["label"]=occurrence["label"] if occurrence else corpus.node_ids[ni]
                state["node_type"]=corpus.nodes[corpus.node_ids[ni]].get("kind","semantic")
            else:state["label"]=state["id"].split(":")[-1]
    receipt=dict(method=("integrated_hierarchy_graph" if hierarchy else "integrated_flat_graph") if graph else "matched_lexical_control",text_matcher="BM25",
        search_queries=executed,eligible_pages=int(eligible.page_mask.sum()),eligible_nodes=int(eligible.active.sum()),
        eligible_documents=len(set(corpus.page_docs[eligible.page_mask])),document_budget=document_budget,
        documents_admitted=len(admitted),pages_admitted=len(pages),document_order=doc_order[:document_budget],
        construction_passage_budget=passage_budget,pages_admitted_are_not_all_inspected=True,
        top_sources=[dict(page_id=corpus.pages[pi]["id"],document_id=corpus.pages[pi]["document_id"],date=corpus.pages[pi]["date"],
            page_rank=page_ranks.get(pi),rrf=scores.get(pi,0)) for pi in pages[:passage_budget]],
        graph_witness=None,hierarchy_active=hierarchy and graph,diffusion=walk.trace,query_only=True,
        generated_leads=bool(plan["leads"]),cutoff=case["date"],whole_origin_excluded=case["document_id"],
        query_fusion="RRF within query family then RRF across families; mean normalized priors per family",
        score_interpretation="Discovery relevance, never factual confidence",api_calls=0)
    return dict(eligible=eligible,pages=pages,page_ranks=page_ranks,node_ranks=node_ranks,kernel=bundle.kernel if bundle else None,
        prior=bundle.prior if bundle else prior,page_scores=scores,node_mass=walk.node_mass,receipt=receipt,hierarchy_bundle=bundle)


def candidate_route(reading,node_id):
    e=reading["eligible"];c=e.corpus;ni=c.node_index.get(node_id)
    if ni is None or not e.active[ni]:return None
    bundle=reading["hierarchy_bundle"]
    if bundle is None:return None
    path=maximum_product_witness(bundle.kernel,bundle.prior,[ni]);hops=[]
    for hop in path["hops"]:
        a,b=hop["source"],hop["target"];edge=bundle.structural_edges[a,b]
        citations=[]
        if edge["kind"]=="SOURCE":
            citations=[e.citation(r["ui"]) for r in c.edge_rows if e.page_mask[r["pi"]] and {a,b}=={r["a"],r["b"]}][:3]
            if a!=b and not citations:raise ValueError("Semantic discovery edge has no eligible source")
        hops.append(dict(source=bundle.state_ids[a],target=bundle.state_ids[b],kind=edge["kind"],
            transition=hop["transition"],citations=citations,historical_relation_certified=False))
    return dict(status="DIRECT_QUERY_NODE_MATCH" if not hops else "SOURCE_AND_NAVIGATION_WITNESS",
        nodes=[bundle.state_ids[i] for i in path["nodes"]],hops=hops,
        meaning="One maximum-product navigation witness, not the algorithm's only path or proof of the hidden action")
