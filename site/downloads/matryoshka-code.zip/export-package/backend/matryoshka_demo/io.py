from __future__ import annotations

from contextlib import contextmanager
import hashlib
import gzip
import json
import os
from pathlib import Path
import shutil
import socket


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def rows(path):
    with Path(path).open() as stream:
        for line in stream:
            if line.strip():
                yield json.loads(line)


def save(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=True, indent=2, allow_nan=False) + "\n")
    os.replace(temp, path)


def save_gzip(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    packet = dict(payload=value, sha256=digest(value))
    data = json.dumps(packet, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()
    temp = path.with_name(path.name + ".tmp")
    temp.write_bytes(gzip.compress(data, mtime=0)); os.replace(temp, path)


def load_gzip(path):
    value = json.loads(gzip.decompress(Path(path).read_bytes()))
    if digest(value["payload"]) != value["sha256"]: raise ValueError("Compressed audit was modified")
    return value["payload"]


def disk_guard(path, minimum_gib=3):
    if shutil.disk_usage(path).free < minimum_gib * 1024**3:
        raise RuntimeError("Disk guard: free space below safe headroom; completed checkpoints are preserved")


@contextmanager
def offline():
    saved = [(owner, key, getattr(owner, key)) for owner, key in (
        (socket, "getaddrinfo"), (socket, "create_connection"),
        (socket.socket, "connect"), (socket.socket, "connect_ex"))]
    def forbidden(*args, **kwargs):
        raise RuntimeError("Local execution cannot access a network or API")
    try:
        for owner, key, _ in saved:
            setattr(owner, key, forbidden)
        yield
    finally:
        for owner, key, original in saved:
            setattr(owner, key, original)
