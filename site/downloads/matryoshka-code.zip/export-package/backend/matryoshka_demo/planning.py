"""Local syntax alternatives, not candidate identities or inferred historical roles."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
import re

from .contracts import VERSION, MASK, public_case, span, validate
from .io import digest, sha


class LocalParser:
    def __init__(self, backend="stanza", model_dir=None):
        self.backend = backend
        if backend == "stanza":
            import torch
            import stanza
            torch.set_num_threads(1)
            self.nlp = stanza.Pipeline("en", dir=str(model_dir), package=None,
                processors={"tokenize": "ewt", "mwt": "ewt", "pos": "ewt_nocharlm", "lemma": "ewt_nocharlm", "depparse": "ewt_nocharlm"},
                download_method=None, use_gpu=False, verbose=False)
            self.binding = dict(backend=backend, version=stanza.__version__,
                model_sha256={str(p.relative_to(model_dir)): sha(p) for p in sorted(Path(model_dir).rglob("*.pt"))},
                pretrained=True, generative_model=False, training_membership_verified=False)
        elif backend == "spacy":
            import spacy
            self.nlp = spacy.load("en_core_web_sm")
            self.binding = dict(backend=backend, version=spacy.__version__, model=self.nlp.meta,
                pretrained=True, generative_model=False, training_membership_verified=False)
        elif backend == "symbolic":
            self.nlp = None
            self.binding = dict(backend=backend, version=VERSION, pretrained=False, generative_model=False)
        else:
            raise ValueError("Unknown local parser")

    @lru_cache(maxsize=256)
    def tokens(self, text):
        if self.backend == "stanza":
            doc = self.nlp(text)
            return [dict(text=w.text, start=w.start_char, end=w.end_char, lemma=w.lemma,
                pos=w.upos, tag=w.xpos, dep=w.deprel, sentence=i, head=w.head, id=w.id)
                for i, sentence in enumerate(doc.sentences) for w in sentence.words]
        if self.backend == "spacy":
            doc = self.nlp(text)
            return [dict(text=t.text, start=t.idx, end=t.idx + len(t), lemma=t.lemma_,
                pos=t.pos_, tag=t.tag_, dep=t.dep_, sentence=i, head=t.head.i, id=t.i)
                for i, sentence in enumerate(doc.sents) for t in sentence]
        return [dict(text=m.group(), start=m.start(), end=m.end(), lemma=m.group().casefold(),
            pos="X", tag="", dep="", sentence=0, head=0, id=i)
            for i, m in enumerate(re.finditer(r"\w+|[^\w\s]", text))]


def sentences(text):
    """Only physical sentence/paragraph separators can terminate a source span."""
    start = 0
    for match in re.finditer(r"[.!?][\"')]*\s+(?=[A-Z\[])|\n\s*\n", text):
        end = match.start() + len(match.group().rstrip())
        a = start + len(text[start:end]) - len(text[start:end].lstrip())
        if end > a:
            yield span(text, a, end)
        start = match.end()
    a = start + len(text[start:]) - len(text[start:].lstrip())
    end = len(text.rstrip())
    if end > a:
        yield span(text, a, end)


def reading_shapes(query, marker, tokens=()):
    at = query.index(marker); end = at + len(marker)
    left, right = query[:at], query[end:]
    lq, rq = left[-100:], right[:100]
    forms = []
    if re.match(r"\s*(initiative|policy|position|decision|orders?)\b", right, re.I):
        forms.append("possessive")
    if re.search(r"\b(?:like|including|among)\s*$", left, re.I):
        forms.append("nominal")
    if re.search(r"\b(?:politicians|leaders|officials|members|people)\s*$", left, re.I):
        forms.extend(["member_example", "adjunct"])
    if re.search(r"\b(?:the|a|an)\s*$", left, re.I) and re.match(r"\s*(?:[A-Z][a-z]+\s+)?[A-Za-z-]+", right):
        forms.extend(["modifier", "quantity"])
    if left.rstrip().endswith(",") and right.lstrip().startswith(","):
        forms.extend(["adjunct", "clause"])
    if re.search(r"\b(?:is|was|were|are|be|been)\s*$", left, re.I):
        forms.extend(["modifier", "nominal"])
    if re.match(r"\s*(?:are|were|is|was|has|have|had)\b", right, re.I):
        forms.append("nominal")
    if not forms:
        forms.extend(["nominal", "adjunct"])
    syntax_forms = {"poss": "possessive", "nmod:poss": "possessive", "amod": "modifier", "nummod": "quantity"}
    placeholder = next((t for t in tokens if t["start"] == at), None)
    syntactic = syntax_forms.get(placeholder["dep"]) if placeholder else None
    if syntactic: forms.insert(0, syntactic)
    return [dict(id=f"R{i}", form=form, left_quote=lq, right_quote=rq,
                 finite=True if form == "clause" else False if form in {"modifier", "possessive", "nominal", "member_example"} else None,
                 basis="dependency" if form == syntactic else "boundary_syntax") for i, form in enumerate(dict.fromkeys(forms), 1)][:4]


def plan(case, parser):
    case = public_case(case)
    text = case["query"]
    tokens = parser.tokens(MASK.sub(lambda m: "thing" + " " * (len(m.group()) - 5), text))
    atoms = []
    for unit in sentences(text):
        if MASK.search(unit["text"]):
            continue
        contained = [t for t in tokens if unit["start"] <= t["start"] < unit["end"]]
        if parser.backend != "symbolic" and not any(t["pos"] in {"VERB", "AUX"} for t in contained):
            continue
        atoms.append(dict(id=f"A{len(atoms)+1}", text=unit["text"], source_quote=unit["text"],
                          start=unit["start"], end=unit["end"]))
    entities = []
    for token in tokens:
        if token["pos"] == "PROPN" and token["text"] == text[token["start"]:token["end"]] and token["text"] != "thing":
            entities.append(dict(local_id=f"E{len(entities)+1}", label=token["text"], type="Other", description="",
                                 confidence=1., evidence_quote=token["text"]))
    claims = [dict(local_id=a["id"], claim_text=a["text"], speaker="", target="", stance="unclear",
                   assertion_mode="unknown", temporal_context="", confidence=1., evidence_quote=a["text"]) for a in atoms]
    result = dict(version=VERSION, task=case["task"], query_sha256=digest(text), atoms=atoms,
        slot_readings=reading_shapes(text, case["focal_marker"], tokens) if case["task"] == "redaction" else [],
        extractions=dict(entities=entities, events=[], claims=claims, relations=[]), parser=parser.binding)
    return validate(result, case)
