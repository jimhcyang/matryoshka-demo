"""Query-atom and direct-question retrieval; no unparsed whole-query search."""
from collections import OrderedDict
from copy import deepcopy

from . import retrieval_v3 as previous
from .corpus import words
from .corpus_policy_v5 import policy_view, VERSION as POLICY_VERSION
from .vendor.matching import clone
from .source_view_policy import descriptor, policy_of


VERSION = "atomic-input-hierarchy-retrieval/5"


def searches(plan, case):
    rows = []
    for atom in plan.get("atoms", []):
        if atom.get("kind") != "context" and atom.get("text", "").strip():
            rows.append(dict(id=atom["id"], kind="atom", query=atom["text"], atom_ids=[atom["id"]]))
    if not rows:
        raise ValueError("No executable atomic search input; context is grammar only")
    unique = OrderedDict()
    for row in rows:
        key = tuple(sorted(set(words(row["query"]))))
        if key in unique:
            unique[key].setdefault("also_serves", []).append(deepcopy(row))
        else:
            unique[key] = deepcopy(row)
    return list(unique.values())


_, _functions = clone(previous, dict(searches=searches))


def retrieve(corpus, case, plan, *, document_budget=100, passage_budget=100,
             hierarchy=True, graph=True, document_states=False):
    corpus = policy_view(corpus)
    value = _functions["retrieve"](corpus, case, plan, document_budget=document_budget,
        passage_budget=passage_budget, hierarchy=hierarchy, graph=graph, document_states=document_states)
    value["receipt"].update(method=VERSION, whole_query_search_executed=False,
        search_input_policy="Only saved faithful non-context atoms; context is grammar only; no whole-query fallback",
        unparsed_query_used_for_seed_or_page_scores=False,
        visible_context_role="Grammatical construction/ownership and source-excerpt presentation only, not an executed search",
        source_policy_version=POLICY_VERSION, handling_veto_documents=corpus.excluded_documents,
        source_view_policy=descriptor(policy_of(corpus)),
        whole_origin_excluded=(case["document_id"] if case["corpus"] != "cib"
            or policy_of(corpus).value == "strict_prior" else None))
    if any(s["kind"] not in {"atom", "question"} for s in value["receipt"]["search_queries"]):
        raise ValueError("Unexpected non-atomic search input")
    return value
