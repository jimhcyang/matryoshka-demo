"""Closed planning contract: quoted syntax and structure, no exploratory prose."""
from copy import deepcopy
from datetime import date
import re

from .io import digest

VERSION = "source-bound-three-task-plan/1"
TASKS = ("redaction", "hypothesis", "reconstruction")
FORMS = ("nominal", "modifier", "possessive", "member_example", "quantity", "adjunct", "verbal", "clause", "unknown")
MASK = re.compile(r"\[\[REDACTION_SLOT:[^\]]+\]\]|\[(?:REDACTION(?:[ _]\d+)?|REDACTED|STILL REDACTED|MASKED|MASK)\]", re.I)
WORD = re.compile(r"[A-Za-z0-9]+(?:['’-][A-Za-z0-9]+)*")
FORBIDDEN = frozenset({"answer", "gold", "oracle", "leads", "keywords", "search_terms", "function_search_terms", "rationale", "predicted_fill"})


def public_case(case):
    wanted = ("case_id", "corpus", "task", "query", "document_id", "date", "focal_marker")
    value = {k: case[k] for k in wanted}
    if not isinstance(value["case_id"],str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*",value["case_id"]):
        raise ValueError("A filesystem-safe case identity is required")
    if value["corpus"] not in {"cib", "iran", "vietnam"} or not isinstance(value["query"], str) or not value["query"].strip() or not value["document_id"]:
        raise ValueError("Corpus, nonempty query and whole-origin identity are required")
    if not isinstance(value["date"], str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}",value["date"]):
        raise ValueError("Strict ISO question date is required")
    date.fromisoformat(value["date"])
    if value["task"] not in TASKS:
        raise ValueError("Unknown task")
    if value["task"] == "redaction" and (not value["focal_marker"] or not MASK.fullmatch(value["focal_marker"])
            or value["query"].count(value["focal_marker"]) != 1):
        raise ValueError("One unique focal mask is required")
    if value["task"] != "redaction" and MASK.search(value["query"]):
        raise ValueError("Complete-claim tasks cannot contain unknown masks")
    return value


def span(text, start, end):
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text):
        raise ValueError("Invalid source interval")
    return dict(start=start, end=end, text=text[start:end])


def validate(plan, case):
    case = public_case(case)
    if set(plan) != {"version", "task", "query_sha256", "atoms", "slot_readings", "extractions", "parser"}:
        raise ValueError("Unexpected planning fields; no leads/keywords/explanatory hints are permitted")
    if plan["version"] != VERSION or plan["task"] != case["task"] or plan["query_sha256"] != digest(case["query"]):
        raise ValueError("Plan belongs to a different query or contract")
    text = case["query"]
    if len(plan["slot_readings"]) > 4 or (case["task"] != "redaction" and plan["slot_readings"]):
        raise ValueError("Slot readings apply only to redaction and have a declared display bound")
    for atom in plan["atoms"]:
        if set(atom) != {"id", "text", "source_quote", "start", "end"}:
            raise ValueError("Atoms are exact source spans, not generated paraphrases")
        source = span(text, atom["start"], atom["end"])
        if atom["text"] != source["text"] or atom["source_quote"] != atom["text"] or MASK.search(atom["text"]):
            raise ValueError("Atom is not exact visible query text")
    if len({a["id"] for a in plan["atoms"]}) != len(plan["atoms"]):
        raise ValueError("Duplicate atom identity")
    for reading in plan["slot_readings"]:
        if set(reading) != {"id", "form", "left_quote", "right_quote", "finite", "basis"}:
            raise ValueError("Readings contain grammatical fields only, no answer descriptions")
        if reading["form"] not in FORMS or (reading["finite"] is not None and type(reading["finite"]) is not bool):
            raise ValueError("Unrecognized slot shape")
        at = text.index(case["focal_marker"])
        right = at + len(case["focal_marker"])
        if (reading["left_quote"] not in text[:at] or reading["right_quote"] not in text[right:]
                or reading["basis"] not in {"boundary_syntax", "dependency", "unresolved"}):
            raise ValueError("Reading is not licensed by visible boundary quotations")
    if set(plan["extractions"]) != {"entities", "events", "claims", "relations"}:
        raise ValueError("The KG-compatible four-table structure is required")
    # Every generated text field must be empty or an actual query substring.
    # This intentionally restricts the general KG contract for query planning.
    for kind, objects in plan["extractions"].items():
        fields = {
            "entities": {"local_id", "label", "type", "description", "confidence", "evidence_quote"},
            "events": {"local_id", "label", "type", "date", "location", "description", "assertion_mode", "confidence", "evidence_quote"},
            "claims": {"local_id", "claim_text", "speaker", "target", "stance", "assertion_mode", "temporal_context", "confidence", "evidence_quote"},
            "relations": {"local_id", "source", "target", "relation", "assertion_mode", "temporal_context", "confidence", "evidence_quote"},
        }[kind]
        for obj in objects:
            if set(obj) != fields:
                raise ValueError("Unexpected KG object fields")
            if not obj.get("evidence_quote") or obj["evidence_quote"] not in text or MASK.search(obj["evidence_quote"]):
                raise ValueError("Extraction has no exact visible evidence")
            for key in ("label", "description", "claim_text", "speaker", "target", "date", "location", "temporal_context"):
                if obj.get(key) and obj[key] not in text:
                    raise ValueError("Query extraction introduced an unprovided descriptive term")
    ids = [o["local_id"] for objects in plan["extractions"].values() for o in objects]
    if len(ids) != len(set(ids)):
        raise ValueError("Extraction local IDs must be unique across tables")
    for relation in plan["extractions"]["relations"]:
        if relation["source"] not in ids or relation["target"] not in ids:
            raise ValueError("Relation endpoint is not a quoted query object")
    if len({r["id"] for r in plan["slot_readings"]}) != len(plan["slot_readings"]):
        raise ValueError("Duplicate reading identity")
    return deepcopy(plan)


def searches(plan, case):
    """Only source text, not reading labels, model descriptions or hidden keys."""
    validate(plan, case)
    found = []
    for text in [case["query"], *[a["text"] for a in plan["atoms"]]]:
        value = MASK.sub(" ", text)
        value = " ".join(WORD.findall(value))
        if value and value not in found:
            found.append(value)
    return found
