"""Optional quoted-identity projection BEFORE the existing extraction validator.

    projected_tables, qc = project(raw_four_tables, public_case)

No planning/cache/runtime integration is performed here. Schema and ALL local
IDs (including records later removed) are checked first. Entity labels must be
contiguous visible spans of their own query-bound evidence quotation; a bag of
source words is not an identity. Only case/whitespace replay is allowed, never
name recombination, punctuation/OCR repair, inferred expansions or mask fills.
Repairs restore raw query spelling and log absolute query offsets.
Event labels containing an opaque mask are dropped, never renamed.

Unsupported optional descriptions are cleared, not used to discard a quoted
identity. Unlicensed/scope-losing claim text falls back to its literal source
quotation, without synthesizing a speaker or scope. Raw inputs stay untouched.
Other fields, types/confidence and dependent relations are NOT certified or
repaired: callers must subsequently run planning_v2.check_extraction, normally
with quarantine=True. This is provenance projection, not factual entailment or
complete-query scope certification; a short quote may omit surrounding scope.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
from pathlib import Path
import re

import jsonschema

from .contracts import MASK, public_case
from .io import digest, load
from .planning_v2 import license_words, scope_cues, scope_preserved


VERSION = "quoted-identity-query-projection/2.2"
SOURCE_LICENSING = dict(projection_version=VERSION,
    entity_identity="Contiguous visible span inside its own query-bound evidence quote",
    normalization="Reversible case/whitespace only; raw spelling and offsets logged",
    optional_description="Clear unsupported text, retain independently quoted identity",
    claim_text="Unsupported lexical content or lost scope falls back to exact evidence quote",
    subsequent_validator="planning_v2.check_extraction(..., quarantine=True)",
    semantic_entailment_certified=False, complete_query_scope_certified=False)
_TABLES = ("entities", "events", "claims", "relations")
_NEGATION = re.compile(r"\b(?:no|not|never|neither|nor|without)\b", re.I)


@lru_cache(maxsize=1)
def _schema():
    return load(Path(__file__).resolve().parents[1] / "contracts/kg_extraction_2_32.json")["schema"]


def _normalized(text):
    return " ".join(text.split()).casefold()


def _scope_safe(text, quote):
    # Determiner negation ("no evidence") need not receive a spaCy neg tag.
    if (not scope_preserved(text, quote)
            or not set(_NEGATION.findall(quote.casefold())) <= set(_NEGATION.findall(text.casefold()))):
        return False
    if scope_cues(quote) or _NEGATION.search(quote):
        # A cue-set check alone permits moving "not" to a different clause.
        # Only trivial article/complementizer edits are accepted under scope.
        def ordered(value):
            return [w for w in re.findall(r"\w+|[^\w\s]", value.casefold())
                    if w not in {"a", "an", "the", "that"}]
        return ordered(text) == ordered(quote)
    return True


def _spans(text, quote):
    if not quote.strip():
        return
    seen = set()
    patterns = [(re.escape(quote), 0), (r"\s+".join(re.escape(p) for p in quote.split()), re.I)]
    for pattern, flags in patterns:
        for match in re.finditer(pattern, text, flags):
            a, b = match.span()
            if (a, b) not in seen and _normalized(text[a:b]) == _normalized(quote):
                seen.add((a, b))
                yield a, b


def _visible_label(query, quote_span, label):
    if MASK.search(label):
        return None
    offset, end = quote_span
    masks = [m.span() for m in MASK.finditer(query)]
    for a, b in _spans(query[offset:end], label):
        a, b = offset + a, offset + b
        if any(a < hi and lo < b for lo, hi in masks):
            continue
        # A name fragment inside a longer word is not an independent mention.
        word = lambda c: c.isalnum() or c == "_"
        if ((a and word(query[a - 1]) and word(query[a]))
                or (b < len(query) and word(query[b - 1]) and word(query[b]))):
            continue
        return a, b
    return None


def project(raw, case):
    """Return independent projected tables and repair/drop QC; make no API calls."""
    case = public_case(case)
    jsonschema.validate(raw, _schema())
    ids = [row["local_id"] for kind in _TABLES for row in raw[kind]]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate extraction identity before projection")
    query = case["query"]
    projected, qc = {kind: [] for kind in raw}, []

    def log(kind, original, policy, field=None, value=None, interval=None):
        entry = dict(version=VERSION, kind=kind, local_id=original["local_id"], policy=policy,
                     original_sha256=digest(original), query_sha256=digest(query))
        if field:
            entry.update(field=field, original_value=original[field], projected_value=value)
        if interval:
            a, b = interval
            entry.update(start=a, end=b, source_quote=query[a:b])
        qc.append(entry)

    for kind, rows in raw.items():
        for original in rows:
            row = deepcopy(original)
            interval = next(_spans(query, row["evidence_quote"]), None)
            if interval is None:
                log(kind, original, "DROP_UNBOUND_EVIDENCE_QUOTE")
                continue
            a, b = interval
            row["evidence_quote"] = query[a:b]
            if row["evidence_quote"] != original["evidence_quote"]:
                log(kind, original, "RESTORE_RAW_QUOTE_CASE_WHITESPACE", "evidence_quote", row["evidence_quote"], interval)
            if kind == "events" and MASK.search(row["label"]):
                log(kind, original, "DROP_OPAQUE_EVENT_LABEL", interval=interval)
                continue
            if kind == "entities":
                label_span = _visible_label(query, interval, row["label"])
                if label_span is None:
                    log(kind, original, "DROP_NONCONTIGUOUS_OR_OPAQUE_IDENTITY", interval=interval)
                    continue
                lo, hi = label_span
                row["label"] = query[lo:hi]
                if row["label"] != original["label"]:
                    log(kind, original, "RESTORE_RAW_LABEL_CASE_WHITESPACE", "label", row["label"], label_span)
            quote = row["evidence_quote"]
            if row.get("description") and (not license_words(row["description"], quote)
                    or not _scope_safe(row["description"], quote)
                    or MASK.findall(row["description"]) != MASK.findall(quote)):
                row["description"] = ""
                log(kind, original, "CLEAR_UNSUPPORTED_OPTIONAL_DESCRIPTION", "description", "", interval)
            if kind == "claims" and (not license_words(row["claim_text"], quote)
                    or not _scope_safe(row["claim_text"], quote)
                    or MASK.findall(row["claim_text"]) != MASK.findall(quote)):
                row["claim_text"] = quote
                log(kind, original, "EXACT_QUOTE_CLAIM_FALLBACK", "claim_text", quote, interval)
            projected[kind].append(row)
    return projected, qc
