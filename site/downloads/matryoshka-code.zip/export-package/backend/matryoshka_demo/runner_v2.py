"""Frozen public plans, offline task execution, and exact-source checkpoints."""
import fcntl
import gc
import importlib.metadata
from pathlib import Path
import platform
import time

from .contracts import public_case
from .corpus import Corpus
from .integrity import source_objects,verify_auxiliary,verify_sources
from .io import digest,disk_guard,load,offline,save,save_gzip,sha
from .planning_v2 import ARMS,make_plan,validate_plan
from .runner import checked,code_binding,load_inputs,write_checkpoint

VERSION="shared-three-task-experiment/2.1"


def environment_binding(root):
    from .tasks import parser
    model=parser().nlp.path
    return dict(python=platform.python_version(),packages={p:importlib.metadata.version(p) for p in
        ("numpy","scipy","scikit-learn","spacy","en_core_web_sm","nltk","jsonschema")},
        spacy_model_files={str(p.relative_to(model)):sha(p) for p in sorted(model.rglob("*")) if p.is_file()},
        wordnet_resource_sha256=sha(root/"data/models/nltk/corpora/wordnet.zip"))


def reference_binding(enabled):
    if not enabled:return {}
    from .legacy_reference_v2 import ORIGINAL_ROOT
    return {str(p.relative_to(ORIGINAL_ROOT)):sha(p) for p in sorted(ORIGINAL_ROOT.rglob("*.py"))}


def prepare(root,catalog_path,*,execute=False,cap=25.,case_ids=None):
    root=Path(root).resolve();catalog=load_inputs(catalog_path)
    cases=catalog["cases"]+catalog["controls"]
    if case_ids:cases=[c for c in cases if c["case_id"] in case_ids]
    if not cases:raise ValueError("No public cases selected")
    if not execute:return dict(cases=len(cases),maximum_new_planning_calls=3*len(cases),api_calls=0)
    entries={}
    for c in cases:
        for arm in ARMS:
            plan=make_plan(c,arm,api_root=root/"data/development_v2/api",cap=cap);validate_plan(plan,c)
            if plan["arm"]!=arm:raise ValueError("Planner returned another comparison arm")
            path=root/"data/development_v2/plans"/(c["case_id"]+"__"+arm+"__"+digest(plan)[:12]+".json")
            packet=dict(case=c,plan=plan)
            if path.exists() and load(path)!=packet:raise ValueError("Existing exact plan changed")
            save(path,packet);entries[c["case_id"]+"__"+arm]=dict(path=str(path.relative_to(root)),sha256=sha(path))
            print("Planned",c["corpus"],c["task"],c["case_id"],arm,flush=True)
    value=dict(version=VERSION,catalog_sha256=catalog["sha256"],
        catalog_ref=dict(path=str(Path(catalog_path).resolve().relative_to(root)),sha256=sha(catalog_path)),
        assessment_release_ref=dict(path=str((Path(catalog_path).resolve().parent/"assessment_release.json").relative_to(root)),
            sha256=sha(Path(catalog_path).resolve().parent/"assessment_release.json")),
        cases=cases,plans=entries,keys_read=False,grades_read=False)
    value["sha256"]=digest(value);path=root/"data/development_v2"/("plan_release_"+value["sha256"][:16]+".json")
    save(path,value);save(root/"data/development_v2/latest_plans.json",dict(path=str(path.relative_to(root)),sha256=sha(path)))
    return dict(path=str(path),cases=len(cases),plans=len(entries))


def verify_record(payload,case,arm,run_id,binding_sha256,plan):
    if (payload["case"]!=case or payload["config"]!=arm or payload["run_id"]!=run_id
            or payload["binding_sha256"]!=binding_sha256 or payload["plan"]!=plan
            or payload.get("inference_network_access") is not False):raise ValueError("Checkpoint condition changed")
    validate_plan(plan,case)


def verify_release_references(root,release):
    for field in ("catalog_ref","assessment_release_ref"):
        ref=release[field];path=(root/ref["path"]).resolve()
        if not path.is_relative_to(root/"data") or sha(path)!=ref["sha256"]:raise ValueError("Referenced public/assessment release changed")
    catalog=load_inputs(root/release["catalog_ref"]["path"])
    if catalog["sha256"]!=release["catalog_sha256"]:raise ValueError("Public catalog binding mismatch")
    if catalog['binding_sha256']!=load(root/'data/bindings.json')['sha256']:
        raise ValueError('Public question catalog belongs to a different source binding')
    admitted={c["case_id"]:c for c in catalog["cases"]+catalog["controls"]}
    if len({c["case_id"] for c in release["cases"]})!=len(release["cases"]):raise ValueError("Duplicate public cases")
    for c in release["cases"]:
        if c!=public_case(c) or admitted.get(c["case_id"])!=c:raise ValueError("Nonpublic or altered case in plan release")


def run(root,*,plan_release=None,reference=True,document_budget=100,passage_budget=100,hierarchy=True):
    from .candidates_v24 import construct
    from .retrieval_v2 import retrieve
    from .task_binding_v21 import execute
    from .exploratory_evidence_v21 import enrich
    from .legacy_reference_v2 import run as original_reference
    from .exploration_v2 import build_index
    root=Path(root).resolve();workspace=root.parent
    binding=load(root/"data/bindings.json")
    if plan_release is None:
        pointer=load(root/"data/development_v2/latest_plans.json");plan_release=root/pointer["path"]
        if sha(plan_release)!=pointer["sha256"]:raise ValueError("Plan pointer changed")
    release=load(plan_release)
    if digest({k:v for k,v in release.items() if k!="sha256"})!=release["sha256"]:raise ValueError("Plan release changed")
    if release.get("keys_read") is not False or release.get("grades_read") is not False:raise ValueError("Private planning input")
    verify_release_references(root,release)
    cases=[public_case(c) for c in release["cases"]];arms=list(ARMS)+(["legacy_reference"] if reference else [])
    plans={}
    for c in cases:
        for arm in ARMS:
            ref=release["plans"][c["case_id"]+"__"+arm];path=(root/ref["path"]).resolve()
            if not path.is_relative_to(root/"data/development_v2/plans") or sha(path)!=ref["sha256"]:raise ValueError("Plan receipt changed")
            value=load(path)
            if value["case"]!=c:raise ValueError("Plan/public case mismatch")
            if value["plan"]["arm"]!=arm:raise ValueError("Plan does not match its declared comparison arm")
            plans[c["case_id"],arm]=validate_plan(value["plan"],c)
    settings=dict(arms=arms,hierarchy=hierarchy,document_budget=document_budget,passage_budget=passage_budget,
        top_k=5,rrf_k=60,alpha=.85,tolerance=1e-8,classification="exact_CONFIDENTIAL_non_NOFORN_for_cables",
        reference="original engines on arm1 fixed-source snapshot; not an end-to-end retrieval baseline")
    identity=dict(version=VERSION,code=code_binding(root),environment=environment_binding(root),
        original_reference_code=reference_binding(reference),
        plan_release_sha256=sha(plan_release),plan_release=release,binding_sha256=binding["sha256"],settings=settings,
        keys_read=False,grades_read=False,inference_network_access=False)
    run_id="demo_v2_"+digest(identity)[:20];directory=root/"data/runs_v2"/run_id;directory.mkdir(parents=True,exist_ok=True)
    disk_guard(directory);lock=(directory/"run.lock").open("a+")
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    try:
        manifest=directory/"manifest.json"
        if manifest.exists() and load(manifest)!=identity:raise ValueError("Frozen run identity changed")
        if not manifest.exists():save(manifest,identity)
        progress=dict(run_id=run_id,status="RUNNING",completed=0,expected=len(cases)*len(arms),failures=[])
        save(directory/"progress.json",progress)
        with offline():
            verify_sources(workspace,binding,{c["corpus"] for c in cases})
            expected={c["case_id"]+"__"+a+".json" for c in cases for a in arms}
            if {p.name for p in (directory/"cases").glob("*.json")}-expected:raise ValueError("Unexpected checkpoint condition")
            source_cache={}
            for corpus_name in dict.fromkeys(c["corpus"] for c in cases):
                relevant=[c for c in cases if c["corpus"]==corpus_name]
                corpus=None
                for c in relevant:
                    primary=None
                    for arm in arms:
                        disk_guard(directory);target=directory/"cases"/(c["case_id"]+"__"+arm+".json")
                        plan=plans[c["case_id"],"llm_leads" if arm=="legacy_reference" else arm]
                        if target.exists():
                            record=checked(target);verify_record(record,c,arm,run_id,binding["sha256"],plan)
                            verify_auxiliary(directory,record,source_cache);progress["completed"]+=1
                            save(directory/"progress.json",progress);continue
                        if corpus is None:
                            print("Loading",corpus_name,flush=True);corpus=Corpus(workspace,binding["corpora"][corpus_name])
                            index=build_index(corpus,root);save(directory/(corpus_name+"_graph_index.json"),index)
                        start=time.perf_counter()
                        try:
                            if arm=="legacy_reference":
                                if primary is None:primary=retrieve(corpus,c,plan,document_budget=document_budget,passage_budget=passage_budget,hierarchy=hierarchy)
                                retrieval=primary;result=original_reference(c,retrieval,passage_budget=passage_budget)
                            else:
                                retrieval=retrieve(corpus,c,plan,document_budget=document_budget,passage_budget=passage_budget,hierarchy=hierarchy)
                                if arm=="llm_leads":primary=retrieval
                                if c["task"]=="redaction":result=construct(c,plan,retrieval,passage_budget=passage_budget)
                                else:
                                    result=execute(c,plan,retrieval,passage_budget=passage_budget)
                                    result=enrich(c,plan,retrieval,result,passage_budget=passage_budget)
                            audit=result.pop("_candidate_audit",None)
                            if audit:
                                path=directory/"candidate_audits"/(target.stem+".json.gz");save_gzip(path,audit)
                                result["candidate_audit_ref"]=dict(path=str(path.relative_to(directory)),sha256=sha(path))
                            record=dict(case=c,config=arm,plan=plan,result=result,runtime_seconds=round(time.perf_counter()-start,4),
                                binding_sha256=binding["sha256"],run_id=run_id,inference_network_access=False)
                            source_ids={s["canonical_page_id"] for s in source_objects(result)}
                            source_ids.update(corpus.pages[i]["id"] for i in retrieval["pages"][:passage_budget])
                            if audit:
                                source_ids.update(audit["inspected_page_ids"])
                                source_ids.update(s["canonical_page_id"] for s in source_objects(audit))
                            for pid in sorted(source_ids):
                                pi=corpus.page_index[pid]
                                if not retrieval["eligible"].page_mask[pi]:raise ValueError("Ineligible source in native result")
                                path=directory/"sources"/(pid+".json");value=corpus.pages[pi]
                                if path.exists() and load(path)!=value:raise ValueError("Saved source changed")
                                if not path.exists():save(path,value)
                            if code_binding(root)!=identity["code"] or reference_binding(reference)!=identity["original_reference_code"]:
                                raise RuntimeError("Code changed during execution; start a separately versioned run")
                            verify_record(record,c,arm,run_id,binding["sha256"],plan);verify_auxiliary(directory,record,source_cache)
                            write_checkpoint(target,record);progress["completed"]+=1
                            print(f'{progress["completed"]}/{progress["expected"]} {corpus_name} {c["task"]} {arm} {record["runtime_seconds"]}s',flush=True)
                        except BaseException as error:
                            failure=dict(case_id=c["case_id"],arm=arm,error_type=type(error).__name__,message=str(error))
                            save(directory/"failures"/target.name,failure);progress["failures"].append(failure);raise
                        finally:save(directory/"progress.json",progress)
                    primary=None
                corpus=None;gc.collect()
        progress["status"]="COMPLETE"
        save(root/"data/latest_run_v2.json",dict(run_id=run_id,directory=str(directory),manifest_sha256=sha(directory/"manifest.json")))
        return progress
    except BaseException:
        if "progress" in locals():progress["status"]="PAUSED_OR_FAILED"
        raise
    finally:
        if "progress" in locals():save(directory/"progress.json",progress)
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
