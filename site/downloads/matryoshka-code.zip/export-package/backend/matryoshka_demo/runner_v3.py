"""Separately frozen four-arm study; inference is offline and answer-blind."""
from collections import defaultdict
from copy import deepcopy
import fcntl
import gc
from pathlib import Path
import time
import zipfile
import shutil

from .contracts import public_case
from .corpus import Corpus
from .integrity import source_objects, verify_auxiliary, verify_sources
from .io import digest, disk_guard, load, offline, save, save_gzip, sha
from .runner import checked, code_binding, load_inputs, write_checkpoint
from .runner_v2 import environment_binding, reference_binding


VERSION = "four-arm-source-bound-study/3"
ARMS = ("llm_readings", "llm_atoms", "llm_local", "legacy_reference")


def execution_binding(root):
    post_run = {"api_v2.py", "assessment_v2.py", "assessment_v3.py", "assessment_replay_v23.py",
        "reporting.py", "reporting_v2.py", "reporting_v3.py", "server.py", "corpus_explorer_v3.py", "cli.py"}
    result = {name:value for name,value in code_binding(root).items()
        if Path(name).name not in post_run}
    for path in sorted((root / "contracts/planning_v3").rglob("*")):
        if path.is_file():
            result[str(path.relative_to(root))] = sha(path)
    return result


def code_archive(root, directory, binding):
    target = directory / "code_snapshot.zip"
    if target.exists():
        with zipfile.ZipFile(target) as archive:
            if set(archive.namelist()) != set(binding):
                raise ValueError("Archived code entry set changed")
            import hashlib
            if any(hashlib.sha256(archive.read(name)).hexdigest() != expected for name, expected in binding.items()):
                raise ValueError("Archived code content changed")
        return
    temporary = directory / "code_snapshot.tmp.zip"
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, expected in sorted(binding.items()):
            path = (root / name).resolve()
            if not path.is_relative_to(root) or sha(path) != expected:
                raise ValueError("Code changed while archiving")
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    temporary.replace(target)


def graph_reference(root, path, expected_binding):
    from .exploration_v2 import verified_hash
    ref = load(path)
    target = (root / ref["path"]).resolve()
    if not target.is_relative_to(root / "data/graph_indexes_v2") or ref.get("binding") != expected_binding:
        raise ValueError("Explorer graph differs from the native source binding")
    manifest = load(target.parent / "manifest.json")
    stat = target.stat()
    if (manifest.get("binding") != expected_binding or manifest.get("sha256") != ref["sha256"]
            or verified_hash(str(target), stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino) != ref["sha256"]):
        raise ValueError("Explorer index changed")
    return ref


def source_catalog(path):
    value = load(path)
    if "status" not in value:
        return load_inputs(path)
    expected = {"version", "factory_sha256", "binding_sha256", "cases", "controls", "sha256", "status"}
    if (set(value) != expected or value["version"] != "public-demo-inputs/1"
            or digest({k: v for k, v in value.items() if k != "sha256"}) != value["sha256"]):
        raise ValueError("Invalid source-screened proposal catalog")
    cases = value["cases"] + value["controls"]
    if any(c != public_case(c) for c in cases) or len({c["case_id"] for c in cases}) != len(cases):
        raise ValueError("Nonpublic or duplicate source proposal")
    return value


def prepare(root, catalog_path, *, execute=False, cap=25., case_ids=None):
    from .planning_v3 import make_plans, select_context, validate_plan
    root = Path(root).resolve()
    catalog_path = Path(catalog_path).resolve()
    original = source_catalog(catalog_path)
    originals = original["cases"] + original["controls"]
    if case_ids:
        originals = [c for c in originals if c["case_id"] in case_ids]
    if not originals:
        raise ValueError("No cases selected")
    if not execute:
        return dict(cases=len(originals), base_planning_calls=3 * len(originals),
            maximum_planning_calls_including_bounded_repairs=7 * len(originals), api_calls=0,
            profile=VERSION, message="Add --execute for the bounded development planning calls")
    cases, windows = [], []
    for old in originals:
        selection = select_context(old)
        if isinstance(selection, tuple):
            current, mapping = selection
        else:
            current, mapping = selection["case"], selection["mapping"]
        cases.append(current)
        windows.append(dict(case_id=old["case_id"], original_query_sha256=digest(old["query"]),
            query_sha256=digest(current["query"]), mapping=mapping, membership_changed=False))
    factory = dict(version="question-windows/3", original_catalog=dict(path=str(catalog_path.relative_to(root)), sha256=sha(catalog_path)),
        windows=windows, original_cases=originals,
        admission_policy="Inherited source-screened development candidates; outcome-informed demo selection, not benchmark admission")
    catalog = dict(version="public-demo-inputs/1", factory_sha256=digest(factory), binding_sha256=original["binding_sha256"], cases=cases, controls=[])
    catalog["sha256"] = digest(catalog)
    population = root / "data/populations_v3" / catalog["sha256"][:16]
    save(population / "inference_catalog.json", catalog)
    save(population / "window_changes.json", factory)
    old_keys = catalog_path.parent / "evaluation_keys.json"
    if not old_keys.exists():
        old_keys = catalog_path.parent / "private/evaluation_keys.json"
    if not old_keys.is_file() or not old_keys.is_relative_to(root):
        raise ValueError("A separate, bound post-run key file is required")
    # Archive opaque bytes without parsing or passing answers to planning.
    key_hash = sha(old_keys)
    key_snapshot = population / "private" / ("evaluation_keys_" + key_hash + ".json")
    key_snapshot.parent.mkdir(parents=True, exist_ok=True)
    if not key_snapshot.exists():
        shutil.copyfile(old_keys, key_snapshot)
    if sha(key_snapshot) != key_hash:
        raise ValueError("Immutable evaluation key snapshot changed")
    assessment_release = dict(version="assessment-inputs/3", public_inputs_sha256=catalog["sha256"],
        evaluation_keys_ref=dict(path=str(key_snapshot.relative_to(root)), sha256=key_hash),
        evaluation_keys_sha256=key_hash)
    assessment_release["sha256"] = digest(assessment_release)
    assessment_path = population / ("assessment_release_" + assessment_release["sha256"][:20] + ".json")
    if assessment_path.exists() and load(assessment_path) != assessment_release:
        raise ValueError("Immutable assessment release changed")
    if not assessment_path.exists():
        save(assessment_path, assessment_release)
    entries = {}
    for case in cases:
        plans = make_plans(case, api_root=root / "data/development_v2/api", cap=cap, execute=True,
            output_root=root / "data/development_v3/bundles")
        atoms = {digest(plan["atoms"]) for plan in plans.values()}
        extractions = {digest(plan["extractions"]) for plan in plans.values()}
        if len(atoms) != 1 or len(extractions) != 1:
            raise ValueError("The three new arms must share identical extraction and atoms")
        for arm, plan in plans.items():
            validate_plan(plan, case)
            path = root / "data/development_v3/plans" / (case["case_id"] + "__" + arm + "__" + digest(plan)[:16] + ".json")
            value = dict(case=case, plan=plan)
            if path.exists() and load(path) != value:
                raise ValueError("Existing plan changed")
            save(path, value)
            entries[case["case_id"] + "__" + arm] = dict(path=str(path.relative_to(root)), sha256=sha(path))
        print("Planned", case["corpus"], case["task"], case["case_id"], flush=True)
    release = dict(version=VERSION, catalog_sha256=catalog["sha256"],
        catalog_ref=dict(path=str((population / "inference_catalog.json").relative_to(root)), sha256=sha(population / "inference_catalog.json")),
        factory_ref=dict(path=str((population / "window_changes.json").relative_to(root)), sha256=sha(population / "window_changes.json")),
        assessment_release_ref=dict(path=str(assessment_path.relative_to(root)), sha256=sha(assessment_path)),
        cases=cases, plans=entries, keys_read=False, grades_read=False,
        exposure="Outcome-informed development cases; not blind benchmark evaluation",
        development_exposure=dict(origins=[dict(corpus=c["corpus"], document_id=c["document_id"], case_id=c["case_id"]) for c in cases],
            partition_policy="Future evaluations from these originating documents must be labelled development-exposed, not reserved/unexposed",
            original_benchmark_release_mutated=False))
    release["sha256"] = digest(release)
    path = root / "data/development_v3" / ("plan_release_" + release["sha256"][:16] + ".json")
    save(path, release)
    save(root / "data/development_v3/latest_plans.json", dict(path=str(path.relative_to(root)), sha256=sha(path)))
    return dict(path=str(path), cases=len(cases), plans=len(entries), api_calls="Exact requests reuse cache")


def release_inputs(root, path):
    from .planning_v3 import validate_plan
    release = load(path)
    if digest({k: v for k, v in release.items() if k != "sha256"}) != release["sha256"]:
        raise ValueError("Plan release changed")
    if release["version"] != VERSION or release["keys_read"] or release["grades_read"]:
        raise ValueError("Invalid public plan release")
    for field in ("catalog_ref", "assessment_release_ref", "factory_ref"):
        ref = release[field]; target = (root / ref["path"]).resolve()
        if not target.is_relative_to(root / "data") or sha(target) != ref["sha256"]:
            raise ValueError("Population reference changed")
    catalog = load_inputs(root / release["catalog_ref"]["path"])
    if catalog["cases"] != release["cases"] or catalog["sha256"] != release["catalog_sha256"]:
        raise ValueError("Public population changed")
    factory = load(root / release["factory_ref"]["path"])
    if digest(factory) != catalog["factory_sha256"]:
        raise ValueError("Question-window factory changed")
    old = {c["case_id"]: c for c in factory["original_cases"]}
    windows = {w["case_id"]: w["mapping"] for w in factory["windows"]}
    for case in release["cases"]:
        mapping = windows[case["case_id"]]
        original = old[case["case_id"]]
        if (case["query"] != original["query"][mapping["source_start"]:mapping["source_end"]]
                or any(case[k] != original[k] for k in case if k != "query")):
            raise ValueError("Question window is not a literal projection of the public source question")
    plans = {}
    for case in release["cases"]:
        public_case(case)
        for arm in ARMS[:-1]:
            ref = release["plans"][case["case_id"] + "__" + arm]
            target = (root / ref["path"]).resolve()
            if not target.is_relative_to(root / "data/development_v3/plans") or sha(target) != ref["sha256"]:
                raise ValueError("Plan reference changed")
            value = load(target)
            if value["case"] != case or value["plan"]["arm"] != arm:
                raise ValueError("Plan condition changed")
            plans[case["case_id"], arm] = validate_plan(value["plan"], case)
    return release, plans


def run(root, *, plan_release=None, reference=True, document_budget=100, passage_budget=100,
        hierarchy=True, document_states=False, case_ids=None):
    from .candidates_v3 import construct, finalize_untyped
    from .retrieval_v3 import retrieve
    from .flow_v3 import replay
    from .task_execution_v3 import execute_v3 as execute, filter_redaction
    from .legacy_reference_v3 import run as original_reference
    from .exploratory_evidence_v21 import enrich
    from .exploration_v2 import build_index
    root = Path(root).resolve()
    if any(type(v) is not int or v < 1 for v in (document_budget, passage_budget)):
        raise ValueError("Positive integer document/page budgets required")
    if plan_release is None:
        pointer = load(root / "data/development_v3/latest_plans.json")
        plan_release = root / pointer["path"]
        if sha(plan_release) != pointer["sha256"]:
            raise ValueError("Plan pointer changed")
    release, plans = release_inputs(root, plan_release)
    cases = [c for c in release["cases"] if not case_ids or c["case_id"] in case_ids]
    if not cases:
        raise ValueError("No conditions selected")
    binding = load(root / "data/bindings.json")
    if load(root / release["catalog_ref"]["path"])["binding_sha256"] != binding["sha256"]:
        raise ValueError("Population/source binding mismatch")
    arms = ARMS if reference else ARMS[:-1]
    settings = dict(arms=list(arms), hierarchy=hierarchy, document_states=document_states,
        document_budget=document_budget, passage_budget=passage_budget, top_k=5, rrf_k=60, alpha=.85, tolerance=1e-8,
        flow_display_nodes=28, expanded_display_nodes=1024, solver_depth_limit=None)
    identity = dict(version=VERSION, code=execution_binding(root), environment=environment_binding(root),
        original_reference_code=reference_binding(reference), binding_sha256=binding["sha256"],
        plan_release=release, plan_release_sha256=sha(plan_release), settings=settings,
        cases=cases, keys_read=False, grades_read=False, inference_network_access=False)
    directory = root / "data/runs_v3" / ("demo_v3_" + digest(identity)[:20])
    directory.mkdir(parents=True, exist_ok=True)
    disk_guard(directory)
    with (directory / "run.lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        manifest = directory / "manifest.json"
        if manifest.exists() and load(manifest) != identity:
            raise ValueError("Frozen run changed")
        if not manifest.exists():
            save(manifest, identity)
        code_archive(root, directory, identity["code"])
        progress = dict(run_id=directory.name, status="RUNNING", completed=0, expected=len(cases) * len(arms), failures=[])
        save(directory / "progress.json", progress)
        try:
            with offline():
                verify_sources(root.parent, binding, {c["corpus"] for c in cases})
                cache = {}
                for name in dict.fromkeys(c["corpus"] for c in cases):
                    corpus = None
                    index_path = directory / (name + "_graph_index.json")
                    if not index_path.exists():
                        print("Loading", name, "and binding its corpus explorer", flush=True)
                        corpus = Corpus(root.parent, binding["corpora"][name])
                        save(index_path, build_index(corpus, root))
                    index_ref = graph_reference(root, index_path, binding["corpora"][name])
                    for case in (c for c in cases if c["corpus"] == name):
                        for arm in arms:
                            disk_guard(directory)
                            target = directory / "cases" / (case["case_id"] + "__" + arm + ".json")
                            if target.exists():
                                record = checked(target)
                                if (record["case"] != case or record["config"] != arm or record["run_id"] != directory.name
                                        or record["binding_sha256"] != binding["sha256"]
                                        or record.get("exploration_index_ref") != index_ref
                                        or record["inference_network_access"] is not False
                                        or arm != "legacy_reference" and record["plan"] != plans[case["case_id"], arm]):
                                    raise ValueError("Checkpoint condition changed")
                                verify_auxiliary(directory, record, cache)
                                progress["completed"] += 1; save(directory / "progress.json", progress)
                                continue
                            if corpus is None:
                                print("Loading", name, flush=True)
                                corpus = Corpus(root.parent, binding["corpora"][name])
                            start = time.perf_counter()
                            if arm == "legacy_reference":
                                result, retrieval = original_reference(case, corpus, passage_budget=passage_budget, document_budget=document_budget)
                                plan = dict(arm=arm, atoms=[dict(id=row["id"], text=row["query"],
                                    source_quote="", required=True, origin="Original parser retrieval contract")
                                    for row in retrieval["receipt"]["search_queries"]],
                                    slot_readings=[], leads=[], parser="Original src parser")
                            else:
                                plan = plans[case["case_id"], arm]
                                retrieval = retrieve(corpus, case, plan, document_budget=document_budget, passage_budget=passage_budget,
                                    hierarchy=hierarchy, document_states=document_states)
                                if case["task"] == "redaction":
                                    result = construct(case, plan, retrieval, passage_budget=passage_budget)
                                    result = filter_redaction(case, result, top_k=5)
                                    result = finalize_untyped(result)
                                else:
                                    result = execute(case, plan, retrieval, passage_budget=passage_budget)
                                    result = enrich(case, plan, retrieval, result, passage_budget=passage_budget)
                                result["flow"] = replay(retrieval, result)
                                result["retrieval"] = retrieval["receipt"]
                            audit = result.pop("_candidate_audit", None)
                            if audit:
                                path = directory / "candidate_audits" / (target.stem + ".json.gz")
                                save_gzip(path, audit)
                                result["candidate_audit_ref"] = dict(path=str(path.relative_to(directory)), sha256=sha(path))
                            record = dict(case=case, config=arm, plan=plan, result=result,
                                runtime_seconds=round(time.perf_counter() - start, 4), binding_sha256=binding["sha256"],
                                run_id=directory.name, inference_network_access=False, exploration_index_ref=index_ref)
                            source_ids = {s["canonical_page_id"] for s in source_objects(result)}
                            source_ids.update(corpus.pages[i]["id"] for i in retrieval["pages"][:passage_budget])
                            if audit:
                                source_ids.update(audit.get("inspected_page_ids", []))
                                source_ids.update(s["canonical_page_id"] for s in source_objects(audit))
                            for pid in sorted(source_ids):
                                pi = corpus.page_index[pid]
                                if not retrieval["eligible"].page_mask[pi]:
                                    raise ValueError("Ineligible source in result")
                                path = directory / "sources" / (pid + ".json")
                                if path.exists() and load(path) != corpus.pages[pi]:
                                    raise ValueError("Saved source changed")
                                if not path.exists():
                                    save(path, corpus.pages[pi])
                            if execution_binding(root) != identity["code"]:
                                raise RuntimeError("Code changed; start a separately versioned run")
                            verify_auxiliary(directory, record, cache)
                            write_checkpoint(target, record)
                            progress["completed"] += 1; save(directory / "progress.json", progress)
                            print(f'{progress["completed"]}/{progress["expected"]} {name} {case["task"]} {arm} {record["runtime_seconds"]}s', flush=True)
                    corpus = None; gc.collect()
            progress["status"] = "COMPLETE"
            save(root / "data/latest_run_v3.json", dict(directory=str(directory), manifest_sha256=sha(manifest)))
            return progress
        except BaseException as error:
            progress["status"] = "PAUSED_OR_FAILED"
            failure = dict(error_type=type(error).__name__, message=str(error))
            progress["failures"].append(failure)
            save(directory / "failures" / (str(time.time_ns()) + ".json"), failure)
            raise
        finally:
            save(directory / "progress.json", progress)
