"""Post-run assessment packets, with complete saved redaction proof citations.

``prepare(case, records, reference_answer)`` retains the v2 two-value interface.
The packet revision changes exact request/cache keys; v2's assessor and artifact
replay remain unchanged. Packet preparation never retrieves, infers a fill, or
calls an API. Only an explicit ``assess`` call invokes the post-run grader.
Citation checks here supplement, not replace, upstream pinned-page replay.

``candidate_sources`` and ``task_sources`` give the local S1/S2 provenance map.
``legacy_units`` additionally describes reference-only units and skipped units.
Legacy mapping keys have the ordinary redaction three-tuple/task two-tuple shape,
but use the unit's branch/id rather than manufacturing readings or atoms. Its
whole-query verdicts are not comparable to proposition-level scores. Main and
marker-adapted references must be reported separately, not pooled as extra ranks.
"""
from copy import deepcopy
from datetime import date
import json
import re

from . import assessment_v2 as previous
from .contracts import MASK, public_case
from .io import digest


VERSION = "source-complete-assessment-packets/3"
PROMPT = previous.PROMPT
SCHEMA = previous.SCHEMA

LEGACY_LIMITATION = (
    "Original engines with an eligible-source adapter, not the original source "
    "representation or an identical-graph baseline. Whole-query decision references "
    "are not atomic-verdict or per-reading rank units. Keep native and marker-adapted "
    "variants separate. Native terminology can reveal a method despite hidden labels."
)
_FIELDS = ("canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256")
_VERDICT_FIELDS = ("target_id", "task_execution_status", "localization_status", "semantic_status",
                   "reconstructability_status", "selected_value_or_text")


def _reference_grades(packet, result):
    references = {i["id"] for i in packet["items"] if i["kind"] == "native_verdict_reference"}
    if any(g["id"] in references and g["answer_match"] != "not_applicable" for g in result["grades"]):
        raise ValueError("Whole native verdict references are not redaction recovery units")


def assess(api_root, packet, *, cap=25., batch_size=20):
    """Reuse the exact v2 wire contract; reject recovery grades for reference units."""
    result = previous.assess(api_root, packet, cap=cap, batch_size=batch_size)
    _reference_grades(packet, result)
    return result


def verify_saved(api_root, packet, result):
    """Preserve v2 receipt replay and additionally enforce reference-unit semantics."""
    audit = previous.verify_saved(api_root, packet, result)
    _reference_grades(packet, result)
    return audit


def _validated_sources(sources, case=None):
    """Deduplicate literal witnesses, not identical words in different documents."""
    chosen, pages, spans = [], {}, {}
    for original in sources:
        if not isinstance(original, dict):
            raise ValueError("An assessment citation must be an object")
        source = original.get("citation", original)
        if not isinstance(source, dict) or any(k not in source for k in _FIELDS):
            raise ValueError("An assessment citation requires its complete saved source binding")
        if source is not original and any(k in original and original[k] != source[k] for k in _FIELDS):
            raise ValueError("Nested and flat citation bindings disagree")
        if any(not isinstance(source[k], str) or not source[k].strip()
               for k in ("canonical_page_id", "document_id", "date", "text", "page_sha256")):
            raise ValueError("Empty or nonliteral assessment citation")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", source["date"]):
            raise ValueError("A strict ISO citation date is required")
        date.fromisoformat(source["date"])
        if not re.fullmatch(r"[a-f0-9]{64}", source["page_sha256"]):
            raise ValueError("Invalid citation page hash")
        a, b = source["start"], source["end"]
        if type(a) is not int or type(b) is not int or not 0 <= a < b or b-a != len(source["text"]):
            raise ValueError("Citation offsets do not match its literal quotation")
        if case is not None:
            if source["document_id"] == case["document_id"] or source["date"] >= case["date"]:
                raise ValueError("Assessment source violates cutoff or whole-origin exclusion")
            if source.get("corpus", case["corpus"]) != case["corpus"]:
                raise ValueError("Assessment source belongs to another corpus")
            if source.get("permitted", True) is not True or source.get("visibility") not in {None, "earlier", "both"}:
                raise ValueError("Assessment source violates saved visibility policy")
            if case["corpus"] != "cib":
                handling = source.get("handling", [])
                handling = [handling] if isinstance(handling, str) else handling
                if not isinstance(handling, (list, tuple)):
                    raise ValueError("Invalid saved handling restrictions")
                if (source.get("classification", "CONFIDENTIAL") != "CONFIDENTIAL"
                        or any("NOFORN" in str(h).upper() for h in handling)):
                    raise ValueError("Assessment source is not eligible CONFIDENTIAL/non-NOFORN evidence")
        pid = source["canonical_page_id"]
        binding = source["document_id"], source["date"], source["page_sha256"]
        if pid in pages and pages[pid] != binding:
            raise ValueError("Conflicting bindings for one canonical page")
        pages[pid] = binding
        identity = pid, a, b
        if identity in spans:
            if spans[identity] != source["text"]:
                raise ValueError("Conflicting quotations for one source span")
            continue
        spans[identity] = source["text"]
        chosen.append(deepcopy(source))
    return chosen


def _wire_sources(sources):
    return [dict(id="S"+str(i), text=s["text"], date=s["date"]) for i,s in enumerate(sources, 1)]


def _item(value):
    value = dict(value, packet_version=VERSION)
    return dict(id="item_"+digest(value)[:24], **value)


def candidate_sources(candidate, case=None):
    """All original and saved proof/counterproof quotes; no direction filtering/cap.

    Stable source order is independent of support labels and evidence-list order.
    Returned full citations are local-only; packets project them to id/text/date.
    """
    supplied = list(candidate.get("sources", []))
    assessment = candidate.get("support_assessment", {})
    if not isinstance(assessment, dict):
        raise ValueError("Invalid saved candidate support assessment")
    for evidence in assessment.get("evidence", []):
        if not isinstance(evidence, dict) or not isinstance(evidence.get("citation"), dict):
            raise ValueError("Saved candidate proof has no citation")
        supplied.append(evidence["citation"])
    chosen = _validated_sources(supplied, case)
    return sorted(chosen, key=lambda s: (s["date"], s["document_id"], s["canonical_page_id"], s["start"], s["end"]))


def candidate_item(case, candidate):
    return _item(dict(kind="redaction_fill", assessment_unit="inserted_fill",
        candidate_fill=candidate["fill"],
        completed_sentence=case["query"].replace(case["focal_marker"], candidate["fill"]),
        sources=_wire_sources(candidate_sources(candidate, case))))


def task_sources(atom, case=None):
    """Keep v2's declared five-quote task selection; return replayable citations."""
    return _validated_sources(previous.task_sources(atom), case)


def task_item(atom, case=None):
    value = previous.task_item(atom)
    value.pop("id")
    value.update(assessment_unit="planned_atomic_verdict", sources=_wire_sources(task_sources(atom, case)))
    return _item(value)


def _legacy_sources(case, branch, engine, row_indices):
    citations = {}
    for source in branch.get("citations", []):
        cid = source["id"]
        if cid in citations and citations[cid] != source:
            raise ValueError("Conflicting native citation IDs")
        citations[cid] = source
    selected = []
    for support in branch.get("support_results", []):
        if support.get("task") == engine and type(support.get("native_evaluation_row")) is not int:
            raise ValueError("Invalid native evaluation row reference")
        if support.get("task") != engine or support.get("native_evaluation_row") not in row_indices:
            continue
        for cid in support.get("citation_ids", []):
            if cid not in citations:
                raise ValueError("Native decision references a missing saved citation")
            selected.append(citations[cid])
    return _validated_sources(selected, case)


def _legacy_focal_row(case, branch_name, branch, rows):
    """Never interpret a nearby slot's selected value as the focal answer."""
    if (len(rows) != 1 or len(list(MASK.finditer(case["query"]))) != 1
            or rows[0].get("target_id") != "R1"):
        return None
    if branch_name == "native":
        # The unadapted old parser recognizes REDACTED, not REDACTION 1/MASK.
        if case["focal_marker"].casefold() != "[redacted]":
            return None
    else:
        proof = branch.get("query_adaptation", {})
        replacement = proof.get("replacement", {})
        a = case["query"].index(case["focal_marker"])
        b = a + len(case["focal_marker"])
        transformed = case["query"][:a] + "[REDACT:R1]" + case["query"][b:]
        if (proof.get("raw_query") != case["query"] or proof.get("transformed_query") != transformed
                or replacement.get("raw_start") != a or replacement.get("raw_end") != b
                or replacement.get("raw_text") != case["focal_marker"]
                or replacement.get("transformed_start") != a
                or replacement.get("transformed_end") != a+len("[REDACT:R1]")
                or replacement.get("transformed_text") != "[REDACT:R1]"
                or rows[0].get("target_id") != "R1"):
            return None
    # Other syntax recognized by the old parser is outside public MASK's regex.
    remainder = case["query"].replace(case["focal_marker"], "")
    if re.search(r"\[\s*(?:REDACT\b|REDACT_SENT\b|REDACT_SPAN\b|R\d+\s*\])|_{3,}|\u2588+|\*{3,}|<\s*redacted\s*>", remainder, re.I):
        return None
    return 0


def legacy_units(case, result):
    """Inspect saved decisions only; no reranking, parser replay or invented fills.

    Each unit exposes item, sources, branch and metric_unit for local reporting.
    Ungradable/ambiguous units have item=None and a reason. Whole native engine
    decisions are references against the full question, not inferred atom verdicts.
    """
    units = []
    variants = [("native", result)]
    if "marker_adapted_reference" in result:
        adapted = result["marker_adapted_reference"]
        variants.append(("marker_adapted", adapted.get("result", adapted)))
    for branch_name, branch in variants:
        for engine, saved in branch.get("native_results", {}).items():
            rows = saved.get("evaluation", [])
            selected = [{k:row[k] for k in _VERDICT_FIELDS if k in row} for row in rows]
            valid = saved.get("execution_status") == "EXECUTED" and bool(selected) and all(
                row.get("semantic_status") for row in selected)
            sources = _legacy_sources(case, branch, engine, set(range(len(rows)))) if valid else []
            verdict = dict(task=engine, execution_status=saved.get("execution_status"), target_verdicts=selected)
            unit = dict(id="reference_"+branch_name+"_"+engine, branch=branch_name, engine=engine,
                metric_unit="whole_query_native_reference", comparable_to_atomic=False,
                comparable_to_per_reading_rank=False, limitation=LEGACY_LIMITATION,
                sources=sources, item=None, reason="NO_EXECUTED_SEMANTIC_VERDICT" if not valid else "SAVED_NATIVE_VERDICTS")
            if valid:
                unit["item"] = _item(dict(kind="native_verdict_reference",
                    assessment_unit=unit["metric_unit"], proposition=case["query"], query_anchor=case["query"],
                    native_verdict=json.dumps(verdict, sort_keys=True, ensure_ascii=True, allow_nan=False),
                    sources=_wire_sources(sources),
                    assessment_instruction="Assess only these saved decisions in their stated task against the full question and supplied quotations. "
                        "These are not atom-level decisions, and quotations may be document-level rather than localized. "
                        "Use answer_match=not_applicable; no fill or corpus-absence conclusion is inferred from abstention."))
            units.append(unit)
            if case["task"] != "redaction" or engine != "redaction":
                continue
            index = _legacy_focal_row(case, branch_name, branch, rows)
            fill = rows[index].get("selected_value_or_text") if index is not None else None
            fill_unit = dict(id="selected_"+branch_name+"_redaction", branch=branch_name, engine=engine,
                metric_unit="single_selected_focal_fill_reference", comparable_to_atomic=False,
                comparable_to_per_reading_rank=False, limitation=LEGACY_LIMITATION, sources=[], item=None,
                native_evaluation_row=index, reason="FOCAL_ROW_NOT_UNAMBIGUOUS" if index is None else "NO_SELECTED_FILL")
            if valid and isinstance(fill, str) and fill.strip():
                fill_sources = _legacy_sources(case, branch, engine, {index})
                fill_unit.update(item=candidate_item(case, dict(fill=fill, sources=fill_sources)),
                    sources=fill_sources, reason="ACTUAL_SAVED_SELECTED_FILL")
            units.append(fill_unit)
    return units


def prepare(case, records, reference_answer=""):
    """Return a versioned model packet and v2-shaped local condition mapping.

    Config/reading/candidate identifiers remain in mapping, never in model items.
    Legacy whole-query and single-selected-fill units require separate denominators;
    do not count a reference-verdict grade as a redaction recovery or an atom score.
    """
    case = public_case(case)
    items, mapping = {}, {}
    def bind(key, item):
        if key in mapping and mapping[key] != item["id"]:
            raise ValueError("Conflicting assessment items for one native output identity")
        items[item["id"]] = item
        mapping[key] = item["id"]
    for config, record in records.items():
        if "case" in record and public_case(record["case"]) != case:
            raise ValueError("Assessment record belongs to another public case")
        result = record["result"]
        if result.get("case_id", case["case_id"]) != case["case_id"]:
            raise ValueError("Assessment result belongs to another case")
        if "native_results" in result:
            for unit in legacy_units(case, result):
                if unit["item"] is None:
                    continue
                item = unit["item"]
                key = ((config, unit["branch"], unit["id"]) if case["task"] == "redaction"
                    else (config, unit["id"]))
                bind(key, item)
        elif case["task"] == "redaction":
            for reading in result["readings"]:
                for candidate in reading["candidates"]:
                    item = candidate_item(case, candidate)
                    bind((config, reading["reading"]["id"], candidate["id"]), item)
        else:
            for atom in result.get("atoms", []):
                item = task_item(atom, case)
                bind((config, atom["id"]), item)
    return dict(version=VERSION, task=case["task"], question=case["query"], question_date=case["date"],
        focal_marker=case["focal_marker"], reference_answer=reference_answer if case["task"] == "redaction" else "",
        items=sorted(items.values(), key=lambda i:i["id"])), mapping
