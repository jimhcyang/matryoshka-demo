"""Same eligible sources and budgets for lexical and factual-graph controls."""
from collections import defaultdict
import numpy as np
from scipy import sparse

from .contracts import public_case, searches
from .corpus import ordered
from .graph_kernel import normalize_prior, personalized_walk, transition, maximum_product_witness


def rrf(rankings, k=60):
    scores = defaultdict(float)
    for order in rankings:
        for rank, key in enumerate(dict.fromkeys(order), 1):
            scores[key] += 1 / (k + rank)
    return sorted(scores, key=lambda k: (-scores[k], str(k))), dict(scores)


def retrieve(corpus, case, plan, *, method="documents", document_budget=100, morphology=False, passage_budget=40):
    case = public_case(case)
    if method not in {"documents", "graph", "hierarchy"}:
        raise ValueError("Declare one retrieval method")
    eligible = corpus.eligible(case)
    channels = []
    priors = []
    search_texts = searches(plan, case)
    if morphology and not hasattr(corpus, "morph_bm25"):
        from .tasks import parser
        corpus.morph_bm25 = corpus.page_bm25.morphological(parser().nlp)
    index = corpus.morph_bm25 if morphology else corpus.page_bm25
    stats = index.stats(eligible.page_mask)
    for query in search_texts:
        values = index.score(query, eligible.page_mask, stats)
        order = ordered(values, corpus.page_ids)
        channels.append(dict(query=query, page_order=order, top_pages=[corpus.page_ids[i] for i in order[:5]],
            pages_scored=int(eligible.page_mask.sum()), positive_pages=len(order)))
        if method != "documents":
            priors.append(normalize_prior(eligible.node_scores(query), eligible.active))
    lexical, _ = rrf([c["page_order"] for c in channels])
    graph_order = []; node_mass = np.zeros(len(corpus.nodes)); witness = None
    if method != "documents" and priors:
        prior = normalize_prior(np.mean(priors, axis=0), eligible.active)
        labels = [corpus.hierarchy.get(n, {}).get("community_id") or "singleton:" + n for n in corpus.node_ids]
        kernel = transition(eligible.adjacency, prior, attention=1., active=eligible.active,
                            communities=labels, community_balanced=method == "hierarchy")
        walk = personalized_walk(kernel, prior)
        node_mass = walk.values
        unit_degree = np.zeros(len(corpus.nodes))
        for ui, ni in corpus.membership:
            if eligible.unit_mask[ui]:
                unit_degree[ni] += 1
        page_mass = np.zeros(len(corpus.pages))
        for ui, ni in corpus.membership:
            if eligible.unit_mask[ui] and unit_degree[ni]:
                page_mass[corpus.units[ui]["pi"]] += node_mass[ni] / unit_degree[ni]
        graph_order = ordered(page_mass, corpus.page_ids)
        nonseed = np.flatnonzero((prior == 0) & (node_mass > 0))
        if len(nonseed):
            target = min(nonseed, key=lambda i: (-node_mass[i], corpus.node_ids[i]))
            path = maximum_product_witness(kernel, prior, [target]); hops = []
            for hop in path["hops"]:
                a, b = hop["source"], hop["target"]
                evidence = [eligible.citation(e["ui"]) for e in corpus.edge_rows
                            if eligible.page_mask[e["pi"]] and {a, b} == {e["a"], e["b"]}]
                if not evidence:
                    raise ValueError("Graph hop lacks an eligible source witness")
                hops.append(dict(source=corpus.node_ids[a], target=corpus.node_ids[b],
                                 transition=hop["transition"], citations=evidence[:3]))
            witness = dict(nodes=[corpus.node_ids[i] for i in path["nodes"]], hops=hops,
                meaning="Undirected source-backed discovery, not proof of a new relation")
    combined, scores = rrf([lexical, graph_order] if graph_order else [lexical])
    doc_order = list(dict.fromkeys(corpus.pages[i]["document_id"] for i in combined))
    admitted = set(doc_order[:document_budget])
    pages = [i for i in combined if corpus.pages[i]["document_id"] in admitted]
    seen = set(pages)
    pages.extend(i for i, p in enumerate(corpus.pages) if eligible.page_mask[i] and p["document_id"] in admitted and i not in seen)
    page_ranks = {pi: rank for rank, pi in enumerate(combined, 1)}
    node_ranks = {ni: rank for rank, ni in enumerate(ordered(node_mass, corpus.node_ids), 1)}
    lexical_ranks = {pi:r for r,pi in enumerate(lexical,1)}
    graph_ranks = {pi:r for r,pi in enumerate(graph_order,1)}
    receipt = dict(method=method, text_matcher="count_preserving_spacy_lemma_BM25" if morphology else "literal_BM25",
        morphology_mapping_sha256=getattr(index, "mapping_sha256", None),
        search_queries=[{k: v for k, v in c.items() if k != "page_order"} for c in channels],
        eligible_pages=int(eligible.page_mask.sum()), eligible_nodes=int(eligible.active.sum()),
        eligible_documents=len(set(corpus.page_docs[eligible.page_mask])), document_budget=document_budget,
        documents_admitted=len(admitted), pages_admitted=len(pages), document_order=doc_order[:document_budget],
        construction_passage_budget=passage_budget, pages_admitted_are_not_all_inspected=True,
        top_sources=[dict(page_id=corpus.pages[pi]["id"], document_id=corpus.pages[pi]["document_id"],
            date=corpus.pages[pi]["date"], page_rank=page_ranks.get(pi), rrf=scores.get(pi, 0),
            lexical_rank=lexical_ranks.get(pi), graph_rank=graph_ranks.get(pi)) for pi in pages[:passage_budget]],
        graph_witness=witness, hierarchy_active=method == "hierarchy", query_only=True,
        no_generated_search_terms=True, score_interpretation="Navigation relevance, not correctness probability",
        cutoff=case["date"], whole_origin_excluded=case["document_id"], api_calls=0)
    return dict(eligible=eligible, pages=pages, page_ranks=page_ranks, node_ranks=node_ranks,
                kernel=kernel if method != "documents" and priors else None,
                prior=prior if method != "documents" and priors else None,
                page_scores=scores, node_mass=node_mass, receipt=receipt)


def candidate_route(reading, node_id):
    """Post-ranking navigation witness to a proposed node, not answer proof."""
    if reading.get("kernel") is None or not node_id:
        return None
    e = reading["eligible"]; c = e.corpus; ni = c.node_index.get(node_id)
    if ni is None or not e.active[ni]: return None
    if not hasattr(e, "route_cache"): e.route_cache = {}
    if node_id in e.route_cache: return e.route_cache[node_id]
    path = maximum_product_witness(reading["kernel"], reading["prior"], [ni])
    if not hasattr(e, "edge_witnesses"):
        e.edge_witnesses = defaultdict(list)
        for edge in c.edge_rows:
            if e.page_mask[edge["pi"]]:
                e.edge_witnesses[tuple(sorted((edge["a"],edge["b"])))].append(edge["ui"])
    hops = []
    for hop in path["hops"]:
        ids = e.edge_witnesses[tuple(sorted((hop["source"],hop["target"])))]
        if not ids: raise ValueError("Candidate route has no eligible source edge")
        hops.append(dict(source=c.node_ids[hop["source"]],target=c.node_ids[hop["target"]],
            transition=hop["transition"],citations=[e.citation(ui) for ui in ids[:3]]))
    result = dict(status="DIRECT_QUERY_NODE_MATCH" if len(path["nodes"])==1 else path["status"],
        nodes=[c.node_ids[i] for i in path["nodes"]],hops=hops,
        meaning="A maximum-product witness in the frozen discovery kernel, not a simulated trace or proof of the missing action")
    e.route_cache[node_id] = result
    return result
