"""Read-only v5 reporting and separate post-run assessment.

Publication never changes a native checkpoint, its ordering, or its verdict.
All outward-facing copies retain their compressed native checkpoint pins.
"""
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from .api_v2 import Budget
from .assessment_v5 import prepare, assess, verify_saved, attach_grades
from .io import digest, load, load_gzip, save, save_gzip, sha
from .reporting_v3 import inspection_scope, redaction_presence


VERSION = "task-directed-inspection-report/5"


def verified_run(root, directory=None):
    from .study_v5 import verified_run as verify
    return verify(Path(root).resolve(), directory)


def assessment_keys(root, manifest):
    """Keys are opened only by reporting/assessment, never by native execution."""
    from .study_v5 import load_release
    _, release = load_release(root, root / manifest["release_ref"]["path"])
    catalog_path = root / release["catalog_ref"]["path"]
    path = (catalog_path.parent / "private/evaluation_keys.json").resolve()
    if not path.is_relative_to(root):
        raise ValueError("Unbound evaluation key file")
    if not path.is_file():
        raise ValueError("Missing separate evaluation keys for this catalog")
    keys = load(path)
    if any(c["task"] == "redaction" and not keys.get(c["case_id"], {}).get("answer") for c in manifest["cases"]):
        raise ValueError("A redaction reference answer is missing")
    return keys, dict(path=str(path.relative_to(root)), sha256=sha(path), used_for_inference=False)


def bind_assessment_keys(directory, key_ref, *, execute=False):
    path = directory / "assessment_key_binding.json"
    if path.exists():
        if load(path) != key_ref:
            raise ValueError("Evaluation keys changed after assessment binding")
    elif execute:
        save(path, key_ref)


def _saved_assessment(root, path, packet):
    value = load(path)
    if value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"}) or value["packet"] != packet:
        raise ValueError("Saved assessment does not match the exact native packet")
    verify_saved(root / "data/development_v2/api", packet, value["assessment"])
    return value


def grade_run(root, directory=None, *, execute=False, cap=25.):
    root = Path(root).resolve()
    directory, manifest, grouped, _ = verified_run(root, directory)
    keys, key_ref = assessment_keys(root, manifest)
    bind_assessment_keys(directory, key_ref, execute=execute)
    items, completed = 0, 0
    for case in manifest["cases"]:
        packet, mapping = prepare(case, grouped[case["case_id"]], keys.get(case["case_id"], {}).get("answer", ""))
        items += len(packet["items"])
        path = directory / "assessments" / (case["case_id"] + ".json")
        if path.exists():
            _saved_assessment(root, path, packet)
            completed += 1
        elif execute:
            result = assess(root / "data/development_v2/api", packet, cap=cap)
            value = dict(case_id=case["case_id"], packet=packet, assessment=result, evaluation_keys_ref=key_ref,
                mapping=[dict(condition=list(k), item_id=v) for k, v in mapping.items()])
            value["sha256"] = digest(value)
            verify_saved(root / "data/development_v2/api", packet, result)
            save(path, value)
            completed += 1
        print("Assessment", completed, "/", len(manifest["cases"]), case["case_id"], flush=True)
    return dict(cases=len(grouped), unique_items=items, completed=completed, executed=execute,
        cumulative_charged_or_reserved_usd=Budget(root / "data/development_v2/api").total())


def slim(result):
    """Bound the view without dropping all evidence of an observed direction."""
    omissions = {}
    for atom in result.get("atoms", []):
        rows = atom.get("evidence", [])
        if len(rows) <= 12:
            continue
        buckets = defaultdict(list)
        for row in rows:
            buckets[row.get("status", row.get("direction", "UNSPECIFIED"))].append(row)
        chosen = []
        for depth in range(len(rows)):
            for key in sorted(buckets):
                if depth < len(buckets[key]):
                    chosen.append(buckets[key][depth])
            if len(chosen) >= 12:
                break
        atom["evidence"] = chosen[:12]
        atom["presentation_omitted_evidence"] = len(rows)-len(atom["evidence"])
    if "matching_diagnostics" in result:
        result["matching_diagnostics"] = dict(presentation="Original-engine tables remain in the pinned native checkpoint")
    result["presentation_projection"] = dict(version=VERSION, full_native_retained=True,
        evidence_selection="Round-robin over native evidence directions, up to 12 per atom", omitted_lists=omissions)


def _statistics(summary, case, record, assessed):
    result = record["result"]
    summary["cases"] += 1
    summary["runtime_seconds"] += record["runtime_seconds"]
    if record["config"] == "legacy_reference":
        summary["original_graph_paths"] += len(result.get("graph_paths", []))
        return
    decision = presentation_success(case, result, assessed=assessed)
    summary["presentation_criterion_checked"] += decision["assessed"]
    summary["presentation_criterion_met"] += decision["success"] is True
    if case["task"] == "redaction":
        rows = result.get("readings", [])
        summary["redaction_cases"] += 1
        summary["readings"] += len(rows)
        summary["displayed_candidates"] += sum(len(r["candidates"]) for r in rows)
        for row in rows:
            for candidate in row["candidates"]:
                summary["candidate_"+candidate.get("disposition", {}).get("evidence_label", "Unresolved")] += 1
        if not assessed:
            return
        summary["assessed_redaction_cases"] += 1
        for k in (1, 3, 5):
            grades = [c["assessment"] for r in rows for c in r["candidates"][:k]]
            for name, present in redaction_presence(grades).items():
                summary[name+"_at_"+str(k)] += present
        ordered, seen = [], set()
        for depth in range(5):
            for row in rows:
                if depth >= len(row["candidates"]):
                    continue
                candidate = row["candidates"][depth]
                identity = candidate.get("node_id"), candidate["fill"].casefold()
                if identity not in seen:
                    ordered.append(candidate["assessment"])
                    seen.add(identity)
        for k in (1, 3, 5):
            for name, present in redaction_presence(ordered[:k]).items():
                summary[name+"_matched_total_display_at_"+str(k)] += present
        summary["grammatical"] += sum(c["assessment"]["grammatical"] is True for r in rows for c in r["candidates"])
        summary["graded_candidates"] += sum(len(r["candidates"]) for r in rows)
    else:
        summary[case["task"]+"_native_"+result.get("status", "UNKNOWN")] += 1
        for atom in result.get("atoms", []):
            summary[case["task"]+"_atom_"+atom.get("status", "UNKNOWN")] += 1
            if "assessment" in atom:
                summary[case["task"]+"_judgment_"+atom["assessment"]["judgment"]] += 1


def presentation_success(case, result, *, assessed):
    """Declared demo-quality criterion, not a post-hoc benchmark accuracy label."""
    if case["task"] == "redaction":
        if not assessed:
            return dict(assessed=False, success=None, reason="Exact-packet answer/grammar assessment is pending")
        success = any(c["assessment"]["answer_match"] == "correct"
            and c["assessment"]["grammatical"] is True and bool(c.get("sources"))
            for r in result.get("readings", []) for c in r["candidates"][:5])
        return dict(assessed=True, success=success,
            reason="Source-grounded grammatical correct fill within one reading's first five; factual support is reported separately")
    atoms = [a for a in result.get("atoms", []) if a.get("required", True)]
    established = sum(a.get("status") == "SUPPORT" for a in atoms)
    if case["task"] == "hypothesis":
        success = result.get("status") in {"SUPPORT", "COUNTER"}
        reason = "Scoped native FOR or AGAINST verdict; missing evidence is not opposition"
    else:
        missing = len(atoms)-established
        success = bool(established) and (missing == 0 or len(atoms) >= 2 and missing == 1)
        reason = "At least one established required atom, with all or all-but-one required atoms supported; missing links remain explicit"
    return dict(assessed=True, success=success, established_atoms=established,
        required_atoms=len(atoms), reason=reason, post_run_model_validation_available=assessed)


def _immutable_gzip(path, value):
    if path.exists():
        if load_gzip(path) != value:
            raise ValueError("Immutable presentation artifact changed")
    else:
        save_gzip(path, value)


def collect_runs(root, directory=None, additional_directories=()):
    """Join disjoint completed shards, never rewrite a native run identity."""
    first = verified_run(root, directory)
    primary, manifest, grouped, binding = first
    grouped = dict(grouped)
    manifests = [manifest]
    directories = [primary]
    shared_maps = {key: dict(manifest.get(key, {})) for key in ("graph_indexes", "handling_veto_documents")}
    case_directories = {c["case_id"]: primary for c in manifest["cases"]}
    cases = list(manifest["cases"])
    for extra in additional_directories:
        path, other, records, other_binding = verified_run(root, extra)
        same = ("version", "source_binding_sha256", "code", "original_reference_code", "environment",
            "release_ref", "settings")
        if other_binding != binding or any(other.get(k) != manifest.get(k) for k in same):
            raise ValueError("Native shards do not have identical methods, plans, sources and settings")
        if set(grouped) & set(records):
            raise ValueError("Duplicate cases across native shards")
        for key, known in shared_maps.items():
            for corpus, value in other.get(key, {}).items():
                if corpus in known and known[corpus] != value:
                    raise ValueError("Native shards disagree about a corpus index or source policy")
                known[corpus] = value
        grouped.update(records)
        cases.extend(other["cases"])
        case_directories.update({c["case_id"]: path for c in other["cases"]})
        directories.append(path)
        manifests.append(other)
    combined = dict(manifest, cases=cases, **shared_maps)
    run_id = primary.name if len(directories) == 1 else "casebook_v5_"+digest([digest(m) for m in manifests])[:20]
    return primary, combined, grouped, binding, case_directories, directories, run_id


def report(root, directory=None, *, additional_directories=()):
    root = Path(root).resolve()
    primary, manifest, grouped, binding, case_directories, directories, run_id = collect_runs(root, directory, additional_directories)
    keys, key_ref = assessment_keys(root, manifest)
    for directory in directories:
        bind_assessment_keys(directory, key_ref)
    from .study_v5 import load_release
    _, planning_release = load_release(root, root / manifest["release_ref"]["path"])
    rows, summary = [], defaultdict(Counter)
    indexes, vetoes = {}, {}
    for case in manifest["cases"]:
        directory = case_directories[case["case_id"]]
        records = deepcopy(grouped[case["case_id"]])
        assessment_path = directory / "assessments" / (case["case_id"] + ".json")
        assessed = assessment_path.exists()
        if assessed:
            packet, mapping = prepare(case, records, keys.get(case["case_id"], {}).get("answer", ""))
            value = _saved_assessment(root, assessment_path, packet)
            attach_grades(case, records, mapping, value["assessment"])
        for arm, record in records.items():
            _statistics(summary[arm], case, record, assessed)
            checkpoint = directory / "cases" / (case["case_id"] + "__" + arm + ".json.gz")
            record["native_checkpoint"] = dict(path=str(checkpoint.relative_to(root)), sha256=sha(checkpoint))
            record["inspection_scope"] = inspection_scope(directory, record)
            record["assessment"] = dict(status="ASSESSED_POST_RUN" if assessed else "NOT_YET_ASSESSED",
                used_for_inference=False, independent_human_validation=False)
            if arm != "legacy_reference":
                record["presentation_criterion"] = presentation_success(case, record["result"], assessed=assessed)
            record["planning_prompts"] = []
            for receipt in record.get("plan", {}).get("receipts", []):
                request_path = root / "data/development_v2/api/requests" / (receipt["request_sha256"] + ".json")
                packet = load(request_path)
                record["planning_prompts"].append(dict(stage=receipt.get("stage", packet["stage"]),
                    model=packet["request"]["model"], prompt=packet["request"]["instructions"]))
            digest_path = directory / "analyst_digests" / (case["case_id"] + "__" + arm + ".json")
            if digest_path.exists():
                from .digest_v5 import verify_artifact
                record["analyst_digest"] = verify_artifact(root, grouped[case["case_id"]][arm], digest_path)
            else:
                record["analyst_digest"] = dict(status="PENDING_SEPARATE_POST_RUN_SUMMARY", used_for_inference=False)
            result = record["result"]
            slim(result)
            flow = result.get("flow", {})
            expanded = flow.pop("expanded", None)
            if expanded is not None:
                target = root / "web/data/flows-v5" / (directory.name+"__"+case["case_id"]+"__"+arm+"__"+digest(expanded)[:16]+".json.gz")
                _immutable_gzip(target, expanded)
                response = json.dumps(expanded, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()
                flow["expanded_ref"] = dict(path=str(target.relative_to(root)), sha256=sha(target),
                    response_sha256=hashlib.sha256(response).hexdigest())
                flow["expanded_lazy"] = True
            indexes[case["corpus"]] = record["exploration_index_ref"]
            excluded = record.get("handling_veto_documents", [])
            if case["corpus"] in vetoes and excluded != vetoes[case["corpus"]]:
                raise ValueError("Conditions disagree about source handling policy")
            vetoes[case["corpus"]] = excluded
        value = dict(case=case, configurations=records, selected_demo=True, assessment_available=assessed,
            reference_answer=keys.get(case["case_id"], {}).get("answer"),
            reference_answer_kind=keys.get(case["case_id"], {}).get("kind", "source_derived_complete_question"))
        target = root / "web/data/report-v5-cases" / (directory.name+"__"+case["case_id"]+"__"+digest(value)[:16]+".json.gz")
        _immutable_gzip(target, value)
        stub = {k: v for k, v in value.items() if k != "configurations"}
        stub["case_detail_ref"] = dict(path=str(target.relative_to(root)), sha256=sha(target))
        stub["configurations"] = {a: dict(config=a, runtime_seconds=r["runtime_seconds"], native_checkpoint=r["native_checkpoint"],
            native_run_id=r["run_id"], result=dict(status=r["result"].get("status", "SAVED_OUTPUT"))) for a, r in records.items()}
        rows.append(stub)
    complete_ids = {r["case"]["case_id"] for r in rows}
    pending = [dict(case=c, status="PENDING", selected_demo=True, assessment_available=False,
        reason="This declared question has no committed v5 execution in the selected run; no older result is substituted.",
        reference_answer=keys.get(c["case_id"], {}).get("answer"), configurations={})
        for c in planning_release["cases"] if c["case_id"] not in complete_ids]
    output = dict(version=VERSION, status="PARTIAL" if pending else "COMPLETE", run_id=run_id,
        cases=rows+pending, completed_cases=len(rows), pending_cases=len(pending), summary=dict(summary),
        native_runs=[dict(path=str(p.relative_to(root)), manifest_sha256=sha(p / "manifest.json")) for p in directories],
        unique_origin_documents=len({(c["case"]["corpus"], c["case"]["document_id"]) for c in rows+pending}),
        source_binding=binding, graph_indexes=indexes, handling_veto_documents=vetoes,
        settings=manifest["settings"], reporting_code_sha256=sha(Path(__file__)), evaluation_keys_ref=key_ref,
        api_cost_usd=Budget(root / "data/development_v2/api").total(),
        population="Outcome-informed exposed presentation cases, not a benchmark accuracy estimate",
        historical_policy="Strict earlier-only eligible evidence; whole-origin exclusion; retrospective identities and hierarchy",
        metrics="Non-additive correct/partial flags at any-reading ranks 1/3/5; matched-total-display round-robin is also reported. Different reading counts create different display budgets.",
        control_note="B/C hypothesis and reconstruction share planning and searches; repeats are consistency checks, not independent samples.",
        reference_limitation="D executes original parser, populated original extraction index, original graph and task engines behind a strict source adapter. This is not an identical historical source universe or a PPR treatment.",
        runtime_note="Sequential execution shares syntax caches; recorded times are operational, not matched cold-start benchmarks.",
        assessment_note="Local feasibility and factual support are separate from post-run model grades and the optional analyst digest. Neither graph connectivity nor a grammatical fill establishes a missing fact.")
    output["sha256"] = digest(output)
    if len(directories) == 1:
        save(primary / "inspection_report.json", output)
    else:
        archive = root / "data/inspection_v5" / (run_id+"__"+output["sha256"][:16]+".json")
        if archive.exists() and load(archive) != output:
            raise ValueError("Immutable combined presentation changed")
        if not archive.exists():
            save(archive, output)
    save(root / "web/data/report-v5.json", output)
    return dict(run_id=run_id, cases=len(rows)+len(pending), completed_cases=len(rows), pending_cases=len(pending),
        assessed=sum(c["assessment_available"] for c in rows),
        summary=dict(summary), cumulative_charged_or_reserved_usd=output["api_cost_usd"])
