"""Post-run packets for modern outputs and actual v5 original-engine units."""
import re

from . import assessment_v3 as previous
from . import reporting_v3
from .vendor.matching import clone


VERSION = "actual-original-graph-assessment-packets/5"


def focal_row(case, branch_name, branch, rows):
    proof = branch.get("query_adaptation")
    if not proof or proof.get("version") != "focal-native-marker-only/5":
        return previous._legacy_focal_row(case, branch_name, branch, rows)
    label = proof.get("native_slot_label", "")
    if not re.fullmatch(r"R[1-9]\d*", label):
        return None
    start = case["query"].index(case["focal_marker"])
    end = start+len(case["focal_marker"])
    replacement = "[REDACT:"+label+"]"
    expected = case["query"][:start]+replacement+case["query"][end:]
    source = proof.get("replacement", {})
    if (proof.get("raw_query") != case["query"] or proof.get("transformed_query") != expected
            or source.get("raw_start") != start or source.get("raw_end") != end
            or source.get("raw_text") != case["focal_marker"] or source.get("transformed_start") != start
            or source.get("transformed_end") != start+len(replacement)
            or source.get("transformed_text") != replacement):
        return None
    remainder = case["query"][:start]+case["query"][end:]
    if re.search(r"\[REDACT:"+re.escape(label)+r"\]", remainder, re.I):
        return None
    matches = [i for i, row in enumerate(rows) if row.get("target_id") == label]
    return matches[0] if len(matches) == 1 else None


_, _functions = clone(previous, dict(_legacy_focal_row=focal_row, VERSION=VERSION))
prepare = _functions["prepare"]
legacy_units = _functions["legacy_units"]
assess = previous.assess
verify_saved = previous.verify_saved
_, _report_functions = clone(reporting_v3, dict(legacy_units=legacy_units))
attach_grades = _report_functions["attach_grades"]
