"""Matryoshka: no generated leads or keywords, source-bound local execution."""

VERSION = "demo-day/0.1"
