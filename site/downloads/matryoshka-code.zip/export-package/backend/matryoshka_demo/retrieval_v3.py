"""Shared local discovery from whole atoms and direct-context questions only."""
from collections import defaultdict
from types import SimpleNamespace

import numpy as np

from .contracts import public_case
from .corpus import ordered, words, ENGLISH_STOP_WORDS
from .io import digest
from .graph_kernel import normalize_prior, transition
from .hierarchy import HierarchyBundle, build_hierarchy, diffuse
from .retrieval import rrf
from .retrieval_v2 import node_matches
from .flow_v3 import provenance_kernel


def searches(plan, case):
    """No generated keyword arrays, including from older cached planner output."""
    rows = [dict(id="visible_context", kind="context", query=case["query"],
        reason="The whole source-faithful visible question; not a generated keyword list")]
    for atom in plan.get("atoms", []):
        rows.append(dict(id=atom["id"], kind="atom", query=atom["text"], atom_ids=[atom["id"]]))
    for lead in plan.get("leads", []):
        if lead.get("question"):
            rows.append(dict(id=lead["id"], kind="question", query=lead["question"],
                atom_ids=lead.get("atom_ids", []), reading_ids=lead.get("reading_ids", [])))
    unique = {}
    for row in rows:
        # BM25 ignores query word order and repeated query terms. Share an
        # identical lexical search without merging its semantic task atoms.
        key = tuple(sorted(set(words(row["query"]))))
        if key in unique:
            unique[key].setdefault("also_serves", []).append(dict(row))
        else:
            unique[key] = row
    return list(unique.values())


def retrieve(corpus, case, plan, *, document_budget=100, passage_budget=100,
             hierarchy=True, graph=True, document_states=False):
    if any(type(v) is not int or v < 1 for v in (document_budget, passage_budget)):
        raise ValueError("Positive integer source budgets required")
    case = public_case(case)
    eligible = corpus.eligible(case)
    families = defaultdict(list)
    priors = defaultdict(list)
    executed = []
    page_query_scores = []
    for row in searches(plan, case):
        page_values = corpus.page_bm25.score(row["query"], eligible.page_mask, eligible.page_stats)
        page_query_scores.append((row, page_values))
        order = ordered(page_values, corpus.page_ids)
        families[row["kind"]].append(order)
        values, seeds = node_matches(eligible, row["query"]) if graph else (np.zeros(len(corpus.nodes)), [])
        prior = normalize_prior(values, eligible.active)
        if prior.any():
            priors[row["kind"]].append((row, prior))
        executed.append(dict(row, pages_scored=int(eligible.page_mask.sum()), positive_pages=len(order),
            top_pages=[dict(page_id=corpus.page_ids[i], document_id=corpus.pages[i]["document_id"],
                bm25=float(page_values[i])) for i in order[:5]], top_nodes=seeds,
            positive_seed_nodes=int(np.count_nonzero(values))))
    lexical, lexical_scores = rrf([rrf(ranks)[0] for ranks in families.values()])
    groups = [normalize_prior(np.mean([p for _, p in rows], axis=0), eligible.active) for rows in priors.values()]
    prior = normalize_prior(np.mean(groups, axis=0), eligible.active) if groups else np.zeros(len(corpus.nodes))
    starters = []
    for rows in priors.values():
        for row, values in rows:
            starters.append(dict(id=row["id"], label=row["query"], kind=row["kind"],
                values=values / len(rows) / len(priors)))
    bundle = None
    if graph and hierarchy:
        bundle = build_hierarchy(eligible, prior)
    elif graph:
        kernel = transition(eligible.adjacency, prior, attention=0., active=eligible.active)
        edges = {(u, int(v)): dict(kind="SOURCE" if u != v else "NUMERICAL_SELF_LOOP", weight=float(w), transition=float(w))
            for u in range(len(corpus.nodes)) for v, w in zip(kernel.indices[kernel.indptr[u]:kernel.indptr[u + 1]],
                kernel.data[kernel.indptr[u]:kernel.indptr[u + 1]])}
        bundle = HierarchyBundle(kernel, prior, len(prior), list(corpus.node_ids), ["semantic"] * len(prior), edges,
            dict(version="eligible-flat/1", groups=[], retrospective_hierarchy=False))
    if bundle is not None and document_states:
        page_prior = np.zeros(len(corpus.pages))
        for pi, value in lexical_scores.items():
            page_prior[pi] = value
        bundle = provenance_kernel(eligible, bundle, page_prior)
        # Semantic starters retain exactly their actual fraction of initial mass.
        semantic_fraction = float(bundle.prior[:len(prior)].sum())
        for source in starters:
            source["values"] *= semantic_fraction
        page_component = bundle.prior.copy()
        page_component[:len(prior)] = 0
        if page_component.any():
            starters.append(dict(id="bm25_sources", label="Source documents matched to the query", kind="source", values=page_component))
    walk = diffuse(bundle) if bundle else SimpleNamespace(node_mass=np.zeros(len(corpus.nodes)), full_mass=None,
        trace=dict(status="LEXICAL_ONLY", snapshots=[], metadata={}, iterations=0))
    degree = np.zeros(len(corpus.nodes))
    for ui, ni in corpus.membership:
        if eligible.unit_mask[ui]:
            degree[ni] += 1
    mass = np.zeros(len(corpus.pages))
    if document_states and bundle:
        for pi, index in bundle.metadata["page_indices"].items():
            mass[int(pi)] = walk.full_mass[index]
    else:
        for ui, ni in corpus.membership:
            if eligible.unit_mask[ui] and degree[ni]:
                mass[corpus.units[ui]["pi"]] += walk.node_mass[ni] / degree[ni]
    graph_order = ordered(mass, corpus.page_ids)
    combined, scores = rrf([lexical, graph_order])
    documents = list(dict.fromkeys(corpus.pages[i]["document_id"] for i in combined))
    admitted = set(documents[:document_budget])
    pages = [i for i in combined if corpus.pages[i]["document_id"] in admitted]
    known = set(pages)
    pages.extend(i for i, page in enumerate(corpus.pages) if eligible.page_mask[i]
        and page["document_id"] in admitted and i not in known)
    page_ranks = {p: i for i, p in enumerate(combined, 1)}
    node_ranks = {n: i for i, n in enumerate(ordered(walk.node_mass, corpus.node_ids), 1)}
    by_page = defaultdict(list)
    for ui, unit in enumerate(corpus.units):
        if eligible.unit_mask[ui]:
            by_page[unit["pi"]].append(ui)
    visible_terms = set(words(case["query"])) - set(ENGLISH_STOP_WORDS)
    seeded_documents, seen_documents = [], set()
    for pi in lexical:
        page = corpus.pages[pi]
        if page["document_id"] in seen_documents:
            continue
        seen_documents.add(page["document_id"])
        units = by_page.get(pi, [])
        if units:
            ui = min(units, key=lambda j: (-len(visible_terms & set(words(page["text"][corpus.units[j]["start"]:corpus.units[j]["end"]]))), j))
            proof = eligible.citation(ui)
        else:
            proof = dict(id="lexical_" + digest(page["id"])[:20], canonical_page_id=page["id"],
                document_id=page["document_id"], date=page["date"], start=0, end=len(page["text"]), text=page["text"],
                page_sha256=page["source_sha256"], earlier_page=page.get("earlier_page"))
        hits = [dict(search_id=q["id"], query=q["query"], bm25=float(values[pi]))
            for q, values in page_query_scores if values[pi] > 0]
        seeded_documents.append(dict(document_id=page["document_id"], page_id=page["id"], date=page["date"],
            citation=proof, lexical_rrf=lexical_scores[pi], lexical_rank=len(seeded_documents) + 1,
            matched_searches=hits, query=hits[0]["query"] if hits else "Combined visible-context and atom searches",
            meaning="Direct lexical discovery with a source-attested excerpt; not a support judgment"))
        if len(seeded_documents) == 20:
            break
    receipt = dict(method="typed_provenance_control" if document_states else "integrated_hierarchy_graph_v3" if hierarchy else "flat_graph_v3",
        text_matcher="BM25", search_queries=executed, eligible_pages=int(eligible.page_mask.sum()),
        eligible_documents=len(set(corpus.page_docs[eligible.page_mask])), eligible_nodes=int(eligible.active.sum()),
        document_budget=document_budget, construction_passage_budget=passage_budget,
        documents_admitted=len(admitted), pages_admitted=len(pages), document_order=documents[:document_budget],
        top_sources=[dict(page_id=corpus.pages[pi]["id"], document_id=corpus.pages[pi]["document_id"],
            date=corpus.pages[pi]["date"], page_rank=page_ranks.get(pi), rrf=scores.get(pi, 0)) for pi in pages[:passage_budget]],
        seeded_documents=seeded_documents, seeded_document_display_limit=20,
        hierarchy_active=bool(hierarchy and graph), diffusion=walk.trace, query_only=True,
        generated_leads=bool(plan.get("leads")), cutoff=case["date"], whole_origin_excluded=case["document_id"],
        source_page_policy="Actual typed states" if document_states else "Source provenance readout, not graph transitions",
        query_fusion="RRF k=60 within search family, then across families; equal normalized prior families",
        score_interpretation="Retrieval influence, not factual support or correctness probability", api_calls=0)
    return dict(eligible=eligible, pages=pages, page_ranks=page_ranks, node_ranks=node_ranks,
        kernel=bundle.kernel if bundle else None, prior=bundle.prior if bundle else prior,
        page_scores=scores, node_mass=walk.node_mass, receipt=receipt, hierarchy_bundle=bundle,
        _full_mass=walk.full_mass, _starter_priors=starters)
