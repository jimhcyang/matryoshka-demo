"""Read-only handling reconciliation for cable evidence; never rewrite metadata."""
import re

import numpy as np

from .corpus import Eligible


VERSION = "strict-cable-internal-handling-veto/5"


class PolicyView:
    def __init__(self, original):
        self.original = original
        self.excluded_documents = sorted({p["document_id"] for p in original.pages
            if original.corpus in {"iran", "vietnam"} and re.search(r"\bNOFORN\b", p["text"], re.I)})
        excluded = set(self.excluded_documents)
        self.allowed = np.asarray(original.allowed, dtype=bool).copy()
        self.allowed &= np.array([p["document_id"] not in excluded for p in original.pages])

    def __getattr__(self, key):
        return getattr(self.original, key)

    def eligible(self, case):
        if case["corpus"] != self.corpus:
            raise ValueError("Question belongs to a different corpus")
        return Eligible(self, case)


def policy_view(corpus):
    return corpus if isinstance(corpus, PolicyView) else PolicyView(corpus)


def scoped_page_view(db, excluded_documents):
    """A temporary in-memory view; the immutable SQLite index stays unchanged."""
    db.execute("CREATE TEMP TABLE handling_veto(doc TEXT PRIMARY KEY)")
    db.executemany("INSERT INTO handling_veto VALUES(?)", [(d,) for d in sorted(set(excluded_documents))])
    db.execute("CREATE TEMP VIEW page AS SELECT p.* FROM main.page p WHERE NOT EXISTS "
        "(SELECT 1 FROM handling_veto v WHERE v.doc=p.doc)")
