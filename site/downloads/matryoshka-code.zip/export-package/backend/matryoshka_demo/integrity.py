"""Fail-closed source, condition and saved-artifact validation."""
from pathlib import Path

from .contracts import validate
from .io import digest, load, load_gzip, sha


def verify_sources(workspace, binding, corpora=None):
    if digest({k:v for k,v in binding.items() if k != "sha256"}) != binding["sha256"]:
        raise ValueError("Binding manifest changed")
    workspace=Path(workspace).resolve()
    for name in corpora or binding["corpora"]:
        for key, record in binding["corpora"][name]["files"].items():
            path=(workspace/record["path"]).resolve()
            if not path.is_relative_to(workspace) or sha(path) != record["sha256"]:
                raise ValueError(f"Corpus artifact changed: {name}/{key}")


def verify_condition(payload, case, config, run_id, binding_sha256):
    if (payload["case"] != case or payload["config"] != config
            or payload["run_id"] != run_id or payload["binding_sha256"] != binding_sha256
            or payload.get("inference_network_access") is not False):
        raise ValueError("Checkpoint does not belong to the expected condition")
    validate(payload["plan"], case)


def source_objects(value):
    if isinstance(value,dict):
        required={"canonical_page_id","document_id","date","text","start","end","page_sha256"}
        if {"canonical_page_id","document_id","date","text"}<=value.keys() and "source_sha256" not in value and not required<=value.keys():
            raise ValueError("Malformed citation: required source fields missing")
        if required <= value.keys():
            yield value
        for child in value.values(): yield from source_objects(child)
    elif isinstance(value,(list,tuple)):
        for child in value: yield from source_objects(child)


def verify_auxiliary(directory, payload, source_cache=None):
    """Replay saved sources and proposal pools, including on exact resume."""
    directory=Path(directory).resolve(); case=payload["case"]
    cache=source_cache if source_cache is not None else {}
    def page(pid):
        path=(directory/"sources"/(pid+".json")).resolve()
        if not path.is_relative_to(directory/"sources"):
            raise ValueError("Source path escapes the run")
        if path not in cache:
            value=load(path)
            if value["id"] != pid or digest(value["text"]) != value["source_sha256"]:
                raise ValueError("Saved source content changed")
            cache[path]=value
        value=cache[path]
        if (not value["permitted"] or value["corpus"] != case["corpus"]
                or value["document_id"] == case["document_id"] or value["date"] >= case["date"]):
            raise ValueError("Saved source violates eligibility")
        return value
    def replay(value):
        for source in source_objects(value):
            p=page(source["canonical_page_id"]); a,b=source["start"],source["end"]
            if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(p["text"])
                    or p["document_id"] != source["document_id"] or p["date"] != source["date"]
                    or p["source_sha256"] != source["page_sha256"] or p["text"][a:b] != source["text"]):
                raise ValueError("Saved citation does not replay")
    replay(payload["result"])
    reference=payload["result"].get("candidate_audit_ref")
    if not reference: return
    path=(directory/reference["path"]).resolve()
    if not path.is_relative_to(directory/"candidate_audits") or sha(path) != reference["sha256"]:
        raise ValueError("Saved candidate audit changed")
    audit=load_gzip(path)
    if audit["keys_read"] or audit["grades_read"]:
        raise ValueError("Private evaluation inputs were accessed")
    replay(audit)
    for pid in audit["inspected_page_ids"]: page(pid)
    for reading in audit["readings"]:
        for proposal in reading["proposals"]:
            p=page(proposal["sources"][0]["canonical_page_id"]); a,b=proposal["source_span"]
            if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(p["text"])
                    or p["text"][a:b] != proposal["source_wording"]):
                raise ValueError("Saved construction span does not replay")
