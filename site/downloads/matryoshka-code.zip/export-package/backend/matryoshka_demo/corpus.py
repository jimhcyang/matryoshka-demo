"""Read-only adapters over existing published graphs and exact source witnesses."""
from __future__ import annotations

from collections import Counter, defaultdict
from datetime import date
from functools import lru_cache
import hashlib
from pathlib import Path
import re

import numpy as np
from scipy import sparse
from sklearn.feature_extraction.text import CountVectorizer, ENGLISH_STOP_WORDS

from .contracts import MASK
from .io import digest, load, rows, save, sha


def words(text):
    return re.findall(r"[a-z0-9]+", MASK.sub(" ", text).casefold())


def locate(text, quote):
    """Whitespace-only normalization with a reversible exact source interval."""
    at = text.find(quote)
    if at >= 0:
        return at, at + len(quote)
    pattern = r"\s+".join(re.escape(x) for x in quote.split())
    found = re.search(pattern, text) if pattern else None
    return (found.start(), found.end()) if found else None


def stable(prefix, value):
    return prefix + "_" + hashlib.sha256(value.encode()).hexdigest()[:20]


class BM25:
    def __init__(self, texts):
        vectorizer = CountVectorizer(analyzer=words, dtype=np.float64)
        try:
            self.matrix = vectorizer.fit_transform(texts).tocsr()
            self.vocabulary = vectorizer.vocabulary_
        except ValueError:
            self.matrix = sparse.csr_matrix((len(texts), 0)); self.vocabulary = {}
        self.postings = self.matrix.tocsc()
        self.lengths = np.asarray(self.matrix.sum(axis=1)).ravel()

    def morphological(self, parse):
        """Context-free local lemmas; remap columns without changing token mass."""
        terms = sorted(self.vocabulary, key=self.vocabulary.get)
        normalized = []
        for doc in parse.pipe(terms, batch_size=512, disable=["parser", "ner"]):
            normalized.append(" ".join(t.lemma_.casefold() for t in doc) or doc.text)
        vocab = {w: i for i, w in enumerate(sorted(set(normalized)))}
        mapping = sparse.coo_matrix((np.ones(len(terms)),
            (np.arange(len(terms)), [vocab[w] for w in normalized])), shape=(len(terms), len(vocab))).tocsr()
        result = object.__new__(BM25)
        result.matrix = (self.matrix @ mapping).tocsr(); result.postings = result.matrix.tocsc()
        result.vocabulary = vocab; result.lengths = self.lengths.copy()
        lookup = dict(zip(terms, normalized))
        @lru_cache(maxsize=4096)
        def normalize_word(word):
            if word in lookup: return lookup[word]
            # Query normalization must not depend on whether a spelling is
            # present only in a future, excluded or SECRET document.
            doc = next(parse.pipe([word], batch_size=1, disable=["parser", "ner"]))
            return " ".join(t.lemma_.casefold() for t in doc) or word
        result.analyze = lambda text: [normalize_word(w) for w in words(text)]
        result.mapping_sha256 = digest(lookup)
        if not np.array_equal(np.asarray(result.matrix.sum(axis=1)).ravel(), self.lengths):
            raise ValueError("Morphological control changed source token counts")
        return result

    def stats(self, mask):
        n = int(mask.sum())
        return n, np.asarray(self.matrix[mask].getnnz(axis=0)).ravel(), float(self.lengths[mask].sum()) / max(n, 1)

    def score(self, query, mask, stats=None):
        n, df, average = stats or self.stats(mask)
        result = np.zeros(len(mask))
        for word in sorted(set(getattr(self, "analyze", words)(query))):
            col = self.vocabulary.get(word)
            if col is None or not n:
                continue
            a, b = self.postings.indptr[col:col+2]
            idx = self.postings.indices[a:b]; tf = self.postings.data[a:b]
            keep = mask[idx]; idx, tf = idx[keep], tf[keep]
            idf = np.log1p((n - df[col] + .5) / (df[col] + .5))
            result[idx] += idf * tf * 2.2 / (tf + 1.2 * (.25 + .75 * self.lengths[idx] / max(average, 1e-12)))
        return result


def ordered(values, ids):
    return sorted(np.flatnonzero(values > 0), key=lambda i: (-float(values[i]), ids[i]))


def discover(workspace, destination):
    """Pin completed published artifacts, not mutable or in-progress latest runs."""
    workspace = Path(workspace).resolve()
    result = dict(version="demo-corpus-bindings/1", corpora={})
    for corpus in ("cib", "iran", "vietnam"):
        root = workspace / "src-redaction/data"
        if corpus == "cib":
            binding = load(workspace / "src/demo/iran_site_visit/web/data/cib_refresh_binding.json")
            prepared = workspace / binding["prepared_source_root"]
            graph = root / "preparation_refresh/graph/runs" / binding["graph_run_id"]
            hierarchy = root / "preparation_refresh/hierarchy/runs" / binding["hierarchy_run_id"]
            projection = None
        else:
            root /= "corpora/" + corpus
            prepared = root / "prepared"
            pointer = load(root / "classification_projection/latest.json")
            projection = Path(pointer["run_directory"]) / "summary.json"
            info = load(projection)
            graph = Path(info["graph_runs"]["confidential"])
            hierarchy = Path(info["hierarchy_run"])
        summary = load(graph / "summary.json")
        semantic = Path(summary["semantic_run_directory"])
        aliases = Path(summary["alias_run_directory"])
        paths = dict(documents=prepared / "documents.jsonl",
            pages=prepared / ("canonical_pages.jsonl" if corpus == "cib" else "source_segments.jsonl"),
            graph=graph / "summary.json", nodes=graph / "views/earlier/semantic_nodes.jsonl",
            edges=graph / "views/earlier/semantic_edge_evidence.jsonl",
            hierarchy=hierarchy / "views/earlier/node_assignments.jsonl",
            assignments=aliases / "mention_assignments.jsonl",
            entities=semantic / "ledgers/entity_mentions.jsonl",
            events=semantic / "ledgers/event_mentions.jsonl", claims=semantic / "ledgers/claim_mentions.jsonl",
            relations=semantic / "ledgers/relation_evidence.jsonl")
        if projection:
            paths["projection"] = projection
        if corpus == "cib":
            policy = workspace / "matryoshka_redaction/data/preflight_v3/source/quarantine_policy.json"
            if policy.exists():
                paths["source_policy"] = policy
        if summary["status"] != "PASS":
            raise ValueError("Only a completed graph may be bound")
        record = dict(corpus=corpus, evidence_policy="paired_earlier" if corpus == "cib" else "confidential_only",
            graph_id=graph.name, hierarchy_id=hierarchy.name,
            extraction_contract=summary.get("source_fingerprint", {}).get("semantic_contract_version"),
            identity_policy="source_only" if corpus == "cib" else "existing_retrospective_aliases",
            retrospective_identities_and_hierarchy=True,
            files={k: dict(path=str(p.resolve().relative_to(workspace)), sha256=sha(p)) for k, p in paths.items()})
        result["corpora"][corpus] = record
    result["sha256"] = digest(result)
    if Path(destination).exists() and load(destination) != result:
        raise ValueError("A pinned corpus binding changed; create a new binding file")
    save(destination, result)
    return result


class Corpus:
    def __init__(self, workspace, binding):
        self.workspace = Path(workspace).resolve(); self.binding = binding
        self.corpus = binding["corpus"]
        self.files = {k: self.workspace / v["path"] for k, v in binding["files"].items()}
        for key, path in self.files.items():
            if not path.resolve().is_relative_to(self.workspace) or sha(path) != binding["files"][key]["sha256"]:
                raise ValueError("Corpus artifact changed: " + key)
        self.documents = {r["document_id"]: r for r in rows(self.files["documents"])}
        self.classification = load(self.files["projection"])["document_metadata"] if "projection" in self.files else {}
        self.pages = []
        quarantined = set()
        if "source_policy" in self.files:
            policy = load(self.files["source_policy"])
            if binding["files"]["pages"]["sha256"] not in policy["source_pins"].values():
                raise ValueError("Source exclusion policy belongs to different prepared pages")
            quarantined = {r["canonical_page_id"] for r in policy["quarantined_pages"] + policy["quarantined_jobs"]}
        for r in rows(self.files["pages"]):
            doc = self.documents.get(r["document_id"], {})
            when = doc.get("document_date_iso") or doc.get("date_iso")
            if not when:
                continue
            date.fromisoformat(when)
            if self.corpus == "cib":
                if r.get("projection_status") != "ready":
                    continue
                text = "".join(u.get("text", "") if u.get("unit_type") == "shared_text" else " [REDACTION] " for u in r["units"]).strip()
                pid = r["canonical_page_id"]; page = r.get("earlier_source_page")
            else:
                text = r["text"]; pid = r["segment_id"]; page = r["segment_sequence"]
            meta = self.classification.get(r["document_id"], {})
            permitted = (self.corpus == "cib" or (meta.get("policy_role") == "confidential_evidence"
                and meta.get("classification") == "CONFIDENTIAL"
                and not any("NOFORN" in str(h).upper() for h in meta.get("handling",[])))) and pid not in quarantined
            self.pages.append(dict(id=pid, canonical_page_id=pid, document_id=r["document_id"], date=when,
                text=text, earlier_page=page, corpus=self.corpus, permitted=permitted,
                classification=meta.get("classification"), visibility="both", source_sha256=digest(text)))
        self.page_index = {p["id"]: i for i, p in enumerate(self.pages)}
        self.page_ids = [p["id"] for p in self.pages]
        self.page_dates = np.array([p["date"] for p in self.pages])
        self.page_docs = np.array([p["document_id"] for p in self.pages])
        self.allowed = np.array([p["permitted"] for p in self.pages])
        self.nodes = {}
        for r in rows(self.files["nodes"]):
            types = r.get("properties", {}).get("type_counts", {})
            self.nodes[r["node_id"]] = dict(id=r["node_id"], kind=r["node_type"],
                entity_type=max(types, key=types.get) if types else None)
        self.node_ids = list(self.nodes); self.node_index = {n: i for i, n in enumerate(self.node_ids)}
        self.units = []; self.unit_pages = []; self.unit_map = {}
        self.surfaces = []; self.surface_nodes = []; self.surface_pages = []
        self.occurrences = []; self.occurrences_by_page = defaultdict(list); self.occurrences_by_node = defaultdict(list)
        self.rejections = Counter()
        assignments = {r["mention_id"]: r["canonical_entity_id"] for r in rows(self.files["assignments"])}
        for field, identity, prefix in (("entities", "mention_id", None), ("events", "event_mention_id", "event"), ("claims", "claim_mention_id", "claim")):
            for r in rows(self.files[field]):
                nid = assignments.get(r[identity]) if prefix is None else stable(prefix, r[identity])
                if nid not in self.node_index or r.get("visibility") != "both" or r.get("introduced_by_slot_id"):
                    continue
                pi = self.page_index.get(r.get("canonical_page_id"))
                if pi is None or not self.pages[pi]["permitted"]:
                    continue
                page = self.pages[pi]
                quote = r.get("evidence_quote", "")
                interval = locate(page["text"], quote)
                if not interval or MASK.search(quote) or r.get("document_id") != page["document_id"] or r.get("document_date_iso") != page["date"]:
                    self.rejections["ungrounded_mention"] += 1; continue
                quote = page["text"][slice(*interval)]
                label = r.get("label") or r.get("claim_text") or quote
                terms = set(words(quote))
                source_label = " ".join(w for w in words(label) if w in terms)
                ni = self.node_index[nid]
                ui = self.add_unit(pi, quote, interval, [ni])
                self.surfaces.append(source_label or quote); self.surface_nodes.append(ni); self.surface_pages.append(pi)
                occurrence = dict(node_id=nid, page_index=pi, unit_index=ui,
                    label=r.get("label") or r.get("claim_text") or quote,
                    entity_type=r.get("type"), start=interval[0], end=interval[1],
                    source_type=field, source_row_id=r[identity])
                self.occurrences_by_page[pi].append(len(self.occurrences))
                self.occurrences_by_node[nid].append(len(self.occurrences)); self.occurrences.append(occurrence)
        del assignments
        self.edge_rows = []
        mapped = {r["relation_evidence_id"]: r for r in rows(self.files["edges"])}
        for r in rows(self.files["relations"]):
            edge = mapped.get(r["relation_evidence_id"])
            if not edge:
                continue
            pi = self.page_index.get(r.get("canonical_page_id"))
            if pi is None or not self.pages[pi]["permitted"] or r.get("visibility") != "both" or r.get("introduced_by_slot_id"):
                continue
            page = self.pages[pi]; quote = r.get("evidence_quote", "")
            interval = locate(page["text"], quote)
            if (not interval or MASK.search(quote) or r.get("document_id") != page["document_id"]
                    or r.get("document_date_iso") != page["date"] or edge.get("job_id") != r.get("job_id")
                    or edge.get("document_id") != r["document_id"] or edge.get("relation_type") != r["relation"]
                    or edge.get("canonical_page_id") != r.get("canonical_page_id")):
                self.rejections["ungrounded_relation"] += 1; continue
            a, b = self.node_index.get(edge["source_id"]), self.node_index.get(edge["target_id"])
            if a is None or b is None or a == b:
                continue
            ui = self.add_unit(pi, page["text"][slice(*interval)], interval, [a, b])
            self.edge_rows.append(dict(a=a, b=b, pi=pi, ui=ui, source_row_id=r["relation_evidence_id"], relation=r["relation"]))
        self.unit_pages = np.asarray(self.unit_pages, dtype=int)
        self.surface_pages = np.asarray(self.surface_pages, dtype=int)
        self.surface_nodes = np.asarray(self.surface_nodes, dtype=int)
        self.membership = [(ui, ni) for ui, u in enumerate(self.units) for ni in u["nodes"]]
        self.hierarchy = {r["node_id"]: r for r in rows(self.files["hierarchy"])}
        self.page_bm25 = BM25([p["text"] for p in self.pages]); self.node_bm25 = BM25(self.surfaces)
        self.counts = dict(pages=len(self.pages), nodes=len(self.nodes), units=len(self.units),
                           relations=len(self.edge_rows), rejected=dict(self.rejections))

    def add_unit(self, pi, quote, interval, nodes):
        key = pi, interval
        if key in self.unit_map:
            ui = self.unit_map[key]; self.units[ui]["nodes"].update(nodes); return ui
        ui = len(self.units); self.unit_map[key] = ui
        self.units.append(dict(id="quote_" + digest([self.page_ids[pi], interval])[:20], pi=pi,
                              text=quote, start=interval[0], end=interval[1], nodes=set(nodes)))
        self.unit_pages.append(pi); return ui

    def eligible(self, case):
        if case["corpus"] != self.corpus:
            raise ValueError("Question belongs to a different corpus")
        return Eligible(self, case)


class Eligible:
    def __init__(self, corpus, case):
        from .source_view_policy import policy_of, source_page_allowed, validate_origin_date
        validate_origin_date(corpus, case)
        self.corpus = corpus; self.case = case
        self.source_view_policy = policy_of(corpus)
        self.page_mask = corpus.allowed & np.asarray([
            source_page_allowed(p, case, self.source_view_policy) for p in corpus.pages], dtype=bool)
        self.unit_mask = self.page_mask[corpus.unit_pages]
        self.surface_mask = self.page_mask[corpus.surface_pages]
        self.active = np.zeros(len(corpus.nodes), dtype=bool)
        self.active[corpus.surface_nodes[self.surface_mask]] = True
        support = {(min(e["a"], e["b"]), max(e["a"], e["b"]), corpus.pages[e["pi"]]["document_id"])
                   for e in corpus.edge_rows if self.page_mask[e["pi"]] and self.active[e["a"]] and self.active[e["b"]]}
        aa, bb = [], []
        for a, b, _ in sorted(support):
            aa.extend([a, b]); bb.extend([b, a])
        self.adjacency = sparse.coo_matrix((np.ones(len(aa)), (aa, bb)), shape=(len(self.active), len(self.active))).tocsr()
        self.page_stats = corpus.page_bm25.stats(self.page_mask); self.node_stats = corpus.node_bm25.stats(self.surface_mask)

    def node_scores(self, query):
        content = " ".join(w for w in words(query) if w not in ENGLISH_STOP_WORDS)
        scores = self.corpus.node_bm25.score(content, self.surface_mask, self.node_stats)
        result = np.zeros(len(self.active)); np.maximum.at(result, self.corpus.surface_nodes, scores)
        result[~self.active] = 0
        return result

    def citation(self, ui):
        from .source_view_policy import source_page_allowed
        u = self.corpus.units[ui]; p = self.corpus.pages[u["pi"]]
        if (not self.unit_mask[ui] or not source_page_allowed(p, self.case, self.source_view_policy)
                or digest(p["text"]) != p["source_sha256"]
                or p["text"][u["start"]:u["end"]] != u["text"]):
            raise ValueError("Citation is outside eligible literal source text")
        return dict(id=u["id"], document_id=p["document_id"], canonical_page_id=p["id"], date=p["date"],
                    text=u["text"], start=u["start"], end=u["end"], earlier_page=p["earlier_page"],
                    page_sha256=p["source_sha256"], corpus=self.corpus.corpus)
