"""Conservative source bindings on an isolated clone of the base executor.

    execute(case, plan, retrieval, passage_budget=100)

The primary execute returns one refined task result, with no duplicate strict
execution. execute_comparison optionally returns strict/refined diagnostic
results. The base executor is cloned into isolated globals, never patched.
Additional source frames hypothesize explicit preceding nominal antecedents
for pronouns, within one sentence or its immediately preceding sentence in
the same paragraph/page. They are candidates, not coreference certifications.

Same-predicate, same nominal object-head candidates can supply PARTIAL evidence
when descriptive qualifiers or finite/nominal proposition bindings differ.
Different predicates remain RELATED, not synonym/entailment declarations.
Names, quantities, places, dates and raw negation cannot be overridden. No
derived claim label, answer, corpus name or case-specific rule is used. Source
shortlisting/enrichment is separate and is deliberately not performed here.
"""
from __future__ import annotations

from copy import deepcopy
from types import SimpleNamespace
import re

from matryoshka_demo import task_execution_v2 as base


VERSION = "source-bound-task-binding/2.1"
__all__ = ("VERSION", "execute", "execute_comparison", "compare", "source_frames")
_PRONOUNS = {"he", "she", "it", "they"}


def _deep(phrase, field):
    return set(phrase[field]) | set().union(*(
        _deep(item["phrase"], field) for item in phrase.get("modifiers", [])))


def _core_actor(target, source):
    if target["unresolved"] or source["unresolved"]:
        return False
    if any(target[k] != source[k] for k in ("head", "quantifiers", "role_qualifiers")):
        return False
    wanted = {p["lemma"] for p in target["proofs"] if p["pos"] in {"NOUN", "PROPN", "NUM"}}
    available = {p["lemma"] for p in source["proofs"] if p["pos"] in {"NOUN", "PROPN", "NUM"}}
    # A source/query POS tag disagreement is not a name alias. Every name
    # token must still be an actual lexical anchor in the other argument.
    if not set(target["names"]) <= available or not set(source["names"]) <= wanted:
        return False
    wanted_modifiers = {p["lemma"] for p in target["proofs"] if p["pos"] == "ADJ"}
    source_modifiers = {p["lemma"] for p in source["proofs"] if p["pos"] == "ADJ"}
    if wanted_modifiers and source_modifiers and not source_modifiers <= wanted_modifiers:
        return False
    return bool(wanted) and wanted <= available


def _source_frames(text, parse):
    originals = base.matching.frames(text, parse)
    doc = parse(text)
    sentences = list(doc.sents)
    sentence_index = {s.start_char: i for i, s in enumerate(sentences)}
    tokens = {t.idx: t for t in doc}
    augmented = []
    for frame in originals:
        actors = frame["roles"].get("agent", [])
        if len(actors) != 1 or actors[0]["head"] not in _PRONOUNS or not actors[0]["unresolved"]:
            continue
        token = tokens[frame["predicate_proof"]["start"]]
        current = token.sent
        candidates = [t for t in current if t.idx < min(p["start"] for p in actors[0]["proofs"])]
        index = sentence_index[current.start_char]
        if index:
            previous = sentences[index - 1]
            between = text[previous.start_char:current.start_char]
            if not re.search(r"\n\s*\n", between) and not base.MASK.search(previous.text):
                candidates = list(previous) + candidates
        candidates = [t for t in candidates if t.pos_ in {"NOUN", "PROPN"}
                      and t.dep_ not in {"compound", "flat", "name"}]
        for nominal in candidates:
            phrase = base.matching.phrase(nominal)
            if phrase["unresolved"]:
                continue
            a = min(p["start"] for p in phrase["proofs"])
            b = max(p["end"] for p in phrase["proofs"])
            start, end = min(nominal.sent.start_char, frame["start"]), frame["end"]
            if base.MASK.search(text[start:end]):
                continue
            candidate = deepcopy(frame)
            candidate["roles"]["agent"] = [deepcopy(phrase)]
            candidate.update(start=start, end=end, quote=text[start:end],
                experimental_binding=dict(kind="SOURCE_NOMINAL_ANTECEDENT_CANDIDATE", unresolved=True,
                    named_identity_certified=False, antecedent_start=a, antecedent_end=b,
                    antecedent_quote=text[a:b], antecedent_proofs=deepcopy(phrase["proofs"]),
                    pronoun_proofs=deepcopy(actors[0]["proofs"]),
                    event_start=frame["start"], event_end=frame["end"], event_quote=frame["quote"],
                    search_scope="Preceding source nominals, same or immediately previous sentence; same paragraph/page"))
            augmented.append(candidate)
    return originals + augmented


def _object_anchor(target, source, parse):
    wanted = target["roles"].get("patient", [])
    available = source["roles"].get("patient", [])
    if not wanted:
        return True, []
    event = source.get("experimental_binding", {}).get("event_quote", source["quote"])
    words = {base.matching.lemma(t) for t in parse(event) if t.pos_ in {"NOUN", "PROPN", "ADJ", "VERB", "NUM"}}
    names = {base.matching.lemma(t) for t in parse(event) if t.pos_ == "PROPN"}
    missing = []
    for phrase in wanted:
        if not any(phrase["head"] == p["head"] for p in available):
            return False, []
        required_names = _deep(phrase, "names")
        if not required_names <= names:
            return False, []
        terms = _deep(phrase, "terms")
        topic = terms - required_names - {phrase["head"]}
        if topic and not topic & words:
            return False, []
        missing.extend(sorted(terms - words))
    return True, missing


def _experimental_compare(target, source):
    native = base._compare(target, source)
    proposed = source.get("experimental_binding")
    if native is not None and native["diagnostics"]["actor"].get("binding") == "EMBEDDED_EVENT_ACTOR_NOT_INHERITED":
        # An anaphora/nominal bridge is not a subject-control resolver.
        if proposed:
            result = deepcopy(native)
            binding = deepcopy(proposed)
            binding.update(direct_support_eligible=False, epistemic_context_only=True)
            result.update(experimental=True, experimental_binding=binding,
                          strict_direction_before_experiment=native["direction"])
            return result
        return native
    if not proposed and (native is None or native["direction"] in {"SUPPORT", "COUNTER"}):
        return native
    actors = target["roles"].get("agent", [])
    available = source["roles"].get("agent", [])
    actor_bound = bool(actors) and all(any(_core_actor(p, q) for q in available) for p in actors)
    if not actor_bound or native is None:
        return None if proposed else native
    def related(reason):
        result = deepcopy(native)
        binding = deepcopy(proposed)
        binding.update(direct_support_eligible=False, epistemic_context_only=True)
        result.update(direction="RELATED", experimental_binding=binding, experimental=True,
                      strict_direction_before_experiment=native["direction"])
        result["reasons"].append(reason)
        return result
    # Inferred bindings never establish opposing polarity or a different event.
    if target["qualifiers"]["negated"] != source["qualifiers"]["negated"]:
        return related("UNRESOLVED_BINDING_HAS_NO_EVENT_POLARITY_AUTHORITY") if proposed else native
    scope = source["qualifiers"]
    if proposed and (scope["epistemic_absence"] or any(s["negated"] for s in scope["scope"])):
        return related("EPISTEMIC_ABSENCE_OR_NEGATED_SCOPE_IDENTITY_CONTEXT_ONLY")
    diagnostics = native["diagnostics"]
    if any(diagnostics[k]["status"] == "MISMATCH" for k in ("quantity", "event_date", "location")):
        return None if proposed else native
    if target["predicate"] != source["predicate"]:
        # A possible actor link can expose an alternative source proposition,
        # but this prototype has no lexical synonym or deverbal entailment rule.
        if not proposed:
            return native
        return related("LEXICAL_PREDICATE_BRIDGE_UNRESOLVED")
    parse = base.offset_safe_parser(base.parser())
    object_bound, missing = _object_anchor(target, source, parse)
    if not object_bound:
        return None if proposed else native
    if not proposed and native["direction"] != "RELATED":
        return native
    result = deepcopy(native)
    binding = deepcopy(proposed) if proposed else dict(kind="NOMINAL_FINITE_PROPOSITION_CANDIDATE", unresolved=True)
    binding.update(missing_object_terms=missing, named_identity_certified=False,
                   missing_actor_terms=sorted(set().union(*(set(p["terms"]) for p in actors))
                                              - set().union(*(set(p["terms"]) for p in available))),
                   actor_binding="SOURCE_ATTESTED_NOMINAL_CANDIDATE",
                   proposition_binding="UNRESOLVED_QUALIFIER_OR_FINITE_CLAUSE", direct_support_eligible=False)
    result.update(direction="PARTIAL", experimental=True, experimental_binding=binding,
                  strict_direction_before_experiment=native["direction"])
    result["reasons"] = list(dict.fromkeys(result["reasons"] + [
        "SOURCE_BINDING_CANDIDATE_NOT_IDENTITY_CERTIFICATION", "PROPOSITION_BINDING_NOT_ENTAILMENT_CERTIFICATION"]))
    return result


compare = _experimental_compare
source_frames = _source_frames


def _binding_diagnostics(result):
    inferred = [e for atom in result["atoms"] for e in atom["evidence"] if e.get("experimental")]
    return dict(partial_candidates=sum(e["direction"] == "PARTIAL" for e in inferred),
        related_candidates=sum(e["direction"] == "RELATED" for e in inferred),
        experimental_evidence_ids=[e["id"] for e in inferred],
        inferred_bindings_certify_support=False, raw_source_text_rewritten=False,
        derived_claim_labels_used=False, runtime_modules_modified=False,
        unresolved_control_promoted=False)


def execute(case, plan, retrieval, passage_budget=100):
    """Run only the refined cloned executor once; return its normal task schema."""
    proxy = SimpleNamespace(**vars(base.matching))
    proxy.frames = source_frames
    _, functions = base.matching.clone(base, dict(
        matching=proxy, _compare=compare, VERSION=VERSION))
    result = functions["execute"](case, plan, retrieval, passage_budget=passage_budget)
    result["binding_diagnostics"] = _binding_diagnostics(result)
    return result


def execute_comparison(case, plan, retrieval, passage_budget=100):
    """Optional diagnostic comparison, not the primary runtime entry point."""
    strict = base.execute(case, plan, retrieval, passage_budget=passage_budget)
    refined = execute(case, plan, retrieval, passage_budget=passage_budget)
    return dict(version=VERSION, strict_baseline_result=strict, experimental_result=refined,
                binding_diagnostics=deepcopy(refined["binding_diagnostics"]), api_calls=0)
