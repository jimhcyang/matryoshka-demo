"""Task-specific local decisions over one shared source-scoped matcher."""
from collections import Counter
from functools import lru_cache

from .contracts import MASK, public_case
from .io import digest
from .vendor import matching


@lru_cache(maxsize=1)
def parser():
    import spacy
    nlp = spacy.load("en_core_web_sm")
    cached = lru_cache(maxsize=2048)(nlp)
    cached.nlp = nlp
    return cached


def target_frames(query, parse):
    frames = matching.frames(query, parse)
    frames = [f for f in frames if not any(g is not f and g["start"] == f["start"]
        and any(s["predicate"] == f["predicate"] for s in g["qualifiers"]["scope"]) for g in frames)]
    return list({digest([f["predicate"], f["roles"], f["qualifiers"], f["event_dates"]]): f for f in frames}.values())


def decide(task, atoms):
    states = [a["status"] for a in atoms]
    full = bool(states) and all(s == "SUPPORT" for s in states)
    if task == "hypothesis":
        verdict = ("MIXED" if "MIXED" in states else "COUNTER" if "COUNTER" in states else
                   "SUPPORT" if full else "PARTIAL" if any(s in {"SUPPORT", "PARTIAL"} for s in states) else "INSUFFICIENT")
    elif task == "reconstruction":
        verdict = ("CONFLICTING" if any(s in {"COUNTER", "MIXED"} for s in states) else
                   "COMPLETE" if full else "PARTIAL" if any(s in {"SUPPORT", "PARTIAL"} for s in states) else "INSUFFICIENT")
    else:
        raise ValueError("Redaction decisions concern proposed fills, not a supplied complete claim")
    return dict(task=task, status=verdict, required_atoms=len(atoms),
        covered_atoms=sum(s == "SUPPORT" for s in states), partial_atoms=states.count("PARTIAL"),
        conflicts=sum(s in {"COUNTER", "MIXED"} for s in states),
        missing_evidence_is_counterevidence=False, general_entailment_certified=False,
        scope="Inspected eligible passages, not proof of absence from the corpus")


def evaluate_claim(case, reading, *, passage_budget=40, include_derived=False):
    case = public_case(case); parse = parser(); corpus = reading["eligible"].corpus
    query = case["query"]
    frames = target_frames(query, parse)
    page_set = set(reading["pages"])
    # Rank whole, exact extraction quotations, then parse their complete source
    # sentences. Never truncate a constituent to a character/token cutoff.
    source_pages = sorted(page_set, key=lambda p: reading["page_ranks"].get(p, 10**9))[:passage_budget]
    source_frames = []
    for pi in source_pages:
        page = corpus.pages[pi]
        for f in matching.frames(page["text"], parse):
            if MASK.search(f["quote"]):
                continue
            source_frames.append((pi, f, None))
    if include_derived:
        for pi in source_pages:
            for oi in corpus.occurrences_by_page.get(pi, []):
                occurrence = corpus.occurrences[oi]
                if occurrence["source_type"] != "claims": continue
                proof = reading["eligible"].citation(occurrence["unit_index"])
                for f in matching.frames(occurrence["label"], parse):
                    source_frames.append((pi, f, proof))
    atoms = []
    for i, target in enumerate(frames, 1):
        evidence = []
        for pi, source, derived_proof in source_frames:
            result = matching.compare(target, source)
            if result is None or result["direction"] not in {"SUPPORT", "COUNTER", "PARTIAL", "RELATED"}:
                continue
            page = corpus.pages[pi]
            a, b = (derived_proof["start"], derived_proof["end"]) if derived_proof else (source["start"], source["end"])
            # A match to an inherited derived statement is an inspectable
            # clue, not independent certification of its semantic grounding.
            direction = "PARTIAL" if derived_proof and result["direction"] in {"SUPPORT", "COUNTER"} else result["direction"]
            evidence.append(dict(id="proof_" + digest([page["id"], a, b, target, direction])[:20], direction=result["direction"],
                document_id=page["document_id"], canonical_page_id=page["id"], date=page["date"],
                start=a, end=b, text=page["text"][a:b], bindings=result, page_sha256=page["source_sha256"],
                match_representation="DERIVED_KG_CLAIM" if derived_proof else "SOURCE_DEPENDENCY_FRAME",
                matched_statement=source["quote"], local_direction_before_grounding_guard=result["direction"]))
            evidence[-1]["direction"] = direction
        unique = {}
        for e in evidence:
            key = (e["canonical_page_id"], e["start"], e["end"], e["direction"])
            if key not in unique or (unique[key]["match_representation"] == "DERIVED_KG_CLAIM" and e["match_representation"] == "SOURCE_DEPENDENCY_FRAME"):
                unique[key] = e
        evidence = list(unique.values())
        directions = {e["direction"] for e in evidence}
        state = ("MIXED" if {"SUPPORT", "COUNTER"} <= directions else
                 next((s for s in ("SUPPORT", "COUNTER", "PARTIAL", "RELATED") if s in directions), "INSUFFICIENT"))
        order = {"SUPPORT": 0, "COUNTER": 0, "PARTIAL": 1, "RELATED": 2}
        evidence.sort(key=lambda e: (order[e["direction"]], -e["bindings"]["aligned_arguments"], e["date"], e["id"]))
        atoms.append(dict(id=f"A{i}", quote=target["quote"], predicate=target["predicate"],
            target_frame=target, status=state, evidence=evidence[:5], evidence_count=len(evidence),
            sensitivity="A new eligible source establishing or countering this exact scoped proposition could change its local status"))
    result = decide(case["task"], atoms)
    result.update(atoms=atoms, source_pages_inspected=len(source_pages), passage_budget=passage_budget,
        derived_statement_control=include_derived,
        source_pages_admitted=len(reading["pages"]), retrieval=reading["receipt"],
        exploratory=dict(kind="unresolved_evidence_requirements", items=[dict(atom_id=a["id"], proposition=a["quote"],
            condition=a["sensitivity"]) for a in atoms if a["status"] != "SUPPORT"],
            invented_facts=False, predictions=False), api_calls=0)
    return result
