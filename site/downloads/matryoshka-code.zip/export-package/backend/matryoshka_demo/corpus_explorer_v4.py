"""Read-only, pinned-corpus hierarchy exploration, independent of workbench cases.

Temporary in-memory catalogs support all-object search and complete hierarchy
counts without adding indexes or changing the authoritative SQLite files.
"""

from collections import OrderedDict
from contextlib import contextmanager
from datetime import date
from hashlib import sha256
import json
from pathlib import Path
import re
import sqlite3
from threading import RLock
import unicodedata
from urllib.parse import urlencode

from .exploration_v2 import verified_hash


VERSION = "bound-corpus-explorer/4"
LEVELS = ("domain", "theme", "community", "evidence")
SCOPES = ("all", "entity", "event", "claim", "evidence", "relationship",
          "domain", "theme", "community", "document", "page")
CAPS = (32, 256, 2048)
SCOPE = ("Independent exploration of the complete bound permitted evidence view, "
         "not every processed classification or release. Earlier-visible CIB and "
         "the bound permitted cable projection remain in force. No workbench "
         "origin-document exclusion or case cutoff is applied. Dates are inclusive; "
         "identities and hierarchy are retrospective, not reconstructed as of that date.")
LABEL_BASIS = "Visible member labels, ordered by source-page frequency; not a historical group name"
_LOCK = RLock()
_CACHE = OrderedDict()
_SEPARATORS = re.compile(r"[\W_]+", re.UNICODE)


def _norm(value):
    text = unicodedata.normalize("NFKD", str(value)).casefold()
    if not text.isascii():
        text = "".join(c for c in text if not unicodedata.combining(c))
    return _SEPARATORS.sub(" ", text).strip()


def _rank(text, query):
    if not query:
        return 3
    labels = text.split("\n")
    if query in labels:
        return 0
    if any(label.startswith(query) for label in labels):
        return 1
    if set(query.split()).issubset(text.split()):
        return 2
    return 3 if query in text else None


class _Labels:
    def __init__(self):
        self.values = set()

    def step(self, label):
        self.values.add(_norm(label))

    def finalize(self):
        return "\n".join(sorted(self.values))


def _text(value, name, maximum=240, optional=False):
    if optional and value is None:
        return None
    if not isinstance(value, str) or len(value) > maximum or "\x00" in value:
        raise ValueError("Invalid " + name)
    return value


def _date(value):
    if value in (None, ""):
        return None
    _text(value, "date", 10)
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise ValueError("Use an ISO date, YYYY-MM-DD")
    date.fromisoformat(value)
    return value


def _count(value, maximum=100, minimum=1):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("Invalid display or pagination limit")
    return value


def _identity(root, reference):
    root = Path(root).resolve()
    path = (root / reference["path"]).resolve()
    if not path.is_relative_to(root / "data/graph_indexes_v2") or not path.is_file():
        raise ValueError("Unbound graph index path")
    if reference.get("binding", {}).get("corpus") not in {"cib", "iran", "vietnam"}:
        raise ValueError("Unbound graph corpus")
    stat = path.stat()
    digest = verified_hash(str(path), stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino)
    if digest != reference["sha256"]:
        raise ValueError("Pinned graph index changed")
    return path, digest


def _connect(path):
    db = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, check_same_thread=False)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA temp_store=MEMORY")
    db.create_function("norm", 1, _norm, deterministic=True)
    db.create_function("match_rank", 2, _rank, deterministic=True)
    db.create_aggregate("source_labels", 1, _Labels)
    db.create_function("aggregate_id", 3, lambda level, a, b: "aggregate_" + sha256(
        json.dumps([level, a, b], separators=(",", ":")).encode()).hexdigest()[:24], deterministic=True)
    return db


class _Snapshot:
    def __init__(self, path, binding, as_of):
        self.db, self.binding, self.as_of = _connect(path), binding, as_of
        db = self.db
        dates = db.execute("SELECT min(date),max(date),count(*),count(DISTINCT doc) FROM page WHERE date!=''").fetchone()
        self.minimum_date, self.maximum_date = dates[0], dates[1]
        self.effective_date = as_of or dates[1] or "0001-01-01"
        self.bound_pages, self.bound_documents = dates[2], dates[3]
        # Only source occurrences on permitted, date-visible pages license labels
        # and memberships. Future aliases and source edges never enter catalogs.
        db.execute("CREATE TEMP TABLE visible_page AS SELECT id,doc,date FROM main.page WHERE date!='' AND date<=?", (self.effective_date,))
        db.execute("CREATE UNIQUE INDEX temp.page_id ON visible_page(id)")
        db.execute("""CREATE TEMP TABLE semantic AS
            SELECT n.id,n.kind,MIN(m.label) label,COUNT(DISTINCT m.page) page_count,
            COUNT(DISTINCT p.doc) document_count,MIN(p.date) first_date,MAX(p.date) last_date,
            json_extract(n.hierarchy,'$.domain_id') domain_id,
            json_extract(n.hierarchy,'$.theme_id') theme_id,
            json_extract(n.hierarchy,'$.community_id') community_id,
            json_extract(n.hierarchy,'$.hierarchy_status') hierarchy_status,
            source_labels(m.label) search_text,0 degree
            FROM main.node n CROSS JOIN main.mention m ON m.node=n.id CROSS JOIN visible_page p ON p.id=m.page
            GROUP BY n.id""")
        db.execute("CREATE UNIQUE INDEX temp.semantic_id ON semantic(id)")
        for field in ("domain_id", "theme_id", "community_id"):
            db.execute(f"CREATE INDEX temp.semantic_{field} ON semantic({field})")
        db.execute("""CREATE TEMP TABLE source_edge AS SELECT e.rowid row_id,e.a,e.b,e.page,e.unit,e.relation
            FROM main.edge e CROSS JOIN visible_page p ON e.page=p.id
            CROSS JOIN semantic a ON a.id=e.a CROSS JOIN semantic b ON b.id=e.b""")
        for field in ("a", "b", "page"):
            db.execute(f"CREATE INDEX temp.source_{field} ON source_edge({field})")
        db.execute("""CREATE TEMP TABLE degree AS SELECT id,count(*) n FROM
            (SELECT a id FROM source_edge UNION ALL SELECT b FROM source_edge) GROUP BY id""")
        db.execute("CREATE UNIQUE INDEX temp.degree_id ON degree(id)")
        db.execute("UPDATE semantic SET degree=COALESCE((SELECT n FROM degree WHERE degree.id=semantic.id),0)")
        db.execute("ANALYZE temp")
        db.execute("""CREATE TEMP TABLE groups(
            id TEXT PRIMARY KEY,kind TEXT,label TEXT,parent_id TEXT,domain_id TEXT,theme_id TEXT,
            member_count INTEGER,connected_member_count INTEGER,child_count INTEGER,
            page_count INTEGER,document_count INTEGER,search_text TEXT)""")
        for level in LEVELS[:3]:
            field = level + "_id"
            parent = "domain_id" if level == "theme" else "theme_id" if level == "community" else None
            child_field = {"domain": "theme_id", "theme": "community_id"}.get(level)
            rows = db.execute(f"""SELECT {field} id,MIN(domain_id) domain_id,MIN(theme_id) theme_id,
                COUNT(*) members,SUM(degree>0) connected,
                COUNT(DISTINCT {parent or 'domain_id'}) parents,
                {('COUNT(DISTINCT '+child_field+')') if child_field else 'COUNT(*)'} children
                FROM semantic WHERE {field} IS NOT NULL AND {field}!='' GROUP BY {field}""").fetchall()
            counts = {r["id"]: (r["pages"], r["documents"]) for r in db.execute(f"""SELECT n.{field} id,
                COUNT(DISTINCT p.id) pages,COUNT(DISTINCT p.doc) documents
                FROM semantic n CROSS JOIN main.mention m ON m.node=n.id CROSS JOIN visible_page p ON p.id=m.page
                WHERE n.{field} IS NOT NULL AND n.{field}!='' GROUP BY n.{field}""")}
            samples = {}
            for r in db.execute(f"""SELECT id,label FROM (SELECT {field} id,label,
                ROW_NUMBER() OVER(PARTITION BY {field} ORDER BY page_count DESC,id) rank
                FROM semantic WHERE {field} IS NOT NULL AND {field}!='') WHERE rank<=3 ORDER BY id,rank"""):
                samples.setdefault(r["id"], []).append(r["label"])
            records = []
            for row in rows:
                if parent and row["parents"] != 1:
                    raise ValueError("Pinned hierarchy has an incomplete or conflicting parent assignment")
                label = level.capitalize() + ": " + " / ".join(samples[row["id"]])
                parent_id = row[parent] if parent else None
                records.append((
                    row["id"], level, label, parent_id, row["domain_id"] if level != "domain" else row["id"],
                    row["theme_id"] if level == "community" else row["id"] if level == "theme" else None,
                    row["members"], row["connected"], row["children"], *counts[row["id"]], _norm(label + " " + row["id"])))
            db.executemany("INSERT INTO groups VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", records)
        db.execute("CREATE TEMP TABLE aggregate(id TEXT PRIMARY KEY,level TEXT,a TEXT,b TEXT,weight INTEGER,page_count INTEGER,document_count INTEGER)")
        for level in LEVELS[:3]:
            field = level + "_id"
            db.execute(f"""INSERT INTO aggregate SELECT aggregate_id(?,a.{field},b.{field}),?,a.{field},b.{field},
                COUNT(*),COUNT(DISTINCT e.page),COUNT(DISTINCT p.doc)
                FROM source_edge e CROSS JOIN semantic a ON a.id=e.a CROSS JOIN semantic b ON b.id=e.b
                CROSS JOIN visible_page p ON p.id=e.page
                WHERE a.{field} IS NOT NULL AND a.{field}!='' AND b.{field} IS NOT NULL AND b.{field}!=''
                GROUP BY a.{field},b.{field}""", (level, level))
        db.commit()

    def metadata(self):
        db = self.db
        page_counts = db.execute("SELECT count(*),count(DISTINCT doc) FROM visible_page").fetchone()
        nodes = db.execute("SELECT count(*),SUM(degree>0),SUM(community_id IS NULL OR community_id='') FROM semantic").fetchone()
        return dict(version=VERSION, corpus=self.binding["corpus"], binding=self.binding,
            scope=SCOPE, independent_of_workbench=True, retrospective_hierarchy=True,
            minimum_date=self.minimum_date, maximum_date=self.maximum_date,
            as_of=self.as_of, effective_as_of=self.effective_date,
            total_pages=self.bound_pages, total_documents=self.bound_documents,
            visible_pages=page_counts[0], visible_documents=page_counts[1], visible_nodes=nodes[0],
            connected_nodes=nodes[1] or 0, unassigned_nodes=nodes[2] or 0,
            source_evidence_rows=db.execute("SELECT count(*) FROM source_edge").fetchone()[0],
            group_counts={r[0]: r[1] for r in db.execute("SELECT kind,count(*) FROM groups GROUP BY kind")},
            node_type_counts={r[0]: r[1] for r in db.execute("SELECT kind,count(*) FROM semantic GROUP BY kind")},
            group_label_basis=LABEL_BASIS, caps=list(CAPS), search_scopes=list(SCOPES))


@contextmanager
def _snapshot(root, reference, as_of):
    as_of = _date(as_of)
    path, digest = _identity(root, reference)
    key = str(path), digest, as_of
    with _LOCK:
        snapshot = _CACHE.pop(key, None)
        if snapshot is None:
            # Bound memory to two catalogs, regardless of date-slider activity.
            while len(_CACHE) >= 2:
                _, old = _CACHE.popitem(last=False)
                old.db.close()
            snapshot = _Snapshot(path, reference["binding"], as_of)
        _CACHE[key] = snapshot
        yield snapshot


def clear_cache():
    """Release temporary catalogs; authoritative indexes remain untouched."""
    with _LOCK:
        while _CACHE:
            _, snapshot = _CACHE.popitem()
            snapshot.db.close()


def _node(row):
    return dict(id=row["id"], type=row["kind"], object_type="node", label=row["label"],
        page_count=row["page_count"], document_count=row["document_count"], source_edge_count=row["degree"],
        first_date=row["first_date"], last_date=row["last_date"],
        hierarchy={field: row[field] for field in ("domain_id", "theme_id", "community_id", "hierarchy_status")})


def _group(row):
    return dict(id=row["id"], type=row["kind"].capitalize(), object_type=row["kind"], label=row["label"],
        label_basis=LABEL_BASIS, parent_id=row["parent_id"], domain_id=row["domain_id"], theme_id=row["theme_id"],
        member_count=row["member_count"], connected_member_count=row["connected_member_count"],
        child_count=row["child_count"], page_count=row["page_count"], document_count=row["document_count"],
        membership_kind="NAVIGATION", historical_relation_certified=False)


def _trail(db, obj):
    ids = [obj.get("domain_id"), obj.get("theme_id")]
    if obj.get("object_type") == "community":
        ids.append(obj["id"])
    elif obj.get("object_type") == "node":
        h = obj["hierarchy"]
        ids = [h.get(k + "_id") for k in LEVELS[:3]]
    elif obj.get("object_type") == "domain":
        ids = [obj["id"]]
    rows = [db.execute("SELECT * FROM groups WHERE id=?", (identity,)).fetchone() for identity in dict.fromkeys(filter(None, ids))]
    return [_group(row) for row in rows if row]


def _proof(db, row, corpus):
    page_row = db.execute("SELECT id,doc,date,payload FROM main.page WHERE id=?", (row["page"],)).fetchone()
    unit = db.execute("SELECT page,start,end FROM main.unit WHERE id=?", (row["unit"],)).fetchone()
    if not page_row or not unit or unit["page"] != row["page"]:
        raise ValueError("Source edge unit/page mismatch")
    page = json.loads(page_row["payload"])
    if (page["id"] != page_row["id"] or page["document_id"] != page_row["doc"]
            or page["date"] != page_row["date"] or page["corpus"] != corpus):
        raise ValueError("Source page identity does not match the pinned row")
    a, b, text = unit["start"], unit["end"], page["text"]
    if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(text):
        raise ValueError("Invalid source quotation bounds")
    digest = sha256(json.dumps(text, ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()
    if page["source_sha256"] != digest or page.get("permitted") is not True:
        raise ValueError("Source page is changed or not permitted")
    return dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
        text=text[a:b], start=a, end=b, page_sha256=digest, earlier_page=page.get("earlier_page"),
        source_url="/api/graph-v4?" + urlencode(dict(corpus=corpus, action="source", page_id=page["id"])))


def _edge(db, row, citations=False, corpus=None):
    a = db.execute("SELECT label FROM semantic WHERE id=?", (row["a"],)).fetchone()
    b = db.execute("SELECT label FROM semantic WHERE id=?", (row["b"],)).fetchone()
    result = dict(id="source_" + str(row["row_id"]), source=row["a"], target=row["b"],
        source_label=a[0], target_label=b[0], kind="SOURCE", object_type="edge", relation=row["relation"],
        label=a[0] + " / " + row["relation"] + " / " + b[0], weight=1,
        historical_relation_certified=False)
    if citations:
        result["citations"] = [_proof(db, row, corpus)]
    return result


def _aggregate(row):
    return dict(id=row["id"], source=row["a"], target=row["b"], level=row["level"],
        kind="SOURCE_AGGREGATE", object_type="aggregate", weight=row["weight"],
        page_count=row["page_count"], document_count=row["document_count"],
        historical_relation_certified=False,
        meaning="Aggregate of source evidence rows between recorded navigation groups; not a factual group relation")


def _memberships(nodes):
    edges = []
    for node in nodes:
        if node["object_type"] == "node":
            parent = node["hierarchy"].get("community_id")
        else:
            parent = node.get("parent_id")
        if parent:
            edges.append(dict(source=parent, target=node["id"], kind="NAVIGATION",
                              meaning="Recorded membership, not a historical or factual relation"))
    return edges


def overview(root, reference, *, as_of=None):
    with _snapshot(root, reference, as_of) as snapshot:
        return snapshot.metadata()


def view(root, reference, *, level="domain", parent_id=None, node_id=None, as_of=None,
         limit=256, connected_only=True):
    if level not in LEVELS or limit not in CAPS or type(limit) is not int or type(connected_only) is not bool:
        raise ValueError("Invalid graph level, node cap, or connected filter")
    _text(parent_id, "parent ID", optional=True)
    _text(node_id, "node ID", optional=True)
    with _snapshot(root, reference, as_of) as snapshot:
        db, params, clause, trail = snapshot.db, [], "1=1", []
        if parent_id and parent_id != "unassigned":
            parent_row = db.execute("SELECT * FROM groups WHERE id=?", (parent_id,)).fetchone()
            if not parent_row:
                raise ValueError("No date-visible hierarchy parent")
            parent = _group(parent_row)
            trail = _trail(db, parent)
            expected = {"domain": "theme", "theme": "community", "community": "evidence"}[parent["object_type"]]
            if level != expected:
                raise ValueError("Hierarchy drill-down must use the recorded child level")
        if node_id:
            level = "evidence"
            focus = db.execute("SELECT * FROM semantic WHERE id=?", (node_id,)).fetchone()
            if not focus:
                raise ValueError("No date-visible source occurrence for this node")
            trail = _trail(db, _node(focus))
            clause = "(id=? OR id IN (SELECT b FROM source_edge WHERE a=? UNION SELECT a FROM source_edge WHERE b=?))"
            params = [node_id] * 3
        elif level == "evidence":
            if parent_id == "unassigned":
                clause = "(community_id IS NULL OR community_id='')"
            elif parent_id:
                clause, params = "community_id=?", [parent_id]
        else:
            clause, params = "kind=?", [level]
            if parent_id:
                clause += " AND parent_id=?"
                params.append(parent_id)
        if level == "evidence":
            if connected_only and not node_id:
                clause += " AND degree>0"
            total = db.execute("SELECT count(*) FROM semantic WHERE " + clause, params).fetchone()[0]
            order = "CASE WHEN id=? THEN 0 ELSE 1 END," if node_id else ""
            rows = db.execute("SELECT * FROM semantic WHERE " + clause + " ORDER BY " + order + "degree DESC,page_count DESC,id LIMIT ?", params + ([node_id] if node_id else []) + [limit]).fetchall()
            nodes = [_node(row) for row in rows]
        else:
            if connected_only:
                clause += " AND connected_member_count>0"
            total = db.execute("SELECT count(*) FROM groups WHERE " + clause, params).fetchone()[0]
            rows = db.execute("SELECT * FROM groups WHERE " + clause + " ORDER BY member_count DESC,id LIMIT ?", params + [limit]).fetchall()
            nodes = [_group(row) for row in rows]
        ids = [n["id"] for n in nodes]
        edges, total_edges = [], 0
        if ids:
            placeholders = ",".join("?" for _ in ids)
            table = "source_edge" if level == "evidence" else "aggregate"
            filter_sql = f"a IN ({placeholders}) AND b IN ({placeholders})"
            edge_params = ids + ids
            if node_id:
                filter_sql += " AND (a=? OR b=?)"
                edge_params += [node_id, node_id]
            if table == "aggregate":
                filter_sql += " AND level=? AND a!=b"
                edge_params.append(level)
            total_edges = db.execute(f"SELECT count(*) FROM {table} WHERE {filter_sql}", edge_params).fetchone()[0]
            order = "row_id" if table == "source_edge" else "weight DESC,id"
            edge_rows = db.execute(f"SELECT * FROM {table} WHERE {filter_sql} ORDER BY {order} LIMIT 16384", edge_params).fetchall()
            edges = [_edge(db, row) if table == "source_edge" else _aggregate(row) for row in edge_rows]
        return dict(**snapshot.metadata(), level=level, parent_id=parent_id, node_id=node_id,
            nodes=nodes, edges=edges, navigation_edges=_memberships(nodes), breadcrumbs=trail, connected_only=connected_only,
            available_nodes=total, displayed_nodes=len(nodes), omitted_nodes=total-len(nodes),
            induced_source_edges=total_edges, displayed_edges=len(edges), omitted_edges=total_edges-len(edges),
            node_cap=limit, edge_cap=16384,
            edge_meaning="SOURCE is an extracted source connection, not certified truth. SOURCE_AGGREGATE summarizes these connections; NAVIGATION memberships are not historical relations.")


def search(root, reference, *, query="", scope="entity", as_of=None, limit=30, offset=0, connected_only=True):
    _text(query, "search", 200)
    _count(limit)
    _count(offset, 10000000, 0)
    if scope not in SCOPES or type(connected_only) is not bool:
        raise ValueError("Invalid search scope")
    normalized = _norm(query)
    with _snapshot(root, reference, as_of) as snapshot:
        db, statements, params = snapshot.db, [], []
        if scope in {"all", "evidence", "entity", "event", "claim"}:
            clause = "degree>0" if connected_only else "1=1"
            params.append(normalized)
            if scope in {"entity", "event", "claim"}:
                clause += " AND lower(kind)=?"
                params.append(scope)
            statements.append("SELECT id,label,'node' object_type,match_rank(search_text,?) rank FROM semantic WHERE " + clause)
        if scope in {"all", "domain", "theme", "community"}:
            clause = "connected_member_count>0" if connected_only else "1=1"
            params.append(normalized)
            if scope != "all":
                clause += " AND kind=?"
                params.append(scope)
            statements.append("SELECT id,label,kind object_type,match_rank(search_text,?) rank FROM groups WHERE " + clause)
        if scope in {"all", "relationship"}:
            statements.append("""SELECT 'source_'||e.row_id id,a.label||' / '||e.relation||' / '||b.label label,
                'edge' object_type,match_rank(a.search_text||char(10)||b.search_text||char(10)||norm(e.relation),?) rank
                FROM source_edge e JOIN semantic a ON a.id=e.a JOIN semantic b ON b.id=e.b""")
            params.append(normalized)
        if scope in {"all", "document", "page"}:
            if scope != "page":
                statements.append("SELECT doc id,doc label,'document' object_type,match_rank(norm(doc),?) rank FROM visible_page GROUP BY doc")
                params.append(normalized)
            if scope != "document":
                statements.append("SELECT id,doc||' / '||date label,'page' object_type,match_rank(norm(doc||' '||id),?) rank FROM visible_page")
                params.append(normalized)
        base = "WITH hits AS (" + " UNION ALL ".join(statements) + ") "
        rows = db.execute(base + "SELECT *,COUNT(*) OVER() total FROM hits WHERE rank IS NOT NULL ORDER BY rank,length(label),lower(label),id,object_type LIMIT ? OFFSET ?", params+[limit,offset]).fetchall()
        total = rows[0]["total"] if rows else db.execute(base + "SELECT COUNT(*) FROM hits WHERE rank IS NOT NULL", params).fetchone()[0]
        results = []
        for row in rows:
            kind, identity = row["object_type"], row["id"]
            if kind == "node":
                item = _node(db.execute("SELECT * FROM semantic WHERE id=?", (identity,)).fetchone())
            elif kind in LEVELS[:3]:
                item = _group(db.execute("SELECT * FROM groups WHERE id=?", (identity,)).fetchone())
            elif kind == "edge":
                item = _edge(db, db.execute("SELECT * FROM source_edge WHERE row_id=?", (int(identity[7:]),)).fetchone())
            else:
                item = dict(id=identity,label=row["label"],type=kind.capitalize(),object_type=kind)
            results.append(dict(item,match_priority=row["rank"]))
        return dict(corpus=snapshot.binding["corpus"], scope=scope, query=query, as_of=as_of,
            total=total, offset=offset, limit=limit, omitted=max(0, total-offset-len(results)), results=results,
            ranking="Case/punctuation-insensitive exact, prefix, all tokens, then substring; stable label and ID ties. No embeddings or model calls.")


def inspect(root, reference, object_id, *, object_type="node", as_of=None, limit=30, offset=0):
    _text(object_id, "object ID")
    _count(limit)
    _count(offset, 10000000, 0)
    with _snapshot(root, reference, as_of) as snapshot:
        db, params, clause = snapshot.db, [], None
        if object_type in LEVELS[:3]:
            row = db.execute("SELECT * FROM groups WHERE id=? AND kind=?", (object_id, object_type)).fetchone()
            if not row:
                raise ValueError("No date-visible hierarchy object")
            obj = _group(row)
            field = object_type + "_id"
            clause, params = f"(a.{field}=? OR b.{field}=?)", [object_id, object_id]
            children = db.execute("SELECT * FROM groups WHERE parent_id=? ORDER BY member_count DESC,id LIMIT ? OFFSET ?", (object_id, limit, offset)).fetchall()
            if object_type == "community":
                children = db.execute("SELECT * FROM semantic WHERE community_id=? ORDER BY degree DESC,page_count DESC,id LIMIT ? OFFSET ?", (object_id, limit, offset)).fetchall()
            child_items = [(_node(row) if object_type == "community" else _group(row)) for row in children]
        elif object_type == "node":
            row = db.execute("SELECT * FROM semantic WHERE id=?", (object_id,)).fetchone()
            if not row:
                raise ValueError("No date-visible semantic object")
            obj = _node(row)
            clause, params, child_items = "(e.a=? OR e.b=?)", [object_id, object_id], []
        elif object_type == "edge":
            if not re.fullmatch(r"source_[1-9]\d*", object_id):
                raise ValueError("Invalid source-edge ID")
            row = db.execute("SELECT * FROM source_edge WHERE row_id=?", (int(object_id[7:]),)).fetchone()
            if not row:
                raise ValueError("No date-visible source edge")
            obj = _edge(db, row, True, snapshot.binding["corpus"])
            return dict(object=obj, citations=obj["citations"], breadcrumbs=[], edges=[], total_source_edges=1, omitted_source_edges=0,
                        binding=snapshot.binding, as_of=as_of, scope=SCOPE)
        elif object_type == "aggregate":
            row = db.execute("SELECT * FROM aggregate WHERE id=?", (object_id,)).fetchone()
            if not row:
                raise ValueError("No date-visible source aggregate")
            obj, child_items = _aggregate(row), []
            field = row["level"] + "_id"
            clause, params = f"a.{field}=? AND b.{field}=?", [row["a"], row["b"]]
        elif object_type in {"document", "page"}:
            field = "doc" if object_type == "document" else "id"
            total = db.execute(f"SELECT count(*) FROM visible_page WHERE {field}=?", (object_id,)).fetchone()[0]
            if not total:
                raise ValueError("No date-visible source object")
            rows = db.execute(f"SELECT * FROM visible_page WHERE {field}=? ORDER BY date,id LIMIT ? OFFSET ?", (object_id, limit, offset)).fetchall()
            return dict(object=dict(id=object_id, label=object_id, type=object_type.capitalize(), object_type=object_type),
                pages=[dict(canonical_page_id=r["id"], document_id=r["doc"], date=r["date"]) for r in rows],
                total_pages=total, omitted_pages=max(0,total-offset-len(rows)), offset=offset, limit=limit,
                binding=snapshot.binding, as_of=as_of, scope=SCOPE)
        else:
            raise ValueError("Invalid inspected object type")
        base = " FROM source_edge e JOIN semantic a ON a.id=e.a JOIN semantic b ON b.id=e.b WHERE " + clause
        total = db.execute("SELECT count(*)" + base, params).fetchone()[0]
        rows = db.execute("SELECT e.*" + base + " ORDER BY e.row_id LIMIT ? OFFSET ?", params+[limit, offset]).fetchall()
        edges = [_edge(db, row, True, snapshot.binding["corpus"]) for row in rows]
        page_info = {}
        if object_type == "node":
            page_rows = db.execute("""SELECT DISTINCT p.* FROM main.mention m JOIN visible_page p ON p.id=m.page
                WHERE m.node=? ORDER BY p.date,p.id LIMIT ? OFFSET ?""", (object_id,limit,offset)).fetchall()
            total_pages = db.execute("SELECT COUNT(DISTINCT m.page) FROM main.mention m JOIN visible_page p ON p.id=m.page WHERE m.node=?", (object_id,)).fetchone()[0]
            page_info = dict(pages=[dict(canonical_page_id=r["id"],document_id=r["doc"],date=r["date"]) for r in page_rows],
                             total_pages=total_pages,omitted_pages=max(0,total_pages-offset-len(page_rows)))
        return dict(object=obj, breadcrumbs=_trail(db, obj), children=child_items, edges=edges, **page_info,
            total_source_edges=total, omitted_source_edges=max(0,total-offset-len(rows)),
            offset=offset, limit=limit, binding=snapshot.binding, as_of=as_of, scope=SCOPE,
            meaning="Actual source quotations and recorded memberships, not certification of a new historical claim")


def page(root, reference, page_id, *, as_of=None):
    _text(page_id, "page ID")
    as_of = _date(as_of)
    path, _ = _identity(root, reference)
    db = _connect(path)
    try:
        row = db.execute("SELECT id,doc,date,payload FROM page WHERE id=? AND date!='' AND date<=?", (page_id, as_of or "9999-12-31")).fetchone()
        if not row:
            raise ValueError("No date-visible source page")
        result = json.loads(row["payload"])
        if (result["id"] != row["id"] or result["document_id"] != row["doc"]
                or result["date"] != row["date"] or result["corpus"] != reference["binding"]["corpus"]):
            raise ValueError("Source page identity does not match the pinned row")
        digest = sha256(json.dumps(result["text"], ensure_ascii=True, separators=(",", ":")).encode()).hexdigest()
        if result.get("permitted") is not True or digest != result["source_sha256"]:
            raise ValueError("Source page is changed or not permitted")
        return result
    finally:
        db.close()


def request(root, reference, params):
    """Server adapter for parse_qs mappings; saved-data GET operations only."""
    if set(params) & {"case_id", "exclude_doc", "cutoff", "policy_cutoff", "policy_exclude_doc"}:
        raise ValueError("Independent corpus exploration does not accept workbench case eligibility parameters")
    def value(key, default=None):
        item = params.get(key, default)
        if isinstance(item, list):
            if len(item) != 1:
                raise ValueError("Repeated request parameter")
            item = item[0]
        return item
    action, as_of = value("action", "view"), value("as_of")
    corpus = value("corpus", reference["binding"]["corpus"])
    if corpus != reference["binding"]["corpus"]:
        raise ValueError("Wrong pinned corpus")
    if action == "source":
        return page(root, reference, value("page_id"), as_of=as_of)
    if action == "overview":
        return overview(root, reference, as_of=as_of)
    if action == "inspect":
        return inspect(root, reference, value("object_id"), object_type=value("object_type", "node"),
            as_of=as_of, limit=int(value("limit", 30)), offset=int(value("offset", 0)))
    connected = value("connected_only", "true")
    if connected not in {"true", "false", "1", "0"}:
        raise ValueError("Invalid connected filter")
    connected = connected in {"true", "1"}
    if action == "search":
        return search(root, reference, query=value("query", ""), scope=value("scope", "entity"),
            as_of=as_of, limit=int(value("limit", 30)), offset=int(value("offset", 0)), connected_only=connected)
    if action == "view":
        return view(root, reference, level=value("level", "domain"), parent_id=value("parent_id"),
            node_id=value("node_id"), as_of=as_of, limit=int(value("limit", 256)), connected_only=connected)
    raise ValueError("Unknown graph action")
