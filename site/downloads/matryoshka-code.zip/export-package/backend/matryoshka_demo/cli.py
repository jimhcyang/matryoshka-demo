"""Current three-task study; paid stages require an explicit --execute flag."""
import argparse
import json
from pathlib import Path


def main(argv=None):
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--workspace", type=Path, default=root.parent)
    commands = p.add_subparsers(dest="command", required=True)
    revised = commands.add_parser("v3", help="Separately versioned four-arm prototype")
    revised.add_argument("stage", choices=("plan", "run", "grade", "report", "verify"))
    revised.add_argument("--execute", action="store_true")
    revised.add_argument("--catalog", type=Path, default=root / "experiments/palette_v3/releases/candidate_d0691e98f314a838a67b/candidate_public_catalog.json")
    revised.add_argument("--plan-release", type=Path)
    revised.add_argument("--run", type=Path)
    revised.add_argument("--case-id", action="append")
    revised.add_argument("--no-reference", action="store_true")
    revised.add_argument("--flat", action="store_true")
    revised.add_argument("--document-states", action="store_true", help="Experimental real provenance-state kernel")
    revised.add_argument("--passages", type=int, default=100)
    revised.add_argument("--documents", type=int, default=100)
    planning = commands.add_parser("plan", help="Current query planning; defaults to preview")
    planning.add_argument("--execute", action="store_true")
    planning.add_argument("--catalog", type=Path, default=root / "data/palette_v21/inference_catalog.json")
    planning.add_argument("--case-id", action="append")
    execute = commands.add_parser("run", help="Execute current frozen plans locally; no API calls")
    execute.add_argument("--execute", action="store_true")
    execute.add_argument("--plan-release", type=Path)
    execute.add_argument("--no-reference", action="store_true")
    execute.add_argument("--flat", action="store_true")
    execute.add_argument("--passages", type=int, default=100)
    execute.add_argument("--documents", type=int, default=100)
    report = commands.add_parser("report")
    report.add_argument("--run", type=Path)
    grading = commands.add_parser("grade", help="Separate post-run assessment; defaults to preview")
    grading.add_argument("--execute", action="store_true")
    grading.add_argument("--run", type=Path)
    verify = commands.add_parser("verify", help="Replay native bindings without API calls or artifact edits")
    verify.add_argument("--run", type=Path)
    serve = commands.add_parser("serve")
    serve.add_argument("--port", type=int, default=8930)
    legacy = commands.add_parser("legacy", help="Explicitly opt into archived v1 experiments")
    legacy.add_argument("stage", choices=("bind", "catalog", "compatibility", "run", "report"))
    legacy.add_argument("--configs", nargs="+")
    legacy.add_argument("--controls", action="store_true")
    legacy.add_argument("--corpus", choices=("cib", "iran", "vietnam"))
    legacy.add_argument("--limit", type=int)
    legacy.add_argument("--passages", type=int, default=100)
    legacy.add_argument("--documents", type=int, default=100)
    legacy.add_argument("--run", type=Path)
    args = p.parse_args(argv)
    if args.command == "v3":
        if args.passages < 1 or args.documents < 1:
            p.error("documents and passages must be positive")
        if args.stage == "plan":
            from .runner_v3 import prepare
            result = prepare(root, args.catalog, execute=args.execute, case_ids=args.case_id)
        elif args.stage == "run":
            if not args.execute:
                result = dict(api_calls=0, message="Add --execute for offline execution")
            else:
                from .runner_v3 import run
                result = run(root, plan_release=args.plan_release, reference=not args.no_reference,
                    hierarchy=not args.flat, document_states=args.document_states, case_ids=args.case_id,
                    document_budget=args.documents, passage_budget=args.passages)
        elif args.stage == "grade":
            from .reporting_v3 import grade_run
            result = grade_run(root, args.run, execute=args.execute)
        elif args.stage == "report":
            from .reporting_v3 import report
            result = report(root, args.run)
        else:
            from .reporting_v3 import verified_run
            directory, manifest, records, binding = verified_run(root, args.run)
            result = dict(run_id=directory.name, cases=len(records), conditions=sum(len(v) for v in records.values()),
                native_replay=True, artifacts_modified=False, api_calls=0)
    elif args.command == "plan":
        from .runner_v2 import prepare
        result = prepare(root, args.catalog, execute=args.execute, case_ids=args.case_id)
    elif args.command == "run":
        if args.documents < 1 or args.passages < 1:
            p.error("documents and passages must be positive")
        if not args.execute:
            result = dict(api_calls=0, message="Add --execute to run current frozen plans locally")
        else:
            from .runner_v2 import run
            result = run(root, plan_release=args.plan_release, reference=not args.no_reference,
                hierarchy=not args.flat, document_budget=args.documents, passage_budget=args.passages)
    elif args.command == "grade":
        from .reporting_v2 import grade_run
        result = grade_run(root, args.run, execute=args.execute)
    elif args.command == "report":
        from .reporting_v2 import report
        result = report(root, args.run)
    elif args.command == "verify":
        from .reporting_v2 import verified_run
        directory, manifest, records, binding = verified_run(root, args.run)
        result = dict(run_id=directory.name, cases=len(records),
            conditions=sum(len(rows) for rows in records.values()),
            binding_sha256=binding["sha256"], native_replay=True,
            grades_replayed=False, artifacts_modified=False, api_calls=0)
    elif args.command == "legacy":
        result = run_legacy(root, args)
    else:
        from .server import serve
        serve(root, args.workspace, args.port); return
    print(json.dumps(result, indent=2, ensure_ascii=True))


def run_legacy(root, args):
    """Archived execution is explicit, never the default run/report path."""
    if args.stage == "bind":
        from .corpus import discover
        return discover(args.workspace, root / "data/bindings.json")
    if args.stage == "catalog":
        from .catalog import build
        from .io import load
        return build(args.workspace, load(root / "data/bindings.json"), root / "data/catalog_v1")["counts"]
    if args.stage == "run":
        from .runner import run
        return run(args.workspace, root, configs=args.configs, include_controls=args.controls,
            corpus_filter=args.corpus, limit=args.limit, passage_budget=args.passages, document_budget=args.documents)
    if args.stage == "compatibility":
        from .compatibility import run
        packet = run(args.workspace, root / "data/legacy_compatibility.json")
        return dict(cases=len(packet["cases"]), source_passages=sum(c["source_passages"] for c in packet["cases"]))
    from .reporting import report
    return report(root, args.run)


if __name__ == "__main__": main()
