"""Unchanged v3 planning contract with one audited interpretation repair.

No validation rule is weakened and no source, answer or corpus hint is added.
Exact cached requests remain reusable; failed model wording remains inspectable.
"""
from copy import deepcopy

from . import planning_v3 as previous
from .io import digest
from .vendor.matching import clone


VERSION = "source-bound-planner-repair/5"
get_plans = previous.get_plans
validate_plan = previous.validate_plan
select_context = previous.select_context


def prepare(case, **kwargs):
    failures = []

    class Calls(previous._Calls):
        def call(self, name, payload, *, record_key=None):
            raw = super().call(name, payload, record_key=record_key)
            if name != "readings":
                return raw
            try:
                interpreted = previous._model_interpretation(raw, case)
                atoms = previous._validate_atoms(dict(atoms=payload["atoms"], context_incomplete=False), case)
                previous._validate_interpretation(interpreted, case, atoms)
                return raw
            except ValueError as error:
                failures.append(dict(stage="readings", error_type=type(error).__name__,
                    reason=str(error), original_output_sha256=digest(raw), attempts=1,
                    supplied_corpus_evidence=False, supplied_answer=False))
                repair = dict(payload, previous_output=deepcopy(raw), validation_error=str(error),
                    repair_instruction="Preserve the original task and visible facts. Correct only the rejected format or wording. "
                        "Copy any names exactly as written in the question, including punctuation. "
                        "Do not add a name, date, keyword list, external fact or proposed answer. "
                        "An unnecessary question may be omitted. Return the same schema.")
                return super().call(name, repair, record_key="readings_repair")

    _, functions = clone(previous, dict(_Calls=Calls))
    bundle = functions["prepare"](case, **kwargs)
    bundle["workflow_version"] = VERSION
    bundle["interpretation_retry_audit"] = failures
    return bundle
