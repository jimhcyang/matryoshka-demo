"""Local read-only v5 workbench endpoints; frozen earlier viewers stay intact."""
from functools import partial
from http.server import ThreadingHTTPServer
import json
from pathlib import Path
import sqlite3
from types import SimpleNamespace
from urllib.parse import parse_qs, unquote, urlsplit

from . import exploration_v2
from .corpus_explorer_v3 import _connection
from .corpus_policy_v5 import scoped_page_view
from .flow_projection_v5 import condition, presentation, guide, _bound_path
from .io import load_gzip
from .server import Handler as EarlierHandler
from .vendor.matching import clone


ASSETS = {"workbench-v5.html", "workbench-v5.js", "workbench-v5.css", "app-theme-v5.css",
    "flow-view-v5.js", "flow-view-v5.css", "graph-full-v5.html", "graph-full-v5.js", "graph-full-v5.css",
    "data/report-v5.json", "data/ui-release-v5.json"}
PAGE_ORDER = "CAST(COALESCE(json_extract(payload,'$.source_char_start'),json_extract(payload,'$.earlier_page'),0) AS INTEGER),id"


def source_tools(excluded):
    def connect(*args, **kwargs):
        db = sqlite3.connect(*args, **kwargs)
        scoped_page_view(db, excluded)
        return db
    _, functions = clone(exploration_v2, dict(sqlite3=SimpleNamespace(connect=connect, Row=sqlite3.Row)))
    return functions


class Handler(EarlierHandler):
    def do_GET(self):
        parsed = urlsplit(self.path)
        path = unquote(parsed.path)
        if path in {"/", "/index.html"}:
            try:
                from .ui_release_v5 import validate
                validate(self.root)
            except (OSError, ValueError, KeyError):
                self.send_error(409, "The v5 presentation has not passed publication checks")
                return
            self.path = "/workbench-v5.html"
            self.file(self.root / "web/workbench-v5.html", self.root / "web")
            return
        if path.lstrip("/") in ASSETS:
            self.file(self.root / "web" / path.lstrip("/"), self.root / "web")
            return
        if path in {"/api/condition-v5", "/api/flow-v5", "/api/source-v5", "/api/node-v5", "/api/native-v5", "/api/guide-v5"}:
            try:
                self.study_api(path, parse_qs(parsed.query))
            except (OSError, ValueError, KeyError, TypeError, IndexError):
                self.send_error(409, "No unchanged eligible v5 artifact matches this request")
            return
        super().do_GET()

    def study_api(self, path, params):
        report = self.published_report(5)
        case_id = params.get("case_id", [""])[0]
        row = next((r for r in report["cases"] if r["case"]["case_id"] == case_id), None)
        if row is None:
            raise ValueError("Unknown v5 question")
        case = row["case"]
        arm = params.get("config", ["llm_readings"])[0]
        if path == "/api/condition-v5":
            value = condition(self.root, report, case_id, arm)
        elif path == "/api/flow-v5":
            value = presentation(self.root, report, case_id, arm, reading=params.get("reading", [None])[0],
                limit=int(params.get("limit", ["1024"])[0]))
        elif path == "/api/guide-v5":
            value = guide(self.root, report, case_id, arm, params.get("candidate_id", [""])[0],
                int(params.get("route_index", ["0"])[0]), params.get("reading", [None])[0])
        elif path == "/api/native-v5":
            selected = condition(self.root, report, case_id, arm)
            saved = next(iter(selected["configurations"].values()))
            target, _ = _bound_path(self.root, saved["native_checkpoint"], "data/runs_v5")
            value = load_gzip(target)
        else:
            reference = report["graph_indexes"][case["corpus"]]
            excluded = report.get("handling_veto_documents", {}).get(case["corpus"], [])
            functions = source_tools(excluded)
            if path == "/api/node-v5":
                value = functions["neighborhood"](self.root, reference, case, params.get("node_id", [""])[0], 30)
            else:
                source_id = params.get("source_id", [""])[0]
                value = functions["source_page"](self.root, reference, case, source_id)
                db = _connection(self.root, reference)
                try:
                    scoped_page_view(db, excluded)
                    pages = [json.loads(r[0]) for r in db.execute(
                        "SELECT payload FROM page WHERE doc=? AND date<? AND doc!=? ORDER BY "
                        + PAGE_ORDER,
                        (value["document_id"], case["date"], case["document_id"]))]
                finally:
                    db.close()
                value = dict(value, document_pages=pages, source_scope="Eligible canonical text segments; not invented PDF pages")
        self.json_response(value, compress=True)


def serve(root, workspace, port=8930):
    server = ThreadingHTTPServer(("127.0.0.1", port), partial(Handler, root=Path(root), workspace=Path(workspace)))
    print(f"Matryoshka v5: http://127.0.0.1:{port}/", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
