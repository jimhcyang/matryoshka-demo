"""Versioned deterministic raw-source execution. Frozen v3 is never patched.

Analysis case changes are projected only across identical token/character maps.
Explicit copular complements and relative possessors remain source-owned roles.
Neither lexical suggestions nor generated labels acquire factual authority.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import re

from . import task_execution_v3 as frozen
from .contracts import public_case
from .io import digest

base = frozen.base
VERSION = "source-structured-task-execution/5.1"
SLOTS = frozen.SLOTS
_CACHE_LIMIT = 256


def _bounds(doc):
    return [(t.idx, len(t.text)) for t in doc]


class _AnalysisParser:
    """Private copies; bounded shared analysis cache, keyed by parser identity."""

    def __init__(self, parse=None):
        raw = base.parser() if parse is None else parse
        self.identity = frozen._ParserIdentity(raw)
        self.language = getattr(raw, "nlp", None)
        self.records = {}

    def __call__(self, text):
        doc, record = _analysis_doc(self.identity, self.language, text)
        self.records[digest(text)] = record
        return doc.copy()


@lru_cache(maxsize=_CACHE_LIMIT)
def _analysis_doc(identity, language, text):
    raw = identity.parser(text)
    if raw.text != text:
        raise ValueError("Parser changed source characters")
    # Token-local policy also handles mixed-case metadata footers. It does not
    # infer a document body boundary or delete any heading/footer characters.
    words = [t.text.lower() if t.text.isupper() else t.text for t in raw]
    record = dict(kind="TOKEN_LOCAL_UPPERCASE_ANALYSIS", raw_source_modified=False,
        original_tokenization_retained=True, proper_name_repair=False,
        changed_tokens=sum(w != t.text for w, t in zip(words, raw)))
    if not record["changed_tokens"]:
        return raw.copy(), dict(record, status="UNCHANGED")
    if any(len(w) != len(t.text) for w, t in zip(words, raw)):
        return raw.copy(), dict(record, status="CASE_EXPANSION_REJECTED")
    from spacy.tokens import Doc
    from spacy.attrs import DEP, ENT_IOB, ENT_TYPE, HEAD, LEMMA, MORPH, POS, SENT_START, TAG
    expected = list(text)
    for token, word in zip(raw, words):
        expected[token.idx:token.idx + len(token.text)] = word
    expected = "".join(expected)
    if language is not None:
        analysis = Doc(raw.vocab, words=words, spaces=[bool(t.whitespace_) for t in raw])
        if analysis.text != expected or _bounds(analysis) != _bounds(raw):
            return raw.copy(), dict(record, status="EXACT_TEXT_MAP_REJECTED")
        analysis = language(analysis)
    else:
        analysis = identity.parser(expected)
    if (analysis.text != expected or analysis.vocab is not raw.vocab
            or _bounds(analysis) != _bounds(raw)):
        return raw.copy(), dict(record, status="TOKEN_MAP_REJECTED")
    attrs = [HEAD, DEP, POS, TAG, LEMMA, MORPH, ENT_IOB, ENT_TYPE, SENT_START]
    restored = raw.copy()
    restored.from_array(attrs, analysis.to_array(attrs))
    return restored, dict(record, status="EXACT_OFFSET_PROJECTION")


def _rewrite_phrase(value, pronoun, antecedent):
    """Replace only an explicit dependency-relative possessor, recursively."""
    result = deepcopy(value)
    proofs = result["proofs"]
    if any(p["start"] == pronoun.idx for p in proofs):
        proofs = [p for p in proofs if p["start"] != pronoun.idx]
        proofs.extend(deepcopy(antecedent["proofs"]))
        result["proofs"] = sorted(proofs, key=lambda p: p["start"])
        result["text"] = " ".join(p["text"] for p in result["proofs"])
        content = [p for p in proofs if p["pos"] in {"NOUN", "PROPN", "ADJ", "NUM"}]
        result["terms"] = sorted({p["lemma"] for p in content})
        result["names"] = sorted({p["lemma"] for p in content if p["pos"] == "PROPN"})
        result["unresolved"] = any(p["pos"] == "PRON" for p in proofs)
    for modifier in result.get("modifiers", []):
        modifier["phrase"] = _rewrite_phrase(modifier["phrase"], pronoun, antecedent)
    return result


def _local_copular_subjects(text, frames, parser):
    """Recover explicit subjects, never inherit a nearby name as an owner.

    Punctuation/coordination windows nominate syntax only. The full-context
    frame must already exist at exactly this predicate, and all its assertion
    qualifications, dates and unresolved arguments survive the reanalysis.
    """
    doc = parser(text)
    tokens = {t.idx: t for t in doc}
    by_predicate = {}
    for frame in frames:
        token = tokens.get(frame["predicate_proof"]["start"])
        if (frame["kind"] == "PROPERTY" and token is not None and not frame.get("v3_binding")
                and not any(t.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"} for t in token.head.children)):
            by_predicate.setdefault(token.idx, []).append(frame)
    if not by_predicate:
        return frames
    starts = {m.end() for m in re.finditer(r"\.[ \t]{2,}(?=\S)", text)}
    for token in doc:
        if token.dep_ == "cc" and token.lemma_.casefold() in {"and", "but"}:
            start = token.idx + len(token.text)
            while start < len(text) and text[start].isspace():
                start += 1
            starts.add(start)
    for start in sorted(starts):
        containing = next((s for s in doc.sents if s.start_char <= start < s.end_char), None)
        if containing is None or not any(start <= p < containing.end_char for p in by_predicate):
            continue
        end = containing.end_char
        local = text[start:end]
        local_doc = parser(local)
        for proposed in base.matching.frames(local, parser):
            if proposed["kind"] != "PROPERTY":
                continue
            proof = proposed["predicate_proof"]
            predicate = next(t for t in local_doc if t.idx == proof["start"])
            copula = predicate.head
            subjects = [t for t in copula.children if t.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"}]
            if len(subjects) != 1 or subjects[0].pos_ not in {"NOUN", "PROPN"}:
                continue
            absolute = start + proof["start"]
            for original in by_predicate.get(absolute, []):
                if original["kind"] != "PROPERTY" or original["predicate"] != proposed["predicate"]:
                    continue
                restored = frozen._Engine.restore_offsets(proposed, text, list(range(start, end)))
                original["roles"] = deepcopy(restored["roles"])
                original["predicate_phrase"] = deepcopy(restored["predicate_phrase"])
                for field, value in restored["qualifiers"].items():
                    prior = original["qualifiers"][field]
                    if isinstance(value, bool):
                        original["qualifiers"][field] = prior or value
                    elif isinstance(value, list):
                        original["qualifiers"][field] = prior + [v for v in value if v not in prior]
                    elif isinstance(value, dict):
                        original["qualifiers"][field] = dict(prior, **value)
                for field in ("event_dates", "unbound_arguments"):
                    original[field].extend(v for v in restored[field] if v not in original[field])
                original["v5_bindings"] = [b for b in original.get("v5_bindings", [])
                    if b["kind"] != "EXPLICIT_LOCAL_COPULAR_SUBJECT"]
                original["v5_bindings"].append(dict(
                    kind="EXPLICIT_LOCAL_COPULAR_SUBJECT", subject=deepcopy(restored["roles"]["owner"]),
                    start=start, end=end, text=local,
                    original_assertion_context_preserved=True, named_identity_inferred=False))
    # An explicitly re-bound subject of a later finite clause must not also
    # survive as a coordinated object of an earlier copular complement.
    subjects = {p["start"] for f in frames for binding in f.get("v5_bindings", [])
        if binding["kind"] == "EXPLICIT_LOCAL_COPULAR_SUBJECT"
        for phrase in binding["subject"] for p in phrase["proofs"] if p["lemma"] == phrase["head"]}
    def prune(phrase, predicate_start):
        phrase["modifiers"] = [m for m in phrase.get("modifiers", []) if not any(
            p["start"] in subjects and p["start"] > predicate_start and p["lemma"] == m["phrase"]["head"]
            for p in m["phrase"]["proofs"])]
        for modifier in phrase["modifiers"]:
            prune(modifier["phrase"], predicate_start)
    for frame in frames:
        if frame.get("predicate_phrase"):
            prune(frame["predicate_phrase"], frame["predicate_proof"]["start"])
    return frames


class _Engine(frozen._Engine):
    def __init__(self, parse=None):
        super().__init__(parse)
        self.analysis_parser = _AnalysisParser(parse)
        self.parse = self.analysis_parser

    def frames(self, text, *, antecedents=False):
        key = (text, antecedents)
        if key not in self.cache:
            # Source eligibility never lives in this cache; it is checked by
            # the executor on every call before any frames are consumed.
            frames, resource = _source_frames(self.analysis_parser.identity,
                self.analysis_parser.language, text, antecedents)
            self.cache[key] = frames
            self.lexical_resource.update(resource)
        return deepcopy(self.cache[key])


@lru_cache(maxsize=_CACHE_LIMIT)
def _source_frames(identity, language, text, antecedents):
    engine = frozen._Engine(identity.parser)
    parser = _AnalysisParser(identity.parser)
    parser.language = language
    engine.parse = parser
    # Preserve v3's ordinary word line-wrap and conservative anaphora paths.
    view, offsets, edits = engine.source_view(text)
    frames = engine.frames(view, antecedents=antecedents)
    frames = _local_copular_subjects(view, frames, parser)
    doc = parser(view)
    tokens = {t.idx: t for t in doc}
    for frame in frames:
        token = tokens.get(frame["predicate_proof"]["start"])
        if token is None:
            continue
        changes = frame.get("v5_bindings", [])
        ambiguous = [base.matching.proof(t) for t in token.children
            if t.dep_ == "advmod" and t.pos_ in {"NOUN", "PROPN"}]
        if ambiguous:
            frame["unbound_arguments"].extend(ambiguous)
            frame["qualifiers"]["unresolved"].append("NOMINAL_ADVERBIAL_ARGUMENT_BINDING_UNRESOLVED")
        governor = token.head if frame["kind"] == "PROPERTY" else token
        if frame["kind"] == "PROPERTY" and frame.get("predicate_phrase"):
            # v3 dropped the entire copular complement from role diagnostics:
            # "A is B's teacher" could match "A is C's teacher". Keep it.
            frame["roles"]["property"] = [deepcopy(frame["predicate_phrase"])]
            changes.append(dict(kind="EXPLICIT_COPULAR_COMPLEMENT",
                proof=deepcopy(frame["predicate_phrase"])))
        relative = governor
        if relative.dep_ == "relcl" and relative.head.pos_ in {"NOUN", "PROPN"}:
            antecedent = base.matching.phrase(relative.head)
            if not antecedent["unresolved"]:
                for role, values in frame["roles"].items():
                    for i, value in enumerate(values):
                        if (value["unresolved"] and value["head"] in {"who", "which", "that", "whom"}
                                and any(tokens[p["start"]].head == relative for p in value["proofs"])):
                            frame["roles"][role][i] = deepcopy(antecedent)
                            changes.append(dict(kind="EXPLICIT_RELATIVE_ARGUMENT", role=role,
                                pronoun=deepcopy(value), antecedent=deepcopy(antecedent),
                                cross_sentence_identity_inferred=False))
                for pronoun in relative.subtree:
                    if pronoun.lemma_.casefold() != "whose" or pronoun.dep_ != "poss":
                        continue
                    # Only the relative's own subject/objects, not nested
                    # relatives with a nearer antecedent, may use this owner.
                    ancestors = list(pronoun.ancestors)
                    if relative not in ancestors or any(t.dep_ == "relcl" for t in ancestors[:ancestors.index(relative)]):
                        continue
                    frame["roles"] = {role: [_rewrite_phrase(p, pronoun, antecedent) for p in values]
                        for role, values in frame["roles"].items()}
                    changes.append(dict(kind="EXPLICIT_RELATIVE_POSSESSOR",
                        pronoun=base.matching.proof(pronoun), antecedent=deepcopy(antecedent),
                        cross_sentence_identity_inferred=False))
                if frame.get("relative_binding") or any(c["kind"] in {
                        "EXPLICIT_RELATIVE_POSSESSOR", "EXPLICIT_RELATIVE_ARGUMENT"} for c in changes):
                    # A nominal relative antecedent is not a reporting speaker.
                    # All other enclosing assertion/conditional scopes remain.
                    frame["qualifiers"]["scope"] = [s for s in frame["qualifiers"]["scope"]
                        if not (s["relation"] == "relcl" and s["predicate"] == relative.head.lemma_.casefold()
                            and not s["speakers"] and not s["negated"] and not s["modality"])]
        if changes:
            frame["v5_bindings"] = changes
        frame["v5_analysis"] = deepcopy(parser.records.get(digest(view), {}))
    if offsets is not None:
        frames = frozen._Engine.restore_offsets(frames, text, offsets)
        for frame in frames:
            frame["source_normalization"] = [deepcopy(e) for e in edits
                if e["start"] < frame["end"] and frame["start"] < e["end"]]
    return frames, deepcopy(engine.lexical_resource)


def compare_frames(target, source, *, engine=None):
    result = frozen.compare_frames(target, source, engine=engine or _Engine())
    if result is not None:
        def identity_terms(phrase, path=()):
            terms = {(path, frozen._term(p)) for p in phrase["proofs"]
                if p["pos"] in {"NOUN", "PROPN", "ADJ", "NUM"}}
            for modifier in phrase.get("modifiers", []):
                terms |= identity_terms(modifier["phrase"], path + (modifier["relation"],))
            return terms
        incomplete = []
        for row in result["bindings"]["argument_matches"]:
            if row["status"] != "EXACT_SCOPED_ARGUMENT" or row["role"] == "property":
                continue
            extra = identity_terms(row["source"]) - identity_terms(row["target"])
            if extra:
                incomplete.append(dict(role=row["role"], additional_source_discriminators=[
                    dict(path=list(path), term=term) for path, term in sorted(extra)]))
        if incomplete and result["direction"] in {"SUPPORT", "COUNTER"}:
            # POS/NER drift must not erase a lexical country/name/committee
            # qualifier and turn a narrower argument into established identity.
            result["direction"] = "PARTIAL"
            result["reasons"].append("SOURCE_ARGUMENT_DISCRIMINATORS_NOT_BOUND_IN_TARGET")
            actor = "owner" if target["kind"] in {"PROPERTY", "NOMINAL_RELATION"} else "agent"
            affected = {"actor" if row["role"] == actor else "location"
                if row["role"].removeprefix("prep:") in base._LOCATION_PREPS else "object" for row in incomplete}
            for field in affected:
                if result["diagnostics"][field]["status"] == "MATCH":
                    result["diagnostics"][field].update(status="PARTIAL",
                        identity_gaps=deepcopy(incomplete))
        result["source_v5_bindings"] = deepcopy(source.get("v5_bindings", []))
        result["source_v5_analysis"] = deepcopy(source.get("v5_analysis", {}))
    return result


def _factual(status):
    return {"COMPLETE": "SUPPORT", "INSUFFICIENT": "UNSUPPORTED",
        "CONFLICTING": "COUNTER"}.get(status, status)


def _grammar_admission(case, reading, fill, parse, bounds):
    right = case["query"].split(case["focal_marker"])[1]
    visible = re.match(r"['\u2019]s\b", right, re.I)
    duplicated = bool(visible and re.search(r"(?:['\u2019]s|s['\u2019])$", fill.strip(), re.I))
    local_reading = dict(reading, form="nominal") if visible and reading.get("form") == "possessive" else reading
    result = frozen._grammar_admission(case, local_reading, fill, parse, bounds)
    if visible:
        result["possessive_boundary"] = dict(visible_clitic=visible.group(),
            morphology_supplied_outside_gap=True, reading_form_preserved=reading.get("form"),
            duplicate_inside_fill=duplicated, source_modified=False)
        result["form"] = reading.get("form")
    if duplicated:
        result["reasons"].append("DUPLICATED_POSSESSIVE_MORPHOLOGY_AT_SLOT_BOUNDARY")
        result["admissible"] = False
    return result


def grammar_admission(case, reading, fill, *, parse=None):
    case = public_case(case)
    engine = _Engine(parse)
    bounds = frozen._focal_sentence_bounds(case, engine.parse)
    return _grammar_admission(case, reading, fill, engine.parse, bounds)


def _isolated(**overrides):
    _, functions = base.matching.clone(frozen, dict(_Engine=_Engine,
        compare_frames=compare_frames, VERSION=VERSION, **overrides))
    return functions


def execute_v5(case, plan, retrieval, passage_budget=100, parse=None):
    """Execute a public saved plan over admitted raw pages, locally only."""
    result = _isolated()["execute_v3"](case, plan, retrieval,
        passage_budget=passage_budget, parse=parse)
    result["factual_support"] = dict(status=_factual(result["status"]),
        missing_support_is_counterevidence=False, scope=result["scope"],
        basis="CITED_RAW_TEXT_AND_STRUCTURED_GATES", generated_labels_are_proof=False)
    for atom in result["atoms"]:
        atom["factual_support"] = _factual(atom["status"])
        for evidence in atom["evidence"]:
            evidence["match_representation"] = evidence["match_representation"].replace("_V3", "_V5")
    result["execution_policy"] = dict(derived_labels_used=False,
        parser_cache_limit=_CACHE_LIMIT, frame_cache_limit=_CACHE_LIMIT,
        eligibility_rechecked_on_cache_hits=True, source_text_modified=False,
        frozen_engine_modified=False, candidate_feasibility_is_factual_support=False)
    return result


execute = execute_v5


def _support_assessment(case, candidate, engine, *, source_index=None, bounds=None):
    assessment = _isolated()["_support_assessment"](case, candidate, engine,
        source_index=source_index, bounds=bounds)
    # Retain the legacy assessment. Additional states are computed from actual
    # native evidence, never post-run grading or the constructor's label.
    directions = [e["direction"] for e in assessment["evidence"]]
    supported = assessment["substantive_support"]
    counter = "COUNTER" in directions
    partial = "PARTIAL" in directions or "SUPPORT" in directions and not supported
    status = "MIXED" if counter and "SUPPORT" in directions else "COUNTER" if counter else (
        "SUPPORT" if supported else "PARTIAL" if partial else "UNSUPPORTED")
    assessment["factual_status"] = status
    assessment["absence_is_counterevidence"] = False
    return assessment


def _citation_replay(case, audit, retrieval, passage_budget):
    pages, _ = frozen._source_pages(case, retrieval, passage_budget)
    index = {p["id"]: p for p in pages}
    primary_ids = set(index)
    wanted = {s["canonical_page_id"] for row in audit["readings"]
        for p in row["proposals"] for s in p.get("sources", [])}
    missing = wanted - primary_ids
    if missing:
        corpus = retrieval["eligible"].corpus
        by_id = {}
        for i, page in enumerate(corpus.pages):
            if page["id"] in missing:
                if page["id"] in by_id:
                    raise ValueError("Ambiguous supplemental canonical page identity")
                by_id[page["id"]] = i
        if set(by_id) != missing:
            raise ValueError("Candidate citation has no raw corpus page")
        supplemental = dict(retrieval, pages=list(by_id.values()))
        additional, _ = frozen._source_pages(case, supplemental, len(by_id))
        pages.extend(additional)
        index.update((p["id"], p) for p in additional)
    for row in audit["readings"]:
        for proposal in row["proposals"]:
            for citation in proposal.get("sources", []):
                page = index.get(citation["canonical_page_id"])
                if page is None:
                    raise ValueError("Candidate citation is not an inspected eligible raw page")
                a, b = citation["start"], citation["end"]
                if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
                        or page["text"][a:b] != citation["text"]
                        or citation["page_sha256"] != page["source_sha256"]
                        or citation["document_id"] != page["document_id"] or citation["date"] != page["date"]):
                    raise ValueError("Candidate citation does not replay against raw source")
    return pages, dict(primary_source_pages_inspected=len(primary_ids),
        supplemental_candidate_pages_inspected=len(missing),
        supplemental_page_ids=sorted(missing), source_pages_inspected=len(pages),
        primary_passage_budget=passage_budget, supplemental_pages_counted_separately=True,
        supplemental_source_policy_identical=True)


def _disposition(candidate, *, contextual):
    assessment = candidate["support_assessment"]
    status = assessment["factual_status"]
    labels = {"SUPPORT": "Supported", "PARTIAL": "Partial evidence", "COUNTER": "Contradicted",
        "MIXED": "Partial evidence", "UNSUPPORTED": "Contextual inference" if contextual else "Unresolved"}
    explanations = {
        "SUPPORT": "All required focal contributions have native structured raw-text support; this does not establish the entire surrounding account.",
        "PARTIAL": "The cited raw text supplies only partial focal evidence; missing roles or assertion scope remain unresolved.",
        "COUNTER": "Native evidence explicitly opposes the same scoped focal requirement; this is not a missing-support decision.",
        "MIXED": "Both supporting and opposing native focal evidence remain; no unqualified support is claimed.",
        "UNSUPPORTED": "The fill passed local insertion checks, but the cited text does not establish its focal proposition. Missing support is not counterevidence.",
    }
    return dict(feasible=True, fit_label="Passed local insertion checks", evidence_label=labels[status],
        explanation=explanations[status], needed=[] if status == "SUPPORT" else [
            "Eligible raw text establishing the same focal actor, relation, event/date and assertion scope."])


def _same_occurrence(left, right):
    return all(left.get(k) == right.get(k) for k in (
        "id", "fill", "sources", "source_span", "source_wording"))


def _validated_candidate_views(result):
    """IDs can repeat at different spans; the full pool index is authoritative."""
    audit = result.get("_candidate_audit")
    if not audit or "readings" not in audit:
        raise ValueError("FULL_POOL_AUDIT_REQUIRED")
    if len(audit["readings"]) != len(result["readings"]):
        raise ValueError("Candidate reading/audit shape changed")
    views = []
    duplicate_occurrences = 0
    for raw, view in zip(audit["readings"], result["readings"]):
        pool = {}
        for proposal in raw["proposals"]:
            pool.setdefault(proposal["id"], []).append(proposal)
        duplicate_occurrences += len(raw["proposals"]) - len(pool)
        for candidate in view["candidates"]:
            if not any(_same_occurrence(candidate, original) for original in pool.get(candidate["id"], [])):
                raise ValueError("Displayed candidate changed from complete audited pool")
        # Frozen v3 caches presentation candidates by ID alone. Bypass that
        # cache so each selected pool index supplies its own original proof.
        # Only shallow view copies are needed: v3 deep-copies its output.
        views.append(dict(view, candidates=[]))
    return dict(result, readings=views), duplicate_occurrences


def filter_redaction_v5(case, result, top_k=5, *, retrieval=None, passage_budget=100, parse=None):
    """Filter the full pool; keep syntactic feasibility separate from evidence.

    Optional retrieval certifies citations against eligible full raw pages.
    Without it the existing caller-replay contract is explicitly retained.
    """
    case = public_case(case)
    execution_input, duplicate_occurrences = _validated_candidate_views(result)
    audit = result.get("_candidate_audit")
    full_citations, replay_audit = None, None
    if retrieval is not None:
        if type(passage_budget) is not int or passage_budget < 0:
            raise ValueError("passage_budget must be a nonnegative whole-page count")
        pages, replay_audit = _citation_replay(case, audit, retrieval, passage_budget)
        full_citations = [dict(canonical_page_id=p["id"], document_id=p["document_id"],
            date=p["date"], start=0, end=len(p["text"]), text=p["text"],
            page_sha256=p["source_sha256"]) for p in pages]
    engine_factory = lambda: _Engine(parse)
    def assessment_sources(c, citations, engine):
        return frozen._assessment_sources(c,
            full_citations if full_citations is not None else citations, engine)
    _, functions = base.matching.clone(frozen, dict(_Engine=engine_factory,
        compare_frames=compare_frames, _support_assessment=_support_assessment,
        _assessment_sources=assessment_sources, _grammar_admission=_grammar_admission, VERSION=VERSION))
    output = functions["filter_redaction"](case, execution_input, top_k=top_k)
    summary = output.pop("task_execution_v3")
    summary.update(source_integrity="RAW_ELIGIBLE_PAGES_REPLAYED" if retrieval is not None
        else "CALLER_REPLAYS_FULL_SOURCE_PAGES", candidate_feasibility_is_factual_support=False)
    summary["candidate_identity"] = dict(strategy="EXACT_SOURCE_OCCURRENCE_AND_POOL_INDEX",
        repeated_id_occurrences=duplicate_occurrences, repeated_ids_rejected=False,
        source_spans_preserved=True, ranking_unchanged=True, id_only_view_cache_used=False)
    if replay_audit is not None:
        summary["source_replay"] = replay_audit
    output["task_execution_v5"] = summary
    ledger = output["_candidate_audit"].pop("task_execution_v3")
    output["_candidate_audit"]["task_execution_v5"] = ledger
    for row in ledger["readings"]:
        for rejected in row["counterevidence_rejections"]:
            rejected["disposition"] = _disposition(rejected, contextual=True)
    for view, source_view, row in zip(output["readings"], result["readings"], ledger["readings"]):
        for candidate, pool_index in zip(view["candidates"], row["displayed_pool_indices"]):
            candidate["candidate_occurrence"] = dict(reading_id=view["reading"]["id"], pool_index=pool_index,
                source_span=deepcopy(candidate["source_span"]))
            original = next((p for p in source_view["candidates"] if _same_occurrence(p, candidate)), None)
            if original is not None and "ranking_explanation" in original:
                candidate["ranking_explanation"] = original["ranking_explanation"]
            candidate["support_assessment"]["source_integrity"] = summary["source_integrity"]
            candidate["candidate_feasibility"] = dict(status="FEASIBLE", factual_support_implied=False,
                basis="LOCAL_INSERTION_AND_SOURCE_BOUND_CONSTRUCTION_CHECKS")
            candidate["disposition"] = _disposition(candidate,
                contextual=bool(candidate.get("sources")))
        view["exploratory_candidates"] = deepcopy(view["candidates"])
        view["evidence_candidates"] = [deepcopy(c) for c in view["candidates"]
            if c["support_assessment"]["factual_status"] == "SUPPORT"]
    return output


filter_redaction = filter_redaction_v5
