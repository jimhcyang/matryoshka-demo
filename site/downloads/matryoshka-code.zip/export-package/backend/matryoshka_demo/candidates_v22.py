"""Fresh source-owned v2.1 construction plus the conservative v2.2 person guard.

The isolated function graph preserves v2.1 pool generation, source-only typing,
IDs, ranking features, quotations and compressed-audit contract without mutating
the base module. Each construct/rerank call owns one lexical resource cache.
rerank remains a fixed-pool diagnostic, not fresh construction or retrieval.
"""
from copy import deepcopy

from matryoshka_demo import candidates_v21 as base
from matryoshka_demo.candidate_types_v22 import NounResource, combine_fit, person_guard
from matryoshka_demo.vendor.matching import clone


VERSION = "source-owned-unified-candidates/2.2"
__all__ = ["VERSION", "Context", "joint_fit", "construct", "rerank"]


class Context(base.Context):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.noun_resource = NounResource()

    def snapshot(self):
        return dict(super().snapshot(), person_guard=dict(noun_lemmas_cached=len(self.noun_resource.cache),
            resource=deepcopy(self.noun_resource.resource)))


def joint_fit(proposal, reading, context, *, resource=None):
    source_fit = base.joint_fit(proposal, reading, context)
    resource = context.noun_resource if resource is None else resource
    return combine_fit(source_fit, person_guard(context.phrase(proposal), reading, source_fit, resource))


_scope, _functions = clone(base, dict(VERSION=VERSION, Context=Context, joint_fit=joint_fit))
construct = _functions["construct"]
rerank = _functions["rerank"]
