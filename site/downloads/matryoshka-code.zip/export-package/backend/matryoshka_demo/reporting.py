"""Post-run key comparisons; never imported by the retrieval/construction path."""
from collections import Counter, defaultdict
from pathlib import Path
import re

from .contracts import public_case
from .integrity import verify_auxiliary, verify_condition, verify_sources
from .io import digest, load, save, sha
from .runner import checked


def tokens(text):
    text = re.sub(r"(?<=[A-Za-z])-\s+(?=[A-Za-z])", "", text)
    return re.findall(r"[a-z0-9]+", text.casefold())


def key_coverage(fill, key):
    wanted, got = tokens(key), tokens(fill)
    it = iter(got)
    return bool(wanted) and all(any(w == t for t in it) for w in wanted)


def summarize(payload, key):
    result = payload["result"]
    if payload["case"]["task"] != "redaction":
        return dict(local_status=result["status"], required_atoms=result["required_atoms"],
            covered_atoms=result["covered_atoms"], partial_atoms=result["partial_atoms"],
            correctness_independently_assessed=False)
    readings = []; displayed = set()
    for reading in result["readings"]:
        lanes = {}
        for lane in ("evidence_candidates", "exploratory_candidates"):
            candidates = reading[lane]
            displayed.update(tokens_key(c["fill"]) for c in candidates)
            lanes[lane] = dict(displayed=len(candidates),
                literal_key_coverage_at={str(k):any(key_coverage(c["fill"], key) for c in candidates[:k]) if key else None for k in (1,3,5)},
                literal_exact_at={str(k):any(tokens(c["fill"]) == tokens(key) for c in candidates[:k]) if key else None for k in (1,3,5)})
        readings.append(dict(id=reading["reading"]["id"], form=reading["reading"]["form"], lanes=lanes))
    return dict(readings=readings, unique_displayed_fills=len(displayed),
        interpretation="Literal-key coverage is not semantic correctness or source support; no new human/LLM grades", key_used_after_run=True)


def tokens_key(text): return " ".join(tokens(text))


def verified_release(path, version):
    try:
        value = load(path)
    except (OSError, ValueError) as error:
        raise ValueError("Missing or invalid release: " + str(path)) from error
    if (not isinstance(value, dict) or value.get("version") != version
            or digest({k:v for k,v in value.items() if k != "sha256"}) != value.get("sha256")):
        raise ValueError("Release version or self-digest changed: " + str(path))
    return value


def report(root, run_directory=None):
    root = Path(root).resolve()
    pointer = load(root / "data/latest_run.json") if run_directory is None else None
    run_directory = Path(run_directory if run_directory is not None else pointer["directory"]).resolve()
    if not run_directory.is_relative_to(root / "data/runs"):
        raise ValueError("Only this prototype's pinned runs may be reported")
    manifest_path = run_directory / "manifest.json"
    manifest = load(manifest_path); progress = load(run_directory / "progress.json")
    run_id = "local_" + digest(manifest)[:20]
    manifest_sha256 = sha(manifest_path)
    if run_directory.name != run_id or progress.get("run_id") != run_id:
        raise ValueError("Frozen manifest or run identity changed")
    if pointer and (pointer.get("run_id") != run_id or pointer.get("manifest_sha256") != manifest_sha256):
        raise ValueError("Latest run pointer does not match the frozen manifest")
    if manifest.get("public_inputs_only") is not True or not manifest.get("assessment_release_sha256"):
        raise ValueError("Run has no frozen public assessment release; legacy reports are preserved, not recertified")
    release_directory = root / "data/catalog_v1"
    catalog = verified_release(release_directory / "catalog.json", "demo-source-admission/1")
    inputs = verified_release(release_directory / "inference_catalog.json", "public-demo-inputs/1")
    binding = verified_release(root / "data/bindings.json", "demo-corpus-bindings/1")
    assessment_path = release_directory / "assessment_release.json"
    assessment = verified_release(assessment_path, "demo-assessment-release/1")
    if set(assessment) != {"version", "factory_sha256", "public_inputs_sha256", "binding_sha256", "evaluation_keys_sha256", "sha256"}:
        raise ValueError("Unexpected assessment release fields")
    if sha(assessment_path) != manifest["assessment_release_sha256"]:
        raise ValueError("Assessment release differs from the frozen run")
    if (assessment["factory_sha256"] != catalog["sha256"] or inputs.get("factory_sha256") != catalog["sha256"]
            or assessment["public_inputs_sha256"] != inputs["sha256"] or manifest.get("catalog_sha256") != inputs["sha256"]
            or any(value.get("binding_sha256") != binding["sha256"] for value in (manifest, catalog, inputs, assessment))):
        raise ValueError("Factory, public inputs, source binding and assessment releases do not match")
    if set(inputs) != {"version", "factory_sha256", "binding_sha256", "cases", "controls", "sha256"}:
        raise ValueError("Unexpected public input release fields")
    if any(inputs.get(kind) != catalog.get(kind) for kind in ("cases", "controls")):
        raise ValueError("Factory and public case projections differ")
    released_cases = inputs["cases"] + inputs["controls"]
    cases_by_id = {}
    for case in released_cases:
        if case != public_case(case) or not isinstance(case["case_id"], str) or not case["case_id"]:
            raise ValueError("Invalid public case fields")
        if case["case_id"] in cases_by_id:
            raise ValueError("Duplicate case identity in public release")
        cases_by_id[case["case_id"]] = case
    settings = manifest["settings"]
    case_ids, configs = settings["case_ids"], settings["configs"]
    if (not isinstance(case_ids, list) or not case_ids or any(not isinstance(cid, str) for cid in case_ids)
            or len(set(case_ids)) != len(case_ids) or not set(case_ids) <= cases_by_id.keys()
            or not isinstance(configs, dict) or not configs or any(not isinstance(c, str) or not c for c in configs)):
        raise ValueError("Invalid or duplicate expected conditions in manifest")
    expected = {(cid, config) for cid in case_ids for config in configs}
    filenames = {cid + "__" + config + ".json": (cid, config) for cid, config in expected}
    if len(filenames) != len(expected) or any(Path(name).name != name for name in filenames):
        raise ValueError("Ambiguous checkpoint filenames in manifest")
    if (progress.get("status") != "COMPLETE" or progress.get("failures") != []
            or any(type(progress.get(k)) is not int or progress[k] != len(expected) for k in ("expected", "completed"))
            or progress.get("settings") != settings):
        raise ValueError("Reporting requires a COMPLETE run with exact counts, matching settings and zero failures")
    paths = sorted((run_directory / "cases").glob("*.json"))
    if {p.name for p in paths} != filenames.keys():
        raise ValueError("Checkpoint set has missing, extra or duplicate condition files")
    keys_path = release_directory / "evaluation_keys.json"
    try:
        if sha(keys_path) != assessment["evaluation_keys_sha256"]:
            raise ValueError("Evaluation keys differ from the frozen assessment release")
        keys = load(keys_path)
    except (OSError, ValueError) as error:
        raise ValueError("Missing or changed evaluation keys: " + str(keys_path)) from error
    if not isinstance(keys, dict):
        raise ValueError("Evaluation keys must be keyed by case identity")
    selected_cases = [cases_by_id[cid] for cid in case_ids]
    for case in selected_cases:
        reference = keys.get(case["case_id"])
        if case["task"] == "redaction" and (not isinstance(reference, dict)
                or not isinstance(reference.get("answer"), str) or not reference["answer"].strip()):
            raise ValueError("Missing redaction evaluation key: " + case["case_id"])
    verify_sources(root.parent, binding, corpora=sorted({c["corpus"] for c in selected_cases}))
    source_cache = {}; seen = set()
    grouped = defaultdict(dict); results = []; totals = defaultdict(Counter)
    for path in paths:
        cid, config = filenames[path.name]; case = cases_by_id[cid]
        payload = checked(path)
        condition = (payload["case"]["case_id"], payload["config"])
        if condition in seen:
            raise ValueError("Duplicate checkpoint condition")
        verify_condition(payload, case, config, run_id, binding["sha256"])
        verify_auxiliary(run_directory, payload, source_cache=source_cache)
        seen.add(condition)
        comparison = summarize(payload, keys.get(cid, {}).get("answer", ""))
        record = dict(payload, post_run_comparison=comparison, reference=keys.get(cid),
            source_metadata=catalog["metadata"][cid], checkpoint_sha256=sha(path))
        grouped[cid][payload["config"]] = record
        results.append(dict(case_id=cid, config=payload["config"], task=case["task"], corpus=case["corpus"],
            runtime_seconds=payload["runtime_seconds"], comparison=comparison,
            checkpoint=str(path.relative_to(root)), checkpoint_sha256=sha(path)))
        total = totals[payload["config"]]; total["case_count"] += 1
        total["runtime_seconds"] += payload["runtime_seconds"]
        if case["task"] == "redaction":
            total["redaction_cases"] += 1
            for lane in ("evidence_candidates", "exploratory_candidates"):
                for k in (1,3,5):
                    total[f"{lane}_literal_coverage_any_reading_at_{k}"] += int(any(r["lanes"][lane]["literal_key_coverage_at"][str(k)] for r in comparison["readings"]))
        else: total["local_" + comparison["local_status"]] += 1
    if seen != expected:
        raise ValueError("Checkpoint conditions do not exactly match the manifest")
    demo_ids = {c["case_id"] for c in inputs["cases"]}
    public = dict(reporting_version="demo-report/3", run_id=run_id, progress=progress,
        input_isolation="PUBLIC_RELEASE_ONLY", manifest_sha256=manifest_sha256,
        assessment_release=assessment, assessment_release_sha256=manifest["assessment_release_sha256"],
        public_inputs_sha256=inputs["sha256"], evaluation_keys_sha256=assessment["evaluation_keys_sha256"],
        source_binding=binding, catalog_counts=catalog["counts"],
        catalog_sha256=catalog["sha256"], selection_rule=catalog["selection_rule"],
        cases=[dict(case=c, selected_demo=c["case_id"] in demo_ids, source_metadata=catalog["metadata"][c["case_id"]],
            reference=keys.get(c["case_id"]), configurations=grouped.get(c["case_id"], {}))
            for c in selected_cases],
        summary={k:dict(v) for k,v in totals.items()}, measured_checkpoints=len(results),
        full_benchmark_evaluation=False, api_cost_usd=0, fresh_api_comparison="NOT_RUN",
        source_base=str(run_directory.relative_to(root)) + "/sources/",
        limitations=["Exposed development demonstrations, not held-out benchmark accuracy",
            "Local lexical/structural verdicts are not independent semantic judgments",
            "Graph connectivity and source wording are not proof of the missing proposition",
            "Local pretrained parsers are not certified free of training exposure",
            "Inherited aliases and hierarchy are retrospective"])
    public["sha256"] = digest(public)
    save(run_directory / "post_run_report.json", public)
    save(run_directory / "metrics.json", dict(results=results, summary=public["summary"]))
    save(root / "web/data/report.json", public)
    return dict(run_id=progress["run_id"], completed=len(results), expected=progress["expected"],
        status=progress["status"], summary=public["summary"], page="http://127.0.0.1:8930/")
