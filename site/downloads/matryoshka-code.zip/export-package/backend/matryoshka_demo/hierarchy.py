"""Eligibility-bound hierarchy navigation and numerical restart-walk traces.

Semantic indices always match ``eligible.corpus.node_ids``. Inactive semantic
slots remain present but have no edges, memberships or prior mass. Group states
are appended only for contiguous community/theme/domain paths of active nodes.
Membership is NAVIGATION, not a historical or factual relation. Group source
edges summarize only the supplied eligible adjacency, never a published
aggregate graph. Inherited assignments can still be retrospective.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import dataclass
import heapq
import math

import numpy as np
from scipy import sparse

from .graph_kernel import normalize_prior


LEVELS = ("community", "theme", "domain")
TRACE_SNAPSHOT_BUDGET = 16


@dataclass
class HierarchyBundle:
    kernel: sparse.csr_matrix
    prior: np.ndarray
    semantic_count: int
    state_ids: list[str]
    state_types: list[str]
    structural_edges: dict[tuple[int, int], dict]
    metadata: dict


@dataclass
class DiffusionResult:
    node_mass: np.ndarray
    full_mass: np.ndarray
    trace: dict
    iterations: int
    residual: float
    error_bound: float

    @property
    def semantic_mass(self):
        return self.node_mass


def build_hierarchy(eligible, prior):
    """Build an augmented row-stochastic CSR kernel without changing inputs.

    Outgoing (edge kind, destination state type) buckets get equal mass; within
    a bucket use eligible adjacency support, or unit weight for each distinct
    navigation membership. Missing hierarchy levels stop the membership chain;
    unassigned active isolates get numerical self-loops, not shared unknown hubs.
    ``structural_edges[(source_index, target_index)]`` describes every kernel
    edge, including SOURCE, SOURCE_AGGREGATE, NAVIGATION and NUMERICAL_SELF_LOOP.
    The kernel/prior can be passed directly to maximum_product_witness.
    """
    corpus = eligible.corpus
    node_ids = list(corpus.node_ids)
    n = len(node_ids)
    if any(not isinstance(node, str) for node in node_ids) or len(set(node_ids)) != n:
        raise ValueError("Semantic node IDs must be unique strings")
    active = np.asarray(eligible.active, dtype=bool)
    if active.shape != (n,):
        raise ValueError("Eligibility mask has wrong shape")
    seed = np.asarray(prior, dtype=np.float64)
    if seed.shape != (n,) or not np.isfinite(seed).all() or (seed < 0).any():
        raise ValueError("Prior must be a finite nonnegative semantic vector")
    seed = seed.copy()
    seed[~active] = 0
    # Scaling first also permits large finite query scores without sum overflow.
    maximum = float(seed.max(initial=0))
    seed = normalize_prior(seed / maximum if maximum else seed)

    adjacency = sparse.csr_matrix(eligible.adjacency, dtype=np.float64).copy()
    adjacency.sum_duplicates()
    if (adjacency.shape != (n, n) or not np.isfinite(adjacency.data).all()
            or (adjacency.data < 0).any()):
        raise ValueError("Eligible adjacency must be square, finite and nonnegative")
    adjacency = adjacency.multiply(active[:, None]).multiply(active[None, :]).tocsr()
    adjacency.eliminate_zeros()
    adjacency.sort_indices()

    paths = {}
    groups = set()
    member_counts = Counter()
    for ni in np.flatnonzero(active):
        row = corpus.hierarchy.get(node_ids[ni], {}) or {}
        path = []
        for level in LEVELS:
            label = row.get(level + "_id")
            if label is None or label == "":
                break
            if not isinstance(label, str):
                raise ValueError("Hierarchy IDs must be strings or missing")
            key = (level, label)
            path.append(key)
            groups.add(key)
            member_counts[key] += 1
        paths[int(ni)] = path

    ordered_groups = sorted(groups, key=lambda key: (LEVELS.index(key[0]), key[1]))
    # A semantic ID must never alias an appended group, even for unusual IDs.
    prefix = "hierarchy:"
    semantic_ids = set(node_ids)
    while any(prefix + kind + ":" + label in semantic_ids for kind, label in ordered_groups):
        prefix += ":"
    state_ids = node_ids + [prefix + kind + ":" + label for kind, label in ordered_groups]
    state_types = ["semantic"] * n + [kind for kind, _ in ordered_groups]
    group_indices = {key: n + i for i, key in enumerate(ordered_groups)}
    edges = {}

    def add_edge(u, v, kind, weight):
        key = (int(u), int(v))
        if key not in edges:
            edges[key] = dict(kind=kind, weight=float(weight))
        elif kind == "NAVIGATION":
            # Many eligible children can attest the same parent membership.
            # It remains one navigation edge, not a multiplicity-based bonus.
            return
        else:
            edges[key]["weight"] += float(weight)

    for ni, path in paths.items():
        chain = [ni] + [group_indices[key] for key in path]
        for u, v in zip(chain, chain[1:]):
            add_edge(u, v, "NAVIGATION", 1)
            add_edge(v, u, "NAVIGATION", 1)

    for u in range(n):
        a, b = adjacency.indptr[u:u + 2]
        for v, weight in zip(adjacency.indices[a:b], adjacency.data[a:b]):
            add_edge(u, v, "SOURCE", weight)
            for left, right in zip(paths[u], paths[int(v)]):
                if left != right:
                    add_edge(group_indices[left], group_indices[right], "SOURCE_AGGREGATE", weight)

    outgoing = defaultdict(lambda: defaultdict(list))
    for (u, v), edge in edges.items():
        if not math.isfinite(edge["weight"]):
            raise ValueError("Aggregated eligible support overflowed")
        outgoing[u][(edge["kind"], state_types[v])].append((v, edge))
    for u in list(paths) + list(group_indices.values()):
        if u not in outgoing:
            add_edge(u, u, "NUMERICAL_SELF_LOOP", 1)
            outgoing[u][("NUMERICAL_SELF_LOOP", state_types[u])].append((u, edges[u, u]))

    aa, bb, probabilities = [], [], []
    for u, buckets in outgoing.items():
        for bucket in buckets.values():
            weights = np.array([edge["weight"] for _, edge in bucket])
            weights /= weights.max()
            weights /= weights.sum() * len(buckets)
            if (weights == 0).any():
                raise ValueError("Eligible transition underflows float64")
            for (v, edge), probability in zip(bucket, weights):
                aa.append(u)
                bb.append(v)
                probabilities.append(float(probability))
                edge["transition"] = float(probability)
    size = len(state_ids)
    kernel = sparse.csr_matrix((probabilities, (aa, bb)), shape=(size, size))
    augmented_prior = np.zeros(size)
    augmented_prior[:n] = seed
    case = getattr(eligible, "case", {})
    metadata = dict(
        version="eligible-hierarchy/1", semantic_count=n, active_semantic_count=int(active.sum()),
        state_count=size, edge_count=kernel.nnz,
        source_binding=deepcopy(getattr(corpus, "binding", {})),
        eligibility={key: case[key] for key in ("corpus", "date", "document_id") if key in case},
        groups=[dict(index=group_indices[key], group_id=key[1], state_type=key[0],
                     eligible_members=member_counts[key]) for key in ordered_groups],
        transition_policy=dict(
            name="uniform_edge_kind_destination_type_then_support",
            bucket=["edge_kind", "destination_state_type"],
            between_buckets="uniform over nonempty outgoing buckets",
            within_bucket="proportional to eligible support; distinct NAVIGATION edges have unit weight",
            inactive_rows="zero", active_isolates="NUMERICAL_SELF_LOOP"),
        edge_kinds=dict(
            SOURCE="Directed support from eligible.adjacency, not a new factual assertion",
            SOURCE_AGGREGATE="Sum of eligible adjacency support crossing distinct groups at the same level; not a group-level factual relation",
            NAVIGATION="Eligible membership only, bidirectional; not historical or factual evidence",
            NUMERICAL_SELF_LOOP="Mass-preserving fallback for an active isolate; not evidence"),
        hierarchy_membership_is_evidence=False, retrospective_hierarchy=True,
        aggregate_source="eligible.adjacency masked on both endpoints only",
        missing_hierarchy="Stop at the first missing level; never pool unknown nodes",
        interpretation="Navigation mass, not factual correctness probability", api_calls=0)
    return HierarchyBundle(kernel, augmented_prior, n, state_ids, state_types, edges, metadata)


def _snapshot(bundle, values, previous, iteration, alpha, state_budget, edge_budget, delta):
    positive = np.flatnonzero(values > 0)
    # The full vector is never truncated; only this serialized view is bounded.
    visible = heapq.nsmallest(state_budget, positive, key=lambda i: (-float(values[i]), int(i)))
    total = float(values.sum())
    visible_mass = float(values[visible].sum())
    flows = []
    if previous is not None and visible:
        subgraph = bundle.kernel[visible][:, visible].tocoo()
        for row, col, probability in zip(subgraph.row, subgraph.col, subgraph.data):
            u, v = int(visible[row]), int(visible[col])
            mass = alpha * float(previous[u]) * float(probability)
            if mass:
                flows.append(dict(source=u, target=v, source_id=bundle.state_ids[u],
                    target_id=bundle.state_ids[v], source_type=bundle.state_types[u],
                    target_type=bundle.state_types[v], kind=bundle.structural_edges[u, v]["kind"],
                    transition=float(probability), mass=mass))
        flows.sort(key=lambda edge: (-edge["mass"], edge["source"], edge["target"]))
        flows = flows[:edge_budget]
    incoming = Counter()
    for edge in flows:
        incoming[edge["target"]] += edge["mass"]
    restart = (1 - alpha) * bundle.prior if previous is not None else np.zeros_like(values)
    walk_mass = alpha * float(previous.sum()) if previous is not None else 0.0
    states = []
    for i in visible:
        inflow = float(values[i] - restart[i]) if previous is not None else 0.0
        states.append(dict(index=int(i), id=bundle.state_ids[i], type=bundle.state_types[i],
            mass=float(values[i]), previous_mass=float(previous[i]) if previous is not None else None,
            restart_mass=float(restart[i]), walk_inflow=inflow,
            omitted_inflow=max(0.0, inflow - incoming[i])))
    by_type = Counter()
    for kind, mass in zip(bundle.state_types, values):
        by_type[kind] += float(mass)
    return dict(iteration=iteration, source_iteration=iteration - 1 if iteration else None,
        total_mass=total, visible_mass=visible_mass, omitted_mass=max(0.0, total - visible_mass),
        mass_by_type=dict(by_type), delta_l1=delta, states=states, edge_flows=flows,
        walk_flow_mass=walk_mass, omitted_flow_mass=max(0.0, walk_mass - sum(e["mass"] for e in flows)),
        restart_mass=float(restart.sum()))


def diffuse(bundle, alpha=.85, tolerance=1e-8, *, visible_states=24, visible_edges=64):
    """Solve the uncapped-depth restart fixed point, recording actual iterates.

    Start at x[0]=prior; x[k+1]=(1-alpha)*prior+alpha*kernel.T@x[k]. Convergence
    uses a global L1 fixed-point residual/(1-alpha) certificate. Visualization
    budgets do not alter the kernel, prior, iteration count or returned mass.
    Snapshots retain iterations 0..4, powers of two and the final iterate (at
    most TRACE_SNAPSHOT_BUDGET frames); flows always refer to the immediately
    preceding numerical iterate, NOT the preceding saved frame. Full kernel
    and prior remain in the bundle for unrestricted maximum-product routing.
    """
    if not 0 < alpha < 1 or not 0 < tolerance < 1:
        raise ValueError("Require 0 < alpha,tolerance < 1")
    for name, budget in (("visible_states", visible_states), ("visible_edges", visible_edges)):
        if isinstance(budget, bool) or not isinstance(budget, int) or budget < 0:
            raise ValueError(name + " must be a nonnegative integer")
    values = bundle.prior.copy()
    transpose = bundle.kernel.T.tocsr()
    restart = (1 - alpha) * bundle.prior
    snapshots = [_snapshot(bundle, values, None, 0, alpha, visible_states, visible_edges, 0.0)]
    iteration = 0
    residual = error_bound = 0.0
    while values.any():
        iteration += 1
        previous = values
        values = restart + alpha * (transpose @ previous)
        delta = float(np.abs(values - previous).sum())
        converged = False
        if alpha * delta / (1 - alpha) <= tolerance:
            residual = float(np.abs(values - (restart + alpha * (transpose @ values))).sum())
            error_bound = residual / (1 - alpha)
            converged = error_bound <= tolerance
        if iteration <= 4 or (iteration & (iteration - 1)) == 0 or converged:
            snapshots.append(_snapshot(bundle, values, previous, iteration, alpha,
                                       visible_states, visible_edges, delta))
            if len(snapshots) > TRACE_SNAPSHOT_BUDGET:
                del snapshots[5]
        if converged:
            break
    trace = dict(version="hierarchy-diffusion/1", alpha=float(alpha), tolerance=float(tolerance),
        recurrence="x[0]=prior; x[k+1]=(1-alpha)*prior+alpha*kernel.T@x[k]",
        kernel_orientation="row-stochastic on eligible active states; inactive rows are zero",
        iterations=iteration, converged=True, residual=residual, error_bound=error_bound, norm="L1",
        semantic_count=bundle.semantic_count, state_count=len(values),
        total_mass=float(values.sum()), metadata=deepcopy(bundle.metadata),
        visualization=dict(state_budget=visible_states, edge_budget=visible_edges,
            snapshot_budget=TRACE_SNAPSHOT_BUDGET, scope="per snapshot, visualization only",
            schedule="0..4, powers of two, final; oldest intermediate powers dropped if necessary",
            edge_flow="alpha*x[k-1][source]*kernel[source,target]; restart recorded separately",
            omitted_flow="All walk flow not shown, including hidden endpoints and edge-budget omissions",
            solver_depth_limit=None), snapshots=snapshots)
    return DiffusionResult(values[:bundle.semantic_count].copy(), values, trace,
                           iteration, residual, error_bound)
