"""Original parser, lexical retrieval and task engines over eligible sources.

The source adapter is required because the new graphs are not original-src
CorpusIndex artifacts. Optional original graph augmentation is NOT reproduced;
this limitation is explicit, rather than labelling a fixed-arm snapshot native.
"""
from collections import defaultdict
from pathlib import Path
from tempfile import TemporaryDirectory

from .contracts import public_case
from .io import digest
from .legacy_reference_v2 import load_original, _run_native, _marker_adaptation


VERSION = "original-eligible-retrieval-reference/3"


def run(case, corpus, *, passage_budget=100, document_budget=100):
    case = public_case(case)
    eligible = corpus.eligible(case)
    native = load_original()
    texts, dates = defaultdict(list), {}
    for pi, page in enumerate(corpus.pages):
        if eligible.page_mask[pi]:
            texts[page["document_id"]].append(page["text"])
            dates[page["document_id"]] = page["date"]
    combined = {doc: "\n".join(parts) for doc, parts in texts.items()}
    index = native.corpus.CorpusIndex(extraction_dir=Path("NO_ORIGINAL_SOURCE_FILES"),
        excluded_doc_ids=frozenset({case["document_id"]}), requested_task=case["task"],
        document_text=combined, document_tokens={doc: frozenset(native.semantics.semantic_tokens(text)) for doc, text in combined.items()},
        document_dates=dates, propositions_by_doc={}, values_by_doc={}, sentences_by_doc={}, provenance_by_doc={},
        fingerprint=digest(combined), load_statistics={})
    resources = native.semantic_resources.load_semantic_resources()
    queries = []
    tasks = ["claims", "contradictions"] if case["task"] == "hypothesis" else [case["task"]]
    with TemporaryDirectory(prefix="matryoshka-native-query-") as temp:
        root = Path(temp)
        query_text = _marker_adaptation(case)[0] if case["task"] == "redaction" else case["query"]
        parsed, mode, warnings = native.parser.parse_query_text(query_text, use_openai=False)
        native.parser.write_parse_outputs(parsed, root, "public_query", mode, warnings)
        for task in tasks:
            try:
                package = native.query.QueryPackage.load(root, task=task)
            except ValueError as error:
                if "no executable primary target" not in str(error):
                    raise
                continue
            atoms = native.matcher.build_retrieval_atom_contract(package, task)
            queries.extend(atoms["retrieval_text"].tolist())
    queries = list(dict.fromkeys(q for q in queries if q))
    scores = {}
    for query in queries:
        for doc, value in native.retrieval.rank_documents(query, index, document_budget, resources):
            scores[doc] = max(scores.get(doc, 0.), value)
    documents = sorted(scores, key=lambda d: (-scores[d], d))[:document_budget]
    ranks = {doc: i for i, doc in enumerate(documents)}
    pages = sorted((i for i, page in enumerate(corpus.pages) if eligible.page_mask[i] and page["document_id"] in ranks),
        key=lambda i: (ranks[corpus.pages[i]["document_id"]], corpus.pages[i]["id"]))[:passage_budget]
    receipt = dict(method=VERSION, search_queries=[dict(id="native_" + str(i), kind="native_atom", query=q) for i, q in enumerate(queries, 1)],
        text_matcher="Actual original semantic normalization plus 0.62 containment + 0.38 Jaccard",
        eligible_documents=len(combined), eligible_pages=int(eligible.page_mask.sum()), documents_admitted=len(documents), pages_admitted=len(pages),
        document_order=documents, original_graph_augmentation=False,
        adapter="Common eligible source text projected into original CorpusIndex; no arm1 source shortlist",
        graph_limitation="Optional original graph retriever requires its original corpus representation and is not reproduced",
        api_calls=0)
    result = _run_native(case, [corpus.pages[i] for i in pages], len(pages), receipt, passage_budget, native)
    if case["task"] == "redaction":
        adapted, audit = _marker_adaptation(case)
        result["marker_adapted_reference"] = _run_native(case, [corpus.pages[i] for i in pages], len(pages), receipt,
            passage_budget, native, native_query=adapted)
        result["marker_adapted_reference"]["query_adaptation"] = audit
    result.update(version=VERSION, reference_kind="ORIGINAL_PARSER_LEXICAL_RETRIEVAL_TASK_ENGINES_WITH_ELIGIBILITY_ADAPTER",
        retrieval_reproduced="Original lexical retrieval only; optional native graph augmentation not reproduced")
    return result, dict(eligible=eligible, pages=pages, receipt=receipt, hierarchy_bundle=None)
