"""Post-run, method-blinded grading. Never imported by inference modules."""
from copy import deepcopy

from .api_v2 import call
from .io import digest
from .planning_v2 import obj,arr,string
from .contracts import MASK

ITEM=obj(dict(id=string(),answer_match=string(("correct","partial","incorrect","not_applicable")),
    evidence_support=string(("direct","partial","context","contradicted","none")),
    grammatical=dict(type=["boolean","null"]),judgment=string(("appropriate","overclaim","underclaim","unclear")),
    cited_source_ids=arr(string()),explanation=string()))
SCHEMA=obj(dict(grades=arr(ITEM)))
PROMPT="""Assess saved analyst outputs using ONLY the supplied question, reference answer
when supplied, and quoted evidence. No web, remembered history or missing sources.
Methods and native scores are deliberately hidden. Do not repair the candidate.
The reference answer is an evaluation key, NEVER evidence of corpus availability.

For redaction, judge answer_match separately from evidence_support. Correct means
the insertion preserves the key's essential meaning in THIS sentence; partial
recovers an integral substantive part; incorrect does not. Attested fuller names
can match a shorter key, but a title/person's existence does not establish a
queried action, attribution or causal claim. Assess actual insertion grammar.
For hypothesis/reconstruction answer_match is not_applicable; assess the quoted
evidence against the supplied planned proposition and whether the native verdict
is appropriate, overclaims, underclaims or remains unclear. Never invent truth.

Support meanings: direct=the sources establish the focal contribution with the
correct participants, predicate, event, scope and qualifiers; partial=they establish
some integral elements but not all; context=source-grounded topic/role/identity
lead without the focal contribution; contradicted=explicit incompatible evidence
about the same proposition/event; none=no useful supplied source basis. A different
dated event is not automatically contradiction. Publication date is not event date.
Earlier contextual clues may be useful even if not event-specific, but cannot be
upgraded to direct support. Absence of a report is not a negative assertion.
Preserve negation, reported/conditional/possible status, subject ownership and
attribution. A graph connection does not establish a historical relation.

Return exactly one grade per item ID. Direct, partial or context support requires
nonempty IDs of supplied sources that actually support that classification.
Explain specifically what the evidence establishes and what remains missing in
one or two short sentences. Do not award correctness merely for plausible prose.
"""


def candidate_item(case,candidate):
    sources=[dict(id="S"+str(i),text=s["text"],date=s["date"]) for i,s in enumerate(candidate["sources"],1)]
    value=dict(kind="redaction_fill",candidate_fill=candidate["fill"],
        completed_sentence=case["query"].replace(case["focal_marker"],candidate["fill"]),sources=sources)
    return dict(id="item_"+digest(value)[:24],**value)


def task_sources(atom):
    chosen=[];groups={};seen=set()
    # Exact-predicate failures must not hide useful retrieved quotations from
    # the independent assessor. Direction names are not sent to the model.
    for source in atom["evidence"]:groups.setdefault(source.get("direction","unspecified"),[]).append(source)
    if atom.get("exploratory_passages"):groups["LEXICAL"]=list(atom["exploratory_passages"])
    groups={k:groups[k] for k in ("SUPPORT","COUNTER","PARTIAL","LEXICAL","RELATED","unspecified") if k in groups}
    while groups and len(chosen)<5:
        for direction in list(groups):
            source=groups[direction].pop(0);identity=(source.get("canonical_page_id"),source.get("start"),source.get("end"),source["text"])
            if identity not in seen:chosen.append(source);seen.add(identity)
            if not groups[direction]:del groups[direction]
            if len(chosen)==5:break
    return chosen


def task_item(atom):
    chosen=task_sources(atom)
    sources=[dict(id="S"+str(i),text=s["text"],date=s["date"]) for i,s in enumerate(chosen,1)]
    value=dict(kind="atomic_verdict",proposition=atom.get("text",atom.get("quote","")),
        query_anchor=atom.get("source_quote",atom.get("text","")),native_verdict=atom["status"],sources=sources,
        omitted_evidence=max(0,len(atom["evidence"])+len(atom.get("exploratory_passages",[]))-len(sources)),
        evidence_selection="Round-robin across structured directions and retrieved lexical clues; up to five distinct citations, native direction labels hidden")
    return dict(id="item_"+digest(value)[:24],**value)


def prepare(case,records,reference_answer=""):
    items={};mapping={}
    for config,record in records.items():
        result=record["result"]
        if case["task"]=="redaction":
            for reading in result["readings"]:
                for candidate in reading["candidates"]:
                    item=candidate_item(case,candidate);items[item["id"]]=item
                    mapping[(config,reading["reading"]["id"],candidate["id"])]=item["id"]
        else:
            for atom in result.get("atoms",[]):
                item=task_item(atom);items[item["id"]]=item
                mapping[(config,atom["id"])]=item["id"]
    return dict(task=case["task"],question=case["query"],question_date=case["date"],focal_marker=case["focal_marker"],
        reference_answer=reference_answer if case["task"]=="redaction" else "",
        items=sorted(items.values(),key=lambda i:i["id"])),mapping


def assess(api_root,packet,*,cap=25.,batch_size=20):
    grades=[];receipts=[]
    for at in range(0,len(packet["items"]),batch_size):
        batch=dict(packet,items=packet["items"][at:at+batch_size])
        output,receipt=call(api_root,"post_run_assessment",batch,PROMPT,SCHEMA,
            model="gpt-6.1-sol",max_output_tokens=6000,cap=cap)
        expected={i["id"]:i for i in batch["items"]}
        if len(output["grades"])!=len(expected) or {r["id"] for r in output["grades"]}!=set(expected):
            raise ValueError("Assessment did not grade the exact saved item set")
        for grade in output["grades"]:
            source_map={s["id"]:s for s in expected[grade["id"]]["sources"]};ids=set(source_map)
            if not set(grade["cited_source_ids"])<=ids:raise ValueError("Invented assessment source ID")
            if grade["evidence_support"] in {"direct","partial","context","contradicted"} and not grade["cited_source_ids"]:
                raise ValueError("Positive source assessment has no cited source")
            if any(not MASK.sub(" ",source_map[s]["text"]).strip() for s in grade["cited_source_ids"]):
                raise ValueError("Assessment source evidence is empty or opaque")
            if packet["task"]!="redaction" and grade["answer_match"]!="not_applicable":
                raise ValueError("Complete-claim task answer_match must be not_applicable")
        grades.extend(output["grades"]);receipts.append({k:v for k,v in receipt.items() if k!="cache"})
    return dict(version="method-blinded-assessment/2",packet_sha256=digest(packet),grades=grades,
        receipts=receipts,answer_aware=True,used_for_inference=False,independent_human_validation=False)


def verify_saved(api_root,packet,result):
    """Return a separately versioned replay audit; never rewrite the v2 result."""
    from .assessment_replay_v23 import verify_saved as verify
    return verify(api_root,packet,result)
