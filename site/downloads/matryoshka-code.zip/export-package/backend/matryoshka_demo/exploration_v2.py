"""Pinned SQLite exploration index; per-question source eligibility at read time."""
import json
from functools import lru_cache
from pathlib import Path
import sqlite3

from .contracts import public_case
from .io import digest,load,save,sha


def build_index(corpus,root):
    root=Path(root);key=digest(dict(version="source-neighborhood-index/2",binding=corpus.binding,
        policy="exact_CONFIDENTIAL_non_NOFORN"))[:20]
    directory=root/"data/graph_indexes_v2"/key;directory.mkdir(parents=True,exist_ok=True)
    path=directory/"graph.sqlite3";manifest=directory/"manifest.json"
    if manifest.exists():
        value=load(manifest)
        if (value["sha256"]!=sha(path) or value["binding"]!=corpus.binding or value["version"]!="source-neighborhood-index/2"):
            raise ValueError("Graph exploration index changed")
        return dict(path=str(path.relative_to(root)),sha256=value["sha256"],binding=corpus.binding)
    for unit in corpus.units:
        page=corpus.pages[unit["pi"]];a,b=unit["start"],unit["end"]
        if type(a) is not int or type(b) is not int or not 0<=a<b<=len(page["text"]):raise ValueError("Invalid source unit interval")
        if "text" in unit and unit["text"]!=page["text"][a:b]:raise ValueError("Source unit quotation does not replay")
    for edge in corpus.edge_rows:
        if not 0<=edge["ui"]<len(corpus.units) or corpus.units[edge["ui"]]["pi"]!=edge["pi"]:raise ValueError("Source edge/unit page mismatch")
    temporary=directory/"building.sqlite3"
    if temporary.exists():temporary.unlink()
    db=sqlite3.connect(temporary)
    try:
        db.executescript('''
        CREATE TABLE page(id TEXT PRIMARY KEY,doc TEXT,date TEXT,payload TEXT);
        CREATE TABLE node(id TEXT PRIMARY KEY,kind TEXT,hierarchy TEXT);
        CREATE TABLE mention(node TEXT,page TEXT,label TEXT);
        CREATE INDEX mention_node ON mention(node,page);
        CREATE TABLE edge(a TEXT,b TEXT,page TEXT,unit INTEGER,relation TEXT);
        CREATE INDEX edge_a ON edge(a,page);
        CREATE INDEX edge_b ON edge(b,page);
        CREATE TABLE unit(id INTEGER PRIMARY KEY,page TEXT,start INTEGER,end INTEGER);
        ''')
        db.executemany('INSERT INTO page VALUES(?,?,?,?)',((p["id"],p["document_id"],p["date"],json.dumps(p)) for p in corpus.pages if p["permitted"]))
        db.executemany('INSERT INTO node VALUES(?,?,?)',((n,corpus.nodes[n]["kind"],json.dumps(corpus.hierarchy.get(n,{}))) for n in corpus.node_ids))
        db.executemany('INSERT INTO mention VALUES(?,?,?)',((o["node_id"],corpus.pages[o["page_index"]]["id"],o["label"]) for o in corpus.occurrences))
        db.executemany('INSERT INTO unit VALUES(?,?,?,?)',((i,corpus.pages[u["pi"]]["id"],u["start"],u["end"]) for i,u in enumerate(corpus.units)))
        db.executemany('INSERT INTO edge VALUES(?,?,?,?,?)',((corpus.node_ids[e["a"]],corpus.node_ids[e["b"]],corpus.pages[e["pi"]]["id"],e["ui"],e["relation"]) for e in corpus.edge_rows))
        db.commit()
    finally:db.close()
    temporary.replace(path);save(manifest,dict(sha256=sha(path),binding=corpus.binding,version="source-neighborhood-index/2"))
    return dict(path=str(path.relative_to(root)),sha256=sha(path),binding=corpus.binding)


def neighborhood(root,reference,case,node_id,limit=20):
    case=public_case(case);root=Path(root).resolve();path=(root/reference["path"]).resolve()
    if not path.is_relative_to(root/"data/graph_indexes_v2"):raise ValueError("Unbound graph index path")
    if not isinstance(node_id,str) or len(node_id)>200 or type(limit) is not int or not 1<=limit<=30:raise ValueError("Invalid neighborhood request")
    if reference["binding"]["corpus"]!=case["corpus"]:raise ValueError("Wrong graph corpus")
    stat=path.stat()
    if verified_hash(str(path),stat.st_mtime_ns,stat.st_size,stat.st_ctime_ns,stat.st_ino)!=reference["sha256"]:raise ValueError("Graph index content changed")
    db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    try:
        node=db.execute('SELECT * FROM node WHERE id=?',(node_id,)).fetchone()
        label=db.execute('SELECT m.label FROM mention m JOIN page p ON p.id=m.page WHERE m.node=? AND p.date<? AND p.doc!=? ORDER BY p.date DESC,m.label LIMIT 1',
            (node_id,case['date'],case['document_id'])).fetchone()
        if not node or not label:raise ValueError("No eligible source occurrence for this node")
        sql='FROM edge e JOIN page p ON p.id=e.page WHERE (e.a=? OR e.b=?) AND p.date<? AND p.doc!=?'
        params=(node_id,node_id,case['date'],case['document_id'])
        count=db.execute('SELECT COUNT(*) '+sql,params).fetchone()[0]
        records=db.execute('SELECT e.* '+sql+' ORDER BY p.date DESC,e.a,e.b,e.unit LIMIT ?',params+(limit,)).fetchall()
        nodes={node_id:dict(id=node_id,label=label[0],kind=node['kind'])};edges=[]
        for edge in records:
            page=json.loads(db.execute('SELECT payload FROM page WHERE id=?',(edge['page'],)).fetchone()[0])
            unit=db.execute('SELECT * FROM unit WHERE id=?',(edge['unit'],)).fetchone();a,b=unit['start'],unit['end']
            if unit['page']!=edge['page'] or not 0<=a<b<=len(page['text']):raise ValueError("Source edge quotation does not replay")
            source=dict(id='source_'+digest([page['id'],a,b])[:20],canonical_page_id=page['id'],document_id=page['document_id'],
                date=page['date'],start=a,end=b,text=page['text'][a:b],page_sha256=page['source_sha256'],earlier_page=page['earlier_page'])
            for n in (edge['a'],edge['b']):
                if n not in nodes:
                    other=db.execute('SELECT m.label,n.kind FROM mention m JOIN node n ON n.id=m.node JOIN page p ON p.id=m.page WHERE m.node=? AND p.date<? AND p.doc!=? ORDER BY p.date DESC,m.label LIMIT 1',
                        (n,case['date'],case['document_id'])).fetchone()
                    nodes[n]=dict(id=n,label=other[0] if other else n,kind=other[1] if other else 'semantic')
            edges.append(dict(source=edge['a'],target=edge['b'],kind='SOURCE',relation=edge['relation'],citations=[source],historical_relation_certified=False))
        return dict(node_id=node_id,nodes=list(nodes.values()),edges=edges,total_source_edges=count,displayed_source_edges=len(edges),
            omitted_source_edges=max(0,count-len(edges)),hierarchy=json.loads(node['hierarchy']),binding=reference['binding'],
            cutoff=case['date'],whole_origin_excluded=case['document_id'],retrospective_hierarchy=True,
            meaning='Eligible source connections for exploration, not proof of a new hidden relation')
    finally:db.close()


@lru_cache(maxsize=12)
def verified_hash(path,mtime_ns,size,ctime_ns,inode):return sha(path)


def source_page(root,reference,case,page_id):
    case=public_case(case);root=Path(root).resolve();path=(root/reference["path"]).resolve()
    if not path.is_relative_to(root/"data/graph_indexes_v2") or reference["binding"]["corpus"]!=case["corpus"]:
        raise ValueError("Unbound source graph")
    stat=path.stat()
    if verified_hash(str(path),stat.st_mtime_ns,stat.st_size,stat.st_ctime_ns,stat.st_ino)!=reference["sha256"]:raise ValueError("Graph index content changed")
    db=sqlite3.connect('file:'+str(path)+'?mode=ro',uri=True)
    try:
        row=db.execute('SELECT payload FROM page WHERE id=? AND date<? AND doc!=?',(page_id,case['date'],case['document_id'])).fetchone()
        if not row:raise ValueError("No eligible source page")
        return json.loads(row[0])
    finally:db.close()
