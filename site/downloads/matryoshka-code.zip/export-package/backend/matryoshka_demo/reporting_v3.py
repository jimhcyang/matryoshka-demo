"""Read-only native replay, separate grading, and human-readable v3 publication."""
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path

from .api_v2 import Budget
from .assessment_v3 import prepare, assess, verify_saved, legacy_units
from .integrity import source_objects, verify_auxiliary, verify_sources
from .io import digest, load, load_gzip, save, save_gzip, sha
from .runner import checked
from .runner_v3 import VERSION, release_inputs, code_archive, graph_reference
from .reporting_v2 import slim_for_browser


def verified_run(root, run_directory=None):
    root = Path(root).resolve()
    directory = Path(run_directory or load(root / "data/latest_run_v3.json")["directory"]).resolve()
    if not directory.is_relative_to(root / "data/runs_v3"):
        raise ValueError("Unbound run directory")
    manifest = load(directory / "manifest.json")
    if manifest["version"] != VERSION or directory.name != "demo_v3_" + digest(manifest)[:20]:
        raise ValueError("Frozen run identity changed")
    if not (directory / "code_snapshot.zip").is_file():
        raise ValueError("Missing frozen code archive")
    code_archive(root, directory, manifest["code"])
    release = manifest["plan_release"]
    path = root / "data/development_v3" / ("plan_release_" + release["sha256"][:16] + ".json")
    if sha(path) != manifest["plan_release_sha256"]:
        raise ValueError("Plan release changed")
    loaded, plans = release_inputs(root, path)
    if loaded != release:
        raise ValueError("Native release differs from original release")
    progress = load(directory / "progress.json")
    arms, cases = manifest["settings"]["arms"], manifest["cases"]
    expected = {c["case_id"] + "__" + a + ".json" for c in cases for a in arms}
    if progress["status"] != "COMPLETE" or progress["completed"] != len(expected) or progress["failures"]:
        raise ValueError("Native conditions are not complete")
    if {p.name for p in (directory / "cases").glob("*.json")} != expected:
        raise ValueError("Native condition set changed")
    binding = load(root / "data/bindings.json")
    if binding["sha256"] != manifest["binding_sha256"]:
        raise ValueError("Source binding changed")
    verify_sources(root.parent, binding, {c["corpus"] for c in cases})
    indexes = {name: graph_reference(root, directory / (name + "_graph_index.json"), binding["corpora"][name])
        for name in {c["corpus"] for c in cases}}
    cache, grouped = {}, {}
    for case in cases:
        records = {}
        for arm in arms:
            record = checked(directory / "cases" / (case["case_id"] + "__" + arm + ".json"))
            if (record["case"] != case or record["config"] != arm or record["run_id"] != directory.name
                    or record["binding_sha256"] != binding["sha256"] or record["inference_network_access"] is not False):
                raise ValueError("Native condition binding changed")
            if record.get("exploration_index_ref") != indexes[case["corpus"]]:
                raise ValueError("Native explorer reference changed")
            if arm != "legacy_reference" and record["plan"] != plans[case["case_id"], arm]:
                raise ValueError("Native planner changed")
            verify_auxiliary(directory, record, cache)
            records[arm] = record
        grouped[case["case_id"]] = records
    return directory, manifest, grouped, binding


def assessment_keys(root, manifest):
    ref = manifest["plan_release"]["assessment_release_ref"]
    path = root / ref["path"]
    if sha(path) != ref["sha256"]:
        raise ValueError("Assessment release changed")
    release = load(path)
    if release["public_inputs_sha256"] != manifest["plan_release"]["catalog_sha256"]:
        raise ValueError("Keys/public population mismatch")
    ref = release.get("evaluation_keys_ref")
    target = (root / ref["path"]).resolve() if ref else path.parent / "evaluation_keys.json"
    if not target.is_relative_to(root):
        raise ValueError("Unbound evaluation key file")
    if sha(target) != release["evaluation_keys_sha256"]:
        raise ValueError("Evaluation keys changed")
    return load(target)


def grade_run(root, run_directory=None, *, execute=False, cap=25.):
    root = Path(root).resolve()
    if execute:
        print("Verifying frozen native outputs and provenance; no API calls during this step", flush=True)
    directory, manifest, grouped, _ = verified_run(root, run_directory)
    keys = assessment_keys(root, manifest)
    total = 0
    for position, case in enumerate(manifest["cases"], 1):
        records = grouped[case["case_id"]]
        packet, mapping = prepare(case, records, keys.get(case["case_id"], {}).get("answer", ""))
        total += len(packet["items"])
        target = directory / "assessments" / (case["case_id"] + ".json")
        if not execute:
            continue
        if target.exists():
            existing = load(target)
            if existing["packet"] != packet or existing["sha256"] != digest({k: v for k, v in existing.items() if k != "sha256"}):
                raise ValueError("Existing assessment changed")
            verify_saved(root / "data/development_v2/api", packet, existing["assessment"])
            print("Replayed cached assessment", position, "/", len(manifest["cases"]), case["case_id"], flush=True)
            continue
        print("Assessing", position, "/", len(manifest["cases"]), case["case_id"], len(packet["items"]), "distinct packets", flush=True)
        result = assess(root / "data/development_v2/api", packet, cap=cap)
        value = dict(case_id=case["case_id"], packet=packet, assessment=result,
            mapping=[dict(condition=list(k), item_id=v) for k, v in mapping.items()])
        value["sha256"] = digest(value)
        verify_saved(root / "data/development_v2/api", packet, result)
        save(target, value)
        print("Assessed", case["case_id"], len(packet["items"]), "distinct packets", flush=True)
    return dict(cases=len(grouped), unique_items=total, executed=execute,
        charged_or_reserved_usd=Budget(root / "data/development_v2/api").total())


def attach_grades(case, records, mapping, assessment):
    """Decorate a reporting copy; reference units never enter ranked/atom lists."""
    grades = {g["id"]: g for g in assessment["grades"]}
    for arm, record in records.items():
        if arm == "legacy_reference":
            references = []
            for unit in legacy_units(case, record["result"]):
                reference = {k: deepcopy(v) for k, v in unit.items() if k not in {"item", "sources"}}
                if unit["item"] is not None:
                    key = ((arm, unit["branch"], unit["id"]) if case["task"] == "redaction"
                        else (arm, unit["id"]))
                    reference["assessment"] = grades[mapping[key]]
                references.append(reference)
            record["result"]["post_run_reference_assessments"] = references
        elif case["task"] == "redaction":
            for row in record["result"]["readings"]:
                for candidate in row["candidates"]:
                    candidate["assessment"] = grades[mapping[arm, row["reading"]["id"], candidate["id"]]]
        else:
            for atom in record["result"]["atoms"]:
                atom["assessment"] = grades[mapping[arm, atom["id"]]]


def inspection_scope(directory, record):
    retrieval = record["result"].get("retrieval", {})
    modern = record.get("config") != "legacy_reference"
    primary_known = "top_sources" in retrieval
    primary = {p["page_id"] for p in retrieval.get("top_sources", [])}
    pages = primary | {s["canonical_page_id"] for s in source_objects(record["result"])}
    ref = record["result"].get("candidate_audit_ref")
    if ref:
        path = (directory / ref["path"]).resolve()
        if not path.is_relative_to(directory.resolve()) or sha(path) != ref["sha256"]:
            raise ValueError("Inspection-scope audit changed")
        audit = load_gzip(path)
        pages.update(audit.get("inspected_page_ids", []))
        pages.update(s["canonical_page_id"] for s in source_objects(audit))
    return dict(eligible_pages_in_scope=retrieval.get("eligible_pages"),
        eligible_pages_scored=retrieval.get("eligible_pages") if modern else None,
        eligible_documents_scored=retrieval.get("eligible_documents"),
        primary_page_count=len(primary) if primary_known else record["result"].get("source_pages_inspected"),
        distinct_snapshot_pages=len(pages) if primary_known else None,
        distinct_referenced_pages=len(pages),
        additional_referenced_or_inspected_pages=len(pages - primary) if primary_known else None,
        meaning=("All eligible pages are lexically scored. Primary page admission is not the full source-search limit: source-owned constituent/type dossiers may reference additional eligible pages. Counts describe saved inspection provenance, not factual support."
            if modern else "The original engine scores eligible document representations, not the modern page matcher. Its native inspection count and cited-page count are separate; missing page-identity accounting is not reported as zero."))


def redaction_presence(grades):
    """Non-exclusive presence flags; partial cited support is not full support."""
    return dict(correct=any(g["answer_match"] == "correct" for g in grades),
        partial=any(g["answer_match"] == "partial" for g in grades),
        directly_supported_correct=any(g["answer_match"] == "correct" and g["evidence_support"] == "direct" for g in grades),
        correct_with_at_least_partial_support=any(g["answer_match"] == "correct" and g["evidence_support"] in {"direct", "partial"} for g in grades))


def explain_neighbor_order(result):
    """Reporting-only comparisons of saved v3.2 priority features, never rerank."""
    if result.get("constructor_version") != "source-owned-candidates/3.2":
        return
    fields = (("visible_actor_reuse", "Reuse of an already visible actor", False),
        ("local_property_match", "Source-attested focal property", True),
        ("positive_slot_kind", "Positive slot-kind fit", True),
        ("focal_anchor_idf", "Focal-context anchor match", True),
        ("full_query_anchor_idf", "Whole-question anchor match", True),
        ("source_owned_role_context", "Source-owned role context", True),
        ("named_person_head_in_matched_context", "Named-person head in matching context", True),
        ("fused_rrf", "Fused retrieval relevance", True),
        ("source_fullness", "Source phrase completeness", True))
    def values(candidate):
        f = candidate.get("v21_features", {})
        if not all(key in f for key, _, _ in fields if key != "named_person_head_in_matched_context"):
            return None
        f = dict(f)
        f["source_owned_role_context"] = f["source_owned_role_context"].get("matched", False)
        f["named_person_head_in_matched_context"] = bool(f.get("named_person_head", False)
            and (f["focal_anchor_idf"] > 0 or f["full_query_anchor_idf"] > 0))
        result = [f[key] for key, _, _ in fields]
        if any(type(v) not in {bool, int, float} or not math.isfinite(v) for v in result):
            return None
        return result
    for row in result.get("readings", []):
        candidates = row["candidates"]
        for i, candidate in enumerate(candidates):
            if len(candidates) < 2:
                continue
            other = candidates[i-1 if i else 1]
            a, b = values(candidate), values(other)
            if a is None or b is None:
                continue
            first = next((n for n, (x, y) in enumerate(zip(a, b)) if x != y), None)
            comparison = dict(version="native-priority-explanation/1", other_fill=other["fill"],
                other_rank=other["rank"], earlier_criteria_tied=True, reranked=False,
                meaning="Ordered relevance criteria, not a correctness probability or a source-support verdict")
            if first is None:
                comparison.update(status="PRIMARY_CRITERIA_TIED", explanation="The displayed primary criteria tie; stable source-occurrence tie breakers decide the order.")
            else:
                key, label, larger = fields[first]
                this_better = a[first] > b[first] if larger else a[first] < b[first]
                consistent = this_better == (candidate["rank"] < other["rank"])
                comparison.update(status="EXPLAINED" if consistent else "NOT_EXPLAINED_BY_DECLARED_PRIORITIES",
                    criterion=key, criterion_label=label, candidate_value=a[first], other_value=b[first],
                    larger_is_preferred=larger, native_order_consistent=consistent)
            candidate["ranking_comparison"] = comparison


def report(root, run_directory=None):
    root = Path(root).resolve()
    directory, manifest, grouped, binding = verified_run(root, run_directory)
    keys = assessment_keys(root, manifest)
    cases, summary = [], defaultdict(Counter)
    for case in manifest["cases"]:
        records = deepcopy(grouped[case["case_id"]])
        assessment = directory / "assessments" / (case["case_id"] + ".json")
        if assessment.exists():
            saved = load(assessment)
            packet, mapping = prepare(case, records, keys.get(case["case_id"], {}).get("answer", ""))
            if saved["sha256"] != digest({k: v for k, v in saved.items() if k != "sha256"}) or packet != saved["packet"]:
                raise ValueError("Assessment packet changed")
            verify_saved(root / "data/development_v2/api", packet, saved["assessment"])
            attach_grades(case, records, mapping, saved["assessment"])
        for arm, record in records.items():
            summary[arm]["cases"] += 1
            summary[arm]["runtime_seconds"] += record["runtime_seconds"]
            result = record["result"]
            if case["task"] == "redaction" and arm != "legacy_reference":
                explain_neighbor_order(result)
            if case["task"] == "redaction" and arm != "legacy_reference":
                rows = result["readings"]
                summary[arm]["redaction_cases"] += 1
                summary[arm]["readings"] += len(record["plan"]["slot_readings"])
                summary[arm]["displayed_candidates"] += sum(len(r["candidates"]) for r in rows)
                if assessment.exists():
                    for k in (1, 3, 5):
                        selected = [p["assessment"] for row in rows for p in row["candidates"][:k]]
                        for name, present in redaction_presence(selected).items():
                            summary[arm][name + "_at_" + str(k)] += present
                    all_grades = [p["assessment"] for row in rows for p in row["candidates"]]
                    summary[arm]["grammatical"] += sum(g["grammatical"] is True for g in all_grades)
                    summary[arm]["graded_candidates"] += len(all_grades)
                    balanced, seen = [], set()
                    for depth in range(5):
                        for row in rows:
                            if depth >= len(row["candidates"]):
                                continue
                            candidate = row["candidates"][depth]
                            identity = candidate.get("node_id"), candidate["fill"].casefold()
                            if identity not in seen:
                                balanced.append(candidate["assessment"]); seen.add(identity)
                    for k in (1, 3, 5):
                        selected = balanced[:k]
                        summary[arm]["correct_matched_total_display_at_" + str(k)] += any(g["answer_match"] == "correct" for g in selected)
                        summary[arm]["partial_matched_total_display_at_" + str(k)] += any(g["answer_match"] == "partial" for g in selected)
            elif arm != "legacy_reference":
                summary[arm]["native_" + result["status"]] += 1
                summary[arm][case["task"] + "_native_" + result["status"]] += 1
                for atom in result.get("atoms", []):
                    if "assessment" in atom:
                        summary[arm][case["task"] + "_assessed_atoms"] += 1
                        summary[arm][case["task"] + "_assessment_" + atom["assessment"]["judgment"]] += 1
            checkpoint = directory / "cases" / (case["case_id"] + "__" + arm + ".json")
            record["native_checkpoint"] = dict(path=str(checkpoint.relative_to(root)), sha256=sha(checkpoint))
            record["inspection_scope"] = inspection_scope(directory, record)
            record["planning_prompts"] = []
            for receipt in record.get("plan", {}).get("receipts", []):
                request_path = root / "data/development_v2/api/requests" / (receipt["request_sha256"] + ".json")
                packet = load(request_path)
                wire = packet["request"]
                record["planning_prompts"].append(dict(stage=receipt.get("stage", packet["stage"]),
                    model=wire["model"], prompt=wire["instructions"]))
            slim_for_browser(result)
            flow = result.get("flow", {})
            expanded = flow.pop("expanded", None)
            if expanded is not None:
                path = root / "web/data/flows-v3" / (directory.name + "__" + case["case_id"] + "__" + arm + "__" + digest(expanded)[:16] + ".json.gz")
                if not path.exists():
                    save_gzip(path, expanded)
                response = json.dumps(expanded, sort_keys=True, ensure_ascii=True, allow_nan=False).encode()
                flow["expanded_ref"] = dict(path=str(path.relative_to(root)), sha256=sha(path),
                    response_sha256=hashlib.sha256(response).hexdigest())
                flow["expanded_lazy"] = True
        value = dict(case=case, configurations=records, reference_answer=keys.get(case["case_id"], {}).get("answer"),
            reference_answer_kind=keys.get(case["case_id"], {}).get("kind", "source_derived_complete_question"),
            selected_demo=True, assessment_available=assessment.exists())
        target = root / "web/data/report-v3-cases" / (directory.name + "__" + case["case_id"] + "__" + digest(value)[:16] + ".json")
        save(target, value)
        stub = {k: v for k, v in value.items() if k != "configurations"}
        stub["case_detail_ref"] = dict(path=str(target.relative_to(root)), sha256=sha(target))
        stub["configurations"] = {a: dict(config=a, runtime_seconds=r["runtime_seconds"], native_checkpoint=r["native_checkpoint"],
            result=dict(status=r["result"].get("status", "SAVED_OUTPUT"))) for a, r in records.items()}
        cases.append(stub)
    indexes = {name: load(directory / (name + "_graph_index.json")) for name in binding["corpora"] if (directory / (name + "_graph_index.json")).exists()}
    output = dict(version="analyst-inspection/3", run_id=directory.name, cases=cases, summary=dict(summary),
        reporting_code_sha256=sha(Path(__file__)),
        source_binding=binding, graph_indexes=indexes, source_directory_v3=str((directory / "sources").relative_to(root)),
        api_cost_usd=Budget(root / "data/development_v2/api").total(), settings=manifest["settings"],
        population="Outcome-informed development/demo selection, not an accuracy estimate",
        metrics="Non-additive presence metrics at any-reading ranks1/3/5, plus matched-total-budget round-robin in declared reading order. A case may have both correct and partial candidates. No global answer list is shown; original whole-query verdict references are not atom/rank units.",
        runtime_note="Sequential local execution shares a bounded raw syntax-parse cache across conditions. Recorded wall times are operational measurements, not matched cold-start arm benchmarks.",
        assessment_note="Redaction packets hide native support labels; their judgment field is not defined as a native-verdict assessment and is not scored. Use answer match, source support and grammar separately. Task-verdict packets include the saved native decision, for which judgment is defined.",
        control_note="B and C have identical hypothesis/reconstruction planning and searches; those repeated runs are consistency controls, not independent treatments or samples. A versus C also changes discovery questions and does not isolate reading origin alone.",
        historical_policy="Strict earlier-only evidence and whole-origin exclusion; identity/hierarchy retrospective",
        reference_limitation="Original parser, lexical retrieval and task engines with source adapter; optional original graph augmentation not reproduced")
    output["sha256"] = digest(output)
    save(directory / "inspection_report.json", output)
    save(root / "web/data/report-v3.json", output)
    return dict(run_id=directory.name, cases=len(cases), summary=dict(summary), api_cost_usd=output["api_cost_usd"], url="http://127.0.0.1:8930/workbench-v3.html")
