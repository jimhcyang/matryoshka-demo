"""Certified all-depth routing, not probabilities of factual correctness.

The restart series sums arbitrarily long walks without enumerating them.
First-hit exposure counts reaching a destination before geometric termination;
stationary mass instead counts discounted visits, including revisits.
"""
from __future__ import annotations

from dataclasses import dataclass
import heapq
import math

import numpy as np
from scipy import sparse


@dataclass
class WalkResult:
    values: np.ndarray
    iterations: int
    residual: float
    error_bound: float
    norm: str


def _nonnegative(values, name):
    result = np.asarray(values, dtype=np.float64)
    if result.ndim != 1 or not np.isfinite(result).all() or (result < 0).any():
        raise ValueError(f"{name} must be a finite nonnegative vector")
    return result


def normalize_prior(values, active=None):
    prior = _nonnegative(values, "prior").copy()
    if active is not None:
        mask = np.asarray(active, dtype=bool)
        if mask.shape != prior.shape:
            raise ValueError("Prior and eligibility mask differ")
        prior[~mask] = 0
    total = float(prior.sum())
    return prior / total if total else prior


def transition(adjacency, relevance=None, *, attention=0.0, communities=None,
               community_balanced=False, active=None):
    """Row-normalize eligible support; optionally apply declared routing policies.

    attention=0 is the ordinary support-weighted walk. Positive attention uses
    exp(attention * max-normalized BM25 destination relevance), a proposed
    routing variant rather than an established confidence model. Community
    balancing chooses a reachable community uniformly, then a supported edge.
    Neither operation adds a factual edge. Isolates receive numerical self-loops.
    """
    matrix = sparse.csr_matrix(adjacency, dtype=np.float64).copy()
    matrix.sum_duplicates()
    matrix.eliminate_zeros()
    if matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Adjacency must be square")
    if not np.isfinite(matrix.data).all() or (matrix.data < 0).any():
        raise ValueError("Adjacency must be finite and nonnegative")
    n = matrix.shape[0]
    mask = np.ones(n, dtype=bool) if active is None else np.asarray(active, dtype=bool)
    if mask.shape != (n,):
        raise ValueError("Eligibility mask has wrong shape")
    matrix = sparse.diags(mask.astype(float)) @ matrix @ sparse.diags(mask.astype(float))
    matrix = matrix.tocsr()
    matrix.eliminate_zeros()
    if not math.isfinite(attention) or not 0 <= attention <= 100:
        raise ValueError("Attention must be finite, nonnegative and numerically safe")
    if attention:
        rel = _nonnegative(relevance, "relevance")
        if rel.shape != (n,):
            raise ValueError("Relevance has wrong shape")
        scale = float(rel[mask].max(initial=0))
        if scale:
            matrix.data *= np.exp(attention * rel[matrix.indices] / scale)
    if community_balanced:
        if communities is None or len(communities) != n:
            raise ValueError("Community balancing requires one assignment per node")
        labels = np.asarray(communities)
        for u in range(n):
            a, b = matrix.indptr[u:u+2]
            if a == b:
                continue
            groups, inverse = np.unique(labels[matrix.indices[a:b]], return_inverse=True)
            masses = np.bincount(inverse, weights=matrix.data[a:b])
            matrix.data[a:b] /= masses[inverse] * len(groups)
    totals = np.asarray(matrix.sum(axis=1)).ravel()
    inverse = np.zeros(n)
    np.divide(1, totals, out=inverse, where=totals > 0)
    matrix = (sparse.diags(inverse) @ matrix).tocsr()
    dangling = mask & (totals == 0)
    matrix = matrix + sparse.diags(dangling.astype(float))
    matrix.eliminate_zeros()
    return matrix.tocsr()


def _validate_kernel(matrix, prior, alpha, tolerance):
    matrix = sparse.csr_matrix(matrix, dtype=np.float64)
    prior = _nonnegative(prior, "prior")
    if matrix.shape != (len(prior), len(prior)):
        raise ValueError("Kernel/prior dimension mismatch")
    if not np.isfinite(matrix.data).all() or (matrix.data < 0).any():
        raise ValueError("Invalid transition values")
    sums = np.asarray(matrix.sum(axis=1)).ravel()
    if (sums > 1 + 1e-12).any():
        raise ValueError("Transition rows cannot exceed one")
    if not 0 < alpha < 1 or not 0 < tolerance < 1:
        raise ValueError("Require 0 < alpha,tolerance < 1")
    if prior.sum() and not np.isclose(prior.sum(), 1):
        raise ValueError("Nonempty prior must sum to one")
    return matrix, prior


def personalized_walk(matrix, prior, *, alpha=0.85, tolerance=1e-8,
                      max_iterations=100_000):
    """All-depth restart walk with an explicit global L1 error certificate."""
    matrix, prior = _validate_kernel(matrix, prior, alpha, tolerance)
    if not prior.sum():
        return WalkResult(np.zeros_like(prior), 0, 0, 0, "L1")
    values = prior.copy()
    transpose = matrix.T.tocsr()
    for iteration in range(1, max_iterations + 1):
        updated = (1-alpha) * prior + alpha * (transpose @ values)
        delta = float(np.abs(updated-values).sum())
        values = updated
        if alpha * delta / (1-alpha) <= tolerance:
            residual = float(np.abs(values - ((1-alpha)*prior + alpha*(transpose @ values))).sum())
            return WalkResult(values, iteration, residual, residual/(1-alpha), "L1")
    raise RuntimeError("Restart walk did not meet its numerical certificate")


def discounted_first_hit(matrix, prior, targets, *, alpha=0.85,
                         tolerance=1e-8, max_iterations=100_000, return_values=False):
    """Probability of first reaching any target before geometric termination.

    This is a routing-event probability under the declared Markov model. It
    is not factual confidence, and target IDs are allowed only in diagnostics.
    """
    matrix, prior = _validate_kernel(matrix, prior, alpha, tolerance)
    ids = np.asarray(sorted(set(int(i) for i in targets)), dtype=int)
    if (ids < 0).any() or (ids >= len(prior)).any():
        raise ValueError("Invalid target index")
    values = np.zeros(len(prior))
    values[ids] = 1
    if not len(ids):
        result=dict(exposure=0.0, iterations=0, error_bound=0.0, residual=0.0)
        if return_values:result['values']=values
        return result
    for iteration in range(1, max_iterations+1):
        updated = alpha * (matrix @ values)
        updated[ids] = 1
        delta = float(np.abs(updated-values).max(initial=0))
        values = updated
        if alpha * delta/(1-alpha) <= tolerance:
            check = alpha * (matrix @ values)
            check[ids] = 1
            residual = float(np.abs(values-check).max(initial=0))
            result=dict(exposure=float(prior @ values), iterations=iteration,
                        error_bound=residual/(1-alpha), residual=residual)
            if return_values:result['values']=values
            return result
    raise RuntimeError("First-hit solver did not meet its numerical certificate")


def discounted_edge_hit(matrix,prior,edges,*,alpha=.85,tolerance=1e-8,max_iterations=100_000):
    """First traversal of a supplied directed edge set before termination.

    This is traversal of a projected node pair, not selection or reading of a
    particular supporting quotation. Parallel relations can share a node pair.
    """
    matrix,prior=_validate_kernel(matrix,prior,alpha,tolerance)
    blocked=matrix.tolil(copy=True);arrival=np.zeros(len(prior))
    for u,v in sorted(set((int(u),int(v))for u,v in edges)):
        if not(0<=u<len(prior)and 0<=v<len(prior)):raise ValueError('Invalid edge index')
        arrival[u]+=float(matrix[u,v]);blocked[u,v]=0
    remainder=blocked.tocsr();values=np.zeros(len(prior))
    for iteration in range(1,max_iterations+1):
        updated=alpha*(arrival+remainder@values)
        delta=float(np.abs(updated-values).max(initial=0));values=updated
        if alpha*delta/(1-alpha)<=tolerance:
            residual=float(np.abs(values-alpha*(arrival+remainder@values)).max(initial=0))
            return dict(exposure=float(prior@values),iterations=iteration,error_bound=residual/(1-alpha),residual=residual)
    raise RuntimeError('Edge first-hit solver did not meet its numerical certificate')


def maximum_product_witness(matrix, prior, targets, *, alpha=0.85):
    """Most probable single finite discovery walk, without a hop cutoff.

    Dijkstra uses -log(seed mass) and -log(alpha * transition). Actual
    numerical self-loops are skipped. The returned witness is not all paths
    and is not the total first-hit probability.
    """
    matrix, prior = _validate_kernel(matrix, prior, alpha, 1e-8)
    ends = set(int(v) for v in targets)
    if any(v < 0 or v >= len(prior) for v in ends):
        raise ValueError("Invalid target index")
    distances = np.full(len(prior), np.inf)
    previous = np.full(len(prior), -1, dtype=int)
    queue = []
    for v in np.flatnonzero(prior > 0):
        distances[v] = -math.log(float(prior[v]))
        heapq.heappush(queue, (float(distances[v]), int(v)))
    expanded = 0
    while queue:
        cost, u = heapq.heappop(queue)
        if cost > distances[u]:
            continue
        expanded += 1
        if u in ends:
            nodes = [u]
            while previous[nodes[-1]] >= 0:
                nodes.append(int(previous[nodes[-1]]))
            nodes.reverse()
            hops = []
            for a, b in zip(nodes, nodes[1:]):
                probability = float(matrix[a, b])
                hops.append(dict(source=a, target=b, transition=probability,
                                 discounted_transition=alpha*probability))
            return dict(status="connected", nodes=nodes, hops=hops,
                        path_probability=math.exp(-cost), negative_log_probability=cost,
                        expanded_nodes=expanded,
                        interpretation="Single routing witness, not answer truth or total path mass")
        a, b = matrix.indptr[u:u+2]
        for v, probability in zip(matrix.indices[a:b], matrix.data[a:b]):
            if u == v:
                continue
            candidate = cost - math.log(alpha * float(probability))
            if candidate < distances[v]:
                distances[v] = candidate
                previous[v] = u
                heapq.heappush(queue, (float(candidate), int(v)))
    return dict(status="unreachable_from_prior", nodes=[], hops=[], path_probability=0.0,
                negative_log_probability=None, expanded_nodes=expanded)


def block_factorization_error(matrix, communities):
    """Verify grouping a transition by community does not change its kernel."""
    matrix = sparse.csr_matrix(matrix)
    if len(communities) != matrix.shape[0]:
        raise ValueError("Community assignment length differs")
    labels = np.asarray(communities)
    error = 0.0
    for u in range(matrix.shape[0]):
        a, b = matrix.indptr[u:u+2]
        if a == b:
            continue
        _, inverse = np.unique(labels[matrix.indices[a:b]], return_inverse=True)
        masses = np.bincount(inverse, weights=matrix.data[a:b])
        reconstructed = masses[inverse] * (matrix.data[a:b]/masses[inverse])
        error = max(error, float(np.abs(reconstructed-matrix.data[a:b]).max(initial=0)))
    return error
