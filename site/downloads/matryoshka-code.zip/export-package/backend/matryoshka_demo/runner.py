"""Offline, source-pinned experiments with atomic, tamper-checked checkpoints."""
from datetime import datetime, timezone
import fcntl
import gc
import importlib.metadata
from pathlib import Path
import platform
import time

from .candidates import construct
from .contracts import public_case
from .corpus import Corpus
from .io import digest, disk_guard, load, offline, save, save_gzip, sha
from .integrity import verify_auxiliary, verify_condition, verify_sources
from .planning import LocalParser, plan
from .retrieval import retrieve
from .tasks import evaluate_claim, parser


CONFIGS = {
    "documents_spacy": dict(parser="spacy", method="documents", morphology=False),
    "lemma_spacy": dict(parser="spacy", method="documents", morphology=True),
    "graph_spacy": dict(parser="spacy", method="graph", morphology=False),
    "hierarchy_spacy": dict(parser="spacy", method="hierarchy", morphology=False),
    "documents_stanza": dict(parser="stanza", method="documents", morphology=False),
    "documents_symbolic": dict(parser="symbolic", method="documents", morphology=False),
    "graph_roles_spacy": dict(parser="spacy", method="graph", morphology=False, source_roles=True),
    "kg_statements_spacy": dict(parser="spacy", method="documents", morphology=False, derived_statements=True),
}


def code_binding(root):
    root = Path(root)
    paths = sorted((root / "matryoshka_demo").rglob("*.py")) + sorted((root / "contracts").glob("*.json"))
    return {str(p.relative_to(root)):sha(p) for p in paths}


def environment_binding(root):
    model = parser().nlp.path
    return dict(python=platform.python_version(), packages={p:importlib.metadata.version(p) for p in
        ("numpy", "scipy", "scikit-learn", "spacy", "en_core_web_sm", "stanza", "nltk")},
        spacy_model_files={str(p.relative_to(model)):sha(p) for p in sorted(model.rglob("*")) if p.is_file()},
        stanza_model_files={str(p.relative_to(root)):sha(p) for p in sorted((root/"data/models/stanza").rglob("*.pt"))},
        wordnet_resource_sha256=sha(root/"data/models/nltk/corpora/wordnet.zip") if (root/"data/models/nltk/corpora/wordnet.zip").exists() else None)


def checked(path):
    value = load(path)
    if digest(value["payload"]) != value["sha256"]:
        raise ValueError("Checkpoint content changed: " + str(path))
    return value["payload"]


def write_checkpoint(path, payload):
    save(path, dict(payload=payload, sha256=digest(payload)))


def load_inputs(path):
    value=load(path)
    expected={"version","factory_sha256","binding_sha256","cases","controls","sha256"}
    if set(value)!=expected or value["version"]!="public-demo-inputs/1":
        raise ValueError("Inference requires the public-only input release, not a factory/evaluation manifest")
    if digest({k:v for k,v in value.items() if k!="sha256"})!=value["sha256"]:
        raise ValueError("Public input release changed")
    for case in value["cases"]+value["controls"]:
        if case!=public_case(case): raise ValueError("Unexpected nonpublic case fields")
    ids=[c["case_id"] for c in value["cases"]+value["controls"]]
    if len(ids)!=len(set(ids)): raise ValueError("Duplicate public case identities")
    return value


def run(workspace, root, *, binding_path=None, catalog_path=None, configs=None,
        include_controls=False, corpus_filter=None, limit=None, passage_budget=100, document_budget=100):
    root = Path(root).resolve(); workspace = Path(workspace).resolve()
    binding = load(binding_path or root / "data/bindings.json")
    catalog = load_inputs(catalog_path or root / "data/catalog_v1/inference_catalog.json")
    if digest({k:v for k,v in binding.items() if k != "sha256"}) != binding["sha256"]:
        raise ValueError("Binding manifest changed")
    if digest({k:v for k,v in catalog.items() if k != "sha256"}) != catalog["sha256"] or catalog["binding_sha256"] != binding["sha256"]:
        raise ValueError("Catalog is not bound to these sources")
    configs = configs or list(CONFIGS)
    if not set(configs) <= CONFIGS.keys(): raise ValueError("Unknown comparison configuration")
    if len(configs)!=len(set(configs)) or document_budget<1 or passage_budget<1:
        raise ValueError("Configurations must be unique and retrieval budgets positive")
    cases = catalog["cases"] + (catalog["controls"] if include_controls else [])
    cases = [public_case(c) for c in cases if not corpus_filter or c["corpus"] == corpus_filter]
    if limit is not None: cases = cases[:limit]
    settings = dict(configs={k:CONFIGS[k] for k in configs}, document_budget=document_budget,
        passage_budget=passage_budget, case_ids=[c["case_id"] for c in cases],
        rrf_k=60, graph_alpha=.85, graph_attention=1., tolerance=1e-8, display_per_lane=5,
        no_leads=True, no_generated_keywords=True, keys_read=False, grades_read=False, api_calls=0)
    identity = dict(code=code_binding(root), environment=environment_binding(root), binding_sha256=binding["sha256"],
                    catalog_sha256=catalog["sha256"], public_inputs_only=True, settings=settings,
                    assessment_release_sha256=sha(Path(catalog_path or root/"data/catalog_v1/inference_catalog.json").parent/"assessment_release.json"))
    run_id = "local_" + digest(identity)[:20]
    directory = root / "data/runs" / run_id; directory.mkdir(parents=True, exist_ok=True)
    disk_guard(directory)
    lock = (directory / "run.lock").open("a+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise RuntimeError("This exact experiment is already running") from None
    manifest = directory / "manifest.json"
    if manifest.exists():
        if load(manifest) != identity: raise ValueError("Frozen run manifest changed")
    else: save(manifest, identity)
    progress = dict(run_id=run_id, status="RUNNING", expected=len(cases)*len(configs), completed=0,
        failures=[], started_utc=datetime.now(timezone.utc).isoformat(), settings=settings)
    save(directory / "progress.json", progress)
    planners = {}
    try:
        with offline():
            expected_files={c["case_id"]+"__"+config+".json" for c in cases for config in configs}
            if {p.name for p in (directory/"cases").glob("*.json")} - expected_files:
                raise ValueError("Unexpected checkpoint condition in the run")
            # Hash source files even when every result is already cached.
            verify_sources(workspace,binding,dict.fromkeys(c["corpus"] for c in cases))
            source_cache={}
            for corpus_name in dict.fromkeys(c["corpus"] for c in cases):
                relevant = [c for c in cases if c["corpus"] == corpus_name]
                pending = [(c, config) for c in relevant for config in configs
                           if not (directory / "cases" / (c["case_id"] + "__" + config + ".json")).exists()]
                if pending:
                    print("Loading", corpus_name, flush=True)
                    corpus = Corpus(workspace, binding["corpora"][corpus_name])
                    save(directory / (corpus_name + "_source_counts.json"), corpus.counts)
                for c in relevant:
                    for config in configs:
                        disk_guard(directory)
                        target = directory / "cases" / (c["case_id"] + "__" + config + ".json")
                        if target.exists():
                            payload=checked(target)
                            verify_condition(payload,c,config,run_id,binding["sha256"])
                            verify_auxiliary(directory,payload,source_cache)
                            progress["completed"] += 1; continue
                        cfg = CONFIGS[config]; started = time.perf_counter()
                        try:
                            if cfg["parser"] not in planners:
                                planners[cfg["parser"]] = LocalParser(cfg["parser"], root / "data/models/stanza")
                            parsed = plan(c, planners[cfg["parser"]])
                            retrieval = retrieve(corpus, c, parsed, method=cfg["method"], morphology=cfg["morphology"],
                                document_budget=document_budget, passage_budget=passage_budget)
                            result = (construct(c, parsed, retrieval, passage_budget=passage_budget, source_roles=cfg.get("source_roles", False)) if c["task"] == "redaction"
                                      else evaluate_claim(c, retrieval, passage_budget=passage_budget, include_derived=cfg.get("derived_statements", False)))
                            audit = result.pop("_candidate_audit", None)
                            if audit:
                                audit_path = directory / "candidate_audits" / (target.stem + ".json.gz")
                                save_gzip(audit_path, audit)
                                result["candidate_audit_ref"] = dict(path=str(audit_path.relative_to(directory)), sha256=sha(audit_path))
                            payload = dict(case=c, config=config, plan=parsed, result=result,
                                runtime_seconds=round(time.perf_counter()-started, 4), binding_sha256=binding["sha256"],
                                run_id=run_id, inference_network_access=False)
                            source_indices = set(inspected_pages(result, corpus))
                            if audit:
                                source_indices.update(corpus.page_index[k] for k in audit["inspected_page_ids"])
                                source_indices.update(corpus.page_index[s["canonical_page_id"]]
                                    for r in audit["readings"] for p in r["proposals"] for s in p["sources"])
                            for pi in sorted(source_indices):
                                page = corpus.pages[pi]
                                if not retrieval["eligible"].page_mask[pi]: raise ValueError("Ineligible source leaked into the result")
                                source_path = directory / "sources" / (page["id"] + ".json")
                                if source_path.exists() and load(source_path) != page: raise ValueError("Saved source changed")
                                if not source_path.exists(): save(source_path, page)
                            if code_binding(root) != identity["code"]:
                                raise RuntimeError("Code changed during execution; preserve this attempt and start a new version")
                            verify_condition(payload,c,config,run_id,binding["sha256"])
                            verify_auxiliary(directory,payload,source_cache)
                            write_checkpoint(target, payload)
                            progress["completed"] += 1
                            print(f'{progress["completed"]}/{progress["expected"]} {corpus_name} {c["task"]} {config} {payload["runtime_seconds"]}s', flush=True)
                        except Exception as error:
                            receipt = dict(case_id=c["case_id"], config=config, error=repr(error))
                            progress["failures"].append(receipt)
                            save(directory / "failures" / (target.name), receipt)
                            raise
                        finally:
                            save(directory / "progress.json", progress)
                if pending: del corpus
                parser().cache_clear(); gc.collect()
        progress["status"] = "COMPLETE"
    except BaseException as error:
        progress["status"] = "PAUSED_OR_FAILED"; progress["last_error"] = repr(error)
        raise
    finally:
        save(directory / "progress.json", progress)
        fcntl.flock(lock, fcntl.LOCK_UN); lock.close()
    save(root / "data/latest_run.json", dict(run_id=run_id, directory=str(directory), manifest_sha256=sha(manifest)))
    return progress


def inspected_pages(result, corpus):
    ids = set()
    for reading in result.get("readings", []):
        for candidate in reading["evidence_candidates"] + reading["exploratory_candidates"]:
            ids.update(s["canonical_page_id"] for s in candidate["sources"])
            route = candidate.get("discovery_route")
            if route:
                for hop in route["hops"]: ids.update(s["canonical_page_id"] for s in hop["citations"])
    for atom in result.get("atoms", []): ids.update(e["canonical_page_id"] for e in atom["evidence"])
    witness = result["retrieval"].get("graph_witness")
    if witness:
        for hop in witness["hops"]: ids.update(e["canonical_page_id"] for e in hop["citations"])
    return [corpus.page_index[k] for k in sorted(ids)]
