"""Source-visible identity-anchor and person-head syntax, never answer lookup.

Generic entity classes remain in retrieval text and functional cues. Fully
uppercase query text has unavailable case information and retains all anchors.
A named head is a binary ranking hint, not an entity-type or event-support fact.
"""
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.candidates_v2 import source_parser

VERSION = "source-visible-identity-anchors/2.4"


def classify_anchors(case, anchors, parse=None):
    parse = parse or source_parser()
    visible = MASK.sub(lambda m:" " * len(m.group()), case["query"])
    if visible.isupper():
        return {a:dict(keep_identity_weight=True, status="UPPERCASE_QUERY_CASE_UNAVAILABLE_KEEP",
            query_occurrences=[], retained_in_query_and_retrieval=True) for a in dict.fromkeys(anchors)}
    doc = parse(visible)
    result = {}
    for anchor in dict.fromkeys(anchors):
        occurrences = []
        for match in re.finditer(re.escape(anchor), visible):
            span = doc.char_span(match.start(), match.end(), alignment_mode="strict")
            if span is None:
                continue
            head = span.root
            partial = (head.dep_ in {"compound", "flat", "flat:name"}
                and head.head.pos_ == "PROPN" and not span.start <= head.head.i < span.end)
            independent_named_ner = head.ent_type_ in {"PERSON", "ORG", "GPE", "LOC"}
            proper = (not partial and (independent_named_ner or head.pos_ == "PROPN"
                and not (head.text.islower() and head.lemma_.islower())
                and not (head.ent_type_ == "NORP" and head.tag_ == "NNS")))
            occurrences.append(dict(start=match.start(), end=match.end(), head=head.text,
                pos=head.pos_, tag=head.tag_, ner=head.ent_type_, partial_name=partial, proper_head=proper))
        keep = not occurrences or any(o["proper_head"] for o in occurrences)
        result[anchor] = dict(keep_identity_weight=keep,
            status="PROPER_HEAD" if occurrences and keep else "UNRESOLVED_KEEP" if not occurrences else "GENERIC_OR_PARTIAL_NAME",
            query_occurrences=occurrences, retained_in_query_and_retrieval=True)
    return result


def named_head(span, reading, source_fit):
    """Binary source-head control, not a PROPN count or a new type assertion."""
    head = span.root
    return (reading.get("target_kind") == "person" and head.pos_ == "PROPN"
        and (source_fit.get("known_kind") == "person" or head.ent_type_ in {"", "PERSON"}))
