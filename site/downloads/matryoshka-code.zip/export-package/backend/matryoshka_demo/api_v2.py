"""Explicit, metered API stages; ordinary retrieval never imports this module."""
from datetime import datetime, timezone
import fcntl
import json
import math
import os
from pathlib import Path
import uuid

from .io import digest, load, save

RATES={"gpt-6-luna":(.10,.50),"gpt-6.1-sol":(2.,10.)}
VERSION="demo-paid-stages/2"


def utc(): return datetime.now(timezone.utc).isoformat()


def transport_policy():
    """Operational deadlines, not model settings or automatic retry permission."""
    values = dict(connect_seconds=float(os.environ.get("MATRYOSHKA_API_CONNECT_SECONDS", "15")),
        response_seconds=float(os.environ.get("MATRYOSHKA_API_RESPONSE_SECONDS", "300")))
    if any(not math.isfinite(v) or v <= 0 for v in values.values()):
        raise ValueError("API transport deadlines must be positive finite seconds")
    return dict(version="separate-connect-response-deadlines/1", **values, automatic_sdk_retries=0)


class Budget:
    def __init__(self,root,cap=25.):
        if type(cap) not in (int,float) or not 0 < cap <= 25:
            raise ValueError("This development authorization has a hard $25 ceiling")
        self.root=Path(root);self.cap=float(cap);self.root.mkdir(parents=True,exist_ok=True)

    def total(self):
        values=[load(p)["charged_or_reserved_usd"] for p in (self.root/"receipts").glob("*.json")]
        if any(type(v) not in (int,float) or not 0<=v<=25 for v in values):
            raise ValueError("Invalid budget receipt")
        return sum(values)

    def reserve(self,request,reserve):
        with (self.root/"budget.lock").open("a+") as lock:
            fcntl.flock(lock,fcntl.LOCK_EX)
            if self.total()+reserve>self.cap: raise RuntimeError("Development API cap reached; checkpoints preserved")
            path=self.root/"receipts"/(uuid.uuid4().hex+".json")
            record=dict(status="RESERVED",request_sha256=digest(request),model=request["model"],
                charged_or_reserved_usd=reserve,started_utc=utc(),cap_usd=self.cap,
                pricing="Workspace listed prices; not a provider invoice",rates=RATES[request["model"]])
            save(path,record)
            return path,record


def request(stage,payload,prompt,schema,*,model="gpt-6-luna",max_output_tokens=8192):
    if model not in RATES: raise ValueError("Model has no recorded price profile")
    value=dict(model=model,instructions=prompt,input=[dict(role="user",content=[dict(type="input_text",
        text=json.dumps(payload,ensure_ascii=True,sort_keys=True))])],
        text=dict(format=dict(type="json_schema",name=stage,strict=True,schema=schema)),
        max_output_tokens=max_output_tokens,store=False)
    if model=="gpt-6-luna": value.update(temperature=0.,reasoning=dict(effort="none"))
    else: value["reasoning"]=dict(effort="low")
    return value


def _call_inner(root,stage,payload,prompt,schema,*,model="gpt-6-luna",max_output_tokens=8192,cap=25.,client=None):
    """One paid attempt; errors retain reservations and never trigger SDK retries."""
    import jsonschema
    wire=request(stage,payload,prompt,schema,model=model,max_output_tokens=max_output_tokens)
    key=digest(dict(version=VERSION,endpoint="https://api.openai.com/v1",stage=stage,request=wire))
    budget=Budget(root,cap);cache=budget.root/"cache"/(key+".json")
    if cache.exists():
        record=load(cache)
        if record["request"]!=wire or digest(record["output"])!=record["output_sha256"]:
            raise ValueError("API cache identity/content changed")
        if not record.get("receipt_path") or load(budget.root/record["receipt_path"])["status"]!="PASS":
            raise ValueError("API cache has no successful usage receipt")
        jsonschema.validate(record["output"],schema)
        return record["output"],dict(request_sha256=key,cache=True,receipt=record["receipt_path"])
    policy = transport_policy() if client is None else None
    in_rate,out_rate=RATES[model]
    reserve=((len(json.dumps(wire,ensure_ascii=True).encode())+4096)*in_rate+max_output_tokens*out_rate)/1e6
    receipt,record=budget.reserve(wire,reserve)
    attempt=budget.root/"attempts"/receipt.stem
    record=dict(record,attempt_ref=str(attempt.relative_to(budget.root)))
    if policy is not None:
        record["transport_policy"] = policy
    save(receipt,record)
    save(attempt/"request.json",wire)
    save(budget.root/"requests"/(key+".json"),dict(version=VERSION,stage=stage,request=wire,request_sha256=key))
    try:
        if client is None:
            from openai import OpenAI
            import httpx
            client=OpenAI(api_key=os.environ.get("OPENAI_API_KEY"),base_url="https://api.openai.com/v1",
                max_retries=0,timeout=httpx.Timeout(policy["response_seconds"],
                    connect=policy["connect_seconds"],pool=policy["connect_seconds"]))
        response=client.responses.create(**wire)
        raw=response.model_dump(mode="json") if hasattr(response,"model_dump") else response
        save(attempt/"response.json",raw)
        current_response=budget.root/"responses"/(key+".json")
        if current_response.exists():
            previous=load(current_response)
            archive=budget.root/"response_history"/(key+"__"+digest(previous)[:16]+".json")
            if not archive.exists():save(archive,previous)
        save(current_response,raw)
        usage=raw.get("usage") or {}
        if not {"input_tokens","output_tokens"}<=usage.keys(): raise ValueError("Missing usage; reservation retained")
        actual=(usage["input_tokens"]*in_rate+usage["output_tokens"]*out_rate)/1e6
        save(receipt,dict(record,status="PASS",charged_or_reserved_usd=actual,usage=usage,
            response_id=raw.get("id"),finished_utc=utc()))
        if actual>reserve or budget.total()>cap: raise RuntimeError("Usage exceeded conservative reservation")
        if raw.get("status")!="completed": raise ValueError("Provider response did not complete")
        texts=[p["text"] for item in raw.get("output",[]) if item.get("type")=="message"
            for p in item.get("content",[]) if p.get("type")=="output_text"]
        if len(texts)!=1: raise ValueError("Exactly one structured response is required")
        output=json.loads(texts[0]);jsonschema.validate(output,schema)
        relative=str(receipt.relative_to(budget.root))
        save(cache,dict(version=VERSION,request=wire,output=output,output_sha256=digest(output),receipt_path=relative))
        return output,dict(request_sha256=key,cache=False,receipt=relative)
    except BaseException as error:
        current=load(receipt)
        save(receipt,dict(current,status="PAID_INVALID_OUTPUT" if current["status"]=="PASS" else "FAILED_UNKNOWN_BILLING",
            error_type=type(error).__name__,finished_utc=utc()))
        raise


def call(root,stage,payload,prompt,schema,*,model="gpt-6-luna",max_output_tokens=8192,cap=25.,client=None):
    """Serialize identical wires across resumptions before checking their cache."""
    wire=request(stage,payload,prompt,schema,model=model,max_output_tokens=max_output_tokens)
    key=digest(dict(version=VERSION,endpoint="https://api.openai.com/v1",stage=stage,request=wire))
    budget=Budget(root,cap)
    directory=budget.root/"request_locks";directory.mkdir(parents=True,exist_ok=True)
    with (directory/(key+".lock")).open("a+") as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        try:
            return _call_inner(root,stage,payload,prompt,schema,model=model,
                max_output_tokens=max_output_tokens,cap=cap,client=client)
        finally:
            fcntl.flock(lock,fcntl.LOCK_UN)
