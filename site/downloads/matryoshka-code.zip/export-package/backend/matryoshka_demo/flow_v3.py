"""Deterministic replay views of real restart-walk iterations.

Display budgets never prune the solver. 'Other' is a sum of omitted states,
not a state in the kernel. Source-page readouts are explicitly not graph hops.
"""
from collections import Counter
import heapq
import re

import numpy as np
from scipy import sparse

from .graph_kernel import maximum_product_witness
from .hierarchy import HierarchyBundle


VERSION = "conserved-discovery-flow/3"


def provenance_kernel(eligible, bundle, page_prior):
    """Experimental typed walk with eligible pages and documents as real states.

    Compare against the unchanged semantic/hierarchy kernel. Equal nonempty
    outgoing relation-type budgets avoid degree-based modality weighting. This
    is an explicit design control, not a learned or correctness probability.
    """
    c = eligible.corpus
    pages = [int(i) for i in np.flatnonzero(eligible.page_mask)]
    docs = sorted({c.pages[i]["document_id"] for i in pages})
    n = len(bundle.state_ids)
    page_indices = {pi: n + j for j, pi in enumerate(pages)}
    doc_indices = {doc: n + len(pages) + j for j, doc in enumerate(docs)}
    ids = list(bundle.state_ids) + ["page:" + c.pages[i]["id"] for i in pages] + ["document:" + d for d in docs]
    kinds = list(bundle.state_types) + ["page"] * len(pages) + ["document"] * len(docs)
    edges = {key: dict(value) for key, value in bundle.structural_edges.items()}
    for ui, ni in c.membership:
        if not eligible.unit_mask[ui]:
            continue
        pi = c.units[ui]["pi"]
        for a, b in ((ni, page_indices[pi]), (page_indices[pi], ni)):
            edges[a, b] = dict(kind="SOURCE_PROVENANCE", weight=1.)
    for pi, index in page_indices.items():
        doc = doc_indices[c.pages[pi]["document_id"]]
        edges[index, doc] = dict(kind="DOCUMENT_MEMBERSHIP", weight=1.)
        edges[doc, index] = dict(kind="DOCUMENT_MEMBERSHIP", weight=1.)
    buckets = {}
    for (u, v), edge in edges.items():
        buckets.setdefault(u, {}).setdefault((edge["kind"], kinds[v]), []).append((v, edge))
    aa, bb, weights = [], [], []
    for u, groups in buckets.items():
        for group in groups.values():
            values = np.array([e["weight"] for _, e in group], dtype=float)
            values /= values.sum() * len(groups)
            for (v, edge), value in zip(group, values):
                edge["transition"] = float(value)
                aa.append(u); bb.append(v); weights.append(float(value))
    prior = np.zeros(len(ids))
    modalities = int(bundle.prior.any()) + int(np.asarray(page_prior).any())
    if modalities:
        prior[:n] = bundle.prior / modalities
        total = float(np.asarray(page_prior)[pages].sum())
        if total:
            for pi, index in page_indices.items():
                prior[index] = float(page_prior[pi]) / total / modalities
    metadata = dict(bundle.metadata, version="eligible-provenance-walk/3",
        experimental=True, page_indices=page_indices, document_indices=doc_indices,
        transition_policy="Uniform nonempty edge-kind/destination-type buckets; support within bucket",
        prior_policy="Equal nonempty semantic and BM25-page modalities",
        provenance_is_factual_relation=False)
    return HierarchyBundle(sparse.csr_matrix((weights, (aa, bb)), shape=(len(ids), len(ids))),
        prior, bundle.semantic_count, ids, kinds, edges, metadata)


def _short(text, limit=88):
    text = re.sub(r"\s+", " ", str(text)).strip()
    return text if len(text) <= limit else text[:limit].rsplit(" ", 1)[0] + "..."


def state_label(eligible, bundle, index, final):
    c = eligible.corpus
    if index < bundle.semantic_count:
        mentions = [c.occurrences[j] for j in c.occurrences_by_node.get(c.node_ids[index], [])
            if eligible.surface_mask[j]]
        label = mentions[0]["label"] if mentions else c.nodes[c.node_ids[index]].get("kind", "Source concept")
        return _short(label), c.nodes[c.node_ids[index]].get("kind", "semantic")
    kind = bundle.state_types[index]
    if kind in {"page", "document"}:
        key = "page_indices" if kind == "page" else "document_indices"
        original = next(k for k, v in bundle.metadata[key].items() if v == index)
        page = c.pages[int(original)] if kind == "page" else next(p for i,p in enumerate(c.pages)
            if p["document_id"] == original and eligible.page_mask[i])
        pi = c.page_index[page["id"]]
        mentions = [c.occurrences[j] for j in c.occurrences_by_page.get(pi, []) if eligible.surface_mask[j]]
        mentions.sort(key=lambda m: (m.get("source_type") not in {"claims", "events"}, m["label"]))
        title = page.get("title") or (mentions[0]["label"] if mentions else "Source passage dated " + page["date"])
        return _short(title), kind
    group = next((g for g in bundle.metadata.get("groups", []) if g["index"] == index), None)
    if not group:
        return kind.capitalize() + " navigation", kind
    field = kind + "_id"
    members = [i for i in np.flatnonzero(eligible.active)
        if c.hierarchy.get(c.node_ids[i], {}).get(field) == group["group_id"]]
    best = heapq.nsmallest(2, members, key=lambda i: (-final[i], int(i)))
    labels = [state_label(eligible, bundle, i, final)[0] for i in best]
    return _short(kind.capitalize() + ": " + " / ".join(labels)), kind


def endpoint_sets(result, retrieval):
    """Only system-proposed endpoints; no key or grading input is accepted."""
    c = retrieval["eligible"].corpus
    endpoints = {}
    by_page = {}
    for ui, node in c.membership:
        if retrieval["eligible"].unit_mask[ui]:
            by_page.setdefault(c.units[ui]["pi"], []).append((ui, node))
    def source_indices(sources):
        indices = []
        bundle = retrieval["hierarchy_bundle"]
        page_states = bundle.metadata.get("page_indices", {})
        for source in sources:
            pid = source.get("canonical_page_id")
            if pid not in c.page_index:
                continue
            pi = c.page_index[pid]
            if pi in page_states:
                indices.append(page_states[pi])
                continue
            for ui, node in by_page.get(pi, []):
                unit = c.units[ui]
                if "start" not in source or "start" not in unit or (unit["start"] < source["end"] and source["start"] < unit["end"]):
                    indices.append(node)
        return indices
    for reading in result.get("readings", []):
        for candidate in reading.get("candidates", []):
            indices = []
            ni = c.node_index.get(candidate.get("node_id"))
            if ni is not None and retrieval["eligible"].active[ni]:
                indices.append(ni)
            source_pages = {s["canonical_page_id"] for s in candidate.get("sources", [])}
            if ni is None:
                indices.extend(source_indices(candidate.get("sources", [])))
            endpoints[candidate["id"]] = dict(indices=list(dict.fromkeys(indices)), label=candidate["fill"],
                binding="semantic_identity" if ni is not None else "source_page_readout",
                source_pages=sorted(source_pages))
    for atom in result.get("atoms", []):
        indices = []
        citations = []
        for evidence in atom.get("evidence", []):
            ni = c.node_index.get(evidence.get("node_id"))
            if ni is not None and retrieval["eligible"].active[ni]:
                indices.append(ni)
            citations.append(evidence.get("citation", evidence))
        bound = bool(indices)
        if not bound:
            indices.extend(source_indices(citations))
        if indices:
            endpoints[atom["id"]] = dict(indices=list(dict.fromkeys(indices)), label=atom["text"],
                binding="source_evidence" if bound else "source_page_readout",
                source_pages=sorted({s["canonical_page_id"] for s in citations if "canonical_page_id" in s}))
    return endpoints


def _view(bundle, indices, vectors, alpha, edge_budget):
    indices = list(indices)
    sub = bundle.kernel[indices][:, indices].tocoo()
    # Edge selection is a display-only, final-state projection, fixed over time.
    candidates = [(int(a), int(b), float(p)) for a, b, p in zip(sub.row, sub.col, sub.data)]
    final = vectors[-1][1]
    displayed = heapq.nsmallest(edge_budget, candidates,
        key=lambda x: (-alpha * final[indices[x[0]]] * x[2], x[0], x[1]))
    edges = [dict(source=bundle.state_ids[indices[a]], target=bundle.state_ids[indices[b]],
        kind=bundle.structural_edges[indices[a], indices[b]]["kind"], transition=p) for a, b, p in displayed]
    rowsums = np.asarray(sub.tocsr().sum(axis=1)).ravel()
    frames = []
    for k, (iteration, values) in enumerate(vectors):
        previous = vectors[k - 1][1] if k else None
        weights = values[indices]
        other = max(0., float(values.sum() - weights.sum()))
        flows = []
        conservation = dict(internal=0., visible_to_other=0., other_to_visible=0., other_to_other=0.)
        if previous is not None:
            local = previous[indices]
            internal = alpha * float(local @ rowsums)
            outgoing = alpha * float(local.sum()) - internal
            incoming = float(weights.sum() - (1 - alpha) * bundle.prior[indices].sum()) - internal
            remainder = alpha * float(previous.sum()) - internal - outgoing - incoming
            conservation = dict(internal=max(0., internal), visible_to_other=max(0., outgoing),
                other_to_visible=max(0., incoming), other_to_other=max(0., remainder))
            flows = [dict(source=bundle.state_ids[indices[a]], target=bundle.state_ids[indices[b]],
                mass=alpha * float(previous[indices[a]]) * p) for a, b, p in displayed]
        frames.append(dict(iteration=iteration, weights=weights.tolist(), flows=flows,
            other_mass=other, total_mass=float(values.sum()),
            restart_mass=float((1 - alpha) * bundle.prior.sum()) if k else 0.,
            transport=conservation, omitted_internal_edge_flow=max(0., conservation["internal"] - sum(e["mass"] for e in flows))))
    return dict(node_indices=indices, edges=edges, frames=frames)


def replay(retrieval, result, *, compact_budget=28, expanded_budget=1024, alpha=.85):
    """Every iteration, constant node set, conserved outside mass, real witnesses."""
    bundle = retrieval.get("hierarchy_bundle")
    if bundle is None:
        return dict(version=VERSION, status="LEXICAL_ONLY", nodes=[], edges=[], frames=[], starters=[])
    trace = retrieval["receipt"]["diffusion"]
    count = trace["iterations"]
    values = bundle.prior.copy()
    vectors = [(0, values)]
    transpose = bundle.kernel.T.tocsr()
    for iteration in range(1, count + 1):
        values = (1 - alpha) * bundle.prior + alpha * (transpose @ values)
        vectors.append((iteration, values))
    final = values
    expected = retrieval.get("_full_mass")
    if expected is not None and not np.allclose(final, expected, rtol=1e-12, atol=1e-14):
        raise ValueError("Flow replay does not reproduce native diffusion")
    endpoints = endpoint_sets(result, retrieval)
    mandatory = []
    for endpoint in endpoints.values():
        # A phrase without a bound entity maps to a truthful source readout.
        best = heapq.nsmallest(1, endpoint["indices"], key=lambda i: (-final[i], i))
        mandatory.extend(best)
        endpoint["display_indices"] = best
    positive = np.flatnonzero(final > 0)
    top = heapq.nsmallest(max(compact_budget, expanded_budget), positive, key=lambda i: (-final[i], int(i)))
    compact = list(dict.fromkeys(mandatory + top))[:max(compact_budget, len(set(mandatory)))]
    expanded = list(dict.fromkeys(compact + top))[:expanded_budget]
    metadata = {}
    labels = {}
    group_lookup = {g["index"]: g for g in bundle.metadata.get("groups", [])}
    group_members = {}
    corpus = retrieval["eligible"].corpus
    for i in np.flatnonzero(retrieval["eligible"].active):
        row = corpus.hierarchy.get(corpus.node_ids[i], {})
        for kind in ("community", "theme", "domain"):
            identity = row.get(kind + "_id")
            if identity:
                group_members.setdefault((kind, identity), []).append(int(i))
    def label_for(i):
        if i not in labels:
            group = group_lookup.get(i)
            if group:
                kind = group["state_type"]
                members = group_members.get((kind, group["group_id"]), [])
                best = heapq.nsmallest(2, members, key=lambda j: (-final[j], j))
                labels[i] = (_short(kind.capitalize() + ": " + " / ".join(label_for(j)[0] for j in best)), kind)
            else:
                labels[i] = state_label(retrieval["eligible"], bundle, i, final)
        return labels[i]
    for i in expanded:
        label, kind = label_for(i)
        metadata[i] = dict(id=bundle.state_ids[i], label=label, type=kind, final_mass=float(final[i]))
    small = _view(bundle, compact, vectors, alpha, 96)
    large = _view(bundle, expanded, vectors, alpha, 2048)
    for view in (small, large):
        view["nodes"] = [metadata[i] for i in view.pop("node_indices")]
    starters = []
    for source in retrieval.get("_starter_priors", []):
        prior = source["values"]
        starters.append(dict(id=source["id"], label=source["label"], kind=source["kind"],
            total_mass=float(prior.sum()), targets=[dict(id=bundle.state_ids[i], mass=float(prior[i]))
                for i in expanded if i < len(prior) and prior[i] > 0],
            meaning="Query injection/restart, not a historical graph node"))
    candidate_flows = {}
    transported = Counter()
    for frame in large["frames"]:
        for edge in frame["flows"]:
            transported[edge["source"], edge["target"]] += edge["mass"]
    sub = bundle.kernel[expanded][:, expanded].tocsr()
    local_index = {i: j for j, i in enumerate(expanded)}
    # Finite-horizon reverse influence on the displayed projection. Escapes
    # through omitted nodes are not silently counted as explained paths.
    downstream = np.zeros((len(expanded), len(endpoints)))
    for column, endpoint in enumerate(endpoints.values()):
        for target in endpoint["display_indices"]:
            downstream[local_index[target], column] = 1.
    attribution = [Counter() for _ in endpoints]
    explained = np.zeros(len(endpoints))
    contained = [bundle.prior[expanded].copy()]
    for _ in range(count):
        contained.append((1 - alpha) * bundle.prior[expanded] + alpha * (sub.T @ contained[-1]))
    projected = np.vstack(contained)
    coo = sub.tocoo()
    for step in range(count, 0, -1):
        explained += ((1 - alpha) * bundle.prior[expanded]) @ downstream
        flow = alpha * projected[step - 1][coo.row] * coo.data
        for column in range(len(endpoints)):
            contribution = flow * downstream[coo.col, column]
            top_edges = np.flatnonzero(contribution > 0)
            for position in top_edges:
                attribution[column][(int(coo.row[position]), int(coo.col[position]))] += float(contribution[position])
        downstream = alpha * (sub @ downstream)
    explained += bundle.prior[expanded] @ downstream
    for column, endpoint in enumerate(endpoints.values()):
        targets = [local_index[i] for i in endpoint["display_indices"]]
        if not np.isclose(explained[column], projected[-1][targets].sum(), rtol=1e-10, atol=1e-13):
            raise ValueError("Forward/reverse contained-influence replay disagrees")
    for column, (cid, endpoint) in enumerate(endpoints.items()):
        targets = endpoint["display_indices"]
        witnesses = []
        for target in targets[:3]:
            witness = maximum_product_witness(bundle.kernel, bundle.prior, [target])
            witnesses.append(dict(nodes=[dict(id=bundle.state_ids[i], label=label_for(i)[0],
                type=bundle.state_types[i]) for i in witness["nodes"]],
                hops=[dict(source=bundle.state_ids[h["source"]], target=bundle.state_ids[h["target"]],
                    kind=bundle.structural_edges[h["source"], h["target"]]["kind"], transition=h["transition"])
                    for h in witness["hops"]], meaning="Maximum-product navigation witness, not factual entailment"))
        ids = {bundle.state_ids[i] for i in targets}
        incoming = [dict(e, transported_mass=transported[e["source"], e["target"]])
            for e in large["edges"] if e["target"] in ids]
        contributions = [dict(source=bundle.state_ids[expanded[a]], target=bundle.state_ids[expanded[b]],
            kind=bundle.structural_edges[expanded[a], expanded[b]]["kind"], transported_influence=value)
            for (a, b), value in attribution[column].most_common(64)]
        readout = endpoint["binding"] == "source_page_readout" and not any(bundle.state_types[i] == "page" for i in targets)
        candidate_flows[cid] = dict(label=endpoint["label"], binding=endpoint["binding"],
            source_pages=endpoint["source_pages"], endpoint_ids=[] if readout else sorted(ids),
            source_contributor_ids=sorted(ids) if readout else [],
            readout_explanation="These nodes contribute relevance to the source page. The proposed phrase has no bound graph identity; it is not a graph destination."
                if readout else "A bound graph state or actual source-page state is the destination.",
            incoming=incoming, witnesses=witnesses,
            contribution_edges=contributions,
            endpoint_mass=float(final[targets].sum()), explained_projection_mass=float(explained[column]),
            omitted_projection_mass=max(0., float(final[targets].sum() - explained[column])),
            interpretation="Finite-iteration adjoint contributions inside the displayed induced graph only; paths leaving it are omitted. Edge totals can count multiple transitions of one walk, not a correctness probability.")
    return dict(version=VERSION, status="RECORDED", **small, expanded=large, starters=starters,
        candidate_flows=candidate_flows, iterations=count, alpha=alpha,
        visualization="Retrospective fixed-node projection; all iterations replayed; display budgets do not prune retrieval",
        other="Sum of omitted real states; no synthetic solver hub", source_pages_are_states="page" in bundle.state_types,
        correctness_probability=False)
