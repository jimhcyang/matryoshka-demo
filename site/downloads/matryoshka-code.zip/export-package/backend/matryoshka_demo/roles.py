"""Optional common-word role matching, never a named-entity alias dictionary."""
from functools import lru_cache
from pathlib import Path

from .io import sha


@lru_cache(maxsize=1)
def lexicon():
    import nltk
    directory = Path(__file__).resolve().parents[1] / "data/models/nltk"
    nltk.data.path.insert(0, str(directory))
    from nltk.corpus import wordnet
    wordnet.ensure_loaded()
    return wordnet


@lru_cache(maxsize=10000)
def concepts(word):
    wn = lexicon()
    # Reject named WordNet entries. The caller also excludes proper-name and
    # NER tokens; this resource is used for common role nouns only.
    return tuple(s for s in wn.synsets(word, pos=wn.NOUN)
                 if any(l.name().islower() and l.name().replace("_", " ") == word for l in s.lemmas()))


def common_words(doc):
    return {t.lemma_.casefold() for t in doc if t.pos_ in {"NOUN", "ADJ"} and not t.ent_type_}


def compare(query_words, source_words):
    wanted = {s.name(): w for w in sorted(query_words) for s in concepts(w)}
    for word in sorted(source_words):
        for synset in concepts(word):
            for node, distance in [(synset, 0)] + [(h, 1) for h in sorted(synset.hypernyms(), key=lambda s:s.name())]:
                compound_words = {part for l in node.lemmas() if l.name().islower() for part in l.name().split("_")}
                overlap = compound_words & query_words
                if node.name() in wanted or overlap:
                    return dict(matched=True, source_word=word, query_word=wanted.get(node.name()) or sorted(overlap)[0],
                        source_concept=synset.name(), query_concept=node.name(), hypernym_edges=distance,
                        match_kind="SAME_CONCEPT" if node.name() in wanted else "COMMON_COMPOUND_COMPONENT",
                        historical_relation_inferred=False, meaning="Common-word lexical relation only, not proof of the missing action")
    return dict(matched=False, historical_relation_inferred=False)


def binding():
    import nltk
    resource = Path(__file__).resolve().parents[1] / "data/models/nltk/corpora/wordnet.zip"
    lexicon()
    return dict(resource="WordNet", version=lexicon().get_version(), nltk_version=nltk.__version__,
        sha256=sha(resource), max_hypernym_edges=1, proper_name_lookups_permitted=False)
