"""Loopback-only inspection; allowlisted artifacts and the existing graph UI."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import gzip
import json
from pathlib import Path
import re
from urllib.parse import parse_qs, unquote, urlsplit

from .io import load, load_gzip, rows, sha,digest


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, root, workspace, **kwargs):
        self.root = root; self.workspace = workspace
        super().__init__(*args, directory=str(root / "web"), **kwargs)

    def published_report(self, version=2):
        report=load(self.root/("web/data/report-v"+str(version)+".json"))
        if report.get('sha256')!=digest({k:v for k,v in report.items() if k!='sha256'}):
            raise ValueError('Published report index changed')
        return report

    def do_GET(self):
        parsed = urlsplit(self.path); path = unquote(parsed.path)
        if path.startswith("/graph-assets-v4/"):
            try:
                from .graph_assets_v4 import asset
                match = re.fullmatch(r"/graph-assets-v4/(cib|iran|vietnam)/([^/]+)", path)
                if not match:
                    raise ValueError("Unbound full graph asset")
                target, directory = asset(self.root, match[1], match[2])
                self.file(target, directory)
            except (ValueError, OSError, KeyError):
                self.send_error(409, "No unchanged full graph asset for this request")
            return
        if path == "/api/graph-v4-viewer":
            try:
                from .graph_assets_v4 import catalog
                corpus = parse_qs(parsed.query).get("corpus", ["cib"])[0]
                item = catalog(self.root)["corpora"][corpus]
                self.json_response(dict(asset_base="/graph-assets-v4/" + corpus + "/",
                    comparison_asset=item["comparison"], search_asset=item["search"],
                    graph_run_id=item["graph_id"], hierarchy_run_id=item["hierarchy_id"],
                    study_graph_id=item["study_graph_id"], study_hierarchy_id=item["study_hierarchy_id"],
                    comparison_sha256=item["source_export_sha256"],
                    scope_note=item["scope"] + " " + item["layout_note"], pdf_available=corpus == "cib"), compress=True)
            except (ValueError, OSError, KeyError):
                self.send_error(409, "No unchanged full corpus binding for this request")
            return
        if path in {"/api/condition-v4", "/api/flow-v4", "/api/graph-v4"}:
            self.presentation_v4(path, parse_qs(parsed.query)); return
        if path in {"/api/case-v3", "/api/native-v3", "/api/source-v3", "/api/node-v3", "/api/flow-v3", "/api/corpus-v3", "/api/corpus-node-v3", "/api/corpus-source-v3"}:
            self.v3_api(path, parse_qs(parsed.query)); return
        if path.startswith("/sources-v3/"):
            try: report=self.published_report(3)
            except (ValueError,OSError):self.send_error(409,"Published v3 report changed");return
            directory=(self.root/report["source_directory_v3"]).resolve()
            if not directory.is_relative_to((self.root/"data/runs_v3").resolve()):
                self.send_error(409,"Unbound source directory");return
            self.file(directory/path.removeprefix("/sources-v3/"),directory);return
        if path=="/api/case-v2":
            params=parse_qs(parsed.query)
            try:report=self.published_report()
            except (ValueError,OSError):self.send_error(409,'Published report index changed');return
            cid=params.get("case_id",[""])[0]
            row=next((r for r in report["cases"] if r["case"]["case_id"]==cid),None)
            ref=(row or {}).get("case_detail_ref")
            if not ref:self.send_error(404,"No published case detail");return
            target=(self.root/ref["path"]).resolve();directory=self.root/"web/data/report-v2-cases"
            if not target.is_relative_to(directory) or not target.is_file() or sha(target)!=ref["sha256"]:
                self.send_error(409,"Published case detail changed");return
            self.file(target,directory);return
        if path=="/api/native-v2":
            params=parse_qs(parsed.query)
            try:report=self.published_report()
            except (ValueError,OSError):self.send_error(409,'Published report index changed');return
            cid=params.get("case_id",[""])[0];arm=params.get("config",[""])[0]
            row=next((r for r in report["cases"] if r["case"]["case_id"]==cid),None)
            ref=(row or {}).get("configurations",{}).get(arm,{}).get("native_checkpoint")
            if not ref:self.send_error(404,"No saved native condition");return
            target=(self.root/ref["path"]).resolve()
            if not target.is_relative_to(self.root/"data/runs_v2") or sha(target)!=ref["sha256"]:
                self.send_error(409,"Native checkpoint changed");return
            self.file(target,self.root/"data/runs_v2");return
        if path in {"/api/graph-neighborhood","/api/source-v2"}:
            from .exploration_v2 import neighborhood,source_page
            params=parse_qs(parsed.query)
            try:report=self.published_report()
            except (ValueError,OSError):self.send_error(409,'Published report index changed');return
            cid=params.get("case_id",[""])[0];row=next((r for r in report["cases"] if r["case"]["case_id"]==cid),None)
            if not row:self.send_error(404,"No saved case eligibility scope");return
            reference=report.get("graph_indexes",{}).get(row["case"]["corpus"])
            if not reference:self.send_error(404,"No pinned graph index");return
            try:
                value=(neighborhood(self.root,reference,row["case"],params.get("node_id",[""])[0],int(params.get("limit",["20"])[0]))
                    if path=="/api/graph-neighborhood" else source_page(self.root,reference,row["case"],params.get("source_id",[""])[0]))
            except (ValueError,OSError):self.send_error(409,"No eligible unchanged source binding for this request");return
            self.json_response(value);return
        if path.startswith("/sources-v2/"):
            try:report=self.published_report()
            except (ValueError,OSError):self.send_error(409,'Published report index changed');return
            directory=(self.root/report["source_directory_v2"]).resolve()
            if not directory.is_relative_to((self.root/'data/runs_v2').resolve()):
                self.send_error(409,'Unbound source directory');return
            self.file(directory/path.removeprefix("/sources-v2/"),directory);return
        if path == "/api/candidate-pool":
            params = parse_qs(parsed.query); cid=params.get("case_id",[""])[0]; cfg=params.get("config",[""])[0]
            report=load(self.root/"web/data/report.json")
            case=next((r for r in report["cases"] if r["case"]["case_id"]==cid),None)
            record=case.get("configurations",{}).get(cfg) if case else None
            reference=record.get("result",{}).get("candidate_audit_ref") if record else None
            if not reference: self.send_error(404,"No saved proposal pool for this checkpoint"); return
            run=self.root/Path(report["source_base"]).parent
            audit=(run/reference["path"]).resolve()
            if not audit.is_relative_to(run.resolve()) or sha(audit)!=reference["sha256"]:
                self.send_error(409,"Proposal audit changed"); return
            packet=load_gzip(audit); data=json.dumps(packet).encode()
            self.send_response(200); self.send_header("Content-Type","application/json")
            self.send_header("Content-Length",str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path == "/api/health":
            data = json.dumps(dict(status="ok", service="src-demo-day", api_calls=0,
                capabilities=["cib_paired_source_pdf"])).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        if path == "/api/cib-pdf":
            params = parse_qs(parsed.query); doc = (params.get("doc_id") or params.get("document_id") or [""])[0]
            release = params.get("release", ["earlier"])[0]
            if release not in {"earlier", "later"}: self.send_error(400); return
            binding = load(self.root / "data/bindings.json")["corpora"]["cib"]
            found = next((r for r in rows(self.workspace / binding["files"]["documents"]["path"]) if r["document_id"] == doc), None)
            if not found: self.send_error(404); return
            pdf = self.workspace / "src-redaction" / found[release + "_pdf"]
            self.file(pdf, self.workspace / "src-redaction/data/source/pdfs"); return
        if path.startswith("/sources/"):
            report = load(self.root / "web/data/report.json")
            directory = self.root / report["source_base"]
            self.file(directory / path.removeprefix("/sources/"), directory); return
        if path.startswith("/legacy/"):
            directory = self.workspace / "src/demo/iran_site_visit/web"
            target = directory / path.removeprefix("/legacy/")
            if target.name == "cib_refresh_binding.json":
                expected = load(self.root / "data/bindings.json")["corpora"]["cib"]["graph_id"]
                if load(target)["graph_run_id"] != expected:
                    self.send_error(409, "Published graph changed since this prototype was bound"); return
            self.file(target, directory, embedded_html=True); return
        if path in {"/","/index.html"} and (self.root/"web/data/ui-release-v4.json").exists():
            try:
                from .ui_release_v4 import validate
                validate(self.root)
            except (ValueError, OSError, KeyError):
                self.send_error(409, "The published interface assets changed; republish the presentation only")
                return
            self.path="/workbench-v4.html";super().do_GET();return
        if path in {"/","/index.html"} and (self.root/"web/data/report-v3.json").exists():
            self.path="/workbench-v3.html";super().do_GET();return
        if path in {"/","/index.html"} and (self.root/"web/data/report-v2.json").exists():
            self.path="/workbench-v2.html";super().do_GET();return
        if path=="/v1.html":
            self.path="/index.html";super().do_GET();return
        if path not in {"/", "/index.html", "/app.js", "/styles.css", "/data/report.json",
                "/workbench-v2.html","/workbench-v2.js","/workbench-v2.css","/data/report-v2.json",
                "/workbench-v3.html","/workbench-v3.js","/workbench-v3.css","/data/report-v3.json",
                "/workbench-v4.html","/workbench-v4.js","/workbench-v4.css",
                "/flow-view-v4.js","/flow-view-v4.css","/flow-layout-v4.js",
                "/graph-v4.html","/graph-v4.js","/graph-v4.css","/data/ui-release-v4.json"}:
            if path in {"/graph-full-v4.html", "/graph-full-v4.js", "/graph-full-v4.css",
                    "/case-study-v4.html", "/case-study-v4.css"}:
                super().do_GET();return
            self.send_error(404); return
        super().do_GET()

    def presentation_v4(self, path, params):
        try:
            from .flow_projection_v4 import condition, presentation
            report = self.published_report(3)
            if path == "/api/graph-v4":
                from .corpus_explorer_v4 import request
                corpus = params.get("corpus", ["cib"])[0]
                reference = report.get("graph_indexes", {}).get(corpus)
                if reference is None:
                    raise ValueError("Unknown graph corpus")
                self.json_response(request(self.root, reference, params), compress=True)
                return
            case_id = params.get("case_id", [""])[0]
            arm = params.get("config", ["llm_readings"])[0]
            value = (condition(self.root, report, case_id, arm) if path == "/api/condition-v4" else
                presentation(self.root, report, case_id, arm, reading=params.get("reading", [None])[0],
                    limit=int(params.get("limit", ["1024"])[0])))
            self.json_response(value, compress=True)
        except (ValueError, OSError, KeyError, TypeError):
            self.send_error(409, "No unchanged saved presentation for this request")

    def v3_api(self,path,params):
        try:
            report=self.published_report(3)
            if path.startswith("/api/corpus"):
                from .corpus_explorer_v3 import overview,node,page
                corpus=params.get("corpus",[""])[0]
                ref=report.get("graph_indexes",{}).get(corpus)
                if not ref: self.send_error(404,"No bound corpus graph");return
                as_of=params.get("as_of",[None])[0]
                if path=="/api/corpus-v3":
                    value=overview(self.root,ref,search=params.get("search",[""])[0],as_of=as_of,
                        limit=int(params.get("limit",["120"])[0]),group_id=params.get("group_id",[None])[0])
                elif path=="/api/corpus-node-v3":
                    value=node(self.root,ref,params.get("node_id",[""])[0],as_of=as_of)
                else:value=page(self.root,ref,params.get("source_id",[""])[0],as_of=as_of)
                self.json_response(value);return
            cid=params.get("case_id",[""])[0]
            row=next((r for r in report["cases"] if r["case"]["case_id"]==cid),None)
            if not row:self.send_error(404,"Unknown published case");return
            if path=="/api/node-v3":
                from .exploration_v2 import neighborhood
                ref=report["graph_indexes"][row["case"]["corpus"]]
                self.json_response(neighborhood(self.root,ref,row["case"],params.get("node_id",[""])[0],30));return
            if path=="/api/source-v3":
                from .exploration_v2 import source_page
                ref=report["graph_indexes"][row["case"]["corpus"]]
                self.json_response(source_page(self.root,ref,row["case"],params.get("source_id",[""])[0]));return
            if path=="/api/flow-v3":
                ref=row["case_detail_ref"];target=(self.root/ref["path"]).resolve()
                if not target.is_relative_to(self.root/"web/data/report-v3-cases") or sha(target)!=ref["sha256"]:
                    raise ValueError("Case detail changed")
                value=load(target);arm=params.get("config",[""])[0]
                ref=value["configurations"][arm]["result"]["flow"]["expanded_ref"]
                target=(self.root/ref["path"]).resolve()
                if not target.is_relative_to(self.root/"web/data/flows-v3") or sha(target)!=ref["sha256"]:
                    raise ValueError("Expanded flow changed")
                self.json_response(load_gzip(target));return
            if path=="/api/case-v3":
                ref=row["case_detail_ref"];directory=self.root/"web/data/report-v3-cases"
            else:
                arm=params.get("config",[""])[0]
                ref=row.get("configurations",{}).get(arm,{}).get("native_checkpoint")
                directory=self.root/"data/runs_v3"
            if not ref:self.send_error(404,"No saved condition");return
            target=(self.root/ref["path"]).resolve()
            if not target.is_relative_to(directory.resolve()) or sha(target)!=ref["sha256"]:
                self.send_error(409,"Saved artifact changed");return
            self.file(target,directory)
        except (ValueError,OSError,KeyError):
            self.send_error(409,"No unchanged eligible source binding for this request")

    def json_response(self,value,compress=False):
        data=json.dumps(value,ensure_ascii=True,allow_nan=False).encode()
        encoded = False
        if compress and len(data) > 4096:
            for coding in self.headers.get("Accept-Encoding", "").lower().split(","):
                name, _, parameters = coding.strip().partition(";")
                if name == "gzip" and not re.search(r"\bq\s*=\s*0(?:\.0*)?(?:\s|;|$)", parameters):
                    data = gzip.compress(data, compresslevel=5, mtime=0)
                    encoded = True
                    break
        self.send_response(200);self.send_header("Content-Type","application/json");self.send_header("Content-Length",str(len(data)))
        if compress:
            self.send_header("Vary", "Accept-Encoding")
        if encoded:
            self.send_header("Content-Encoding", "gzip")
        self.end_headers();self.wfile.write(data)

    def file(self, target, directory, embedded_html=False):
        target = target.resolve()
        if not target.is_relative_to(directory.resolve()) or not target.is_file():
            self.send_error(404); return
        if embedded_html and target.suffix == ".html":
            data = target.read_bytes().replace(b"</head>", b"<style>.topbar,.hero{display:none!important}body{background:#f5f2e9}</style></head>")
            self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
        size = target.stat().st_size; start, end = 0, size-1
        range_header = self.headers.get("Range")
        if range_header:
            match = re.fullmatch(r"bytes=(\d+)-(\d*)", range_header)
            if not match: self.send_error(416); return
            start = int(match[1]); end = min(int(match[2]), size-1) if match[2] else size-1
            if not 0 <= start <= end < size: self.send_error(416); return
        self.send_response(206 if range_header else 200)
        self.send_header("Content-Type", self.guess_type(str(target)))
        self.send_header("Content-Length", str(end-start+1)); self.send_header("Accept-Ranges", "bytes")
        if range_header: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        try:
            with target.open("rb") as source:
                source.seek(start); left = end-start+1
                while left:
                    data = source.read(min(left, 1024*1024))
                    if not data: break
                    self.wfile.write(data); left -= len(data)
        except (BrokenPipeError, ConnectionResetError): pass


def serve(root, workspace, port):
    server = ThreadingHTTPServer(("127.0.0.1", port), partial(Handler, root=Path(root), workspace=Path(workspace)))
    print(f"Matryoshka demo: http://127.0.0.1:{port}/", flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
