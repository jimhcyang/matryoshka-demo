"""Saved diffusion with explicit task/evidence targets, never answer-key targets."""
from copy import deepcopy

from . import flow_v3 as previous
from .io import digest


VERSION = "task-directed-evidence-flow/5"


def task_targets(case, result, *, per_atom=5):
    if case["task"] == "redaction":
        return []
    targets = []
    for atom in result.get("atoms", []):
        seen, rows = set(), []
        for evidence in atom.get("evidence", []):
            direction = evidence.get("direction")
            if direction not in {"SUPPORT", "COUNTER", "PARTIAL"}:
                continue
            proof = evidence.get("citation", evidence)
            if not all(k in proof for k in ("canonical_page_id", "document_id", "date", "start", "end", "text")):
                raise ValueError("Task flow target lacks original quotation provenance")
            key = (direction, proof["canonical_page_id"], proof["start"], proof["end"])
            if key in seen:
                continue
            seen.add(key)
            label = {"SUPPORT": "FOR", "COUNTER": "AGAINST", "PARTIAL": "PARTIAL / direction unestablished"}[direction]
            rows.append(dict(id="flow_" + digest([atom["id"], key])[:24], atom_id=atom["id"],
                direction=label, native_direction=direction, status=atom["status"],
                fill=label + " / " + atom["text"], label=label + " / " + atom["text"],
                sources=[deepcopy(proof)], node_id=evidence.get("node_id"),
                establishes_atom=direction == "SUPPORT", is_counterevidence=direction == "COUNTER",
                meaning="Highlight source evidence by its saved local task decision, not graph relevance or hidden-answer agreement"))
        # Keep each observed direction represented; do not let many FOR excerpts
        # suppress a separately observed AGAINST source.
        directions = [d for d in ("SUPPORT", "COUNTER", "PARTIAL") if any(r["native_direction"] == d for r in rows)]
        admitted = []
        for d in directions:
            admitted.append(next(r for r in rows if r["native_direction"] == d))
        admitted.extend(r for r in rows if r not in admitted)
        if not admitted:
            admitted = [dict(id="flow_" + digest([atom["id"], "missing"])[:24], atom_id=atom["id"],
                direction="UNRESOLVED", native_direction="INSUFFICIENT", status=atom["status"],
                fill="UNRESOLVED / " + atom["text"], label="UNRESOLVED / " + atom["text"],
                sources=[], establishes_atom=False, is_counterevidence=False,
                meaning="No supporting or opposing source endpoint exists; no destination is invented")]
        targets.extend(admitted[:per_atom])
    return targets


def replay(retrieval, result, *, case, compact_budget=48, expanded_budget=1024, alpha=.85):
    proxy = deepcopy(result)
    targets = task_targets(case, result)
    if case["task"] != "redaction":
        proxy["atoms"] = [dict(id=r["id"], text=r["label"], evidence=[dict(citation=p,
            node_id=r.get("node_id")) for p in r["sources"]]) for r in targets]
    value = previous.replay(retrieval, proxy, compact_budget=compact_budget,
        expanded_budget=expanded_budget, alpha=alpha)
    value.update(version=VERSION, task=case["task"], targets=targets,
        starter_policy="Only actual atom/direct-question restart inputs; no whole-query starter")
    if any(s["kind"] == "context" for s in value.get("starters", [])):
        raise ValueError("Whole-query starter leaked into task-directed flow")
    return value
