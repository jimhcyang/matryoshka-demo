"""Current source-owned construction with isolated v3 plan compatibility.

Planner arms never acquire synthetic readings in their saved plan. The atoms-only
control enumerates mechanical source-phrase operations into one untyped pool;
those operations are not represented as LLM or local grammatical interpretations.
"""
from copy import deepcopy

from . import candidates_v24 as previous
from . import roles
from .contracts import MASK
from .io import digest
from .vendor.matching import clone


OPERATIONS = ("nominal", "modifier", "quantity", "possessive", "member_example")
VERSION = "source-owned-candidates/3.2"
RANK_TIERS = ("visible_actor_reuse", "local_property_match", "positive_slot_kind",
    "focal_anchor_idf", "full_query_anchor_idf", "source_owned_role_context",
    "named_person_head_in_matched_context", "fused_rrf", "source_fullness", "stable_occurrence")


class Context(previous.Context):
    def reused_actor(self, node_id):
        if not node_id:
            return False
        if node_id not in self.reuse:
            self.labels[node_id] = {self.c.occurrences[j]["label"]
                for j in self.c.occurrences_by_node.get(node_id, [])
                if self.e.page_mask[self.c.occurrences[j]["page_index"]]}
            self.reuse[node_id] = any(label and self.pattern(label).search(self.case["query"])
                for label in self.labels[node_id])
            self.counts["eligible_node_label_sets"] += 1
        return self.reuse[node_id]


def owned_role_context(proposal, query, parse):
    """An attested own-role lexical clue, not a missing-action assertion."""
    normalize = lambda s: " ".join(s.split()).casefold()
    sources = proposal.get("sources", [])
    query_words = roles.common_words(parse(MASK.sub(" ", query)))
    for phrase in (proposal.get("owner") or {}).get("roles", []):
        if not isinstance(phrase, str) or not phrase.strip():
            continue
        citation = next((s for s in sources if normalize(phrase) in normalize(s["text"])), None)
        if citation is None:
            continue
        match = roles.compare(query_words, roles.common_words(parse(phrase)))
        if match["matched"]:
            return dict(match, source_role_quote=phrase, citation=deepcopy(citation),
                query_basis="Common nouns/adjectives in the visible masked question",
                executed_search_expansion=False, supports_missing_action=False)
    return dict(matched=False, absence_is_counterevidence=False, supports_missing_action=False)


def features(proposal, context, *, reading=None, source_fit=None):
    value = previous.features(proposal, context, reading=reading, source_fit=source_fit)
    span = context.phrase(proposal)
    value["positive_slot_kind"] = positive_slot_kind(span, reading or {}, source_fit or {})
    value["named_person_head"] = positive_person_head(span, reading or {}, source_fit or {})
    value["named_person_head_in_matched_context"] = bool(value["named_person_head"]
        and (value["focal_anchor_idf"] > 0 or value["full_query_anchor_idf"] > 0))
    # Explicit roles are already source-owned. Nearby names and action snippets
    # are not used to invent an actor's role or reverse a source negation.
    value["source_owned_role_context"] = owned_role_context(proposal, context.case["query"], context.parse)
    return value


def positive_person_head(span, reading, source_fit):
    """Unknown type is admissible, but is not positive person-name evidence."""
    if source_fit.get("source_kind_conflict"):
        return False
    head = span.root
    return (reading.get("target_kind") == "person" and head.pos_ == "PROPN"
        and (source_fit.get("known_kind") == "person" or head.ent_type_ == "PERSON"))


def positive_slot_kind(span, reading, source_fit):
    target = reading.get("target_kind")
    if target not in {"person", "organization", "place"} or source_fit.get("source_kind_conflict"):
        return False
    if source_fit.get("known_kind") == target:
        return True
    ordinary = set(source_fit.get("ordinary_head_kinds", []))
    if ordinary == {target}:
        return True
    return span.root.ent_type_ in {"person": {"PERSON"}, "organization": {"ORG"},
        "place": {"GPE", "LOC", "FAC"}}[target]


def rank_key(proposal, f, index):
    return (f["visible_actor_reuse"], not f["local_property_match"],
        not f.get("positive_slot_kind", False), -f["focal_anchor_idf"], -f["full_query_anchor_idf"],
        not f.get("source_owned_role_context", {}).get("matched", False),
        not (f.get("named_person_head", False) and (f["focal_anchor_idf"] > 0 or f["full_query_anchor_idf"] > 0)),
        -f["fused_rrf"], -f["source_fullness"], proposal["id"], tuple(proposal["source_span"]), index)


def _execution_plan(plan, case):
    value = deepcopy(plan)
    value["leads"] = []
    for reading in value.get("slot_readings", []):
        reading.pop("explanation", None)
        reading.pop("origin", None)
    if not value.get("slot_readings"):
        position = case["query"].index(case["focal_marker"])
        value["slot_readings"] = [dict(id="operation_" + form, form=form, role="unknown", target_kind="any",
            left_quote=case["query"][:position][-60:], right_quote=case["query"][position + len(case["focal_marker"]):][:60],
            attachment_quote="", notes="Mechanical source-phrase operation, not a predicted slot reading", finite=None)
            for form in OPERATIONS]
    return value


def construct(case, plan, retrieval, *, passage_budget=100, top_k=5):
    from .planning_v3 import validate_plan
    validate_plan(plan, case)
    execution = _execution_plan(plan, case)
    # Only already-validated, source-bound fields enter the old constructor.
    # No upstream module globals or completed results are mutated.
    _, functions = clone(previous, dict(validate_plan=lambda value, public: value,
        Context=Context, features=features, rank_key=rank_key, RANK_TIERS=RANK_TIERS, VERSION=VERSION))
    result = functions["construct"](case, execution, retrieval, passage_budget=passage_budget, top_k=top_k)
    result["constructor_version"] = VERSION
    result["planning_arm"] = plan["arm"]
    result["keyword_role_matching_used"] = False
    result["generated_keyword_role_matching_used"] = False
    result["source_owned_role_context_used"] = True
    result["proper_name_length_rank_bonus"] = False
    result["visible_actor_reuse_scope"] = "WHOLE_VISIBLE_QUERY_WITH_ELIGIBLE_SOURCE_LABELS"
    if not plan.get("slot_readings"):
        result["untyped_pool"] = True
    for row in result["readings"]:
        for candidate in row["candidates"]:
            witness = candidate.get("v21_features", {}).get("source_owned_role_context", {})
            candidate["ranking_explanation"] = (
                "An explicit source-owned role shares a common-word lexical concept with the visible question. "
                "This boosts contextual relevance, not support for the missing action."
                if witness.get("matched") else
                "Ordered source-context and retrieval criteria determine this rank. Name length supplies no bonus.")
            clue = candidate.get("support") == "LOCAL_PROPERTY_ATTESTED"
            candidate["support_assessment"] = dict(label="Inferred", level="partial_clue" if clue else "context",
                explanation="The source attests this property, but the complete missing assertion is not certified."
                    if clue else "The wording or identity is source-attested; the missing action or relationship remains unproved.",
                needed="An eligible passage establishing the inserted assertion with the same participants and event scope.",
                local=True, relevance_is_support=False)
    result["execution_plan_sha256"] = digest(execution)
    return result


def finalize_untyped(result, *, top_k=5):
    """Collapse source operations only after complete-pool grammar filtering."""
    if result.get("untyped_pool"):
        all_candidates = []
        seen = set()
        for row in result["readings"]:
            for candidate in row["candidates"]:
                candidate["source_operation"] = row["reading"]["form"]
                all_candidates.append(candidate)
        all_candidates.sort(key=lambda p: rank_key(p, p["v21_features"], 0))
        kept = []
        for candidate in all_candidates:
            identity = candidate.get("node_id"), candidate["fill"].casefold()
            if identity in seen:
                continue
            seen.add(identity); kept.append(candidate)
        result["readings"] = [dict(reading=dict(id="untyped_pool", form="unknown", role="unknown", target_kind="any",
            notes="One candidate pool; this arm did not predict slot readings", explanation="Candidates without a proposed slot reading"),
            candidates=kept[:top_k])]
        for i, candidate in enumerate(result["readings"][0]["candidates"], 1):
            candidate["rank"] = i
    for row in result["readings"]:
        for candidate in row["candidates"]:
            assessment = candidate.get("support_assessment", {})
            witness = candidate.get("v21_features", {}).get("source_owned_role_context", {})
            candidate.setdefault("ranking_explanation",
                "An explicit source-owned role shares a common-word concept with the visible question; this is contextual relevance, not missing-action support."
                if witness.get("matched") else
                "Ordered source-context and retrieval criteria determine this rank; name length supplies no bonus.")
            assessment["label"] = assessment.get("status", assessment.get("label", "Inferred"))
            if assessment["label"] == "Supported":
                explanation = "The quoted source establishes the focal inserted contribution under the local participant, predicate and scope checks."
            elif assessment.get("partial_clue"):
                explanation = "A relevant property or phrase is attested, but some requirements of the inserted assertion remain unresolved."
            else:
                explanation = "The wording or identity is source-attested; these passages do not establish the missing action or relationship."
            assessment.setdefault("explanation", explanation)
            assessment.setdefault("needed", "" if assessment["label"] == "Supported" else
                "An eligible source connecting this proposed fill to the same participants, action and event scope.")
            assessment["absence_is_counterevidence"] = False
            candidate["support_assessment"] = assessment
    return result
