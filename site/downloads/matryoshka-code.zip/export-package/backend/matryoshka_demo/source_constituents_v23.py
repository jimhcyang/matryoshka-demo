"""Literal nested source NPs, insertion edits, and source-format exclusions.

No identity joins or event-support transfer. All edits and exclusions retain
source offsets, original quotations, and the actual enumerated page identity.
"""
from copy import deepcopy
import re

from matryoshka_demo.fill_wording_v23 import adapt, boundary_wording, modifier_wording
from matryoshka_demo import candidates as legacy
from matryoshka_demo.io import digest
from matryoshka_demo.vendor.matching import clone


VERSION = "source-owned-constituents/2.3"
LEFT_MODIFIERS = {"compound", "amod", "det", "nummod", "poss", "nmod", "quantmod"}
NESTED_ROLES = {"pobj", "obj", "dobj", "attr", "conj", "appos", "nmod"}
ROUTING = re.compile(r"^\s*(?:(?:FM|TO|INFO)\s+)?(?:AM(?:EMBASSY|CONSUL(?:ATE)?|MISSION)|SECSTATE)\b", re.I)
SECTION = re.compile(r"(?m)^[ \t]*(\d+\.)[ \t]+")


def format_regions(text, analysis):
    """Recognized routing lines only; uppercase itself is never an exclusion."""
    routing = []
    offset = 0
    for line in text.splitlines(keepends=True):
        end = offset + len(line)
        if ROUTING.match(line):
            tokens = [t for t in analysis if offset <= t.idx < end]
            finite = any(t.pos_ in {"VERB", "AUX"} and (
                t.tag_ in {"VBD", "VBP", "VBZ", "MD"} or "Fin" in t.morph.get("VerbForm")) for t in tokens)
            if not finite:
                routing.append((offset, end))
        offset = end
    sections = [(m.start(1), m.end()) for m in SECTION.finditer(text)]
    return routing, sections


def _unsafe_boundary(edits):
    return any(e.get("kind") == "VISIBLE_ADJACENT_PREFIX_SHARED"
        and re.search(r"[.!?;]", e.get("visible_query_suffix", "")) for e in edits)


def safe_boundary(case, fill):
    changed, edits = boundary_wording(case, fill)
    if _unsafe_boundary(edits):
        return " ".join(fill.split()), [dict(kind="BOUNDARY_EDIT_WITHHELD",
            reason="SENTENCE_BOUNDARY_IN_SHARED_CONTEXT", requested_edits=edits)]
    return changed, edits


def insertion_wording(case, reading, proposal, span):
    changed, edits = adapt(case, reading, proposal, span)
    if _unsafe_boundary(edits):
        changed, modifier_edits = (modifier_wording(proposal["fill"], span)
            if reading["form"] == "modifier" else (proposal["fill"], []))
        changed, boundary_edits = safe_boundary(case, changed)
        return changed, modifier_edits + boundary_edits
    return changed, edits


def proposal_spans(text, parse):
    """Keep base spans and add ordinary nested nominal cores, never aliases."""
    doc, originals = legacy.proposal_spans(text, parse)
    spans = {(p["start"], p["end"]):p for p in originals}
    views = [(doc, "ORIGINAL_PAGE_ANALYSIS")]
    lowered = text.lower()
    if lowered != text and len(lowered) == len(text):
        views.append((parse(lowered), "LOWERCASE_PAGE_SAME_OFFSETS"))
    routing, sections = format_regions(text, views[-1][0])

    def add(a, b, route, normalization):
        if (a, b) in spans:
            return
        part = doc.char_span(a, b, alignment_mode="strict")
        if part is None or not part or part[0].sent.start_char != part[-1].sent.start_char:
            return
        spans[a, b] = dict(kind="nominal", head=part.root, owner=None,
            text=part.text, edited=part.text, start=a, end=b,
            source_constituent=dict(route=route, normalization=normalization,
                source_span=[a, b], semantic_support_transferred=False))

    for view, normalization in views:
        for chunk in view.noun_chunks:
            if chunk.root.pos_ in {"NOUN", "PROPN"}:
                add(chunk.start_char, chunk.end_char, "UNEXTENDED_SOURCE_NP", normalization)
        for head in view:
            if head.pos_ not in {"NOUN", "PROPN"} or head.dep_ not in NESTED_ROLES:
                continue
            selected = {head.i}
            for child in head.children:
                if child.i < head.i and child.dep_ in LEFT_MODIFIERS:
                    subtree = list(child.subtree)
                    if not any(t.pos_ in {"ADP", "SCONJ", "CCONJ", "AUX"}
                            or t.pos_ == "VERB" and t.tag_ not in {"VBN", "VBG"} for t in subtree):
                        selected.update(t.i for t in subtree)
            part = view[min(selected):max(selected)+1]
            if any(t.pos_ in {"ADP", "SCONJ", "CCONJ", "AUX"}
                    or t.pos_ == "VERB" and t.tag_ not in {"VBN", "VBG"} for t in part):
                continue
            add(part.start_char, part.end_char, "NESTED_NOMINAL_HEAD", normalization)
    for original in list(spans.values()):
        for a, b in sections:
            if original["kind"] == "nominal" and original["start"] <= a < b < original["end"]:
                add(b, original["end"], "SECTION_BODY_SOURCE_NP", "SOURCE_SECTION_PREFIX_BOUNDARY")
    for value in spans.values():
        a, b = value["start"], value["end"]
        if any(a < stop and b > start for start, stop in routing):
            value["source_format_rejection"] = "ADMINISTRATIVE_ROUTING_MATERIAL"
        elif any(a < stop and b > start for start, stop in sections):
            value["source_format_rejection"] = "SECTION_NUMBER_PREFIX_IN_PROPOSAL"
    return doc, list(spans.values())


def construct_source_pool(case, plan, reading, *, parse, focal_requirements, validate_page, passage_budget=100):
    """Build and adapt a source pool using isolated legacy function globals."""
    registry = {}
    excluded = []
    corpus = reading["eligible"].corpus
    inspected = sorted(reading["pages"], key=lambda index:reading["page_ranks"].get(index, 10**9))[:passage_budget]
    source_pages = iter(corpus.pages[index] for index in inspected)

    def source_clone(module, overrides):
        if module is not legacy:
            return clone(module, overrides)
        def spans(text, parser):
            page = next(source_pages)
            validate_page(page["id"])
            if page["text"] != text:
                raise ValueError("Source-page enumeration changed")
            doc, values = proposal_spans(text, parser)
            kept = []
            for value in values:
                if "source_format_rejection" in value:
                    sentence = value["head"].sent
                    a, b = min(value["start"], sentence.start_char), max(value["end"], sentence.end_char)
                    excluded.append(dict(page_sha256=digest(text), source_span=[value["start"], value["end"]],
                        source_wording=value["text"], kind=value["kind"], reason=value["source_format_rejection"],
                        start=a, end=b, text=text[a:b], canonical_page_id=page["id"],
                        document_id=page["document_id"], date=page["date"]))
                    continue
                kept.append(value)
                if "source_constituent" in value:
                    registry[digest(text), value["start"], value["end"]] = value["source_constituent"]
            return doc, kept
        def boundary_fit(public, fill, form, parser, *, source_kind=None):
            changed, _ = safe_boundary(public, fill)
            return legacy.fit(public, changed, form, parser, source_kind=source_kind)
        scope, functions = clone(module, dict(overrides, proposal_spans=spans, fit=boundary_fit))
        original = functions["construct"]
        def adapted(*args, **kwargs):
            result = original(*args, **kwargs)
            parser = overrides["parser"]()
            for row in result["_candidate_audit"]["readings"]:
                for item in row["proposals"]:
                    source = item["sources"][0]
                    page = reading["eligible"].corpus.pages[
                        reading["eligible"].corpus.page_index[source["canonical_page_id"]]]
                    span = parser(page["text"]).char_span(*item["source_span"], alignment_mode="strict")
                    if span is None:
                        raise ValueError("Constituent cuts a source token")
                    changed, edits = insertion_wording(case, row["reading"], item, span)
                    if edits:
                        item["unadapted_fill"] = item["fill"]
                        item["unadapted_proposal_id"] = item["id"]
                        item["fill"] = changed
                        item["insertion_edits"] = edits
                        item["id"] = "fill_v23_" + digest([item["id"], changed, item["source_span"]])[:20]
                    key = source["page_sha256"], *item["source_span"]
                    if key in registry:
                        item["source_constituent"] = deepcopy(registry[key])
            return result
        functions["construct"] = adapted
        return scope, functions

    _, functions = source_clone(legacy, dict(parser=lambda:parse, candidate_route=lambda *a, **k:None,
        focal_requirements=focal_requirements))
    output = functions["construct"](case, plan, dict(reading, kernel=None), passage_budget=passage_budget)
    return output, excluded
