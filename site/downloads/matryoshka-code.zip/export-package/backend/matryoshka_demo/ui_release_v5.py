"""Independent v5 presentation seal, never an inference reseal."""
from pathlib import Path

from .graph_assets_v4 import bound
from .io import digest, load, save, sha


FILES = (
    "web/workbench-v5.html", "web/workbench-v5.js", "web/workbench-v5.css", "web/app-theme-v5.css",
    "web/flow-view-v5.js", "web/flow-view-v5.css", "web/flow-layout-v4.js",
    "web/graph-full-v5.html", "web/graph-full-v5.js", "web/graph-full-v5.css",
    "matryoshka_demo/server_v5.py", "matryoshka_demo/flow_projection_v5.py",
)
POINTER = "web/data/ui-release-v5.json"


def proposal(root):
    root = Path(root).resolve()
    graph = bound(root)
    path = root / "web/data/report-v5.json"
    report = load(path)
    if report.get("sha256") != digest({k: v for k, v in report.items() if k != "sha256"}):
        raise ValueError("Published v5 report changed")
    value = dict(version="task-directed-workbench-presentation/5", run_id=report["run_id"],
        source_report=dict(path="web/data/report-v5.json", sha256=sha(path)),
        full_graph_binding_sha256=graph["sha256"],
        assets=[dict(path=p, sha256=sha(root / p)) for p in FILES],
        native_outputs_modified=False, inference_api_calls_from_viewer=0,
        population_status=report.get("status", "UNSPECIFIED"))
    value["sha256"] = digest(value)
    return value


def publish(root, execute=False, *, allow_partial=False):
    root = Path(root).resolve()
    value = proposal(root)
    if value["population_status"] != "COMPLETE" and not allow_partial:
        raise ValueError("Native run is incomplete; an explicit partial preview must retain pending labels")
    if execute:
        path = root / "web/data/ui-releases" / ("ui_v5_" + value["sha256"][:20] + ".json")
        if path.exists() and load(path) != value:
            raise ValueError("Immutable UI release changed")
        if not path.exists():
            save(path, value)
        save(root / POINTER, value)
    return value


def validate(root):
    root = Path(root).resolve()
    value = load(root / POINTER)
    if value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"}):
        raise ValueError("Presentation pointer changed")
    if value != proposal(root):
        raise ValueError("Presentation files changed since publication")
    return value
