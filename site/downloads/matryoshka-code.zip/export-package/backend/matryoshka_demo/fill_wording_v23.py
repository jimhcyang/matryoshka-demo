"""Source-preserving insertion edits; no retrieval, identity or answer rules."""
import re

from matryoshka_demo.contracts import WORD


VERSION='source-preserving-insertion-wording/2.3'


def boundary_wording(case,fill):
    """Share an exactly duplicated adjacent prefix, never a sentence boundary."""
    left=case['query'].split(case['focal_marker'])[0].rstrip()
    value=fill;edits=[]
    if left and (left[-1].isalnum() or left[-1] in "'\u2019"):
        before=list(WORD.finditer(left));after=list(WORD.finditer(value));maximum=min(len(before),len(after)-1)
        for size in range(maximum,0,-1):
            if [m.group().casefold() for m in before[-size:]]==[m.group().casefold() for m in after[:size]]:
                removed=value[:after[size-1].end()]
                suffix=left[before[-size].start():]
                if re.search(r'[.!?;,]',suffix) or ' '.join(removed.split()).casefold()!=' '.join(suffix.split()).casefold():continue
                value=value[after[size-1].end():].lstrip()
                edits.append(dict(kind='VISIBLE_ADJACENT_PREFIX_SHARED',removed=removed,
                    visible_query_suffix=left[before[-size].start():],meaning='The visible context supplies these same tokens; source quotation stays unchanged'))
                break
    compact=' '.join(value.split())
    if compact!=value:edits.append(dict(kind='WHITESPACE_COLLAPSED',meaning='No source word removed or added'))
    return compact,edits


def modifier_wording(fill,span):
    """Move post-head adverbial modifiers into a prenominal modifier position.

    Only complete, otherwise unchanged source spans are eligible. Every token
    including negation survives; this is not an adjective-only truncation.
    """
    tokens=[t for t in span if not t.is_space];head=span.root
    if ' '.join(fill.split())!=' '.join(t.text for t in tokens):
        without_aux=[t for t in tokens if not(t.pos_=='AUX' and t.lemma_=='be' and t.dep_ in {'aux','auxpass'} and t.head.i==head.i)]
        if ' '.join(fill.split())!=' '.join(t.text for t in without_aux):return fill,[]
        tokens=without_aux
    if head.pos_ not in {'ADJ','VERB'}:return fill,[]
    post=[t for t in tokens if t.idx>head.idx and t.dep_=='advmod' and t.head.i==head.i]
    if not post:return fill,[]
    if any(t is not head and t.i!=head.i and (t.dep_ not in {'advmod','neg'} or t.head.i!=head.i) for t in tokens):return fill,[]
    before=[t for t in tokens if t.idx<head.idx];after=[t for t in tokens if t.idx>head.idx and t not in post]
    edited=' '.join(t.text for t in before+post+[head]+after)
    return edited,[dict(kind='POST_HEAD_ADVERBS_PREPOSED',original=fill,edited=edited,
        preserved_token_multiset=True,meaning='All source modifiers and negation retained; source word order remains available separately')]


def adapt(case,reading,proposal,span):
    fill=proposal['fill'];edits=[]
    if reading['form']=='modifier':fill,edits=modifier_wording(fill,span)
    fill,boundary=boundary_wording(case,fill)
    return fill,edits+boundary
