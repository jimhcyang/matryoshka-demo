"""Read-only hierarchical presentation of saved diffusion, never new inference."""
from collections import OrderedDict, defaultdict
from copy import deepcopy
from functools import lru_cache
import heapq
import json
import math
from pathlib import Path
import re
from threading import RLock

from .corpus_explorer_v3 import _connection
from .exploration_v2 import verified_hash
from .io import digest, load, load_gzip


VERSION = "nested-saved-diffusion/4"
ARMS = {"A": "llm_readings", "B": "llm_atoms", "C": "llm_local", "D": "legacy_reference"}
LEVELS = ("community", "theme", "domain")
_CACHE_LOCK = RLock()
_PRESENTATIONS = OrderedDict()
_PARENTS = OrderedDict()


def _bound_path(root, ref, directory):
    target = (root / ref["path"]).resolve()
    if not target.is_relative_to((root / directory).resolve()):
        raise ValueError("Unbound presentation artifact")
    stat = target.stat()
    if verified_hash(str(target), stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino) != ref["sha256"]:
        raise ValueError("Saved presentation artifact changed")
    return target, (stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino)


@lru_cache(maxsize=2)
def _case_file(path, stamp, expected):
    return load(Path(path))


@lru_cache(maxsize=2)
def _expanded_file(path, stamp, expected):
    return load_gzip(Path(path))


def condition(root, report, case_id, arm):
    """One selected arm; the old native run and published report remain intact."""
    root = Path(root).resolve()
    arm = ARMS.get(arm, arm)
    if arm not in ARMS.values():
        raise ValueError("Unknown comparison arm")
    row = next((r for r in report["cases"] if r["case"]["case_id"] == case_id), None)
    if row is None:
        raise ValueError("Unknown saved question")
    target, stamp = _bound_path(root, row["case_detail_ref"], "web/data/report-v3-cases")
    value = _case_file(str(target), stamp, row["case_detail_ref"]["sha256"])
    if value["case"] != row["case"] or arm not in value["configurations"]:
        raise ValueError("Question/condition binding changed")
    return dict({k: v for k, v in value.items() if k != "configurations"},
                configurations={arm: value["configurations"][arm]}, selected_arm=arm)


def hierarchy_catalog(db):
    """Only assignment IDs, never global labels that might expose later names."""
    rows = db.execute("SELECT DISTINCT json_extract(hierarchy,'$.community_id') c, "
        "json_extract(hierarchy,'$.theme_id') t,json_extract(hierarchy,'$.domain_id') d FROM node").fetchall()
    parents = {}
    for row in rows:
        for key, parent in ((("community", row[0]), ("theme", row[1])),
                            (("theme", row[1]), ("domain", row[2]))):
            if not key[1] or not parent[1]:
                continue
            if key in parents and parents[key] != parent:
                raise ValueError("Hierarchy has conflicting parents")
            parents[key] = parent
    return parents


def _group_key(node):
    kind = str(node.get("type", "")).lower()
    if kind not in LEVELS:
        return None
    match = re.fullmatch(r"hierarchy:+" + kind + r":(.+)", node["id"])
    if not match:
        raise ValueError("Unknown saved hierarchy state identity")
    return kind, match.group(1)


def _finite_nonnegative(value):
    return isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0


def _candidate_rows(result, reading):
    rows = result.get("readings", [])
    def identity(row):
        return row.get("reading_id") or row.get("reading", {}).get("id") or row.get("id")
    if rows:
        if reading:
            rows = [r for r in rows if identity(r) == reading]
            if not rows:
                raise ValueError("Unknown saved slot reading")
        elif rows:
            rows = rows[:1]
        return [dict(id=c["id"], fill=c["fill"], rank=c.get("rank", i),
            reading_id=identity(r), sources=c.get("sources", []),
            support=c.get("support_assessment", {}).get("label", c.get("support_label", "Inferred")))
            for r in rows for i, c in enumerate(r.get("candidates", [])[:5], 1)]
    return [dict(id=a["id"], fill=a["text"], rank=i, reading_id=None,
        sources=[e.get("citation", e) for e in a.get("evidence", [])], support=a.get("status", "Unresolved"))
        for i, a in enumerate(result.get("atoms", [])[:5], 1)]


def _widest_routes(starters, candidate, node_map, edge_map):
    """Representative simple corridors, not an enumeration or joint path mass."""
    targets = set(candidate.get("endpoint_ids") or candidate.get("source_contributor_ids") or [])
    graph = defaultdict(list)
    for edge in candidate.get("contribution_edges", []):
        u, v = edge["source"], edge["target"]
        if u != v and (u, v) in edge_map and _finite_nonnegative(edge.get("transported_influence")) and edge["transported_influence"] > 0:
            graph[u].append((v, edge["transported_influence"]))
    routes, used = [], set()
    for starter in starters:
        origins = {t["id"] for t in starter.get("targets", []) if t["mass"] > 0 and t["id"] in node_map}
        heap = [(-math.inf, (u,), u) for u in sorted(origins - targets)]
        heapq.heapify(heap)
        best = {}
        while heap:
            negative, path, u = heapq.heappop(heap)
            score = -negative
            if score <= best.get(u, -1):
                continue
            best[u] = score
            if u in targets:
                if path not in used:
                    used.add(path)
                    routes.append(dict(nodes=[deepcopy(node_map[n]) for n in path],
                        hops=[dict(edge_map[a, b]) for a, b in zip(path, path[1:])], starter_id=starter["id"],
                        route_kind="DISPLAYED_INFLUENCE_CORRIDOR", bottleneck_edge_influence=score,
                        meaning="A simple corridor chosen by its weakest accumulated contribution edge inside the saved projection. Not a measured joint path probability or a factual inference."))
                break
            for v, weight in sorted(graph[u]):
                if v not in path:
                    heapq.heappush(heap, (-min(score, weight), path + (v,), v))
    return sorted(routes, key=lambda r: (-r["bottleneck_edge_influence"], r["starter_id"]))[:3]


def project(flow, expanded, assignments, parents, candidates, *, limit=1024):
    """Bound the drawing, retain true parents, and preserve saved numeric values."""
    if type(limit) is not int or not 32 <= limit <= 1024:
        raise ValueError("Drawing limit must be between 32 and 1024")
    if flow.get("status") != "RECORDED":
        return dict(version=VERSION, status="LEXICAL_ONLY", nodes=[], edges=[], frames=[], starters=[],
            candidates=[], documents=[], scope="No diffusion was recorded for this method.")
    candidates = deepcopy(candidates)
    raw = expanded["nodes"]
    if len({n["id"] for n in raw}) != len(raw) or not expanded.get("frames"):
        raise ValueError("Malformed saved flow node universe")
    raw_map = {n["id"]: n for n in raw}
    previous_iteration = -1
    raw_edges = {(e["source"], e["target"]) for e in expanded.get("edges", [])}
    for edge in expanded.get("edges", []):
        if edge["source"] not in raw_map or edge["target"] not in raw_map or not (
                _finite_nonnegative(edge.get("transition")) and 0 < edge["transition"] <= 1):
            raise ValueError("Invalid saved transport edge")
    for frame in expanded["frames"]:
        if type(frame["iteration"]) is not int or frame["iteration"] != previous_iteration + 1:
            raise ValueError("Saved iterations are not a complete ordered replay")
        previous_iteration = frame["iteration"]
        if len(frame["weights"]) != len(raw) or not all(_finite_nonnegative(x) for x in frame["weights"]):
            raise ValueError("Invalid saved diffusion weights")
        if not all(_finite_nonnegative(frame.get(k)) for k in ("other_mass", "total_mass", "restart_mass")):
            raise ValueError("Invalid saved mass accounting")
        if any((e["source"], e["target"]) not in raw_edges or not _finite_nonnegative(e.get("mass"))
                for e in frame.get("flows", [])):
            raise ValueError("Invalid saved flow values")
        if not math.isclose(sum(frame["weights"]) + frame["other_mass"], frame["total_mass"], rel_tol=1e-9, abs_tol=1e-11):
            raise ValueError("Saved visible/omitted mass does not conserve total mass")
    group_ids = {key: n["id"] for n in raw if (key := _group_key(n))}
    if len(group_ids) != sum(str(n.get("type", "")).lower() in LEVELS for n in raw):
        raise ValueError("Repeated hierarchy group identity")
    group_parents = dict(parents)
    decorated = {}

    def group(key):
        identity = group_ids.get(key, "layout:" + key[0] + ":" + key[1])
        if identity not in decorated:
            original = raw_map.get(identity)
            decorated[identity] = dict(original or {}, id=identity,
                label=(original or {}).get("label", key[0].capitalize() + " group"), type=key[0],
                group_id=key[1], layout_only=original is None, parent_id=None)
            if key in group_parents:
                decorated[identity]["parent_id"] = group(group_parents[key])
        return identity

    for n in raw:
        key = _group_key(n)
        if key:
            group(key)
            continue
        assignment = assignments.get(n["id"], {})
        parent = group(("community", assignment["community_id"])) if assignment.get("community_id") else None
        decorated[n["id"]] = dict(n, parent_id=parent, layout_only=False,
            hierarchy_status=assignment.get("hierarchy_status", "not_assigned"))
    starters = deepcopy(flow.get("starters", []))
    capacity = limit - len(starters) - 1
    if capacity <= 0:
        raise ValueError("Starters exceed the drawing budget")

    def closure(identity):
        result, seen = [], set()
        while identity:
            if identity in seen or identity not in decorated:
                raise ValueError("Invalid or cyclic hierarchy layout")
            seen.add(identity)
            result.append(identity)
            identity = decorated[identity]["parent_id"]
        return result

    selected = set()
    def admit(identity):
        if identity not in decorated:
            return False
        needed = set(closure(identity))
        if len(selected | needed) > capacity:
            return False
        selected.update(needed)
        return True

    bindings = flow.get("candidate_flows", {})
    for candidate in candidates:
        cf = bindings.get(candidate["id"], {})
        for identity in cf.get("endpoint_ids") or cf.get("source_contributor_ids") or []:
            if not admit(identity):
                raise ValueError("Candidate endpoints do not fit the declared drawing budget")
    for starter in starters:
        targets = sorted(starter.get("targets", []), key=lambda t: (-t["mass"], t["id"]))
        if targets:
            admit(targets[0]["id"])
    for candidate in candidates:
        cf = bindings.get(candidate["id"], {})
        for witness in cf.get("witnesses", [])[:3]:
            for node in witness.get("nodes", []):
                admit(node["id"])
        for edge in cf.get("contribution_edges", [])[:24]:
            admit(edge["source"])
            admit(edge["target"])
    for node in sorted(raw, key=lambda n: (-n["final_mass"], n["id"])):
        admit(node["id"])
    ordered = sorted(selected, key=lambda identity: (
        {"domain": 0, "theme": 1, "community": 2}.get(decorated[identity]["type"].lower(), 3),
        decorated[identity]["parent_id"] or "", -decorated[identity].get("final_mass", 0), identity))
    raw_positions = {n["id"]: i for i, n in enumerate(raw)}
    nodes = [dict(decorated[identity], mass_index=i, candidate_ranks=[], source_candidate_ranks=[])
        for i, identity in enumerate(ordered)]
    node_map = {n["id"]: n for n in nodes}
    for node in nodes:
        if node["layout_only"]:
            child = next((n for n in nodes if n["parent_id"] == node["id"] and not n["layout_only"]), None)
            if child:
                node["label"] += ": " + child["label"][:55]
    edges = [dict(e) for e in expanded.get("edges", []) if e["source"] in selected and e["target"] in selected]
    if len({(e["source"], e["target"]) for e in edges}) != len(edges):
        raise ValueError("Repeated saved transport edge")
    edge_map = {(e["source"], e["target"]): e for e in edges}
    frames = []
    for original in expanded["frames"]:
        weights = [original["weights"][raw_positions[n["id"]]] if not n["layout_only"] else None for n in nodes]
        flows = {(e["source"], e["target"]): e["mass"] for e in original.get("flows", [])}
        visible_edge_mass = [flows.get((e["source"], e["target"]), 0.) for e in edges]
        displayed = sum(w for w in weights if w is not None)
        total_transport = flow.get("alpha", .85) * original["total_mass"] if original["iteration"] else 0.
        frames.append(dict(iteration=original["iteration"], weights=weights, edge_mass=visible_edge_mass,
            total_mass=original["total_mass"], other_mass=max(0., original["total_mass"] - displayed),
            restart_mass=original["restart_mass"], unshown_transport=max(0., total_transport - sum(visible_edge_mass))))
    for candidate in candidates:
        cf = deepcopy(bindings.get(candidate["id"], {}))
        candidate.update({k: cf.get(k, [] if k.endswith("ids") else None) for k in
            ("binding", "endpoint_ids", "source_contributor_ids", "endpoint_mass", "explained_projection_mass", "omitted_projection_mass", "readout_explanation")})
        for key, field in (("endpoint_ids", "candidate_ranks"), ("source_contributor_ids", "source_candidate_ranks")):
            for identity in cf.get(key, []):
                if identity in node_map:
                    node_map[identity][field].append(candidate["rank"])
        candidate["routes"] = [dict(deepcopy(w), route_kind="NATIVE_MAXIMUM_PRODUCT_WITNESS")
            for w in cf.get("witnesses", [])[:3]]
        candidate["influence_corridors"] = _widest_routes(starters, cf, node_map, edge_map)
        candidate["contribution_edges"] = [e for e in cf.get("contribution_edges", [])
            if e["source"] in selected and e["target"] in selected]
    for starter in starters:
        all_targets = starter.get("targets", [])
        starter["targets"] = [t for t in all_targets if t["id"] in selected]
        starter["omitted_target_mass"] = max(0., starter["total_mass"] - sum(t["mass"] for t in starter["targets"]))
    return dict(version=VERSION, status="RECORDED", nodes=nodes, starters=starters, edges=edges,
        frames=frames, candidates=candidates, documents=[], iterations=flow["iterations"], alpha=flow["alpha"],
        drawing_limit=limit, drawing_count=len(nodes) + len(starters) + 1,
        source_pages_are_states=flow.get("source_pages_are_states", False),
        hierarchy_membership_is_evidence=False, ranking_changed=False, answer_key_used=False,
        disclosures=["Nesting is the actual fixed hierarchy, not the temporal order of the random walk.",
            "Starters inject directly into matched states. A domain-first drawing does not create domain-first transport.",
            "Layout-only parent containers have no saved solver mass; null is not zero.",
            "Other is the exact mass of omitted states. Not all transport edges are saved or drawn.",
            "Candidate outlines mark system proposals, not known correct answers. Dashed outlines mark source contributors for unbound phrases.",
            "Source-backed connections, hierarchy navigation and aggregate connections are distinct; none alone proves a missing fact."])


def _citation(db, page_id):
    found = db.execute("SELECT payload FROM page WHERE id=?", (page_id,)).fetchone()
    if found is None:
        raise ValueError("Missing document provenance")
    page = json.loads(found[0])
    return dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
        start=0, end=len(page["text"]), text=page["text"], page_sha256=page["source_sha256"],
        earlier_page=page.get("earlier_page"))


def attach_documents(db, projection, case, result):
    identities = [n["id"] for n in projection["nodes"] if n["type"].lower() not in LEVELS and not n["layout_only"]]
    if not identities:
        return
    slots = ",".join("?" for _ in identities)
    members = db.execute("SELECT p.doc,m.node,min(p.id) page,min(p.date) date FROM mention m "
        "JOIN page p ON p.id=m.page WHERE p.date<? AND p.doc!=? AND m.node IN (" + slots + ") "
        "GROUP BY p.doc,m.node", [case["date"], case["document_id"]] + identities).fetchall()
    by_doc = defaultdict(dict)
    for row in members:
        by_doc[row[0]][row[1]] = (row[2], row[3])
    seeded = result.get("retrieval", {}).get("seeded_documents", [])
    if not seeded:
        seeded = result.get("retrieval", {}).get("receipt", {}).get("seeded_documents", [])
    meta = {d["document_id"]: d for d in seeded}
    candidates = defaultdict(list)
    for c in projection["candidates"]:
        for source in c.get("sources", []):
            if source.get("document_id"):
                candidates[source["document_id"]].append(c["id"])
    final = {n["id"]: projection["frames"][-1]["weights"][i] or 0. for i, n in enumerate(projection["nodes"])}
    ranked = sorted(by_doc, key=lambda d: (-sum(final[n] for n in by_doc[d]), d))
    selected = list(dict.fromkeys(list(candidates) + list(meta)[:20] + ranked[:12]))[:64]
    counts = {}
    if selected:
        placeholders = ",".join("?" for _ in selected)
        counts = dict(db.execute("SELECT p.doc,count(DISTINCT m.node) FROM mention m JOIN page p ON p.id=m.page "
            "WHERE p.doc IN (" + placeholders + ") AND p.date<? AND p.doc!=? GROUP BY p.doc",
            selected + [case["date"], case["document_id"]]).fetchall())
    for identity in selected:
        if identity not in by_doc:
            continue
        row = by_doc[identity]
        first = next(iter(row.values()))
        projection["documents"].append(dict(id=identity, title=identity, date=first[1],
            visible_node_ids=sorted(row), eligible_node_count=counts.get(identity, 0),
            visible_final_member_mass=sum(final[n] for n in row), candidate_ids=sorted(set(candidates[identity])),
            source=_citation(db, first[0]), lexical_rank=meta.get(identity, {}).get("lexical_rank"),
            matched_searches=meta.get(identity, {}).get("matched_searches", []),
            meaning="Overlapping provenance readout: sum of displayed member-node masses, not a document visit or extra transported mass."))
    projection["disclosures"].append("Document membership readouts overlap across documents and must not be summed as conserved mass. Selecting a document highlights its displayed eligible nodes; it does not activate all nodes jointly.")


def attach_route_sources(db, projection, case):
    for candidate in projection["candidates"]:
        for route in candidate.get("routes", []) + candidate.get("influence_corridors", []):
            for hop in route.get("hops", []):
                if hop.get("kind") != "SOURCE":
                    continue
                row = db.execute("SELECT e.page,u.start,u.end,p.payload FROM edge e JOIN page p ON p.id=e.page "
                    "JOIN unit u ON u.id=e.unit WHERE ((e.a=? AND e.b=?) OR (e.a=? AND e.b=?)) "
                    "AND p.date<? AND p.doc!=? ORDER BY p.date DESC,e.unit LIMIT 1",
                    (hop["source"], hop["target"], hop["target"], hop["source"], case["date"], case["document_id"])).fetchone()
                if row:
                    page = json.loads(row[3])
                    if not 0 <= row[1] < row[2] <= len(page["text"]):
                        raise ValueError("Route quotation interval changed")
                    hop["citations"] = [dict(canonical_page_id=page["id"], document_id=page["document_id"],
                        date=page["date"], start=row[1], end=row[2], text=page["text"][row[1]:row[2]],
                        page_sha256=page["source_sha256"], earlier_page=page.get("earlier_page"))]
                hop["meaning"] = "Direction of numerical transport over a source connection, not direction of a factual predicate."


def presentation(root, report, case_id, arm, *, reading=None, limit=1024):
    root = Path(root).resolve()
    selected = condition(root, report, case_id, arm)
    record = next(iter(selected["configurations"].values()))
    result, case = record["result"], selected["case"]
    flow = result.get("flow", {})
    if flow.get("status") != "RECORDED":
        return project(flow, {}, {}, {}, [], limit=limit)
    ref = flow["expanded_ref"]
    target, stamp = _bound_path(root, ref, "web/data/flows-v3")
    expanded = _expanded_file(str(target), stamp, ref["sha256"])
    candidates = _candidate_rows(result, reading)
    reference = report["graph_indexes"][case["corpus"]]
    db = _connection(root, reference)
    case_sha = next(r["case_detail_ref"]["sha256"] for r in report["cases"] if r["case"]["case_id"] == case_id)
    key = (str(root), case_sha, record["config"], reading, limit, ref["sha256"],
        reference["sha256"], digest(reference["binding"]))
    try:
        with _CACHE_LOCK:
            if key in _PRESENTATIONS:
                _PRESENTATIONS.move_to_end(key)
                return deepcopy(_PRESENTATIONS[key])
            parent_key = str((root / reference["path"]).resolve()), reference["sha256"]
            parents = _PARENTS.get(parent_key)
        if parents is None:
            parents = hierarchy_catalog(db)
            with _CACHE_LOCK:
                _PARENTS[parent_key] = parents
                while len(_PARENTS) > 3:
                    _PARENTS.popitem(last=False)
        semantic = [n["id"] for n in expanded["nodes"] if str(n["type"]).lower() not in LEVELS]
        assignments = {}
        if semantic:
            slots = ",".join("?" for _ in semantic)
            assignments = {r[0]: json.loads(r[1]) for r in db.execute("SELECT id,hierarchy FROM node WHERE id IN (" + slots + ")", semantic)}
        value = project(flow, expanded, assignments, parents, candidates, limit=limit)
        attach_documents(db, value, case, result)
        attach_route_sources(db, value, case)
        value.update(case_id=case_id, config=record["config"], reading_id=reading,
            scope=dict(corpus=case["corpus"], strictly_before=case["date"], whole_origin_excluded=case["document_id"],
                binding=reference["binding"], retrospective_hierarchy=True),
            source_case_sha256=case_sha,
            source_expanded_sha256=ref["sha256"])
        with _CACHE_LOCK:
            _PRESENTATIONS[key] = deepcopy(value)
            while len(_PRESENTATIONS) > 4:
                _PRESENTATIONS.popitem(last=False)
        return value
    finally:
        db.close()
