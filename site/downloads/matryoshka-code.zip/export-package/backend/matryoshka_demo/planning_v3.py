"""Shared extraction/atoms, three explicit planner views, no keyword execution.

Main owns the public catalog, release, and original-src reference arm. Select a
public context before make_plans; do not silently change a catalog case. The
model reading arm has no local supplementation or local repair fallback.
Extraction alone uses the existing quoted projection/quarantine. All raw stage
outputs and exact shared hashes are available in prepare's diagnostic bundle.
No API call occurs at import; execute=False cannot reserve or spend.
"""
from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import json
import math
from pathlib import Path
import re

import jsonschema

from . import api_v2 as api
from .contracts import MASK, public_case
from .io import digest, load, save
from .local_readings_v21 import compile_readings
from .planning import sentences
from .planning_v2 import check_extraction, lexical, license_words, nlp
from .query_projection_v22 import project
from .query_projection_v22 import _spans
from .task_execution_v2 import offset_safe_parser
from .vendor import matching


VERSION = "shared-question-planning/3.1"
CONTEXT_VERSION = "public-query-context/3.1"
LOCAL_POLICY = "local-personal-possessive/1"
ARMS = ("llm_readings", "llm_atoms", "llm_local")
PRESENTATION_WORDS = 200
ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = ROOT / "contracts/planning_v3"
MODEL = "gpt-6-luna"
MODEL_PROFILES = {"luna": dict(extraction="gpt-6-luna", atoms="gpt-6-luna", readings="gpt-6-luna"),
                  "sol": dict(extraction="gpt-6-luna", atoms="gpt-6.1-sol", readings="gpt-6.1-sol")}
DEFAULT_PROFILE = "sol"
MAX_OUTPUT_TOKENS = 4096
FORMAT_RETRY_VERSION = "provider-format-retry/1"
FORMAT_RETRY_MESSAGE = ("The previous provider output was incomplete. Return compact, complete JSON for "
    "the same question and schema. Do not pad the output with whitespace.")
_CALENDAR_MONTHS = tuple("january february march april may june july august september october november december".split())
_DAYPARTS = "morning|afternoon|evening|night"
_SPECULATIVE = re.compile(r"\b(?:biograph\w*|logical authority|officeholder\w*|historical background)\b", re.I)
_GRAMMAR = frozenset("""noun phrase nominal modifier modify possessive possess possession example member enumeration
    quantity number count amount adjunct adverb adverbial adjective adjectival verb verbal clause finite nonfinite
    subject object argument complement relative preposition prepositional auxiliary copula determiner article plural
    singular coordinate coordination conjunction possessive pronoun attachment attach govern head carrier boundary
    left right visible missing opaque gap slot expression grammatical grammar syntax syntactic form insert insertion
    complete whole fit occupy introduce follow precede require permit allow alternative alternatively unknown
    unresolved interpretation reading position act role property describe refer referent qualify quotation quoted
    support source evidence passage record question context explicitly state identify report supply text indicate
    stand contain retain separate describe part sentence context present possible type what which who whom whose
    where when how whether why can could would should may might do does did is are was were be been being
    a an the that this these those of to in on at by for from with without as and or but not no only also
    one another each either both any same it its they their them here there before after between within around
    specify take supply constrain belong associated entire itself function use locally inferred identity answer
    assert certify certain certainty name fill need more than than provide describe hold position unresolved
    information connect related modify modifying absence negation attribution modality condition
    local determine replace owner denote specify s miss mean express signal link restrict combine admit incomplete
    specific unspecified restrictive nonrestrictive supplementary apposition appositive attributive predicative
    participial participle infinitive infinitival genitive possessor pronominal conjunct subordinate nonclausal
    non-clausal postnominal prenominal countable uncountable grammatical grammatically actor agent patient
    participant recipient speaker reference span material content term kind introduce complete singular plural""".split())
_ROLES = dict(nominal="unknown", modifier="nominal_property", possessive="possessor",
    member_example="member_example", quantity="quantity", adjunct="adjunct",
    verbal="verbal_bridge", clause="statement", unknown="unknown")
_LOCAL_EXPLANATIONS = dict(nominal="A noun phrase can occupy the missing argument position.",
    modifier="A modifier can qualify the visible noun without replacing its head.",
    possessive="A possessive expression can attach to the visible noun.",
    member_example="An example member can follow the visible plural expression.",
    quantity="A quantity can specify the count of the visible plural noun.",
    adjunct="An adjunct can qualify the surrounding clause.", verbal="A verb phrase can occupy the missing verbal position.",
    clause="A clause can occupy the missing statement position.", unknown="The local grammar does not determine the missing form.")


class PlanFailure(ValueError):
    def __init__(self, stage, message, bundle=None):
        super().__init__(stage + ": " + message)
        self.stage, self.bundle = stage, bundle


def select_context(case, policy="paragraph", word_budget=PRESENTATION_WORDS):
    """Return a literal public case and reversible source-query offset mapping."""
    case = public_case(case)
    if policy not in {"paragraph", "focal_window"} or type(word_budget) is not int or word_budget < 1:
        raise ValueError("Unknown context policy or invalid presentation budget")
    q = case["query"]
    a, b, reason = 0, len(q), "COMPLETE_CLAIM_QUERY"
    focal_exceeds = False
    if case["task"] == "redaction":
        at = q.index(case["focal_marker"])
        breaks = list(re.finditer(r"\r?\n[ \t\r]*\n", q))
        a = max([m.end() for m in breaks if m.end() <= at] or [0])
        b = min([m.start() for m in breaks if m.start() > at] or [len(q)])
        while a < b and q[a].isspace(): a += 1
        while b > a and q[b - 1].isspace(): b -= 1
        reason = "FOCAL_SOURCE_PARAGRAPH"
        if policy == "focal_window" or len(q[a:b].split()) > word_budget:
            units = list(sentences(q[a:b]))
            index = next(i for i, s in enumerate(units) if s["start"] <= at - a < s["end"])
            lo, hi = units[index]["start"], units[index]["end"]
            focal_exceeds = len(q[a + lo:a + hi].split()) > word_budget
            # Presentation-only rule: prefer preceding attribution context,
            # then the following sentence, never split or clip a sentence.
            if index and len(q[a + units[index - 1]["start"]:a + hi].split()) <= word_budget:
                lo = units[index - 1]["start"]
            if index + 1 < len(units) and len(q[a + lo:a + units[index + 1]["end"]].split()) <= word_budget:
                hi = units[index + 1]["end"]
            a, b = a + lo, a + hi
            reason = "FOCAL_SENTENCE_PRESENTATION_WINDOW"
    selected = q[a:b]
    output = dict(case, query=selected)
    return dict(case=output, mapping=dict(version=CONTEXT_VERSION, policy=policy, reason=reason,
        presentation_word_budget=word_budget, focal_sentence_exceeds_budget=focal_exceeds,
        selected_words=len(selected.split()), source_query_sha256=digest(q), query_sha256=digest(selected),
        source_start=a, source_end=b, selected_start=0, selected_end=len(selected),
        pieces=[dict(kind="COPY", source_start=a, source_end=b, selected_start=0, selected_end=len(selected))],
        support_or_retrieval_tuned=False, sentence_splitter="planning.sentences physical-boundary/1"))


@lru_cache(maxsize=3)
def _contract(stage):
    if stage not in {"extraction", "atoms", "readings"}: raise ValueError("Unknown planner stage")
    prompt = (CONTRACTS / (stage + ".prompt.txt")).read_text().strip()
    if "\n" in prompt: raise ValueError("Planner instruction must be one paragraph")
    schema = (load(ROOT / "contracts/kg_extraction_2_32.json")["schema"] if stage == "extraction"
              else load(CONTRACTS / (stage + ".schema.json")))
    return prompt, schema


def _calendar_quote(value, query):
    """Match a month spelling/daypart-order variant, never infer a date value."""
    parsed = re.fullmatch(r"(?:(?P<before>" + _DAYPARTS + r")\s+)?(?P<month>[a-z]+)\.?\s+"
        r"(?P<day>\d{1,2})(?:(?:,\s*|\s+)(?P<year>\d{4}))?"
        r"(?:\s+(?P<after>" + _DAYPARTS + r"))?", value.strip(), re.I)
    if not parsed or parsed["before"] and parsed["after"]: return None
    spelling = parsed["month"].casefold()
    month = next((m for m in _CALENDAR_MONTHS if spelling in {m, m[:3]}
                  or m == "september" and spelling == "sept"), None)
    day = int(parsed["day"])
    if month is None or not 1 <= day <= 31: return None
    aliases = sorted({month, month[:3]} | ({"sept"} if month == "september" else set()))
    core = r"(?:" + "|".join(aliases) + r")\.?\s+" + ("0?" if day < 10 else "") + str(day)
    if parsed["year"]: core += r"(?:,\s*|\s+)" + parsed["year"]
    part = parsed["before"] or parsed["after"]
    # The entire date/daypart expression must occur together, not as a bag of
    # independently visible month, day, year and time-of-day tokens.
    if part: core = "(?:" + re.escape(part) + r"\s+" + core + "|" + core + r"\s+" + re.escape(part) + ")"
    return re.search(r"(?<!\w)" + core + r"(?!\w)", query, re.I)


def _validate_prose(text, query):
    if not isinstance(text, str) or not text.strip(): raise ValueError("Empty explanatory text")
    novelty = sorted(lexical(text) - lexical(query) - _GRAMMAR)
    if _SPECULATIVE.search(text) and not _SPECULATIVE.search(query):
        raise ValueError("Question/explanation introduces an unsupported speculative direction")
    doc = nlp()(MASK.sub(lambda m: " " * len(m.group()), text))
    # Name spans, not bags of name tokens: never recombine a visible title and
    # somebody else's surname into a new apparently source-attested identity.
    def visible(value):
        return re.search(r"(?<!\w)" + r"\s+".join(re.escape(p) for p in value.split()) + r"(?!\w)", query, re.I)
    chunks = list(doc.ents)
    calendar_alignments = []
    name_spans = []
    for match in re.finditer(r"[A-Z][\w'-]*(?:\s+[A-Z][\w'-]*)+", text):
        start = match.start()
        for token in doc:
            if (start < token.idx and token.idx + len(token) < match.end()
                    and token.pos_ == "PART" and token.dep_ == "case"
                    and token.text in {"'s", "'", "\u2019s", "\u2019"}
                    and visible(text[start:token.idx + len(token)])):
                # A source-attested genitive separates names; an apostrophe
                # inside a surname is not a grammatical boundary.
                name_spans.append((start, token.idx))
                start = token.idx + len(token)
        name_spans.append((start, match.end()))
    for start, end in name_spans:
        words = text[start:end].split()
        prefix_tokens = [t for t in doc if start <= t.idx < end]
        while words and prefix_tokens and prefix_tokens[0].i == prefix_tokens[0].sent.start:
            if prefix_tokens[0].pos_ not in {"AUX", "DET", "ADP", "SCONJ", "CCONJ", "PART", "PRON"}: break
            words.pop(0)
            prefix_tokens.pop(0)
        while words and lexical(words[0]) <= _GRAMMAR: words.pop(0)
        if words and lexical(" ".join(words)) - _GRAMMAR and not visible(" ".join(words)):
            raise ValueError("Unlicensed or recombined name in prose")
    for entity in chunks:
        if entity.label_ in {"DATE", "TIME", "PERCENT", "MONEY", "QUANTITY", "ORDINAL", "CARDINAL"}:
            if lexical(entity.text) - _GRAMMAR and not visible(entity.text):
                calendar = _calendar_quote(entity.text, query) if entity.label_ == "DATE" else None
                if calendar is not None:
                    calendar_alignments.append(dict(policy="CALENDAR_SPELLING_DAYPART_ALIGNMENT/1",
                        model_text=entity.text, source_quote=calendar.group(),
                        start=calendar.start(), end=calendar.end()))
                    continue
                # Deictic grammar ("this month" / "that month") can change
                # without inventing a calendar value. Absolute values cannot
                # be recombined from unrelated dates elsewhere in the query.
                absolute = re.search(r"\d|\b(?:january|february|march|april|may|june|july|august|september|october|november|december|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", entity.text, re.I)
                relative = entity.label_ in {"DATE", "TIME"} and not absolute and not (
                    lexical(entity.text) - lexical(query) - _GRAMMAR)
                if not relative: raise ValueError("Unlicensed date/quantity in prose")
            continue
        if entity.label_ not in {"PERSON", "ORG", "GPE", "LOC", "FAC", "NORP", "EVENT", "WORK_OF_ART", "LAW", "LANGUAGE"}:
            continue
        if lexical(entity.text) - _GRAMMAR and not visible(entity.text):
            raise ValueError("Unlicensed named span in prose")
    result = dict(novel_lemmas=novelty, novelty_is_rejection=False, semantic_faithfulness_certified=False)
    if calendar_alignments: result["calendar_quote_alignments"] = calendar_alignments
    return result


@lru_cache(maxsize=512)
def _frames(text):
    shadow = MASK.sub(lambda m: " " * len(m.group()), text)
    parse = offset_safe_parser(nlp())
    frames = matching.frames(shadow, parse)
    tokens = list(parse(shadow))
    epistemic = matching.parent._REPORTING | {"doubt", "expect", "appear", "seem"}
    for frame in frames:
        # Do not let a later independent non-reporting clause become a
        # backward governor through a parser's semicolon attachment error.
        end = frame["predicate_proof"]["end"]
        frame["qualifiers"]["scope"] = [g for g in frame["qualifiers"]["scope"] if not (
            g["predicate"] not in epistemic and any(matching.lemma(t) == g["predicate"]
            and t.idx > end and ";" in shadow[end:t.idx] for t in tokens))]
    return frames


def _compatible_arguments(target, source):
    for role in ("agent", "patient", "recipient", "owner"):
        wanted, available = target["roles"].get(role, []), source["roles"].get(role, [])
        for p in wanted:
            resolved = [q for q in available if not q["unresolved"]]
            if p["unresolved"] or not resolved: continue
            if not any(p["head"] == q["head"] and set(p["names"]) <= set(q["terms"])
                       and p["quantifiers"] == q["quantifiers"]
                       and sorted(v["lemma"] for v in p["proofs"] if v["pos"] == "NUM")
                       == sorted(v["lemma"] for v in q["proofs"] if v["pos"] == "NUM") for q in resolved):
                return False
    return True


def _scope_matches(target, source):
    t, s = target["qualifiers"], source["qualifiers"]
    for key in ("negated", "modality", "epistemic_absence", "conditional", "question"):
        if t[key] != s[key]: return False
    if [d["value"] for d in target["event_dates"]] != [d["value"] for d in source["event_dates"]]: return False
    def governors(frame):
        return [(g["predicate"], g["negated"], tuple(g["modality"]),
                 tuple((p["head"], tuple(p["names"])) for p in g["speakers"] if not p["unresolved"]))
                for g in frame["qualifiers"]["scope"]]
    return governors(target) == governors(source)


def _scope_bound(text, quote, query, at):
    normalize = lambda s: " ".join(s.split()).casefold().rstrip(".!?")
    container = next((s for s in sentences(query) if s["start"] <= at
                      and at + len(quote) <= s["end"]), None)
    if (container and normalize(quote) == normalize(container["text"])
            and normalize(text) == normalize(quote)
            and container["text"].rstrip().endswith("?") == text.rstrip().endswith("?")):
        return True  # A model-supplied complete literal sentence needs no repair.
    targets = _frames(text)
    available = [f for f in _frames(query) if at <= f["predicate_proof"]["start"]
                 and f["predicate_proof"]["end"] <= at + len(quote)]
    if not targets: return False
    for target in targets:
        candidates = [s for s in available if s["predicate"] == target["predicate"]
                      and _compatible_arguments(target, s)]
        if not any(_scope_matches(target, s) for s in candidates): return False
    return True


def _validate_atoms(raw, case, quote_qc=None):
    jsonschema.validate(raw, _contract("atoms")[1])
    q, rows, ids = case["query"], [], set()
    for atom in raw["atoms"]:
        if atom["id"] in ids: raise ValueError("Duplicate atom identity")
        ids.add(atom["id"])
        original, text = atom["source_quote"], atom["text"]
        exact = [m.span() for m in re.finditer(re.escape(original), q)]
        intervals = exact or list(_spans(q, original))
        if not intervals and original.rstrip(".!?") != original:
            intervals = list(_spans(q, original.rstrip(".!?")))
        if len(intervals) != 1: raise ValueError("Atom " + atom["id"] + " requires one unambiguous replayable quotation")
        at, end = intervals[0]
        quote = q[at:end]
        if quote != original and quote_qc is not None:
            quote_qc.append(dict(atom_id=atom["id"], policy="REVERSIBLE_SOURCE_QUOTE_ALIGNMENT",
                original_quote=original, source_quote=quote, start=at, end=end, original_sha256=digest(atom)))
        if not license_words(text, quote) or MASK.findall(text) != MASK.findall(quote):
            raise ValueError("Atom " + atom["id"] + " introduces words or changes opaque masks")
        if not _scope_bound(text, quote, q, at):
            raise ValueError("Atom " + atom["id"] + " lacks compatible governing predicate/scope; quote its full source sentence and retain scope")
        # Proper-name recombination is prohibited even when all words occur.
        _validate_prose(text, q)
        rows.append(dict(atom, source_quote=quote, start=at, end=end))
    if case["task"] != "redaction" and not rows: raise ValueError("Complete-claim plan has no atoms")
    return rows


def _validate_interpretation(raw, case, atoms):
    schema_view = dict(raw, slot_readings=[{k: v for k, v in r.items() if k not in {"left_quote", "right_quote"}}
                                         for r in raw["slot_readings"]])
    jsonschema.validate(schema_view, _contract("readings")[1])
    q, readings = case["query"], raw["slot_readings"]
    if (case["task"] == "redaction") != bool(readings): raise ValueError("Slot readings must match task")
    ids = [r["id"] for r in readings]
    joints = {(r["form"], r["referent_kind"], r["grammatical_number"], r["finite"]) for r in readings}
    if len(ids) != len(set(ids)) or len(joints) != len(readings):
        raise ValueError("Readings must be distinct joint OR forms/kinds/numbers with unique IDs")
    at = q.index(case["focal_marker"]) if readings else 0
    qc = []
    for reading in readings:
        left, right = reading["left_quote"], reading["right_quote"]
        if not left and not right: raise ValueError("Reading has no visible boundary")
        if not q[:at].rstrip().endswith(left.rstrip()) or not q[at + len(case["focal_marker"]):].lstrip().startswith(right.lstrip()):
            raise ValueError("Reading boundary does not touch the focal mask")
        attachment = reading["attachment_quote"]
        if attachment and (attachment not in q or MASK.search(attachment)): raise ValueError("Unbound reading attachment")
        cue = reading["cue_quote"]
        if (reading["referent_kind"] != "any" or reading["grammatical_number"] != "unknown") and not cue:
            raise ValueError("Typed reading requires a literal grammatical cue")
        if cue and (cue not in q or MASK.search(cue)): raise ValueError("Unbound or opaque grammatical kind/number cue")
        qc.append(dict(kind="reading_prose", id=reading["id"], referent_kind=reading["referent_kind"],
            grammatical_number=reading["grammatical_number"], cue_quote=cue, cue_certifies_identity=False,
            **_validate_prose(reading["explanation"], q)))
    lead_ids = [lead["id"] for lead in raw["leads"]]
    if len(lead_ids) != len(set(lead_ids)): raise ValueError("Duplicate question identity")
    for lead in raw["leads"]:
        if not set(lead["reading_ids"]) <= set(ids) or not set(lead["atom_ids"]) <= {a["id"] for a in atoms}:
            raise ValueError("Unbound question links")
        if any(quote not in q for quote in lead["anchor_quotes"]): raise ValueError("Question has a fabricated anchor")
        if not lead["question"].strip().endswith("?"): raise ValueError("Executable lead must be a full question")
        qc.append(dict(kind="question_prose", id=lead["id"], **_validate_prose(lead["question"], q)))
    return qc


def _reading_view(reading):
    role = _ROLES[reading["form"]]
    return dict(id=reading["id"], form=reading["form"], role=role, target_kind=reading["referent_kind"],
        grammatical_number=reading["grammatical_number"], kind_cue_quote=reading["cue_quote"],
        left_quote=reading["left_quote"], right_quote=reading["right_quote"],
        attachment_quote=reading["attachment_quote"], finite=reading["finite"], notes=reading["explanation"])


def _local_interpretation(case, policy=LOCAL_POLICY):
    """Compile the declared local policy; None replays the legacy base view."""
    if policy is not None and policy != LOCAL_POLICY: raise ValueError("Unknown local reading policy")
    q, marker = case["query"], case["focal_marker"]
    local = compile_readings(q, marker) if case["task"] == "redaction" else []
    at, end = (q.index(marker), q.index(marker) + len(marker)) if local else (0, 0)
    clean = [dict(id=r["id"], form=r["form"], explanation=_LOCAL_EXPLANATIONS[r["form"]],
        referent_kind=r.get("target_kind", "any"), grammatical_number=r.get("grammatical_number", r.get("number", "unknown")),
        cue_quote=r.get("cue_quote", r["attachment_quote"]),
        left_quote=q[:at] if policy is not None else r["left_quote"],
        right_quote=q[end:] if policy is not None else r["right_quote"],
        attachment_quote=r["attachment_quote"], finite=r["finite"]) for r in local]
    if policy is None: return dict(slot_readings=clean, leads=[]), local

    def personal_cue():
        doc = offset_safe_parser(nlp())(MASK.sub(lambda m: " " * len(m.group()), q))
        right = [t for t in doc if t.idx >= end and not t.is_space]
        if len(right) < 3: return None
        carrier, separator, pronoun = right[:3]
        if (carrier.pos_ != "NOUN" or carrier.tag_ != "NN" or separator.text != ";"
                or pronoun.lower_ not in {"he", "she"} or pronoun.pos_ != "PRON"
                or pronoun.dep_ not in {"nsubj", "nsubjpass"} or pronoun.head.pos_ not in {"VERB", "AUX"}
                or pronoun.sent.start != carrier.sent.start
                or q[end:carrier.idx].strip()
                or re.search(r"\r?\n[ \t\r]*\n", q[end:pronoun.idx])):
            return None
        subjects = [t for t in carrier.sent if t.idx < at and t.dep_ in {"nsubj", "nsubjpass"}]
        if len(subjects) != 1 or subjects[0].pos_ != "NOUN": return None
        # An opaque argument is not a usable antecedent. A bare preceding
        # header mask is outside the visible host subject and supplies no cue.
        if any(m.span() != (at, end) and subjects[0].idx <= m.start() < pronoun.idx for m in MASK.finditer(q)):
            return None
        paragraph_start = max([m.end() for m in re.finditer(r"\r?\n[ \t\r]*\n", q[:at])] or [0])
        competing = [t for t in doc if paragraph_start <= t.idx < pronoun.idx]
        if any(t.pos_ in {"PROPN", "PRON"} or t.ent_type_ in {"PERSON", "ORG", "GPE", "LOC", "FAC", "NORP"}
               for t in competing):
            return None
        if any(t.i != pronoun.i and (t.pos_ in {"PROPN", "PRON"} or t.dep_ == "conj") for t in pronoun.subtree):
            return None
        return carrier.text, q[pronoun.idx:pronoun.idx + len(pronoun)]

    possessives = [r for r in clean if r["form"] == "possessive" and r["referent_kind"] == "any"
                   and r["grammatical_number"] in {"unknown", "singular"}]
    cue = personal_cue() if possessives else None
    if cue:
        carrier, quote = cue
        for reading in possessives:
            if reading["attachment_quote"] != carrier: continue
            if any(r["form"] == reading["form"] and r["referent_kind"] == "person"
                   and r["grammatical_number"] == "singular" and r["finite"] == reading["finite"] for r in clean):
                continue
            identity = reading["id"] + "_personal_v1"
            while any(r["id"] == identity for r in clean): identity += "_"
            clean.append(dict(reading, id=identity, referent_kind="person", grammatical_number="singular", cue_quote=quote,
                explanation="A nearby singular personal subject permits a tentative person reading of the possessor. "
                "The pronoun's referent remains unresolved; coreference is not established."))
        # Literal grammatical kind/number constraints precede unconstrained
        # fallbacks. Equal specificity retains the compiler's original order.
        clean.sort(key=lambda r: -sum((r["referent_kind"] != "any", r["grammatical_number"] != "unknown"))
                   if r["cue_quote"] else 0)
    return dict(slot_readings=clean, leads=[]), local


def _model_interpretation(raw, case):
    value = deepcopy(raw)
    if case["task"] == "redaction":
        at = case["query"].index(case["focal_marker"])
        end = at + len(case["focal_marker"])
        for row in value["slot_readings"]:
            row.update(left_quote=case["query"][:at], right_quote=case["query"][end:])
    return value


def _matching_provider_attempts(root, wire):
    """Read only local receipts for this exact wire; never infer billing."""
    found = []
    for path in sorted((root / "receipts").glob("*.json")):
        record = load(path)
        if record.get("request_sha256") == digest(wire) and record.get("model") == wire["model"]:
            found.append((path, record))
    return found


def confirmed_provider_format_failure(root, wire, key, attempts=None):
    """Return bound evidence of paid provider truncation, never parse/repair JSON.

    An incomplete response without settled recorded usage is NOT retryable.
    New per-attempt archives take precedence; legacy response/history files
    are accepted only when their response ID and usage match the receipt.
    """
    root = Path(root).resolve()
    request_path = root / "requests" / (key + ".json")
    if not request_path.is_file(): return None
    request = load(request_path)
    name = wire["text"]["format"]["name"]
    expected_key = digest(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=name, request=wire))
    if (request.get("version") != api.VERSION or request.get("request_sha256") != key
            or request.get("stage") != name or key != expected_key
            or digest(request.get("request")) != digest(wire)): return None
    rows = _matching_provider_attempts(root, wire) if attempts is None else attempts
    for path, receipt in sorted(rows, key=lambda row: (row[1].get("started_utc", ""), row[0].name)):
        if receipt.get("status") != "PAID_INVALID_OUTPUT": continue
        usage = receipt.get("usage", {})
        if any(type(usage.get(k)) is not int or usage[k] < 0 for k in ("input_tokens", "output_tokens")):
            continue
        if usage["output_tokens"] == 0: continue
        if receipt.get("attempt_ref"):
            attempt = (root / receipt["attempt_ref"]).resolve()
            if not attempt.is_relative_to(root / "attempts"): continue
            if not (attempt / "request.json").is_file() or load(attempt / "request.json") != wire: continue
            candidates = [attempt / "response.json"]
        else:
            candidates = [root / "responses" / (key + ".json")]
            candidates.extend(sorted((root / "response_history").glob(key + "__*.json")))
        for response_path in candidates:
            if not response_path.is_file(): continue
            raw = load(response_path)
            if (raw.get("id") != receipt.get("response_id") or raw.get("model") != wire["model"]
                    or raw.get("usage") != usage or raw.get("status") != "incomplete"
                    or raw.get("error") is not None
                    or (raw.get("incomplete_details") or {}).get("reason") != "max_output_tokens"):
                continue
            return dict(request_sha256=key, receipt=str(path.relative_to(root)),
                response_ref=str(response_path.relative_to(root)), raw_response=raw,
                provider_reason="max_output_tokens", raw_response_sha256=digest(raw),
                paid_receipt_sha256=digest(receipt))
    return None


class _Calls:
    def __init__(self, root, execute, cap, client, reservation_limit, model_profile):
        if type(cap) not in (int, float) or not 0 < cap <= 25: raise ValueError("Invalid API cap")
        if type(reservation_limit) not in (int, float) or not math.isfinite(reservation_limit) or reservation_limit < 0:
            raise ValueError("Invalid pilot reservation allowance")
        self.root = Path(root).resolve() if root is not None else None
        self.execute, self.cap, self.client = execute, cap, client
        self.limit, self.reserved, self.receipts, self.raw = reservation_limit, 0., [], {}
        if model_profile not in MODEL_PROFILES: raise ValueError("Unknown global model profile")
        self.profile = model_profile
        self.format_retry_stages = set()

    def _retry_format(self, stage, payload, evidence, *, record_key, reserve, cached):
        """One operational model retry per stage, including atom semantic repair."""
        name = record_key or stage
        self.raw.setdefault(name + "_provider_incomplete", []).append(deepcopy(evidence))
        prompt, schema = _contract(stage)
        self.receipts.append(dict(request_sha256=evidence["request_sha256"], receipt=evidence["receipt"],
            stage=name, model=MODEL_PROFILES[self.profile][stage], cache=cached,
            reservation_estimate_usd=reserve, attempt_kind="PROVIDER_INCOMPLETE", status="PAID_INVALID_OUTPUT",
            provider_reason=evidence["provider_reason"], response_ref=evidence["response_ref"],
            raw_response_sha256=evidence["raw_response_sha256"],
            paid_receipt_sha256=evidence["paid_receipt_sha256"], prompt_sha256=digest(prompt), schema_sha256=digest(schema)))
        if stage in self.format_retry_stages or "format_retry" in payload:
            raise PlanFailure(stage, "Provider format retry exhausted; failed artifacts retained")
        self.format_retry_stages.add(stage)
        retry = deepcopy(payload)
        retry["format_retry"] = dict(version=FORMAT_RETRY_VERSION, attempt=1,
            previous_request_sha256=evidence["request_sha256"], cause="provider_incomplete_max_output_tokens",
            message=FORMAT_RETRY_MESSAGE)
        return self.call(stage, retry, record_key=record_key)

    def call(self, stage, payload, *, record_key=None):
        prompt, schema = _contract(stage)
        name = "planning_v3_" + stage
        model = MODEL_PROFILES[self.profile][stage]
        wire = api.request(name, payload, prompt, schema, model=model, max_output_tokens=MAX_OUTPUT_TOKENS)
        key = digest(dict(version=api.VERSION, endpoint="https://api.openai.com/v1", stage=name, request=wire))
        if self.root is None: raise PlanFailure(stage, "An explicit API cache root is required")
        path = self.root / "cache" / (key + ".json")
        reserve = 0.
        if path.exists():
            record = load(path)
            receipt_path = (self.root / record["receipt_path"]).resolve()
            if not receipt_path.is_relative_to(self.root / "receipts"): raise ValueError("Unbound API receipt")
            receipt = load(receipt_path)
            if (record["version"] != api.VERSION or record["request"] != wire
                    or record["output_sha256"] != digest(record["output"]) or receipt["status"] != "PASS"
                    or receipt["request_sha256"] != digest(wire) or receipt["model"] != model):
                raise ValueError("Planner API cache identity changed")
            output = deepcopy(record["output"])
            ref = dict(request_sha256=key, receipt=record["receipt_path"], cache=True)
        else:
            attempts = _matching_provider_attempts(self.root, wire)
            if any(r.get("status") in {"RESERVED", "FAILED_UNKNOWN_BILLING"} for _, r in attempts):
                raise PlanFailure(stage, "Prior request has pending/unknown billing; manual review required")
            evidence = confirmed_provider_format_failure(self.root, wire, key, attempts)
            if evidence:
                return self._retry_format(stage, payload, evidence, record_key=record_key, reserve=0., cached=True)
            if attempts and ("format_retry" in payload or any(r.get("status") == "PAID_INVALID_OUTPUT" for _, r in attempts)):
                raise PlanFailure(stage, "Prior paid output failed without retryable truncation; manual revision required")
            if not self.execute: raise PlanFailure(stage, "CACHE_MISS_NO_PAID_APPROVAL")
            rates = api.RATES[model]
            reserve = ((len(json.dumps(wire, ensure_ascii=True).encode()) + 4096) * rates[0]
                       + MAX_OUTPUT_TOKENS * rates[1]) / 1e6
            if self.reserved + reserve > self.limit: raise PlanFailure(stage, "Pilot reservation allowance exceeded")
            self.reserved += reserve
            before = {path for path, _ in attempts}
            try:
                output, ref = api.call(self.root, name, payload, prompt, schema, model=model,
                    max_output_tokens=MAX_OUTPUT_TOKENS, cap=self.cap, client=self.client)
            except Exception:
                # Do not borrow another concurrent caller's paid attempt or
                # automatically replay an unknown network/billing failure.
                new = [(p, r) for p, r in _matching_provider_attempts(self.root, wire) if p not in before]
                evidence = confirmed_provider_format_failure(self.root, wire, key, new) if len(new) == 1 else None
                if evidence:
                    return self._retry_format(stage, payload, evidence, record_key=record_key, reserve=reserve, cached=False)
                if len(new) == 1:
                    path, receipt = new[0]
                    self.receipts.append(dict(request_sha256=key, receipt=str(path.relative_to(self.root)),
                        stage=record_key or stage, model=model, cache=False, reservation_estimate_usd=reserve,
                        attempt_kind="FORMAT_RETRY_FAILED" if "format_retry" in payload else "PROVIDER_FAILED",
                        status=receipt.get("status"), prompt_sha256=digest(prompt), schema_sha256=digest(schema)))
                raise
        self.raw[record_key or stage] = deepcopy(output)
        self.receipts.append(dict(ref, stage=record_key or stage, model=model, raw_sha256=digest(output), prompt_sha256=digest(prompt),
            schema_sha256=digest(schema), reservation_estimate_usd=reserve))
        if "format_retry" in payload:
            self.receipts[-1].update(attempt_kind="FORMAT_RETRY", format_retry=deepcopy(payload["format_retry"]))
        jsonschema.validate(output, schema)
        return output


def prepare(case, *, api_root=None, execute=False, approved_targets=(), context_policy="paragraph",
            output_root=None, cap=25., reservation_limit=1., client=None, model_profile=None):
    """Return all raw diagnostics and ready arm views; never substitute failures."""
    case = public_case(case)
    selected = select_context(case, context_policy)
    if selected["case"] != case:
        raise PlanFailure("context", "Use select_context(...)[case] in the public catalog before planning")
    calls = _Calls(api_root, bool(execute and case["case_id"] in approved_targets), cap, client, reservation_limit,
                   model_profile or DEFAULT_PROFILE)
    bundle = dict(version=VERSION, case=deepcopy(case), context_mapping=selected["mapping"], plans={}, failures={},
                  raw_outputs=calls.raw, receipts=calls.receipts, shared={}, status="FAILED", model_profile=calls.profile)
    stage = "extraction"
    try:
        public = {k: case[k] for k in ("task", "query", "focal_marker")}
        raw = calls.call(stage, public)
        extracted, qc = project(raw, case)
        extracted, rejected = check_extraction(extracted, case, quarantine=True)
        qc.extend(rejected)
        stage = "atoms"
        atom_raw = calls.call(stage, dict(public, extraction=extracted))
        atom_qc = []
        try:
            atoms = _validate_atoms(atom_raw, case, atom_qc)
        except ValueError as error:
            bundle["atom_validation_failure"] = dict(reason=str(error), raw_sha256=digest(atom_raw))
            atom_raw = calls.call(stage, dict(public, extraction=extracted,
                previous_output=atom_raw, validation_error=str(error)), record_key="atoms_repair")
            atom_qc = []
            atoms = _validate_atoms(atom_raw, case, atom_qc)
        bundle["shared"] = dict(atoms_sha256=digest(atoms), extraction_sha256=digest(extracted),
            raw_atoms_sha256=digest(atom_raw), raw_extraction_sha256=digest(raw), extraction_qc=deepcopy(qc),
            atom_quote_qc=deepcopy(atom_qc))
        shared_receipts = deepcopy(calls.receipts)
        def plan(arm, interpretation, provenance, receipts):
            interpretation_qc = _validate_interpretation(interpretation, case, atoms) if arm == "llm_readings" else []
            licensing = dict(version=VERSION, reading_provenance=provenance, question_execution="WHOLE_TEXT_ONLY",
                model_profile=calls.profile, model_supplementation=False, semantic_entailment_certified=False)
            if arm == "llm_local": licensing["local_policy"] = LOCAL_POLICY
            return dict(version=VERSION, arm=arm, task=case["task"], query_sha256=digest(case["query"]),
                atoms=deepcopy(atoms), extractions=deepcopy(extracted),
                slot_readings=[_reading_view(r) for r in interpretation["slot_readings"]],
                leads=deepcopy(interpretation["leads"]), context_incomplete=atom_raw["context_incomplete"],
                extraction_qc=deepcopy(qc), interpretation_qc=interpretation_qc,
                receipts=[{k: deepcopy(v) for k, v in r.items() if k not in {"cache", "reservation_estimate_usd"}} for r in receipts],
                source_licensing=licensing,
                shared_atoms_sha256=digest(atoms), shared_extraction_sha256=digest(extracted),
                raw_shared_atoms_sha256=digest(atom_raw), raw_shared_extraction_sha256=digest(raw),
                interpretation_repairs=deepcopy(atom_qc), expansion_repairs=[], keys_read=False, grades_read=False)
        bundle["plans"]["llm_atoms"] = plan("llm_atoms", dict(slot_readings=[], leads=[]), "NONE", shared_receipts)
        try:
            local, raw_local = _local_interpretation(case)
            calls.raw["local_readings"] = deepcopy(raw_local)
            bundle["plans"]["llm_local"] = plan("llm_local", local, "LOCAL_ONLY", shared_receipts)
        except Exception as error:
            bundle["failures"]["llm_local"] = dict(stage="local_readings", reason=str(error), error_type=type(error).__name__)
        try:
            interpretation = _model_interpretation(calls.call("readings", dict(public,
                extraction=extracted, atoms=atom_raw["atoms"])), case)
            bundle["plans"]["llm_readings"] = plan("llm_readings", interpretation, "MODEL_ONLY", calls.receipts)
        except Exception as error:
            bundle["failures"]["llm_readings"] = dict(stage="readings", reason=str(error), error_type=type(error).__name__)
    except Exception as error:
        bundle["failures"]["shared"] = dict(stage=stage, reason=str(error), error_type=type(error).__name__)
    bundle["status"] = "READY" if set(bundle["plans"]) == set(ARMS) and not bundle["failures"] else "FAILED"
    bundle["reservation_estimate_usd"] = calls.reserved
    if output_root is not None:
        path = Path(output_root) / (case["case_id"] + "__" + digest(bundle)[:16] + ".json")
        if path.exists() and load(path) != bundle: raise ValueError("Existing v3 bundle changed")
        save(path, bundle)
    return bundle


def get_plans(bundle):
    if bundle["status"] != "READY": raise PlanFailure("planning", str(bundle["failures"]), bundle)
    if any(p["shared_atoms_sha256"] != bundle["shared"]["atoms_sha256"]
           or p["shared_extraction_sha256"] != bundle["shared"]["extraction_sha256"]
           for p in bundle["plans"].values()):
        raise PlanFailure("planning", "Shared inputs differ between arms", bundle)
    return {arm: validate_plan(deepcopy(bundle["plans"][arm]), bundle["case"]) for arm in ARMS}


def make_plans(case, api_root, cap=25, execute=True, *, output_root=None):
    """Main-facing API; execute authorizes only this explicitly supplied case."""
    return get_plans(prepare(case, api_root=api_root, cap=cap, execute=execute,
                            approved_targets=(case["case_id"],) if execute else (), output_root=output_root))


def validate_plan(plan, case):
    case = public_case(case)
    expected = {"version", "arm", "task", "query_sha256", "atoms", "extractions", "slot_readings", "leads",
        "context_incomplete", "extraction_qc", "interpretation_qc", "receipts", "source_licensing", "shared_atoms_sha256",
        "shared_extraction_sha256", "raw_shared_atoms_sha256", "raw_shared_extraction_sha256",
        "interpretation_repairs", "expansion_repairs", "keys_read", "grades_read"}
    if set(plan) != expected: raise ValueError("Unexpected or missing v3 plan fields")
    if plan.get("version") != VERSION or plan.get("arm") not in ARMS or plan.get("task") != case["task"]:
        raise ValueError("Invalid v3 planning binding")
    if plan["query_sha256"] != digest(case["query"]) or plan["keys_read"] is not False or plan["grades_read"] is not False:
        raise ValueError("Nonpublic or changed planning query")
    check_extraction(plan["extractions"], case)
    if project(plan["extractions"], case)[0] != plan["extractions"]: raise ValueError("Extraction projection is not stable")
    raw_atoms = dict(atoms=[{k: a[k] for k in ("id", "text", "source_quote", "required")} for a in plan["atoms"]],
                     context_incomplete=plan["context_incomplete"])
    if _validate_atoms(raw_atoms, case) != plan["atoms"]: raise ValueError("Atom offsets changed")
    if digest(plan["atoms"]) != plan["shared_atoms_sha256"] or digest(plan["extractions"]) != plan["shared_extraction_sha256"]:
        raise ValueError("Shared atom or extraction hash changed")
    readings = []
    for r in plan["slot_readings"]:
        row = dict(id=r["id"], form=r["form"], explanation=r["notes"],
                   referent_kind=r["target_kind"], grammatical_number=r["grammatical_number"], cue_quote=r["kind_cue_quote"],
                   **{k: r[k] for k in ("left_quote", "right_quote", "attachment_quote", "finite")})
        if _reading_view(row) != r: raise ValueError("Reading routing metadata changed")
        readings.append(row)
    if plan["arm"] == "llm_atoms":
        if readings or plan["leads"]: raise ValueError("Atoms-only arm acquired readings/questions")
    elif plan["arm"] == "llm_readings":
        if _validate_interpretation(dict(slot_readings=readings, leads=plan["leads"]), case, plan["atoms"]) != plan["interpretation_qc"]:
            raise ValueError("Interpretation QC changed")
    if plan["arm"] == "llm_local" and plan["leads"]: raise ValueError("Local arm acquired model questions")
    provenance = dict(llm_readings="MODEL_ONLY", llm_atoms="NONE", llm_local="LOCAL_ONLY")[plan["arm"]]
    profile = plan["source_licensing"].get("model_profile")
    if profile not in MODEL_PROFILES: raise ValueError("Unknown model profile")
    expected_licensing = dict(version=VERSION, reading_provenance=provenance,
        question_execution="WHOLE_TEXT_ONLY", model_profile=profile, model_supplementation=False, semantic_entailment_certified=False)
    local_policy = None
    if plan["arm"] == "llm_local" and "local_policy" in plan["source_licensing"]:
        local_policy = plan["source_licensing"]["local_policy"]
        if local_policy != LOCAL_POLICY: raise ValueError("Unknown local reading policy")
        expected_licensing["local_policy"] = local_policy
    if plan["source_licensing"] != expected_licensing:
        raise ValueError("Planning provenance changed")
    for receipt in plan["receipts"]:
        stage = receipt["stage"].removesuffix("_repair")
        if receipt["model"] != MODEL_PROFILES[profile][stage] or "cache" in receipt or "reservation_estimate_usd" in receipt:
            raise ValueError("Noncanonical planning receipt")
    if plan["arm"] == "llm_local" and plan["slot_readings"] != [
            _reading_view(r) for r in _local_interpretation(case, policy=local_policy)[0]["slot_readings"]]:
        raise ValueError("Local-only readings changed")
    return plan


def searches(plan, case):
    """Whole-text execution adapter; explanatory notes are never search inputs."""
    validate_plan(plan, case)
    rows = [dict(kind="context", query=MASK.sub(" ", case["query"]), reading_ids=[])]
    rows.extend(dict(kind="atom", query=MASK.sub(" ", a["text"]), atom_id=a["id"], reading_ids=[]) for a in plan["atoms"])
    rows.extend(dict(kind="question", query=MASK.sub(" ", q["question"]), lead_id=q["id"],
                     reading_ids=q["reading_ids"]) for q in plan["leads"])
    return rows
