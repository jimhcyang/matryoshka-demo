"""Keep retrieved source clues even when the strict predicate binder fails.

These quotations do not change native support decisions. They prevent an exact
predicate gate from hiding potentially useful passages from analysts or graders.
"""
from copy import deepcopy
import re

import numpy as np

from .contracts import MASK
from .corpus import BM25,ordered
from .io import digest
from .task_execution_v2 import offset_safe_parser
from .tasks import parser


VERSION="source-exploration-quotes/2.1"


def passage_pool(case,retrieval,passage_budget):
    if type(passage_budget) is not int or passage_budget<1:raise ValueError("A positive source-page budget is required")
    c=retrieval["eligible"].corpus;e=retrieval["eligible"];parse=offset_safe_parser(parser());rows={}
    pages=sorted(set(retrieval["pages"]),key=lambda pi:(retrieval["page_ranks"].get(pi,10**9),c.pages[pi]["id"]))[:passage_budget]
    for pi in pages:
        p=c.pages[pi]
        if not e.page_mask[pi] or p["document_id"]==case["document_id"] or p["date"]>=case["date"]:raise ValueError("Ineligible exploration source")
        # Parse paragraphs independently: parser sentence boundaries alone can
        # absorb a blank line and silently join unrelated source sections.
        for paragraph in re.finditer(r"[^\n]*(?:\n(?!\s*\n)[^\n]*)*",p["text"]):
            if not paragraph.group().strip():continue
            sentences=[s for s in parse(paragraph.group()).sents if s.text.strip()]
            for i,s in enumerate(sentences):
                if MASK.search(s.text):continue
                a,b=s.start_char,s.end_char
                if i and not MASK.search(sentences[i-1].text):a=sentences[i-1].start_char
                if i+1<len(sentences) and not MASK.search(sentences[i+1].text):b=sentences[i+1].end_char
                a+=paragraph.start();b+=paragraph.start()
                while a<b and p["text"][a].isspace():a+=1
                while b>a and p["text"][b-1].isspace():b-=1
                quote=p["text"][a:b];identity="clue_"+digest([p["id"],a,b])[:24]
                rows[identity]=dict(id=identity,canonical_page_id=p["id"],document_id=p["document_id"],date=p["date"],
                    start=a,end=b,text=quote,page_sha256=p["source_sha256"],earlier_page=p.get("earlier_page"),
                    corpus=case["corpus"],relevance_only=True,used_for_native_verdict=False)
    return rows,len(pages)


def enrich(case,plan,retrieval,result,*,passage_budget=100,top_k=5):
    if case["task"] not in {"hypothesis","reconstruction"}:raise ValueError("Exploratory task evidence only")
    if type(top_k) is not int or not 1<=top_k<=5:raise ValueError("At most five displayed source clues")
    value=deepcopy(result);pool,inspected=passage_pool(case,retrieval,passage_budget)
    ids=sorted(pool);index=BM25([pool[k]["text"] for k in ids]);mask=np.ones(len(ids),dtype=bool)
    accounts=[]
    for atom in value["atoms"]:
        scores=index.score(atom["text"]+" "+atom["source_quote"],mask)
        selected=[]
        for i in ordered(scores,ids):
            source=deepcopy(pool[ids[i]])
            # Overlapping windows of the same sentence are one display clue.
            if any(source["canonical_page_id"]==other["canonical_page_id"] and max(source["start"],other["start"])<min(source["end"],other["end"]) for other in selected):continue
            source.update(rank=len(selected)+1,bm25=float(scores[i]),support_label="Exploratory passage; no local claim-support assertion")
            selected.append(source)
            if len(selected)==top_k:break
        atom["exploratory_passages"]=selected
        for source in selected:
            accounts.append(dict(atom_id=atom["id"],text=source["text"],citations=[source],
                epistemic_status="SOURCE_QUOTATION_NOT_QUERY_ENTAILMENT",supports_planned_proposition=False,
                used_for_native_verdict=False))
    task=value[case["task"]]
    task["retrieved_source_accounts"]=sorted(accounts,key=lambda a:(a["citations"][0]["date"],a["citations"][0]["document_id"],a["citations"][0]["start"],a["atom_id"]))
    task["retrieved_source_account_meaning"]="Chronology of source reports, not an inferred chronology or causal account of events"
    value["exploratory_evidence"]=dict(version=VERSION,source_pages_inspected=inspected,source_windows=len(pool),
        per_atom_display=top_k,native_verdict_unchanged=True,source_only=True,api_calls=0,
        meaning="Potentially useful lexical source clues survive strict structured-match failure; these are not positive support votes")
    return value
