"""Run the real src pipeline on a replayable projection of archived extraction.

This module adapts sources, not native scores or decisions. It never creates
propositions from raw pages and never imports the current task engines. The
historical graph cannot safely be reused under the current source policy:
original Stage B/C and GraphRetriever rebuild it from the admitted records.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from contextlib import redirect_stdout
from copy import deepcopy
import csv
from datetime import date
from functools import lru_cache
import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import time

import numpy as np

from .contracts import MASK, public_case
from .corpus import locate
from .corpus_policy_v5 import PolicyView, VERSION as POLICY_VERSION, policy_view
from .io import digest, sha
from .legacy_reference_v2 import (
    ORIGINAL_QUERY_CONTRACT, WORKSPACE, _citation, _json, _lineage,
    _locate_native_sentence, _marker_adaptation, load_original,
)


VERSION = "original-src-source-projection/5"
IMPLEMENTATION_SHA256 = sha(Path(__file__))
TABLES = ("chunks.csv", "entities.csv", "claims.csv", "events.csv", "relations.csv")
REFERENCE_KIND = "ORIGINAL_SRC_PIPELINE_WITH_GROUNDED_EXTRACTION_AND_ELIGIBILITY_ADAPTER"
FIELDS = (
    "doc_id", "source_id", "date", "subject", "paragraph_id", "chunk_id",
    "local_id", "chunk_text", "label", "normalized_label", "type",
    "description", "context_window_text", "claim_text", "speaker", "target",
    "stance", "modality", "location", "date_or_temporal_context", "source",
    "relation", "evidence", "confidence",
)
LIMITATIONS = [
    "Original mechanics on a filtered source projection, not identical historical results or an archived-graph replay.",
    "Only complete archived chunks replayable with whitespace-only normalization in current permitted pages are admitted; masked chunks are rejected.",
    "Historical extraction assertions remain model-derived; source replay is not entailment certification.",
    "Original heuristic query parsing is used; neither an API parser nor optional LLM/mosaic inference runs.",
    "A finite page budget is an adapter restriction: native lexical atomic retrieval admits pages before the native graph is rebuilt.",
    "Stage B/C, hierarchy and graph paths are regenerated from admitted records, not copied from another arm or from the historical unrestricted graph.",
    "Native verdicts are unchanged and separate from current strict task assessments; missing evidence is not counterevidence.",
    "No retrieval superiority or equivalence to the published demo's different source universe is claimed.",
]


@lru_cache(maxsize=1)
def _stages():
    """Import unmodified original materializers without retaining sys.path edits."""
    root = WORKSPACE / "src/scripts/knowledge_graph"
    previous, bytecode = list(sys.path), sys.dont_write_bytecode
    try:
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(root))
        modules = [importlib.import_module("kg_scripts." + name) for name in ("stage_b", "stage_c")]
        for name, module in tuple(sys.modules.items()):
            if name == "kg_scripts" or name.startswith("kg_scripts."):
                path = getattr(module, "__file__", None)
                if path and not Path(path).resolve().is_relative_to(root):
                    raise ImportError("Refusing non-original materializer: " + name)
        return tuple(modules)
    finally:
        sys.path[:] = previous
        sys.dont_write_bytecode = bytecode


def _archive(corpus):
    project = {"iran": "iran_full_unredacted", "vietnam": "viet_full_unredacted",
               "cib": "cib_full_redacted"}[corpus.corpus]
    # CIB must not fall back to the later/unredacted release.
    directory = "extraction" if corpus.corpus == "cib" else "extraction_canonicalized"
    return WORKSPACE / "src/output/knowledge_graph" / project / directory


def _read_csv(path):
    if not path.is_file() or not path.stat().st_size:
        return []
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return list(reader)


def _native_frame(path):
    import pandas as pd
    if not path.is_file() or not path.stat().st_size:
        return pd.DataFrame()
    try:
        return pd.read_csv(path, keep_default_na=False, low_memory=False)
    except pd.errors.EmptyDataError:
        return pd.DataFrame()


def _write_csv(path, records, fields=FIELDS):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)


def _write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2), encoding="utf-8")


def _key(row):
    return (row.get("doc_id", "").strip().upper(), row.get("paragraph_id", ""), row.get("chunk_id", ""))


@lru_cache(maxsize=3)
def _grounded_archive(corpus, extraction_dir, stamps, handling_veto=()):
    """Cache only query-independent, literal-source-grounded archive rows."""
    del stamps  # Included in the cache identity, checked again by run().
    root = Path(extraction_dir)
    by_doc, normalized_ids = defaultdict(list), {}
    veto = set(handling_veto)
    for pi, page in enumerate(corpus.pages):
        if (not page.get("permitted", False) or not corpus.allowed[pi]
                or page["document_id"] in veto):
            continue
        doc = page["document_id"].strip().upper()
        if doc in normalized_ids and normalized_ids[doc] != page["document_id"]:
            raise ValueError("Distinct pinned document IDs collide under native normalization")
        normalized_ids[doc] = page["document_id"]
        by_doc[doc].append(pi)
    chunks, statistics, hashes = {}, {}, {}
    result = {name: [] for name in TABLES}
    csv.field_size_limit(max(csv.field_size_limit(), 16 * 1024 * 1024))
    for name in TABLES:
        counts = Counter()
        path = root / name
        if not path.is_file():
            statistics[name] = {"missing": True, "admitted": 0}
            continue
        hashes[name] = sha(path)
        with path.open(encoding="utf-8", newline="") as handle:
            for ordinal, row in enumerate(csv.DictReader(handle)):
                counts["read"] += 1
                key = _key(row)
                if name == "chunks.csv":
                    doc = next((value.strip().upper() for value in
                                (row.get("doc_id", ""), row.get("source_id", ""))
                                if value.strip().upper() in by_doc), "")
                    if not doc:
                        counts["no_current_document"] += 1
                        continue
                    raw = row.get("chunk_text", "") or row.get("body", "")
                    if not raw.strip() or MASK.search(raw):
                        counts["empty_or_masked_chunk"] += 1
                        continue
                    matches = [(pi, interval) for pi in by_doc[doc]
                               if (interval := locate(corpus.pages[pi]["text"], raw)) is not None]
                    if not matches:
                        counts["chunk_not_replayable"] += 1
                        continue
                    # Preserve duplicate-page ambiguity rather than inventing an offset.
                    chunks[key] = (doc, raw, tuple(matches))
                elif key not in chunks:
                    counts["no_grounded_chunk"] += 1
                    continue
                doc, raw, matches = chunks[key]
                if name == "entities.csv":
                    label = row.get("label", "")
                    if not label.strip() or MASK.search(label) or label.casefold() not in raw.casefold():
                        counts["nonliteral_entity_value"] += 1
                        continue
                projected = {field: row.get(field, "") for field in FIELDS}
                projected.update(doc_id=doc, source_id=doc, chunk_text=raw)
                # Remove corpus-wide sibling contexts/aliases and source paths. Retain
                # the archived assertion itself, with its exact parent chunk witness.
                projected["context_window_text"] = raw if name == "entities.csv" else ""
                if name == "entities.csv":
                    projected["normalized_label"] = projected["label"]
                evidence = dict(original_table=name, original_row=ordinal, original_document_id=key[0],
                                original_paragraph_id=key[1], original_chunk_id=key[2],
                                original_local_id=row.get("local_id", ""), original_row_sha256=digest(row),
                                page_matches=matches, native_document_id=doc)
                result[name].append((projected, evidence))
                counts["admitted"] += 1
        statistics[name] = dict(counts)
    return result, statistics, hashes


def _eligible(case, corpus):
    selected = corpus.eligible(case)
    if len(selected.page_mask) != len(corpus.pages):
        raise ValueError("Eligibility mask length mismatch")
    cutoff = date.fromisoformat(case["date"])
    origin = case["document_id"].strip().casefold()
    mask = np.array([bool(selected.page_mask[pi]) and bool(corpus.allowed[pi]) and page.get("permitted", False)
                     and date.fromisoformat(page["date"]) < cutoff
                     and page["document_id"].strip().casefold() != origin
                     for pi, page in enumerate(corpus.pages)], dtype=bool)
    # Do not trust an adapter mask that silently admits forbidden source rows.
    if np.any(np.asarray(selected.page_mask, dtype=bool) & ~mask):
        raise ValueError("Eligibility adapter admitted an origin, cutoff, future or forbidden page")
    return selected, mask


def _project(grounded, mask, corpus):
    result = {name: [] for name in TABLES}
    for name, records in grounded.items():
        for row, witness in records:
            matches = [(pi, interval) for pi, interval in witness["page_matches"] if mask[pi]]
            if not matches:
                continue
            for pi, interval in matches:
                page = corpus.pages[pi]
                if (page["document_id"].strip().upper() != witness["native_document_id"]
                        or locate(page["text"], row["chunk_text"]) != tuple(interval)):
                    raise ValueError("Cached archived chunk witness no longer replays in its pinned source")
            value, evidence = dict(row), dict(witness, page_matches=matches)
            # The original event date may describe an event, not the report's
            # eligibility date. Keep that event time separately in the native schema.
            when = corpus.pages[matches[0][0]]["date"]
            if name == "events.csv" and value["date"] and value["date"] != when:
                value["date_or_temporal_context"] = value["date_or_temporal_context"] or value["date"]
            value["date"] = when
            value["subject"] = ""
            result[name].append((value, evidence))
    return result


def _materialize(project, records):
    """The original B/C builders receive real archived rows, never invented NLP."""
    stage_b, stage_c = _stages()
    extraction = project / "extraction_canonicalized"
    for name in TABLES:
        _write_csv(extraction / name, [row for row, _ in records[name]])
    segments = {}
    for row, _ in records["chunks.csv"]:
        key = (row["doc_id"], row["paragraph_id"])
        segment = segments.setdefault(key, dict(doc_id=key[0], paragraph_id=key[1], date=row["date"],
                                               subject="", source_path="", heading="", texts=[]))
        if row["chunk_text"] not in segment["texts"]:
            segment["texts"].append(row["chunk_text"])
    sources = []
    for segment in segments.values():
        raw = "\n".join(segment.pop("texts"))
        sources.append(dict(segment, unredacted_text=raw, redacted_text=raw,
                            char_count=len(raw), word_count=len(raw.split())))
    _write_csv(project / "prepared/source_segments.csv", sources,
               ("doc_id", "paragraph_id", "date", "subject", "source_path", "heading",
                "unredacted_text", "redacted_text", "char_count", "word_count"))
    identity = digest({name: [row for row, _ in values] for name, values in records.items()})
    _write_json(project / "state/current_snapshot.json", {"snapshot_id": identity, "complete": True,
                                                          "adapter": VERSION, "stage_a_extraction_rerun": False})
    _write_json(project / "alias/incremental_state.json", {"source_snapshot_id": identity,
                                                          "adapter": "source-local archived labels; no alias resolution rerun"})
    _write_json(extraction / "runtime_state.json", {"snapshot_id": identity, "status": "ALIAS_READY_AWAITING_STAGE_C"})
    with redirect_stdout(io.StringIO()):
        stage_b.build_graph(project, extraction)
        stage_c.build_task_views(project, extraction, 1, 10)
    return extraction


def _admission_index(native, root, records, resources):
    """Use native lexical indexing without materializing a discarded full KG.

    This is only the finite-page admission adapter. The primary matcher still
    builds the original task views, graph and task-specific feature index.
    """
    for name in TABLES:
        _write_csv(root / name, [row for row, _ in records[name]])
    return native.corpus.CorpusIndex.build(root, task="claims", semantic_resources=resources,
                                           semantic_resource_fingerprint=resources.fingerprint)


def _parse(native, text, root):
    parsed, mode, warnings = native.parser.parse_query_text(text, use_openai=False)
    native.parser.write_parse_outputs(parsed, root, "public_query", mode, warnings)
    return native.contracts.safe_json(root / "query_parse_manifest.json")


def _native_marker_adaptation(case, native):
    transformed, audit = _marker_adaptation(case)
    start = case["query"].index(case["focal_marker"])
    end = start + len(case["focal_marker"])
    matches = list(native.parser.iter_redaction_matches(case["query"]))
    others = [match for match, _ in matches if match.span() != (start, end)]
    label = "R1"
    if others:
        explicit = [int(match.groupdict()["slot_label"][1:]) for match in others
                    if match.groupdict().get("slot_label")]
        label = "R" + str(max([len(matches) + 2, *[value + 1 for value in explicit]]))
        replacement = "[REDACT:" + label + "]"
        transformed = case["query"][:start] + replacement + case["query"][end:]
        delta = len(replacement) - len(audit["replacement"]["transformed_text"])
        audit["replacement"].update(transformed_end=start + len(replacement), transformed_text=replacement)
        for piece in audit["piecewise_map"]:
            if piece["kind"] == "OPAQUE_MARKER_REPLACEMENT":
                piece["transformed_end"] += delta
            elif piece["raw_start"] >= end:
                piece["transformed_start"] += delta
                piece["transformed_end"] += delta
        audit.update(transformed_query=transformed,
                     transformed_query_sha256=hashlib.sha256(transformed.encode("utf-8")).hexdigest())
    audit.update(version="focal-native-marker-only/5", native_slot_label=label,
                 slot_label_collision_avoided=bool(others))
    return transformed, audit


def _bindings(records, corpus, native):
    citations, bindings, paragraphs = {}, defaultdict(set), defaultdict(set)
    for name, values in records.items():
        for row, witness in values:
            doc = row["doc_id"]
            for pi, (start, end) in witness["page_matches"]:
                page = corpus.pages[pi]
                cite = _citation(page, doc, start, end, "ARCHIVED_CHUNK_WITNESS")
                citations[cite["id"]] = cite
                bindings[(doc, name, row["local_id"])].add(cite["id"])
                bindings[(doc, "chunks.csv", row["chunk_id"])].add(cite["id"])
                paragraphs[(doc, row["paragraph_id"])].add(cite["id"])
                if name == "chunks.csv":
                    cursor = start
                    for sentence in native.corpus._sentences(row["chunk_text"]):
                        interval = _locate_native_sentence(page["text"], sentence, cursor)
                        if interval is None or interval[1] > end:
                            continue
                        cursor = interval[1]
                        sentence_cite = _citation(page, doc, *interval, "SENTENCE")
                        citations[sentence_cite["id"]] = sentence_cite
    return citations, bindings, paragraphs


def _reference(row, citations, bindings):
    docs = set()
    for key, value in row.items():
        if isinstance(value, str) and (key == "doc_id" or key.endswith("_doc_id")):
            docs.update(part.strip().upper() for part in value.replace("|", ";").replace(",", ";").split(";") if part.strip())
    row_ids = {v for k, v in row.items() if isinstance(v, str) and (k.endswith("row_id") or k in {"chunk_id", "component_id"})}
    ids = sorted({cid for (doc, _, rid), values in bindings.items()
                  if doc in docs and rid and rid in row_ids for cid in values})
    if ids:
        return dict(citation_ids=ids, binding="ARCHIVED_NATIVE_RECORD_PARENT_CHUNK",
                    native_record_parent_binding_ambiguous=len(ids) > 1,
                    localization="PARENT_CHUNK_NOT_ASSERTION_ENTAILMENT")
    ids = sorted(cid for cid, cite in citations.items()
                 if cite["native_document_id"] in docs and cite["granularity"] == "ARCHIVED_CHUNK_WITNESS")
    return dict(citation_ids=ids, binding="DOCUMENT_ONLY_NOT_LOCALIZED" if ids else "NO_NATIVE_SOURCE_SELECTED")


def _execute(native, case, query_root, project, *, document_budget, graph):
    tasks = ["claims", "contradictions"] if case["task"] == "hypothesis" else [case["task"]]
    results, diagnostics, paths, atoms = {}, {}, [], []
    for task in tasks:
        output = project / "native_outputs" / task
        try:
            package = native.query.QueryPackage.load(query_root, task=task)
        except ValueError as error:
            if "no executable primary target" not in str(error):
                raise
            results[task] = dict(execution_status="BLOCKED_BY_ORIGINAL_QUERY_CONTRACT", error=str(error), evaluation=[])
            continue
        preflight = native.matcher._preflight(task, package)
        if any(row["status"].startswith("BLOCKED_") for row in preflight):
            results[task] = dict(execution_status="BLOCKED_BY_ORIGINAL_QUERY_CONTRACT", preflight=preflight, evaluation=[])
            continue
        args = ["--extraction-dir", str(project / "extraction_canonicalized"),
                "--query-parse-dir", str(query_root), "--output-dir", str(output),
                "--task-mode", task, "--exclude-doc-ids", case["document_id"],
                "--staged-top-docs", str(document_budget), "--retrieval-mode", "graph_staged" if graph else "staged",
                "--audit-row-limit-per-target", "100"]
        if graph:
            args.extend(["--graph-index-dir", str(project / "retrieval_graph")])
        with redirect_stdout(io.StringIO()):
            code = native.matcher.main(args)
        contract = native.contracts.safe_json(output / "matcher_output_contract_v048.json")
        frame = _native_frame(output / "task_evaluation_v048.csv") if code == 0 else _native_frame(output / "ABSENT.csv")
        evaluation = _json(frame.to_dict("records"))
        results[task] = dict(execution_status="EXECUTED" if code == 0 else "NATIVE_EXECUTION_FAILED",
                             exit_code=code, preflight=preflight, evaluation=evaluation,
                             output_contract=contract,
                             authoritative_digest=native.contracts.authoritative_digest(frame))
        digest_path = output / "semantic_match_task_digest_v0413.md"
        if digest_path.is_file():
            results[task]["task_digest"] = digest_path.read_text(encoding="utf-8")
        diagnostics[task] = {path.name: dict(rows=_json(_native_frame(path).to_dict("records"))) for path in sorted(output.glob("*.csv"))
                             if not path.name.startswith("graph_retrieval_")}
        for filename, key in (("task_evidence_units_v0413.json", "evidence_units"),
                              ("semantic_match_run_manifest_v048.json", "run_manifest")):
            results[task][key] = native.contracts.safe_json(output / filename)
        paths.extend(dict(row, native_task=task) for row in _read_csv(output / "graph_retrieval_paths_v1.csv"))
        atoms.extend(dict(row, native_task=task) for row in _read_csv(output / "retrieval_atom_contract_v1.csv"))
    return results, diagnostics, paths, atoms


def _original_graph(project, results, paths, paragraphs):
    """Keep original tables untouched; witness links are a separate overlay."""
    root = project / "retrieval_graph"
    graph = {"schema": "original-src-graph-tables/1", "paths": paths,
             "manifest": json.loads((root / "manifest.json").read_text(encoding="utf-8")),
             "nodes": _json(_native_frame(root / "nodes.csv.gz").to_dict("records")),
             "edges": _json(_native_frame(root / "edges.csv.gz").to_dict("records")),
             "communities": _json(_native_frame(root / "communities.csv").to_dict("records")),
             "narratives": _json(_native_frame(root / "narratives.csv").to_dict("records"))}
    for kind in ("seeds", "documents", "communities", "calls"):
        graph["retrieval_" + kind] = [dict(row, native_task=task) for task in results
            for row in _json(_native_frame(project / "native_outputs" / task / ("graph_retrieval_" + kind + "_v1.csv")).to_dict("records"))]
    edge_lookup = defaultdict(list)
    graph["edge_source_bindings"] = []
    for i, edge in enumerate(graph["edges"]):
        doc, paragraph = edge["doc_id"], edge["paragraph_id"]
        ids = sorted(paragraphs.get((doc, paragraph), ()))
        binding = dict(edge_index=i, citation_ids=ids,
                       binding="ARCHIVED_PARENT_CHUNK_WITNESS_NOT_EDGE_ASSERTION_ENTAILMENT")
        graph["edge_source_bindings"].append(binding)
        edge_lookup[(edge["source_node_id"], edge["target_node_id"], edge["edge_type"], doc)].append(i)
    if any(not binding["citation_ids"] for binding in graph["edge_source_bindings"]):
        raise ValueError("Original graph has an edge without an admitted exact source-chunk witness")
    provenance = []
    for i, path in enumerate(paths):
        nodes = path.get("path_node_ids", "").split(" -> ")
        types = path.get("path_edge_types", "").split(" -> ") if len(nodes) > 1 else []
        docs = path.get("path_edge_support_docs", "").split(" -> ") if types else []
        hops = []
        for a, b, kind, doc in zip(nodes, nodes[1:], types, docs):
            key = (b, a, kind[:-4], doc) if kind.endswith(":REV") else (a, b, kind, doc)
            indices = edge_lookup.get(key, [])
            if not indices:
                raise ValueError("Native graph path does not replay in its original typed adjacency")
            hops.append(dict(source_node_id=a, target_node_id=b, edge_type=kind, support_document_id=doc,
                             original_edge_indices=indices,
                             citation_ids=sorted({cid for index in indices for cid in graph["edge_source_bindings"][index]["citation_ids"]})))
        provenance.append(dict(graph_path_index=i, native_task=path["native_task"], path_kind=path["path_kind"],
                               hops=hops, citation_ids=sorted({cid for hop in hops for cid in hop["citation_ids"]}),
                               binding="ORIGINAL_TYPED_ADJACENCY_WITH_EXACT_PARENT_CHUNK_QUOTES",
                               path_is_semantic_proof=False))
    return graph, provenance


def _lineage_v5(native, tasks):
    result = _lineage(native, tasks)
    _stages()
    for name, module in tuple(sys.modules.items()):
        if name.startswith("kg_scripts."):
            path = Path(module.__file__).resolve()
            result["files_sha256"][str(path.relative_to(WORKSPACE))] = sha(path)
    result["contract_functions"].update({
        "corpus.CorpusIndex.build": "Original extraction-table loader and task feature indexing",
        "stage_b.build_graph": "Original graph materialization on admitted archive rows",
        "stage_c.build_task_views": "Original task pseudo views and component provenance",
        "common.retrieval_graph.build_retrieval_graph": "Original typed adjacency, TF-IDF seeds and Leiden hierarchy",
        "common.retrieval_graph.GraphRetriever.rank": "Original semantic/alias seeds, hierarchy expansion, local PPR and path audit",
        "matcher.main": "Original matcher entry point, native output contract, evidence bundle and digest",
    })
    result.update(retrieval_reproduced="Native graph-staged retrieval on a filtered source projection",
                  source_representation_functions=["CorpusIndex.build", "stage_b.build_graph", "stage_c.build_task_views"],
                  matcher_main_invoked=True, source_adapter=VERSION)
    return result


def run(case, corpus, *, passage_budget=100, document_budget=100, extraction_dir=None, graph=True):
    """Return (native result, current retrieval envelope), with no API calls.

    extraction_dir is an explicit archive override for tests/research. graph=False
    is an explicit native lexical ablation, never an automatic error fallback.
    """
    case = public_case(case)
    for name, value in (("passage_budget", passage_budget), ("document_budget", document_budget)):
        if type(value) is not int or value < 0:
            raise ValueError(name + " must be a nonnegative integer")
    if type(graph) is not bool:
        raise ValueError("graph must be an explicit boolean")
    corpus = policy_view(corpus)
    if corpus.corpus != case["corpus"]:
        raise ValueError("Case/corpus mismatch")
    started = time.perf_counter()
    eligible, mask = _eligible(case, corpus)
    native = load_original()
    archive = Path(extraction_dir).resolve() if extraction_dir is not None else _archive(corpus)
    stamps = tuple((name, (archive / name).stat().st_mtime_ns, (archive / name).stat().st_size)
                   for name in TABLES if (archive / name).is_file())
    original = corpus.original if isinstance(corpus, PolicyView) else corpus
    grounded, archive_counts, archive_hashes = _grounded_archive(
        original, str(archive), stamps, tuple(corpus.excluded_documents))
    records = _project(grounded, mask, corpus)
    query_text, adaptation = (_native_marker_adaptation(case, native) if case["task"] == "redaction" else (case["query"], None))
    binding = getattr(corpus, "binding", {})
    receipt = dict(method=VERSION, adapter="Archived extraction -> exact pinned chunk witnesses -> original B/C and matcher.main",
                   eligible_pages=int(mask.sum()), source_policy=getattr(corpus, "binding", {}).get("evidence_policy", "current_pinned_eligibility"),
                   current_extraction_contract=binding.get("extraction_contract"), current_graph_id=binding.get("graph_id"),
                   source_policy_version=POLICY_VERSION, handling_veto_documents=list(corpus.excluded_documents),
                   archive_path=str(archive), archive_sha256=archive_hashes, archive_grounding_statistics=archive_counts,
                   page_budget_admission="ORIGINAL_ATOMIC_LEXICAL_RANK_BEFORE_NATIVE_GRAPH_REBUILD",
                   original_graph_augmentation=False, api_calls=0, search_queries=[], document_order=[])
    base = dict(version=VERSION, implementation_sha256=IMPLEMENTATION_SHA256,
                task=case["task"], case_id=case["case_id"], reference_kind=REFERENCE_KIND,
                native_results={}, support_results=[], matching_diagnostics={}, citations=[], graph_paths=[], graph_path_provenance=[],
                retrieval=receipt, limitations=list(LIMITATIONS), api_calls=0, source_pages_inspected=0,
                source_pages_admitted=0, passage_budget=passage_budget, budget_unit="whole_source_page",
                retrieval_reproduced="Original pipeline on a strict filtered source projection",
                retrieval_superiority_claim_permitted=False, scores_are_entailment=False,
                general_entailment_certified=False, missing_evidence_is_counterevidence=False,
                current_strict_verdict_equivalent=False, query_adaptation=adaptation,
                original_query_contract=deepcopy(ORIGINAL_QUERY_CONTRACT))
    base["original_query_contract"]["marker_policy"] = "Focal opaque demo marker only -> collision-free [REDACT:Rn]; no type, answer, reading or plan hint" if adaptation else "Unmodified public query"
    if adaptation:
        base["original_query_contract"]["demo_marker_compatibility"] = "Marker-only adapted primary; literal native preflight is separately retained"
    envelope = dict(eligible=eligible, pages=[], receipt=receipt, hierarchy_bundle=None)
    if not records["chunks.csv"] or not any(records[name] for name in TABLES[1:]) or not passage_budget or not document_budget:
        base.update(execution_status="BLOCKED_NO_GROUNDED_ORIGINAL_EXTRACTION" if passage_budget and document_budget else "EMPTY_BUDGET",
                    source_projection_counts={name: len(values) for name, values in records.items()})
        return _json(base), envelope
    with TemporaryDirectory(prefix="matryoshka-original-v5-") as temporary:
        root = Path(temporary)
        query_root = root / "query"
        manifest = _parse(native, query_text, query_root)
        if adaptation:
            literal_root = root / "literal_query"
            literal_manifest = _parse(native, case["query"], literal_root)
            try:
                literal = native.query.QueryPackage.load(literal_root, task="redaction")
                control = dict(preflight=native.matcher._preflight("redaction", literal))
            except ValueError as error:
                control = dict(execution_status="BLOCKED_BY_ORIGINAL_QUERY_CONTRACT", error=str(error))
            base["literal_query_control"] = dict(control, parser_mode=literal_manifest.get("parser_mode"),
                                                 task_engine_invoked=False, raw_public_query_unchanged=True)
        resources = native.semantic_resources.load_semantic_resources()
        index = _admission_index(native, root / "admission", records, resources)
        receipt["admission_index_contract"] = "Original CorpusIndex claims profile over five grounded archive tables; no pseudo-view or graph preselection"
        scores, queries = {}, []
        tasks = ["claims", "contradictions"] if case["task"] == "hypothesis" else [case["task"]]
        for task in tasks:
            try:
                package = native.query.QueryPackage.load(query_root, task=task)
            except ValueError as error:
                if "no executable primary target" not in str(error):
                    raise
                continue
            for query in native.matcher.build_retrieval_atom_contract(package, task)["retrieval_text"].tolist():
                if query and query not in queries:
                    queries.append(query)
                    for doc, score in native.retrieval.rank_documents(query, index, document_budget, resources):
                        scores[doc] = max(scores.get(doc, 0.), score)
        documents = sorted(scores, key=lambda doc: (-scores[doc], doc))[:document_budget]
        doc_ranks = {doc: rank for rank, doc in enumerate(documents)}
        covered = {pi for _, witness in records["chunks.csv"] for pi, _ in witness["page_matches"]
                   if witness["native_document_id"] in doc_ranks}
        pages = sorted(covered, key=lambda pi: (doc_ranks[corpus.pages[pi]["document_id"].strip().upper()], corpus.pages[pi]["id"]))[:passage_budget]
        admitted_mask = np.zeros(len(mask), dtype=bool)
        admitted_mask[pages] = True
        admitted = _project(grounded, admitted_mask, corpus)
        receipt.update(search_queries=[dict(id="native_" + str(i), kind="native_atom", query=query) for i, query in enumerate(queries, 1)],
                       document_order=[doc for doc in documents if any(corpus.pages[pi]["document_id"].strip().upper() == doc for pi in pages)],
                       eligible_documents=len(index.doc_ids), documents_admitted=len({corpus.pages[pi]["document_id"] for pi in pages}), pages_admitted=len(pages))
        envelope["pages"] = pages
        if not pages:
            base.update(execution_status="BLOCKED_BY_ORIGINAL_QUERY_CONTRACT", query_package=manifest)
            return _json(base), envelope
        project = root / "execution"
        extraction = _materialize(project, admitted)
        counts = native.corpus.CorpusIndex.build(extraction, task="all", semantic_resources=resources,
                                                semantic_resource_fingerprint=resources.fingerprint)
        feature_counts = {name: sum(len(values) for values in getattr(counts, name + "_by_doc").values())
                          for name in ("propositions", "values", "sentences", "provenance")}
        native_tables = {name: dict(rows=len(_native_frame(extraction / name)), sha256=sha(extraction / name))
                         for name in native.corpus.ALL_SOURCE_TABLES if (extraction / name).is_file()}
        if graph:
            graph_module = sys.modules["common.retrieval_graph"]
            graph_module.build_retrieval_graph(project)
            receipt["original_graph_augmentation"] = True
        results, diagnostics, paths, atoms = _execute(native, case, query_root, project, document_budget=document_budget, graph=graph)
        citations, bindings, paragraphs = _bindings(admitted, corpus, native)
        supports = [dict(task=task, native_evaluation_row=i, native_semantic_status=row.get("semantic_status", ""),
                         **_reference(row, citations, bindings))
                    for task, result in results.items() for i, row in enumerate(result["evaluation"])]
        original_graph, path_sources = _original_graph(project, results, paths, paragraphs) if graph else ({}, [])
        for artifacts in diagnostics.values():
            for artifact in artifacts.values():
                artifact["source_bindings"] = [_reference(row, citations, bindings) for row in artifact["rows"]]
        executed = [task for task, result in results.items() if result["execution_status"] == "EXECUTED"]
        base.update(execution_status="EXECUTED" if len(executed) == len(tasks) else "PARTIAL_OR_BLOCKED_NATIVE_EXECUTION",
                    native_results=results, matching_diagnostics=diagnostics, support_results=supports,
                    citations=list(citations.values()), graph_paths=paths, graph_path_provenance=path_sources,
                    original_graph=original_graph,
                    retrieval_atoms=atoms, native_feature_counts=feature_counts,
                    native_source_tables=native_tables,
                    source_projection_counts={name: len(values) for name, values in admitted.items()},
                    source_projection_rows=[dict(witness, native_table=name, native_local_id=row["local_id"])
                                            for name, values in admitted.items() for row, witness in values],
                    source_pages_inspected=len(pages), source_pages_admitted=len(pages),
                    query_package={key: manifest.get(key) for key in ("schema_version", "parser_mode", "query_sha256", "query_parse_sha256", "table_sha256", "frozen_parse_contract")},
                    lineage=_lineage_v5(native, executed), elapsed_seconds=time.perf_counter() - started,
                    native_document_id_map={corpus.pages[pi]["document_id"].strip().upper(): corpus.pages[pi]["document_id"] for pi in pages})
    return _json(base), envelope
