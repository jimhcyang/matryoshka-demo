"""Immutable references to existing full graph-browser exports; no data copies."""
from pathlib import Path
import re

from .exploration_v2 import verified_hash
from .io import digest, load, save, sha


VERSION = "full-browser-asset-binding/4"
MANIFEST = "data/full_graph_bindings_v4.json"


def _references(value, stems):
    if isinstance(value, dict):
        for key, child in value.items():
            yield from _references(key, stems)
            yield from _references(child, stems)
    elif isinstance(value, list):
        for child in value:
            yield from _references(child, stems)
    elif isinstance(value, str) and Path(value).name == value and re.search(r"\.json(?:\.gz)?$", value):
        if any(value == stem + ".json" or value.startswith(stem + ".") for stem in stems):
            yield value


def bind(root, *, execute=False):
    root = Path(root).resolve()
    workspace = root.parent
    native = load(root / "data/bindings.json")
    base = workspace / "src/demo/iran_site_visit/web/data"
    corpora = {}
    for corpus in ("cib", "iran", "vietnam"):
        study = native["corpora"][corpus]
        if corpus == "cib":
            prefix = "cib_refresh_" + study["graph_id"].removeprefix("graph_") + "_" + study["hierarchy_id"].removeprefix("hierarchy_")
            names = (prefix + "_comparison.json", prefix + "_search.json")
        else:
            names = (corpus + "_comparison.json", corpus + "_entity_search.json")
        comparison, search = (load(base / name) for name in names)
        metadata = comparison.get("corpus_metadata", {})
        if corpus != "cib" and metadata.get("corpus_id") != corpus:
            raise ValueError("Full graph catalog belongs to another corpus")
        if corpus == "cib" and (comparison.get("graph_run_id") != study["graph_id"] or comparison.get("hierarchy_run_id") != study["hierarchy_id"]):
            raise ValueError("Full CIB catalog differs from the pinned graph")
        stems = tuple(Path(name).stem for name in names)
        filenames = set(names) | set(_references(comparison, stems)) | set(_references(search, stems))
        for name in list(filenames):
            if "{" in name or "}" in name:
                pattern = re.sub(r"\{[^{}]+\}", "*", name)
                expanded = {path.name for path in base.glob(pattern)}
                if not expanded:
                    raise ValueError("No shards match the declared catalog template: " + name)
                filenames.remove(name)
                filenames.update(expanded)
        for stem in stems:
            filenames.update(path.name for path in base.glob(stem + ".*.json*"))
        assets = {}
        for name in sorted(filenames):
            path = base / name
            if not path.is_file() or Path(name).name != name:
                raise ValueError("Missing full graph shard: " + name)
            assets[name] = dict(path=str(path.relative_to(workspace)), sha256=sha(path), bytes=path.stat().st_size)
        layout_matches = comparison.get("hierarchy_run_id") == study["hierarchy_id"]
        corpora[corpus] = dict(corpus=corpus, name=metadata.get("name", "Central Intelligence Bulletins"),
            comparison=names[0], search=names[1], assets=assets,
            aliases={corpus + "_comparison.json": names[0], corpus + "_entity_search.json": names[1]},
            graph_id=comparison.get("graph_run_id"), hierarchy_id=comparison.get("hierarchy_run_id"),
            study_graph_id=study["graph_id"], study_hierarchy_id=study["hierarchy_id"], layout_matches_study=layout_matches,
            scope=("Full paired-release browser export; earlier/later visibility is not the workbench's historical evidence filter."
                if corpus == "cib" else "Full classification-projection browser export; CONFIDENTIAL and SECRET views are separate from the workbench evidence-only view."),
            layout_note=("Same fixed hierarchy as the saved study." if layout_matches else
                "This full-corpus browser retains its separately versioned overview hierarchy. Saved study paths use the study hierarchy; the layouts are not asserted identical."),
            source_export_sha256=assets[names[0]]["sha256"],
            copied_data_bytes=0, existing_asset_bytes=sum(a["bytes"] for a in assets.values()))
    manifest = dict(version=VERSION, corpora=corpora, study_binding_sha256=native["sha256"],
        upstream_modified=False, benchmark_inputs_changed=False)
    manifest["sha256"] = digest(manifest)
    target = root / MANIFEST
    if execute:
        if target.exists() and load(target) != manifest:
            raise ValueError("Full graph asset binding changed; do not overwrite the previous binding")
        if not target.exists():
            save(target, manifest)
    return manifest


def bound(root):
    root = Path(root).resolve()
    value = load(root / MANIFEST)
    if value.get("version") != VERSION or value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"}):
        raise ValueError("Full graph asset manifest changed")
    study = load(root / "data/bindings.json")
    if study.get("sha256") != digest({k: v for k, v in study.items() if k != "sha256"}):
        raise ValueError("Study binding integrity changed")
    if value["study_binding_sha256"] != study["sha256"]:
        raise ValueError("Full graph and study binding no longer agree")
    return value


def catalog(root):
    value = bound(root)
    return dict(version=VERSION, corpora={name: {k: v for k, v in item.items() if k not in {"assets", "aliases"}}
        for name, item in value["corpora"].items()}, data_copied=False, benchmark_inputs_changed=False)


def asset(root, corpus, filename):
    root = Path(root).resolve()
    if corpus not in {"cib", "iran", "vietnam"} or Path(filename).name != filename:
        raise ValueError("Unbound full graph asset")
    item = bound(root)["corpora"][corpus]
    name = item["aliases"].get(filename, filename)
    reference = item["assets"].get(name)
    if not reference:
        raise ValueError("Full graph asset is not allowlisted")
    base = (root.parent / "src/demo/iran_site_visit/web/data").resolve()
    target = (root.parent / reference["path"]).resolve()
    if not target.is_relative_to(base) or not target.is_file():
        raise ValueError("Unbound full graph source path")
    stat = target.stat()
    if stat.st_size != reference["bytes"] or verified_hash(str(target), stat.st_mtime_ns,
            stat.st_size, stat.st_ctime_ns, stat.st_ino) != reference["sha256"]:
        raise ValueError("Full graph asset changed")
    return target, base
