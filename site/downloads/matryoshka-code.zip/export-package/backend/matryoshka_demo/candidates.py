"""Source-owned phrases; separate evidence and exploratory ranks per reading."""
from collections import defaultdict, Counter
import re

import numpy as np

from .contracts import public_case, MASK
from .corpus import BM25, locate, ordered, words
from .io import digest
from .tasks import parser
from .retrieval import candidate_route


def proposal_spans(text, parse):
    doc = parse(text)
    spans = {}
    for chunk in doc.noun_chunks:
        root = chunk.root
        if root.pos_ == "PRON" or root.lower_ in {"thing", "something", "which", "who", "that"}:
            continue
        # Complete titles/proper-name compounds stay together. Following
        # noun complements are extended only without an intervening clause.
        end = chunk.end
        for prep in root.children:
            if prep.dep_ == "prep":
                tail = list(prep.subtree)
                if tail and not any(t.pos_ in {"VERB", "AUX"} for t in tail):
                    end = max(end, max(t.i for t in tail) + 1)
        part = doc[chunk.start:end]
        if len(part) <= 18:
            spans[(part.start_char, part.end_char)] = dict(kind="nominal", head=root,
                owner=None, text=part.text, start=part.start_char, end=part.end_char, edited=part.text)
    for token in doc:
        if token.pos_ == "NUM":
            spans[(token.idx, token.idx+len(token))] = dict(kind="quantity", head=token,
                owner=token.head, text=token.text, edited=token.text, start=token.idx, end=token.idx+len(token))
        if token.pos_ != "ADJ" and not (token.pos_ == "VERB" and token.tag_ in {"VBN", "VBG"}):
            continue
        if token.pos_ == "VERB" and token.dep_ not in {"amod", "acomp", "acl"} and not any(c.dep_ == "auxpass" for c in token.children):
            continue
        selected = [token, *[c for c in token.children if c.dep_ in {"advmod", "neg"}]]
        if token.dep_ == "amod":
            owner = token.head
        else:
            governor = token.head if token.dep_ in {"acomp", "attr"} else token
            owner = next((c for c in governor.children if c.dep_ in {"nsubj", "nsubjpass"}), None)
            # Copular adjectives inherit clause negation from "be". Without
            # this, "the minister is not ambitious" became "ambitious".
            if governor is not token:
                selected.extend(c for c in governor.children if c.dep_ == "neg")
        a, b = min(t.i for t in selected), max(t.i for t in selected) + 1
        part = doc[a:b]
        complements = [c for c in token.children if c.dep_ in {"prep", "prt", "xcomp", "ccomp", "dobj"}]
        if token.pos_ == "ADJ":
            if token.dep_ in {"acomp", "attr"} and token.head.lemma_ == "be":
                complements.extend(c for c in token.head.children if c.dep_ == "prep" and c.i == token.i+1)
            for child in complements:
                tail = list(child.subtree)
                if child.dep_ == "prep" and not any(t.pos_ in {"VERB", "AUX"} for t in tail): selected.extend(tail)
            a, b = min(t.i for t in selected), max(t.i for t in selected)+1
            part = doc[a:b]
        spans[(part.start_char, part.end_char)] = dict(kind="modifier", head=token, owner=owner,
            text=part.text, start=part.start_char, end=part.end_char,
            edited=" ".join(t.text for t in sorted(set(selected), key=lambda t:t.i)),
            clausal_complement=bool(token.pos_ == "VERB" and complements),
            prepositional_complement=bool(token.pos_ == "ADJ" and complements))
    return doc, list(spans.values())


def visible_carrier(case, parse):
    q = case["query"]; at = q.index(case["focal_marker"]); right = at + len(case["focal_marker"])
    tokens = parse(q[right:])
    return next((t.lemma_.casefold() for t in tokens if t.pos_ == "NOUN"),
                next((t.lemma_.casefold() for t in tokens if t.pos_ == "PROPN"), None))


def fit(case, fill, form, parse, *, source_kind=None):
    q = case["query"]; marker = case["focal_marker"]; at = q.index(marker)
    right = q[at + len(marker):]; left = q[:at]
    if form in {"clause","verbal","adjunct","unknown"}:
        return False  # These constructors are not implemented in this prototype.
    # Source POS/constituency is already available. Re-parsing thousands of
    # isolated phrases both wastes time and can mis-tag participles as past
    # tense. Unattested external calls still receive their own local parse.
    doc = parse(fill) if source_kind is None else None
    if not fill.strip() or MASK.search(fill):
        return False
    if form in {"nominal", "possessive", "member_example"} and (source_kind is not None and source_kind != "nominal"
            or doc is not None and not any(t.pos_ in {"NOUN", "PROPN"} for t in doc)):
        return False
    if form == "modifier" and source_kind != "modifier" and (doc is None or not any(t.pos_ == "ADJ" or t.tag_ in {"VBN", "VBG"} for t in doc)):
        return False
    if form == "possessive" and not re.search(r"(?:['\u2019]s|s['\u2019])$", fill):
        return False
    if re.search(r"\b(?:the|a|an)\s*$", left, re.I) and re.match(r"^(?:the|a|an|all)\b", fill, re.I):
        return False
    if fill.split()[-1].casefold() in {"the", "a", "an", "of", "its", "their", "and", "to"}:
        return False
    if re.match(re.escape(fill.strip()) + r"\b", right.lstrip(), re.I):
        return False
    if left.rstrip().endswith(",") and right.lstrip().startswith(",") and doc is not None and len(doc) == 1 and doc[0].pos_ == "NOUN":
        return False
    if re.search(r"['\u2019]s\s*[\"]?\s*$", left) and form == "nominal" and doc is not None and doc[0].pos_ in {"ADP", "SCONJ"}:
        return False
    return True


def focal_requirements(case, parse):
    text = case["query"]; at = text.index(case["focal_marker"]); end = at + len(case["focal_marker"])
    left, right = text[:at], text[end:]
    # These are visible grammatical/ontological requirements, not names or
    # invented roles. A personal anaphor rules out a country as possessor.
    person = bool(re.search(r"^\s*initiative\s*;\s*he\b", right, re.I)
                  or re.search(r"\b(?:politicians|officers|officials|leaders|people)\s*$", left, re.I))
    parsed = parse(MASK.sub(" ", text))
    places = defaultdict(int)
    for ent in parsed.ents:
        if ent.label_ in {"GPE", "LOC"}: places[ent.text.casefold()] += 1
    primary = {p for p, n in places.items() if n == max(places.values())} if places else set()
    opposed_titles = {m.group(1).casefold() for m in re.finditer(
        r"\b(?:oust|overthrow|replace|remove|oppose)\s+(?:the\s+)?(president|premier|minister|commander)\b", right, re.I)}
    opposed_names = set()
    for ent in parsed.ents:
        if ent.label_ == "PERSON" and ent.start > 0 and parsed[ent.start-1].lemma_.casefold() in opposed_titles:
            opposed_names.add(ent.text.casefold())
    return dict(person=person, places=primary, opposed_names=opposed_names)


def paragraph_context(text, position):
    bounds = [0] + [m.end() for m in re.finditer(r"\n\s*\n", text)] + [len(text)]
    index = next((i for i in range(len(bounds)-1) if bounds[i] <= position < bounds[i+1]), 0)
    return text[bounds[max(index-1, 0)]:bounds[min(index+2, len(bounds)-1)]]


def owned_roles(proposal, doc):
    tokens = [t for t in doc if proposal["start"] <= t.idx < proposal["end"]]
    tokens.extend(t for child in proposal["head"].children if child.dep_ == "appos" for t in child.subtree)
    return {t.lemma_.casefold() for t in tokens if t.pos_ in {"NOUN", "ADJ"} and not t.ent_type_}


def construct(case, plan, reading, *, passage_budget=40, dossier_budget=3, source_roles=False):
    case = public_case(case); eligible = reading["eligible"]; c = eligible.corpus; parse = parser()
    query = case["query"]; visible = MASK.sub(" ", query)
    focus = visible_carrier(case, parse)
    requirements = focal_requirements(case, parse)
    if source_roles:
        from .roles import common_words, compare as compare_roles, binding as role_binding
        query_roles = common_words(parse(visible))
    ranked_pages = sorted(reading["pages"], key=lambda pi: reading["page_ranks"].get(pi, 10**9))[:passage_budget]
    inventory = []
    for pi in ranked_pages:
        page = c.pages[pi]; doc, spans = proposal_spans(page["text"], parse)
        for p in spans:
            sentence = p["head"].sent
            quote = page["text"][sentence.start_char:sentence.end_char]
            if MASK.search(quote):
                continue
            node = None; person = False; nonperson = False
            for oi in c.occurrences_by_page.get(pi, []):
                occurrence = c.occurrences[oi]
                if occurrence["source_type"] != "entities": continue
                name = occurrence["label"]
                at = re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)", p["text"], re.I)
                head_at = p["head"].idx - p["start"]
                if at and at.start() <= head_at < at.end():
                    if occurrence["entity_type"] == "Person": node = occurrence["node_id"]; person = True
                    elif occurrence["entity_type"] in {"Country", "Location", "Organization", "Government", "Document"}: nonperson = True
            if p["kind"] == "nominal" and any(e.label_ == "PERSON" and e.start_char <= p["head"].idx < e.end_char for e in doc.ents):
                person = True
            if nonperson: person = False
            proof = dict(id="source_" + digest([page["id"], sentence.start_char, sentence.end_char])[:20],
                document_id=page["document_id"], canonical_page_id=page["id"], date=page["date"],
                start=sentence.start_char, end=sentence.end_char, text=quote,
                page_sha256=page["source_sha256"], earlier_page=page["earlier_page"])
            inventory.append(dict(text=p["edited"], source_wording=p["text"], kind=p["kind"], node_id=node, person=person,
                owner=p["owner"].lemma_.casefold() if p["owner"] is not None else None,
                head=p["head"].lemma_.casefold(), source=proof, span=[p["start"], p["end"]],
                source_page_index=pi, topic_context=paragraph_context(page["text"], p["start"]),
                clausal_complement=p.get("clausal_complement", False),
                prepositional_complement=p.get("prepositional_complement", False),
                source_roles=owned_roles(p, doc) if source_roles else set()))
    # Local BM25 on the exact shared sentence population, not route count or
    # number of generated candidate variants, supplies passage relevance.
    quotes = {p["source"]["id"]: p["source"] for p in inventory}
    quote_ids = sorted(quotes)
    index = BM25([quotes[k]["text"] for k in quote_ids]); mask = np.ones(len(quote_ids), dtype=bool)
    scores = index.score(visible, mask)
    qrank = {quote_ids[i]: r for r, i in enumerate(ordered(scores, quote_ids), 1)}
    outputs = []; audits = []
    for r in plan["slot_readings"]:
        proposals = []; rejected = Counter()
        for p in inventory:
            text = p["text"]; form = r["form"]; added = ""
            if form == "modifier" and p["kind"] != "modifier":
                continue
            if form == "modifier" and p["clausal_complement"]:
                rejected["incomplete_verbal_complement"] += 1
                continue
            if form == "modifier" and p["prepositional_complement"] and re.search(r"\b(?:a|an|the)\s*$", query[:query.index(case["focal_marker"])], re.I):
                continue
            if form == "quantity" and p["kind"] != "quantity":
                continue
            if form in {"nominal", "possessive", "member_example"} and p["kind"] != "nominal":
                continue
            if requirements["person"] and not p["person"]:
                rejected["person_requirement_not_met"] += 1
                continue
            if p["person"] and any(re.search(r"(?<!\w)"+re.escape(name)+r"(?!\w)", text, re.I) for name in requirements["opposed_names"]):
                continue
            if form in {"adjunct","clause","verbal","unknown"}:
                # Never shove arbitrary entities or adjectives into a clause
                # reading. Unsupported construction types remain empty.
                continue
            if form == "possessive":
                text = text.rstrip(" ,.")
                if not text.endswith(("'s", "\u2019s")):
                    text += "'s"; added = "'s"
            if form in {"possessive", "member_example"}:
                text = re.sub(r"^(?:both|neither|either)\s+", "", text, flags=re.I)
            if form == "member_example":
                text = "like " + text; added = "like"
            if not fit(case, text, form, parse, source_kind=p["kind"]):
                rejected["boundary_grammar_incompatible"] += 1
                continue
            repeat = bool(p["node_id"] and re.search(re.escape(p["text"]), visible, re.I))
            local_property = bool(form in {"modifier", "quantity"} and p["owner"] and p["owner"] == focus)
            source_rank = qrank.get(p["source"]["id"], len(quote_ids) + 1)
            ni = c.node_index.get(p["node_id"])
            graph_rank = reading["node_ranks"].get(ni)
            relevance = 1 / (60 + source_rank) + (1 / (60 + graph_rank) if graph_rank else 0)
            support = "LOCAL_PROPERTY_ATTESTED" if local_property else "SOURCE_WORDING_CONTEXT_ONLY"
            topic = sum(bool(re.search(r"\b" + re.escape(place) + r"\b", p["topic_context"], re.I)) for place in requirements["places"])
            role = compare_roles(query_roles, p["source_roles"]) if source_roles and p["person"] else dict(matched=False)
            proposals.append(dict(id="fill_" + digest([text.casefold(), p["node_id"], p["source"]["id"]])[:20],
                fill=text, sources=[p["source"]], source_span=p["span"], source_wording=p["source_wording"],
                added_function_words=added, node_id=p["node_id"], support=support,
                source_owner=p["owner"], expected_carrier=focus,
                evidence_key=(not local_property, -topic, not role["matched"], repeat, -relevance), context_key=(not local_property, -topic, not role["matched"], repeat, -relevance),
                ranking=dict(passage_rank=source_rank, node_rank=graph_rank, rrf=relevance,
                    visible_repetition=repeat, local_property_match=local_property, primary_place_matches=topic,
                    source_role_match=role,
                    source_role_matched=role["matched"],
                    person_requirement=requirements["person"], calibrated_probability=False),
                interpretation="Literal source property" if local_property else
                    "Source-attested phrase/person; this does not establish the missing action or relation"))
        # Dossiers are candidate-specific and use the same eligible corpus for
        # every route. More mentions never add votes. Keep original quotes.
        for item in proposals:
            if not item["node_id"]:
                continue
            seen = {s["id"] for s in item["sources"]}
            occurrences = [c.occurrences[i] for i in c.occurrences_by_node[item["node_id"]]
                           if eligible.page_mask[c.occurrences[i]["page_index"]]]
            occurrences.sort(key=lambda o: (reading["page_ranks"].get(o["page_index"], 10**9), c.units[o["unit_index"]]["id"]))
            for occurrence in occurrences:
                source = eligible.citation(occurrence["unit_index"])
                if source["id"] not in seen and len(item["sources"]) < dossier_budget:
                    item["sources"].append(source); seen.add(source["id"])
        def unique(items, key):
            chosen = []; fills = set(); identities = set()
            for item in sorted(items, key=lambda p: (p[key], len(p["fill"].split()), p["id"])):
                normalized = " ".join(words(item["fill"]))
                if normalized in fills or item["node_id"] and item["node_id"] in identities:
                    continue
                fills.add(normalized)
                if item["node_id"]: identities.add(item["node_id"])
                value = {k: v for k, v in item.items() if k not in {"evidence_key", "context_key"}}
                value["discovery_route"] = candidate_route(reading, item["node_id"])
                value["rank"] = len(chosen) + 1; chosen.append(value)
                if len(chosen) == 5: break
            return chosen
        evidence = unique([p for p in proposals if p["support"] == "LOCAL_PROPERTY_ATTESTED"], "evidence_key")
        context = unique(proposals, "context_key")
        outputs.append(dict(reading=r, evidence_candidates=evidence, exploratory_candidates=context,
                            generated_proposals=len(proposals), rejection_counts=dict(rejected)))
        audits.append(dict(reading=r, proposals=[{k:v for k,v in p.items() if k not in {"evidence_key", "context_key"}}
            for p in sorted(proposals,key=lambda p:(p["context_key"],len(p["fill"].split()),p["id"]))],
            rejection_counts=dict(rejected)))
    return dict(task="redaction", readings=outputs, retrieval=reading["receipt"],
        construction=dict(passage_budget=passage_budget, source_pages_inspected=len(ranked_pages),
            all_admitted_pages=len(reading["pages"]), source_sentence_count=len(quotes), proposals=len(inventory),
            dossier_budget=dossier_budget, dossier_mentions_are_not_support=True),
        source_role_control=role_binding() if source_roles else None,
        _candidate_audit=dict(version="source-owned-candidate-pool/1", readings=audits,
            inspected_page_ids=[c.pages[pi]["id"] for pi in ranked_pages], keys_read=False, grades_read=False),
        api_calls=0, keys_read=False, grades_read=False,
        limitation="Identity/role suggestions are exploratory unless their target contribution has a source-bound match; grammar checks are not a guarantee")
