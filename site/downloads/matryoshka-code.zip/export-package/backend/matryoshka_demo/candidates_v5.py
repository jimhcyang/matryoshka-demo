"""Source-owned construction with a source-preserving insertion-boundary adapter."""
from copy import deepcopy
import re

from .io import digest


ADAPTER_VERSION = "visible-possessive-boundary-adapter/5.1"


def adapt(case, result):
    """Remove only an explicitly constructor-added duplicate genitive clitic."""
    output = deepcopy(result)
    right = case["query"].split(case["focal_marker"])[1]
    visible = re.match(r"['\u2019]s\b", right, re.I)
    if not visible:
        return output
    audit = output.get("_candidate_audit")
    if not audit:
        raise ValueError("FULL_POOL_AUDIT_REQUIRED")
    edits = []
    for raw, view in zip(audit["readings"], output["readings"]):
        if raw["reading"] != view["reading"]:
            raise ValueError("Candidate reading changed")
        if raw["reading"].get("form") != "possessive":
            continue
        originals = {}
        for candidate in raw["proposals"]:
            originals.setdefault(candidate["id"], []).append(candidate)
        for candidate in view.get("candidates", []):
            if not any(all(candidate.get(k) == p.get(k) for k in
                    ("id", "fill", "sources", "source_span", "source_wording"))
                    for p in originals.get(candidate["id"], [])):
                raise ValueError("View occurrence changed from audited pool")

        def transform(candidate, *, record):
            added = candidate.get("added_function_words")
            if not isinstance(added, str) or added.casefold() not in {"'s", "\u2019s"}:
                return
            fill = candidate["fill"]
            if not fill.endswith(added) or not fill[:-len(added)].strip():
                return
            new_fill = fill[:-len(added)]
            edit = dict(kind="VISIBLE_RIGHT_POSSESSIVE_SHARED", candidate_id=candidate["id"],
                source_occurrence_sha256=digest([candidate.get("sources"), candidate.get("source_span"), candidate.get("source_wording")]),
                original_fill=fill, fill=new_fill, removed_constructor_added=added,
                visible_query_clitic=visible.group(), source_quote_unchanged=True,
                source_span_unchanged=True, native_rank_unchanged=True,
                source_words_removed=False, factual_support_implied=False)
            candidate["fill"] = new_fill
            candidate["added_function_words"] = ""
            candidate.setdefault("insertion_edits", []).append(deepcopy(edit))
            if record:
                edits.append(edit)
        for candidate in raw["proposals"]:
            transform(candidate, record=True)
        for key in ("candidates", "exploratory_candidates", "evidence_candidates"):
            for candidate in view.get(key, []):
                transform(candidate, record=False)
    output["candidate_boundary_v5"] = dict(version=ADAPTER_VERSION, edits=edits,
        full_pool_transformed=True, source_proofs_modified=False, ranks_modified=False,
        reading_forms_modified=False, candidate_ids_preserved=True)
    return output


from .candidates_v3 import construct as _construct, finalize_untyped, RANK_TIERS

BASE_VERSION = "source-owned-candidates/3.2"
CONSTRUCTOR_VERSION = "source-owned-candidates/5.0"
VERSION = CONSTRUCTOR_VERSION


def construct(case, plan, retrieval, *, passage_budget=100, top_k=5):
    value = _construct(case, plan, retrieval, passage_budget=passage_budget, top_k=top_k)
    value = adapt(case, value)
    value["base_constructor_version"] = BASE_VERSION
    value["constructor_version"] = CONSTRUCTOR_VERSION
    value["construction_policy"] = "Original source-owned pool and priority ordering; only recorded duplicated insertion clitics are removed"
    return value

