"""Read-only assessment artifact replay for reporting, not native inference.

verify_saved(api_root, packet, result) verifies the existing v2 paid artifacts
under the current, explicitly recorded assessment contract. Callers must first
reconstruct packet from frozen native results; this module does not authenticate
an arbitrary supplied packet. No API call, reservation, cache repair or artifact
rewrite is performed. The returned v2.3 audit is separate from old v2 results.

Cache/request keys hash the API version/endpoint/stage/wire envelope, whereas a
usage receipt's request_sha256 hashes ONLY the wire. Raw SDK schema_ is accepted
as a serialization alias for schema, never as a different schema. Charges use
the same workspace RATES as api_v2, not a claimed provider invoice or current
ledger total. These checks establish local artifact consistency, not provider
authenticity against coordinated rewriting of every local record.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import re

import jsonschema

from . import api_v2 as api, assessment_v2 as assessment
from .contracts import MASK
from .io import digest


VERSION = "assessment-artifact-replay/2.3"
STAGE = "post_run_assessment"
MODEL = "gpt-6.1-sol"
ENDPOINT = "https://api.openai.com/v1"
MAX_OUTPUT_TOKENS = 6000


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _path(root, group, relative):
    _require(isinstance(relative, str) and bool(relative), "Invalid artifact path")
    ref = Path(relative)
    _require(not ref.is_absolute() and ".." not in ref.parts, "Artifact path traversal")
    path = (root / ref).resolve()
    _require(path.is_relative_to(root / group) and path.suffix == ".json", "Unbound artifact path")
    return path


def _read(root, group, relative, hashes):
    path = _path(root, group, relative)
    try:
        data = path.read_bytes()
        value = json.loads(data)
    except (OSError, ValueError) as error:
        raise ValueError("Missing or invalid " + group + " artifact") from error
    hashes[str(path.relative_to(root))] = hashlib.sha256(data).hexdigest()
    return value


def _same(a, b):
    return digest(a) == digest(b)


def _validate_grades(batch, output):
    try:
        jsonschema.validate(output, assessment.SCHEMA)
    except jsonschema.ValidationError as error:
        raise ValueError("Invalid assessment output schema") from error
    expected = {item["id"]: item for item in batch["items"]}
    grades = output["grades"]
    _require(len(grades) == len(expected) and {g["id"] for g in grades} == set(expected),
             "Assessment did not grade the exact saved item set")
    for grade in grades:
        sources = expected[grade["id"]]["sources"]
        ids = [s["id"] for s in sources]
        _require(len(ids) == len(set(ids)), "Duplicate assessment source ID")
        source_map = {s["id"]: s for s in sources}
        cited = grade["cited_source_ids"]
        _require(set(cited) <= set(source_map), "Invented assessment source ID")
        if grade["evidence_support"] in {"direct", "partial", "context", "contradicted"}:
            _require(bool(cited), "Positive source assessment has no cited source")
        _require(all(MASK.sub(" ", source_map[s]["text"]).strip() for s in cited),
                 "Assessment source evidence is empty or opaque")
        if batch["task"] != "redaction":
            _require(grade["answer_match"] == "not_applicable", "Invalid complete-claim answer_match")


def _validate_response(raw, wire, output):
    _require(raw["status"] == "completed" and raw.get("error") is None
             and raw.get("incomplete_details") is None, "Raw response did not complete successfully")
    for field in ("model", "instructions", "max_output_tokens", "store"):
        _require(_same(raw[field], wire[field]), "Raw response request echo differs: " + field)
    _require(raw["reasoning"]["effort"] == wire["reasoning"]["effort"], "Raw response reasoning differs")
    actual, expected = raw["text"]["format"], wire["text"]["format"]
    for field in ("type", "name", "strict"):
        _require(_same(actual[field], expected[field]), "Raw response format differs: " + field)
    aliases = [actual[k] for k in ("schema", "schema_") if k in actual]
    _require(bool(aliases) and all(_same(s, expected["schema"]) for s in aliases),
             "Raw response schema differs")
    texts = []
    for item in raw["output"]:
        if item["type"] != "message":
            continue
        _require(item["role"] == "assistant" and item["status"] == "completed", "Invalid raw response message")
        _require(all(p["type"] != "refusal" for p in item["content"]), "Raw response contains a refusal")
        texts.extend(p["text"] for p in item["content"] if p["type"] == "output_text")
    _require(len(texts) == 1, "Exactly one structured raw response is required")
    _require(_same(json.loads(texts[0]), output), "Cached output differs from raw paid response")


def _validate_receipt(receipt, raw, wire):
    _require(receipt["status"] == "PASS", "Assessment has no successful usage receipt")
    _require(receipt["request_sha256"] == digest(wire), "Usage receipt wire digest differs")
    _require(receipt["model"] == wire["model"], "Usage receipt model differs")
    _require(isinstance(raw["id"], str) and bool(raw["id"]) and receipt["response_id"] == raw["id"],
             "Usage receipt response ID differs")
    usage = raw["usage"]
    _require(_same(receipt["usage"], usage), "Usage receipt differs from raw response")
    for field in ("input_tokens", "output_tokens"):
        _require(type(usage[field]) is int and usage[field] >= 0, "Invalid recorded token usage")
    if "total_tokens" in usage:
        _require(type(usage["total_tokens"]) is int
                 and usage["total_tokens"] == usage["input_tokens"] + usage["output_tokens"],
                 "Invalid recorded total token usage")
    rates = api.RATES[MODEL]
    _require(_same(receipt["rates"], list(rates)), "Usage receipt rates differ")
    amount = (usage["input_tokens"] * rates[0] + usage["output_tokens"] * rates[1]) / 1e6
    charge, cap = receipt["charged_or_reserved_usd"], receipt["cap_usd"]
    _require(type(charge) in (int, float) and math.isfinite(charge) and charge >= 0
             and math.isclose(charge, amount, rel_tol=1e-12, abs_tol=1e-12), "Usage receipt charge differs")
    _require(type(cap) in (int, float) and math.isfinite(cap) and 0 < cap <= 25 and charge <= cap,
             "Usage receipt cap differs")


def _verify(root, packet, result):
    _require(packet["task"] in {"redaction", "hypothesis", "reconstruction"}, "Invalid assessment task")
    items = packet["items"]
    _require(isinstance(items, list), "Assessment items must be a list")
    ids = [item["id"] for item in items]
    _require(all(isinstance(i, str) and i for i in ids) and len(ids) == len(set(ids)), "Duplicate or invalid packet item ID")
    _require(result["version"] == "method-blinded-assessment/2" and result["answer_aware"] is True
             and result["used_for_inference"] is False and result["independent_human_validation"] is False,
             "Invalid saved assessment contract")
    _require(result["packet_sha256"] == digest(packet), "Assessment packet changed")
    _require(isinstance(result["receipts"], list), "Assessment receipts must be a list")
    hashes, seen_keys, grades, at = {}, set(), [], 0
    for ref in result["receipts"]:
        key = ref["request_sha256"]
        _require(isinstance(key, str) and re.fullmatch(r"[0-9a-f]{64}", key), "Invalid assessment request key")
        _require(key not in seen_keys, "Duplicate assessment receipt")
        seen_keys.add(key)
        cached = _read(root, "cache", "cache/" + key + ".json", hashes)
        sent = json.loads(cached["request"]["input"][0]["content"][0]["text"])
        _require(isinstance(sent["items"], list) and bool(sent["items"]), "Empty or invalid paid batch")
        batch = dict(packet, items=items[at:at + len(sent["items"])])
        _require(_same(sent, batch), "Paid batch differs from the exact ordered packet")
        wire = api.request(STAGE, batch, assessment.PROMPT, assessment.SCHEMA,
                           model=MODEL, max_output_tokens=MAX_OUTPUT_TOKENS)
        _require(cached["version"] == api.VERSION and _same(cached["request"], wire), "Assessment wire contract differs")
        expected_key = digest(dict(version=api.VERSION, endpoint=ENDPOINT, stage=STAGE, request=wire))
        _require(key == expected_key, "Assessment envelope key differs")
        request = _read(root, "requests", "requests/" + key + ".json", hashes)
        _require(_same(request, dict(version=api.VERSION, stage=STAGE, request=wire, request_sha256=key)),
                 "Saved paid request differs")
        _require(cached["receipt_path"] == ref["receipt"], "Cache and assessment receipt paths differ")
        receipt = _read(root, "receipts", ref["receipt"], hashes)
        raw = _read(root, "responses", "responses/" + key + ".json", hashes)
        output = cached["output"]
        _require(cached["output_sha256"] == digest(output), "Assessment cached output hash differs")
        _validate_response(raw, wire, output)
        _validate_receipt(receipt, raw, wire)
        _validate_grades(batch, output)
        grades.extend(output["grades"])
        at += len(batch["items"])
    _require(at == len(items) and _same(grades, result["grades"]), "Saved assessment differs from raw paid grades")
    return dict(version=VERSION, status="VERIFIED_LOCAL_ARTIFACT_CONSISTENCY", packet_sha256=digest(packet),
        batches=len(seen_keys), grades=len(grades), artifact_sha256=hashes,
        contract=dict(api_version=api.VERSION, assessment_version=result["version"], stage=STAGE,
                      model=MODEL, endpoint=ENDPOINT, max_output_tokens=MAX_OUTPUT_TOKENS,
                      prompt_sha256=digest(assessment.PROMPT), schema_sha256=digest(assessment.SCHEMA),
                      rates=list(api.RATES[MODEL])),
        provider_authenticity_certified=False, api_calls=0, artifacts_modified=False)


def verify_saved(api_root, packet, result):
    """Read and verify archived v2 artifacts; return a separate v2.3 audit dict."""
    try:
        return _verify(Path(api_root).resolve(), packet, result)
    except (KeyError, IndexError, TypeError, AttributeError) as error:
        raise ValueError("Malformed assessment replay artifact") from error

