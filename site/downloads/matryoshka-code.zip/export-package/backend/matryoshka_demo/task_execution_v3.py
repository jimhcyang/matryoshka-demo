"""Local structured task execution, with no retrieval or truth-score threshold.

execute_v3(case, plan, retrieval, passage_budget=100) uses the existing retrieval
interface. filter_redaction(case, result, top_k=5) requires the complete in-memory
candidate audit, not just an already shortened display. No old executor,
constructor, source, plan, graph, answer key, or benchmark is modified.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from datetime import date
from functools import lru_cache
from numbers import Integral
import re

from . import task_execution_v2 as base
from . import task_binding_v21 as binding
from .contracts import MASK, public_case, span
from .io import digest, offline
from .roles import lexicon


VERSION = "source-structured-task-execution/3.2"
SLOTS = base.SLOTS
_GOOD = {"MATCH", "UNSPECIFIED"}
_ORDER = {"SUPPORT": 0, "COUNTER": 1, "PARTIAL": 2, "RELATED": 3}
_OCCURRENCE = {"occur", "happen"}
_DEICTIC = re.compile(r"\b(?:today|tomorrow|yesterday|tonight|now|currently|presently|recently|soon|ago|"
    r"monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b|"
    r"\b(?:this|next|last|past)\s+(?:(?:few|several|two|three|\d+)\s+)?"
    r"(?:days?|weeks?|months?|years?|night|morning|evening)\b",re.I)
_NORMAL_NUMBERS = dict(zip(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty".split(),
    map(str, range(21))))


class _ParserIdentity:
    """Hold the parser alive and compare identity, never callable equality."""
    def __init__(self, parser):
        self.parser = parser

    def __hash__(self):
        return id(self.parser)

    def __eq__(self, other):
        return isinstance(other, _ParserIdentity) and self.parser is other.parser


# Process-local RAM engineering limit, not a source/retrieval/pruning parameter.
# Only raw Docs are retained; eligibility and semantic/frame dictionaries are
# recomputed per invocation. The default parser/pipeline must remain immutable.
_RAW_DOC_CACHE_LIMIT = 4096


@lru_cache(maxsize=_RAW_DOC_CACHE_LIMIT)
def _cached_raw_doc(identity, text):
    return identity.parser(text)


def _task_parser(parse=None):
    if parse is None:
        identity = _ParserIdentity(base.parser())
        parse = lambda text: _cached_raw_doc(identity, text)
    return base.offset_safe_parser(parse or base.parser())


def _term(proof):
    value = proof["lemma"]
    return _NORMAL_NUMBERS.get(value, value.replace(",", "")) if proof["pos"] == "NUM" else value


def _phrase_match(target, source):
    """Literal role match tolerant of POS drift, never a name/alias join."""
    if target["unresolved"] or source["unresolved"]:
        return False
    if target["head"] != source["head"] or any(
            target[k] != source[k] for k in ("quantifiers", "role_qualifiers")):
        return False
    def terms(p):
        return {_term(x) for x in p["proofs"] if x["pos"] in {"NOUN", "PROPN", "ADJ", "NUM"}}
    wanted, available = terms(target), terms(source)
    if not wanted or not wanted <= available:
        return False
    # Names must be literal in both arguments, even if one parser calls a title
    # NOUN and the other PROPN. Additional names are not treated as aliases.
    if not set(target["names"]) <= available or not set(source["names"]) <= wanted:
        return False
    return all(any(w["relation"] == s["relation"] and _phrase_match(w["phrase"], s["phrase"])
                   for s in source.get("modifiers", [])) for w in target.get("modifiers", []))


def _alignment(target, source):
    roles = source["roles"]
    if target["kind"] == "PROPERTY" and source["kind"] == "EVENT" and source["passive"]:
        roles = dict(roles, owner=roles.get("patient", []))
    rows = []
    for role, values in target["roles"].items():
        for wanted in values:
            available = roles.get(role, [])
            found = next((p for p in available if _phrase_match(wanted, p)), None)
            rows.append(dict(role=role, target=deepcopy(wanted), source=deepcopy(found),
                status="EXACT_SCOPED_ARGUMENT" if found else "MISSING" if not available else "DIFFERENT_ARGUMENT"))
    return rows


def _attached_deictics(predicate):
    """Only time expressions syntactically owned by this predicate."""
    result = []
    for match in _DEICTIC.finditer(predicate.doc.text):
        part = predicate.doc.char_span(match.start(),match.end(),alignment_mode="expand")
        if part is None:
            continue
        current,seen = part.root,set()
        while current.i not in seen:
            seen.add(current.i)
            if current == predicate:
                result.append(dict(start=match.start(),end=match.end(),text=match.group()))
                break
            if current.pos_ in {"VERB","AUX"} or current.head == current or (
                    current not in part and current.pos_ in {"NOUN","PROPN","PRON"}):
                break
            current = current.head
    return result


def _unclear_reporting_block(prior, parse):
    markers = list(re.finditer(r"\b(?:qte|quote|unqte|unquote|end\s+quote)\b",prior,re.I))
    if ":" not in prior and prior.count('"') % 2 == 0 and not markers:
        return False
    doc = parse(prior)
    reported = lambda sentence: any(base.matching.lemma(t) in base.matching.parent._REPORTING
        or base.matching.lemma(t) in {"statement","quotation","quote","qte"} for t in sentence)
    if reported(doc) and (prior.count('"') % 2 or markers
            and markers[-1].group().casefold() in {"qte","quote"}):
        return True
    for token in doc:
        if token.text != ":" or not reported(token.sent):
            continue
        if token.idx and token.idx+1 < len(prior) and prior[token.idx-1].isdigit() and prior[token.idx+1].isdigit():
            continue
        after = prior[token.idx+1:]
        closed = after.count('"') >= 2 and after.count('"') % 2 == 0 or re.search(r"\b(?:unqte|unquote|end\s+quote)\b",after,re.I)
        if not closed:
            return True
    return False


class _Engine:
    """All extra frame/lexical caches belong to this invocation."""
    def __init__(self, parse=None):
        self.parse = _task_parser(parse)
        self.cache, self.nouns, self.predicates, self.layout_words = {}, {}, {}, {}
        self.grammar_sources, self.plural_labels = {}, {}
        self.adjective_positions, self.quantity_units = {}, {}
        self.verb_objects = {}
        self.lexical_resource = dict(resource="WordNet", status="NOT_CONSULTED",
            proper_name_lookups=False, lexical_links_certify_entailment=False)

    def source_view(self, text):
        """Join dictionary-attested ordinary line-wrap words, with raw offsets.

        No proper-name/OCR correction, blank-line joining or source rewrite.
        This view is for dependency analysis; the literal proof path does NOT
        use it to upgrade a non-verbatim question to exact source equality.
        """
        removals, records = [], []
        for match in re.finditer(r"(?<=[A-Za-z])-[ \t]*\r?\n[ \t]*(?=[A-Za-z])",text):
            before = re.search(r"[A-Za-z]+$",text[:match.start()])
            after = re.match(r"[A-Za-z]+",text[match.end():])
            if not before or not after:
                continue
            word = (before.group()+after.group()).casefold()
            if word not in self.layout_words:
                valid = False
                try:
                    wn = lexicon()
                    valid = any(not s.instance_hypernyms() and any(l.name().islower() for l in s.lemmas())
                        for pos in ("v","n","a","r") for s in wn.synsets(word,pos=pos))
                    self.lexical_resource.update(status="AVAILABLE",version=wn.get_version())
                except LookupError:
                    self.lexical_resource["status"] = "UNAVAILABLE"
                self.layout_words[word] = valid
            if self.layout_words[word]:
                removals.append(match.span())
                a,b = before.start(),match.end()+after.end()
                records.append(dict(kind="ORDINARY_WORD_LINEWRAP_VIEW",start=a,end=b,
                    text=text[a:b],analysis_word=before.group()+after.group(),
                    raw_source_modified=False,named_identity_inferred=False))
        if not removals:
            return text,None,[]
        omitted = {i for a,b in removals for i in range(a,b)}
        offsets = [i for i in range(len(text)) if i not in omitted]
        return "".join(text[i] for i in offsets),offsets,records

    @staticmethod
    def restore_offsets(value, raw, offsets):
        if isinstance(value,list):
            return [_Engine.restore_offsets(v,raw,offsets) for v in value]
        if not isinstance(value,dict):
            return value
        result = {k:_Engine.restore_offsets(v,raw,offsets) for k,v in value.items()}
        for prefix in ("","antecedent_","event_"):
            ka,kb = prefix+"start",prefix+"end"
            if ka not in value or kb not in value:
                continue
            a,b = value[ka],value[kb]
            if type(a) is int and type(b) is int and 0 <= a < b <= len(offsets):
                start,end = offsets[a],offsets[b-1]+1
                result[ka],result[kb] = start,end
                for label in ((prefix+"quote",) if prefix else ("text","quote")):
                    if label in result:
                        result[label] = raw[start:end]
        return result

    def noun_verbs(self, word):
        if word not in self.nouns:
            result = set()
            try:
                wn = lexicon()
                for sense in wn.synsets(word, pos="n"):
                    if sense.instance_hypernyms():
                        continue
                    for lemma in sense.lemmas():
                        if lemma.name() != word or not lemma.name().islower():
                            continue
                        result.update(r.name() for r in lemma.derivationally_related_forms()
                            if r.synset().pos() == "v" and re.fullmatch("[a-z]+", r.name()))
                self.lexical_resource.update(status="AVAILABLE", version=wn.get_version())
            except LookupError:
                self.lexical_resource["status"] = "UNAVAILABLE"
            self.nouns[word] = tuple(sorted(result))
        return self.nouns[word]

    def lexical_relation(self, target, source):
        pair = target, source
        if pair not in self.predicates:
            links = []
            if all(re.fullmatch("[a-z]+", w) for w in pair) and target != source:
                try:
                    wn = lexicon()
                    wanted = {s.name() for s in wn.synsets(target, pos="v")}
                    for s in wn.synsets(source, pos="v"):
                        for relation, ancestor in [("SAME_SYNSET", s)] + [
                                ("SOURCE_DIRECT_ENTAILMENT", x) for x in s.entailments()]:
                            if ancestor.name() in wanted:
                                links.append(dict(relation=relation, source_synset=s.name(),
                                    target_synset=ancestor.name(), sense_disambiguated=False))
                    self.lexical_resource.update(status="AVAILABLE", version=wn.get_version())
                except LookupError:
                    self.lexical_resource["status"] = "UNAVAILABLE"
            self.predicates[pair] = links
        return deepcopy(self.predicates[pair])

    def frames(self, text, *, antecedents=False):
        key = text, antecedents
        if key not in self.cache:
            raw = text
            text,offsets,edits = self.source_view(raw)
            doc = self.parse(text)
            tokens = {t.idx: t for t in doc}
            originals = deepcopy(base.matching.frames(text, self.parse))
            result = []
            for frame in originals:
                token = tokens[frame["predicate_proof"]["start"]]
                frame["deictic_time"] = _attached_deictics(token)
                if frame["kind"] == "NOMINAL_RELATION":
                    # Possession establishes an owner, not who performed a
                    # deverbal action ("the city's destruction" is ambiguous).
                    frame["roles"]["owner"] = frame["roles"].pop("agent", [])
                    governor = token.head
                    verbs = self.noun_verbs(frame["predicate"])
                    explicit = (governor.pos_ == "VERB" and governor.lemma_.casefold() in _OCCURRENCE
                        and token.dep_ == "nsubj")
                    frame["nominal_realization"] = dict(owner_is_event_actor=False,
                        head=deepcopy(frame["predicate_proof"]), possible_verbs=list(verbs),
                        occurrence_explicit=explicit,
                        governor=base.matching.proof(governor) if governor != token else None)
                    if explicit:
                        frame["qualifiers"] = deepcopy(base.matching.qualifiers(governor))
                        frame["event_dates"] = deepcopy(base.matching.times(governor))
                        frame["deictic_time"] = _attached_deictics(governor)
                    elif verbs:
                        frame["qualifiers"]["unresolved"].append("NOMINAL_REFERENCE_NOT_AN_ESTABLISHED_EVENT")
                    result.append(frame)
                    for verb in verbs:
                        proposed = deepcopy(frame)
                        proposed.update(kind="EVENT", predicate=verb, copula=None, passive=False)
                        roles = deepcopy(frame["roles"])
                        roles["agent"] = roles.pop("owner", [])
                        if "prep:by" in roles:
                            roles["agent"] = roles.pop("prep:by")
                        if "prep:of" in roles:
                            roles["patient"] = roles.pop("prep:of")
                        proposed["roles"] = roles
                        proposed["v3_binding"] = dict(kind="DEVERBAL_NOMINAL_ROLE_CANDIDATE",
                            raw_predicate=frame["predicate"], possible_verbs=list(verbs),
                            owner_is_event_actor=False, direct_support_eligible=False)
                        result.append(proposed)
                    continue
                if token.dep_ == "relcl" and token.head.pos_ in {"NOUN", "PROPN"}:
                    for role, values in frame["roles"].items():
                        if len(values) == 1 and values[0]["unresolved"] and values[0]["head"] in {"who", "which", "that", "whom"}:
                            antecedent = base.matching.phrase(token.head)
                            if not antecedent["unresolved"]:
                                prior = deepcopy(values[0])
                                frame["roles"][role] = [antecedent]
                                frame["relative_binding"] = dict(kind="EXPLICIT_DEPENDENCY_RELATIVE_ANTECEDENT",
                                    role=role, pronoun=prior, antecedent=deepcopy(antecedent),
                                    event_scope_preserved=True, cross_sentence_identity_inferred=False)
                result.append(frame)
            if antecedents:
                for frame in binding.source_frames(text, self.parse):
                    if frame.get("experimental_binding"):
                        value = deepcopy(frame)
                        value["v3_binding"] = dict(deepcopy(frame["experimental_binding"]),
                            kind="POSSIBLE_LOCAL_ANTECEDENT", direct_support_eligible=False)
                        result.append(value)
            reporting = {}
            for frame in result:
                if frame["qualifiers"]["scope"]:
                    continue
                start = frame["start"]
                if start not in reporting:
                    previous = text.rfind("\n\n",0,start)
                    prior = text[0 if previous < 0 else previous+2:start]
                    reporting[start] = _unclear_reporting_block(prior,self.parse)
                if reporting[start]:
                    frame["qualifiers"]["unresolved"].append("PRIOR_REPORTING_BLOCK_SCOPE_UNCLEAR")
            if offsets is not None:
                result = self.restore_offsets(result,raw,offsets)
                for frame in result:
                    frame["source_normalization"] = [deepcopy(e) for e in edits
                        if e["start"] < frame["end"] and frame["start"] < e["end"]]
            self.cache[key] = result
        return deepcopy(self.cache[key])

    def targets(self, text):
        frames = [f for f in self.frames(text) if not f.get("v3_binding")]
        return [f for f in frames if not any(g is not f and g["start"] == f["start"]
            and any(s["predicate"] == f["predicate"] for s in g["qualifiers"]["scope"]) for g in frames)]


def _diagnostics(target, source, alignment):
    rows = base._diagnostics(target, source, alignment)
    deictic = {k:deepcopy(f.get("deictic_time",[])) for k,f in (("target",target),("source",source))}
    if any(deictic.values()) and rows["event_date"]["status"] in _GOOD:
        rows["event_date"].update(status="UNRESOLVED",deictic_surfaces=deictic,
            resolution="NOT_RESOLVED_FROM_PUBLICATION_DATE_OR_ORIGIN_CONTEXT")
    quantity = rows["quantity"]
    if quantity["status"] == "MISMATCH":
        without_operator = lambda values: [{k:v for k,v in row.items() if k != "operators"} for row in values]
        if without_operator(quantity["target"]) == without_operator(quantity["source"]):
            quantity.update(status="PARTIAL", qualification="SAME_AMOUNT_DIFFERENT_QUANTIFIER_NOT_EXACT_SUPPORT")
    actors = {"owner"} if target["kind"] in {"PROPERTY", "NOMINAL_RELATION"} else {"agent"}
    objects = {r for r in target["roles"] if r not in actors and (
        not r.startswith("prep:") or r.removeprefix("prep:") not in base._LOCATION_PREPS)}
    rows["object"] = base._argument(target, source, objects, alignment)
    if target["kind"] == "NOMINAL_RELATION":
        rows["actor"] = base._argument(target, source, {"owner"}, alignment)
        rows["actor"]["binding"] = "NOMINAL_OWNER_NOT_CERTIFIED_EVENT_AGENT"
    return rows


def compare_frames(target, source, *, engine=None):
    """Nine field gates; lexical/anaphora hypotheses can never certify truth."""
    engine = engine or _Engine()
    checks = _alignment(target, source)
    same = target["predicate"] == source["predicate"]
    aligned = sum(r["status"] == "EXACT_SCOPED_ARGUMENT" for r in checks)
    if not same and not aligned:
        return None
    fields = _diagnostics(target, source, checks)
    reasons = []
    different = [k for k in SLOTS[:6] if fields[k]["status"] == "MISMATCH"]
    missing = [k for k in SLOTS if fields[k]["status"] not in _GOOD and k != "polarity"]
    t, s = target["qualifiers"], source["qualifiers"]
    if base._embedded_actor_unresolved(target) or base._embedded_actor_unresolved(source):
        direction = "RELATED"
        reasons.append("EMBEDDED_EVENT_ACTOR_BINDING_UNRESOLVED_NOT_EVENT_EVIDENCE")
    elif different or any(r["status"] == "DIFFERENT_ARGUMENT" for r in checks):
        direction = "RELATED"
        reasons.extend("DIFFERENT_" + k.upper() + "_NOT_COUNTEREVIDENCE" for k in different)
        if not different:
            reasons.append("DIFFERENT_SCOPED_ARGUMENT_NOT_COUNTEREVIDENCE")
    elif not aligned:
        direction = "RELATED"
        reasons.append("NO_SOURCE_OWNED_ARGUMENT_MATCH")
    else:
        unresolved = bool(target["unbound_arguments"] or source["unbound_arguments"]
            or t["unresolved"] or s["unresolved"] or any(r["status"] == "MISSING" for r in checks))
        uncertain = any(q["epistemic_absence"] or q["conditional"] or q["question"] for q in (t, s))
        role_scope = any(q.get("role_qualifiers") for q in (t, s))
        manner_missing = not set(t["manner"]) <= set(s["manner"])
        if not same:
            direction = "RELATED"
            reasons.append("DIFFERENT_LEXICAL_PREDICATE")
        elif missing or unresolved or uncertain or manner_missing or role_scope:
            direction = "PARTIAL"
            reasons.extend("UNRESOLVED_" + k.upper() for k in missing)
            if unresolved: reasons.append("UNRESOLVED_ARGUMENT_OR_ASSERTION_SCOPE")
            if uncertain: reasons.append("NONASSERTIVE_OR_EPISTEMIC_ABSENCE_NOT_EVENT_NEGATION")
            if manner_missing: reasons.append("MISSING_TARGET_MANNER_QUALIFIER")
            if role_scope: reasons.append("ROLE_SCOPED_QUALIFICATION_NOT_UNSCOPED_EVENT_NEGATION")
        elif fields["polarity"]["status"] == "OPPOSED":
            if t["scope"] or s["scope"] or t["modality"] or s["modality"] or (
                    source["event_dates"] and not target["event_dates"]):
                direction = "PARTIAL"
                reasons.append("OPPOSITION_SCOPE_OR_EVENT_IDENTITY_NOT_ESTABLISHED")
            else:
                direction = "COUNTER"
                reasons.append("EXPLICIT_OPPOSING_POLARITY_SAME_STRUCTURED_REQUIREMENT")
        else:
            direction = "SUPPORT"
            reasons.append("ALL_REQUIRED_STRUCTURED_FIELDS_MATCH")
    proposed = source.get("v3_binding") or target.get("v3_binding")
    if proposed and direction in {"SUPPORT", "COUNTER"}:
        direction = "PARTIAL"
        reasons.append("HYPOTHESIZED_BINDING_NOT_DIRECT_SUPPORT_OR_COUNTER")
    # Deverbal/predicate variants remain visible, but are never exact lexical
    # matches just because their candidate normalized predicate is the same.
    if proposed and proposed["kind"] == "DEVERBAL_NOMINAL_ROLE_CANDIDATE":
        fields["predicate"].update(status="PARTIAL", source_wording=proposed["raw_predicate"],
            binding=deepcopy(proposed))
    lexical = None
    if not same and all(fields[k]["status"] in _GOOD for k in ("actor", "object", "quantity", "event_date", "location")):
        if all(f["kind"] == "EVENT" and f["predicate_proof"]["pos"] == "VERB" for f in (target, source)):
            links = engine.lexical_relation(target["predicate"], source["predicate"])
            lexical = dict(candidates=links, contextual_entailment_certified=False) if links else None
            blocked = (any(q["negated"] or q["scope"] or q["modality"] or q["epistemic_absence"]
                or q["conditional"] or q["question"] or q["unresolved"] for q in (t, s))
                or target["unbound_arguments"] or source["unbound_arguments"] or proposed)
            if links and not blocked:
                direction = "PARTIAL"
                reasons.append("ORDINARY_PREDICATE_LEXICAL_CANDIDATE_ONLY")
    return dict(direction=direction, reasons=list(dict.fromkeys(reasons)), diagnostics=fields,
        bindings=dict(argument_matches=checks, aligned_arguments=aligned, predicate_match=same,
            event_identity_certified=False, named_identity_certified=False),
        source_binding=deepcopy(source.get("v3_binding") or source.get("relative_binding")),
        source_realization=deepcopy(source.get("nominal_realization")),
        source_normalization=deepcopy(source.get("source_normalization",[])),
        predicate_lexical_candidate=lexical, event_date_from_publication=False)


def _bind(atom, query, engine):
    normalize = lambda x: " ".join(x.casefold().split())
    literal = normalize(atom["text"]) == normalize(atom["source_quote"])
    basic_fields = {"id", "text", "source_quote", "start", "end", "required"}
    if literal and set(atom) <= basic_fields:
        # Exact source atoms need no paraphrase/projection recovery. Preserve
        # every frame's original query scope instead of inheriting unrelated
        # failed prepare_atom alternatives as binding errors.
        units = [u for u in base.sentences(query) if u["start"] < atom["end"] and atom["start"] < u["end"]]
        if not units:
            return [], ["NO_ANCHORED_SENTENCE"]
        a, b = units[0]["start"], units[-1]["end"]
        found = []
        for frame in engine.targets(query[a:b]):
            proof = frame["predicate_proof"]
            if atom["start"] - a < proof["end"] and proof["start"] < atom["end"] - a:
                frame["query_context"] = dict(start=a, end=b, text=query[a:b])
                found.append(frame)
        return found, [] if found else ["NO_SOURCE_BOUND_QUERY_FRAME"]
    native, issues = base._bind_atom(atom, query, engine.parse)
    bound = []
    for f in native:
        if f.get("projection"):
            bound.append(f)
            continue
        context = f["query_context"]
        choices = [g for g in engine.targets(context["text"])
            if g["predicate"] == f["predicate"] and g["predicate_proof"]["start"] == f["predicate_proof"]["start"]]
        if len(choices) == 1:
            value = choices[0]
            value["query_context"] = deepcopy(context)
            bound.append(value)
    if bound:
        return bound, issues
    # A literal atom can use an explicit nominal/relative frame missed by the
    # old planner binder. A paraphrase never gains this fallback authority.
    if normalize(atom["text"]) != normalize(atom["source_quote"]):
        return [], issues or ["NO_LITERAL_QUERY_BINDING"]
    units = [u for u in base.sentences(query) if u["start"] < atom["end"] and atom["start"] < u["end"]]
    if not units:
        return [], ["NO_ANCHORED_SENTENCE"]
    a, b = units[0]["start"], units[-1]["end"]
    context = query[a:b]
    for f in engine.targets(context):
        proof = f["predicate_proof"]
        if not atom["start"] - a < proof["end"] or not proof["start"] < atom["end"] - a:
            continue
        errors = base._declared_issues(atom, f, engine.parse)
        if atom.get("predicate"):
            declared = {base.matching.lemma(t) for t in engine.parse(str(atom["predicate"]))}
            if f["predicate"] not in declared:
                continue
        if any(p["unresolved"] for values in f["roles"].values() for p in values):
            errors.append("UNRESOLVED_QUERY_PARTICIPANT")
        if errors:
            continue
        f["query_context"] = dict(start=a, end=b, text=context)
        bound.append(f)
    return bound, [] if bound else issues or ["NO_SOURCE_BOUND_QUERY_FRAME"]


def _coverage(query, plan, bindings, engine):
    contexts, covered = {}, {}
    for aid, f in bindings:
        c = f["query_context"]
        contexts[(c["start"], c["end"])] = c
        if not f.get("projection"):
            covered.setdefault(base._query_frame_id(f, c["start"]), []).append(aid)
    requirements = {}
    for c in contexts.values():
        for f in engine.targets(c["text"]):
            key = base._query_frame_id(f, c["start"])
            proof = f["predicate_proof"]
            a, b = c["start"] + proof["start"], c["start"] + proof["end"]
            requirements[key] = dict(id=key, predicate=f["predicate"], start=a, end=b,
                source_quote=query[a:b], bound_atom_ids=covered.get(key, []), executed=key in covered)
    units = []
    for unit in base.sentences(query):
        if not any(c.isalnum() for c in unit["text"]):
            continue
        anchors = [a["id"] for a in plan["atoms"] if a["start"] < unit["end"] and unit["start"] < a["end"]]
        required = [r for r in requirements.values() if unit["start"] <= r["start"] < unit["end"]]
        done = sum(r["executed"] for r in required)
        status = ("COVERED" if required and done == len(required) else "PARTIAL" if done else "UNBOUND" if anchors else "OMITTED")
        units.append(dict(id="query_unit_" + str(len(units) + 1), **unit, source_quote=unit["text"],
            status=status, anchored_atom_ids=anchors, requirements=deepcopy(required),
            missing_requirement_ids=[r["id"] for r in required if not r["executed"]]))
    complete = bool(units) and all(u["status"] == "COVERED" for u in units)
    return dict(status="COVERED_BY_BOUND_FRAMES" if complete else "INCOMPLETE", complete=complete,
        query_sha256=digest(query), units=units, required_units=len(units),
        covered_units=sum(u["status"] == "COVERED" for u in units),
        uncovered_unit_ids=[u["id"] for u in units if u["status"] != "COVERED"],
        required_frames_in_bound_contexts=len(requirements),
        covered_frames_in_bound_contexts=sum(r["executed"] for r in requirements.values()),
        omitted_requirements_executed=False, semantic_exhaustiveness_certified=False,
        missing_query_coverage_is_counterevidence=False)


def _source_pages(case, retrieval, budget):
    from .source_view_policy import policy_of, source_page_allowed
    eligible, corpus = retrieval["eligible"], retrieval["eligible"].corpus
    indices = retrieval["pages"]
    if any(not isinstance(i, Integral) or isinstance(i, bool) or not 0 <= i < len(corpus.pages) for i in indices):
        raise ValueError("Invalid retrieved source-page index")
    ranks = retrieval.get("page_ranks", {})
    selected = sorted({int(i) for i in indices}, key=lambda i:(ranks.get(i, 10**9), i))[:budget]
    pages, seen = [], {}
    for i in selected:
        p = corpus.pages[i]
        date.fromisoformat(p["date"])
        if (not source_page_allowed(p, case, policy_of(corpus))
                or p.get("visibility") not in {None, "earlier", "both"}
                or not eligible.page_mask[i]
                or case["corpus"] != "cib" and (p.get("classification") != "CONFIDENTIAL"
                    or "NOFORN" in p.get("handling", []))):
            raise ValueError("Retrieved source violates cutoff/origin/source policy")
        if digest(p["text"]) != p["source_sha256"]:
            raise ValueError("Source text hash changed")
        if p["id"] in seen and seen[p["id"]] != p:
            raise ValueError("Ambiguous canonical source-page identity")
        if p["id"] not in seen:
            pages.append(p)
            seen[p["id"]] = p
    return pages, len(set(indices))


def _decide(task, atoms):
    required = [a for a in atoms if a["required"]]
    states = [a["status"] for a in required]
    if task == "hypothesis":
        status = ("MIXED" if "MIXED" in states else "COUNTER" if "COUNTER" in states else
            "SUPPORT" if states and all(s == "SUPPORT" for s in states) else
            "PARTIAL" if any(s in {"SUPPORT", "PARTIAL"} for s in states) else "INSUFFICIENT")
    else:
        status = ("CONFLICTING" if any(s in {"COUNTER", "MIXED"} for s in states) else
            "COMPLETE" if states and all(s == "SUPPORT" for s in states) else
            "PARTIAL" if any(s in {"SUPPORT", "PARTIAL"} for s in states) else "INSUFFICIENT")
    return dict(task=task, status=status, required_atoms=len(required), optional_atoms=len(atoms)-len(required),
        covered_atoms=states.count("SUPPORT"), partial_atoms=states.count("PARTIAL"),
        conflicts=sum(s in {"COUNTER", "MIXED"} for s in states),
        missing_evidence_is_counterevidence=False, general_entailment_certified=False,
        scope="Supplied requirements and inspected eligible source pages; not corpus absence")


def _literal_sentence_proofs(atom, pages, engine):
    """A whole, stable scoped statement; never an embedded lexical substring."""
    if " ".join(atom["text"].casefold().split()) != " ".join(atom["source_quote"].casefold().split()):
        return []
    if _DEICTIC.search(atom["source_quote"]):
        return []
    doc = engine.parse(atom["source_quote"])
    parsed = engine.frames(atom["source_quote"])
    if any(d["value"] is None for f in parsed for d in f["event_dates"]):
        return []
    relatives = {p["start"] for f in parsed if f.get("relative_binding")
        for p in f["relative_binding"]["pronoun"]["proofs"]}
    if any(t.pos_ == "PRON" and t.dep_ != "expl" and t.idx not in relatives for t in doc):
        return []
    subjects = [t for t in doc if t.dep_ in {"nsubj","nsubjpass","nsubj:pass"} and t.pos_ in {"NOUN","PROPN"}]
    if not subjects:
        return []
    for subject in subjects:
        phrase = base.matching.phrase(subject)
        # A bare "government/president/council" is not a cross-document world
        # identity. Qualification must be visible in this NP, not an origin ID.
        proofs = [p for _,p in _proofs(phrase)]
        owned = {p["start"] for p in proofs}
        if not any(t.idx in owned and (t.pos_ == "PROPN" or t.ent_type_ in {"PERSON","ORG","GPE","LOC","NORP"})
                for t in doc):
            return []
    if not any(t.pos_ in {"VERB","AUX"} for t in doc):
        return []
    pattern = re.compile(r"\s+".join(re.escape(w) for w in atom["source_quote"].split()),re.I)
    records = []
    for page in pages:
        sentences = list(engine.parse(page["text"]).sents)
        for match in pattern.finditer(page["text"]):
            a,b = match.span()
            if a and page["text"][a-1].isalnum() or b < len(page["text"]) and page["text"][b].isalnum():
                continue
            enclosing = [s for s in sentences if s.start_char < b and a < s.end_char]
            if not enclosing:
                continue
            prefix = page["text"][enclosing[0].start_char:a]
            suffix = page["text"][b:enclosing[-1].end_char]
            # Only layout punctuation/section numbering can sit outside the
            # complete matched sentence. No "denied/reported that", dates,
            # names, qualifications or missing clause tails are stripped.
            prefix = re.sub(r"^\s*\d+\.\s*","",prefix)
            if re.search(r"\w",prefix+suffix) or MASK.search(prefix+suffix):
                continue
            previous_break = page["text"].rfind("\n\n",0,enclosing[0].start_char)
            paragraph_start = 0 if previous_break < 0 else previous_break+2
            prior = page["text"][paragraph_start:enclosing[0].start_char]
            if _unclear_reporting_block(prior,engine.parse):
                continue
            citation = dict(document_id=page["document_id"],canonical_page_id=page["id"],
                date=page["date"],document_date=page["date"],start=a,end=b,
                text=page["text"][a:b],page_sha256=page["source_sha256"])
            diagnostics = {}
            self_fields = [_diagnostics(f,f,_alignment(f,f)) for f in parsed if not f.get("v3_binding")]
            for field in SLOTS:
                values = [deepcopy(d[field]["target"]) for d in self_fields]
                diagnostics[field] = base._row(values,values,"MATCH")
                diagnostics[field]["match_basis"] = "ENTIRE_SCOPED_ATOM_CASE_WHITESPACE_EQUALITY"
                diagnostics[field]["unresolved_inner_events_resolved"] = False
            records.append(dict(citation=citation,diagnostics=diagnostics,
                source_binding=dict(kind="EXACT_WHOLE_SCOPED_SENTENCE",direct_support_eligible=True,
                    source_sentence_start=enclosing[0].start_char,source_sentence_end=enclosing[-1].end_char,
                    case_whitespace_only=True,stable_explicit_subject=True,external_reporting_scope=False,
                    supports_unscoped_inner_events=False,named_identity_certified=False,
                    qualified_identity_visible_in_sentence=True,deictic_time_certified=False)))
    return records


def execute_v3(case, plan, retrieval, passage_budget=100, *, parse=None):
    """Execute a supplied plan once, without searching, replanning, or APIs."""
    with offline():
        case = public_case(case)
        if case["task"] not in {"hypothesis", "reconstruction"}:
            raise ValueError("Use filter_redaction for candidate grammar/support admission")
        if type(passage_budget) is not int or passage_budget < 0:
            raise ValueError("passage_budget must be a nonnegative whole-page count")
        base._validate_plan(case, plan)
        if any(type(a.get("required", True)) is not bool for a in plan["atoms"]):
            raise ValueError("Atom required flags must be Boolean")
        engine = _Engine(parse)
        pages, admitted = _source_pages(case, retrieval, passage_budget)
        sources = [(p, f) for p in pages for f in engine.frames(p["text"], antecedents=True)
            if not MASK.search(f["quote"])]
        atoms, bindings = [], []
        for atom in plan["atoms"]:
            targets, issues = _bind(atom, case["query"], engine)
            bindings.extend((atom["id"], t) for t in targets)
            evidence, frames = [], []
            for n, target in enumerate(targets, 1):
                fid = atom["id"] + ":F" + str(n)
                records = {}
                for page, source in sources:
                    match = compare_frames(target, source, engine=engine)
                    if match is None:
                        continue
                    citation = base._citation(page, source)
                    key = digest([fid, citation, match])
                    records[key] = dict(id="proof_" + key[:24], frame_id=fid,
                        **citation, citation=citation, **match,
                        match_representation="SOURCE_STRUCTURED_FRAME_V3", matched_statement=citation["text"])
                ordered = sorted(records.values(), key=lambda e:(
                    _ORDER[e["direction"]], e["canonical_page_id"], e["start"], e["id"]))
                frames.append(dict(id=fid, status=base._status(e["direction"] for e in ordered),
                    target_frame=base._summary(target), evidence_ids=[e["id"] for e in ordered]))
                evidence.extend(ordered)
            literal = _literal_sentence_proofs(atom,pages,engine) if targets and not issues else []
            if literal and not all(f["status"] == "SUPPORT" for f in frames):
                fid = atom["id"] + ":LITERAL"
                for proof in literal:
                    key = digest([fid,proof])
                    citation = proof["citation"]
                    evidence.append(dict(id="proof_"+key[:24],frame_id=fid,direction="SUPPORT",
                        **citation,**proof,reasons=["EXACT_WHOLE_SCOPED_SENTENCE_NOT_EMBEDDED_SUBSTRING"],
                        bindings=dict(event_identity_certified=False,named_identity_certified=False),
                        match_representation="SOURCE_WHOLE_SCOPED_SENTENCE_V3",
                        matched_statement=citation["text"],event_date_from_publication=False))
                opposed = any(e["direction"] == "COUNTER" for e in evidence)
                summary = base._summary(targets[0])
                summary.update(kind="SCOPED_STATEMENT",scoped_text=atom["source_quote"],
                    supports_unscoped_inner_events=False)
                frames.append(dict(id=fid,status="MIXED" if opposed else "SUPPORT",
                    target_frame=summary,evidence_ids=[e["id"] for e in evidence if e["frame_id"] == fid],
                    proof_role="ALTERNATIVE_COMPLETE_ATOM_GROUNDING"))
                status = "MIXED" if opposed else "SUPPORT"
            else:
                status = base._aggregate([f["status"] for f in frames] + (["INSUFFICIENT"] if issues else []))
            atoms.append(dict(id=atom["id"], text=atom["text"], source_quote=atom["source_quote"],
                start=atom["start"], end=atom["end"], required=atom.get("required", True),
                planned_atom=deepcopy(atom), status=status,
                state={"SUPPORT":"supported", "COUNTER":"counter", "MIXED":"mixed",
                    "PARTIAL":"partial", "INSUFFICIENT":"missing"}[status],
                binding_issues=issues, frames=frames, evidence=evidence, evidence_count=len(evidence),
                whole_scoped_literal_support=bool(literal)))
        decision = _decide(case["task"], atoms)
        scoped = deepcopy(decision)
        scoped["verdict_scope"] = "SUPPLIED_PLANNED_ATOM_BINDINGS_ONLY"
        coverage = _coverage(case["query"], plan, bindings, engine)
        for unit in coverage["units"]:
            complete = [a["id"] for a in atoms if a["whole_scoped_literal_support"]
                and a["start"] <= unit["start"] and unit["end"] <= a["end"]]
            if complete:
                unit.update(status="COVERED",whole_atom_literal_proof_ids=complete)
        coverage["complete"] = bool(coverage["units"]) and all(u["status"] == "COVERED" for u in coverage["units"])
        coverage.update(status="COVERED_BY_BOUND_FRAMES_OR_WHOLE_ATOM_PROOFS" if coverage["complete"] else "INCOMPLETE",
            covered_units=sum(u["status"] == "COVERED" for u in coverage["units"]),
            uncovered_unit_ids=[u["id"] for u in coverage["units"] if u["status"] != "COVERED"])
        if not coverage["complete"] and decision["status"] in {"SUPPORT", "COMPLETE"}:
            decision["status"] = "PARTIAL"
        result = dict(decision, version=VERSION, case_id=case["case_id"], native_verdict=decision["status"],
            atoms=atoms, planned_atom_verdict=scoped["status"], planned_atom_decision=scoped,
            verdict_scope="PLANNED_ATOMS_WITH_QUERY_COVERAGE_GUARD", query_coverage=coverage,
            whole_query_support_certified=False, query_sha256=digest(case["query"]), plan_sha256=digest(plan),
            api_calls=0, keys_read=False, grades_read=False, source_only_evidence=True,
            llm_assessment=dict(status="NOT_RUN", used_for_native_verdict=False, api_calls=0),
            source_pages_inspected=len(pages), source_pages_admitted=admitted,
            passage_budget=passage_budget, budget_unit="whole_source_page",
            retrieval=deepcopy(retrieval.get("receipt", {})), derived_statement_control=False,
            diagnostics_fields=list(SLOTS), lexical_resource=deepcopy(engine.lexical_resource))
        payload = base._hypothesis(atoms) if case["task"] == "hypothesis" else base._reconstruction(atoms)
        gaps = base._coverage_gaps(coverage)
        payload["query_coverage_gaps"] = gaps
        payload["gaps"].extend(deepcopy(gaps))
        if case["task"] == "reconstruction":
            components = payload["assembled_components"]
            payload["established_assembly"] = deepcopy(payload["source_cited_account"])
            payload["conflicting_requirements"] = [
                dict(atom_id=a["id"], frame_id=f["id"], status=f["status"],
                    evidence_ids=f["evidence_ids"]) for a in atoms for f in a["frames"]
                if f["status"] in {"COUNTER", "MIXED"}]
            payload["chronology"] = [
                dict(component_id=c["id"], event_dates=deepcopy(c["scoped_proposition"]["event_dates"]),
                    document_dates=sorted({s["document_date"] for s in c["citations"]}),
                    event_date_from_publication=False) for c in components]
            payload["hypothetical_bridges"].extend(dict(kind="CONDITIONAL_PLAN_AND_EVIDENCE_REQUIREMENT",
                query_unit_id=g["query_unit_id"], atom_id=None, required_proposition=g["proposition"],
                conditional=True, asserted_as_fact=False, evidence_ids=[]) for g in gaps)
        result[case["task"]] = payload
        return result


execute = execute_v3


def _focal_sentence_bounds(case, parse):
    a = case["query"].index(case["focal_marker"])
    b = a + len(case["focal_marker"])
    all_sentences = list(parse(case["query"]).sents)
    selected = [i for i,s in enumerate(all_sentences) if s.start_char < b and a < s.end_char]
    if not selected:
        raise ValueError("No replayable focal sentence")
    first,last = selected[0],selected[-1]
    # Cable line wrapping can make the parser put a sentence break at the mask.
    # Only punctuation/paragraph boundaries may clip actual slot context.
    def boundary(before):
        stripped = before.rstrip()
        return (not stripped or bool(re.search(r"\n\s*\n\s*$",before)) or
            bool(re.search(r"[.!?][\"')]*$",stripped)) and
            not bool(re.search(r"(?:\b[A-Z]\.){1,}$",stripped)))
    while first and not boundary(case["query"][:all_sentences[first].start_char]):
        first -= 1
    while last+1 < len(all_sentences) and not boundary(case["query"][:all_sentences[last].end_char]):
        last += 1
    return all_sentences[first].start_char,all_sentences[last].end_char


def _grammar_admission(case, reading, fill, parse, bounds):
    if not isinstance(fill, str):
        raise ValueError("A literal candidate fill is required")
    left, right = case["query"].split(case["focal_marker"])
    completed = left + fill + right
    a, b = bounds
    at = len(left)
    focal = case["query"][a:at] + fill + case["query"][at+len(case["focal_marker"]):b]
    local_start = at-a
    result = dict(admissible=False, reasons=[], original_fill=fill, fill=fill,
        insertion_edits=[], padding_added=False, syntax_only=True, semantic_type_certified=False,
        completed_query=completed, fill_start=len(left), fill_end=len(left)+len(fill),
        focal_context=dict(start=a, end=b, text=case["query"][a:b],
            query_sha256=digest(case["query"]), suffix_context_clipped=False,
            unit="WHOLE_PARSED_FOCAL_SENTENCE"))
    reasons = result["reasons"]
    if not fill.strip() or MASK.search(fill):
        reasons.append("EMPTY_OR_MASKED_FILL")
        return result
    doc = parse(focal)
    supplied = doc.char_span(local_start, local_start+len(fill), alignment_mode="strict")
    if supplied is None:
        reasons.append("FILL_CUTS_OR_JOINS_A_TOKEN")
        return result
    tokens = [t for t in supplied if not t.is_space]
    if not tokens:
        reasons.append("EMPTY_FILL")
        return result
    form = reading.get("form", "unknown")
    # Preserve raw insertion characters while inspecting an offset-aligned
    # lowercase view for uppercase common-noun chunks.
    lowered = focal.lower()
    if fill.isupper() and len(lowered) == len(focal):
        view = parse(lowered).char_span(local_start, local_start+len(fill), alignment_mode="strict")
        if view is not None:
            supplied, tokens = view, [t for t in view if not t.is_space]
    head = supplied.root
    example_prefix = (1 if form == "member_example" and tokens[0].lemma_.casefold() in {"like","as"} else
        2 if form == "member_example" and [t.lemma_.casefold() for t in tokens[:2]] == ["such","as"] else 0)
    if example_prefix:
        if len(tokens) <= example_prefix:
            reasons.append("EXAMPLE_CONNECTOR_WITHOUT_NOMINAL")
        else:
            head = supplied.doc[tokens[example_prefix].i:tokens[-1].i+1].root
        before = next((t for t in reversed(supplied.doc[:tokens[0].i])
            if not t.is_space and t.text not in {",", "(", "["}), None)
        if before is None or before.pos_ not in {"NOUN", "PROPN", "PRON"}:
            reasons.append("EXAMPLE_CONNECTOR_WITHOUT_VISIBLE_NOMINAL_CLASS")
        else:
            result["example_parent"] = dict(text=before.text, pos=before.pos_,
                start=a+before.idx, end=a+before.idx+len(before))
    nominal = form in {"nominal", "possessive", "member_example"}
    if form == "unknown":
        nominal = head.pos_ in {"NOUN", "PROPN", "PRON"}
    result.update(form=form, head=head.text, head_pos=head.pos_, head_tag=head.tag_, head_lemma=head.lemma_)
    if len(list(supplied.sents)) != 1:
        reasons.append("FILL_CROSSES_SENTENCES")
    if any(t.text in {";", ":"} for t in tokens):
        reasons.append("FILL_CONTAINS_CLAUSE_OR_SECTION_DELIMITER")
    if nominal:
        first, last = tokens[0], tokens[-1]
        example = bool(example_prefix)
        if head.pos_ not in {"NOUN", "PROPN"}:
            reasons.append("NOMINAL_FILL_HAS_NONNOMINAL_HEAD")
        if first.pos_ in {"ADP", "SCONJ", "CCONJ"} and not example:
            reasons.append("PREPOSITION_OR_CONNECTIVE_LED_NOMINAL")
        if last.pos_ in {"ADP", "SCONJ", "CCONJ", "DET"}:
            reasons.append("STRANDED_NOMINAL_FUNCTION_WORD")
        if any(t.dep_ in {"ccomp", "advcl", "relcl"} or t.pos_ in {"VERB", "AUX"}
                and ("Fin" in t.morph.get("VerbForm") or t.tag_ in {"VBD", "VBP", "VBZ", "MD"}) for t in tokens):
            reasons.append("NOMINAL_FILL_CONTAINS_A_CLAUSE")
        if first.pos_ == "ADV" and len(tokens) > 1 and tokens[1].pos_ in {"NOUN", "PROPN"}:
            reasons.append("ADVERB_DIRECTLY_PREFIXES_NOMINAL")
        if re.search(r"\b(?:a|an|the)\s*$", left, re.I) and (
                first.pos_ == "DET" or first.lemma_.casefold() in {"this", "that", "these", "those"}):
            reasons.append("DUPLICATED_OR_STRANDED_SOURCE_DETERMINER")
        if re.search(r"\b(?:a|an)\s*$", left, re.I) and head.tag_ in {"NNS", "NNPS"}:
            reasons.append("INDEFINITE_ARTICLE_WITH_BARE_PLURAL")
        if form == "possessive" and not re.search(r"(?:['\u2019]s|s['\u2019])$", fill.strip()):
            reasons.append("POSSESSIVE_FORM_REQUIRES_POSSESSIVE_MORPHOLOGY")
    if form == "modifier":
        if head.pos_ not in {"ADJ", "VERB"} or head.pos_ == "VERB" and head.tag_ not in {"VBN", "VBG"}:
            reasons.append("NOMINAL_OR_FINITE_FILL_IS_NOT_A_MODIFIER")
        if any(t.dep_ in {"ccomp", "advcl", "relcl"} for t in tokens):
            reasons.append("MODIFIER_CONTAINS_A_CLAUSE")
        # Head-attached post-adverbs belong before a prenominal carrier. This
        # filter withholds malformed ordering rather than dropping qualifiers.
        following = parse(right.lstrip())
        before = next((t for t in reversed(supplied.doc[:supplied.start]) if not t.is_space), None)
        result["postnominal_modifier"] = bool(before is not None and before.pos_ in {"NOUN","PROPN","PRON"}
            and (not following or following[0].pos_ not in {"NOUN","PROPN","ADJ"}))
        result["completed_modifier_complement"] = any(c.dep_ in {"prep","dobj","obj","xcomp"}
            and (c.dep_ != "prep" or any(o.dep_ == "pobj" for o in c.children))
            for c in head.children)
        result["completed_modifier_object"] = any(c.dep_ in {"dobj","obj"}
            and not c.tag_.startswith("W") for c in head.children)
        if following and following[0].pos_ in {"NOUN", "PROPN"} and any(
                t.pos_ == "ADV" and t.i > head.i for t in tokens):
            reasons.append("POST_HEAD_ADVERB_BEFORE_PRENOMINAL_CARRIER")
    if form == "quantity" and not any(t.like_num for t in tokens):
        reasons.append("QUANTITY_REQUIRES_A_LEXICAL_NUMBER")
    if form == "quantity":
        result["quantity_binding"] = _number_binding(supplied, offset=a, raw=focal, query=True)
    if form in {"clause", "verbal", "adjunct"}:
        reasons.append("UNIMPLEMENTED_FORM_WITHHELD_NOT_PADDED")
    if head.pos_ == "PRON":
        reasons.append("UNRESOLVED_PRONOUN_NOT_A_SOURCE_LABEL")
    result["admissible"] = not reasons
    return result


def grammar_admission(case, reading, fill, *, parse=None):
    """Syntactic admission only; parse a complete focal sentence, never pad."""
    case = public_case(case)
    if case["task"] != "redaction":
        raise ValueError("Redaction grammar requires a unique focal mask")
    parse = _task_parser(parse)
    return _grammar_admission(case, reading, fill, parse, _focal_sentence_bounds(case, parse))


def _ordinary_plural_label(word, engine):
    """Lexical inflection, not an s-ending/proper-name heuristic."""
    word = word.casefold()
    if word not in engine.plural_labels:
        result = dict(status="UNKNOWN", resource="WordNet", ordinary_senses=[])
        try:
            wn = lexicon()
            lemma = wn.morphy(word, "n")
            senses = [s.name() for s in wn.synsets(lemma, pos="n")
                if not s.instance_hypernyms() and any(l.name() == lemma and l.name().islower()
                    for l in s.lemmas())] if lemma and lemma != word else []
            result.update(status="PLURAL_COMMON_NOUN" if senses else "NOT_VERIFIED_PLURAL",
                version=wn.get_version(), lemma=lemma, ordinary_senses=sorted(senses))
        except LookupError:
            result["status"] = "RESOURCE_UNAVAILABLE"
        engine.plural_labels[word] = result
    return engine.plural_labels[word]


def _source_grammar_admission(case, proposal, engine):
    """Withhold a shared plural label clipped to one source-named conjunct.

    The primary occurrence alone owns source_span. Other dossier mentions must
    not license singularization or repair it. No source/fill text is changed.
    """
    result = dict(admissible=True, status="UNKNOWN", reasons=[], insertion_edits=[],
        binding_scope="PRIMARY_SOURCE_OCCURRENCE", source_modified=False,
        semantic_type_certified=False)
    sources, interval = proposal.get("sources", []), proposal.get("source_span")
    wording, fill = proposal.get("source_wording"), proposal.get("fill")
    if not sources or not isinstance(wording, str) or not isinstance(fill, str) or not (
            isinstance(interval, (list, tuple)) and len(interval) == 2
            and all(type(i) is int for i in interval)):
        result["status"] = "NO_REPLAYABLE_SOURCE_OCCURRENCE"
        return result
    source = sources[0]
    a, b = interval
    start, text = source["start"], source["text"]
    if not start <= a < b <= source["end"] or text[a-start:b-start] != wording:
        result["status"] = "SOURCE_OCCURRENCE_DOES_NOT_REPLAY"
        return result
    result["status"] = "NO_PROVEN_CLIPPED_SHARED_PLURAL"
    if not re.match(r"\s*(?:,|(?:and|or|nor)\b)", text[b-start:], re.I):
        return result
    key = (source["canonical_page_id"], start, source["end"], source["page_sha256"])
    if key not in engine.grammar_sources:
        engine.grammar_sources[key] = engine.parse(text)
    doc = engine.grammar_sources[key]
    part = doc.char_span(a-start, b-start, alignment_mode="strict")
    if part is None:
        result["status"] = "SOURCE_OCCURRENCE_NOT_TOKEN_ALIGNED"
        return result
    tokens = [t for t in part if not t.is_space]
    after = (t for t in doc[part.end:] if not t.is_space)
    connector = next(after, None)
    # Surface adjacency is required: dependency coordination is often attached
    # to the cable's main clause rather than the actual shared-name group.
    if connector is None or not (connector.text == "," or
            connector.lower_ in {"and", "or", "nor"} and connector.pos_ == "CCONJ"):
        return result
    separator, names, coordinated = connector, [], False
    while separator is not None:
        if separator.text == ",":
            separator = next(after, None)
            if separator is None:
                return result
        if separator.lower_ in {"and", "or", "nor"} and separator.pos_ == "CCONJ":
            coordinated = True
            token = next(after, None)
        else:
            token = separator
        group = []
        while token is not None and (token.pos_ == "PROPN" or
                token.text in {"-", "\u2011"} and group):
            group.append(token)
            token = next(after, None)
        if not group or group[-1].pos_ != "PROPN":
            return result
        names.extend(group)
        if coordinated:
            break
        if token is None or not (token.text == "," or
                token.lower_ in {"and", "or", "nor"} and token.pos_ == "CCONJ"):
            return result
        separator = token
    if not coordinated:
        return result
    for i, label in enumerate(tokens[:-1]):
        tail = tokens[i+1:]
        if not label.is_alpha or not any(t.pos_ == "PROPN" for t in tail) or any(
                t.pos_ != "PROPN" and t.text not in {"-", "\u2011"} for t in tail):
            continue
        if not re.search(r"(?<!\w)"+re.escape(label.text)+r"(?!\w)", fill, re.I):
            continue
        lexical = _ordinary_plural_label(label.text, engine)
        if lexical["status"] != "PLURAL_COMMON_NOUN":
            continue
        omitted_start, omitted_end = connector.idx, names[-1].idx+len(names[-1])
        omitted = text[omitted_start:omitted_end]
        right = case["query"].split(case["focal_marker"])[1]
        prefix = r"\s*"+r"\s+".join(re.escape(w) for w in omitted.split())+r"(?!\w)"
        completed_in_context = bool(re.match(prefix, right, re.I))
        result.update(status="SOURCE_COORDINATION_COMPLETED_IN_QUERY" if completed_in_context else
            "CLIPPED_SHARED_PLURAL_SOURCE_LABEL", lexical=deepcopy(lexical),
            proof=dict(canonical_page_id=source["canonical_page_id"], document_id=source["document_id"],
                date=source["date"], page_sha256=source["page_sha256"],
                start=a, end=start+omitted_end, text=text[a-start:omitted_end],
                source_span=[a,b], source_wording=wording,
                plural_label=dict(start=start+label.idx,end=start+label.idx+len(label),text=label.text),
                omitted_conjunct=dict(start=start+omitted_start,end=start+omitted_end,text=omitted)),
            context_supplies_omitted_conjunct=completed_in_context)
        if not completed_in_context:
            result.update(admissible=False, reasons=["CLIPPED_SHARED_PLURAL_SOURCE_LABEL"])
        return result
    return result


def _token_interval(token, offset=0, raw=None):
    text = token.doc.text if raw is None else raw
    return dict(start=offset+token.idx,end=offset+token.idx+len(token),
        text=text[token.idx:token.idx+len(token)],lemma=token.lemma_.casefold(),pos=token.pos_)


def _number_binding(part, *, offset=0, raw=None, query=False):
    """Only an explicit numeric dependency/NER role; never a nearby noun."""
    numbers = [t for t in part if t.like_num]
    value = dict(kind="UNKNOWN",unit=None,numbers=[_token_interval(t,offset,raw) for t in numbers])
    heads = {}
    for number in numbers:
        token, seen = number, set()
        while token.dep_ == "conj" and token.head.like_num and token.i not in seen:
            seen.add(token.i)
            token = token.head
        if (token.dep_ == "nummod" or token.dep_ == "appos" and "Sing" in token.head.morph.get("Number")) and token.head.pos_ in {"NOUN","PROPN"} and token.head not in part:
            heads[token.head.i] = token.head
        elif query and token.dep_ == "compound" and token.head.pos_ == "ADJ" and token.head.dep_ == "amod" and token.head.head.pos_ == "NOUN":
            heads[token.head.head.i] = token.head.head
    head = next(iter(heads.values())) if len(heads) == 1 else None
    if head is not None:
        value["unit"] = _token_interval(head,offset,raw)
    kinds = {"DATE","TIME","MONEY","ORDINAL","PERCENT","QUANTITY"}
    special = ({head.ent_type_} if query and head is not None else
        set() if query else {t.ent_type_ for t in part}) & kinds
    if head is not None and head.ent_type_ in kinds:
        special.add(head.ent_type_)
    group = {t.i for n in numbers for t in (n,*n.conjuncts) if t.like_num}
    dates = [e for e in part.doc.ents if not query and e.label_ == "DATE"
        and any(t.i in group for t in e) and any(not t.like_num and not t.is_punct for t in e)]
    if dates:
        special = {"DATE"}
        value["date_expressions"] = [dict(start=offset+e.start_char,end=offset+e.end_char,text=e.text) for e in dates]
        if head is not None and not any(head in e for e in dates):
            value["unit"] = None
    # A stray DATE annotation on a cardinal with an explicit non-date unit
    # must not turn an actual people/aircraft count into a calendar claim.
    if special == {"DATE"} and not dates and head is not None and head.ent_type_ != "DATE":
        special.clear()
    if len(special) == 1:
        value["kind"] = next(iter(special))
    elif head is not None:
        value["kind"] = "IDENTIFIER" if all(head.idx < t.idx for t in numbers) else "COUNT"
    elif any(any(c.isalpha() for c in t.text) and any(c.isdigit() for c in t.text) for t in part):
        value["kind"] = "IDENTIFIER"
    return value


def _proposal_source_view(proposal, engine):
    sources, interval = proposal.get("sources",[]), proposal.get("source_span")
    if not sources or not isinstance(interval,(list,tuple)) or len(interval) != 2 or not all(type(i) is int for i in interval):
        return None
    source = sources[0]
    a,b = interval
    if not source["start"] <= a < b <= source["end"] or source["text"][a-source["start"]:b-source["start"]] != proposal.get("source_wording"):
        return None
    key = (source["canonical_page_id"],source["start"],source["end"],source["page_sha256"])
    if key not in engine.grammar_sources:
        engine.grammar_sources[key] = engine.parse(source["text"])
    doc = engine.grammar_sources[key]
    part = doc.char_span(a-source["start"],b-source["start"],alignment_mode="strict")
    return source,doc,part


def _adjective_position(word, engine):
    word = word.casefold()
    if word not in engine.adjective_positions:
        value = dict(resource="WordNet",status="UNKNOWN",markers=[])
        try:
            wn = lexicon()
            markers = {l.syntactic_marker().strip("()") for s in wn.synsets(word,pos="a")
                for l in s.lemmas() if l.name() == word and l.syntactic_marker()}
            value.update(status="AVAILABLE",version=wn.get_version(),markers=sorted(markers))
        except LookupError:
            value["status"] = "RESOURCE_UNAVAILABLE"
        engine.adjective_positions[word] = value
    return deepcopy(engine.adjective_positions[word])


def _unit_relation(source, target, engine):
    pair = source["lemma"],target["lemma"]
    if pair[0] == pair[1]:
        return dict(status="COMPATIBLE",basis="LITERAL_UNIT_LEMMA")
    key = pair,source["pos"],target["pos"]
    if key not in engine.quantity_units:
        value = dict(status="UNKNOWN",basis="NO_VERIFIED_ORDINARY_UNIT_RELATION",resource="WordNet")
        try:
            wn = lexicon()
            def ordinary(word):
                return [s for s in wn.synsets(word,pos="n") if not s.instance_hypernyms()
                    and any(l.name().islower() and l.name().replace("_"," ") == word for l in s.lemmas())]
            left,right = ordinary(pair[0]),ordinary(pair[1])
            if left and right and source["pos"] == target["pos"] == "NOUN":
                def nearby(s):
                    direct = s.hypernyms()
                    return set(direct) | {g for h in direct for g in h.hypernyms()}
                links = [dict(source=s.name(),target=t.name()) for s in left for t in right
                    if s == t or s in nearby(t) or t in nearby(s)]
                value.update(status="COMPATIBLE" if links else "DIFFERENT_KNOWN_UNITS",
                    basis="SAME_OR_TWO_EDGE_ORDINARY_NOUN_ANCESTOR",max_hypernym_edges=2,
                    links=links,version=wn.get_version())
        except LookupError:
            value["basis"] = "RESOURCE_UNAVAILABLE"
        engine.quantity_units[key] = value
    return deepcopy(engine.quantity_units[key])


def _verb_object_frames(word, engine):
    """Only exact-lemma WordNet frames; incomplete/mixed valency stays unknown."""
    word = word.casefold()
    if word not in engine.verb_objects:
        value = dict(resource="WordNet",status="UNKNOWN",all_require_direct_object=False,senses=[])
        try:
            from nltk.corpus.reader.wordnet import VERB_FRAME_STRINGS
            wn = lexicon()
            for sense in wn.synsets(word,pos="v"):
                lemmas = [l for l in sense.lemmas() if l.name() == word and l.name().islower()]
                if not lemmas:
                    continue
                ids = sorted({i for l in lemmas for i in l.frame_ids()})
                frames = [VERB_FRAME_STRINGS[i] if 0 < i < len(VERB_FRAME_STRINGS) else None for i in ids]
                value["senses"].append(dict(synset=sense.name(),frame_ids=ids,frames=frames))
            complete = bool(value["senses"]) and all(s["frames"] and all(s["frames"]) for s in value["senses"])
            required = complete and all(re.match(r"^(?:Somebody|Something) %s (?:somebody|something)\b",f)
                for s in value["senses"] for f in s["frames"])
            value.update(status="COMPLETE_FRAMES" if complete else "INCOMPLETE_OR_ABSENT_FRAMES",
                all_require_direct_object=bool(required),version=wn.get_version())
        except LookupError:
            value["status"] = "RESOURCE_UNAVAILABLE"
        engine.verb_objects[word] = value
    return deepcopy(engine.verb_objects[word])


def _construction_constraints(case, reading, proposal, grammar, engine):
    """Source-bound admission only: incompatibility is not factual opposition."""
    result = dict(admissible=True,reasons=[],absence_is_counterevidence=False,
        substantive_support=False,source_modified=False,insertion_edits=[])
    form = reading.get("form")
    if form not in {"modifier","quantity"}:
        return result
    view = _proposal_source_view(proposal,engine)
    if view is not None:
        source,doc,part = view
        result["source_proof"] = {k:deepcopy(source[k]) for k in
            ("canonical_page_id","document_id","date","page_sha256","start","end","text")}
        result["source_proof"].update(source_span=deepcopy(proposal["source_span"]),source_wording=proposal["source_wording"])
    if form == "quantity":
        target = grammar.get("quantity_binding",dict(kind="UNKNOWN",unit=None))
        owned = dict(kind="UNKNOWN",unit=None)
        if view is not None:
            if part is None:
                a,b = proposal["source_span"]
                expanded = doc.char_span(a-source["start"],b-source["start"],alignment_mode="expand")
                if expanded is not None and any(any(c.isalpha() for c in t.text) and
                        any(c.isdigit() for c in t.text) for t in expanded):
                    owned.update(kind="IDENTIFIER",token_text=expanded.text)
            else:
                owned = _number_binding(part,offset=source["start"])
        relation = dict(status="UNKNOWN",basis="UNRESOLVED_SOURCE_OR_QUERY_CARRIER")
        if owned["kind"] != "UNKNOWN" and target["kind"] != "UNKNOWN":
            if owned["kind"] != target["kind"]:
                relation = dict(status="INCOMPATIBLE_NUMERIC_ROLE",basis="SOURCE_AND_QUERY_NUMERIC_ROLES_DIFFER")
            elif owned["unit"] is not None and target["unit"] is not None:
                relation = _unit_relation(owned["unit"],target["unit"],engine)
        result["quantity"] = dict(source=owned,query=target,relation=relation,
            event_identity_certified=False,event_date_from_publication=False)
        if relation["status"] in {"INCOMPATIBLE_NUMERIC_ROLE","DIFFERENT_KNOWN_UNITS"}:
            result["reasons"].append("SOURCE_QUANTITY_ROLE_OR_UNIT_INCOMPATIBLE")
    elif grammar.get("postnominal_modifier"):
        post_usage, clipped = False, []
        if view is not None and part is not None:
            head = part.root
            post_usage = (head.pos_ == "ADJ" and head.dep_ in {"amod","acl"}
                and head.head.pos_ in {"NOUN","PROPN"} and head.head.idx < head.idx and head.head not in part)
            for child in head.children:
                if child.dep_ not in {"prep","dobj","obj","xcomp"}:
                    continue
                subtree = list(child.subtree)
                a,b = min(t.idx for t in subtree),max(t.idx+len(t) for t in subtree)
                if part.start_char <= a and b <= part.end_char:
                    continue
                quote = source["text"][a:b]
                right = case["query"].split(case["focal_marker"])[1]
                pattern = r"\s*"+r"\s+".join(re.escape(w) for w in quote.split())+r"(?!\w)"
                if not re.match(pattern,right,re.I):
                    clipped.append(dict(start=source["start"]+a,end=source["start"]+b,text=quote,dependency=child.dep_))
            # Some source trees misread a gerund's object as its noun carrier.
            # Surface adjacency alone is insufficient (e.g. running officials).
            if (head.pos_ == grammar["head_pos"] == "VERB"
                    and head.tag_ == grammar.get("head_tag") == "VBG" and head.dep_ == "amod"
                    and head.head.pos_ == "NOUN" and head.head.idx >= part.end_char
                    and head.lemma_.casefold() == grammar["head_lemma"].casefold()
                    and not grammar.get("completed_modifier_object")):
                tail = doc[part.end:head.head.i+1]
                if tail and all(t.pos_ in {"NOUN","PROPN","ADJ","DET","NUM"} or t.is_space for t in tail):
                    valency = _verb_object_frames(head.lemma_,engine)
                    result["verb_object_frames"] = valency
                    if valency["all_require_direct_object"]:
                        result["reasons"].append("CLIPPED_SOURCE_VBG_NOMINAL_ALL_FRAMES_REQUIRE_OBJECT")
                        result["clipped_source_nominal"] = dict(start=source["start"]+tail.start_char,
                            end=source["start"]+tail.end_char,text=tail.text,
                            parser_dependency="PRENOMINAL_AMOD_NOT_OBJECT_CERTIFICATE")
        marker = _adjective_position(grammar["head_lemma"],engine) if grammar["head_pos"] == "ADJ" else None
        licensed = bool(grammar.get("completed_modifier_complement") or post_usage or
            marker and set(marker["markers"]) & {"p","ip"})
        result["postnominal"] = dict(own_source_postnominal_usage=post_usage,
            completed_visible_complement=grammar.get("completed_modifier_complement",False),
            lexical=marker,clipped_source_complements=clipped)
        if clipped:
            result["reasons"].append("CLIPPED_SOURCE_MODIFIER_COMPLEMENT")
        if grammar["head_pos"] == "ADJ" and not licensed:
            result["reasons"].append("UNLICENSED_BARE_POSTNOMINAL_ADJECTIVE")
    result["admissible"] = not result["reasons"]
    return result


def _focal_frames(case, fill, engine, bounds=None):
    left, right = case["query"].split(case["focal_marker"])
    start, end = bounds or _focal_sentence_bounds(case, engine.parse)
    text = case["query"][start:len(left)] + fill + case["query"][len(left)+len(case["focal_marker"]):end]
    a, b = len(left)-start, len(left)-start+len(fill)
    # Other masked sentences are not part of this slot's claim. Replacing
    # masks with equal-length whitespace is analysis-only, preserving offsets.
    visible = MASK.sub(lambda m:" " * len(m.group()), text)
    sentences = [s for s in engine.parse(visible).sents if s.start_char < b and a < s.end_char]
    if not sentences:
        return [], "NO_FOCAL_SENTENCE"
    start, end = sentences[0].start_char, sentences[-1].end_char
    text, a, b = text[start:end], a-start, b-start
    if MASK.search(text):
        return [], "UNKNOWN_MASK_IN_REQUIRED_FOCAL_CLAIM"
    doc = engine.parse(text)
    properties = []
    for token in doc:
        if not a <= token.idx < b or token.pos_ not in {"ADJ", "VERB"}:
            continue
        carrier = token.head
        if token.dep_ not in {"amod", "acl"} or carrier.pos_ not in {"NOUN", "PROPN"} or a <= carrier.idx < b:
            continue
        owner = base.matching.phrase(carrier)
        removed = {p["lemma"] for p in owner["proofs"] if a < p["end"] and p["start"] < b}
        owner["proofs"] = [p for p in owner["proofs"] if not a < p["end"] or not p["start"] < b]
        for key in ("terms", "names", "descriptive_terms", "role_qualifiers"):
            owner[key] = [w for w in owner.get(key, []) if w not in removed]
        owner["text"] = " ".join(p["text"] for p in owner["proofs"])
        properties.append(dict(kind="PROPERTY", predicate=base.matching.lemma(token),
            predicate_proof=base.matching.proof(token), predicate_phrase=base.matching.phrase(token),
            copula=None, roles=dict(owner=[owner]), qualifiers=base.matching.qualifiers(token),
            event_dates=[], passive=False, unbound_arguments=[],
            deictic_time=_attached_deictics(token),
            start=carrier.sent.start_char, end=carrier.sent.end_char, quote=carrier.sent.text))
    if properties:
        return properties, "FOCAL_PROPERTY_ONLY_NOT_SURROUNDING_EVENT"
    frames = []
    for f in engine.targets(text):
        proofs = [f["predicate_proof"]] + [p for values in f["roles"].values()
            for phrase in values for _, p in _proofs(phrase)]
        if any(a < p["end"] and p["start"] < b for p in proofs):
            frames.append(f)
    return frames, "FOCAL_STRUCTURED_REQUIREMENTS" if frames else "NO_FOCAL_FRAME"


def _proofs(phrase):
    for p in phrase["proofs"]:
        yield None, p
    for item in phrase.get("modifiers", []):
        yield from _proofs(item["phrase"])


def _assessment_sources(case, citations, engine):
    from .source_view_policy import policy_of, time_origin_allowed
    index = {}
    for citation in citations:
        date.fromisoformat(citation["date"])
        if not time_origin_allowed(citation, case, policy_of(engine)):
            raise ValueError("Ineligible candidate source citation")
        if (type(citation["start"]) is not int or type(citation["end"]) is not int
                or citation["start"] < 0 or citation["end"]-citation["start"] != len(citation["text"])):
            raise ValueError("Candidate source quote offsets do not replay")
        for source in engine.frames(citation["text"]):
            if not MASK.search(source["quote"]):
                index.setdefault(source["predicate"], []).append((citation, source))
    return index


def _support_assessment(case, candidate, engine, *, source_index=None, bounds=None):
    assessment = dict(status="Inferred", scope="FOCAL_CONTRIBUTION_ONLY",
        substantive_support=False, supports_completed_slot=False, supports_whole_event=False,
        partial_clue=candidate.get("support") == "LOCAL_PROPERTY_ATTESTED",
        absence_is_counterevidence=False, evidence=[], source_integrity="CALLER_REPLAYS_FULL_SOURCE_PAGES")
    targets, reason = _focal_frames(case, candidate["fill"], engine, bounds)
    assessment["reason"] = reason
    if not targets:
        return assessment
    source_index = source_index if source_index is not None else _assessment_sources(case, candidate.get("sources", []), engine)
    states = []
    for target in targets:
        records = []
        for citation, source in source_index.get(target["predicate"], []):
                match = compare_frames(target, source, engine=engine)
                if match is None:
                    continue
                local = span(citation["text"], source["start"], source["end"])
                proof = dict(citation, start=citation["start"]+local["start"],
                    end=citation["start"]+local["end"], text=local["text"])
                if match["direction"] in {"SUPPORT", "COUNTER", "PARTIAL"}:
                    records.append(dict(direction=match["direction"], diagnostics=match["diagnostics"],
                        citation=proof, reasons=match["reasons"]))
        states.append(base._status(r["direction"] for r in records))
        assessment["evidence"].extend(records)
    if states and all(s == "SUPPORT" for s in states):
        assessment.update(status="Supported", substantive_support=True, supports_completed_slot=True,
            reason="ALL_FOCAL_STRUCTURED_REQUIREMENTS_SOURCE_SUPPORTED")
        assessment["scope"] = "FOCAL_PROPERTY_ONLY" if all(f["kind"] == "PROPERTY" for f in targets) else "FOCAL_CONTRIBUTION_ONLY"
        assessment["supports_whole_event"] = all(f["kind"] == "EVENT" for f in targets)
    else:
        assessment["reason"] = "FOCAL_EVENT_OR_PROPERTY_NOT_ESTABLISHED"
    assessment["same_scoped_counterevidence"] = any(e["direction"] == "COUNTER" for e in assessment["evidence"])
    if assessment["same_scoped_counterevidence"]:
        assessment["reason"] = "EXPLICIT_COUNTEREVIDENCE_TO_FOCAL_REQUIREMENT"
    return assessment


def filter_redaction(case, result, top_k=5):
    """Filter the entire ranked audit pool before dedup/shortlist; never pad it."""
    from .candidates_v24 import display_selection
    case = public_case(case)
    if case["task"] != "redaction" or type(top_k) is not int or not 1 <= top_k <= 5:
        raise ValueError("A redaction case and a one-to-five display budget are required")
    audit = result.get("_candidate_audit")
    if not audit or "v21" not in audit:
        raise ValueError("FULL_POOL_AUDIT_REQUIRED: cannot filter only a saved top-five list")
    if audit.get("keys_read") is not False or audit.get("grades_read") is not False:
        raise ValueError("Private evaluation artifacts are not inference inputs")
    with offline():
        engine = _Engine()
        bounds = _focal_sentence_bounds(case, engine.parse)
        grammar_cache = {}
        output = deepcopy(result)
        ledgers = []
        rows = audit["readings"]
        scores = audit["v21"]["readings"]
        if len(rows) != len(scores) or len(rows) != len(output["readings"]):
            raise ValueError("Candidate reading/audit shape changed")
        citations = {}
        for row in rows:
            for p in row["proposals"]:
                for source in p.get("sources", []):
                    key = (source["canonical_page_id"],source["start"],source["end"],source["page_sha256"])
                    normalized = {k:source[k] for k in ("canonical_page_id","document_id","date",
                        "start","end","text","page_sha256")}
                    if key in citations and citations[key] != normalized:
                        raise ValueError("Candidate source citation changed")
                    citations[key] = normalized
        source_index = _assessment_sources(case, citations.values(), engine)
        for raw, ledger, view in zip(rows, scores, output["readings"]):
            pool, features = raw["proposals"], ledger["all_features"]
            if raw["reading"]["id"] != ledger["reading_id"] or raw["reading"] != view["reading"] or len(pool) != len(features):
                raise ValueError("Candidate reading/feature binding changed")
            order = ledger["ranked_pool_indices"]
            if len(order) != len(set(order)) or any(type(i) is not int or not 0 <= i < len(pool) for i in order):
                raise ValueError("Invalid complete candidate rank order")
            if set(order) != {i for i,x in enumerate(features) if x["joint_fit"]["admissible"]}:
                raise ValueError("Rank order must contain the complete admissible pool")
            accepted, rejected, admissions = [], [], []
            for i,p in enumerate(pool):
                f = features[i]
                if f["pool_index"] != i or f["candidate_id"] != p["id"]:
                    raise ValueError("Candidate feature identity changed")
                key = (raw["reading"].get("form","unknown"),p["fill"])
                if key not in grammar_cache:
                    grammar_cache[key] = _grammar_admission(case, raw["reading"], p["fill"], engine.parse, bounds)
                grammar = grammar_cache[key]
                if grammar["admissible"]:
                    source_grammar = _source_grammar_admission(case, p, engine)
                    constraints = _construction_constraints(case,raw["reading"],p,grammar,engine)
                    grammar = dict(grammar, source_bound_admission=source_grammar,
                        source_constraints=constraints,
                        reasons=grammar["reasons"]+source_grammar["reasons"]+constraints["reasons"],
                        admissible=source_grammar["admissible"] and constraints["admissible"])
                admissions.append(grammar)
                if grammar["admissible"] and f["joint_fit"]["admissible"]:
                    accepted.append(i)
                elif not grammar["admissible"]:
                    rejected.append(dict(pool_index=i, candidate_id=p["id"], grammar=grammar,
                        sources=deepcopy(p.get("sources", []))))
            eligible = set(accepted)
            kept, suppressed = display_selection(pool, features, [i for i in order if i in eligible])
            old = {p["id"]:p for p in view["candidates"]}
            displayed, displayed_indices, counters = [], [], []
            for i in kept:
                p = deepcopy(old.get(pool[i]["id"], pool[i]))
                assessment = _support_assessment(case, p, engine, source_index=source_index, bounds=bounds)
                if assessment.get("same_scoped_counterevidence"):
                    counters.append(dict(pool_index=i,candidate_id=p["id"],support_assessment=assessment,
                        reason="EXPLICIT_SCOPED_COUNTEREVIDENCE_NOT_MISSING_SUPPORT"))
                    continue
                p.update(rank=len(displayed)+1, v21_features=deepcopy(features[i]["features"]),
                    v21_joint_fit=deepcopy(features[i]["joint_fit"]),
                    grammar_admission=deepcopy(admissions[i]),
                    support_assessment=assessment)
                displayed.append(p)
                displayed_indices.append(i)
                if len(displayed) == top_k:
                    break
            view.update(candidates=displayed, exploratory_candidates=deepcopy(displayed),
                evidence_candidates=[deepcopy(p) for p in displayed if p["support_assessment"]["substantive_support"]],
                generated_proposals=len(pool), grammar_rejections=len(rejected))
            ledgers.append(dict(reading_id=raw["reading"]["id"], raw_pool_size=len(pool),
                grammar_rejections=rejected, accepted_ranked_pool_indices=[i for i in order if i in eligible],
                displayed_pool_indices=displayed_indices, display_suppressions=suppressed,
                counterevidence_rejections=counters,
                pool_capped_before_filter=False, synthetic_padding_added=False))
        output["_candidate_audit"]["task_execution_v3"] = dict(readings=ledgers, keys_read=False, grades_read=False)
        output["task_execution_v3"] = dict(version=VERSION, api_calls=0, full_pool_filtered=True,
            raw_proposals_retained=True, synthetic_padding_added=False,
            grammar_rejections=sum(len(x["grammar_rejections"]) for x in ledgers),
            counterevidence_rejections=sum(len(x["counterevidence_rejections"]) for x in ledgers),
            grammar_unique_fills_checked=len(grammar_cache), focal_context=dict(start=bounds[0],end=bounds[1],
                text=case["query"][bounds[0]:bounds[1]],query_sha256=digest(case["query"])),
            support_meaning="Structured support for focal contribution; vocabulary/role overlap alone is Inferred")
        return output
