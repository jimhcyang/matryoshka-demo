"""Versioned presentation/assessment joins; native checkpoints stay unchanged."""
from collections import Counter,defaultdict
from copy import deepcopy
from pathlib import Path

from .api_v2 import Budget
from .assessment_v2 import prepare,assess,verify_saved,task_sources
from .assessment_replay_v23 import VERSION as REPLAY_VERSION
from .integrity import verify_auxiliary,verify_sources
from .io import digest,load,save,sha
from .runner import checked,load_inputs
from .runner_v2 import verify_record,verify_release_references,VERSION


def verified_run(root,run_directory=None):
    root=Path(root).resolve()
    directory=Path(run_directory or load(root/"data/latest_run_v2.json")["directory"]).resolve()
    if not directory.is_relative_to(root/"data/runs_v2"):raise ValueError("Unbound v2 run directory")
    manifest=load(directory/"manifest.json");progress=load(directory/"progress.json")
    run_id="demo_v2_"+digest(manifest)[:20]
    if directory.name!=run_id or manifest["version"]!=VERSION:raise ValueError("Frozen run identity changed")
    release=manifest["plan_release"];cases=release["cases"];arms=manifest["settings"]["arms"]
    verify_release_references(root,release)
    expected={c["case_id"]+"__"+a+".json" for c in cases for a in arms}
    if (progress["status"]!="COMPLETE" or progress["completed"]!=len(expected) or progress["expected"]!=len(expected)
            or progress["failures"] or {p.name for p in (directory/"cases").glob("*.json")}!=expected):
        raise ValueError("Reporting requires every exact condition complete with zero active failures")
    binding=load(root/"data/bindings.json")
    if binding["sha256"]!=manifest["binding_sha256"]:raise ValueError("Run source binding changed")
    verify_sources(root.parent,binding,{c["corpus"] for c in cases});cache={};grouped={}
    for case in cases:
        records={}
        for arm in arms:
            plan_ref=release["plans"][case["case_id"]+"__"+("llm_leads" if arm=="legacy_reference" else arm)]
            path=(root/plan_ref["path"]).resolve()
            if not path.is_relative_to(root/"data/development_v2/plans") or sha(path)!=plan_ref["sha256"]:raise ValueError("Frozen plan changed")
            plan=load(path)["plan"];record=checked(directory/"cases"/(case["case_id"]+"__"+arm+".json"))
            verify_record(record,case,arm,run_id,binding["sha256"],plan);verify_auxiliary(directory,record,cache)
            records[arm]=record
        grouped[case["case_id"]]=records
    return directory,manifest,grouped,binding


def assessment_keys(root,manifest):
    release=manifest["plan_release"];ref=release["assessment_release_ref"];path=(root/ref["path"]).resolve()
    if not path.is_relative_to(root/"data") or sha(path)!=ref["sha256"]:raise ValueError("Assessment release changed")
    value=load(path)
    if (digest({k:v for k,v in value.items() if k!="sha256"})!=value["sha256"]
            or value["public_inputs_sha256"]!=release["catalog_sha256"]):raise ValueError("Assessment/public population mismatch")
    path=path.parent/"evaluation_keys.json"
    if sha(path)!=value["evaluation_keys_sha256"]:raise ValueError("Evaluation keys changed")
    return load(path)


def grade_run(root,run_directory=None,*,execute=False,cap=25.):
    root=Path(root).resolve();directory,manifest,grouped,_=verified_run(root,run_directory)
    keys=assessment_keys(root,manifest);count=0
    for case in manifest["plan_release"]["cases"]:
        records={a:r for a,r in grouped[case["case_id"]].items() if a!="legacy_reference"}
        packet,mapping=prepare(case,records,keys.get(case["case_id"],{}).get("answer",""));count+=len(packet["items"])
        if not execute:continue
        result=assess(root/"data/development_v2/api",packet,cap=cap)
        output=dict(case_id=case["case_id"],packet=packet,assessment=result,
            mapping=[dict(condition=list(k),item_id=v) for k,v in mapping.items()])
        output["sha256"]=digest(output)
        save(directory/"assessments"/(case["case_id"]+".json"),output)
        print("Assessed",case["case_id"],len(packet["items"]),"distinct saved packets",flush=True)
    return dict(cases=len(grouped),unique_items=count,executed=execute,charged_or_reserved_usd=Budget(root/"data/development_v2/api").total())


def report(root,run_directory=None):
    root=Path(root).resolve();directory,manifest,grouped,binding=verified_run(root,run_directory)
    keys=assessment_keys(root,manifest);cases=[];summary=defaultdict(Counter)
    for case in manifest["plan_release"]["cases"]:
        records=deepcopy(grouped[case["case_id"]]);path=directory/"assessments"/(case["case_id"]+".json")
        assessed=False;replay_ref=None
        if path.exists():
            saved=load(path)
            if digest({k:v for k,v in saved.items() if k!="sha256"})!=saved["sha256"]:raise ValueError("Saved assessment changed")
            packet,mapping=prepare(case,{a:r for a,r in records.items() if a!="legacy_reference"},keys.get(case["case_id"],{}).get("answer",""))
            if packet!=saved["packet"] or saved["assessment"]["packet_sha256"]!=digest(packet):raise ValueError("Assessment packet does not match native results")
            replay=verify_saved(root/"data/development_v2/api",packet,saved["assessment"])
            replay_path=directory/"assessment_replays"/(case["case_id"]+"__"+digest(replay)[:16]+".json")
            if replay_path.exists() and load(replay_path)!=replay:raise ValueError("Assessment replay audit changed")
            if not replay_path.exists():save(replay_path,replay)
            replay_ref=dict(path=str(replay_path.relative_to(root)),sha256=sha(replay_path),version=replay["version"])
            grades={g["id"]:g for g in saved["assessment"]["grades"]}
            if len(grades)!=len(saved["assessment"]["grades"]) or set(grades)!={i["id"] for i in packet["items"]}:raise ValueError("Assessment grade set changed")
            for arm,record in records.items():
                if arm=="legacy_reference":continue
                record["assessment"]=dict(status="ASSESSED_POST_RUN",independent_human_validation=False,
                    packet_sha256=digest(packet),used_for_inference=False)
                if case["task"]=="redaction":
                    for reading in record["result"]["readings"]:
                        for candidate in reading["candidates"]:
                            candidate["assessment"]=grades[mapping[arm,reading["reading"]["id"],candidate["id"]]]
                else:
                    for atom in record["result"]["atoms"]:
                        atom["assessment"]=grades[mapping[arm,atom["id"]]]
                        atom["assessment_source_mapping"]={"S"+str(i):s for i,s in enumerate(task_sources(atom),1)}
            assessed=True
        for arm,record in records.items():
            summary[arm]["cases"]+=1;summary[arm]["runtime_seconds"]+=record["runtime_seconds"]
            if arm=="legacy_reference":continue
            result=record["result"]
            if case["task"]=="redaction":
                summary[arm]["redaction_cases"]+=1
                displayed=[p for r in result["readings"] for p in r["candidates"]]
                summary[arm]["displayed_candidates"]+=len(displayed)
                summary[arm]["readings"]+=len(result["readings"])
                if assessed:
                    summary[arm]["assessed_redaction_cases"]+=1
                    summary[arm]["grammatical_displayed_candidates"]+=sum(p["assessment"]["grammatical"] is True for p in displayed)
                    for k in (1,3,5):
                        grades=[p["assessment"] for r in result["readings"] for p in r["candidates"][:k]]
                        summary[arm][f"correct_any_reading_at_{k}"]+=any(g["answer_match"]=="correct" for g in grades)
                        summary[arm][f"partial_any_reading_at_{k}"]+=any(g["answer_match"]=="partial" for g in grades)
                        summary[arm][f"supported_correct_any_reading_at_{k}"]+=any(g["answer_match"]=="correct" and g["evidence_support"] in {"direct","partial"} for g in grades)
            else:
                summary[arm]["native_"+result["status"]]+=1
                if assessed:
                    for atom in result["atoms"]:
                        summary[arm]["assessed_atoms"]+=1;summary[arm]["judgment_"+atom["assessment"]["judgment"]]+=1
        for arm,record in records.items():
            checkpoint=directory/"cases"/(case["case_id"]+"__"+arm+".json")
            record["native_checkpoint"]=dict(path=str(checkpoint.relative_to(root)),sha256=sha(checkpoint))
            slim_for_browser(record["result"])
        cases.append(dict(case=case,reference_answer=keys.get(case["case_id"],{}).get("answer"),
            reference_answer_kind=keys.get(case["case_id"],{}).get("kind","complete_source_derived_question"),
            configurations=records,selected_demo=True,assessment_available=assessed,assessment_replay_ref=replay_ref))
    indexes={name:load(directory/(name+"_graph_index.json")) for name in {c["case"]["corpus"] for c in cases}
        if (directory/(name+"_graph_index.json")).exists()}
    cases=publish_case_details(root,directory,cases)
    output=dict(version="three-task-inspection-report/2.3",run_id=directory.name,cases=cases,
        source_base_v2="/sources-v2",source_directory_v2=str((directory/"sources").relative_to(root)),source_binding=binding,
        graph_indexes=indexes,api_cost_usd=Budget(root/"data/development_v2/api").total(),summary=dict(summary),
        control_metadata=dict(settings=manifest["settings"],population="Outcome-informed development/presentation palette, not an unbiased benchmark",
            oracle_development=True,upstream_extraction_alias_graph_unchanged=True,
            rank_metrics="Per-reading top1/3/5; any-reading totals have different display budgets when reading counts differ",
            partial_metrics="Partial and correct are distinct judgments; any-reading case counts may overlap",
            native_and_grade_separate=True,assessment_verifier_version=REPLAY_VERSION,
            replay_guarantee="Local request/receipt/raw-response/grade consistency, not provider-authenticated provenance",
            reference="Actual original engines, same arm1 source snapshot, original query preflight; not an end-to-end retrieval baseline"))
    output["sha256"]=digest(output);save(directory/"inspection_report.json",output);save(root/"web/data/report-v2.json",output)
    return dict(run_id=directory.name,cases=len(cases),assessed=sum(c["assessment_available"] for c in cases),summary=dict(summary),
        charged_or_reserved_usd=output["api_cost_usd"],url="http://127.0.0.1:8930/")


def slim_for_browser(result):
    """A bounded presentation projection; accepted native files remain intact."""
    omissions={}
    for atom in result.get("atoms",[]):
        rows=atom.get("evidence",[])
        if len(rows)>12:
            atom["evidence"]=rows[:12];atom["presentation_omitted_evidence"]=len(rows)-12
    for key in ("hypothesis","reconstruction"):
        task=result.get(key,{})
        for field in ("alternatives","alternative_interpretations","exploratory_components","exploratory_account","exploratory_source_cited_account","discriminating_evidence_questions","retrieved_source_accounts"):
            rows=task.get(field)
            if isinstance(rows,list) and len(rows)>12:
                task[field]=rows[:12];omissions[key+"."+field]=len(rows)-12
    for container in (result,result.get("marker_adapted_reference",{})):
        if "matching_diagnostics" in container:
            container["matching_diagnostics"]={"presentation":"Full original-engine diagnostic tables remain in the immutable native checkpoint"}
        diffusion=container.get("retrieval",{}).get("diffusion",{})
        groups=diffusion.get("metadata",{}).get("groups",[])
        if len(groups)>40:
            visible={s["index"] for frame in diffusion.get("snapshots",[]) for s in frame.get("states",[])}
            retained=[g for g in groups if g["index"] in visible]
            diffusion["metadata"]["groups"]=retained
            diffusion["metadata"]["omitted_group_metadata_count"]=len(groups)-len(retained)
    result["presentation_projection"]=dict(version="bounded-inspection/1",omitted_lists=omissions,
        full_native_retained=True,visible_diffusion_values_unchanged=True)


def publish_case_details(root,directory,cases):
    """Keep the landing index small; selected-case details load on demand."""
    rows=[]
    for row in cases:
        name=directory.name+"__"+row["case"]["case_id"]+"__"+digest(row)[:16]+".json"
        path=root/"web/data/report-v2-cases"/name
        if path.exists() and load(path)!=row:raise ValueError("Published case detail changed")
        if not path.exists():save(path,row)
        stub={k:v for k,v in row.items() if k!="configurations"}
        stub["case_detail_ref"]=dict(path=str(path.relative_to(root)),sha256=sha(path))
        stub["configurations"]={arm:dict(config=arm,native_checkpoint=record["native_checkpoint"],
            runtime_seconds=record["runtime_seconds"],
            result=dict(status=record["result"].get("status","SAVED_NATIVE_OUTPUT"),evaluated=True))
            for arm,record in row["configurations"].items()}
        rows.append(stub)
    return rows
