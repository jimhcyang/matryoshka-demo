"""Source-only admission and predeclared demonstration sampling, not a benchmark."""
from collections import Counter
from pathlib import Path
import re

from .contracts import MASK, public_case
from .io import digest, load, rows, save, sha
from .planning import sentences


VERSION = "demo-source-admission/1"
# Chosen from source texts for contrasting linguistic/evidence requirements,
# before this prototype's retrieval was run. No legacy scores are consulted.
SELECTION = {
    "iran": {
        "reconstruction": ["workbench_candidate_01d2a7ee803997c96c", "workbench_candidate_349c6455c513ccd0d2"],
        "hypothesis": ["workbench_candidate_06f782f9fec76dd222", "workbench_candidate_1e79683d1cba8d1963"],
        "redaction": ["workbench_candidate_09cf60900e5e75fd78"],
    },
    "vietnam": {
        "reconstruction": ["workbench_candidate_09a21fa73adad9ea62", "workbench_candidate_0ac713a63105b28e80"],
        "hypothesis": ["workbench_candidate_013740be6026ca7102", "workbench_candidate_147759d84864274191"],
        "redaction": ["workbench_candidate_0bf9a41c1600788011"],
    },
    "cib": {
        "redaction": ["cloze_58515686f17296d84522d1ca", "cloze_bf6b67a66a3956b2d8fde879", "cloze_58e8550212498c5d863f8883"],
        "hypothesis": ["hypothesis_cloze_82d792a764fe12c3318c18b6"],
        "reconstruction": ["reconstruction_cloze_587d6f99570ab695a52ba24e"],
    },
}


def find_folded(text, fragment):
    parts = fragment.split()
    # OCR line-wrap hyphenation is reversible: keep the entire literal span
    # as the key and proof, rather than silently replacing source characters.
    def token(word):
        return r"(?:-\s+)?".join(re.escape(c) for c in word)
    match = re.search(r"\s+".join(token(w) for w in parts), text, re.I) if parts else None
    return (match.start(), match.end()) if match else None


def sentence_window(text, interval):
    units = list(sentences(text))
    hits = [i for i, u in enumerate(units) if u["start"] <= interval[0] < u["end"]]
    if not hits:
        raise ValueError("Hidden phrase is not attached to a source sentence")
    i = hits[0]
    # At least the complete focal sentence; adjacent sentences provide both
    # sides without importing an unrelated preceding topical section.
    a = units[max(0, i-1)]["start"]; b = units[min(len(units)-1, i+1)]["end"]
    return text[a:interval[0]] + "[REDACTION 1]" + text[interval[1]:b]


def informative(answer):
    if MASK.search(answer) or not re.search(r"[A-Za-z0-9]", answer):
        return False
    # Reject pure connectives, not short factual quantities or uppercase names.
    return answer.strip().casefold() not in {"and", "or", "but", "of", "the", "a", "an", "to", "in", "on", "by"}


def public_release(factory):
    """Only masked/public task inputs; no admission proofs or source metadata."""
    packet=dict(version="public-demo-inputs/1",factory_sha256=factory["sha256"],
        binding_sha256=factory["binding_sha256"],cases=[public_case(c) for c in factory["cases"]],
        controls=[public_case(c) for c in factory["controls"]])
    packet["sha256"]=digest(packet)
    return packet


def build(workspace, binding, destination):
    workspace = Path(workspace); destination = Path(destination)
    cases = []; gold = {}; audit = []; source_pins = {}; metadata = {}
    for corpus in ("iran", "vietnam"):
        root = workspace / "src-redaction/data/corpora" / corpus
        path = root / "workbench/master_candidates.jsonl"
        source_pins[str(path.relative_to(workspace))] = sha(path)
        segments = {r["segment_id"]: r for r in rows(workspace / binding["corpora"][corpus]["files"]["pages"]["path"])}
        projection = load(workspace / binding["corpora"][corpus]["files"]["projection"]["path"])["document_metadata"]
        for r in rows(path):
            reason = None; segment = segments.get(r["segment_id"]); query = r["query"]; proof = None
            if not segment or segment["document_id"] != r["document_id"]:
                reason = "source_segment_missing_or_document_mismatch"
            elif projection.get(r["document_id"], {}).get("policy_role") != "secret_expansion":
                reason = "not_a_certified_secret_query_origin"
            elif not re.fullmatch(r"\d{4}-\d{2}-\d{2}", r.get("document_date_iso", "")):
                reason = "missing_source_date"
            elif r["task"] == "redaction":
                answer = r.get("redaction_answer") or r.get("answer", "")
                interval = find_folded(segment["text"], answer)
                if not informative(answer): reason = "noninformative_or_masked_key"
                elif not interval: reason = "hidden_phrase_not_verbatim_in_prepared_source"
                else:
                    query = sentence_window(segment["text"], interval)
                    answer = segment["text"][slice(*interval)]
                    proof = dict(start=interval[0], end=interval[1], text=answer)
                    gold[r["id"]] = dict(answer=answer, kind="synthetic_source_span")
            elif MASK.search(query) or len(query.split()) < 5 or not re.search(r"[.!?]$", query):
                reason = "incomplete_proposition"
            row = dict(case_id=r["id"], corpus=corpus, task=r["task"], admitted=reason is None,
                reason=reason or "source_bound_demonstration_proposal", original_query_sha256=digest(r["query"]),
                query_sha256=digest(query), membership_selected=False,
                source_text_sha256=digest(segment["text"]) if segment else None,
                semantic_faithfulness_human_certified=False)
            audit.append(row)
            if reason: continue
            case = dict(case_id=r["id"], corpus=corpus, task=r["task"], query=query,
                document_id=r["document_id"], date=r["document_date_iso"],
                focal_marker="[REDACTION 1]" if r["task"] == "redaction" else "")
            cases.append(public_case(case))
            metadata[r["id"]] = dict(source_id=r["segment_id"], source_text_sha256=digest(segment["text"]),
                source_title=r.get("document_title"), source_kind="secret_cable",
                span=proof, origin_classification=projection[r["document_id"]]["classification"],
                query_construction="verbatim_source_window" if proof else "inherited_source_derived_proposition",
                exposure="EXPOSED_DEVELOPMENT_DEMO_NOT_HELD_OUT")
    # Only source fields of the CIB population archive are read here, never
    # old candidates, grades, planned terms, or answer-aware traversal results.
    source_path = workspace / "matryoshka_redaction/data/preflight_v2/population/proposed_population.jsonl"
    source_pins[str(source_path.relative_to(workspace))] = sha(source_path)
    origins = {r["case_id"]: r for r in rows(source_path)}
    pages = {r["canonical_page_id"]: r for r in rows(workspace / binding["corpora"]["cib"]["files"]["pages"]["path"])}
    for cid in SELECTION["cib"]["redaction"]:
        r = origins[cid]; page = pages[r["canonical_page_id"]]
        pieces = []; answer = None
        for unit in page["units"]:
            if unit["unit_type"] == "shared_text": pieces.append(unit["text"])
            elif r["parent_slot_id"] in unit.get("slot_ids", []):
                if unit.get("reveal_states") != ["revealed"] or not informative(unit.get("later_visible_text", "")):
                    raise ValueError("Selected CIB span is not genuinely revealed")
                answer = unit["later_visible_text"]; pieces.append("[REDACTION 1]")
            else: pieces.append("[REDACTED]")
        if answer is None or answer != r["answer"]:
            raise ValueError("Selected CIB key does not match current prepared span")
        query = "".join(pieces).strip()
        # Use complete body paragraphs and omit the source heading, not words
        # merely because they are uppercase. This is a wording change only.
        blocks = query.split("\n\n")
        if len(blocks) > 1 and not re.search(r"[.!?]", blocks[0]) and len(blocks[0].split()) < 16:
            query = "\n\n".join(blocks[1:])
        case = public_case(dict(case_id=cid, corpus="cib", task="redaction", query=query,
            document_id=r["document_id"], date=r["date"], focal_marker="[REDACTION 1]"))
        cases.append(case); gold[cid] = dict(answer=answer, kind="paired_earlier_redacted_later_revealed")
        metadata[cid] = dict(source_id=page["canonical_page_id"], source_text_sha256=digest(page),
            earlier_page=page["earlier_source_page"], later_page=page["later_source_page"],
            paired_pdf=r["paired_pdf"], query_construction="current_prepared_earlier_masked_page",
            exposure="USER_REQUESTED_ANSWER_EXPOSED_REGRESSION_CASE")
        audit.append(dict(case_id=cid, corpus="cib", task="redaction", admitted=True,
            reason="verified_current_paired_reveal", source_text_sha256=digest(page), membership_selected=True))
    query_dir = workspace / "src-redaction/data/analyst_tasks/source_focus_v9/queries"
    query_files = sorted(query_dir.glob("*.json"))
    # Select by topic, not result. IDs are resolved by their declared origin
    # prefix because legacy filenames use full hashes not display labels.
    topics = {"reconstruction": "Saudi Arabia", "hypothesis": "Kishi"}
    for task, topic in topics.items():
        found = []
        for p in query_files:
            r = load(p)
            if r["task"] == task and topic in r["query"]: found.append((p, r))
        if len(found) != 1: raise ValueError("CIB task topic is not uniquely source-bound")
        p, r = found[0]; SELECTION["cib"][task] = [r["case_id"]]
        origin = origins.get(r["origin_case_id"])
        if not origin or origin["answer"] != r["hidden_contribution"]:
            raise ValueError("CIB proposition's hidden contribution differs from the source archive")
        page = pages[origin["canonical_page_id"]]
        if not any(r["hidden_contribution"] == u.get("later_visible_text") for u in page["units"]):
            raise ValueError("CIB task contribution absent from current prepared page")
        case = public_case(dict(case_id=r["case_id"], corpus="cib", task=task, query=r["query"],
            document_id=r["document_id"], date=r["date"], focal_marker=""))
        cases.append(case); source_pins[str(p.relative_to(workspace))] = sha(p)
        metadata[case["case_id"]] = dict(source_id=page["canonical_page_id"],
            source_text_sha256=digest(page), query_construction="inherited_focal_contribution_proposition",
            semantic_faithfulness_human_certified=False, exposure="EXPOSED_DEVELOPMENT_DEMO_NOT_HELD_OUT")
        audit.append(dict(case_id=case["case_id"], corpus="cib", task=task, admitted=True,
            reason="current_source_contribution_verified_semantic_rephrasing_not_certified", membership_selected=True))
    selected_ids = {cid for tasks in SELECTION.values() for ids in tasks.values() for cid in ids}
    by_id = {r["case_id"]: r for r in cases}
    missing = selected_ids - by_id.keys()
    if missing: raise ValueError("Predeclared source selection failed admission: " + str(sorted(missing)))
    selected = [by_id[cid] for c in ("cib", "iran", "vietnam") for t in ("redaction", "hypothesis", "reconstruction") for cid in SELECTION[c][t]]
    controls = []
    for corpus in ("iran", "vietnam"):
        for task in ("redaction", "hypothesis", "reconstruction"):
            candidates = [r for r in cases if r["corpus"] == corpus and r["task"] == task and r["case_id"] not in selected_ids]
            controls.extend(sorted(candidates, key=lambda r: digest(["source-only-control-v1", r["case_id"]]))[:2])
    for r in audit: r["membership_selected"] = r["case_id"] in selected_ids
    packet = dict(version=VERSION, binding_sha256=binding["sha256"], cases=selected, controls=controls,
        metadata={r["case_id"]:metadata[r["case_id"]] for r in selected+controls},
        selection_rule="Declared linguistic/topic contrasts, fixed before fresh retrieval; 12 hash-sampled additional controls",
        counts=dict(screened=len(audit), admitted=sum(r["admitted"] for r in audit), demonstrations=len(selected), controls=len(controls),
            excluded_reasons=dict(Counter(r["reason"] for r in audit if not r["admitted"]))),
        source_pins=source_pins, source_only_admission=True, benchmark_accuracy_claim_permitted=False)
    packet["sha256"] = digest(packet)
    target = destination / "catalog.json"
    if target.exists() and load(target) != packet:
        raise ValueError("Catalog changed; use a new output directory rather than resealing")
    keys={r["case_id"]:gold[r["case_id"]] for r in selected+controls if r["case_id"] in gold}
    key_path=destination/"evaluation_keys.json"
    if key_path.exists() and load(key_path)!=keys:
        raise ValueError("Evaluation keys changed; do not overwrite the release")
    save(target, packet); save(destination / "source_audit.json", audit)
    save(key_path,keys)
    public_path=destination/"inference_catalog.json"
    released=public_release(packet)
    if public_path.exists() and load(public_path)!=released:
        raise ValueError("Public input release changed; use a new version")
    save(public_path,released)
    assessment=dict(version="demo-assessment-release/1",factory_sha256=packet["sha256"],
        public_inputs_sha256=released["sha256"],binding_sha256=binding["sha256"],
        evaluation_keys_sha256=sha(destination/"evaluation_keys.json"))
    assessment["sha256"]=digest(assessment)
    assessment_path=destination/"assessment_release.json"
    if assessment_path.exists() and load(assessment_path)!=assessment:
        raise ValueError("Assessment release changed; use a new version")
    save(assessment_path,assessment)
    return packet
