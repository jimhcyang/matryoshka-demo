"""Version presentation independently of the immutable native study outputs."""
from pathlib import Path

from .graph_assets_v4 import bound
from .io import digest, load, save, sha


FILES = (
    "web/workbench-v4.html", "web/workbench-v4.js", "web/workbench-v4.css",
    "web/flow-view-v4.js", "web/flow-view-v4.css", "web/flow-layout-v4.js",
    "web/graph-full-v4.html", "web/graph-full-v4.js", "web/graph-full-v4.css",
    "web/graph-v4.html", "web/graph-v4.js", "web/graph-v4.css",
    "matryoshka_demo/flow_projection_v4.py", "matryoshka_demo/corpus_explorer_v4.py",
    "matryoshka_demo/graph_assets_v4.py", "matryoshka_demo/server.py",
    "scripts/derive_graph_full_v4.py",
    "web/case-study-v4.html", "web/case-study-v4.css",
    "scripts/publish_case_study_v4.py",
)
POINTER = "web/data/ui-release-v4.json"


def publish(root, execute=False):
    root = Path(root).resolve()
    graph = bound(root)
    report_path = root / "web/data/report-v3.json"
    report = load(report_path)
    if report.get("sha256") != digest({k: v for k, v in report.items() if k != "sha256"}):
        raise ValueError("Published inference report changed")
    value = dict(version="inspection-presentation/4", native_run_id=report["run_id"],
        inference_unchanged=True,
        source_report=dict(path="web/data/report-v3.json", sha256=sha(report_path)),
        full_graph_binding=dict(path="data/full_graph_bindings_v4.json", sha256=graph["sha256"]),
        assets=[dict(path=name, sha256=sha(root / name)) for name in FILES])
    value["sha256"] = digest(value)
    if execute:
        archive = root / "web/data/ui-releases" / ("ui_" + value["sha256"][:20] + ".json")
        if archive.exists() and load(archive) != value:
            raise ValueError("An immutable presentation release changed")
        if not archive.exists():
            save(archive, value)
        save(root / POINTER, value)
    return value


def validate(root):
    root = Path(root).resolve()
    value = load(root / POINTER)
    if value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"}):
        raise ValueError("Presentation release changed")
    if value != publish(root):
        raise ValueError("Presentation assets differ from their published release")
    return value
