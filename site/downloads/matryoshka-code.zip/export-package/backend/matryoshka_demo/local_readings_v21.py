"""Dependency-first local spaCy slot compiler for planning version 2.1.

``compile_readings(query, marker, nlp=None)`` returns strict planning_v2.READING
records. It uses only the visible query and an installed spaCy English model,
not corpora, plans, answers, Stanza, network calls or lexical identity lists.
Every opaque mask becomes an offset-preserving ``thing``. A second parse with
the focal mask blank checks whether an actual visible noun carrier survives.
This is conservative grammar routing, not a completeness or semantic claim.
"""
from __future__ import annotations

from functools import lru_cache
import re


VERSION = "local-spacy-slot-readings/2.1"
MASK = re.compile(r"\[\[REDACTION_SLOT:[^\]]+\]\]|\[(?:REDACTION(?:[ _]\d+)?|REDACTED|STILL REDACTED|MASK)\]", re.I)
RELATIVES = frozenset({"who", "whom", "whose", "which", "that"})
NOMINAL_DEPS = frozenset({"nsubj", "nsubjpass", "dobj", "iobj", "pobj", "attr", "oprd", "appos", "conj"})
ARGUMENT_DEPS = frozenset({"nsubj", "nsubjpass", "dobj", "iobj", "dative"})
QUOTES = {'"': '"', "'": "'", "\u201c": "\u201d", "\u2018": "\u2019"}


@lru_cache(maxsize=1)
def _model():
    import spacy
    return spacy.load("en_core_web_sm")


def _shadow(query, intervals, blank=None):
    pieces, cursor = [], 0
    for start, end in intervals:
        pieces.append(query[cursor:start])
        pieces.append(" " * (end - start) if (start, end) == blank else "thing" + " " * (end - start - 5))
        cursor = end
    pieces.append(query[cursor:])
    shadow = "".join(pieces)
    if len(shadow) != len(query):
        raise ValueError("Placeholder replacement changed source offsets")
    return shadow


def _tokens(nlp, text, intervals):
    from spacy.tokens import Doc
    # Tokenize each side separately so touching masks cannot fuse with words.
    boundaries = sorted({0, len(text), *(position for interval in intervals for position in interval)})
    pieces = [nlp.make_doc(text[a:b]) for a, b in zip(boundaries, boundaries[1:]) if a < b]
    doc = Doc.from_docs(pieces, ensure_whitespace=False)
    if doc.text != text:
        raise ValueError("Tokenization did not preserve source characters")
    for token in doc:
        token.is_sent_start = True if token.i == 0 else None
    return doc


def _parse(nlp, text, intervals, *, uppercase=False):
    from spacy.attrs import DEP, ENT_IOB, ENT_TYPE, HEAD, LEMMA, MORPH, POS, SENT_START, TAG
    raw = _tokens(nlp, text, intervals)
    lowered = text.lower()
    if uppercase and len(lowered) == len(text):
        analysis = _tokens(nlp, lowered, intervals)
        if [(t.idx, len(t)) for t in raw] == [(t.idx, len(t)) for t in analysis]:
            analysis = nlp(analysis)
            attrs = [HEAD, DEP, POS, TAG, LEMMA, MORPH, ENT_IOB, ENT_TYPE, SENT_START]
            raw.from_array(attrs, analysis.to_array(attrs))
            return raw, "lowercase_annotations_with_identical_token_offsets"
    return nlp(raw), "original_characters"


def _visible(token, intervals):
    return not token.is_space and not any(a < token.idx + len(token) and token.idx < b for a, b in intervals)


def _carrier(doc, end, intervals):
    right = [t for t in doc if t.idx >= end and _visible(t, intervals)]
    if not right:
        return None
    first = right[0]
    if first.is_punct or first.lower_ in RELATIVES or first.ent_type_ in {"DATE", "TIME"} or first.like_num:
        return None
    token, seen = first, set()
    while token.i not in seen:
        seen.add(token.i)
        if not _visible(token, intervals):
            return None
        if token.pos_ == "NOUN" and token.tag_ in {"NN", "NNS"}:
            if token.dep_ in {"compound", "nmod"} and token.head.pos_ == "NOUN" and token.head.idx > token.idx:
                token = token.head
                continue
            prefix = [t for t in right if t.idx <= token.idx]
            if all(t.pos_ in {"NOUN", "PROPN", "ADJ", "ADV"} and t.ent_type_ not in {"DATE", "TIME"} for t in prefix):
                return token
            return None
        if token.pos_ not in {"ADJ", "ADV", "PROPN"} or token.head.idx <= token.idx:
            return None
        token = token.head
    return None


def compile_readings(query, marker="[REDACTION 1]", *, nlp=None):
    """Compile typed local alternatives without instantiating the hidden slot.

    Boundaries and attachment quotes are exact original-query substrings, in
    Python Unicode character coordinates. ``notes`` carries local provenance;
    no extra ``basis`` field is added to the strict v2 READING schema. Missing
    parser annotations are errors, not a silent fallback to symbolic syntax.
    """
    from spacy.language import Language
    if not isinstance(query, str) or not query.strip() or not isinstance(marker, str) or not MASK.fullmatch(marker):
        raise ValueError("A nonempty query and a supported opaque focal marker are required")
    if query.count(marker) != 1:
        raise ValueError("The focal marker must occur exactly once")
    nlp = _model() if nlp is None else nlp
    if not isinstance(nlp, Language) or not nlp.has_pipe("parser") or not nlp.has_pipe("tagger"):
        raise ValueError("A spaCy dependency/tagger pipeline is required")
    at, end = query.index(marker), query.index(marker) + len(marker)
    intervals = [m.span() for m in MASK.finditer(query)]
    shadow = _shadow(query, intervals)
    doc, mode = _parse(nlp, shadow, intervals, uppercase=query.isupper())
    slot = next((t for t in doc if t.idx == at and t.text == "thing"), None)
    if slot is None or not doc.has_annotation("DEP") or not doc.has_annotation("POS"):
        raise ValueError("Offset-preserving placeholder has no dependency/POS annotation")
    deleted, _ = _parse(nlp, _shadow(query, intervals, (at, end)), intervals, uppercase=query.isupper())
    left = [t for t in doc if t.idx + len(t) <= at and _visible(t, intervals)]
    right = [t for t in doc if t.idx >= end and _visible(t, intervals)]
    previous, following = (left[-1] if left else None), (right[0] if right else None)
    carrier = _carrier(deleted, end, intervals)
    modal_context = any(_visible(t, intervals) and (t.tag_ == "MD" or t.lower_ in {"if", "unless", "whether"}) for t in slot.sent)

    def attachment(token):
        seen = set()
        while token is not None and token.i not in seen:
            seen.add(token.i)
            if _visible(token, intervals):
                return query[token.idx:token.idx + len(token)]
            token = token.head
        return ""

    def output(specs, reason):
        return [dict(id="R" + str(i), form=form, role=role, target_kind=target,
            left_quote=query[max(0, at - 120):at], right_quote=query[end:end + 120],
            attachment_quote=attachment(head), finite=finite,
            notes=f"{VERSION}; local grammar only, not a hidden answer; basis=dependency+joint_boundaries; "
                  f"slot=[{at},{end}); placeholder_dep={slot.dep_}; parse={mode}; "
                  f"sentence_modal_or_conditional={modal_context}; role_is_syntactic_not_asserted_fact; {reason}")
            for i, (form, role, target, head, finite) in enumerate(specs, 1)]

    def unknown(reason):
        return output([("unknown", "unknown", "any", None, None)], reason)

    for start, stop in intervals:
        if (start, stop) == (at, end):
            continue
        if (stop <= at and not query[stop:at].strip()) or (start >= end and not query[end:start].strip()):
            return unknown("Adjacent opaque slot prevents a joint boundary interpretation.")

    stripped_left, stripped_right = query[:at].rstrip(), query[end:].lstrip()
    if stripped_left and stripped_left[-1] in QUOTES and stripped_right.startswith(QUOTES[stripped_left[-1]]):
        return output([("nominal", "quoted_characterization", "any", slot.head, False)],
                      "Paired quote boundaries enclose the whole opaque nominal expression; not a quantity or inferred name.")

    if following is not None and (following.ent_type_ in {"DATE", "TIME"} or following.like_num):
        return unknown("Visible date/time/numeral boundary requires a more specific licensed construction; no generic quantity union.")

    if previous is not None and following is not None and previous.pos_ == "NOUN" and previous.tag_ == "NNS" and following.lower_ in RELATIVES:
        relative = any(t.dep_ in {"relcl", "acl"} and t.head.i in {slot.i, previous.i} for t in doc if t.idx >= end)
        if relative:
            target = "person" if following.lower_ in {"who", "whom", "whose"} else "any"
            return output([("member_example", "member_example", target, previous, False)],
                          "Visible plural class on the left and a dependency-bound relative clause on the right license an example-member insertion.")

    if following is not None and following.lower_ in RELATIVES and slot.pos_ in {"NOUN", "PROPN", "PRON"}:
        if any(t.dep_ == "relcl" and t.head.i == slot.i for t in doc):
            return output([("nominal", "actor_argument" if slot.dep_ in ARGUMENT_DEPS else "unknown", "any", slot.head, False)],
                          "The relative clause modifies the missing nominal head; its first alphabetic token is not a visible noun carrier.")

    if slot.pos_ in {"VERB", "AUX"} and previous is not None and previous.pos_ == "AUX":
        return output([("verbal", "verbal_bridge", "action", previous, False)],
                      "A visible auxiliary governs a verbal placeholder; noun-phrase alternatives fail the left boundary.")

    if carrier is not None:
        if any(start < carrier.idx + len(carrier) and stop > end for start, stop in intervals):
            return unknown("Another opaque slot intervenes before the proposed visible carrier; it cannot be treated as known syntax.")
        if query.isupper() and carrier.tag_ == "NN":
            # Padding tokens can confuse all-caps NER. This extra guard alone
            # compacts whitespace; no compacted offset/quote is ever returned.
            compact = re.sub(r"\s+", " ", shadow)
            compact_start = len(re.sub(r"\s+", " ", shadow[:carrier.idx]))
            original_case = nlp(compact)
            original_head = next((t for t in original_case if t.idx == compact_start), None)
            if original_head is not None and original_head.pos_ == "PROPN" and original_head.ent_type_ in {"PERSON", "ORG", "GPE", "LOC", "FAC", "NORP"}:
                return unknown("Original-case proper-entity annotation conflicts with the lowercased common-noun carrier; no modifier or quantity is inferred.")
        if re.search(r"\n\s*\n", query[end:carrier.idx]):
            return unknown("A paragraph boundary separates the slot from the proposed visible carrier.")
        prior = next((t for t in reversed(list(deleted)) if t.idx + len(t) <= at and _visible(t, intervals)), None)
        determiners = [t for t in carrier.children if t.dep_ in {"det", "poss"} and _visible(t, intervals)]
        left_np = prior is None or prior.is_punct or prior.pos_ in {"DET", "ADP", "ADJ", "ADV"} or prior.tag_ == "POS" or carrier.head.i == prior.i
        if not left_np or (prior is not None and prior.pos_ == "DET" and prior.head.i != carrier.i):
            return unknown("Deletion parse does not join the left boundary and visible common-noun carrier into one nominal phrase.")
        indefinite = any(t.lower_ in {"a", "an"} for t in determiners)
        if carrier.tag_ == "NNS":
            if indefinite:
                return unknown("An indefinite singular article cannot directly quantify this visible plural carrier.")
            specs = [("modifier", "nominal_property", "property", carrier, False)]
            if prior is None or prior.pos_ in {"DET", "ADP", "VERB"} or prior.is_punct or prior.tag_ == "POS":
                specs.append(("quantity", "quantity", "quantity", carrier, False))
            return output(specs, "Deletion parse retains a visible plural common-noun head; both boundaries admit a property, and a count only where its position is licensed.")
        if determiners:
            return output([("modifier", "nominal_property", "property", carrier, False)],
                          "A visible determiner/possessor already licenses the singular common-noun carrier; no plural quantity or extra possessor is added.")
        if slot.dep_ in {"compound", "poss", "nmod"} and slot.head.idx == carrier.idx:
            return output([("possessive", "possessor", "any", carrier, False)],
                          "The bare singular carrier lacks a visible determiner; the prenominal dependency admits a possessive determiner. No holder identity is inferred.")
        return unknown("Visible singular carrier is not licensed by a joint determiner/possessor analysis.")

    if following is not None and following.pos_ == "PROPN":
        return unknown("Adjacent proper-name context without a common-noun carrier does not license modifier/quantity expansion.")
    boundary = following is None or following.is_punct or following.pos_ in {"VERB", "AUX", "ADP", "CCONJ"}
    if previous is not None and previous.lemma_ == "be" and previous.pos_ == "AUX" and boundary:
        return output([("modifier", "nominal_property", "property", previous, False),
                       ("nominal", "nominal_property", "any", previous, False)],
                      "A visible copula licenses adjectival or nominal complements, but no quantity without a visible count carrier.")
    if boundary and slot.pos_ in {"NOUN", "PROPN", "PRON"} and slot.dep_ in NOMINAL_DEPS:
        role = "actor_argument" if slot.dep_ in ARGUMENT_DEPS else "actor_enumeration" if slot.dep_ == "conj" else "unknown"
        return output([("nominal", role, "any", slot.head, False)],
                      "A nominal dependency and the right boundary license one complete missing argument, not an unbounded property/quantity/adjunct union.")
    return unknown("No dependency and joint-boundary rule licenses a typed construction; the local compiler abstains.")
