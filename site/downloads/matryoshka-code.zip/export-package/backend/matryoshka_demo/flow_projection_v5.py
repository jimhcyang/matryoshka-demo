"""Source-bound projection and guide routes for the new native v5 run."""
from collections import OrderedDict, defaultdict
from copy import deepcopy
from functools import lru_cache
import heapq
import json
import math
from pathlib import Path
from threading import RLock

from .corpus_explorer_v3 import _connection
from .corpus_policy_v5 import scoped_page_view
from .flow_projection_v4 import (ARMS, LEVELS, _bound_path, hierarchy_catalog,
    project, attach_documents, attach_route_sources, _candidate_rows)
from .io import digest, load, load_gzip


VERSION = "task-directed-inspection/5.1"
_LOCK = RLock()
_CACHE = OrderedDict()
_PARENTS = OrderedDict()


@lru_cache(maxsize=3)
def _read(path, stamp, expected):
    return load_gzip(path) if path.endswith(".gz") else load(path)


def condition(root, report, case_id, arm):
    root = Path(root).resolve()
    arm = ARMS.get(arm, arm)
    if arm not in ARMS.values():
        raise ValueError("Unknown comparison arm")
    row = next((r for r in report["cases"] if r["case"]["case_id"] == case_id), None)
    if row is None:
        raise ValueError("Unknown saved question")
    if row.get("status") == "PENDING":
        return dict(case=deepcopy(row["case"]), status="PENDING", reason=row["reason"],
            configurations={}, selected_arm=arm, reference_answer=row.get("reference_answer"))
    ref = row["case_detail_ref"]
    target, stamp = _bound_path(root, ref, "web/data/report-v5-cases")
    value = _read(str(target), stamp, ref["sha256"])
    if value["case"] != row["case"] or arm not in value["configurations"]:
        raise ValueError("Question or condition binding changed")
    saved = value["configurations"][arm]
    expected_run = row["configurations"][arm].get("native_run_id")
    if expected_run is not None and saved.get("run_id") != expected_run:
        raise ValueError("Native run differs from its exact published condition binding")
    pin = row["configurations"][arm]["native_checkpoint"]
    if saved["native_checkpoint"] != pin:
        raise ValueError("Native checkpoint binding changed")
    _bound_path(root, pin, "data/runs_v5")
    return dict({k: deepcopy(v) for k, v in value.items() if k != "configurations"},
        configurations={arm: deepcopy(saved)}, selected_arm=arm)


def targets(result, reading=None):
    if result.get("readings"):
        rows = _candidate_rows(result, reading)
        originals = {((r.get("reading_id") or r.get("reading", {}).get("id") or r.get("id")), c["id"]): c
            for r in result["readings"] for c in r["candidates"]}
        for row in rows:
            original = originals[row["reading_id"], row["id"]]
            row["disposition"] = deepcopy(original.get("disposition", {}))
            row["support"] = (row["disposition"].get("evidence_label")
                or original.get("support_assessment", {}).get("status") or "Unresolved")
        return rows
    if reading:
        raise ValueError("A grammatical reading was requested for a non-redaction result")
    return [dict(deepcopy(t), rank=i) for i, t in enumerate(result.get("flow_targets", []), 1)]


def decorate(value, task):
    value["version"] = VERSION
    value["task"] = task
    by_id = {n["id"]: n for n in value["nodes"]}
    for node in value["nodes"]:
        node["task_roles"] = []
    for target in value["candidates"]:
        if not target.get("atom_id"):
            continue
        for identity in target.get("endpoint_ids", []) + target.get("source_contributor_ids", []):
            if identity in by_id:
                by_id[identity]["task_roles"].append({k: target.get(k) for k in
                    ("id", "atom_id", "direction", "status", "establishes_atom", "is_counterevidence")})
    for document in value["documents"]:
        members = [by_id[n] for n in document["visible_node_ids"] if n in by_id]
        if members:
            member = min(members, key=lambda n: (n["type"].lower() not in {"claim", "event"}, -n.get("final_mass", 0), n["id"]))
            document["summary"] = " ".join(member["label"].split()[:12])
    return value


def _positive_number(value):
    return (isinstance(value, (int, float)) and not isinstance(value, bool)
        and math.isfinite(value) and value > 0)


def _influence_corridors(starters, candidate, nodes):
    """One widest simple corridor per starter, from recorded adjoint edges only.

    These edge totals span the finite solver horizon. Joining them does not
    establish a time-consistent trajectory or a joint random-walk probability.
    The independently capped per-iteration drawing is deliberately not used.
    """
    node_map = {n["id"]: n for n in nodes if not n.get("layout_only", False)}
    destinations = set(candidate.get("endpoint_ids") or candidate.get("source_contributor_ids") or []) & node_map.keys()
    graph, edge_map = defaultdict(list), {}
    for original in candidate.get("contribution_edges", []):
        weight = original.get("transported_influence")
        if (not isinstance(weight, (int, float)) or isinstance(weight, bool)
                or not math.isfinite(weight) or weight < 0):
            raise ValueError("Invalid saved candidate contribution influence")
        u, v = original["source"], original["target"]
        if not weight or u == v or u not in node_map or v not in node_map:
            continue
        if original.get("kind") not in {"SOURCE", "NAVIGATION", "SOURCE_AGGREGATE"}:
            raise ValueError("Unknown saved candidate contribution kind")
        hop = {k: deepcopy(original[k]) for k in ("source", "target", "kind", "transported_influence")}
        if "transition" in original:
            if not _positive_number(original["transition"]) or original["transition"] > 1:
                raise ValueError("Invalid recorded contribution transition")
            hop["transition"] = original["transition"]
        if (u, v) in edge_map:
            if edge_map[u, v] != hop:
                raise ValueError("Conflicting saved candidate contribution edge")
            continue
        edge_map[u, v] = hop
        graph[u].append((v, weight))
    routes, used, starter_ids = [], set(), set()
    for starter in starters:
        if starter["id"] in starter_ids:
            raise ValueError("Repeated recorded starter identity")
        starter_ids.add(starter["id"])
        injections = {}
        for target in starter.get("targets", []):
            if target["id"] in node_map and _positive_number(target.get("mass")):
                if target["id"] in injections and injections[target["id"]] != target["mass"]:
                    raise ValueError("Conflicting recorded starter target mass")
                injections[target["id"]] = target["mass"]
        # A direct restart at the destination is not a transported corridor.
        heap = [(-math.inf, 0, (u,)) for u in sorted(injections.keys() - destinations)]
        heapq.heapify(heap)
        best = {}
        while heap:
            negative, count, path = heapq.heappop(heap)
            score, u = -negative, path[-1]
            if score <= best.get(u, -1):
                continue
            best[u] = score
            if u in destinations:
                if path not in used:
                    used.add(path)
                    routes.append(dict(nodes=[deepcopy(node_map[n]) for n in path],
                        hops=[deepcopy(edge_map[a, b]) for a, b in zip(path, path[1:])],
                        starter_id=starter["id"], starter_target_id=path[0],
                        starter_target_mass=injections[path[0]],
                        route_kind="DISPLAYED_INFLUENCE_CORRIDOR",
                        influence_basis="SAVED_POSITIVE_CANDIDATE_CONTRIBUTION_EDGES",
                        starter_attribution_basis="RECORDED_POSITIVE_RESTART_TARGET_ONLY",
                        bottleneck_edge_influence=score,
                        time_consistency_certified=False, joint_probability_certified=False,
                        per_starter_influence_certified=False,
                        meaning="Accumulated finite-horizon influence corridor over saved positive candidate contributions. "
                            "Not a single-walk probability, a time-consistent trajectory, or factual entailment. "
                            "The first state is a recorded positive starter match; edge influence is pooled, not a per-starter contribution. "
                            "Unsaved transitions and per-iteration masses are not reconstructed."))
                break
            for v, weight in sorted(graph[u]):
                if v not in path:
                    heapq.heappush(heap, (-min(score, weight), count + 1, path + (v,)))
    return sorted(routes, key=lambda r: (-r["bottleneck_edge_influence"],
        r["starter_id"], tuple(n["id"] for n in r["nodes"])))[:3]


def attach_influence_corridors(value):
    """Presentation only: do not add edges or masses to the iteration replay."""
    for candidate in value["candidates"]:
        candidate["influence_corridors"] = _influence_corridors(
            value["starters"], candidate, value["nodes"])
    value["disclosures"].append("Representative corridors use saved positive candidate-specific finite-horizon "
        "contributions, independently of the global drawn-edge cap. They are not factual paths, "
        "time-consistent walks or joint path probabilities; omitted contributions remain omitted.")


def _corridor_provenance(value):
    for candidate in value["candidates"]:
        for route in candidate["influence_corridors"]:
            for hop in route["hops"]:
                if hop["kind"] == "SOURCE":
                    hop["source_proof_status"] = ("ELIGIBLE_CANONICAL_SOURCE_UNIT_ATTACHED"
                        if hop.get("citations") else "NO_ELIGIBLE_SOURCE_UNIT_ATTACHED")
                else:
                    hop["source_proof_status"] = ("KERNEL_NAVIGATION_NOT_SOURCE_ASSERTION"
                        if hop["kind"] == "NAVIGATION" else "KERNEL_SOURCE_AGGREGATE_NOT_GROUP_FACT")
                hop["influence_semantics"] = "ACCUMULATED_FINITE_HORIZON_NOT_PER_ITERATION"


def presentation(root, report, case_id, arm, *, reading=None, limit=1024):
    root = Path(root).resolve()
    selected = condition(root, report, case_id, arm)
    if selected.get("status") == "PENDING":
        return dict(version=VERSION, status="PENDING", reason=selected["reason"],
            task=selected["case"]["task"], nodes=[], edges=[], frames=[], starters=[], candidates=[], documents=[])
    record = next(iter(selected["configurations"].values()))
    result, case = record["result"], selected["case"]
    flow = result.get("flow", {})
    if flow.get("status") != "RECORDED":
        return dict(version=VERSION, status="NO_RECORDED_DIFFUSION", task=case["task"], nodes=[],
            edges=[], frames=[], starters=[], candidates=[], documents=[],
            native_paths=deepcopy(result.get("graph_paths", [])),
            scope="Only actually executed source paths are available for this condition.")
    if any(s.get("kind") == "context" for s in flow.get("starters", [])):
        raise ValueError("An old whole-query-seeded run cannot be relabeled as atomic-only")
    ref = flow["expanded_ref"]
    path, stamp = _bound_path(root, ref, "web/data/flows-v5")
    expanded = _read(str(path), stamp, ref["sha256"])
    reference = report["graph_indexes"][case["corpus"]]
    case_sha = next(r["case_detail_ref"]["sha256"] for r in report["cases"] if r["case"]["case_id"] == case_id)
    key = (VERSION, str(root), case_sha, record["config"], reading, limit, ref["sha256"], reference["sha256"])
    db = _connection(root, reference)
    try:
        scoped_page_view(db, report.get("handling_veto_documents", {}).get(case["corpus"], []))
        with _LOCK:
            if key in _CACHE:
                _CACHE.move_to_end(key)
                return deepcopy(_CACHE[key])
            parent_key = str((root / reference["path"]).resolve()), reference["sha256"]
            parents = _PARENTS.get(parent_key)
        if parents is None:
            parents = hierarchy_catalog(db)
            with _LOCK:
                _PARENTS[parent_key] = parents
                while len(_PARENTS) > 3:
                    _PARENTS.popitem(last=False)
        semantic = [n["id"] for n in expanded["nodes"] if n["type"].lower() not in LEVELS]
        assignments = {}
        if semantic:
            placeholders = ",".join("?" for _ in semantic)
            assignments = {r[0]: json.loads(r[1]) for r in db.execute(
                "SELECT id,hierarchy FROM node WHERE id IN (" + placeholders + ")", semantic)}
        value = project(flow, expanded, assignments, parents, targets(result, reading), limit=limit)
        attach_influence_corridors(value)
        attach_documents(db, value, case, result)
        attach_route_sources(db, value, case)
        _corridor_provenance(value)
        decorate(value, case["task"])
        value.update(case_id=case_id, config=record["config"], reading_id=reading,
            scope=dict(corpus=case["corpus"], strictly_before=case["date"], whole_origin_excluded=case["document_id"],
                binding=reference["binding"], retrospective_hierarchy=True),
            source_case_sha256=case_sha, source_expanded_sha256=ref["sha256"])
        with _LOCK:
            _CACHE[key] = deepcopy(value)
            while len(_CACHE) > 4:
                _CACHE.popitem(last=False)
        return value
    finally:
        db.close()


def routes_for(candidate):
    seen, routes = set(), []
    for route in candidate.get("routes", [])[:1]:
        key = tuple(n["id"] for n in route.get("nodes", []))
        seen.add(key)
        routes.append(route)
    corridors = 0
    for route in candidate.get("influence_corridors", []):
        key = tuple(n["id"] for n in route.get("nodes", []))
        if key in seen:
            continue
        seen.add(key)
        routes.append(route)
        corridors += 1
        if corridors == 2:
            break
    return routes


def guide(root, report, case_id, arm, candidate_id, route_index=0, reading=None):
    if type(route_index) is not int or not 0 <= route_index < 3:
        raise ValueError("Unknown saved route")
    value = presentation(root, report, case_id, arm, reading=reading)
    candidate = next((c for c in value["candidates"] if c["id"] == candidate_id), None)
    if candidate is None:
        raise ValueError("Unknown proposed result")
    routes = routes_for(candidate)
    if route_index >= len(routes):
        raise ValueError("No route was recorded for this result")
    route = deepcopy(routes[route_index])
    first = route.get("nodes", [{}])[0].get("id") if route.get("nodes") else None
    route["query_inputs"] = [dict(id=s["id"], text=s["label"], kind=s["kind"]) for s in value["starters"]
        if (not route.get("starter_id") or route["starter_id"] == s["id"])
        and any(t["id"] == first and _positive_number(t["mass"]) for t in s["targets"])]
    return dict(case_id=case_id, corpus=value["scope"]["corpus"], scope=value["scope"], route=route,
        candidate={k: candidate.get(k) for k in ("id", "fill", "binding", "direction", "atom_id")},
        graph_binding=value["scope"]["binding"], source_version=value["source_case_sha256"],
        guidance_is_entailment=False)
