"""Source-owned construction with nested constituents and insertion wording, v2.3.

Self-contained constructor; v2.1/v2.2 remain frozen controls. This module writes no
artifacts. The caller persists _candidate_audit as a compressed sidecar and saves
raw source pages separately. The legacy ``prototype`` metadata key is retained
for caller compatibility; execution_kind distinguishes construction/diagnostics.

Rules (all applied per grammatical reading):
1. Fresh construction uses the existing v1 full-audit constructor with local
   parser caches. It never truncates a pool before joint fit or feature scoring.
2. Source citations, phrase offsets, strict date/origin/visibility/classification
   constraints are replayed. Original fills, node IDs, negation, qualifications,
   quotations, and the complete raw constructor audit remain inspectable.
3. Type facts use only eligible own-page entity labels covering the NP head,
   never global type_counts. Conflicting own types are UNKNOWN. Joint fit rejects
   explicit type contradictions, malformed nominal constituents/boundaries,
   a/an + bare plural, nominal
   names in property/modifier slots, and nonnumeric NUM annotations. Missing or
   ambiguous typing is UNKNOWN, not grounds for rejection. Common-head WordNet
   ontology is optional; proper-name WordNet senses are never consulted.
   Legacy query-shaped person prefilters are disabled before pool construction;
   target-kind compatibility is deferred to the source-owned per-reading fit.
4. Order: existing visible-actor reuse penalty, local-property clue, focal-anchor
   IDF, full-query-anchor IDF, source-owned function match, complete source-span
   PROPN count, existing RRF, source fullness, stable occurrence tie-breakers.
   These are relevance heuristics, never semantic support or correctness scores.
5. Display-only dedup handles exact wording and proper-name suffixes after a
   higher-ranked fuller label. Two different bound node IDs are NEVER suppressed.
   At least one unbound ID permits suffix suppression, never identity joining,
   source/route transfer, or assigning the unbound phrase a known node ID.

construct() builds nested source NPs and losslessly adapts insertion wording.
Source-owned functional matching does not require a graph identity. Ranking
priorities are unchanged. construct() is the cached fresh full-audit path. construct_native()
calls candidates_v2.construct and is comparison-only: its upstream global-type
guard is not source-safe. rerank() alone is a fixed-pool diagnostic, explicitly
NOT fresh construction. No helper constructs a new retrieval/graph. Outputs are
relevance suggestions, never correctness or semantic-support certification.
"""
from bisect import bisect_right
from collections import Counter
from copy import deepcopy
import math
import re

import numpy as np

from matryoshka_demo import candidates as legacy
from matryoshka_demo import candidates_v2 as native
from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.corpus import BM25, ordered, words
from matryoshka_demo.io import digest, offline
from matryoshka_demo.planning_v2 import focal_context, validate_plan
from matryoshka_demo.roles import compare as role_match, lexicon
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo.candidate_types_v22 import NounResource, combine_fit, person_guard
from matryoshka_demo.source_constituents_v23 import construct_source_pool, safe_boundary

VERSION = "source-owned-unified-candidates/2.3"
RANK_TIERS = ("visible_actor_reuse", "local_property_match", "focal_anchor_idf",
    "full_query_anchor_idf", "source_function_match", "source_propn_count",
    "fused_rrf", "source_fullness", "stable_occurrence")
ENTITY_KINDS = {"Person": "person", "Organization": "organization", "Government": "organization",
    "Military": "organization", "PoliticalGroup": "organization", "ReligiousGroup": "organization",
    "Country": "place", "Location": "place"}


class ParseCache:
    """Per-construction cache, including page Docs; no process-global mutation."""
    def __init__(self, parse):
        self.parse = parse
        self.docs = {}
        self.calls = 0

    def __call__(self, text):
        if text not in self.docs:
            self.docs[text] = self.parse(text)
            self.calls += 1
        return self.docs[text]


class Context:
    def __init__(self, case, plan, reading, parse=None, *, common_head_ontology=True):
        self.case = public_case(case)
        if self.case["task"] != "redaction" or plan["query_sha256"] != digest(self.case["query"]):
            raise ValueError("A bound public redaction plan is required")
        self.plan, self.reading = plan, reading
        self.e = reading["eligible"]
        self.c = self.e.corpus
        self.parse = parse if isinstance(parse, ParseCache) else ParseCache(parse or native.source_parser())
        self.common_head_ontology = common_head_ontology
        self.patterns, self.contexts, self.bounds, self.labels = {}, {}, {}, {}
        self.views, self.phrases, self.reuse, self.head_kinds, self.role_words, self.role_matches = {}, {}, {}, {}, {}, {}
        self.source_fact_cache = {}
        self.noun_resource = NounResource()
        self.grammar_spans = {}
        self.pages_used = {}
        self.counts = Counter()
        self.focus = focal_context(self.case)
        self.focal_anchors = native.named_anchors(self.case, plan, self.parse)
        self.full_anchors = native.named_anchors(dict(self.case, focal_marker=""), plan, self.parse)
        self.n, df, _ = self.e.page_stats
        self.vocab = self.c.page_bm25.vocabulary
        if self.n < 0 or any(not 0 <= value <= self.n for value in df):
            raise ValueError("Invalid eligible source-only IDF statistics")
        self.idfs = {}
        for anchor in dict.fromkeys(self.focal_anchors + self.full_anchors):
            self.idfs[anchor] = sum(math.log1p((self.n - (df[self.vocab[w]] if w in self.vocab else 0) + .5)
                / ((df[self.vocab[w]] if w in self.vocab else 0) + .5)) for w in set(words(anchor)))
            self.pattern(anchor)

    def pattern(self, text):
        if text not in self.patterns:
            self.patterns[text] = re.compile(r"(?<!\w)" + re.escape(text) + r"(?!\w)", re.I)
        return self.patterns[text]

    def page(self, pid):
        pi = self.c.page_index[pid]
        p = self.c.pages[pi]
        case = self.case
        if (not self.e.page_mask[pi] or not p["permitted"] or p["corpus"] != case["corpus"]
                or p["document_id"] == case["document_id"] or p["date"] >= case["date"]
                or p.get("visibility") not in {None, "both", "earlier"}
                or case["corpus"] != "cib" and (p.get("classification") != "CONFIDENTIAL"
                    or "NOFORN" in p.get("handling", []))):
            raise ValueError("Candidate source violates current eligibility")
        if pid not in self.pages_used:
            if digest(p["text"]) != p["source_sha256"]:
                raise ValueError("Candidate source text hash changed")
            self.pages_used[pid] = p
        return p

    def replay(self, source):
        p = self.page(source["canonical_page_id"])
        a, b = source["start"], source["end"]
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(p["text"])
                or p["text"][a:b] != source["text"] or source["page_sha256"] != p["source_sha256"]
                or source["document_id"] != p["document_id"] or source["date"] != p["date"]):
            raise ValueError("Candidate quotation does not replay")
        return p

    def phrase(self, proposal):
        p = self.page(proposal["sources"][0]["canonical_page_id"])
        a, b = proposal["source_span"]
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(p["text"])
                or p["text"][a:b] != proposal["source_wording"]
                or not proposal["sources"][0]["start"] <= a < b <= proposal["sources"][0]["end"]):
            raise ValueError("Candidate phrase is not its literal source span")
        key = (p["id"], a, b)
        if key not in self.phrases:
            span = self.parse(p["text"]).char_span(a, b, alignment_mode="strict")
            if span is None:
                raise ValueError("Source phrase cuts through an analysis token")
            self.phrases[key] = span
        return self.phrases[key]

    def around(self, proposal):
        p = self.page(proposal["sources"][0]["canonical_page_id"])
        if p["id"] not in self.bounds:
            self.bounds[p["id"]] = [0] + [m.end() for m in re.finditer(r"\n\s*\n", p["text"])] + [len(p["text"])]
        bounds = self.bounds[p["id"]]
        i = min(len(bounds) - 2, bisect_right(bounds, proposal["source_span"][0]) - 1)
        key = p["id"], i
        if key not in self.contexts:
            a, b = bounds[max(0, i-1)], bounds[min(i+2, len(bounds)-1)]
            self.contexts[key] = dict(canonical_page_id=p["id"], document_id=p["document_id"], date=p["date"],
                text=p["text"][a:b], start=a, end=b, page_sha256=p["source_sha256"],
                meaning="Broader literal source context; not an assertion of focal support")
        return self.contexts[key]

    def grammar_phrase(self, proposal):
        """A separate, offset-aligned grammar view; never rewrite source Docs."""
        source = self.phrase(proposal)
        key = proposal["sources"][0]["canonical_page_id"], tuple(proposal["source_span"])
        if key not in self.grammar_spans:
            value, normalization = source, "ORIGINAL_SOURCE_ANALYSIS"
            page = self.page(key[0])
            lowered = page["text"].lower()
            if source.text.isupper() and len(lowered) == len(page["text"]):
                aligned = self.parse(lowered).char_span(*key[1], alignment_mode="strict")
                if aligned is not None:
                    value, normalization = aligned, "LOWERCASE_OFFSET_ALIGNED_PAGE"
            self.grammar_spans[key] = value, normalization
        return self.grammar_spans[key]

    def owner(self, proposal):
        key = proposal["sources"][0]["canonical_page_id"], tuple(proposal["source_span"])
        if key not in self.views:
            self.views[key] = native.owner_view(proposal, self.c, self.parse)
            self.counts["owner_views"] += 1
        return self.views[key]

    def source_facts(self, proposal):
        """Types and bindings come from eligible own-page entity witnesses only."""
        pid = proposal["sources"][0]["canonical_page_id"]
        key = pid, tuple(proposal["source_span"])
        if key not in self.source_fact_cache:
            span = self.phrase(proposal)
            pi = self.c.page_index[pid]
            relative_head = span.root.idx - proposal["source_span"][0]
            found = []
            for j in self.c.occurrences_by_page.get(pi, []):
                row = self.c.occurrences[j]
                if row.get("source_type") != "entities" or row["page_index"] != pi or not self.e.page_mask[pi]:
                    continue
                node = self.c.nodes.get(row["node_id"], {})
                if node.get("kind") != "Entity":
                    continue
                match = self.pattern(row["label"]).search(proposal["source_wording"])
                if match and match.start() <= relative_head < match.end():
                    found.append(dict(occurrence_index=j, node_id=row["node_id"],
                        source_entity_type=row.get("entity_type"), label=row["label"]))
            self.source_fact_cache[key] = found
            self.counts["source_head_bindings_checked"] += 1
        return self.source_fact_cache[key]

    def bind(self, proposal):
        original = proposal.get("node_id")
        facts = self.source_facts(proposal)
        ids = {f["node_id"] for f in facts}
        assigned = next(iter(ids)) if original is None and len(ids) == 1 else original
        return assigned, dict(original_node_id=original, node_id=assigned,
            policy="INHERITED_BINDING" if original is not None else "UNAMBIGUOUS_OWN_SOURCE_HEAD" if assigned is not None else "UNBOUND_OR_AMBIGUOUS",
            witnesses=deepcopy(facts), alias_join_performed=False)

    def reused_actor(self, node_id):
        if not node_id:
            return False
        if node_id not in self.reuse:
            self.labels[node_id] = {self.c.occurrences[j]["label"]
                for j in self.c.occurrences_by_node.get(node_id, [])
                if self.e.page_mask[self.c.occurrences[j]["page_index"]]}
            self.reuse[node_id] = any(label and self.pattern(label).search(self.focus) for label in self.labels[node_id])
            self.counts["eligible_node_label_sets"] += 1
        return self.reuse[node_id]

    def common_kind(self, head):
        # A lowercase ordinary head can be mistagged PROPN (e.g. a common
        # institutional noun). Named/instance senses still never supply types.
        ordinary_shape = head.pos_ == "NOUN" or (head.pos_ == "PROPN" and head.text.islower() and not head.ent_type_)
        if not self.common_head_ontology or not ordinary_shape:
            return set()
        lemma = head.lemma_.casefold()
        if lemma not in self.head_kinds:
            found = set()
            try:
                for syn in lexicon().synsets(lemma, pos="n"):
                    ordinary = [l.name() for l in syn.lemmas() if l.name().casefold() == lemma]
                    if not any(name.islower() for name in ordinary) or syn.instance_hypernyms():
                        continue
                    ancestors = {s.name() for path in syn.hypernym_paths() for s in path}
                    if "person.n.01" in ancestors: found.add("person")
                    if "organization.n.01" in ancestors: found.add("organization")
                    if {"location.n.01", "geographical_area.n.01"} & ancestors: found.add("place")
            except LookupError:
                pass  # Missing local ontology is uncertainty, never an API/download.
            self.head_kinds[lemma] = found
        return self.head_kinds[lemma]

    def snapshot(self):
        return dict(self.counts, parsed_texts=self.parse.calls, cached_source_pages=len(self.pages_used),
            cached_phrases=len(self.phrases), precompiled_patterns=len(self.patterns),
            target_guard=dict(noun_lemmas_cached=len(self.noun_resource.cache),
                resource=deepcopy(self.noun_resource.resource)))


def joint_fit(proposal, reading, context):
    """Compatibility is separate from relevance; lack of type evidence is UNKNOWN."""
    span = context.phrase(proposal)
    head = span.root
    facts = [f for f in context.source_facts(proposal)
        if proposal.get("node_id") is None or f["node_id"] == proposal["node_id"]]
    source_kinds = {ENTITY_KINDS[f["source_entity_type"]] for f in facts if f["source_entity_type"] in ENTITY_KINDS}
    conflicting = len(source_kinds) > 1
    known = next(iter(source_kinds)) if len(source_kinds) == 1 else None
    inferred = context.common_kind(head) if not known and not conflicting else set()
    kinds = {known} if known else inferred
    target = reading.get("target_kind", "any")
    reasons = []
    typing = "UNKNOWN_NOT_REJECTED"
    if target in {"person", "organization", "place"} and kinds:
        typing = ("COMPATIBLE" if known else "CONTEXT_PLAUSIBLE_NOT_CERTIFIED") if target in kinds else "INCOMPATIBLE"
        if typing == "INCOMPATIBLE": reasons.append("EXPLICIT_TARGET_KIND_CONTRADICTION")
    q, marker = context.case["query"], context.case["focal_marker"]
    left, right = q.split(marker)
    integrity = nominal_integrity(proposal, reading, context, left)
    reasons.extend(integrity["reasons"])
    if (re.search(r"\b(?:a|an)\s*$", left, re.I) and head.tag_ in {"NNS", "NNPS"}):
        reasons.append("INDEFINITE_ARTICLE_WITH_BARE_PLURAL")
    if re.search(r"\b(?:a|an|the)\s*$", left, re.I) and re.match(r"^(?:a|an|the|all)\b", proposal["fill"], re.I):
        reasons.append("DUPLICATED_DETERMINER")
    following = context.parse(right.lstrip())
    if reading["form"] == "modifier" or target == "property":
        if known in {"person", "organization", "place"} or head.pos_ in {"PROPN", "NOUN", "PRON"}:
            reasons.append("NOMINAL_LABEL_IS_NOT_A_PROPERTY_MODIFIER")
    if reading["form"] == "quantity" or target == "quantity":
        if not any(t.like_num for t in span): reasons.append("NUM_TAG_WITHOUT_LEXICAL_NUMBER")
    if (reading["form"] == "nominal" and target == "person" and following
            and following[0].pos_ == "NOUN" and following[0].tag_ == "NN"
            and not re.search(r"(?:['\u2019]s|s['\u2019])$", proposal["fill"])):
        reasons.append("PERSONAL_POSSESSOR_REQUIRES_POSSESSIVE")
    if head.pos_ == "PRON": reasons.append("UNRESOLVED_PRONOUN_NOT_A_SOURCE_LABEL")
    fit = dict(admissible=not reasons, reasons=reasons, typing=typing, known_kind=known,
        ordinary_head_kinds=sorted(inferred), source_kind_conflict=conflicting,
        source_type_witnesses=deepcopy(facts), global_node_type_used=False,
        nominal_integrity=integrity,
        shared_boundary_context_replayed=integrity.get("source_context_prefix_shared", False),
        source_head=head.text, source_head_pos=head.pos_,
        source_head_tag=head.tag_, target_kind=target, semantics="Compatibility only, not event support")
    return combine_fit(fit, person_guard(span, reading, fit, context.noun_resource))


def nominal_integrity(proposal, reading, context, left):
    """Conservative constituent/boundary checks, not semantic certification."""
    if reading["form"] not in {"nominal", "possessive", "member_example"}:
        return dict(checked=False, reasons=[])
    span, normalization = context.grammar_phrase(proposal)
    tokens = [t for t in span if not t.is_space]
    reasons = []
    shared = False
    if len(list(span.sents)) > 1:
        reasons.append("NOMINAL_SPAN_CROSSES_SENTENCES")
    if tokens:
        first, last = tokens[0], tokens[-1]
        if first.pos_ in {"ADP", "SCONJ", "CCONJ"} and first.dep_ != "det":
            reasons.append("PREPOSITION_OR_CONNECTIVE_LED_NOMINAL")
        original = proposal.get("unadapted_fill", proposal["fill"])
        supplied, edits = safe_boundary(context.case, original)
        shared = supplied == proposal["fill"] and any(e.get("kind") == "VISIBLE_ADJACENT_PREFIX_SHARED" for e in edits)
        if not shared and re.search(r"\b(?:a|an|the)\s*$", left, re.I) and (
                first.pos_ == "DET" or first.lower_ in {"this", "that", "these", "those"}):
            reasons.append("ARTICLE_WITH_SOURCE_DETERMINER")
        if first.pos_ == "ADV" and len(tokens) > 1 and tokens[1].pos_ in {"NOUN", "PROPN"}:
            reasons.append("ADVERB_DIRECTLY_PREFIXES_NOMINAL_HEAD")
        if span.root.pos_ not in {"NOUN", "PROPN"}:
            reasons.append("NOMINAL_SPAN_HAS_NONNOMINAL_HEAD")
        if last.pos_ in {"ADP", "SCONJ", "CCONJ", "DET"}:
            reasons.append("STRANDED_NOMINAL_FUNCTION_WORD")
        if any(t.dep_ in {"ccomp", "advcl", "relcl"} or (
                t.pos_ in {"VERB", "AUX"} and (t.tag_ in {"VBD", "VBP", "VBZ", "MD"}
                    or "Fin" in t.morph.get("VerbForm"))) for t in tokens):
            reasons.append("NOMINAL_SPAN_CONTAINS_CLAUSE")
    return dict(checked=True, reasons=reasons, normalization=normalization,
        source_context_prefix_shared=shared,
        grammar_head=span.root.text, grammar_head_pos=span.root.pos_,
        meaning="Conservative source-constituent fit; no guarantee of grammaticality or support")


def features(proposal, context):
    for source in proposal["sources"]:
        context.replay(source)
    span = context.phrase(proposal)
    around = context.around(proposal)
    matches = lambda anchors: [a for a in anchors if context.pattern(a).search(around["text"])]
    focal, full = matches(context.focal_anchors), matches(context.full_anchors)
    proper = [t.text.casefold() for t in span if t.pos_ == "PROPN"]
    pure = bool(proper) and all(t.pos_ == "PROPN" or t.is_punct or t.tag_ == "POS" for t in span)
    return dict(focal_anchors=focal, full_query_anchors=full,
        focal_anchor_idf=sum(context.idfs[a] for a in focal),
        full_query_anchor_idf=sum(context.idfs[a] for a in full),
        source_propn_tokens=proper, source_propn_count=len(proper), pure_name_suffix=pure,
        visible_actor_reuse=proposal.get("visible_actor_reuse", False),
        local_property_match=proposal["ranking"]["local_property_match"],
        source_function_match=bool(proposal["source_function_match"].get("matched")),
        fused_rrf=float(proposal["ranking"]["fused_rrf"]), source_fullness=len(proposal["source_wording"].split()))


def rank_key(proposal, f, index):
    return (f["visible_actor_reuse"], not f["local_property_match"], -f["focal_anchor_idf"],
        -f["full_query_anchor_idf"], not f["source_function_match"], -f["source_propn_count"],
        -f["fused_rrf"], -f["source_fullness"], proposal["id"], tuple(proposal["source_span"]), index)


def suppression_reason(candidate, cf, keeper, kf):
    a, b = candidate.get("node_id"), keeper.get("node_id")
    if a is not None and b is not None and a != b:
        return None
    if words(candidate["fill"]) == words(keeper["fill"]):
        return "EXACT_WORDING_DISPLAY_DUPLICATE_NOT_IDENTITY_MERGE"
    short, full = cf["source_propn_tokens"], kf["source_propn_tokens"]
    if cf["pure_name_suffix"] and short and len(short) < len(full) and full[-len(short):] == short:
        return "UNDERSPECIFIED_PROPER_NAME_SUFFIX_NOT_IDENTITY_MERGE"
    return None


def display_selection(pool, computed, ordered_indices):
    """Indexed display suppression; examine every proposal, not just top-k."""
    exact, suffixes = {}, {}
    kept, suppressed = [], []
    def compatible(table, node):
        if not table:
            return None
        if node is None:
            return next(iter(table.values()))
        possibilities = [table[n] for n in (node, None) if n in table]
        return min(possibilities) if possibilities else None
    for position, i in enumerate(ordered_indices):
        p, f = pool[i], computed[i]["features"]
        node = p.get("node_id")
        normal = tuple(words(p["fill"]))
        witnesses = []
        match = compatible(exact.get(normal), node)
        if match is not None: witnesses.append(match)
        if f["pure_name_suffix"]:
            match = compatible(suffixes.get(tuple(f["source_propn_tokens"])), node)
            if match is not None: witnesses.append(match)
        if witnesses:
            _, j = min(witnesses)
            reason = suppression_reason(p, f, pool[j], computed[j]["features"])
            if not reason:
                raise ValueError("Display suppression index disagrees with explicit identity rules")
            suppressed.append(dict(pool_index=i, keeper_pool_index=j, reason=reason, identity_merged=False,
                suppressed_node_id=node, keeper_node_id=pool[j].get("node_id")))
            continue
        kept.append(i)
        exact.setdefault(normal, {}).setdefault(node, (position, i))
        proper = f["source_propn_tokens"]
        for offset in range(1, len(proper)):
            suffixes.setdefault(tuple(proper[offset:]), {}).setdefault(node, (position, i))
    return kept, suppressed


def _rerank(case, plan, reading, output, *, top_k=5, context=None, execution_kind="FIXED_POOL_DIAGNOSTIC"):
    if type(top_k) is not int or not 1 <= top_k <= 5:
        raise ValueError("Display budget is between one and five; there is no pool cap")
    context = context or Context(case, plan, reading)
    audit = output["_candidate_audit"]
    if audit.get("keys_read") is not False or audit.get("grades_read") is not False:
        raise ValueError("Answer-aware pools are not inference inputs")
    result = {k: deepcopy(v) for k, v in output.items() if not k.startswith("_candidate_audit")}
    result["_candidate_audit"] = deepcopy(audit)
    views, ledgers = [], []
    for row in audit["readings"]:
        pool, computed, accepted, rejected = row["proposals"], [], [], []
        for i, p in enumerate(pool):
            f = features(p, context)
            fit = joint_fit(p, row["reading"], context)
            computed.append(dict(pool_index=i, candidate_id=p["id"], features=f, joint_fit=fit))
            if fit["admissible"]: accepted.append(i)
            else: rejected.append(dict(pool_index=i, candidate_id=p["id"], joint_fit=fit))
        accepted.sort(key=lambda i: rank_key(pool[i], computed[i]["features"], i))
        kept, suppressed = display_selection(pool, computed, accepted)
        displayed = []
        for rank, i in enumerate(kept[:top_k], 1):
            value = deepcopy(pool[i])
            value.update(rank=rank, v21_features=deepcopy(computed[i]["features"]),
                v21_joint_fit=deepcopy(computed[i]["joint_fit"]),
                broader_source_context=deepcopy(context.around(pool[i])),
                support_label="Source-property clue" if value["support"] == "LOCAL_PROPERTY_ATTESTED" else "Exploratory source-grounded suggestion")
            value["discovery_route"] = (native.candidate_route(reading, value["node_id"])
                if value.get("node_id") and "hierarchy_bundle" in reading else None)
            displayed.append(value)
        views.append(dict(reading=deepcopy(row["reading"]), candidates=displayed,
            evidence_candidates=[p for p in displayed if p["support"] == "LOCAL_PROPERTY_ATTESTED"],
            exploratory_candidates=displayed, generated_proposals=len(pool),
            joint_fit_rejections=len(rejected), score_meaning="Relevance only, not correctness"))
        ledgers.append(dict(reading_id=row["reading"]["id"], all_features=computed,
            ranked_pool_indices=accepted, display_suppressions=suppressed, joint_fit_rejections=rejected,
            raw_pool_size=len(pool), uncapped_display_survivors=len(kept)))
    result["_candidate_audit"]["v21"] = dict(readings=ledgers, keys_read=False, grades_read=False,
        raw_pool_sha256=digest(audit), global_node_type_used=False)
    result.update(version=VERSION, readings=views,
        prototype=dict(version=VERSION, execution_kind=execution_kind,
            native_results=execution_kind == "FRESH_SOURCE_BOUND_CONSTRUCTION",
            fresh_construction=execution_kind != "FIXED_POOL_DIAGNOSTIC",
            rank_tiers=RANK_TIERS, full_query_anchors=context.full_anchors, focal_anchors=context.focal_anchors,
            eligible_idf_pages=int(context.n), source_pages={pid: dict(id=pid, source_sha256=p["source_sha256"],
                document_id=p["document_id"], date=p["date"], characters=len(p["text"]),
                meaning="Full raw text remains in separately saved source pages") for pid, p in context.pages_used.items()},
            cache=context.snapshot(), identity_merges_performed=0, pool_cap=None, api_calls=0,
            interpretation="Source-grounded relevance suggestions; no accuracy or semantic-support claim"))
    return result


def rerank(case, plan, reading, output, *, top_k=5, parse=None, common_head_ontology=True):
    """Fixed-pool diagnostic. Never represented as fresh construction."""
    with offline():
        context = Context(case, plan, reading, parse, common_head_ontology=common_head_ontology)
        return _rerank(case, plan, reading, output, top_k=top_k, context=context)


def construct_native(case, plan, reading, *, passage_budget=100, top_k=5):
    """Fresh upstream-v2 comparison; its global type guard is not promotable."""
    with offline():
        case = public_case(case)
        validate_plan(plan, case)
        output = native.construct(case, plan, reading, passage_budget=passage_budget)
        result = _rerank(case, plan, reading, output, top_k=top_k, execution_kind="UPSTREAM_V2_COMPARISON")
        result["prototype"].update(fresh_construction=True, constructor="current_candidates_v2.construct",
            reference_only=True, promotable=False,
            warning="Upstream v2 still has a global-majority type guard; retained as a comparison, not the source-safe proposal")
        return result


def deferred_focal_requirements(case, parse):
    """Keep legacy geography/opposition cues, never prefilter a pool by person."""
    text = case["query"]
    right = text[text.index(case["focal_marker"]) + len(case["focal_marker"]):]
    parsed = parse(MASK.sub(" ", text))
    places = Counter(ent.text.casefold() for ent in parsed.ents if ent.label_ in {"GPE", "LOC"})
    primary = {place for place, count in places.items() if count == max(places.values())} if places else set()
    opposed_titles = {m.group(1).casefold() for m in re.finditer(
        r"\b(?:oust|overthrow|replace|remove|oppose)\s+(?:the\s+)?(president|premier|minister|commander)\b",
        right, re.I)}
    opposed_names = {ent.text.casefold() for ent in parsed.ents
        if ent.label_ == "PERSON" and ent.start > 0
        and parsed[ent.start-1].lemma_.casefold() in opposed_titles}
    return dict(person=False, places=primary, opposed_names=opposed_names)


def construct(case, plan, reading, *, passage_budget=100, top_k=5, parse=None, common_head_ontology=True):
    """Canonical fresh full-audit construction, cached features and joint fit.

    The isolated legacy function graph does not monkey-patch upstream modules.
    Unknown entity typing is deliberately retained for the explicit joint-fit gate.
    """
    with offline():
        case = public_case(case)
        validate_plan(plan, case)
        context = Context(case, plan, reading, parse, common_head_ontology=common_head_ontology)
        output, format_exclusions = construct_source_pool(case, plan, reading, parse=context.parse,
            focal_requirements=deferred_focal_requirements, validate_page=context.page, passage_budget=passage_budget)
        raw = output["_candidate_audit"]
        audit = deepcopy(raw)
        for row in audit["readings"]:
            leads = [l for l in plan["leads"] if row["reading"]["id"] in l["reading_ids"]]
            role_query = " ".join(t for l in leads for t in l["function_terms"])
            role_words = {t.lemma_.casefold() for t in context.parse(role_query)
                if t.pos_ in {"NOUN", "ADJ"} and not t.ent_type_} if role_query else set()
            role_docs = []
            for item in row["proposals"]:
                inherited = item.get("node_id")
                item["node_id"], item["v21_source_binding"] = context.bind(item)
                if inherited is None and item["node_id"] is not None:
                    rank = reading.get("node_ranks", {}).get(context.c.node_index[item["node_id"]])
                    item["ranking"]["node_rank"] = rank
                    item["ranking"]["rrf"] = 1 / (60 + item["ranking"]["passage_rank"]) + (1 / (60 + rank) if rank else 0)
                view = context.owner(item)
                matches = [a for a in context.focal_anchors if context.pattern(a).search(context.around(item)["text"])]
                item.update(owner=deepcopy(view), matched_anchors=matches,
                    anchor_idf=sum(context.idfs[a] for a in matches),
                    visible_actor_reuse=context.reused_actor(item.get("node_id")))
                match = dict(matched=False)
                if role_words:
                    if view["text"] not in context.role_words:
                        context.role_words[view["text"]] = frozenset(t.lemma_.casefold() for t in context.parse(view["text"])
                            if t.pos_ in {"NOUN", "ADJ"} and not t.ent_type_)
                        context.counts["owned_role_word_parses"] += 1
                    pair = frozenset(role_words), context.role_words[view["text"]]
                    if pair not in context.role_matches:
                        context.role_matches[pair] = role_match(*pair)
                    match = deepcopy(context.role_matches[pair])
                    match.update(ownership_requires_node_id=False, role_is_not_event_support=True)
                    if item.get("node_id") is None:
                        context.counts["unbound_function_checks"] += 1
                        context.counts["unbound_function_matches"] += int(match["matched"])
                item["source_function_match"] = match
                role_docs.append(view["text"])
            scores = np.zeros(len(role_docs))
            if role_query:
                scores = BM25(role_docs).score(role_query, np.ones(len(role_docs), dtype=bool))
            ranks = {i: r for r, i in enumerate(ordered(scores, [p["id"] for p in row["proposals"]]), 1)}
            for i, item in enumerate(row["proposals"]):
                rank = ranks.get(i)
                item["ranking"].update(source_role_bm25=float(scores[i]), source_role_rank=rank,
                    source_function_match=item["source_function_match"], anchor_idf=item["anchor_idf"],
                    visible_actor_reuse=item["visible_actor_reuse"],
                    fused_rrf=item["ranking"]["rrf"] + (1 / (60 + rank) if rank else 0), calibrated_probability=False)
        output["_candidate_audit"] = audit
        result = _rerank(case, plan, reading, output, top_k=top_k, context=context,
            execution_kind="FRESH_SOURCE_BOUND_CONSTRUCTION")
        result["_candidate_audit"]["v21"]["raw_constructor_audit"] = deepcopy(raw)
        result["_candidate_audit"]["source_constituents_v23"] = dict(source_format_rejections=format_exclusions,
            source_pages_modified=False, semantic_support_transferred=False)
        result["prototype"].update(fresh_construction=True, constructor="source_constituents_v23_full_audit_with_per_call_caches",
            global_node_type_used=False,
            person_typing_policy="DEFERRED_TO_PER_READING_SOURCE_OWNED_JOINT_FIT",
            feature_delta="Nested source NPs, logged insertion/format edits, target-kind lexical exclusion and identity-independent owned function checks; ranking priorities unchanged",
            owned_function_match_requires_node_id=False)
        return result
