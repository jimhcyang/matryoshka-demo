"""Legacy fixed-passage compatibility diagnostic, not a fresh retrieval score."""
from collections import Counter
import csv
from pathlib import Path

from .io import load, save, sha
from .tasks import parser, target_frames
from .vendor import matching


def run(workspace, output):
    base = Path(workspace) / "src/output/matryoshka_workbench/benchmarks/five_corpus_pair_20x5_semantic_handoff_final_v2__original/runs"
    results = []; pins = {}
    for corpus in ("cib", "iran", "viet"):
        for prefix in ("rc", "cl"):
            for number in (0,1):
                directory = base / f"{prefix}{number:02d}_{corpus}"
                query_path = directory / "query_input.txt"; query = query_path.read_text().strip()
                pins[str(query_path)] = sha(query_path)
                filename = "reconstruction_candidate_passages_v0413.csv" if prefix == "rc" else "claim_support_candidates_v048.csv"
                path = directory / "baseline/semantic_match_output" / filename
                pins[str(path)] = sha(path); passages = []
                with path.open() as stream:
                    for row in csv.DictReader(stream):
                        text = row.get("selected_raw_sentence") or row.get("raw_sentence")
                        if text and text not in passages: passages.append(text)
                        if len(passages) == 10: break
                targets = target_frames(query, parser()); counts = Counter(); examples = []
                for text in passages:
                    matches = [r for target in targets for source in matching.frames(text, parser())
                               if (r := matching.compare(target, source))]
                    for r in matches: counts[r["direction"]] += 1
                    examples.append(dict(source_text=text, matches=matches))
                results.append(dict(id=directory.name, corpus=corpus, task="reconstruction" if prefix == "rc" else "hypothesis",
                    query=query, source_passages=len(passages), matches=dict(counts), examples=examples,
                    historical_eligibility_revalidated=False, accuracy_claim_permitted=False))
    packet = dict(version="legacy-fixed-passage-compatibility/1", cases=results, source_pins=pins,
        scope="First two stored src examples per corpus/task, first ten distinct raw baseline passages; no old model grades read",
        caution="This exercises structured matching on legacy material; it neither reproduces the original engine nor evaluates current eligible-corpus recall")
    save(output, packet); return packet
