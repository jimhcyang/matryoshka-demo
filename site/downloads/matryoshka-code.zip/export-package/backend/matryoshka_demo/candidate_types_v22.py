"""Conservative ordinary-noun compatibility for entity readings, not a type oracle.

Call only with an eligible source span and its own-source fit. Unknown names,
missing resources/entries, ambiguous compatible senses, and conflicting source kinds
remain uncertain. Named/instance WordNet senses never supply identity. Existing
own-source kinds take precedence; country/government metonymy is not inferred.
"""
from copy import deepcopy

from matryoshka_demo.roles import binding, lexicon


REASON = "ORDINARY_NOUN_SENSES_EXCLUDE_PERSON"
NOMINAL_FORMS = {"nominal", "possessive", "member_example"}
NAMED_TAGS = {"PERSON", "ORG", "GPE", "LOC", "FAC", "NORP", "PRODUCT", "WORK_OF_ART", "LAW", "EVENT"}


class NounResource:
    """Per-construction lexical cache with serializable resource diagnostics."""
    def __init__(self, loader=lexicon, metadata=binding):
        self.loader, self.metadata = loader, metadata
        self.reader = None
        self.resource = dict(resource="WordNet", availability="NOT_LOADED",
            proper_name_lookups_permitted=False, ancestry="ALL_HYPERNYM_PATHS")
        self.cache = {}

    def _load(self):
        if self.resource["availability"] == "NOT_LOADED":
            try:
                self.reader = self.loader()
                info = self.metadata()
                self.resource.update(resource=info["resource"], version=info["version"],
                    nltk_version=info.get("nltk_version"), sha256=info["sha256"], availability="AVAILABLE")
            except (LookupError, OSError) as exc:
                self.resource.update(availability="UNAVAILABLE", error_type=type(exc).__name__, error=str(exc))

    def lookup(self, lemma):
        lemma = lemma.casefold()
        self._load()
        if lemma not in self.cache:
            result = dict(lemma=lemma, status="RESOURCE_UNAVAILABLE", senses=[])
            if self.resource["availability"] == "AVAILABLE":
                try:
                    senses = []
                    for syn in self.reader.synsets(lemma, pos="n"):
                        ordinary = [word.name() for word in syn.lemmas()
                            if word.name().islower() and word.name().replace("_", " ") == lemma]
                        if not ordinary or syn.instance_hypernyms():
                            continue
                        paths = syn.hypernym_paths()
                        if not paths:
                            raise LookupError("Incomplete noun ancestry for " + syn.name())
                        ancestry={node.name() for path in paths for node in path}
                        person_paths = [[node.name() for node in path] for path in paths
                            if any(node.name() == "person.n.01" for node in path)]
                        senses.append(dict(synset=syn.name(), ordinary_lemmas=ordinary,
                            person_possible=bool(person_paths), person_paths=person_paths,
                            possible_kinds=dict(person=bool(person_paths),organization='organization.n.01' in ancestry,
                                place=bool({'location.n.01','geographical_area.n.01'}&ancestry))))
                    result.update(status="SENSES_AVAILABLE" if senses else "NO_ORDINARY_NOUN_SENSES", senses=senses)
                except (LookupError, OSError) as exc:
                    result.update(status="LOOKUP_UNAVAILABLE", error_type=type(exc).__name__, error=str(exc))
            self.cache[lemma] = result
        return deepcopy(self.cache[lemma])


def person_guard(span, reading, source_fit, resource):
    """A lexical negative for person/organization/place; legacy function name.

    Compatibility never turns a previously unknown phrase into a certified
    historical entity. The output always records its requested target kind.
    """
    head = span.root
    value = dict(admissible=True, status="NOT_APPLICABLE", reason=None,
        head=head.text, lemma=head.lemma_.casefold(), source_lemma=head.lemma_, source_pos=head.pos_, source_ner=head.ent_type_,
        known_kind=source_fit["known_kind"], person_fact_established=False,
        metonymy_policy="NOT_INFERRED; country/government representation is not person identity",
        resource="WordNet", resource_consulted=False)
    target=reading.get('target_kind');value['target_kind']=target
    if target not in {'person','organization','place'} or reading["form"] not in NOMINAL_FORMS:
        return value
    if source_fit["known_kind"] is not None:
        value["status"] = "OWN_SOURCE_KIND_TAKES_PRECEDENCE"
    elif source_fit.get("source_kind_conflict"):
        value["status"] = "CONFLICTING_SOURCE_KINDS_STAY_UNKNOWN"
    elif head.ent_type_ in NAMED_TAGS or not head.lemma_.islower() or not (head.pos_ == "NOUN" or (
            head.pos_ == "PROPN" and head.text.islower() and not head.ent_type_)):
        value["status"] = "NAMED_OR_NONCOMMON_HEAD_STAYS_UNKNOWN"
    else:
        lookup = resource.lookup(head.lemma_)
        value.update(resource_consulted=True, lookup=lookup, resource_binding=deepcopy(resource.resource))
        if lookup["status"] != "SENSES_AVAILABLE":
            value["status"] = lookup["status"]
        elif any(s.get('possible_kinds',{}).get(target,s['person_possible'] if target=='person' else False) for s in lookup["senses"]):
            value["status"] = target.upper()+"_SENSE_POSSIBLE_NOT_CERTIFIED"
        else:
            value.update(admissible=False, status="ALL_ORDINARY_SENSES_EXCLUDE_"+target.upper(),
                reason="ORDINARY_NOUN_SENSES_EXCLUDE_"+target.upper())
    return value


def combine_fit(source_fit, guard):
    """Append a guard without mutating or resurrecting the underlying fit."""
    value = deepcopy(source_fit)
    value["v22_person_guard"] = guard
    if not guard["admissible"]:
        value["admissible"] = False
        value["reasons"] = list(dict.fromkeys(value["reasons"] + [guard['reason']]))
        value["typing"] = "INCOMPATIBLE_ORDINARY_LEXICAL_HEAD"
    return value
