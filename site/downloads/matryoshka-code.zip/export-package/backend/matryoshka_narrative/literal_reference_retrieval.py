"""OPTIONAL exact-public-reference probes; unintegrated retrieval prototype.

No leads, generated keywords, labels/aliases as query substitutes, source facts,
type/identity credit, source-admission exceptions, or changed graph assertions.
The existing focal kernel is cloned per call, not copied or globally patched.
Use ONLY inside the existing narrative retrieval wrapper: its complete-index
SourcePolicy check must still run unchanged after this lower-level kernel.
"""
from collections import Counter, defaultdict
import math
import re

import numpy as np

from matryoshka_demo.contracts import MASK
from matryoshka_demo.corpus import words
from matryoshka_demo.corpus_policy_v5 import policy_view
from matryoshka_demo.io import digest
from matryoshka_demo.vendor.matching import clone
from matryoshka_next.facts import public_plan
from . import focal_retrieval as focal


VERSION = "literal-public-reference-retrieval/2"
MAX_PROBES = 8
NAMED_TYPES = frozenset({"person", "organization", "org", "country", "location", "place", "geo"})
NAMED_NER = frozenset({"PERSON", "ORG", "GPE", "LOC", "FAC"})
CLAUSE_POS = frozenset({"VERB", "AUX", "ADV", "PRON", "SCONJ", "CCONJ"})
_LOCATOR_ID = r"(?:[a-z]|[ivxlcdm]{1,8}|\d+(?:[.-]\d+)*(?:\([a-z0-9]+\))?)"
DOCUMENT_LOCATOR = re.compile(
    r"^\s*(?:the\s+)?(?P<head>refs?|references?|paras?|paragraphs?|secs?|sections?|"
    r"cables?|telegrams?|docs?|documents?|annex(?:es)?|appendi(?:x|ces)|enclosures?|"
    r"attachments?|pages?|figures?|tables?)\.?\s+(?:no\.?\s*|#\s*)?"
    r"(?P<label>\(?"+_LOCATOR_ID+r"\)?(?:\s*(?:[/,-]|and)\s*\(?"+_LOCATOR_ID+r"\)?)*)\.?\s*$", re.I)


def _key(text):
    return tuple(sorted(set(words(MASK.sub(" ", text)))))


def _span(query, row):
    a, b = row.get("start"), row.get("end")
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(query)
            or query[a:b] != row.get("text")):
        raise ValueError("Extraction query_span does not replay literally")
    return a, b


def _token(token, query):
    return dict(start=token.idx, end=token.idx+len(token), text=query[token.idx:token.idx+len(token)],
                pos=token.pos_, dependency=token.dep_, governor_start=token.head.idx)


def compile_probes(case, plan, parse, *, cap=MAX_PROBES):
    """Compile only exact extraction query_spans; no corpus or expected answer.

    The caller retains full planner validation; public_plan plus this compiler
    replays exact public atom/entity bindings and rejects private fields. A model
    Person/Org/Geo type license AND public name evidence are required. Document
    locator head+identifier phrases are excluded even if mistyped as entities.
    Proper/NER evidence alone cannot rescue an unlicensed extraction type.
    All phrase words are retained, including articles.
    """
    case = public_plan(case, plan)
    if plan.get("leads"):
        raise ValueError("Literal references do not accept generated leads/questions")
    if type(cap) is not int or not 0 <= cap <= MAX_PROBES:
        raise ValueError("Reference cap must be an integer between zero and eight")
    before = digest([case, plan])
    query, marker = case["query"], case.get("focal_marker")
    result = dict(version=VERSION, query_sha256=digest(query), probes=[], rejected=[],
        max_probes=cap, label_or_alias_used_as_search=False, generated_assertions=False,
        factual_support_certified=False, source_type_certified=False, identity_certified=False,
        source_eligibility_changed=False, private_or_expected_answers_read=False)
    if case["task"] != "redaction" or not marker or query.count(marker) != 1:
        return dict(result, status="NO_SINGLE_PUBLIC_REDACTION_FOCAL_SLOT")
    focal_atoms = [a for a in plan["atoms"] if marker in a["text"] or
                   any(marker in s["text"] for s in a["query_spans"])]
    atom_spans = {a["id"]:[_span(query,s) for s in a["query_spans"]] for a in focal_atoms}
    at = query.index(marker)
    paragraphs = [(m.start(),m.end()) for m in re.finditer(r"\n[ \t]*\n", query)]
    lo = max([b for a,b in paragraphs if b <= at], default=0)
    hi = min([a for a,b in paragraphs if a >= at+len(marker)], default=len(query))
    shadow = MASK.sub(lambda m:" "*(m.end()-m.start()),query)
    original = parse(shadow)
    if original.text != shadow:
        raise ValueError("Public parser changed original query offsets")
    lowered = shadow.lower()
    control = parse(lowered) if len(lowered) == len(shadow) else None
    if control is not None and control.text != lowered:
        raise ValueError("Public lowercase control changed offsets")
    rows = []
    for index, entity in enumerate(plan.get("extractions", {}).get("entities", [])):
        spans = entity.get("query_spans")
        if not isinstance(spans, list) or not spans:
            result["rejected"].append(dict(entity_id=entity.get("local_id"), reason="NO_VALIDATED_PUBLIC_QUERY_SPANS"))
            continue
        for quoted in spans:
            a,b = _span(query,quoted)
            rows.append((a,b,index,entity,quoted))
    atomic_words = {_key(r["query"]) for r in focal.grouped_searches(plan,case)}
    seen = set(atomic_words)
    for a,b,index,entity,quoted in sorted(rows,key=lambda r:(r[0],r[1],r[2])):
        text = query[a:b]
        item = dict(entity_id=entity.get("local_id", "entity_"+str(index)), query_span=dict(quoted),
                    extraction_type=entity.get("type"), extraction_label=entity.get("label"),
                    extraction_label_used_as_search=False)
        def reject(reason):
            result["rejected"].append(dict(item, reason=reason))
        if (entity.get("contains_unknown_slot") is True
                or any(a < m.end() and m.start() < b for m in MASK.finditer(query))):
            reject("OPAQUE_OR_PARTIALLY_OPAQUE_SPAN"); continue
        if b-a > 96 or not 1 <= len(words(text)) <= 8:
            reject("REFERENCE_EXCEEDS_96_CHARACTERS_OR_EIGHT_TOKENS"); continue
        parents = [identity for identity,spans in atom_spans.items() if any(x <= a < b <= y for x,y in spans)]
        if not parents or not lo <= a < b <= hi:
            reject("NOT_IN_FOCAL_ATOM_AND_FOCAL_PHYSICAL_PARAGRAPH"); continue
        locator = DOCUMENT_LOCATOR.fullmatch(text)
        if locator is not None:
            item["document_locator_syntax"] = dict(head=locator.group("head"), label=locator.group("label"),
                grammar="CLOSED_DOCUMENT_LOCATOR_HEAD_PLUS_IDENTIFIER_NOT_ENTITY_NAME")
            reject("DOCUMENT_REFERENCE_LOCATOR_SYNTAX"); continue
        raw_type = str(entity.get("type", "")).casefold()
        if raw_type not in NAMED_TYPES:
            reject("NO_MODEL_PERSON_ORG_GEO_TYPE_LICENSE"); continue
        part = original.char_span(a,b,alignment_mode="strict")
        other = control.char_span(a,b,alignment_mode="strict") if control is not None else None
        if part is None or not part:
            reject("PUBLIC_REFERENCE_TOKEN_BOUNDARIES_UNESTABLISHED"); continue
        nes = [e for e in original.ents if e.label_ in NAMED_NER and a <= e.start_char < e.end_char <= b]
        whole_ne = any(e.start_char == a and e.end_char == b for e in nes)
        proper = [t for t in other if t.pos_ == "PROPN"] if other is not None else []
        # Whole named NEs can have function words. Without one, a purported
        # entity span containing a predicate/pronoun/coordination is not a probe.
        clause = any(t.pos_ in CLAUSE_POS for t in part) or (other is not None and any(t.pos_ in CLAUSE_POS for t in other))
        finite = any(t.pos_ in {"VERB","AUX"} and t.tag_ in {"VBD","VBP","VBZ","MD"}
                     for t in part)
        if finite or clause and not whole_ne:
            reject("CLAUSE_OR_GENERIC_FUNCTION_PHRASE_NOT_A_NAMED_REFERENCE"); continue
        if not nes and not proper:
            reject("NO_CREDIBLE_PUBLIC_NAMED_OR_PROPER_EVIDENCE"); continue
        normalized = _key(text)
        if not normalized:
            reject("NO_LITERAL_WORDS"); continue
        if normalized in seen:
            reject("DUPLICATE_RAW_NORMALIZED_WORD_SET"); continue
        if len(result["probes"]) >= cap:
            reject("PUBLIC_ORDER_CAP_EIGHT"); continue
        seen.add(normalized)
        witness = dict(public_ner=[dict(start=e.start_char,end=e.end_char,text=query[e.start_char:e.end_char],label=e.label_) for e in nes],
            public_proper_control=[_token(t,query) for t in proper], whole_named_ne=whole_ne,
            route="LICENSED_PUBLIC_ENTITY_SPAN_WITH_PUBLIC_NAME_EVIDENCE", licensed_type=raw_type,
            type_is_a_search_hint_not_factual_credit=True)
        result["probes"].append(dict(id="visible_reference_"+digest([a,b,text])[:20], kind="focal", query=text,
            atom_ids=parents, focal_atom_ids=parents, origin="visible_reference", search_origin="visible_reference",
            parent_atom_spans={p:[dict(s) for atom in focal_atoms if atom["id"]==p for s in atom["query_spans"]] for p in parents},
            public_role=dict(head=_token(part.root,query), claimed_extraction_role=entity.get("role")),
            named_reference_proof=witness, **item,
            raw_normalized_words=list(normalized), type_credit=False, factual_credit=False, identity_credit=False))
    if digest([case,plan]) != before:
        raise RuntimeError("Public plan was mutated")
    return dict(result,status="PUBLIC_REFERENCE_PROBES" if result["probes"] else "NO_ADMISSIBLE_PUBLIC_REFERENCES")


def grouped_searches(plan, case, compiled):
    base = [dict(row,search_origin="original_atom") for row in focal.grouped_searches(plan,case)]
    return base+[dict(row) for row in compiled["probes"]]


def retrieve(corpus, case, plan, *, parse, document_budget=40, passage_budget=80,
             focal_share=.5, graph_share=.5, alpha=.85, hierarchy=True, cap=MAX_PROBES):
    """Optional lower-level kernel only; mandatory narrative source wrapper stays.

    Two nested equal lexical channels within focal: original atoms/references.
    Positive graph priors are averaged within channel then split equally across
    present channels. Zero-prior channels cannot invent mass; conditional actual
    starter mass is recorded. Background family and public budgets are unchanged.
    """
    for n in (document_budget,passage_budget):
        if type(n) is not int or n < 1: raise ValueError("Positive integer budgets required")
    for n in (focal_share,graph_share):
        if type(n) not in (int,float) or not math.isfinite(n) or not 0 <= n <= 1:
            raise ValueError("Focal and graph shares must be finite in [0,1]")
    if type(alpha) not in (int,float) or not math.isfinite(alpha) or not 0 < alpha < 1:
        raise ValueError("Restart alpha must be strictly between zero and one")
    compiled = compile_probes(case,plan,parse,cap=cap)
    rows = grouped_searches(plan,case,compiled)
    options = dict(document_budget=document_budget,passage_budget=passage_budget,
        focal_share=focal_share,graph_share=graph_share,alpha=alpha,hierarchy=hierarchy)
    if not compiled["probes"]:
        value = focal.retrieve(corpus,case,plan,**options)
        graph_balance = dict(status="NO_EXTRA_PROBES_ATOMIC_KERNEL_UNCHANGED")
    else:
        selected = policy_view(corpus)
        eligible = selected.eligible(case)
        signatures = {name:np.asarray(getattr(eligible,name)).copy() for name in ("page_mask","unit_mask","active")}
        cached = {}
        positive = Counter()
        for row in rows:
            scores,seeds = focal.node_matches(eligible,row["query"]) if graph_share else (np.zeros(len(selected.nodes)),[])
            prior = focal.normalize_prior(scores,eligible.active)
            cached[row["query"]] = (scores,seeds)
            if prior.any(): positive[(row["kind"],row["search_origin"])] += 1
        scales = []
        for row in rows:
            family,channel = row["kind"],row["search_origin"]
            counts = {c:n for (f,c),n in positive.items() if f==family}
            scale = sum(counts.values())/(len(counts)*counts[channel]) if family=="focal" and counts.get(channel) else 1.
            scales.append(scale)
        families = sorted({row["kind"] for row in rows})
        rrf_calls, normal_calls = 0,0
        def groups(bound_plan,bound_case):
            if digest([bound_plan,bound_case]) != digest([plan,case]): raise ValueError("Kernel public binding changed")
            return rows
        def nodes(actual,query):
            if any(not np.array_equal(signatures[k],getattr(actual,k)) for k in signatures):
                raise ValueError("Kernel eligibility changed between query-only seed stages")
            return cached[query]
        def normalized(values,active=None):
            nonlocal normal_calls
            position = normal_calls
            normal_calls += 1
            result = focal.normalize_prior(values,active)
            if position < len(rows): return result*scales[position]
            if position != len(rows): raise ValueError("Focal kernel normalizer call contract changed")
            return result
        def fused(rankings,constant=60):
            nonlocal rrf_calls
            if rrf_calls >= len(families): raise ValueError("Focal kernel fusion call contract changed")
            family = families[rrf_calls]; rrf_calls += 1
            schedule = [r for r in rows if r["kind"]==family]
            if len(rankings) != len(schedule): raise ValueError("Kernel query/family order changed")
            atoms = [r for r,s in zip(rankings,schedule) if s["search_origin"]=="original_atom"]
            refs = [r for r,s in zip(rankings,schedule) if s["search_origin"]=="visible_reference"]
            if family=="focal" and atoms and refs:
                return focal.weighted_rrf([focal.rrf(atoms,constant)[0],focal.rrf(refs,constant)[0]],[.5,.5],constant)
            return focal.rrf(rankings,constant)
        _,functions = clone(focal,dict(grouped_searches=groups,node_matches=nodes,normalize_prior=normalized,rrf=fused))
        value = functions["retrieve"](selected,case,plan,**options)
        if normal_calls != len(rows)+1 or rrf_calls != len(families):
            raise ValueError("Existing kernel call contract changed; do not silently approximate")
        by_id = {r["id"]:r for r in rows}
        actual_mass = defaultdict(float)
        for starter in value["_starter_priors"]:
            row = by_id[starter["id"]]
            actual_mass[row["kind"]+"/"+row["search_origin"]] += float(np.asarray(starter["values"]).sum())
        graph_balance = dict(status="EQUAL_MEAN_POSITIVE_CHANNELS_WITHIN_EXISTING_FAMILIES",
            positive_query_counts={f+"/"+c:n for (f,c),n in positive.items()},
            actual_normalized_starter_mass=dict(actual_mass),
            zero_prior_policy="NO_INVENTED_SEEDS; EXISTING_KERNEL_RENORMALIZES_NONZERO_MASS",
            scaled_seed_normalizer_calls=normal_calls, lexical_family_fusions=rrf_calls)
    value["receipt"].update(method=VERSION, reused_kernel_version=focal.VERSION,
        reference_probe_receipt=compiled, search_input_policy="Original atomic searches plus bounded exact public entity query_spans only",
        focal_reference_lexical_split=dict(atom=.5,reference=.5) if compiled["probes"] else dict(atom=1.,reference=0.),
        graph_reference_balance=graph_balance, source_scope="OPTIONAL_PUBLIC_REFERENCE_QUERY_CONDITIONED_HIERARCHY_KERNEL",
        not_original_8941_literal_path=True, original_kernel_is_not_relabelled_as_directed_walk=True,
        requires_existing_narrative_complete_index_source_policy=True, complete_index_policy_recomputed_here=False,
        new_assertions=False, type_credit=False, factual_credit=False, navigation_is_evidence=False,
        source_admission_exception=False, paid_or_native_inference_run=False)
    return value
