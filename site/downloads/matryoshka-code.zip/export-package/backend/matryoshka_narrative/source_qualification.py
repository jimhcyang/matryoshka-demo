"""Retain unmatched epistemic tails even when event extraction omits them."""
from functools import lru_cache

VERSION = "raw-source-epistemic-tail-hold/1"


def raw_envelope_holds(matcher, page, unit, doc):
    from .exact_matrix import _forward_epistemic_prefix, _PREMISE
    from matryoshka_demo_v6.planning import sentences
    a, b = unit["start"], unit["end"]
    holds = []
    if any(t.is_quote for t in doc):
        holds.append("QUOTED_SOURCE_REPORTING_EVENT_NOT_ASSERTED_BY_THIS_PROJECTION")
    bounds = {(u["start"], u["end"]) for u in sentences(page["text"])}
    if _forward_epistemic_prefix(matcher, page, a, bounds):
        holds.append("FORWARD_REFERENCING_EPISTEMIC_SOURCE_ENVELOPE")
    lo = page["text"].rfind("\n\n", 0, a)
    lo = 0 if lo < 0 else lo + 2
    hi = page["text"].find("\n\n", b)
    if _PREMISE.search(page["text"][lo:None if hi < 0 else hi]):
        holds.append("EXPLICIT_PREMISE_OR_SCENARIO_SOURCE_ENVELOPE")
    return holds


@lru_cache(maxsize=512)
def _epistemic_noun(lemma):
    from matryoshka_demo.roles import lexicon
    try:
        senses = lexicon().synsets(lemma, pos="n")
    except LookupError:
        return True
    return bool(senses) and senses[0].lexname() in {"noun.communication", "noun.cognition"}


def unmatched_tails(query_doc, source_doc):
    wanted = {t.lemma_.casefold() for t in query_doc if not t.is_space and not t.is_punct}
    holds = []
    for head in source_doc:
        if head.dep_ not in {"advcl", "parataxis"}:
            continue
        tokens = list(head.subtree)
        subjects = [t for t in head.children if t.dep_ in {"nsubj", "nsubjpass", "csubj"}]
        if not subjects:
            continue
        epistemic = [t for t in tokens if t.pos_ == "NOUN" and _epistemic_noun(t.lemma_.casefold())]
        content = {t.lemma_.casefold() for t in tokens if t.pos_ in {"VERB", "AUX", "ADJ", "NOUN", "PROPN", "ADV", "PART"}}
        if not epistemic or content <= wanted:
            continue
        start, end = min(t.idx for t in tokens), max(t.idx + len(t) for t in tokens)
        holds.append(dict(version=VERSION, start=start, end=end, text=source_doc.text[start:end],
            attachment=head.dep_, attachment_head_start=head.head.idx,
            epistemic_nominals=[dict(text=t.text, start=t.idx, end=t.idx + len(t), lemma=t.lemma_) for t in epistemic],
            reason="UNMATCHED_ATTACHED_EPISTEMIC_SOURCE_CLAUSE",
            source_text_modified=False, signed_opposition_inferred=False))
    return holds
