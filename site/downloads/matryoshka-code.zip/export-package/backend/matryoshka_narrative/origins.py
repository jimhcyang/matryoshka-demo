"""Post-run source displays with producer-recorded birth and focal coordinates."""
from copy import deepcopy
import hashlib

from matryoshka_demo.io import digest
from .contracts import public_query


def _utf8(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _source_layout(text, segments):
    """Validate the producer's unchanged source blocks and literal join gaps."""
    previous, separators = 0, []
    for segment in segments:
        a, b = segment["raw_start"], segment["raw_end"]
        if (type(a) is not int or type(b) is not int or not previous <= a < b <= len(text)
                or _utf8(text[a:b]) != segment["text_sha256"]):
            raise ValueError("Original source segment bounds/hash do not replay")
        if a != previous:
            if previous == 0 or text[previous:a] != "\n\n":
                raise ValueError("Only explicit two-newline canonical joins may separate source pages")
            separators.append(dict(raw_start=previous, raw_end=a, text="\n\n"))
        previous = b
    if segments and previous != len(text):
        raise ValueError("Original source segments omit a trailing extent")
    return separators


def _masked_layout(original, masked, segments, focal, marker):
    """New display coordinates never overwrite original source coordinates."""
    a, b = focal["start"], focal["end"]
    change = len(marker) - (b - a)
    if segments and sum(s["raw_start"] <= a < b <= s["raw_end"] for s in segments) != 1:
        raise ValueError("A focal mask crossing source blocks needs a separate validated layout contract")
    mappings = []
    for index, segment in enumerate(segments):
        lo, hi = segment["raw_start"], segment["raw_end"]
        start = lo + change if lo >= b else lo
        end = hi + change if hi >= b else hi
        mappings.append(dict(source_segment_index=index, source_raw_start=lo, source_raw_end=hi,
            source_text_sha256=segment["text_sha256"], display_start=start, display_end=end,
            display_text_sha256=_utf8(masked[start:end])))
    separators = [dict(raw_start=left["display_end"], raw_end=right["display_start"], text="\n\n")
        for left,right in zip(mappings, mappings[1:]) if left["display_end"] != right["display_start"]]
    if any(masked[s["raw_start"]:s["raw_end"]] != "\n\n" for s in separators):
        raise ValueError("Masked source layout changed a canonical page separator")
    return dict(contract="source-mask-coordinate-map/1", source_text_utf8_sha256=_utf8(original),
        display_text_utf8_sha256=_utf8(masked), source_length=len(original), display_length=len(masked),
        source_focal_start=a, source_focal_end=b, display_focal_start=a,
        display_focal_end=a+len(marker), marker=marker, segments=mappings,
        separator_spans=separators, source_coordinates_unchanged=True,
        display_coordinates_are_not_original_source_offsets=True)


def build(case, text, birth_spans, *, source_ref, focal_span=None, segments=None):
    public_query(case)
    if not isinstance(text, str) or not text or not source_ref.get("sha256"):
        raise ValueError("A verified original source and its byte reference are required")
    spans = []
    for span in birth_spans:
        a, b = span["start"], span["end"]
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(text)
                or text[a:b] != span["text"]):
            raise ValueError("Birth-of-question quotation does not replay in the original")
        spans.append(dict(start=a, end=b, text=text[a:b]))
    if not spans:
        raise ValueError("The source birth quotation cannot be omitted")
    common = dict(version="narrative-source-origin/1", **deepcopy(case),
        query_sha256=digest(case["query"]), source_proof_ref=deepcopy(source_ref),
        eligible_evidence=False, postrun_only=True, used_for_inference=False,
        inferred_anchors=False, complete_original_supplied=True)
    source_segments = deepcopy(segments or [])
    separators = _source_layout(text, source_segments)
    full = dict(text=text, text_sha256=digest(text), query_anchors=spans,
        anchors=spans, segments=source_segments,
        segment_coordinate_space="ORIGINAL_CANONICAL_SOURCE_TEXT",
        segment_separator_contract="source-page-join-separators/1", separator_spans=separators)
    if any("CANONICAL" in str(s.get("locator", {}).get("kind", "")) for s in source_segments):
        common["source_projection_label"] = "Canonical text projection. The paired PDFs are the physical originals."
    visible = dict(common, text=text, text_sha256=digest(text), query_anchors=spans,
        anchors=spans, focal_revealed=False, full_transcription=full)
    if case["task"] != "redaction":
        if focal_span is not None:
            raise ValueError("Mosaic/Hypothesis cannot receive a redaction answer")
        return dict(masked=visible)
    if focal_span is None:
        raise ValueError("A complete source-verified focal interval is required")
    a, b = focal_span["start"], focal_span["end"]
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(text)
            or text[a:b] != focal_span["text"]):
        raise ValueError("Focal redaction extent does not replay")
    focal = dict(start=a, end=b, text=text[a:b])
    revealed = dict(visible, focal_revealed=True, focal_reference=focal["text"], anchors=[focal],
        full_transcription=dict(full, anchors=[focal]))
    marker = case["focal_marker"]
    masked = text[:a] + marker + text[b:]
    change = len(marker) - (b-a)
    rebased = []
    for span in spans:
        lo, hi = span["start"], span["end"]
        if lo < a < hi < b or a < lo < b < hi:
            raise ValueError("Birth quotation partially intersects the focal interval")
        lo = lo + change if lo >= b else a if a <= lo < b else lo
        hi = hi + change if hi >= b else a + len(marker) if a < hi <= b else hi
        rebased.append(dict(start=lo, end=hi, text=masked[lo:hi]))
    hidden = dict(start=a, end=a+len(marker), text=marker)
    visible.update(text=masked, text_sha256=digest(masked), query_anchors=rebased, anchors=[hidden],
        full_transcription=dict(full, text=masked, text_sha256=digest(masked), query_anchors=rebased,
            anchors=[hidden], display_segment_mapping=_masked_layout(text, masked, source_segments, focal, marker)))
    return dict(masked=visible, revealed=revealed)
