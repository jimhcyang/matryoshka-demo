"""Versioned decision DTOs; no inference, source replay, grading or resealing.

All validation needs an independently retained context and required-set snapshot.
Hashes bind records, not historical truth. Consumers MUST replay exact citations
and source-policy admission before treating a signed witness as evidence.
"""
from copy import deepcopy
from datetime import date
import re

from matryoshka_demo.io import digest

VERSION = "narrative-decision-certificate/2"
ADAPTER_VERSION = "narrative-certificate-observation-adapter/2"
VALIDATION_VERSION = "narrative-certificate-validation/4"
AUTHORITY_VERSION = "narrative-certificate-producer-authority/1"
SCOPE_KINDS = ("SOURCE_ASCRIPTION", "QUERIED_OPERATOR_ONLY")
STATES = ("SUPPORTED", "OPPOSED", "CONFLICTED", "PARTIAL", "CONTEXTUAL",
          "ASSESSED_NO_SUPPORT", "UNASSESSED", "UNMODELED")
SIGNS = ("SUPPORT", "OPPOSITION", "PARTIAL", "CONTEXT")
_DIRECTIONS = {"SUPPORT": ("SUPPORT",), "Support": ("SUPPORT",),
    "COUNTER": ("OPPOSITION",), "Counterevidence": ("OPPOSITION",),
    "CONFLICTED": ("SUPPORT", "OPPOSITION"),
    "Support + Counterevidence": ("SUPPORT", "OPPOSITION"),
    "PARTIAL": ("PARTIAL",), "Partial": ("PARTIAL",), "Context": ("CONTEXT",)}


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _text(value, name):
    _require(isinstance(value, str) and bool(value.strip()), name + " must be nonempty text")


def _hash(value, name):
    _require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
             name + " must be a SHA256")


def _unique(values, name):
    _require(isinstance(values, list), name + " must be a list")
    for value in values:
        _text(value, name)
    _require(len(values) == len(set(values)), name + " contains duplicates")


def _reasons(values):
    _require(isinstance(values, list) and bool(values), "Explicit local reasons are required")
    for value in values:
        _text(value, "reason")


def freeze_required_units(rows, *, denominator, authority):
    """Snapshot an EXISTING unit list/count, never parse or split new requirements.

    H/M use result.overall.required_atoms. Redaction uses the existing focal
    requirements list's cardinality where its producer exports no numeric count.
    An empty modeled set is permitted but has undefined ratios, never sufficiency.
    """
    _require(type(denominator) is int and denominator >= 0, "Invalid required denominator")
    _require(isinstance(rows, list), "Required units must be a list")
    _text(authority, "required-set authority")
    units = []
    for row in rows:
        unit = {k: deepcopy(row[k]) for k in ("id", "text", "kind")}
        for key, value in unit.items():
            _text(value, "required unit " + key)
        units.append(unit)
    _unique([u["id"] for u in units], "required-unit IDs")
    _require(len(units) == denominator, "Existing count and required-unit set disagree")
    return dict(denominator=denominator, authority=authority, units=units,
                units_sha256=digest(units))


def _packet_context(packet):
    """Capture the narrative native packet's exact query, plan, resource and pool.

    This is an observation adapter, NOT a new seal on the input execution. The
    returned native_packet_sha256 is a canonical JSON digest, not a file hash.
    """
    case, plan, result = packet["case"], packet["plan"], packet["result"]
    task = packet["public_task"]
    _require(task in {"mosaic", "hypothesis", "redaction"}, "Unknown public task")
    _require(case["task"] == {"mosaic": "reconstruction"}.get(task, task), "Task mapping changed")
    if "public_case" in packet:
        public = deepcopy(packet["public_case"])
        public["task"] = case["task"]
        _require(public == case, "Public/native question binding changed")
    _text(packet["version"], "native version")
    _text(result["version"], "result version")
    query_hash, plan_hash = digest(case["query"]), digest(plan)
    _require(packet["query_sha256"] == query_hash, "Native query binding changed")
    _require(packet["native_checksum"] == digest(result), "Native result binding changed")
    for key, expected in (("query_sha256", query_hash), ("provided_plan_sha256", plan_hash)):
        _require(result.get(key) == expected, "Result " + key + " changed")
    resource = deepcopy(packet["binding"])
    _hash(resource["sha256"], "resource index")
    _hash(resource["registry_sha256"], "resource registry")
    _require(resource["corpus"] == case["corpus"], "Resource corpus changed")
    ids = deepcopy(result["inspected_page_ids"])
    _unique(ids, "inspected-page IDs")
    count = result["source_pages_inspected"]
    _require(type(count) is int and count == len(ids), "Inspected count/pool disagree")
    pool = dict(kind="RECORDED_INSPECTED_PAGES", page_ids=ids, inspected_count=count,
                resource_binding_sha256=digest(resource), exhaustive_corpus_search=False)
    binding = dict(case_id=case["case_id"], query_sha256=query_hash, plan_sha256=plan_hash,
        native_packet_sha256=digest(packet), native_result_sha256=packet["native_checksum"],
        resource_binding_sha256=digest(resource), source_pool_sha256=digest(pool))
    subjects = {}
    for row in result.get("readings", []):
        for candidate in row["candidates"]:
            _require(candidate["id"] not in subjects, "Duplicate candidate identity")
            _require(candidate["reading_id"] == row["reading"]["id"], "Candidate belongs to a different reading")
            subjects[candidate["id"]] = dict(candidate_id=candidate["id"],
                reading_id=candidate["reading_id"], fill=candidate["fill"])
    return dict(task=task, binding=binding, resource_binding=resource, source_pool=pool,
        subjects=subjects,
        native_identity=dict(layer="native", engine=packet["version"],
            result_engine=result["version"], record_sha256=digest(packet)),
        source_replay_required=True)


def _scope(raw=None, *, operator_only=False):
    return dict(kind="QUERIED_OPERATOR_ONLY" if operator_only else "SOURCE_ASCRIPTION",
        qualification=deepcopy(raw), inner_execution_certified=False,
        event_join_certified=False, world_truth_certified=False)


def _check_scope(scope, *, operator_only_ancestor=False):
    """Validate scope and return the restriction inherited by its descendants.

    A child's label cannot relax an operator-only ancestor. Carry the restriction
    separately from the child kind, including through conservatively relabelled
    intermediate units and the Redaction context-witness branch.
    """
    _require(isinstance(scope, dict), "Explicit scope is required")
    _text(scope.get("kind"), "scope kind")
    _require("qualification" in scope, "Scope qualification must be preserved")
    for key in ("inner_execution_certified", "event_join_certified", "world_truth_certified"):
        _require(type(scope.get(key)) is bool, "Explicit scope flag required: " + key)
    _require(scope["world_truth_certified"] is False, "Source certificates do not certify world truth")
    operator_only = operator_only_ancestor or scope["kind"] == "QUERIED_OPERATOR_ONLY"
    if operator_only:
        _require(not scope["inner_execution_certified"] and not scope["event_join_certified"],
                 "Queried operator does not certify inner execution or event joins")
    _require(scope["kind"] in SCOPE_KINDS, "Unsupported scope kind")
    return operator_only


def _citation(ref, context):
    for key in ("canonical_page_id", "document_id", "corpus", "text"):
        _text(ref.get(key), "citation " + key)
    _hash(ref.get("page_sha256"), "citation page hash")
    _text(ref.get("date"), "citation date")
    try:
        date.fromisoformat(ref["date"])
    except ValueError as error:
        raise ValueError("Invalid citation publication date") from error
    _require(ref["corpus"] == context["resource_binding"]["corpus"], "Citation corpus differs")
    _require(ref["canonical_page_id"] in context["source_pool"]["page_ids"],
             "Citation is outside the recorded inspected source pool")
    start, end = ref.get("start"), ref.get("end")
    _require(type(start) is int and type(end) is int and 0 <= start < end,
             "Citation requires exact half-open character offsets")
    _require(end - start == len(ref["text"]), "Citation offsets and quotation length disagree")


def signed_coverage(units, required_units):
    """Project signed numerators over the supplied frozen denominator; no threshold."""
    wanted = [u["id"] for u in required_units["units"]]
    _unique([u["id"] for u in units], "decision-unit IDs")
    _require([u["id"] for u in units] == wanted, "Missing, reordered or incompatible required-unit IDs")
    n = required_units["denominator"]
    _require(type(n) is int and n == len(wanted), "Frozen denominator changed")
    for unit in units:
        _require(unit["state"] in STATES, "Unknown decision state")
    support = [u["id"] for u in units if u["state"] in {"SUPPORTED", "CONFLICTED"}]
    opposition = [u["id"] for u in units if u["state"] in {"OPPOSED", "CONFLICTED"}]
    unopposed = [u["id"] for u in units if u["state"] == "SUPPORTED"]
    def ratio(ids):
        return dict(numerator=len(ids), denominator=n, unit_ids=ids,
                    fraction=len(ids) / n if n else None)
    return dict(support_present=ratio(support), opposition_present=ratio(opposition),
        unopposed_support=ratio(unopposed),
        states={state: [u["id"] for u in units if u["state"] == state] for state in STATES},
        modeled_required_set=bool(n), partial_is_fractional_proof=False, counts_are_probabilities=False)


def _assemble_certificate(*, context, required_units, engine, units, native_status,
                     scope, subject=None, redaction=None, identities=None, provenance=None):
    """Build a future certificate or a labelled observation; never change a native verdict."""
    value = deepcopy(dict(version=VERSION, task=context["task"], binding=context["binding"],
        resource_binding=context["resource_binding"], source_pool=context["source_pool"],
        required_units=required_units, engine=engine, units=units, native_status=native_status,
        scope=scope, subject=subject, redaction=redaction,
        identities=identities or dict(native=context["native_identity"], observer=None, model_assessment=None),
        provenance=provenance, source_replay_required=True, scientific_validity_certified=False))
    value["coverage"] = signed_coverage(value["units"], value["required_units"])
    return value


def validate_certificate(value, *, expected_context, expected_required_units):
    """Validate against trusted external expectations, never the DTO's own claims.

    Returns a defensive copy. Does not replay source bytes, decide entailment,
    verify model output or approve this interface for ordinary integration.
    """
    _require(value.get("version") == VERSION, "Unsupported certificate version")
    for key in ("task", "binding", "resource_binding", "source_pool"):
        _require(value.get(key) == expected_context[key], "Certificate " + key + " binding changed")
    _require(value.get("required_units") == expected_required_units, "Frozen required-unit snapshot changed")
    snapshot = value["required_units"]
    _require(snapshot == freeze_required_units(snapshot["units"], denominator=snapshot["denominator"],
        authority=snapshot["authority"]), "Required-unit snapshot digest changed")
    _require(value.get("source_replay_required") is True and value.get("scientific_validity_certified") is False,
             "Schema validation cannot replace source replay or scientific review")
    _require(value.get("coverage") == signed_coverage(value["units"], snapshot), "Signed counts changed")
    for key in ("layer", "name", "version", "record_sha256"):
        _text(value["engine"].get(key), "engine " + key)
    _require(value["engine"]["layer"] in {"native", "observer"}, "A model assessment cannot supply local decisions")
    _hash(value["engine"]["record_sha256"], "engine record")
    _text(value["native_status"], "native status")
    authority_ref = value.get("producer_authority_sha256")
    _hash(authority_ref, "producer authority")
    authorities = expected_context.get("producer_authorities", {})
    _require(authority_ref in authorities, "No independently trusted producer authority for this observation")
    authority = authorities[authority_ref]
    _require(authority.get("version") == AUTHORITY_VERSION and digest(authority) == authority_ref,
             "Trusted producer authority binding changed")
    _require(authority["binding_sha256"] == digest(expected_context["binding"]), "Producer authority belongs to another native context")
    _require(value["engine"] == authority["engine"], "Observed engine differs from trusted producer authority")
    _require(value["native_status"] == authority["native_status"], "Observed native status differs from trusted producer authority")
    _require(value["identities"] == authority["identities"], "Judgment layer identities differ from trusted producer authority")
    operator_only = _check_scope(value["scope"])
    _require(value["identities"]["native"] == expected_context["native_identity"], "Native identity changed")
    _require({"observer", "model_assessment"} <= value["identities"].keys(), "Expose all three judgment layers")
    observer = value["identities"]["observer"]
    if observer is not None:
        _require(observer.get("layer") == "observer", "Observer identity layer changed")
        _hash(observer.get("record_sha256"), "observer record")
        _text(observer.get("engine"), "observer engine")
        for key, native_key in (("case_id", "case_id"), ("query_sha256", "query_sha256"),
                                ("native_checksum", "native_result_sha256")):
            _require(observer["binding"].get(key) == value["binding"][native_key], "Observer identity binding changed")
    _require(value["engine"]["layer"] != "observer" or observer is not None,
             "Observer engine requires its own identity")
    model = value["identities"]["model_assessment"]
    if model is not None:
        _require(observer is not None and model.get("layer") == "model_assessment" and
            model.get("gate_sha256") == observer["record_sha256"] and
            model.get("used_for_inference") is False and model.get("opinion_only") is True,
            "Model opinion binding changed or used for local inference")
        _hash(model.get("record_sha256"), "model assessment record")
    for unit in value["units"]:
        _reasons(unit["reasons"])
        unit_operator_only = _check_scope(unit["scope"], operator_only_ancestor=operator_only)
        witnesses = unit["witnesses"]
        _require(isinstance(witnesses, list), "Witnesses must be a list")
        witness_keys = []
        for witness in witnesses:
            _require(witness["sign"] in SIGNS, "Unknown witness sign")
            _citation(witness["citation"], expected_context)
            _check_scope(witness["scope"], operator_only_ancestor=unit_operator_only)
            _reasons(witness["reasons"])
            witness_keys.append(digest([witness["sign"], witness["citation"]]))
        _unique(witness_keys, "signed witnesses")
        signs = {w["sign"] for w in witnesses}
        _require(("SUPPORT" in signs) == (unit["state"] in {"SUPPORTED", "CONFLICTED"}),
                 "Complete support state and signed witnesses disagree")
        _require(("OPPOSITION" in signs) == (unit["state"] in {"OPPOSED", "CONFLICTED"}),
                 "Opposition state and signed witnesses disagree")
        if unit["state"] == "PARTIAL":
            _require("PARTIAL" in signs, "Partial grounding requires an exact partial witness")
        if unit["state"] in {"UNASSESSED", "UNMODELED", "ASSESSED_NO_SUPPORT"}:
            _require(not signs.intersection({"SUPPORT", "OPPOSITION", "PARTIAL"}),
                     "Unassessed, unmodeled or no-support unit has substantive evidence")
    if value["task"] == "redaction":
        red = value["redaction"]
        _require(isinstance(red, dict) and isinstance(value["subject"], dict), "Redaction axes and candidate identity required")
        for key in ("candidate_id", "reading_id", "fill"):
            _text(value["subject"].get(key), key)
        _require(expected_context["subjects"].get(value["subject"]["candidate_id"]) == value["subject"],
                 "Candidate, reading or fill changed from the native packet")
        _require(red["focal_support"] == value["coverage"], "Focal denominator/counts changed")
        _require(red["grammar"]["state"] in {"PASS", "FAIL", "UNASSESSED", "UNMODELED"}, "Unknown grammar state")
        _require(red["wider_event"]["state"] in STATES, "Unknown wider-event state")
        _require(red["exact_recovery"]["state"] in {"EXACT", "PARTIAL", "MISMATCH", "UNASSESSED", "UNMODELED"}, "Unknown exact-recovery state")
        for axis in ("grammar", "wider_event", "exact_recovery"):
            _reasons(red[axis]["reasons"])
        for witness in red.get("context_witnesses", []):
            _require(witness["sign"] == "CONTEXT", "Candidate context cannot become focal support")
            _citation(witness["citation"], expected_context)
            _check_scope(witness["scope"], operator_only_ancestor=operator_only)
            _reasons(witness["reasons"])
        if red["wider_event"]["state"] not in {"UNASSESSED", "UNMODELED"}:
            _hash(red["wider_event"].get("certificate_sha256"), "separate wider-event certificate")
        if red["exact_recovery"]["state"] in {"EXACT", "PARTIAL", "MISMATCH"}:
            assessment = red["exact_recovery"].get("comparison", {})
            for key in ("reference_sha256", "assessment_sha256"):
                _hash(assessment.get(key), "exact-recovery " + key)
            _require(assessment.get("fill_sha256") == digest(value["subject"]["fill"]), "Exact comparison belongs to another fill")
            _text(assessment.get("method"), "exact-recovery comparison method")
    else:
        _require(value["redaction"] is None and value["subject"] is None, "Assertion certificates cannot acquire Redaction axes")
    _require(_scopes(value) == authority["scopes"], "Scope differs from trusted producer authority")
    _require(digest(_judgment(value)) == authority["judgment_sha256"], "Judgment differs from trusted producer authority")
    return deepcopy(value)


def _operator_only(row):
    checks = row.get("checks", {})
    direct = row.get("source_account_match_certificate")
    direct_operator = False
    local = row.get("source_local_assessment_certificate")
    local_operator = False
    if local is not None:
        from .source_local_assessments import VERSION as local_version, TYPE as local_type
        _require(isinstance(local, dict) and local.get("version") == local_version
            and local.get("type") == local_type, "Unsupported local assessment proof")
        scope = local.get("scope", {})
        _require(scope.get("kind") == row.get("support_scope") == "QUERIED_OPERATOR_ONLY"
            and row.get("complete_required_frames") is True and local.get("citation") == row.get("citation")
            and local.get("full_parent_retained") is True and local.get("assessment_tail_literal") is True
            and local.get("source_text_modified") is False and local.get("raw_identity_claimed") is False
            and local.get("named_actor_identity_inferred") is False,
            "Local assessment lost its complete source account or scope")
        _require(all(scope.get(key) is False for key in
            ("inner_execution_certified", "event_join_certified", "world_truth_certified",
             "physical_executor_certified", "canonical_identity_certified")),
            "Local assessment cannot certify execution, identity or joins")
        parent = local["citation"]
        for key in ("selected_citation", "antecedent_citation"):
            part = local.get(key, {})
            _require(all(part.get(k) == parent.get(k) for k in
                ("canonical_page_id", "document_id", "date", "corpus", "page_sha256"))
                and type(part.get("start")) is int and type(part.get("end")) is int
                and parent["start"] <= part["start"] < part["end"] <= parent["end"]
                and part.get("text") == parent["text"][part["start"]-parent["start"]:part["end"]-parent["start"]],
                "Local assessment subspan does not replay in its raw parent")
        guard = local.get("local_assessment_qualification", {})
        _require(guard.get("version") == "current-source-assessment-qualification/1"
            and guard.get("held") is False and guard.get("signed_opposition_inferred") is False
            and guard.get("scope") == "CURRENT_AND_IMMEDIATELY_ADJACENT_PARAGRAPH"
            and type(guard.get("start")) is int and type(guard.get("end")) is int
            and guard["start"] == local["selected_citation"]["end"]
            and guard["start"] <= guard["end"] <= guard["start"] + 8192
            and isinstance(guard.get("text_sha256"), str) and re.fullmatch(r"[a-f0-9]{64}", guard["text_sha256"]),
            "Local assessment qualification guard is missing or held")
        replay = row.get("local_assessment_producer_replay", {})
        _require(replay.get("version") == local_version and replay.get("replayed") is True
            and replay.get("certificate_sha256") == digest(local)
            and replay.get("atom_sha256") == local.get("atom_sha256")
            and replay.get("raw_page_sha256") == local.get("full_source_page_sha256") == parent.get("page_sha256")
            and replay.get("qualification_sha256") == digest(guard)
            and replay.get("execution_or_join_authority_added") is False,
            "Local assessment lacks its trusted raw producer replay")
        local_operator = True
    prefix = row.get("source_prefix_account_certificate")
    prefix_operator = False
    if prefix is not None:
        from .source_prefix_accounts import VERSION as prefix_version, LITERAL_TYPE, NORMALIZED_TYPE
        _require(isinstance(prefix,dict) and prefix.get("version")==prefix_version
            and prefix.get("type") in {LITERAL_TYPE,NORMALIZED_TYPE},"Unsupported source-prefix proof")
        scope=prefix.get("scope",{})
        _require(prefix.get("complete_required_account") is True
            and prefix.get("citation")==row.get("citation")
            and row.get("support_scope")==scope.get("kind")
            and prefix.get("source_text_modified") is False
            and prefix.get("full_parent_retained") is True
            and prefix.get("all_first_conjunct_operators_retained") is True,
            "Source-prefix proof lost its full quotation, scope or operators")
        _require(all(scope.get(key) is False for key in
            ("inner_execution_certified","event_join_certified","world_truth_certified",
                "physical_executor_certified","canonical_identity_certified")),
            "A source-prefix account cannot certify execution, identity or joins")
        prefix_operator=scope.get("kind")=="QUERIED_OPERATOR_ONLY"
        _require(prefix_operator or prefix.get("type")==LITERAL_TYPE and scope.get("kind")=="SOURCE_ASCRIPTION",
            "Source-prefix type/scope pairing changed")
        _require(prefix.get("type")!=NORMALIZED_TYPE or prefix.get("raw_identity_claimed") is False,
            "Normalized source account cannot claim raw identity")
        parent=prefix["citation"];part=prefix.get("raw_prefix_citation",{})
        _require(all(part.get(key)==parent.get(key) for key in
            ("canonical_page_id","document_id","date","corpus","page_sha256"))
            and type(part.get("start")) is int and type(part.get("end")) is int
            and part["start"]==parent.get("start") and part["start"]<part["end"]<=parent.get("end",-1)
            and part.get("text")==parent["text"][:part["end"]-part["start"]],
            "Source-prefix raw span does not replay within its full quotation")
        replay=row.get("prefix_account_producer_replay",{})
        _require(replay.get("version")==prefix_version and replay.get("replayed") is True
            and replay.get("certificate_sha256")==digest(prefix)
            and replay.get("atom_sha256")==prefix.get("atom_sha256")
            and replay.get("raw_page_sha256")==prefix.get("full_source_page_sha256")
            and replay.get("execution_or_join_authority_added") is False,
            "Source-prefix proof lacks its trusted producer replay")
    inventory = row.get("source_inventory_announcement_certificate")
    inventory_operator = False
    if inventory is not None:
        from .source_inventory_announcement import VERSION as inventory_version, TYPE as inventory_type
        _require(isinstance(inventory, dict) and inventory.get("version") == inventory_version
            and inventory.get("type") == inventory_type,
            "Unsupported inventory-announcement proof")
        scope = inventory.get("scope", {})
        _require(inventory.get("complete_required_account") is True
            and inventory.get("citation") == row.get("citation")
            and row.get("support_scope") == scope.get("kind") == "QUERIED_OPERATOR_ONLY"
            and inventory.get("source_text_modified") is False
            and inventory.get("full_parent_operators_retained") is True,
            "Inventory-announcement proof lost its quotation, scope or operators")
        _require(all(scope.get(key) is False for key in
            ("inner_execution_certified", "event_join_certified", "world_truth_certified",
             "physical_executor_certified", "canonical_identity_certified", "completed_withdrawal_certified",
             "order_issuance_certified", "physical_passive_agent_explicit")),
            "An inventory announcement cannot certify physical execution or joins")
        replay = row.get("inventory_announcement_producer_replay", {})
        _require(replay.get("version") == inventory_version and replay.get("replayed") is True
            and replay.get("certificate_sha256") == digest(inventory)
            and replay.get("atom_sha256") == inventory.get("atom_sha256")
            and replay.get("raw_page_sha256") == inventory.get("full_source_page_sha256")
            and replay.get("execution_or_join_authority_added") is False,
            "Inventory-announcement proof lacks its trusted producer replay")
        inventory_operator = True
    relative = row.get("source_relative_account_certificate")
    relative_operator = False
    if relative is not None:
        from .source_relative_accounts import VERSION as relative_version, H_TYPE, M_TYPE
        _require(isinstance(relative, dict) and relative.get("version") == relative_version,
                 "Unsupported source-relative proof")
        scope = relative.get("scope", {})
        _require(relative.get("complete_required_account") is True
            and relative.get("citation") == row.get("citation")
            and row.get("support_scope") == scope.get("kind")
            and relative.get("source_text_modified") is False
            and relative.get("full_parent_operators_retained") is True
            and relative.get("source_local_reference_only") is True,
            "Source-relative proof lost its quotation, scope or operators")
        _require(all(scope.get(key) is False for key in
            ("inner_execution_certified", "event_join_certified", "world_truth_certified",
             "physical_executor_certified", "canonical_identity_certified")),
            "Source-relative proof cannot certify execution, identity or joins")
        relative_operator = relative.get("type") == H_TYPE
        _require((relative_operator and scope.get("kind") == "QUERIED_OPERATOR_ONLY")
            or (relative.get("type") == M_TYPE and scope.get("kind") == "SOURCE_ASCRIPTION"),
            "Source-relative proof type/scope changed")
        replay = row.get("relative_account_producer_replay", {})
        _require(replay.get("version") == relative_version and replay.get("replayed") is True
            and replay.get("certificate_sha256") == digest(relative)
            and replay.get("atom_sha256") == relative.get("atom_sha256")
            and replay.get("raw_page_sha256") == relative.get("full_source_page_sha256")
            and replay.get("execution_or_join_authority_added") is False,
            "Source-relative proof lacks its trusted producer replay")
    if direct is not None:
        from .source_account_match import VERSION as direct_version
        _require(isinstance(direct, dict) and direct.get("version") in {
            "direct-literal-source-account-match/5", direct_version},
                 "Unsupported direct source-account proof")
        scope = direct.get("scope", {})
        _require(direct.get("complete_literal_account") is True
            and direct.get("citation") == row.get("citation")
            and row.get("support_scope") == scope.get("kind"),
            "Direct source-account proof lost its observed quotation or scope")
        _require(all(scope.get(k) is False for k in
            ("inner_execution_certified", "event_join_certified", "world_truth_certified",
             "physical_executor_certified", "canonical_identity_certified")),
            "Direct source account cannot certify execution, identity or joins")
        direct_operator = direct.get("type") == "ATTRIBUTED_OR_MODAL_QUERIED_ACCOUNT"
        _require((direct_operator and scope.get("kind") == "QUERIED_OPERATOR_ONLY")
            or (direct.get("type") == "LITERAL_HISTORICAL_SOURCE_ASCRIPTION"
                and scope.get("kind") == "SOURCE_ASCRIPTION"),
            "Direct source-account proof type/scope changed")
    return (bool(row.get("root_content_certificate")) or
        direct_operator or relative_operator or inventory_operator or prefix_operator or local_operator or (isinstance(checks, dict) and checks.get("queried_root_operator") == "PASS"))


def _witnesses(rows):
    output = {}
    for row in rows:
        direction = row.get("direction")
        _require(direction in _DIRECTIONS, "Unknown observed evidence direction: " + str(direction))
        refs = row.get("citations", [row["citation"]] if "citation" in row else [])
        _require(bool(refs), "Signed evidence lacks an exact quotation")
        for sign in _DIRECTIONS[direction]:
            for ref in refs:
                scope = _scope(row.get("support_scope", row.get("evidence_semantics")), operator_only=_operator_only(row))
                witness = dict(sign=sign, citation=deepcopy(ref), scope=scope,
                    reasons=["OBSERVED_" + direction.upper().replace(" ", "_")], details=deepcopy(row))
                output.setdefault(digest([sign, ref]), witness)
    return list(output.values())


def _observed_unit(row, state, *, evidence=None):
    witnesses = _witnesses(row.get("evidence", []) if evidence is None else evidence)
    operator = any(w["scope"]["kind"] == "QUERIED_OPERATOR_ONLY" for w in witnesses)
    return dict(id=row["id"], state=state, witnesses=witnesses,
        scope=_scope(row.get("qualified_accounts", row.get("qualified_scope", row.get("scope"))), operator_only=operator),
        reasons=["OBSERVED_STATE_" + state], details=deepcopy(row))


def _required_atoms(packet):
    rows = [a for a in packet["plan"]["atoms"] if a.get("required") is True]
    return freeze_required_units(rows, denominator=packet["result"]["overall"]["required_atoms"],
        authority="native.result.overall.required_atoms + native.plan.atoms[required=true]")


def _certificate_scope(units, raw):
    return _scope(raw, operator_only=bool(units) and all(u["scope"]["kind"] == "QUERIED_OPERATOR_ONLY" for u in units))


def _native_observation(packet):
    """Observe narrative H/M atom judgments without recomputing their sufficiency."""
    context = _packet_context(packet)
    _require(context["task"] in {"mosaic", "hypothesis"}, "Expected an assertion task")
    required = _required_atoms(packet)
    result = packet["result"]
    raw = result["atoms"]
    _unique([a["id"] for a in raw], "native atom IDs")
    _require([a["id"] for a in raw] == [a["id"] for a in packet["plan"]["atoms"]], "Native/plan atoms changed")
    mapping = {"SUPPORTED": "SUPPORTED", "OPPOSED": "OPPOSED", "CONFLICTED": "CONFLICTED",
        "FEASIBLE": "PARTIAL", "NO_INFO": "ASSESSED_NO_SUPPORT"}
    units = []
    for atom, planned in zip(raw, packet["plan"]["atoms"]):
        _require(all(atom[key] == planned[key] for key in ("id", "text", "kind", "required")),
                 "Native/plan required unit changed")
        if not planned["required"]:
            continue
        _require(atom["criterion_state"] in mapping, "Unknown observed criterion state")
        units.append(_observed_unit(atom, mapping[atom["criterion_state"]]))
    return _assemble_certificate(context=context, required_units=required,
        engine=dict(layer="native", name="narrative assertion decision", version=result["version"], record_sha256=digest(result)),
        units=units, native_status=result["status"], scope=_certificate_scope(units, result.get("query_requirements")),
        provenance=dict(adapter_version=ADAPTER_VERSION, observation_only=True, old_native_resealed=False,
                        original_overall=deepcopy(result["overall"])))


def _observer_identity(record, packet):
    context = _packet_context(packet)
    _require(record["case"] == packet["public_case"], "Observer public question changed")
    _require(record["plan"] == packet["plan"] or
        all(record["plan"].get(k) == v for k, v in packet["plan"].items()), "Observer original plan changed")
    _require(record["native_checksum"] == context["binding"]["native_result_sha256"], "Observer native result changed")
    gate = record["local_decisions_v65"]
    _require(gate["case_id"] == packet["case"]["case_id"], "Observer case ID changed")
    binding = gate["binding"]
    expected = dict(case_id=packet["case"]["case_id"], query_sha256=packet["query_sha256"],
        config=record["config"], native_run_id=record["run_id"], native_checksum=packet["native_checksum"],
        resource_binding_sha256=digest(record["resource_binding"]))
    _require(binding == expected, "Observer binding changed")
    resource = record["resource_binding"]
    native_resource = packet["binding"]
    _require(record["result"]["inspected_page_ids"] == context["source_pool"]["page_ids"] and
        record["result"]["source_pages_inspected"] == context["source_pool"]["inspected_count"],
        "Observer inspected source pool changed")
    if "pool_replay" in gate:
        _require(gate["pool_replay"]["page_ids"] == context["source_pool"]["page_ids"],
                 "Observer claims a different replay pool")
    _require(resource["index_sha256"] == native_resource["sha256"] and
        resource["registry_sha256"] == native_resource["registry_sha256"] and
        resource["corpus"] == native_resource["corpus"] and
        resource["source_status"] == native_resource["source_status"], "Observer source resource changed")
    native_index = native_resource.get("native_index_ref", {})
    expected_graph = native_index.get("binding", {}).get("graph_id")
    expected_resource = native_resource.get("resource_id") or expected_graph
    if expected_resource:
        _require(resource["resource_id"] == expected_resource, "Observer resource ID changed")
    _require(gate["resource_binding"] == resource and gate["query_sha256"] == packet["query_sha256"], "Observer query/resource changed")
    _require(gate.get("task") == context["task"], "Observer task changed")
    return dict(layer="observer", engine=gate["version"], record_sha256=digest(gate),
        source_decision_engine=gate.get("source_decision_engine"),
        binding=deepcopy(binding), judgment_identity_preserved=True)


def _observer_observation(packet, record):
    """Observe current-evidence-decision atom shapes as a distinct judgment layer."""
    context = _packet_context(packet)
    _require(context["task"] in {"mosaic", "hypothesis"}, "Expected an assertion task")
    identity = _observer_identity(record, packet)
    gate = record["local_decisions_v65"]
    required = _required_atoms(packet)
    _require(gate["overall"]["required_components"] == required["denominator"], "Observer denominator changed")
    rows = gate["decisions"]
    _unique([u["id"] for u in rows], "observer atom IDs")
    _require([u["id"] for u in rows] == [a["id"] for a in packet["plan"]["atoms"]], "Observer required IDs changed")
    mapping = {"SUPPORT": "SUPPORTED", "ESTABLISHED": "SUPPORTED", "OPPOSED": "OPPOSED",
        "CONFLICTED": "CONFLICTED", "PARTIAL": "PARTIAL", "UNRESOLVED": "ASSESSED_NO_SUPPORT", "INSUFFICIENT": "ASSESSED_NO_SUPPORT"}
    units = []
    for row, atom in zip(rows, packet["plan"]["atoms"]):
        _require(row["text"] == atom["text"] and row["required"] == atom["required"], "Observer unit content changed")
        if atom["required"]:
            _require(row["native_current_status"] in mapping, "Unknown observer native status")
            units.append(_observed_unit(row, mapping[row["native_current_status"]]))
    return _assemble_certificate(context=context, required_units=required,
        engine=dict(layer="observer", name="current display assertion projection", version=gate["version"], record_sha256=digest(gate)),
        units=units, native_status=gate["overall"]["status"], scope=_certificate_scope(units, gate.get("source_scope")),
        identities=dict(native=context["native_identity"], observer=identity, model_assessment=None),
        provenance=dict(adapter_version=ADAPTER_VERSION, observation_only=True, old_native_resealed=False))


def _redaction_observation(packet, candidate_id, *, record=None):
    """Snapshot existing candidate-local focal requirements; never infer recovery.

    Without record: gate saved during native construction. With record: separately
    versioned displayed gate. These may disagree and are never silently merged.
    """
    context = _packet_context(packet)
    _require(context["task"] == "redaction", "Expected Redaction")
    candidates = [c for r in packet["result"]["readings"] for c in r["candidates"]]
    _unique([c["id"] for c in candidates], "native candidate IDs")
    matches = [c for c in candidates if c["id"] == candidate_id]
    _require(len(matches) == 1, "Candidate is missing or duplicated")
    candidate = matches[0]
    observer = _observer_identity(record, packet) if record is not None else None
    decision = (record["local_decisions_v65"]["candidates"][candidate_id] if record is not None
                else candidate["local_decision"])
    _require(decision["id"] == candidate_id and decision["reading_id"] == candidate["reading_id"] and
        decision["text"] == candidate["fill"], "Candidate/reading/fill binding changed")
    raw = decision["requirements"]
    native_requirements = candidate["local_decision"]["requirements"]
    required = freeze_required_units(native_requirements, denominator=len(native_requirements),
        authority="saved candidate.local_decision.requirements cardinality (producer has no numeric count)")
    observed_required = freeze_required_units(raw, denominator=len(raw), authority=required["authority"])
    _require(observed_required == required, "Observer focal required-unit set differs from native; no invented mapping")
    units = []
    for row in raw:
        witnesses = _witnesses(row.get("evidence", []))
        signs = {w["sign"] for w in witnesses}
        support, opposition = "SUPPORT" in signs, "OPPOSITION" in signs
        _require((row["coverage"] == "Established") == support, "Observed focal coverage/sign mismatch")
        _require(row["counterevidence"] == opposition, "Observed focal counter/sign mismatch")
        state = ("CONFLICTED" if support and opposition else "SUPPORTED" if support else "OPPOSED" if opposition
            else "PARTIAL" if "PARTIAL" in signs else "CONTEXTUAL" if row.get("context_citations") else "ASSESSED_NO_SUPPORT")
        unit = _observed_unit(row, state)
        unit["witnesses"].extend(_witnesses([dict(direction="Context", citations=row["context_citations"])]) if row.get("context_citations") else [])
        units.append(unit)
    coverage = signed_coverage(units, required)
    grammar = [c for c in decision["checklist"] if c["id"] == "grammar"]
    _require(len(grammar) <= 1, "Duplicate grammar checks")
    grammar_state = {"pass": "PASS", "fail": "FAIL", "missing": "UNASSESSED", "unmodeled": "UNMODELED"}
    _require(not grammar or grammar[0]["state"] in grammar_state, "Unknown grammar check state")
    redaction = dict(grammar=dict(state=grammar_state[grammar[0]["state"]] if grammar else "UNASSESSED",
        reasons=[grammar[0]["detail"] if grammar else "NO_SAVED_GRAMMAR_ASSESSMENT"]), focal_support=coverage,
        wider_event=dict(state="UNASSESSED", reasons=["FOCAL_GATE_DOES_NOT_CERTIFY_WIDER_EVENT"]),
        exact_recovery=dict(state="UNASSESSED", reasons=["NO_SEPARATE_REFERENCE_COMPARISON_ATTACHED"]))
    if candidate.get("sources"):
        redaction["context_witnesses"] = _witnesses([dict(direction="Context", citations=candidate["sources"])])
    identities = dict(native=context["native_identity"], observer=observer, model_assessment=None)
    return _assemble_certificate(context=context, required_units=required,
        engine=dict(layer="observer" if observer else "native", name="saved Redaction focal gate",
            version=record["local_decisions_v65"]["version"] if observer else packet["result"]["evidence_gate_version"],
            record_sha256=digest(decision)), units=units, native_status=decision["status"],
        scope=_certificate_scope(units, decision.get("scope")), identities=identities,
        subject=dict(candidate_id=candidate_id, reading_id=candidate["reading_id"], fill=candidate["fill"]),
        redaction=redaction, provenance=dict(adapter_version=ADAPTER_VERSION, observation_only=True,
            old_native_resealed=False, original_decision=deepcopy(decision)))


def model_assessment_identity(assessment, *, observer_gate):
    """Adapt an observed V65 assessment attachment as identity/opinion ONLY.

    No grades, exact recovery or support signs are imported into local decisions.
    Source assessment_ref replay remains the consumer's responsibility.
    """
    _require(assessment["gate_version"] == observer_gate["version"] and
        assessment["gate_sha256"] == digest(observer_gate), "Model opinion belongs to another observer gate")
    _text(assessment["version"], "assessment version")
    _require(assessment.get("used_for_inference") is False, "Model assessment must remain post-run only")
    _hash(assessment["assessment_ref"]["sha256"], "model assessment reference")
    _text(assessment["assessment_ref"]["path"], "model assessment reference path")
    return dict(layer="model_assessment", engine=assessment["version"],
        record_sha256=digest(assessment), gate_sha256=assessment["gate_sha256"],
        assessment_ref=deepcopy(assessment["assessment_ref"]), used_for_inference=False,
        opinion_only=True, grades=deepcopy(assessment["grades"]))


def _scopes(value):
    scopes = {"certificate": value["scope"]}
    for unit in value["units"]:
        key = "unit:" + unit["id"]
        scopes[key] = unit["scope"]
        for index, witness in enumerate(unit["witnesses"]):
            scopes[key + ":witness:" + str(index)] = witness["scope"]
    for index, witness in enumerate((value.get("redaction") or {}).get("context_witnesses", [])):
        scopes["redaction:context:" + str(index)] = witness["scope"]
    return scopes


def _judgment(value):
    return {key: value[key] for key in ("required_units", "engine", "native_status", "scope",
        "units", "subject", "redaction", "identities", "coverage", "provenance")}


def _register_producer(context, observation, *, producer_kind, source_sha256):
    """Private authoring boundary: called only from independently supplied inputs.

    Never call this with a submitted DTO. A digest is a binding, not a signature;
    callers must authenticate the source records before constructing context.
    """
    authority = deepcopy(dict(version=AUTHORITY_VERSION, producer_kind=producer_kind,
        source_sha256=source_sha256, binding_sha256=digest(context["binding"]),
        engine=observation["engine"], native_status=observation["native_status"],
        identities=observation["identities"], scopes=_scopes(observation),
        judgment_sha256=digest(_judgment(observation))))
    context.setdefault("producer_authorities", {})[digest(authority)] = authority


def _with_assessment(observation, record, assessment):
    if assessment is not None:
        _require(record is not None, "A model opinion needs its independent observer record")
        observation["identities"]["model_assessment"] = model_assessment_identity(
            assessment, observer_gate=record["local_decisions_v65"])
    return observation


def context_for_packet(packet, *, record=None, assessment=None, candidate_id=None):
    """Build trusted authority OUTSIDE the DTO from authenticated producer inputs.

    Native observations are reproduced from the original packet. Observer and
    model authority additionally require their own independently retained records.
    Passing a submitted certificate as any of these inputs is not a trust boundary.
    """
    context = _packet_context(packet)
    _require(assessment is None or record is not None, "Model authority needs an independent observer")
    if context["task"] == "redaction":
        subjects = [candidate_id] if candidate_id is not None else list(context["subjects"])
        _require(all(identity in context["subjects"] for identity in subjects), "Unknown trusted candidate selector")
        native = [_redaction_observation(packet, identity) for identity in subjects] if record is None else []
        observed = ([_redaction_observation(packet, identity, record=record) for identity in subjects]
                    if record is not None else [])
    else:
        _require(candidate_id is None, "Assertion authority cannot select a Redaction candidate")
        native = [_native_observation(packet)] if record is None else []
        observed = [_observer_observation(packet, record)] if record is not None else []
    for observation in native:
        _register_producer(context, observation, producer_kind="native",
                           source_sha256=context["binding"]["native_packet_sha256"])
    for observation in observed:
        _register_producer(context, _with_assessment(observation, record, assessment),
            producer_kind="observer", source_sha256=digest(dict(record=record, assessment=assessment)))
    context.setdefault("producer_authorities", {})
    return context


def _finalize(observation, context):
    wanted = digest(_judgment(observation))
    matches = [key for key, authority in context.get("producer_authorities", {}).items()
               if authority["judgment_sha256"] == wanted]
    _require(len(matches) == 1, "Observation has no unique independently trusted producer authority")
    value = deepcopy(observation)
    value["producer_authority_sha256"] = matches[0]
    return validate_certificate(value, expected_context=context, expected_required_units=value["required_units"])


def make_certificate(*, context, **judgment):
    """Build only an observation already authorized by independent producer input.

    This function cannot register authority from its submitted judgment fields.
    Use context_for_packet or context_for_producer before accepting a DTO.
    """
    return _finalize(_assemble_certificate(context=context, **judgment), context)


def adapt_native_assertions(packet):
    return _finalize(_native_observation(packet), context_for_packet(packet))


def adapt_observer_assertions(packet, record, *, assessment=None):
    context = context_for_packet(packet, record=record, assessment=assessment)
    return _finalize(_with_assessment(_observer_observation(packet, record), record, assessment), context)


def adapt_redaction_candidate(packet, candidate_id, *, record=None, assessment=None):
    context = context_for_packet(packet, record=record, assessment=assessment, candidate_id=candidate_id)
    observation = _redaction_observation(packet, candidate_id, record=record)
    return _finalize(_with_assessment(observation, record, assessment), context)


def _explicit_observation(packet, producer_record):
    """A different future producer is an explicit, independently trusted record."""
    context = _packet_context(packet)
    _require(producer_record.get("version") == "narrative-explicit-producer-record/1", "Unsupported explicit producer record")
    _require(producer_record.get("binding") == context["binding"], "Explicit producer belongs to another native packet")
    required = producer_record["required_units"]
    _require(required == freeze_required_units(required["units"], denominator=required["denominator"],
        authority=required["authority"]), "Explicit producer required snapshot changed")
    judgment = deepcopy(producer_record["judgment"])
    if context["task"] == "redaction":
        subject = judgment["subject"]
        _require(context["subjects"].get(subject["candidate_id"]) == subject, "Explicit producer candidate changed")
        candidates = [c for row in packet["result"]["readings"] for c in row["candidates"]]
        candidate = next(c for c in candidates if c["id"] == subject["candidate_id"])
        rows = candidate["local_decision"]["requirements"]
        expected = freeze_required_units(rows, denominator=len(rows), authority=required["authority"])
    else:
        expected = _required_atoms(packet)
    _require(required["units"] == expected["units"] and required["denominator"] == expected["denominator"],
             "Explicit producer cannot redefine the existing required set")
    header = producer_record["engine"]
    _require(set(header) == {"layer", "name", "version"} and header["layer"] in {"native", "observer"},
             "Explicit producer needs a separate engine identity; record digest is derived")
    identities = dict(native=context["native_identity"], observer=None, model_assessment=None)
    if header["layer"] == "observer":
        identities["observer"] = dict(layer="observer", engine=header["version"], record_sha256=digest(producer_record),
            binding=dict(case_id=packet["case"]["case_id"], query_sha256=packet["query_sha256"],
                         native_checksum=packet["native_checksum"]))
    observation = _assemble_certificate(context=context, required_units=required,
        engine=dict(header, record_sha256=digest(producer_record)), identities=identities,
        provenance=dict(adapter_version=ADAPTER_VERSION, explicit_producer_record=True,
                        source_record_sha256=digest(producer_record), old_native_resealed=False), **judgment)
    return context, observation


def context_for_producer(packet, producer_record):
    """Trust an independently authenticated NEW producer record, never a DTO.

    This is an explicit trust input, like the original native/observer records.
    The record must be retained and byte-verified outside the submitted DTO.
    No API, inference, source replay or semantic approval occurs here.
    """
    context, observation = _explicit_observation(packet, producer_record)
    _register_producer(context, observation, producer_kind="explicit", source_sha256=digest(producer_record))
    return context


def adapt_producer_record(packet, producer_record):
    context = context_for_producer(packet, producer_record)
    _, observation = _explicit_observation(packet, producer_record)
    return _finalize(observation, context)
