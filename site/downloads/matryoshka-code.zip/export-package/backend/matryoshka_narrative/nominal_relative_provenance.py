"""Exact public/source bindings for context-only helper calls; no file/model I/O."""
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK,public_case
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE,source_page_allowed
from matryoshka_narrative import adjunct_candidates as shared

VERSION = "exact-public-source-context-bindings/2"
REGISTERED_PREFIX = re.compile(r"^(?P<label>Comment:)(?P<separator>\s+)",re.I)


def paragraphs(text):
    for block in re.finditer(r"\S[\s\S]*?(?=\n\s*\n|\Z)",text):
        yield block.start(),block.end(),block.group()


def focal_context(case):
    text,marker = case["query"],case["focal_marker"]
    at,end = text.index(marker),text.index(marker)+len(marker)
    left,right = 0,len(text)
    for match in re.finditer(r"\n\s*\n",text):
        if match.end() <= at:
            left = match.end()
        elif match.start() >= end:
            right = match.start()
            break
    for match in MASK.finditer(text):
        if match.end() <= at:
            left = max(left,match.end())
        elif match.start() >= end:
            right = min(right,match.start())
            break
    return dict(span=[left,right],text=text[left:right],rule="EXACT_FOCAL_PARAGRAPH_AND_VISIBLE_COMPONENT")


def public_binding(case,reading):
    shared._inputs(case,reading)
    return dict(version=VERSION,case=deepcopy(case),case_sha256=digest(case),query_sha256=digest(case["query"]),
        focal_marker=case["focal_marker"],reading_id=reading["id"],reading_sha256=digest(reading),
        query_context=focal_context(case))


def validate_public_binding(pool,case,reading,query_text):
    expected = public_binding(case,reading)
    if (pool.get("public_binding") != expected or pool.get("declared_reading") != reading
            or pool.get("reading_id") != reading["id"] or pool.get("query_context") != expected["query_context"]):
        raise ValueError("EXACT_PUBLIC_BINDING_CHANGED: case/query/span/reading receipt")
    if query_text != expected["query_context"]["text"]:
        raise ValueError("EXACT_QUERY_TEXT_CHANGED: lemma equality is not a query receipt")
    return expected


def canonical_pages(case,pages,expected_page_ids):
    if not isinstance(case,dict) or set(case) != {"case_id","corpus","task","query","document_id","date","focal_marker"}:
        raise ValueError("Exact seven-field public case required")
    public_case(case)
    if (not isinstance(pages,(list,tuple)) or not isinstance(expected_page_ids,(list,tuple))
            or [p["id"] for p in pages] != list(expected_page_ids)
            or len(set(expected_page_ids)) != len(expected_page_ids)):
        raise ValueError("EXACT_ORDINARY_POOL_CHANGED")
    by_id = {}
    for page in pages:
        if not source_page_allowed(page,case,SOURCE_DAY_INCLUSIVE) or digest(page["text"]) != page["source_sha256"]:
            raise ValueError("ORDINARY_SOURCE_POLICY_OR_TEXT_HASH_CHANGED: source policy or canonical text hash")
        by_id[page["id"]] = page
    return by_id


def _slice(text,span):
    if (not isinstance(span,(list,tuple)) or len(span)!=2 or any(type(v) is not int for v in span)
            or not 0 <= span[0] < span[1] <= len(text)):
        raise ValueError("SOURCE_COORDINATES_INVALID")
    return text[span[0]:span[1]]


def _quoted_tree(value,text):
    if isinstance(value,list):
        for child in value:
            _quoted_tree(child,text)
    elif isinstance(value,dict):
        if "text" in value and "start" in value and "end" in value:
            if _slice(text,[value["start"],value["end"]]) != value["text"]:
                raise ValueError("SOURCE_TOKEN_REPLAY_FAILED")
        elif "text" in value and "span" in value and _slice(text,value["span"]) != value["text"]:
            raise ValueError("SOURCE_SCOPE_REPLAY_FAILED")
        for child in value.values():
            if isinstance(child,(list,dict)):
                _quoted_tree(child,text)


def replay_occurrence(occurrence,by_id,*,fill):
    """Actual canonical substrings, not a claimed page hash, authorize wording."""
    try:
        page = by_id[occurrence["source_page_id"]]
        text = page["text"]
        if (occurrence["source_document_id"] != page["document_id"] or occurrence["source_date"] != page["date"]
                or occurrence["source_page_sha256"] != page["source_sha256"] or digest(text) != page["source_sha256"]):
            raise ValueError("SOURCE_PAGE_BINDING_CHANGED")
        span = [occurrence["source_sentence_start"],occurrence["source_sentence_end"]]
        body = _slice(text,span)
        if body != occurrence["source_sentence"] or MASK.search(body):
            raise ValueError("SOURCE_BODY_REPLAY_FAILED")
        if _slice(text,occurrence["source_subject"]["span"]) != occurrence["source_subject"]["text"]:
            raise ValueError("SOURCE_SUBJECT_REPLAY_FAILED")
        if _slice(text,occurrence["source_predicate_span"]) != occurrence["source_predicate_text"]:
            raise ValueError("SOURCE_PREDICATE_REPLAY_FAILED")
        for key in ("source_subject","source_copula","source_predicate_tokens","nested_finite_clauses","source_qualifier_scopes"):
            _quoted_tree(occurrence.get(key,[]),text)
        for edit in reversed(occurrence["operation_license"]["replacements"]):
            lo,hi = edit["span"]
            if not span[0] <= lo < hi <= span[1] or text[lo:hi] != edit["before"]:
                raise ValueError("SOURCE_OPERATION_REPLAY_FAILED")
            a,b = lo-span[0],hi-span[0]
            body = body[:a]+edit["after"]+body[b:]
        if body != fill or occurrence["fill"] != fill:
            raise ValueError("SOURCE_GENERATED_SURFACE_REPLAY_FAILED")
        parent_bounds = next((p for p in paragraphs(text) if p[0] <= span[0] and span[1] <= p[1]),None)
        if parent_bounds is None:
            raise ValueError("SOURCE_PARENT_NOT_IN_ONE_RAW_PARAGRAPH")
        parent = occurrence["source_parent_quote"]
        if parent["span"] != list(parent_bounds[:2]) or parent["text"] != parent_bounds[2]:
            raise ValueError("WHOLE_RAW_PARENT_REPLAY_FAILED")
        registered = REGISTERED_PREFIX.match(parent["text"]) if page["corpus"]=="cib" else None
        if registered:
            if MASK.search(parent["text"]):
                raise ValueError("MASKED_COMMENT_PARENT_MUST_HOLD")
            operator = occurrence["source_assessment_operator"]
            view = occurrence["source_parse_partition"]
            start,end = parent["span"]
            expected_label = [start,start+registered.end("label")]
            expected_body = [start+registered.end(),end]
            if (operator["span"] != expected_label or operator["text"] != _slice(text,expected_label)
                    or operator["source_scope_span"] != parent["span"] or operator["source_scope_text"] != parent["text"]
                    or operator["kind"] != "COMMENT_ASSESSMENT" or operator["assessment_is_verified_truth"] is not False
                    or operator["assessment_is_completed_decision"] is not False or operator["source_authority_credit_added"] is not False
                    or view["body_span"] != expected_body or view["body_text"] != _slice(text,expected_body)):
                raise ValueError("COMMENT_OPERATOR_OR_BODY_SCOPE_CHANGED")
        elif "source_assessment_operator" in occurrence:
            raise ValueError("UNREGISTERED_COMMENT_OPERATOR")
        if occurrence["factual_support_certified"] is not False:
            raise ValueError("CONTEXT_CANNOT_CERTIFY_FACTS")
    except (KeyError,TypeError,StopIteration) as error:
        raise ValueError("INCOMPLETE_SOURCE_RECEIPT") from error
    return True


def pool_fingerprint(pool):
    """Unknown annotations never score; exact duplicate source receipts add no votes."""
    candidates = []
    for candidate in pool["proposals"]:
        candidates.append(dict(id=candidate["id"],fill=candidate["fill"],
            compatibility=candidate["compatibility"],context_order=candidate["context_order"],
            source_occurrence_hashes=sorted({digest(o) for o in candidate["source_occurrences"]}),
            factual_support_certified=candidate["factual_support_certified"]))
    return digest(dict(version=pool["version"],nested_finite=pool["nested_finite"],
        factual_support_certified=pool["factual_support_certified"],
        source_scope_receipts={key:pool[key] for key in ("source_shape_holds","raw_source_occurrence_n",
            "distinct_surface_n","cap_reached","held_comment_paragraphs") if key in pool},
        public_binding=pool["public_binding"],reading=pool["declared_reading"],
        inspected_page_ids=pool["inspected_page_ids"],proposal_cap=pool["proposal_cap"],eligible=pool["eligible"],
        query_context=pool["query_context"],context_order_ids=pool["context_order_ids"],
        syntax_accepted_context_order_ids=pool["syntax_accepted_context_order_ids"],candidates=candidates))

