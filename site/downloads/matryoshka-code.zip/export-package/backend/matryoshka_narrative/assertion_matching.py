"""Source-frame matching with an explicit root-content ascription certificate."""
from copy import deepcopy

from . import matching as baseline
from .nonfactive_content_v53 import evaluate, VERSION as CONTENT_POLICY_VERSION
from .nominal_bindings import evaluate as nominal_evaluate
from .prename_role_binding import evaluate as prename_evaluate
from .qualified_account_bindings import evaluate as account_evaluate

VERSION = "narrative-root-content-source-matching/8"
REVIEWED_CONTENT_POLICY = "narrative-root-nonfactive-content-experiment/5.3"
class MatcherCase:
    """Keep the v4 control intact; attest a requested operator, not inner action."""
    def __init__(self, *args, **kwargs):
        self.baseline = baseline.MatcherCase(*args, **kwargs)

    def supplement(self, atom, page, unit):
        if CONTENT_POLICY_VERSION != REVIEWED_CONTENT_POLICY:
            raise RuntimeError("Root-content policy version is not independently cleared; ordinary execution is blocked")
        control = self.baseline.supplement(atom, page, unit)
        projected = evaluate(self.baseline, atom, page, unit)
        if not projected["root_content_policy_applicable"]:
            nominal = nominal_evaluate(self.baseline, atom, page, unit, control)
            if nominal["direction"] != "SUPPORT":
                prename = prename_evaluate(self.baseline, atom, page, unit, control)
                if prename["direction"] == "SUPPORT":
                    nominal = prename
            if nominal["applicable"]:
                row = deepcopy(control)
                row["nominal_binding_audit"] = nominal
                if nominal["direction"] == "SUPPORT" and control["direction"] in {"UNRESOLVED", "PARTIAL"}:
                    row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
                        source_assertion_not_world_truth=True, qualified=True,
                        qualified_account="The eligible source explicitly describes the named subject's historical role; its matrix action and continued tenure are not established.",
                        support_scope="HISTORICAL_NOMINAL_ROLE_SOURCE_ASCRIPTION",
                        source_attestation_not_persistence=True,
                        source_ascription_date=page["date"],
                        nominal_role_certificate=deepcopy(nominal["certificate"]),
                        strict_v4_control=deepcopy(control), event_bindings=[],
                        actual_inner_event_established=False, canonical_identity_certified=False,
                        cross_atom_or_event_join_certified=False)
                    row["checks"].update(nominal_role_binding="PASS", event_join="NOT_CERTIFIED")
                return row
            account = account_evaluate(self.baseline, atom, page, unit, control)
            if account["applicable"]:
                row = deepcopy(control)
                row["qualified_source_account_audit"] = account
                if account.get("form_policy_withheld"):
                    row.update(version=VERSION, direction="UNRESOLVED", complete_required_frames=False,
                        source_account_policy_withheld=True, strict_v4_control=deepcopy(control), event_bindings=[],
                        actual_inner_event_established=False, canonical_identity_certified=False,
                        cross_atom_or_event_join_certified=False)
                    row["checks"].update(complete_qualified_source_account="WITHHELD_BY_FORM_POLICY", event_join="NOT_CERTIFIED")
                elif account.get("potential_counter"):
                    row.update(version=VERSION, direction="PARTIAL", complete_required_frames=False,
                        potential_counter=True, counter_scope="UNMODELED",
                        potential_counter_receipt=deepcopy(account["counter_receipt"]),
                        strict_v4_control=deepcopy(control), event_bindings=[],
                        actual_inner_event_established=False, canonical_identity_certified=False,
                        cross_atom_or_event_join_certified=False)
                    row["checks"].update(complete_qualified_source_account="POTENTIAL_COUNTER_SCOPE_UNMODELED", event_join="NOT_CERTIFIED")
                elif account["direction"] == "SUPPORT":
                    row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
                        qualified=True, source_assertion_not_world_truth=True,
                        qualified_account="The eligible source attests the complete account with its reported, planned or disjunctive scope preserved; independent execution and continuing tenure are not established.",
                        support_scope="COMPLETE_QUALIFIED_HISTORICAL_SOURCE_ACCOUNT",
                        source_account_certificate=deepcopy(account["certificate"]),
                        strict_v4_control=deepcopy(control), event_bindings=[],
                        actual_inner_event_established=False, canonical_identity_certified=False,
                        cross_atom_or_event_join_certified=False,
                        source_attestation_not_persistence=True,
                        source_ascription_date=row["citation"]["date"])
                    row["checks"].update(complete_qualified_source_account="PASS", event_join="NOT_CERTIFIED")
                return row
            return control
        if projected["direction"] != "SUPPORT":
            row = deepcopy(control)
            row.update(version=VERSION,direction="UNRESOLVED",complete_required_frames=False,
                root_content_policy_applicable=True,root_content_withheld=True,
                root_content_audit=deepcopy(projected),strict_v4_control=deepcopy(control),
                event_bindings=[],actual_inner_event_established=False,
                canonical_identity_certified=False,cross_atom_or_event_join_certified=False)
            row["checks"].update(queried_root_operator="WITHHELD",inner_action_execution="NOT_CLAIMED",
                event_join="NOT_CERTIFIED")
            return row
        certificate = projected["source_attestation"]
        if (not certificate or projected["event_bindings"]
                or any(certificate[k] for k in ("inner_actor_assigned", "inner_actor_certified",
                    "inner_execution_certified", "canonical_identity_certified",
                    "cross_atom_or_event_join_certified"))):
            raise ValueError("Root-content certificate cannot assert inner execution or identity")
        row = deepcopy(control)
        row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
            root_content_policy_applicable=True,root_content_withheld=False,
            source_assertion_not_world_truth=True, qualified=True,
            qualified_account="The eligible source records the queried past operator and its content; the embedded action is not established.",
            source_ascription_policy=VERSION, source_ascription_date=row["citation"]["date"],
            source_attestation_not_persistence=True,
            root_content_certificate=deepcopy(certificate),
            support_scope=projected["support_scope"],
            event_bindings=[], actual_inner_event_established=False,
            canonical_identity_certified=False, cross_atom_or_event_join_certified=False,
            strict_v4_control=deepcopy(control))
        row["checks"].update(queried_root_operator="PASS", own_branch_clock="PASS",
            inner_action_execution="NOT_CLAIMED", event_join="NOT_CERTIFIED")
        return row
