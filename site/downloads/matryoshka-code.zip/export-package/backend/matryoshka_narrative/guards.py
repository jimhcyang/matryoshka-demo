"""Execution boundaries shared by narrative planning, checkpoints and publication."""
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil

MINIMUM_FREE_BYTES = 8 * 1024**3


def remaining_seconds(*, new_work=False):
    field = "NARRATIVE_NO_NEW_WORK_UTC" if new_work else "NARRATIVE_DEADLINE_UTC"
    value = os.environ.get(field) or os.environ.get("NARRATIVE_DEADLINE_UTC")
    if not value:
        return None
    end = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if end.tzinfo is None:
        raise ValueError("Narrative deadline must have an explicit timezone")
    remaining = (end - datetime.now(timezone.utc)).total_seconds()
    if remaining <= 0:
        raise TimeoutError("Narrative execution deadline reached; preserve completed artifacts")
    return remaining


def require_headroom(path, *, disk_usage=None):
    """Testable without exhausting the user's disk; never removes old artifacts."""
    remaining_seconds()
    target = Path(path).resolve()
    while not target.exists() and target != target.parent:
        target = target.parent
    usage = (disk_usage or shutil.disk_usage)(target)
    if usage.free < MINIMUM_FREE_BYTES:
        raise OSError("8 GiB free-disk guard required")
    return usage.free
