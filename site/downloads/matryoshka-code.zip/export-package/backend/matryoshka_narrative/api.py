"""A separate, locked $50 authorization for this narrative development phase."""
from datetime import datetime, timezone
import fcntl
import json
import math
import os
from pathlib import Path
import re
import uuid

from matryoshka_demo.api_v2 import RATES, request, transport_policy
from matryoshka_demo.io import digest, load, save
from .guards import require_headroom, remaining_seconds

VERSION = "narrative-development-api/1"
AUTHORIZATION = "narrative-demo-new-phase-50-usd"
CEILING = 50.0


def utc():
    return datetime.now(timezone.utc).isoformat()


def _usage(raw):
    usage = raw.get("usage") or {}
    if any(type(usage.get(key)) is not int or usage[key] < 0 for key in ("input_tokens", "output_tokens")):
        raise ValueError("Usage must contain nonnegative integer counts; reservation retained")
    return usage


def _output(raw):
    if raw.get("status") != "completed":
        raise ValueError("Incomplete provider response")
    texts = [part["text"] for item in raw.get("output", []) if item.get("type") == "message"
        for part in item.get("content", []) if part.get("type") == "output_text"]
    if len(texts) != 1:
        raise ValueError("Exactly one structured response required")
    return json.loads(texts[0])


class Budget:
    def __init__(self, root, cap=CEILING):
        if type(cap) not in (float, int) or not math.isfinite(cap) or not 0 < cap <= CEILING:
            raise ValueError("Narrative development has a hard $50 ceiling")
        self.root, self.cap = Path(root), float(cap)
        self.root.mkdir(parents=True, exist_ok=True)
        with (self.root / "budget.lock").open("a+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            path = self.root / "authorization.json"
            expected = dict(version=VERSION, authorization=AUTHORIZATION, ceiling_usd=CEILING)
            if path.exists() and load(path) != expected:
                raise ValueError("This directory belongs to another budget authorization")
            if not path.exists():
                if list((self.root / "receipts").glob("*.json")):
                    raise ValueError("Do not reset or adopt an existing phase ledger")
                save(path, expected)

    def total(self):
        values = [load(p) for p in (self.root / "receipts").glob("*.json")]
        if any(v.get("authorization") != AUTHORIZATION or
               type(v.get("charged_or_reserved_usd")) not in (int, float) or
               not math.isfinite(v["charged_or_reserved_usd"]) or
               not 0 <= v["charged_or_reserved_usd"] <= CEILING for v in values):
            raise ValueError("Invalid narrative budget receipt")
        return sum(v["charged_or_reserved_usd"] for v in values)

    def reserve(self, wire, amount):
        if not math.isfinite(amount) or amount <= 0:
            raise ValueError("Positive finite reservation required")
        with (self.root / "budget.lock").open("a+") as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            if self.total() + amount > self.cap:
                raise RuntimeError("Narrative API budget reached; saved checkpoints remain resumable")
            baseline = os.environ.get("NARRATIVE_INCREMENTAL_BASELINE_USD")
            envelope = os.environ.get("NARRATIVE_INCREMENTAL_CEILING_USD")
            if baseline is not None or envelope is not None:
                if baseline is None or envelope is None:
                    raise ValueError("Both incremental budget bounds are required")
                baseline, envelope = float(baseline), float(envelope)
                if (not math.isfinite(baseline) or not math.isfinite(envelope)
                        or baseline < 0 or envelope < 0):
                    raise ValueError("Invalid incremental budget bounds")
                if self.total() + amount - baseline > envelope + 1e-10:
                    raise RuntimeError("Narrative job envelope reached; cumulative authorization is unchanged")
            path = self.root / "receipts" / (uuid.uuid4().hex + ".json")
            record = dict(version=VERSION, authorization=AUTHORIZATION, status="RESERVED",
                request_sha256=digest(wire), model=wire["model"], charged_or_reserved_usd=amount,
                started_utc=utc(), cap_usd=self.cap, rates=RATES[wire["model"]],
                pricing="Workspace listed prices, not a provider invoice")
            save(path, record)
            return path, record


def call(root, stage, payload, prompt, schema, *, model="gpt-6-luna", max_output_tokens=6000,
         cap=CEILING, client=None):
    """Exactly one attempt, exact-wire caching, no invisible retries."""
    import jsonschema
    wire = request(stage, payload, prompt, schema, model=model, max_output_tokens=max_output_tokens)
    key = digest(dict(version=VERSION, endpoint="https://api.openai.com/v1", stage=stage, request=wire))
    budget = Budget(root, cap)
    lockdir = budget.root / "request_locks"
    lockdir.mkdir(exist_ok=True)
    with (lockdir / (key + ".lock")).open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        cache = budget.root / "cache" / (key + ".json")
        if cache.exists():
            prior = load(cache)
            if not isinstance(prior.get("receipt_path"), str) or not re.fullmatch(
                    r"receipts/[a-f0-9]{32}\.json", prior["receipt_path"]):
                raise ValueError("Unsafe cached receipt path")
            for relative in (prior["receipt_path"], "attempts/" + Path(prior["receipt_path"]).stem + "/response.json",
                    "attempts/" + Path(prior["receipt_path"]).stem + "/request.json"):
                target = budget.root / relative
                if target.is_symlink() or not target.resolve().is_relative_to(budget.root.resolve()):
                    raise ValueError("Receipt or retained attempt escapes the phase root")
            receipt = load(budget.root / prior["receipt_path"])
            attempt = budget.root / "attempts" / Path(prior["receipt_path"]).stem
            raw = load(attempt / "response.json")
            usage = _usage(raw)
            expected_cost = (usage["input_tokens"] * RATES[model][0] + usage["output_tokens"] * RATES[model][1]) / 1e6
            if (prior["request"] != wire or digest(prior["output"]) != prior["output_sha256"] or
                    receipt["status"] != "PASS" or receipt["request_sha256"] != digest(wire) or
                    receipt.get("authorization") != AUTHORIZATION or receipt.get("model") != model or
                    receipt.get("usage") != usage or receipt["charged_or_reserved_usd"] != expected_cost or
                    load(attempt / "request.json") != wire or _output(raw) != prior["output"] or
                    receipt.get("response_sha256", digest(raw)) != digest(raw)):
                raise ValueError("Cached response or successful receipt changed")
            jsonschema.validate(prior["output"], schema)
            return prior["output"], dict(request_sha256=key, cache=True, receipt=prior["receipt_path"])
        in_rate, out_rate = RATES[model]
        reserve = ((len(json.dumps(wire, ensure_ascii=True).encode()) + 4096) * in_rate +
                   max_output_tokens * out_rate) / 1e6
        seconds = remaining_seconds(new_work=True)
        require_headroom(budget.root)
        receipt_path, record = budget.reserve(wire, reserve)
        attempt = budget.root / "attempts" / receipt_path.stem
        save(attempt / "request.json", wire)
        try:
            if client is None:
                from openai import OpenAI
                import httpx
                policy = transport_policy()
                response_seconds = min(policy["response_seconds"], seconds) if seconds is not None else policy["response_seconds"]
                connect_seconds = min(policy["connect_seconds"], response_seconds)
                client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"), max_retries=0,
                    base_url="https://api.openai.com/v1", timeout=httpx.Timeout(response_seconds,
                    connect=connect_seconds, pool=connect_seconds))
            response = client.responses.create(**wire)
            raw = response.model_dump(mode="json") if hasattr(response, "model_dump") else response
            save(attempt / "response.json", raw)
            usage = _usage(raw)
            actual = (usage["input_tokens"] * in_rate + usage["output_tokens"] * out_rate) / 1e6
            save(receipt_path, dict(record, status="PAID_INVALID_OUTPUT", usage=usage,
                charged_or_reserved_usd=actual, response_id=raw.get("id"), finished_utc=utc()))
            if actual > reserve or budget.total() > cap:
                raise RuntimeError("Usage exceeded conservative reservation")
            output = _output(raw)
            jsonschema.validate(output, schema)
            relative = str(receipt_path.relative_to(budget.root))
            save(receipt_path, dict(load(receipt_path), status="PASS", response_sha256=digest(raw)))
            save(cache, dict(version=VERSION, request=wire, output=output,
                output_sha256=digest(output), receipt_path=relative))
            return output, dict(request_sha256=key, cache=False, receipt=relative)
        except BaseException as error:
            current = load(receipt_path)
            save(receipt_path, dict(current, status="PAID_INVALID_OUTPUT" if "usage" in current else
                "FAILED_UNKNOWN_BILLING", error_type=type(error).__name__, finished_utc=utc()))
            raise
