"""Pure, unintegrated corpus-text restoration verifier, never event evidence.

V1 deliberately requires whole-page/whole-query scope. SourcePolicy validates
admission, not clause closure; this module cannot promote a clipped quotation
to a complete assertion. It nominates nothing and never overrides grammar.
"""
from dataclasses import dataclass
from copy import deepcopy
import re

from matryoshka_demo.contracts import FORBIDDEN, MASK, public_case
from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy, public_plan

VERSION = "narrative-corpus-textual-restoration/1"
KIND = "TEXTUAL_RESTORATION_WITNESS"
MAX_TEXT = 16384
MAX_FILL = 256
MAX_ANCHOR = 128
_WRAP = re.compile(r"(?<=[A-Za-z])-[ \t]*\r?\n[ \t]*(?=[A-Za-z])")
_WORD = re.compile(r"[A-Za-z0-9]+")
_FUNCTION = frozenset("a an the is was were be been being of to in on at by for and or "
    "not no if as it its that this these those with from are has had have do did does".split())
_PRIVATE = frozenset({"reference_answer", "answer_key", "evaluation_keys", "gold", "grades",
    "origin_text", "origin_body", "hidden_answer", "predicted_fill"}) | FORBIDDEN


def _public_inputs(*values):
    pending = list(values)
    count, characters = 0, 0
    while pending:
        value = pending.pop()
        count += 1
        if count > 20000:
            raise ValueError("PUBLIC_CANDIDATE_STRUCTURE_BUDGET")
        if isinstance(value, str):
            characters += len(value)
            if len(value) > MAX_TEXT or characters > 256 * 1024:
                raise ValueError("PUBLIC_CANDIDATE_CHARACTER_BUDGET")
        if isinstance(value, dict):
            if _PRIVATE.intersection(value):
                raise ValueError("PRIVATE_ANSWER_OR_ORIGIN_INPUT_FORBIDDEN")
            pending.extend(value.values())
        elif isinstance(value, (list, tuple)):
            pending.extend(value)


@dataclass(frozen=True)
class Normalized:
    text: str
    offsets: tuple
    line_hyphens: tuple


def normalize(text):
    """Case/whitespace/line-wrap hyphen only, with raw Unicode offset proofs.

    Inline hyphens, punctuation, quote marks, spelling and word order survive.
    Raw text is never mutated. A line-wrap deletion is an explicit textual
    normalization license, not an identity or semantic-equivalence assertion.
    """
    if not isinstance(text, str) or len(text) > MAX_TEXT:
        raise ValueError("TEXT_BUDGET_OR_TYPE")
    wraps = {m.start(): m for m in _WRAP.finditer(text)}
    chars, offsets, edits = [], [], []
    i = 0
    while i < len(text):
        if i in wraps:
            m = wraps[i]
            edits.append(dict(start=i, end=m.end(), text=m.group(), rule="OCR_LINE_HYPHEN"))
            i = m.end()
            continue
        if text[i].isspace():
            j = i + 1
            while j < len(text) and text[j].isspace():
                j += 1
            chars.append(" ")
            offsets.append((i, j))
            i = j
        else:
            for char in text[i].casefold():
                chars.append(char)
                offsets.append((i, i + 1))
            i += 1
    if chars and chars[-1] == " ":
        chars.pop()
        offsets.pop()
    if chars and chars[0] == " ":
        chars.pop(0)
        offsets.pop(0)
    return Normalized("".join(chars), tuple(offsets), tuple(edits))


def _interval(value, text):
    if (not isinstance(value, (tuple, list)) or len(value) != 2
            or any(type(n) is not int for n in value)):
        raise ValueError("INVALID_LITERAL_INTERVAL")
    a, b = value
    if not 0 <= a < b <= len(text):
        raise ValueError("INVALID_LITERAL_INTERVAL")
    return a, b


def _word_boundary(text, a, b):
    word = lambda c: c.isalnum() or c == "_"
    return not (a and word(text[a-1]) and word(text[a])) and not (
        b < len(text) and word(text[b-1]) and word(text[b]))


def _anchor(text, *, left):
    if len(text) <= MAX_ANCHOR:
        return text
    if left:
        start = text.find(" ", len(text) - MAX_ANCHOR)
        return text[start+1:] if start >= 0 else ""
    end = text.rfind(" ", 0, MAX_ANCHOR)
    return text[:end] if end >= 0 else ""


def _anchor_strength(left, right):
    words = [_WORD.findall(s) for s in (left, right)]
    return (all(len(w) >= 2 for w in words) and sum(map(len, words)) >= 8
        and all(any(len(t) >= 3 and t not in _FUNCTION for t in w) for w in words))


def _brackets(text, left, right):
    pairs = []
    # Lookaheads retain overlapping anchor hits; ambiguity cannot disappear
    # merely because the regex engine consumed a preceding copy.
    for hit in re.finditer("(?=" + re.escape(left) + ")", text):
        start = hit.start() + len(left)
        stop = min(len(text), start + MAX_FILL + len(right))
        for match in re.finditer("(?=" + re.escape(right) + ")", text[start:stop]):
            end = start + match.start()
            if 0 < end - start <= MAX_FILL:
                pairs.append((start, end))
                if len(pairs) > 1:
                    return pairs
    return pairs


def verify_restoration(case, plan, candidate, citation, *, source_policy, page_index, trusted_bindings):
    """Verify one *already nominated* source candidate against trusted pins.

    trusted_bindings is supplied by the caller's saved-public-plan/candidate
    boundary, not taken from candidate fields or an arbitrary claim packet.
    Required digest keys: case, query, atoms, candidate, citation. SourcePolicy
    must be the caller's original complete policy, not a reduced replacement.
    No hidden answer argument, search, parser, file/network I/O or nomination.
    A witness is NOT construction/grammar admission or SUPPORT/world truth.
    """
    result = dict(version=VERSION, disposition="HOLD", reasons=[], witness=None,
        completed_query=None, grammar_checked=False, grammar_overridden=False,
        construction_policy_authorized=False, source_candidates_nominated=0,
        world_event_truth_certified=False, semantic_entailment_certified=False,
        canonical_identity_certified=False, native_decision_changed=False, api_calls=0)

    def hold(reason):
        result["reasons"].append(reason)
        return result

    try:
        _public_inputs(case, plan, candidate, citation, trusted_bindings)
        public = public_case(case)
        if case != public or public["task"] != "redaction":
            return hold("PUBLIC_REDACTION_CASE_ONLY")
        if len(public["query"]) > MAX_TEXT or len(plan.get("atoms", [])) > 64:
            return hold("PUBLIC_INPUT_BUDGET")
        public_plan(public, plan)
        actual = dict(case=digest(public), query=digest(public["query"]),
            atoms=digest(plan["atoms"]), candidate=digest(candidate), citation=digest(citation))
        if trusted_bindings != actual or plan.get("query_sha256") != actual["query"]:
            return hold("TRUSTED_PUBLIC_OR_CANDIDATE_BINDING_MISMATCH")
        query, marker = public["query"], public["focal_marker"]
        at = query.index(marker)
        focal = [a for a in plan["atoms"] if marker in a["text"]]
        if len(focal) != 1 or focal[0].get("kind") != "proposition":
            return hold("ONE_PUBLIC_FOCAL_PROPOSITION_REQUIRED")
        atom = focal[0]
        spans = atom.get("query_spans", [])
        if len(spans) != 1:
            return hold("ONE_CONTIGUOUS_PUBLIC_FOCAL_SCOPE_REQUIRED")
        span = spans[0]
        qa, qb = _interval([span["start"], span["end"]], query)
        if not qa <= at < at + len(marker) <= qb or normalize(atom["text"]).text != normalize(span["text"]).text:
            return hold("FOCAL_ATOM_MUST_REPLAY_LITERAL_PUBLIC_SCOPE")
        if (not isinstance(source_policy, SourcePolicy) or type(page_index) is not int
                or not 0 <= page_index < len(source_policy.corpus.pages)):
            return hold("CALLER_ORIGINAL_SOURCE_POLICY_REQUIRED")
        page = source_policy.corpus.pages[page_index]
        if not isinstance(page.get("text"), str) or len(page["text"]) > MAX_TEXT:
            return hold("SOURCE_PAGE_BINDING_OR_BUDGET")
        if public_case(source_policy.case) != public or source_policy.bound_pages.get(page["id"]) != page:
            return hold("CALLER_SOURCE_POLICY_BINDING_MISMATCH")
        if not source_policy.allowed(page_index) or digest(page["text"]) != page["source_sha256"]:
            return hold("INELIGIBLE_OR_CHANGED_SOURCE_PAGE")
        if len(page["text"]) > MAX_TEXT or citation.get("canonical_page_id") != page["id"]:
            return hold("SOURCE_PAGE_BINDING_OR_BUDGET")
        a, b = _interval([citation["start"], citation["end"]], page["text"])
        checked = source_policy.citation(page_index, a, b)
        if citation != checked:
            return hold("CALLER_CITATION_REPLAY_MISMATCH")
        sa, sb = _interval(candidate["source_span"], page["text"])
        wording, fill = candidate["source_wording"], candidate["fill"]
        if (not isinstance(candidate.get("id"), str) or not candidate["id"]
                or not a <= sa < sb <= b or page["text"][sa:sb] != wording
                or not wording or wording != wording.strip() or len(fill) > MAX_FILL
                or MASK.search(fill) or MASK.search(wording)
                or normalize(fill).text != normalize(wording).text):
            return hold("ONE_UNMODIFIED_LITERAL_SOURCE_CANDIDATE_REQUIRED")
        occurrences = candidate.get("source_occurrences", [])
        if (citation not in candidate.get("sources", []) or not any(
                o.get("source_span") == [sa, sb] and o.get("source_wording") == wording
                and o.get("citation") == citation for o in occurrences)):
            return hold("CANDIDATE_HAS_NO_BOUND_ACTUAL_SOURCE_OCCURRENCE")
        if (not _word_boundary(page["text"], sa, sb)
                or at and (query[at-1].isalnum() or query[at-1] == "_")
                or at+len(marker) < len(query) and (
                    query[at+len(marker)].isalnum() or query[at+len(marker)] == "_")):
            return hold("PARTIAL_WORD_SLOT_OR_SOURCE_SPAN")
        completed = query[:at] + fill + query[at+len(marker):]
        result["completed_query"] = completed
        if [m.group() for m in MASK.finditer(completed)] != [
                m.group() for m in MASK.finditer(query) if m.start() != at]:
            return hold("SECONDARY_MASKS_CHANGED")
        if MASK.search(query[qa:at] + query[at+len(marker):qb]):
            return hold("SECONDARY_MASK_IN_FOCAL_SCOPE_UNASSESSED")
        completed_atom = query[qa:at] + fill + query[at+len(marker):qb]
        target, source = normalize(completed_atom), normalize(citation["text"])
        result["exact_normalized_unit_match"] = target.text == source.text
        result["scope_limit"] = "WHOLE_RAW_PAGE_AND_WHOLE_PUBLIC_QUERY_ONLY"
        # Neither SourcePolicy nor a string comparison licenses an interior
        # clause boundary. V1 holds rather than dropping any surrounding scope.
        if (a != 0 or b != len(page["text"]) or query[:qa].strip() or query[qb:].strip()):
            return hold("COMPLETE_SCOPE_AUTHORITY_UNAVAILABLE_FOR_INTERIOR_UNIT")
        if not target.text or target.text != source.text:
            return hold("COMPLETE_SOURCE_TEXT_NOT_LITERAL_RESTORATION")
        before, after = normalize(query[qa:at]), normalize(query[at+len(marker):qb])
        # Retain separator whitespace in the anchors; only outer unit padding
        # is ignored. This also rejects character matches inside longer words.
        left = before.text + (" " if query[qa:at] and query[at-1].isspace() else "")
        right = (" " if query[at+len(marker):qb] and query[at+len(marker)].isspace() else "") + after.text
        left, right = _anchor(left, left=True), _anchor(right, left=False)
        if not _anchor_strength(left, right):
            return hold("SHORT_OR_TAUTOLOGICAL_VISIBLE_ANCHORS")
        pairs = _brackets(source.text, left, right)
        if len(pairs) != 1:
            return hold("AMBIGUOUS_OR_MISSING_VISIBLE_ANCHOR_BRACKET")
        lo, hi = pairs[0]
        slot_offsets = source.offsets[lo:hi]
        if not slot_offsets or (a + slot_offsets[0][0], a + slot_offsets[-1][1]) != (sa, sb):
            return hold("ANCHORS_DO_NOT_BRACKET_THE_ACTUAL_LITERAL_SOURCE_SPAN")
        if normalize(page["text"][sa:sb]).text != source.text[lo:hi]:
            return hold("SOURCE_SLOT_NORMALIZATION_DOES_NOT_REPLAY")
        # Every compared character has an explicit original source/query map.
        alignment = []
        inserted_end = at - qa + len(fill)
        for index, ((ta, tb), (pa, pb)) in enumerate(zip(target.offsets, source.offsets)):
            original = ([qa+ta, qa+tb] if tb <= at-qa else
                [qa+ta-len(fill)+len(marker), qa+tb-len(fill)+len(marker)] if ta >= inserted_end else None)
            alignment.append(dict(normalized_index=index, normalized_character=target.text[index],
                completed_atom_span=[ta, tb], original_query_span=original, source_page_span=[a+pa, a+pb]))
        witness = dict(kind=KIND, version=VERSION, support_contract="CORPUS_ASSERTION_TEXTUAL_RESTORATION_ONLY",
            trusted_bindings=dict(actual), focal_atom_id=atom["id"], public_query=query,
            original_focal_atom=deepcopy(atom), original_marker=marker, original_marker_span=[at, at+len(marker)],
            completed_query=completed, source_candidate_id=candidate["id"], fill=fill,
            source_span=[sa, sb], source_wording=wording, full_untrimmed_source_unit=dict(citation),
            source_page_sha256=page["source_sha256"], normalized_complete_scope=source.text,
            left_anchor=left, right_anchor=right, unique_anchor_bracket=[lo, hi],
            character_alignment=alignment,
            source_line_hyphen_edits=[dict(e, start=a+e["start"], end=a+e["end"]) for e in source.line_hyphens],
            completed_atom_line_hyphen_edits=list(target.line_hyphens),
            secondary_masks_preserved=True, source_text_modified=False,
            source_admission_authority="CALLER_ORIGINAL_SOURCE_POLICY_CITATION_REPLAY",
            grammar_checked=False, grammar_overridden=False, construction_authorized=False,
            world_event_truth_certified=False, event_time_certified=False,
            clause_grammar_certified=False, beyond_unit_scope_certified=False,
            canonical_identity_certified=False, original_traversal_claimed=False)
        result.update(disposition=KIND, witness=witness)
        return result
    except (ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        return hold("INPUT_OR_SOURCE_REPLAY_FAILURE: " + str(error))
