"""Isolate an observed name inside an opaque extraction record, for context only."""
from copy import deepcopy

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_next.quotations import locate

VERSION = "public-literal-visible-label-context/3"


def observe(query, entity, parse):
    """Read the literal label only; neither known nor opaque records imply identity."""
    if entity.get("type") not in {"person", "place", "organization"}:
        return None
    label = entity.get("label")
    if not isinstance(label, str) or not label.strip() or MASK.search(label):
        return None
    spans = entity.get("query_spans", [])
    if not spans:
        return None
    proofs = []
    for span in spans:
        a, b = span.get("start"), span.get("end")
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(query)
                or query[a:b] != span.get("text")):
            raise ValueError("Opaque extraction locator lost its literal public binding")
        try:
            start, end, text, mode = locate(query[a:b], label, allow_layout=True,
                ignore_case=True, token_boundaries=True)
        except ValueError:
            return None
        start, end = a + start, a + end
        word = lambda char: char.isalnum() or char == "_"
        if ((start and word(query[start]) and word(query[start-1]))
                or (end < len(query) and word(query[end-1]) and word(query[end]))):
            return None
        if MASK.search(text) or any(start < m.end() and m.start() < end for m in MASK.finditer(query)):
            return None
        proofs.append(dict(start=start, end=end, text=text, matching_mode=mode,
            locator=deepcopy(span), locator_is_position_only=True))
    if len({p["text"] for p in proofs}) != 1:
        return None
    literal = proofs[0]["text"]
    doc = parse(literal)
    if doc.text != literal:
        raise ValueError("Visible-label analysis changed the public name")
    if not any(t.pos_ == "PROPN" and t.lower_ not in {"the", "de", "la"} for t in doc):
        return None
    return dict(version=VERSION, literal_label=literal, label_bindings=proofs,
        original_entity_record_sha256=digest(entity), query_sha256=digest(query),
        original_unknown_flag_preserved=True, complete_entity_certified=False,
        canonical_identity_certified=False, grammatical_attachment_certified=False,
        historical_action_certified=False, context_hint_only=True)


def isolate(query, entity, parse):
    """Compatibility scope for repairing opaque extraction records only."""
    if entity.get("contains_unknown_slot") is not True:
        return None
    return observe(query, entity, parse)
