"""Pure supplied-data IDF context observations, never evidence or confidence."""
from collections import Counter
from copy import deepcopy
import math
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from . import nominal_relative_provenance as provenance

VERSION = "bound-ordinary-document-idf-own-clause-context/2"
FORMULA = "log(1+(N-df+0.5)/(df+0.5))"


def terms(text,parser):
    """Same lemma set as existing unweighted own-clause observation."""
    return {t.lemma_.casefold() for t in parser(MASK.sub(" ",text)) if not t.is_stop
        and not t.is_punct and not t.is_space and re.search(r"[A-Za-z0-9]",t.text)}


def idf(document_count,document_frequency):
    if (type(document_count) is not int or document_count < 1
            or type(document_frequency) is not int or not 0 <= document_frequency <= document_count):
        raise ValueError("Distinct document N>=1 and integer df in0..N required")
    return math.log(1+(document_count-document_frequency+.5)/(document_frequency+.5))


def build_profile(inspected_pages,parser,*,expected_page_ids,case=None):
    """All supplied ordinary pages, one DF vote per distinct original document."""
    if (not isinstance(inspected_pages,(list,tuple)) or not inspected_pages
            or not isinstance(expected_page_ids,(list,tuple))
            or [p["id"] for p in inspected_pages] != list(expected_page_ids)
            or len(set(expected_page_ids)) != len(expected_page_ids)):
        raise ValueError("The exact full unique inspected-page sequence is required")
    if case is None:
        raise ValueError("Exact public case is required for a bound ordinary profile")
    provenance.canonical_pages(case,inspected_pages,expected_page_ids)
    documents,bindings = {},{}
    for page in inspected_pages:
        if not isinstance(page["document_id"],str) or not page["document_id"] or digest(page["text"]) != page["source_sha256"]:
            raise ValueError("Original document identity and canonical text hash required")
        documents.setdefault(page["document_id"],set()).update(terms(page["text"],parser))
        bindings[page["id"]] = dict(document_id=page["document_id"],source_sha256=page["source_sha256"])
    df = Counter()
    for values in documents.values():
        df.update(values)
    count = len(documents)
    profile = dict(version=VERSION,formula=FORMULA,document_count=count,document_ids=list(documents),
        page_ids=list(expected_page_ids),page_bindings=bindings,document_frequency=dict(sorted(df.items())),
        document_term_hashes={key:digest(sorted(value)) for key,value in documents.items()},
        corpus_unit="DISTINCT_ORIGINAL_DOCUMENT_IN_ALL_INSPECTED_PAGES",candidate_selection_used=False,
        QA_used=False,source_authorization_certified=False,public_case_sha256=digest(case))
    profile["profile_sha256"] = digest(profile)
    return profile


def validate_profile(profile):
    raw = {k:v for k,v in profile.items() if k != "profile_sha256"}
    if (profile.get("version") != VERSION or profile.get("formula") != FORMULA
            or profile.get("profile_sha256") != digest(raw)
            or profile["document_count"] != len(profile["document_ids"])
            or len(set(profile["document_ids"])) != profile["document_count"]):
        raise ValueError("IDF profile identity or document membership changed")
    for value in profile["document_frequency"].values():
        idf(profile["document_count"],value)


def score_terms(query_terms,source_terms,profile):
    q,s = set(query_terms),set(source_terms)
    weights = {t:idf(profile["document_count"],profile["document_frequency"].get(t,0)) for t in sorted(q|s)}
    shared = q&s
    numerator = sum(weights[t] for t in sorted(shared))
    q_denominator = sum(weights[t] for t in sorted(q))
    union_denominator = sum(weights.values())
    coverage = numerator/q_denominator if q_denominator else 0.
    jaccard = numerator/union_denominator if union_denominator else 0.
    return dict(score=.75*coverage+.25*jaccard,coverage=coverage,jaccard=jaccard,
        query_terms=sorted(q),source_terms=sorted(s),matched_terms=sorted(shared),
        intersection_idf_sum=numerator,query_idf_sum=q_denominator,union_idf_sum=union_denominator,
        term_weights=weights,term_document_frequencies={t:profile["document_frequency"].get(t,0) for t in weights})


def order_pool(pool,*,query_text,parser,profile,case=None,reading=None,inspected_pages=None,issuer=None):
    """Copy, observe and add an IDF order; never change a saved gate/provenance."""
    validate_profile(profile)
    if case is None or reading is None or inspected_pages is None or issuer is None:
        raise ValueError("Exact case/reading/canonical pages and producer issuer are required")
    provenance.validate_public_binding(pool,case,reading,query_text)
    if profile["public_case_sha256"] != digest(case) or profile["page_ids"] != pool["inspected_page_ids"]:
        raise ValueError("PROFILE_CASE_OR_SOURCE_SCOPE_CHANGED")
    by_id = provenance.canonical_pages(case,inspected_pages,profile["page_ids"])
    issuer.validate_pool(pool)
    for candidate in pool["proposals"]:
        for occurrence in candidate["source_occurrences"]:
            provenance.replay_occurrence(occurrence,by_id,fill=candidate["fill"])
    out = deepcopy(pool)
    q = terms(query_text,parser)
    for original_index,candidate in enumerate(out["proposals"]):
        if set(candidate["context_order"]["best_single_occurrence"]["query_terms"]) != q:
            raise ValueError("Use the same sealed public focal paragraph, not a new query scope")
        clauses = {}
        for index,occurrence in enumerate(candidate["source_occurrences"]):
            binding = profile["page_bindings"].get(occurrence["source_page_id"])
            if binding != dict(document_id=occurrence["source_document_id"],source_sha256=occurrence["source_page_sha256"]):
                raise ValueError("Own source occurrence is not in this exact ordinary page profile")
            key = (occurrence["source_document_id"],occurrence["source_sentence"])
            clauses.setdefault(key,[]).append(index)
        observed = []
        for (document_id,sentence),indices in clauses.items():
            index = indices[0]
            source = candidate["source_occurrences"][index]
            record = score_terms(q,terms(sentence,parser),profile)
            observed.append(dict(record,occurrence_index=index,duplicate_receipt_indices=indices,
                source_document_id=document_id,source_page_id=source["source_page_id"],
                source_sentence=sentence,source_sentence_span=[source["source_sentence_start"],source["source_sentence_end"]]))
        if not observed:
            raise ValueError("An actual own source clause is required")
        best = max(observed,key=lambda v:v["score"])
        candidate["idf_context_order"] = dict(version=VERSION,profile_sha256=profile["profile_sha256"],
            query_text=query_text,best_single_occurrence=best,all_unique_clause_scores=observed,
            original_proposal_order=original_index,old_best_occurrence_index=candidate["context_order"]["best_single_occurrence"]["occurrence_index"],
            coverage_weight=.75,jaccard_weight=.25,correctness_probability=False,
            factual_support_certified=False,source_or_qualification_or_gate_changed=False)
    ranked = sorted(out["proposals"],key=lambda p:(-p["idf_context_order"]["best_single_occurrence"]["score"],
        p["idf_context_order"]["original_proposal_order"]))
    out["idf_context_order_ids"] = [p["id"] for p in ranked]
    out["idf_syntax_accepted_context_order_ids"] = [p["id"] for p in ranked if p["compatibility"]["state"]=="PASS_SYNTAX_ONLY"]
    out["idf_profile_sha256"] = profile["profile_sha256"]
    out["idf_input_binding_sha256"] = digest(pool["public_binding"])
    return out


def replay_ranking(weighted_pool,*,query_text,parser,profile,case,reading,inspected_pages,issuer):
    """Recompute arithmetic/receipts, never completed-insertion compatibility."""
    original = deepcopy(weighted_pool)
    for name in ("idf_context_order_ids","idf_syntax_accepted_context_order_ids","idf_profile_sha256","idf_input_binding_sha256"):
        original.pop(name,None)
    for candidate in original["proposals"]:
        candidate.pop("idf_context_order",None)
    expected = order_pool(original,query_text=query_text,parser=parser,profile=profile,case=case,
        reading=reading,inspected_pages=inspected_pages,issuer=issuer)
    if expected != weighted_pool:
        raise ValueError("EXACT_RANKING_RECEIPT_REPLAY_FAILED")
    return True

