"""Literal pre-name historical role ascription after an unchanged source baseline.

Additive constructor only: the caller retains the complete SourcePolicy and
validated public atom. This module does not install a routing hook or change a
native result. A printed matrix predicate is provenance, not action evidence.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from functools import lru_cache
import re

from matryoshka_demo.io import digest, offline
from matryoshka_demo.roles import concepts, lexicon, binding as wordnet_binding
from matryoshka_demo_v61 import scope_matching as scoped
from . import nominal_bindings as nominal3

VERSION = "narrative-literal-prename-role-binding/2"
CERTIFICATE_KIND = "LITERAL_NAMED_SUBJECT_ROLE_PRETITLE"
SCOPE_VERSION = "literal-full-page-sentence-scope/1"
REQUIRES_NOMINAL = "narrative-literal-nominal-role-bindings/3"
BASELINE_VERSION = "narrative-guarded-source-frame-matching/4"
MAX_CHARACTERS = 4096
MAX_TOKENS = 256
MAX_PAGE_SCOPE_CHARACTERS = 16384
MAX_PAGE_SCOPE_TOKENS = 4096
_NAME_DEPS = {"compound", "flat", "name"}
_NP_DEPS = _NAME_DEPS | {"amod"}
_QUALIFIED = {
    "former", "acting", "alleged", "possible", "prospective", "future", "would-be", "late",
    "retired", "incoming", "outgoing", "designate", "elect", "deputy", "assistant", "vice",
    "ex", "purported", "so-called", "nominee",
}
_SCOPE_FIELDS = ("negated", "modality", "scope", "attribution", "epistemic_absence",
                 "conditional", "question", "unresolved")


def _literal(tokens):
    if not tokens:
        return ""
    return " ".join(tokens[0].doc.text[tokens[0].idx:tokens[-1].idx + len(tokens[-1])].casefold().split())


def _contiguous(tokens):
    return bool(tokens) and [t.i for t in tokens] == list(range(tokens[0].i, tokens[-1].i + 1))


def _common_person(word):
    return tuple(s.name() for s in concepts(word) if s.lexname() == "noun.person")


def _common_modifier(word):
    return any(l.name().islower() and l.name().replace("_", " ") == word
               for s in lexicon().synsets(word) for l in s.lemmas())


@lru_cache(maxsize=1)
def _military_roles():
    """Bounded WordNet class, never a lookup of an observed person's name."""
    root = lexicon().synset("military_officer.n.01")
    pending, seen, entries = [root], set(), set()
    while pending:
        node = pending.pop()
        if node.name() in seen:
            continue
        seen.add(node.name())
        if len(seen) > 256:
            raise ValueError("Military-role dictionary traversal bound exceeded")
        if node.lexname() == "noun.person":
            entries.update((lemma.name(), node.name()) for lemma in node.lemmas()
                           if lemma.name().isalpha() and lemma.name().islower())
        pending.extend(node.hyponyms())
    return tuple(sorted(entries))


def _rank_gap(tokens):
    if not tokens:
        return dict(kind="NO_INTERVENING_RANK", proofs=[], rank_asserted=False)
    if len(tokens) > 2 or not _contiguous(tokens):
        return None
    printed = tokens[0].doc.text[tokens[0].idx:tokens[-1].idx + len(tokens[-1])]
    word = printed.casefold()
    abbreviated = bool(re.fullmatch(r"[A-Za-z]{3,4}\.", printed))
    if abbreviated:
        candidates = {(lemma, sense) for lemma, sense in _military_roles() if lemma.startswith(word[:-1])}
    else:
        candidates = {(lemma, sense) for lemma, sense in _military_roles() if lemma == word}
    if len(candidates) != 1:
        return None
    lemma, sense = next(iter(candidates))
    return dict(kind="UNIQUE_DICTIONARY_MILITARY_ROLE_GAP", printed=printed,
                lexical_lemma=lemma, noun_synset=sense, abbreviated=abbreviated,
                proofs=[scoped.matching.proof(t) for t in tokens],
                source_text_expanded=False, rank_asserted=False, identity_alias_created=False)


def _prerequisites(matcher, atom, page, unit, control):
    if nominal3.VERSION != REQUIRES_NOMINAL:
        return "UNREVIEWED_NOMINAL_VERSION"
    if (control.get("version") != BASELINE_VERSION
            or control.get("direction") not in {"UNRESOLVED", "PARTIAL"}
            or control.get("potential_counter") or control.get("query_issues") != []
            or control.get("source_text_modified") is not False
            or control.get("unit_join_performed") is not False
            or any(control.get("checks", {}).get(k) != "PASS" for k in ("eligible_source", "literal_quote"))):
        return "BASELINE_PREREQUISITES_NOT_SATISFIED"
    case = matcher.case
    if (page.get("permitted") is not True or page.get("document_id") == case["document_id"]
            or page.get("corpus") != case["corpus"]
            or page.get("visibility") not in {"earlier", "earlier_only", "both"}):
        return "SOURCE_OWNER_OR_ELIGIBILITY_MISMATCH"
    try:
        if date.fromisoformat(page["date"]) >= date.fromisoformat(case["date"]):
            return "SOURCE_NOT_STRICTLY_EARLIER"
    except (KeyError, ValueError, TypeError):
        return "SOURCE_DATE_MISMATCH"
    text = unit.get("text", unit.get("quote"))
    a, b = unit.get("start"), unit.get("end")
    if (not isinstance(text, str) or not text or len(text) > MAX_CHARACTERS
            or len(atom.get("text", "")) > MAX_CHARACTERS
            or type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != text or digest(page["text"]) != page.get("source_sha256")):
        return "SOURCE_QUOTE_OR_HASH_MISMATCH"
    expected = dict(canonical_page_id=page["id"], corpus=page["corpus"], document_id=page["document_id"],
                    date=page["date"], start=a, end=b, text=text, page_sha256=page["source_sha256"])
    if any(control.get("citation", {}).get(k) != v for k, v in expected.items()):
        return "BASELINE_CITATION_OWNER_MISMATCH"
    return None


def _source_sentence_scope(engine, page, unit):
    """Bind the unchanged unit to a complete sentence in its actual full page.

    Baseline citation replay proves a slice's bytes, not that the slice retained
    its governing title/attribution. Ignore whitespace only for comparing bounds;
    never expand the unit, remove a printed token, or repair sentence boundaries.
    """
    text = page["text"]
    if len(text) > MAX_PAGE_SCOPE_CHARACTERS:
        return None, "SOURCE_PAGE_SCOPE_BOUND_EXCEEDED"
    doc = engine.parse(text)
    if len(doc) > MAX_PAGE_SCOPE_TOKENS or doc.text != text:
        return None, "SOURCE_PAGE_SCOPE_BOUND_EXCEEDED_OR_TEXT_CHANGED"

    def trimmed_bounds(start, end):
        while start < end and text[start].isspace():
            start += 1
        while end > start and text[end - 1].isspace():
            end -= 1
        return start, end

    wanted = trimmed_bounds(unit["start"], unit["end"])
    try:
        matches = [s for s in doc.sents if trimmed_bounds(s.start_char, s.end_char) == wanted]
    except ValueError:
        return None, "SOURCE_PAGE_SENTENCE_SCOPE_UNCERTAIN"
    if len(matches) != 1 or matches[0].root.head != matches[0].root:
        return None, "SOURCE_UNIT_NOT_COMPLETE_PAGE_SENTENCE"
    return dict(version=SCOPE_VERSION, canonical_page_id=page["id"], page_sha256=page["source_sha256"],
                sentence_start=wanted[0], sentence_end=wanted[1],
                unit_start=unit["start"], unit_end=unit["end"],
                boundary_comparison_ignores_whitespace_only=True,
                source_unit_expanded=False, source_text_modified=False), None


def evaluate(matcher, atom, page, unit, control):
    """Nominal3-compatible constructor over an actual already-gated baseline.

    The caller must obtain control from the ordinary matcher, not fabricate
    eligibility/coverage flags. No corpus is fetched, no records are joined, and
    no input plan, source, control, or native decision is modified here.
    """
    result = dict(version=VERSION, applicable=False, direction="UNRESOLVED", reasons=[], certificate=None)

    def reject(reason):
        result["reasons"] = [reason]
        return result

    failed = _prerequisites(matcher, atom, page, unit, control)
    if failed:
        return reject(failed)
    with offline():
        engine = matcher.engine
        source_scope, failed = _source_sentence_scope(engine, page, unit)
        if failed:
            return reject(failed)
        query = engine.parse(atom["text"])
        if len(query) > MAX_TOKENS:
            return reject("QUERY_TOKEN_BOUND_EXCEEDED")
        roots = [t for t in query if t.dep_ == "ROOT"]
        if len(roots) != 1 or roots[0].lemma_.casefold() != "be":
            return reject("NOT_A_SINGLE_COPULAR_ROLE_QUERY")
        root = roots[0]
        owners = [t for t in root.children if t.dep_ == "nsubj"]
        roles = [t for t in root.children if t.dep_ == "attr" and t.pos_ == "NOUN" and t.tag_ == "NN"]
        if len(owners) != 1 or len(roles) != 1:
            return reject("QUERY_OWNER_OR_COMMON_ROLE_NOT_BOUND")
        wanted, owner = roles[0], owners[0]
        senses = _common_person(wanted.lemma_.casefold())
        if not senses:
            return reject("QUERY_HEAD_NOT_DICTIONARY_COMMON_PERSON_ROLE")
        result["applicable"] = True
        if (root.tag_ != "VBD" or atom.get("kind") != "proposition"
                or atom.get("polarity", "positive") != "positive"
                or atom.get("modality", "asserted") != "asserted"
                or any(t not in [owner, wanted] and t.dep_ != "punct" for t in root.children)
                or any(t.is_quote or t.text == "?" or t.ent_type_ in {"DATE", "TIME"} for t in query)
                or len(engine.targets(atom["text"])) != 1):
            return reject("QUERY_ROLE_SCOPE_CLOCK_OR_REPRESENTATION_UNSUPPORTED")
        qname = nominal3._name_tokens(owner)
        qtitle = nominal3._base(wanted)
        if (len(qname) < 2 or not _contiguous(qname) or set(owner.subtree) != set(qname)
                or any(t.pos_ != "PROPN" for t in qname)):
            return reject("QUERY_REQUIRES_COMPLETE_LITERAL_MULTITOKEN_NAME")
        if (not _contiguous(qtitle) or set(wanted.subtree) != set(qtitle)
                or nominal3._qualified(wanted)
                or any(t.text.casefold() in _QUALIFIED or t.lemma_.casefold() in _QUALIFIED for t in qtitle)
                or any(t != wanted and (t.pos_ not in {"NOUN", "ADJ"} or t.ent_type_
                    or not _common_modifier(t.lemma_.casefold())) for t in qtitle)):
            return reject("QUERY_TITLE_NOT_UNQUALIFIED_LITERAL_COMMON_WORDS")
        source = engine.parse(unit.get("text", unit.get("quote")))
        if len(source) > MAX_TOKENS:
            return reject("SOURCE_TOKEN_BOUND_EXCEEDED")
        roots = [t for t in source if t.dep_ == "ROOT"]
        if (len(roots) != 1 or len(list(source.sents)) != 1
                or any(t.is_quote or t.text in {"?", "(", ")", "[", "]", "--"}
                       or t.lower_ == "according" or t.dep_ in {"parataxis", "advcl"} for t in source)):
            return reject("SOURCE_UNIT_SCOPE_NOT_LICENSED")
        matrix = roots[0]
        subjects = [t for t in matrix.children if t.dep_ in {"nsubj", "nsubjpass"}]
        if len(subjects) != 1 or matrix.pos_ != "VERB":
            return reject("NO_UNIQUE_VERBAL_MATRIX_SUBJECT")
        subject = subjects[0]
        governing = scoped.matching.qualifiers(matrix)
        if any(governing.get(k) for k in _SCOPE_FIELDS):
            return reject("SOURCE_MATRIX_QUALIFIED_NEGATED_OR_NONFACTIVE")
        np = sorted(subject.subtree, key=lambda t: t.i)
        if (not _contiguous(np) or np[-1] != subject or subject.pos_ != "PROPN"
                or any(t != subject and t.dep_ not in _NP_DEPS for t in np)
                or any(t.text.casefold() in _QUALIFIED or t.lemma_.casefold() in _QUALIFIED for t in np)):
            return reject("SOURCE_SUBJECT_QUALIFIED_COORDINATED_OR_NONLITERAL")
        if len(np) < len(qtitle) + len(qname):
            return reject("SOURCE_PRETITLE_OR_NAME_INCOMPLETE")
        stitle, sname = np[:len(qtitle)], np[-len(qname):]
        gap = np[len(qtitle):-len(qname)]
        if (not _contiguous(stitle) or not _contiguous(sname)
                or _literal(sname) != _literal(qname)
                or any(t.pos_ != "PROPN" for t in sname)
                or _literal(stitle) != _literal(qtitle)
                or any(t.pos_ not in {"NOUN", "PROPN", "ADJ"} for t in stitle)
                or stitle[-1].text.casefold() != wanted.text.casefold()):
            return reject("SOURCE_NAME_OR_PRETITLE_NOT_LITERAL_QUERY_SPELLING")
        rank = _rank_gap(gap)
        if rank is None:
            return reject("INTERVENING_RANK_UNATTESTED_OR_AMBIGUOUS")
        for token in stitle + gap + sname[:-1]:
            node = token
            while node != subject and node.dep_ in _NP_DEPS:
                node = node.head
            if node != subject:
                return reject("PRETITLE_NOT_BOUND_TO_MATRIX_SUBJECT")
        certificate = dict(
            kind=CERTIFICATE_KIND, version=VERSION,
            source_proof_offset_basis="SOURCE_UNIT_UNICODE_CHARACTERS", source_unit_page_start=unit["start"],
            owner_binding=dict(kind="ORDERED_LITERAL_NAME_AFTER_COMMON_ROLE_PRETITLE",
                target_proofs=[scoped.matching.proof(t) for t in qname],
                source_proofs=[scoped.matching.proof(t) for t in sname], literal_name=_literal(qname),
                additional_title_proofs=[scoped.matching.proof(t) for t in stitle + gap],
                canonical_identity_certified=False),
            role_proof=scoped.matching.proof(stitle[-1]), target_role_proof=scoped.matching.proof(wanted),
            possessor_binding=None, source_relation_proof=None, literal_role_complement=None,
            source_role_modifiers=[scoped.matching.proof(t) for t in stitle[:-1]],
            appositive_proof=None, source_matrix_predicate=scoped.matching.proof(matrix),
            prename_title_proofs=[scoped.matching.proof(t) for t in stitle], rank_gap_guard=rank,
            common_person_role_guard=dict(common_lemma=wanted.lemma_.casefold(), noun_synsets=list(senses),
                dictionary=wordnet_binding(), proper_name_lookup_performed=False,
                source_propn_accepted_only_as_literal_common_role=True, semantic_synonym_matching=False),
            source_governing_qualifiers=deepcopy(governing), citation=deepcopy(control["citation"]),
            source_sentence_scope=source_scope,
            source_matrix_claim_certified=False, reporter_inferred=False,
            source_attestation_not_persistence=True, source_ascription_date=page["date"],
            continued_tenure_at_query_cutoff_certified=False, precise_event_time_certified=False,
            completed_action_certified=False, publication_date_used_as_event_time=False,
            canonical_identity_certified=False, inner_execution_certified=False,
            cross_atom_or_event_join_certified=False, source_text_modified=False,
            world_truth_certified=False)
        result.update(direction="SUPPORT", reasons=[], certificate=certificate)
        return result
