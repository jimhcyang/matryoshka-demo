"""Opt-in inspected-pool control over untrusted extracted event/claim semantics.

QUALIFIED_SOURCE_SUPPORT means an eligible source describes P with the recorded
qualifications. It is neither world proof, a replacement decision nor a join
certificate. Descriptions nominate; literal query and source roles still gate.
"""
from collections import Counter
from collections.abc import Mapping
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy, fact_index as source_facts, public_plan

VERSION = "narrative-qualified-source-support-control/1.1"
_CONTENT = {"PROPN", "NOUN", "ADJ", "VERB", "ADV", "NUM"}
_REPORT = {"say", "report", "state", "claim", "announce", "tell", "confirm"}
_NONFACTIVE = {"plan", "intend", "hope", "want", "expect", "believe", "think",
    "suspect", "fear", "deny", "prepare", "propose", "consider", "seek", "agree"}
_NONFACTIVE_NOUNS = {"allegation", "rumor", "rumour", "possibility", "plan",
    "proposal", "claim", "belief", "hope", "intention", "report"}
_SCALAR = re.compile(r"\b(?:only|solely|exclusively|exactly|at\s+least|at\s+most|"
    r"more\s+than|less\s+than|fewer\s+than|between|minimum|maximum|"
    r"all|each|every|any|either|neither|none)\b", re.I)
_SEMANTIC = ("label", "description", "claim_text", "actor", "subject", "predicate",
    "object", "speaker", "target", "assertion_mode", "polarity", "modality",
    "conditional", "condition", "uncertainty", "negated", "negation_scope", "stance",
    "temporal_context", "date", "relation")
_PUBLIC = {"case_id", "task", "corpus", "query", "document_id", "date", "focal_marker"}


def _lemma(t):
    return t.lemma_.casefold()


def _phrase(head):
    """A noun phrase cannot borrow actors/patients from a relative clause."""
    out = []
    def visit(token):
        out.append(token)
        for child in token.children:
            if child.dep_ in {"acl", "relcl", "ccomp", "xcomp", "advcl", "prep", "agent", "punct"}:
                continue
            visit(child)
    visit(head)
    return sorted(out, key=lambda t: t.i)


def _terms(tokens):
    return {_lemma(t) for t in tokens if t.pos_ in _CONTENT
        and (t.pos_ in {"PROPN", "NUM"} or not t.is_stop)}


def _frame(predicate):
    agents, roles, verbs = [], {}, [predicate]
    def argument(head, path):
        roles.setdefault(path, []).extend(_phrase(head))
        for token in _phrase(head):
            for prep in token.children:
                if prep.dep_ == "prep":
                    for child in prep.children:
                        if child.dep_ in {"pobj", "pcomp"}:
                            argument(child, path + "/prep:" + _lemma(prep))
    passive = any(c.dep_ in {"auxpass", "nsubjpass"} for c in predicate.children)
    for child in predicate.children:
        if child.dep_ in {"nsubj", "csubj"}:
            agents.extend(_phrase(child))
        elif child.dep_ == "nsubjpass":
            argument(child, "patient")
        elif child.dep_ == "agent" or child.dep_ == "prep" and _lemma(child) == "by":
            passive = True
            for obj in child.children:
                if obj.dep_ == "pobj":
                    agents.extend(_phrase(obj))
    reduced = predicate.dep_ == "acl" and predicate.tag_ == "VBN" and passive
    if reduced:
        argument(predicate.head, "patient")
    def complements(verb, prefix=""):
        for child in verb.children:
            if child.dep_ in {"dobj", "obj", "attr", "oprd", "acomp"}:
                argument(child, prefix + "patient")
            elif child.dep_ == "dative":
                argument(child, prefix + "recipient")
            elif child.dep_ == "prep" and _lemma(child) != "by":
                if any(t.ent_type_ in {"DATE", "TIME"} for t in child.subtree):
                    continue
                for obj in child.children:
                    if obj.dep_ in {"pobj", "pcomp"}:
                        argument(obj, prefix + "prep:" + _lemma(child))
            elif child.dep_ == "xcomp" and child.pos_ == "VERB":
                verbs.append(child)
                complements(child, prefix + "xcomp:" + _lemma(child) + "/")
    complements(predicate)
    return dict(predicate=predicate, agents=agents, roles=roles, verbs=verbs,
        syntax="REDUCED_ACL_HEAD_PATIENT" if reduced else "PASSIVE_BY_AGENT" if passive else "ACTIVE")


def _proof(tokens, offset=0):
    return [dict(start=t.idx + offset, end=t.idx + offset + len(t), text=t.text,
        lemma=_lemma(t), dependency=t.dep_) for t in sorted({t.i:t for t in tokens}.values(), key=lambda t:t.i)]


def _event_dates(predicate):
    """Only direct event-time attachments, not another event's sentence date."""
    dates = []
    for child in predicate.children:
        if child.dep_ not in {"prep", "npadvmod"} or child.dep_ == "prep" and _lemma(child) not in {"on", "in", "at", "during"}:
            continue
        tokens = list(child.subtree)
        if any(t.pos_ == "VERB" for t in tokens):
            continue
        ids = {t.i for t in tokens}
        dates.extend(e.text.casefold() for e in predicate.doc.ents
            if e.label_ in {"DATE", "TIME"} and all(t.i in ids for t in e))
    return dates


def _target(case, atom, nlp):
    if atom.get("kind", "proposition") != "proposition":
        return None, "ONLY_FINITE_PROPOSITION_CONTROL_IMPLEMENTED"
    if atom.get("polarity") != "positive":
        return None, "NEGATIVE_OR_UNKNOWN_QUERY_NOT_IMPLEMENTED_NO_OPPOSITION"
    if any(not isinstance(atom.get(k), str) or not atom[k].strip() for k in ("subject", "predicate", "object")):
        return None, "UNBOUND_PUBLIC_ARGUMENT_NOT_A_WILDCARD"
    if atom.get("unresolved_scope") or (atom.get("field_intent") or {}).get("unresolved_scope"):
        return None, "UNRESOLVED_PUBLIC_SCOPE"
    spans = atom.get("query_spans", [])
    if len(spans) != 1:
        return None, "ONE_LITERAL_QUERY_SPAN_REQUIRED_BY_CONTROL"
    literal = case["query"][spans[0]["start"]:spans[0]["end"]]
    if _SCALAR.search(literal):
        return None, "UNIMPLEMENTED_EXCLUSIVITY_SCALAR_OR_QUANTIFIER"
    doc = nlp(literal)
    roots = [t for t in doc if t.dep_ == "ROOT" and t.pos_ == "VERB"]
    if len(roots) != 1:
        return None, "FINITE_PUBLIC_PREDICATE_UNVERIFIED"
    frame = _frame(roots[0])
    if not any(t.pos_ == "PROPN" for t in frame["agents"]):
        return None, "LITERAL_NAMED_QUERY_ACTOR_REQUIRED"
    if any(t.dep_ == "neg" for t in doc) or any(t.lower_ in {"never", "always", "or", "nor", "if", "unless"} for t in doc):
        return None, "UNIMPLEMENTED_NEGATION_QUANTIFIER_OR_CONDITION"
    if not _terms(nlp(atom["subject"])) <= _terms(frame["agents"]):
        return None, "NORMALIZED_SUBJECT_DIFFERS_FROM_LITERAL_QUERY_ROLE"
    predicate_terms = {_lemma(t) for t in nlp(atom["predicate"]) if not t.is_stop and not t.is_punct}
    if not predicate_terms <= {_lemma(t) for t in frame["verbs"]}:
        return None, "NORMALIZED_PREDICATE_DIFFERS_FROM_LITERAL_QUERY"
    offered = [t for values in frame["roles"].values() for t in values]
    if not _terms(nlp(atom["object"])) <= _terms(offered):
        return None, "NORMALIZED_PATIENT_DIFFERS_FROM_LITERAL_QUERY_ROLE"
    covered = {t.i for t in frame["agents"] + offered + frame["verbs"]}
    covered.update(t.i for t in doc if t.ent_type_ in {"DATE", "TIME"})
    uncovered = [t.text for t in doc if t.pos_ in _CONTENT and not t.is_stop and t.i not in covered]
    if uncovered:
        return None, "UNMODELED_LITERAL_QUERY_CONTENT: " + ", ".join(uncovered)
    actor_ids = {t.i for t in frame["agents"]}
    dates = [e.text.casefold() for e in doc.ents if e.label_ in {"DATE", "TIME"}
        and not all(t.i in actor_ids for t in e)]
    if dates and dates != _event_dates(roots[0]):
        return None, "UNIMPLEMENTED_QUERY_EVENT_TIME_SCOPE"
    frame.update(doc=doc, literal=literal, span_start=spans[0]["start"], requested_dates=dates)
    return frame, None


def _kind(record):
    if "native_relation" in record or "relation_evidence_id" in record:
        return "RELATION"
    if record.get("event_mention_id") or record.get("record_kind") == "event":
        return "EVENT"
    if record.get("claim_mention_id") or record.get("claim_text"):
        return "CLAIM"
    return "ENTITY_OR_UNKNOWN"


def _semantic(record):
    native = record.get("native_relation", record)
    return {k:deepcopy(native[k]) for k in _SEMANTIC if k in native}


def _qualifiers(frame, record):
    token = frame["predicate"]
    heads = [token, *token.ancestors]
    sentence = list(token.sent)
    reporting, nonfactive = [], []
    for head in heads[1:]:
        if head.pos_ == "NOUN" and _lemma(head) in _NONFACTIVE_NOUNS:
            nonfactive.append(head.text)
        if head.pos_ != "VERB":
            continue
        if _lemma(head) in _REPORT:
            speaker = [t for c in head.children if c.dep_ == "nsubj" for t in _phrase(c)]
            reporting.append(dict(predicate=head.text, speaker=" ".join(t.text for t in speaker),
                proofs=_proof([head, *speaker])))
        elif _lemma(head) in _NONFACTIVE:
            nonfactive.append(head.text)
    dates = _event_dates(token)
    role_tokens = frame["agents"] + [t for ts in frame["roles"].values() for t in ts]
    quoted = any(m.start() + token.sent.start_char < token.idx < m.end() + token.sent.start_char
        for m in re.finditer(r'"[^"]*"|\u201c[^\u201d]*\u201d|(?<!\w)\x27[^\x27]+\x27(?!\w)', token.sent.text))
    return dict(source_extracted_assertion_mode=record.get("assertion_mode"),
        source_extracted_speaker=record.get("speaker"),
        source_extracted_qualifiers={k:deepcopy(record[k]) for k in
            ("polarity", "modality", "conditional", "condition", "uncertainty", "negated",
                "negation_scope", "stance", "temporal_context", "date") if k in record},
        literal_reporting_scope=reporting, literal_nonfactive_scope=nonfactive,
        negated=any(c.dep_ == "neg" for h in heads for c in h.children)
            or any(t.lower_ in {"no", "none", "neither", "nor"} for t in role_tokens)
            or any(t.lower_ == "never" for t in sentence),
        modals=[c.text for h in heads for c in h.children if c.tag_ == "MD"],
        conditional=[t.text for t in sentence if t.lower_ in {"if", "unless", "provided"}],
        disjunctive_roles=any(t.lower_ in {"or", "nor"} for t in role_tokens),
        prospective_infinitival=any(c.tag_ == "TO" for c in token.children),
        direct_quotation=quoted,
        direct_quotation_has_literal_reporting_holder=bool(reporting and any(s["speaker"] for s in reporting)),
        uncertainty=[t.text for t in sentence if t.lower_ in {"apparently", "reportedly", "allegedly", "possibly", "perhaps", "probably"}],
        literal_event_date_mentions=dates, publication_date_is_event_date=False,
        historical_only=True, continued_tenure_certified=False,
        actual_inner_event_established=False)


def _role_check(target, offered, start, end):
    errors, bindings = [], {}
    agent_terms = _terms(target["agents"])
    named = [t for t in offered["agents"] if _lemma(t) in agent_terms]
    if not agent_terms <= _terms(named) or not any(t.pos_ == "PROPN" for t in named):
        errors.append("RAW_NAMED_ACTOR_ROLE_UNVERIFIED")
    else:
        bindings["actor"] = named
    if not {_lemma(t) for t in target["verbs"]} <= {_lemma(t) for t in offered["verbs"]}:
        errors.append("RAW_PREDICATE_OR_COMPLEMENT_UNVERIFIED")
    else:
        bindings["predicates"] = [t for t in offered["verbs"] if _lemma(t) in {_lemma(v) for v in target["verbs"]}]
    for role, wanted in target["roles"].items():
        terms = _terms(wanted)
        available = [t for t in offered["roles"].get(role, []) if _lemma(t) in terms]
        if not terms or not terms <= _terms(available):
            errors.append("RAW_ROLE_UNVERIFIED:" + role)
        else:
            bindings[role] = available
    if not target["roles"]:
        errors.append("NO_TYPED_QUERY_PATIENT")
    if any(not start <= t.idx < t.idx + len(t) <= end for ts in bindings.values() for t in ts):
        errors.append("ROLE_BINDING_OUTSIDE_NATIVE_QUOTE")
    return errors, {k:_proof(ts) for k,ts in bindings.items()}


def _raw_candidate(target, record, native, page_doc, ref, policy, pi, nlp):
    predicates = [t for t in page_doc if _lemma(t) == _lemma(target["predicate"])
        and t.pos_ == "VERB" and ref["start"] <= t.idx < t.idx + len(t) <= ref["end"]]
    attempts = []
    for token in predicates:
        frame = _frame(token)
        errors, bindings = _role_check(target, frame, ref["start"], ref["end"])
        qualifiers = _qualifiers(frame, native)
        if qualifiers["negated"]:
            errors.append("NEGATIVE_SOURCE_NOT_POSITIVE_OR_UNTIMED_OPPOSITION")
        if (qualifiers["modals"] or qualifiers["conditional"] or qualifiers["literal_nonfactive_scope"]
                or qualifiers["disjunctive_roles"] or qualifiers["prospective_infinitival"]):
            errors.append("NONACTUAL_OR_NONFACTIVE_SCOPE_NOT_COMPLETED_EVENT")
        if qualifiers["direct_quotation"] and not qualifiers["direct_quotation_has_literal_reporting_holder"]:
            errors.append("DIRECT_QUOTE_WITHOUT_VERIFIED_REPORTING_HOLDER")
        if any(t.casefold() in {"possibly", "perhaps", "probably", "apparently", "allegedly"} for t in qualifiers["uncertainty"]):
            errors.append("EPISTEMIC_UNCERTAINTY_NOT_UNQUALIFIED_COMPLETION")
        if token.tag_ == "VBG" or any(c.tag_ == "VBG" and _lemma(c) == "be" for c in token.children):
            errors.append("PROGRESSIVE_NOT_COMPLETED_EVENT")
        if target["predicate"].tag_ == "VBD" and token.tag_ not in {"VBD", "VBN"}:
            errors.append("HISTORICAL_EVENT_CLOCK_UNVERIFIED")
        if native.get("assertion_mode") not in {"report", "reported", "asserted", "assertion"}:
            errors.append("EXTRACTED_ASSERTION_MODE_NOT_REPORTED_EVENT")
        if (("polarity" in native and native["polarity"] not in {"positive", "affirmative"})
                or native.get("modality") in {"possible", "conditional", "planned", "forecast"}
                or any(native.get(k) for k in ("conditional", "condition", "uncertainty", "negated", "negation_scope"))):
            errors.append("EXTRACTED_NONACTUAL_OR_NEGATIVE_SCOPE_NOT_COMPLETED_POSITIVE")
        speaker = native.get("speaker")
        holders = " ".join(s["speaker"] for s in qualifiers["literal_reporting_scope"])
        if speaker and (not isinstance(speaker, str) or speaker.casefold() not in holders.casefold()):
            errors.append("EXTRACTED_SPEAKER_NOT_LITERAL_REPORTING_HOLDER")
        if target["requested_dates"] and target["requested_dates"] != qualifiers["literal_event_date_mentions"]:
            errors.append("REQUESTED_EVENT_TIME_NOT_VERIFIED")
        try:
            context = policy.citation(pi, token.sent.start_char, token.sent.end_char)
        except ValueError:
            context = None
            errors.append("OPAQUE_OR_INVALID_SCOPE_CONTEXT")
        # A normalized description with explicit reversed roles is not certified
        # merely because the native quote happens to contain all the names.
        description = " ".join(str(native.get(k, "")) for k in ("description", "claim_text"))
        if description:
            d = nlp(description)
            explicit = [_frame(t) for t in d if t.pos_ == "VERB" and _lemma(t) == _lemma(target["predicate"])]
            for semantic_frame in explicit:
                sq = _qualifiers(semantic_frame, native)
                if sq["negated"] or sq["modals"] or sq["conditional"] or sq["literal_nonfactive_scope"]:
                    errors.append("EXTRACTED_DESCRIPTION_NONACTUAL_OR_NEGATIVE")
                semantic_names = {_lemma(t) for t in semantic_frame["agents"] if t.pos_ == "PROPN"}
                raw_names = {_lemma(t) for t in frame["agents"] if t.pos_ == "PROPN"}
                if semantic_names and not semantic_names <= raw_names:
                    errors.append("EXTRACTED_DESCRIPTION_ACTOR_DISAGREES_WITH_TARGET")
                for role in target["roles"]:
                    # A generic 'the treaty' may omit raw adjectives; a different
                    # explicit patient/recipient head is a conflicting extraction.
                    semantic_heads = {_lemma(t) for t in semantic_frame["roles"].get(role, [])
                        if t.dep_ in {"dobj", "obj", "nsubjpass", "pobj", "attr", "oprd"} and t.pos_ != "PRON"}
                    raw_heads = {_lemma(t) for t in frame["roles"].get(role, [])
                        if t.dep_ in {"dobj", "obj", "nsubjpass", "pobj", "attr", "oprd", "nsubj"}}
                    if semantic_heads and not semantic_heads <= raw_heads:
                        errors.append("EXTRACTED_DESCRIPTION_ROLE_DISAGREES:" + role)
        attempts.append(dict(status="PARTIAL" if errors else "QUALIFIED_SOURCE_SUPPORT",
            reasons=sorted(set(errors)), raw_role_bindings=bindings, raw_syntax=frame["syntax"],
            source_qualifications=qualifiers, scope_context=context,
            literal_actor_identity_only=True, canonical_identity_certified=False,
            actual_inner_event_established=False))
    if not attempts:
        return dict(status="PROPOSAL", reasons=["LITERAL_PREDICATE_NOT_FOUND_IN_NATIVE_QUOTE"])
    return next((a for a in attempts if a["status"] == "QUALIFIED_SOURCE_SUPPORT"), attempts[0])


def evaluate(corpus, case, plan, *, inspected_page_ids, source_index,
             fact_index=None, nlp=None, record_budget=6000, candidate_budget_per_atom=80):
    """Read only recorded INSPECTED pages; the complete index can veto, not add proof.

    The caller supplies the existing Corpus/FactIndex and explicit frozen source
    mapping. No source proofs, reference answers, prior grades or retrieval calls
    are accepted. Output remains a separately versioned experimental sidecar.
    """
    if set(case) != _PUBLIC or case["task"] not in {"hypothesis", "mosaic", "reconstruction"}:
        raise ValueError("A public-only H/M case is required")
    if not isinstance(source_index, Mapping):
        raise ValueError("Complete frozen source-index mapping required")
    if type(record_budget) is not int or not 1 <= record_budget <= 10000:
        raise ValueError("Bounded record budget required")
    if type(candidate_budget_per_atom) is not int or not 1 <= candidate_budget_per_atom <= 200:
        raise ValueError("Bounded candidate budget required")
    adapted, checked_plan = deepcopy(case), deepcopy(plan)
    if case["task"] == "mosaic":
        adapted["task"] = "reconstruction"
        if checked_plan.get("task") == "mosaic":
            checked_plan["task"] = "reconstruction"
    public_plan(adapted, checked_plan)
    policy = SourcePolicy(corpus, adapted, source_index)
    positions = {p["id"]:i for i,p in enumerate(corpus.pages)}
    inspected = list(inspected_page_ids)
    if not inspected or len(inspected) != len(set(inspected)) or any(pid not in positions for pid in inspected):
        raise ValueError("Explicit distinct recorded INSPECTED page IDs required")
    for pid in inspected:
        p, bound = corpus.pages[positions[pid]], source_index.get(pid)
        if (bound is None or any(bound.get(k) != p.get(k) for k in
                ("id", "text", "document_id", "date", "source_sha256", "classification", "permitted", "visibility", "corpus"))
                or digest(p["text"]) != p["source_sha256"] or not policy.allowed(positions[pid])
                or pid in getattr(corpus, "excluded_pages", set())
                or p["document_id"] in getattr(corpus, "excluded_documents", set())
                or getattr(corpus, "allowed", None) is not None and not bool(corpus.allowed[positions[pid]])):
            raise ValueError("INSPECTED page fails frozen source/cutoff/whole-origin/handling replay")
    if nlp is None:
        from matryoshka_next.readings import _model
        nlp = _model()
    index = fact_index or source_facts(corpus)
    index.prime_local_records([positions[pid] for pid in inspected])
    atoms, counts, cache = [], Counter(), {}
    records = []
    for pid in inspected:
        for record in sorted(index.local_records(positions[pid]), key=digest):
            if _kind(record) != "ENTITY_OR_UNKNOWN":
                records.append((pid, record))
    incomplete = len(records) > record_budget
    records = records[:record_budget]
    for atom in plan["atoms"]:
        target, error = _target(adapted, atom, nlp)
        candidates, seen = [], {}
        if target is not None:
            wanted = _terms(target["doc"])
            actor_terms = _terms(target["agents"])
            for pid, record in records:
                native = record.get("native_relation", record)
                semantic = _semantic(record)
                description = " ".join(str(semantic.get(k, "")) for k in ("label", "description", "claim_text"))
                words = {t.casefold() for t in re.findall(r"[A-Za-z]+", description)}
                # A broad, non-certifying nomination filter, never a confidence.
                if not words & actor_terms and len(words & wanted) < 2:
                    continue
                proposal = dict(record_kind=_kind(record), semantic_record_sha256=digest(record),
                    source_record_id=next((record[k] for k in ("event_mention_id", "claim_mention_id", "relation_evidence_id") if k in record), None),
                    source_extracted_semantics=semantic, semantic_fields_are_original_quote=False,
                    status="PROPOSAL", reasons=[], source_page_id=pid)
                if len(candidates) >= candidate_budget_per_atom:
                    incomplete = True
                    break
                pi = positions[pid]
                try:
                    if any(native.get(k) != value for k,value in (("canonical_page_id",pid),
                            ("document_id",corpus.pages[pi]["document_id"]), ("document_date_iso",corpus.pages[pi]["date"]))):
                        raise ValueError("Extracted source identity changed")
                    if native.get("visibility") not in {"both", "earlier_only"} or native.get("introduced_by_slot_id"):
                        raise ValueError("Extraction is later/hidden/unknown")
                    ref = policy.citation(pi, native.get("char_start"), native.get("char_end"))
                    if ref["text"] != native.get("evidence_quote"):
                        raise ValueError("Native extraction quotation does not replay")
                    proposal["citation"] = ref
                except (ValueError, TypeError):
                    counts["rejected_native_source_quote"] += 1
                    proposal.update(status="REJECTED_SOURCE", reasons=["NATIVE_QUOTE_OR_EXTRACTION_BINDING_FAILED"])
                    candidates.append(proposal)
                    continue
                if _kind(record) == "RELATION":
                    proposal["reasons"] = ["RELATION_OR_EVENT_PARTICIPANT_IS_NOT_A_SIGNER_ROLE_CERTIFICATE"]
                else:
                    if pid not in cache:
                        cache[pid] = nlp(corpus.pages[pi]["text"])
                    proposal.update(_raw_candidate(target, record, native, cache[pid], ref, policy, pi, nlp))
                identity = digest([ref, proposal["status"], proposal.get("raw_role_bindings")])
                if identity in seen:
                    seen[identity].setdefault("duplicate_semantic_record_sha256", []).append(digest(record))
                    continue
                seen[identity] = proposal
                candidates.append(proposal)
        status = ("QUALIFIED_SOURCE_SUPPORT" if any(c["status"] == "QUALIFIED_SOURCE_SUPPORT" for c in candidates)
            else "PARTIAL" if any(c["status"] in {"PROPOSAL", "PARTIAL"} for c in candidates) else "NO_INFO")
        atoms.append(dict(id=atom["id"], text=" ".join(s["text"] for s in atom.get("query_spans", [])),
            public_plan_atom_text=atom["text"], literal_query_spans=deepcopy(atom.get("query_spans", [])),
            support_target="ORIGINAL_PUBLIC_QUERY_SPAN_NOT_GENERATED_ATOM_TEXT",
            required=atom.get("required", True) and atom.get("kind") != "context",
            status=status, query_gate_error=error, candidates=candidates,
            world_truth_certified=False, actual_inner_event_established=False))
    return dict(version=VERSION, experimental=True, default_engine_adopted=False,
        case_id=case["case_id"], query_sha256=digest(case["query"]), plan_sha256=digest(plan),
        inspected_page_ids=inspected, inspected_pool_sha256=digest(inspected),
        source_scope="FIXED_NATIVE_INSPECTED_POOL_ONLY", atoms=atoms,
        status="PARTIAL_STAGE_ONLY", atom_counts=dict(Counter(a["status"] for a in atoms if a["required"])),
        semantics="SOURCE_REPORTS_QUALIFIED_P_NOT_WORLD_PROOF",
        joint_bindings_established=False, opposition_implemented=False,
        independent_corroboration_claimed=False, extraction_semantics_alone_certify_nothing=True,
        diagnostics=dict(counts, typed_records_examined=len(records), raw_pages_parsed=len(cache),
            record_budget=record_budget, candidate_budget_per_atom=candidate_budget_per_atom,
            bounded_control_incomplete=incomplete),
        api_calls=0, keys_read=False, grades_read=False, retrieval_called=False,
        ordinary_engine_or_native_outputs_modified=False,
        limitations=["No final H/M verdict, event joins, canonical actor identity or time-completeness certificate.",
            "No untimed negative opposition; source absence is not opposition.",
            "Literal lexical/role control only; unmatched paraphrases and unmodeled clauses remain partial.",
            "Normalized descriptions are untrusted source-extracted fields, never original quotations."])
