"""Document-deduplicated terminal evidence and fit indices, never probabilities."""
from copy import deepcopy
import math
import re
from . import controller_role

VERSION = 'terminal-evidence-fit/3'
LEGACY_VERSION = 'terminal-evidence-fit/2'
EVIDENCE_VERSION = 'terminal-evidence-fit/4'
POINTS_VERSION = 'terminal-evidence-fit/5'
SOURCE_POINTS_VERSION = 'terminal-evidence-fit/6'
CONTEXT_POINTS_VERSION = 'terminal-evidence-fit/7'
SUPPORTED = {'SUPPORT', 'SUPPORTED', 'ESTABLISHED'}
OPPOSED = {'COUNTER', 'OPPOSED', 'OPPOSE'}
PARTIAL = {'PARTIAL', 'FEASIBLE', 'CONTEXT', 'UNRESOLVED'}
TIERS = {'evidence_backed_suggestion': 2, 'partial_grounding': 1,
         'exploratory_contextual': 0}


def _rows(value):
    return value if isinstance(value, list) else []


def _finite(value, fallback=0.):
    return float(value) if type(value) in (int, float) and math.isfinite(value) else fallback


def _citation(value):
    if not isinstance(value, dict):
        return None
    ref = value.get('citation', value)
    if (not isinstance(ref, dict) or not ref.get('document_id') or not ref.get('canonical_page_id')
            or type(ref.get('start')) is not int or type(ref.get('end')) is not int
            or ref['start'] < 0 or ref['end'] <= ref['start']
            or len(ref.get('text', '')) != ref['end'] - ref['start'] or not ref.get('page_sha256')):
        return None
    return ref


def _rank_map(retrieval):
    return {r.get('page_id'): r['page_rank'] for r in _rows(retrieval.get('top_sources'))
            if type(r.get('page_rank')) is int and r['page_rank'] >= 1}


def source_weight(ref, ranks, fallback_rank=None):
    rank = ranks.get(ref['canonical_page_id'], fallback_rank)
    if type(rank) is not int or not 1 <= rank < 10**10:
        return .5, None
    return .5 + .5 / (1 + math.log2(rank)), rank


def _sum_documents(observations, ranks):
    best = {}
    for direction, reference, fit, fallback_rank in observations:
        ref = _citation(reference)
        if ref is None:
            continue
        weight, rank = source_weight(ref, ranks, fallback_rank)
        fit = min(1., max(0., _finite(fit)))
        contribution = weight * fit
        key = (direction, ref['document_id'])
        row = dict(direction=direction, document_id=ref['document_id'], citation=deepcopy(ref),
                   retrieval_weight=weight, page_rank=rank, fit=fit, contribution=contribution)
        if key not in best or contribution > best[key]['contribution']:
            best[key] = row
    rows = sorted(best.values(), key=lambda r: (r['direction'], r['document_id']))
    totals = {name: sum(r['contribution'] for r in rows if r['direction'] == name)
              for name in ('support', 'oppose', 'context')}
    return totals, rows


def _applicable_checks(checks):
    return [c for c in _rows(checks) if isinstance(c, dict)
            and 'not required' not in str(c.get('detail', '')).casefold()
            and str(c.get('state', '')).casefold() not in {'not_applicable', 'n/a'}]


def criteria_fraction(unit):
    coverage = unit.get('coverage')
    if (isinstance(coverage, dict) and coverage.get('complete') is True
            or coverage == 'Established'):
        return 1.
    checks = _applicable_checks(unit.get('checks', unit.get('checklist', [])))
    if checks:
        return sum(str(c.get('state', '')).casefold() == 'pass' for c in checks) / len(checks)
    return 0.


def _scope_fit(candidate, plan):
    anchors = {}
    for entity in (plan or {}).get('extractions', {}).get('entities', []):
        if (entity.get('contains_unknown_slot') is not False or str(entity.get('type', '')).casefold()
                not in {'person', 'place', 'location', 'country', 'organization'}):
            continue
        label, quote = entity.get('label', ''), entity.get('evidence_quote', '')
        if (not isinstance(label, str) or not isinstance(quote, str) or not label
                or not any(c.isupper() for c in label) or label.casefold() not in quote.casefold()):
            continue
        labels = [label]
        for attribute in _rows(entity.get('attributes')):
            if attribute.get('key') == 'title' and isinstance(attribute.get('value'), str):
                title = attribute['value']
                if label.casefold().startswith(title.casefold() + ' '):
                    labels.append(label[len(title):].strip())
        for value in labels:
            if value:
                anchors.setdefault(value.casefold(), dict(label=value, query_entity=entity.get('local_id')))
    matches = {}
    for source in _rows(candidate.get('sources')):
        citation = _citation(source)
        if citation is None:
            continue
        for anchor in anchors.values():
            match = re.search(r'(?<!\w)' + re.escape(anchor['label']) + r'(?!\w)', citation['text'], re.I)
            if match:
                value = dict(**anchor, canonical_page_id=citation['canonical_page_id'],
                    start=citation['start'] + match.start(), end=citation['start'] + match.end(),
                    text=match.group(), source_owned_action_certified=False)
                matches[(anchor['label'].casefold(), citation['canonical_page_id'], value['start'], value['end'])] = value
    return dict(value=float(bool(matches)), matches=list(matches.values()),
                meaning='VISIBLE_QUERY_ANCHOR_COOCCURRENCE_ONLY')


def _function_band(candidate):
    key = candidate.get('context_rank_key')
    if not isinstance(key, (tuple, list)) or len(key) != 20 or any(type(v) is not bool for v in key[:9]):
        raise ValueError('Source-function band requires the native twenty-field key with nine boolean checks')
    names = ('named_or_owned_activity', 'own_person_role_or_goal', 'positive_source_clue',
             'owned_relation', 'source_type', 'owned_carrier', 'focal_argument_predicate',
             'no_visible_name_penalty', 'owned_role_context')
    checks = [dict(name=name, satisfied=not flag, contribution=2**(8-i) if not flag else 0)
              for i, (name, flag) in enumerate(zip(names, key[:9]))]
    observation = candidate.get('focal_visible_attachment_priority', {})
    attachment = observation.get('matched') is True
    if attachment and (observation.get('producer_replayed') is not True
            or observation.get('saved_observation_equal') is not True
            or observation.get('native_exploratory_only') is not True
            or observation.get('version') != 'native-role-kind-visible-attachment-order/1'
            or candidate.get('local_decision', {}).get('status') != 'exploratory_contextual'):
        raise ValueError('Visible-role attachment lacks its original verified contextual producer observation')
    return dict(value=sum(c['contribution'] for c in checks) + 512*attachment,
                source_checks=checks, declared_visible_attachment=attachment,
                source_key_available=True, rank_or_pool_position_used=False)


def candidate_score(candidate, retrieval=None, *, plan=None, version=VERSION, case=None):
    if version == CONTEXT_POINTS_VERSION:
        from .contextual_scores import score
        return score(candidate, case, plan, retrieval or {})
    if version not in {VERSION, LEGACY_VERSION, EVIDENCE_VERSION, POINTS_VERSION, SOURCE_POINTS_VERSION}:
        raise ValueError('Unknown terminal arithmetic version')
    decision = candidate.get('local_decision', {})
    feature = candidate.get('ranking', {}).get('features', {})
    count = _finite(feature.get('focal_context_coverage'))
    denominator = _finite(feature.get('focal_term_count'))
    overlap = min(1., count / denominator) if denominator > 0 else 0.
    primary = [r for r in _rows(candidate.get('source_occurrences'))
               if r.get('source_span') == candidate.get('source_span')
               and r.get('source_wording') == candidate.get('source_wording')]
    cues = [r.get('selection_cue', {}) for r in primary]
    relation = (any(feature.get(k) is True for k in ('source_owned_relation_match',
        'source_owned_property_match', 'direct_actor_relation_match', 'direct_argument_relation_match'))
        or any(c.get('owned_goal_context', {}).get('matched') is True for c in cues))
    role = (feature.get('source_owned_role_context', {}).get('matched') is True
            or any((c.get('own_role_context') or {}).get('matched') is True for c in cues))
    kind = (feature.get('source_type_match') is True
            or any(c.get('named_actor_priority') is True or c.get('named_example_priority') is True for c in cues))
    scope = _scope_fit(candidate, plan)
    fit_components = dict(owned_relation=.32 * relation, owned_role=.16 * role,
                          source_type=.16 * kind, focal_terms=.16 * overlap, visible_scope=.2 * scope['value'])
    fit = sum(fit_components.values())
    observations = []
    fallback_rank = feature.get('retrieval_page_rank')
    for ref in _rows(candidate.get('sources')):
        observations.append(('context', ref, fit, fallback_rank))
    requirements = _rows(decision.get('requirements'))
    for requirement in requirements:
        complete = requirement.get('coverage') == 'Established'
        for item in _rows(requirement.get('evidence')):
            direction = str(item.get('direction', requirement.get('direction', ''))).upper()
            target = 'oppose' if direction in OPPOSED or 'COUNTEREVIDENCE' in direction else (
                'support' if complete and direction in {'SUPPORT', 'SUPPORTED'} else 'context')
            for ref in [item.get('citation'), *_rows(item.get('citations'))]:
                observations.append((target, ref, 1. if target != 'context' else criteria_fraction(requirement), None))
        if complete and requirement.get('direction') == 'Support':
            for ref in _rows(requirement.get('citations')):
                observations.append(('support', ref, 1., None))
        for ref in _rows(requirement.get('context_citations')):
            observations.append(('context', ref, fit, fallback_rank))
    totals, contributions = _sum_documents(observations, _rank_map(retrieval or {}))
    status = decision.get('status')
    tier = TIERS.get(status, -1)
    if status == 'partial_grounding' and not any(r.get('coverage') == 'Established' for r in requirements):
        tier = 0
    # Preserve logical sufficiency before ranking contextual alternatives.
    utility = max(0., (totals['support'] + fit + .5 * totals['context']) / (1 + totals['oppose']))
    band = _function_band(candidate) if version in {VERSION, POINTS_VERSION, SOURCE_POINTS_VERSION} else None
    residual = utility / (1 + utility)
    score = max(0., tier + ((band['value'] + residual)/1024 if band else residual)) if tier >= 0 else 0.
    if version == EVIDENCE_VERSION:
        score *= 100
    points = None
    if version in {POINTS_VERSION, SOURCE_POINTS_VERSION}:
        # Type compatibility and absence of a name penalty are not functional nomination cues.
        functional = bool(band['value'] & ~18)
        points = dict(evidence_tier_points=100*max(0, tier),
            source_function_points=(40*functional + 25*band['value']/1023
                                    if version == SOURCE_POINTS_VERSION else 65*band['value']/1023),
            evidence_fit_points=35*residual,
            source_function_max=65, evidence_fit_max=35,
            utility=utility, saturated_utility=residual,
            rank_or_pool_position_used=False)
        score = sum(points[k] for k in ('evidence_tier_points', 'source_function_points', 'evidence_fit_points')) if tier >= 0 else 0.
    coverage = sum(criteria_fraction(r) for r in requirements) / len(requirements) if requirements else 0.
    return dict(version=version, id=candidate.get('id'), score=score, native_status=status,
        evidence_tier=tier, fit=fit, fit_components=fit_components, visible_scope=scope, criteria_coverage=coverage,
        source_function_band=band,
        support=totals['support'], oppose=totals['oppose'], context=totals['context'],
        contributions=contributions, calibrated_probability=False,
        score_units='EVIDENCE_FIT_POINTS_NOT_CORRECTNESS_CONFIDENCE' if version in {EVIDENCE_VERSION, POINTS_VERSION, SOURCE_POINTS_VERSION} else 'INDEX',
        **({'ranking_components': points} if points is not None else {}),
        **({'source_function_context': dict(matched=functional, excluded_bits=[16, 2],
            meaning='POSITIVE_FUNCTIONAL_NOMINATION_CUE_NOT_FACTUAL_SUPPORT')}
           if version == SOURCE_POINTS_VERSION else {}),
        formula=('100*tier + 40*W + 25*B/1023 + 35*u/(1+u); W=bool(B & ~18); u=(support+fit+0.5*context)/(1+oppose)' if version == SOURCE_POINTS_VERSION else
                 '100*tier + 65*B/1023 + 35*u/(1+u); u=(support+fit+0.5*context)/(1+oppose)' if version == POINTS_VERSION else
                 '100*(tier + u/(1+u)); u=(support+fit+0.5*context)/(1+oppose)' if version == EVIDENCE_VERSION else
                 'tier + (B + u/(1+u))/1024; B=source_function_band; u=(support+fit+0.5*context)/(1+oppose)'
                 if band else 'tier + u/(1+u); u=(support+fit+0.5*context)/(1+oppose)'),
        document_deduplication='MAX_PER_DOCUMENT_AND_DIRECTION', gates_modified=False)


def atom_score(atom, retrieval=None, *, version=VERSION):
    observations = []
    for key, fallback in (('evidence', None), ('positive_evidence', 'support'),
                          ('counterevidence', 'oppose'), ('partial_evidence', 'context')):
        for item in _rows(atom.get(key)):
            direction = str(item.get('direction', '')).upper()
            target = 'support' if direction in SUPPORTED else 'oppose' if direction in OPPOSED else fallback or 'context'
            complete = item.get('complete_required_frames') is True or item.get('whole_clause_certificate') is True
            if target == 'support' and direction not in SUPPORTED and not complete:
                target = 'context'
            ratio = 1. if target != 'context' else criteria_fraction(item)
            for ref in [item.get('citation'), *_rows(item.get('citations'))]:
                observations.append((target, ref, ratio, None))
    totals, contributions = _sum_documents(observations, _rank_map(retrieval or {}))
    requirements = _rows(atom.get('requirements'))
    coverage = (sum(criteria_fraction(r) for r in requirements) / len(requirements)
                if requirements else float(atom.get('status') in SUPPORTED))
    return dict(version=version, id=atom.get('id'), native_status=atom.get('status'),
        score=totals['support'] - totals['oppose'], support=totals['support'],
        oppose=totals['oppose'], context=totals['context'], criteria_coverage=coverage,
        contributions=contributions, calibrated_probability=False, gates_modified=False)


def score_result(result, retrieval=None, *, plan=None, version=VERSION, case=None):
    score_args = dict(plan=plan, version=version)
    if version == CONTEXT_POINTS_VERSION:
        score_args['case'] = case
    readings = []
    for reading in _rows(result.get('readings')):
        readings.append(dict(id=reading['reading']['id'], candidates=[
            candidate_score(c, retrieval, **score_args) for c in _rows(reading.get('candidates'))]))
    atoms = [atom_score(a, retrieval, version=version) for a in _rows(result.get('atoms'))]
    return dict(version=version, readings=readings, atoms=atoms,
        overall=dict(native_status=result.get('status'), support=sum(a['support'] for a in atoms),
            oppose=sum(a['oppose'] for a in atoms), context=sum(a['context'] for a in atoms),
            complete_atoms=sum(a.get('native_status') in SUPPORTED for a in atoms), required_atoms=len(atoms),
            aggregation_scope='SUM_OF_FACT_WISE_INDICES_NOT_DISTINCT_DOCUMENT_VOTES'),
        source_weight_formula='0.5 + 0.5/(1+log2(page_rank)); 0.5 if unrecorded',
        within_unit_same_document_repetitions_add_no_credit=True, probability=False,
        document_deduplication_scope='WITHIN_EACH_CANDIDATE_OR_FACT_AND_DIRECTION',
        support_threshold_is_not_score_one=True, judgments_unchanged=True)


def annotate_result(result, retrieval=None, *, rerank=False, top_k=5, plan=None, version=VERSION, case=None):
    """Annotate newly executed results; never rewrite a historical saved packet."""
    value = deepcopy(result)
    score_args = dict(plan=plan, version=version)
    if version == CONTEXT_POINTS_VERSION:
        score_args['case'] = case
    if rerank and value.get('task') == 'redaction':
        pool = _rows(value.get('assessed_candidates')) or [
            c for r in _rows(value.get('readings')) for c in _rows(r.get('candidates'))]
        withheld = set()
        for candidate in pool:
            if controller_role.withheld_from_shortlist(candidate, query_sha256=value.get('query_sha256')):
                withheld.add(candidate['id'])
                candidate['terminal_scorecard'] = candidate_score(candidate, retrieval, **score_args)
        shortlist = value.get('controller_shortlist')
        if withheld or isinstance(shortlist, dict):
            ids = shortlist.get('withheld_candidate_ids') if isinstance(shortlist, dict) else None
            if (not isinstance(ids, list) or any(not isinstance(cid, str) for cid in ids)
                    or len(ids) != len(set(ids)) or set(ids) != withheld
                    or shortlist.get('audit_collection') != 'assessed_candidates'):
                raise ValueError('Controller withheld inventory must remain accessible in the raw assessed pool')
        for row in _rows(value.get('readings')):
            candidates = {c['id']: c for c in pool if c.get('reading_id') == row['reading']['id']
                          and c.get('local_decision', {}).get('status') in TIERS and c['id'] not in withheld}
            if version in {EVIDENCE_VERSION, POINTS_VERSION, SOURCE_POINTS_VERSION, CONTEXT_POINTS_VERSION}:
                from .candidate_identity import consolidate
                candidates = {c['id']: c for c in consolidate(candidates.values(),
                    score=lambda c: candidate_score(c, retrieval, **score_args),
                    source_local_identity=version in {POINTS_VERSION, SOURCE_POINTS_VERSION, CONTEXT_POINTS_VERSION},
                    query_sha256=value.get('query_sha256'))}
            ordered = sorted(candidates.values(), key=lambda c: (
                -candidate_score(c, retrieval, **score_args)['score'], c.get('source_rank_position', 10**9), c['id']))
            seen, families, selected = set(), set(), []
            for candidate in ordered:
                key = ' '.join(candidate['fill'].casefold().split())
                decision = candidate.get('local_decision', {})
                family = (candidate.get('alternative_family', candidate['id']), decision.get('status'), decision.get('scope'),
                    tuple((r.get('id'), str(r.get('coverage')), r.get('direction'))
                          for r in _rows(decision.get('requirements'))), bool(decision.get('counterevidence')))
                surface_scope = (key, decision.get('scope'))
                if surface_scope in seen or family in families:
                    continue
                seen.add(surface_scope)
                families.add(family)
                selected.append(candidate)
                if len(selected) == top_k:
                    break
            row['candidates'] = selected
            for rank, candidate in enumerate(selected, 1):
                candidate['rank'] = rank
                candidate['terminal_scorecard'] = candidate_score(candidate, retrieval, **score_args)
                candidate.setdefault('ranking', {}).update(terminal_scoring_version=version,
                    canonical_order=('Evidence class plus weighted source-function and document-evidence fit points; source position breaks exact ties'
                        if version in {POINTS_VERSION, SOURCE_POINTS_VERSION, CONTEXT_POINTS_VERSION} else 'Evidence tier, native source/function feature band, saturated document-weighted evidence and fit; source position breaks exact ties'
                        if version == VERSION else 'Terminal evidence tier plus saturated document-weighted evidence and source-owned fit; source position breaks exact ties'))
        value['candidates'] = [c for r in value['readings'] for c in r['candidates']]
        shortlist = value.get('controller_shortlist')
        if isinstance(shortlist, dict):
            shortlist['displayed_count'] = len(value['candidates'])
            for row in _rows(value.get('readings')):
                rid = row['reading']['id']
                counts = shortlist.get('counts_by_reading', {}).get(rid)
                if isinstance(counts, dict):
                    counts['displayed'] = len(row['candidates'])
    value['terminal_scores'] = score_result(value, retrieval, **score_args)
    value['terminal_scores']['ranking_applied'] = rerank
    return value
