"""Exact visible-person/source-apposition ownership, contextual priority only."""
from datetime import date
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo.roles import lexicon
from matryoshka_next.quotations import locate
from matryoshka_next.facts import _HANDLING

VERSION = "literal-visible-person-owned-role-apposition-context/1"
NAME_DEPS = {"compound","flat","flat:name","name"}
CLAUSE_DEPS = {"ccomp","xcomp","advcl","relcl","parataxis"}


def proof(t):
    return dict(i=t.i,text=t.text,start=t.idx,end=t.idx+len(t),pos=t.pos_,tag=t.tag_,
        dependency=t.dep_,head_start=t.head.idx,morph=str(t.morph),entity=t.ent_type_)


def _literal(text):
    return " ".join(text.casefold().split())


def _span(doc,values):
    values = sorted(values,key=lambda t:t.i)
    a,b = values[0].idx,values[-1].idx+len(values[-1])
    part = doc.char_span(a,b,alignment_mode="strict")
    if part is None or {t for t in part if not t.is_space} != set(values):
        return None
    return part


def bind_public(case,reading,entity,visible):
    query,marker = case["query"],case["focal_marker"]
    if (reading.get("constructor_form",reading.get("form")) != "nominal"
            or reading.get("outer_family","nominal") != "nominal" or not isinstance(marker,str) or not marker
            or query.count(marker) != 1 or entity.get("type") != "person" or visible is None):
        return None
    if (visible.get("query_sha256") != digest(query)
            or visible.get("original_entity_record_sha256") != digest(entity)
            or visible.get("context_hint_only") is not True):
        raise ValueError("Visible label is not bound to this public entity/query")
    label = visible.get("literal_label")
    if not isinstance(label,str) or not label or MASK.search(label):
        return None
    bindings = visible.get("label_bindings",[])
    located = set()
    for binding in bindings:
        a,b = binding.get("start"),binding.get("end")
        locator = binding.get("locator")
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(query)
                or query[a:b] != binding.get("text") or _literal(query[a:b]) != _literal(label)
                or locator not in entity.get("query_spans",[])):
            raise ValueError("Visible label lost its exact query-span binding")
        x,y = locator.get("start"),locator.get("end")
        if (type(x) is not int or type(y) is not int or not 0 <= x <= a < b <= y <= len(query)
                or query[x:y] != locator.get("text")):
            raise ValueError("Visible locator lost its original public text")
        lo,hi,_,_ = locate(query[x:y],entity["label"],allow_layout=True,ignore_case=True,token_boundaries=True)
        if (x+lo,x+hi) != (a,b):
            raise ValueError("Visible label differs from the full declared Person label")
        located.add((a,b))
    if len(located) != 1:
        return None
    a,b = next(iter(located))
    end = query.index(marker)+len(marker)
    if not re.fullmatch(r"\s*,\s*",query[end:a]) or not re.match(r"\s*,",query[b:]):
        return None
    return dict(query_sha256=digest(query),reading_sha256=digest(reading),entity_sha256=digest(entity),
                visible_record_sha256=digest(visible),span=[a,b],literal_label=query[a:b])


def observe(case,reading,entity,visible,page,doc,raw):
    result = dict(version=VERSION,matched=False,context_only=True,identity_or_action_certified=False,
        factual_support_certified=False,grammar_certified=False,identity_certified=False,
        event_certified=False,source_eligibility_certified=False,reasons=[])
    def finish(reason):
        result["reasons"] = [] if reason is None else [reason]
        result["sha256"] = digest(result)
        return result
    public = bind_public(case,reading,entity,visible)
    if public is None:
        return finish("NO_EXACT_COMMA_BOUND_VISIBLE_PERSON")
    text = page["text"]
    if doc.text != text or digest(text) != page["source_sha256"]:
        raise ValueError("Original source page/Doc hash changed")
    try:
        earlier = date.fromisoformat(page["date"]) < date.fromisoformat(case["date"])
    except (KeyError,ValueError,TypeError):
        return finish("SOURCE_DATE_UNRESOLVED")
    if (not earlier or page["document_id"] == case["document_id"] or page.get("permitted") is not True
            or page.get("classification") != "CONFIDENTIAL" or page.get("visibility") not in {"earlier","both"}):
        return finish("CALLER_EARLIER_ELIGIBLE_SOURCE_FLAGS_NOT_PRESENT")
    if _HANDLING.search(text) or any(_HANDLING.search(str(h)) for h in page.get("handling",[]) or []):
        return finish("OWN_SOURCE_HANDLING_VETO")
    a,b = raw.get("start"),raw.get("end")
    if (raw.get("kind") != "nominal" or type(a) is not int or type(b) is not int
            or not 0 <= a < b <= len(text) or text[a:b] != raw.get("text")):
        return finish("RAW_NOMINAL_SOURCE_SPAN_NOT_EXACT")
    part = doc.char_span(a,b,alignment_mode="strict")
    if part is None or len(part) > 32:
        return finish("SOURCE_TOKEN_BOUND_OR_ALIGNMENT_HOLD")
    role = part.root
    senses = [s.name() for s in lexicon().synsets(role.lemma_.casefold(),pos="n")
              if s.lexname() == "noun.person" and any(l.name() == role.lemma_.casefold() for l in s.lemmas())]
    if role.pos_ not in {"NOUN","PROPN"} or role.tag_ not in {"NN","NNP"} or not senses:
        return finish("HEAD_NOT_EXACT_DICTIONARY_COMMON_PERSON_ROLE")
    if role.dep_ != "appos" or role.head.pos_ != "PROPN":
        return finish("NOT_DIRECT_ROLE_APPOSITION_OF_PROPER_NAME")
    owner = role.head
    if (any(t.dep_ in CLAUSE_DEPS for t in (owner,*owner.ancestors))
            or owner.dep_ in {"poss","nmod:poss","conj","appos"}
            or any(c.dep_ in {"poss","nmod:poss","conj","cc"} for c in owner.children)
            or [c for c in owner.children if c.dep_ == "appos"] != [role]):
        return finish("OWNER_OTHER_CLAUSE_POSSESSOR_OR_AMBIGUOUS_APPOSITION")
    words = [t for t in role.subtree if not t.is_space and not (t.is_punct and t.text == ",")]
    complete = _span(doc,words)
    if complete is None or (complete.start_char,complete.end_char) != (a,b):
        return finish("CANDIDATE_CLIPS_OR_CHANGES_COMPLETE_ROLE_NP")
    if any(t.pos_ in {"VERB","AUX","SCONJ"} or t.dep_ in CLAUSE_DEPS | {"poss","nmod:poss","conj","cc"}
           or t != role and t.dep_ == "appos" for t in part):
        return finish("ROLE_NP_HAS_CLAUSAL_POSSESSED_OR_NESTED_OWNERSHIP")
    name,pending = {owner},[owner]
    while pending:
        node = pending.pop()
        for child in node.children:
            if child.dep_ in NAME_DEPS:
                if child.pos_ != "PROPN":
                    return finish("SOURCE_NAME_FOREST_NOT_ENTIRELY_PROPER")
                if child not in name:
                    name.add(child);pending.append(child)
    full_name = _span(doc,list(name))
    if full_name is None or _literal(full_name.text) != _literal(public["literal_label"]):
        return finish("FULL_SOURCE_PROPER_NAME_NOT_FULL_VISIBLE_LABEL")
    if any(c not in name and c != role and c.dep_ not in {"punct"} and not c.is_space
           for t in name for c in t.children):
        return finish("UNBOUND_SOURCE_NAME_MODIFIER_OR_OWNER")
    sentence = owner.sent
    if role.sent != sentence or part[0].sent != sentence or part[-1].sent != sentence:
        return finish("SOURCE_ROLE_OWNER_CROSS_UNIT")
    quote = dict(canonical_page_id=page["id"],document_id=page["document_id"],date=page["date"],
        page_sha256=page["source_sha256"],start=sentence.start_char,end=sentence.end_char,
        text=text[sentence.start_char:sentence.end_char])
    if MASK.search(quote["text"]):
        return finish("OPAQUE_SOURCE_PARENT")
    scope = [dict(token=proof(t),children=[proof(c) for c in t.children]) for t in (owner,*owner.ancestors) if t.sent == sentence]
    result.update(matched=True,public_binding=public,source_candidate=dict(start=a,end=b,text=text[a:b]),
        source_role_head=proof(role),source_role_tokens=[proof(t) for t in part],
        common_person_role_synsets=senses,source_full_proper_name=dict(start=full_name.start_char,end=full_name.end_char,
            text=full_name.text,tokens=[proof(t) for t in full_name]),source_owner_root=proof(owner),
        source_parent_quote=quote,source_scope_chain=scope,
        source_qualifiers_retained_not_asserted=True,source_words_modified=False,
        hidden_role_name_inferred_from_query=False,canonical_identity_certified=False)
    return finish(None)


def binds_occurrence(observed,occurrence,query_sha256):
    if (observed.get("version") != VERSION or observed.get("matched") is not True
            or observed.get("context_only") is not True
            or observed.get("sha256") != digest({k:v for k,v in observed.items() if k != "sha256"})
            or observed["public_binding"]["query_sha256"] != query_sha256):
        return False
    own = observed["source_candidate"]
    quote,ref = observed["source_parent_quote"],occurrence["citation"]
    return (occurrence.get("source_span") == [own["start"],own["end"]]
        and occurrence.get("source_wording") == own["text"]
        and all(ref.get(k) == quote.get(k) for k in ("canonical_page_id","document_id","date","page_sha256"))
        and ref["start"] <= quote["start"] < quote["end"] <= ref["end"]
        and ref["text"][quote["start"]-ref["start"]:quote["end"]-ref["start"]] == quote["text"])
