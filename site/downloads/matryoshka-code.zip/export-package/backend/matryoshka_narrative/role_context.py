"""Literal nominal role ownership for narrative scheduling, never identity proof."""
from functools import lru_cache

from matryoshka_demo import roles
from matryoshka_demo.contracts import MASK


VERSION = "narrative-owned-nominal-role-context/3"
QUALIFIERS = {"former", "ex", "acting", "current", "previous", "past", "future",
              "new", "late", "then", "not", "no", "never", "neither", "nor"}
NEGATORS = {"not", "no", "never", "neither", "nor"}
MODIFIERS = {"amod", "compound", "nmod", "nummod"}


@lru_cache(maxsize=4096)
def _concepts(word, kind):
    senses = roles.concepts(word)
    if kind == "organization":
        return tuple(s for s in senses if any(h.name() == "organization.n.01"
            for h in (s, *s.closure(lambda n: n.hypernyms()))))
    return tuple(s for s in senses if s.lexname() == "noun.person" and any(
        h.name() == "person.n.01" for h in (s, *s.closure(lambda n: n.hypernyms()))))


@lru_cache(maxsize=4096)
def _compound_role(words, kind):
    phrase = "_".join(words)
    senses = roles.lexicon().synsets(phrase, pos="n")
    return tuple(s for s in senses if s.lexname() == ("noun.group" if kind == "organization" else "noun.person")
        and any(l.name().islower() and l.name() == phrase for l in s.lemmas())
        and any(h.name() == ("organization.n.01" if kind == "organization" else "person.n.01")
                for h in (s, *s.closure(lambda n: n.hypernyms()))))


def _lemma(token):
    if token.lower_ == "acting" and token.dep_ == "amod":
        return "acting"
    return token.lemma_.casefold()


def _role(token, owner, kind):
    if _lemma(token) in QUALIFIERS:
        return False
    if token.pos_ == "NOUN" and not token.ent_type_:
        return bool(_concepts(_lemma(token), kind))
    if (token == owner and token.pos_ == "PROPN" and not token.ent_type_
            and any(c.dep_ == "det" for c in token.children)):
        return bool(_concepts(token.text.casefold(), kind))
    # A title is a common dictionary role, not a lookup of the following name.
    if (token.pos_ == "PROPN" and token.dep_ in {"compound", "nmod"}
            and token.i < owner.i and owner.pos_ in {"NOUN", "PROPN"}
            and token.ent_type_ not in {"PERSON", "ORG", "GPE", "LOC", "FAC"}):
        return bool(_concepts(token.text.casefold(), kind))
    return False


def _record(token):
    return dict(text=token.text, lemma=_lemma(token), pos=token.pos_,
        dependency=token.dep_, span=[token.idx, token.idx+len(token)])


def _descriptor(token, owner, kind, ownership):
    tokens = {token.i: token}
    pending = [token]
    while pending:
        node = pending.pop()
        for child in node.children:
            if ((child.dep_ in MODIFIERS | {"det", "neg", "advmod"}
                     or child.dep_ in {"preconj", "cc"} and _lemma(child) in NEGATORS)
                    and (child.pos_ not in {"VERB", "AUX"} or _lemma(child) in QUALIFIERS)):
                tokens[child.i] = child
                pending.append(child)
            elif child.dep_ == "prep":
                # Preserve role discriminators (chief of staff), not their roles.
                branch = list(child.subtree)
                if not any(t.pos_ in {"VERB", "AUX"} or t.dep_ in {"poss", "agent"}
                           or t.ent_type_ == "PERSON" for t in branch):
                    tokens.update((t.i, t) for t in branch)
    ordered = sorted(tokens.values(), key=lambda t: t.i)
    qualifiers = [t for t in ordered if _lemma(t) in QUALIFIERS or t.dep_ == "neg"]
    modifiers = [t for t in ordered if t != token and t not in qualifiers
        and t.pos_ in {"NOUN", "ADJ", "PROPN", "NUM"}]
    required = [t for t in modifiers if t.dep_ in {"compound", "nmod", "nummod", "pobj", "obj"}
        or _compound_role((_lemma(t), _lemma(token)), kind)]
    lo, hi = ordered[0].idx, ordered[-1].idx+len(ordered[-1])
    return dict(head=_record(token), modifiers=[_record(t) for t in modifiers],
        required_modifiers=[_record(t) for t in required],
        qualifiers=[_record(t) for t in qualifiers], ownership=ownership,
        span=[lo, hi], quote=token.doc.text[lo:hi],
        negated=any(t.dep_ == "neg" or _lemma(t) in NEGATORS for t in qualifiers))


def query_context(case, reading, parse):
    """Prefer the bound attachment's role heads; broad query words are not a bag."""
    kind = "organization" if reading.get("target_kind") == "organization" else "person"
    quote = reading.get("attachment_quote", "")
    attachment = parse(quote) if quote else None
    broad = parse(MASK.sub(lambda m: " "*len(m.group()), case["query"]))
    def extract(doc, basis):
        if doc is None:
            return []
        values = []
        for token in doc:
            # A capitalized role at the edge of an attachment has no name yet.
            title = (basis == "LITERAL_QUERY_ATTACHMENT" and token.pos_ == "PROPN" and not token.ent_type_
                     and _lemma(token) not in QUALIFIERS
                     and bool(_concepts(token.text.casefold(), kind)))
            if _role(token, token.head, kind) or title:
                if (token.dep_ in MODIFIERS and token.head != token and token.head.pos_ in {"NOUN", "PROPN"}
                        and not (token.head.pos_ == "PROPN" and token.head.ent_type_ == "PERSON")):
                    continue
                if (basis == "LITERAL_QUERY_ATTACHMENT" and any(
                        a.pos_ == "NOUN" and _role(a, a.head, kind) for a in token.ancestors)):
                    continue
                values.append(_descriptor(token, token.head, kind, basis))
        return values
    try:
        values = extract(attachment, "LITERAL_QUERY_ATTACHMENT")
        if not values:
            values = extract(broad, "VISIBLE_QUERY_ROLE_HEADS")
    except (LookupError, OSError):
        return dict(version=VERSION, kind=kind, query_basis="RESOURCE_UNAVAILABLE",
            attachment_quote=quote, role_heads=[], resource_unavailable=True)
    basis = values[0]["ownership"] if values else "VISIBLE_QUERY_ROLE_HEADS"
    return dict(version=VERSION, kind=kind, query_basis=basis, attachment_quote=quote,
        role_heads=values, all_broad_query_words_required=False)


def _owned_descriptors(part, kind, source_types):
    owner = part.root
    named_owner = owner.ent_type_ == "PERSON" or any(
        w.get("source_entity_type") == "Person" and w["start"] <= owner.idx
        and owner.idx+len(owner) <= w["end"] for w in source_types)
    found, excluded = [], []
    def add(token, ownership):
        between = part.doc[min(token.i, owner.i):max(token.i, owner.i)+1]
        if any(t.text == ";" for t in between):
            excluded.append(dict(head=_record(token), reason="LIST_ITEM_BOUNDARY"))
            return
        if any(t.dep_ == "conj" and t.pos_ in {"NOUN", "PROPN"}
               and not _role(t, owner, kind) for t in between if t != owner):
            excluded.append(dict(head=_record(token), reason="INTERVENING_OTHER_NOMINAL_CONJUNCT"))
            return
        if any(c.dep_ == "poss" for c in token.children):
            excluded.append(dict(head=_record(token), reason="POSSESSED_DESCRIPTOR"))
            return
        if not _role(token, owner, kind):
            excluded.append(dict(head=_record(token), reason="NOT_A_COMMON_ROLE_HEAD"))
            return
        descriptor = _descriptor(token, owner, kind, ownership)
        owner_qualifiers = [c for c in owner.children if c.dep_ in {"amod", "neg", "advmod", "det"}
            and (_lemma(c) in QUALIFIERS or c.dep_ == "neg") and c not in token.subtree]
        descriptor["owner_qualifiers"] = [_record(t) for t in owner_qualifiers]
        descriptor["negated"] |= any(t.dep_ == "neg" or _lemma(t) in NEGATORS for t in owner_qualifiers)
        if token.dep_ == "conj":
            coordinated = [c for c in token.head.children if _lemma(c) in {"neither", "nor"}]
            descriptor["coordinated_negation"] = [_record(t) for t in coordinated]
            descriptor["negated"] |= bool(coordinated)
        found.append(descriptor)
        for child in token.children:
            if child.dep_ == "conj" and _role(child, owner, kind):
                # Coordinated roles may share an owner; coordinated people do not.
                if not any(t.pos_ == "PROPN" or t.ent_type_ == "PERSON" for t in child.subtree):
                    add(child, ownership)
    if _role(owner, owner, kind):
        add(owner, "EXACT_SOURCE_NP_HEAD")
    for child in owner.children:
        if child.dep_ in {"compound", "nmod"} and named_owner:
            add(child, "OWN_PRENAME_TITLE")
        elif child.dep_ == "appos":
            add(child, "DIRECT_NOMINAL_APPOSITION")
    if owner.dep_ == "appos" and owner.head.pos_ in {"NOUN", "PROPN"}:
        # Reverse apposition is safe only for a role, not another named owner.
        if not any(c.dep_ in {"compound", "appos", "conj"} and c.pos_ == "PROPN"
                   and c != owner for c in owner.head.children):
            add(owner.head, "DIRECT_NOMINAL_APPOSITION")
    return found, excluded


@lru_cache(maxsize=4096)
def _compare(query, source, kind):
    wanted = {s.name(): s for s in _concepts(query, kind)}
    for sense in _concepts(source, kind):
        for node, distance in [(sense, 0), *[(h, 1) for h in sorted(sense.hypernyms(), key=lambda s: s.name())]]:
            if node.name() in wanted:
                return dict(source_word=source, query_word=query, source_concept=sense.name(),
                    query_concept=node.name(), hypernym_edges=distance,
                    match_kind="SAME_COMMON_ROLE" if distance == 0 else "COMMON_ROLE_HYPERNYM")
    return None


def independent_anchor_context(wording, citation, anchors, context):
    from .candidate_salience import anchor_match, tokens
    own=set(tokens(wording))
    role_words={w for r in context["role_heads"] for w in tokens(r["quote"])}
    independent=[a for a in anchors if not set(tokens(a["key"]))<=own
        and not set(tokens(a["key"]))<=role_words]
    return anchor_match(wording,citation,independent)


def owned_role_context(part, context, source_types=(), anchor_context=None):
    """Roles stay on the candidate's own head/title or direct nominal apposition."""
    value = dict(version=VERSION, matched=False, query_basis=context["query_basis"],
        needed_role_heads=context["role_heads"], source_owner=_record(part.root),
        source_candidate_span=[part.start_char, part.end_char],
        supports_missing_action=False, factual_support_certified=False,
        identity_certified=False, absence_is_counterevidence=False,
        historical_relation_inferred=False, qualifiers_are_identity_proof=False,
        missing_qualifier_is_contradiction=False,
        proper_name_dictionary_lookup=False)
    anchor = anchor_context or dict(available=0, matched=False)
    # A visible name/role cannot anchor itself. The caller supplies only the
    # candidate's literal citation, never a pooled page or another occurrence.
    value["query_anchor_context"] = dict(available=anchor.get("available", 0),
        matched=anchor.get("matched", False),
        required_for_role_match=False,
        absence_is_counterevidence=False)
    try:
        descriptors, excluded = _owned_descriptors(part, context["kind"], source_types)
        value.update(owned_roles=descriptors, excluded_descriptors=excluded)
        conflicts = []
        for query in context["role_heads"]:
            required = {t["lemma"] for t in query["required_modifiers"]}
            for source in descriptors:
                match = _compare(query["head"]["lemma"], source["head"]["lemma"], context["kind"])
                if not match:
                    continue
                actual = {t["lemma"] for t in source["modifiers"]}
                # A lexical hypernym can itself specify a role modifier, as in
                # commander -> military_officer. It cannot turn minister into PM.
                lexical = {w for lemma in roles.lexicon().synset(match["query_concept"]).lemmas()
                           if lemma.name().islower() for w in lemma.name().split("_")}
                actual |= lexical-{query["head"]["lemma"]}
                needed_qualifiers = {t["lemma"] for t in query["qualifiers"] if t["lemma"] not in NEGATORS}
                source_qualifiers = {t["lemma"] for t in source["qualifiers"]+source.get("owner_qualifiers", [])}
                missing_qualifiers = needed_qualifiers-source_qualifiers
                if required-actual or query["negated"] or source["negated"] or missing_qualifiers:
                    conflicts.append(dict(query_role=query, source_role=source,
                        missing_role_modifiers=sorted(required-actual), negated=query["negated"] or source["negated"],
                        missing_query_qualifiers=sorted(missing_qualifiers),
                        missing_is_counterevidence=False))
                    continue
                return dict(value, **match, matched=True, ownership=source["ownership"],
                    source_role_span=source["span"], source_role_quote=source["quote"],
                    query_role=query, source_role=source, role_conflicts=conflicts)
        return dict(value, role_conflicts=conflicts, reason="NO_OWNED_UNNEGATED_QUERY_ROLE")
    except (LookupError, OSError):
        return dict(value, resource_unavailable=True)
