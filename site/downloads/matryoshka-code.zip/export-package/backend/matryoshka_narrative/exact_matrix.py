"""Internally produced literal whole-matrix source ascription for ordinary H/M.

This does not alter leaf extraction or accept observer certificates as native
proof. Exact public wording, dependency roles, full source/context replay and a
conservative concession grammar are independently checked at the native gate.
"""
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_current.proposition_matching import compile_proposition
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import qualifiers
from matryoshka_demo_v6.planning import sentences
from matryoshka_demo_v6.reporting_fixed_pool_role_projection_v2 import NONFACTIVE
from matryoshka_next.decisions import _prefix_blocker, _public_scope
from .source_sentences import _REPORTS

VERSION = "literal-whole-matrix-source-ascription/2"
_CLAUSAL = {"advcl", "ccomp", "xcomp", "acl", "relcl", "parataxis", "csubj", "csubjpass"}
_PREMISE = re.compile(r"\b(?:hypothetical|fictional|scenario|premise|assumption|fabricated|invented)\b", re.I)


def _normal(text):
    return " ".join(text.split()).casefold().rstrip(".").strip()


def _prefilter(query, source):
    q, s = _normal(query), " ".join(source.split()).casefold()
    return bool(q and s.startswith(q) and (len(s) == len(q) or s[len(q)] in ",."))


def _proof(token):
    return dict(start=token.idx, end=token.idx + len(token), text=token.text,
                lemma=token.lemma_.casefold(), dependency=token.dep_, pos=token.pos_, tag=token.tag_)


def _root(doc):
    roots = [t for t in doc if t.dep_ == "ROOT" and not t.is_space]
    return roots[0] if len(roots) == 1 else None


def _signature(doc, excluded=()):
    tokens = [t for t in doc if not t.is_space and not t.is_punct and t.i not in excluded]
    positions = {t.i: i for i, t in enumerate(tokens)}
    return [(t.text.casefold(), t.dep_, positions.get(t.head.i, -1)) for t in tokens]


def _asserted_past(token):
    if token is None or token.pos_ != "VERB" or token.tag_ != "VBD":
        return False
    subjects = [t for t in token.children if t.dep_ in {"nsubj", "nsubjpass"}]
    if len(subjects) != 1 or subjects[0].pos_ not in {"NOUN", "PROPN"}:
        return False
    q = qualifiers(token)
    return (not any(q.get(k) for k in ("negated", "modality", "scope", "attribution",
                                     "conditional", "question", "epistemic_absence", "unresolved"))
            and not any(t.dep_ in {"aux", "auxpass", "advmod", "neg"} for t in token.children))


@lru_cache(maxsize=256)
def _epistemic_subject(word):
    from matryoshka_demo.roles import lexicon
    try:
        senses = lexicon().synsets(word, pos="n")
    except LookupError:
        return True
    return not senses or any(s.lexname() in {"noun.communication", "noun.cognition"} for s in senses)


@lru_cache(maxsize=256)
def _epistemic_core(word, pos):
    from matryoshka_demo.roles import lexicon
    try:
        senses = lexicon().synsets(word, pos=pos)
    except LookupError:
        return True
    return not senses or senses[0].lexname() in {
        "noun.communication", "noun.cognition", "verb.communication", "verb.cognition"}


def _concession(root, tail):
    """Only a separate finite material/relation event, not an epistemic caveat."""
    if tail.pos_ != "VERB" or tail.head != root:
        return None
    children = list(tail.children)
    markers = [t for t in children if t.dep_ == "mark"]
    subjects = [t for t in children if t.dep_ == "nsubj"]
    auxiliaries = [t for t in children if t.dep_ in {"aux", "auxpass"}]
    patients = [t for t in children if t.dep_ in {"dobj", "obj", "iobj"}]
    finite = tail.tag_ in {"VBD", "VBP", "VBZ"} or any(t.tag_ in {"VBD", "VBP", "VBZ"} for t in auxiliaries)
    if (len(markers) != 1 or markers[0].lemma_.casefold() not in {"although", "though"}
            or len(subjects) != 1 or not finite
            or subjects[0].pos_ not in {"NOUN", "PROPN"}
            or subjects[0].pos_ == "NOUN" and _epistemic_subject(subjects[0].lemma_.casefold())
            or _epistemic_core(tail.lemma_.casefold(), "v")
            or any(t.pos_ == "NOUN" and _epistemic_core(t.lemma_.casefold(), "n") for t in patients)
            or any(t.dep_ in {"attr", "acomp", "oprd"} for t in children)
            or any(t.pos_ in {"VERB", "AUX"} and t != tail and t not in auxiliaries for t in tail.subtree)
            or any(t.dep_ in _CLAUSAL or t.tag_ == "MD" for t in tail.subtree if t != tail)
            or any(t.lemma_.casefold() in {"if", "unless", "whether"} for t in tail.subtree)
            or any(t.lemma_.casefold() in NONFACTIVE | _REPORTS for t in tail.subtree if t.pos_ in {"VERB", "AUX"})
            or any(t.lemma_.casefold() == root.lemma_.casefold() for t in tail.subtree)):
        return None
    return dict(relation="ATTACHED_FINITE_NONEPISTEMIC_CONCESSION", proofs=[_proof(t) for t in tail.subtree if not t.is_space],
                negation_preserved=any(t.dep_ == "neg" for t in tail.subtree), removed_from_public_quote=False)


def _public_fact(matcher, atom):
    spans = atom.get("query_spans", [])
    exact = [s for s in spans if _normal(s["text"]) == _normal(atom["text"])]
    if len(exact) != 1:
        return False
    span = exact[0]
    query = matcher.case["query"]
    if query[span["start"]:span["end"]] != span["text"]:
        return False
    if not hasattr(matcher, "_exact_matrix_public_doc"):
        matcher._exact_matrix_public_doc = matcher.engine.parse(query)
    doc = matcher._exact_matrix_public_doc
    candidates = [t for t in doc if span["start"] <= t.idx < span["end"] and
                  (t.dep_ == "ROOT" or t.dep_ == "conj" and t.head.dep_ == "ROOT"
                   and any(c.dep_ == "cc" and c.lower_ == "and" for c in t.head.children))]
    return len(candidates) == 1 and _asserted_past(candidates[0])


def _forward_epistemic_prefix(matcher, page, start, bounds):
    """Do not crop an adjacent forward-referencing report/premise envelope.

    A communication/cognition nominal announced as following/below/next owns
    the next statement even when punctuation makes that statement a new ROOT.
    This is a source-only scope hold, not a negative historical assertion.
    """
    previous = [(a, b) for a, b in bounds if b <= start]
    if not previous:
        return False
    a, b = max(previous, key=lambda pair: pair[1])
    if page["text"][b:start].strip():
        return False
    text = page["text"][a:b]
    if not re.search(r"\b(?:follow(?:s|ed|ing)?|next|below)\b", text, re.I):
        return False
    if len(text) > 2048:
        return True
    if not hasattr(matcher, "_exact_matrix_prefix_docs"):
        matcher._exact_matrix_prefix_docs = {}
    key = page["id"], page["source_sha256"], a, b
    if key not in matcher._exact_matrix_prefix_docs:
        matcher._exact_matrix_prefix_docs[key] = matcher.engine.parse(text)
    doc = matcher._exact_matrix_prefix_docs[key]
    return any(t.pos_ == "NOUN" and _epistemic_subject(t.lemma_.casefold()) for t in doc)


def supplement(matcher, atom, page, unit, control):
    """Native-only positive fallback, after ordinary full-policy source matching."""
    if (matcher.case["task"] not in {"hypothesis", "reconstruction"} or atom.get("kind") != "proposition"
            or control["direction"] not in {"UNRESOLVED", "PARTIAL"}
            or any(control.get(k) for k in ("root_content_policy_applicable", "source_account_policy_withheld", "potential_counter"))
            or not _prefilter(atom["text"], unit.get("text", unit.get("quote", "")))):
        return control
    with offline():
        a, b = unit["start"], unit["end"]
        pi = matcher.positions.get(page["id"])
        if pi is None or any(page.get(k) != matcher.corpus.pages[pi].get(k) for k in
                ("id", "text", "document_id", "date", "source_sha256", "classification", "permitted", "visibility", "corpus")):
            raise ValueError("Exact matrix source differs from the bound source index")
        citation = matcher.policy.citation(pi, a, b)
        if citation["text"] != unit.get("text", unit.get("quote")):
            raise ValueError("Exact matrix source unit does not replay")
        if b - a > 2048 or _public_scope(atom, matcher.case) or not _public_fact(matcher, atom):
            return control
        if not hasattr(matcher, "_exact_matrix_units"):
            matcher._exact_matrix_units = {}
        key = page["id"], page["source_sha256"]
        if key not in matcher._exact_matrix_units:
            matcher._exact_matrix_units[key] = {(u["start"], u["end"]) for u in sentences(page["text"])}
        bounds = matcher._exact_matrix_units[key]
        if ((a, b) not in bounds or _prefix_blocker(page, a, matcher.engine)
                or _forward_epistemic_prefix(matcher, page, a, bounds)):
            return control
        paragraph_start = page["text"].rfind("\n\n", 0, a)
        paragraph_start = 0 if paragraph_start < 0 else paragraph_start + 2
        paragraph_end = page["text"].find("\n\n", b)
        if _PREMISE.search(page["text"][paragraph_start:None if paragraph_end < 0 else paragraph_end]):
            return control
        cached_query = matcher.query_cache.get(digest(atom))
        qc, qdoc = (cached_query[0], cached_query[2]) if cached_query else (
            compile_proposition(atom["text"], engine=matcher.engine), matcher.engine.parse(atom["text"]))
        source_key = page["id"], page["source_sha256"], a, b
        cached_source = matcher.unit_cache.get(source_key)
        sdoc = cached_source[1] if cached_source else matcher.engine.parse(citation["text"])
        sc = compile_proposition(citation["text"], engine=matcher.engine)
        qr, sr = _root(qdoc), _root(sdoc)
        if (not qc["complete"] or not sc["complete"] or len(qc["propositions"]) != 1
                or len(sc["propositions"]) != 1 or not _asserted_past(qr) or not _asserted_past(sr)
                or any(t.dep_ in _CLAUSAL or t.tag_ == "MD" for t in qdoc)
                or any(t.is_quote or t.text in {"?", ";", ":", "(", ")", "[", "]"} for t in [*qdoc, *sdoc])):
            return control
        tails = [t for t in sr.children if t.dep_ == "advcl"]
        excluded, qualification = set(), None
        if tails:
            if len(tails) != 1 or (qualification := _concession(sr, tails[0])) is None:
                return control
            tail = tails[0]
            excluded = {t.i for t in tail.subtree}
            lo, hi = min(t.idx for t in tail.subtree), max(t.idx + len(t) for t in tail.subtree)
            qualification.update(start=lo, end=hi, text=citation["text"][lo:hi])
        if any(t.dep_ in _CLAUSAL for t in sdoc if t.i not in excluded) or _signature(qdoc) != _signature(sdoc, excluded):
            return control
        source_core = [t for t in sdoc if t.i not in excluded and not t.is_space and not t.is_punct]
        if not source_core or excluded and max(t.i for t in source_core) >= min(excluded):
            return control
        proof = dict(version=VERSION, kind="LITERAL_WHOLE_PUBLIC_MATRIX_SOURCE_ASCRIPTION",
            citation=deepcopy(citation), query_sha256=digest(matcher.case["query"]), atom_sha256=digest(atom),
            query_token_proofs=[_proof(t) for t in qdoc if not t.is_space and not t.is_punct],
            source_token_proofs=[_proof(t) for t in source_core], retained_source_qualification=qualification,
            source_unit_page_start=a, source_proof_offset_basis="SOURCE_UNIT_UNICODE_CHARACTERS",
            matrix_polarity="positive", matrix_tense="past", source_text_modified=False,
            global_entity_alias_created=False, canonical_identity_certified=False,
            publication_date_used_as_event_time=False, embedded_execution_certified=False,
            cross_atom_or_event_join_certified=False, world_truth_certified=False)
        row = deepcopy(control)
        row.update(version=VERSION, direction="SUPPORT", citation=citation, complete_required_frames=True,
            exact_matrix_certificate=proof, strict_exact_matrix_control=deepcopy(control),
            source_assertion_not_world_truth=True, qualified=True,
            qualified_account="The eligible source explicitly states the whole public assertion; any attached finite concession remains in the full quotation. This is source ascription, not independent truth, canonical identity or an event join.",
            support_scope="LITERAL_WHOLE_MATRIX_QUALIFIED_SOURCE_ASCRIPTION", event_bindings=[],
            source_attestation_not_persistence=True, source_ascription_date=page["date"],
            actual_inner_event_established=False, canonical_identity_certified=False,
            cross_atom_or_event_join_certified=False)
        row["checks"] = dict(eligible_source="PASS", literal_quote="PASS", exact_whole_public_fact="PASS",
            ordered_matrix_tokens_and_roles="PASS", context_and_qualifying_concession="PASS",
            event_join="NOT_CERTIFIED", world_truth="NOT_CERTIFIED", lexical_relevance_used_as_proof=False)
        return row
