"""Bounded source-owned person-set projections; nominations, never joint-action proof."""
from collections import Counter
from copy import deepcopy
from itertools import combinations
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE,source_page_allowed,descriptor
from . import adjunct_candidates as shared
from .nominal_realization import coordinate_boundary

VERSION = "source-owned-coordinate-person-candidates/1"
MAX_PROPOSALS = 64
MAX_GROUP_MEMBERS = 4
MAX_SUBSET_MEMBERS = 3


def eligible(reading):
    """A coordinated NP may fill an existing nominal actor slot; no new reading."""
    return (reading.get("outer_family")=="nominal"
        and (reading.get("function"),reading.get("role")) in {
            ("argument","actor_argument"),("coordinate_member","actor_enumeration")}
        and reading.get("grammatical_number") in {"unknown","plural"}
        and reading.get("target_kind") in {"any","person"})


def _ancestor(token,*,source_list=False):
    seen = set()
    while token.dep_ in ({"conj","appos"} if source_list else {"conj"}) and token.head.pos_=="PROPN" and token.i not in seen:
        seen.add(token.i)
        token = token.head
    return token


def _name(token,base,text):
    members = [t for t in token.subtree if t==token or t.dep_ in {"compound","flat","name"}
        and t.pos_=="PROPN" and t.head==token]
    members = sorted(members,key=lambda t:t.i)
    if [t.i for t in members]!=list(range(members[0].i,members[-1].i+1)):
        return None
    if not any(t.ent_type_=="PERSON" for t in members) or any(t.ent_type_ in {"GPE","LOC","ORG"} for t in members):
        return None
    a,b = base+members[0].idx,base+members[-1].idx+len(members[-1])
    return dict(start=a,end=b,text=text[a:b],head=shared._token(token,base),person_basis="FROZEN_PARSER_PERSON_NER_NOT_IDENTITY")


class Constructor:
    def __init__(self,parser):
        self.parser = parser
        self._source_cache = {}
        self._issued = {}
        self._pages = {}
        self.compatibility_calls = 0

    def source_spans(self,page):
        if digest(page["text"])!=page["source_sha256"]:
            raise ValueError("Exact source text hash required")
        key = digest(page)
        if key in self._source_cache:
            return deepcopy(self._source_cache[key])
        found,holds = [],Counter()
        for block in re.finditer(r"\S[\s\S]*?(?=\n\s*\n|\Z)",page["text"]):
            if MASK.search(block.group()):
                holds["MASKED_PARENT_SCOPE_UNKNOWN"] += 1
                continue
            base = block.start()
            doc = self.parser(block.group())
            if doc.text!=block.group():
                raise ValueError("Source parser changed raw text")
            for sentence in doc.sents:
                for anchor in sentence:
                    if anchor.pos_!="PROPN" or anchor.dep_ in {"conj","appos"}:
                        continue
                    group = [t for t in sentence if t.pos_=="PROPN" and _ancestor(t,source_list=True)==anchor]
                    if len(group)<2:
                        continue
                    if len(group)>MAX_GROUP_MEMBERS:
                        holds["TOO_MANY_COORDINATE_MEMBERS_NO_COMBINATORIAL_TRUNCATION"] += 1
                        continue
                    names = [_name(t,base,page["text"]) for t in group]
                    if any(n is None for n in names):
                        holds["EVERY_MEMBER_NEEDS_OWN_PROPER_PERSON_SPAN"] += 1
                        continue
                    gaps = [page["text"][a["end"]:b["start"]] for a,b in zip(names,names[1:])]
                    if (not any(re.search(r"\band\b",gap,re.I) for gap in gaps)
                            or any(re.fullmatch(r"\s*(?:,\s*)?(?:and\s*)?",gap,re.I) is None or not gap.strip() for gap in gaps)):
                        holds["NOT_AN_EXPLICIT_COMMA_AND_PERSON_LIST"] += 1
                        continue
                    governor = anchor.head
                    if governor.pos_=="ADP":
                        governor = governor.head
                    if governor.pos_ not in {"VERB","AUX"} or any(t.head==governor and t.dep_ in {"ccomp","xcomp"} and t in group for t in group):
                        holds["ONE_OWN_SOURCE_CLAUSE_GOVERNOR_REQUIRED"] += 1
                        continue
                    if not shared._closed_sentence(sentence):
                        holds["INCOMPLETE_SOURCE_SENTENCE"] += 1
                        continue
                    sa,sb = base+sentence.start_char,base+sentence.end_char
                    for size in range(2,min(len(group),MAX_SUBSET_MEMBERS)+1):
                        for indices in combinations(range(len(group)),size):
                            selected = [names[i] for i in indices]
                            chunks,member_spans,at = [],[],0
                            for i,name in enumerate(selected):
                                separator = "" if i==0 else " and " if i==len(selected)-1 else ", "
                                chunks.append(separator)
                                at += len(separator)
                                member_spans.append([at,at+len(name["text"])])
                                chunks.append(name["text"])
                                at += len(name["text"])
                            fill = "".join(chunks)
                            value = dict(version=VERSION,family="nominal",fill=fill,
                                source_page_id=page["id"],source_document_id=page["document_id"],source_date=page["date"],
                                source_page_sha256=page["source_sha256"],source_start=selected[0]["start"],source_end=selected[-1]["end"],
                                source_span=[selected[0]["start"],selected[-1]["end"]],
                                source_wording=page["text"][selected[0]["start"]:selected[-1]["end"]],source_segments=selected,
                                source_sentence_start=sa,source_sentence_end=sb,source_sentence=page["text"][sa:sb],
                                source_parent_quote=dict(span=[block.start(),block.end()],text=block.group()),
                                source_group_members=names,source_members=selected,member_fill_spans=member_spans,
                                source_governor=shared._token(governor,base),source_role=anchor.dep_,
                                source_qualifiers=[shared._token(t,base) for t in sentence if t.dep_ in shared.QUALIFIER],
                                operation_license=dict(kind="SOURCE_PERSON_COORDINATE_SUBSET_WITH_AND",selected_indices=list(indices),
                                    original_member_count=len(names),literal_member_wording_unchanged=True,
                                    realization_segments=[dict(kind="LITERAL_SOURCE_MEMBER",source_span=[n["start"],n["end"]],
                                        source_text=n["text"],fill_span=member_spans[i]) for i,n in enumerate(selected)],
                                    inserted_grammar=[dict(text=fill[b:member_spans[i+1][0]],fill_span=[b,member_spans[i+1][0]])
                                        for i,(_,b) in enumerate(member_spans[:-1])],
                                    inserted_connectors_are_grammar_not_evidence=True,omitted_members_are_not_denied=True),
                                source_owned_exact_span=False,generated_surface_is_exact_source_span=False,
                                source_joint_query_action_attested=False,source_person_identity_certified=False,
                                factual_support_certified=False,owner_event_binding="UNASSESSED")
                            found.append(value)
                            self._issued[digest(value)] = key
        self._pages[key] = deepcopy(page)
        self._source_cache[key] = deepcopy((found,dict(holds)))
        return found,dict(holds)

    def replay(self,occurrence):
        key = self._issued.get(digest(occurrence))
        if key is None:
            return False
        page = self._pages[key]
        text = page["text"]
        if digest(text)!=occurrence["source_page_sha256"]:
            return False
        for member in occurrence["source_group_members"]:
            if text[member["start"]:member["end"]]!=member["text"]:
                return False
        a,b = occurrence["source_sentence_start"],occurrence["source_sentence_end"]
        parent = occurrence["source_parent_quote"]
        return text[a:b]==occurrence["source_sentence"] and text[slice(*parent["span"])]==parent["text"] and not MASK.search(parent["text"])

    def pool(self,case,reading,pages,*,proposal_cap=MAX_PROPOSALS,defer_compatibility=True):
        shared._inputs(case,reading)
        if type(proposal_cap) is not int or not 1<=proposal_cap<=MAX_PROPOSALS or type(defer_compatibility) is not bool:
            raise ValueError("Strict proposal cap1..64 and bool required")
        if len({p["id"] for p in pages})!=len(pages):
            raise ValueError("Unique ordinary inspected pages required")
        for page in pages:
            if not source_page_allowed(page,case,SOURCE_DAY_INCLUSIVE) or digest(page["text"])!=page["source_sha256"]:
                raise ValueError("Unchanged ordinary source policy/hash failed")
        base = dict(version=VERSION,reading_id=reading["id"],declared_reading=deepcopy(reading),case_sha256=digest(case),
            inspected_page_ids=[p["id"] for p in pages],source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE),
            compatibility_deferred=defer_compatibility,proposal_cap=proposal_cap,factual_support_certified=False)
        if not eligible(reading):
            return dict(base,eligible=False,proposals=[],reason="OUTSIDE_NOMINAL_PERSON_COORDINATE_SLOT")
        per_page,holds,by_fill = [],Counter(),{}
        for page in pages:
            values,rejected = self.source_spans(page)
            holds.update(rejected)
            per_page.append(values)
            for value in values:
                by_fill.setdefault(value["fill"],[]).append(value)
        proposals,seen = [],set()
        for depth in range(max(map(len,per_page),default=0)):
            for values in per_page:
                if depth>=len(values) or values[depth]["fill"] in seen:
                    continue
                value = values[depth]
                seen.add(value["fill"])
                compatibility = (dict(state="UNASSESSED",reason="DEFERRED_TO_CALLER_COMPLETED_INSERTION_BUDGET",grammar_only=True,
                    factual_support_certified=False) if defer_compatibility else self.compatibility(case,reading,value))
                proposals.append(dict(id="coordinate_nomination_"+digest([VERSION,digest(case),reading["id"],value["fill"]])[:24],
                    fill=value["fill"],family="nominal",reading_id=reading["id"],source_occurrences=deepcopy(by_fill[value["fill"]]),
                    compatibility=compatibility,factual_support_certified=False,source_function_credit_added=False))
                if len(proposals)>=proposal_cap:
                    break
            if len(proposals)>=proposal_cap:
                break
        return dict(base,eligible=True,proposals=proposals,source_shape_holds=dict(holds),
            raw_source_occurrences=sum(map(len,per_page)),cap_reached=len(proposals)==proposal_cap,
            eager_compatibility_checks=0 if defer_compatibility else len(proposals),new_readings=False,legacy_candidates_modified=False)

    def compatibility(self,case,reading,occurrence):
        shared._inputs(case,reading)
        self.compatibility_calls += 1
        result = dict(state="HOLD",grammar_only=True,factual_support_certified=False,source_joint_query_action_attested=False,
            source_person_identity_certified=False,native_final_form_or_support_gate_executed=False)
        def hold(reason):
            return dict(result,reason=reason)
        if not eligible(reading) or not self.replay(occurrence):
            return hold("UNISSUED_CHANGED_OR_OUTSIDE_DECLARED_READING")
        page = self._pages[self._issued[digest(occurrence)]]
        if not source_page_allowed(page,case,SOURCE_DAY_INCLUSIVE):
            return hold("SOURCE_POLICY_HOLD")
        if any(w["placement"]=="inside_gap" for w in reading["wrappers"]):
            return hold("INSIDE_GAP_WRAPPER_NOT_SUPPORTED")
        marker = case["focal_marker"]
        at,end = case["query"].index(marker),case["query"].index(marker)+len(marker)
        fill = occurrence["fill"]
        boundary = coordinate_boundary(case,reading,self.parser)
        prefix = "and " if boundary["add_connector"] else ""
        realized = prefix+fill
        completed = case["query"][:at]+realized+case["query"][end:]
        left,right = 0,len(completed)
        for mask in MASK.finditer(completed):
            if mask.end()<=at:
                left = mask.end()
            elif mask.start()>=at+len(realized):
                right = mask.start()
                break
            else:
                return hold("OPAQUE_INSERTION_BOUNDARY")
        doc = self.parser(completed[left:right])
        part = doc.char_span(at-left,at-left+len(realized),alignment_mode="strict")
        if part is None:
            return hold("COMPLETED_MEMBER_TOKEN_BOUNDARIES")
        members = []
        for a,b in occurrence["member_fill_spans"]:
            member = doc.char_span(at-left+len(prefix)+a,at-left+len(prefix)+b,alignment_mode="strict")
            if member is None or member.root.pos_!="PROPN":
                return hold("COMPLETED_PROPER_PERSON_MEMBER_NOT_BOUND")
            members.append(member.root)
        root = members[0]
        if any(t.dep_!="conj" or _ancestor(t)!=_ancestor(root) for t in members[1:]):
            return hold("INSERTED_MEMBERS_NOT_ONE_COORDINATE_NP")
        delta = len(realized)-len(marker)
        anchors = []
        for span in reading["attachment_spans"]:
            a,b = span["start"],span["end"]
            if a<end and at<b:
                return hold("DECLARED_ATTACHMENT_OPAQUE")
            if a>=end:
                a,b = a+delta,b+delta
            if a<left or b>right:
                return hold("ATTACHMENT_OUTSIDE_VISIBLE_COMPONENT")
            anchor = doc.char_span(a-left,b-left,alignment_mode="strict")
            if anchor is None or anchor.text!=span["text"]:
                return hold("DECLARED_ATTACHMENT_CHANGED")
            anchors.append(anchor.root)
        head = root.head
        if reading["role"]=="actor_enumeration" and root.dep_=="conj":
            head = _ancestor(root).head
        elif root.dep_ not in {"nsubj","nsubjpass"}:
            return hold("COORDINATE_NP_NOT_DECLARED_ACTOR_SUBJECT")
        if head not in anchors or head.pos_ not in {"VERB","AUX"}:
            return hold("NOT_ATTACHED_TO_DECLARED_PUBLIC_PREDICATE")
        if head.tag_=="VBZ" or head.lower_ in {"is","was","has","does"}:
            return hold("VISIBLE_SINGULAR_PREDICATE_CONFLICT")
        if reading["finite"] is True:
            return hold("NOMINAL_COORDINATE_IS_NOT_FINITE")
        return dict(result,state="PASS_SYNTAX_ONLY",reason="SOURCE_PERSON_SUBSET_FITS_UNCHANGED_NOMINAL_ACTOR_SLOT",
            realized_fill=realized,inserted_span=[at,at+len(realized)],coordinate_boundary=boundary,
            inserted_tokens=[shared._token(t,left) for t in part],completed_query_sha256=digest(completed),
            number_license="EXPLICIT_PLURAL_OR_NUMBER_NEUTRAL_PUBLIC_PREDICATE",parse_view_span=[left,right],
            and_edit_receipt=dict(base_fill=fill,realized_fill=realized,public_prefix=prefix,grammar_not_source_evidence=True),
            operator_semantics="UNASSESSED",owner_event_binding="UNASSESSED")


def order(pool,case,reading,parser):
    shared._inputs(case,reading)
    if pool["case_sha256"]!=digest(case) or pool["declared_reading"]!=reading:
        raise ValueError("Exact public case/reading pool binding required")
    out = deepcopy(pool)
    query = " ".join(s["text"] for s in reading["attachment_spans"])
    q = shared._terms(parser,query)
    for i,proposal in enumerate(out["proposals"]):
        scores = []
        for index,occurrence in enumerate(proposal["source_occurrences"]):
            s = shared._terms(parser,occurrence["source_sentence"])
            cov,jac = len(q&s)/max(1,len(q)),len(q&s)/max(1,len(q|s))
            scores.append(dict(score=.75*cov+.25*jac,coverage=cov,jaccard=jac,occurrence_index=index,
                source_sentence=occurrence["source_sentence"],source_page_id=occurrence["source_page_id"]))
        proposal["context_order"] = dict(best_single_occurrence=max(scores,key=lambda s:s["score"]),
            original_proposal_order=i,advisory_only=True,factual_support_certified=False)
    ranked = sorted(out["proposals"],key=lambda p:(-p["context_order"]["best_single_occurrence"]["score"],p["context_order"]["original_proposal_order"]))
    out["context_order_ids"] = [p["id"] for p in ranked]
    out["syntax_accepted_context_order_ids"] = [p["id"] for p in ranked if p["compatibility"]["state"]=="PASS_SYNTAX_ONLY"]
    return out


context_order = order
