"""Counter-only comparison of assessed Red requirements against inspected pages.

The immutable Red matcher supplies typed, scoped comparisons. This layer never
uses another page as positive evidence or as a candidate's source origin. Its
receipt is separate from the old gate's positive-citation source receipt.

The default complete_pool policy retains the counter1 contract. Explicit
positive_support uses counter2: opaque/unmodeled coverage is disclosed without
vetoing an existing complete positive, but failed work and signed counters hold.
"""
from collections import Counter
from copy import deepcopy
import time

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo_v6 import reporting_fixed_pool_decisions_v65 as gate
from matryoshka_demo_v61 import scope_matching as scoped


VERSION = "narrative-inspected-pool-redaction-counters/1"
DECISION_VERSION = "narrative-positive-citation-gate-with-inspected-pool-counters/1"
POSITIVE_SUPPORT_VERSION = "narrative-inspected-pool-redaction-counters/2"
POSITIVE_SUPPORT_DECISION_VERSION = "narrative-positive-citation-gate-with-inspected-pool-counters/2"
POLICY_VERSION = "narrative-redaction-counter-policy/2"
_COVERAGE_WARNINGS = {"OPAQUE_PAGE_CONTENT_NOT_COUNTER_CLEARED", "NO_TYPED_SOURCE_FRAMES_UNMODELED"}
DESCRIPTORS = ("id", "kind", "predicate", "text")


def descriptors(requirements):
    return [{k: r.get(k) for k in DESCRIPTORS} for r in requirements]


class CounterComparison:
    """One bounded source pool; no proposal, family, or display truncation."""
    def __init__(self, case, pages, policy, *, policy_mode="complete_pool"):
        if policy_mode not in ("complete_pool", "positive_support"):
            raise ValueError("Unknown redaction counter policy mode")
        self.policy_mode = policy_mode
        self.version = VERSION if policy_mode == "complete_pool" else POSITIVE_SUPPORT_VERSION
        self.decision_version = DECISION_VERSION if policy_mode == "complete_pool" else POSITIVE_SUPPORT_DECISION_VERSION
        self.case, self.pages, self.policy = case, list(pages), policy
        self.engine = None
        self.frames = {}
        self.opaque_frames = {}
        self.receipts = []
        self.seconds = 0.0
        seen = set()
        for pi, page in self.pages:
            self.opaque_frames[page["id"]] = []
            bound = policy.bound_pages.get(page["id"])
            if (page["id"] in seen or policy.corpus.pages[pi] != page or bound is None
                    or not policy.allowed(pi) or digest(page["text"]) != page["source_sha256"]
                    or any(bound.get(k) != page.get(k) for k in
                        ("id", "text", "document_id", "date", "source_sha256", "classification",
                         "permitted", "visibility", "corpus", "handling"))):
                raise ValueError("Counter pool lost its eligible exact source binding")
            seen.add(page["id"])

    def _parse_pool(self):
        if self.engine is not None:
            return
        self.engine = scoped.Engine()
        for pi, page in self.pages:
            row = dict(page_id=page["id"], page_sha256=page["source_sha256"],
                document_id=page["document_id"], corpus=page["corpus"], issues=[],
                frames=[], opaque_frames_skipped=0)
            if MASK.search(page["text"]):
                row["issues"].append("OPAQUE_PAGE_CONTENT_NOT_COUNTER_CLEARED")
            try:
                parsed = self.engine.frames(page["text"], antecedents=True)
                row["frames_returned"] = len(parsed)
                for frame in parsed:
                    if MASK.search(frame["quote"]):
                        row["opaque_frames_skipped"] += 1
                        self.opaque_frames[page["id"]].append(deepcopy(frame))
                        continue
                    # Every compared frame must replay as a clean raw quote.
                    self.policy.citation(pi, frame["start"], frame["end"])
                    row["frames"].append(frame)
                if not parsed:
                    row["issues"].append("NO_TYPED_SOURCE_FRAMES_UNMODELED")
            except (ValueError, KeyError, TypeError) as error:
                row["issues"].append("SOURCE_FRAME_INCOMPLETE: " + str(error))
            self.frames[page["id"]] = row

    def _potential_opaque_counter(self, target, page):
        """Visible same-owner/predicate cues with unresolved text are a hold.

        This is only a conservative scheduling/risk screen, never a signed
        comparison or a claim that all other masked content is irrelevant.
        """
        owners = target.get("roles", {}).get("owner", target.get("roles", {}).get("agent", []))
        required = [{p["lemma"].casefold() for p in owner.get("proofs", [])
                     if p.get("pos") in {"NOUN", "PROPN", "ADJ", "NUM"}}
                    for owner in owners]
        if not required or any(not words for words in required):
            return []
        risks = []
        for frame in self.opaque_frames.get(page["id"], []):
            if frame.get("predicate") != target.get("predicate"):
                continue
            proof = frame.get("predicate_proof", {})
            pa, pb = proof.get("start"), proof.get("end")
            if (type(pa) is not int or type(pb) is not int or not 0 <= pa < pb <= len(page["text"])
                    or any(m.start() < pb and pa < m.end() for m in MASK.finditer(page["text"]))):
                continue
            visible = MASK.sub(lambda m: " " * len(m.group()), frame["quote"])
            terms = {t.lemma_.casefold() for t in self.engine.parse(visible) if not t.is_space}
            predicate_start = frame.get("predicate_proof", {}).get("start")
            unknown_owner = (type(predicate_start) is int and any(
                frame["start"] + m.start() < predicate_start for m in MASK.finditer(frame["quote"])))
            if all(words <= terms for words in required) or unknown_owner:
                risks.append(dict(page_id=page["id"], page_sha256=page["source_sha256"],
                    start=frame["start"], end=frame["end"], text=frame["quote"],
                    predicate=target["predicate"], state="POTENTIAL_SAME_SCOPE_OPAQUE_EVIDENCE",
                    owner_scope="UNRESOLVED_MASK_BEFORE_PREDICATE" if unknown_owner else "VISIBLE_OWNER_DISCRIMINATORS",
                    signed_counterevidence=False, positive_evidence=False))
        return risks

    def _positive_support_issues(self, candidate, original):
        """Validate an existing complete positive; never synthesize one."""
        issues = []
        required = original.get("requirements", [])
        if (original.get("status") != gate.parent.BACKED or original.get("coverage") != "Established"
                or original.get("support_present") is not True or not required):
            issues.append("ORIGINAL_POSITIVE_NOT_FULLY_ESTABLISHED")
        checks = original.get("checklist", [])
        if (not {"provenance", "binding", "facts", "conflicts", "grammar"} <= {c["id"] for c in checks}
                or any(c["state"] != "pass" for c in checks)):
            issues.append("ORIGINAL_POSITIVE_CHECKS_NOT_ALL_PASS")
        if original.get("source_failures") != []:
            issues.append("ORIGINAL_POSITIVE_SOURCE_FAILURE")
        if original.get("counterevidence") is not False:
            issues.append("ORIGINAL_POSITIVE_HAS_COUNTEREVIDENCE")
        scope = "FOCAL_PROPERTY_ONLY" if required and all(r.get("kind") == "PROPERTY" for r in required) else "FOCAL_CONTRIBUTION_ONLY"
        if (original.get("task") != "redaction" or original.get("scope") != scope
                or original.get("reading_id") != candidate.get("reading_id")):
            issues.append("ORIGINAL_POSITIVE_SCOPE_OR_READING_FAILURE")
        pages = {p["id"]: pi for pi, p in self.pages}
        refs = list(candidate.get("sources", []))
        if (not refs or original.get("source_pages_checked") != sorted({r["canonical_page_id"] for r in refs})
                or original.get("id") != candidate.get("id") or original.get("text") != candidate.get("fill")):
            issues.append("ORIGINAL_POSITIVE_SOURCE_OR_CANDIDATE_BINDING_FAILURE")
        for unit in required:
            witnesses = [w for w in unit.get("evidence", []) if w.get("direction") == "Support"]
            if (unit.get("coverage") != "Established" or unit.get("counterevidence") is not False
                    or not witnesses or not unit.get("checks")
                    or not set(gate.parent.FIELDS) <= {c["id"] for c in unit["checks"]}
                    or any(c["state"] != "pass" for c in unit["checks"])):
                issues.append("ORIGINAL_REQUIRED_UNIT_NOT_ESTABLISHED")
            for witness in witnesses:
                states = witness.get("checks", [])
                if (not set(gate.parent.FIELDS) <= {c["id"] for c in states}
                        or any(c["state"] != "pass" for c in states)
                        or witness.get("source_identity_only") or witness.get("focal_support_certified") is False
                        or not witness.get("citations")):
                    issues.append("ORIGINAL_SUPPORT_WITNESS_INCOMPLETE")
                refs.extend(witness.get("citations", []))
        try:
            for ref in refs:
                if not {"canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256", "corpus"} <= ref.keys():
                    raise ValueError("Positive quotation lacks exact source metadata")
                if ref["canonical_page_id"] not in original.get("source_pages_checked", []):
                    raise ValueError("Positive witness borrowed another source origin")
                clean = self.policy.citation(pages[ref["canonical_page_id"]], ref["start"], ref["end"])
                if any(clean.get(k) != v for k, v in ref.items()):
                    raise ValueError("Positive quotation differs from its raw source")
        except (ValueError, KeyError, TypeError) as error:
            issues.append("ORIGINAL_POSITIVE_SOURCE_REPLAY_FAILURE: " + str(error))
        return sorted(set(issues))

    def _policy_fields(self):
        return dict(policy_mode=self.policy_mode, counter_policy_version=POLICY_VERSION,
            decision_version=self.decision_version,
            recommendation_scope="SOURCE_CITATION_POSITIVE_SUPPORT_WITH_OBSERVED_TYPED_COUNTER_CHECK",
            bounded_recommendation=True, probability_estimate=False,
            corpus_counter_cleared=False, world_truth_certified=False)

    def apply(self, candidate, reading, original):
        started = time.perf_counter()
        self._parse_pool()
        required = original.get("requirements", [])
        frozen = descriptors(required)
        receipt = dict(version=self.version, candidate_id=candidate["id"],
            positive_citation_decision_sha256=digest(original),
            positive_citation_source_pages_checked=deepcopy(original.get("source_pages_checked", [])),
            declared_inspected_page_ids=[p["id"] for _, p in self.pages],
            required_descriptors=frozen, required_count=len(required), requirements=[], issues=[],
            compared_frame_pairs=0, added_counter_witnesses=0,
            positive_evidence_added=False, candidate_origins_expanded=False,
            proposal_or_display_cap_applied=False, semantic_exhaustiveness_certified=False,
            comparison_model=gate.VERSION + "/_red_match; " + scoped.VERSION)
        self.engine.disposition_reading = (reading.get("form") == "modifier"
            and reading.get("role") == "nominal_property" and reading.get("target_kind") == "property")
        try:
            targets, reason = gate._property_targets(self.case, candidate["fill"], reading, self.engine, scoped)
        except (ValueError, KeyError, TypeError) as error:
            targets, reason = [], str(error)
        compiled = [dict(id="f" + str(i), kind=t["kind"], predicate=t["predicate"], text=t["quote"])
            for i, t in enumerate(targets, 1)]
        bound = bool(required) and frozen == compiled
        if not bound:
            receipt["issues"].append("REQUIRED_TARGETS_UNMODELED_OR_DESCRIPTOR_MISMATCH: " + str(reason))
        decision = deepcopy(original)
        for i, requirement in enumerate(decision.get("requirements", [])):
            unit = dict(descriptor=frozen[i], disposition="UNMODELED", pages=[],
                compared_frame_pairs=0, counter_witnesses=[], issues=[])
            if bound:
                for pi, page in self.pages:
                    parsed = self.frames[page["id"]]
                    work = dict(page_id=page["id"], page_sha256=page["source_sha256"],
                        source_frames_available=len(parsed["frames"]), compared_frame_pairs=0,
                        match_directions={}, issues=list(parsed["issues"]))
                    if self.policy_mode == "positive_support":
                        risks = self._potential_opaque_counter(targets[i], page)
                        if risks:
                            work["issues"].append("POTENTIAL_SAME_SCOPE_OPAQUE_EVIDENCE")
                            work["potential_opaque_evidence"] = risks
                    directions = Counter()
                    for source in parsed["frames"]:
                        work["compared_frame_pairs"] += 1
                        try:
                            match = gate._red_match(targets[i], source, page, self.engine, scoped)
                            direction = match["direction"] if match else "NO_TYPED_MATCH"
                            directions[direction] += 1
                            if direction != "Counterevidence":
                                continue
                            # An opposed polarity cannot excuse another missing scope field.
                            if not all(c["state"] == "pass" or c["id"] == "polarity"
                                    and c["state"] == "conflict" for c in match["checks"]):
                                work["issues"].append("COUNTER_SCOPE_INCOMPLETE_NOT_SIGNED")
                                continue
                            witness = deepcopy(match)
                            citations = []
                            for ref in witness["citations"]:
                                clean = self.policy.citation(pi, ref["start"], ref["end"])
                                if any(clean.get(k) != v for k, v in ref.items()):
                                    raise ValueError("Counter quotation differs from its raw source")
                                citations.append(clean)
                            if not citations:
                                raise ValueError("Counter lacks a literal quotation")
                            witness["citations"] = citations
                            unit["counter_witnesses"].append(witness)
                            existing = {digest(e) for e in requirement.get("evidence", [])}
                            if digest(witness) not in existing:
                                requirement.setdefault("evidence", []).append(witness)
                                receipt["added_counter_witnesses"] += 1
                        except (ValueError, KeyError, TypeError) as error:
                            work["issues"].append("COMPARISON_INCOMPLETE: " + str(error))
                    work["match_directions"] = dict(directions)
                    work["disposition"] = "INCOMPLETE_OR_UNMODELED" if work["issues"] else "COMPLETE_TYPED_FRAME_COMPARISON"
                    unit["pages"].append(work)
                    unit["compared_frame_pairs"] += work["compared_frame_pairs"]
                unit["disposition"] = ("COMPLETE_TYPED_FRAME_COMPARISON" if self.pages
                    and all(not p["issues"] for p in unit["pages"]) else "INCOMPLETE_OR_UNMODELED")
            else:
                unit["issues"].append("EXISTING_REQUIREMENT_NOT_RECOMPILED_EXACTLY")
            evidence = requirement.get("evidence", [])
            support = any(e["direction"] == "Support" for e in evidence)
            counter = any(e["direction"] == "Counterevidence" for e in evidence)
            requirement["counterevidence"] = counter
            requirement["direction"] = ("Support + Counterevidence" if support and counter else
                "Counterevidence" if counter else requirement.get("direction", "Unresolved"))
            receipt["requirements"].append(unit)
            receipt["compared_frame_pairs"] += unit["compared_frame_pairs"]
        complete = bound and bool(self.pages) and all(
            u["disposition"] == "COMPLETE_TYPED_FRAME_COMPARISON" for u in receipt["requirements"])
        receipt["disposition"] = "COMPLETE_TYPED_FRAME_COMPARISON" if complete else "INCOMPLETE_OR_UNMODELED"
        receipt["full_declared_pool_compared_under_typed_model"] = complete
        decision["counterevidence"] = original.get("counterevidence", False) or any(
            r["counterevidence"] for r in decision.get("requirements", []))
        if required:
            decision["mixed_evidence"] = any(r["counterevidence"] and any(
                e["direction"] == "Support" for e in r.get("evidence", [])) for r in decision["requirements"])
            decision["decisive_counter"] = any(r["counterevidence"] and not any(
                e["direction"] == "Support" for e in r.get("evidence", [])) for r in decision["requirements"])
        counter_ready = complete
        if self.policy_mode == "positive_support":
            observed_issues = set(receipt["issues"])
            for unit in receipt["requirements"]:
                observed_issues.update(unit["issues"])
                for page in unit["pages"]:
                    observed_issues.update(page["issues"])
            blocking = set(self._positive_support_issues(candidate, original))
            blocking.update(observed_issues - _COVERAGE_WARNINGS)
            if not self.pages:
                blocking.add("EMPTY_DECLARED_COUNTER_POOL")
            if decision["counterevidence"]:
                blocking.add("OBSERVED_SIGNED_SAME_SCOPED_COUNTEREVIDENCE")
            counter_ready = not blocking
            receipt.update(self._policy_fields(), coverage_warning=not complete,
                coverage_warnings=sorted(observed_issues & _COVERAGE_WARNINGS),
                policy_blocking_issues=sorted(blocking), positive_support_preserved=counter_ready,
                warning="Incomplete or opaque content is not counter-cleared. No probability, hidden-content or complete-corpus claim is made."
                    if not complete else "Typed comparison completeness is model-relative, not complete-corpus clearance.")
        # Preserve positive coverage, grammar, provenance and all old failures.
        for check in decision.get("checklist", []):
            if check["id"] == "conflicts":
                if self.policy_mode == "positive_support":
                    if decision["counterevidence"]:
                        check.update(state="conflict", detail="Exact same-scoped opposing quotations are retained.")
                    elif original.get("source_failures") or check["state"] != "pass":
                        pass  # An existing positive-source or conflict failure is never cleared.
                    else:
                        check.update(state="pass" if counter_ready else "missing",
                            detail="No observed signed opposition under the bounded typed comparison model; opaque/unmodeled content and the corpus are not counter-cleared."
                                if counter_ready else "Counter comparison or positive-source validation failed; no bounded positive-support recommendation is licensed.")
                    continue
                check.update(state="conflict" if decision["counterevidence"] else "pass" if complete else "missing",
                    detail="Exact same-scoped opposing quotations are retained." if decision["counterevidence"] else
                    "Every typed source frame in the declared inspected pool was compared; no same-scoped opposition was found under this model. This is not semantic exhaustiveness." if complete else
                    "Counter comparison is incomplete or unmodeled; the inspected pool is not counter-cleared.")
        if original["status"] != gate.parent.INCOMPATIBLE and (decision["counterevidence"] or not counter_ready):
            any_grounding = any(r["coverage"] in {"Established", "Partial"} for r in required)
            established = any(r["coverage"] == "Established" for r in required)
            status = (gate.parent.INCOMPATIBLE if decision["counterevidence"] and not established else
                gate.parent.PARTIAL if any_grounding else gate.parent.CONTEXT)
            decision.update(status=status, label=gate.parent.LABELS[status])
            decision["what_would_suffice"] = [c["detail"] for c in decision["checklist"] if c["state"] != "pass"]
        if self.policy_mode == "positive_support":
            decision["counter_policy"] = {k: deepcopy(receipt[k]) for k in (
                "policy_mode", "counter_policy_version", "decision_version", "recommendation_scope",
                "bounded_recommendation", "probability_estimate", "corpus_counter_cleared", "world_truth_certified",
                "coverage_warning", "coverage_warnings", "policy_blocking_issues", "positive_support_preserved", "warning")}
        assert descriptors(decision.get("requirements", [])) == frozen
        receipt["elapsed_seconds"] = time.perf_counter() - started
        self.seconds += receipt["elapsed_seconds"]
        self.receipts.append(receipt)
        return decision, receipt

    def summary(self):
        result = dict(version=self.version, declared_inspected_page_ids=[p["id"] for _, p in self.pages],
            source_pages_parsed=len(self.frames), source_frames_available=sum(len(r["frames"]) for r in self.frames.values()),
            source_frame_inventory=[{k: v for k, v in row.items() if k != "frames"} | dict(clean_frames=len(row["frames"]))
                for row in self.frames.values()],
            assessed_candidate_comparisons=len(self.receipts),
            required_units_declared=sum(r["required_count"] for r in self.receipts),
            required_units_compared=sum(u["disposition"] != "UNMODELED" for r in self.receipts for u in r["requirements"]),
            compared_frame_pairs=sum(r["compared_frame_pairs"] for r in self.receipts),
            added_counter_witnesses=sum(r["added_counter_witnesses"] for r in self.receipts),
            complete_candidate_comparisons=sum(r["full_declared_pool_compared_under_typed_model"] for r in self.receipts),
            incomplete_or_unmodeled_candidate_comparisons=sum(not r["full_declared_pool_compared_under_typed_model"] for r in self.receipts),
            elapsed_seconds=self.seconds, disposition="EXECUTED" if self.receipts else "NOT_RUN_NO_FOCAL_ASSESSMENTS",
            proposal_and_display_caps_do_not_limit_counter_work=True,
            semantic_exhaustiveness_certified=False, api_calls=0)
        if self.policy_mode == "positive_support":
            result.update(self._policy_fields(),
                coverage_warning=any(r["coverage_warning"] for r in self.receipts),
                coverage_warnings=sorted({w for r in self.receipts for w in r["coverage_warnings"]}),
                blocked_candidate_comparisons=sum(bool(r["policy_blocking_issues"]) for r in self.receipts),
                positive_support_preserved=sum(r["positive_support_preserved"] for r in self.receipts))
        return result
