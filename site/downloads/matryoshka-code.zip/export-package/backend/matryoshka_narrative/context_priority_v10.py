"""Frozen contextual ordering only. No entity/answer dictionary or factual judgment."""
from copy import deepcopy
from datetime import date
import math
import re

from matryoshka_demo.io import digest
from matryoshka_demo.contracts import MASK
from matryoshka_demo.corpus import words, ENGLISH_STOP_WORDS
from matryoshka_narrative import terminal_scores as terminal, candidate_identity, controller_role
from matryoshka_narrative.contextual_scores import bound_occurrences

VERSION='source-human-recency-context-rank/10'
SCORE_VERSION='terminal-context-priority/10'
SCORE_UNITS='TIERED_CONTEXT_PRIORITY_ORDINAL_NOT_PROBABILITY'
_CUE_STOP=frozenset('a an the and or but at by for from in into of on onto to with without as is are was were be been being have has had do does did he she it they we you i his her its their our your that this these those which who whom whose said say reportedly would could should will may might can must not no only than then there if so such all any some more most very about under over up down out receive'.split())


def require(ok,message):
    if not ok:raise ValueError(message)


def terms(text):
    return set(words(MASK.sub(' ',text)))-set(ENGLISH_STOP_WORDS)


def exact_span(query,value):
    if not isinstance(value,dict):return False
    a,b=value.get('start'),value.get('end')
    return type(a)is int and type(b)is int and 0<=a<b<=len(query) and query[a:b]==value.get('text')


def focal_context(case,plan,reading):
    query,marker=case['query'],case['focal_marker']
    require(query.count(marker)==1 and plan.get('query_sha256')==digest(query),'EXACT_PUBLIC_QUERY_REQUIRED')
    gap=[query.index(marker),query.index(marker)+len(marker)]
    hint=None
    for attachment in reading.get('attachment_spans',[]):
        require(exact_span(query,attachment),'READING_ATTACHMENT_SPAN_CHANGED')
        if attachment['start']<gap[1] or query[gap[1]:attachment['start']].strip(): continue
        match=re.match(r'\s*[,;]\s*(he|she)\b',query[attachment['end']:],re.I)
        if match:
            start=attachment['end']+match.start(1)
            hint=dict(pronoun_span=dict(start=start,end=start+len(match.group(1)),text=match.group(1)),
                attachment_span=deepcopy(attachment),identity_or_coreference_certified=False)
            break
    spans=[]
    atoms=[]
    for atom in plan.get('atoms',[]):
        atom_spans=atom.get('query_spans',[])
        require(isinstance(atom_spans,list) and all(exact_span(query,s) for s in atom_spans),'PLAN_ATOM_SPAN_CHANGED')
        keep=[]
        for s in atom_spans:
            focal=s['start']<=gap[0]<gap[1]<=s['end']
            adjacent=False
            if hint:
                pronoun=hint['pronoun_span']
                adjacent=(s['start']<=pronoun['start']<pronoun['end']<=s['end']
                    and not re.search(r'[.!?\n]',query[gap[1]:pronoun['start']]))
            if focal or adjacent: keep.append(deepcopy(s))
        if keep:
            spans.extend(keep)
            atoms.append(dict(id=atom['id'],query_spans=keep,polarity=atom.get('polarity'),modality=atom.get('modality')))
    require(any(s['start']<=gap[0]<gap[1]<=s['end'] for s in spans),'MISSING_BOUND_FOCAL_ATOM')
    unique={digest(s):s for s in spans}
    text=' '.join(s['text'].replace(marker,' ') for s in unique.values())
    return dict(query_sha256=digest(query),reading_id=reading['id'],person_hint=hint,
        atoms=atoms,query_spans=list(unique.values()),literal_terms=sorted(t for t in re.findall(r'[a-z0-9]+',text.casefold()) if len(t)>=3 and t not in _CUE_STOP),
        semantic_coreference_or_identity_certified=False)


def public_context(case,plan,reading):
    if not (reading.get('form')=='nominal' and reading.get('outer_family')=='nominal'
            and reading.get('role')=='possessor' and reading.get('function')=='possessor'):
        return dict(active=False,reason='NO_DECLARED_NOMINAL_POSSESSOR')
    value=focal_context(case,plan,reading)
    literal=terms(' '.join(s['text'] for s in value['query_spans']))
    return dict(active=value['person_hint']is not None,reason='BOUND_ADJACENT_PRONOUN' if value['person_hint'] else 'NO_ADJACENT_PERSON_HINT',
        public_span_binding=value,terms=sorted(literal),coreference_or_identity_certified=False)


def age_decay(origin,source,half_life):
    require(half_life in {None,90},'FROZEN_HALF_LIFE_ONLY')
    days=(date.fromisoformat(origin)-date.fromisoformat(source)).days
    require(days>=0,'FUTURE_SOURCE_DATE')
    return days,1.0 if half_life is None else 2.0**(-days/90.0)


def features(candidate,case,context,pages,citation,half_life):
    require(context['active'],'ACTIVE_PUBLIC_CUE_REQUIRED')
    observations=[]
    for ref in candidate.get('sources',[]):
        occurrences=[o for o in bound_occurrences(candidate,ref) if o.get('source_span')==candidate.get('source_span')
            and o.get('source_wording')==candidate.get('source_wording')]
        if not occurrences:continue
        pid=ref['canonical_page_id']
        require(pid in pages,'OWN_SOURCE_NOT_IN_ACTUAL_INSPECTED_POOL')
        page=pages[pid]
        require(page['source_sha256']==digest(page['text']) and all(ref.get(k)==page.get(k) for k in ('document_id','date')),
            'OWN_RAW_SOURCE_HASH_OR_METADATA_CHANGED')
        replay=citation(pid,ref['start'],ref['end'])
        require(all(replay.get(k)==ref.get(k) for k in ('canonical_page_id','document_id','date','start','end','text','page_sha256')),
            'ACTUAL_SOURCE_POLICY_CITATION_DIFFERS')
        for own in occurrences:
            lo,hi=own['source_span']
            require(page['text'][lo:hi]==own['source_wording'],'OWN_PHRASE_CHANGED')
            head=own.get('source_head',{})
            hs=head.get('span',[])
            head_bound=(len(hs)==2 and all(type(x)is int for x in hs) and lo<=hs[0]<hs[1]<=hi
                and page['text'][hs[0]:hs[1]]==head.get('text'))
            kinds=set()
            witnesses=[]
            for w in own.get('features',{}).get('source_type_witnesses',[]):
                a,b=w.get('start'),w.get('end')
                if (head_bound and type(a)is int and type(b)is int and lo<=a<=hs[0]<hs[1]<=b<=hi
                        and w.get('canonical_page_id')==pid and w.get('page_sha256')==page['source_sha256']
                        and page['text'][a:b]==w.get('label')):
                    kinds.add(w.get('source_entity_type'))
                    if w.get('node_id')==candidate.get('node_id'):witnesses.append(deepcopy(w))
            conflicts=kinds-{'Person','Other',None}
            ner=own.get('features',{}).get('source_ner','')
            person=bool(head_bound and head.get('pos')=='PROPN' and not conflicts
                and (any(w.get('source_entity_type')=='Person' for w in witnesses) or ner=='PERSON'))
            wanted=set(context['terms'])
            matched=wanted&terms(ref['text'])
            coverage=len(matched)/len(wanted) if wanted else 0.0
            age,decay=age_decay(case['date'],ref['date'],half_life)
            merit=(1.0+coverage)*decay
            observations.append(dict(citation=deepcopy(ref),source_phrase_span=[lo,hi],source_wording=own['source_wording'],
                source_head=deepcopy(head),own_head_bound=head_bound,own_head_ner=ner,person_witnesses=witnesses,
                conflicting_own_head_types=sorted(str(k) for k in conflicts),human_context_category=int(person),
                literal_focal_coverage=coverage,matched_focal_terms=sorted(matched),source_age_days=age,
                half_life_days=half_life,decay=decay,context_merit=merit,coreference_or_factual_support_certified=False))
    require(observations,'NO_OWN_PRIMARY_CITATION_FOR_CONTEXT_FEATURES')
    winner=max(observations,key=lambda o:(o['human_context_category'],o['context_merit']))
    return dict(winner=winner,observations=observations,each_citation_scored_separately=True,
        human_and_date_and_fit_from_same_quote=True,no_source_or_truth_credit=True)


def context_key(candidate,card,feature):
    own=feature['winner']
    return (-own['human_context_category'],-own['context_merit'],-card['score'],
        candidate.get('source_rank_position',10**9),candidate['id'])


def reorder_context_only(ordered,cards,features_by_id):
    positions=[i for i,c in enumerate(ordered) if c['local_decision']['status']=='exploratory_contextual'
        and cards[c['id']]['evidence_tier']==0]
    replacement=sorted((ordered[i] for i in positions),key=lambda c:context_key(c,cards[c['id']],features_by_id[c['id']]))
    result=list(ordered)
    for i,c in zip(positions,replacement):result[i]=c
    return result


def dedup(ordered):
    seen,families,output=set(),set(),[]
    for c in ordered:
        decision=c['local_decision']
        surface=(' '.join(c['fill'].casefold().split()),decision.get('scope'))
        family=(c.get('alternative_family',c['id']),decision.get('status'),decision.get('scope'),
            tuple((r.get('id'),str(r.get('coverage')),r.get('direction')) for r in decision.get('requirements',[])),bool(decision.get('counterevidence')))
        if surface in seen or family in families:continue
        seen.add(surface);families.add(family);output.append(c)
    return output


def candidate_projection(candidate):
    value=deepcopy(candidate)
    for key in ('rank','terminal_scorecard'):value.pop(key,None)
    if isinstance(value.get('ranking'),dict):
        for key in ('terminal_scoring_version','canonical_order'):value['ranking'].pop(key,None)
        if not value['ranking']:value.pop('ranking')
    return value


def _number(value):
    require(type(value)in(int,float)and math.isfinite(value),'FINITE_PRIORITY_NUMBER_REQUIRED')
    return float(value)


def replay_scorecard(card):
    """Strict arithmetic reference; source/candidate hashes need separate binding replay."""
    require(set(card)=={'version','producer','id','reading_id','fill','native_status','evidence_tier','mode',
        'raw_features','components','score','score_units','calibrated_probability','bindings','source_features',
        'native_v7_auxiliary','facts_classes_gates_unchanged','source_support_or_B_credit_added'},'V10_CLOSED_CARD_REQUIRED')
    require(card['version']==SCORE_VERSION and card['producer']==VERSION and card['score_units']==SCORE_UNITS
        and card['calibrated_probability']is False and card['facts_classes_gates_unchanged']is True
        and card['source_support_or_B_credit_added']is False,'V10_SCORE_CONTRACT')
    tier=card['evidence_tier'];legacy=card['native_v7_auxiliary']
    require(set(card['bindings'])=={'case_sha256','origin_date','query_sha256','provided_plan_sha256','readings_sha256',
        'reading_sha256','raw_candidate_sha256','source_binding','source_view_policy','public_context'},'V10_CLOSED_BINDINGS')
    require(type(tier)is int and tier in {0,1,2} and legacy['evidence_tier']==tier
        and legacy.get('version')in{'terminal-evidence-fit/7','native-own-complement-context-fit/1','native-source-relative-context-fit/1'}
        and legacy['id']==card['id'] and legacy['fill']==card['fill'] and legacy['native_status']==card['native_status'],
        'V10_UNCHANGED_LEGACY_TIER_BINDING')
    raw=card['raw_features']
    require(set(raw)=={'human_context_category','literal_focal_coverage','source_age_days','half_life_days',
        'decay','context_merit','legacy_score'}and raw['half_life_days']==90,'V10_CLOSED_FEATURES')
    legacy_score=_number(raw['legacy_score'])
    require(legacy_score==_number(legacy['score']) and 0<=legacy_score<300,'V10_LEGACY_POINTS_CHANGED')
    expected=dict(evidence_tier=tier/3,context_human=0.0,context_merit=0.0,legacy_residual=0.0)
    if card['mode']=='source_human_recency':
        require(tier==0 and card['native_status']=='exploratory_contextual' and card['bindings']['public_context']['active']is True,
            'V10_CONTEXTUAL_ONLY')
        human=raw['human_context_category'];coverage=_number(raw['literal_focal_coverage']);age=raw['source_age_days']
        require(type(human)is int and human in {0,1} and 0<=coverage<=1 and type(age)is int and age>=0,'V10_FEATURE_RANGE')
        decay=2.0**(-age/90.0);merit=(1.0+coverage)*decay
        require(abs(_number(raw['decay'])-decay)<=1e-12 and abs(_number(raw['context_merit'])-merit)<=1e-12,'V10_DECAY_OR_MERIT')
        winner=card['source_features']['winner']
        require((date.fromisoformat(card['bindings']['origin_date'])-date.fromisoformat(winner['citation']['date'])).days==age,
            'V10_ACTUAL_SOURCE_DATE_BINDING')
        require(winner['human_context_category']==human and winner['literal_focal_coverage']==coverage
            and winner['source_age_days']==age and winner['half_life_days']==90 and winner['decay']==raw['decay']
            and winner['context_merit']==raw['context_merit'] and winner in card['source_features']['observations']
            and card['source_features']['human_and_date_and_fit_from_same_quote']is True,'V10_SAME_QUOTE_FEATURE_BINDING')
        expected.update(context_human=.99*human/6,context_merit=.99*merit/18)
    else:
        require(card['mode']=='legacy_v7_passthrough' and card['source_features']is None
            and all(raw[k]is None for k in ('human_context_category','literal_focal_coverage','source_age_days','decay','context_merit')),
            'V10_EXACT_INACTIVE_PASSTHROUGH')
        expected['legacy_residual']=legacy_score/300-tier/3
    require(set(card['components'])==set(expected) and all(abs(_number(card['components'][k])-v)<=1e-12 for k,v in expected.items()),
        'V10_COMPONENT_MATH')
    score=sum(expected.values())
    require(abs(_number(card['score'])-score)<=1e-12 and 0<=score<1,'V10_ORDINAL_MATH')
    return score


def make_card(candidate,legacy,feature,*,case,plan,context,source_binding,source_view_policy):
    active=feature is not None
    winner=feature['winner']if active else None
    raw=dict(human_context_category=winner['human_context_category']if active else None,
        literal_focal_coverage=winner['literal_focal_coverage']if active else None,
        source_age_days=winner['source_age_days']if active else None,half_life_days=90,
        decay=winner['decay']if active else None,context_merit=winner['context_merit']if active else None,
        legacy_score=legacy['score'])
    tier=legacy['evidence_tier']
    components=dict(evidence_tier=tier/3,context_human=.99*raw['human_context_category']/6 if active else 0.0,
        context_merit=.99*raw['context_merit']/18 if active else 0.0,
        legacy_residual=0.0 if active else legacy['score']/300-tier/3)
    card=dict(version=SCORE_VERSION,producer=VERSION,id=candidate['id'],reading_id=candidate['reading_id'],fill=candidate['fill'],
        native_status=candidate['local_decision']['status'],evidence_tier=tier,
        mode='source_human_recency'if active else 'legacy_v7_passthrough',raw_features=raw,components=components,
        score=sum(components.values()),score_units=SCORE_UNITS,calibrated_probability=False,
        bindings=dict(case_sha256=digest(case),origin_date=case['date'],query_sha256=digest(case['query']),provided_plan_sha256=digest(plan),
            readings_sha256=digest(plan['readings_packet']),reading_sha256=digest(candidate['declared_reading']),
            raw_candidate_sha256=digest(candidate_projection(candidate)),source_binding=deepcopy(source_binding),
            source_view_policy=deepcopy(source_view_policy),public_context=deepcopy(context)),
        source_features=deepcopy(feature),native_v7_auxiliary=deepcopy(legacy),facts_classes_gates_unchanged=True,
        source_support_or_B_credit_added=False)
    replay_scorecard(card)
    return card
