"""Unintegrated fixed-pool context ordering; never evidence or native inference.

Only already assessed saved candidates may enter. Public focal text and a SINGLE
own literal source sentence provide uniform cue-word overlap. No expected answer,
private label, case-specific dictionary, alias, new proposal or named bonus is
accepted. Existing gates, support tiers and original fallback keys remain visible.
"""
from dataclasses import dataclass
from weakref import WeakSet

from matryoshka_demo.contracts import MASK
from matryoshka_demo.corpus import words, ENGLISH_STOP_WORDS
from matryoshka_demo.io import digest


VERSION = "fixed-pool-focal-context-relevance/2"
TIERS = {"evidence_backed_suggestion": 0, "partial_grounding": 1, "exploratory_contextual": 2}
FORMULA = "MASK-first unique cue terms; descending shared count, then shared/source-unique-term count; no fitted weights"


def _terms(text):
    # Explicit even when the shared tokenizer also strips masks. Opaque marker
    # payloads must never enter overlap counts OR source-density denominators.
    return set(words(MASK.sub(" ", text))) - set(ENGLISH_STOP_WORDS)


def _freeze(value):
    return tuple(_freeze(v) for v in value) if isinstance(value, (tuple, list)) else value


def _sentences(text, parse):
    # Lowercasing is only a boundary control for ALL-CAPS source text. The
    # quotation/output remains exact raw text; no source word is rewritten.
    shadow = MASK.sub(lambda m: " "*(m.end()-m.start()), text)
    view = shadow.lower() if shadow.isupper() and len(shadow.lower()) == len(shadow) else shadow
    doc = parse(view)
    if doc.text != view:
        raise ValueError("Sentence parser changed literal text")
    return [(s.start_char, s.end_char) for s in doc.sents]


def focal_sentence(query, marker, parse):
    if not isinstance(query, str) or not marker or query.count(marker) != 1:
        raise ValueError("One exact public focal marker required")
    a = query.index(marker)
    b = a+len(marker)
    shadow = MASK.sub(lambda m: " "*(m.end()-m.start()), query)
    spans = [(lo, hi) for lo, hi in _sentences(shadow, parse) if lo <= a and b <= hi]
    if len(spans) != 1:
        raise ValueError("Focal sentence boundary is unestablished; no whole-query fallback")
    lo, hi = spans[0]
    return dict(start=lo, end=hi, text=query[lo:hi])


def source_sentence(candidate, parse):
    key = candidate["context_rank_key"]
    if len(key) != 20:
        raise ValueError("Only the inspected ctor22 20-field saved context key is supported")
    a, b = candidate["source_span"]
    page_id = key[16]
    found = []
    for occurrence in candidate["source_occurrences"]:
        quote = occurrence["citation"]
        if (occurrence["source_span"] == [a, b] and occurrence["source_wording"] == candidate["source_wording"]
                and quote["canonical_page_id"] == page_id):
            found.append(quote)
    unique = {digest(q): q for q in found}
    if len(unique) != 1:
        raise ValueError("Saved primary source occurrence is missing or ambiguous")
    quote = next(iter(unique.values()))
    lo, hi, raw = quote["start"], quote["end"], quote["text"]
    if (any(type(n) is not int for n in (a, b, lo, hi)) or not 0 <= lo <= a < b <= hi
            or len(raw) != hi-lo or raw[a-lo:b-lo] != candidate["source_wording"]
            or not quote.get("page_sha256")):
        raise ValueError("Primary source span/quotation lost its exact literal binding")
    spans = [(x, y) for x, y in _sentences(raw, parse) if x <= a-lo and b-lo <= y]
    if len(spans) == 1:
        start, end = spans[0]
        scope = "PARSER_SENTENCE_CONTAINING_OWN_CONSTITUENT"
    else:
        start, end, scope = 0, len(raw), "FULL_SAVED_QUOTATION_BOUNDARY_UNRESOLVED"
    return dict(canonical_page_id=quote["canonical_page_id"], document_id=quote["document_id"],
                date=quote["date"], page_sha256=quote["page_sha256"], start=lo+start, end=lo+end,
                text=raw[start:end], window_scope=scope, parent_quote_sha256=digest(quote))


def saved_gate(candidate):
    """Replay saved admission flags only; never call/recompute a gate."""
    decision = candidate["local_decision"]
    failures = []
    if decision.get("status") not in TIERS:
        failures.append("UNKNOWN_OR_INCOMPATIBLE_SAVED_TIER")
    for field in ("final_form_fit", "joint_slot_fit"):
        if candidate.get(field, {}).get("state") != "pass":
            failures.append(field)
    kind = candidate.get("completed_head_kind_fit", {}).get("state")
    exception = candidate.get("context_slot_compatibility", {}).get("state") == "possible"
    if kind != "pass" and not (exception and decision.get("status") == "exploratory_contextual"):
        failures.append("completed_head_kind_fit_without_saved_context_only_exception")
    for name in ("grammar", "provenance"):
        if not any(c.get("id") == name and c.get("state") == "pass" for c in decision.get("checklist", [])):
            failures.append("saved_"+name)
    return dict(eligible_for_reordering=not failures, saved_holds=failures,
                support_tier=TIERS.get(decision.get("status"), 3), gates_recomputed=False)


def _candidate_binding(candidate):
    # Exclude presentation/cache fields and displayed rank so callers may attach
    # an observation without invalidating itself. Bind all actual dependencies.
    fields = ("id", "reading_id", "fill", "source_span", "source_wording", "source_occurrences",
              "sources", "context_rank_key", "source_rank_position", "local_decision",
              "final_form_fit", "completed_head_kind_fit", "joint_slot_fit", "context_slot_compatibility")
    return digest({name:candidate.get(name) for name in fields})


def observe(candidate, query, marker, parse):
    """Fresh, serializable lexical observation; no gate/decision is changed."""
    focal = focal_sentence(query, marker, parse)
    source = source_sentence(candidate, parse)
    wanted, actual = _terms(focal["text"]), _terms(source["text"])
    shared = sorted(wanted & actual)
    precision = len(shared)/len(actual) if actual else 0.0
    value = dict(version=VERSION, kind="PUBLIC_FOCAL_OWN_SOURCE_CUE_OBSERVATION",
                 candidate_binding_sha256=_candidate_binding(candidate),
                 public_query_sha256=digest(query), focal_marker_sha256=digest(marker),
                 focal_sentence=focal, focal_terms=sorted(wanted), source_window=source,
                 source_terms=sorted(actual), shared_terms=shared, shared_count=len(shared),
                 source_unique_count=len(actual), source_precision=precision,
                 lexical_key=[-len(shared), -precision], formula=FORMULA,
                 opacity_policy="SHARED_MASK_REMOVED_BEFORE_ALL_LEXICAL_TERM_SETS",
                 factual_support_certified=False, raw_proofs_modified=False)
    value["sha256"] = digest(value)
    return value


_VALIDATED = object()
_CACHES = WeakSet()


@dataclass(frozen=True)
class ValidatedObservation:
    """Process-local cache, minted by fresh/replayed validation, not JSON input."""
    candidate_binding_sha256: str
    public_query_sha256: str
    focal_marker_sha256: str
    lexical_key: tuple
    proof_sha256: str
    _seal: object


def _validated(value):
    cached = ValidatedObservation(value["candidate_binding_sha256"], value["public_query_sha256"],
                                  value["focal_marker_sha256"], tuple(value["lexical_key"]),
                                  value["sha256"], _VALIDATED)
    _CACHES.add(cached)
    return cached


def validate_observation(candidate, query, marker, parse, observation):
    """Replay exact source/query/marker, parser windows and lexical arithmetic.

    Serialized observations are never trusted just because their checksum matches.
    A successful replay mints an immutable process-local cache for repeated keys.
    """
    if parse is None:
        raise ValueError("Raw observations require parser/source replay before use")
    expected = observe(candidate, query, marker, parse)
    if observation != expected:
        raise ValueError("Supplied observation differs from fresh literal/query/source replay")
    return _validated(expected)


def ordering_key(candidate, query, marker, parse=None, *, observation=None):
    """Conservative context key ONLY; caller retains factual tier and admission.

    key[:11] + focal lexical components + key[11:] + original source rank.
    Existing saved holds raise; they cannot become accepted by ordering. For a
    serialized observation provide parse for replay, or first validate it and
    supply the returned process-local ValidatedObservation with parse=None.
    """
    gate = saved_gate(candidate)
    if not gate["eligible_for_reordering"]:
        raise ValueError("Saved gate hold remains: " + ",".join(gate["saved_holds"]))
    if observation is None:
        if parse is None:
            raise ValueError("Fresh ordering requires a parser or a validated observation")
        cached = _validated(observe(candidate, query, marker, parse))
    elif isinstance(observation, ValidatedObservation):
        cached = observation
    else:
        cached = validate_observation(candidate, query, marker, parse, observation)
    if (cached._seal is not _VALIDATED or cached not in _CACHES
            or cached.candidate_binding_sha256 != _candidate_binding(candidate)
            or cached.public_query_sha256 != digest(query) or cached.focal_marker_sha256 != digest(marker)):
        raise ValueError("Validated observation is stale or bound to another candidate/query/marker")
    old = _freeze(candidate["context_rank_key"])
    if len(old) != 20:
        raise ValueError("Unknown saved key schema")
    return old[:11]+cached.lexical_key+old[11:]+(candidate["source_rank_position"],)


def ordering_utilities(candidates, query, marker, parse=None, *, observations=None):
    """Optional exact finite-pool context-order encoding, not a feature score.

    Distinct complete keys receive equally spaced descending ordinal values in
    [0,1]. All key components, including focal overlap/precision and the original
    stable fallback, are represented. Equal keys share a value. This avoids an
    inexact universal mixed-radix score over unbounded counts/real-valued keys.
    Values are comparable ONLY inside this query/reading/explicit fixed pool.
    The caller still sorts by factual tier, then exact ordering_key; floats are
    display-only and collisions always fall back to the exact key.
    """
    ids = [c["id"] for c in candidates]
    if len(set(ids)) != len(ids) or len({c["reading_id"] for c in candidates}) > 1:
        raise ValueError("Utility requires unique candidates within one reading")
    keys = {c["id"]:ordering_key(c, query, marker, parse,
            observation=None if observations is None else observations.get(c["id"])) for c in candidates}
    distinct = sorted(set(keys.values()))
    positions = {key:i for i,key in enumerate(distinct)}
    denominator = max(1, len(distinct)-1)
    pool_pin = digest(dict(query=digest(query), marker=digest(marker),
                           candidates=sorted((identity, key) for identity,key in keys.items())))
    rows = {}
    for identity, key in keys.items():
        rank = positions[key]
        numerator = denominator-rank if len(distinct) > 1 else 1
        rows[identity] = dict(value=numerator/denominator, exact_numerator=numerator,
            exact_denominator=denominator, distinct_key_rank=rank+1, ordering_key=key,
            focal_lexical_components=key[11:13], original_source_rank_fallback=key[-1])
    return dict(version=VERSION, kind="POOL_BOUND_ORDINAL_CONTEXT_UTILITY", pool_sha256=pool_pin,
                candidates=rows, distinct_keys=len(distinct),
                formula="(distinct_key_count - 1 - zero_based_key_rank)/(distinct_key_count - 1); singleton=1",
                caller_factual_tiers_encoded=False, support_or_acceptance_encoded=False,
                exact_key_is_authority=True, float_collisions_use_exact_key=True,
                calibrated=False, correctness_probability=False, confidence_margin=False,
                cross_pool_comparable=False, factual_support_certified=False)


def ordering_utility(candidate, query, marker, parse=None, *, pool, observations=None):
    """One-row convenience; use the batch API instead of recomputing per row."""
    found = [c for c in pool if c["id"] == candidate["id"]]
    if len(found) != 1 or _candidate_binding(found[0]) != _candidate_binding(candidate):
        raise ValueError("Candidate is not the exact member of the declared utility pool")
    return ordering_utilities(pool, query, marker, parse, observations=observations)["candidates"][candidate["id"]]


def rerank(query, focal_marker, candidates, parse):
    """Return full ID permutations and source proofs; input records stay unchanged.

    alignment_first preserves the first eleven saved source/function priorities,
    placing focal lexical relevance ahead of broad query/page context priors.
    focal_first is an explicitly aggressive TRADEOFF CONTROL: only hard gates
    and factual support tiers precede context; source-role priorities follow.
    Neither ordering is a new top-five display, acceptance or support decision.
    """
    before_pin = digest(candidates)
    ids = [c["id"] for c in candidates]
    if len(set(ids)) != len(ids):
        raise ValueError("Fixed pool contains duplicate candidate IDs")
    focal = focal_sentence(query, focal_marker, parse)
    wanted = _terms(focal["text"])
    observations, by_reading = {}, {}
    for candidate in candidates:
        if "local_decision" not in candidate or "source_occurrences" not in candidate:
            raise ValueError("Only fully saved assessed-candidate records are allowed")
        key = candidate["context_rank_key"]
        if len(key) != 20:
            raise ValueError("Unknown saved key schema")
        source = source_sentence(candidate, parse)
        actual = _terms(source["text"])
        shared = sorted(wanted & actual)
        score = len(shared)
        precision = score/len(actual) if actual else 0.0
        observations[candidate["id"]] = dict(
            saved_candidate_sha256=digest(candidate), saved_decision_sha256=digest(candidate["local_decision"]),
            saved_source_proofs_sha256=digest(candidate["source_occurrences"]),
            saved_gate=saved_gate(candidate), source_window=source,
            shared_terms=shared, shared_count=score, source_unique_count=len(actual),
            query_unique_count=len(wanted), source_precision=precision,
            lexical_key=[-score, -precision], factual_support_certified=False,
            constructor_kind_diagnostics_applied=False)
        by_reading.setdefault(candidate["reading_id"], []).append(candidate)
    orders = {}
    for rid, pool in by_reading.items():
        def key(c, variant):
            observed = observations[c["id"]]
            gate = observed["saved_gate"]
            prefix = (not gate["eligible_for_reordering"], gate["support_tier"])
            old = _freeze(c["context_rank_key"])
            stable = (c["source_rank_position"],)
            lex = tuple(observed["lexical_key"])
            return (prefix+old+stable if variant == "before" else
                    prefix+old[:11]+lex+old[11:]+stable if variant == "alignment_first" else
                    prefix+lex+old+stable)
        orders[rid] = {mode: [c["id"] for c in sorted(pool, key=lambda c: key(c, mode))]
                       for mode in ("before", "alignment_first", "focal_first")}
    if digest(candidates) != before_pin:
        raise RuntimeError("Fixed candidate pool mutated")
    return dict(version=VERSION, fixed_pool_sha256=before_pin, candidate_count=len(candidates),
                public_query_sha256=digest(query), focal_sentence=focal, focal_terms=sorted(wanted),
                formula=FORMULA, observations=observations, orders=orders,
                input_pool_unchanged=True, saved_decisions_unchanged=True,
                source_eligibility_recomputed=False, checked_pool_expanded=False,
                active_engine_integrated=False, native_runs=0, api_calls=0,
                labels_or_reference_answers_read=False, probabilities=False,
                boundary_parse_is_not_factual_authority=True)
