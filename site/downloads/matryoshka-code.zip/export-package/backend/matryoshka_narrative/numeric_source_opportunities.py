"""Literal range/unit source navigation only; no fills, facts, aliases or NLP."""
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.corpus import ENGLISH_STOP_WORDS, words
from matryoshka_demo.io import digest
from matryoshka_narrative.source_witnesses import facts

VERSION='numeric-range-source-page-opportunities/3'
METHOD='current_hierarchy_numeric_ranges'
UNIT=r'(?:troops?|soldiers?|personnel|men|man)'
RANGE=re.compile(r'(?<![\w.,])(?P<lo>\d{1,7})\s*[-\u2013\u2014]\s*(?P<hi>\d{1,7})\s+'
    r'(?P<modifier>(?:[A-Za-z][A-Za-z\'\-]*\s+){1,3}?)(?P<unit>'+UNIT+r')\b',re.I)
COUNT=re.compile(r'(?<![\w.,])(?P<count>\d{1,7})(?:\s*-\s*|\s+)(?P<unit>'+UNIT+r')\b',re.I)
MILITARY=re.compile(r'\b(?:troops?|soldiers?|garrisons?|battalions?|regiments?|navy|army|military)\b',re.I)
GRAMMAR_LINKS=frozenset('and or but who whom whose which that of on in at from to for by with without as is are was were be been being have has had'.split())


def require(value,message):
    if not value:raise ValueError(message)


def occurrences(text,word):
    return [list(m.span())for m in re.finditer(r'(?<!\w)'+re.escape(word)+r'(?!\w)',text,re.I)]


def literal_terms(text):
    return set(words(MASK.sub(' ',text)))-set(ENGLISH_STOP_WORDS)


def focal_ranges(case,plan):
    require(plan.get('query_sha256')==digest(case['query']),'PUBLIC_PLAN_QUERY_MISMATCH')
    atoms=facts(plan,case)
    if case['task']!='redaction':return []
    query,marker=case['query'],case['focal_marker']
    require(isinstance(marker,str)and query.count(marker)==1,'SINGLE_PUBLIC_GAP_REQUIRED')
    gap=query.index(marker);output=[]
    for atom in atoms:
        spans=[s for s in atom['query_spans']if s['start']<=gap<gap+len(marker)<=s['end']]
        if not spans:continue
        seen=set()
        for span in spans:
            for match in RANGE.finditer(span['text']):
                lo,hi=int(match['lo']),int(match['hi'])
                a,b=span['start']+match.start(),span['start']+match.end()
                if not(0<lo<=hi)or(a,b)in seen:continue
                modifiers=re.findall(r"[A-Za-z][A-Za-z'\-]*",match['modifier'])
                modifiers=[m for m in modifiers if m.casefold()not in ENGLISH_STOP_WORDS]
                if not modifiers:continue
                seen.add((a,b));output.append(dict(atom_id=atom['id'],atom_sha256=digest(atom),
                    atom_query_spans=deepcopy(atom['query_spans']),range_span=dict(start=a,end=b,text=query[a:b]),
                    lower=lo,upper=hi,unit=match['unit'],unit_family='PERSONNEL_COUNT',
                    literal_modifiers=modifiers,focal_terms=sorted(literal_terms(span['text']))))
    return output


def sentence_span(text,position,end):
    bounds=[m.end()for m in re.finditer(r'[.!?](?=\s|$)',text)]
    start=max((p for p in bounds if p<=position),default=0)
    stop=min((p for p in bounds if p>=end),default=len(text))
    return [start,stop]


@lru_cache(maxsize=1)
def _wordnet():
    from matryoshka_demo import roles
    return roles.lexicon(),roles.binding()


def _unit_head_guard(text,match,quote):
    """Counted personnel must be a head, not a noun modifier of unknown equipment."""
    gap=text[match.end('count'):match.start('unit')]
    if re.fullmatch(r'\s*-\s*',gap)and match['unit'].casefold()in{'man','men','soldier','soldiers'}and MILITARY.search(quote):
        return dict(state='pass',basis='EXPLICIT_HUMAN_COUNT_CLASSIFIER_IN_MILITARY_CONTEXT',factual_support_certified=False)
    tail=text[match.end('unit'):]
    if not tail.strip()or re.match(r'\s*[,.;:!?()]',tail):
        return dict(state='pass',basis='DELIMITED_UNIT_HEAD',factual_support_certified=False)
    word=re.match(r'\s+(?P<word>[A-Za-z]+(?:-[A-Za-z]+)*)\b',tail)
    if word is None:return dict(state='hold',basis='UNIT_HEAD_BOUNDARY_UNRESOLVED',factual_support_certified=False)
    token=word['word'];lower=token.casefold()
    if lower in GRAMMAR_LINKS:
        return dict(state='pass',basis='CLOSED_GRAMMATICAL_LINK_AFTER_UNIT',next_token=token,factual_support_certified=False)
    if token!=lower and not text.isupper():
        return dict(state='hold',basis='NAMED_OR_UNKNOWN_SUCCESSOR_NOT_LOOKED_UP',next_token=token,factual_support_certified=False)
    try:
        wn,resource=_wordnet()
        nouns=wn.synsets(lower,pos=wn.NOUN)
        other=[s for pos in(wn.VERB,wn.ADJ,wn.ADV)for s in wn.synsets(lower,pos=pos)]
        return dict(state='pass'if not nouns and other else 'hold',
            basis='NON_NOUN_SUCCESSOR'if not nouns and other else 'NOUN_COMPOUND_OR_UNRESOLVED_UNIT_HEAD',
            next_token=token,noun_senses=sorted(s.name()for s in nouns),resource=deepcopy(resource),factual_support_certified=False)
    except (LookupError,OSError,ValueError,ImportError):
        return dict(state='hold',basis='UNIT_HEAD_RESOURCE_UNAVAILABLE',next_token=token,factual_support_certified=False)


def source_matches(page,spec,diagnostics=None):
    text=page['text'];require(page['source_sha256']==digest(text),'RAW_PAGE_HASH_MISMATCH')
    anchors=[]
    for modifier in spec['literal_modifiers']:
        anchors.extend(dict(start=a,end=b,text=text[a:b],public_modifier=modifier)for a,b in occurrences(text,modifier))
    if not anchors:return []
    out=[]
    for match in COUNT.finditer(text):
        value=int(match['count'])
        if not spec['lower']<=value<=spec['upper']:continue
        start,end=sentence_span(text,match.start(),match.end());quote=text[start:end]
        def withhold(reason,details=None):
            if diagnostics is not None:diagnostics.append(dict(page_id=page['id'],atom_id=spec['atom_id'],
                count_span=[match.start('count'),match.end('count')],quote_span=[start,end],page_sha256=page['source_sha256'],
                reason=reason,details=deepcopy(details),optional_opportunity_only=True,ordinary_baseline_aborted=False))
        if MASK.search(quote):
            withhold('OPAQUE_OPTIONAL_QUANTITY_QUOTATION');continue
        if match['unit'].casefold()in{'man','men'}and not MILITARY.search(quote):continue
        unit_head=_unit_head_guard(text,match,quote)
        if unit_head['state']!='pass':
            withhold('COUNTED_PERSONNEL_HEAD_NOT_ESTABLISHED',unit_head);continue
        wanted=set(spec['focal_terms']);overlap=sorted(wanted&literal_terms(quote))
        out.append(dict(source_count=value,source_count_span=[match.start('count'),match.end('count')],
            source_unit=match['unit'],source_unit_span=[match.start('unit'),match.end('unit')],
            compatible_range=[spec['lower'],spec['upper']],unit_family='PERSONNEL_COUNT',
            unit_head_guard=unit_head,
            citation=dict(canonical_page_id=page['id'],document_id=page['document_id'],corpus=page['corpus'],
                date=page['date'],classification=page['classification'],earlier_page=page.get('earlier_page'),
                page_sha256=page['source_sha256'],start=start,end=end,text=quote),
            modifier_spans=deepcopy(anchors),literal_focal_overlap=overlap,raw_quantity_event_or_identity_proven=False))
    return out


def configuration(*,passage_budget,document_budget,construction_pages=32,draft_budget=64,source_view_policy):
    from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE,descriptor
    require(source_view_policy==descriptor(SOURCE_DAY_INCLUSIVE),'NUMERIC_ORDINARY_INCLUSIVE_C_ONLY_POLICY')
    require(type(passage_budget)is int and 48<=passage_budget<=128
        and type(document_budget)is int and document_budget in{32,40}
        and construction_pages==32 and type(construction_pages)is int
        and draft_budget==64 and type(draft_budget)is int,'NUMERIC_EXPLICIT_BASE32_CHECK64_PROFILE')
    return dict(version=VERSION,base_construction_pages=32,inspection_cap=33,document_cap=document_budget+1,
        additional_pages_per_atom=1,total_extra_pages=1,reserved_checks_per_reading=1,completed_check_cap=64,
        original_primary_allocations_preserved=True,original_supplemental_tail_may_be_displaced=True,
        source_policy_or_factual_credit_changed=False)


def _records(case,plan,pages,allowed):
    records=[];specs=focal_ranges(case,plan);withheld=[]
    for spec in specs:
        for pid in sorted(allowed):
            matches=source_matches(pages[pid],spec,withheld)
            if not matches:continue
            records.append(dict(atom_id=spec['atom_id'],public_range=deepcopy(spec),page_id=pid,
                document_id=pages[pid]['document_id'],source_matches=matches,
                distinct_modifier_count=len({a['public_modifier'].casefold()for m in matches for a in m['modifier_spans']}),
                count_match_count=len(matches),best_one_quote_overlap=max(len(m['literal_focal_overlap'])for m in matches)))
    records.sort(key=lambda c:(-c['distinct_modifier_count'],-c['count_match_count'],-c['best_one_quote_overlap'],c['page_id']))
    return specs,records,withheld


def discover(corpus,case,plan,value,*,source_index_ref,passage_budget,document_budget):
    from matryoshka_demo.source_view_policy import descriptor
    from .source_witnesses import BoundSourceIndex,_execution_index_path
    require(case['task']=='redaction'and case['corpus']in{'iran','vietnam'},'NUMERIC_CABLE_REDACTION_ONLY')
    receipt=value['receipt'];policy=value['source_policy']
    settings=configuration(passage_budget=passage_budget,document_budget=document_budget,
        source_view_policy=descriptor(policy.source_view_policy))
    require(policy.corpus is corpus and policy.case==case,'NUMERIC_TRUSTED_POLICY_CASE')
    require(receipt['query_sha256']==digest(case['query']),'NUMERIC_ACTUAL_RECEIPT_QUERY')
    path=_execution_index_path(source_index_ref,case)
    source=BoundSourceIndex(path,source_index_ref['sha256'],case=case,receipt=receipt)
    try:
        mask=list(value['eligible'].page_mask);actual=list(policy.mask())
        require(len(mask)==len(actual)==len(corpus.pages),'NUMERIC_COMPLETE_SOURCE_MASK')
        allowed={p['id']for i,p in enumerate(corpus.pages)if mask[i]and actual[i]}
        require(allowed==source.allowed,'NUMERIC_ACTUAL_INDEX_POLICY_POPULATION')
        specs,records,withheld=_records(case,plan,source.pages,allowed)
        meta=dict(version=VERSION,settings=settings,case_sha256=digest(case),query_sha256=digest(case['query']),
            plan_sha256=digest(plan),source_binding=deepcopy(source_index_ref),source_view_policy=deepcopy(receipt['source_view_policy']),
            base_method=receipt['method'],base_retrieval_sha256=digest(receipt),base_retrieval_passage_budget=passage_budget,
            public_ranges=specs,candidates=records,withheld_optional_matches=withheld,
            discovery_only=True,fills_created=0,support_or_identity_or_event_credit=0)
        updated=dict(value);updated['numeric_range_source_opportunities']=meta
        updated['numeric_range_execution_index_ref']=deepcopy(source_index_ref)
        updated['receipt']=deepcopy(receipt)
        updated['receipt'].update(method=METHOD,numeric_range_source_opportunities=deepcopy(meta))
        source.unchanged()
        return updated
    finally:source.close()


def _validated_metadata(case,plan,retrieval):
    meta=retrieval.get('numeric_range_source_opportunities')
    require(isinstance(meta,dict)and meta.get('version')==VERSION
        and retrieval['receipt']['method']==METHOD
        and retrieval['receipt'].get('numeric_range_source_opportunities')==meta,'NUMERIC_OPT_IN_PRODUCER_BINDING')
    require(set(meta)=={'version','settings','case_sha256','query_sha256','plan_sha256','source_binding','source_view_policy',
        'base_method','base_retrieval_sha256','base_retrieval_passage_budget','public_ranges','candidates',
        'withheld_optional_matches','discovery_only','fills_created','support_or_identity_or_event_credit'}
        and meta['source_binding']==retrieval.get('numeric_range_execution_index_ref')
        and meta['discovery_only']is True and meta['fills_created']==0 and meta['support_or_identity_or_event_credit']==0,
        'NUMERIC_CLOSED_SOURCE_AUTHORITY')
    require(meta['case_sha256']==digest(case)and meta['query_sha256']==digest(case['query'])
        and meta['plan_sha256']==digest(plan),'NUMERIC_PUBLIC_CASE_PLAN_CHANGED')
    base=deepcopy(retrieval['receipt']);base.pop('numeric_range_source_opportunities');base['method']=meta['base_method']
    if 'numeric_range_final_inspection'in base:
        base.pop('numeric_range_final_inspection')
        counts=base.pop('numeric_range_base_counts')
        require(set(counts)=={'document_order','documents_admitted','pages_admitted'},'NUMERIC_BASE_COUNTS_SCHEMA')
        base.update(counts)
    require(digest(base)==meta['base_retrieval_sha256'],'NUMERIC_BASE_RETRIEVAL_CHANGED')
    require(base['construction_passage_budget']==meta['base_retrieval_passage_budget'],'NUMERIC_RETRIEVAL_PASSAGE_BINDING')
    require(meta['settings']==configuration(passage_budget=meta['base_retrieval_passage_budget'],
        document_budget=base['document_budget'],source_view_policy=meta['source_view_policy']),
        'NUMERIC_FIXED_SETTINGS_CHANGED')
    policy=retrieval['source_policy'];corpus=policy.corpus
    require(policy.case==case and retrieval['eligible'].corpus is corpus,'NUMERIC_CURRENT_SOURCE_POLICY')
    from matryoshka_demo.source_view_policy import descriptor
    require(descriptor(policy.source_view_policy)==meta['source_view_policy'],'NUMERIC_POLICY_CHANGED')
    mask=list(retrieval['eligible'].page_mask);pmask=list(policy.mask())
    require(len(mask)==len(pmask)==len(corpus.pages),'NUMERIC_SOURCE_MASK_CHANGED')
    pages={p['id']:p for p in corpus.pages}
    require(len(pages)==len(corpus.pages),'NUMERIC_AMBIGUOUS_PAGE_ID')
    allowed={p['id']for i,p in enumerate(corpus.pages)if mask[i]and pmask[i]}
    specs,records,withheld=_records(case,plan,pages,allowed)
    require(meta['public_ranges']==specs and meta['candidates']==records and meta['withheld_optional_matches']==withheld,
        'NUMERIC_SOURCE_PROOFS_OR_ORDER_CHANGED')
    for row in records:
        pi=corpus.page_index[row['page_id']]
        for match in row['source_matches']:
            q=match['citation'];actual=policy.citation(pi,q['start'],q['end'])
            require(all(actual.get(k)==q[k]for k in('canonical_page_id','document_id','date','text','start','end','page_sha256')),
                'NUMERIC_ACTUAL_SOURCE_POLICY_QUOTE')
    return meta,pages


def extend_inspection(case,plan,retrieval,pool):
    """After unchanged base selection, append bounded raw source pages; never reorder."""
    meta,pages=_validated_metadata(case,plan,retrieval)
    require(pool['passage_budget']==32,'NUMERIC_BASE_CONSTRUCTION_CAP_CHANGED')
    base=list(pool['inspected_page_ids']);docs=list(retrieval['receipt']['document_order'])
    require(len(base)==len(set(base))and len(base)<=32 and len(docs)==len(set(docs))<=meta['settings']['document_cap'],'NUMERIC_BASE_INVENTORY')
    corpus=retrieval['source_policy'].corpus
    require(all(corpus.page_index[p]in pool['pages']for p in base),'NUMERIC_BASE_PAGE_NOT_ADMITTED')
    chosen=list(base);counts={};witnesses=[];holds=[]
    for row in meta['candidates']:
        pid,doc,atom=row['page_id'],row['document_id'],row['atom_id']
        if pid not in chosen:
            if counts.get(atom,0)>=1:holds.append(dict(page_id=pid,reason='PER_ATOM_EXTRA_CAP'));continue
            if len(chosen)-len(base)>=1 or(doc not in docs and len(docs)>=meta['settings']['document_cap']):
                holds.append(dict(page_id=pid,reason='SINGLE_GLOBAL_EXTRA_PAGE_CAP'));continue
            chosen.append(pid);counts[atom]=counts.get(atom,0)+1
        if doc not in docs:docs.append(doc)
        witnesses.append(deepcopy(row))
    updated=dict(pool);updated['pages']=list(pool['pages'])
    for pid in chosen:
        pi=corpus.page_index[pid]
        if pi not in updated['pages']:updated['pages'].append(int(pi))
    updated['inspected_page_ids']=chosen
    require(len(chosen)<=len(base)+1<=33,'NUMERIC_SINGLE_GLOBAL_EXTRA_WITNESS_PAGE')
    updated['passage_budget']=max(pool['passage_budget'],len(chosen))
    audit=dict(version=VERSION,base_inspected_page_ids=base,selected_page_ids=chosen,
        appended_page_ids=[p for p in chosen if p not in base],document_order=docs,
        base_document_order=list(retrieval['receipt']['document_order']),witnesses=witnesses,capacity_holds=holds,
        original_page_prefix_preserved=chosen[:len(base)]==base,requested_base_page_cap=32,
        effective_page_cap=updated['passage_budget'],completed_check_cap=64,discovery_only=True,
        single_extra_witness_page_cap=1,withheld_optional_matches=deepcopy(meta['withheld_optional_matches']),
        normal_construction_and_gates_required=True,independent_support_credit_added=False)
    updated['numeric_range_inspection']=audit
    return updated,audit


def _attachment(case,reading):
    if not(reading.get('form')=='nominal'and reading.get('outer_family')=='nominal'
        and reading.get('function')=='complement'and reading.get('role')=='prepositional_argument'):return None
    gap=case['query'].index(case['focal_marker'])
    for span in reading.get('attachment_spans',[]):
        a,b=span.get('start'),span.get('end')
        require(type(a)is int and type(b)is int and 0<=a<b<=gap and case['query'][a:b]==span.get('text'),
            'NUMERIC_LITERAL_PUBLIC_ATTACHMENT')
        if not case['query'][b:gap].strip()and re.fullmatch(r'[A-Za-z]+(?:\s+[A-Za-z]+){0,2}',span['text']):
            return span['text']
    return None


def reserve_existing_checks(ordered,case,plan,pool,inspection,*,draft_budget):
    """One existing group/reading early; replace only a supplemental tail slot, cap64."""
    require(draft_budget==64 and type(draft_budget)is int,'NUMERIC_FIXED_COMPLETED_CHECK_CAP')
    require(pool.get('numeric_range_inspection')==inspection,'NUMERIC_INSPECTION_ALLOCATION_BINDING')
    meta,_=_validated_metadata(case,plan,pool)
    require(inspection['selected_page_ids']==pool['inspected_page_ids']
        and all(w in meta['candidates']for w in inspection['witnesses']),
        'NUMERIC_INSPECTED_WITNESS_SOURCE_BINDING')
    require(len({id(g)for g in ordered})==len(ordered),'NUMERIC_DISTINCT_EXISTING_GROUPS_REQUIRED')
    policy=pool['source_policy'];corpus=policy.corpus
    readings={r['id']:r for r in plan['readings_packet']['readings']}
    index={id(g):i for i,g in enumerate(ordered)};by_reading={};proofs={}
    for g in ordered:
        reading=g['original_reading'];rid=reading['id']
        require(readings.get(rid)==reading,'NUMERIC_DECLARED_READING_CHANGED')
        attachment=_attachment(case,reading)
        if attachment is None or g.get('scheduling',{}).get('preliminary_source_form_match')is not True:continue
        for occurrence in g['occurrences']:
            q=occurrence['citation'];pid=q['canonical_page_id']
            if pid not in inspection['selected_page_ids']:continue
            matches=[m for row in inspection['witnesses']if row['page_id']==pid for m in row['source_matches']]
            for match in matches:
                count=match['source_count_span'];unit=match['source_unit_span'];a,b=occurrence['source_span']
                if not(q['start']<=count[0]<count[1]<=unit[0]<unit[1]<=a<b<=q['end']):continue
                page=corpus.pages[corpus.page_index[pid]]
                actual=policy.citation(corpus.page_index[pid],q['start'],q['end'])
                require(all(actual.get(k)==q.get(k)for k in('canonical_page_id','document_id','date','text','start','end','page_sha256')),
                    'NUMERIC_EXISTING_OCCURRENCE_QUOTE')
                require(page['text'][a:b]==occurrence['source_wording'],'NUMERIC_EXISTING_PHRASE_SPAN')
                head=occurrence.get('source_head',{});hs=head.get('span',[])
                if not(head.get('pos')in{'NOUN','PROPN'}and len(hs)==2 and a<=hs[0]<hs[1]<=b
                    and page['text'][hs[0]:hs[1]]==head.get('text')):continue
                bridge=page['text'][unit[1]:a]
                if len(bridge)>48 or len(bridge.split())>8 or re.search(r'[.!?;]',bridge):continue
                pattern=r'(?<!\w)'+r'\s+'.join(re.escape(w)for w in attachment.split())+r'\s*$'
                if not re.search(pattern,bridge,re.I):continue
                proofs.setdefault(id(g),dict(reading_id=rid,group_input_position=index[id(g)]+1,
                    group_source_identity_sha256=digest([rid,g['fill'],g['node_id'],g['occurrences']]),
                    source_occurrence=deepcopy(occurrence),quantity_match=deepcopy(match),public_attachment=attachment,
                    priority_only=True,source_support_or_truth_added=False))
                by_reading.setdefault(rid,[]).append(g)
    reserved=[];displaced=[];notes=[]
    for rid,values in sorted(by_reading.items()):
        winner=min(values,key=lambda g:index[id(g)])
        selected=[g for g in ordered if g['reading']['id']==rid and g['selected_for_evaluation']]
        require(len(selected)<=64,'NUMERIC_BASE_ALLOCATION_EXCEEDS_CAP')
        oldids=[index[id(g)]+1 for g in selected]
        if not winner['selected_for_evaluation']:
            if len(selected)>=64:
                tail=next((g for g in reversed(selected)if 'PRIMARY_SOURCE_FAMILY'not in g['evaluation_lanes']),None)
                if tail is None:continue
                tail['selected_for_evaluation']=False;tail['initial_opportunity_allocated']=False
                tail['evaluation_lanes']=[];tail['assessment_reason']='NUMERIC_RANGE_CHECK_RESERVATION_DISPLACED_SUPPLEMENTAL_TAIL'
                displaced.append(index[id(tail)]+1)
            winner['selected_for_evaluation']=True;winner['initial_opportunity_allocated']=True
        winner['evaluation_lanes'].append('NUMERIC_RANGE_SOURCE_CONTEXT_RESERVED_CHECK')
        reserved.append(winner)
        notes.append(dict(**proofs[id(winner)],old_selected_group_positions=oldids,
            displaced_supplemental_group_positions=[p for p in displaced if ordered[p-1]['reading']['id']==rid]))
    reserved_ids={id(g)for g in reserved}
    result=(reserved+[g for g in ordered if id(g)not in reserved_ids and g['selected_for_evaluation']]
        +[g for g in ordered if not g['selected_for_evaluation']])if reserved else ordered
    for rid in readings:
        require(sum(g['selected_for_evaluation']and g['reading']['id']==rid for g in result)<=64,'NUMERIC_CHECK_CAP_EXCEEDED')
    return result,dict(version=VERSION,reserved=notes,reserved_check_count=len(reserved),
        displaced_supplemental_group_positions=displaced,completed_check_cap=64,new_candidates_created=0,
        normal_final_form_head_controller_joint_source_counter_gates_unchanged=True,
        primary_allocations_preserved=True,reserved_checks_execute_before_family_fallbacks=True,
        recovery_or_factual_credit_claimed=False)


def finalize_retrieval(case,plan,retrieval,inspection):
    """Commit actual post-selection admission counts, preserving original kernel counts."""
    meta,_=_validated_metadata(case,plan,retrieval)
    require('numeric_range_final_inspection'not in retrieval['receipt'],'NUMERIC_ALREADY_FINALIZED')
    base=inspection['base_inspected_page_ids'];selected=inspection['selected_page_ids']
    require(selected[:len(base)]==base and len(set(selected))==len(selected)<=len(base)+1<=33
        and all(w in meta['candidates']for w in inspection['witnesses']),'NUMERIC_FINAL_INSPECTION_BINDING')
    require(inspection['base_document_order']==retrieval['receipt']['document_order'],'NUMERIC_BASE_DOCUMENT_COUNTS')
    corpus=retrieval['source_policy'].corpus
    docs=list(inspection['base_document_order']);expected=list(base)
    for witness in inspection['witnesses']:
        if witness['page_id']not in expected:expected.append(witness['page_id'])
        if witness['document_id']not in docs:docs.append(witness['document_id'])
    require(selected==expected and docs==inspection['document_order']and len(docs)<=meta['settings']['document_cap'],'NUMERIC_FINAL_OPPORTUNITY_INVENTORY')
    updated=dict(retrieval);updated['pages']=list(retrieval['pages'])
    for pid in selected:
        pi=corpus.page_index[pid]
        if pi not in updated['pages']:updated['pages'].append(int(pi))
    updated['receipt']=deepcopy(retrieval['receipt'])
    updated['receipt']['numeric_range_base_counts']={k:deepcopy(retrieval['receipt'][k])for k in('document_order','documents_admitted','pages_admitted')}
    updated['receipt'].update(document_order=docs,documents_admitted=len(docs),pages_admitted=len(updated['pages']),
        numeric_range_final_inspection=deepcopy(inspection))
    return updated
