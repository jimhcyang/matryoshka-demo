"""Bounded source-owned graph-seed opportunities, not an inference engine."""
from collections import deque
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import time

VERSION = 'source-owned-seed-opportunities/1'
METHOD = 'current_hierarchy_witnesses'
ROOT = Path(__file__).resolve().parents[1]
_HANDLING = re.compile(r'\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM(?:INATION)?\b', re.I)
_PUBLIC_FIELDS = {'case_id', 'task', 'corpus', 'query', 'date', 'document_id', 'focal_marker'}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode()).hexdigest()


def file_sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def literal(text, surface):
    if not isinstance(surface, str) or not surface.strip() or len(surface) > 160:
        return None
    match = re.search(r'(?<!\w)' + r'\s+'.join(re.escape(t) for t in surface.split()) + r'(?!\w)', text, re.I)
    return [match.start(), match.end()] if match else None


def norm(text):
    return ' '.join(text.casefold().split())


class SeedRejected(ValueError):
    pass


class OpportunityCapacityError(ValueError):
    pass


def facts(plan, case):
    result = []
    for atom in plan.get('atoms', []):
        if atom.get('kind') == 'context':
            continue
        if not isinstance(atom.get('id'), str) or not atom.get('text', '').strip():
            raise ValueError('Executable atom ID/text required')
        spans = atom.get('query_spans')
        if not isinstance(spans, list) or not spans:
            raise ValueError('Executable atoms need actual public query spans')
        for span in spans:
            a, b = span.get('start'), span.get('end')
            if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(case['query']) or case['query'][a:b] != span.get('text'):
                raise ValueError('Public atom query span mismatch')
        result.append(atom)
    if not result or len({a['id'] for a in result}) != len(result):
        raise ValueError('Distinct executable atoms required')
    return result


class BoundSourceIndex:
    """Thin immutable index adapter; no hierarchy materialization or NLP."""

    def __init__(self, path, expected_sha256, *, case, receipt):
        if set(case) != _PUBLIC_FIELDS or case['corpus'] not in {'vietnam', 'iran'} or case['task'] not in {'mosaic', 'hypothesis', 'redaction'}:
            raise ValueError('This candidate is bounded to exact public C-only cable cases')
        expected = {'id': 'source_day_inclusive', 'date_relation': '<=', 'cable_classification': 'CONFIDENTIAL',
            'cable_origin': 'WHOLE_DOCUMENT_EXCLUDED', 'cable_document_wide_handling_veto': True,
            'later_or_secret_version_admitted': False, 'source_dates_or_document_ids_rewritten': False}
        policy = receipt.get('source_view_policy', {})
        if any(key not in policy or type(policy[key]) is not type(value) or policy[key] != value for key, value in expected.items()):
            raise ValueError('Exact C-only inclusive source policy required')
        self.path = Path(path).resolve()
        self.index_sha256 = expected_sha256
        if file_sha256(self.path) != expected_sha256:
            raise ValueError('Actual native index checksum mismatch')
        self.case = deepcopy(case)
        self.receipt = deepcopy(receipt)
        self.receipt_hash = digest(receipt)
        self.db = sqlite3.connect(self.path.as_uri() + '?mode=ro&immutable=1', uri=True)
        self.db.execute('PRAGMA query_only=ON')
        self.pages = {row[0]: json.loads(row[1]) for row in self.db.execute('SELECT id,payload FROM page ORDER BY id')}
        self.veto = set(receipt['handling_veto_documents'])
        self.veto.update(page['document_id'] for page in self.pages.values() if _HANDLING.search(page['text']) or
            any(_HANDLING.search(str(h)) for h in page.get('handling', [])))
        self.allowed = {id for id, page in self.pages.items() if page.get('id') == id and page.get('permitted') is True
            and page.get('corpus') == case['corpus'] and page.get('classification') == 'CONFIDENTIAL'
            and page['date'] <= case['date'] and page['document_id'] != case['document_id'] and page['document_id'] not in self.veto}
        if len(self.allowed) != receipt['eligible_pages']:
            self.close()
            raise ValueError('Actual source-policy population mismatch')

    def close(self):
        self.db.close()

    def unchanged(self):
        if file_sha256(self.path) != self.index_sha256:
            raise ValueError('Read-only source index changed')

    def sql(self, query, values):
        deadline = time.monotonic() + 5
        self.db.set_progress_handler(lambda: int(time.monotonic() > deadline), 10000)
        try:
            return self.db.execute(query, values).fetchall()
        finally:
            self.db.set_progress_handler(None, 0)

    def validate_seed(self, seed, atom):
        if seed.get('node_type') != 'Entity':
            raise SeedRejected('NOT_ENTITY_SEED')
        surface = seed.get('source_surface')
        atom_anchor = literal(atom['text'], surface)
        if atom_anchor is None:
            raise SeedRejected('NO_LITERAL_ATOM_ANCHOR')
        public_anchors = []
        for span in atom['query_spans']:
            hit = literal(span['text'], surface)
            if hit is not None:
                public_anchors.append([span['start'] + hit[0], span['start'] + hit[1]])
        if not public_anchors:
            raise SeedRejected('NO_BOUND_PUBLIC_QUERY_ANCHOR')
        proof = seed.get('source_proof')
        if not isinstance(proof, dict):
            raise SeedRejected('MISSING_OWN_SOURCE_PROOF')
        page_id = proof.get('canonical_page_id')
        if page_id not in self.allowed:
            raise SeedRejected('UNKNOWN_OR_INELIGIBLE_PAGE')
        page = self.pages[page_id]
        expected = {'document_id': page['document_id'], 'date': page['date'], 'corpus': page['corpus'],
            'page_sha256': page['source_sha256'], 'earlier_page': page.get('earlier_page')}
        if any(type(proof.get(key)) is not type(value) or proof.get(key) != value for key, value in expected.items()):
            raise SeedRejected('SOURCE_METADATA_MISMATCH')
        a, b = proof.get('start'), proof.get('end')
        if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page['text']) or page['text'][a:b] != proof.get('text'):
            raise SeedRejected('SOURCE_SPAN_MISMATCH')
        source_anchor = literal(proof['text'], surface)
        if source_anchor is None:
            raise SeedRejected('SEED_SURFACE_ABSENT_FROM_OWN_QUOTE')
        node = seed.get('node_id')
        if self.sql('SELECT kind FROM node WHERE id=?', (node,)) != [('Entity',)]:
            raise SeedRejected('INDEX_NODE_NOT_ENTITY')
        labels = self.sql('SELECT label FROM mention WHERE node=? AND page=? LIMIT 128', (node, page_id))
        if not any(norm(row[0]) == norm(surface) for row in labels):
            raise SeedRejected('NO_OWN_INDEXED_ENTITY_MENTION')
        if not self.sql('SELECT id FROM unit WHERE page=? AND start=? AND end=? LIMIT 1', (page_id, a, b)):
            raise SeedRejected('NO_EXACT_INDEXED_CITATION_UNIT')
        return {'atom_id': atom['id'], 'node_id': node, 'surface': surface, 'page_id': page_id,
            'document_id': page['document_id'], 'public_query_anchor_spans': public_anchors,
            'source_surface_span': [a + source_anchor[0], a + source_anchor[1]],
            'source_proof': deepcopy(proof), 'raw_text_sha256': hashlib.sha256(page['text'].encode()).hexdigest(),
            'seed': deepcopy(seed), 'discovery_only': True, 'positive_support_certified': False,
            'identity_or_event_certified': False, 'support_credit': 0}


def add_document_opportunities(source, case, plan, receipt, *, query_sha256,
        per_atom_extra=2, document_cap=40, seed_limit=5):
    """Append bounded owned-seed documents; never displace original documents."""
    if source.case != case or source.receipt_hash != digest(receipt):
        raise ValueError('Source adapter/case/actual receipt binding mismatch')
    if digest(case['query']) != query_sha256 or receipt.get('query_sha256') != query_sha256:
        raise ValueError('Actual public query hash mismatch')
    if type(document_cap) is not int or document_cap not in {40, 48} or type(per_atom_extra) is not int or not 1 <= per_atom_extra <= 4:
        raise ValueError('Explicit bounded document settings required')
    if type(seed_limit) is not int or not 1 <= seed_limit <= 5:
        raise ValueError('Only actual top-five seed witnesses may be considered')
    atoms = facts(plan, case)
    by_atom = {atom['id']: atom for atom in atoms}
    baseline = list(receipt['document_order'])
    if not baseline or len(baseline) > 32 or len(set(baseline)) != len(baseline) or receipt['documents_admitted'] != len(baseline):
        raise ValueError('Distinct original <=32-document pool required')
    if receipt.get('document_budget') != 32:
        raise ValueError('Candidate is explicitly bound to the original32 profile')
    allowed_docs = {source.pages[id]['document_id'] for id in source.allowed}
    if not set(baseline) <= allowed_docs:
        raise ValueError('Original pool contains unknown/ineligible documents')
    candidates = {id: [] for id in by_atom}
    rejections, served = [], set()
    for search in receipt['search_queries']:
        if search.get('kind') != 'atom' or search.get('id') not in by_atom or search.get('query') != by_atom[search['id']]['text']:
            raise ValueError('Actual search is not an exact executable plan atom')
        rows = [search] + search.get('also_serves', [])
        for row in rows:
            atom = by_atom.get(row.get('id'))
            if atom is None or row.get('kind') != 'atom' or row.get('query') != atom['text']:
                raise ValueError('Search alias not bound to an executable plan atom')
            if set(re.findall(r'[a-z0-9]+', row['query'].lower())) != set(re.findall(r'[a-z0-9]+', search['query'].lower())):
                raise ValueError('Search alias changes the executed lexical query')
            if atom['id'] in served:
                raise ValueError('Repeated atom search would duplicate opportunities')
            served.add(atom['id'])
            seen_docs = set()
            for rank, seed in enumerate(search.get('top_nodes', [])[:seed_limit], 1):
                try:
                    value = source.validate_seed(seed, atom)
                    if value['document_id'] in seen_docs:
                        raise SeedRejected('DUPLICATE_ATOM_DOCUMENT')
                    seen_docs.add(value['document_id'])
                    candidates[atom['id']].append({**value, 'native_seed_rank': rank})
                except SeedRejected as error:
                    rejections.append({'atom_id': atom['id'], 'native_seed_rank': rank,
                        'node_id': seed.get('node_id'), 'reason': str(error)})
    if served != set(by_atom):
        raise ValueError('All executable atoms must be served by actual receipt searches')
    documents, admitted = list(baseline), set(baseline)
    chosen = {id: {row['document_id'] for row in rows if row['document_id'] in admitted} for id, rows in candidates.items()}
    for turn in range(per_atom_extra):
        for atom in atoms:
            id = atom['id']
            for row in candidates[id]:
                doc = row['document_id']
                if doc in chosen[id] or doc in baseline:
                    continue
                if doc not in admitted and len(documents) >= document_cap:
                    continue
                if doc not in admitted:
                    documents.append(doc)
                    admitted.add(doc)
                chosen[id].add(doc)
                break
    witnesses = {id: [row for row in rows if row['document_id'] in chosen[id]] for id, rows in candidates.items()}
    no_witness = [id for id, rows in candidates.items() if not rows]
    unfunded = [id for id, rows in candidates.items() if rows and not witnesses[id]]
    result = {'version': VERSION, 'status': 'HOLD_DOCUMENT_CAPACITY' if unfunded else 'READY_FOR_PHASE_INSPECTION',
        'case_sha256': digest(case), 'query_sha256': query_sha256, 'plan_sha256': digest(plan),
        'native_retrieval_sha256': digest(receipt), 'index_sha256': source.index_sha256,
        'per_atom_extra': per_atom_extra, 'document_cap': document_cap, 'seed_limit': seed_limit,
        'base_document_order': baseline, 'document_order': documents,
        'extra_document_order': documents[len(baseline):], 'atom_order': list(by_atom),
        'witnesses': witnesses, 'unavailable_atoms': no_witness, 'unfunded_atoms': unfunded,
        'deferred_witnesses': [row for id, rows in candidates.items() for row in rows if row['document_id'] not in chosen[id]],
        'rejections': rejections, 'base_documents_preserved': documents[:len(baseline)] == baseline,
        'citation_page_ids': list(dict.fromkeys(row['page_id'] for rows in witnesses.values() for row in rows)),
        'source_or_source_policy_modified': False, 'support_or_identity_credit_added': False}
    result['metadata_sha256'] = digest(result)
    return result


def schedule_opportunity_inspection(source, plan, opportunities, baseline_page_order, *, budget=48):
    """Reserve actual witnesses before the existing inspection queue, capped48."""
    if type(budget) is not int or not 1 <= budget <= 48:
        raise ValueError('Explicit inspection cap <=48 required')
    value = deepcopy(opportunities)
    metadata_hash = value.pop('metadata_sha256', None)
    if digest(value) != metadata_hash or value['index_sha256'] != source.index_sha256 or value['case_sha256'] != digest(source.case) or value['plan_sha256'] != digest(plan):
        raise ValueError('Opportunity metadata/source/plan binding mismatch')
    if value['native_retrieval_sha256'] != source.receipt_hash:
        raise ValueError('Opportunity receipt binding mismatch')
    replayed = add_document_opportunities(source, source.case, plan, source.receipt,
        query_sha256=value['query_sha256'], per_atom_extra=value['per_atom_extra'],
        document_cap=value['document_cap'], seed_limit=value['seed_limit'])
    if digest(replayed) != digest(opportunities):
        raise ValueError('Opportunity metadata differs from actual seed-receipt replay')
    if value['unfunded_atoms']:
        raise OpportunityCapacityError('Document cap cannot provide an owned witness for all coverable atoms')
    atoms = {a['id']: a for a in facts(plan, source.case)}
    if list(atoms) != value['atom_order'] or set(value['witnesses']) != set(atoms):
        raise ValueError('Witness atom inventory changed')
    baseline = list(baseline_page_order)
    if len(set(baseline)) != len(baseline):
        raise ValueError('Duplicate baseline inspection page')
    for id in baseline:
        if id not in source.allowed or source.pages[id]['document_id'] not in value['base_document_order']:
            raise ValueError('Baseline inspection contains unknown/ineligible/non-original page')
    for id, rows in value['witnesses'].items():
        for row in rows:
            checked = source.validate_seed(row['seed'], atoms[id])
            for key, expected in checked.items():
                if row.get(key) != expected:
                    raise ValueError('Witness replay mismatch')
            if row['document_id'] not in value['document_order']:
                raise ValueError('Witness document not admitted')
    selected, seen = [], set()
    coverable = [id for id in atoms if value['witnesses'][id]]
    # The first round is mandatory; fail closed rather than silently skipping an atom.
    for id in coverable:
        rows = value['witnesses'][id]
        if any(row['page_id'] in seen for row in rows):
            continue
        if len(selected) >= budget:
            raise OpportunityCapacityError('Inspection cap cannot fund first witness round')
        page = rows[0]['page_id']
        selected.append(page)
        seen.add(page)
    queues = {id: deque(row['page_id'] for row in rows) for id, rows in value['witnesses'].items()}
    while len(selected) < budget and any(queues.values()):
        for id in atoms:
            queue = queues[id]
            while queue and queue[0] in seen:
                queue.popleft()
            if queue and len(selected) < budget:
                page = queue.popleft()
                selected.append(page)
                seen.add(page)
    reserved = list(selected)
    for page in baseline:
        if len(selected) >= budget:
            break
        if page not in seen:
            selected.append(page)
            seen.add(page)
    coverage = {id: [row['page_id'] for row in rows if row['page_id'] in seen] for id, rows in value['witnesses'].items()}
    if any(not coverage[id] for id in coverable):
        raise OpportunityCapacityError('Coverable atom was not inspected')
    return {'version': VERSION, 'budget': budget, 'selected_page_ids': selected,
        'reserved_witness_page_ids': reserved, 'atom_witness_pages_inspected': coverage,
        'unavailable_atoms': value['unavailable_atoms'], 'coverable_atoms_all_inspected': True,
        'original_inspection_pages_retained': [id for id in baseline[:budget] if id in seen],
        'original_inspection_pages_displaced': [id for id in baseline[:budget] if id not in seen],
        'baseline_order_preserved_in_fill': True, 'selected_pages': len(selected),
        'all_pages_remain_subject_to_ordinary_evidence_checks': True,
        'support_or_identity_credit_added': False, 'opportunity_metadata_sha256': metadata_hash}


def configuration(*, passage_budget, document_budget, source_view_policy):
    """One explicit reviewed opt-in, separate from focal discovery parameters."""
    if type(document_budget) is not int or document_budget != 32 or type(passage_budget) is not int or passage_budget != 48:
        raise ValueError('Source-owned opportunities require primary32 documents and48 inspections')
    expected = {'id': 'source_day_inclusive', 'date_relation': '<=', 'cable_classification': 'CONFIDENTIAL',
        'cable_origin': 'WHOLE_DOCUMENT_EXCLUDED', 'cable_document_wide_handling_veto': True,
        'later_or_secret_version_admitted': False, 'source_dates_or_document_ids_rewritten': False}
    if any(type(source_view_policy.get(key)) is not type(value) or source_view_policy.get(key) != value for key, value in expected.items()):
        raise ValueError('Source-owned opportunities require ordinary C-only inclusive cable policy')
    return dict(version=VERSION, primary_document_budget=32, overall_document_cap=40,
        per_atom_extra_documents=2, seed_limit=5, inspection_budget=48,
        preserves_primary_document_pool=True, source_judgments_or_scores_modified=False)


def _execution_index_path(reference, case):
    from matryoshka_current import resources
    if not isinstance(reference, dict) or reference.get('corpus') != case['corpus'] or reference.get('source_status') != 'INCUMBENT_NOT_MIGRATED':
        raise ValueError('Trusted incumbent execution index reference required')
    native = reference.get('native_index_ref')
    if not isinstance(native, dict) or native.get('sha256') != reference.get('sha256'):
        raise ValueError('Execution/native source index checksums differ')
    for key in ('sha256', 'registry_sha256', 'source_binding_sha256'):
        if not isinstance(reference.get(key), str) or re.fullmatch(r'[0-9a-f]{64}', reference[key]) is None:
            raise ValueError('Incomplete execution index binding')
    path = resources.safe_path(ROOT, reference['path'])
    if path != resources.safe_path(ROOT, native['path']) or not path.is_relative_to((ROOT / 'data/graph_indexes_v2').resolve()):
        raise ValueError('Unexpected cable index path/root adaptation')
    manifest = json.loads(path.with_name('manifest.json').read_bytes())
    if manifest.get('binding') != native.get('binding') or manifest.get('sha256') != reference['sha256']:
        raise ValueError('Source index manifest differs from actual execution binding')
    return path


def apply_source_owned_opportunities(corpus, case, plan, value, *, source_index_ref,
        passage_budget, document_budget):
    """After unchanged base inspection, expose only exact owned-citation pages."""
    if case['corpus'] not in {'iran', 'vietnam'} or case['task'] not in {'reconstruction', 'hypothesis'}:
        raise ValueError('This opt-in is reviewed only for ordinary cable Mosaic/Hypothesis')
    receipt = value['receipt']
    settings = configuration(passage_budget=passage_budget, document_budget=document_budget,
        source_view_policy=receipt['source_view_policy'])
    if 'fact_document_inspection' not in receipt or receipt['fact_document_inspection'].get('budget') != passage_budget:
        raise ValueError('Unchanged base inspection must run before the opportunity lane')
    if value['source_policy'].corpus is not corpus:
        raise ValueError('Source policy/corpus identity differs from inspected base')
    public_case = deepcopy(case)
    if public_case['task'] == 'reconstruction':
        public_case['task'] = 'mosaic'
    path = _execution_index_path(source_index_ref, case)
    source = BoundSourceIndex(path, source_index_ref['sha256'], case=public_case, receipt=receipt)
    try:
        mask = list(value['eligible'].page_mask)
        policy_mask = list(value['source_policy'].mask())
        if len(mask) != len(corpus.pages) or len(policy_mask) != len(mask):
            raise ValueError('Complete source mask length differs from corpus')
        allowed = {corpus.pages[i]['id'] for i in range(len(mask)) if mask[i] and policy_mask[i]}
        if allowed != source.allowed:
            raise ValueError('Complete SourcePolicy and actual index disagree on eligible pages')
        baseline = list(value['pages'])
        if len(baseline) != len(set(baseline)) or any(type(i) is not int or not 0 <= i < len(corpus.pages) for i in baseline):
            raise ValueError('Unknown/duplicate base page index')
        baseline_ids = [corpus.pages[i]['id'] for i in baseline]
        opportunities = add_document_opportunities(source, public_case, plan, receipt,
            query_sha256=receipt['query_sha256'], per_atom_extra=settings['per_atom_extra_documents'],
            document_cap=settings['overall_document_cap'], seed_limit=settings['seed_limit'])
        index_by_id = {page['id']: i for i, page in enumerate(corpus.pages)}
        if len(index_by_id) != len(corpus.pages):
            raise ValueError('Ambiguous corpus page identity')
        for rows in opportunities['witnesses'].values():
            for row in rows:
                pi = index_by_id.get(row['page_id'])
                if pi is None or row['page_id'] not in allowed:
                    raise ValueError('Owned witness absent from actual eligible corpus')
                # This checks complete bound source bytes, not just the matched label.
                proof = row['source_proof']
                checked = value['source_policy'].citation(pi, proof['start'], proof['end'])
                if any(type(proof.get(k)) is not type(v) or proof.get(k) != v for k, v in checked.items()):
                    raise ValueError('Owned seed citation differs from actual SourcePolicy/index')
        inspection = schedule_opportunity_inspection(source, plan, opportunities, baseline_ids, budget=passage_budget)
        admitted_ids = list(dict.fromkeys(baseline_ids + opportunities['citation_page_ids']))
        selected_ids = inspection['selected_page_ids']
        selected_set = set(selected_ids)
        ordered_ids = selected_ids + [id for id in admitted_ids if id not in selected_set]
        updated = dict(value)
        updated['pages'] = [int(index_by_id[id]) for id in ordered_ids]
        updated['receipt'] = deepcopy(receipt)
        final = updated['receipt']
        base_inspection = deepcopy(receipt['fact_document_inspection'])
        active = deepcopy(base_inspection)
        active.update(version=VERSION, admitted_pages=len(admitted_ids),
            admitted_documents=len(opportunities['document_order']), selected_pages=len(selected_ids),
            eligible_pages_in_admitted_documents=sum(source.pages[id]['document_id'] in opportunities['document_order'] for id in source.allowed),
            newly_nominated_document_pages=sum(id not in set(baseline_ids) for id in selected_ids),
            admitted_document_pool_changed=bool(opportunities['extra_document_order']),
            source_pool_changed=bool(set(selected_ids) - set(baseline_ids)),
            source_owned_witness_inspection=deepcopy(inspection), eligibility_filters_changed=False,
            source_text_modified=False, original_relevance_order_retained_in_tail=True)
        for cell in active.get('nominations', []):
            cell['inspected'] = cell['page_id'] in selected_set
        active['uninspected_nominations'] = sum(not cell['inspected'] for cell in active.get('nominations', []))
        active['nomination_pages_selected'] = len({cell['page_id'] for cell in active.get('nominations', []) if cell['inspected']} |
            set(inspection['reserved_witness_page_ids']))
        final.update(method=METHOD, source_scope='ORIGINAL_HIERARCHY_PLUS_SOURCE_OWNED_SEED_CITATION_OPPORTUNITIES',
            document_budget_role='PRIMARY_POOL_BEFORE_SEPARATE_BOUNDED_OPPORTUNITIES',
            documents_admitted=len(opportunities['document_order']), document_order=opportunities['document_order'],
            pages_admitted=len(admitted_ids), base_fact_document_inspection=base_inspection,
            fact_document_inspection=active, base_top_sources=deepcopy(receipt.get('top_sources', [])),
            source_owned_document_opportunities=dict(settings=settings, metadata=opportunities,
                execution_index_ref=deepcopy(source_index_ref), base_retrieval_sha256=digest(receipt),
                original_inspection_pages_displaced=inspection['original_inspection_pages_displaced'],
                source_policy_and_index_citations_replayed=True, independent_support_credit_added=False))
        final['top_sources'] = [dict(page_id=corpus.pages[pi]['id'], document_id=corpus.pages[pi]['document_id'],
            date=corpus.pages[pi]['date'], page_rank=value.get('page_ranks', {}).get(pi),
            rrf=value.get('page_scores', {}).get(pi), inspection_rank=rank)
            for rank, pi in enumerate(updated['pages'][:passage_budget], 1)]
        source.unchanged()
        return updated
    finally:
        source.close()
