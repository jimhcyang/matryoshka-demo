"""Unintegrated Red sidecar over unchanged complete-assertion source matching.

No construction, grammar, source-kind, joint-fit or recommendation authority is
granted here. A caller must retain those independent filters. Only candidate-own
cited units are examined; the complete SourcePolicy supplies admission/vetoes.
"""
from collections.abc import Mapping
from copy import copy, deepcopy

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v6.planning import sentences, _open_reporting_context
from matryoshka_next.facts import SourcePolicy, public_plan
from . import assertion_matching, source_sentences

VERSION = "narrative-redaction-complete-assertion-sidecar/1"


class AssertionWitnessError(ValueError):
    """Invalid public/source binding; no witness can be licensed."""


def _require(condition, detail):
    if not condition:
        raise AssertionWitnessError(detail)


def _focal_atoms(case, plan, candidate):
    public_plan(case, plan)
    query, marker, fill = case["query"], case["focal_marker"], candidate["fill"]
    _require(isinstance(fill, str) and fill.strip() and not MASK.search(fill), "A literal nonempty unmasked fill is required")
    at = query.index(marker)
    completed = query[:at] + fill + query[at + len(marker):]
    if MASK.search(completed):
        return completed, [], ["SECONDARY_QUERY_MASK_NOT_COMPLETED"]
    delta = len(fill) - len(marker)
    scope = next((s for s in sentences(query) if s["start"] <= at and at + len(marker) <= s["end"]), None)
    _require(scope is not None, "Focal marker has no literal source sentence")
    required, issues = [], []
    for atom in plan["atoms"]:
        if marker not in atom["text"] or atom.get("required") is False:
            continue
        spans = atom.get("query_spans", [])
        if not spans and "start" in atom and "end" in atom:
            spans = [dict(start=atom["start"], end=atom["end"], text=atom.get("source_quote", atom["text"]))]
        if len(spans) != 1:
            issues.append("FOCAL_ATOM_NOT_ONE_LITERAL_SPAN: " + atom["id"])
            continue
        span = spans[0]
        a, b = span["start"], span["end"]
        literal = lambda text: " ".join(text.split()).casefold()
        if (literal(atom["text"]) != literal(query[a:b]) or span["text"] != query[a:b]
                or not a <= at < at + len(marker) <= b
                or atom.get("kind", "proposition") != "proposition"):
            issues.append("FOCAL_ATOM_NOT_LITERAL_COMPLETE_ASSERTION: " + atom["id"])
            continue
        if (a > scope["start"] or b < scope["end"] or _open_reporting_context(query[:a])):
            issues.append("FOCAL_ATOM_DROPS_OUTER_SENTENCE_SCOPE: " + atom["id"])
            continue
        text = completed[a:b + delta]
        required.append(dict(id=atom["id"], original_atom_sha256=digest(atom),
            original_atom_text=atom["text"], raw_public_span_used_without_rephrasing=True,
            original_span=dict(start=a, end=b, text=query[a:b]),
            completed_span=dict(start=a, end=b + delta, text=text),
            matcher_atom=dict(id=atom["id"], text=text, kind="proposition", required=True,
                query_spans=[dict(start=a, end=b + delta, text=text)])))
    if not required:
        issues.append("NO_REQUIRED_LITERAL_FOCAL_ATOMS")
    return completed, required, issues


def _owned_units(case, candidate, source_pages, corpus, policy, source_index, parse):
    _require(type(policy) is SourcePolicy and policy.corpus is corpus, "Concrete complete SourcePolicy/corpus required")
    _require(public_case(policy.case) == case, "SourcePolicy belongs to another public case")
    _require(isinstance(source_index, Mapping) and source_index is policy.bound_pages,
             "Use the complete admitted SourcePolicy.bound_pages index, not a candidate-only substitute")
    _require(isinstance(source_pages, Mapping) and source_pages, "Candidate-own admitted source pages required")
    refs = candidate["sources"]
    _require(isinstance(refs, list) and refs and set(source_pages) == {r["canonical_page_id"] for r in refs},
             "Candidate page set differs from its own cited sources")
    a, b = candidate["source_span"]
    wording = candidate["source_wording"]
    _require(type(a) is int and type(b) is int and 0 <= a < b and isinstance(wording, str) and wording,
             "Exact candidate source span/wording required")
    positions = {p["id"]: i for i, p in enumerate(corpus.pages)}
    units, issues, seen = [], [], set()
    for pid, page in source_pages.items():
        pi = positions.get(pid)
        _require(pi is not None and page == corpus.pages[pi] == source_index.get(pid), "Candidate page differs from complete source binding")
        _require(digest(page["text"]) == page["source_sha256"] and page["text"][a:b] == wording,
                 "Candidate wording/page hash does not replay")
        for ref in (r for r in refs if r["canonical_page_id"] == pid):
            _require({"canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256", "corpus"} <= ref.keys(),
                     "Candidate citation lacks exact metadata")
            clean = policy.citation(pi, ref["start"], ref["end"])
            _require(all(clean.get(k) == v for k, v in ref.items()), "Candidate citation does not replay exactly")
            _require(ref["start"] <= a < b <= ref["end"], "Candidate literal extent is outside its own cited source")
        own_refs = [r for r in refs if r["canonical_page_id"] == pid]
        for parent in sentences(page["text"]):
            if not any(r["start"] <= parent["start"] and parent["end"] <= r["end"] for r in own_refs):
                continue
            if not parent["start"] <= a < b <= parent["end"]:
                continue
            if MASK.search(parent["text"]):
                issues.append("OPAQUE_OWN_SOURCE_UNIT: " + pid)
                continue
            parent_ref = policy.citation(pi, parent["start"], parent["end"])
            options = [parent]
            for child in source_sentences.recover(page, parent, parse):
                proof = deepcopy(child["source_boundary"])
                proof["parent_policy_citation"] = deepcopy(parent_ref)
                options.append(dict(child, source_boundary=proof))
            for unit in options:
                if not unit["start"] <= a < b <= unit["end"]:
                    continue
                key = (pid, unit["start"], unit["end"])
                if key in seen:
                    continue
                seen.add(key)
                policy.citation(pi, unit["start"], unit["end"])
                units.append((page, deepcopy(unit)))
    if not units:
        issues.append("NO_COMPLETE_CANDIDATE_OWN_CITED_SOURCE_UNIT")
    return units, sorted(set(issues))


def _unmodeled_source_attachment(row, unit, parse):
    # A verbal preposition attached to a matched predicate is qualification,
    # not an extra independent assertion. Do not silently drop its provenance.
    represented = {m["source_predicate_proof"]["start"] for group in row.get("comparisons", [])
        for m in group if m.get("direction") in {"SUPPORT", "COUNTER"} and m.get("source_predicate_proof")}
    return [dict(text=t.text, start=unit["start"] + t.idx, end=unit["start"] + t.idx + len(t),
                 dependency=t.dep_, head=t.head.text)
        for t in parse(unit["text"]) if t.pos_ == "VERB" and t.dep_ == "prep" and t.idx not in represented]


def _assess(case, plan, reading, candidate, source_pages, corpus, source_policy, source_index):
    case = public_case(case)
    _require(case["task"] == "redaction", "Red public case required")
    _require(reading["id"] == candidate["reading_id"], "Candidate/reading binding changed")
    before = digest([case, plan, reading, candidate, source_pages])
    completed, required, issues = _focal_atoms(case, plan, candidate)
    output = dict(version=VERSION, candidate_id=candidate["id"], reading_id=reading["id"],
        matcher_version=assertion_matching.VERSION, source_boundary_version=source_sentences.VERSION,
        original_query_sha256=digest(case["query"]), completed_query_sha256=digest(completed),
        input_binding=dict(public_case_sha256=digest(case), plan_sha256=digest(plan),
            reading_sha256=digest(reading), candidate_sha256=digest(candidate),
            candidate_source_pages_sha256=digest(source_pages)),
        completed_query=completed, fill=candidate["fill"], requirements=required,
        issues=issues, signed_counters=[], diagnostics=[], source_units=[],
        direction="UNRESOLVED", strong_support=False, positive_support_complete=False,
        construction_authorized=False, grammar_or_source_kind_or_joint_fit_certified=False,
        recommendation_authorized=False, native_decision_modified=False,
        world_truth_certified=False, actual_inner_event_established=False,
        cross_atom_or_event_join_certified=False, candidate_origins_expanded=False,
        all_pool_counter_claim=False, source_text_modified=False, api_calls=0, native_runs=0,
        scope="COMPLETE_LITERAL_FOCAL_ASSERTION_SOURCE_ASCRIPTION_ONLY")
    if not required or issues:
        return output
    completed_case = dict(case, task="hypothesis", query=completed, focal_marker="")
    # Admission depends on unchanged origin/corpus/cutoff, not H/Red task labels.
    # Copy the complete policy; never build a candidate-only whole-document veto.
    _require(type(source_policy) is SourcePolicy and public_case(source_policy.case) == case,
             "Complete original Red SourcePolicy required")
    adapter_policy = copy(source_policy)
    adapter_policy.case = public_case(completed_case)
    matcher = assertion_matching.MatcherCase(completed_case, source_index,
        corpus=corpus, source_policy=adapter_policy)
    output["matcher_compatibility_view"] = dict(task="hypothesis", original_task="redaction",
        literal_focal_substitution_only=True, original_packet_changed=False,
        source_policy_admission_fields_unchanged=True, complete_source_policy_retained=True)
    units, source_issues = _owned_units(case, candidate, source_pages, corpus, source_policy,
                                       source_index, matcher.baseline.engine.parse)
    output["issues"].extend(source_issues)
    output["source_units"] = [dict(page_id=p["id"], page_sha256=p["source_sha256"], unit=deepcopy(u)) for p,u in units]
    for requirement in required:
        supports, counters, appraisals = [], [], []
        for page, unit in units:
            try:
                row = matcher.supplement(requirement["matcher_atom"], page, unit)
            except (ValueError, KeyError, TypeError) as error:
                output["issues"].append("ASSERTION_MATCHING_FAILED: " + str(error))
                continue
            row = deepcopy(row)
            if unit.get("source_boundary"):
                row["source_boundary_certificate"] = deepcopy(unit["source_boundary"])
            appraisals.append(row)
            attachment = _unmodeled_source_attachment(row, unit, matcher.baseline.engine.parse)
            if attachment:
                output["issues"].append("UNMODELED_SOURCE_VERBAL_PREPOSITION_ATTACHMENT")
                output["diagnostics"].append(dict(requirement_id=requirement["id"],
                    unmodeled_source_attachment=attachment, unchanged_matcher_appraisal=deepcopy(row)))
            signed = row.get("complete_required_frames") is True
            if (signed and not attachment and row.get("direction") == "SUPPORT" and not row.get("source_identity_only")
                    and row.get("focal_support_certified") is not False):
                supports.append(row)
            if signed and not attachment and row.get("direction") in {"COUNTER", "CONFLICTED"}:
                counters.append(row)
            if row.get("direction") not in {"SUPPORT", "COUNTER", "CONFLICTED"}:
                output["diagnostics"].append(dict(requirement_id=requirement["id"], appraisal=row))
        requirement.update(positive_witnesses=supports, signed_counters=counters,
            appraisals=appraisals, supported=bool(supports))
        output["signed_counters"].extend(dict(requirement_id=requirement["id"], appraisal=r) for r in counters)
    positive = bool(required) and all(r["supported"] for r in required)
    opposed = bool(output["signed_counters"])
    output.update(positive_support_complete=positive,
        strong_support=positive and not opposed and not output["issues"],
        direction="CONFLICTED" if positive and opposed else "COUNTER" if opposed else
            "SUPPORT" if positive and not output["issues"] else "PARTIAL" if any(r["supported"] for r in required) else "UNRESOLVED")
    _require(digest([case, plan, reading, candidate, source_pages]) == before, "Public/source input changed during appraisal")
    return output


def assess(case, plan, reading, candidate, *, source_pages, corpus, source_policy, source_index):
    """Return a sidecar or fail closed, with no construction/recommendation power.

    source_index must be the already-complete source_policy.bound_pages mapping.
    No source-index loading, fallback source search, ranking or gate calls occur.
    """
    try:
        with offline():
            return _assess(case, plan, reading, candidate, source_pages, corpus, source_policy, source_index)
    except AssertionWitnessError:
        raise
    except (ValueError, KeyError, TypeError, AttributeError, StopIteration) as error:
        raise AssertionWitnessError("Invalid Red assertion witness binding: " + str(error)) from error
