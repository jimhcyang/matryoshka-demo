"""Resumable narrative runs: public planning, deterministic execution, separate assessment."""
from copy import deepcopy
import hashlib
from pathlib import Path
import time
import traceback

from matryoshka_demo.io import digest
from matryoshka_next import workflow as native
from .contracts import engine_case, public_query
from .planning import validate_plan
from .guards import require_headroom, remaining_seconds

VERSION = "narrative-local-execution/3"
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "experiments/narrative_demo"


def code_pins():
    pins = native.code_pins()
    for name in ("__init__.py", "contracts.py", "api.py", "planning.py", "workflow.py", "decisions.py",
                 "matching.py", "assertion_matching.py", "nonfactive_content.py", "nonfactive_content_v52.py",
                 "nonfactive_content_v53.py", "retrieval.py", "construction.py", "guards.py",
                 "nominal_bindings.py", "prename_role_binding.py", "proper_nominal_compounds.py", "source_sentences.py", "source_nominals.py",
                 "redaction_selection.py", "redaction_counters.py", "context_relevance.py", "nominal_realization.py",
                 "certificates.py", "bundles.py", "discovery_diagnostics.py", "qualified_account_bindings.py", "focal_retrieval.py", "fit_scores.py", "candidate_salience.py", "role_context.py"):
        p = ROOT / "matryoshka_narrative" / name
        pins[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return pins


def configuration(method, passage_budget, document_budget, construction_pages, draft_budget,
                  discovery_profile=None,selection_profile=None):
    value = dict(method=method, retrieval_passage_budget=passage_budget,
        retrieval_document_budget=document_budget, construction_pages=construction_pages,
        completed_drafts_per_reading=draft_budget, top_k=5)
    if discovery_profile is not None:
        value["discovery_profile"]=deepcopy(discovery_profile)
    if selection_profile is not None:
        value["selection_profile"]=deepcopy(selection_profile)
    return value


def validate_packet(packet, case, base, selected, *, pins, binding, environment, settings):
    """Replay the full cache contract against independently supplied expectations."""
    adapted = engine_case(case)
    validate_plan(base, adapted)
    plan = deepcopy(base)
    if case["task"] == "redaction":
        from matryoshka_next.readings import validate_readings
        validate_readings(selected, adapted)
        plan["readings_packet"] = deepcopy(selected)
    elif selected is not None:
        raise ValueError("Mosaic/Hypothesis cannot acquire slot readings")
    expected = dict(version=VERSION, case=adapted, public_case=case, public_task=case["task"],
        plan=plan, code_pins=pins, binding=binding, environment=environment,
        query_sha256=digest(adapted["query"]), configuration=settings,
        compatibility=dict(version="public-mosaic-legacy-engine/1", public_task=case["task"],
            engine_task=adapted["task"], frozen_outputs_modified=False),
        query_only_inference=True, api_calls=0, grades_read=False, answers_read=False)
    if any(packet.get(key) != value for key, value in expected.items()):
        raise ValueError("Cached native packet differs from trusted execution bindings")
    if not isinstance(packet.get("result"), dict) or packet.get("native_checksum") != digest(packet["result"]):
        raise ValueError("Cached native result checksum changed")
    if (packet["result"].get("query_sha256") != digest(adapted["query"])
            or packet["result"].get("provided_plan_sha256") != digest(plan)):
        raise ValueError("Cached result query/plan integrity changed")
    return packet


def _write(path, value, *, immutable=False):
    require_headroom(path)
    return (native.put_immutable if immutable else native.put)(path, value)


def _completion(target, packet, key):
    return dict(version="narrative-native-completion/1", execution_key=key,
        packet_sha256=hashlib.sha256(Path(target).read_bytes()).hexdigest(),
        packet_digest=digest(packet), native_checksum=packet["native_checksum"])


def inspection_artifacts(packet):
    """Wire approved adapters after sealing; never rewrite native judgments."""
    from . import certificates, bundles
    if packet["public_task"] == "redaction":
        values = [certificates.adapt_redaction_candidate(packet, candidate["id"])
            for reading in packet["result"]["readings"] for candidate in reading["candidates"]]
        return dict(version="narrative-saved-decision-adapters/1", native_packet_sha256=digest(packet),
            certificates=values, factual_judgments_modified=False)
    certificate = certificates.adapt_native_assertions(packet)
    output = dict(version="narrative-saved-decision-adapters/1", native_packet_sha256=digest(packet),
        certificates=[certificate], factual_judgments_modified=False)
    if packet["public_task"] == "mosaic":
        pool = bundles.native_pool(packet)
        output["mosaic_bundle"] = bundles.select_bundle(**pool)
    return output


class Session(native.Session):
    def __init__(self, *args, **kwargs):
        if code_pins() != _IMPORT_PINS:
            raise RuntimeError("Inference files changed after import; start a fresh worker")
        super().__init__(*args, **kwargs)
        self.narrative_pins = code_pins()

    def execute(self, case, base, *, readings_packet=None, method="current_hierarchy",
                passage_budget=80, document_budget=40, construction_pages=16, draft_budget=24,
                discovery_profile=None,selection_profile=None):
        require_headroom(OUTPUT)
        remaining_seconds(new_work=True)
        if code_pins() != self.narrative_pins:
            raise RuntimeError("Inference changed in this worker; restart before another case")
        public_query(case)
        adapted = engine_case(case)
        validate_plan(base, adapted)
        pins = code_pins()
        started = time.perf_counter()
        context = self.context(adapted["corpus"])
        opened = time.perf_counter() - started
        plan = deepcopy(base)
        if adapted["task"] == "redaction":
            from matryoshka_next.readings import validate_readings
            if readings_packet is None:
                raise ValueError("A saved, explicit Redaction reading packet is required")
            validate_readings(readings_packet, adapted)
            plan["readings_packet"] = deepcopy(readings_packet)
        elif readings_packet is not None:
            raise ValueError("Mosaic/Hypothesis cannot acquire slot readings")
        from .retrieval import retrieve
        started = time.perf_counter()
        retrieval = retrieve(context.corpus, adapted, plan, method=method,
            passage_budget=passage_budget, document_budget=document_budget,
            source_index=context.source_index,discovery_profile=discovery_profile)
        retrieval_seconds = time.perf_counter() - started
        started = time.perf_counter()
        if adapted["task"] == "redaction":
            from .construction import construct
            result = construct(adapted, plan, retrieval, top_k=5, source_index=context.source_index,
                passage_budget=construction_pages, draft_budget=draft_budget,selection_profile=selection_profile)
        else:
            from .decisions import execute
            result = execute(adapted, plan, retrieval, passage_budget=passage_budget,
                source_index=context.source_index)
        packet = dict(case=adapted, plan=plan, result=result, retrieval=deepcopy(retrieval["receipt"]),
            native_checksum=digest(result),
            timings=dict(context_open_seconds=opened, retrieval_seconds=retrieval_seconds,
                task_seconds=time.perf_counter() - started),
            binding=deepcopy(self.refs["index_refs"][adapted["corpus"]]),
            environment=deepcopy(self.environment), query_sha256=digest(adapted["query"]),
            configuration=configuration(method, passage_budget, document_budget, construction_pages, draft_budget,
                discovery_profile,selection_profile),
            query_only_inference=True, api_calls=0, grades_read=False, answers_read=False)
        if pins != code_pins():
            raise RuntimeError("Narrative implementation changed during execution; no result sealed")
        from matryoshka_demo.runner_v2 import environment_binding
        if environment_binding(self.root) != self.environment:
            raise RuntimeError("Execution language resources changed during execution")
        packet.update(version=VERSION, public_task=case["task"], public_case=deepcopy(case),
            compatibility=dict(version="public-mosaic-legacy-engine/1", public_task=case["task"],
                engine_task=adapted["task"], frozen_outputs_modified=False),
            code_pins=pins, source_aware_development=True,
            outcome_informed_showcase_candidate=True, benchmark_accuracy_claimed=False)
        return packet


def plan_case(case, *, api_root=None, model="gpt-6.1-sol"):
    from .planning import parse
    api_root = api_root or OUTPUT / "api"
    from .planning import VERSION as planning_version
    path = OUTPUT / "planning" / (case["case_id"] + "__" + digest([case, planning_version, model])[:16] + ".json")
    if path.exists():
        saved = native.read(path)
        if (saved["public_query"] != public_query(case) or saved.get("version") != planning_version
                or saved.get("public_task") != case["task"]
                or saved.get("compatibility_task") != engine_case(case)["task"]):
            raise ValueError("Saved planning question changed")
        validate_plan(saved["native_plan"], engine_case(case))
        return saved
    remaining_seconds(new_work=True)
    require_headroom(path)
    try:
        saved = parse(case, api_root, model=model)
    except ValueError as error:
        if model == "gpt-6-luna" or str(error) != "Incomplete provider response":
            raise
        # A truncated provider response is never accepted as a plan. A single
        # capacity fallback sees the identical public query and strict schema.
        saved = parse(case, api_root, model="gpt-6-luna")
        saved["provider_retry"] = dict(requested_model=model, actual_model="gpt-6-luna",
            reason="INCOMPLETE_PROVIDER_RESPONSE", identical_public_query=True,
            same_contract=True, retained_paid_attempts=True, maximum_fallbacks=1)
    _write(path, saved, immutable=True)
    return saved


def run_cases(cases, *, api_root=None, reading_mode="model", method="current_hierarchy",
              passage_budget=80, document_budget=40, construction_pages=16, draft_budget=24,
              discovery_profile=None, selection_profile=None):
    from .planning import model_readings
    from matryoshka_next import readings
    api_root = api_root or OUTPUT / "api"
    summaries = []
    with Session() as session:
        for case in cases:
            start = time.perf_counter()
            try:
                remaining_seconds(new_work=True)
                if code_pins() != session.narrative_pins:
                    raise RuntimeError("Inference changed in this worker; restart before planning another case")
                saved = plan_case(case, api_root=api_root)
                selected = None
                if case["task"] == "redaction":
                    ref = OUTPUT / "readings" / (digest(dict(case=case, mode=reading_mode)) + ".json")
                    if ref.exists():
                        selected = native.read(ref)["packet"]
                        readings.validate_readings(selected, engine_case(case))
                    else:
                        if reading_mode == "model":
                            selected, audit = model_readings(case, api_root)
                        elif reading_mode == "local":
                            selected, audit = readings.compile_readings(engine_case(case)), dict(api_calls=0)
                        else:
                            raise ValueError("Use an explicit model or local reading control")
                        _write(ref, dict(packet=selected, audit=audit), immutable=True)
                identity = dict(case=case, plan=saved, reading=selected, method=method,
                    passage_budget=passage_budget, document_budget=document_budget,
                    construction_pages=construction_pages, draft_budget=draft_budget, code=code_pins())
                if discovery_profile is not None:
                    identity["discovery_profile"] = deepcopy(discovery_profile)
                if selection_profile is not None:
                    identity["selection_profile"] = deepcopy(selection_profile)
                key = digest(identity)
                target = OUTPUT / "runs" / key / "native.json.gz"
                completion = target.with_name("completion.json")
                expected = dict(pins=code_pins(), binding=session.refs["index_refs"][case["corpus"]],
                    environment=session.environment, settings=configuration(method, passage_budget,
                        document_budget, construction_pages, draft_budget, discovery_profile, selection_profile))
                if target.exists():
                    # Opening verifies actual registry/index/source bytes, not
                    # just equality with a cached copy of their references.
                    session.context(case["corpus"])
                    packet = native.read(target)
                    validate_packet(packet, case, saved["native_plan"], selected, **expected)
                    if not completion.exists() or native.read(completion) != _completion(target, packet, key):
                        raise ValueError("Cached packet completion seal is absent or changed")
                    cached = True
                else:
                    packet = session.execute(case, saved["native_plan"], readings_packet=selected,
                        method=method, passage_budget=passage_budget, document_budget=document_budget,
                        construction_pages=construction_pages, draft_budget=draft_budget,
                        discovery_profile=discovery_profile, selection_profile=selection_profile)
                    validate_packet(packet, case, saved["native_plan"], selected, **expected)
                    _write(target, packet, immutable=True)
                    _write(completion, _completion(target, packet, key), immutable=True)
                    cached = False
                adapter_ref = target.with_name("decision_adapters.json")
                _write(adapter_ref, inspection_artifacts(packet), immutable=True)
                atoms = packet["result"].get("atoms", [])
                summary = dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
                    path=str(target.relative_to(ROOT)), status=packet["result"].get("status"),
                    atoms=[dict(id=a["id"], text=a["text"], status=a["status"],
                        evidence=len(a.get("evidence", []))) for a in atoms],
                    readings=[dict(id=r["reading"]["id"], candidates=[dict(fill=c["fill"],
                        support=c.get("support_assessment")) for c in r["candidates"]])
                        for r in packet["result"].get("readings", [])],
                    cached=cached, timings=packet["timings"],
                    decision_adapters_ref=str(adapter_ref.relative_to(ROOT)))
            except Exception as error:
                summary = dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
                    status="ERROR", error_type=type(error).__name__, error=str(error),
                    diagnostic_traceback=traceback.format_exc())
            summary["wall_seconds"] = time.perf_counter() - start
            summaries.append(summary)
            _write(OUTPUT / "progress.json", dict(version=VERSION, completed=len(summaries),
                requested=len(cases), cases=summaries))
            print(case["case_id"], summary["status"], summary.get("error", ""), flush=True)
            if code_pins() != session.narrative_pins:
                break
    return summaries


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("cases", type=Path)
    parser.add_argument("--reading-mode", choices=("model", "local"), default="model")
    parser.add_argument("--method", default="current_hierarchy")
    parser.add_argument("--passage-budget", type=int, default=80)
    args = parser.parse_args()
    value = native.read(args.cases)
    cases = value.get("cases", []) if isinstance(value, dict) else value
    run_cases(cases, reading_mode=args.reading_mode, method=args.method, passage_budget=args.passage_budget)


_IMPORT_PINS = code_pins()


if __name__ == "__main__":
    main()
