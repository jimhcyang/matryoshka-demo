"""Resumable narrative runs: public planning, deterministic execution, separate assessment."""
from copy import deepcopy
import hashlib
from pathlib import Path
import time
import traceback

from matryoshka_demo.io import digest
from matryoshka_next import workflow as native
from .contracts import engine_case, public_query
from .planning import validate_plan
from .guards import require_headroom, remaining_seconds
from matryoshka_demo.source_view_policy import (
    STRICT_PRIOR, apply_source_view, descriptor, require_policy, packet_policy)

VERSION = "narrative-local-execution/4"
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "experiments/narrative_demo"


def code_pins():
    pins = native.code_pins()
    for name in ("__init__.py", "contracts.py", "api.py", "planning.py", "workflow.py", "decisions.py",
                 "matching.py", "query_analysis.py", "assertion_matching.py", "clause_semantics.py", "exact_matrix.py", "hypothesis_stances.py", "nonfactive_content.py", "nonfactive_content_v52.py",
                 "nonfactive_content_v53.py", "retrieval.py", "inspection.py", "construction.py", "guards.py", "input_realization.py", "proposal_pool.py",
                 "nominal_bindings.py", "prename_role_binding.py", "reverse_role_bindings.py", "proper_nominal_compounds.py", "source_sentences.py", "source_qualification.py", "source_nominals.py", "property_context.py", "excerpts.py",
                 "redaction_selection.py", "opportunity_allocation.py", "redaction_counters.py", "context_relevance.py", "context_priority.py", "nominal_realization.py", "lexical_realization.py", "controller_role.py",
                 "certificates.py", "bundles.py", "discovery_diagnostics.py", "qualified_account_bindings.py", "focal_retrieval.py", "fit_scores.py", "candidate_salience.py", "visible_query_labels.py", "visible_apposition_context.py", "visible_apposition_order.py", "role_context.py", "role_kind_context.py", "literal_reference_retrieval.py", "nominal_case_bindings.py", "traces.py", "terminal_scores.py", "candidate_identity.py", "presentation.py", "server.py"):
        p = ROOT / "matryoshka_narrative" / name
        pins[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return pins


def configuration(method, passage_budget, document_budget, construction_pages, draft_budget,
                  discovery_profile=None,selection_profile=None, source_view_policy=STRICT_PRIOR,
                  terminal_ranking=None):
    require_policy(source_view_policy)
    if terminal_ranking not in {None, "evidence_fit_v2", "evidence_fit_v3", "evidence_fit_v4", "evidence_fit_v5", "evidence_fit_v6"}:
        raise ValueError("Unknown optional terminal ranking")
    value = dict(method=method, retrieval_passage_budget=passage_budget,
        retrieval_document_budget=document_budget, construction_pages=construction_pages,
        completed_drafts_per_reading=draft_budget, top_k=5,
        source_view_policy=descriptor(source_view_policy), terminal_ranking=terminal_ranking)
    if discovery_profile is not None:
        value["discovery_profile"]=deepcopy(discovery_profile)
    if selection_profile is not None:
        value["selection_profile"]=deepcopy(selection_profile)
    return value


def validate_packet(packet, case, base, selected, *, pins, binding, environment, settings):
    """Replay the full cache contract against independently supplied expectations."""
    adapted = engine_case(case)
    validate_plan(base, adapted)
    plan = deepcopy(base)
    if case["task"] == "redaction":
        from matryoshka_next.readings import validate_readings
        validate_readings(selected, adapted)
        plan["readings_packet"] = deepcopy(selected)
    elif selected is not None:
        raise ValueError("Mosaic/Hypothesis cannot acquire slot readings")
    expected = dict(version=VERSION, case=adapted, public_case=case, public_task=case["task"],
        plan=plan, code_pins=pins, binding=binding, environment=environment,
        query_sha256=digest(adapted["query"]), configuration=settings,
        compatibility=dict(version="public-mosaic-legacy-engine/1", public_task=case["task"],
            engine_task=adapted["task"], frozen_outputs_modified=False),
        query_only_inference=True, api_calls=0, grades_read=False, answers_read=False)
    if any(packet.get(key) != value for key, value in expected.items()):
        raise ValueError("Cached native packet differs from trusted execution bindings")
    if not isinstance(packet.get("result"), dict) or packet.get("native_checksum") != digest(packet["result"]):
        raise ValueError("Cached native result checksum changed")
    if (packet["result"].get("query_sha256") != digest(adapted["query"])
            or packet["result"].get("provided_plan_sha256") != digest(plan)):
        raise ValueError("Cached result query/plan integrity changed")
    packet_policy(packet)
    if packet.get("retrieval", {}).get("source_view_policy") != settings["source_view_policy"]:
        raise ValueError("Cached retrieval source policy differs from trusted execution configuration")
    return packet


def _write(path, value, *, immutable=False):
    require_headroom(path)
    return (native.put_immutable if immutable else native.put)(path, value)


def _completion(target, packet, key):
    return dict(version="narrative-native-completion/1", execution_key=key,
        packet_sha256=hashlib.sha256(Path(target).read_bytes()).hexdigest(),
        packet_digest=digest(packet), native_checksum=packet["native_checksum"])


def inspection_artifacts(packet):
    """Wire approved adapters after sealing; never rewrite native judgments."""
    from . import certificates, bundles
    if packet["public_task"] == "redaction":
        values = [certificates.adapt_redaction_candidate(packet, candidate["id"])
            for reading in packet["result"]["readings"] for candidate in reading["candidates"]]
        return dict(version="narrative-saved-decision-adapters/1", native_packet_sha256=digest(packet),
            certificates=values, factual_judgments_modified=False)
    certificate = certificates.adapt_native_assertions(packet)
    output = dict(version="narrative-saved-decision-adapters/1", native_packet_sha256=digest(packet),
        certificates=[certificate], factual_judgments_modified=False)
    if packet["public_task"] == "mosaic":
        pool = bundles.native_pool(packet)
        output["mosaic_bundle"] = bundles.select_bundle(**pool)
    return output


TERMINAL_STAGE_PINS = frozenset({"matryoshka_narrative/workflow.py",
    "matryoshka_narrative/terminal_scores.py"})


def _terminal_candidate(candidate):
    value = deepcopy(candidate)
    for name in ("rank", "terminal_scorecard"):
        value.pop(name, None)
    if isinstance(value.get("ranking"), dict):
        for name in ("terminal_scoring_version", "canonical_order"):
            value["ranking"].pop(name, None)
    return value


def _restore_terminal_prefix(result):
    """Recover only saved choices from the postfiltered pool, never nominations."""
    value = deepcopy(result)
    value.pop("terminal_scores", None)
    if value.get("task") != "redaction":
        return value
    pool = value.get("assessed_candidates")
    saved = value.get("pre_terminal_candidate_order")
    if not isinstance(pool, list) or not isinstance(saved, list):
        raise ValueError("A sealed viable pool and explicit pre-terminal choices are required")
    by_id = {}
    for candidate in pool:
        cid = candidate["id"]
        if cid in by_id or candidate.get("local_decision", {}).get("status") not in {
                "evidence_backed_suggestion", "partial_grounding", "exploratory_contextual"}:
            raise ValueError("Ambiguous or nonviable terminal-prefix candidate")
        by_id[cid] = _terminal_candidate(candidate)
    branches = value.get("readings", [])
    rids = [r["reading"]["id"] for r in branches]
    if (len(set(rids)) != len(rids) or [r["reading_id"] for r in saved] != rids
            or any(c.get("reading_id") not in rids for c in pool)):
        raise ValueError("Terminal-prefix reading identities changed")
    flat = [c for row in branches for c in row["candidates"]]
    if value.get("candidates") != flat:
        raise ValueError("Terminal displayed candidates differ from their reading branches")
    for row, selection in zip(branches, saved):
        rid = row["reading"]["id"]
        for candidate in row["candidates"]:
            if (candidate["id"] not in by_id or by_id[candidate["id"]].get("reading_id") != rid
                    or _terminal_candidate(candidate) != by_id[candidate["id"]]):
                raise ValueError("Displayed candidate differs from its sealed viable pool")
        ids = selection["candidate_ids"]
        if (not isinstance(ids, list) or len(ids) > 5 or len(set(ids)) != len(ids)
                or any(cid not in by_id or by_id[cid].get("reading_id") != rid for cid in ids)):
            raise ValueError("Pre-terminal selection is absent, duplicate or outside its viable reading pool")
        row["candidates"] = [by_id[cid] for cid in ids]
        for rank, candidate in enumerate(row["candidates"], 1):
            candidate["rank"] = rank
    value["assessed_candidates"] = [by_id[c["id"]] for c in pool]
    value["candidates"] = [c for row in branches for c in row["candidates"]]
    return value


def _terminal_source_replay(packet, context):
    from matryoshka_next.facts import SourcePolicy
    policy = SourcePolicy(context.corpus, packet["case"], context.source_index)
    inspected = packet["result"]["inspected_page_ids"]
    if len(set(inspected)) != len(inspected):
        raise ValueError("Duplicate source pages in terminal prefix")
    for pid in inspected:
        pi = context.corpus.page_index.get(pid)
        if pi is None or not policy.allowed(pi):
            raise ValueError("Terminal prefix inspected source is missing or ineligible")
    fields = ("canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256")
    checked = set()
    def replay(value):
        if isinstance(value, dict):
            if all(k in value for k in fields):
                key = digest({k:value[k] for k in fields})
                if key not in checked:
                    pid = value["canonical_page_id"]
                    if pid not in inspected:
                        raise ValueError("Terminal evidence is outside the sealed inspected pool")
                    pi = context.corpus.page_index[pid]
                    actual = policy.citation(pi, value["start"], value["end"])
                    if any(actual[k] != value[k] for k in fields):
                        raise ValueError("Terminal source hash, span or metadata does not replay")
                    checked.add(key)
            for child in value.values():
                replay(child)
        elif isinstance(value, (list, tuple)):
            for child in value:
                replay(child)
    replay(packet["result"].get("assessed_candidates", []))
    replay(packet["result"].get("atoms", []))
    return dict(status="PASS", inspected_pages=len(inspected), unique_bound_quotes=len(checked),
        source_view_policy=descriptor(packet_policy(packet)), gates_reexecuted=False,
        sealed_native_sufficiency_decisions_reused=True)


class Session(native.Session):
    def __init__(self, *args, **kwargs):
        if code_pins() != _IMPORT_PINS:
            raise RuntimeError("Inference files changed after import; start a fresh worker")
        super().__init__(*args, **kwargs)
        self.narrative_pins = code_pins()

    def execute(self, case, base, *, readings_packet=None, method="current_hierarchy",
                passage_budget=80, document_budget=40, construction_pages=16, draft_budget=24,
                discovery_profile=None,selection_profile=None, source_view_policy=STRICT_PRIOR,
                terminal_ranking=None):
        settings = configuration(method, passage_budget, document_budget, construction_pages,
            draft_budget, discovery_profile, selection_profile, source_view_policy, terminal_ranking)
        require_headroom(OUTPUT)
        remaining_seconds(new_work=True)
        if code_pins() != self.narrative_pins:
            raise RuntimeError("Inference changed in this worker; restart before another case")
        public_query(case)
        adapted = engine_case(case)
        validate_plan(base, adapted)
        pins = code_pins()
        started = time.perf_counter()
        context = apply_source_view(self.context(adapted["corpus"]), source_view_policy)
        corpus = context.corpus
        opened = time.perf_counter() - started
        plan = deepcopy(base)
        if adapted["task"] == "redaction":
            from matryoshka_next.readings import validate_readings
            if readings_packet is None:
                raise ValueError("A saved, explicit Redaction reading packet is required")
            validate_readings(readings_packet, adapted)
            plan["readings_packet"] = deepcopy(readings_packet)
        elif readings_packet is not None:
            raise ValueError("Mosaic/Hypothesis cannot acquire slot readings")
        from .retrieval import retrieve
        started = time.perf_counter()
        retrieval = retrieve(corpus, adapted, plan, method=method,
            passage_budget=passage_budget, document_budget=document_budget,
            source_index=context.source_index,discovery_profile=discovery_profile)
        retrieval_seconds = time.perf_counter() - started
        started = time.perf_counter()
        if adapted["task"] == "redaction":
            from .construction import construct
            result = construct(adapted, plan, retrieval, top_k=5, source_index=context.source_index,
                passage_budget=construction_pages, draft_budget=draft_budget,selection_profile=selection_profile)
        else:
            from .decisions import execute
            result = execute(adapted, plan, retrieval, passage_budget=passage_budget,
                source_index=context.source_index)
        construction_seconds = time.perf_counter() - started
        input_nomination_seconds = 0.
        if adapted["task"] == "redaction":
            from . import input_realization
            from matryoshka_next.construction import SourceParses
            nomination_started = time.perf_counter()
            try:
                result["input_nomination"] = input_realization.nominate(adapted, plan, SourceParses())
            except (ValueError, LookupError, OSError) as error:
                result["input_nomination_failure"] = dict(version=input_realization.VERSION,
                    reason=str(error), error_type=type(error).__name__,
                    corpus_candidates_modified=False, independent_evidence_votes=0)
            input_nomination_seconds = time.perf_counter() - nomination_started
        ranking_seconds = 0.
        if terminal_ranking is not None:
            ranking_started = time.perf_counter()
            original_order = [dict(reading_id=r["reading"]["id"],
                candidate_ids=[c["id"] for c in r["candidates"]]) for r in result.get("readings", [])]
            from .terminal_scores import annotate_result, VERSION as score_version, LEGACY_VERSION, EVIDENCE_VERSION, POINTS_VERSION, SOURCE_POINTS_VERSION
            arithmetic = {"evidence_fit_v3": score_version, "evidence_fit_v2": LEGACY_VERSION,
                "evidence_fit_v4": EVIDENCE_VERSION, "evidence_fit_v5": POINTS_VERSION,
                "evidence_fit_v6": SOURCE_POINTS_VERSION}[terminal_ranking]
            result = annotate_result(result, retrieval["receipt"], rerank=True, top_k=5, plan=plan,
                version=arithmetic)
            if not isinstance(result, dict):
                raise ValueError("Terminal annotation must return the complete result")
            result["pre_terminal_candidate_order"] = original_order
            ranking_seconds = time.perf_counter() - ranking_started
        if adapted["task"] == "redaction":
            from . import proposal_pool
            from matryoshka_next.construction import SourceParses
            result["proposal_pool"] = proposal_pool.build(adapted, plan, result, SourceParses())
        result["source_view_policy"] = descriptor(source_view_policy)
        packet = dict(case=adapted, plan=plan, result=result, retrieval=deepcopy(retrieval["receipt"]),
            native_checksum=digest(result),
            timings=dict(context_open_seconds=opened, retrieval_seconds=retrieval_seconds,
                task_seconds=time.perf_counter() - started,
                construction_seconds=construction_seconds if adapted["task"] == "redaction" else None,
                decision_seconds=construction_seconds if adapted["task"] != "redaction" else None,
                input_nomination_seconds=input_nomination_seconds,
                ranking_seconds=ranking_seconds),
            binding=deepcopy(self.refs["index_refs"][adapted["corpus"]]),
            environment=deepcopy(self.environment), query_sha256=digest(adapted["query"]),
            configuration=settings,
            query_only_inference=True, api_calls=0, grades_read=False, answers_read=False)
        if pins != code_pins():
            raise RuntimeError("Narrative implementation changed during execution; no result sealed")
        from matryoshka_demo.runner_v2 import environment_binding
        if environment_binding(self.root) != self.environment:
            raise RuntimeError("Execution language resources changed during execution")
        packet.update(version=VERSION, public_task=case["task"], public_case=deepcopy(case),
            compatibility=dict(version="public-mosaic-legacy-engine/1", public_task=case["task"],
                engine_task=adapted["task"], frozen_outputs_modified=False),
            code_pins=pins, source_aware_development=True,
            outcome_informed_showcase_candidate=True, benchmark_accuracy_claimed=False)
        return packet

    def replay_terminal(self, parent_ref, *, trusted_parent_pins, terminal_ranking="evidence_fit_v3"):
        """Execute only a terminal stage after validating a sealed native prefix."""
        if terminal_ranking != "evidence_fit_v3":
            raise ValueError("Terminal replay requires explicit v3 configuration")
        require_headroom(OUTPUT)
        pins = code_pins()
        if pins != self.narrative_pins:
            raise RuntimeError("Inference changed; start a fresh terminal worker")
        if (set(pins) != set(trusted_parent_pins) or any(pins[k] != trusted_parent_pins[k]
                for k in pins if k not in TERMINAL_STAGE_PINS)):
            raise ValueError("A nonterminal inference pin changed; prefix replay is forbidden")
        from matryoshka_current.resources import safe_path
        path = safe_path(self.root, parent_ref["path"])
        if hashlib.sha256(path.read_bytes()).hexdigest() != parent_ref["sha256"]:
            raise ValueError("Parent checkpoint byte pin changed")
        parent = native.read(path)
        seal = native.read(path.with_name("completion.json"))
        if seal != _completion(path, parent, seal["execution_key"]):
            raise ValueError("Parent checkpoint completion seal changed")
        case = parent["public_case"]
        base = deepcopy(parent["plan"])
        selected = base.pop("readings_packet", None)
        cfg = parent["configuration"]
        source_policy = packet_policy(parent)
        settings = configuration(cfg["method"], cfg["retrieval_passage_budget"],
            cfg["retrieval_document_budget"], cfg["construction_pages"], cfg["completed_drafts_per_reading"],
            cfg.get("discovery_profile"), cfg.get("selection_profile"), source_policy, cfg.get("terminal_ranking"))
        validate_packet(parent, case, base, selected, pins=trusted_parent_pins,
            binding=self.refs["index_refs"][case["corpus"]], environment=self.environment, settings=settings)
        prefix = _restore_terminal_prefix(parent["result"])
        started = time.perf_counter()
        context = apply_source_view(self.context(case["corpus"]), source_policy)
        audit = _terminal_source_replay(parent, context)
        opened = time.perf_counter() - started
        from .terminal_scores import annotate_result, VERSION as score_version
        started = time.perf_counter()
        result = annotate_result(prefix, parent["retrieval"], rerank=True, top_k=5,
            plan=parent["plan"], version=score_version)
        result["pre_terminal_candidate_order"] = deepcopy(prefix.get("pre_terminal_candidate_order", []))
        if _restore_terminal_prefix(result) != prefix:
            raise ValueError("Terminal execution changed a source, candidate, gate or nonterminal fact")
        packet = deepcopy(parent)
        packet.update(result=result, native_checksum=digest(result), code_pins=pins,
            configuration=dict(settings, terminal_ranking=terminal_ranking),
            timings=dict(context_open_seconds=opened, retrieval_seconds=0.,
                task_seconds=time.perf_counter() - started),
            terminal_stage_replay=dict(version="trusted-native-terminal-prefix/1", parent_checkpoint=deepcopy(parent_ref),
                parent_native_checksum=parent["native_checksum"], prefix_sha256=digest(prefix),
                parent_code_pins=deepcopy(trusted_parent_pins), parent_configuration=deepcopy(cfg),
                parent_timings=deepcopy(parent["timings"]), source_audit=audit,
                reused_stages=["QUERY_PLAN", "READINGS", "RETRIEVAL", "CONSTRUCTION_AND_SUFFICIENCY_GATES"],
                executed_stages=["BOUND_SOURCE_REPLAY", "TERMINAL_SCORING"],
                retrieval_reexecuted=False, constructor_reexecuted=False, whole_fresh_constructor_run=False))
        if code_pins() != pins:
            raise RuntimeError("Inference changed during terminal execution; no packet sealed")
        validate_packet(packet, case, base, selected, pins=pins, binding=packet["binding"],
            environment=self.environment, settings=packet["configuration"])
        return packet


def plan_case(case, *, api_root=None, model="gpt-6.1-sol"):
    from .planning import parse
    api_root = api_root or OUTPUT / "api"
    from .planning import VERSION as planning_version
    path = OUTPUT / "planning" / (case["case_id"] + "__" + digest([case, planning_version, model])[:16] + ".json")
    if path.exists():
        saved = native.read(path)
        if (saved["public_query"] != public_query(case) or saved.get("version") != planning_version
                or saved.get("public_task") != case["task"]
                or saved.get("compatibility_task") != engine_case(case)["task"]):
            raise ValueError("Saved planning question changed")
        validate_plan(saved["native_plan"], engine_case(case))
        return saved
    remaining_seconds(new_work=True)
    require_headroom(path)
    try:
        saved = parse(case, api_root, model=model)
    except ValueError as error:
        if model == "gpt-6-luna" or str(error) != "Incomplete provider response":
            raise
        # A truncated provider response is never accepted as a plan. A single
        # capacity fallback sees the identical public query and strict schema.
        saved = parse(case, api_root, model="gpt-6-luna")
        saved["provider_retry"] = dict(requested_model=model, actual_model="gpt-6-luna",
            reason="INCOMPLETE_PROVIDER_RESPONSE", identical_public_query=True,
            same_contract=True, retained_paid_attempts=True, maximum_fallbacks=1)
    _write(path, saved, immutable=True)
    return saved


def run_cases(cases, *, api_root=None, reading_mode="model", method="current_hierarchy",
              passage_budget=80, document_budget=40, construction_pages=16, draft_budget=24,
              discovery_profile=None, selection_profile=None, source_view_policy=STRICT_PRIOR,
              terminal_ranking=None):
    from .planning import model_readings
    from matryoshka_next import readings
    api_root = api_root or OUTPUT / "api"
    summaries = []
    with Session() as session:
        for case in cases:
            start = time.perf_counter()
            try:
                remaining_seconds(new_work=True)
                if code_pins() != session.narrative_pins:
                    raise RuntimeError("Inference changed in this worker; restart before planning another case")
                saved = plan_case(case, api_root=api_root)
                selected = None
                if case["task"] == "redaction":
                    ref = OUTPUT / "readings" / (digest(dict(case=case, mode=reading_mode)) + ".json")
                    if ref.exists():
                        selected = native.read(ref)["packet"]
                        readings.validate_readings(selected, engine_case(case))
                    else:
                        if reading_mode == "model":
                            selected, audit = model_readings(case, api_root)
                        elif reading_mode == "local":
                            selected, audit = readings.compile_readings(engine_case(case)), dict(api_calls=0)
                        else:
                            raise ValueError("Use an explicit model or local reading control")
                        _write(ref, dict(packet=selected, audit=audit), immutable=True)
                identity = dict(case=case, plan=saved, reading=selected, method=method,
                    passage_budget=passage_budget, document_budget=document_budget,
                    construction_pages=construction_pages, draft_budget=draft_budget, code=code_pins(),
                    source_view_policy=descriptor(source_view_policy), terminal_ranking=terminal_ranking)
                if discovery_profile is not None:
                    identity["discovery_profile"] = deepcopy(discovery_profile)
                if selection_profile is not None:
                    identity["selection_profile"] = deepcopy(selection_profile)
                key = digest(identity)
                target = OUTPUT / "runs" / key / "native.json.gz"
                completion = target.with_name("completion.json")
                expected = dict(pins=code_pins(), binding=session.refs["index_refs"][case["corpus"]],
                    environment=session.environment, settings=configuration(method, passage_budget,
                        document_budget, construction_pages, draft_budget, discovery_profile, selection_profile,
                        source_view_policy, terminal_ranking))
                if target.exists():
                    # Opening verifies actual registry/index/source bytes, not
                    # just equality with a cached copy of their references.
                    session.context(case["corpus"])
                    packet = native.read(target)
                    validate_packet(packet, case, saved["native_plan"], selected, **expected)
                    if not completion.exists() or native.read(completion) != _completion(target, packet, key):
                        raise ValueError("Cached packet completion seal is absent or changed")
                    cached = True
                else:
                    packet = session.execute(case, saved["native_plan"], readings_packet=selected,
                        method=method, passage_budget=passage_budget, document_budget=document_budget,
                        construction_pages=construction_pages, draft_budget=draft_budget,
                        discovery_profile=discovery_profile, selection_profile=selection_profile,
                        source_view_policy=source_view_policy, terminal_ranking=terminal_ranking)
                    validate_packet(packet, case, saved["native_plan"], selected, **expected)
                    _write(target, packet, immutable=True)
                    _write(completion, _completion(target, packet, key), immutable=True)
                    cached = False
                adapter_ref = target.with_name("decision_adapters.json")
                _write(adapter_ref, inspection_artifacts(packet), immutable=True)
                atoms = packet["result"].get("atoms", [])
                summary = dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
                    path=str(target.relative_to(ROOT)), status=packet["result"].get("status"),
                    atoms=[dict(id=a["id"], text=a["text"], status=a["status"],
                        evidence=len(a.get("evidence", []))) for a in atoms],
                    readings=[dict(id=r["reading"]["id"], candidates=[dict(fill=c["fill"],
                        support=c.get("support_assessment")) for c in r["candidates"]])
                        for r in packet["result"].get("readings", [])],
                    cached=cached, timings=packet["timings"],
                    decision_adapters_ref=str(adapter_ref.relative_to(ROOT)))
            except Exception as error:
                summary = dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
                    status="ERROR", error_type=type(error).__name__, error=str(error),
                    diagnostic_traceback=traceback.format_exc())
            summary["wall_seconds"] = time.perf_counter() - start
            summaries.append(summary)
            _write(OUTPUT / "progress.json", dict(version=VERSION, completed=len(summaries),
                requested=len(cases), cases=summaries))
            print(case["case_id"], summary["status"], summary.get("error", ""), flush=True)
            if code_pins() != session.narrative_pins:
                break
    return summaries


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("cases", type=Path)
    parser.add_argument("--reading-mode", choices=("model", "local"), default="model")
    parser.add_argument("--method", default="current_hierarchy")
    parser.add_argument("--passage-budget", type=int, default=80)
    args = parser.parse_args()
    value = native.read(args.cases)
    cases = value.get("cases", []) if isinstance(value, dict) else value
    run_cases(cases, reading_mode=args.reading_mode, method=args.method, passage_budget=args.passage_budget)


_IMPORT_PINS = code_pins()


if __name__ == "__main__":
    main()
