"""Source-local relative accounts, not world entailment or canonical identity.

Two bounded forms: an attributed modal view with a relative topic/reporter,
and a completed descriptive person-relative inside identification advice.
The full raw parent and its qualifiers remain the evidence, not a new sentence.
"""
from copy import deepcopy
from functools import lru_cache
import json
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import qualifiers
from matryoshka_demo_v6.planning import sentences, SECTION
from matryoshka_demo_v61.scope_matching import _layout
from matryoshka_next.facts import public_plan
from matryoshka_next.decisions import _prefix_blocker
from . import source_account_match as account
from . import clause_semantics as clauses
from .source_qualification import raw_envelope_holds

VERSION = "source-local-relative-accounts/3"
PROOF_FIELD = "source_relative_account_certificate"
H_TYPE = "SOURCE_LOCAL_ATTRIBUTED_CONDITIONAL_RELATIVE_VIEW"
M_TYPE = "SOURCE_LOCAL_COMPLETED_PERSON_RELATIVE_ACCOUNT"
_BLOCKED = {"alleged", "purported", "fictional", "hypothetical", "fake", "fabricated", "imaginary",
            "supposed", "other", "different", "previous", "earlier", "unrelated"}


def _words(tokens):
    return [t.text.casefold() for t in tokens if not t.is_space and not t.is_punct
        and not (t.dep_ == "det" and t.lower_ in {"the", "a", "an"})]


def _np(head):
    excluded = {t.i for c in head.children if c.dep_ in {"relcl", "acl", "appos"} for t in c.subtree}
    return [t for t in head.subtree if t.i not in excluded and not t.is_space and not t.is_punct]


def _negated(head):
    return any(t.dep_ == "neg" or t.lower_ in {"never", "neither"} for t in head.children)


def _passage(base, page, unit):
    lo, hi = unit["start"], unit["end"]
    previous = [s for s in sentences(page["text"]) if s["end"] <= lo]
    for candidate in reversed(previous[-2:]):
        gap = page["text"][candidate["end"]:lo]
        if (gap.strip() or re.search(r"\n[ \t\r]*\n", gap) or MASK.search(candidate["text"])
                or SECTION.search(candidate["text"]) or re.fullmatch(r"\d{1,3}\.", candidate["text"])
                or re.match(r"\s*(?:\([A-Z]\)|[A-Z][.)]|\d{1,3}\.)\s", page["text"][lo:hi])
                or hi - candidate["start"] > 4096):
            break
        lo = candidate["start"]
    return base.policy.citation(base.positions[page["id"]], lo, hi)


def _raw_span(parent, mapping, start, end):
    return (parent["start"] + (mapping[start] if mapping is not None else start),
        parent["start"] + (mapping[end - 1] + 1 if mapping is not None else end))


def _quotes(doc):
    stack, ranges = [], []
    for token in doc:
        if token.text in {'"', '\u201c', '\u201d'}:
            family = '"'
        elif token.text in {"'", '\u2018', '\u2019'} and token.dep_ != "case":
            family = "'"
        else:
            continue
        if stack and stack[-1][0] == family:
            _, opening = stack.pop()
            ranges.append((opening, token.idx + len(token)))
        else:
            stack.append((family, token.idx))
    return None if stack else ranges


def _guard(base, page, parent, doc, critical, *, quoted_view):
    ranges = _quotes(doc)
    if ranges is None or any(a <= t.idx < b for t in critical for a, b in ranges):
        return None
    if _prefix_blocker(page, parent["start"], base.engine):
        return None
    epistemic = account._EPISTEMIC | {"allegedly", "reportedly", "supposedly", "falsely", "fake"}
    for root in {t.sent.root for t in critical}:
        if any(t.dep_ == "advmod" and t.lower_ in epistemic for t in root.children):
            return None
        envelopes = [t for c in root.children if c.dep_ in {"prep", "advcl", "npadvmod", "parataxis", "nsubj"}
            for t in c.subtree if t.pos_ == "NOUN" and t.lemma_.casefold() in
                {"report", "account", "statement", "claim", "speech", "message"}]
        if any(c.lower_ in epistemic | _BLOCKED for n in envelopes for c in n.children if c.dep_ in {"amod", "advmod"}):
            return None
    holds = raw_envelope_holds(base, page, parent, doc)
    permitted = {"QUOTED_SOURCE_REPORTING_EVENT_NOT_ASSERTED_BY_THIS_PROJECTION"} if quoted_view else set()
    if any(hold not in permitted for hold in holds):
        return None
    return dict(raw_holds=holds, balanced_quote_spans=ranges,
        quoted_fragments_not_reporting_frame=True, full_parent_retained=True,
        quotation_license="NAMED_NARRATIVE_REPORTER_AND_EXACT_MODAL_CONTENT" if quoted_view else None,
        no_global_qualifier_stripping=True)


def _tail_holds(base, page, end, actor, *, predicate=None, event_terms=()):
    context = account._report_context(base, page, end, actor=actor)
    if context is None:
        return True
    tail = base.engine.parse(page["text"][end:context["end"]].lstrip())

    def current_reference(noun, kinds):
        if noun.lower_ in {"this", "that", "it"}:
            return True
        words = {t.lower_ for t in noun.children}
        return (noun.lemma_.casefold() in kinds
            and bool(words & {"this", "that", "these", "those", "such", "the"})
            and not words & account._DISTINCT
            and not any(t.dep_ == "poss" and t.pos_ == "PROPN" for t in noun.children))

    for sentence in tail.sents:
        root = next((t for t in sentence if t.dep_ == "ROOT"), None)
        if root is None:
            continue
        owner = account._subject(root)
        same_actor = owner is not None and (owner.lower_ in {"he", "she"}
            or clauses._actor(actor, owner, tail) is not None)
        if same_actor and root.lemma_.casefold() in {"deny", "retract"} and not _negated(root):
            # A denial of making THIS statement qualifies the reporting act,
            # not the truth of its modal/conditional content.
            for action in root.children:
                if (action.dep_ == "xcomp" and account._subject(action) is None
                        and action.lemma_.casefold() in {"make", "write", "issue", "utter", "publish"}
                        and any(t.dep_ in {"dobj", "obj"} and current_reference(t, account._REPORT_NOUNS)
                            for t in action.children)):
                    return True
        if same_actor and _negated(root) and not any(t.tag_ == "MD" for t in root.children):
            if root.lemma_.casefold() in {"say", "state", "report"} and any(
                    t.lower_ in {"this", "that", "so"} for t in root.children):
                return True
            if predicate and root.lemma_.casefold() == predicate:
                return True
        if owner is None:
            continue
        current = current_reference(owner,
            {"view", "assessment", "forecast", predicate, *event_terms} | account._REPORT_NOUNS)
        if not current:
            continue
        properties = [root, *(t for c in root.children if c.dep_ in {"attr", "acomp"} for t in c.subtree)]
        if any(t.lemma_.casefold() in {"false", "fabricated", "unverified", "hypothetical", "fictional", "uncertain"} for t in properties):
            return True
        if root.lemma_.casefold() in {"happen", "occur", "exist"} and _negated(root):
            return True
        if (root.lemma_.casefold() in {"be", "constitute", "represent"} and _negated(root)
                and any(t.dep_ in {"attr", "dobj", "obj"} and t.lemma_.casefold() == "statement"
                    for t in root.children)):
            return True
        if (root.lemma_.casefold() in {"propose", "plan", "schedule", "draft", "contemplate"}
                and not _negated(root) and any(t.lower_ in {"only", "merely", "just", "solely"}
                    for t in root.children)
                and not re.search(r"\bnot\s+(?:only|merely|just|solely)\b", sentence.text, re.I)):
            return True
    return False


def _topic(qsubject, topic, doc):
    wanted = _words(_np(qsubject))
    offered = _words(_np(topic))
    if not wanted or any(t.lower_ in _BLOCKED for t in _np(topic)):
        return None
    if wanted == offered:
        return dict(kind="LITERAL_RELATIVE_HEAD", topic=account._proof(topic), antecedent=account._proof(topic))
    if (offered != [topic.text.casefold()] or not any(c.dep_ == "det" and c.lower_ == "the" for c in topic.children)
            or len(wanted) < 2):
        return None
    candidates = []
    for t in doc[:topic.sent.start]:
        if t.lemma_.casefold() != topic.lemma_.casefold() or t.pos_ not in {"NOUN", "PROPN"}:
            continue
        words = _np(t)
        core = [s for s in words if s.dep_ != "amod" or s.text.casefold() in wanted]
        if any(s.lower_ in _BLOCKED for s in words):
            return None
        if _words(core) == wanted:
            candidates.append(t)
        elif len(_words(words)) > 1:
            return None
    if len(candidates) != 1:
        return None
    return dict(kind="UNIQUE_PRIOR_FULL_NP_TO_DEFINITE_RELATIVE_HEAD", topic=account._proof(topic),
        antecedent=account._proof(candidates[0]), complete_antecedent_tokens=[account._proof(t) for t in _np(candidates[0])],
        canonical_identity_certified=False)


def _conditional_view(base, qdoc, doc):
    qr = account._root(qdoc)
    qs = account._subject(qr) if qr is not None else None
    if (qr is None or qs is None or qs.pos_ == "PRON" or not account._complete(qdoc, named=False)
            or not any(t.tag_ == "MD" for t in qr.children)):
        return None
    for speech in doc:
        if speech.dep_ != "relcl" or speech.lemma_.casefold() not in {"say", "state", "report"} or speech.tag_ != "VBD":
            continue
        topic = speech.head
        speaker = account._subject(speech)
        matrix = topic.sent.root
        matrix_owner = account._subject(matrix)
        attitudes = [t for t in matrix.children if t.dep_ == "acomp" and t.lemma_.casefold() in {"hopeful", "optimistic"}]
        if (topic.pos_ not in {"NOUN", "PROPN"} or matrix.lemma_.casefold() != "be" or not attitudes
                or matrix_owner is None or not clauses._name_tokens(matrix_owner)
                or speaker is None or speaker.lower_ not in {"he", "she"}
                or _negated(matrix) or any(t.tag_ == "MD" for t in matrix.children)
                or _negated(speech) or any(t.dep_ in {"aux", "advmod", "advcl"} for t in speech.children)):
            continue
        if not any(t == topic for t in attitudes[0].subtree):
            continue
        leaves = [t for t in speech.children if t.dep_ == "ccomp"]
        if len(leaves) != 1:
            continue
        leaf = leaves[0]
        relative = account._subject(leaf)
        if relative is None or relative.lower_ != "which":
            continue
        binding = _topic(qs, topic, doc)
        if binding is None or account._content_signature(qr, qs) != account._content_signature(leaf, relative):
            continue
        return dict(type=H_TYPE, kind="ATTRIBUTED_RELATIVE_TOPIC_MODAL_VIEW", owner=matrix_owner,
            critical=[matrix_owner, matrix, speaker, speech, topic,
                next(t for t in doc if t.idx == binding["antecedent"]["start"])], target=leaf,
            bindings=dict(topic=binding, relative=account._proof(relative), reporter=account._proof(speaker),
                reporter_antecedent=account._proof(matrix_owner), reporting_operator=account._proof(speech),
                attitude=account._proof(attitudes[0]), exact_content_signature=account._content_signature(qr, qs)),
            scope_kind="QUERIED_OPERATOR_ONLY", quoted_view=True,
            qualified_account="The eligible source records this conditional view with its named speaker, hopeful attitude, modal and complete condition retained. No result, sincerity, or anticipated event is established.")
    return None


@lru_cache(maxsize=128)
def _person_role(lemma):
    from matryoshka_demo.roles import lexicon, binding
    try:
        found = next((s for s in lexicon().synsets(lemma, pos="n") if s.lexname() == "noun.person"), None)
    except LookupError:
        return None
    return dict(concept=found.name(), resource=binding()) if found else None


def _role_core(role):
    return _words(
        sorted([role, *(t for t in role.children if t.dep_ in {"amod", "compound"})], key=lambda t: t.i))


def _advice_polarity(action, matrix):
    """Only an explicit BUT RATHER edge resets a negated coordination domain."""
    cursor, contrast, resets, negatives = action, False, [], []
    while cursor != matrix:
        head = cursor.head
        if head == cursor:
            return None
        if cursor.dep_ == "conj":
            for cc in head.children:
                if cc.dep_ != "cc" or cc.lower_ != "but" or not head.i < cc.i < cursor.i:
                    continue
                between = list(action.doc[cc.i + 1:cursor.i])
                rather = [t for t in between if t.lower_ == "rather" and t.head in {cc, cursor}]
                if len(rather) == 1 and not any(t.lower_ in {"not", "never", "nor"} for t in between):
                    contrast = True
                    resets.append(dict(coordinator=account._proof(cc), rather=account._proof(rather[0]),
                        positive_branch=account._proof(cursor)))
        else:
            contrast = False
        if _negated(head):
            if not contrast:
                return None
            negatives.append(account._proof(head))
        cursor = head
    return dict(positive_identification_licensed=True, contrast_resets=resets,
        negated_coordination_governors=negatives, noncoordination_negation_never_reset=True)


def _person_relative(base, qdoc, doc):
    qr = account._root(qdoc)
    qs = account._subject(qr) if qr is not None else None
    if (qr is None or qs is None or not clauses._name_tokens(qs) or qr.tag_ != "VBN"
            or qs.dep_ != "nsubjpass" or _negated(qr)
            or not any(t.dep_ == "auxpass" and t.lower_ in {"was", "were"} for t in qr.children)
            or any(t.tag_ == "MD" for t in qr.children)
            or any(t.dep_ not in {"nsubjpass", "auxpass", "punct"} and not t.is_space for t in qr.children)):
        return None
    for leaf in doc:
        if (leaf.dep_ != "relcl" or leaf.lemma_.casefold() != qr.lemma_.casefold() or leaf.tag_ != "VBN"
                or _negated(leaf) or any(t.tag_ == "MD" for t in leaf.children)):
            continue
        who = account._subject(leaf)
        if who is None or who.lower_ != "who" or who.dep_ != "nsubjpass":
            continue
        if not (any(t.dep_ == "aux" and t.lower_ in {"has", "had"} for t in leaf.children)
                and any(t.dep_ == "auxpass" and t.lower_ == "been" for t in leaf.children)):
            continue
        if any(t.dep_ == "advmod" and t.lower_ not in {"now", "already"} for t in leaf.children):
            continue
        matrix = leaf.sent.root
        advisory = any(t.dep_ in {"acomp", "oprd"} and t.pos_ == "ADJ"
            and t.lower_ in {"best", "advisable", "appropriate"} for t in matrix.children)
        advisory |= any(t.dep_ == "oprd" and t.lemma_.casefold() == "serve"
            and any(c.dep_ == "advmod" and c.lower_ == "best" for c in t.children) for t in matrix.children)
        if (matrix.lemma_.casefold() != "seem" or _negated(matrix) or not advisory
                or any(t.dep_ == "ccomp" for t in matrix.children)):
            continue
        if any(t.lower_ in {"if", "unless", "whether"} and t.dep_ == "mark" for t in matrix.subtree):
            continue
        identities = []
        for action in leaf.sent:
            if (action.lemma_.casefold() != "identify" or _negated(action)
                    or any(t.dep_ == "advmod" and t.lower_ not in {"rather", "so"} for t in action.children)):
                continue
            advice = _advice_polarity(action, matrix)
            if advice is None:
                continue
            people = [t for t in action.children if t.dep_ in {"dobj", "obj"} and t.lower_ in {"him", "her"}]
            roles = [obj for p in action.children if p.dep_ == "prep" and p.lower_ == "as"
                for obj in p.children if obj.dep_ == "pobj"]
            if len(people) != 1 or len(roles) != 1 or roles[0].i >= who.i or not _person_role(roles[0].lemma_.casefold()):
                continue
            role = roles[0]
            if any(t.lower_ in _BLOCKED | {"false", "supposed"} for t in _np(role)):
                continue
            if leaf.head != role:
                # Only repair the number/animacy-inconsistent PP attachment,
                # never a competing human or named-person relative head.
                if (leaf.head.pos_ != "NOUN" or "Plur" not in leaf.head.morph.get("Number")
                        or _person_role(leaf.head.lemma_.casefold())
                        or any(t.pos_ == "PROPN" or t.pos_ == "NOUN" and _person_role(t.lemma_.casefold())
                            for t in doc[role.i + 1:who.i])):
                    continue
            candidates, ambiguous = [], False
            for prior in doc[:leaf.sent.start]:
                if prior.pos_ in {"NOUN", "PROPN"} and _role_core(prior) == _role_core(role):
                    if prior.dep_ != "appos" or not clauses._name_tokens(prior.head):
                        ambiguous = True
                    else:
                        candidates.append((prior.head, prior))
            if ambiguous or len(candidates) != 1:
                continue
            name, prior_role = candidates[0]
            if clauses._actor(qs, name, doc) is None:
                continue
            for other in doc[:leaf.sent.start]:
                names = clauses._name_tokens(other)
                if not names or other == name or other.dep_ in {"compound", "flat", "name"}:
                    continue
                if other.ent_type_ == "PERSON" or other.dep_ == "nsubj" and other.head.dep_ == "ROOT":
                    ambiguous = True
            if ambiguous:
                continue
            identities.append((action, people[0], role, name, prior_role, advice))
        if len(identities) != 1:
            continue
        action, person, role, name, prior_role, advice = identities[0]
        if clauses._clock(qr, leaf, qdoc, doc) is None:
            continue
        return dict(type=M_TYPE, kind="COMPLETED_DESCRIPTIVE_PERSON_RELATIVE", owner=qs,
            critical=[matrix, action, person, role, name, leaf], target=leaf,
            bindings=dict(named_person=[account._proof(t) for t in clauses._name_tokens(name)],
                prior_role=account._proof(prior_role), role=account._proof(role),
                role_class=_person_role(role.lemma_.casefold()), controlled_person=account._proof(person),
                identification=account._proof(action), relative=account._proof(who),
                positive_identification_scope=advice,
                parser_attachment=account._proof(leaf.head), predicate=account._proof(leaf),
                reference_scope="DEFINITE_PERSON_AND_LITERAL_PERSON_ROLE_NOT_NEAREST_PP_NOUN",
                normative_parent_retained=True, completed_perfect_not_a_prospective_identification=True),
            scope_kind="SOURCE_ASCRIPTION", quoted_view=False,
            qualified_account="The source describes the uniquely named person as already having undergone this completed action. The complete identification-advice parent is retained; advice is not certified as executed and no independent world truth is claimed.")
    return None


def supplement(matcher, atom, page, unit, control):
    base = getattr(matcher, "baseline", matcher)
    if (base.case["task"] not in {"hypothesis", "reconstruction"} or atom.get("kind") != "proposition"
            or control.get("direction") not in {"PARTIAL", "UNRESOLVED"}
            or any(control.get(k) for k in ("source_account_policy_withheld", "root_content_withheld",
                "root_content_policy_applicable", "potential_counter", "unbound_material_counter"))):
        return control
    public_plan(base.case, dict(atoms=[atom], query_sha256=digest(base.case["query"])))
    pi = base.positions.get(page.get("id"))
    if pi is None or page != base.corpus.pages[pi] or digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Relative account requires a complete bound raw page")
    citation = base.policy.citation(pi, unit["start"], unit["end"])
    if citation != control.get("citation") or citation["text"] != unit.get("text", unit.get("quote")):
        raise ValueError("Relative account original citation does not replay")
    if (unit["start"], unit["end"]) not in {(s["start"], s["end"]) for s in sentences(page["text"])}:
        return control
    if len(atom["text"]) > 2048 or len(citation["text"]) > 4096:
        return control
    marker = "which" if base.case["task"] == "hypothesis" else "who"
    if not re.search(r"\b" + marker + r"\b", citation["text"], re.I):
        return control
    with offline():
        qview, _, qnorm = _layout(base.engine, atom["text"])
        qdoc = base.engine.parse(qview)
        if not account._public(base, atom, qdoc):
            return control
        parent = _passage(base, page, unit)
        view, mapping, norm = _layout(base.engine, parent["text"])
        doc = base.engine.parse(view)
        matched = _conditional_view(base, qdoc, doc) if base.case["task"] == "hypothesis" else _person_relative(base, qdoc, doc)
        if matched is None:
            return control
        target = matched["target"]
        a, b = _raw_span(parent, mapping, target.idx, target.idx + len(target))
        if not unit["start"] <= a < b <= unit["end"]:
            return control
        guard = _guard(base, page, parent, doc, matched["critical"], quoted_view=matched["quoted_view"])
        if guard is None or _tail_holds(base, page, parent["end"], matched["owner"],
                predicate=target.lemma_.casefold() if matched["type"] == M_TYPE else None):
            return control
        scope = dict(kind=matched["scope_kind"], qualification=matched["qualified_account"],
            inner_execution_certified=False, event_join_certified=False, world_truth_certified=False,
            physical_executor_certified=False, canonical_identity_certified=False)
        proof = dict(version=VERSION, type=matched["type"], mode=matched["kind"], scope=scope,
            citation=parent, original_unit_citation=citation, query_sha256=digest(base.case["query"]),
            atom_sha256=digest(atom), full_source_page_sha256=page["source_sha256"], bindings=matched["bindings"],
            query_normalization=qnorm, source_normalization=norm, qualification_guard=guard,
            critical_raw_spans=[dict(token=account._proof(t), raw_start=x, raw_end=y)
                for t in matched["critical"] for x, y in [_raw_span(parent, mapping, t.idx, t.idx + len(t))]],
            offset_basis="NORMALIZED_PARENT_TOKEN_PROOFS_WITH_EXACT_RAW_PAGE_SPANS",
            strict_control_sha256=digest(control), source_text_modified=False,
            full_parent_operators_retained=True, source_local_reference_only=True,
            original_parser_attachment_preserved_in_audit=True, complete_required_account=True)
        proof = json.loads(json.dumps(proof))
        row = deepcopy(control)
        row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
            citation=deepcopy(parent), source_relative_account_certificate=proof,
            strict_relative_account_control=deepcopy(control), event_bindings=[],
            support_scope=scope["kind"], queried_account_scope=deepcopy(scope), qualified=True,
            qualified_account=matched["qualified_account"], source_assertion_not_world_truth=True,
            actual_inner_event_established=False, world_truth_certified=False,
            canonical_identity_certified=False, cross_atom_or_event_join_certified=False)
        row["checks"] = dict(eligible_source="PASS", raw_quote="PASS", source_local_reference="PASS",
            complete_required_account="PASS", full_parent_operators="PASS", world_truth="NOT_CERTIFIED",
            inner_execution="NOT_CERTIFIED", event_join="NOT_CERTIFIED")
        return row


def replay(matcher, atom, page, unit, control, certificate):
    produced = supplement(matcher, atom, page, unit, control)
    if certificate.get("version") != VERSION or produced.get(PROOF_FIELD) != certificate:
        raise ValueError("Relative-account proof differs from trusted raw producer replay")
    return deepcopy(certificate)
