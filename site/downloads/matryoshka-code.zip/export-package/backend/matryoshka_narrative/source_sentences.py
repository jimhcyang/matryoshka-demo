"""Conservative, source-only dotted-initialism sentence-boundary recovery.

Every proposed partition keeps its complete parent quote. No query, answer or
entity lookup is an input; both sides must independently parse as complete
finite assertions. The ordinary matcher still decides their meaning.
"""
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo_v6.reporting_fixed_pool_role_projection_v2 import NONFACTIVE

VERSION = "source-initialism-boundary-recovery/2"
_BOUNDARY = re.compile(r"(?<![A-Za-z])(?:[A-Z]\.){2,}([ \t]{2,}|\r?\n[ \t]*)(?=[A-Z][A-Za-z])")
_PREFIX_RISK = {"according", "allegedly", "reportedly", "apparently", "presumably",
    "possibly", "purportedly", "if", "unless", "whether", "would", "could", "might",
    "may", "should", "not", "never", "neither", "nor", "perhaps", "probably",
    "likely", "unlikely", "possible", "uncertain", "conceivably", "arguably"}
_REPORTS = {"say", "tell", "report", "claim", "believe", "deny", "suggest", "hear",
    "assume", "allege", "think", "expect", "hope", "plan", "intend", "warn",
    "estimate", "assert", "state", "announce", "doubt", "seem", "appear",
    "suspect", "imagine", "suppose", "consider", "wonder", "question", "fear",
    "know", "learn", "discover", "find", "prove", "demonstrate", "confirm",
    "speculate", "predict", "forecast", "reason", "infer", "surmise", "guess"} | NONFACTIVE


def _balanced(text):
    stack = []
    for index, char in enumerate(text):
        if char in {"'", "\u2019"} and index and index + 1 < len(text) and (
                text[index - 1].isalnum() and text[index + 1].isalnum()):
            continue
        if char in {'"', "'"}:
            if stack and stack[-1] == char:
                stack.pop()
            else:
                stack.append(char)
        elif char in "([\u201c\u2018":
            stack.append(char)
        elif char in ")]\u201d\u2019":
            wanted = {")": "(", "]": "[", "\u201d": "\u201c", "\u2019": "\u2018"}[char]
            if not stack or stack.pop() != wanted:
                return False
    return not stack


def _root(doc, *, named_subject=False):
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1:
        return None
    root = roots[0]
    if root.pos_ not in {"VERB", "AUX"} or root.tag_ not in {"VBD", "VBP", "VBZ"}:
        return None
    subjects = [t for t in root.children if t.dep_ in {"nsubj", "nsubjpass"}]
    if len(subjects) != 1 or named_subject and subjects[0].pos_ != "PROPN":
        return None
    if root.pos_ == "AUX" and (root.lemma_.casefold() != "be" or not any(
            t.dep_ in {"attr", "acomp", "prep"} for t in root.children)):
        return None
    return root, subjects[0]


def recover(page, unit, parse):
    """Return additional raw partitions and their independently replayable audit."""
    a, b = unit.get("start"), unit.get("end")
    text = unit.get("text", unit.get("quote"))
    raw = page.get("text")
    if (not isinstance(raw, str) or digest(raw) != page.get("source_sha256")
            or type(a) is not int or type(b) is not int or not 0 <= a < b <= len(raw)
            or raw[a:b] != text):
        raise ValueError("Sentence recovery requires an exact hash-bound parent source unit")
    if len(text) > 8192 or MASK.search(text) or not _balanced(text):
        return []
    candidates = list(_BOUNDARY.finditer(text))
    if len(candidates) != 1:
        return []
    match = candidates[0]
    split = match.end()
    left, right = text[:split], text[split:]
    if not left.rstrip().endswith(".") or not right or not _balanced(left) or not _balanced(right):
        return []
    if "?" in left or any(word.casefold() in _PREFIX_RISK for word in re.findall(r"[A-Za-z]+", left)):
        return []
    before, after = parse(left), parse(right)
    prefix, suffix = _root(before), _root(after, named_subject=True)
    # A copular epistemic matrix ("it was possible ...") is not an
    # independent event boundary; reparsing its complement would drop scope.
    if (prefix is None or suffix is None or prefix[0].pos_ != "VERB"
            or any(t.lemma_.casefold() in _REPORTS for t in before)
            or any(t.dep_ in {"ccomp", "xcomp", "csubj", "csubjpass"} for t in before)):
        return []
    if any(t.dep_ in {"mark", "neg"} or t.tag_ == "MD" for t in before):
        return []
    first = next((t for t in after if not t.is_space), None)
    names = {suffix[1], *(t for t in suffix[1].subtree if t.pos_ == "PROPN"
        and t.dep_ in {"compound", "flat", "name"})}
    if first not in names:
        return []
    # The original parent and its punctuation are authority, not a cropped
    # suffix's new ROOT by itself. Every character belongs to one partition.
    parent = dict(canonical_page_id=page["id"], document_id=page["document_id"],
        date=page["date"], page_sha256=page["source_sha256"], start=a, end=b, text=text)
    proof = dict(version=VERSION, kind="VALIDATED_DOTTED_INITIALISM_RAW_PARTITION",
        parent=parent, boundary=a + split,
        boundary_literal=raw[a + match.start():a + split],
        prefix_root=dict(text=prefix[0].text, start=a + prefix[0].idx,
            end=a + prefix[0].idx + len(prefix[0]), lemma=prefix[0].lemma_),
        suffix_root=dict(text=suffix[0].text, start=a + split + suffix[0].idx,
            end=a + split + suffix[0].idx + len(suffix[0]), lemma=suffix[0].lemma_),
        suffix_subject=dict(text=suffix[1].text, start=a + split + suffix[1].idx,
            end=a + split + suffix[1].idx + len(suffix[1])),
        source_characters_modified=False, dates_moved=False,
        identity_inferred=False, factual_support_certified=False,
        complete_parent_retained=True, segmentation_is_local_linguistic_inference=True)
    return [dict(start=lo, end=hi, text=raw[lo:hi], source_boundary=deepcopy(proof))
        for lo, hi in ((a, a + split), (a + split, b))]
