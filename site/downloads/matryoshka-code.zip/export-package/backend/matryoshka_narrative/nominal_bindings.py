"""Literal personal-role appositions; no event, pronoun or identity inference.

This narrow constructor attests a historical source role description. The
appositive must attach to a literal named matrix subject. Nothing in the
matrix predicate or another appositive is certified by that description.
"""
from functools import lru_cache

from matryoshka_demo.io import offline
from matryoshka_demo_v61 import scope_matching as scoped

VERSION = "narrative-literal-nominal-role-bindings/3"
_POSSESSOR_PREPOSITIONS = {
    "adviser": {"to"}, "advisor": {"to"}, "assistant": {"to"},
    "representative": {"of"}, "leader": {"of"}, "director": {"of"},
}
_FUNCTIONAL = {"det", "punct"}
_REFINEMENTS = {"close"}
_QUANTIFIED_COMPLEMENTS = {"all", "every", "each", "any", "some", "many", "few",
    "most", "several", "both", "either", "neither"}


@lru_cache(maxsize=128)
def _personal_role(word):
    from matryoshka_demo.roles import lexicon
    try:
        return any(s.lexname() == "noun.person" for s in lexicon().synsets(word, pos="n"))
    except LookupError:
        return False


def _name_tokens(head):
    """Keep ordered spelling, including repeated name parts and hyphens."""
    tokens = [head]
    pending = [head]
    while pending:
        token = pending.pop()
        for child in token.children:
            if child.dep_ in {"compound", "flat", "name"} and child.pos_ == "PROPN":
                tokens.append(child)
                pending.append(child)
    return sorted(tokens, key=lambda t: t.i)


def _bound_name(wanted, offered, *, appositions=False):
    if wanted.pos_ != "PROPN" or offered.pos_ != "PROPN":
        return None
    target, source = _name_tokens(wanted), _name_tokens(offered)
    if any(t.dep_ not in {"compound", "flat", "name", "case", "punct"}
            for name in target for t in name.children if t not in target):
        return None
    if any(t.dep_ not in {"compound", "flat", "name", "case", "punct"}
            | ({"appos"} if appositions else set())
            for name in source for t in name.children if t not in source):
        return None
    if len(source) < len(target):
        return None
    name, titles = source[-len(target):], source[:-len(target)]
    literal = lambda tokens: " ".join(tokens[0].doc.text[tokens[0].idx:
        tokens[-1].idx + len(tokens[-1])].casefold().split())
    if ([t.text.casefold() for t in target] != [t.text.casefold() for t in name]
            or literal(target) != literal(name)
            or any(not _personal_role(t.lemma_.casefold()) for t in titles)):
        return None
    return dict(kind="ORDERED_LITERAL_NAME_WITH_OPTIONAL_ATTESTED_PERSON_TITLE",
        target_proofs=[scoped.matching.proof(t) for t in target],
        source_proofs=[scoped.matching.proof(t) for t in name],
        literal_name=literal(target),
        additional_title_proofs=[scoped.matching.proof(t) for t in titles],
        canonical_identity_certified=False)


def _base(role):
    tokens = [role]
    for child in role.children:
        if child.dep_ in {"compound", "amod"}:
            tokens.extend(child.subtree)
    return sorted(tokens, key=lambda t: t.i)


def _qualified(role):
    phrase = scoped.matching.phrase(role)
    return bool(phrase["role_qualifiers"] or phrase["quantifiers"]
        or any(t.dep_ == "cc" and t.lower_ in {"or", "nor"} for t in role.children)
        or any(t.dep_ not in _FUNCTIONAL | {"compound", "amod", "poss", "prep", "cc", "conj"}
            for t in role.children)
        or any(t.dep_ in {"advmod", "neg", "nummod"} or t.like_num
            or t.lemma_.casefold() in {"former", "late", "acting", "alleged", "possible", "prospective", "future", "would-be"}
            for t in _base(role)))


def _literal_complement(wanted, offered):
    """Attest one identical role complement, without resolving its referent."""
    query = [c for c in wanted.children if c.dep_ == "prep"]
    source = [c for c in offered.children if c.dep_ == "prep"]
    if len(query) != 1 or len(source) != 1:
        return None
    sides = []
    for role, prep in ((wanted, query[0]), (offered, source[0])):
        objects = [c for c in prep.children if c.dep_ == "pobj"]
        tokens = sorted(prep.subtree, key=lambda t: t.i)
        # No clauses, clock, alternatives, possessive inference or nested PP.
        if (len(objects) != 1 or objects[0].pos_ not in {"NOUN", "PROPN"}
                or scoped.matching.phrase(objects[0]).get("quantifiers")
                or any(t.lemma_.casefold() in _QUANTIFIED_COMPLEMENTS for t in tokens)
                or role.dep_ == "appos" and any(c.dep_ == "relcl" for c in role.head.children)
                or any(t != prep and t.dep_ not in {"pobj", "det", "compound", "flat", "name", "amod"}
                    for t in tokens)
                or any(t.pos_ in {"VERB", "AUX", "NUM"} or t.like_num
                    or t.ent_type_ in {"DATE", "TIME"} for t in tokens)):
            return None
        sides.append(tokens)
    spelling = lambda tokens: [t.text.casefold() for t in tokens]
    if spelling(sides[0]) != spelling(sides[1]):
        return None
    return dict(kind="IDENTICAL_LITERAL_PREPOSITIONAL_ROLE_COMPLEMENT",
        query_proofs=[scoped.matching.proof(t) for t in sides[0]],
        source_proofs=[scoped.matching.proof(t) for t in sides[1]],
        canonical_identity_certified=False, event_join_certified=False)


def evaluate(matcher, atom, page, unit, control):
    """Evaluate only after the ordinary source-policy and raw-quote replay."""
    result = dict(version=VERSION, applicable=False, direction="UNRESOLVED",
        reasons=[], certificate=None)
    with offline():
        engine = matcher.engine
        query = engine.parse(atom["text"])
        roots = [t for t in query if t.dep_ == "ROOT"]
        if len(roots) != 1 or roots[0].lemma_.casefold() != "be":
            return result
        root = roots[0]
        owners = [c for c in root.children if c.dep_ == "nsubj"]
        roles = [c for c in root.children if c.dep_ == "attr" and c.pos_ == "NOUN"]
        if len(owners) != 1 or len(roles) != 1 or not _personal_role(roles[0].lemma_.casefold()):
            return result
        result["applicable"] = True
        result["reasons"] = ["NO_LITERAL_NAMED_MATRIX_SUBJECT_ROLE_APPOSITION"]
        if (root.tag_ != "VBD" or atom.get("kind") != "proposition"
                or any(c not in [*owners, *roles] and c.dep_ != "punct" for c in root.children)
                or any(t.is_quote or t.text == "?" or t.ent_type_ in {"DATE", "TIME"} for t in query)
                or control["query_issues"] or len(engine.targets(atom["text"])) != 1):
            result["reasons"] = ["QUERY_ROLE_SCOPE_CLOCK_OR_REPRESENTATION_UNSUPPORTED"]
            return result
        wanted = roles[0]
        if wanted.tag_ != "NN" or _qualified(wanted):
            result["reasons"] = ["QUALIFIED_OR_QUANTIFIED_ROLE_NOT_LICENSED"]
            return result
        poss = [c for c in wanted.children if c.dep_ == "poss"]
        query_preps = [c for c in wanted.children if c.dep_ == "prep"]
        if (len(poss) > 1 or len(query_preps) > 1 or poss and query_preps
                or any(c.dep_ in {"cc", "conj"} for c in wanted.children)):
            result["reasons"] = ["QUERY_ROLE_COMPLEMENTS_NOT_LICENSED"]
            return result
        text = unit.get("text", unit.get("quote"))
        source = engine.parse(text)
        if (sum(t.dep_ == "ROOT" for t in source) != 1
                or any(t.is_quote or t.text in {"?", "(", ")", "[", "]", "—", "--"}
                    or t.lower_ == "according" or t.dep_ in {"parataxis", "advcl"} for t in source)):
            result["reasons"] = ["SOURCE_UNIT_SCOPE_NOT_LICENSED"]
            return result
        for role in source:
            if role.pos_ != "NOUN" or role.tag_ != "NN" or role.lemma_.casefold() != wanted.lemma_.casefold():
                continue
            appos = role
            if role.dep_ == "conj":
                if not any(c.dep_ == "cc" and c.lower_ == "and" for c in role.head.children):
                    continue
                appos = role.head
            if appos.dep_ != "appos" or appos.head.dep_ not in {"nsubj", "nsubjpass"}:
                continue
            owner = appos.head
            if owner.head.dep_ != "ROOT" or _qualified(role) or _qualified(appos):
                continue
            # A role inside a report, conditional, relative or planned action
            # is not a matrix-subject apposition licensed by this constructor.
            governing = scoped.matching.qualifiers(owner.head)
            if any(governing.get(k) for k in ("negated", "modality", "scope", "attribution",
                    "epistemic_absence", "conditional", "question", "unresolved")):
                continue
            owner_proof = _bound_name(owners[0], owner, appositions=True)
            if owner_proof is None:
                continue
            qbase, sbase = _base(wanted), _base(role)
            qwords = [t.lemma_.casefold() for t in qbase]
            swords = [t.lemma_.casefold() for t in sbase
                if t.lemma_.casefold() not in _REFINEMENTS or t.lemma_.casefold() in qwords]
            if qwords != swords:
                continue
            preps = [c for c in role.children if c.dep_ == "prep"]
            source_poss = [c for c in role.children if c.dep_ == "poss"]
            beneficiary, relation, complement = None, None, None
            if poss:
                if len(preps) == 1 and not source_poss and preps[0].lemma_.casefold() in _POSSESSOR_PREPOSITIONS.get(qwords[-1], set()):
                    objects = [c for c in preps[0].children if c.dep_ == "pobj"]
                    if len(objects) == 1:
                        beneficiary = _bound_name(poss[0], objects[0])
                        relation = scoped.matching.proof(preps[0])
                elif len(source_poss) == 1 and not preps:
                    beneficiary = _bound_name(poss[0], source_poss[0])
                if beneficiary is None:
                    continue
            elif query_preps:
                complement = _literal_complement(wanted, role)
                if source_poss or complement is None:
                    continue
            elif preps or source_poss:
                continue
            result.update(direction="SUPPORT", reasons=[], certificate=dict(
                kind="LITERAL_NAMED_SUBJECT_ROLE_APPOSITION", version=VERSION,
                source_proof_offset_basis="SOURCE_UNIT_UNICODE_CHARACTERS",
                source_unit_page_start=unit["start"],
                owner_binding=owner_proof, role_proof=scoped.matching.proof(role),
                target_role_proof=scoped.matching.proof(wanted),
                possessor_binding=beneficiary, source_relation_proof=relation,
                literal_role_complement=complement,
                source_role_modifiers=[scoped.matching.proof(t) for t in sbase if t != role],
                appositive_proof=scoped.matching.proof(appos),
                source_matrix_predicate=scoped.matching.proof(owner.head),
                source_matrix_claim_certified=False, reporter_inferred=False,
                source_attestation_not_persistence=True, publication_date_used_as_event_time=False,
                canonical_identity_certified=False, inner_execution_certified=False,
                cross_atom_or_event_join_certified=False, source_text_modified=False))
            return result
    return result
