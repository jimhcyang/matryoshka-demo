"""Exact source NP cores whose initial THE is already in the visible query.

This is a versioned nominal-realization rule, not quote stripping or an edit to
source evidence. All source words survive in the completed visible phrase.
"""
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest

VERSION = "literal-visible-prefix-nominal-realization/1"


def _quote_scope(text, at):
    # Multiple straight-quote pairs are ambiguous without a quotation parser.
    if text.count('"') > 2:
        return None
    stack, enclosing = [], []
    for i, char in enumerate(text):
        if char == '"':
            if stack and stack[-1][1] == '"':
                start, _ = stack.pop()
                if start < at < i:
                    enclosing.append([start, i])
            else:
                stack.append((i, char))
        elif char == "\u201c":
            stack.append((i, char))
        elif char == "\u201d":
            if not stack or stack[-1][1] != "\u201c":
                return None
            start, _ = stack.pop()
            if start < at < i:
                enclosing.append([start, i])
    return enclosing if not stack and len(enclosing) <= 1 else None


def visible_prefix_nominal(page, raw, part, case):
    if raw.get("kind") != "nominal" or part is None or len(part) < 2:
        return None
    a, b = raw["start"], raw["end"]
    if (part.start_char != a or part.end_char != b or page["text"][a:b] != raw["text"]
            or digest(page["text"]) != page["source_sha256"]):
        raise ValueError("Visible-prefix realization lost its complete raw source NP")
    if MASK.search(raw["text"]) or any(t.is_quote for t in part):
        return None
    words = [t for t in part if not t.is_space]
    first = words[0]
    if (first.lower_ != "the" or first.head != part.root or first.dep_ not in {"det", "compound"}
            or part.root.pos_ not in {"NOUN", "PROPN"} or first == part.root
            or any(t.pos_ in {"VERB", "AUX"} or t.dep_ in {"ccomp", "advcl", "relcl"} for t in part)):
        return None
    query, marker = case["query"], case["focal_marker"]
    if not marker or query.count(marker) != 1:
        return None
    left, _ = query.split(marker)
    visible = re.search(r"(?<!\w)the\s+$", left, re.I)
    quotes = _quote_scope(query, len(left))
    if visible is None or quotes is None:
        return None
    start = words[1].idx
    if not page["text"][first.idx + len(first):start].isspace():
        return None
    core = page["text"][start:b]
    if not core.strip() or not any(t == part.root for t in words[1:]):
        return None
    proof = dict(version=VERSION, kind="EXACT_VISIBLE_SOURCE_PREFIX_PARTITION",
        original_np=dict(start=a, end=b, text=raw["text"]),
        retained_core=dict(start=start, end=b, text=core),
        source_prefix=dict(start=first.idx, end=first.idx + len(first), text=first.text,
            original_pos=first.pos_, original_dependency=first.dep_),
        visible_prefix=dict(start=visible.start(), end=visible.start() + 3,
            text=query[visible.start():visible.start() + 3]),
        query_sha256=digest(query), page_sha256=page["source_sha256"],
        source_words_preserved_in_completed_context=True, source_text_modified=False,
        quotation_characters_modified=False, enclosing_query_quote=quotes,
        factual_support_certified=False, identity_join=False)
    # Runtime proposal rows contain read-only spaCy Token views. Keep those
    # references in a new row; serializable proof data is constructed above.
    return dict(raw, start=start, text=core, edited=core,
        only_constructor_forms=["nominal", "member_example", "possessive"],
        source_constituent=proof)
