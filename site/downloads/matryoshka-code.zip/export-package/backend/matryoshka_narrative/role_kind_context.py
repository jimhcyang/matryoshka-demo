"""Reviewed V02 literal-role lexical context; never identity or factual support."""
from copy import deepcopy

from matryoshka_demo.io import digest
from matryoshka_demo.roles import lexicon
from . import redaction_selection as selection
from . import visible_apposition_context as apposition

VERSION = "visible-person-complete-role-kind-context/2"
REVIEWED_PROTOTYPE_SHA256 = "a82ebccbe522af9264f972b4bf5b72e33fb394bb18412b44bf27788f7dc4d498"
CUE_NAME = "visible_role_kind_context"
ROLES = {"actor_argument", "patient_argument", "recipient_argument", "agent_argument"}


def _head_matches(record, token, *, required):
    if not isinstance(record, dict):
        return False
    if record.get("span") != [token.idx, token.idx+len(token)] or record.get("text") != token.text:
        return False
    return all((not required and key not in record) or record.get(key) == value
               for key,value in (("pos",token.pos_), ("tag",token.tag_)))


def _completed_name_forest(name_part):
    """A whole name forest; the new alternative is contextual, never a type fact."""
    person = name_part.root
    if person.pos_ != "PROPN":
        return None
    name,pending = {person},[person]
    while pending:
        node = pending.pop()
        for child in node.children:
            if child.dep_ in apposition.NAME_DEPS and child not in name:
                name.add(child);pending.append(child)
    tokens = [t for t in name_part if not t.is_space]
    if not tokens or set(tokens) != name:
        return None
    if all(t.pos_ == "PROPN" for t in tokens):
        return dict(mode="UNCHANGED_ALL_PROPN_FOREST", leading_common_tokens=[],
                    context_only=True, identity_certified=False)
    split = 0
    while split < len(tokens) and tokens[split].pos_ == "NOUN":
        split += 1
    leading,proper = tokens[:split],tokens[split:]
    if (not leading or not proper or person not in proper
            or any(t.tag_ != "NN" or t.dep_ != "compound" for t in leading)
            or any(t.pos_ != "PROPN" for t in proper)):
        return None
    lo,hi = name_part.start_char,name_part.end_char
    entities = [e for e in name_part.doc.ents if e.start_char < hi and lo < e.end_char]
    if (len(entities) != 1 or entities[0].label_ != "PERSON"
            or entities[0].start_char != lo or entities[0].end_char != hi):
        return None
    return dict(mode="EXACT_PERSON_NAMED_EP_WITH_LEADING_NN_COMPOUNDS",
                leading_common_tokens=[apposition.proof(t) for t in leading],
                exact_person_entity=dict(text=entities[0].text,span=[lo,hi],label="PERSON"),
                context_only=True,identity_certified=False)


def _completed_attachment(case, candidate, form, parse, source_head, public):
    left,right = case["query"].split(case["focal_marker"])
    text = left+candidate["fill"]+right
    doc = parse(text)
    if doc.text != text:
        return None
    a,b = len(left),len(left)+len(candidate["fill"])
    if form.get("inserted_span") != [a,b] or form.get("completed_query_sha256") != digest(text):
        return None
    part = doc.char_span(a,b,alignment_mode="strict")
    head = form.get("head",{})
    if part is None or "entity_head" in form:
        return None
    role = part.root
    actual = dict(text=role.text,lemma=role.lemma_,pos=role.pos_,tag=role.tag_,
                  dependency=role.dep_,span=[role.idx,role.idx+len(role)])
    if (head != actual or role.pos_ != "PROPN" or role.tag_ != "NNP"
            or role.text != source_head.text or role.lemma_.casefold() != source_head.lemma_.casefold()
            or selection.literal_head_span(candidate,form) != [source_head.idx,source_head.idx+len(source_head)]):
        return None
    delta = len(candidate["fill"])-len(case["focal_marker"])
    lo,hi = (n+delta for n in public["span"])
    name_part = doc.char_span(lo,hi,alignment_mode="strict")
    if name_part is None or apposition._literal(name_part.text) != apposition._literal(public["literal_label"]):
        return None
    person = name_part.root
    if person.dep_ != "appos" or person.head != role or person.pos_ != "PROPN":
        return None
    named_ep = _completed_name_forest(name_part)
    if named_ep is None:
        return None
    name = {t for t in name_part if not t.is_space}
    if (person.sent != role.sent or [t for t in role.children if t.dep_ == "appos"] != [person]
            or any(t.dep_ in {"poss","nmod:poss","conj","cc"} or t.is_quote
                   or t.text in {"(",")","[","]"} for t in role.subtree)
            or any(c not in name and c.dep_ != "punct" and not c.is_space
                   for t in name for c in t.children)):
        return None
    return dict(completed_query=text, completed_query_sha256=digest(text),
        inserted_span=[a,b], completed_role_head=apposition.proof(role),
        visible_name_span=[lo,hi], visible_name_tokens=[apposition.proof(t) for t in sorted(name,key=lambda t:t.i)],
        local_relation="COMPLETE_VISIBLE_NAME_DIRECT_APPOS_OF_INSERTED_ROLE_HEAD",
        completed_named_ep=named_ep,
        full_query_parse=[apposition.proof(t) for t in doc],
        full_grammar_certified=False, parse_mutated=False)


def evaluate(case, reading, entity, visible, candidate, final_form, page, parse, source_types):
    from . import construction
    result = dict(version=VERSION,prototype_only=False,production_hook_installed=True,
        state="hold",reason=None,slot_compatibility_only=True,lexical_reference_only=True,
        source_type_match_added=False,identity_certified=False,canonical_identity_certified=False,
        factual_support_certified=False,event_certified=False,action_certified=False,
        grammar_certified=False,source_eligibility_certified=False,node_assigned=False)
    def hold(reason):
        result["reason"] = reason
        return result
    try:
        converted = candidate["v6_reading"]
        if (candidate.get("declared_reading") != reading or candidate.get("reading_id") != reading.get("id")
                or reading.get("constructor_form",reading.get("form")) != "nominal"
                or reading.get("outer_family") != "nominal" or reading.get("role") not in ROLES
                or reading.get("target_kind") != "person" or converted.get("form") != "nominal"
                or converted.get("role") != reading.get("role") or converted.get("target_kind") != "person"
                or candidate["ranking"]["features"].get("effective_target_kind") != "person"):
            return hold("READING_OR_PERSON_TARGET_NOT_EXACT")
        left,right = case["query"].split(case["focal_marker"])
        if converted.get("left_quote") != left or converted.get("right_quote") != right:
            return hold("CONVERTED_READING_NOT_BOUND_TO_PUBLIC_SLOT")
        if (final_form.get("state") != "pass" or candidate.get("final_form_fit") != final_form
                or final_form.get("constructor_form") != "nominal" or final_form.get("outer_family") != "nominal"
                or candidate.get("insertion_edits") != [] or candidate.get("fill") != candidate.get("source_wording")):
            return hold("UNCHANGED_NOMINAL_FINAL_FORM_REQUIRED")
        if "joint_slot_fit" in candidate and candidate["joint_slot_fit"].get("state") != "pass":
            return hold("SAVED_JOINT_SLOT_HOLD")
        if construction.final_form_fit(case,reading,candidate["fill"],parse) != final_form:
            return hold("COMPLETED_FORM_DOES_NOT_REPLAY")
        owned = [o for o in candidate["source_occurrences"]
            if o.get("source_span") == candidate["source_span"] and o.get("source_wording") == candidate["source_wording"]
            and o.get("citation",{}).get("canonical_page_id") == page["id"]]
        if len(owned) != 1 or owned[0]["citation"] not in candidate.get("sources",[]):
            return hold("ONE_OWNED_PRIMARY_OCCURRENCE_REQUIRED")
        occurrence = owned[0]
        raw = dict(kind="nominal",start=candidate["source_span"][0],end=candidate["source_span"][1],text=candidate["source_wording"])
        doc = parse(page["text"])
        observed = apposition.observe(case,reading,entity,visible,page,doc,raw)
        saved = occurrence.get("selection_cue",{}).get("visible_apposition_context")
        if (not observed["matched"] or saved != observed
                or not apposition.binds_occurrence(observed,occurrence,digest(case["query"]))):
            return hold("FULL_OWNED_VISIBLE_APPOSITION_CUE_NOT_REPLAYED")
        head = doc.char_span(raw["start"],raw["end"],alignment_mode="strict").root
        if (head.pos_ != "PROPN" or head.tag_ != "NNP"
                or not _head_matches(occurrence.get("source_head"),head,required=True)
                or not _head_matches(occurrence["selection_cue"].get("raw_source_head"),head,required=False)):
            return hold("SOURCE_HEAD_OR_CUE_PROVENANCE_NOT_EXACT")
        old = construction.completed_head_kind(candidate,final_form,parse,source_page=page,source_types=source_types)
        result["original_completed_head_kind"] = deepcopy(old)
        if candidate.get("completed_head_kind_fit",old) != old:
            return hold("SAVED_KIND_RESULT_STALE")
        if old.get("state") != "missing" or old.get("reason") != "NO_SOURCE_ENTITY_KIND_AT_COMPLETED_HEAD":
            return hold("EXPLICIT_OR_OTHER_KIND_GATE_NOT_OVERRIDABLE")
        senses = [s for s in lexicon().synsets(head.lemma_.casefold(),pos="n")
                  if any(l.name() == head.lemma_.casefold() for l in s.lemmas())]
        if not senses or any(s.lexname() != "noun.person" for s in senses):
            return hold("ALL_EXACT_NOUN_SENSES_MUST_BE_PERSON")
        attached = _completed_attachment(case,candidate,final_form,parse,head,observed["public_binding"])
        if attached is None:
            return hold("COMPLETED_NAME_NOT_DIRECT_APPOS_OF_EXACT_ROLE_HEAD")
        cue = dict(version=VERSION,kind="EXACT_VISIBLE_PERSON_OWNED_COMMON_ROLE_KIND_CONTEXT_ONLY",
            case_sha256=digest(case),query_sha256=digest(case["query"]),reading_sha256=digest(reading),
            converted_reading_sha256=digest(converted),entity_sha256=digest(entity),visible_sha256=digest(visible),
            candidate_id=candidate.get("id"),candidate_source_span=deepcopy(candidate["source_span"]),
            occurrence_sha256=digest(occurrence),page_id=page["id"],page_sha256=page["source_sha256"],
            source_observation=deepcopy(observed),source_role_head=apposition.proof(head),
            exact_ordinary_noun_person_senses=[s.name() for s in senses],
            completed_attachment=attached,final_form_sha256=digest(final_form),
            context_only=True,source_type_match_added=False,factual_support_certified=False,
            identity_or_action_certified=False,grammar_certified=False,source_eligibility_certified=False)
        cue["sha256"] = digest(cue)
        result.update(state="possible",reason="COMPLETE_VISIBLE_PERSON_APPOSITION_COMMON_ROLE_LEXICAL_CONTEXT_ONLY",
                      **{CUE_NAME:cue})
        return result
    except (KeyError,IndexError,TypeError,ValueError):
        return hold("UNBOUND_OR_MALFORMED_CONTEXT_INPUT")


def require_context_decision(compatibility,candidate,decision):
    if compatibility.get("state") != "possible" or compatibility.get("lexical_reference_only") is not True:
        raise ValueError("No possible lexical-only context exception")
    selection.require_context_decision(candidate,decision)
    return decision
