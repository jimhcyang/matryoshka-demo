"""Source-bound narrative showcase, independent of frozen study releases."""

VERSION = "narrative-showcase/1"
