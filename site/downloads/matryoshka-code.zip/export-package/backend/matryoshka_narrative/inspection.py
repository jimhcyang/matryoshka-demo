"""Fact-fair page inspection inside an already admitted document pool."""
from collections import defaultdict, deque

import numpy as np

VERSION = "directed-fact-document-inspection/2"


def schedule(corpus, plan, retrieval, *, budget):
    if type(budget) is not int or budget < 1:
        raise ValueError("Positive inspection budget required")
    pages = list(retrieval["pages"])
    if len(pages) != len(set(pages)):
        raise ValueError("Duplicate admitted source page")
    policy = retrieval["source_policy"]
    allowed = np.asarray(retrieval["eligible"].page_mask, dtype=bool) & policy.mask()
    if any(type(pi) is not int or not 0 <= pi < len(corpus.pages) or not allowed[pi] for pi in pages):
        raise ValueError("Inspection cannot admit an ineligible or unknown page")
    facts = [a for a in plan["atoms"] if a.get("kind") != "context"]
    if not facts or len({a["id"] for a in facts}) != len(facts):
        raise ValueError("Distinct executable Facts required")
    by_document = defaultdict(list)
    for pi in pages:
        by_document[corpus.pages[pi]["document_id"]].append(pi)
    documents = list(by_document)
    # A document match admits inspection opportunities, not only its first
    # retrieval hit. Each Fact may need a different page of that same document.
    document_set = set(documents)
    pool = [pi for pi, page in enumerate(corpus.pages)
        if allowed[pi] and page["document_id"] in document_set]
    for document_id in documents:
        by_document[document_id] = []
    for pi in pool:
        by_document[corpus.pages[pi]["document_id"]].append(pi)
    stats = corpus.page_bm25.stats(allowed)
    queues, cells = {}, []
    for atom in facts:
        scores = corpus.page_bm25.score(atom["text"], allowed, stats)
        nominations = []
        for document_id in documents:
            candidates = [pi for pi in by_document[document_id] if scores[pi] > 0]
            if not candidates:
                continue
            pi = min(candidates, key=lambda i: (-float(scores[i]), corpus.pages[i]["id"]))
            nominations.append(pi)
            cells.append(dict(atom_id=atom["id"], document_id=document_id,
                page_id=corpus.pages[pi]["id"], lexical_score=float(scores[pi])))
        nominations.sort(key=lambda pi: (-float(scores[pi]), corpus.pages[pi]["id"]))
        queues[atom["id"]] = deque(nominations)
    selected, seen = [], set()
    # One turn per Fact; a shared page satisfies multiple nominations only once.
    while len(selected) < budget and any(queues.values()):
        for atom in facts:
            queue = queues[atom["id"]]
            while queue and queue[0] in seen:
                queue.popleft()
            if queue and len(selected) < budget:
                pi = queue.popleft()
                selected.append(pi)
                seen.add(pi)
    nominations_selected = len(selected)
    for pi in pages:
        if len(selected) >= budget:
            break
        if pi not in seen:
            selected.append(pi)
            seen.add(pi)
    for pi in pool:
        if len(selected) >= budget:
            break
        if pi not in seen:
            selected.append(pi)
            seen.add(pi)
    selected_ids = {corpus.pages[pi]["id"] for pi in selected}
    receipt = dict(version=VERSION, budget=budget, admitted_pages=len(pages),
        admitted_documents=len(documents), executable_facts=len(facts),
        eligible_pages_in_admitted_documents=len(pool),
        newly_nominated_document_pages=sum(pi not in set(pages) for pi in selected),
        selected_pages=len(selected), nomination_pages_selected=nominations_selected,
        nominations=[dict(cell, inspected=cell["page_id"] in selected_ids) for cell in cells],
        uninspected_nominations=sum(cell["page_id"] not in selected_ids for cell in cells),
        all_inspected_pages_checked_against_every_fact=True,
        lexical_nomination_is_not_support=True, source_pool_changed=set(selected)-set(pages)!=set(),
        admitted_document_pool_changed=False, eligibility_filters_changed=False,
        source_text_modified=False, original_relevance_order_retained_in_tail=True)
    return selected + [pi for pi in pages if pi not in seen], receipt
