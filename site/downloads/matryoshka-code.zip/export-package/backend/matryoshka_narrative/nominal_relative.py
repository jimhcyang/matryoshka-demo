"""Source-owned full-suffix copular relatives; context only, never actor truth."""
from collections import Counter
from copy import deepcopy
import hashlib
import json
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, source_page_allowed
from matryoshka_narrative import adjunct_candidates as frozen
from . import nominal_relative_provenance as provenance

VERSION = "bound-comment-copular-relative/2"
MAX_PROPOSALS = 128
MAX_SUFFIX_TOKENS = 64
SUBJECT = frozenset({"nsubj", "nsubjpass", "csubj", "csubjpass"})
QUANTIFIED_SUBJECT = frozenset({"no", "none", "neither", "nobody", "nothing", "no-one",
    "all", "any", "each", "every", "either", "few", "most", "only"})


def eligible(reading):
    return (reading.get("constructor_form") is None
        and (reading.get("outer_family"),reading.get("function"),reading.get("role")) ==
        ("clausal","modifier","nominal_property"))


def _scope(token, page, base):
    subtree = sorted(token.subtree, key=lambda t:t.i)
    lo,hi = base+subtree[0].idx,base+subtree[-1].idx+len(subtree[-1])
    return dict(root=frozen._token(token,base),span=[lo,hi],text=page["text"][lo:hi],
        tokens=[frozen._token(t,base) for t in subtree])


def query_context(case):
    return provenance.focal_context(case)


class Constructor:
    def __init__(self,parser):
        self.parser = parser
        self._issued = {}
        self._pages = {}
        self._source_cache = {}
        self._query_cache = {}
        self._issued_pools = set()
        self._held_parents = {}
        self.compatibility_calls = 0

    def _frames(self,page,holds):
        for start,finish,parent in provenance.paragraphs(page["text"]):
            comment = provenance.REGISTERED_PREFIX.match(parent) if page["corpus"]=="cib" else None
            if comment:
                if MASK.search(parent):
                    holds["MASKED_COMMENT_PARENT_SCOPE_UNKNOWN"] += 1
                    self._held_parents[(page["id"],start,finish)] = dict(source_page_id=page["id"],
                        source_page_sha256=page["source_sha256"],parent_span=[start,finish],parent_text=parent,
                        state="HOLD",reason="MASKED_COMMENT_PARENT_SCOPE_UNKNOWN",full_scope_certified=False)
                    continue
                body_start = start+comment.end()
                yield body_start,page["text"][body_start:finish],False,False,(start,finish,parent),comment
            else:
                for base,text,left_open,right_open in frozen._fragments(parent):
                    yield start+base,text,left_open,right_open,(start,finish,parent),None

    def _seal_pool(self,pool):
        fingerprint = provenance.pool_fingerprint(pool)
        self._issued_pools.add(fingerprint)
        pool["producer_receipt"] = dict(version=VERSION,pool_sha256=fingerprint,
            public_binding_sha256=digest(pool["public_binding"]))
        return pool

    def validate_pool(self,pool):
        receipt = pool.get("producer_receipt",{})
        fingerprint = provenance.pool_fingerprint(pool)
        if (receipt.get("version") != VERSION or receipt.get("pool_sha256") != fingerprint
                or fingerprint not in self._issued_pools
                or receipt.get("public_binding_sha256") != digest(pool["public_binding"])):
            raise ValueError("UNISSUED_OR_CHANGED_NOMINATION_RECEIPT")
        return True

    def receipt_bytes(self,pool):
        self.validate_pool(pool)
        return json.dumps(pool["producer_receipt"],sort_keys=True,ensure_ascii=True,separators=(",", ":")).encode()

    def restore_pool(self,pool,*,receipt_bytes,trusted_receipt_sha256):
        """No grammar replay. Expected hash MUST come from a trusted immutable seal."""
        if type(receipt_bytes) is not bytes or hashlib.sha256(receipt_bytes).hexdigest() != trusted_receipt_sha256:
            raise ValueError("AUTHENTICATED_PRODUCER_RECEIPT_REQUIRED")
        receipt = json.loads(receipt_bytes)
        fingerprint = provenance.pool_fingerprint(pool)
        if (receipt != pool.get("producer_receipt") or receipt.get("version") != VERSION
                or receipt.get("pool_sha256") != fingerprint
                or receipt.get("public_binding_sha256") != digest(pool["public_binding"])):
            raise ValueError("RESTORED_POOL_DIFFERS_FROM_TRUSTED_RECEIPT")
        self._issued_pools.add(fingerprint)
        return True

    def source_spans(self,page,*,nested_finite=True):
        if type(nested_finite) is not bool:
            raise ValueError("nested_finite must be a strict bool")
        if digest(page["text"]) != page["source_sha256"]:
            raise ValueError("Exact source text hash required")
        page_key = digest(page)
        key = (page_key,nested_finite)
        if key in self._source_cache:
            return deepcopy(self._source_cache[key])
        self._pages[page_key] = deepcopy(page)
        values,holds = [],Counter()
        for base,text,left_open,right_open,parent,comment in self._frames(page,holds):
            sentences = list(self.parser(text).sents)
            for sentence in sentences:
                if (left_open and sentence == sentences[0] or right_open and sentence == sentences[-1]
                        and not frozen._closed_sentence(sentence)):
                    holds["OPAQUE_CLIPPED_SOURCE_SENTENCE"] += 1
                    continue
                head = sentence.root
                if head.lemma_ != "be" or head.pos_ not in {"AUX","VERB"} or head.dep_ != "ROOT":
                    continue
                if sentence[-1].text != "." or not frozen._closed_sentence(sentence):
                    holds["NO_COMPLETE_DECLARATIVE_TERMINAL_PERIOD"] += 1
                    continue
                subjects = [t for t in head.children if t.dep_ == "nsubj"]
                predicates = [t for t in head.children if t.dep_ in {"attr","acomp","prep","ccomp"}]
                if len(subjects) != 1 or not predicates:
                    holds["SINGLE_SUBJECT_AND_OWNED_COPULAR_PREDICATE_REQUIRED"] += 1
                    continue
                subject = subjects[0]
                subject_tokens = sorted(subject.subtree,key=lambda t:t.i)
                if (subject_tokens[0].i != sentence.start
                        or [t.i for t in subject_tokens] != list(range(sentence.start,subject_tokens[-1].i+1))
                        or any(t.dep_ == "conj" for t in subject_tokens)):
                    holds["PREPOSED_SCOPE_OR_COORDINATED_SUBJECT_NOT_REMOVED"] += 1
                    continue
                if (any(t.dep_ == "neg" or t.lower_ in QUANTIFIED_SUBJECT for t in subject_tokens)
                        or any(frozen._finite(t) for t in subject_tokens)):
                    holds["SUBJECT_QUANTIFIER_OR_CLAUSAL_SCOPE_NOT_REMOVED"] += 1
                    continue
                suffix = [t for t in sentence if t.i > subject_tokens[-1].i and t.i < sentence[-1].i]
                if not suffix or head not in suffix or len(suffix) > MAX_SUFFIX_TOKENS:
                    holds["COPULAR_SUFFIX_OUTSIDE_BOUNDED_SUBSET"] += 1
                    continue
                if not (frozen._finite(head) or any(frozen._finite(t) for t in head.children if t.dep_ in {"aux","auxpass"})):
                    holds["NO_FINITE_MAIN_COPULAR_CHAIN"] += 1
                    continue
                if any(t.head not in suffix for t in suffix):
                    holds["SUFFIX_DEPENDENCY_OUTSIDE_COPIED_PREDICATE"] += 1
                    continue
                if any(t.dep_ in SUBJECT and t.pos_ in {"SCONJ","CCONJ","ADP","PUNCT"} for t in suffix):
                    holds["NOMINAL_NESTED_SUBJECT_REQUIRED_NOT_A_CONJUNCTION"] += 1
                    continue
                malformed = any(t.dep_ in {"ccomp","advcl"} and any(c.dep_ == "mark" for c in t.children)
                    and (t.pos_ not in {"AUX","VERB"} or t.dep_ == "ccomp" and not (
                        frozen._finite(t) or any(frozen._finite(c) for c in t.children if c.dep_ in {"aux","auxpass"}))) for t in suffix)
                if malformed:
                    holds["CLAUSAL_BOUNDARY_WITHOUT_OWN_FINITE_PREDICATE"] += 1
                    continue
                extra = [t for t in suffix if t != head and t.pos_ in {"AUX","VERB"}
                    and t.dep_ not in {"aux","auxpass"} and (frozen._finite(t)
                        or any(frozen._finite(c) for c in t.children if c.dep_ in {"aux","auxpass"}))]
                if extra and not nested_finite:
                    holds["OTHER_FINITE_CLAUSE_OUTSIDE_SIMPLE_ABLATION"] += 1
                    continue
                clauses,unowned = [],False
                for token in extra:
                    owner,seen = token,set()
                    while not any(c.dep_ in SUBJECT for c in owner.children) and owner.dep_ == "conj" and owner not in seen:
                        seen.add(owner)
                        owner = owner.head
                    actors = [t for t in owner.children if t.dep_ in SUBJECT]
                    matrix_shared = owner == head and actors == [subject]
                    if (not actors or any(t.pos_ in {"SCONJ","CCONJ","ADP","PUNCT"} for t in actors)
                            or not matrix_shared and any(t not in suffix for t in actors)):
                        unowned = True
                        break
                    clauses.append(dict(predicate=frozen._token(token,base),copied_clause_scope=_scope(token,page,base),
                        owning_subjects=[_scope(t,page,base) for t in actors],
                        matrix_subject_variable_shared=matrix_shared,
                        subject_invented_or_borrowed=False))
                if unowned:
                    holds["NESTED_FINITE_SUBJECT_NOT_OWNED_IN_COPIED_SUFFIX"] += 1
                    continue
                sa,sb = base+subject_tokens[0].idx,base+subject_tokens[-1].idx+len(subject_tokens[-1])
                stop = base+sentence[-1].idx
                body = page["text"][sb:stop]
                if MASK.search(body) or body.count('"') % 2 or body.count("\u201c") != body.count("\u201d"):
                    holds["OPAQUE_OR_UNBALANCED_QUOTED_SUFFIX"] += 1
                    continue
                start,finish = base+sentence.start_char,base+sentence.end_char
                value = dict(version=VERSION,fill="that"+body,family="clausal",source_page_id=page["id"],
                    source_document_id=page["document_id"],source_date=page["date"],source_page_sha256=page["source_sha256"],
                    source_sentence=page["text"][start:finish],source_sentence_start=start,source_sentence_end=finish,
                    source_subject=dict(span=[sa,sb],text=page["text"][sa:sb],root=frozen._token(subject,base)),
                    source_predicate_span=[sb,stop],source_predicate_text=body,source_copula=frozen._token(head,base),
                    source_predicate_tokens=[frozen._token(t,base) for t in suffix],nested_finite_clauses=clauses,
                    source_qualifier_scopes=[_scope(t,page,base) for t in head.children if t.dep_ in frozen.QUALIFIER],
                    operation_license=dict(kind="REPLACE_INITIAL_SUBJECT_WITH_THAT_COPY_COMPLETE_SUFFIX",
                        replacements=[dict(span=[sa,sb],before=page["text"][sa:sb],after="that"),
                            dict(span=[stop,finish],before=page["text"][stop:finish],after="")],
                        copied_predicate_span=[sb,stop],copied_whitespace_and_punctuation_unchanged=True,
                        modal_negative_conditional_content_unchanged=True,source_owner_equivalence_certified=False),
                    source_wording=page["text"][start:finish],generated_surface_is_exact_source_span=False,
                    source_internal_references_resolved=False,owner_event_binding="UNASSESSED",factual_support_certified=False,
                    source_parent_quote=dict(span=list(parent[:2]),text=parent[2]),
                    source_parent_scope_complete=not bool(MASK.search(parent[2])))
                if comment:
                    p0,p1,ptext = parent
                    value.update(source_sentence_is_exact_body_partition=True,
                        source_assessment_operator=dict(kind="COMMENT_ASSESSMENT",observed=True,
                            span=[p0,p0+comment.end("label")],text=ptext[:comment.end("label")],
                            source_scope_span=[p0,p1],source_scope_text=ptext,assessment_is_verified_truth=False,
                            assessment_is_completed_decision=False,source_authority_credit_added=False),
                        source_parse_partition=dict(version=VERSION,body_span=[p0+comment.end(),p1],
                            body_text=page["text"][p0+comment.end():p1],registered_label_only=True,
                            original_source_text_or_hash_changed=False,body_operators_or_qualifications_removed=False))
                    value["operation_license"].update(comment_assessment_operator_preserved=True,
                        source_parent_quote_span=[p0,p1],relative_is_not_full_factual_ascription=True)
                provenance.replay_occurrence(value,{page["id"]:page},fill=value["fill"])
                values.append(value)
                self._issued[digest(value)] = page_key
        result = values,dict(holds)
        self._source_cache[key] = deepcopy(result)
        return result

    def compatibility(self,case,reading,occurrence):
        self.compatibility_calls += 1
        frozen._inputs(case,reading)
        result = dict(state="HOLD",reason=None,version=VERSION,grammar_only=True,
            factual_support_certified=False,owner_event_binding="UNASSESSED",full_English_grammar_certified=False,
            source_owner_equivalence_certified=False,source_internal_references_resolved=False,
            hidden_actor_invented_or_borrowed=False)
        def hold(reason):
            return dict(result,reason=reason)
        page_key = self._issued.get(digest(occurrence))
        if page_key is None or not source_page_allowed(self._pages[page_key],case,SOURCE_DAY_INCLUSIVE):
            return hold("SOURCE_OPERATION_NOT_REPLAYED_OR_CHANGED")
        try:
            provenance.replay_occurrence(occurrence,{occurrence["source_page_id"]:self._pages[page_key]},fill=occurrence["fill"])
        except ValueError:
            return hold("CANONICAL_SOURCE_OCCURRENCE_REPLAY_FAILED")
        if "source_assessment_operator" in occurrence:
            result.update(source_assessment_operator=deepcopy(occurrence["source_assessment_operator"]),
                whole_parent_quote_retained=True,comment_is_not_factual_authority=True,
                completed_decision_certified=False)
        if not eligible(reading):
            return hold("OUTSIDE_DECLARED_CLAUSAL_MODIFIER_SUBSET")
        if reading["target_kind"] != "any" or reading["grammatical_number"] != "unknown":
            return hold("NONDEFAULT_TYPED_HINT_UNMODELED")
        if any(w["placement"] == "inside_gap" for w in reading["wrappers"]):
            return hold("NO_ADDITIONAL_WRAPPER_REALIZATION")
        fill = occurrence["fill"]
        if fill != "that"+occurrence["source_predicate_text"]:
            return hold("SOURCE_SUFFIX_CHANGED")
        at = case["query"].index(case["focal_marker"])
        end = at+len(case["focal_marker"])
        final = case["query"][:at]+fill+case["query"][end:]
        left,right = 0,len(final)
        for mask in MASK.finditer(final):
            if mask.end() <= at:
                left = mask.end()
            elif mask.start() >= at+len(fill):
                right = mask.start()
                break
            else:
                return hold("OPAQUE_INSERTION")
        view = final[left:right]
        key = digest(view)
        if key not in self._query_cache:
            self._query_cache[key] = self.parser(view)
        doc = self._query_cache[key]
        part = doc.char_span(at-left,at+len(fill)-left,alignment_mode="strict")
        if part is None:
            return hold("INSERTION_NOT_EXACT_TOKENS")
        roots,mapped = set(),[]
        delta = len(fill)-len(case["focal_marker"])
        for anchor in reading["attachment_spans"]:
            lo,hi = anchor["start"],anchor["end"]
            if case["query"][lo:hi] != anchor["text"] or lo < end and at < hi:
                return hold("ATTACHMENT_BINDING_CHANGED_OR_OPAQUE")
            lo,hi = (lo+delta,hi+delta) if lo >= end else (lo,hi)
            if lo < left or hi > right:
                return hold("ATTACHMENT_OUTSIDE_VISIBLE_COMPONENT")
            bound = doc.char_span(lo-left,hi-left,alignment_mode="strict")
            if bound is None or bound.text != anchor["text"]:
                return hold("ATTACHMENT_NOT_EXACT_TOKENS")
            roots.add(bound.root)
            mapped.append(dict(start=lo,end=hi,text=bound.text,root=frozen._token(bound.root,left)))
        head = part.root
        if head.dep_ != "relcl" or head.lemma_ != "be" or head.head not in roots or head.head.pos_ not in {"NOUN","PROPN"}:
            return hold("RELATIVE_NOT_ATTACHED_TO_DECLARED_VISIBLE_NOUN")
        if not any(t.text == "that" and t.dep_ == "nsubj" and t.head == head for t in part):
            return hold("NO_OWN_INSERTED_RELATIVE_SUBJECT")
        chain = [head]+[t for t in head.children if t.dep_ in {"aux","auxpass"} and t in part]
        finite = any(frozen._finite(t) for t in chain)
        if not finite or reading["finite"] is not None and reading["finite"] != finite:
            return hold("MAIN_COPULAR_FINITE_HINT_CONFLICT")
        words = {t.text.casefold() for t in chain if frozen._finite(t)}
        number = set(head.head.morph.get("Number"))
        if (words & {"is","was","has"} and "Plur" in number
                or words & {"are","were"} and "Sing" in number or "am" in words):
            return hold("MAIN_SOURCE_AGREEMENT_NOT_CHANGED_TO_FIT_CARRIER")
        return dict(result,state="PASS_SYNTAX_ONLY",reason="LOCAL_COMPLETE_COPULAR_RELATIVE_ATTACHMENT_ONLY",
            inserted_span=[at,at+len(fill)],inserted_tokens=[frozen._token(t,left) for t in part],
            mapped_attachments=mapped,completed_query_sha256=digest(final),parse_view_span=[left,right],
            parse_view_text=view,source_suffix_unchanged=True,hypothetical_operator_semantics="UNASSESSED")

    def pool(self,case,reading,pages,*,nested_finite=True,proposal_cap=MAX_PROPOSALS,defer_compatibility=False):
        frozen._inputs(case,reading)
        if type(nested_finite) is not bool or type(proposal_cap) is not int or not 1 <= proposal_cap <= MAX_PROPOSALS:
            raise ValueError("Strict nested_finite bool and per-reading cap1..128 required")
        if type(defer_compatibility) is not bool:
            raise ValueError("defer_compatibility must be a strict bool")
        if not isinstance(pages,(list,tuple)) or len({p["id"] for p in pages}) != len(pages):
            raise ValueError("Unique actual inspected pages in native sequence required")
        provenance.canonical_pages(case,pages,[p["id"] for p in pages])
        base = dict(version=VERSION,reading_id=reading["id"],declared_reading=deepcopy(reading),nested_finite=nested_finite,
            inspected_page_ids=[p["id"] for p in pages],proposal_cap=proposal_cap,factual_support_certified=False,
            public_binding=provenance.public_binding(case,reading),query_context=query_context(case),
            compatibility_deferred=defer_compatibility,eager_compatibility_checks=0)
        if not eligible(reading):
            return self._seal_pool(dict(base,eligible=False,proposals=[],context_order_ids=[],syntax_accepted_context_order_ids=[]))
        per_page,holds = [],Counter()
        for page in pages:
            values,rejected = self.source_spans(page,nested_finite=nested_finite)
            per_page.append(values)
            holds.update(rejected)
        all_occurrences = {}
        for values in per_page:
            for value in values:
                all_occurrences.setdefault(value["fill"],[]).append(value)
        proposals,seen = [],set()
        for depth in range(max((len(v) for v in per_page),default=0)):
            for values in per_page:
                if depth >= len(values) or values[depth]["fill"] in seen:
                    continue
                value = values[depth]
                seen.add(value["fill"])
                proposals.append(dict(id="relative_v2_"+digest([VERSION,nested_finite,digest(case),reading["id"],value["fill"]])[:24],
                    fill=value["fill"],source_occurrences=deepcopy(all_occurrences[value["fill"]]),
                    compatibility=(dict(state="UNASSESSED",reason="DEFERRED_TO_CALLER_COMPLETED_INSERTION_BUDGET",
                        grammar_only=True,factual_support_certified=False) if defer_compatibility else self.compatibility(case,reading,value)),
                    factual_support_certified=False))
                if len(proposals) >= proposal_cap:
                    break
            if len(proposals) >= proposal_cap:
                break
        context = query_context(case)
        q = frozen._terms(self.parser,context["text"])
        term_cache = {}
        for index,proposal in enumerate(proposals):
            scores = []
            for occurrence_index,occurrence in enumerate(proposal["source_occurrences"]):
                sentence = occurrence["source_sentence"]
                if sentence not in term_cache:
                    term_cache[sentence] = frozen._terms(self.parser,sentence)
                s = term_cache[sentence]
                coverage,jaccard = len(q&s)/max(1,len(q)),len(q&s)/max(1,len(q|s))
                scores.append(dict(score=.75*coverage+.25*jaccard,coverage=coverage,jaccard=jaccard,
                    occurrence_index=occurrence_index,query_terms=sorted(q),source_terms=sorted(s),matched_terms=sorted(q&s)))
            proposal["context_order"] = dict(version=VERSION,query_context=context,
                best_single_occurrence=max(scores,key=lambda v:v["score"]),all_occurrence_scores=scores,
                original_proposal_order=index,coverage_weight=.75,jaccard_weight=.25,advisory_only=True,
                factual_support_certified=False,correctness_probability=False)
        ranked = sorted(proposals,key=lambda p:(-p["context_order"]["best_single_occurrence"]["score"],
            p["context_order"]["original_proposal_order"]))
        return self._seal_pool(dict(base,eligible=True,proposals=proposals,source_shape_holds=dict(holds),
            eager_compatibility_checks=0 if defer_compatibility else len(proposals),
            raw_source_occurrence_n=sum(len(v) for v in per_page),distinct_surface_n=len(all_occurrences),
            cap_reached=len(proposals)==proposal_cap,query_context=context,
            context_order_ids=[p["id"] for p in ranked],
            held_comment_paragraphs=[deepcopy(value) for value in self._held_parents.values() if value["source_page_id"] in {p["id"] for p in pages}],
            syntax_accepted_context_order_ids=[p["id"] for p in ranked if p["compatibility"]["state"] == "PASS_SYNTAX_ONLY"]))

