"""Source-owned nomination, visible context and conservative focal-scope guards."""
from copy import deepcopy
import math
import re

from matryoshka_demo import roles

VERSION="source-owned-candidate-salience/5"


def tokens(text):return re.findall(r"[a-z0-9]+",text.casefold())


def visible_anchors(case,plan,parse):
    values={}
    for entity in plan.get("extractions",{}).get("entities",[]):
        if entity.get("contains_unknown_slot") or entity.get("type") not in {"person","place","organization"}:continue
        spans=entity.get("query_spans",[])
        if not spans or any(type(s.get("start")) is not int or type(s.get("end")) is not int
                or not 0<=s["start"]<s["end"]<=len(case["query"])
                or case["query"][s["start"]:s["end"]]!=s.get("text") for s in spans):
            raise ValueError("Visible entity anchor lost its public query binding")
        quoted=spans[0]["text"]
        label=entity.get("label",quoted)
        match=re.search(r"(?<!\w)"+re.escape(label)+r"(?!\w)",quoted,re.I)
        text=match.group() if match else quoted
        if entity["type"]=="person":
            proper=[t for t in parse(text) if t.pos_=="PROPN" and t.lower_ not in {"the","de","la"}]
            if not proper:continue
            text=proper[-1].text
        key=" ".join(tokens(text))
        if key:values[key]=dict(key=key,query_quote=quoted,entity_type=entity["type"],query_spans=deepcopy(spans))
    return list(values.values())


def anchor_match(wording,citation,anchors):
    identity=" "+" ".join(tokens(wording))+" "
    text=" "+" ".join(tokens(citation["text"]))+" "
    hits=[a for a in anchors if " "+a["key"]+" " not in identity and " "+a["key"]+" " in text]
    return dict(matched=bool(hits),matched_anchors=hits,available=len(anchors),
        source_quote=citation,context_only=True,identity_or_action_certified=False,
        absence_is_counterevidence=False,candidate_own_name_excluded=True)


def person_sense(role_context):
    if not role_context.get("matched"):return False
    concept=role_context.get("source_concept")
    if not concept:return False
    try:
        sense=roles.lexicon().synset(concept)
        return sense.name()=="person.n.01" or any(s.name()=="person.n.01" for s in sense.closure(lambda s:s.hypernyms()))
    except (LookupError,ValueError):return False


def personal_possessor(case,reading):
    if reading.get("form")!="possessive":return False
    right=case["query"].split(case["focal_marker"],1)[1]
    attachment=reading.get("attachment_quote","")
    return bool(attachment and re.match(r"\s*"+re.escape(attachment)+r"\s*[;,]\s*(?:he|she)\b",right,re.I))


def source_nomination_cue(case,reading,part,feature,cue,types=None):
    result=deepcopy(cue)
    kinds={w.get("source_entity_type") for w in (types if types is not None else feature.get("source_type_witnesses",[]))
        if w["start"]<=part.root.idx<part.root.idx+len(part.root)<=w["end"]}
    person=(kinds=={"Person"} or part.root.ent_type_=="PERSON")
    own_role=result.get("own_role_context") or {}
    if result.get("own_person_role_context_priority") and not person_sense(own_role):
        result["own_person_role_context_priority"]=False
        result["typed_sense_hold"]=dict(reason="MATCHED_LEXICAL_SENSE_IS_NOT_A_PERSON_ROLE",source_concept=own_role.get("source_concept"),
            source_kind="Person",historical_claim_rejected=False)
    proper=part.root.pos_=="PROPN" and person and not any(t.dep_=="poss" and t.head in part for t in part)
    applicable=(reading.get("role")=="actor_enumeration" or feature.get("effective_target_kind")=="person"
        and reading.get("role") in {"actor_argument","patient_argument","agent_argument","recipient_argument"}
        or personal_possessor(case,reading))
    result["named_actor_priority"]=bool(proper and applicable)
    result["personal_possessor_is_soft_context_only"]=personal_possessor(case,reading)
    return result


def coordinate_head(reading,part):
    """Resolve a leading coordinator only to its explicit in-span nominal conjunct."""
    if reading.get("function")!="coordinate_member" or not part or part[0].lower_!="and":return None
    if part[0].dep_!="cc" or part[0].head in part:return None
    heads=[t for t in part if t.dep_=="conj" and t.head==part[0].head and t.pos_ in {"NOUN","PROPN","PRON"}]
    if len(heads)!=1:return None
    if any(t.pos_=="CCONJ" for t in part[1:]):return None
    return heads[0]


def owned_goal(part,goals,types):
    """Literal action in an entity's own appositive role; contextual, not actor proof."""
    roles_=[t for t in part.root.children if t.dep_=="appos" and t.pos_=="NOUN"]
    kinds={w.get("source_entity_type") for w in types if w["start"]<=part.root.idx<part.root.idx+len(part.root)<=w["end"]}
    known=kinds-{None,"Other"}
    if known and known!={"Person"}:return dict(matched=False,context_only=True,actor_action_certified=False)
    for role in roles_:
        senses=roles.lexicon().synsets(role.lemma_,pos=roles.lexicon().NOUN)
        typed_role=bool(senses) and all(person_sense(dict(matched=True,source_concept=s.name())) for s in senses)
        if not (kinds=={"Person"} or part.root.ent_type_=="PERSON" or typed_role):continue
        for token in role.subtree:
            if token.pos_!="VERB" or token.lemma_.casefold() not in goals:continue
            path=[token]
            while path[-1]!=role and path[-1].head!=path[-1] and len(path)<6:path.append(path[-1].head)
            if path[-1]!=role:continue
            forward=list(reversed(path))
            group=None
            if len(forward)>2 and forward[1].dep_=="prep" and forward[1].lemma_ in {"for","of"} and forward[2].dep_=="pobj":
                group=forward[2]
                verbal_path=forward[3:]
            else:verbal_path=forward[1:]
            if not verbal_path or any(t.dep_ not in {"acl","relcl","xcomp"} for t in verbal_path):continue
            if any(c.dep_ in {"nsubj","nsubjpass","csubj","csubjpass","auxpass","neg"}
                for t in (*path,part.root) for c in t.children):continue
            if any(t.lemma_.casefold() in {"deny","refuse","prevent","oppose","avoid","abandon","cease","stop"}
                for t in path[:-1]):continue
            if any(c.lemma_.casefold() in {"former","ex"} for c in role.children):continue
            wanted=set(goals.get(token.lemma_.casefold(),[])) if isinstance(goals,dict) else set()
            objects={c.lemma_.casefold() for c in token.children if c.dep_ in {"dobj","obj"}}
            if wanted and not wanted & objects:continue
            return dict(matched=True,goal=token.lemma_,source_role=role.text,source_identity=part.root.text,
                source_path=[dict(text=t.text,dependency=t.dep_,span=[t.idx,t.idx+len(t)]) for t in reversed(path)],
                goal_owner=group.text if group is not None else role.text,goal_object_heads=sorted(objects),
                query_object_heads=sorted(wanted),object_check_available=isinstance(goals,dict),
                source_owned=True,context_only=True,actor_action_certified=False)
    return dict(matched=False,context_only=True,actor_action_certified=False)


def recorded_counter(decision):
    directions={"Counterevidence","Support + Counterevidence","OPPOSED","CONFLICTED"}
    return bool(decision.get("counterevidence") or any(c.get("id")=="conflicts" and c.get("state")=="conflict"
        for c in decision.get("checklist",[])) or any(r.get("counterevidence") or r.get("direction") in directions
        or any(e.get("counterevidence") or e.get("direction") in directions for e in r.get("evidence",[]))
        for r in decision.get("requirements",[])))


def number_fit(reading,part):
    required=reading.get("grammatical_number")
    if reading.get("constructor_form",reading.get("form"))!="nominal" or reading.get("function")!="argument" or required not in {"singular","plural"}:
        return dict(state="pass",reason="NO_DECLARED_NOMINAL_ARGUMENT_NUMBER_CONSTRAINT")
    coordinated=any(t.dep_=="conj" and t.head==part.root for t in part)
    numbers=part.root.morph.get("Number")
    actual="plural" if coordinated or "Plur" in numbers else "singular" if "Sing" in numbers else None
    return dict(state="missing" if actual and actual!=required else "pass",reason="DECLARED_ARGUMENT_NUMBER",
        required=required,observed=actual,uncertain_is_not_opposition=True)


def focal_scope_guard(case,reading,candidate,decision):
    if decision.get("status") not in {"evidence_backed_suggestion","partial_grounding"}:return decision
    if recorded_counter(decision):
        return decision
    actor=reading.get("role") in {"actor_argument","patient_argument","agent_argument","recipient_argument","actor_enumeration","possessor"}
    requirements=decision.get("requirements",[])
    # Only a declared visible attachment can license this nominal relation.
    # An unrelated background use of the word cannot establish the focal action.
    visible=set(tokens(reading.get("attachment_quote","")))
    internal=actor and requirements and all(r.get("kind")=="NOMINAL_RELATION" and r.get("predicate") not in visible for r in requirements)
    if not internal:return decision
    result=deepcopy(decision)
    candidate["source_identity_assessment"]=deepcopy(decision)
    result.update(status="exploratory_contextual",label="Exploratory / contextual",coverage="Missing",support_present=False,
        focal_scope_guard=dict(version=VERSION,reason="CANDIDATE_INTERNAL_RELATION_IS_NOT_VISIBLE_GOVERNING_ACTION",source_identity_grounding_preserved=True))
    for r in result["requirements"]:
        r.update(coverage="Missing",direction="Unresolved",source_identity_only=True)
        for witness in r.get("evidence",[]):
            witness.update(source_identity_direction=witness.get("direction"),direction="Context",
                source_identity_only=True,focal_support_certified=False)
    for c in result["checklist"]:
        if c["id"]=="facts":c.update(state="missing",detail="The source grounds an internal description of the candidate, not its participation in the visible governing action.")
    return result


def quoted_owner(case,reading):
    if reading.get("constructor_form")!="nominal" or not any(w.get("kind")=="quotation" for w in reading.get("wrappers",[])):return None
    left=case["query"].split(case["focal_marker"])[0]
    match=re.search(r"\b([A-Z][\w-]*(?:\s+[A-Z][\w-]*)*)['\u2019]s\s*[\"\u201c]$",left)
    return match.group(1) if match else None


def gerund_form(head,parse):
    if head.tag_=="VBG":return head.text
    lemma=head.lemma_.casefold()
    choices={lemma+"ing"}
    if lemma.endswith("e"):choices.add(lemma[:-1]+"ing")
    if lemma.endswith("ie"):choices.add(lemma[:-2]+"ying")
    if len(lemma)>2:choices.add(lemma+lemma[-1]+"ing")
    wn=roles.lexicon()
    valid=[word for word in sorted(choices) if wn.morphy(word,wn.VERB)==lemma
        and any(t.lemma_.casefold()==lemma and t.tag_=="VBG" for t in parse(word))]
    return valid[0] if len(valid)==1 else None


def activity_proposals(case,reading,doc,parse):
    owner=quoted_owner(case,reading)
    if not owner:return []
    output=[]
    for head in doc:
        if head.pos_!="VERB" or head.tag_ not in {"VB","VBG"}:continue
        governor=head
        while not any(c.dep_=="nsubj" for c in governor.children) and governor.dep_=="xcomp" and governor.head.lemma_.casefold() in {"continue","begin","start","resume","keep"}:
            governor=governor.head
        subjects=[c for c in governor.children if c.dep_=="nsubj"]
        if len(subjects)!=1:continue
        subject=" ".join(t.text for t in subjects[0].subtree if t.dep_!="det")
        if " ".join(tokens(subject))!=" ".join(tokens(owner)):continue
        if any(c.dep_=="neg" for token in (head,*head.ancestors) for c in token.children):continue
        arguments=[c for c in head.children if c.dep_ in {"dobj","obj","prep"}
            and not any(t.pos_ in {"VERB","AUX"} and t.tag_ not in {"VBG","VBN"} for t in c.subtree)]
        if not any(c.dep_ in {"dobj","obj"} for c in arguments):continue
        end=max(t.idx+len(t) for c in arguments for t in c.subtree)
        part=doc.char_span(head.idx,end,alignment_mode="strict")
        if part is None or any(t.pos_ in {"AUX","CCONJ"} for t in part):continue
        form=gerund_form(head,parse)
        if form is None:continue
        raw=part.text;realized=form+raw[len(head):]
        edits=[] if raw==realized else [dict(kind="SOURCE_VERB_GERUND_INFLECTION",before=raw,after=realized,
            source_modified=False,grammatical_operation_only=True)]
        output.append(dict(kind="nominal_activity",text=raw,start=part.start_char,end=part.end_char,
            realization=realized,edits=edits,owner=owner,source_predicate=head.text,
            source_scope_preserved_in_quote=True,factual_support_certified=False))
    return output


def projection_context_decision(candidate,decision):
    """Replace only the obsolete nominal syntax veto for two verified projections."""
    form=candidate.get("final_form_fit",{})
    kind=("source_owned_activity" if candidate.get("activity_projection") else
        "declared_nominal_coordination" if form.get("coordinate_head_resolution") else None)
    if not kind:return decision
    if (form.get("state")!="pass" or candidate.get("joint_slot_fit",{}).get("state")!="pass"
            or candidate.get("completed_head_kind_fit",{}).get("state")!="pass"
            or recorded_counter(decision) or decision.get("source_failures")):
        return decision
    checks={c["id"]:c for c in decision.get("checklist",[])}
    if any(checks.get(i,{}).get("state")!="pass" for i in ("provenance","slot_tokens","slot_number")):
        return decision
    permitted={"Nominal fill has nonnominal head","Preposition or connective led nominal"}
    legacy=checks.get("legacy_syntax",{})
    if legacy.get("state")!="pass" and not set(legacy.get("detail","").split("; "))<=permitted:
        return decision
    if checks.get("grammar",{}).get("state")!="pass" and (legacy.get("state")!="conflict"
            or checks.get("grammar",{}).get("detail")!="An explicit insertion conflict is present."):
        return decision
    if any(c.get("state")=="conflict" and c["id"] not in {"grammar","legacy_syntax"}
           for c in checks.values()):return decision
    if any(r.get("direction") in {"Counterevidence","Support + Counterevidence"} or any(
            e.get("direction")=="Counterevidence" for e in r.get("evidence",[])) for r in decision.get("requirements",[])):
        return decision
    candidate["pre_projection_decision"]=deepcopy(decision)
    result=deepcopy(decision)
    result.update(status="exploratory_contextual",label="Exploratory / contextual",coverage="Missing",support_present=False,
        projection_grammar=dict(version=VERSION,kind=kind,source_action_certified=False,
            replaces_only_obsolete_nominal_head_veto=True,whole_english_grammar_certified=False))
    for requirement in result.get("requirements",[]):
        requirement.update(coverage="Missing",direction="Unresolved",evidence=[])
    for check in result["checklist"]:
        if check["id"] in {"grammar","legacy_syntax"}:
            check.update(state="pass",detail="Verified bounded "+kind.replace("_"," ")+" projection; original veto retained separately. No factual support is created.")
    result["what_would_suffice"]=["An eligible quotation establishing the candidate's participation in the same queried action, with matching scope and attribution."]
    return result


def ordering_utility(candidate):
    key=candidate["context_rank_key"]
    f=candidate["ranking"]["features"]
    score=f["retrieval_page_score"]
    if type(score) not in (int,float) or not math.isfinite(score) or score<0:
        raise ValueError("Retrieval utility must be finite and nonnegative")
    value=float(score)/(1+float(score))
    layers=[dict(name="retrieval_relevance",value=value,formula="r/(1+r)")]
    for name,numerator,denominator in (
        ("focal_context",f["focal_context_coverage"],max(f.get("focal_term_count",0),f["focal_context_coverage"])+1),
        ("literal_attachment",f["literal_attachment_coverage"],max(f.get("attachment_term_count",0),f["literal_attachment_coverage"])+1),
        ("whole_context",f["whole_query_context_coverage"],max(f.get("whole_query_term_count",0),f["whole_query_context_coverage"])+1)):
        value=(numerator+value)/denominator
        layers.append(dict(name=name,count=numerator,radix=denominator,value=value))
    value=((not key[10])+value)/2
    layers.append(dict(name="visible_source_anchor",value=value,matched=not key[10]))
    value=(999-min(999,key[9])+value)/1000
    layers.append(dict(name="lexical_role_distance",ordinal=key[9],value=value))
    for i,flag in reversed(list(enumerate(key[:9]))):
        value=((not flag)+value)/2
        layers.append(dict(name="source_priority_"+str(i+1),satisfied=not flag,value=value))
    tier={"evidence_backed_suggestion":2,"partial_grounding":1,"exploratory_contextual":0}.get(candidate["local_decision"]["status"])
    return dict(value=(tier+value)/3 if tier is not None else None,context_order_utility=value,
        native_tier=tier,layers=layers,formula="Nested mixed-radix encoding of the declared source-order key; tier bands divide by 3",
        calibrated=False,correctness_probability=False,confidence_margin=False,
        stable_source_ties_and_float_collisions_use_original_key=True)
