"""Read-only viewer of one explicitly pinned narrative publication."""
import argparse
from copy import deepcopy
from functools import partial
import gzip
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import mimetypes
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlencode, urlsplit

from matryoshka_current import inspection, resources
from matryoshka_current.server import one, ARMS
from matryoshka_demo.io import digest
from . import presentation
from .contracts import engine_case


# Existing presentation modules only; this namespace is never an execution API.
NARRATIVE_DISPLAY_ASSETS = frozenset({"narrative-trace-v1.js",
    "narrative-collections-v1.js", "narrative-scene-v2.js"})
CASE_ROUTE_NAMES = frozenset({"condition-v6", "native-v6", "source-v6", "node-v6",
    "origin-v63", "postrun-review", "flow-v6", "analyst-digest", "guide-v6",
    "guide-view-v6", "guide-overlay-v63", "guide-overlay-v64"})


class Viewer:
    def __init__(self, root, report_ref, maps, *, ui_root=None, casebook_ref=None, digest_ref=None):
        self.root, self.report_ref, self.maps = Path(root).resolve(), deepcopy(report_ref), maps
        self.ui_root = Path(ui_root).resolve() if ui_root is not None else None
        if self.ui_root is not None and not self.ui_root.is_dir():
            raise ValueError("Shared UI root must be an existing directory")
        self.casebook_ref = deepcopy(casebook_ref)
        self.digest_ref = deepcopy(digest_ref)
        self.slots = None
        self.report = presentation.read(self.root, report_ref)
        if self.report["version"] != presentation.VERSION or self.report["sha256"] != digest(
                {k:v for k,v in self.report.items() if k != "sha256"}):
            raise ValueError("Narrative report seal changed")
        self.cases = {r["case"]["case_id"]: r for r in self.report["cases"]}
        if len(self.cases) != len(self.report["cases"]):
            raise ValueError("Duplicate narrative case")
        self.contexts = {}
        self.pdf_catalog = (presentation.read(self.root, self.report["pdf_catalog_ref"])
            if self.report.get("pdf_catalog_ref") else None)

    def pinned_report(self):
        if presentation.read(self.root, self.report_ref) != self.report:
            raise ValueError("Pinned report changed")
        return self.report

    def manifest(self):
        report = self.pinned_report()
        additional = [r["case"]["case_id"] for r in report["cases"] if r.get("selected_additional")]
        return dict(version=presentation.VERSION, report_ref=deepcopy(self.report_ref),
            investigations=deepcopy(report["investigations"]),
            starters=[r["case"]["case_id"] for r in report["cases"] if r["selected_demo"]],
            bench=[r["case"]["case_id"] for r in report["cases"] if r["selected_bench"]],
            additional=additional, additional_real_redaction=deepcopy(additional),
            trace_url="/api/narrative-v1/trace", api_calls=0)

    def casebook(self):
        report = self.pinned_report()
        if self.casebook_ref is None:
            raise ValueError("No exact saved-narrative casebook was selected")
        value = presentation.read(self.root, self.casebook_ref)
        if (value.get("version") != "workbench-casebook/1"
                or value.get("source_report_sha256") != self.report_ref["sha256"]
                or value.get("source_report_run") != report["run_id"]):
            raise ValueError("Casebook belongs to another saved narrative publication")
        primary, special = value.get("primary"), value.get("special_redactions")
        if not isinstance(primary, list) or not isinstance(special, list):
            raise ValueError("Explicit primary and special collections are required")
        for entries in (primary, special):
            seen = set()
            for entry in entries:
                row = self.cases[entry["case_id"]]
                case = row["case"]
                if (case["case_id"] in seen or entry.get("corpus") != case["corpus"]
                        or entry.get("task") != case["task"]
                        or entry.get("case", case) != case
                        or entry.get("resource_binding", row["resource_binding"]) != row["resource_binding"]
                        or entries is special and (case["corpus"], case["task"]) != ("cib", "redaction")):
                    raise ValueError("Casebook changes or repeats a saved case or source resource")
                seen.add(case["case_id"])
        return value

    def asset(self, name):
        if ("/" in name or "\\" in name or name.startswith(".")
                or Path(name).suffix not in {".html", ".js", ".css"}):
            return None
        roots = ([self.ui_root] if self.ui_root is not None else []) + [self.root / "narrative_demo/web"]
        for web in roots:
            target = web / name
            if target.is_symlink():
                raise ValueError("UI assets must not escape the selected directory")
            if target.exists():
                if not target.is_file() or target.resolve().parent != web.resolve():
                    raise ValueError("Unsafe shared UI asset")
                return target
        return None

    def narrative_asset(self, name):
        if name not in NARRATIVE_DISPLAY_ASSETS:
            return None
        web = self.root / "narrative_demo/web"
        target = web / name
        if target.is_symlink() or target.resolve().parent != web.resolve():
            raise ValueError("Unsafe narrative display module")
        return target if target.is_file() else None

    def select(self, params):
        self.pinned_report()
        row = self.cases[one(params, "case_id", "")]
        binding = row["resource_binding"]
        for key in ("resource_id", "registry_sha256", "index_sha256"):
            if one(params, key) != binding[key]:
                raise ValueError("Exact narrative resource pins are required")
        arm = one(params, "config", "llm_readings")
        arm = ARMS.get(arm, arm)
        if arm not in ARMS.values():
            raise ValueError("Unknown saved narrative comparison arm")
        item = row["configurations"][arm]
        condition = presentation.read(self.root, item["condition_ref"])
        native = presentation.read(self.root, item["native_checkpoint"])
        saved = condition["configurations"][arm]
        if (native.get("version") not in {"narrative-local-execution/2", "narrative-local-execution/3"} or
                condition["case"] != row["case"] or native["public_case"] != row["case"] or
                condition["resource_binding"] != binding or
                native["case"] != engine_case(row["case"]) or
                saved["config"] != arm or item["config"] != arm or
                saved["case"] != row["case"] or
                native["query_sha256"] != digest(row["case"]["query"]) or
                native["native_checksum"] != digest(native["result"]) or
                saved.get("version") != "narrative-condition-projection/1" or
                saved["native_record_sha256"] != digest(native) or
                saved["native_checksum"] != digest(native["result"]) or
                saved["native_checkpoint"] != item["native_checkpoint"] or
                saved["resource_binding"] != binding):
            raise ValueError("Condition/native/public question or resource mismatch")
        return row, arm, item, condition, native

    def presentation_context_sources(self, params):
        """Explicitly requested post-attempt introduction evidence, never planning."""
        if set(params) - {"corpus", "narrative_id"}:
            raise ValueError("Unknown introduction-source selector")
        corpus, narrative = one(params, "corpus", ""), one(params, "narrative_id", "")
        if corpus not in {"cib", "iran", "vietnam"}:
            raise ValueError("Explicit corpus required")
        if narrative and not any(r["case"]["corpus"] == corpus and r["narrative_id"] == narrative
                for r in self.report["cases"]):
            raise ValueError("Narrative belongs to another corpus or release")
        ref = self.report.get("presentation_context_sources_ref")
        if not ref:
            raise ValueError("No deferred introduction-source packet")
        value = presentation.read(self.root, ref)
        if value.get("version") != "narrative-presentation-context-sources/1":
            raise ValueError("Unexpected introduction-source version")
        return dict(version=value["version"], corpus=corpus, narrative_id=narrative,
            report_run_id=self.report["run_id"], sources_ref=deepcopy(ref),
            corpora={corpus:deepcopy(value["corpora"][corpus])},
            narratives={narrative:deepcopy(value["narratives"][narrative])} if narrative else {})

    def context(self, native):
        corpus = native["case"]["corpus"]
        refs_path = self.root / "experiments/current_refresh/resource_handoff/registries/db09a0bd26047428e9350b57/execution_refs_v01.json"
        from matryoshka_next.workflow import read
        refs = read(refs_path)
        if native["binding"] != refs["index_refs"][corpus]:
            raise ValueError("Native run belongs to another source index")
        if corpus not in self.contexts:
            self.contexts[corpus] = resources.open_context(self.root, refs["registry_ref"],
                refs["index_refs"][corpus], corpus)
        from matryoshka_demo.source_view_policy import apply_source_view, packet_policy, descriptor
        return apply_source_view(self.contexts[corpus], descriptor(packet_policy(native)))

    def trace(self, row, arm, item, native, reading):
        refs = item.get("trace_refs", {})
        ref = refs.get(reading)
        if ref is None and not reading and len(refs) == 1:
            ref = next(iter(refs.values()))
        if ref is None:
            raise ValueError("No saved trace for this exact reading")
        value = presentation.read(self.root, ref)
        if (value.get("sha256") != digest({k:v for k,v in value.items() if k != "sha256"}) or
                value["case_id"] != row["case"]["case_id"] or value.get("config") != arm or
                value["query_sha256"] != digest(row["case"]["query"]) or
                value["case"] != native["case"] or
                reading and value.get("reading_id") != reading or
                value["native_checkpoint"] != item["native_checkpoint"] or
                value["resource_binding"] != row["resource_binding"]):
            raise ValueError("Trace/native/source binding mismatch")
        return value

    def saved_flow(self, row, arm, item, native, params):
        limit = int(one(params, "limit", "1024"))
        if not 32 <= limit <= 2048:
            raise ValueError("Invalid saved trace inspection bound")
        reading = one(params, "reading", "")
        refs = item.get("trace_refs", {})
        if refs:
            trace = self.trace(row, arm, item, native, reading)
        else:
            readings = {r["reading"]["id"] for r in native["result"].get("readings", [])}
            if reading and reading not in readings:
                raise ValueError("Unknown saved reading")
            trace = None
        # A selected-evidence trace is not a numerical diffusion projection.
        return dict(version="narrative-saved-flow/1", available=trace is not None,
            status="SAVED_TRACE" if trace is not None else "NO_SAVED_TRACE",
            case_id=row["case"]["case_id"], config=arm,
            reading_id=trace["reading_id"] if trace is not None else reading,
            query_sha256=digest(row["case"]["query"]),
            native_checkpoint=deepcopy(item["native_checkpoint"]),
            native_version=native["version"], resource_binding=deepcopy(row["resource_binding"]),
            execution_kind="saved_narrative", current_native_execution=False,
            trace=trace, numerical_projection_available=False,
            graph_route_available=bool(trace and any(p["graph_hops"] for p in trace["paths"])),
            reason=None if trace is not None else "No saved trace or graph route is published for this exact execution.",
            native_decisions_or_ranks_modified=False, api_calls=0)

    def origin(self, row, reveal):
        if reveal not in {"0", "1"}:
            raise ValueError("Explicit focal reveal selection required")
        state = "revealed" if reveal == "1" and row["case"]["task"] == "redaction" else "masked"
        value = presentation.read(self.root, row["origin_refs"][state])
        if (any(value[k] != row["case"][k] for k in ("case_id", "corpus", "task", "document_id", "date", "query"))
                or value["query_sha256"] != digest(row["case"]["query"])
                or value["text_sha256"] != digest(value["text"]) or value["eligible_evidence"] is not False):
            raise ValueError("Original source display mismatch")
        return dict(value, resource_binding=row["resource_binding"])

    def api(self, name, params):
        common = {"case_id", "config", "resource_id", "registry_sha256", "index_sha256"}
        extras = {"trace": {"reading"}, "condition-v6": set(), "native-v6": set(),
            "flow-v6": {"reading", "limit"}, "analyst-digest": set(),
            "origin-v63": {"reveal_focal"}, "postrun-review": {"reveal"}, "source-v6": {"source_id"},
            "node-v6": {"node_id"}, "guide-v6": {"reading", "candidate_id", "route_index"},
            "guide-overlay-v63": {"reading", "candidate_id", "route_index"},
            "guide-overlay-v64": {"reading", "candidate_id", "route_index"},
            "guide-view-v6": {"reading", "candidate_id", "route_index", "phase", "source_id", "node_id",
                "hop_index", "limit", "offset", "page_size"}}
        if name not in extras or set(params) - common - extras[name]:
            raise ValueError("Unsupported narrative API selector")
        if name == "analyst-digest" and not common.issubset(params):
            raise ValueError("Saved digest requires an explicit question, arm and resource binding")
        for key in params:
            one(params, key)
        row, arm, item, condition, native = self.select(params)
        binding = row["resource_binding"]
        if name == "condition-v6":
            return condition
        if name == "native-v6":
            return dict(native=native, resource_binding=binding)
        if name == "flow-v6":
            return self.saved_flow(row, arm, item, native, params)
        if name == "analyst-digest":
            if self.digest_ref is not None:
                from .analyst_digest import read_for_case
                return read_for_case(self.root, self.digest_ref, self.report_ref,
                    row["case"], arm, item, native, binding)
            return dict(version="narrative-saved-digest/1", available=False,
                status="NO_SAVED_DIGEST", case_id=row["case"]["case_id"], config=arm,
                native_checkpoint=deepcopy(item["native_checkpoint"]), native_version=native["version"],
                resource_binding=binding, execution_kind="saved_narrative", current_native_execution=False,
                reason="No exact saved analyst digest is attached; no current-engine or generated digest was substituted.",
                postrun=True, used_for_inference=False, api_calls=0)
        if name == "postrun-review":
            if one(params, "reveal", "0") not in {"0", "1"}:
                raise ValueError("Explicit post-run reveal selection required")
            return dict(available=False, answer_aware=True, used_for_inference=False, resource_binding=binding)
        if name == "origin-v63":
            return self.origin(row, one(params, "reveal_focal", "0"))
        if name == "trace":
            return self.trace(row, arm, item, native, one(params, "reading", ""))
        context = self.context(native)
        if name == "source-v6":
            return dict(inspection.source(context, native["case"], one(params, "source_id")), resource_binding=binding)
        if name == "node-v6":
            return dict(inspection.node(context, native["case"], one(params, "node_id")), resource_binding=binding)
        trace = self.trace(row, arm, item, native, one(params, "reading", ""))
        from .traces import guide_packet
        identity = one(params, "candidate_id", "")
        choices = [p for p in trace["paths"] if p["id"] == identity or
            p["candidate_or_atom_id"] == identity or p["candidate_or_atom_id"].rsplit("/", 1)[-1] == identity]
        route_index = int(one(params, "route_index", "0"))
        if route_index < 0:
            raise ValueError("Negative saved route index")
        selected = choices[route_index]
        guide = guide_packet(trace, selected["id"], context)
        if name == "guide-v6":
            return dict(guide, resource_binding=binding)
        value = (inspection.guide_view(context, native["case"], guide, params) if name == "guide-view-v6" else
            inspection.guide_overlay(context, native["case"], guide))
        return dict(value, resource_binding=binding)

    def close(self):
        for context in self.contexts.values():
            context.close()

    def pdf(self, params):
        allowed = {"case_id", "config", "resource_id", "registry_sha256", "index_sha256", "doc_id", "release"}
        if set(params) - allowed:
            raise ValueError("Unknown PDF selector")
        row, _, _, _, native = self.select(params)
        case = row["case"]
        document, release = one(params, "doc_id"), one(params, "release")
        if case["corpus"] != "cib" or release not in {"earlier", "later"}:
            raise ValueError("CIB release PDF required")
        if document != case["document_id"]:
            from matryoshka_next.facts import SourcePolicy
            context = self.context(native)
            policy = SourcePolicy(context.corpus, native["case"], context.source_index)
            if release != "earlier" or not any(p["document_id"] == document and policy.allowed(i)
                    for i,p in enumerate(context.corpus.pages)):
                raise ValueError("PDF is outside the eligible evidence view")
        elif not row["origin_refs"]:
            raise ValueError("The original requires verified source provenance")
        else:
            self.origin(row, "0")
        if self.pdf_catalog is not None and document + "/" + release in self.pdf_catalog["entries"]:
            from . import pdfs
            current = presentation.read(self.root, self.report["pdf_catalog_ref"])
            if current != self.pdf_catalog:
                raise ValueError("Pinned PDF catalog changed")
            return pdfs.read(self.root, current, document, release)
        if self.maps is None:
            raise ValueError("No exact PDF catalog or immutable map export selected")
        raw, mime = self.maps.packet("/api/cib-pdf?" + urlencode(sorted(dict(doc_id=document, release=release).items())))
        if not raw.startswith(b"%PDF-") or not mime.startswith("application/pdf"):
            raise ValueError("PDF source returned another content type")
        return raw, mime


class Handler(BaseHTTPRequestHandler):
    def __init__(self, *args, viewer, **kwargs):
        self.viewer = viewer
        super().__init__(*args, **kwargs)

    def send_bytes(self, raw, mime="application/json; charset=utf-8"):
        encoded = "gzip" in self.headers.get("Accept-Encoding", "") and len(raw) > 2048 and not mime.startswith("application/pdf")
        if encoded:
            raw = gzip.compress(raw, compresslevel=1, mtime=0)
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if encoded:
            self.send_header("Content-Encoding", "gzip")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlsplit(self.path)
        path, params = unquote(parsed.path), parse_qs(parsed.query, keep_blank_values=True)
        try:
            if path == "/api/health":
                self.viewer.pinned_report()
                value = dict(status="ok", service="narrative-resource-workbench", report_ref=self.viewer.report_ref,
                    cases=len(self.viewer.cases), api_calls=0, live_inference=False,
                    execution_kind="saved_narrative", current_native_execution=False,
                    narrative_display_assets="/narrative-assets/", display_modules_only=True)
            elif path == "/api/narrative-v1/manifest":
                if params:
                    raise ValueError("Manifest has no case selectors")
                value = self.viewer.manifest()
            elif path in {"/data/report-v6.json", "/api/current/report-v6"}:
                if params:
                    raise ValueError("Report has no case selectors")
                self.viewer.pinned_report()
                return self.send_bytes((self.viewer.root / self.viewer.report_ref["path"]).read_bytes())
            elif path == "/api/current/casebook":
                if params:
                    raise ValueError("Casebook has no case selectors")
                value = self.viewer.casebook()
            elif path == "/api/current/slots-v1":
                self.viewer.pinned_report()
                if self.viewer.maps is None:
                    raise ValueError("Opaque slots require the explicitly pinned immutable corpus map")
                if self.viewer.slots is None:
                    from matryoshka_current.slot_overlay import SlotOverlay
                    self.viewer.slots = SlotOverlay(self.viewer.maps, self.viewer.report["cases"])
                value = self.viewer.slots.packet(params)
            elif path == "/api/narrative-v1/trace":
                value = self.viewer.api("trace", params)
            elif path == "/api/narrative-v1/presentation-context-sources":
                value = self.viewer.presentation_context_sources(params)
            elif path == "/api/current/cib-pdf":
                raw, mime = self.viewer.pdf(params)
                return self.send_bytes(raw, mime)
            elif path.startswith("/api/current/") or path in {"/api/" + name for name in CASE_ROUTE_NAMES}:
                value = self.viewer.api(path.rsplit("/", 1)[-1], params)
            elif path.startswith("/narrative-assets/"):
                target = self.viewer.narrative_asset(path.removeprefix("/narrative-assets/"))
                if target is None:
                    return self.send_error(404, "No allowlisted narrative display module")
                return self.send_bytes(target.read_bytes(), "text/javascript; charset=utf-8")
            elif path.startswith("/graph-assets-v4/") or path in {"/api/graph-v4-viewer", "/api/cib-pdf"}:
                if self.viewer.maps is None:
                    raise ValueError("No pinned immutable map export selected")
                query = urlencode(sorted((k, one(params, k)) for k in params))
                raw, mime = self.viewer.maps.packet(path + ("?" + query if query else ""))
                return self.send_bytes(raw, mime)
            elif path == "/docs/matryoshka-guide.pdf":
                from matryoshka_current.planning import bound
                raw = bound(self.viewer.root, "docs/demo-guide/guide.pdf").read_bytes()
                if not raw.startswith(b"%PDF-"):
                    raise ValueError("The illustrated guide is not a PDF")
                return self.send_bytes(raw, "application/pdf")
            else:
                name = ("workbench-v6.html" if path in {"/", "/index.html"} and "case" in params and one(params, "view") != "home" else
                    "corpus-home.html" if path in {"/", "/index.html"} else path.lstrip("/"))
                target = self.viewer.asset(name)
                if target is None:
                    return self.send_error(404)
                return self.send_bytes(target.read_bytes(), mimetypes.guess_type(name)[0] or "application/octet-stream")
            self.send_bytes(json.dumps(value, ensure_ascii=True, allow_nan=False, separators=(",", ":")).encode())
        except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
            self.log_error("Narrative request rejected: %s", str(error))
            self.send_error(409, "The exact saved narrative artifact is unavailable")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--report", required=True)
    parser.add_argument("--report-sha256", required=True)
    parser.add_argument("--map-root", type=Path, default=Path(__file__).resolve().parents[2] / "matryoshka_demo_site")
    parser.add_argument("--map-index-sha256", default="37554272d5a2987248dc8c3fd9df2566bcea6ef8c076dbbbbafe8fba12354a27")
    parser.add_argument("--ui-root", type=Path, help="Optional shared UI root; display assets only, no execution changes")
    parser.add_argument("--casebook", help="Optional exact saved-narrative casebook path")
    parser.add_argument("--casebook-sha256", help="Byte pin for the optional casebook")
    parser.add_argument("--digest-index", help="Optional detached source-bound analyst digest index")
    parser.add_argument("--digest-index-sha256", help="Byte pin for the optional digest index")
    parser.add_argument("--source-workspace", help="Workspace containing the paired physical source PDFs")
    parser.add_argument("--pdf-catalog", help="Optional exact LocalPDFs catalog path relative to --root")
    parser.add_argument("--pdf-catalog-sha256", help="Byte pin for the LocalPDFs catalog")
    parser.add_argument("--port", type=int, default=8942)
    args = parser.parse_args(argv)
    if bool(args.casebook) != bool(args.casebook_sha256):
        parser.error("Both saved-narrative casebook path and byte pin are required")
    if bool(args.digest_index) != bool(args.digest_index_sha256):
        parser.error("Both analyst digest index path and byte pin are required")
    pdf_args = (args.source_workspace, args.pdf_catalog, args.pdf_catalog_sha256)
    if any(pdf_args) and not all(pdf_args):
        parser.error("Local PDF inspection requires workspace, catalog and catalog pin")
    pdfs = None
    if all(pdf_args):
        from matryoshka_current.local_pdfs import LocalPDFs
        pdfs = LocalPDFs(args.source_workspace, args.root,
            dict(path=args.pdf_catalog, sha256=args.pdf_catalog_sha256))
    from matryoshka_current.map_transport import SavedMaps
    viewer = Viewer(args.root, dict(path=args.report, sha256=args.report_sha256),
        SavedMaps(args.map_root, args.map_index_sha256, pdfs=pdfs), ui_root=args.ui_root,
        casebook_ref=dict(path=args.casebook, sha256=args.casebook_sha256) if args.casebook else None,
        digest_ref=dict(path=args.digest_index, sha256=args.digest_index_sha256) if args.digest_index else None)
    server = HTTPServer(("127.0.0.1", args.port), partial(Handler, viewer=viewer))
    print(f"Narrative workbench: http://127.0.0.1:{args.port}/", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
        viewer.close()


if __name__ == "__main__":
    main()
