"""Consolidate attested variants of one source occurrence, not surnames."""
from copy import deepcopy
import math
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest

VERSION = "source-occurrence-candidate-consolidation/1"
SOURCE_LOCAL_VERSION = "query-bound-source-occurrence-candidate-consolidation/3"


def occurrence_key(candidate):
    form = candidate.get("completed_head_kind_fit", {})
    span = form.get("mapped_source_head_span")
    if not isinstance(span, (list, tuple)) or len(span) != 2:
        return None
    sources = [s for s in candidate.get("sources", []) if isinstance(s, dict)
        and s.get("start", -1) <= span[0] < span[1] <= s.get("end", -1)]
    if not sources:
        return None
    # The first source is the producer's primary occurrence. Other pages cannot
    # establish that a matching surname denotes this historical person.
    ref = sources[0]
    if not ref.get("page_sha256") or not ref.get("canonical_page_id"):
        return None
    text = ref.get("text", "")
    if len(text) != ref["end"] - ref["start"]:
        return None
    raw_span = candidate.get("source_span")
    if (not isinstance(raw_span, (list, tuple)) or len(raw_span) != 2
            or any(type(x) is not int for x in (*span, *raw_span))
            or not ref["start"] <= raw_span[0] <= span[0] < span[1] <= raw_span[1] <= ref["end"]
            or text[raw_span[0]-ref["start"]:raw_span[1]-ref["start"]] != candidate.get("source_wording")):
        return None
    head_start, head_end = span[0]-ref["start"], span[1]-ref["start"]
    if ((head_start > 0 and re.match(r"\w", text[head_start-1]))
            or (head_end < len(text) and re.match(r"\w", text[head_end]))):
        return None
    decision = candidate.get("local_decision", {})
    requirements = tuple((r.get("id"), str(r.get("coverage")), r.get("direction"))
        for r in decision.get("requirements", []))
    return (candidate.get("reading_id"), ref["document_id"], ref["canonical_page_id"],
        ref["page_sha256"], tuple(span), decision.get("status"), decision.get("scope"),
        requirements, bool(decision.get("counterevidence")))


def consolidate(candidates, *, score=None, source_local_identity=False, query_sha256=None):
    """Keep the most complete already-checked wording; never construct a name."""
    if type(source_local_identity) is not bool:
        raise ValueError("Source-local identity must be explicitly enabled with a boolean")
    if source_local_identity:
        if not isinstance(query_sha256, str) or re.fullmatch(r"[0-9a-f]{64}", query_sha256) is None:
            raise ValueError("Source-local identity requires the actual result query_sha256")
        return _source_local_consolidate(list(candidates), score, query_sha256)
    groups = {}
    for candidate in candidates:
        key = occurrence_key(candidate)
        groups.setdefault(key if key is not None else ("unbound", candidate["id"]), []).append(candidate)
    output = []
    for variants in groups.values():
        best = max(variants, key=lambda c: (len(c.get("source_wording", "").split()),
            len(c.get("source_wording", "")), -c.get("source_rank_position", 10**9), c["id"]))
        value = deepcopy(best)
        if len(variants) > 1:
            # Do not union support requirements across different variants. Each
            # selected decision remains the original producer's checked one.
            value["identity_consolidation"] = dict(version=VERSION,
                rule="SAME_EXACT_SOURCE_HEAD_AND_DECISION_SCOPE", decisions_pooled=False,
                cross_document_identity_inferred=False, variants=[dict(id=c["id"],
                    fill=c["fill"], source_wording=c.get("source_wording"),
                    source_span=deepcopy(c.get("source_span")),
                    local_decision=deepcopy(c.get("local_decision")),
                    raw_score=deepcopy(score(c) if score else c.get("terminal_scorecard")),
                    sources=deepcopy(c.get("sources", []))) for c in variants])
        output.append(value)
    return output


def _span(value):
    return (isinstance(value, (list, tuple)) and len(value) == 2
        and all(type(n) is int for n in value) and 0 <= value[0] < value[1])


def _citation(ref):
    return (isinstance(ref, dict) and all(isinstance(ref.get(k), str) and ref[k]
        for k in ("document_id", "canonical_page_id", "page_sha256", "text"))
        and _span([ref.get("start"), ref.get("end")])
        and len(ref["text"]) == ref["end"] - ref["start"])


def _literal(ref, span, text):
    if not _citation(ref) or not _span(span) or not ref["start"] <= span[0] < span[1] <= ref["end"]:
        return False
    a, b = span[0] - ref["start"], span[1] - ref["start"]
    return (ref["text"][a:b] == text
        and (a == 0 or not re.match(r"\w", ref["text"][a-1]))
        and (b == len(ref["text"]) or not re.match(r"\w", ref["text"][b])))


def _decision_key(candidate):
    decision = deepcopy(candidate.get("local_decision", {}))
    decision.pop("id", None)
    decision.pop("source_passages", None)
    for requirement in decision.get("requirements", []):
        # Evidence stays attached to its raw variant, never to a reconstructed
        # requirement. All other requirement fields must agree exactly.
        for key in ("citations", "context_citations", "evidence"):
            requirement.pop(key, None)
        if isinstance(requirement.get("text"), str):
            requirement["text"] = requirement["text"].replace(candidate["fill"], "[IDENTITY]")
    return digest(dict(reading_id=candidate.get("reading_id"), decision=decision))


def _view(candidate, query_sha256):
    """Replay existing source observations, not query/name ranking authority."""
    decision = candidate.get("local_decision", {})
    if (candidate.get("final_form_fit", {}).get("state") != "pass"
            or decision.get("status") not in {"evidence_backed_suggestion", "partial_grounding", "exploratory_contextual"}
            or any(c.get("id") == "grammar" and c.get("state") != "pass" for c in decision.get("checklist", []))):
        return None
    if (decision.get("id", candidate["id"]) != candidate["id"]
            or decision.get("reading_id", candidate.get("reading_id")) != candidate.get("reading_id")
            or candidate.get("declared_reading", {}).get("id", candidate.get("reading_id")) != candidate.get("reading_id")
            or candidate.get("controller_shortlist_eligibility", {}).get("query_sha256", query_sha256) != query_sha256):
        return None
    span = candidate.get("source_span")
    head = candidate.get("completed_head_kind_fit", {}).get("mapped_source_head_span")
    sources = candidate.get("sources", [])
    if not sources or not _span(span) or not _span(head):
        return None
    ref = sources[0]
    if (not _literal(ref, span, candidate.get("source_wording"))
            or not span[0] <= head[0] < head[1] <= span[1]
            or MASK.search(ref["text"]) or not isinstance(ref.get("date"), str)):
        return None
    primary = [o for o in candidate.get("source_occurrences", [])
        if o.get("source_span") == span and o.get("source_wording") == candidate["source_wording"]
        and o.get("citation") == ref]
    if not primary:
        return None
    occurrence = primary[0]
    context = candidate.get("source_claim_context") or {}
    if context != occurrence.get("source_claim_context"):
        return None
    source_head = context.get("source_head", {})
    head_text = ref["text"][head[0]-ref["start"]:head[1]-ref["start"]]
    if (source_head.get("span") != head or source_head.get("text") != head_text
            or source_head.get("pos") != "PROPN" or not _literal(ref, head, head_text)):
        return None
    prior = occurrence.get("selection_cue", {}).get("focal_name_prior", {})
    source = prior.get("source", {})
    if (prior.get("version") != "focal-paragraph-visible-person-negative-prior/1"
            or not isinstance(prior.get("query_context"), dict)
            or prior["query_context"].get("query_sha256") != query_sha256
            or prior.get("binding_sha256") != digest(dict(query_context=prior["query_context"], source=source))
            or source.get("span") != span or source.get("wording") != candidate["source_wording"]
            or source.get("citation_sha256") != digest(ref)
            or any(source.get(k) != ref[k] for k in ("document_id", "canonical_page_id", "page_sha256"))):
        return None
    proper = source.get("proper_tokens", [])
    if not proper or any(t.get("pos") != "PROPN" or not _literal(ref,
            [t.get("start"), t.get("end")], t.get("text"))
            or not span[0] <= t["start"] < t["end"] <= span[1] for t in proper):
        return None
    if any(a["end"] > b["start"] for a, b in zip(proper, proper[1:])):
        return None
    kind = candidate.get("completed_head_kind_fit", {})
    compatibility = candidate.get("context_slot_compatibility") or {}
    if not (kind.get("state") == "pass" and "person" in kind.get("observed_kinds", [])
            or compatibility.get("state") == "possible" and compatibility.get("person_ner")):
        return None
    paragraph = context.get("paragraph")
    if paragraph is not None:
        if (context.get("paragraph_withheld_for_opacity") or not _citation(paragraph)
                or any(paragraph[k] != ref[k] for k in ("document_id", "canonical_page_id", "page_sha256"))
                or not _literal(paragraph, span, candidate["source_wording"])
                or MASK.search(paragraph["text"]) or re.search(r"\n[ \t]*\n|\r[ \t]*\r", paragraph["text"])):
            return None
        a, b = max(ref["start"], paragraph["start"]), min(ref["end"], paragraph["end"])
        if ref["text"][a-ref["start"]:b-ref["start"]] != paragraph["text"][a-paragraph["start"]:b-paragraph["start"]]:
            return None
    names = []
    witnesses = [dict(start=w.get("start"), end=w.get("end"), text=w.get("label"))
        for w in kind.get("head_witnesses", []) if w.get("source_entity_type") == "Person"
        and w.get("canonical_page_id") == ref["canonical_page_id"] and w.get("page_sha256") == ref["page_sha256"]]
    witnesses += compatibility.get("person_ner", [])
    roles = occurrence.get("features", {}).get("source_owned_role_context", {}).get("owned_roles", [])
    bound_person = False
    for witness in witnesses:
        name_span = [witness.get("start"), witness.get("end")]
        if (not _literal(ref, name_span, witness.get("text"))
                or not name_span[0] <= head[0] < head[1] <= name_span[1]):
            continue
        bound_person = True
        if not span[0] <= name_span[0] < name_span[1] <= span[1]:
            continue
        # Producer-owned title spans are not given names.
        start = max([name_span[0]] + [r["span"][1] for r in roles
            if _span(r.get("span")) and name_span[0] <= r["span"][0] < r["span"][1] <= head[0]])
        tokens = [t for t in proper if start <= t["start"] and t["end"] <= name_span[1]]
        if len(tokens) >= 2 and tokens[-1]["start"] == head[0] and tokens[-1]["end"] == head[1]:
            names.append(dict(start=tokens[0]["start"], end=head[1],
                text=ref["text"][tokens[0]["start"]-ref["start"]:head[1]-ref["start"]]))
    if not bound_person:
        return None
    return dict(candidate=candidate, ref=ref, span=span, head=head, head_text=head_text,
        proper=proper, names=names, paragraph=paragraph, decision_key=_decision_key(candidate),
        source_key=tuple(ref[k] for k in ("document_id", "canonical_page_id", "page_sha256", "date")))


def _document_audit(variants, scores):
    best = {}
    for candidate, score in zip(variants, scores):
        if not score:
            continue
        refs = []
        def citations(value):
            if isinstance(value, dict):
                if _citation(value):
                    refs.append(value)
                else:
                    for item in value.values():
                        citations(item)
            elif isinstance(value, list):
                for item in value:
                    citations(item)
        citations(candidate.get("sources", []))
        citations(candidate.get("local_decision", {}))
        for row in score.get("contributions", []):
            ref, amount = row.get("citation"), row.get("contribution")
            if (row.get("direction") not in {"support", "oppose", "context"} or not _citation(ref)
                    or row.get("document_id") != ref["document_id"] or ref not in refs
                    or type(amount) not in (float, int) or not math.isfinite(amount) or amount < 0):
                raise ValueError("Identity audit received an unbound raw evidence contribution")
            key = (row["direction"], row["document_id"])
            if key not in best or amount > best[key]["contribution"]:
                best[key] = dict(deepcopy(row), raw_candidate_id=candidate["id"])
    rows = [best[key] for key in sorted(best)]
    return dict(rule="MAX_PER_DOCUMENT_AND_DIRECTION", contributions=rows,
        totals={direction: sum(r["contribution"] for r in rows if r["direction"] == direction)
            for direction in ("support", "oppose", "context")},
        audit_only=True, applied_to_candidate_score=False, requirements_pooled=False)


def _source_local_consolidate(candidates, score, query_sha256):
    if len({c["id"] for c in candidates}) != len(candidates):
        raise ValueError("Distinct raw candidate IDs required")
    views = [_view(c, query_sha256) for c in candidates]
    groups = {}
    for i, view in enumerate(views):
        key = ((view["source_key"], digest(view["ref"]), tuple(view["head"]), view["decision_key"])
            if view is not None else ("unbound", candidates[i]["id"]))
        groups.setdefault(key, []).append(i)
    output = []
    for indices in groups.values():
        best = max(indices, key=lambda i: (max([0] + [len(n["text"].split()) for n in (views[i] or {}).get("names", [])]),
            len((views[i] or {}).get("proper", [])), len(candidates[i].get("source_wording", "").split()),
            len(candidates[i].get("source_wording", "")), -candidates[i].get("source_rank_position", 10**9), candidates[i]["id"]))
        value = deepcopy(candidates[best])
        if len(indices) > 1:
            variants = [candidates[i] for i in indices]
            scores = [deepcopy(score(c) if score else c.get("terminal_scorecard")) for c in variants]
            value["identity_consolidation"] = dict(version=SOURCE_LOCAL_VERSION,
                rule="SAME_EXACT_SOURCE_HEAD_AND_CITATION", representative_id=value["id"],
                query_sha256=query_sha256, cross_occurrence_identity_inferred=False,
                decisions_pooled=False, cross_document_identity_inferred=False,
                representative_score_unchanged=True, identity_proofs_add_evidence_credit=False,
                proofs=[dict(rule="SAME_EXACT_SOURCE_HEAD_AND_CITATION", citation=deepcopy(views[best]["ref"]),
                    head_span=deepcopy(views[best]["head"]), factual_support_certified=False)],
                document_evidence=_document_audit(variants, scores),
                variants=[dict(id=c["id"], fill=c["fill"], source_wording=c["source_wording"],
                    source_span=deepcopy(c["source_span"]), local_decision=deepcopy(c["local_decision"]),
                    sources=deepcopy(c["sources"]), raw_score=s, raw_candidate=deepcopy(c))
                    for c, s in zip(variants, scores)])
        output.append(value)
    return output
