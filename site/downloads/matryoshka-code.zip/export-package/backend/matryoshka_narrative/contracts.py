"""Public task vocabulary and one explicit frozen-engine compatibility boundary."""
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_demo.io import digest

TASKS = ("mosaic", "hypothesis", "redaction")
LEGACY_TASKS = {"mosaic": "reconstruction", "hypothesis": "hypothesis", "redaction": "redaction"}
VERSION = "narrative-public-contract/1"


@lru_cache(maxsize=2048)
def _declarative(task, query):
    if re.match(r"^(?:assess|reconstruct|identify|determine|evaluate|trace|provide|summarize|explain|describe|test)\b", query, re.I):
        return False
    if query.endswith("?"):
        return False
    if task == "redaction":
        return True
    from matryoshka_next.readings import _model
    doc = _model()(query)
    return any(t.pos_ in {"VERB", "AUX"} and t.tag_ in {"VBD", "VBP", "VBZ", "MD"}
        for t in doc)


def engine_case(case):
    if case.get("task") not in TASKS:
        raise ValueError("Use the public Mosaic, Hypothesis or Redaction task")
    value = deepcopy(case)
    value["task"] = LEGACY_TASKS[case["task"]]
    return value


def public_query(case):
    """Never copy the source-aware curator or answer-bearing case dictionary."""
    if case.get("task") not in TASKS or not isinstance(case.get("query"), str):
        raise ValueError("A public task and analyst clause are required")
    query = case["query"].strip()
    if not query or not _declarative(case["task"], query):
        raise ValueError("Narrative queries must be ordinary declarative clauses")
    return dict(task=case["task"], query=query, focal_marker=case.get("focal_marker"))


def identity(case):
    return digest(dict(version=VERSION, **public_query(case)))
