"""Saved relevance, separate native coverage and gates; never probabilities."""
from collections import Counter, defaultdict
from copy import deepcopy
import math

from matryoshka_demo.io import digest
from .traces import SourceReplay, decision_items, evidence_inventory, packet_view


VERSION = "narrative-scorecards/2"
_STATES = {"SUPPORT":"SUPPORTED", "ESTABLISHED":"SUPPORTED", "SUPPORTED":"SUPPORTED",
    "OPPOSED":"OPPOSED", "COUNTER":"OPPOSED", "CONFLICTED":"CONFLICTED", "PARTIAL":"PARTIAL",
    "INSUFFICIENT":"UNRESOLVED", "NO_INFO":"UNRESOLVED", "UNRESOLVED":"UNRESOLVED"}


def _number(value):
    if type(value) not in (int,float) or not math.isfinite(value):
        raise ValueError("Finite actual numeric score required")
    return value


def reciprocal_rank_scores(rankings, *, k=60):
    """Exact arithmetic over explicit complete lists, not truncated receipts."""
    if type(k) is not int or k < 1:
        raise ValueError("Positive integer RRF constant required")
    contributions = defaultdict(list)
    for channel, order in enumerate(rankings):
        if len(order) != len(set(order)) or any(not isinstance(key,str) for key in order):
            raise ValueError("Rank lists require distinct string identities")
        for rank,key in enumerate(order,1):
            contributions[key].append(dict(channel=channel, rank=rank, value=1/(k+rank)))
    rows = [dict(id=key, score=sum(c["value"] for c in values), contributions=values)
            for key,values in contributions.items()]
    return dict(k=k, formula="sum(1/(k+rank))", rankings_sha256=digest(rankings),
        rows=sorted(rows,key=lambda r:(-r["score"],r["id"])), correctness_probability=False)


def build_scorecards(packet, corpus=None, source_index=None, *, max_documents=100):
    """Use persisted rubric fields; missing values remain explicitly unrecorded."""
    if type(max_documents) is not int or not 1 <= max_documents <= 256:
        raise ValueError("Invalid finite document display bound")
    case,plan,result,receipt = packet_view(packet)
    raw_packet = packet.get("packet",packet)
    live = raw_packet.get("retrieval",result.get("retrieval",{}))
    items = decision_items(case,plan,result)
    replay = None
    if corpus is not None:
        inspected = packet.get("inspected_page_ids", result.get("inspected_page_ids"))
        if inspected is None:
            raise ValueError("Source verification needs the exact inspected pool")
        replay = SourceReplay(corpus,case,inspected,source_index)
    inventory = evidence_inventory(items,replay)
    by_item = defaultdict(list)
    for row in inventory:
        by_item[row["item_id"]].append(row)
    page_cards = {}

    def page(pid, did=None):
        if not isinstance(pid,str):
            raise ValueError("Saved page identity required")
        if corpus is not None:
            actual = replay.pages.get(pid)
            if actual is None or not replay.allowed(actual):
                raise ValueError("Scored page is outside the eligible bound corpus")
            if did is not None and did != actual["document_id"]:
                raise ValueError("Scored page/document mismatch")
            did = actual["document_id"]
        row = page_cards.setdefault(pid,dict(page_id=pid,document_id=did,observations=[]))
        if did is not None and row["document_id"] not in (None,did):
            raise ValueError("Conflicting saved document identity")
        if did is not None:
            row["document_id"] = did
        return row

    for i,search in enumerate(receipt.get("search_queries", [])):
        for j,top in enumerate(search.get("top_pages", [])):
            pid = top if isinstance(top,str) else top["page_id"]
            card = page(pid, None if isinstance(top,str) else top.get("document_id"))
            observation = dict(kind="BM25_SEARCH", search_index=i, query=search["query"],
                saved_rank=j+1, value=_number(top["bm25"]) if isinstance(top,dict) and "bm25" in top else None,
                numeric_status="RECORDED" if isinstance(top,dict) and "bm25" in top else "UNRECORDED",
                provenance=f"/retrieval/search_queries/{i}/top_pages/{j}")
            card["observations"].append(observation)
    for i,source in enumerate(receipt.get("top_sources", [])):
        card = page(source["page_id"],source.get("document_id"))
        card["observations"].append(dict(kind="NATIVE_RETRIEVAL_RRF", value=_number(source["rrf"]) if "rrf" in source else None,
            numeric_status="RECORDED" if "rrf" in source else "UNRECORDED", page_rank=source.get("page_rank"),
            provenance=f"/retrieval/top_sources/{i}"))
    for i,source in enumerate(receipt.get("seeded_documents", [])):
        card = page(source["page_id"],source["document_id"])
        if "lexical_rrf" in source:
            card["observations"].append(dict(kind="LEXICAL_RRF",value=_number(source["lexical_rrf"]),
                numeric_status="RECORDED",provenance=f"/retrieval/seeded_documents/{i}/lexical_rrf"))
    live_scores = []
    if "receipt" in live and live.get("page_scores"):
        if corpus is None:
            raise ValueError("Live numeric page indices require the explicit Corpus")
        for pi,value in sorted(live["page_scores"].items()):
            if type(pi) is not int or not 0 <= pi < len(corpus.pages):
                raise ValueError("Live score has no actual Corpus page index")
            p = corpus.pages[pi]
            observation = dict(kind="NATIVE_RETRIEVAL_RRF",value=_number(value),numeric_status="LIVE_RECORDED",
                page_rank=live.get("page_ranks",{}).get(pi),provenance=f"/retrieval/page_scores/{pi}")
            page(p["id"],p["document_id"])["observations"].append(observation)
            live_scores.append(dict(page_id=p["id"],**observation))
    documents = defaultdict(list)
    for card in page_cards.values():
        # A truncated top-page list without source metadata cannot invent a doc ID.
        documents[card["document_id"] or "UNBOUND_PAGE:"+card["page_id"]].append(card)
    document_cards = []
    for did,pages in sorted(documents.items()):
        observations = [o for p in pages for o in p["observations"]]
        document_cards.append(dict(document_id=did if not did.startswith("UNBOUND_PAGE:") else None,
            pages=sorted(pages,key=lambda p:p["page_id"]),
            bm25_max=max((o["value"] for o in observations if o["kind"] == "BM25_SEARCH" and o["value"] is not None),default=None),
            native_rrf_max=max((o["value"] for o in observations if o["kind"] == "NATIVE_RETRIEVAL_RRF" and o["value"] is not None),default=None),
            aggregation="MAX_RECORDED_PAGE_VALUE; NOT_SUMMED_SUPPORT", correctness_probability=False))
    components, candidates = [], []
    for item in items:
        evidence = [r for r in by_item[item["id"]] if r["purpose"] == "FINAL_DECISION_EVIDENCE"]
        support = [r for r in evidence if r["direction"] in {"SUPPORT","CONFLICTED"}]
        opposed = [r for r in evidence if r["direction"] in {"COUNTER","CONFLICTED"}]
        docs = sorted({r["document_id"] for e in evidence for r in e["source_refs"]})
        context = [r for r in by_item[item["id"]] if r["purpose"] != "FINAL_DECISION_EVIDENCE"]
        context_docs = sorted({r["document_id"] for e in context for r in e["source_refs"]})
        component = dict(id=item["id"], text=item["text"], required=item["required"],
            native_status=item["status"], status=_STATES.get(item["status"],item["status"]),
            recorded_signed_units=len(evidence), recorded_support_units=len(support), recorded_opposing_units=len(opposed),
            unique_actual_documents=docs, document_count=len(docs), source_replayed=replay is not None,
            context_document_count=len(context_docs),unique_context_documents=context_docs,
            recorded_context_units=len(context),context_is_signed_evidence=False,
            supported_with_replayed_witness=bool(replay and support and _STATES.get(item["status"]) == "SUPPORTED"),
            citations_are_not_independent_samples=True)
        components.append(component)
        if "candidate_id" in item:
            native = item["native"]
            gate = native.get("local_decision", {})
            facts = gate.get("requirements", [])
            candidates.append(dict(id=item["candidate_id"], reading_id=item["reading_id"], fill=item["text"],
                rank=native["rank"], native_status=item["status"],
                native_score=_number(native["score"]) if "score" in native else None,
                ranking=deepcopy(native.get("ranking", {})), checklist=deepcopy(gate.get("checklist", [])),
                required_field_count=len(facts), established_fields=sum(f.get("coverage") == "Established" for f in facts),
                partial_fields=sum(f.get("coverage") == "Partial" for f in facts),
                missing_fields=sum(f.get("coverage") == "Missing" for f in facts),
                opposing_fields=sum(bool(f.get("counterevidence")) for f in facts),
                factual_support_implied_by_relevance=False, correctness_probability=False))
    required = [c for c in components if c["required"]]
    supported = sum(c["status"] == "SUPPORTED" for c in required)
    doc_order = {did:i for i,did in enumerate(receipt.get("document_order",[]))}
    document_cards.sort(key=lambda d:(doc_order.get(d["document_id"],len(doc_order)),d["document_id"] or d["pages"][0]["page_id"]))
    document_count = len(document_cards)
    return dict(version=VERSION,input_sha256=digest(dict(case=case,plan=plan,result=result,retrieval=receipt)),
        live_numeric_snapshot_sha256=digest(live_scores) if live_scores else None,
        documents=document_cards[:max_documents],document_selection=dict(recorded_documents=document_count,
            display_limit=max_documents,omitted_documents=max(0,document_count-max_documents),
            rule="SAVED_DOCUMENT_ORDER_THEN_STABLE_ID; NO_RELEVANCE_SCORE_REWEIGHTING"),
        candidates=candidates,components=dict(rows=components,
            required_count=len(required),native_status_counts=dict(Counter(c["status"] for c in required)),
            native_supported_fraction=dict(numerator=supported,denominator=len(required),
                value=supported/len(required) if required else None),
            supported_with_replayed_witness_count=sum(c["supported_with_replayed_witness"] for c in required)),
        source_replayed=replay is not None, retrieval_ranking_rule=receipt.get("ranking_rule",receipt.get("query_fusion")),
        missing_scores="UNRECORDED_NOT_ZERO; TRUNCATED_LISTS_NOT_RECONSTRUCTED_AS_COMPLETE_RRF",
        graph_membership_support_credit=False, relevance_cannot_compensate_failed_gates=True,
        scores_are_correctness_probabilities=False, old_weights_restored=False, api_calls=0)
