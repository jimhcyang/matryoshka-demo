"""Pure observations of authenticated native Red evidence, never recommendations.

The caller must authenticate the completion, code/resource bindings and admitted
source pages independently before constructing NativeEvidenceAuthority. Hashes
bind those inputs; they are not signatures or proof of historical truth. This
module does no I/O, inference, source discovery, counter comparison or resealing.
Validation errors MUST be treated as ABSTAIN, not as permission to use a label.
"""
from collections import Counter
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import dataclass
from datetime import date
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest

VERSION = "native-positive-evidence-observation/2"
_BINDING = "narrative-legacy-gate-source-metadata-binding/1"
_COUNTERS = "narrative-inspected-pool-redaction-counters/1"
_GATE = "local-evidence-sufficiency/6.5.5-fixed-pool"
_COMPLETE = "COMPLETE_TYPED_FRAME_COMPARISON"
_SCOPES = {"FOCAL_PROPERTY_ONLY", "FOCAL_CONTRIBUTION_ONLY"}
_FIELDS = {"actor", "predicate", "object", "quantity", "event_date", "location",
           "polarity", "uncertainty", "attribution"}
_STATUSES = {"evidence_backed_suggestion", "partial_grounding", "exploratory_contextual", "incompatible_not_viable"}
_PIN_KEYS = {"matryoshka_narrative/construction.py", "matryoshka_narrative/redaction_selection.py",
    "matryoshka_narrative/redaction_counters.py", "matryoshka_narrative/candidate_salience.py",
    "matryoshka_next/construction.py", "matryoshka_demo_v6/reporting_fixed_pool_decisions_v65.py",
    "matryoshka_demo_v6/reporting_local_decisions_v65.py"}


class EvidenceValidationError(ValueError):
    """No positive display or qualification may be inferred from invalid input."""


def _require(condition, message):
    if not condition:
        raise EvidenceValidationError(message)


def _hash(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _pairs(values, name):
    _require(type(values) is tuple and all(type(v) is tuple and len(v) == 2 for v in values), name + " must be immutable pairs")
    _require(all(isinstance(k, str) and k and _hash(v) for k, v in values), "Invalid " + name)
    _require(len({k for k, _ in values}) == len(values), "Duplicate " + name)
    return dict(values)


@dataclass(frozen=True)
class NativeEvidenceAuthority:
    """Independent expectations, NOT a factory that trusts the submitted packet.

    First two fields come from an authenticated native completion. Code pins and
    resource digest come from the independently validated execution context.
    Page digests bind complete policy-admitted page objects, not just their text.
    Do not populate these expectations from an untrusted candidate/DTO itself.
    """
    packet_digest: str
    native_checksum: str
    code_pins: tuple[tuple[str, str], ...]
    resource_binding_digest: str
    source_page_digests: tuple[tuple[str, str], ...]

    def __post_init__(self):
        _require(all(_hash(v) for v in (self.packet_digest, self.native_checksum, self.resource_binding_digest)), "Invalid native authority hashes")
        _require(_PIN_KEYS <= _pairs(self.code_pins, "code pins").keys(), "Required native gate pins missing")
        _pairs(self.source_page_digests, "source page bindings")


def _checks(rows):
    _require(isinstance(rows, list), "Missing native checks")
    ids = [r["id"] for r in rows]
    _require(len(ids) == len(set(ids)), "Duplicate native checks")
    _require(all(r.get("state") in {"pass", "missing", "conflict", "unmodeled"} for r in rows), "Unknown check state")
    return {r["id"]: r["state"] for r in rows}


def _descriptors(requirements):
    return [{k: r[k] for k in ("id", "kind", "predicate", "text")} for r in requirements]


def _citations(value):
    if isinstance(value, dict):
        if "canonical_page_id" in value:
            yield value
        for child in value.values():
            yield from _citations(child)
    elif isinstance(value, list):
        for child in value:
            yield from _citations(child)


def _citation(ref, pages, case, inspected):
    required = {"canonical_page_id", "page_sha256", "document_id", "corpus", "date", "text", "start", "end"}
    _require(required <= ref.keys(), "Incomplete native citation")
    page = pages.get(ref["canonical_page_id"])
    _require(page is not None and page["id"] in inspected, "Citation lacks an independently bound inspected page")
    a, b = ref["start"], ref["end"]
    _require(type(a) is int and type(b) is int and 0 <= a < b <= len(page["text"]), "Invalid citation offsets")
    _require(page["text"][a:b] == ref["text"], "Native quote does not replay")
    _require(ref["page_sha256"] == page["source_sha256"] == digest(page["text"]), "Source text hash changed")
    _require(all(ref[k] == page[k] for k in ("document_id", "corpus", "date")), "Citation source metadata changed")
    _require(page["corpus"] == case["corpus"] and page["document_id"] != case["document_id"], "Ineligible source origin/corpus")
    _require(date.fromisoformat(page["date"]) < date.fromisoformat(case["date"]), "Source violates strict cutoff")
    _require(page.get("permitted") is True and page.get("visibility") in {None, "earlier", "both"}, "Source not policy-admitted")
    if case["corpus"] != "cib":
        from matryoshka_next.facts import _HANDLING
        _require(page.get("classification") == "CONFIDENTIAL" and not _HANDLING.search(page["text"])
            and not any(_HANDLING.search(str(h)) for h in page.get("handling", [])), "Source handling disallows evidence")


def _provenance(decision, binding, replay):
    _require(binding["version"] == _BINDING and binding["signs_or_scope_or_requirements_changed"] is False,
             "Exact native positive/local provenance binding required")
    _require(binding["bound_decision_sha256"] == digest(decision) and _hash(binding["original_gate_decision_sha256"]), "Decision provenance digest changed")
    restored = deepcopy(decision)
    refs = list(_citations(restored))
    for ref in refs:
        replay(ref)
    additions = binding["added_corpus_fields"]
    _require(isinstance(additions, list), "Invalid provenance additions")
    key = lambda r:(r["canonical_page_id"], r["start"], r["end"], r["corpus"])
    counts = Counter()
    for item in additions:
        _require(set(item) == {"canonical_page_id", "start", "end", "corpus"}, "Provenance added more than corpus metadata")
        counts[key(item)] += 1
    grouped = {}
    for ref in refs:
        grouped.setdefault(key(ref), []).append(ref)
    for wanted, count in counts.items():
        matching = grouped.get(wanted, [])
        # Partial removal among indistinguishable repeats is not uniquely replayable.
        _require(len(matching) == count, "Ambiguous or fabricated corpus-field provenance")
        for ref in matching:
            del ref["corpus"]
    _require(digest(restored) == binding["original_gate_decision_sha256"], "Original gate provenance cannot be replayed exactly")


def _decision(decision, candidate, replay):
    _require(decision["id"] == candidate["id"] and decision["reading_id"] == candidate["reading_id"]
        and decision["text"] == candidate["fill"] and decision["task"] == "redaction", "Native candidate/reading/fill mismatch")
    _require(decision["scope"] in _SCOPES and decision["status"] in _STATUSES, "Unsupported native scope/status")
    _require(decision.get("source_failures") == [], "Native source failures prevent positive classification")
    checks = _checks(decision["checklist"])
    _require({"provenance", "binding", "facts", "conflicts", "grammar"} <= checks.keys(), "Missing decision checklist contract")
    units = decision["requirements"]
    _require(isinstance(units, list) and len({r["id"] for r in units}) == len(units), "Invalid required-unit set")
    if decision["scope"] == "FOCAL_PROPERTY_ONLY":
        _require(all(r["kind"] == "PROPERTY" for r in units), "Property scope contains a wider event")
    supported, opposed, observations = [], [], []
    for unit in units:
        _descriptors([unit])
        _checks(unit["checks"])
        witnesses, counters = [], []
        for witness in unit["evidence"]:
            direction = witness["direction"]
            _require(direction in {"Support", "Counterevidence", "Partial", "Context"}, "Unknown witness sign")
            states = _checks(witness["checks"])
            refs = witness["citations"]
            _require(isinstance(refs, list) and refs, "A signed native witness needs its complete citation group")
            for ref in refs:
                replay(ref)
            certificate = witness.get("focal_property_certificate")
            if certificate is not None:
                reading = candidate["v6_reading"]
                _require(unit["kind"] == "PROPERTY" and decision["scope"] == "FOCAL_PROPERTY_ONLY"
                    and reading["form"] == "modifier" and reading["role"] == "nominal_property" and reading["target_kind"] == "property"
                    and certificate["kind"] == "EXISTING_CAN_EASILY_PASSIVE_WITH_EXACT_OWNER" and certificate["source_modal"] == "can"
                    and certificate["raw_source_rechecked"] is True
                    and certificate["surrounding_event_established"] is False
                    and certificate["source_sha256"] in {r["page_sha256"] for r in refs},
                    "Focal property certificate/source scope changed")
            if direction in {"Support", "Counterevidence"}:
                _require(_FIELDS <= states.keys(), "Signed witness lacks scoped checks")
                _require(not witness.get("source_identity_only") and witness.get("focal_support_certified") is not False,
                         "Source identity is not focal support")
                _require(all(not MASK.search(r["text"]) for r in refs), "Opaque content cannot be a signed witness")
                if direction == "Support":
                    _require(all(s == "pass" for s in states.values()), "Partial checks cannot be combined into a support witness")
                    witnesses.append(deepcopy(witness))
                else:
                    _require(all(s == "pass" or k == "polarity" and s == "conflict" for k,s in states.items()), "Opposition lacks complete non-polarity scope")
                    counters.append(deepcopy(witness))
        _require(unit["coverage"] in {"Established", "Partial", "Missing"}, "Unknown positive coverage")
        _require((unit["coverage"] == "Established") == bool(witnesses), "Established requirement lacks complete native support")
        _require(type(unit["counterevidence"]) is bool and unit["counterevidence"] == bool(counters), "Material counter flag/witness mismatch")
        if witnesses:
            _require(all(s == "pass" for s in _checks(unit["checks"]).values()), "Grounded unit contradicts its scoped checks")
            _require(unit["direction"] in {"Support", "Support + Counterevidence"}, "Requirement sign differs from support")
            supported.append(unit["id"])
        if counters:
            _require(unit["direction"] in {"Counterevidence", "Support + Counterevidence"}, "Requirement sign differs from opposition")
            opposed.append(unit["id"])
        observations.append(dict(**_descriptors([unit])[0], native_coverage=unit["coverage"],
            complete_support_witnesses=witnesses, material_counter_witnesses=counters))
    _require(type(decision["counterevidence"]) is bool and decision["counterevidence"] == bool(opposed), "Decision opposition flag changed")
    all_grounded = bool(units) and len(supported) == len(units)
    _require((decision["coverage"] == "Established") == all_grounded, "Decision/required-unit coverage mismatch")
    _require(type(decision["support_present"]) is bool and decision["support_present"] == any(
        u["coverage"] in {"Established", "Partial"} for u in units), "Decision support flag contradicts required coverage")
    if decision["status"] == "evidence_backed_suggestion":
        _require(all_grounded and not opposed and all(s == "pass" for s in checks.values()), "Native backed label contradicts its checks")
    return dict(units=observations, supported=supported, opposed=opposed, all_grounded=all_grounded)


def _assess(packet, candidate_id, authority, source_pages):
    _require(type(authority) is NativeEvidenceAuthority, "A concrete independent NativeEvidenceAuthority is required, not a generic dict")
    _require(packet["version"] == "narrative-local-execution/3" and packet["public_task"] == "redaction", "Current sealed native Red packet required")
    _require(packet["query_only_inference"] is True and packet["answers_read"] is False and packet["grades_read"] is False,
             "Answer/evaluation inputs cannot supply native positive authority")
    _require(digest(packet) == authority.packet_digest, "Authenticated native packet digest changed")
    result, case, binding = packet["result"], packet["case"], packet["binding"]
    _require(packet["native_checksum"] == authority.native_checksum == digest(result), "Native result seal changed")
    _require(packet["code_pins"] == _pairs(authority.code_pins, "code pins"), "Native code pins differ from independent expectations")
    _require(digest(binding) == authority.resource_binding_digest and _hash(binding["sha256"]), "Resource binding changed")
    _require(binding["corpus"] == case["corpus"] and case["task"] == "redaction", "Native task/resource mismatch")
    _require(packet["query_sha256"] == result["query_sha256"] == digest(case["query"])
        and result["provided_plan_sha256"] == digest(packet["plan"]), "Native query/plan binding changed")
    _require(result["positive_citation_gate_version"] == _GATE and result["counter_comparison_version"] == _COUNTERS,
             "Unsupported native evidence/counter version")
    _require(result["certificate_contract_version"] == "narrative-decision-certificate/2"
        and re.fullmatch(r"narrative-bounded-red-construction/[0-9]+", result["version"]) is not None,
        "Unsupported native result/certificate contract")
    inspected = result["inspected_page_ids"]
    _require(isinstance(inspected, list) and len(set(inspected)) == len(inspected) == result["source_pages_inspected"], "Invalid inspected pool binding")
    _require(isinstance(source_pages, Mapping), "Independently bound source-page mapping required")
    page_bindings = _pairs(authority.source_page_digests, "source page bindings")
    _require(set(source_pages) == set(page_bindings), "Source-page authority differs from supplied pages")
    for pid, page in source_pages.items():
        _require(page["id"] == pid and digest(page) == page_bindings[pid], "Admitted source-page metadata/bytes changed")
    replay = lambda ref:_citation(ref, source_pages, case, inspected)
    candidates = result["assessed_candidates"]
    _require(len({c["id"] for c in candidates}) == len(candidates), "Duplicate assessed native candidate")
    matches = [c for c in candidates if c["id"] == candidate_id]
    _require(len(matches) == 1, "Candidate is not a saved native assessment")
    candidate = matches[0]
    views = [c for row in result["readings"] for c in row["candidates"] if c["id"] == candidate_id]
    flat = [c for c in result["candidates"] if c["id"] == candidate_id]
    _require(len(views) == len(flat) <= 1 and all(c == candidate for c in views+flat), "Displayed/assessed candidate differs")
    adapted = [r for r in result["reading_adapter"]["readings"] if r["reading"]["id"] == candidate["reading_id"]]
    _require(len(adapted) == 1 and candidate["declared_reading"] == adapted[0]["reading"]
        and candidate["v6_reading"] == adapted[0]["constructor"], "Original/effective reading binding changed")
    positive, final = candidate["positive_citation_decision"], candidate["local_decision"]
    _provenance(positive, candidate["positive_citation_decision_provenance_binding"], replay)
    _provenance(final, candidate["local_decision_provenance_binding"], replay)
    for ref in candidate["sources"]:
        replay(ref)
    a, b = candidate["source_span"]
    _require(type(a) is int and type(b) is int and 0 <= a < b, "Invalid candidate source extent")
    origins = [o for o in candidate["source_occurrences"] if o["source_span"] == [a,b]
        and o["source_wording"] == candidate["source_wording"] and o["citation"] in candidate["sources"]]
    _require(bool(origins), "Candidate lost its original source occurrence")
    for origin in origins:
        page = source_pages.get(origin["citation"]["canonical_page_id"])
        _require(page is not None and page["text"][a:b] == candidate["source_wording"], "Raw candidate wording no longer replays")
    _require(positive["source_pages_checked"] == sorted({r["canonical_page_id"] for r in candidate["sources"]}),
             "Positive gate source origins differ from the native candidate")
    _require(all(r["canonical_page_id"] in positive["source_pages_checked"] for r in _citations(positive)),
             "Positive gate borrowed another source origin")
    _require(positive["scope"] == final["scope"] and _descriptors(positive["requirements"]) == _descriptors(final["requirements"]), "Positive/final scope or required set changed")
    p, f = _decision(positive, candidate, replay), _decision(final, candidate, replay)
    added_counters = 0
    for old, new in zip(p["units"], f["units"]):
        _require(all(w in old["complete_support_witnesses"] for w in new["complete_support_witnesses"]),
                 "Final stage introduced new positive evidence")
        _require(all(w in new["material_counter_witnesses"] for w in old["material_counter_witnesses"]),
                 "Final stage dropped material opposition")
        added_counters += sum(w not in old["material_counter_witnesses"] for w in new["material_counter_witnesses"])
    receipt = candidate["inspected_pool_counter_comparison"]
    descriptors = _descriptors(positive["requirements"])
    _require(receipt["version"] == _COUNTERS and receipt["candidate_id"] == candidate_id
        and receipt["positive_citation_decision_sha256"] == digest(positive), "Counter receipt lost positive-decision binding")
    _require(receipt["required_descriptors"] == descriptors and receipt["required_count"] == len(descriptors)
        and [r["descriptor"] for r in receipt["requirements"]] == descriptors, "Counter required-set binding changed")
    _require(receipt["declared_inspected_page_ids"] == inspected
        and receipt["positive_citation_source_pages_checked"] == positive["source_pages_checked"], "Counter source pool changed")
    known_hashes = {p["page_id"]:p["page_sha256"] for p in result.get("source_budget", {}).get("selection_scan", [])}
    known_hashes.update({pid:p["source_sha256"] for pid,p in source_pages.items()})
    for unit in receipt["requirements"]:
        page_ids = [p["page_id"] for p in unit["pages"]]
        _require(len(page_ids) == len(set(page_ids)) and set(page_ids) <= set(inspected), "Counter page observations differ from inspected pool")
        for page in unit["pages"]:
            _require(_hash(page["page_sha256"]) and (page["page_id"] not in known_hashes
                or page["page_sha256"] == known_hashes[page["page_id"]]), "Counter page hash differs from native/source binding")
    _require(receipt["positive_evidence_added"] is False and receipt["candidate_origins_expanded"] is False, "Counter stage cannot supply new positive origins")
    _require(receipt["proposal_or_display_cap_applied"] is False and receipt["semantic_exhaustiveness_certified"] is False,
             "Unsupported counter comparison scope claim")
    _require(type(receipt["added_counter_witnesses"]) is int and receipt["added_counter_witnesses"] == added_counters,
             "Added material-counter count differs from final witnesses")
    complete = receipt["full_declared_pool_compared_under_typed_model"]
    _require(type(complete) is bool and receipt["disposition"] == (_COMPLETE if complete else "INCOMPLETE_OR_UNMODELED"), "Invalid counter coverage disposition")
    if complete:
        _require(bool(descriptors) and not receipt["issues"] and all(r["disposition"] == _COMPLETE
            and not r["issues"] and [p["page_id"] for p in r["pages"]] == inspected
            and all(not p["issues"] and p["disposition"] == _COMPLETE for p in r["pages"])
            for r in receipt["requirements"]), "Counter completeness contradicts its receipt")
    if final["status"] == "evidence_backed_suggestion":
        _require(complete, "Final backed status cannot conceal incomplete counter coverage")
    counter_witnesses = [w for unit in f["units"] for w in unit["material_counter_witnesses"]]
    for unit in receipt["requirements"]:
        for witness in unit["counter_witnesses"]:
            _require(witness in counter_witnesses, "Counter receipt witness was dropped from final decision")
    issues = sorted({issue for unit in receipt["requirements"] for page in unit["pages"] for issue in page["issues"]}
                    | set(receipt["issues"]))
    state = ("Conflicted" if counter_witnesses and p["supported"] else "Opposed" if counter_witnesses
        else "Partial" if final["status"] == "partial_grounding" else "Contextual" if final["status"] == "exploratory_contextual"
        else "Native Evidence-Backed" if final["status"] == "evidence_backed_suggestion" else "Withheld")
    return dict(version=VERSION, validation="AUTHENTICATED_NATIVE_OBSERVATION", candidate_id=candidate_id,
        native_packet_digest=authority.packet_digest, positive_decision_sha256=digest(positive), final_decision_sha256=digest(final),
        positive_evidence=dict(state="NATIVE_POSITIVE_NOT_RETAINED_AS_FOCAL" if p["supported"] and not set(p["supported"]) <= set(f["supported"])
            else "ESTABLISHED" if p["all_grounded"] else "PARTIAL_REQUIREMENT_SET" if p["supported"] else "NO_ESTABLISHED_WITNESS",
            source_support_present=bool(p["supported"]), all_required_units_grounded=p["all_grounded"],
            required_count=len(p["units"]), grounded_unit_ids=p["supported"], scope=positive["scope"], units=p["units"],
            focal_property_grounded=p["all_grounded"] and all(r["kind"] == "PROPERTY" for r in positive["requirements"])
                and set(p["supported"]) <= set(f["supported"]),
            final_focal_support_retained=bool(p["supported"]) and set(p["supported"]) <= set(f["supported"])),
        counter_coverage=dict(state="RECORDED_TYPED_COMPARISON_COMPLETE" if complete else "INCOMPLETE_OR_UNMODELED",
            inspected_page_count=len(inspected), issues=issues, material_counterevidence=bool(counter_witnesses),
            material_counter_witnesses=counter_witnesses, semantic_exhaustiveness_certified=False,
            corpus_counter_cleared=False, comparison_reexecuted=False),
        native_final=deepcopy(final), recommendation=dict(action="ABSTAIN", assessment_state=state,
            native_status=final["status"], new_qualification_authorized=False,
            reason="Read-only evidence classification never authorizes a new final SUPPORT recommendation"),
        answer_correctness=dict(state="NOT_EVALUATED", reference_comparison_performed=False, used_for_inference=False),
        case_qualification=dict(authorized=False, reason="Candidate-local positive evidence is not complete case/recommendation authority"),
        world_truth_certified=False, wider_event_certified=False, native_status_changed=False,
        scope="CANDIDATE_FOCAL_NATIVE_EVIDENCE_ONLY_NOT_CASE_OR_CORPUS_QUALIFICATION")


def assess_candidate(packet, candidate_id, *, authority, source_pages):
    """Return orthogonal display fields or raise EvidenceValidationError/ABSTAIN.

    Only sealed native inputs are accepted; observer/model/generic decision
    dictionaries are not authority. Outputs are defensive copies. Even when
    positive grounding is Established, this function never emits final SUPPORT.
    """
    try:
        value = _assess(packet, candidate_id, authority, source_pages)
        _require(digest(packet) == authority.packet_digest, "Native input changed during classification")
        return value
    except EvidenceValidationError:
        raise
    except (KeyError, TypeError, ValueError, AttributeError) as error:
        raise EvidenceValidationError("Malformed native evidence contract: " + str(error)) from error
