"""One proposal slate with explicit, non-interchangeable provenance families.

Corpus judgments remain intact. Public-input realizations may nominate a fill,
but never acquire a corpus citation, support vote or correctness probability.
"""
from copy import deepcopy
import re

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest
from matryoshka_next.facts import public_plan
from . import input_realization

VERSION = "source-separated-redaction-proposal-fusion/1"
RRF_K = 60
TIERS = {"evidence_backed_suggestion": 2, "partial_grounding": 1,
         "exploratory_contextual": 0}
POLICY = "EVIDENCE_TIER_THEN_EQUAL_FAMILY_RRF_INPUT_TIE_BREAK"


def surface_key(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Nonempty literal proposal wording required")
    return re.sub(r"[ \t\r\n\f\v]+", " ", text).strip(" \t\r\n\f\v").lower()


def corpus_descriptor(candidate):
    value = {key: deepcopy(candidate[key]) for key in
        ("id", "reading_id", "fill", "rank", "local_decision")}
    value['score'] = candidate.get('terminal_scorecard', {}).get('score', candidate.get('score'))
    return value


def _fuse(corpus, inputs, *, blocked=(), limit=5):
    """Pure slate arithmetic; callers must first validate source/input proofs."""
    if type(limit) is not int or not 1 <= limit <= 5:
        raise ValueError("A proposal slate contains at most five fills")
    grouped = {}
    for ordinal, candidate in enumerate(corpus, 1):
        status = candidate["local_decision"]["status"]
        if status not in TIERS or candidate["rank"] != ordinal:
            raise ValueError("Unchanged viable corpus order required")
        key = surface_key(candidate["fill"])
        if key in grouped:
            grouped[key]['same_surface_corpus_ids'].append(candidate['id'])
            continue
        grouped[key] = dict(id=candidate["id"], fill=candidate["fill"], surface_key=key,
            provenance="CORPUS", evidence_tier=TIERS[status], status=status,
            corpus_candidate_id=candidate["id"], corpus_candidate_sha256=digest(corpus_descriptor(candidate)),
            corpus_rank=ordinal, corpus_score=corpus_descriptor(candidate)['score'], input_nomination_id=None,
            input_nomination_sha256=None, input_rank=None,
            same_surface_corpus_ids=[candidate['id']],
            independent_corpus_evidence=status == "evidence_backed_suggestion",
            input_independent_evidence_votes=0, fusion_contributions=[
                dict(family="CORPUS", rank=ordinal, value=1 / (RRF_K + ordinal))])
    blocked = set(blocked)
    input_seen = set()
    for ordinal, candidate in enumerate(inputs, 1):
        key = surface_key(candidate["fill"])
        if key in input_seen or candidate["ranking"]["input_context_ordinal"] != ordinal:
            raise ValueError("Distinct verified input nominations in their original order required")
        input_seen.add(key)
        if key in blocked and key not in grouped:
            continue
        if key not in grouped:
            grouped[key] = dict(id=candidate["id"], fill=candidate["fill"], surface_key=key,
                provenance="INPUT", evidence_tier=0, status="input_context_only",
                corpus_candidate_id=None, corpus_candidate_sha256=None,
                corpus_rank=None, corpus_score=None, input_nomination_id=None,
                input_nomination_sha256=None, input_rank=None,
                same_surface_corpus_ids=[],
                independent_corpus_evidence=False, input_independent_evidence_votes=0,
                fusion_contributions=[])
        row = grouped[key]
        row.update(input_nomination_id=candidate["id"], input_nomination_sha256=digest(candidate),
            input_rank=ordinal, provenance="CORPUS_AND_INPUT" if row["corpus_candidate_id"] else "INPUT")
        row["fusion_contributions"].append(dict(family="INPUT", rank=ordinal,
                                               value=1 / (RRF_K + ordinal)))
    for row in grouped.values():
        row["fusion_score"] = sum(c["value"] for c in row["fusion_contributions"])
    values = sorted(grouped.values(), key=lambda row: (-row["evidence_tier"], -row["fusion_score"],
        row["input_rank"] is None, row["corpus_rank"] or 10**9,
        row["input_rank"] or 10**9, row["surface_key"], row["id"]))
    for rank, row in enumerate(values, 1):
        row["rank"] = rank
    return deepcopy(values[:limit]), len(values)


def build(case, plan, result, parser):
    """Build locally from native corpus outputs and replayed public-input forms."""
    case = public_case(case)
    public_plan(case, plan)
    if case["task"] != "redaction" or result.get("task") != "redaction":
        raise ValueError("Proposal fusion applies only to Redaction")
    if result.get("query_sha256") != digest(case["query"]):
        raise ValueError("Corpus result belongs to another input")
    nominal = result.get("input_nomination")
    if nominal is not None:
        input_realization.replay(nominal, case, plan, parser)
    rows = result.get("readings", [])
    declared = plan["readings_packet"]["readings"]
    if [row["reading"]["id"] for row in rows] != [r["id"] for r in declared]:
        raise ValueError("Every declared reading must retain its own proposal slate")
    by_input = {r["reading_id"]: r for r in nominal["readings"]} if nominal else {}
    withheld = set(result.get("controller_shortlist", {}).get("withheld_candidate_ids", []))
    output = []
    for row, reading in zip(rows, declared):
        rid = reading["id"]
        if digest(row["reading"]) != digest(reading):
            raise ValueError("Declared reading changed")
        corpus = row["candidates"]
        if any(c["reading_id"] != rid or c["id"] in withheld for c in corpus):
            raise ValueError("A withheld or other-reading corpus candidate cannot enter the slate")
        visible_keys = {surface_key(c["fill"]) for c in corpus}
        blocked = set()
        for candidate in result.get("assessed_candidates", []):
            if candidate.get("reading_id") != rid:
                continue
            if (candidate["id"] in withheld or candidate.get("local_decision", {}).get("status") not in TIERS):
                blocked.add(surface_key(candidate["fill"]))
        blocked -= visible_keys
        inputs = by_input.get(rid, {}).get("nominations", [])
        proposals, unique_count = _fuse(corpus, inputs, blocked=blocked)
        output.append(dict(reading_id=rid, reading_sha256=digest(reading),
            corpus_shortlist_sha256=digest([corpus_descriptor(c) for c in corpus]),
            input_nominations_sha256=digest(inputs), blocked_input_forms=sorted(blocked),
            proposed_unique_fills=unique_count, proposals=proposals))
    return dict(version=VERSION, query_sha256=digest(case["query"]),
        case_sha256=digest(case), plan_sha256=digest(plan),
        readings_packet_sha256=digest(plan["readings_packet"]), readings=output,
        ranking_policy=POLICY, rrf_k=RRF_K, family_weights=dict(CORPUS=1, INPUT=1), top_k=5,
        score_meaning="RECIPROCAL_RANK_FUSION_WITHIN_EVIDENCE_TIER_NOT_CORRECTNESS_PROBABILITY",
        evidence_tier_priority=True, exact_surface_deduplication=True,
        corpus_candidates_scores_decisions_unchanged=True,
        input_evidence_credit=False, same_actor_or_event_certified=False,
        source_policy_modified=False, api_calls=0)


def replay(value, case, plan, result, parser):
    if value != build(case, plan, result, parser):
        raise ValueError("Proposal pool differs from its verified source/input calculation")
    return True
