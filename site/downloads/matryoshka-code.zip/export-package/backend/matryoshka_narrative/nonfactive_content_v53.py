"""Separate structural coverage audit; unmodeled clauses cannot disappear.

The frozen earlier helpers nominate a root-content certificate. This layer
checks the complete matched branch, including holders and nominal arguments,
not only children of the two matched verbs. It never guesses a reporter.
"""
from copy import deepcopy

from matryoshka_demo.io import offline
from matryoshka_demo_v61 import scope_matching as scoped
from . import matching as baseline
from . import nonfactive_content_v52 as previous

VERSION = "narrative-root-nonfactive-content-experiment/5.3"
_CLAUSAL = {"acl", "relcl", "advcl", "ccomp", "csubj", "csubjpass", "parataxis", "appos"}
_QUALIFYING = {"advmod", "neg", "mark", "npadvmod"}


def _branch_audit(certificate, query_doc, source_doc):
    target, source = certificate["target_leaf_frame"], certificate["source_leaf_frame"]
    qt, st = baseline._token(target, query_doc), baseline._token(source, source_doc)
    if qt is None or st is None:
        return [dict(kind="LEAF_PROOF_NOT_REPLAYABLE")], None
    issues, proofs = [], {}
    for side, leaf, doc in (("QUERY", qt, query_doc), ("SOURCE", st, source_doc)):
        root = leaf.head
        excluded = [c for c in root.children if previous._enumerated_previous_branch(c, root)]
        skipped = {t.i for branch in excluded for t in branch.subtree}
        branch = [t for t in root.subtree if t.i not in skipped]
        modeled_verbs = {root.i, leaf.i}
        modeled_qualifiers = set()
        for head in (root, leaf):
            for child in head.children:
                if child.dep_ in previous._FUNCTIONAL:
                    modeled_verbs.update(t.i for t in child.subtree)
                    modeled_qualifiers.update(t.i for t in child.subtree)
                elif child.dep_ == "advmod":
                    modeled_qualifiers.update(t.i for t in child.subtree)
        for token in branch:
            kind = None
            if token.pos_ in {"VERB", "AUX"} and token.i not in modeled_verbs:
                kind = "UNMODELED_BRANCH_VERBAL_PREDICATE"
            elif token.dep_ in _CLAUSAL:
                kind = "UNMODELED_BRANCH_CLAUSAL_OR_APPOSITIVE_ATTACHMENT"
            elif token.dep_ == "xcomp" and token != leaf:
                kind = "UNMODELED_BRANCH_EMBEDDED_COMPLEMENT"
            elif token.dep_ in _QUALIFYING and token.i not in modeled_qualifiers:
                kind = "UNMODELED_NOMINAL_OR_HOLDER_QUALIFICATION"
            if kind is not None:
                issues.append(dict(kind=kind, side=side, proof=scoped.matching.proof(token)))
        # A reporting tail can be parsed as a separate sentence/ROOT after a
        # dash, so subtree-only coverage is not a complete source-unit audit.
        ancestors = {t.i for t in root.ancestors}
        for token in doc:
            if token.dep_ == "ROOT" and token != root and token.i not in ancestors:
                issues.append(dict(kind="UNMODELED_DISCONNECTED_UNIT_ROOT", side=side,
                    proof=scoped.matching.proof(token)))
            if token.text == "?" or token.is_quote:
                issues.append(dict(kind="UNMODELED_QUESTION_OR_QUOTATION_SCOPE", side=side,
                    proof=scoped.matching.proof(token)))
        proofs[side.casefold()] = dict(root=scoped.matching.proof(root),
            modeled_verbal_predicate_proofs=[scoped.matching.proof(t) for t in doc if t.i in modeled_verbs],
            independently_enumerated_previous_branches=[scoped.matching.proof(t) for t in excluded],
            inspected_branch_token_count=len(branch),
            unmodeled_clauses_ignored=False, unmodeled_nominal_or_holder_qualifiers_ignored=False,
            reporter_inferred=False)
    return issues, proofs


def evaluate(matcher, atom, page, unit):
    """Return an unadopted sidecar; applicable holds must not use V4 fallback."""
    result = deepcopy(previous.evaluate(matcher, atom, page, unit))
    result.update(version=VERSION, structural_coverage_issues=[])
    if result["direction"] != "SUPPORT":
        return result
    with offline():
        query_doc = matcher.engine.parse(atom["text"])
        source_doc = matcher.engine.parse(unit.get("text", unit.get("quote")))
        issues, proof = _branch_audit(result["source_attestation"], query_doc, source_doc)
    if issues:
        result.update(direction="UNRESOLVED", source_attestation=None, structural_coverage_issues=issues)
    else:
        result["source_attestation"]["structural_coverage_audit"] = proof
    return result
