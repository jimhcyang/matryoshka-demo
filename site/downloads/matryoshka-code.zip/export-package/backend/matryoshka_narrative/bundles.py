"""Bounded selection of already assessed Mosaic proofs; no new entailment.

The certificate and assessed pool must come from independently authenticated
producer inputs. Selection cannot license joins, promote partial evidence, or
remove inspected-pool counters. The approved certificate module is read-only.
"""
from copy import deepcopy
from datetime import date

from matryoshka_demo.io import digest
from . import certificates as c

VERSION = "narrative-mosaic-bundles/1.2"
POOL_VERSION = "mosaic-assessed-witness-pool/1"
JOIN_KINDS = {"same_actor", "same_referent", "event_identity", "role", "chronology",
              "attribution", "causal", "conditional", "unmodeled"}
EVENT_JOINS = {"event_identity", "chronology", "causal", "conditional"}


def _recorded_candidates(check, kind):
    """Occurrence identities, restricted to the saved check's candidate list."""
    if kind == "event_identity":
        return {("event_occurrence", token) for token in check.get("shared_event_bindings", [])
                if isinstance(token, str) and token}
    if kind != "same_actor":
        return set()
    candidates = set()
    for binding in check.get("shared_source_subject_bindings", []):
        if not isinstance(binding, (list, tuple)) or len(binding) != 6:
            continue
        page, page_hash, quote_start, quote_end, owner_start, owner_end = binding
        if (isinstance(page, str) and isinstance(page_hash, str) and
            all(type(value) is int for value in (quote_start, quote_end, owner_start, owner_end)) and
            0 <= quote_start <= owner_start < owner_end <= quote_end):
            # Quote windows may differ. The owner occurrence itself must not.
            candidates.add(("source_owner_occurrence", page, page_hash, owner_start, owner_end))
    return candidates


def _binding_record(candidate):
    if candidate[0] == "event_occurrence":
        return dict(kind=candidate[0], event_token=candidate[1])
    return dict(kind=candidate[0], canonical_page_id=candidate[1], page_sha256=candidate[2],
                owner_start=candidate[3], owner_end=candidate[4])


def _binding_key(binding):
    if not isinstance(binding, dict):
        return None
    if binding.get("kind") == "event_occurrence" and isinstance(binding.get("event_token"), str):
        return ("event_occurrence", binding["event_token"])
    if (binding.get("kind") == "source_owner_occurrence" and
        isinstance(binding.get("canonical_page_id"), str) and isinstance(binding.get("page_sha256"), str) and
        type(binding.get("owner_start")) is int and type(binding.get("owner_end")) is int):
        return ("source_owner_occurrence", binding["canonical_page_id"], binding["page_sha256"],
                binding["owner_start"], binding["owner_end"])
    return None


def _matches_candidate(witness, candidate):
    if candidate is None or witness["sign"] != "SUPPORT":
        return False
    if candidate[0] == "event_occurrence":
        return candidate[1] in (witness.get("details") or {}).get("event_bindings", [])
    ref = witness["citation"]
    return (ref["canonical_page_id"] == candidate[1] and ref["page_sha256"] == candidate[2] and
            ref["start"] <= candidate[3] < candidate[4] <= ref["end"])


def _require(condition, message):
    if not condition:
        raise ValueError(message)


def _ids(values, name):
    _require(isinstance(values, list) and all(isinstance(v, str) and v for v in values), "Invalid " + name)
    _require(len(values) == len(set(values)), "Duplicate " + name)


def witness_catalog(certificate):
    """Exact signed witness usages; this function alone is not validation."""
    return [dict(id="w_" + digest([unit["id"], witness]), unit_id=unit["id"],
                 **deepcopy(witness)) for unit in certificate["units"] for witness in unit["witnesses"]]


def pool_record(certificate, *, producer, query_scope_complete, proofs, joins=None,
                licenses=None, dependence=None):
    """Package trusted PRE-SELECTION assessments, never derive them from a bundle.

    A producer is responsible for complete proof groups and the exhaustive set
    of requested joins within its declared scope. This is a trust-input API,
    not semantic checking of a caller's declarations or a new certificate.
    """
    return deepcopy(dict(version=POOL_VERSION, certificate_sha256=digest(certificate),
        binding=certificate["binding"], required_units_sha256=digest(certificate["required_units"]),
        source_pool_sha256=digest(certificate["source_pool"]), producer=producer,
        query_scope_complete=query_scope_complete, proofs=proofs, joins=joins or [],
        licenses=licenses or [], dependence=dependence or []))


def _prepare(certificate, context, required, pool):
    value = c.validate_certificate(certificate, expected_context=context, expected_required_units=required)
    _require(value["task"] == "mosaic", "Bundle selection requires a Mosaic certificate")
    _require(pool.get("version") == POOL_VERSION, "Unsupported assessed-pool version")
    for key, expected in (("certificate_sha256", digest(value)), ("binding", value["binding"]),
        ("required_units_sha256", digest(required)), ("source_pool_sha256", digest(value["source_pool"]))):
        _require(pool.get(key) == expected, "Assessed pool " + key + " binding changed")
    _require(type(pool.get("query_scope_complete")) is bool, "Explicit query-scope disposition required")
    qualification = value["scope"].get("qualification")
    _require(not (pool["query_scope_complete"] and isinstance(qualification, dict) and
                  qualification.get("complete") is False), "Pool cannot override an incomplete native query scope")
    _require(isinstance(pool.get("producer"), dict) and bool(pool["producer"]), "Independent assessed-pool producer required")
    catalog = witness_catalog(value)
    known = {w["id"]: w for w in catalog}
    _ids(list(known), "witness IDs")
    units = {u["id"]: u for u in value["units"]}
    pages = {}
    for witness in catalog:
        ref = witness["citation"]
        identity = (ref["document_id"], ref["page_sha256"], ref["date"], ref["corpus"])
        _require(pages.setdefault(ref["canonical_page_id"], identity) == identity, "Incompatible source page identities")
    proofs = deepcopy(pool["proofs"])
    _ids([p["id"] for p in proofs], "proof IDs")
    for proof in proofs:
        unit = units.get(proof["unit_id"])
        _require(unit is not None and unit["state"] in {"SUPPORTED", "CONFLICTED"}, "Proof cannot promote an incomplete/opposed unit")
        _ids(proof["witness_ids"], "proof witnesses")
        _require(bool(proof["witness_ids"]) and set(proof["witness_ids"]) <= known.keys(), "Proof has missing/foreign witnesses")
        _require(any(known[w]["unit_id"] == unit["id"] and known[w]["sign"] == "SUPPORT" for w in proof["witness_ids"]), "Complete proof lacks this unit's signed support")
        _require(all(known[w]["sign"] != "OPPOSITION" for w in proof["witness_ids"]), "An opponent cannot supply a positive proof")
        _ids(proof.get("prerequisite_witness_ids", []), "prerequisite witnesses")
        _require(set(proof.get("prerequisite_witness_ids", [])) <= set(proof["witness_ids"]), "Prerequisite is outside its complete proof")
        _require(bool(proof.get("basis")), "Complete proof needs a saved assessment reason")
    joins = deepcopy(pool["joins"])
    _ids([j["id"] for j in joins], "join IDs")
    join_index = {j["id"]: j for j in joins}
    for join in joins:
        _require(join["kind"] in JOIN_KINDS and type(join["required"]) is bool, "Unknown join kind or requirement")
        _ids(join["unit_ids"], "join units")
        _require(bool(join["unit_ids"]) and set(join["unit_ids"]) <= units.keys(), "Join has missing/foreign units")
        _require(bool(join.get("description")) and isinstance(join.get("bindings"), dict) and bool(join["bindings"]), "Join needs explicit requested bindings")
    licenses = deepcopy(pool["licenses"])
    _ids([license["id"] for license in licenses], "join-license IDs")
    audits = []
    for license in licenses:
        _require(license["join_id"] in join_index, "License for an undeclared join")
        join = join_index[license["join_id"]]
        _ids(license["witness_ids"], "join witnesses")
        _require(set(license["witness_ids"]) <= known.keys(), "Join license has foreign witnesses")
        _require(license["state"] in {"LICENSED", "UNRESOLVED", "OPPOSED", "UNMODELED"}, "Unknown join assessment state")
        reasons = []
        if license["state"] != "LICENSED": reasons.append("JOIN_NOT_LICENSED")
        if join["kind"] == "unmodeled": reasons.append("JOIN_KIND_UNMODELED")
        if license.get("bindings") != join["bindings"]: reasons.append("REQUESTED_JOIN_BINDINGS_DISAGREE")
        fields = {"same_actor":{"referent_id"}, "same_referent":{"referent_id"},
            "event_identity":{"event_id"}, "role":{"holder_id","role_id"},
            "chronology":{"first_unit_id","second_unit_id","relation"},
            "attribution":{"speaker_id","scope_id"},
            "causal":{"antecedent_unit_id","consequent_unit_id","relation"},
            "conditional":{"antecedent_unit_id","consequent_unit_id","relation"}}.get(join["kind"], set())
        native_check = license.get("original_native_check")
        native_binding = native_check is not None and join["bindings"].get("native_check_sha256") == digest(native_check)
        if not native_binding and not fields <= join["bindings"].keys(): reasons.append("JOIN_BINDINGS_UNMODELED")
        if not native_binding and any(not isinstance(join["bindings"].get(field), str) or
            not join["bindings"][field].strip() for field in fields): reasons.append("JOIN_BINDING_VALUES_UNRESOLVED")
        if native_binding and license["state"] == "LICENSED" and native_check.get("state") != "SATISFIED":
            reasons.append("SAVED_NATIVE_JOIN_NOT_SATISFIED")
        if native_binding and license["state"] == "LICENSED" and join["kind"] in {"event_identity", "same_actor"}:
            candidate = _binding_key(license.get("common_binding"))
            witnesses = [known[w] for w in license["witness_ids"]]
            common = (candidate in _recorded_candidates(native_check, join["kind"]) and
                all(w["unit_id"] in join["unit_ids"] and _matches_candidate(w, candidate) for w in witnesses) and
                all(any(w["unit_id"] == identity and _matches_candidate(w, candidate) for w in witnesses)
                    for identity in join["unit_ids"]))
            if not common: reasons.append("NATIVE_COMMON_OCCURRENCE_NOT_ESTABLISHED")
        if join["kind"] in {"causal", "conditional"} and not native_binding:
            antecedent, consequent = join["bindings"].get("antecedent_unit_id"), join["bindings"].get("consequent_unit_id")
            if antecedent == consequent or not {antecedent, consequent} <= set(join["unit_ids"]):
                reasons.append("CAUSAL_OR_CONDITIONAL_ENDPOINTS_UNBOUND")
        if not license["witness_ids"]: reasons.append("NO_EXACT_JOIN_WITNESSES")
        if any(known[w]["sign"] == "OPPOSITION" for w in license["witness_ids"]): reasons.append("OPPONENT_IS_NOT_A_JOIN_LICENSE")
        operator = value["scope"]["kind"] == "QUERIED_OPERATOR_ONLY" or any(
            units[u]["scope"]["kind"] == "QUERIED_OPERATOR_ONLY" for u in join["unit_ids"]) or any(
            known[w]["scope"]["kind"] == "QUERIED_OPERATOR_ONLY" for w in license["witness_ids"])
        if operator and join["kind"] in EVENT_JOINS: reasons.append("OPERATOR_ONLY_SCOPE_FORBIDS_EVENT_JOIN")
        if join["kind"] == "chronology":
            clocks = license.get("event_times", {})
            bindings = join["bindings"]
            try:
                first, second = bindings["first_unit_id"], bindings["second_unit_id"]
                before, after = date.fromisoformat(clocks[first]), date.fromisoformat(clocks[second])
                valid = (first in join["unit_ids"] and second in join["unit_ids"] and
                    license.get("event_time_basis") == "EXPLICIT_EVENT_TIME" and
                    ((bindings["relation"] == "before" and before < after) or
                     (bindings["relation"] == "after" and before > after)))
            except (KeyError, TypeError, ValueError):
                valid = False
            if not valid: reasons.append("EXPLICIT_EVENT_CHRONOLOGY_NOT_ESTABLISHED")
        audits.append(dict(id=license["id"], join_id=join["id"], admissible=not reasons,
                           reasons=reasons, original=license))
    docs = {w["citation"]["document_id"] for w in catalog}
    _ids([d["id"] for d in pool["dependence"]], "dependence groups")
    for group in pool["dependence"]:
        _ids(group["document_ids"], "dependent documents")
        _require(set(group["document_ids"]) <= docs and bool(group.get("reason")), "Unbound source dependence")
    return value, known, units, proofs, joins, audits


def _span_cost(ids, known):
    pages = {}
    for identity in ids:
        ref = known[identity]["citation"]
        pages.setdefault((ref["canonical_page_id"], ref["page_sha256"]), []).append((ref["start"], ref["end"]))
    total = 0
    for spans in pages.values():
        start, end = -1, -1
        for left, right in sorted(spans):
            if left > end:
                total += max(0, end - start)
                start, end = left, right
            else:
                end = max(end, right)
        total += max(0, end - start)
    return total


def select_bundle(certificate, *, expected_context, expected_required_units, assessed_pool,
                  max_documents=8, beam_width=64, max_expansions=2048,
                  max_closure_expansions=4096, baseline_document_ids=None):
    """Return the smallest set found under an explicit deterministic bounded search.

    Complete assessed proofs are atomic actions, so prerequisite-only source
    pairs are not pruned for having zero individual component contribution.
    Required active joins must close with an already licensed exact witness set.
    """
    for name, number in (("max_documents", max_documents), ("beam_width", beam_width),
                         ("max_expansions", max_expansions), ("max_closure_expansions", max_closure_expansions)):
        _require(type(number) is int and number > 0, "Positive " + name + " required")
    value, known, units, proofs, joins, audits = _prepare(certificate, expected_context, expected_required_units, assessed_pool)
    baseline = baseline_document_ids or []
    _ids(baseline, "baseline documents")
    _require(set(baseline) <= {w["citation"]["document_id"] for w in known.values()}, "Baseline document outside assessed witnesses")
    required_ids = [u["id"] for u in value["required_units"]["units"]]
    def established(state):
        return {p["unit_id"] for p in proofs if set(p["witness_ids"]) <= state}
    def documents(state):
        return {known[w]["citation"]["document_id"] for w in state}
    def rank(state):
        return (-len(established(state)), len(documents(state) - set(baseline)),
                _span_cost(state, known), len(documents(state)), tuple(sorted(state)))
    license_map = {join["id"]: [a["original"] for a in audits if a["join_id"] == join["id"] and a["admissible"]] for join in joins}
    stats = dict(expansions=0, closure_expansions=0, closure_pruned=0, beam_pruned=0, document_holds=0, join_holds=0)
    closure_capped = False
    def close(seed):
        nonlocal closure_capped
        frontier, completed, seen = [frozenset(seed)], set(), set()
        while frontier and stats["closure_expansions"] < max_closure_expansions:
            state = frontier.pop(0)
            if state in seen: continue
            seen.add(state)
            stats["closure_expansions"] += 1
            if len(documents(state)) > max_documents:
                stats["document_holds"] += 1
                continue
            active = [j for j in joins if j["required"] and set(j["unit_ids"]) <= established(state)]
            missing = next((j for j in active if not any(set(l["witness_ids"]) <= state for l in license_map[j["id"]])), None)
            if missing is None:
                completed.add(state)
                continue
            options = license_map[missing["id"]]
            if not options:
                stats["join_holds"] += 1
                continue
            frontier.extend(state | set(license["witness_ids"]) for license in options)
            frontier = sorted(set(frontier), key=rank)
            if len(frontier) > beam_width:
                stats["closure_pruned"] += len(frontier) - beam_width
                frontier = frontier[:beam_width]
        closure_capped = closure_capped or bool(frontier)
        return completed
    empty = frozenset()
    frontier, visited, best = [empty], {empty}, empty
    while frontier and stats["expansions"] < max_expansions:
        successors = set()
        for state in frontier:
            for proof in sorted(proofs, key=lambda p: p["id"]):
                if set(proof["witness_ids"]) <= state: continue
                if stats["expansions"] >= max_expansions: break
                stats["expansions"] += 1
                for candidate in close(state | set(proof["witness_ids"])):
                    if rank(candidate) < rank(best): best = candidate
                    if candidate not in visited:
                        visited.add(candidate)
                        successors.add(candidate)
        ordered = sorted(successors, key=rank)
        stats["beam_pruned"] += max(0, len(ordered) - beam_width)
        frontier = ordered[:beam_width]
    search_capped = closure_capped or bool(frontier) and stats["expansions"] >= max_expansions
    # Remove redundant uses only if the same established content and every
    # activated required join remain licensed. This never creates new support.
    for identity in sorted(best, key=lambda w: (-(known[w]["citation"]["end"] - known[w]["citation"]["start"]), w)):
        smaller = best - {identity}
        active = [j for j in joins if j["required"] and set(j["unit_ids"]) <= established(smaller)]
        if established(smaller) == established(best) and all(any(set(l["witness_ids"]) <= smaller for l in license_map[j["id"]]) for j in active):
            best = smaller
    selected = established(best)
    counters = [deepcopy(w) for w in known.values() if w["sign"] == "OPPOSITION"]
    required_joins = {j["id"] for j in joins if j["required"]}
    join_counters = [deepcopy(a["original"]) for a in audits if a["join_id"] in required_joins and
        a["original"]["state"] == "OPPOSED" and
        set(a["reasons"]) <= {"JOIN_NOT_LICENSED", "OPPONENT_IS_NOT_A_JOIN_LICENSE"}]
    join_rows = []
    for join in joins:
        matching = [l for l in license_map[join["id"]] if set(l["witness_ids"]) <= best and set(join["unit_ids"]) <= selected]
        join_rows.append(dict(requirement=deepcopy(join), state="LICENSED_IN_BUNDLE" if matching else "UNSUPPORTED_BRIDGE",
            selected_license_ids=sorted(l["id"] for l in matching),
            assessment_ids=[a["id"] for a in audits if a["join_id"] == join["id"]]))
    bridges = [j for j in join_rows if j["requirement"]["required"] and j["state"] != "LICENSED_IN_BUNDLE"]
    complete = bool(required_ids) and selected == set(required_ids) and not bridges and assessed_pool["query_scope_complete"] and not counters and not join_counters
    status = ("CONFLICTED" if counters or join_counters else "SUFFICIENT_IN_DECLARED_SOURCE_SCOPE" if complete else
              "UNRESOLVED_BRIDGES" if selected == set(required_ids) and required_ids else
              "PARTIAL" if selected or any(u["state"] == "PARTIAL" for u in units.values()) else "UNRESOLVED")
    quotes = {}
    for identity in sorted(best):
        ref = known[identity]["citation"]
        entry = quotes.setdefault(digest(ref), dict(citation=deepcopy(ref), witness_ids=[]))
        entry["witness_ids"].append(identity)
    selected_proofs = [p for p in proofs if set(p["witness_ids"]) <= best]
    remaining, cumulative, contributions = sorted(documents(best)), set(), []
    while remaining:
        document = min(remaining, key=lambda d: (-len(established(cumulative | {w for w in best if known[w]["citation"]["document_id"] == d}) - established(cumulative)), d))
        new_ids = {w for w in best if known[w]["citation"]["document_id"] == document}
        newly = established(cumulative | new_ids) - established(cumulative)
        declared_prerequisites = {w for p in selected_proofs for w in p.get("prerequisite_witness_ids", [])}
        primary_proof_ids = {w for p in selected_proofs for w in set(p["witness_ids"]) - set(p.get("prerequisite_witness_ids", []))}
        join_only_ids = {w for options in license_map.values() for license in options for w in license["witness_ids"]} - primary_proof_ids
        contributions.append(dict(document_id=document, newly_established_unit_ids=[u for u in required_ids if u in newly],
            zero_complete_components_at_this_step=not bool(newly),
            declared_prerequisite_witness_ids=sorted(new_ids & declared_prerequisites),
            prerequisite_only_source=bool(new_ids) and not bool(new_ids & primary_proof_ids) and new_ids <= declared_prerequisites | join_only_ids,
            contributes_to_proof_ids=sorted(p["id"] for p in selected_proofs if set(p["witness_ids"]) & new_ids)))
        cumulative.update(new_ids)
        remaining.remove(document)
    components = [dict(id=identity, text=descriptor["text"], native_state=units[identity]["state"],
        selected_full_proof=identity in selected,
        selected_proof_ids=sorted(p["id"] for p in selected_proofs if p["unit_id"] == identity),
        partial_witness_ids=sorted(w["id"] for w in known.values() if w["unit_id"] == identity and w["sign"] == "PARTIAL"),
        support_outside_bundle=units[identity]["state"] in {"SUPPORTED", "CONFLICTED"} and identity not in selected)
        for identity, descriptor in zip(required_ids, value["required_units"]["units"])]
    removable = [w for w in known if w not in best and known[w]["sign"] == "SUPPORT"]
    redundant = [w for w in removable if known[w]["unit_id"] in selected and
        all(p["unit_id"] in selected for p in proofs if w in p["witness_ids"]) and
        not any(w in license["witness_ids"] for options in license_map.values() for license in options)]
    assembly = [dict(unit_id=component["id"], text=component["text"], scope=deepcopy(units[component["id"]]["scope"]),
        witness_ids=sorted({w for p in selected_proofs if p["unit_id"] == component["id"] for w in p["witness_ids"]}))
        for component in components if component["selected_full_proof"]]
    result = dict(version=VERSION, task="mosaic", certificate_sha256=digest(value), assessed_pool_sha256=digest(assessed_pool),
        certificate_version=value["version"], producer_authority_sha256=value["producer_authority_sha256"],
        input_engine=deepcopy(value["engine"]), input_identities=deepcopy(value["identities"]),
        binding=deepcopy(value["binding"]), required_units=deepcopy(value["required_units"]),
        coverage=deepcopy(value["coverage"]), native_status=value["native_status"], native_scope=deepcopy(value["scope"]),
        status=status, sufficient_in_declared_source_scope=complete, selected_required_unit_ids=[u for u in required_ids if u in selected],
        selected_witness_ids=sorted(best), selected_proof_ids=sorted(p["id"] for p in selected_proofs),
        selected_document_ids=sorted(documents(best)), selected_quotes=list(quotes.values()), components=components,
        assembly=assembly, selected_proofs=deepcopy(selected_proofs),
        joins=join_rows, unsupported_bridges=bridges, license_audit=audits,
        material_counters=counters, counter_scope="ALL_RECORDED_ASSESSED_WITNESSES_IN_CERTIFICATE_INSPECTED_POOL",
        marginal_contributions=contributions, nonselected_support_witness_ids=sorted(removable),
        redundant_witness_ids=sorted(redundant), redundancy_basis="NO_ADDITIONAL_REQUIRED_CONTENT_OR_LICENSED_JOIN; NOT_AN_INDEPENDENCE_JUDGMENT",
        known_source_dependence=deepcopy(assessed_pool["dependence"]),
        same_document_witness_usages={d:sorted(w for w in best if known[w]["citation"]["document_id"] == d) for d in sorted(documents(best))},
        independent_corroboration_claimed=False, witness_catalog=deepcopy(list(known.values())),
        search=dict(stats, capped=search_capped, bounds=dict(max_documents=max_documents, beam_width=beam_width,
            max_expansions=max_expansions, baseline_document_ids=baseline), visited_states=len(visited),
            objective=["newly established existing required content", "fewer extra documents", "tighter union of exact witness spans", "stable witness IDs"],
            max_closure_expansions=max_closure_expansions,
            span_characters=_span_cost(best, known), result_claim="SMALLEST_SET_FOUND", global_minimum_proved=False),
        source_ascription_only=True, inner_execution_or_world_truth_inferred=False,
        source_replay_required=True, native_outputs_modified=False, model_calls=0)
    if join_counters:
        result["material_join_counters"] = join_counters
    return result


def validate_bundle(bundle, *, certificate, expected_context, expected_required_units, assessed_pool, **policy):
    """Reproduce from independently retained inputs/policy, never the bundle's claims."""
    expected = select_bundle(certificate, expected_context=expected_context,
        expected_required_units=expected_required_units, assessed_pool=assessed_pool, **policy)
    _require(bundle == expected, "Bundle does not reproduce from trusted certificate, assessments and policy")
    return deepcopy(bundle)


def native_pool(packet, *, record=None):
    """Observe saved native proof groups/scope checks without invoking inference.

    Unsupported saved join shapes remain explicit gaps. A satisfied same-event
    check requires its exact recorded predicate-occurrence token in every unit;
    publication dates and page overlap never substitute for that token.
    """
    context = c.context_for_packet(packet, record=record)
    certificate = c.adapt_native_assertions(packet) if record is None else c.adapt_observer_assertions(packet, record)
    _require(certificate["task"] == "mosaic", "Native pool requires Mosaic")
    catalog = witness_catalog(certificate)
    proofs, signatures = [], set()
    for witness in catalog:
        if witness["sign"] != "SUPPORT": continue
        refs = witness.get("details", {}).get("citations") or [witness["citation"]]
        ids = sorted(w["id"] for w in catalog if w["unit_id"] == witness["unit_id"] and w["sign"] == "SUPPORT" and w["citation"] in refs)
        signature = (witness["unit_id"], tuple(ids))
        if signature in signatures: continue
        signatures.add(signature)
        proofs.append(dict(id="p_" + digest(signature), unit_id=witness["unit_id"], witness_ids=ids,
            prerequisite_witness_ids=[], basis="SAVED_COMPLETE_SIGNED_SOURCE_DECISION; ALL_ITS_QUOTATIONS_RETAINED"))
    scope = packet["result"].get("query_requirements", {})
    joins, licenses = [], []
    required_ids = [u["id"] for u in certificate["units"]]
    checks = list(scope.get("checks", []))
    for group in packet["plan"].get("scope_constraints", []):
        if not any(set(check.get("atom_ids", [])) >= set(group.get("atom_ids", [])) and
                   check.get("kind") == group.get("kind") for check in checks):
            checks.append(dict(group, state="UNRESOLVED", reason="DECLARED_SCOPE_WITHOUT_SAVED_JOIN_CHECK"))
    for index, check in enumerate(checks):
        raw_identities = check.get("atom_ids", required_ids)
        identities = [u for u in raw_identities if u in required_ids] or required_ids
        unrepresented = sorted(set(raw_identities) - set(required_ids))
        kind = {"same_event":"event_identity", "shared_subject":"same_actor"}.get(check.get("kind"), "unmodeled")
        if unrepresented: kind = "unmodeled"
        join = dict(id="j_" + str(index), kind=kind, unit_ids=identities, required=True,
            bindings={"native_check_sha256":digest(check)}, description=check.get("reason", "Saved material query-scope constraint"))
        if unrepresented: join["bindings"]["unrepresented_unit_ids"] = unrepresented
        joins.append(join)
        witnesses = [w for w in catalog if w["unit_id"] in identities and w["sign"] == "SUPPORT"]
        candidates = _recorded_candidates(check, kind)
        unit_candidates = [{candidate for candidate in candidates if any(
            w["unit_id"] == identity and _matches_candidate(w, candidate) for w in witnesses)} for identity in identities]
        common = set.intersection(*unit_candidates) if unit_candidates else set()
        if check.get("state") == "SATISFIED" and common:
            # Each alternative proves ONE occurrence across the entire group.
            # Neither a union nor pairwise overlap supplies this intersection.
            for candidate in sorted(common):
                licenses.append(dict(id="l_" + str(index) + "_" + digest(candidate), join_id=join["id"], state="LICENSED",
                    witness_ids=sorted(w["id"] for w in witnesses if _matches_candidate(w, candidate)),
                    common_binding=_binding_record(candidate), bindings=deepcopy(join["bindings"]),
                    original_native_check=deepcopy(check)))
        else:
            licenses.append(dict(id="l_" + str(index), join_id=join["id"], state="UNRESOLVED",
                witness_ids=sorted(w["id"] for w in witnesses), common_binding=None,
                basis="NO_COMMON_RECORDED_OCCURRENCE_OR_SATISFIED_CHECK",
                bindings=deepcopy(join["bindings"]), original_native_check=deepcopy(check)))
    pool = pool_record(certificate, producer=dict(engine=certificate["engine"], native_scope_sha256=digest(scope)),
        query_scope_complete=scope.get("complete") is True, proofs=proofs, joins=joins, licenses=licenses)
    return dict(certificate=certificate, expected_context=context,
                expected_required_units=certificate["required_units"], assessed_pool=pool)
