"""Literal carrier/apposition cues schedule checks; they never establish a fact."""
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest

VERSION = 'source-property-carrier-opportunity/1'


def observe(page, part, citation, query_features, shared):
    result = dict(version=VERSION, matched=False, priority_only=True,
        identity_certified=False, factual_support_added=False, source_modified=False)
    if (part.doc.text != page['text'] or digest(page['text']) != page['source_sha256']
            or citation['page_sha256'] != page['source_sha256']
            or citation['canonical_page_id'] != page['id']
            or page['text'][citation['start']:citation['end']] != citation['text']):
        raise ValueError('Property opportunity lost its exact source binding')
    if MASK.search(citation['text']):
        return dict(result, reason='OPAQUE_SOURCE_UNIT')
    head = part.root
    if not (head.pos_ == 'ADJ' or head.pos_ == 'VERB' and head.tag_ in {'VBN', 'VBG'}):
        return dict(result, reason='NOT_SOURCE_ADJECTIVAL_PROPERTY')
    carrier = shared._nominal_carrier(part)
    if carrier is None or carrier.pos_ not in {'NOUN', 'PROPN'}:
        return dict(result, reason='NO_LITERAL_SOURCE_CARRIER')
    # Complete source modifiers keep their local qualification and negation.
    modifiers = [child for child in head.children if child.dep_ in {'advmod', 'neg', 'xcomp', 'ccomp', 'prep'}]
    if any(not token.is_space and not token.is_punct and token not in part
            for child in modifiers for token in child.subtree):
        return dict(result, reason='INCOMPLETE_MODIFIER')
    if any(child.dep_ == 'neg' and child not in part for owner in (head, carrier) for child in owner.children):
        return dict(result, reason='OUTSIDE_NEGATION')
    target = query_features.get('carrier')
    if not target:
        return dict(result, reason='NO_PUBLIC_QUERY_CARRIER')
    owners = [(carrier, 'LITERAL_CARRIER')]
    if carrier.dep_ == 'appos':
        owners.append((carrier.head, 'DIRECT_SOURCE_APPOSITION'))
    owners.extend((child, 'DIRECT_SOURCE_APPOSITION') for child in carrier.children if child.dep_ == 'appos')
    for owner, relation in owners:
        if (owner.sent != head.sent or owner.pos_ not in {'NOUN', 'PROPN'}
                or owner.lemma_.casefold() != target or not citation['start'] <= owner.idx < owner.idx + len(owner) <= citation['end']
                or any(child.dep_ == 'neg' for child in owner.children)):
            continue
        constraints = shared._owner_constraints(owner, part)
        if not shared._owner_compatibility(constraints, query_features.get('owner_constraints') or [])['compatible']:
            continue
        proof = lambda token: dict(text=token.text, start=token.idx, end=token.idx+len(token), lemma=token.lemma_.casefold())
        return dict(result, matched=True, relation=relation, source_carrier=proof(carrier),
            source_owner=proof(owner), query_carrier=target, source_quote=citation,
            meaning='GRAMMATICAL_SOURCE_CARRIER_MATCH_NOT_SAME_ACTOR_OR_EVENT')
    return dict(result, reason='NO_DIRECT_CARRIER_OR_APPOSITION_MATCH')
