"""Minimal, immutable source-manifest PDF attachments for selected CIB records."""
import csv
import hashlib
import os
from pathlib import Path
import re
import tempfile

from . import presentation

VERSION = "narrative-selected-cib-pdfs/1"
MAX_BYTES = 64 * 1024 * 1024


def _pdf_bytes(path, expected=None):
    path = Path(path)
    if path.is_symlink() or not 5 <= path.stat().st_size <= MAX_BYTES:
        raise ValueError("PDF is missing, redirected or exceeds its attachment bound")
    data = path.read_bytes()
    if not data.startswith(b"%PDF-") or expected and hashlib.sha256(data).hexdigest() != expected:
        raise ValueError("PDF attachment content or byte pin changed")
    return data


def stage(root, documents):
    """documents maps exact origin/source document IDs to allowed release sets."""
    import fitz
    root = Path(root).resolve()
    source = root.parent / "src-redaction"
    manifest = source / "data/source/manifests/cibcia.csv"
    with manifest.open(newline="", encoding="utf-8-sig") as stream:
        rows = list(csv.DictReader(stream))
    records = {}
    for row in rows:
        records.setdefault(row["Document_ID"], []).append(row)
    entries = {}
    for document, releases in sorted(documents.items()):
        if (not re.fullmatch(r"CIA-[A-Z0-9-]+", document) or not set(releases) <= {"earlier", "later"}
                or len(records.get(document, [])) != 1):
            raise ValueError("PDF document/release is not uniquely bound in the source manifest")
        row = records[document][0]
        record_id = row["Record_ID"]
        if not record_id.isdigit():
            raise ValueError("Non-numeric CIB source record ID")
        for release in sorted(releases):
            filename = document + ".pdf" if release == "earlier" else f"cib_{int(record_id):08d}.pdf"
            original = source / "data/source/pdfs" / release / filename
            if not original.resolve().is_relative_to(source.resolve()):
                raise ValueError("PDF source escapes the declared source dataset")
            data = _pdf_bytes(original)
            with fitz.open(stream=data, filetype="pdf") as pdf:
                pages = pdf.page_count
                if pdf.is_encrypted or not pages:
                    raise ValueError("Source PDF cannot be inspected")
            sha = hashlib.sha256(data).hexdigest()
            relative = presentation.PREFIX + "pdfs/" + sha + ".pdf"
            target = root / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if not target.resolve().is_relative_to(root) or target.is_symlink():
                raise ValueError("PDF publication path escapes the application")
            if target.exists():
                _pdf_bytes(target, sha)
            else:
                temporary = None
                try:
                    with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as stream:
                        temporary = Path(stream.name)
                        stream.write(data)
                        stream.flush()
                        os.fsync(stream.fileno())
                    try:
                        os.link(temporary, target)
                    except FileExistsError:
                        _pdf_bytes(target, sha)
                finally:
                    if temporary is not None:
                        temporary.unlink(missing_ok=True)
            entries[document + "/" + release] = dict(path=relative, sha256=sha,
                document_id=document, release=release, record_id=record_id, page_count=pages,
                bytes=len(data), source_path=str(original.relative_to(root.parent)),
                binding="SOURCE_MANIFEST_DOCUMENT_AND_RELEASE; NOT_A_SEMANTIC_CERTIFICATE")
    catalog = dict(version=VERSION, entries=entries, source_manifest=dict(
        path=str(manifest.relative_to(root.parent)), sha256=hashlib.sha256(manifest.read_bytes()).hexdigest()),
        inference_inputs_changed=False)
    from matryoshka_demo.io import digest
    return presentation.write(root, presentation.PREFIX + "pdf_catalog_" + digest(catalog) + ".json", catalog)


def read(root, catalog, document, release):
    if catalog.get("version") != VERSION:
        raise ValueError("Unknown PDF attachment catalog")
    entry = catalog["entries"][document + "/" + release]
    if entry["document_id"] != document or entry["release"] != release:
        raise ValueError("PDF release identity mismatch")
    relative = entry["path"]
    if not re.fullmatch(re.escape(presentation.PREFIX) + r"pdfs/[a-f0-9]{64}\.pdf", relative):
        raise ValueError("PDF is outside the immutable attachment namespace")
    if Path(relative).stem != entry["sha256"]:
        raise ValueError("PDF content address and byte pin differ")
    path = Path(root).resolve() / relative
    if not path.resolve().is_relative_to(Path(root).resolve()):
        raise ValueError("PDF attachment escapes the publication")
    data = _pdf_bytes(path, entry["sha256"])
    if len(data) != entry["bytes"]:
        raise ValueError("PDF attachment length changed")
    return data, "application/pdf"
