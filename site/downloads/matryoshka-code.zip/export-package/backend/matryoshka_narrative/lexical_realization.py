"""Source-nominated lexical grammar, never an entity or event identity oracle."""
from collections import defaultdict
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_demo import roles
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo_v61.candidates import boundary_fit


VERSION = "source-noun-slot-adjective-realization/2"
OPERATION = "PERSON_NOUN_MEMBER_HOLONYM_TO_ADJECTIVE_PERTAINYM"


@lru_cache(maxsize=1)
def _resource():
    wn = roles.lexicon()
    info = roles.binding()
    metadata = {k: info[k] for k in ("resource", "version", "nltk_version", "sha256")}
    metadata.update(availability="AVAILABLE", named_entity_identity_lookup=False,
        relation_scope="LEXICAL_CLASS_MEMBERSHIP_AND_PERTAINYM_ONLY",
        output_policy="SIMPLE_ASCII_ALPHABETIC_ADJECTIVE; COMPLEX_MEANING_PROOF_UNAVAILABLE")
    adjectives = defaultdict(set)
    for synset in wn.all_synsets(pos=wn.ADJ):
        for lemma in synset.lemmas():
            for parent in lemma.pertainyms():
                adjectives[parent.synset().name()].add((lemma.name(), synset.name()))
    return wn, metadata, {k: tuple(sorted(v)) for k, v in adjectives.items()}


class LexicalRealizer:
    """Lazy resource loading; retain all licensed paths rather than pick a sense."""
    def __init__(self):
        self.resource = dict(resource="WordNet", availability="NOT_LOADED")
        self.cache = {}

    def forms(self, noun):
        if noun not in self.cache:
            result = dict(source_noun=noun, forms=[], held_forms=[], noun_senses=[], ambiguity_unresolved=True)
            try:
                wn, metadata, adjectives = _resource()
                self.resource = deepcopy(metadata)
                senses = wn.synsets(noun, pos=wn.NOUN)
                result["noun_senses"] = sorted(s.name() for s in senses)
                found = defaultdict(list)
                for synset in senses:
                    ancestry = {s.name() for s in synset.closure(lambda s: s.hypernyms())}
                    if "person.n.01" not in ancestry:
                        continue
                    for group in synset.member_holonyms():
                        ancestors = {s.name() for s in group.closure(
                            lambda s: s.hypernyms() + s.instance_hypernyms())}
                        if "country.n.02" not in ancestors:
                            continue
                        for adjective, adjective_synset in adjectives.get(group.name(), ()):
                            found[adjective].append(dict(noun_synset=synset.name(),
                                member_holonym_synset=group.name(), adjective_synset=adjective_synset))
                for fill, paths in sorted(found.items()):
                    form = dict(fill=fill, operation=OPERATION, derivations=sorted(paths, key=digest))
                    if re.fullmatch(r"[A-Za-z]+", fill):
                        result["forms"].append(form)
                    else:
                        result["held_forms"].append(dict(form,
                            reason="NON_SIMPLE_ADJECTIVE_REQUIRES_MEANING_PRESERVATION_PROOF"))
                licensed = {p["noun_synset"] for form in result["forms"] for p in form["derivations"]}
                result.update(status="LICENSED_FORMS" if result["forms"] else
                    "NON_SIMPLE_FORMS_HELD" if found else "NO_LICENSED_FORM",
                    unlicensed_noun_senses=sorted(set(result["noun_senses"]) - licensed),
                    ambiguity_unresolved=len(senses) != 1 or len(result["forms"]) != 1)
            except (LookupError, OSError) as exc:
                self.resource = dict(resource="WordNet", availability="UNAVAILABLE",
                    error_type=type(exc).__name__)
                result.update(status="RESOURCE_UNAVAILABLE", error_type=type(exc).__name__)
            self.cache[noun] = result
        return deepcopy(self.cache[noun])


def applicable(row):
    reading = row["reading"]
    return (reading.get("outer_family") == "adjectival"
        and reading.get("function") == "modifier" and reading.get("role") == "nominal_property"
        and (row.get("constructor") or {}).get("form") == "modifier")


def _scope_hold(token):
    # Never turn a negated class predication, or a qualified source noun, into
    # an unqualified adjective. Retaining the quote alone cannot license that.
    for owner in (token, *token.ancestors):
        if owner.sent != token.sent:
            break
        if any(c.dep_ == "neg" or c.dep_ == "det" and c.lower_ in {"no", "neither"}
                for c in owner.children):
            return "SOURCE_NEGATION_IN_LEXICAL_SCOPE"
    if token.dep_ == "conj" or any(not c.is_punct
            and not (c.dep_ == "det" and c.lower_ in {"a", "an", "the"}) for c in token.children):
        return "QUALIFIED_SOURCE_NOUN_NOT_BARE_LEXICAL_IDENTITY"
    return None


def _source_class(token, page, source_types):
    """NER is context, not identity; Person witnesses must replay this source."""
    own = []
    for witness in source_types:
        a, b = witness.get("start"), witness.get("end")
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
                or witness.get("canonical_page_id") != page["id"]
                or witness.get("page_sha256") != page["source_sha256"]
                or page["text"][a:b] != witness.get("label")):
            raise ValueError("Lexical source-kind witness lost its exact page/span binding")
        if a <= token.idx < token.idx + len(token) <= b:
            own.append(deepcopy(witness))
    kinds = {w["source_entity_type"] for w in own}
    norp = [dict(start=e.start_char, end=e.end_char, text=e.text, label=e.label_)
        for e in token.doc.ents if e.label_ == "NORP"
        and e.start_char <= token.idx < token.idx + len(token) <= e.end_char]
    reason = ("EXPLICIT_SOURCE_NOUN_KIND_NOT_PERSON_CLASS" if kinds - {"Person", "Other"} else
        None if norp or "Person" in kinds else "NO_ATTESTED_NORP_OR_OWN_SOURCE_PERSON_WITNESS")
    return dict(state="hold" if reason else "class_context", reason=reason,
        source_noun_ner=token.ent_type_, norp_observations=norp, own_source_kind_witnesses=own,
        ambiguity_resolved=False, identity_certified=False, factual_support_certified=False)


def proposals(page, doc, rows, realizer, holds, *, source_spans, source_types=()):
    """Nominate actual source noun tokens before asking the resource for forms."""
    active = [r for r in rows if applicable(r)]
    if not active:
        return []
    values = []
    for token in doc:
        if token.pos_ not in {"NOUN", "PROPN"}:
            continue
        nominated = [s for s in source_spans if s["kind"] == "nominal"
            and not s.get("source_format_rejection")
            and s["start"] <= token.idx < token.idx + len(token) <= s["end"]]
        if not nominated:
            continue
        if MASK.search(token.sent.text):
            continue
        lookup = realizer.forms(token.text)
        if not lookup["forms"] and not lookup["held_forms"]:
            continue
        source_class = _source_class(token, page, source_types)
        reason = _scope_hold(token)
        if source_class["state"] == "hold":
            reason = source_class["reason"]
        if reason:
            holds.append(dict(canonical_page_id=page["id"], page_sha256=page["source_sha256"],
                source_span=[token.idx, token.idx + len(token)], source_wording=token.text,
                reason=reason, source_class_observation=source_class, not_factual_counterevidence=True))
            continue
        for held in lookup["held_forms"]:
            holds.append(dict(canonical_page_id=page["id"], page_sha256=page["source_sha256"],
                source_span=[token.idx, token.idx + len(token)], source_wording=token.text,
                reason=held["reason"], held_form=held, not_factual_counterevidence=True))
        for row in active:
            for form in lookup["forms"]:
                values.append(dict(kind="nominal", start=token.idx, end=token.idx + len(token),
                    text=token.text, only_reading=row["reading"]["id"],
                    nominated_constituent={k: min(nominated, key=lambda s:s["end"]-s["start"])[k]
                        for k in ("start", "end", "text")},
                    source_class_observation=deepcopy(source_class),
                    lexical_form=form, lexical_lookup=lookup))
    return values


def wording(case, row, page, raw, part, citation, realizer, *, source_types=()):
    """Replay both source and resource paths; never replace the source quotation."""
    if not applicable(row) or len(part) != 1 or part.root.pos_ not in {"NOUN", "PROPN"}:
        raise ValueError("Lexical realization requires a declared adjective and an observed noun")
    a, b = raw["start"], raw["end"]
    lo, hi = citation["start"], citation["end"]
    if (type(a) is not int or type(b) is not int or type(lo) is not int or type(hi) is not int
            or not 0 <= lo <= a < b <= hi <= len(page["text"])
            or part.start_char != a or part.end_char != b or part.doc.text != page["text"]
            or page["text"][a:b] != raw["text"] or page["text"][lo:hi] != citation["text"]
            or digest(page["text"]) != page["source_sha256"]
            or any(citation[k] != page[p] for k, p in (("canonical_page_id", "id"),
                ("document_id", "document_id"), ("date", "date"), ("page_sha256", "source_sha256")))
            or MASK.search(citation["text"]) or _scope_hold(part.root)):
        raise ValueError("Lexical realization lost its literal source/scope binding")
    constituent = raw["nominated_constituent"]
    start, end = constituent.get("start"), constituent.get("end")
    if (type(start) is not int or type(end) is not int or not lo <= start <= a < b <= end <= hi
            or page["text"][start:end] != constituent.get("text")):
        raise ValueError("Lexical nomination lost its complete source constituent")
    source_class = _source_class(part.root, page, source_types)
    if source_class["state"] == "hold" or source_class != raw.get("source_class_observation"):
        raise ValueError("Lexical realization lacks an attested source class witness")
    lookup = realizer.forms(raw["text"])
    form = raw["lexical_form"]
    if lookup != raw["lexical_lookup"] or form not in lookup["forms"]:
        raise ValueError("Lexical realization is not licensed by the bound resource")
    fitted = boundary_fit(case, form["fill"])
    if not fitted["admissible"]:
        return None, None, fitted.get("reason", "LEXICAL_FORM_BOUNDARY_HOLD")
    edit = dict(kind=OPERATION, before=raw["text"], after=form["fill"],
        resource=deepcopy(realizer.resource), derivations=deepcopy(form["derivations"]),
        grammar_only=True, source_modified=False, source_evidence_credit=False,
        source_is_verbatim_adjective=False, identity_or_event_certified=False)
    edits = [edit, *fitted["edits"]]
    audit = dict(version=VERSION, state="licensed", source_identity=raw["text"], source_span=[a, b],
        source_noun_ner=part.root.ent_type_, lexical_resource_does_not_certify_ner=True,
        source_class_observation=source_class,
        nominated_constituent=deepcopy(raw["nominated_constituent"]),
        original_quote=deepcopy(citation), resource=deepcopy(realizer.resource),
        proposed_insertion=fitted["fill"], transformations=deepcopy(edits), lexical_lookup=lookup,
        selected_form=deepcopy(form), ambiguity_unresolved=lookup["ambiguity_unresolved"],
        source_nominated_before_realization=True, source_wording_modified=False,
        verbatim_source_fill=False, context_only=True, factual_support_certified=False,
        same_owner_or_event_certified=False, used_as_retrieval_seed=False)
    return (fitted["fill"], edits), audit, None


def context_features(feature):
    """A noun's source argument does not become an adjective's positive clue."""
    result = deepcopy(feature)
    for key in ("source_owned_relation_match", "source_owned_property_match", "direct_actor_relation_match",
                "direct_argument_relation_match", "source_type_match"):
        result[key] = False
    result["source_boundary_frame_cue"] = dict(matched=False)
    result["source_role_type_license"] = dict(eligible=False)
    result["lexical_realization_context_only"] = True
    return result
