"""Bounded public-input grammar suggestions, separate from corpus inference.

The workflow records nominate(...) as result.input_nomination. Its verified
forms can enter the proposal slate, but never append corpus evidence or votes.
"""
from copy import deepcopy

from matryoshka_demo.contracts import FORBIDDEN, MASK, public_case
from matryoshka_demo.io import digest, offline
from . import construction, lexical_realization as lexical


VERSION = "public-input-noun-adjective-nomination/1"
PROVENANCE = "ANALYST_INPUT_NOT_INDEPENDENT_CORPUS_EVIDENCE"
MAX_QUERY_CHARACTERS = 16384
MAX_NOUN_CHECKS = 64
MAX_SURFACE_CHECKS_PER_READING = 16
_PRIVATE = FORBIDDEN | {"reference_answer", "answer_key", "evaluation_keys", "grades",
    "origin_text", "origin_body", "source_proof", "source_qa"}


def _public_only(value):
    if isinstance(value, dict):
        if _PRIVATE.intersection(value):
            raise ValueError("Private answer/source/grade fields cannot nominate input forms")
        for child in value.values():
            _public_only(child)
    elif isinstance(value, (tuple, list)):
        for child in value:
            _public_only(child)


def _span(query, query_sha, a, b):
    if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(query):
        raise ValueError("Input span is outside the public query")
    return dict(query_sha256=query_sha, start=a, end=b, text=query[a:b], provenance_kind=PROVENANCE)


def _input_class(token, query, query_sha):
    # The shared guard requires a hash-bound text context. This internal ID is
    # a query identity, not a corpus page, admission record or citation.
    context = dict(id="input-query:"+query_sha, text=query, source_sha256=query_sha)
    people = [e for e in token.doc.ents if e.label_ == "PERSON"
        and e.start_char == token.idx and e.end_char == token.idx+len(token)]
    witnesses = [dict(canonical_page_id=context["id"], page_sha256=query_sha,
        start=e.start_char, end=e.end_char, label=e.text, source_entity_type="Person") for e in people]
    checked = lexical._source_class(token, context, witnesses)
    return dict(state=checked["state"], reason=checked["reason"], input_noun_ner=checked["source_noun_ner"],
        norp_observations=[_span(query, query_sha, p["start"], p["end"])
            for p in checked["norp_observations"]],
        person_observations=[_span(query, query_sha, e.start_char, e.end_char) for e in people],
        basis="INPUT_PARSER_NORP_OR_EXACT_PERSON_SPAN_NOT_PLANNER_TYPE_HINT",
        lexical_resource_does_not_certify_ner=True, ambiguity_resolved=False,
        identity_certified=False, factual_support_certified=False)


def _bare_constituent(token, spans, doc):
    if token.dep_ in {"compound", "flat", "flat:name", "name"}:
        return None
    found = []
    for raw in spans:
        if (raw["kind"] != "nominal" or raw.get("source_format_rejection")
                or not raw["start"] <= token.idx < token.idx+len(token) <= raw["end"]):
            continue
        part = doc.char_span(raw["start"], raw["end"], alignment_mode="strict")
        if part is None or part.root != token:
            continue
        words = [t for t in part if not t.is_space and not t.is_punct
            and not (t.dep_ == "det" and t.lower_ in {"a", "an", "the"})]
        if words == [token]:
            found.append(part)
    return min(found, key=lambda p:len(p.text)) if found else None


def _distance(a, b, focal_start, focal_end):
    return max(focal_start-b, a-focal_end, 0)


def nominate(case, plan, parser):
    """Return the separate input_nomination payload, never a native result.

    Inputs are only the public case, its bound plan/readings and shared parser.
    Parser Person observations must cover the exact bare class noun; planner
    labels cannot retype a vegetable, name component or organization as people.
    """
    _public_only(case)
    _public_only(plan)
    case = public_case(case)
    if case["task"] != "redaction":
        raise ValueError("Input adjective nomination requires a Redaction case")
    query = case["query"]
    if len(query) > MAX_QUERY_CHARACTERS:
        raise ValueError("Public input exceeds the bounded nomination character limit")
    snapshot = digest([case, plan])
    with offline():
        adapted = construction.adapt_plan(case, plan)
        result = _nominate(case, plan, parser, adapted)
    if digest([case, plan]) != snapshot:
        raise ValueError("Input nomination changed its public query or plan")
    return result


def _nominate(case, plan, parser, adapted):
    query, query_sha = case["query"], digest(case["query"])
    binding = dict(case_sha256=digest(case), query_sha256=query_sha, plan_sha256=digest(plan),
        readings_packet_sha256=digest(plan["readings_packet"]), lexical_policy_version=lexical.VERSION,
        final_form_version=construction.FINAL_FORM_VERSION)
    rows = adapted["readings"]
    active = [row for row in rows if lexical.applicable(row)]
    realizer = lexical.LexicalRealizer()
    holds, observations = [], []
    counters = dict(input_noun_tokens=0, noun_checks=0, noun_checks_withheld=0,
        licensed_noun_observations=0, surface_checks=0, surface_checks_withheld=0)
    focal_start = query.index(case["focal_marker"])
    focal_end = focal_start+len(case["focal_marker"])
    if active:
        doc, spans = construction.shared.proposal_spans(query, parser)
        if doc.text != query:
            raise ValueError("Shared parser changed the literal public input")
        sentences = list(doc.sents)
        focal = [i for i, s in enumerate(sentences) if s.start_char <= focal_start < focal_end <= s.end_char]
        if len(focal) != 1:
            raise ValueError("Focal slot does not belong to one complete input sentence")
        sentence_index = {t.i:i for i, sentence in enumerate(sentences) for t in sentence}
        nouns = [t for t in doc if t.pos_ in {"NOUN", "PROPN"}]
        counters["input_noun_tokens"] = len(nouns)
        nouns.sort(key=lambda t:(abs(sentence_index[t.i]-focal[0]),
            _distance(t.idx, t.idx+len(t), focal_start, focal_end), t.idx))
        for token in nouns:
            sentence = sentences[sentence_index[token.i]]
            sentence_text = query[sentence.start_char:sentence.end_char]
            if MASK.search(sentence_text):
                continue
            if counters["noun_checks"] >= MAX_NOUN_CHECKS:
                counters["noun_checks_withheld"] += 1
                continue
            counters["noun_checks"] += 1
            lookup = realizer.forms(token.text)
            if not lookup["forms"] and not lookup["held_forms"]:
                if lookup["status"] == "RESOURCE_UNAVAILABLE":
                    holds.append(dict(reason="LEXICAL_RESOURCE_UNAVAILABLE", provenance_kind=PROVENANCE))
                    break
                continue
            noun = _span(query, query_sha, token.idx, token.idx+len(token))
            sentence_proof = _span(query, query_sha, sentence.start_char, sentence.end_char)
            part = _bare_constituent(token, spans, doc)
            classification = _input_class(token, query, query_sha)
            reason = lexical._scope_hold(token)
            if part is None:
                reason = reason or "NO_COMPLETE_BARE_INPUT_NOMINAL_CONSTITUENT"
            if classification["state"] == "hold":
                reason = classification["reason"]
            if reason:
                holds.append(dict(reason=reason, input_noun_span=noun, input_sentence_span=sentence_proof,
                    input_class_observation=classification, provenance_kind=PROVENANCE,
                    not_factual_counterevidence=True))
                continue
            for held in lookup["held_forms"]:
                holds.append(dict(reason=held["reason"], held_form=held, input_noun_span=noun,
                    input_sentence_span=sentence_proof, provenance_kind=PROVENANCE,
                    not_factual_counterevidence=True))
            for form in lookup["forms"]:
                observations.append(dict(form=form, lookup=lookup,
                    input_noun_span=dict(noun, lemma=token.lemma_, pos=token.pos_, ner=token.ent_type_),
                    input_constituent_span=_span(query, query_sha, part.start_char, part.end_char),
                    input_sentence_span=sentence_proof, input_class_observation=classification,
                    sentence_distance=abs(sentence_index[token.i]-focal[0]),
                    character_distance=_distance(token.idx, token.idx+len(token), focal_start, focal_end)))
            counters["licensed_noun_observations"] += bool(lookup["forms"])
    output = []
    for row in rows:
        declared = row["reading"]
        nominated, checks = {}, 0
        if lexical.applicable(row):
            for observation in observations:
                form = observation["form"]
                key = form["fill"].casefold()
                if key in nominated:
                    nominated[key]["input_occurrences"].append(deepcopy(observation))
                    continue
                if checks >= MAX_SURFACE_CHECKS_PER_READING:
                    counters["surface_checks_withheld"] += 1
                    continue
                checks += 1
                counters["surface_checks"] += 1
                fitted = lexical.boundary_fit(case, form["fill"])
                fit = (construction.final_form_fit(case, declared, fitted["fill"], parser)
                    if fitted["admissible"] else None)
                if fit is None or fit["state"] != "pass":
                    holds.append(dict(reading_id=declared["id"], input_noun_span=observation["input_noun_span"],
                        reason="DECLARED_INPUT_ADJECTIVE_SURFACE_NOT_ESTABLISHED", surface_fit=fit,
                        boundary_fit=fitted, provenance_kind=PROVENANCE, not_factual_counterevidence=True))
                    continue
                edit = dict(kind=lexical.OPERATION, before=observation["input_noun_span"]["text"],
                    after=form["fill"], derivations=deepcopy(form["derivations"]),
                    grammar_only=True, input_text_modified=False, source_evidence_credit=False,
                    identity_or_event_certified=False)
                nominated[key] = dict(id="input_nomination_"+digest([VERSION, binding, declared["id"], key])[:24],
                    reading_id=declared["id"], declared_reading_sha256=digest(declared), fill=fitted["fill"],
                    provenance_kind=PROVENANCE, status="INPUT_DERIVED_GRAMMATICAL_CONTEXT_ONLY",
                    input_noun_span=deepcopy(observation["input_noun_span"]),
                    input_constituent_span=deepcopy(observation["input_constituent_span"]),
                    input_sentence_span=deepcopy(observation["input_sentence_span"]),
                    input_class_observation=deepcopy(observation["input_class_observation"]),
                    input_occurrences=[deepcopy(observation)], surface_fit=fit,
                    lexical_realization=dict(version=lexical.VERSION, resource=deepcopy(realizer.resource),
                        selected_form=deepcopy(form), lexical_lookup=deepcopy(observation["lookup"]),
                        ambiguity_unresolved=observation["lookup"]["ambiguity_unresolved"],
                        transformations=[edit, *deepcopy(fitted["edits"])], context_only=True,
                        identity_or_event_certified=False, factual_support_certified=False),
                    ranking=dict(sentence_distance=observation["sentence_distance"],
                        character_distance=observation["character_distance"],
                        scope="INPUT_CONTEXT_ONLY_NOT_CORPUS_RANK_OR_CONFIDENCE"),
                    independent_corpus_evidence=False, independent_evidence_votes=0,
                    substantive_support=False, same_actor_or_event_certified=False,
                    same_delegation_identity_certified=False, coreference_inference_performed=False,
                    corpus_citation=None, corpus_score=None, factual_decision=None)
        values = sorted(nominated.values(), key=lambda c:(c["ranking"]["sentence_distance"],
            c["ranking"]["character_distance"], c["input_noun_span"]["start"], c["fill"].casefold()))
        for rank, candidate in enumerate(values, 1):
            candidate["ranking"]["input_context_ordinal"] = rank
        output.append(dict(reading_id=declared["id"], declared_reading_sha256=digest(declared),
            applicable=lexical.applicable(row), status="INPUT_CONTEXT_NOMINATIONS" if values else
                "NO_INPUT_DERIVED_NOMINATIONS" if lexical.applicable(row) else "NOT_APPLICABLE",
            nominations=values, surface_checks=checks))
    return dict(version=VERSION, provenance_kind=PROVENANCE, binding=binding,
        status="INPUT_CONTEXT_NOMINATIONS" if any(r["nominations"] for r in output) else "NO_INPUT_DERIVED_NOMINATIONS",
        readings=output, holds=holds, counts=counters, lexical_resource=deepcopy(realizer.resource),
        bounds=dict(query_characters=MAX_QUERY_CHARACTERS, noun_checks=MAX_NOUN_CHECKS,
            surface_checks_per_reading=MAX_SURFACE_CHECKS_PER_READING),
        ranking_policy="LEXICOGRAPHIC_SENTENCE_DISTANCE_CHARACTER_DISTANCE_RAW_SPAN_STABLE_FORM",
        ranking_is_confidence=False, ranking_is_semantic_identity=False, empty_readings_are_not_padded=True,
        output_contract="ASSIGN_ONLY_TO_RESULT_INPUT_NOMINATION_NOT_CORPUS_CANDIDATES_OR_SCORES",
        input_sentence_policy="COMPLETE_VISIBLE_SENTENCE_NO_OPAQUE_MASKS",
        corpus_retrieval_or_admission_performed=False, source_policy_modified=False,
        independent_corpus_evidence=False, independent_evidence_votes=0,
        substantive_support=False, same_actor_or_event_certified=False,
        same_delegation_identity_certified=False, native_corpus_recovery_claimed=False,
        corpus_candidates_or_scores_modified=False, api_calls=0)


def replay(value, case, plan, parser):
    """Recompute spans, class/scope, resource, routing, surfaces and ordering."""
    if not isinstance(value, dict) or value != nominate(case, plan, parser):
        raise ValueError("Input nomination failed exact public-input/resource/reading replay")
    return True
