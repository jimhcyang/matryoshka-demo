"""Closed first top-level AND accounts, with one licensed common-noun repair.

Raw source citations never change. Normalized accounts are operator-only and
never certify execution, world truth, identities or event joins.
"""
from copy import deepcopy
from functools import lru_cache
import re
import string

from matryoshka_demo.io import digest, offline
from matryoshka_demo.roles import lexicon, binding
from matryoshka_demo_v6.planning import sentences, SECTION
from matryoshka_demo.contracts import MASK
from matryoshka_demo_v61.scope_matching import _layout
from matryoshka_next.facts import public_plan
from matryoshka_next.decisions import _prefix_blocker
from .source_qualification import raw_envelope_holds
from . import source_account_match as account
from .source_relative_accounts import _tail_holds

VERSION = "closed-source-prefix-account/3"
PROOF_FIELD = "source_prefix_account_certificate"
LITERAL_TYPE = "LITERAL_FIRST_TOP_LEVEL_AND_SOURCE_ACCOUNT"
NORMALIZED_TYPE = "COMMON_NOUN_NORMALIZED_FIRST_AND_OPERATOR_ACCOUNT"
_LEX = re.compile(r"[A-Za-z]+|\d+(?:,\d{3})*|[^\s]")
_IDENTITY_ROLES = {"ROOT", "nsubj", "nsubjpass", "csubj", "csubjpass", "agent",
    "attr", "oprd", "acomp", "appos", "poss", "dobj", "obj", "iobj", "dative"}


def _normal(text):
    return " ".join(text.casefold().split()).removesuffix(".")


@lru_cache(maxsize=4096)
def _common_nouns(word):
    return tuple(s.name() for s in lexicon().synsets(word, pos="n")
        if not s.instance_hypernyms() and any(n.islower() for n in s.lemma_names()))


def _neighbors(word):
    result = {word[:i] + word[i + 1:] for i in range(len(word))}
    result.update(word[:i] + c + word[i + 1:] for i in range(len(word)) for c in string.ascii_lowercase)
    result.update(word[:i] + c + word[i:] for i in range(len(word) + 1) for c in string.ascii_lowercase)
    result.discard(word)
    return result


def _edit(source, target):
    for i in range(len(source) + 1):
        if source[:i] != target[:i]:
            continue
        if len(target) == len(source) + 1 and source[i:] == target[i + 1:]:
            return dict(kind="INSERT_ONE_CHARACTER", at=i, character=target[i])
        if len(source) == len(target) + 1 and source[i + 1:] == target[i:]:
            return dict(kind="DELETE_ONE_CHARACTER", at=i, character=source[i])
        if len(source) == len(target) and i < len(source) and source[i + 1:] == target[i + 1:]:
            return dict(kind="REPLACE_ONE_CHARACTER", at=i, before=source[i], after=target[i])
    return None


def _protected_head(token):
    if token.dep_ in _IDENTITY_ROLES:
        return True
    if any(t.dep_ == "agent" or t.lower_ == "as" and t.dep_ == "prep" for t in token.ancestors):
        return True
    return any(s.lexname() in {"noun.person", "noun.group"}
        for s in lexicon().synsets(token.text.casefold(), pos="n"))


@lru_cache(maxsize=1)
def _account_evaluations():
    positive = {"true", "accurate", "supported", "verified", "substantiated",
        "confirmed", "correct", "valid", "reliable", "factual", "proven"}
    negative_senses = {a.synset() for w in positive for s in lexicon().synsets(w, pos="a")
        for lemma in s.lemmas() for a in lemma.antonyms()}
    negative_senses |= {n for s in tuple(negative_senses) for n in s.similar_tos()}
    negative = {name.casefold() for s in negative_senses for name in s.lemma_names()}
    return frozenset(positive), frozenset(negative)


def _metadiscourse_holds(base, page, end):
    context = account._report_context(base, page, end)
    if context is None:
        return True
    doc = base.engine.parse(page["text"][end:context["end"]])
    positive, negative = _account_evaluations()
    for root in doc:
        if root.dep_ not in {"ROOT", "conj"}:
            continue
        owner = account._subject(root)
        if owner is None:
            continue
        words = {t.lower_ for t in owner.children}
        current = owner.lower_ in {"this", "that"} or (
            owner.lemma_.casefold() in account._REPORT_NOUNS | {"view", "assessment", "assertion", "proposition", "conclusion"}
            and bool(words & {"this", "that", "such", "the"}) and not words & account._DISTINCT
            and not any(t.dep_ == "poss" and t.pos_ == "PROPN" for t in owner.children))
        if not current:
            continue
        properties = [root, *(t for c in root.children if c.dep_ in {"attr", "acomp", "oprd"} for t in c.subtree)]
        root_negation = [t for t in root.children if t.dep_ == "neg"]
        direct = sorted((t for t in root.children if t.dep_ in {"attr", "acomp", "oprd"}), key=lambda t: t.i)
        for prop in properties:
            word = prop.lemma_.casefold()
            if word not in positive | negative:
                continue
            owned = [t for t in prop.children if t.dep_ == "neg"]
            # A copular NOT owns only its first direct evaluation. It does not
            # cross a BUT/AND edge to an independently evaluated conjunct.
            if prop != root and direct and prop == direct[0] and root_negation:
                if owned or len(root_negation) != 1 or root_negation[0].i > prop.i:
                    return True
                owned = root_negation
            if len(owned) > 1:
                return True
            negated = bool(owned)
            if (word in negative and not negated) or (word in positive and negated):
                return True
    return False


def _identity(query, prefix, qdoc, sdoc, mapping, unit_start):
    if _normal(query) == _normal(prefix):
        return dict(mode="EXACT_AFTER_DECLARED_LAYOUT_CASE_WHITESPACE_AND_END_PERIOD", repair=None)
    qt, st = list(_LEX.finditer(query.removesuffix("."))), list(_LEX.finditer(prefix))
    if len(qt) != len(st):
        return None
    differences = [(q, s) for q, s in zip(qt, st) if q.group().casefold() != s.group().casefold()]
    if len(differences) != 1:
        return None
    q, s = differences[0]
    wanted, raw = q.group().casefold(), s.group().casefold()
    qtoken = next((t for t in qdoc if (t.idx, t.idx + len(t)) == q.span()), None)
    stoken = next((t for t in sdoc if (t.idx, t.idx + len(t)) == s.span()), None)
    if (qtoken is None or stoken is None or qtoken.pos_ != "NOUN" or qtoken.ent_type_
            or stoken.pos_ != "NOUN" or stoken.ent_type_ or len(wanted) < 7
            or _protected_head(qtoken) or _protected_head(stoken)
            or not wanted.isascii() or not wanted.isalpha() or not raw.isascii() or not raw.isalpha()
            or lexicon().synsets(raw) or not _common_nouns(wanted)):
        return None
    operation = _edit(raw, wanted)
    candidates = sorted(w for w in _neighbors(raw) if _common_nouns(w))
    if operation is None or candidates != [wanted]:
        return None
    revised = prefix[:s.start()] + q.group() + prefix[s.end():]
    if _normal(revised) != _normal(query):
        return None
    start = mapping[s.start()] if mapping is not None else s.start()
    end = mapping[s.end() - 1] + 1 if mapping is not None else s.end()
    return dict(mode="ONE_RESOURCE_BOUND_NONLEXICAL_COMMON_NOUN_ORTHOGRAPHIC_REPAIR",
        repair=dict(raw_token=s.group(), raw_start=unit_start + start, raw_end=unit_start + end,
            analysis_word=q.group(), operation=operation, source_has_no_wordnet_sense=True,
            query_token=account._proof(qtoken), noninstance_noun_senses=list(_common_nouns(wanted)),
            unique_distance_one_common_noun_candidates=candidates, resource=binding(),
            named_entity_or_identity_inference=False, raw_quote_edited=False),
        analysis_prefix=revised)


def _public(base, atom):
    spans = atom.get("query_spans", [])
    return len(spans) == 1 and any(
        (s["start"], s["end"], s["text"]) == (spans[0]["start"], spans[0]["end"], spans[0]["text"])
        and _normal(atom["text"]) == _normal(s["text"]) for s in sentences(base.case["query"]))


def _completion(doc, base, page, unit):
    root = account._root(doc)
    if root is None or root.pos_ not in {"VERB", "AUX", "ADJ"}:
        return None
    # Personal/deictic references cannot borrow identities from the omitted Q.
    if any(t.pos_ == "PRON" and t.lower_ not in {"what", "which"} for t in doc):
        return None
    if any(t.dep_ == "neg" or t.lower_ == "never" for t in root.children):
        return None
    if account._complete(doc, named=False):
        subject = account._subject(root)
        if subject is not None and subject.pos_ != "PRON":
            return dict(kind="EXPLICIT_PARSED_MATRIX_SUBJECT", subject=account._proof(subject))
    # Closed printed NP + MD [ONLY] HAVE BEEN VBN. The parser may lose the
    # ordinary nominal subject, but no word, predicate, modal or condition moves.
    tokens = account._tokens(doc)
    modals = [i for i, t in enumerate(tokens) if t.tag_ == "MD" and t.head == root]
    if len(modals) != 1 or root.tag_ != "VBN":
        return None
    at = modals[0]
    after = tokens[at + 1:]
    if after and after[0].lower_ == "only":
        after = after[1:]
    if len(after) < 3 or [t.lower_ for t in after[:2]] != ["have", "been"] or after[2] != root:
        return None
    before = [t for t in doc if t.idx < tokens[at].idx and not t.is_space]
    commas = [i for i, t in enumerate(before) if t.text == ","]
    cut = commas[-1] + 1 if commas else 0
    if commas and before[0].lower_ != "with":
        return None
    np = before[cut:]
    if np and np[0].lower_ in {"the", "a", "an"}:
        np = np[1:]
    if len(np) != 1 or np[0].ent_type_ or not np[0].text.isalpha():
        return None
    nominal_context = None
    if not _common_nouns(np[0].text.casefold()):
        previous = [s for s in sentences(page["text"]) if s["end"] <= unit["start"]]
        if not previous:
            return None
        prior = previous[-1]
        gap = page["text"][prior["end"]:unit["start"]]
        if (gap.strip() or re.search(r"\n\s*\n", gap) or len(prior["text"]) > 2048
                or MASK.search(prior["text"]) or SECTION.search(prior["text"])):
            return None
        prior_doc = base.engine.parse(prior["text"])
        nouns = [t for t in prior_doc if t.text.casefold() == np[0].text.casefold()
            and t.pos_ == "NOUN" and t.dep_ == "pobj" and t.head.pos_ == "ADP" and not t.ent_type_]
        if len(nouns) != 1 or any(t.is_quote for t in prior_doc):
            return None
        nominal_context = dict(citation=base.policy.citation(base.positions[page["id"]], prior["start"], prior["end"]),
            noun=account._proof(nouns[0]), function="LOCAL_LITERAL_NOUN_TYPE_NOT_ACTION_OR_IDENTITY_SUPPORT")
    return dict(kind="PRINTED_COMMON_NP_MD_OPTIONAL_ONLY_HAVE_BEEN_VBN",
        subject=account._proof(np[0]), resource=binding(),
        source_nominal_context=nominal_context,
        entire_preposed_WITH_condition_retained=True, dependency_graph_not_rewritten=True)


def supplement(matcher, atom, page, unit, control):
    base = getattr(matcher, "baseline", matcher)
    if (base.case["task"] not in {"hypothesis", "reconstruction"} or atom.get("kind") != "proposition"
            or control.get("direction") not in {"UNRESOLVED", "PARTIAL"}
            or any(control.get(k) for k in ("source_account_policy_withheld", "root_content_withheld",
                "root_content_policy_applicable", "potential_counter", "unbound_material_counter"))):
        return control
    public_plan(base.case, dict(atoms=[atom], query_sha256=digest(base.case["query"])))
    pi = base.positions.get(page.get("id"))
    if pi is None or page != base.corpus.pages[pi] or digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Prefix account needs the full bound raw page")
    citation = base.policy.citation(pi, unit["start"], unit["end"])
    if citation != control.get("citation") or citation["text"] != unit.get("text", unit.get("quote")):
        raise ValueError("Prefix account full citation does not replay")
    if (len(citation["text"]) > 4096 or len(atom["text"]) > 2048 or not _public(base, atom)
            or (unit["start"], unit["end"]) not in {(s["start"], s["end"]) for s in sentences(page["text"])}):
        return control
    with offline():
        raw_doc = base.engine.parse(citation["text"])
        if _prefix_blocker(page, unit["start"], base.engine) or raw_envelope_holds(base, page, citation, raw_doc):
            return control
        qview, _, qnorm = _layout(base.engine, atom["text"])
        sview, mapping, snorm = _layout(base.engine, citation["text"])
        qdoc, sdoc = base.engine.parse(qview), base.engine.parse(sview)
        root = account._root(sdoc)
        if root is None or any(t.dep_ == "neg" or t.lower_ == "never" for t in root.children):
            return control
        conjuncts = [t for t in root.children if t.dep_ == "conj" and t.pos_ in {"VERB", "AUX", "ADJ"}]
        coordinators = [t for t in root.children if t.dep_ == "cc"]
        if (len(conjuncts) != 1 or len(coordinators) != 1 or coordinators[0].lower_ != "and"
                or account._subject(conjuncts[0]) is None
                or not any(t.tag_ in {"VBD", "VBP", "VBZ", "MD"} for t in (conjuncts[0], *conjuncts[0].children))):
            return control
        cc, second = coordinators[0], conjuncts[0]
        if not root.i < cc.i < second.i or any(t.idx < cc.idx for t in second.subtree):
            return control
        prefix = sview[:cc.idx].rstrip()
        if prefix.endswith(","):
            prefix = prefix[:-1].rstrip()
        identity = _identity(qview, prefix, qdoc, sdoc, mapping, unit["start"])
        completion = _completion(qdoc, base, page, unit)
        if identity is None or completion is None:
            return control
        qr = account._root(qdoc)
        # Root reporting/conditional context must be present in the exact P;
        # neither leaf extraction nor a dependency relabel licenses cropping.
        source_prefix_root = account._root(base.engine.parse(prefix))
        if source_prefix_root is None or source_prefix_root.lemma_.casefold() != qr.lemma_.casefold():
            return control
        end = mapping[len(prefix) - 1] + 1 if mapping is not None else len(prefix)
        raw_prefix = base.policy.citation(pi, unit["start"], unit["start"] + end)
        subject = account._subject(qr)
        if subject is None:
            subject = next(t for t in qdoc if t.idx == completion["subject"]["start"])
        if (_metadiscourse_holds(base, page, raw_prefix["end"])
                or _tail_holds(base, page, raw_prefix["end"], subject, predicate=qr.lemma_.casefold())
                or account._reporting_tail_holds(base, page, raw_prefix["end"], subject)):
            return control
        repaired = identity["repair"] is not None
        operator = repaired or any(t.tag_ == "MD" for t in qdoc) or qr.lemma_.casefold() in account._REPORTS
        scope = dict(kind="QUERIED_OPERATOR_ONLY" if operator else "SOURCE_ASCRIPTION",
            inner_execution_certified=False, event_join_certified=False, world_truth_certified=False,
            physical_executor_certified=False, canonical_identity_certified=False)
        proof = dict(version=VERSION, type=NORMALIZED_TYPE if repaired else LITERAL_TYPE, scope=scope,
            citation=deepcopy(citation), raw_prefix_citation=raw_prefix,
            query_sha256=digest(base.case["query"]), atom_sha256=digest(atom),
            public_query_spans=deepcopy(atom["query_spans"]), full_source_page_sha256=page["source_sha256"],
            strict_control_sha256=digest(control), identity=identity, completion=completion,
            metadiscourse_evaluation_resource=binding(),
            query_normalization=qnorm, source_normalization=snorm,
            coordinator=account._proof(cc), independent_second_conjunct=account._proof(second),
            full_parent_retained=True, all_first_conjunct_operators_retained=True,
            source_text_modified=False, raw_identity_claimed=not repaired and _normal(atom["text"]) == _normal(raw_prefix["text"]),
            complete_required_account=True,
            offset_basis="NORMALIZED_SOURCE_TOKEN_PROOFS_PLUS_EXACT_RAW_PREFIX_AND_REPAIR_SPANS")
        row = deepcopy(control)
        row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
            source_prefix_account_certificate=proof, strict_prefix_account_control=deepcopy(control),
            support_scope=scope["kind"], queried_account_scope=scope, qualified=True,
            qualified_account="The eligible source ascribes the complete first AND-conjunct with every operator and condition retained. Any recorded common-noun orthographic analysis is not raw identity; no execution, world truth, identity or joins are certified.",
            source_assertion_not_world_truth=True, actual_inner_event_established=False,
            world_truth_certified=False, canonical_identity_certified=False,
            cross_atom_or_event_join_certified=False, event_bindings=[])
        row["checks"] = dict(eligible_source="PASS", full_raw_quote="PASS", public_literal_account="PASS",
            first_top_level_AND="PASS", complete_prefix="PASS", raw_qualifications="PASS",
            inner_execution="NOT_CERTIFIED", world_truth="NOT_CERTIFIED", event_join="NOT_CERTIFIED")
        return row


def replay(matcher, atom, page, unit, control, certificate):
    produced = supplement(matcher, atom, page, unit, control)
    if certificate.get("version") != VERSION or produced.get(PROOF_FIELD) != certificate:
        raise ValueError("Prefix account proof differs from trusted raw producer replay")
    return deepcopy(certificate)
