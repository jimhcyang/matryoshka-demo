"""Pure, source-replayed views of evidence already used by a local decision."""
from collections import defaultdict, deque
from collections.abc import Mapping
from copy import deepcopy
from datetime import date
import re

from matryoshka_demo.io import digest
from matryoshka_demo.contracts import MASK


VERSION = "narrative-selected-evidence-trace/4"
DISPLAY_LINK_VERSION = "narrative-query-source-display-links/1"
REF_FIELDS = ("canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256")
_HANDLING = re.compile(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM\b", re.I)
_DIRECTIONS = {"SUPPORT": "SUPPORT", "COUNTER": "COUNTER", "COUNTEREVIDENCE": "COUNTER",
               "OPPOSED": "COUNTER", "PARTIAL": "PARTIAL", "CONFLICTED": "CONFLICTED"}


def packet_view(packet):
    """Accept saved current/next packets without resolving any external references."""
    if "packet" in packet:
        if packet.get("packet_sha256") != digest(packet["packet"]):
            raise ValueError("Native envelope packet seal changed")
        packet = packet["packet"]
    if packet.get("native_checksum") is not None and packet["native_checksum"] != digest(packet["result"]):
        raise ValueError("Current native result seal changed")
    if packet.get("sha256") is not None and packet["sha256"] != digest({k:v for k,v in packet.items() if k != "sha256"}):
        raise ValueError("Native record seal changed")
    case, plan, result = packet["case"], packet["plan"], packet["result"]
    for value in (packet, plan, result):
        if value.get("query_sha256", digest(case["query"])) != digest(case["query"]):
            raise ValueError("Native query binding changed")
    if result.get("provided_plan_sha256", digest(plan)) != digest(plan):
        raise ValueError("Native plan binding changed")
    retrieval = packet.get("retrieval", result.get("retrieval", {}))
    return case, plan, result, retrieval.get("receipt", retrieval)


def _refs(row):
    values = ([row["citation"]] if "citation" in row else []) + list(row.get("citations", []))
    if "canonical_page_id" in row:
        values.append(row)
    return list({digest({k:r.get(k) for k in REF_FIELDS}):r for r in values}.values())


def decision_items(case, plan, result):
    """Locate authoritative rows only; do not recurse into diagnostics or graphs."""
    items = []
    if case["task"] != "redaction":
        known = {a["id"] for a in plan["atoms"]}
        if len(known) != len(plan["atoms"]) or len(known) > 256:
            raise ValueError("Distinct bounded query atom IDs required")
        for i, atom in enumerate(result.get("atoms", [])):
            if atom["id"] not in known:
                raise ValueError("Decision atom is not in the supplied plan")
            rows = []
            if "evidence" in atom:
                rows = [(r, f"/result/atoms/{i}/evidence/{j}") for j,r in enumerate(atom["evidence"])]
            else:
                for name in ("positive_evidence", "counterevidence", "partial_evidence"):
                    rows.extend((r, f"/result/atoms/{i}/{name}/{j}") for j,r in enumerate(atom.get(name, [])))
            items.append(dict(id=atom["id"], query_atom_id=atom["id"], text=atom["text"],
                required=atom.get("required", True) and atom.get("kind") != "context", status=atom["status"],
                rows=rows, contexts=[], native=atom))
    else:
        seen = set()
        for i, branch in enumerate(result.get("readings", [])):
            rid = branch.get("reading_id", branch.get("reading", {}).get("id"))
            if not rid or rid in seen or len(branch["candidates"]) > 5:
                raise ValueError("Distinct Red readings with at most five saved candidates required")
            seen.add(rid)
            ranks = [c["rank"] for c in branch["candidates"]]
            if ranks != sorted(set(ranks)) or any(type(r) is not int or not 1 <= r <= 5 for r in ranks):
                raise ValueError("Invalid saved candidate order")
            for j, candidate in enumerate(branch["candidates"]):
                base = f"/result/readings/{i}/candidates/{j}"
                gate = candidate.get("local_decision", {})
                rows = [(r, f"{base}/local_decision/requirements/{k}/evidence/{n}")
                        for k,q in enumerate(gate.get("requirements", [])) for n,r in enumerate(q.get("evidence", []))]
                rows.extend((r, f"{base}/evidence/{k}") for k,r in enumerate(candidate.get("evidence", []))
                            if str(r.get("direction", "")).upper() in _DIRECTIONS)
                contexts = []
                for name in ("sources", "evidence", "exploratory_passages"):
                    contexts.extend((r, f"{base}/{name}/{k}") for k,r in enumerate(candidate.get(name, [])))
                items.append(dict(id=rid+"/"+candidate["id"], candidate_id=candidate["id"], reading_id=rid,
                    query_atom_id=None, text=candidate["fill"], required=False, status=gate.get("status", "UNRECORDED"),
                    rows=rows, contexts=contexts, native=candidate))
    if len({i["id"] for i in items}) != len(items):
        raise ValueError("Duplicate decision item identity")
    return items


class SourceReplay:
    """Memory-only exact replay. Other pages may veto, never supply extra proof."""
    def __init__(self, corpus, case, inspected, source_index=None):
        self.corpus, self.case = corpus, case
        self.pages = {p["id"]:p for p in corpus.pages}
        self.positions = {p["id"]:i for i,p in enumerate(corpus.pages)}
        if corpus.corpus != case["corpus"] or len(self.pages) != len(corpus.pages):
            raise ValueError("Corpus or source page identity mismatch")
        if source_index is not None and not isinstance(source_index, Mapping):
            raise ValueError("Pure replay requires an already materialized source-page mapping")
        self.bound = self.pages if source_index is None else source_index
        self.inspected = set(inspected)
        if len(self.inspected) != len(inspected) or not self.inspected.issubset(self.pages):
            raise ValueError("Recorded inspected pool is missing, duplicated or unknown")
        self.node_id_set = frozenset(getattr(corpus, "node_ids", []))
        self.occurrences_by_page = defaultdict(list)
        self.occurrences_by_node = defaultdict(list)
        for occurrence in getattr(corpus, "occurrences", []):
            pid = corpus.pages[occurrence["page_index"]]["id"]
            if pid in self.inspected:
                self.occurrences_by_page[pid].append(occurrence)
                self.occurrences_by_node[occurrence["node_id"]].append(occurrence)
        self.veto = set(getattr(corpus, "excluded_documents", ()))
        if case["corpus"] != "cib":
            for p in list(self.pages.values()) + list(self.bound.values()):
                if _HANDLING.search(p["text"]) or any(_HANDLING.search(str(h)) for h in p.get("handling", [])):
                    self.veto.add(p["document_id"])
            for did, metadata in getattr(corpus, "classification", {}).items():
                if any(_HANDLING.search(str(h)) for h in metadata.get("handling", [])):
                    self.veto.add(did)
        self.graph = None

    def allowed(self, page):
        mask = getattr(self.corpus, "allowed", None)
        return (page["id"] in self.pages and (mask is None or bool(mask[self.positions[page["id"]]]))
            and page.get("permitted") is True and page.get("corpus") == self.case["corpus"]
            and page.get("visibility") in {"earlier", "both"}
            and date.fromisoformat(page["date"]) < date.fromisoformat(self.case["date"])
            and page["document_id"] != self.case["document_id"] and page["document_id"] not in self.veto
            and (self.case["corpus"] == "cib" or page.get("classification") == "CONFIDENTIAL"))

    def quote(self, ref):
        pid = ref.get("canonical_page_id")
        if pid not in self.inspected:
            raise ValueError("Evidence or navigation quote is outside the recorded inspected pool")
        p = self.pages[pid]
        bound = self.bound.get(pid)
        if bound is None or any(bound.get(k) != p.get(k) for k in
                ("id", "text", "document_id", "date", "source_sha256", "corpus", "classification", "permitted", "visibility")):
            raise ValueError("Source index differs from the supplied Corpus")
        a, b = ref.get("start"), ref.get("end")
        if (not self.allowed(p) or digest(p["text"]) != p["source_sha256"]
                or type(a) is not int or type(b) is not int or not 0 <= a < b <= len(p["text"])
                or any(ref.get(k) != value for k,value in (("document_id",p["document_id"]), ("date",p["date"]),
                    ("page_sha256",p["source_sha256"]), ("text",p["text"][a:b])))
                or MASK.search(ref.get("text", ""))):
            raise ValueError("Literal source/cutoff/origin/visibility/classification/handling replay failed")
        return {k:deepcopy(ref[k]) for k in REF_FIELDS}

    def edges(self):
        if self.graph is not None:
            return self.graph
        graph = []
        for edge in getattr(self.corpus, "edge_rows", []):
            page = self.corpus.pages[edge["pi"]]
            if page["id"] not in self.inspected or not self.allowed(page):
                continue
            unit = self.corpus.units[edge["ui"]]
            if unit["pi"] != edge["pi"] or page["text"][unit["start"]:unit["end"]] != unit["text"]:
                raise ValueError("Graph source unit differs from its literal page")
            ref = self.quote(dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
                start=unit["start"], end=unit["end"], text=unit["text"], page_sha256=page["source_sha256"]))
            a,b = self.corpus.node_ids[edge["a"]], self.corpus.node_ids[edge["b"]]
            if a == b:
                continue
            row = dict(source=a, target=b, relation=edge["relation"], source_row_id=edge["source_row_id"],
                citation=ref, kind="SOURCE_ASSERTION", factual_support_implied=False,
                native_source_direction_preserved=True, route_class=edge.get("route_class"))
            row["id"] = "edge_"+digest(row)[:24]
            graph.append(row)
            if len(graph) > 20000:
                raise ValueError("Inspected graph exceeds the bounded presentation edge budget")
        self.graph = sorted(graph, key=lambda e:e["id"])
        return self.graph


def evidence_inventory(items, replay=None):
    inventory = []
    for item in items:
        unique = {}
        for raw,path in item["rows"]:
            direction = _DIRECTIONS.get(str(raw.get("direction", "")).upper())
            if direction is None:
                continue
            refs = _refs(raw)
            if not refs:
                raise ValueError("Signed final match lacks source coordinates")
            refs = [replay.quote(r) if replay else {k:r.get(k) for k in REF_FIELDS} for r in refs]
            identity = digest([item["id"], direction, sorted(digest(r) for r in refs)])
            if identity in unique:
                unique[identity]["recorded_locations"].append(path)
                continue
            row = dict(id="evidence_"+identity[:24], item_id=item["id"], query_atom_id=item["query_atom_id"],
                direction=direction, source_refs=refs, purpose="FINAL_DECISION_EVIDENCE", recorded_locations=[path],
                recorded_match_sha256=digest(raw), source_replayed=replay is not None,
                world_truth_certified=False, independent_sample=False)
            unique[identity] = row
        inventory.extend(unique.values())
        signed_refs = {digest(r) for row in unique.values() for r in row["source_refs"]}
        for raw,path in item["contexts"]:
            for ref in _refs(raw):
                ref = replay.quote(ref) if replay else {k:ref.get(k) for k in REF_FIELDS}
                if digest(ref) in signed_refs:
                    continue
                identity = digest([item["id"], ref, "CONTEXT"])
                if any(r["id"] == "context_"+identity[:24] for r in inventory):
                    continue
                inventory.append(dict(id="context_"+identity[:24], item_id=item["id"], query_atom_id=None,
                    direction="CONTEXT", source_refs=[ref], purpose="CANDIDATE_ORIGINAL_CONTEXT_NOT_ASSERTED_SUPPORT",
                    recorded_locations=[path], recorded_match_sha256=digest(raw), source_replayed=replay is not None,
                    world_truth_certified=False, independent_sample=False))
    if len(inventory) > 10000:
        raise ValueError("Final evidence exceeds the presentation record bound")
    return inventory


def _overlap(a, b):
    return a["canonical_page_id"] == b["canonical_page_id"] and max(a["start"],b["start"]) < min(a["end"],b["end"])


def _preview(text):
    return " ".join(text.split())[:120]


def _display_node(replay, identity, fallback):
    found = []
    for occurrence in replay.occurrences_by_node.get(identity, []):
        page = replay.corpus.pages[occurrence["page_index"]]
        if occurrence["node_id"] != identity or page["id"] not in replay.inspected or not replay.allowed(page):
            continue
        a,b = occurrence["start"],occurrence["end"]
        label = occurrence.get("label","")
        if not label or label != page["text"][a:b] or MASK.search(label):
            continue
        cite = replay.quote(dict(canonical_page_id=page["id"],document_id=page["document_id"],date=page["date"],
            start=a,end=b,text=label,page_sha256=page["source_sha256"]))
        found.append((not _overlap(cite,fallback),len(label),digest(cite),label,cite,occurrence))
    if found:
        _,_,_,label,cite,occurrence = min(found,key=lambda v:v[:3])
        node_type = occurrence.get("entity_type") or getattr(replay.corpus,"nodes",{}).get(identity,{}).get("kind","Semantic")
        label_kind = "VERBATIM_ELIGIBLE_SOURCE_LABEL"
    else:
        cite = replay.quote(fallback)
        label, node_type, label_kind = _preview(cite["text"]), "Source-backed context", "ORIGINAL_SOURCE_QUOTE_PREVIEW"
    member = getattr(replay.corpus,"hierarchy",{}).get(identity,{})
    community = member.get("community_id")
    mother = dict(id="hierarchy:community:"+community,community_id=community,label="Source community",
        type="Community",navigation_only=True,is_evidence=False) if community else None
    return dict(id=identity,label=label,type=node_type,citation=cite,is_graph_node=True,label_kind=label_kind,
        originating_document_id=cite["document_id"],mother_community=mother,
        parent_id=mother["id"] if mother else None,hierarchy_membership_is_evidence=False)


def _recorded_route(replay, receipt, item, ref, max_hops):
    rows = receipt.get("source_edges", [])
    for raw in sorted(rows,key=lambda r:(len(r.get("path_source_row_ids", [r.get("source_row_id")])),digest(r))):
        if not _overlap(raw["citation"], ref):
            continue
        criteria = raw.get("pending_criteria", [])
        if item["query_atom_id"] and item["query_atom_id"] not in criteria:
            continue
        ids = raw.get("path_source_row_ids", [raw["source_row_id"]])
        if not 1 <= len(ids) <= max_hops or len(ids) != len(set(ids)):
            continue
        if ids[-1] != raw["source_row_id"]:
            raise ValueError("Recorded source route does not end at its selected edge")
        if any(not any(r.get("source_row_id") == identity and r["citation"].get("canonical_page_id") in replay.inspected
                       for r in rows) for identity in ids[:-1]):
            # Keep the valid final witness, but never import an off-pool route
            # quote merely to make its presentation path longer.
            continue
        selected = []
        for identity in ids:
            recorded = [r for r in rows if r.get("source_row_id") == identity]
            matches = [e for e in replay.edges() if e["source_row_id"] == identity and any(
                all(r.get(k) == e[k] for k in ("source", "target", "relation")) and replay.quote(r["citation"]) == e["citation"]
                for r in recorded)]
            if len(matches) != 1:
                raise ValueError("Selected recorded graph edge has no unique actual directed source edge")
            selected.append(deepcopy(matches[0]))
        if not _overlap(selected[-1]["citation"], ref):
            raise ValueError("Recorded source route does not reach the decision witness")
        at, seen = None, set()
        for edge in selected:
            if at is not None and at not in {edge["source"],edge["target"]}:
                raise ValueError("Recorded source path is disconnected")
            if at is None:
                first = next(r for r in rows if r.get("source_row_id") == ids[0])
                at = edge["target"] if first.get("lookup_direction") == "INCOMING_LOOKUP" else edge["source"]
            destination = edge["target"] if at == edge["source"] else edge["source"]
            if destination in seen:
                raise ValueError("Recorded source path repeats a state")
            seen.add(at)
            edge.update(traversal_from=at, traversal_to=destination, reverse_lookup=at != edge["source"])
            at = destination
        if raw.get("path_source_row_ids"):
            if not raw.get("seed_citation"):
                raise ValueError("Recorded traversal lacks its original seed source")
            seed = replay.quote(raw["seed_citation"])
            first_node = selected[0]["traversal_from"]
            if not _node_at_ref(replay, first_node, seed):
                raise ValueError("Recorded seed does not own the route's first graph node")
        return selected, "RECORDED_SOURCE_ROUTE" if raw.get("path_source_row_ids") else "RECORDED_RELATION_NOMINATION"
    return [], "DIRECT_SOURCE_HANDOFF"


def _node_at_ref(replay, node, ref):
    for occurrence in replay.occurrences_by_page.get(ref["canonical_page_id"], []):
        page = replay.corpus.pages[occurrence["page_index"]]
        if (occurrence["node_id"] == node and page["id"] == ref["canonical_page_id"]
                and max(occurrence["start"],ref["start"]) < min(occurrence["end"],ref["end"])):
            return True
    for unit in getattr(replay.corpus, "units", []):
        page = replay.corpus.pages[unit["pi"]]
        if (page["id"] == ref["canonical_page_id"] and unit["start"] >= ref["start"] and unit["end"] <= ref["end"]
                and any(replay.corpus.node_ids[n] == node for n in unit.get("nodes", []))):
            return True
    return False


def _source_endpoint(replay, item, ref):
    """An extraction of this selected quote, not an extra retrieval or proof hop."""
    preferred = item["native"].get("node_id")
    choices = []
    for occurrence in replay.occurrences_by_page.get(ref["canonical_page_id"], []):
        page = replay.corpus.pages[occurrence["page_index"]]
        identity = occurrence["node_id"]
        a, b = occurrence["start"], occurrence["end"]
        if (identity not in replay.node_id_set or page["id"] != ref["canonical_page_id"]
                or type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])):
            continue
        label = occurrence.get("label", "")
        if not label or MASK.search(label) or MASK.search(page["text"][a:b]):
            continue
        if "candidate_id" in item:
            # A Red readout may inspect the candidate's saved node, never find
            # a different node by searching for its now-known answer wording.
            if not preferred or identity != preferred:
                continue
        elif not re.search(r"(?<!\w)" + re.escape(label) + r"(?!\w)", item["text"], re.I):
            continue
        entity_type = str(occurrence.get("entity_type", "")).casefold()
        if identity != preferred and entity_type not in {
                "person", "organization", "organisation", "org", "gpe", "loc", "location", "place"}:
            continue
        # Native offsets usually delimit the evidence quote, NOT a name span.
        # Derive only a unique literal label inside that exact owned quotation.
        pattern = r"(?<!\w)" + r"\s+".join(re.escape(w) for w in label.split()) + r"(?!\w)"
        matches = list(re.finditer(pattern, page["text"][a:b], re.I))
        selected_matches = list(re.finditer(pattern, ref["text"], re.I))
        if len(matches) != 1 or len(selected_matches) != 1:
            continue
        start, end = a + matches[0].start(), a + matches[0].end()
        if not ref["start"] <= start < end <= ref["end"]:
            continue
        native_quote = replay.quote(dict(canonical_page_id=page["id"], document_id=page["document_id"],
            date=page["date"], start=a, end=b, text=page["text"][a:b],
            page_sha256=page["source_sha256"]))
        citation = replay.quote(dict(canonical_page_id=page["id"], document_id=page["document_id"],
            date=page["date"], start=start, end=end, text=page["text"][start:end],
            page_sha256=page["source_sha256"]))
        choices.append((identity != preferred, entity_type != "person", -len(label),
            identity, digest(citation), citation, dict(native_quote=native_quote,
                source_row_id=occurrence.get("source_row_id"), stored_label=label,
                source_entity_type=occurrence.get("entity_type"),
                derived_literal_span=[start, end], native_name_span_claimed=False,
                analysis="CASE_AND_WHITESPACE_ONLY_UNIQUE_LITERAL_MATCH")))
    if not choices:
        return _source_contributor_endpoint(replay, ref)
    best = min(choices, key=lambda row: row[:5])
    if len({row[3] for row in choices if row[:3] == best[:3] and row[5] == best[5]}) > 1:
        return None
    _, _, _, identity, _, citation, label_proof = best
    return dict(_display_node(replay, identity, citation), label=citation["text"],
        type=label_proof["source_entity_type"] or "Entity",
        citation=citation, originating_document_id=citation["document_id"],
        label_kind="DERIVED_LITERAL_LABEL_WITHIN_NATIVE_EXTRACTION_QUOTE", source_label_proof=label_proof,
        endpoint_selection="SAVED_CANDIDATE_OR_LITERAL_QUERY_LABEL_IN_SELECTED_QUOTE",
        postrun_provenance_inspection=True, original_traversal_claimed=False,
        identity_or_event_certified=False, factual_support_implied=False)


def _source_contributor_endpoint(replay, ref):
    """Inspect a typed quote-owned extraction, never infer an answer entity."""
    choices = []
    for occurrence in replay.occurrences_by_page.get(ref["canonical_page_id"], []):
        identity = occurrence.get("node_id")
        kind = getattr(replay.corpus, "nodes", {}).get(identity, {}).get("kind")
        row_id = occurrence.get("source_row_id")
        if (identity not in replay.node_id_set or kind not in {"Claim", "Event"}
                or occurrence.get("source_type") != {"Claim": "claims", "Event": "events"}[kind]
                or not isinstance(row_id, str) or not row_id):
            continue
        page = replay.corpus.pages[occurrence["page_index"]]
        a, b = occurrence.get("start"), occurrence.get("end")
        if (page["id"] != ref["canonical_page_id"] or type(a) is not int or type(b) is not int
                or not ref["start"] <= a < b <= ref["end"]):
            continue
        try:
            owned = replay.quote(dict(canonical_page_id=page["id"], document_id=page["document_id"],
                date=page["date"], start=a, end=b, text=page["text"][a:b], page_sha256=page["source_sha256"]))
            edges = [e for e in replay.edges() if identity in {e["source"], e["target"]}
                and isinstance(e["source_row_id"], str) and e["source_row_id"]
                and isinstance(e["relation"], str) and e["relation"]
                and e["source"] in replay.node_id_set and e["target"] in replay.node_id_set
                and e["citation"]["canonical_page_id"] == ref["canonical_page_id"]
                and ref["start"] <= e["citation"]["start"] <= a < b <= e["citation"]["end"] <= ref["end"]]
        except (ValueError, KeyError, TypeError, IndexError):
            continue
        for edge in edges:
            proof = dict(native_quote=owned, source_row_id=row_id,
                occurrence_sha256=digest(occurrence), source_type=occurrence["source_type"],
                bound_node_kind=kind, stored_label=occurrence.get("label"),
                source_entity_type=occurrence.get("entity_type"),
                source_edge_id=edge["id"], source_edge_row_id=edge["source_row_id"],
                source_edge_citation=deepcopy(edge["citation"]), selected_final_citation=deepcopy(ref),
                native_name_span_claimed=False,
                analysis="EXACT_OWNED_OCCURRENCE_AND_INCIDENT_SOURCE_EDGE_WITHIN_SELECTED_CITATION")
            choices.append((owned != ref, -(b-a), identity, row_id, edge["id"], owned, kind, proof))
    if not choices:
        return None
    _, _, identity, _, _, citation, kind, proof = min(choices, key=lambda r:r[:5])
    return dict(_display_node(replay, identity, citation), label=_preview(citation["text"]), type=kind,
        citation=citation, originating_document_id=citation["document_id"],
        label_kind="VERBATIM_SOURCE_CONTRIBUTOR_QUOTE_PREVIEW", source_label_proof=proof,
        endpoint_role="SOURCE_CONTRIBUTOR", endpoint_selection="SELECTED_CITATION_OWNED_TYPED_SOURCE_CONTRIBUTOR",
        postrun_provenance_inspection=True, original_traversal_claimed=False,
        answer_entity_certified=False, identity_or_event_certified=False, factual_support_implied=False)


def _postrun_route(replay, case, plan, receipt, item, ref, max_hops, *, saved_seeds_only=False,
                   source_endpoint=None):
    seeds = set()
    for search in receipt.get("search_queries", []):
        if item["query_atom_id"] and item["query_atom_id"] not in search.get("atom_ids", [search.get("id")]):
            continue
        for seed in search.get("top_nodes", []):
            proof = seed.get("source_proof")
            if proof and proof.get("canonical_page_id") in replay.inspected:
                ref_seed = replay.quote(proof)
                if seed["node_id"] not in replay.node_id_set or not _node_at_ref(replay, seed["node_id"], ref_seed):
                    raise ValueError("Saved seed node lacks its source-owned occurrence")
                seeds.add(seed["node_id"])
    # This is a disclosed postrun literal seed lookup, never identity entailment.
    if not seeds and not saved_seeds_only and source_endpoint is None:
        for occurrence in getattr(replay.corpus, "occurrences", []):
            page = replay.corpus.pages[occurrence["page_index"]]
            label = occurrence.get("label", "")
            if (page["id"] in replay.inspected and replay.allowed(page) and label
                    and label == page["text"][occurrence["start"]:occurrence["end"]]
                    and re.search(r"(?<!\w)"+re.escape(label)+r"(?!\w)", item["text"], re.I)):
                seeds.add(occurrence["node_id"])
    adjacency = defaultdict(list)
    goals = {source_endpoint["id"]} if source_endpoint is not None else set()
    for edge in replay.edges():
        for a,b in ((edge["source"],edge["target"]), (edge["target"],edge["source"])):
            adjacency[a].append((b,edge))
        if source_endpoint is None and _overlap(edge["citation"], ref):
            goals.update((edge["source"],edge["target"]))
    if seeds & goals:
        return []
    agenda = deque((n, (), (n,)) for n in sorted(seeds))
    visited = set(seeds)
    examined = 0
    while agenda and examined < 4096:
        node,path,states = agenda.popleft()
        if len(path) >= min(max_hops, 3):
            continue
        for target,edge in adjacency[node]:
            examined += 1
            if target in states:
                continue
            hop = dict(deepcopy(edge), traversal_from=node, traversal_to=target,
                       reverse_lookup=node != edge["source"])
            route = path + (hop,)
            if target in goals:
                return list(route)
            if target not in visited:
                visited.add(target)
                agenda.append((target,route,states+(target,)))
    return []


def build_trace(corpus, case, plan, result, retrieval, source_index=None, *, max_paths=24,
                max_hops=3, postrun_graph=False):
    """Select final witnesses, not arbitrary branches or PPR contributors."""
    if (type(max_paths) is not int or not 1 <= max_paths <= 256 or type(max_hops) is not int
            or not 0 <= max_hops <= 6 or type(postrun_graph) is not bool):
        raise ValueError("Invalid finite presentation bounds")
    live = retrieval
    receipt = retrieval.get("receipt", retrieval)
    packet = dict(case=case, plan=plan, result=result, retrieval=receipt)
    packet_view(packet)
    if receipt.get("query_sha256", digest(case["query"])) != digest(case["query"]):
        raise ValueError("Retrieval query binding changed")
    inspected = result.get("inspected_page_ids",live.get("inspected_page_ids"))
    if inspected is None:
        raise ValueError("An explicit recorded inspected-page pool is required")
    if "inspected_page_ids" in result and "inspected_page_ids" in live and result["inspected_page_ids"] != live["inspected_page_ids"]:
        raise ValueError("Conflicting explicit inspected-page pools")
    packet["inspected_page_ids"] = list(inspected)
    if source_index is None and live.get("source_policy") is not None:
        source_index = live["source_policy"].bound_pages
    replay = SourceReplay(corpus, case, inspected, source_index)
    items = decision_items(case, plan, result)
    inventory = evidence_inventory(items, replay)
    by_item = {i["id"]:i for i in items}
    proposals = [(row, ref) for row in inventory for ref in row["source_refs"]]
    # One witness per item/direction/document family before repeated excerpts.
    families, deferred = {}, []
    for row,ref in proposals:
        key = row["item_id"], row["direction"], ref["document_id"]
        if key not in families:
            families[key] = (row,ref)
        else:
            deferred.append((row,ref))
    grouped = defaultdict(deque)
    for row,ref in families.values():
        grouped[row["item_id"]].append((row,ref))
    diverse = []
    while any(grouped.values()):
        for item in items:
            if grouped[item["id"]]:
                diverse.append(grouped[item["id"]].popleft())
    selected = (diverse + deferred)[:max_paths]
    steps, paths, roots = [], [], {}

    def step(label, kind, item, **extra):
        value = dict(label=label, kind=kind, query_atom_id=item["query_atom_id"], nodes=[], edges=[],
            display_edges=[],source_refs=[], accepted_evidence_ids=[], candidate_updates=[])
        value.update(extra)
        value["id"] = "step_"+digest([len(steps), value])[:24]
        steps.append(value)
        return value["id"]

    for item in items:
        query_label = item["text"] if item["query_atom_id"] else case["query"]
        query_id = "query:"+item["id"]
        roots[item["id"]] = step(query_label, "QUERY_ATOM" if item["query_atom_id"] else "READING_CANDIDATE", item,
            nodes=[dict(id=query_id,label=query_label,type="query",is_graph_node=False)],
            native_status=item["status"], required=item["required"], missing_is_opposition=False)
    for row,ref in selected:
        item = by_item[row["item_id"]]
        source_endpoint = _source_endpoint(replay, item, ref)
        accepted = [row["id"]] if row["purpose"] == "FINAL_DECISION_EVIDENCE" else []
        passage = dict(id="passage_"+digest(ref)[:24],label=_preview(ref["text"]),type="source_passage",
            is_graph_node=False,citation=ref,originating_document_id=ref["document_id"])
        display_edge = dict(id="lookup_"+digest([item["id"],row["id"],ref])[:24],
            source="query:"+item["id"],target=passage["id"],kind="QUERY_SOURCE_LOOKUP",
            version=DISPLAY_LINK_VERSION,is_graph_edge=False,historical_relation_certified=False,
            meaning="Recorded query-to-source match handoff, not a KG relation",source_refs=[ref])
        chain = [roots[item["id"]], step("Recorded "+row["direction"].lower()+" match", "RECORDED_MATCH", item,
            nodes=[passage],display_edges=[display_edge],
            recorded_locations=row["recorded_locations"], recorded_match_sha256=row["recorded_match_sha256"],
            accepted_evidence_ids=accepted, source_refs=[ref])]
        edges,mode = _recorded_route(replay, receipt, item, ref, max_hops) if max_hops else ([], "DIRECT_SOURCE_HANDOFF")
        if not edges and postrun_graph and max_hops:
            # Red fills and original context must never seed an answer-led walk.
            edges = _postrun_route(replay, case, plan, receipt, item, ref, max_hops,
                saved_seeds_only=not accepted or item["query_atom_id"] is None,
                source_endpoint=source_endpoint)
            if edges:
                mode = "POSTRUN_GRAPH_VIEW"
        for edge in edges:
            chain.append(step(edge["relation"], "SOURCE_GRAPH_NAVIGATION", item,
                nodes=[_display_node(replay,n,edge["citation"]) for n in (edge["source"],edge["target"])], edges=[edge],
                source_refs=[edge["citation"]], route_mode=mode, factual_support_implied=False,
                original_traversal_claimed=mode == "RECORDED_SOURCE_ROUTE"))
        updates = [dict(candidate_id=item["candidate_id"], reading_id=item["reading_id"],
            native_status=item["status"], direction=row["direction"], source_purpose=row["purpose"])] if "candidate_id" in item else []
        chain.append(step("Read the decision witness" if accepted else "Read original candidate context", "SOURCE_READOUT", item,
            nodes=[dict(passage,type="source_readout",outside_kg=True)],
            source_refs=[ref], accepted_evidence_ids=accepted, candidate_updates=updates, direction=row["direction"],
            purpose=row["purpose"], route_mode=mode))
        path_refs = list({digest(r):r for r in [*[e["citation"] for e in edges],ref]}.values())
        paths.append(dict(id="path_"+digest([item["id"],row["id"],ref])[:24], candidate_or_atom_id=item["id"],
            query_atom_id=item["query_atom_id"], steps=chain, source_refs=path_refs, decision_source_refs=[ref], accepted_evidence_ids=accepted,
            endpoint_kind="DECISION_EVIDENCE" if accepted else "CANDIDATE_SOURCE_CONTEXT", route_mode=mode,
            graph_hops=len(edges), original_traversal_claimed=mode == "RECORDED_SOURCE_ROUTE",
            direction=row["direction"], distinct_document_family=ref["document_id"],
            source_endpoint=source_endpoint))
    from .scores import build_scorecards
    value = dict(version=VERSION, case=deepcopy(case), inspected_page_ids=list(inspected), case_id=case["case_id"], task="mosaic" if case["task"] == "reconstruction" else case["task"],
        native_wire_task=case["task"], input_sha256=digest(packet), corpus_binding_sha256=digest(getattr(corpus,"binding",{})),
        native_status=result.get("status"), steps=steps, paths=paths, evidence_inventory=inventory,
        scorecards=build_scorecards(dict(packet,retrieval=live), corpus, source_index),
        selection=dict(max_paths=max_paths, max_hops=max_hops, available_endpoints=len(proposals), displayed_paths=len(paths),
            omitted_endpoints=len(proposals)-len(paths), rule="FINAL_MATCHES_ONLY; DISTINCT_ITEM_DIRECTION_DOCUMENT_THEN_REPEATED_EXCERPTS",
            outcome_informed_presentation=True, full_evidence_retained=True, original_chronology_not_reconstructed=True),
        postrun_graph_enabled=postrun_graph, community_membership_is_evidence=False, ppr_used=False,
        display_link_version=DISPLAY_LINK_VERSION,
        route_scope="INSPECTED_POOL_ONLY; INCOMPLETE_OR_OFFPOOL_RECORDED_CHAINS_USE_DIRECT_READOUT",
        new_evidence_fetched=False, native_decisions_or_ranks_modified=False, api_calls=0)
    value["sha256"] = digest(value)
    return value


def _guide_graph_nodes(corpus, nodes):
    """Use bound graph kinds at the map boundary, keeping extraction subtypes."""
    result = deepcopy(nodes)
    for node in result:
        kind = getattr(corpus, "nodes", {}).get(node["id"], {}).get("kind")
        if kind in {"Entity", "Claim", "Event"}:
            node["source_extraction_type"] = node.get("type")
            node["type"] = kind
            node["graph_kind_authority"] = "BOUND_CORPUS_NODE_KIND"
    return result


def _guide_route_metadata(trace, path, by_id):
    """Reject contradictory display provenance; never upgrade a route's history."""
    mode = path.get("route_mode")
    modes = {"DIRECT_SOURCE_HANDOFF", "POSTRUN_GRAPH_VIEW", "RECORDED_SOURCE_ROUTE", "RECORDED_RELATION_NOMINATION"}
    hops = path.get("graph_hops")
    original = mode == "RECORDED_SOURCE_ROUTE"
    maximum = trace.get("selection", {}).get("max_hops")
    if (not isinstance(mode, str) or mode not in modes or type(hops) is not int or type(maximum) is not int
            or not 0 <= hops <= maximum <= 6
            or type(path.get("original_traversal_claimed")) is not bool
            or path["original_traversal_claimed"] != original
            or (hops == 0) != (mode == "DIRECT_SOURCE_HANDOFF")
            or type(trace.get("postrun_graph_enabled")) is not bool
            or mode == "POSTRUN_GRAPH_VIEW" and (not trace["postrun_graph_enabled"] or hops > 3)):
        raise ValueError("Contradictory trace route provenance metadata for actual owned extraction")
    ids = path.get("steps")
    if (not isinstance(ids, list) or not ids or not all(isinstance(s, str) for s in ids)
            or len(ids) != len(set(ids)) or any(s not in by_id for s in ids)):
        raise ValueError("Invalid trace route step metadata")
    counted = 0
    for identity in ids:
        step = by_id[identity]
        edges = step.get("edges")
        navigation = step.get("kind") == "SOURCE_GRAPH_NAVIGATION"
        if (not isinstance(edges, list) or bool(edges) != navigation
                or "route_mode" in step and step["route_mode"] != mode
                or "original_traversal_claimed" in step and (type(step["original_traversal_claimed"]) is not bool
                    or step["original_traversal_claimed"] != original)
                or navigation and (step.get("route_mode") != mode
                    or step.get("original_traversal_claimed") is not original
                    or step.get("factual_support_implied") is not False)):
            raise ValueError("Contradictory trace navigation provenance metadata")
        counted += len(edges)
    if counted != hops:
        raise ValueError("Trace route/navigation hop metadata differs")


def guide_packet(trace, path_or_candidate_id, context):
    """Adapt a verified trace path to the existing KG guide, without fake readout hops."""
    if trace.get("sha256") != digest({k:v for k,v in trace.items() if k != "sha256"}):
        raise ValueError("Narrative trace seal changed")
    get = lambda name: context.get(name) if isinstance(context, Mapping) else getattr(context,name,None)
    corpus,registry,index_ref = get("corpus"),get("registry"),get("index_ref")
    case = trace["case"]
    if (corpus is None or registry is None or corpus.corpus != case["corpus"]
            or digest(getattr(corpus,"binding",{})) != trace["corpus_binding_sha256"]):
        raise ValueError("Guide context differs from the exact trace resource")
    if registry.get("sha256") != digest({k:v for k,v in registry.items() if k != "sha256"}):
        raise ValueError("Guide registry seal changed")
    bound = registry["corpora"][case["corpus"]]
    if corpus.binding != bound.get("incumbent_binding",bound):
        raise ValueError("Guide Corpus does not bind the selected registry")
    exact = [p for p in trace["paths"] if p["id"] == path_or_candidate_id]
    matches = exact or [p for p in trace["paths"] if p["candidate_or_atom_id"] == path_or_candidate_id
        or p["candidate_or_atom_id"].rsplit("/",1)[-1] == path_or_candidate_id]
    if not matches:
        raise ValueError("Unknown trace path or candidate ID")
    path = min(matches,key=lambda p:(not bool(p["graph_hops"]),p["graph_hops"],p["id"]))
    by_id = {s["id"]:s for s in trace["steps"]}
    if len(by_id) != len(trace["steps"]):
        raise ValueError("Duplicate trace step identity")
    _guide_route_metadata(trace, path, by_id)
    source_index = get("source_index")
    replay = SourceReplay(corpus,case,trace["inspected_page_ids"],source_index if isinstance(source_index,Mapping) else None)
    refs = [replay.quote(r) for r in path["decision_source_refs"]]
    packet = dict(version="narrative-current-guide-adapter/4",case_id=case["case_id"],corpus=case["corpus"],
        graph_binding=deepcopy(bound),registry_sha256=registry["sha256"],
        scope=dict(strictly_before=case["date"],whole_origin_excluded=case["document_id"],binding=deepcopy(bound)),
        candidate=dict(id=path["candidate_or_atom_id"],fill=by_id[path["steps"][0]]["label"],sources=refs),
        trace_sha256=trace["sha256"],path_id=path["id"],postrun_view=path["route_mode"] == "POSTRUN_GRAPH_VIEW",
        original_traversal_claimed=path["original_traversal_claimed"],source_readout=dict(source_refs=refs,
            endpoint_kind=path["endpoint_kind"],direction=path["direction"],outside_kg=True),
        factual_support_from_guide=False,api_calls=0)
    if index_ref is not None:
        packet["index_ref"] = deepcopy(index_ref)
        if "source_binding_sha256" in index_ref:
            packet["source_binding_sha256"] = index_ref["source_binding_sha256"]
    endpoint = path.get("source_endpoint")
    if endpoint is not None:
        root = by_id[path["steps"][0]]
        item = dict(text=root["label"], native={})
        if root["kind"] == "READING_CANDIDATE":
            item.update(candidate_id=path["candidate_or_atom_id"], native=dict(node_id=endpoint.get("id")))
        verified = ([_source_contributor_endpoint(replay, ref) for ref in refs]
            if endpoint.get("endpoint_role") == "SOURCE_CONTRIBUTOR" else
            [_source_endpoint(replay, item, ref) for ref in refs])
        if not any(value == endpoint for value in verified):
            raise ValueError("Source endpoint differs from its actual owned extraction")
        if endpoint.get("endpoint_role") == "SOURCE_CONTRIBUTOR":
            packet.update(source_contributor_inspection=True, selected_source_endpoint=deepcopy(endpoint))
    hops,states = [], []
    actual = {e["id"]:e for e in replay.edges()} if path["graph_hops"] else {}
    for step_id in path["steps"]:
        for edge in by_id[step_id]["edges"]:
            native = actual.get(edge["id"])
            if native is None or any(native[k] != edge[k] for k in ("source","target","relation","source_row_id","citation")):
                raise ValueError("Guide edge is not the trace's actual bound source edge")
            a,b = edge["traversal_from"],edge["traversal_to"]
            if {a,b} != {edge["source"],edge["target"]} or states and states[-1] != a:
                raise ValueError("Guide graph chain is disconnected")
            if not states:
                states.append(a)
            states.append(b)
            hops.append(dict(source=a,target=b,kind="SOURCE",relation=edge["relation"],
                source_row_id=edge["source_row_id"],citations=[edge["citation"]],
                native_source=edge["source"],native_target=edge["target"],
                reverse_lookup=a != edge["source"],historical_relation_certified=False))
    if not hops:
        if endpoint is not None:
            if path["graph_hops"] != 0 or path["original_traversal_claimed"]:
                raise ValueError("Source endpoint differs from its actual owned extraction")
            packet.update(status="SOURCE_ENDPOINT_INSPECTION",source_endpoint_inspection_only=True,
                retrieval_route_certified=False,graph_hops=0,graph_guide_available=True,
                postrun_view=True,
                route=dict(nodes=_guide_graph_nodes(corpus, [endpoint]),hops=[],route_kind="SOURCE_ENDPOINT_INSPECTION",
                    citations=deepcopy(refs),source_readout_outside_kg=True,factual_support_implied=False))
            return packet
        packet.update(status="DIRECT_SOURCE_READOUT_ONLY",graph_guide_available=False,route=None,
            reason="No real graph route was saved for this source handoff; do not call the KG guide.")
        return packet
    if len(hops) != path["graph_hops"] or len(states) != len(set(states)):
        raise ValueError("Guide path count or simple route differs")
    if path["route_mode"] == "POSTRUN_GRAPH_VIEW" and endpoint is not None and states[-1] != endpoint["id"]:
        raise ValueError("Postrun graph route does not reach the selected source endpoint")
    nodes = []
    for identity in states:
        if identity not in corpus.node_ids:
            raise ValueError("Guide endpoint is not a real bound KG node")
        node_ref = next(e["citation"] for e in actual.values() if identity in {e["source"],e["target"]})
        nodes.append(deepcopy(endpoint) if endpoint is not None and identity == endpoint["id"]
                     else _display_node(replay,identity,node_ref))
    packet.update(status="READY",graph_guide_available=True,route=dict(nodes=_guide_graph_nodes(corpus, nodes),hops=hops,
        route_kind=path["route_mode"],source_readout_outside_kg=True,factual_support_implied=False))
    return packet
