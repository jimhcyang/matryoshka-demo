"""Narrow public-query dependency repair; no source or factual inference."""
from matryoshka_demo.io import digest

VERSION = "public-finite-amod-clause-scope/1"
_SUBJECTS = {"nsubj", "nsubjpass", "csubj", "csubjpass"}


def _token(token):
    return dict(text=token.text, start=token.idx, end=token.idx + len(token),
        dependency=token.dep_, head_start=token.head.idx, pos=token.pos_, tag=token.tag_)


def repair_doc(original):
    """Repair only an overt VBD with its own adjacent sentence-initial subject."""
    doc = original.copy()
    candidates = []
    for verb in doc:
        patient = verb.head
        subjects = [token for token in verb.children if token.dep_ == "nsubj"]
        if (verb.pos_ != "VERB" or verb.tag_ != "VBD" or verb.dep_ != "amod"
                or patient.pos_ not in {"NOUN", "PROPN"} or patient.i != verb.i + 1
                or len(subjects) != 1):
            continue
        subject = subjects[0]
        prefix = [token for token in doc[verb.sent.start:verb.i] if not token.is_space]
        subject_tokens = [token for token in subject.subtree if not token.is_space]
        if (prefix != subject_tokens or subject.right_edge.i != verb.i - 1
                or any(token.pos_ in {"VERB", "AUX", "PRON"} for token in subject_tokens)):
            continue
        if patient.dep_ == "ROOT":
            candidates.append((verb, patient, None, None, None))
            continue
        right = patient.head
        if (patient.dep_ != "nsubj" or right.dep_ != "ROOT" or right.pos_ not in {"VERB", "AUX"}
                or not any(token.tag_ in {"VBD", "VBP", "VBZ", "MD"} for token in (right, *right.children))):
            continue
        right_subjects = [token for token in right.children if token.dep_ in _SUBJECTS and token != patient]
        separators = [token for token in patient.children if token.dep_ == "cc" and token.lower_ == "and"
            and token.i == patient.right_edge.i and token.i > patient.i
            and doc[token.i - 1].text == ","]
        if len(right_subjects) != 1 or len(separators) != 1:
            continue
        separator, right_subject = separators[0], right_subjects[0]
        if (right_subject.left_edge.i != separator.i + 1 or right_subject.right_edge.i >= right.i
                or any(token.pos_ in {"VERB", "AUX"} for token in right_subject.subtree)):
            continue
        candidates.append((verb, patient, right, separator, doc[separator.i - 1]))
    if len(candidates) != 1:
        return doc, []
    verb, patient, right, separator, comma = candidates[0]
    moved = [token for token in (verb, patient, right, separator, comma) if token is not None]
    before = [_token(token) for token in moved]
    verb.head, verb.dep_ = verb, "ROOT"
    patient.head, patient.dep_ = verb, "dobj"
    if right is not None:
        right.head, right.dep_ = verb, "conj"
        separator.head = verb
        comma.head = verb
    if (doc.text != original.text or [(t.text, t.idx, t.lemma_, t.tag_, t.pos_) for t in doc]
            != [(t.text, t.idx, t.lemma_, t.tag_, t.pos_) for t in original]):
        raise ValueError("Query syntax repair changed lexical content or coordinates")
    return doc, [dict(version=VERSION,
        kind="OVERT_PAST_VERB_OWN_SUBJECT_MISTAGGED_AS_NOMINAL_MODIFIER",
        before=before, after=[_token(token) for token in moved], text_sha256=digest(doc.text),
        separate_finite_and_clause=right is not None, source_or_world_coreference=False,
        query_characters_or_lexical_tags_modified=False, tokens_deleted=False,
        grammar_inference_not_factual_support=True)]


def parse(text):
    from matryoshka_next.readings import _model
    return repair_doc(_model()(text))
