"""Source-bound narrative clause ascriptions, not historical entailment.

Resignation may resolve a single source-owned office ellipsis. A completed
statement may realize 'stated', but necessity of making it never proves that it
was made. All certificates retain the office-departure reading, raw operators,
source policy, and the distinction between utterance and content truth.
"""
from copy import deepcopy
from datetime import datetime
from functools import lru_cache
import re

from matryoshka_current.proposition_matching import _event_dates
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import qualifiers

VERSION = "source-bound-clause-ascription/1"
_SUBJECT = {"nsubj", "nsubjpass", "nsubj:pass"}
_NAME = {"compound", "flat", "name"}
_UNSAFE = {"not", "never", "no", "neither", "nor", "or", "if", "unless", "whether",
           "allegedly", "reportedly", "apparently", "almost", "nearly", "perhaps", "possibly"}
_RELATIVE = {"yesterday", "today", "tomorrow", "now", "recently", "ago", "last", "next"}


def _lemma(token):
    return token.lemma_.casefold()


def _proof(token):
    return dict(start=token.idx, end=token.idx + len(token), text=token.text,
                lemma=_lemma(token), dependency=token.dep_)


def _nominal(token):
    tokens = [t for t in token.subtree if not t.is_space and not t.is_punct
              and not (t.dep_ == "det" and _lemma(t) == "the")]
    if any(t.dep_ not in {"compound", "amod", "poss", "case", token.dep_} for t in tokens):
        return None
    return tuple(_lemma(t) for t in tokens)


def _name_tokens(head):
    if head.pos_ != "PROPN":
        return []
    pending, tokens = [head], []
    while pending:
        token = pending.pop()
        tokens.append(token)
        for child in token.children:
            if child.dep_ in _NAME and child.pos_ == "PROPN":
                pending.append(child)
            elif child.dep_ not in {"appos", "punct"}:
                return []
    return sorted(tokens, key=lambda t: t.i)


def _subject(token):
    values = [c for c in token.children if c.dep_ in _SUBJECT]
    return values[0] if len(values) == 1 else None


def _objects(token, prep):
    return [obj for p in token.children if p.dep_ == "prep" and _lemma(p) == prep
            for obj in p.children if obj.dep_ == "pobj"]


def _actor(wanted, offered, doc):
    qt, st = _name_tokens(wanted), _name_tokens(offered)
    q, s = tuple(_lemma(t) for t in qt), tuple(_lemma(t) for t in st)
    if not q or not s:
        return None
    candidates = {tuple(_lemma(c) for c in _name_tokens(t)) for t in doc
                  if t.pos_ == "PROPN" and _lemma(t) == q[-1] and t.dep_ not in _NAME | {"poss"}}
    full_names = {value for value in candidates if len(value) > 1}
    if len(q) == 1 and len(full_names) > 1:
        return None
    if q == s:
        kind = "LITERAL_ACTOR_NAME"
    elif len(q) == 1 and len(s) > 1 and q[0] == s[-1] and full_names == {s}:
        kind = "UNIQUE_CLAUSE_LOCAL_SURNAME_EXTENSION"
    else:
        return None
    return dict(kind=kind, query_proofs=[_proof(t) for t in qt], source_proofs=[_proof(t) for t in st],
                canonical_identity_certified=False, global_alias_created=False)


@lru_cache(maxsize=128)
def _office_class(word):
    """Existing WordNet role classes, never case names or a learned answer list."""
    from matryoshka_demo.roles import lexicon, binding
    try:
        for synset in lexicon().synsets(word, pos="n"):
            if synset.lexname() != "noun.person":
                continue
            for node in [synset, *synset.closure(lambda s: s.hypernyms())]:
                if node.name() in {"leader.n.01", "member.n.01", "official.n.01"}:
                    return dict(source_concept=synset.name(), office_class=node.name(), resource=binding())
    except LookupError:
        pass
    return None


def _dates(token, raw):
    values = []
    for row in _event_dates(token, raw):
        literal = " ".join(row["text"].replace(",", "").split())
        day = None
        for form in ("%Y-%m-%d", "%B %d %Y", "%d %B %Y"):
            try:
                day = datetime.strptime(literal.title(), form).date().isoformat()
                break
            except ValueError:
                pass
        values.append((day, row))
    return values


def _clock(query, source, query_doc, source_doc):
    qdates, sdates = _dates(query, query_doc.text), _dates(source, source_doc.text)
    if any(_lemma(t) in _RELATIVE for t in query.subtree):
        return None
    if qdates and (any(day is None for day, _ in qdates) or
                   [d for d, _ in qdates] != [d for d, _ in sdates]):
        return None
    return dict(kind="EXACT_EXPLICIT_DAY" if qdates else "UNDATED_PAST_SOURCE_ATTESTATION",
                query_date_proofs=[row for _, row in qdates], source_date_proofs=[row for _, row in sdates],
                source_relative_times=[_proof(t) for t in source.subtree if _lemma(t) in _RELATIVE],
                publication_date_used_as_event_time=False, continued_tenure_certified=False)


def _utterance(token):
    if _lemma(token) == "state":
        contents = [c for c in token.children if c.dep_ == "ccomp"]
        return contents[0] if len(contents) == 1 else None
    if _lemma(token) == "make":
        objects = [c for c in token.children if c.dep_ in {"dobj", "obj"}]
        if len(objects) != 1 or _lemma(objects[0]) != "statement":
            return None
        statement = objects[0]
        if any(c.dep_ not in {"det", "amod", "acl", "punct"} or
               c.dep_ == "amod" and _lemma(c) != "write" or
               c.dep_ == "det" and _lemma(c) not in {"a", "the"} for c in statement.children):
            return None
        contents = [c for c in statement.children if c.dep_ == "acl"]
        return contents[0] if len(contents) == 1 else None
    return None


def _content(token):
    owner = _subject(token)
    properties = [c for c in token.children if c.dep_ == "acomp"]
    if _lemma(token) != "be" or token.tag_ != "VBD" or owner is None or len(properties) != 1:
        return None
    prop = properties[0]
    if any(not c.is_punct and not c.is_space for c in prop.children):
        return None
    if any(c.dep_ not in _SUBJECT | {"acomp", "mark", "punct"} for c in token.children):
        return None
    return owner, prop


def _query(doc):
    roots = [t for t in doc if t.dep_ == "ROOT" and not t.is_space]
    if len(roots) != 1:
        return None
    root, actor = roots[0], _subject(roots[0])
    if root.tag_ != "VBD" or actor is None or not _name_tokens(actor):
        return None
    if any(t not in _name_tokens(actor) and not t.is_punct and not t.is_space for t in actor.subtree):
        return None
    if any(_lemma(t) in _UNSAFE or t.tag_ == "MD" or t.is_quote or t.text == "?" for t in doc):
        return None
    allowed = {t.i for t in actor.subtree} | {root.i}
    for _, row in _dates(root, doc.text):
        allowed.update(t.i for t in doc[row["attachment_child"]].subtree)
    objects = _objects(root, "from")
    if _lemma(root) == "resign" and len(objects) == 1 and _nominal(objects[0]):
        allowed.update(t.i for t in objects[0].head.subtree)
        spec = dict(kind="resignation", root=root, actor=actor, body=objects[0])
    elif _lemma(root) == "state" and (utterance := _utterance(root)) is not None and (content := _content(utterance)):
        allowed.update(t.i for t in utterance.subtree)
        spec = dict(kind="utterance", root=root, actor=actor, body=content[0], property=content[1])
    else:
        return None
    if any(t.i not in allowed and not t.is_punct and not t.is_space for t in doc):
        return None
    return spec


def _operator(action):
    if action.dep_ == "xcomp" and _lemma(action.head) == "have" and any(
            c.dep_ == "aux" and _lemma(c) == "to" for c in action.children):
        return "OBLIGATION_NOT_COMPLETION", action.head
    if action.dep_ != "ROOT":
        return "EMBEDDED_OR_NONMATRIX_ACTION_NOT_ASSERTED", action
    q = qualifiers(action)
    if (action.tag_ != "VBD" or any(c.dep_ in {"aux", "auxpass", "neg", "advmod"} for c in action.children)
            or any(q.get(k) for k in ("negated", "modality", "conditional", "scope", "attribution",
                                     "epistemic_absence", "question", "unresolved"))):
        return "ACTION_CLOCK_ASPECT_OR_QUALIFICATION_NOT_LICENSED", action
    return "COMPLETED_PAST_SOURCE_ASSERTION", action


def _office(body, action, actor):
    direct = _objects(action, "from")
    if direct:
        if len(direct) != 1 or _nominal(direct[0]) != _nominal(body):
            return None
        return dict(kind="EXPLICIT_DEPARTURE_BODY", source_body=_proof(direct[0]))
    if any(c.dep_ == "prep" and _lemma(c) in {"as", "to"} for c in action.children):
        return None
    offices = [c for c in actor.children if c.dep_ == "appos"]
    if len(offices) != 1:
        return None
    role = offices[0]
    if (role.pos_ != "NOUN" or role.tag_ != "NN" or
            any(c.dep_ not in {"det", "prep", "punct"} for c in role.children)):
        return None
    preps = [c for c in role.children if c.dep_ == "prep"]
    bodies = _objects(role, "of")
    lexical = _office_class(_lemma(role))
    if len(preps) != 1 or len(bodies) != 1 or _nominal(bodies[0]) != _nominal(body) or not lexical:
        return None
    return dict(kind="UNIQUE_SOURCE_OWNED_OFFICE_DEPARTURE", source_role=_proof(role),
                source_body=_proof(bodies[0]), role_class=deepcopy(lexical),
                interpretation="departure from an office in the body, not cessation of all membership")


def _body(wanted, offered, doc):
    q, s = _nominal(wanted), _nominal(offered)
    if q and q == s:
        return dict(kind="LITERAL_CONTENT_SUBJECT", source_subject=_proof(offered))
    if not q or s != (_lemma(offered),) or q[-1] != _lemma(offered) or not any(
            c.dep_ == "det" and _lemma(c) == "the" for c in offered.children):
        return None
    preceding = [sent for sent in doc.sents if sent.end <= offered.sent.start]
    if not preceding:
        return None
    previous = preceding[-1]
    visible = [t for t in previous if not t.is_space]
    if not visible or re.search(r"\n[ \t\r]*\n", doc.text[visible[-1].idx + len(visible[-1]):offered.sent.start_char]):
        return None
    candidates = [t for t in previous if _lemma(t) == _lemma(offered)
                  and t.dep_ in _SUBJECT | {"pobj", "dobj", "obj"}]
    if not candidates or {_nominal(t) for t in candidates} != {q}:
        return None
    if any(_lemma(t) == _lemma(offered) for t in doc[previous.end:offered.i]):
        return None
    return dict(kind="UNIQUE_IMMEDIATELY_PRECEDING_DEFINITE_HEAD", source_subject=_proof(offered),
                antecedents=[_proof(t) for t in candidates], cross_document_join=False,
                canonical_identity_certified=False)


def _adjacent_unit(matcher, page, unit):
    doc = matcher.engine.parse(page["text"][:unit["end"]])
    previous = [s for s in doc.sents if s.end_char <= unit["start"]]
    if not previous:
        return unit
    sentence = previous[-1]
    visible = [t for t in sentence if not t.is_space]
    if not visible:
        return unit
    end = visible[-1].idx + len(visible[-1])
    start = sentence.start_char + re.match(r"\s*(?:\d{1,3}\.\s+)?", sentence.text).end()
    gap = page["text"][end:unit["start"]]
    if gap.strip() or re.search(r"\n[ \t\r]*\n", gap) or unit["end"] - start > 2048:
        return unit
    return dict(start=start, end=unit["end"], text=page["text"][start:unit["end"]])


def evaluate(matcher, atom, page, unit, control):
    """Only called after MatcherCase's public-query/full-index source replay.

    Nonapplicable queries and ordinary baseline certificates stay untouched.
    This channel creates no signed opposition, event join or membership proof.
    """
    result = dict(version=VERSION, applicable=False, direction="UNRESOLVED", reasons=[],
                  observations=[], certificate=None, citation=deepcopy(control["citation"]),
                  api_calls=0, source_policy_replayed=True, source_words_modified=False,
                  native_result_modified=False, canonical_identity_certified=False,
                  world_truth_certified=False, embedded_content_truth_certified=False,
                  membership_cessation_certified=False, publication_date_used_as_event_time=False)
    with offline():
        cached_query = matcher.query_cache.get(digest(atom))
        query_doc = cached_query[2] if cached_query else matcher.engine.parse(atom["text"])
        spec = _query(query_doc) if atom.get("kind", "proposition") == "proposition" else None
        if spec is None:
            return result
        result["applicable"] = True
        from matryoshka_next.decisions import _public_scope
        public_text = " ".join(s["text"] for s in atom.get("query_spans", []))
        if _public_scope(atom, matcher.case) or re.search(r"\b(?:membership|members?)\b", public_text, re.I):
            result["reasons"] = ["PUBLIC_QUALIFICATION_OR_MEMBERSHIP_READING_NOT_LICENSED"]
            return result
        text = unit.get("text", unit.get("quote"))
        # Discovery-only screens avoid parsing many distinct page prefixes.
        pattern = r"\b(?:state[ds]?|stating|statement)\b" if spec["kind"] == "utterance" else r"\bre(?:-\s*)?sign(?:ed|s|ing)?\b"
        if not re.search(pattern, text, re.I):
            return result
        key = (page["id"], page["source_sha256"], unit["start"], unit["end"])
        cached_source = matcher.unit_cache.get(key)
        doc = cached_source[1] if cached_source else matcher.engine.parse(text)
        needs_reference = spec["kind"] == "utterance" and any(
            (head := _utterance(t)) is not None and (content := _content(head)) is not None
            and _nominal(content[0]) != _nominal(spec["body"]) for t in doc)
        if needs_reference:
            expanded = _adjacent_unit(matcher, page, unit)
            if expanded is not unit:
                # Replaying a larger contiguous citation is not a join of
                # favorable leaves. The original native/control row is retained.
                checked = matcher.supplement(atom, page, expanded)
                unit, doc = expanded, matcher.engine.parse(expanded["text"])
                result["citation"] = deepcopy(checked["citation"])
        from matryoshka_next.decisions import _prefix_blocker
        if _prefix_blocker(page, unit["start"], matcher.engine):
            result["reasons"] = ["UNBOUND_PRECEDING_SOURCE_QUALIFICATION"]
            return result
        if any(_lemma(t) in _UNSAFE or t.tag_ == "MD" or t.is_quote or t.text == "?" for t in doc):
            result["reasons"] = ["SOURCE_POLARITY_UNCERTAINTY_OR_ALTERNATIVE_BRANCH"]
            return result
        if spec["kind"] == "resignation" and any(_lemma(t) in {"remain", "retain", "continue"} for t in doc):
            result["reasons"] = ["OFFICE_VERSUS_MEMBERSHIP_CONFLICT_REQUIRES_EXPLICIT_READING"]
            return result
        for action in doc:
            content_head = _utterance(action) if spec["kind"] == "utterance" else None
            if ((spec["kind"] == "resignation" and _lemma(action) != "resign") or
                    (spec["kind"] == "utterance" and content_head is None)):
                continue
            operator, governor = _operator(action)
            actor = _subject(governor)
            binding = _actor(spec["actor"], actor, doc) if actor is not None else None
            if binding is None:
                result["reasons"].append("LITERAL_ACTOR_NOT_UNIQUELY_BOUND")
                continue
            if spec["kind"] == "resignation":
                relation = _office(spec["body"], action, actor)
                if relation is None:
                    result["reasons"].append("DEPARTURE_BODY_MISSING_DIFFERENT_OR_AMBIGUOUS")
                    continue
            else:
                content = _content(content_head)
                if content is None or _lemma(content[1]) != _lemma(spec["property"]):
                    result["reasons"].append("COMPLETE_UTTERANCE_CONTENT_NOT_ALIGNED")
                    continue
                relation = _body(spec["body"], content[0], doc)
                if relation is None:
                    result["reasons"].append("CONTENT_SUBJECT_OR_DEFINITE_ANTECEDENT_UNRESOLVED")
                    continue
            clock = _clock(spec["root"], governor, query_doc, doc)
            if clock is None:
                result["reasons"].append("REQUESTED_EVENT_CLOCK_NOT_ALIGNED")
                continue
            observation = dict(actor=binding, relation=relation, clock=clock, operator=operator,
                               source_action=_proof(action), source_governor=_proof(governor),
                               target_action=_proof(spec["root"]), source_unit_page_start=unit["start"],
                               source_proof_offset_basis="SOURCE_UNIT_UNICODE_CHARACTERS",
                               query_proof_offset_basis="NORMALIZED_PUBLIC_ATOM_UNICODE_CHARACTERS")
            result["observations"].append(observation)
            if operator != "COMPLETED_PAST_SOURCE_ASSERTION":
                result["reasons"].append(operator)
                continue
            certificate = dict(observation, version=VERSION, citation=deepcopy(result["citation"]),
                query_sha256=digest(matcher.case["query"]), atom_sha256=digest(atom),
                source_ascription_reading="OFFICE_DEPARTURE_NOT_MEMBERSHIP_CESSATION" if spec["kind"] == "resignation"
                else "COMPLETED_UTTERANCE_NOT_CONTENT_ENDORSEMENT",
                source_words_modified=False, membership_cessation_certified=False,
                embedded_content_truth_certified=False, canonical_identity_certified=False,
                cross_atom_or_event_join_certified=False, publication_date_used_as_event_time=False)
            result.update(direction="SUPPORT", reasons=[], certificate=certificate,
                support_scope="SOURCE_ATTESTED_OFFICE_DEPARTURE" if spec["kind"] == "resignation"
                else "SOURCE_ATTESTED_COMPLETED_UTTERANCE_NOT_ENDORSEMENT",
                qualified_account=("The source describes the named actor's office in the body and a completed resignation. This supports departure from that office, not cessation of every membership or continued tenure."
                    if spec["kind"] == "resignation" else
                    "The source attests the named holder's completed statement and its content, not endorsement or independent truth of that content."))
            return result
        result["reasons"] = sorted(set(result["reasons"])) or ["NO_MATCHING_ASSERTED_MATRIX_ACTION"]
        if result["observations"]:
            result["direction"] = "PARTIAL"
        return result


def supplement(matcher, atom, page, unit, control):
    """Add the source-owned positive grammar channel after ordinary matching.

    Existing signed certificates and the strict baseline are never rewritten.
    Unsigned rows retain their original source/diagnostics and gain an audit;
    in particular an obligation is not converted to completed-utterance support.
    """
    if (control["direction"] not in {"UNRESOLVED", "PARTIAL"}
            or control.get("source_account_policy_withheld")):
        return control
    audit = evaluate(matcher, atom, page, unit, control)
    if not audit["applicable"]:
        return control
    row = deepcopy(control)
    row["source_clause_semantics_audit"] = audit
    if audit["direction"] != "SUPPORT":
        return row
    row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
        citation=deepcopy(audit["citation"]), source_clause_certificate=deepcopy(audit["certificate"]),
        source_assertion_not_world_truth=True, qualified=True,
        qualified_account=audit["qualified_account"], support_scope=audit["support_scope"],
        source_attestation_not_persistence=True, source_ascription_date=page["date"],
        strict_clause_control=deepcopy(control), event_bindings=[],
        actual_inner_event_established=False, canonical_identity_certified=False,
        membership_cessation_certified=False, embedded_content_truth_certified=False,
        cross_atom_or_event_join_certified=False)
    row["checks"].update(source_bound_clause_ascription="PASS", event_join="NOT_CERTIFIED",
        membership_cessation="NOT_CERTIFIED", embedded_content_truth="NOT_CERTIFIED")
    return row
