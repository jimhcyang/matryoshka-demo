"""Ordinary-source PP/clausal nominations and local syntax, never factual support.

The caller supplies actual inspected pages after complete-index source checks.
This helper does not retrieve, read QA, load a parser, or run factual gates.
"""
from collections import Counter
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE, descriptor, source_page_allowed
from matryoshka_next.readings import MODEL_RESPONSE_SCHEMA, PUBLIC_FIELDS, from_model_response

VERSION = "source-owned-adjunct-candidates/3"
COMPATIBILITY_VERSION = "exact-visible-component-adjunct-syntax/1"
CONTEXT_VERSION = "own-clause-adjunct-context/1"
SCOPED_VERSION = "source-owned-pp-relative-clauses/1"
MAX_PROPOSALS = 128
MAX_SPAN_TOKENS = 64
SUBJECT = frozenset({"nsubj", "nsubjpass"})
QUALIFIER = frozenset({"neg", "aux", "auxpass", "advmod", "npadvmod", "advcl", "prep", "agent", "oprd", "acomp", "prt"})


def eligible(reading):
    """Routing hint only: never replace an existing legacy constructor."""
    if reading.get("constructor_form") is not None:
        return False
    if (reading.get("outer_family"), reading.get("function"), reading.get("role")) == (
            "prepositional", "modifier", "nominal_property"):
        return True
    return (reading.get("outer_family") in {"prepositional", "clausal"}
        and reading.get("function") == "adjunct" and reading.get("role") in {"adjunct", "statement"})


def _inputs(case, reading):
    if not isinstance(case, dict) or set(case) != PUBLIC_FIELDS:
        raise ValueError("Exactly seven public case fields required; no private extras")
    public_case(case)
    if case["task"] != "redaction":
        raise ValueError("Adjunct candidates require a redaction case")
    try:
        raw = {k: reading[k] for k in MODEL_RESPONSE_SCHEMA["$defs"]["reading"]["properties"]}
        expected = from_model_response(dict(status="ready", reason=None, readings=[raw]), case)["readings"]
    except (KeyError, TypeError) as error:
        raise ValueError("An actual bound grammatical reading is required") from error
    if expected != [reading]:
        raise ValueError("Reading must be unchanged and bound to this public case")


def _finite(token):
    return token.pos_ in {"AUX", "VERB"} and (
        "Fin" in token.morph.get("VerbForm") or token.tag_ in {"VBD", "VBP", "VBZ", "MD"})


def _token(token, base=0):
    return dict(text=token.text, start=base + token.idx, end=base + token.idx + len(token),
        pos=token.pos_, tag=token.tag_, dependency=token.dep_, head_start=base + token.head.idx,
        head=token.head.text, morphology=str(token.morph))


def _fragments(text):
    """Keep exact coordinates; mask-adjacent edge sentences stay incomplete."""
    masks = list(MASK.finditer(text))
    start = 0
    for index, mask in enumerate(masks + [None]):
        stop = mask.start() if mask else len(text)
        section = text[start:stop]
        blocks = list(re.finditer(r"\S[\s\S]*?(?=\n\s*\n|\Z)", section))
        for block in blocks:
            left_open = index > 0 and not re.search(r"\n\s*\n", section[:block.start()])
            right_open = mask is not None and not re.search(r"\n\s*\n", section[block.end():])
            yield start + block.start(), block.group(), left_open, right_open
        start = mask.end() if mask else len(text)


def _closed_sentence(sentence):
    tokens = list(sentence)
    while tokens and tokens[-1].text in {'"', "'", "\u201d", "\u2019", ")", "]"}:
        tokens.pop()
    return bool(tokens and tokens[-1].text in {".", "!", "?"}
        and (len(tokens) < 2 or tokens[-2].text not in {".", "..", "..."}))


class Constructor:
    """Reusable parser caches; occurrences must be issued by this instance.

    Replaying a saved occurrence requires re-enumerating its actual source page
    with source_spans or pool first. Mutated or unissued occurrences are held.
    """
    def __init__(self, parser, *, scoped_phrases=False):
        if type(scoped_phrases) is not bool:
            raise ValueError("scoped_phrases must be a strict bool")
        self.parser = parser
        self.scoped_phrases = scoped_phrases
        self.source_cache = {}
        self.query_cache = {}
        self._issued = {}
        self._pages = {}
        self._validated = set()

    def _validate(self, case, reading):
        key = digest([case, reading])
        if key not in self._validated:
            _inputs(case, reading)
            self._validated.add(key)

    def source_spans(self, page):
        """Exact source shapes only; pool/compatibility separately check policy."""
        if digest(page["text"]) != page["source_sha256"]:
            raise ValueError("Source text/hash mismatch")
        key = digest(page)
        if key in self.source_cache:
            return deepcopy(self.source_cache[key])
        found, holds = [], Counter()
        for base, text, left_open, right_open in _fragments(page["text"]):
            doc = self.parser(text)
            sentences = list(doc.sents)
            for sentence in sentences:
                if (left_open and sentence == sentences[0]
                        or right_open and sentence == sentences[-1] and not _closed_sentence(sentence)):
                    holds["OPAQUE_CLIPPED_SOURCE_SENTENCE"] += 1
                    continue
                for head in sentence:
                    if head.pos_ == "ADP" and head.dep_ == "prep":
                        tokens = sorted(head.subtree, key=lambda t: t.i)
                        if not any(t.dep_ in {"pobj", "obj", "pcomp"} for t in head.children):
                            holds["PP_WITHOUT_OWN_OBJECT"] += 1
                            continue
                        if any(_finite(t) for t in tokens) and not (self.scoped_phrases and _owned_relative_clause(tokens,head)):
                            holds["PP_EMBEDDED_FINITE_NOT_SUPPORTED_IN_THIS_SUBSET"] += 1
                            continue
                        if any(t.dep_ == "neg" and t not in tokens for t in head.head.children):
                            holds["EXTERNAL_SOURCE_NEGATION_NOT_CLIPPED"] += 1
                            continue
                        if head.head.pos_ == "VERB" and not _finite(head.head) and not any(_finite(t) for t in head.head.children):
                            holds["NONFINITE_SOURCE_GOVERNOR_SCOPE_UNRESOLVED"] += 1
                            continue
                        value = self._span(page, tokens, base, "prepositional", head)
                        if value:
                            found.append(value)
                    if head.pos_ != "VERB" or head.dep_ != "ROOT":
                        continue
                    subjects = [t for t in head.children if t.dep_ in SUBJECT]
                    complements = [t for t in head.children if t.dep_ == "ccomp"]
                    if len(subjects) != 1 or len(complements) != 1 or not (
                            _finite(head) or any(_finite(t) for t in head.children)):
                        continue
                    complement = complements[0]
                    marks = [t for t in complement.children if t.dep_ == "mark" and t.pos_ == "SCONJ"]
                    if len(marks) != 1 or marks[0].i <= head.i:
                        continue
                    mark = marks[0]
                    content = set(complement.subtree)
                    if any(t.i > mark.i and t not in content and t.dep_ in QUALIFIER for t in head.children):
                        holds["POSTPOSED_MATRIX_QUALIFIER_NOT_CLIPPED"] += 1
                        continue
                    tokens = [t for t in sentence if t.i <= mark.i]
                    if head not in tokens or not all(t in tokens for t in subjects[0].subtree):
                        continue
                    value = self._span(page, tokens, base, "clausal", head)
                    if value:
                        value.update(source_complement_boundary=_token(mark, base),
                            source_embedded_predicate=_token(complement, base),
                            prefix_not_an_independent_source_proposition=True)
                        found.append(value)
        values = list({(v["family"], v["source_start"], v["source_end"]): v for v in found}.values())
        self._pages[key] = deepcopy(page)
        for value in values:
            self._issued[digest(value)] = key
        result = values, dict(holds)
        self.source_cache[key] = deepcopy(result)
        return result

    def _span(self, page, tokens, base, family, head):
        if not tokens or len(tokens) > MAX_SPAN_TOKENS or [t.i for t in tokens] != list(range(tokens[0].i, tokens[-1].i + 1)):
            return None
        first, last = tokens[0], tokens[-1]
        start, end = base + first.idx, base + last.idx + len(last)
        fill = page["text"][start:end]
        if MASK.search(fill) or fill.count('"') % 2 or fill.count("\u201c") != fill.count("\u201d"):
            return None
        qualifiers = [t for t in head.head.children if t.dep_ in QUALIFIER]
        scopes = []
        for token in qualifiers:
            subtree = sorted(token.subtree, key=lambda t: t.i)
            lo, hi = base + subtree[0].idx, base + subtree[-1].idx + len(subtree[-1])
            scopes.append(dict(dependency=token.dep_, span=[lo, hi], text=page["text"][lo:hi],
                tokens=[_token(t, base) for t in subtree]))
        return dict(family=family, fill=fill, source_page_id=page["id"], source_start=start, source_end=end,
            source_document_id=page["document_id"], source_date=page["date"], source_page_sha256=page["source_sha256"],
            source_root=_token(head, base), source_tokens=[_token(t, base) for t in tokens],
            source_sentence=first.sent.text, source_sentence_start=base + first.sent.start_char,
            source_sentence_end=base + first.sent.end_char, source_sentence_initial=first.i == first.sent.start,
            source_governor=_token(head.head, base),
            source_governor_qualifiers=[_token(t, base) for t in qualifiers], source_qualifier_scopes=scopes,
            source_owned_exact_span=True, factual_support_certified=False,
            owner_event_binding="UNASSESSED_REQUIRED_SEPARATELY", independent_corroboration_counted=False,
            version=VERSION)

    def pool(self, case, reading, pages, *, proposal_cap=MAX_PROPOSALS, defer_compatibility=False):
        """Keep all syntax holds, native page order, and occurrences of each fill."""
        self._validate(case, reading)
        if type(proposal_cap) is not int or not 1 <= proposal_cap <= MAX_PROPOSALS:
            raise ValueError("proposal_cap must be an integer from1 through128")
        if type(defer_compatibility) is not bool:
            raise ValueError("defer_compatibility must be a strict bool")
        if not isinstance(pages, (list, tuple)) or len({p["id"] for p in pages}) != len(pages):
            raise ValueError("Unique actual inspected pages in native sequence required")
        for page in pages:
            if not source_page_allowed(page, case, SOURCE_DAY_INCLUSIVE):
                raise ValueError("Unchanged ordinary SourceDay source admission failed")
            if digest(page["text"]) != page["source_sha256"]:
                raise ValueError("Source text/hash mismatch")
        base = dict(version=VERSION, reading_id=reading["id"], declared_reading=deepcopy(reading),
            source_view_policy=descriptor(SOURCE_DAY_INCLUSIVE), inspected_page_ids=[p["id"] for p in pages],
            proposal_cap=proposal_cap, grammar_only=True, factual_support_certified=False, api_calls=0,
            compatibility_deferred=defer_compatibility, eager_compatibility_checks=0)
        if self.scoped_phrases:
            base["scoped_phrase_version"] = SCOPED_VERSION
        if not eligible(reading):
            return dict(base, eligible=False, proposals=[], reason="DECLARED_FAMILY_FUNCTION_OUTSIDE_NEW_SUBSET")
        per_page, holds = [], Counter()
        for page in pages:
            spans, rejected = self.source_spans(page)
            holds.update(rejected)
            values = [v for v in spans if v["family"] == reading["outer_family"]]
            values.sort(key=lambda v: (not v["source_sentence_initial"], v["source_start"], v["source_end"]))
            per_page.append(values)
        occurrences = {}
        for values in per_page:
            for value in values:
                occurrences.setdefault(value["fill"], []).append(value)
        selected, seen = [], set()
        for depth in range(max((len(v) for v in per_page), default=0)):
            for values in per_page:
                if depth >= len(values) or values[depth]["fill"] in seen:
                    continue
                value = values[depth]
                seen.add(value["fill"])
                compatibility = (dict(state="UNASSESSED",reason="DEFERRED_TO_CALLER_COMPLETED_INSERTION_BUDGET",
                    version=COMPATIBILITY_VERSION,grammar_only=True,factual_support_certified=False,
                    full_English_grammar_certified=False,owner_event_binding="UNASSESSED",
                    source_ascription_or_truth_certified=False,no_reading_or_query_fields_modified=True)
                    if defer_compatibility else self.compatibility(case, reading, value))
                selected.append(dict(id="adjunct_nomination_" + digest([VERSION, digest(case), reading["id"], value["fill"]])[:24],
                    version=VERSION, reading_id=reading["id"], family=value["family"], fill=value["fill"],
                    source_occurrences=deepcopy(occurrences[value["fill"]]),
                    compatibility=compatibility, grammar_only=True,
                    factual_support_certified=False, source_function_credit_added=False))
                if len(selected) >= proposal_cap:
                    break
            if len(selected) >= proposal_cap:
                break
        return dict(base, eligible=True, proposals=selected, raw_source_occurrence_n=sum(len(v) for v in per_page),
            eager_compatibility_checks=0 if defer_compatibility else len(selected),
            distinct_source_surface_n=len(occurrences), cap_reached=len(selected) == proposal_cap,
            source_shape_holds=dict(holds), actual_reading_unchanged=True, no_new_readings=True,
            policy="PAGE_DIVERSE_ROUND_ROBIN_SENTENCE_INITIAL_FIRST_THEN_SOURCE_OFFSETS_NO_QA")

    def compatibility(self, case, reading, occurrence):
        """Replay local syntax for an exact occurrence issued by this instance."""
        self._validate(case, reading)
        result = dict(state="HOLD", reason=None, version=COMPATIBILITY_VERSION,
            grammar_only=True, factual_support_certified=False, full_English_grammar_certified=False,
            owner_event_binding="UNASSESSED", source_ascription_or_truth_certified=False,
            no_reading_or_query_fields_modified=True)
        def hold(reason):
            return dict(result, reason=reason)
        page_key = self._issued.get(digest(occurrence))
        if page_key is None:
            return hold("SOURCE_OCCURRENCE_NOT_REPLAYED_OR_CHANGED")
        page = self._pages[page_key]
        if not source_page_allowed(page, case, SOURCE_DAY_INCLUSIVE):
            return hold("SOURCE_DAY_POLICY_HOLD")
        if not eligible(reading) or occurrence["family"] != reading["outer_family"]:
            return hold("DECLARED_FAMILY_FUNCTION_MISMATCH")
        if reading["target_kind"] != "any" or reading["grammatical_number"] != "unknown":
            return hold("NONDEFAULT_TYPED_HINT_NOT_SUPPORTED_BY_ADJUNCT_SUBSET")
        if any(w["placement"] == "inside_gap" for w in reading["wrappers"]):
            return hold("NO_UNDECLARED_OR_INSIDE_GAP_WRAPPER_REALIZATION")
        fill = occurrence["fill"]
        at = case["query"].index(case["focal_marker"])
        end = at + len(case["focal_marker"])
        final = case["query"][:at] + fill + case["query"][end:]
        left, right = 0, len(final)
        for mask in MASK.finditer(final):
            if mask.end() <= at:
                left = mask.end()
            elif mask.start() >= at + len(fill):
                right = mask.start()
                break
            else:
                return hold("INSERTION_INTERSECTS_OPAQUE_BOUNDARY")
        view = final[left:right]
        key = digest(view)
        if key not in self.query_cache:
            self.query_cache[key] = self.parser(view)
        doc = self.query_cache[key]
        part = doc.char_span(at-left, at+len(fill)-left, alignment_mode="strict")
        if part is None:
            return hold("INSERTED_SPAN_NOT_EXACT_TOKENS")
        roots, mapped = set(), []
        delta = len(fill) - len(case["focal_marker"])
        for anchor in reading["attachment_spans"]:
            lo, hi = anchor["start"], anchor["end"]
            if case["query"][lo:hi] != anchor["text"] or lo < end and at < hi:
                return hold("ATTACHMENT_BINDING_CHANGED_OR_OPAQUE")
            lo, hi = (lo+delta, hi+delta) if lo >= end else (lo, hi)
            if lo < left or hi > right:
                return hold("ATTACHMENT_OUTSIDE_FOCAL_VISIBLE_COMPONENT")
            bound = doc.char_span(lo-left, hi-left, alignment_mode="strict")
            if bound is None or bound.text != anchor["text"]:
                return hold("COMPLETED_ATTACHMENT_NOT_EXACT_TOKENS")
            roots.add(bound.root)
            mapped.append(dict(start=lo, end=hi, text=bound.text, root=_token(bound.root, left)))
        if not roots:
            return hold("NO_DECLARED_VISIBLE_ATTACHMENT")
        actual_finite = any(_finite(t) for t in part)
        if reading["finite"] is not None and reading["finite"] != actual_finite:
            return hold("DECLARED_FINITE_HINT_CONFLICT")
        if occurrence["family"] == "prepositional":
            nested = self.scoped_phrases and _owned_relative_clause(list(part),part.root)
            if part.root.pos_ != "ADP" or actual_finite and not nested or part.root.dep_ != "prep":
                return hold("COMPLETED_INSERTION_NOT_NONFINITE_PP_ADJUNCT")
            if part.root.head in part or part.root.head not in roots:
                return hold("PP_NOT_ATTACHED_TO_DECLARED_VISIBLE_GOVERNOR")
            if reading["function"] == "modifier" and part.root.head.pos_ not in {"NOUN", "PROPN"}:
                return hold("PP_MODIFIER_REQUIRES_DECLARED_VISIBLE_NOUN_GOVERNOR")
        else:
            if part.root.pos_ != "VERB" or not actual_finite or not any(t.dep_ in SUBJECT and t.head == part.root for t in part):
                return hold("PREFIX_HAS_NO_OWN_FINITE_PREDICATE_AND_SUBJECT")
            content = [t for t in part.root.children if t.dep_ == "ccomp" and t not in part]
            if len(content) != 1 or content[0] not in roots:
                return hold("PREFIX_DOES_NOT_BIND_DECLARED_VISIBLE_CLAUSE")
            if not any(t.dep_ == "mark" and t.head == content[0] for t in part):
                return hold("MISSING_EXPLICIT_COMPLEMENT_BOUNDARY")
            if not any(t.dep_ in SUBJECT and t not in part and t.idx >= at+len(fill)-left for t in content[0].children):
                return hold("NO_OWN_VISIBLE_INNER_SUBJECT_NO_ACTOR_INHERITANCE")
        return dict(result, state="PASS_SYNTAX_ONLY", reason="DECLARED_ADJUNCT_LOCAL_DEPENDENCY_PREREQUISITES",
            inserted_span=[at, at+len(fill)], inserted_root=_token(part.root, left),
            inserted_tokens=[_token(t, left) for t in part], mapped_attachments=mapped,
            completed_query_sha256=digest(final), parse_view_span=[left, right], parse_view_text=view,
            parse_view_is_exact_contiguous_visible_substring=True, hidden_text_or_wrappers_added=False,
            native_final_form_or_support_gate_executed=False, hypothetical_operator_semantics="UNASSESSED_NOT_CERTIFIED")


def _owned_relative_clause(tokens,head):
    """A finite clause is allowed only as a whole NP-owned relative inside a PP."""
    inside = set(tokens)
    finite = [t for t in tokens if _finite(t)]
    if not finite:
        return False
    for token in finite:
        node = token
        while node in inside and node!=head and node.dep_!="relcl" and node.head!=node:
            node = node.head
        if node.dep_!="relcl" or node.head not in inside or node.head.pos_ not in {"NOUN","PROPN"}:
            return False
        if not any(c.dep_ in SUBJECT for c in node.children):
            return False
    return all(t.head in inside or t==head for t in tokens)


def _terms(parser, text):
    return {t.lemma_.casefold() for t in parser(MASK.sub(" ", text)) if not t.is_stop
        and not t.is_punct and not t.is_space and re.search(r"[A-Za-z0-9]", t.text)}


def order(pool, case, reading, parser):
    """Fixed own-clause advisory order, copied output, no factual tier or credit."""
    _inputs(case, reading)
    if pool["version"] != VERSION or pool["reading_id"] != reading["id"] or pool["declared_reading"] != reading:
        raise ValueError("Pool must belong to this exact production version and reading")
    out = deepcopy(pool)
    if not pool["eligible"]:
        return dict(out, context_order_ids=[], syntax_accepted_context_order_ids=[])
    if reading["outer_family"] == "clausal":
        query = " ".join(v["text"] for v in reading["attachment_spans"])
    else:
        at = case["query"].index(case["focal_marker"])
        query = next(s.text for s in parser(case["query"]).sents if s.start_char <= at < s.end_char)
    q, cache = _terms(parser, query), {}
    for original_index, proposal in enumerate(out["proposals"]):
        scores = []
        for index, occurrence in enumerate(proposal["source_occurrences"]):
            sentence = occurrence["source_sentence"]
            source = sentence[occurrence["source_end"]-occurrence["source_sentence_start"]:] if occurrence["family"] == "clausal" else sentence
            if source not in cache:
                cache[source] = _terms(parser, source)
            s = cache[source]
            common = q & s
            coverage, jaccard = len(common)/max(1,len(q)), len(common)/max(1,len(q|s))
            scores.append(dict(score=.75*coverage+.25*jaccard, coverage=coverage, jaccard=jaccard,
                matched_terms=sorted(common), query_terms=sorted(q), source_terms=sorted(s),
                occurrence_index=index, source_text=source, source_sentence=sentence,
                source_page_id=occurrence["source_page_id"], source_start=occurrence["source_start"], source_end=occurrence["source_end"]))
        proposal["context_order"] = dict(version=CONTEXT_VERSION, query_text=query,
            best_single_occurrence=max(scores,key=lambda v:v["score"]), all_occurrence_scores=scores,
            original_proposal_order=original_index, coverage_weight=.75, jaccard_weight=.25,
            advisory_only=True, correctness_probability=False, factual_support_certified=False,
            owner_event_binding="UNASSESSED", support_tier_changed=False)
    ranked = sorted(out["proposals"], key=lambda p:(-p["context_order"]["best_single_occurrence"]["score"],
        p["context_order"]["original_proposal_order"]))
    out["context_order_ids"] = [p["id"] for p in ranked]
    out["syntax_accepted_context_order_ids"] = [p["id"] for p in ranked if p["compatibility"]["state"] == "PASS_SYNTAX_ONLY"]
    return out


COORDINATE_MEMBER_VERSION = "source-owned-literal-coordinate-member/1"
MAX_COORDINATE_MEMBER_TOKENS = 48


def coordinate_member_eligible(reading):
    return (reading.get("constructor_form") is None
        and reading.get("outer_family") in {"residual_complex","nominal"}
        and reading.get("function")=="coordinate_member" and reading.get("role")=="actor_enumeration"
        and reading.get("target_kind") in {"any","person"}
        and bool(reading.get("operators"))
        and all(o["kind"]=="connective" and o["realization"]=="hypothetical" for o in reading["operators"]))


class CoordinateMemberConstructor:
    def __init__(self,parser):
        self.parser = parser
        self._source_cache,self._query_cache,self._issued,self._pages = {},{},{},{}
        self.compatibility_calls = 0

    def source_spans(self,page):
        if digest(page["text"])!=page["source_sha256"]:
            raise ValueError("Exact raw source hash required")
        key = digest(page)
        if key in self._source_cache: return deepcopy(self._source_cache[key])
        self._pages[key] = deepcopy(page)
        found,holds = [],Counter()
        for block in re.finditer(r"\S[\s\S]*?(?=\n\s*\n|\Z)",page["text"]):
            if MASK.search(block.group()):
                holds["MASKED_PARENT_SCOPE_UNKNOWN"] += 1
                continue
            base = block.start()
            doc = self.parser(block.group())
            if doc.text!=block.group(): raise ValueError("Source parser changed raw text")
            for sentence in doc.sents:
                if not _closed_sentence(sentence):
                    holds["INCOMPLETE_SOURCE_SENTENCE"] += 1
                    continue
                for head in sentence:
                    if head.pos_ not in {"NOUN","PROPN","PRON"} or head.dep_!="conj" or head.head.pos_ not in {"NOUN","PROPN","PRON"}:
                        continue
                    if any(t.dep_=="conj" for t in head.children):
                        holds["NESTED_MEMBER_COORDINATION_UNMODELED"] += 1
                        continue
                    tokens = sorted(head.subtree,key=lambda t:t.i)
                    connectors = [t for t in sentence if t.dep_=="cc" and t.lower_=="and" and t.i<head.i
                        and t.head in {head,head.head}]
                    if not connectors: continue
                    cc = max(connectors,key=lambda t:t.i)
                    tokens = [t for t in tokens if t!=cc]
                    if (not tokens or len(tokens)>MAX_COORDINATE_MEMBER_TOKENS or cc.i+1!=tokens[0].i
                            or [t.i for t in tokens]!=list(range(tokens[0].i,tokens[-1].i+1))
                            or any(t.pos_=="PUNCT" for t in tokens) or any(_finite(t) for t in tokens)):
                        holds["COMPLETE_CONTIGUOUS_NONFINITE_MEMBER_REQUIRED"] += 1
                        continue
                    if any(t.head not in set(tokens) and t!=head for t in tokens):
                        holds["MEMBER_DEPENDENCY_OUTSIDE_COPIED_SPAN"] += 1
                        continue
                    a,b = base+cc.idx,base+tokens[-1].idx+len(tokens[-1])
                    ma = base+tokens[0].idx
                    sa,sb = base+sentence.start_char,base+sentence.end_char
                    value = dict(version=COORDINATE_MEMBER_VERSION,family="residual_complex",fill=page["text"][a:b],
                        source_start=a,source_end=b,source_wording=page["text"][a:b],source_page_id=page["id"],
                        source_document_id=page["document_id"],source_date=page["date"],source_page_sha256=page["source_sha256"],
                        source_sentence_start=sa,source_sentence_end=sb,source_sentence=page["text"][sa:sb],
                        source_parent_quote=dict(span=[block.start(),block.end()],text=block.group()),
                        source_connector=_token(cc,base),source_member_span=[ma,b],
                        source_member_tokens=[_token(t,base) for t in tokens],source_head=_token(head,base),
                        source_coordinate_governor=_token(head.head,base),
                        source_operators=[_token(t,base) for t in sentence if t.dep_ in QUALIFIER],
                        operation_license=dict(kind="COPY_LITERAL_SOURCE_COORDINATOR_AND_COMPLETE_NP",source_span=[a,b],
                            inserted_words=[],deleted_words=[],source_wording_unchanged=True),
                        source_owned_exact_span=True,generated_surface_is_exact_source_span=True,
                        source_joint_query_action_attested=False,source_person_identity_certified=False,
                        factual_support_certified=False,owner_event_binding="UNASSESSED")
                    found.append(value)
                    self._issued[digest(value)] = key
        self._source_cache[key] = deepcopy((found,dict(holds)))
        return found,dict(holds)

    def replay(self,occurrence):
        key = self._issued.get(digest(occurrence))
        if key is None: return False
        p = self._pages[key]
        parent = occurrence["source_parent_quote"]
        return (digest(p["text"])==occurrence["source_page_sha256"]
            and p["text"][occurrence["source_start"]:occurrence["source_end"]]==occurrence["fill"]
            and p["text"][occurrence["source_sentence_start"]:occurrence["source_sentence_end"]]==occurrence["source_sentence"]
            and p["text"][slice(*parent["span"])]==parent["text"] and not MASK.search(parent["text"]))

    def pool(self,case,reading,pages,*,proposal_cap=MAX_PROPOSALS,defer_compatibility=True):
        _inputs(case,reading)
        if type(proposal_cap) is not int or not 1<=proposal_cap<=MAX_PROPOSALS or type(defer_compatibility) is not bool:
            raise ValueError("Strict cap1..128 and bool required")
        if len({p["id"] for p in pages})!=len(pages): raise ValueError("Unique ordinary pages required")
        for p in pages:
            if not source_page_allowed(p,case,SOURCE_DAY_INCLUSIVE) or digest(p["text"])!=p["source_sha256"]:
                raise ValueError("Ordinary source policy/hash failed")
        base = dict(version=COORDINATE_MEMBER_VERSION,declared_reading=deepcopy(reading),case_sha256=digest(case),reading_id=reading["id"],
            inspected_page_ids=[p["id"] for p in pages],proposal_cap=proposal_cap,compatibility_deferred=defer_compatibility,
            eager_compatibility_checks=0,factual_support_certified=False)
        if not coordinate_member_eligible(reading): return dict(base,eligible=False,proposals=[],reason="OUTSIDE_EXPLICIT_UNSUPPORTED_COORDINATE_MEMBER")
        per_page,by_fill,holds = [],{},Counter()
        for p in pages:
            values,failures = self.source_spans(p); holds.update(failures); per_page.append(values)
            for v in values: by_fill.setdefault(v["fill"],[]).append(v)
        proposals,seen = [],set()
        for depth in range(max(map(len,per_page),default=0)):
            for values in per_page:
                if depth>=len(values) or values[depth]["fill"] in seen: continue
                v = values[depth]; seen.add(v["fill"])
                fit = (dict(state="UNASSESSED",reason="DEFERRED_TO_CALLER_COMPLETED_INSERTION_BUDGET",factual_support_certified=False)
                    if defer_compatibility else self.compatibility(case,reading,v))
                proposals.append(dict(id="coordinate_member_"+digest([COORDINATE_MEMBER_VERSION,digest(case),reading["id"],v["fill"]])[:24],
                    fill=v["fill"],source_occurrences=deepcopy(by_fill[v["fill"]]),compatibility=fit,factual_support_certified=False))
                if len(proposals)>=proposal_cap: break
            if len(proposals)>=proposal_cap: break
        return dict(base,eligible=True,proposals=proposals,source_shape_holds=dict(holds),
            eager_compatibility_checks=0 if defer_compatibility else len(proposals),cap_reached=len(proposals)==proposal_cap)

    def compatibility(self,case,reading,occurrence):
        _inputs(case,reading)
        self.compatibility_calls += 1
        base = dict(state="HOLD",version=COORDINATE_MEMBER_VERSION,grammar_only=True,factual_support_certified=False,
            source_joint_query_action_attested=False,source_person_identity_certified=False,
            native_factual_gate_executed=False,declared_reading_changed=False)
        def hold(reason): return dict(base,reason=reason)
        if not coordinate_member_eligible(reading) or not self.replay(occurrence): return hold("UNISSUED_CHANGED_OR_UNSUPPORTED_READING")
        page = self._pages[self._issued[digest(occurrence)]]
        if not source_page_allowed(page,case,SOURCE_DAY_INCLUSIVE): return hold("SOURCE_POLICY_HOLD")
        if reading["target_kind"]!="any" or reading["grammatical_number"]!="unknown": return hold("TYPED_MEMBER_CONSTRAINT_UNMODELED")
        if reading["wrappers"]: return hold("NO_ADDED_WRAPPER_REALIZATION")
        at = case["query"].index(case["focal_marker"]); end=at+len(case["focal_marker"])
        fill = occurrence["fill"]; completed=case["query"][:at]+fill+case["query"][end:]
        left,right=0,len(completed)
        for m in MASK.finditer(completed):
            if m.end()<=at: left=m.end()
            elif m.start()>=at+len(fill): right=m.start(); break
            else: return hold("OPAQUE_INSERTION")
        view=completed[left:right]
        if view not in self._query_cache: self._query_cache[view]=self.parser(view)
        doc=self._query_cache[view]
        part=doc.char_span(at-left,at+len(fill)-left,alignment_mode="strict")
        if part is None: return hold("INSERTION_NOT_EXACT_TOKENS")
        if any(_finite(t) for t in part) or reading["finite"] is True: return hold("FINITE_MEMBER_UNMODELED")
        roots,mapped=set(),[]
        delta=len(fill)-len(case["focal_marker"])
        for anchor in reading["attachment_spans"]:
            a,b=anchor["start"],anchor["end"]
            if a<end and at<b or case["query"][a:b]!=anchor["text"]: return hold("ATTACHMENT_CHANGED_OR_OPAQUE")
            if a>=end: a,b=a+delta,b+delta
            if not left<=a<b<=right: return hold("ATTACHMENT_OUTSIDE_VISIBLE_COMPONENT")
            bound=doc.char_span(a-left,b-left,alignment_mode="strict")
            if bound is None or bound.text!=anchor["text"]: return hold("ATTACHMENT_NOT_EXACT_TOKENS")
            roots.add(bound.root); mapped.append(dict(start=a,end=b,text=bound.text,root=_token(bound.root,left)))
        # spaCy Span.root may choose the leading CC: both CC and nominal
        # conjunct point outside the insertion. Select the actual NP head.
        heads=[t for t in part if t.pos_ in {"NOUN","PROPN","PRON"} and t.dep_=="conj" and t.head not in part]
        if len(heads)!=1: return hold("ONE_COMPLETE_INSERTED_NOMINAL_CONJUNCT_REQUIRED")
        head=heads[0]
        if (head.head not in roots
                or head.head in part or head.head.pos_ not in {"NOUN","PROPN","PRON"}):
            return hold("MEMBER_NOT_COORDINATED_WITH_DECLARED_VISIBLE_NOUN")
        connectors=[t for t in part if t.dep_=="cc" and t.lower_=="and" and t.head in {head,head.head}]
        if len(connectors)!=1 or part[0]!=connectors[0]: return hold("SOURCE_CONNECTOR_NOT_BOUND_TO_COMPLETED_COORDINATION")
        return dict(base,state="PASS_SYNTAX_ONLY",reason="EXACT_DECLARED_LITERAL_COORDINATE_MEMBER",inserted_span=[at,at+len(fill)],
            completed_query_sha256=digest(completed),inserted_tokens=[_token(t,left) for t in part],
            mapped_attachments=mapped,parse_view_span=[left,right],parse_view_text=view,
            hypothetical_connective_truth="UNASSESSED",whole_source_parent_retained=True)


def coordinate_member_order(pool,case,reading,parser):
    from .nominal_relative_provenance import focal_context
    _inputs(case,reading)
    if pool["case_sha256"]!=digest(case) or pool["declared_reading"]!=reading: raise ValueError("Exact public binding changed")
    out=deepcopy(pool); context=focal_context(case); q=_terms(parser,context["text"])
    for i,p in enumerate(out["proposals"]):
        observations=[]
        for oi,o in enumerate(p["source_occurrences"]):
            s=_terms(parser,o["source_sentence"]); common=q&s
            coverage=len(common)/max(1,len(q)); jaccard=len(common)/max(1,len(q|s))
            observations.append(dict(occurrence_index=oi,score=.75*coverage+.25*jaccard,coverage=coverage,jaccard=jaccard,
                query_terms=sorted(q),source_terms=sorted(s),matched_terms=sorted(common)))
        p["context_order"]=dict(version="own-clause-adjunct-context/1",coverage_weight=.75,jaccard_weight=.25,
            correctness_probability=False,factual_support_certified=False,original_proposal_order=i,
            best_single_occurrence=max(observations,key=lambda x:x["score"]),all_occurrence_scores=observations)
    out["context_order_ids"]=[p["id"] for p in sorted(out["proposals"],key=lambda p:(
        -p["context_order"]["best_single_occurrence"]["score"],p["context_order"]["original_proposal_order"]))]
    return out
