"""Source-local OUTER actor reference, never inner event identity.

Only replayed clause/source-account producers can nominate anchors. Repeated
names on a page are not sufficient: the anchors must be outer subjects in one
unmasked printed paragraph, with one unambiguous local name interpretation.
"""
from copy import deepcopy
import json
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v6.planning import sentences, SECTION
from matryoshka_demo_v61.scope_matching import _layout
from matryoshka_next.facts import public_plan
from . import clause_semantics as clauses
from . import exact_matrix, hypothesis_stances, source_account_match

VERSION = "source-local-shared-outer-actor/2"
PROOF_FIELD = "shared_outer_actor_certificate"
_BOUNDARY = re.compile(r"(?m)^[ \t]*(?:\d{1,3}\.|\([A-Z]\)|[A-Z][.)])[ \t]+|\n[ \t\r]*\n")
_REASON = "SAME_SOURCE_ASSERTION_SUBJECT_OR_AUTHORIZED_REFERENCE_REQUIRED"
_NAME = {"compound", "flat", "name"}
_FALSE = ("inner_execution_certified", "event_join_certified", "physical_executor_certified",
          "world_truth_certified", "canonical_identity_certified")


def _names(head):
    return tuple(t.text.casefold() for t in clauses._name_tokens(head)) if head is not None else ()


def _paragraph(page, start, end):
    boundaries = [*list(_BOUNDARY.finditer(page["text"])), *list(SECTION.finditer(page["text"]))]
    if any(start < m.start() < end for m in boundaries):
        return None
    lo = max((m.start() for m in boundaries if m.start() <= start), default=0)
    hi = min((m.start() for m in boundaries if m.start() >= end), default=len(page["text"]))
    if hi - lo > 4096 or MASK.search(page["text"][lo:hi]):
        return None
    return lo, hi


def _raw_span(ref, start, end, mapping=None):
    a = mapping[start] if mapping is not None else start
    b = mapping[end - 1] + 1 if mapping is not None else end
    return ref["start"] + a, ref["start"] + b


def _producer(matcher, atom, saved):
    base = matcher.baseline
    clause = saved.get("source_clause_certificate")
    account = saved.get("source_account_match_certificate")
    inventory = saved.get("source_inventory_announcement_certificate")
    if sum(map(bool,(clause,account,inventory))) != 1:
        return None
    if clause:
        reference = clause["citation"]
        original = saved.get("strict_clause_control", {}).get("citation")
        family = "SOURCE_BOUND_CLAUSE"
    elif inventory:
        reference = original = inventory["citation"]
        family = "SOURCE_BOUND_INVENTORY_ANNOUNCEMENT"
    else:
        if not account.get("reporting_realization"):
            return None
        reference = account["citation"]
        original = account["original_unit_citation"]
        family = "NARRATIVE_REPORTING_REALIZATION"
    if not isinstance(original, dict):
        raise ValueError("Outer actor producer lost its original source unit")
    pi = base.positions.get(reference["canonical_page_id"])
    if pi is None:
        raise ValueError("Outer actor source is outside the bound corpus")
    page = base.corpus.pages[pi]
    if base.policy.citation(pi, original["start"], original["end"]) != original:
        raise ValueError("Outer actor original source citation changed")
    unit = dict(start=original["start"], end=original["end"], text=original["text"])
    if (unit["start"], unit["end"]) not in {(u["start"], u["end"]) for u in sentences(page["text"])}:
        return None
    row = matcher.supplement(atom, page, unit)
    row = clauses.supplement(base, atom, page, unit, row)
    row = exact_matrix.supplement(base, atom, page, unit, row)
    row = hypothesis_stances.supplement(base, atom, page, unit, row)
    row = source_account_match.supplement(matcher, atom, page, unit, row)
    if inventory:
        from . import source_prefix_accounts,source_inventory_announcement
        row = source_prefix_accounts.supplement(matcher,atom,page,unit,row)
        row = source_inventory_announcement.supplement(matcher,atom,page,unit,row)
    key = ("source_clause_certificate" if clause else "source_inventory_announcement_certificate"
        if inventory else "source_account_match_certificate")
    # Compare the entire independently regenerated producer in JSON form;
    # internal tuples become lists in saved native packets. A claimed digest
    # is never accepted in place of replaying the producer.
    if (digest(row.get(key)) != digest(saved.get(key)) or row.get("citation") != saved.get("citation")
            or row.get("direction") != "SUPPORT" or saved.get("direction") != "SUPPORT"):
        raise ValueError("Outer actor proof differs from trusted source producer replay")
    if any(saved.get(k) for k in ("source_account_policy_withheld", "root_content_withheld",
            "potential_counter", "unbound_material_counter")):
        return None
    if saved.get("event_bindings") or saved.get("actual_inner_event_established"):
        return None
    if inventory:
        scope = inventory.get("scope",{})
        receipt = saved.get("inventory_announcement_producer_replay",{})
        if (scope.get("kind") != "QUERIED_OPERATOR_ONLY"
                or any(scope.get(k) is not False for k in _FALSE)
                or receipt.get("version") != source_inventory_announcement.VERSION
                or receipt.get("certificate_sha256") != digest(inventory)
                or receipt.get("atom_sha256") != digest(atom)
                or receipt.get("raw_page_sha256") != page["source_sha256"]
                or receipt.get("replayed") is not True
                or receipt.get("execution_or_join_authority_added") is not False):
            raise ValueError("Inventory outer actor lost its operator-only producer receipt")
        proofs=inventory["source_holder"]
        holder=tuple(p["text"].casefold() for p in proofs if p["dependency"]!="det")
        query_holder=tuple(p["text"].casefold() for p in inventory["query_holder"] if p["dependency"]!="det")
        if len(holder)<2 or holder!=query_holder:
            return None
        actor_spans=[_raw_span(reference,p["start"],p["end"]) for p in proofs]
        if any(page["text"][a:b]!=p["text"] for (a,b),p in zip(actor_spans,proofs)):
            raise ValueError("Inventory announcer token spans do not replay raw source")
        operator_only=True
    elif clause:
        proofs = clause["actor"]["source_proofs"]
        actor_spans = [_raw_span(dict(start=clause["source_unit_page_start"]), p["start"], p["end"]) for p in proofs]
        if any(page["text"][a:b] != p["text"] for (a, b), p in zip(actor_spans, proofs)):
            raise ValueError("Clause actor token offsets do not replay raw text")
        operator_only = False
    else:
        view, mapping, _ = _layout(base.engine, account["parent_citation"]["text"])
        doc = base.engine.parse(view)
        op = account["reporting_realization"]["operator"]
        governor = next((t for t in doc if t.idx == op["start"] and t.text == op["text"]), None)
        owner = source_account_match._subject(governor) if governor is not None else None
        names = clauses._name_tokens(owner) if owner is not None else []
        if governor is None or governor.dep_ != "ROOT" or not names:
            return None
        actor_spans = [_raw_span(account["parent_citation"], t.idx, t.idx + len(t), mapping) for t in names]
        operator_only = account["scope"]["kind"] == "QUERIED_OPERATOR_ONLY"
        if any(account["scope"].get(k) is not False for k in _FALSE):
            raise ValueError("Outer actor input has relaxed an operator-only scope")
    return dict(page=page, citation=reference, actor_spans=actor_spans, family=family,
        producer_certificate=deepcopy(row[key]), operator_only=operator_only,
        **(dict(literal_inventory_holder=holder) if inventory else {}))


def prove(matcher, plan, atoms, *, subject, atom_ids):
    """Prove only this explicit shared-outer-subject group, or return None."""
    base = matcher.baseline
    if base.case["task"] not in {"hypothesis", "reconstruction"}:
        return None
    public_plan(base.case, plan)
    if (not isinstance(atom_ids, list) or not 2 <= len(atom_ids) <= 16
            or len(set(atom_ids)) != len(atom_ids) or not isinstance(subject, str) or not subject.strip()):
        return None
    planned = {a["id"]: a for a in plan["atoms"]}
    observed = {a["id"]: a for a in atoms}
    subject_doc = base.engine.parse(subject)
    wanted = tuple(t.text.casefold() for t in subject_doc if not t.is_space and not t.is_punct
        and not (t.dep_ == "det" and t.lower_ in {"the", "a", "an"}))
    if not wanted:
        return None
    choices = {}
    with offline():
        for aid in atom_ids:
            if aid not in planned or aid not in observed:
                return None
            atom, result = planned[aid], observed[aid]
            if (not atom.get("required") or atom.get("kind") != "proposition"
                    or result.get("criterion_state") != "SUPPORTED" or result.get("counterevidence")):
                return None
            qview, _, _ = _layout(base.engine, atom["text"])
            qdoc = base.engine.parse(qview)
            qr = source_account_match._root(qdoc)
            qa = source_account_match._subject(qr) if qr is not None else None
            literal_public=source_account_match._public(base,atom,qdoc)
            choices[aid] = {}
            for saved in result.get("positive_evidence", [])[:16]:
                produced = _producer(matcher, atom, saved)
                if produced is None:
                    continue
                # Inventory replay independently validates its closed public
                # coordinate projection; it is not a general span waiver.
                if not literal_public and produced["family"]!="SOURCE_BOUND_INVENTORY_ANNOUNCEMENT":
                    continue
                inventory_holder=produced.get("literal_inventory_holder")
                if (inventory_holder!=wanted if inventory_holder else _names(qa)!=wanted):
                    continue
                page, ref = produced["page"], produced["citation"]
                bounds = _paragraph(page, ref["start"], ref["end"])
                if bounds is None:
                    continue
                parent = base.policy.citation(base.positions[page["id"]], *bounds)
                view, mapping, _ = _layout(base.engine, parent["text"])
                doc = base.engine.parse(view)
                head_span = produced["actor_spans"][-1]
                owners = [t for t in doc if _raw_span(parent, t.idx, t.idx + len(t), mapping) == head_span]
                if len(owners) != 1:
                    continue
                owner = owners[0]
                if owner.dep_ != "nsubj" or owner.head.dep_ != "ROOT":
                    continue
                binding = (dict(kind="LITERAL_REPLAYED_NAMED_INVENTORY_ANNOUNCER",
                    name=list(inventory_holder), source_actor_spans=produced["actor_spans"],
                    source_local_reference_only=True,canonical_identity_certified=False,
                    inner_actor_or_executor_inferred=False) if inventory_holder else clauses._actor(qa, owner, doc))
                if binding is None:
                    continue
                full_names = {_names(t) for t in doc if t.pos_ == "PROPN" and t.dep_ not in _NAME
                    and t.text.casefold() == wanted[-1] and len(_names(t)) > 1}
                if len(wanted) == 1 and len(full_names) > 1:
                    continue
                namespace = next(iter(full_names)) if len(wanted) == 1 and full_names else wanted
                key = (page["id"], page["source_sha256"], *bounds, namespace)
                choices[aid].setdefault(key, dict(atom_id=aid, atom_sha256=digest(atom),
                    citation=ref, paragraph_citation=parent, raw_outer_actor_spans=produced["actor_spans"],
                    actor_binding=binding, local_name=list(namespace), producer_family=produced["family"],
                    producer_certificate=produced["producer_certificate"], operator_only=produced["operator_only"],
                    position_basis="RAW_PAGE_UNICODE_CODEPOINT_HALF_OPEN", inner_actor_used=False))
            if not choices[aid]:
                return None
        common = set.intersection(*(set(choices[aid]) for aid in atom_ids))
        if not common:
            return None
        key = sorted(common)[0]
        anchors = [choices[aid][key] for aid in atom_ids]
        operator_only = any(a["operator_only"] for a in anchors)
        proof = dict(version=VERSION, type="SOURCE_LOCAL_SHARED_OUTER_ACTOR_REFERENCE",
            query_sha256=digest(base.case["query"]), plan_sha256=digest(plan), subject=subject,
            atom_ids=list(atom_ids), paragraph_citation=anchors[0]["paragraph_citation"], anchors=anchors,
            same_outer_actor_reference_certified=True, canonical_identity_certified=False,
            only_shared_subject_check_satisfied=True, inner_actor_identity_certified=False,
            event_bindings_created=[], source_text_modified=False,
            other_query_referents_or_relations_certified=False,
            scope=dict(kind="QUERIED_OPERATOR_ONLY" if operator_only else "SOURCE_ASCRIPTION",
                qualification="Same source-paragraph OUTER actor reference only; each producer's speech and necessity scope remains unchanged.",
                outer_actor_reference_join_certified=True, operator_only_ancestor_preserved=True,
                **{k: False for k in _FALSE}))
        return json.loads(json.dumps(proof))


def replay(matcher, plan, atoms, certificate):
    produced = prove(matcher, plan, atoms, subject=certificate.get("subject"), atom_ids=certificate.get("atom_ids"))
    if produced != certificate or certificate.get("version") != VERSION:
        raise ValueError("Shared outer actor proof differs from trusted producer replay")
    return deepcopy(certificate)


def supplement_scope(matcher, plan, atoms, scope):
    """Repair only proved shared_subject checks, without changing atom verdicts."""
    result = deepcopy(scope)
    changed = False
    for check in result.get("checks", []):
        if (check.get("kind") != "shared_subject" or check.get("state") != "UNRESOLVED"
                or check.get("reason") != _REASON):
            continue
        certificate = prove(matcher, plan, atoms, subject=check.get("subject"), atom_ids=check.get("atom_ids"))
        if certificate is None:
            continue
        check.update(state="SATISFIED", local_account_only=True,
            source_local_outer_actor_reference_certified=True, shared_outer_actor_certificate=certificate)
        changed = True
    if not changed:
        return scope
    result["complete"] = all(c.get("state") == "SATISFIED" for c in result["checks"])
    if result.get("counter_scope_complete") is False:
        result["complete"] = False
    result["source_actor_binding_version"] = VERSION
    result["inner_execution_or_event_joins_added"] = False
    return result
