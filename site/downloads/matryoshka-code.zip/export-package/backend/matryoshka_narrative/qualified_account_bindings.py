"""Conservative source-owned qualified accounts, without event/identity joins.

These explicit linguistic forms retain every requested argument and operator.
They attest what one eligible printed source states; plans and disjunctions do
not become completed events. No cases, historical names or source IDs occur in
the grammar. Source eligibility and literal quotation replay belong to MatcherCase.
"""
import re

from matryoshka_demo.io import offline
from matryoshka_next.decisions import _prefix_blocker

VERSION = "narrative-qualified-source-account-bindings/3"
_ARTICLES = {"a", "an", "the"}
_UNSAFE = {"not", "no", "never", "neither", "nor", "if", "unless", "whether",
           "might", "may", "could", "would", "should", "will", "allegedly", "reportedly"}
_MONTH = r"(?:January|February|March|April|May|June|July|August|September|October|November|December)"
_CLOCK = re.compile(r"\b\d{4}\b|\b" + _MONTH + r"\s+\d{1,2}\b|\b\d{1,2}\s+" + _MONTH
    + r"\b|\b(?:on|during|in)\s+" + _MONTH + r"\b|\b(?:today|yesterday|tomorrow|now|currently|recently|soon|ago)\b"
    + r"|\b(?:last|next|this)\s+(?:day|week|month|year)\b", re.I)
_ANNOUNCED = re.compile(r"(?P<subject>.+?)\s+(?P<aux>had|has|have)\s+(?P<negation>not\s+)?announced\s+"
    r"(?P<process>it\s+is\s+proceeding\s+with\s+)?plans\s+to\s+(?P<purpose>.+?)\s*[.]?\Z", re.I | re.S)
_REPORTED = re.compile(r"(?P<subject>.+?)\s+(?P<aux>were|are)\s+(?P<negation>not\s+)?reported\s+to\s+"
    r"have\s+(?P<completed>\w+)\s+or\s+to\s+be\s+about\s+to\s+(?P<imminent>\w+)\s+for\s+(?P<destination>.+?)\s*[.]?\Z", re.I | re.S)
_CAMPAIGN = re.compile(r"(?:A|The)\s+(?P<nominal>.+?)\s+led\s+by\s+(?P<person>.+?),\s*"
    r"(?P<apposition>.+?),\s*to\s+(?P<purpose>.+?)\s+(?:has\s+)?resulted\s+in\s+(?P<result>.+?)\s*[.]?\Z", re.I | re.S)
_APPOINTMENT = re.compile(r"(?P<person>[^,]+?)(?:,\s*(?P<prior>who\s+was\s+[^,]+),)?\s+"
    r"(?:(?P<perfect_report>reportedly)\s+(?P<perfect_aux>has|had)\s+(?P<perfect_negation>not\s+)?been"
    r"|(?P<past_aux>was)\s+(?P<before_report_negation>not\s+)?(?P<past_report>reportedly)\s*(?P<past_negation>not\s+)?)"
    r"\s+appointed\s+(?P<office>.+?)(?:\s+in\s+the\s+(?P<government>new\s+government))?\s*[.]?\Z",re.I|re.S)


def _proofs(match):
    return {name: dict(text=match[name], start=match.start(name), end=match.end(name))
            for name in match.re.groupindex if match[name] is not None}


def _words(text, engine, *, articles=False):
    """Ordered lemmas; modifiers, quantities and named spellings remain required."""
    doc = engine.parse(text.strip().rstrip("."))
    if not doc or any(t.is_quote or t.text in {";", ":", "?", "[", "]", "(", ")"} for t in doc):
        return None
    tokens = [t for t in doc if not t.is_space and not t.is_punct]
    if any(t.pos_ == "PRON" or t.lower_ in _UNSAFE
            and not (t.lower_ in {"may", "will"} and t.pos_ == "PROPN") for t in tokens):
        return None
    if articles:
        tokens = [t for t in tokens if not (t.dep_ == "det" and t.lower_ in _ARTICLES)]
    return tuple((t.text.casefold() if t.pos_ == "PROPN" else (t.lemma_ or t.text).casefold()) for t in tokens)


def _proper(text, engine):
    if re.fullmatch(r"[A-Z][A-Z0-9-]{1,11}", text.strip()):
        return (text.strip().casefold(),)
    doc = engine.parse(text.strip())
    tokens = [t for t in doc if not t.is_space]
    if (not tokens or any(t.pos_ != "PROPN" or t.is_punct or t.dep_ in {"poss", "case"} for t in tokens)
            or any(t.ent_type_ in {"DATE", "TIME"} for t in tokens)):
        return None
    return tuple(t.text.casefold() for t in tokens)


def _acronym(text):
    """An immediately printed uppercase parenthetical alias, never a dictionary."""
    match = re.fullmatch(r"(?P<full>[^()]+?)\s*\((?P<alias>[A-Z][A-Z0-9-]{1,11})\)", text.strip())
    return (match["full"].strip(), match["alias"].casefold()) if match else (text.strip(), None)


def _owned(text, engine):
    """One literal possessive/of owner; all core words and restrictions retained."""
    text, alias = _acronym(text.strip().rstrip("."))
    text = re.sub(r"^(?:a|an|the)\s+", "", text, flags=re.I)
    possessive = re.fullmatch(r"(?P<owner>[^'’]+)['’]s\s+(?P<core>.+)", text)
    of = re.fullmatch(r"(?P<core>.+?)\s+of\s+(?P<owner>.+)", text, re.I)
    if possessive:
        core, owner = possessive["core"], possessive["owner"]
    elif of:
        core, owner = of["core"], of["owner"]
    else:
        core, owner = text, None
    words = _words(core, engine, articles=True)
    ownership = _words(owner, engine, articles=True) if owner is not None else None
    if not words or owner is not None and not ownership:
        return None
    return dict(core=words, owner=ownership, printed_alias=alias)


def _nominal_equal(wanted, offered, engine):
    a, b = _owned(wanted, engine), _owned(offered, engine)
    if a is None or b is None:
        return False
    return a["core"] == b["core"] and a["owner"] == b["owner"]


def _purpose(text, engine):
    # The infinitive is retained as a purpose; its predicate is not an event.
    match = re.fullmatch(r"(?P<verb>\w+)\s+(?P<object>.+?)\s+over\s+(?P<function>.+)", text.strip(), re.I | re.S)
    if not match:
        return None
    verb, obj, function = _words(match["verb"], engine), _words(match["object"], engine, articles=True), _owned(match["function"], engine)
    return (verb, obj, function) if verb and obj and function else None


def _apposition(text, engine):
    source = re.fullmatch(r"a\s+suspected\s+(?P<affiliation>.+?)\s+who\s+is\s+(?P<office>.+)", text.strip(), re.I | re.S)
    query = re.fullmatch(r"(?P<office>.+?)\s+and\s+a\s+suspected\s+(?P<affiliation>.+)", text.strip(), re.I | re.S)
    match = source or query
    if match is None:
        return None
    affiliation, office = _words(match["affiliation"], engine, articles=True), _owned(match["office"], engine)
    if not affiliation or not office:
        return None
    # No suppression of former/acting/etc: they remain words in office signature.
    return dict(office=office, affiliation=affiliation, qualification="suspected")


def _result(text, engine):
    # by/among is an experiencer alternation ONLY for these nominal mental states.
    match = re.fullmatch(r"(?P<growth>growing\s+)?(?P<head>awareness|concern)\s+"
        r"(?P<relation>of|about)\s+(?P<object>.+?)\s+(?:by|among)\s+(?P<experiencer>.+)", text.strip(), re.I | re.S)
    if not match:
        return None
    obj = _words(match["object"], engine, articles=True)
    experiencer = _owned(match["experiencer"], engine)
    if not obj or experiencer is None:
        return None
    return dict(growing=bool(match["growth"]), head=match["head"].casefold(),
        relation=match["relation"].casefold(), object=obj, experiencer=experiencer)


def _campaign(text, engine):
    match = _CAMPAIGN.fullmatch(text.strip())
    if not match:
        return None
    person, nominal = _proper(match["person"], engine), _words(match["nominal"], engine, articles=True)
    apposition, purpose, result = _apposition(match["apposition"], engine), _purpose(match["purpose"], engine), _result(match["result"], engine)
    if not all((person, nominal, apposition, purpose, result)):
        return None
    return dict(nominal=nominal, person=person, apposition=apposition, purpose=purpose, result=result,
        coordination_refinement=bool(re.match(r"(?:concerted|coordinated)\s+", match["nominal"], re.I)),
        raw_group_proofs=_proofs(match))


def _campaign_equal(a, b):
    if a is None or b is None:
        return False
    # concerted/coordinated modifies joint manner, not factual uncertainty. No
    # other extra adjective can disappear through this narrow refinement rule.
    bn = b["nominal"]
    if len(bn) == len(a["nominal"]) + 1 and b["coordination_refinement"]:
        bn = bn[1:]
    return (a["nominal"] == bn and all(a[k] == b[k] for k in ("person", "apposition", "purpose", "result")))


def _leaders(text, engine):
    match = re.fullmatch(r"(?P<number>\w+)\s+(?P<body>.+)", text.strip(), re.S)
    if not match:
        return None
    number = _words(match["number"], engine)
    doc = engine.parse(match["number"])
    if not number or not all(t.like_num for t in doc if not t.is_space):
        return None
    body = match["body"].strip()
    of = re.fullmatch(r"(?P<role>\w+)\s+of\s+(?P<owner>.+)", body, re.I | re.S)
    if of:
        expansion, alias = _acronym(of["owner"])
        if (alias and (_words(expansion, engine, articles=True) is None
                or re.search(r"\b(?:alleged|suspected|possible|former|prospective|purported)\b", expansion, re.I))):
            return None
        owner = (alias,) if alias else _proper(re.sub(r"^the\s+", "", expansion, flags=re.I), engine)
        role = _words(of["role"], engine)
    else:
        compound = re.fullmatch(r"(?P<owner>.+?)\s+(?P<role>\w+)", body, re.S)
        if not compound:
            return None
        owner, role = _proper(compound["owner"], engine), _words(compound["role"], engine)
    if not owner or not role:
        return None
    return dict(number=number, role=role, owner=owner)


def _announced(query, source, engine):
    q, s = _ANNOUNCED.fullmatch(query.strip()), _ANNOUNCED.fullmatch(source.strip())
    if not q or not s or q["process"] or not _nominal_equal(q["subject"], s["subject"], engine):
        return None
    wanted = _words(q["purpose"], engine, articles=True)
    offered_text = s["purpose"]
    # A source's additional positive geographic extent does not turn a plan
    # into execution. This one explicit refinement carries no participant join.
    offered_text = re.sub(r"\s+throughout\s+the\s+country\s*[.]?\Z", "", offered_text, flags=re.I)
    offered = _words(offered_text, engine, articles=True)
    if not wanted or wanted != offered:
        return None
    return dict(kind="COMPLETE_ANNOUNCED_PLAN_SOURCE_ACCOUNT", subject=_owned(q["subject"], engine),
        source_subject=_owned(s["subject"], engine), target_raw_group_proofs=_proofs(q), source_raw_group_proofs=_proofs(s),
        target_matrix_negated=bool(q["negation"]), source_matrix_negated=bool(s["negation"]),
        purpose=wanted, source_proceeding_with_plans=bool(s["process"]),
        planned_action_execution_certified=False, geographic_refinement_not_required=offered_text != s["purpose"])


def _reported(query, source, engine):
    q, s = _REPORTED.fullmatch(query.strip()), _REPORTED.fullmatch(source.strip())
    if not q or not s:
        return None
    actors = _leaders(q["subject"], engine), _leaders(s["subject"], engine)
    values = []
    for match in (q, s):
        completed, imminent, dest = (_words(match[k], engine, articles=True) for k in ("completed", "imminent", "destination"))
        values.append((completed, imminent, dest))
    if not actors[0] or actors[0] != actors[1] or not all(values[0]) or values[0] != values[1]:
        return None
    return dict(kind="COMPLETE_REPORTED_DISJUNCTION_SOURCE_ACCOUNT", actor=actors[0], branches=values[0],
        target_raw_group_proofs=_proofs(q), source_raw_group_proofs=_proofs(s),
        target_matrix_negated=bool(q["negation"]), source_matrix_negated=bool(s["negation"]),
        operator="reported", connective="or", either_branch_individually_certified=False,
        completed_departure_or_arrival_certified=False)


def _prior_role(text, engine):
    """One independent past role relative, with its own named-administration clock."""
    match=re.fullmatch(r"who\s+was\s+(?P<role>.+?)(?:\s+during\s+(?P<owner>[^'’]+)['’]s\s+administration)?",text.strip(),re.I|re.S)
    if not match:
        return None
    tokens=[t for t in engine.parse(match["role"]) if not t.is_space and not t.is_punct]
    if (not tokens or any(t.pos_ not in {"NOUN","PROPN","ADJ","DET","ADP"} for t in tokens)
            or not any(t.pos_=="NOUN" for t in tokens)):
        return None
    role=_words(match["role"],engine,articles=True)
    owner=_proper(match["owner"],engine) if match["owner"] else None
    owner_proofs=[]
    if match["owner"]:
        owner_tokens=[t for t in engine.parse(text.strip()) if match.start("owner")<=t.idx
            and t.idx+len(t)<=match.end("owner") and not t.is_space]
        if owner_tokens and all(t.pos_=="PROPN" for t in owner_tokens):
            owner=tuple(t.text.casefold() for t in owner_tokens)
            owner_proofs=[dict(text=t.text,start=t.idx,end=t.idx+len(t),dependency=t.dep_,pos=t.pos_) for t in owner_tokens]
    if not role or match["owner"] and not owner:
        return None
    return dict(role=role,administration_owner=owner,administration_owner_proofs=owner_proofs,
        tense="past",raw_group_proofs=_proofs(match),
        independent_nonrestrictive_role_not_a_query_requirement=True,
        administration_clock_not_applied_to_appointment=True)


def _appointment(query,source,engine):
    """A report-qualified completed passive, never appointment execution or tenure."""
    if any(len(char.casefold())!=1 for text in (query,source) for char in text):
        return None
    q,s=_APPOINTMENT.fullmatch(query.strip()),_APPOINTMENT.fullmatch(source.strip())
    if not q or not s or q["prior"] or not q["past_aux"]:
        return None
    names=_proper(q["person"],engine),_proper(s["person"],engine)
    if not names[0] or names[0]!=names[1]:
        return None
    def office(match):
        tokens=[t for t in engine.parse(match["office"]) if not t.is_space and not t.is_punct]
        if (not tokens or not any(t.pos_ in {"NOUN","PROPN"} for t in tokens)
                or any(t.ent_type_ in {"DATE","TIME"} for t in tokens)
                or any(t.pos_=="ADP" and t.lemma_.casefold() not in {"of","to","for"} for t in tokens)
                or any(t.pos_ not in {"NOUN","PROPN","ADJ","DET","ADP","PART"} for t in tokens)):
            return None
        return _owned(match["office"],engine)
    wanted,offered=office(q),office(s)
    prior=_prior_role(s["prior"],engine) if s["prior"] else None
    if (not wanted or wanted!=offered or s["prior"] and prior is None
            or q["government"] and not s["government"]):
        return None
    negated=lambda m:[m[k] for k in ("perfect_negation","before_report_negation","past_negation") if m[k]]
    if any(len(negated(m))>1 for m in (q,s)):
        return None
    return dict(kind="REPORT_QUALIFIED_COMPLETED_PASSIVE_APPOINTMENT",person=names[0],office=wanted,
        target_matrix_negated=bool(negated(q)),source_matrix_negated=bool(negated(s)),
        target_raw_group_proofs=_proofs(q),source_raw_group_proofs=_proofs(s),
        reportedly_preserved=True,source_perfect_to_historical_past_ascription=bool(s["perfect_aux"]),
        independent_prior_role=prior,additional_source_government_context=s["government"],
        government_context_in_query=bool(q["government"]),
        reported_appointment_only=True,appointment_execution_independently_certified=False,
        current_office_tenure_certified=False,continuous_office_certified=False,
        appointing_agent_inferred=False,country_owner_inferred=False)


def evaluate(matcher, atom, page, unit, control):
    """Run after strict policy replay; never changes eligibility or raw strings."""
    result = dict(version=VERSION, applicable=False, direction="UNRESOLVED", certificate=None, reasons=[])
    if atom.get("kind") != "proposition":
        return result
    text = unit.get("text", unit.get("quote"))
    qtext = atom["text"]
    # The broader prototype is preserved for research. Its counter scope is
    # not modeled, so this grammatical family cannot gain source support here.
    if _CAMPAIGN.fullmatch(qtext.strip()):
        result.update(applicable=True, form_policy_withheld=True,
            reasons=["QUALIFIED_NOMINAL_CAMPAIGN_FORM_WITHHELD_COUNTER_SCOPE_NOT_MODELED"])
        return result
    if control["direction"] not in {"PARTIAL", "UNRESOLVED"}:
        return result
    with offline():
        engine = matcher.engine
        prefix = page["text"][:unit["start"]]
        boundaries = list(re.finditer(r"[.!?]\s+|\n\s*\n", prefix))
        fragment = prefix[boundaries[-1].end() if boundaries else 0:].strip()
        following = page["text"][unit["end"]:]
        incomplete_suffix = bool(following and not re.match(r"(?:\s|[.!?](?:\s|$))", following))
        if (following.strip() and not re.search(r"[.!?]\s*\Z", text)
                and not re.match(r"(?:[.!?](?:\s|$)|\s*\n\s*\n)", following)):
            incomplete_suffix = True
        unfinished = re.split(r"[.!?](?:\s|$)", prefix)[-1]
        unclosed_conditional = bool(re.search(r"\b(?:if|unless|whether|provided\s+that)\b", unfinished, re.I))
        if fragment or incomplete_suffix or unclosed_conditional or _prefix_blocker(page, unit["start"], engine):
            result["reasons"] = ["UNBOUND_EXTERNAL_SOURCE_SCOPE"]
            return result
        # NER alone mistakes month words inside printed organization names for
        # event dates. Explicit/deictic clock syntax still requires abstention.
        if any(_CLOCK.search(raw) for raw in (qtext, text)):
            result["reasons"] = ["EXPLICIT_EVENT_CLOCK_REQUIRES_SEPARATE_BOUND_POLICY"]
            return result
        certificate = (_announced(qtext, text, engine) or _reported(qtext, text, engine)
            or _appointment(qtext,text,engine))
        if certificate is None:
            return result
        if certificate["target_matrix_negated"] or certificate["source_matrix_negated"]:
            result.update(applicable=True, matched_account=certificate,
                reasons=["NEGATIVE_MATRIX_SUPPORT_POLICY_NOT_IMPLEMENTED"])
            if certificate["target_matrix_negated"] != certificate["source_matrix_negated"]:
                result.update(direction="PARTIAL", potential_counter=True, counter_scope="UNMODELED",
                    counter_receipt=dict(control["citation"]),
                    reasons=["OPPOSITE_MATRIX_POLARITY_EVENT_CLOCK_NOT_BOUND"])
            return result
        certificate.update(version=VERSION, source_unit_page_start=unit["start"],
            source_unit_page_end=unit["end"], source_text_modified=False,
            source_proof_offset_basis="SOURCE_UNIT_UNICODE_CHARACTERS_ADD_SOURCE_UNIT_PAGE_START",
            complete_requested_content_bound=True, source_attestation_not_persistence=True,
            inner_proceeding_actor_inferred=False, plan_owner_or_executor_certified=False,
            source_assertion_not_world_truth=True, canonical_identity_certified=False,
            cross_atom_or_event_join_certified=False, publication_date_used_as_event_time=False)
        result.update(applicable=True, direction="SUPPORT", certificate=certificate, reasons=[])
        return result
