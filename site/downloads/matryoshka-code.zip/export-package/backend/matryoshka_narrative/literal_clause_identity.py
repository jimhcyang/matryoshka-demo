"""Recognize an unchanged top-level public clause despite parser attachment drift."""
VERSION = "unchanged-public-clause-identity/1"


def unchanged_clause(query, atom_text, public_frame, normalized_frame):
    from .query_syntax import parse
    if (public_frame.get("predicate") != normalized_frame.get("predicate")
            or public_frame.get("negated") != normalized_frame.get("negated")
            or public_frame.get("public_operators") != normalized_frame.get("public_operators")
            or public_frame.get("public_operators",{}).get("scope")
            or any(b.get("kind")=="FRONTED_ADJUNCT_OVER_EXPLICIT_AND_COORDINATION"
                for b in public_frame.get("public_attachment_bindings",[]))):
        return False
    doc,_=parse(query)
    head=next((t for t in doc if t.idx==public_frame["start"]),None)
    if head is None or head.dep_ not in {"ROOT","conj"}:
        return False
    # Every original clause token must remain, including all argument modifiers.
    # A reporting complement or conditional subordinate is not a free assertion.
    original=[t.lower_ for t in sorted(head.subtree,key=lambda t:t.i)
        if not t.is_space and not t.is_punct]
    normalized,_=parse(atom_text)
    supplied=[t.lower_ for t in normalized if not t.is_space and not t.is_punct]
    return bool(original) and supplied==original
