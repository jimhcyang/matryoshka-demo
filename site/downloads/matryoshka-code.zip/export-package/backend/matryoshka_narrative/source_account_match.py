"""Bounded literal source accounts for M/H; never inner execution/world truth.

The caller retains ordinary retrieval and decision authority. This fallback
matches complete literal clauses, not topical overlap or inferred paraphrases.
"""
from copy import deepcopy
import re

from matryoshka_demo.io import digest, offline
from matryoshka_demo.contracts import MASK
from matryoshka_demo.vendor.matching import qualifiers
from matryoshka_demo_v61.scope_matching import _layout
from matryoshka_demo_v6.planning import sentences, SECTION
from matryoshka_next.decisions import _prefix_blocker, _public_scope
from matryoshka_next.facts import public_plan
from .exact_matrix import _epistemic_subject
from .source_qualification import raw_envelope_holds
from .source_sentences import recover, _REPORTS
from . import clause_semantics as clauses

VERSION = "direct-literal-source-account-match/7"
PROOF_FIELD = "source_account_match_certificate"
_ASSERTIVE = {"say", "state", "report", "note", "announce", "declare", "confirm",
              "argue", "believe", "think", "maintain", "contend", "conclude", "judge"}
_MODALS = {"can", "could", "may", "might", "will", "would", "should", "must"}
_HEADING = re.compile(r"(?P<label>[A-Z]|\d{1,2})\. (?P<title>[A-Z][A-Z0-9 -]{2,100})\r?\n")
_REPORT_NOUNS = {"announcement", "report", "statement", "claim", "declaration", "account"}
_DISTINCT = {"previous", "earlier", "prior", "other", "another", "different", "unrelated"}
_EPISTEMIC = {"uncertain", "unclear", "unknown", "unverified", "unconfirmed", "false", "fabricated", "doubtful"}
_CREATION = {"make", "issue", "exist", "occur", "publish", "announce"}


def _proof(token):
    return dict(text=token.text, start=token.idx, end=token.idx + len(token),
        lemma=token.lemma_.casefold(), dependency=token.dep_, pos=token.pos_, tag=token.tag_)


def _tokens(doc):
    return [t for t in doc if not t.is_space and not t.is_punct]


def _root(doc):
    roots = [t for t in doc if t.dep_ == "ROOT"]
    return roots[0] if len(roots) == 1 else None


def _subject(root):
    subjects = [t for t in root.children if t.dep_ in {"nsubj", "nsubjpass", "csubj", "csubjpass"}]
    if not subjects and root.dep_ == "conj" and root.head.dep_ == "ROOT":
        # A final proper-name subject is sometimes attached to the preceding
        # nominal object. Require the literal AND + complete proper-name prefix;
        # never invent a missing actor or inherit a generic-title subject.
        before = [t for t in root.doc[:root.i] if not t.is_space]
        names = []
        for token in reversed(before):
            if token.pos_ != "PROPN":
                break
            names.append(token)
        names.reverse()
        if names and len(before) > len(names) and before[-len(names) - 1].lower_ == "and":
            subjects = [names[-1]]
    return subjects[0] if len(subjects) == 1 else None


def _complete(doc, *, named):
    root = _root(doc)
    if root is None or root.pos_ not in {"VERB", "AUX", "ADJ"}:
        return False
    subject = _subject(root)
    finite = any(t.tag_ in {"VBD", "VBP", "VBZ", "MD"} for t in (root, *root.children))
    if subject is None and root.lemma_.casefold() == "be" and any(t.dep_ == "expl" for t in root.children):
        attributes = [t for t in root.children if t.dep_ == "attr" and t.pos_ in {"NOUN", "PROPN"}]
        if len(attributes) == 1 and any(t.pos_ == "PROPN" for t in attributes[0].subtree):
            subject = attributes[0]
    if not finite or subject is None or subject.pos_ == "PRON":
        return False
    if named and not any(t.pos_ == "PROPN" for t in subject.subtree):
        return False
    if any(t.is_quote or t.text in {"?", ":", ";", "[", "]", "(", ")"} for t in doc):
        return False
    # Full nested report content remains literal. Independent generic-title
    # conjuncts cannot borrow the first clause's named owner.
    for verb in doc:
        if verb.dep_ == "conj" and verb.pos_ in {"VERB", "AUX"} and verb.head == root:
            owner = _subject(verb)
            if owner is None or named and not any(t.pos_ == "PROPN" for t in owner.subtree):
                return False
    return True


def _equal(query_doc, source_doc, source_tokens=None, source_root=None, query_tokens=None, promote_root=False):
    wanted = query_tokens if query_tokens is not None else _tokens(query_doc)
    offered = source_tokens if source_tokens is not None else _tokens(source_doc)
    if [t.text.casefold() for t in wanted] != [t.text.casefold() for t in offered]:
        return None
    qp, sp = {t.i: i for i, t in enumerate(wanted)}, {t.i: i for i, t in enumerate(offered)}
    changes = []
    for q, s in zip(wanted, offered):
        qhead, shead = qp.get(q.head.i, -1), sp.get(s.head.i, -1)
        qdep, sdep = q.dep_, s.dep_
        if s == source_root and (s.dep_ == "conj" or promote_root and s.dep_ == "ccomp"):
            shead, sdep = sp[s.i], "ROOT"
        if (qhead, qdep) == (shead, sdep):
            continue
        # Identical explicit TO infinitives can differ only in parser label.
        if (qhead == shead and {qdep, sdep} == {"advcl", "xcomp"}
                and q.pos_ == s.pos_ == "VERB" and q.tag_ == s.tag_ == "VB"
                and all(any(c.lower_ == "to" and c.dep_ in {"aux", "mark"} for c in t.children) for t in (q, s))):
            changes.append(dict(query=_proof(q), source=_proof(s), kind="SAME_HEAD_LITERAL_TO_INFINITIVE_LABEL"))
        else:
            return None
    return changes if len(changes) <= 1 else None


def _whole_literal_identity(query, source, qdoc):
    """Whole affirmative account identity; syntax labels cannot remove words."""
    root = _root(qdoc)
    if (root is None or root.pos_ != "VERB" or not _complete(qdoc, named=True)
            or root.lemma_.casefold() in _ASSERTIVE | _REPORTS
            or any(t.dep_ in {"neg", "advcl", "ccomp", "xcomp", "relcl", "acl", "parataxis"}
                or t.tag_ == "MD" for t in qdoc)):
        return None

    def normalized(text):
        chars, mapping = [], []
        pending = None
        for i, char in enumerate(text):
            if char.isspace():
                if chars and pending is None:
                    pending = i
                continue
            if pending is not None:
                chars.append(" ")
                mapping.append(pending)
                pending = None
            for folded in char.casefold():
                chars.append(folded)
                mapping.append(i)
        return "".join(chars), mapping

    qtext, qmap = normalized(query)
    stext, smap = normalized(source)
    if not qtext or qtext != stext:
        return None
    return dict(kind="WHOLE_RAW_UNIT_CASE_WHITESPACE_IDENTITY", normalized_text=qtext,
        query_raw_character_map=qmap, source_raw_character_map=smap,
        punctuation_and_all_lexical_characters_retained=True, substring_match=False,
        normalization="CASEFOLD_AND_COLLAPSED_WHITESPACE_ONLY",
        offset_basis="ORIGINAL_ATOM_TEXT_AND_FULL_RAW_SOURCE_UNIT", syntax_labels_used_as_proof=False)


def _opposing(query_doc, source_doc, offered, source_root):
    """Only explicit negation owned by an identical modal root can differ."""
    qr = _root(query_doc)
    if qr is None or source_root is None:
        return None
    qt = _tokens(query_doc)
    if any(t.lower_ in {"all", "every", "each", "both", "neither", "nor", "never", "no"} for t in [*qt, *offered]):
        return None
    if any(t.tag_ == "MD" and t.lower_ in {"may", "might"} for t in [*qt, *offered]):
        return None
    if not any(t.head == qr and t.tag_ == "MD" and t.lower_ in _MODALS for t in qt):
        return None
    def owned(tokens, root):
        return [t for t in tokens if t.dep_ == "neg" and t.lower_ in {"not", "n't"}
            and (t.head == root or t.head.head == root and t.head.tag_ == "MD")]
    qneg, sneg = owned(qt, qr), owned(offered, source_root)
    if sorted([len(qneg), len(sneg)]) != [0, 1]:
        return None
    variation = _equal(query_doc, source_doc, [t for t in offered if t not in sneg], source_root,
        [t for t in qt if t not in qneg], promote_root=True)
    if variation is None:
        return None
    return dict(kind="EXACT_MODAL_ACCOUNT_EXPLICIT_OWNED_ROOT_NEGATION_ONLY",
        query_negation=[_proof(t) for t in qneg], source_negation=[_proof(t) for t in sneg],
        unchanged_modals=[t.text.casefold() for t in qt if t.tag_ == "MD"],
        opposing_view_not_world_event_refutation=True, syntax_variations=variation)


def _heading(text, engine):
    found = _HEADING.match(text)
    if not found:
        return 0, None
    doc = engine.parse(found["title"])
    root = _root(doc)
    if (root is None or root.pos_ != "VERB" or root.tag_ not in {"VBD", "VBP", "VBZ"}
            or root.lemma_.casefold() in _REPORTS
            or any(qualifiers(root).get(k) for k in ("negated", "modality", "scope", "conditional", "unresolved"))
            or any(t.pos_ in {"ADJ", "ADV", "AUX", "PRON", "SCONJ"} or t.is_quote for t in doc)):
        return None, None
    subject = _subject(root)
    if subject is None or subject.pos_ == "NOUN" and _epistemic_subject(subject.lemma_.casefold()):
        return None, None
    return found.end(), dict(text=text[:found.end()], title_used_as_evidence=False,
        rule="FINITE_AFFIRMATIVE_NONREPORTING_SECTION_TITLE")


def _branches(doc):
    """Whole matrix first; only independent, own-subject AND branches after it."""
    yield _tokens(doc), _root(doc), "WHOLE_LITERAL_ACCOUNT"
    root = _root(doc)
    if root is None or root.lemma_.casefold() in _REPORTS or any(qualifiers(root).get(k)
            for k in ("negated", "modality", "scope", "attribution", "conditional", "question", "unresolved")):
        return
    conjuncts = [t for t in root.children if t.dep_ == "conj" and t.pos_ in {"VERB", "AUX"}]
    if not conjuncts or any(t.dep_ == "cc" and t.lower_ != "and" for t in root.children):
        return
    if not any(t.dep_ == "cc" and t.lower_ == "and" for t in root.children):
        return
    excluded = {t.i for c in conjuncts for t in c.subtree}
    excluded.update(t.i for t in root.children if t.dep_ == "cc")
    first = [t for t in _tokens(doc) if t.i not in excluded]
    yield first, root, "INDEPENDENT_AND_MATRIX"
    for conjunct in conjuncts:
        if _subject(conjunct) is None or any(t.dep_ in {"advcl", "cc", "conj"} for t in conjunct.children):
            continue
        yield _tokens(conjunct.subtree), conjunct, "INDEPENDENT_AND_CONJUNCT"


def _public(base, atom, qdoc):
    if _public_scope(atom, base.case):
        return False
    normalized = lambda text: " ".join(text.casefold().split()).rstrip(".")
    if normalized(atom["text"]) == normalized(base.case["query"]):
        return True
    view, _, _ = _layout(base.engine, base.case["query"])
    public = base.engine.parse(view)
    for tokens, root, _ in _branches(public):
        if root is not None and _equal(qdoc, public, tokens, root) is not None:
            return True
    # Public-only shared-subject AND expansion. No source words, new actor,
    # modal inheritance, OR branch or reported-content extraction is allowed.
    root = _root(public)
    subject = _subject(root) if root is not None else None
    if (subject is not None and clauses._name_tokens(subject)
            and root.lemma_.casefold() not in _REPORTS
            and not any(qualifiers(root).get(k) for k in
                ("negated", "modality", "scope", "conditional", "question", "unresolved"))
            and any(t.dep_ == "cc" and t.lower_ == "and" for t in root.children)
            and not any(t.dep_ == "cc" and t.lower_ != "and" for t in root.children)):
        for conjunct in root.children:
            if (conjunct.dep_ != "conj" or conjunct.tag_ != "VBD" or _subject(conjunct) is not None
                    or any(t.dep_ in {"cc", "conj"} for t in conjunct.children)):
                continue
            words = [*_tokens(subject.subtree), *_tokens(conjunct.subtree)]
            if [t.text.casefold() for t in words] == [t.text.casefold() for t in _tokens(qdoc)]:
                return True
    return False


def _report_context(base, page, selected_end, *, actor=None):
    """A local qualifier of THIS account is a HOLD, not signed opposition."""
    text = page["text"]
    a = text.rfind("\n\n", 0, selected_end)
    a = 0 if a < 0 else a + 2
    first_end = text.find("\n\n", selected_end)
    first_end = len(text) if first_end < 0 else first_end
    second_end = text.find("\n\n", first_end + 2)
    b = len(text) if second_end < 0 else second_end
    if b - a > 8192:
        return None
    doc = base.engine.parse(text[a:b])
    anchor = True
    inspected = []
    for sentence in doc.sents:
        if a + sentence.end_char <= selected_end:
            continue
        nouns = [t for t in sentence if a + t.idx >= selected_end and t.pos_ == "NOUN" and t.lemma_.casefold() in _REPORT_NOUNS]
        for verb in sentence:
            if (a + verb.idx >= selected_end and verb.dep_ == "ROOT" and verb.lemma_.casefold() in _ASSERTIVE
                    and _subject(verb) is not None and any(t.pos_ == "PROPN" for t in _subject(verb).subtree)
                    and not nouns):
                anchor = False
        if anchor:
            for token in sentence:
                if (a + token.idx < selected_end or token.lower_ not in {"this", "that"}
                        or token.pos_ not in {"PRON", "DET"} or token.dep_ not in {"nsubj", "nsubjpass", "attr"}
                        or token.head.pos_ not in {"VERB", "AUX", "ADJ"}):
                    continue
                governor = token.head
                properties = [governor, *list(governor.children)]
                false_account = any(t.lower_ in _EPISTEMIC for t in properties)
                negated_occurrence = governor.lemma_.casefold() in {"happen", "occur", "exist", "take", "make"} and any(
                    t.dep_ == "neg" for t in governor.children)
                if false_account or negated_occurrence:
                    return None
        for noun in nouns:
            words = {t.lower_ for t in noun.children}
            if words & _DISTINCT or any(t.dep_ == "poss" and t.pos_ == "PROPN" for t in noun.children):
                anchor = False
                continue
            current = anchor and (bool(words & {"this", "that", "such"})
                or a + noun.idx < first_end and bool(words & {"the", "no", "any"}))
            if not current:
                continue
            path = [noun, *noun.ancestors]
            creation = [t for t in path if t.lemma_.casefold() in _CREATION]
            if noun.dep_ == "attr" and noun.head.lemma_.casefold() == "be":
                creation.append(noun.head)
            if actor is not None:
                wanted = clauses._name_tokens(actor)
                foreign = False
                for action in creation:
                    owner = _subject(action)
                    offered = clauses._name_tokens(owner) if owner is not None else []
                    # An explicit different named performer does not cancel
                    # this actor's report. Ambiguous same-surname cases hold.
                    if (offered and clauses._actor(actor, owner, doc) is None
                            and not (len(wanted) == 1 and wanted[0].lower_ == offered[-1].lower_)):
                        foreign = True
                if foreign:
                    inspected.append(dict(proof=_proof(noun), current=False,
                        reason="EXPLICIT_OTHER_REPORTING_ACTOR"))
                    continue
            negative = any(t.lower_ in {"no", "neither"} for t in noun.children)
            negative |= any(c.dep_ == "neg" or c.lower_ == "never" for t in creation for c in t.children)
            uncertain = any(c.lower_ in _EPISTEMIC or c.lower_ in {"whether", "if"} and c.dep_ == "mark"
                for t in path for c in t.children)
            direct = (noun.head.lower_ in _EPISTEMIC or noun.head.lemma_.casefold() in {"deny", "retract", "withdraw"}
                or any(t.lower_ in _EPISTEMIC for t in noun.children)
                or any(t.lower_ in _EPISTEMIC and t.dep_ in {"acomp", "attr"} for t in noun.head.children))
            inspected.append(dict(proof=_proof(noun), current=True))
            if direct or creation and (negative or uncertain):
                return None
    return dict(start=a, end=b, text_sha256=digest(text[a:b]), inspected_report_mentions=inspected,
        scope="CURRENT_AND_IMMEDIATELY_FOLLOWING_PARAGRAPH", signed_opposition_inferred=False)


def _content_signature(head, subject):
    """Only an independently proved nominal reference may differ in content."""
    nominal = set(t.i for t in subject.subtree)
    tokens = [t for t in _tokens(head.subtree) if t.i not in nominal
        and not (t.head == head and t.dep_ == "mark" and t.lower_ == "that")]
    ordered = sorted([*tokens, subject], key=lambda t: t.i)
    positions = {t.i: i for i, t in enumerate(ordered)}
    result = []
    for token in ordered:
        if token == subject:
            result.append(("BOUND_CONTENT_SUBJECT", token.dep_, positions[head.i]))
        else:
            result.append((token.text.casefold(), "ROOT" if token == head else token.dep_,
                positions[token.i] if token == head else positions.get(token.head.i, -1)))
    return result


def _reporting_tail_holds(base, page, end, actor):
    """Bind nonrealization to this reporting act, not arbitrary negative words."""
    context = _report_context(base, page, end, actor=actor)
    if context is None:
        return True
    tail = base.engine.parse(page["text"][end:context["end"]].lstrip())
    report_actions = {"make", "write", "issue", "publish", "deliver", "send", "utter", "do"}
    requirements = {"requirement", "obligation", "request", "demand", "instruction", "proposal"}
    focus = True

    def negated(head):
        return any(t.dep_ == "neg" or t.lower_ == "never" for t in head.children)

    def same_actor(owner):
        return owner is not None and (owner.pos_ == "PRON" and focus
            or clauses._actor(actor, owner, tail) is not None)

    def reference(noun, *, kind=False):
        if not focus:
            return False
        if noun.pos_ == "PRON":
            return noun.lower_ in {"it", "this", "that"}
        if noun.lemma_.casefold() not in _REPORT_NOUNS | requirements:
            return False
        words = {t.lower_ for t in noun.children}
        determiners = {"this", "that", "such", "the", "no", "any"} | ({"a", "an"} if kind else set())
        if words & _DISTINCT or not words & determiners:
            return False
        for child in noun.children:
            if child.dep_ == "poss" and child.pos_ == "PROPN":
                names = tuple(t.text.casefold() for t in child.subtree if t.pos_ == "PROPN")
                wanted = tuple(t.text.casefold() for t in clauses._name_tokens(actor))
                if names != wanted:
                    return False
            if child.dep_ == "prep" and child.lower_ in {"about", "regarding", "on"}:
                return False
            if child.dep_ == "prep" and child.lower_ == "by":
                owners = [t for t in child.children if t.dep_ == "pobj"]
                if len(owners) != 1 or not same_actor(owners[0]):
                    return False
        return True

    def linked(action):
        if action.lemma_.casefold() == "do" and any(t.lower_ == "so" for t in action.children):
            return focus
        if action.lemma_.casefold() in report_actions:
            return any(t.dep_ in {"dobj", "obj", "nsubjpass"} and reference(t) for t in action.children)
        if action.lemma_.casefold() == "comply":
            return any(reference(obj) for prep in action.children if prep.dep_ == "prep" and prep.lower_ == "with"
                for obj in prep.children if obj.dep_ == "pobj")
        return False

    def owned_complement(action, root):
        token = action
        while token != root:
            if token.dep_ not in {"xcomp", "acomp", "prep", "pcomp"}:
                return False
            if token.dep_ == "prep" and token.lower_ != "of":
                return False
            if token != action and token.pos_ == "VERB":
                return False
            if _subject(token) is not None:
                return False
            token = token.head
        return True

    # The complete current and immediately following paragraph are bounded by
    # _report_context; a blank line does not erase a definite passive referent.
    for sentence in tail.sents:
        # Deictic qualification of this reporting act, not a word ban on an
        # unrelated actor's requirements or a previous announcement.
        root = next((t for t in sentence if t.dep_ == "ROOT"), None)
        owner = _subject(root) if root is not None else None
        if root is None:
            continue
        if (root is not None and root.lemma_.casefold() in {"be", "remain"}
                and owner is not None and owner.lower_ in {"it", "this", "that"}
                and any(t.dep_ == "attr" and t.lemma_.casefold() in
                    requirements for t in root.children) and focus):
            return True
        if owner is not None and reference(owner):
            agents = [obj for agent in root.children if agent.dep_ == "agent"
                for obj in agent.children if obj.dep_ == "pobj"]
            foreign_agent = agents and not all(same_actor(a) for a in agents)
            properties = [t for child in root.children if child.dep_ in {"attr", "acomp"} for t in child.subtree]
            hypothetical = any(t.lemma_.casefold() in {"hypothetical", "imaginary", "fictional", "unrealized", "unmet"}
                for t in properties)
            restricted = any(t.lower_ in {"only", "merely", "just", "solely"}
                for t in [*root.children, *properties])
            limited = restricted and not negated(root) and not re.search(
                r"\bnot\s+(?:only|merely|just|solely)\b", root.sent.text, re.I)
            draft_only = root.lemma_.casefold() in {"be", "remain"} and limited and any(
                t.dep_ == "attr" and t.lemma_.casefold() in {"draft", "proposal", "plan"} for t in root.children)
            proposed_only = root.lemma_.casefold() in {"propose", "plan", "draft", "contemplate"} and limited
            kind_denial = (root.lemma_.casefold() in {"be", "constitute", "represent"} and negated(root)
                and not re.search(r"\bnot\s+only\b", root.sent.text, re.I)
                # This realization licenses MAKE STATEMENT, not every kind
                # of report: "not a declaration" need not deny a statement.
                and any(t.dep_ in {"attr", "dobj", "obj"} and t.lemma_.casefold() == "statement"
                    and reference(t, kind=True) for t in root.children))
            if not foreign_agent and (root.lemma_.casefold() in report_actions and negated(root)
                    or hypothetical or draft_only or proposed_only or kind_denial):
                return True
        if same_actor(owner):
            actions = [t for t in root.subtree if t.lemma_.casefold() in report_actions | {"comply"}
                and owned_complement(t, root) and linked(t)]
            properties = [root, *list(root.children)]
            inability = any(t.lemma_.casefold() in {"unable", "incapable"} for t in properties)
            inability |= negated(root) and any(t.lemma_.casefold() == "able" for t in properties)
            failure = root.lemma_.casefold() in {"fail", "refuse", "decline", "cancel"}
            prospective_only = (root.lemma_.casefold() in {"propose", "plan", "draft", "contemplate"}
                and not negated(root)
                and any(t.lower_ in {"only", "merely", "just", "solely"} for t in root.children)
                and any(t.dep_ in {"dobj", "obj"} and reference(t) for t in root.children))
            if actions and (inability or failure or negated(root)) or prospective_only:
                return True
        elif owner is not None and owner.pos_ != "PRON" and (
                root.lemma_.casefold() in _ASSERTIVE or any(linked(t) for t in root.subtree)):
            focus = False
    return False


def _reporting_realization(base, atom, page, unit, control, qdoc):
    """Completed or narrated-past compelled speech, never execution proof.

    Convention: an unqualified matrix HAD TO MAKE [a written] STATEMENT THAT
    in a past narrative licenses the *source-reported account*. It does not
    certify actual utterance performance or truth of the reported content.
    Other obligations, purposes, prospective/conditional acts and cancellations
    do not license this convention.
    """
    qr = _root(qdoc)
    if qr is None or qr.lemma_.casefold() not in {"state", "say"} or qr.tag_ != "VBD":
        return None
    qa = _subject(qr)
    contents = [t for t in qr.children if t.dep_ == "ccomp"]
    if qa is None or not clauses._name_tokens(qa) or len(contents) != 1:
        return None
    qhead = contents[0]
    qsubject = _subject(qhead)
    if qsubject is None or not clauses._nominal(qsubject):
        return None
    qdate_tokens = {t.i for _, row in clauses._dates(qr, qdoc.text)
        for t in qdoc[row["attachment_child"]].subtree}
    if any(t.dep_ not in {"nsubj", "ccomp", "punct"} and t.i not in qdate_tokens
            and not t.is_space for t in qr.children):
        return None
    expanded = clauses._adjacent_unit(base, page, unit)
    pi = base.positions[page["id"]]
    parent = base.policy.citation(pi, expanded["start"], expanded["end"])
    if MASK.search(parent["text"]) or expanded["start"] < unit["start"] and SECTION.search(parent["text"]):
        return None
    view, mapping, edits = _layout(base.engine, parent["text"])
    doc = base.engine.parse(view)
    if (_prefix_blocker(page, parent["start"], base.engine)
            or raw_envelope_holds(base, page, parent, doc)):
        return None
    for action in doc:
        if action.lemma_.casefold() != "make":
            continue
        content = clauses._utterance(action)
        if content is None:
            continue
        source_subject = _subject(content)
        if source_subject is None:
            continue
        governor = action
        mode = "COMPLETED_NOMINAL_REPORTING_REALIZATION"
        if (action.dep_ == "xcomp" and action.head.lemma_.casefold() == "have"
                and action.head.tag_ == "VBD" and action.head.text.casefold() == "had"
                and any(t.dep_ == "aux" and t.lower_ == "to" for t in action.children)):
            governor = action.head
            mode = "NARRATED_PAST_COMPULSION_REPORTING_CONVENTION"
        elif action.dep_ != "ROOT" or action.tag_ != "VBD":
            continue
        if governor.dep_ != "ROOT":
            continue
        raw_position = mapping[governor.idx] if mapping is not None else governor.idx
        if not unit["start"] <= parent["start"] + raw_position < unit["end"]:
            continue
        speaker = _subject(governor)
        actor = clauses._actor(qa, speaker, doc) if speaker is not None else None
        body = clauses._body(qsubject, source_subject, doc)
        clock = clauses._clock(qr, governor, qdoc, doc)
        if actor is None or body is None or clock is None:
            continue
        if _content_signature(qhead, qsubject) != _content_signature(content, source_subject):
            continue
        if body["kind"] != "LITERAL_CONTENT_SUBJECT":
            previous = [s for s in doc.sents if s.end <= content.sent.start]
            previous_root = next((t for t in previous[-1] if t.dep_ == "ROOT"), None) if previous else None
            previous_actor = _subject(previous_root) if previous_root is not None else None
            if previous_actor is None or clauses._actor(qa, previous_actor, doc) is None:
                continue
        # Do not strip any operator on the report act. Content operators remain
        # in the exact signature above, including embedded negation and modals.
        dates = {t.i for _, row in clauses._dates(governor, doc.text)
            for t in doc[row["attachment_child"]].subtree}
        allowed = {"nsubj", "punct", "xcomp"} if governor != action else {"nsubj", "punct", "dobj", "obj"}
        unsafe = False
        for child in governor.children:
            if child.dep_ in allowed or child.is_space or child.i in dates:
                continue
            if child.dep_ == "advcl":
                markers = [t.lower_ for t in child.children if t.dep_ == "mark"]
                causal = markers and set(markers) <= {"as", "because", "since"}
                qualified = any(qualifiers(child).get(k) for k in
                    ("negated", "modality", "conditional", "question", "unresolved"))
                if causal and not qualified and not any(t.tag_ == "MD" for t in child.subtree):
                    continue
            unsafe = True
        if governor != action and any(t.dep_ not in {"aux", "dobj", "obj", "punct"}
                or t.dep_ == "aux" and t.lower_ != "to" for t in action.children if not t.is_space):
            unsafe = True
        if unsafe or any(t.is_quote or t.text == "?" for t in governor.sent):
            continue
        if _reporting_tail_holds(base, page, parent["end"], qa):
            continue
        return dict(mode=mode, parent=parent, actor=actor, content_subject=body, clock=clock,
            source_normalization=edits, source_tokens=[_proof(t) for t in _tokens(governor.sent)],
            operator=_proof(governor), action=_proof(action), query_operator=_proof(qr),
            literal_content_signature=_content_signature(qhead, qsubject),
            source_account_only=True, actual_utterance_execution_certified=False,
            narrated_past_convention=mode == "NARRATED_PAST_COMPULSION_REPORTING_CONVENTION")
    return None


def _reporting_row(base, atom, page, unit, control, realization, qdoc, qedits):
    citation = realization["parent"]
    scope = dict(kind="QUERIED_OPERATOR_ONLY", inner_execution_certified=False,
        event_join_certified=False, world_truth_certified=False,
        physical_executor_certified=False, canonical_identity_certified=False)
    proof = dict(version=VERSION, type="ATTRIBUTED_OR_MODAL_QUERIED_ACCOUNT",
        query_sha256=digest(base.case["query"]), atom_sha256=digest(atom),
        citation=deepcopy(citation), parent_citation=deepcopy(citation),
        original_unit_citation=deepcopy(control["citation"]), selected_clause_citation=deepcopy(citation),
        scope=scope, mode=realization["mode"], reporting_realization=realization,
        query_normalization=qedits, source_normalization=realization["source_normalization"],
        query_token_proofs=[_proof(t) for t in _tokens(qdoc)],
        source_token_proofs=realization["source_tokens"],
        full_source_page_sha256=page["source_sha256"],
        qualification_context=_report_context(base, page, citation["end"], actor=_subject(_root(qdoc))),
        source_proof_offset_basis="NORMALIZED_CONTIGUOUS_PARENT_WITH_EXACT_RAW_CITATION",
        complete_literal_account=True, literal_content_with_documented_reporting_realization=True,
        publication_date_used_as_event_time=False, source_text_modified=False,
        no_global_alias_or_identity_inferred=True, strict_control_sha256=digest(control))
    row = deepcopy(control)
    row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
        citation=deepcopy(citation), source_account_match_certificate=proof,
        strict_source_account_match_control=deepcopy(control), support_scope=scope["kind"],
        queried_account_scope=deepcopy(scope), event_bindings=[],
        source_assertion_not_world_truth=True, qualified=True,
        qualified_account="The source reports this attributed statement. Past narrated compulsion is accepted as a qualified reporting construction, with its necessity wording retained; actual performance and truth of the statement are not certified."
            if realization["narrated_past_convention"] else
            "The source ascribes this complete statement to the named speaker; actual performance and truth of its content are not independently certified.",
        actual_inner_event_established=False, actual_utterance_execution_certified=False,
        world_truth_certified=False, canonical_identity_certified=False,
        cross_atom_or_event_join_certified=False,
        account_coverage=dict(matched_tokens=len(_tokens(qdoc)), required_tokens=len(_tokens(qdoc)),
            complete=True, probability=False, basis="EXACT_CONTENT_AND_BOUND_NARRATIVE_REPORTING_REALIZATION"))
    row["checks"] = dict(eligible_source="PASS", raw_quote="PASS", complete_literal_account="PASS",
        named_owner_or_attributed_speaker="PASS", quantity_polarity_modality_roles="PASS",
        raw_qualification_context="PASS", source_reporting_realization="PASS",
        physical_execution="NOT_CERTIFIED", world_truth="NOT_CERTIFIED")
    return row


def supplement(matcher, atom, page, unit, control):
    base = getattr(matcher, "baseline", matcher)
    if (base.case["task"] not in {"hypothesis", "reconstruction"} or atom.get("kind") != "proposition"
            or control.get("direction") not in {"UNRESOLVED", "PARTIAL"}
            or any(control.get(k) for k in ("source_account_policy_withheld", "root_content_withheld",
                "root_content_policy_applicable", "potential_counter", "unbound_material_counter"))):
        return control
    public_plan(base.case, dict(atoms=[atom], query_sha256=digest(base.case["query"])))
    pi = base.positions.get(page.get("id"))
    if pi is None or page != base.corpus.pages[pi] or digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Source account page differs from complete bound raw view")
    a, b = unit["start"], unit["end"]
    citation = base.policy.citation(pi, a, b)
    if citation != control.get("citation") or citation["text"] != unit.get("text", unit.get("quote")):
        raise ValueError("Source account citation does not replay")
    if b - a > 4096 or len(atom["text"]) > 2048:
        return control
    with offline():
        parent = citation
        boundaries = {(u["start"], u["end"]) for u in sentences(page["text"])}
        if (a, b) not in boundaries:
            recovery = unit.get("source_boundary")
            if not recovery:
                return control
            original = recovery.get("parent", {})
            parent = base.policy.citation(pi, original.get("start"), original.get("end"))
            if any(original.get(k) != parent.get(k) for k in ("canonical_page_id", "document_id", "date", "page_sha256", "start", "end", "text")):
                raise ValueError("Recovered account parent does not replay")
            reproduced = recover(page, parent, base.engine.parse)
            if not any((p["start"], p["end"], p["text"]) == (a, b, citation["text"]) for p in reproduced):
                raise ValueError("Unlicensed source-boundary recovery")
        # The relative-account channel licenses its own exact local reference
        # and quotation scope; all existing broad source guards remain below.
        from .source_relative_accounts import supplement as relative_supplement
        relative = relative_supplement(matcher, atom, page, unit, control)
        if relative is not control:
            return relative
        raw_doc = base.engine.parse(parent["text"])
        if (_prefix_blocker(page, parent["start"], base.engine)
                or raw_envelope_holds(base, page, parent, raw_doc)):
            return control
        offset, heading = _heading(citation["text"], base.engine)
        if offset is None:
            return control
        qview, _, qedits = _layout(base.engine, atom["text"])
        source_raw = citation["text"][offset:]
        sview, mapping, sedits = _layout(base.engine, source_raw)
        qdoc, sdoc = base.engine.parse(qview), base.engine.parse(sview)
        query_root = _root(qdoc)
        if (query_root is not None and not any(t.tag_ == "MD" for t in qdoc)
                and any(t.dep_ == "neg" for t in query_root.children)
                and not any(t.ent_type_ == "DATE" for t in qdoc)):
            return control
        if not _public(base, atom, qdoc):
            return control
        realization = _reporting_realization(base, atom, page, unit, control, qdoc)
        if realization is not None:
            return _reporting_row(base, atom, page, unit, control, realization, qdoc, qedits)
        found = None
        opposing = None
        literal_identity = None
        for tokens, root, mode in _branches(sdoc):
            if root is None or not tokens or not _complete(qdoc, named=True):
                continue
            variation = _equal(qdoc, sdoc, tokens, root)
            if variation is not None:
                found = tokens, root, mode, variation, None
                break
            if (mode == "WHOLE_LITERAL_ACCOUNT" and offset == 0 and parent == citation
                    and (a, b) in boundaries):
                identity = _whole_literal_identity(atom["text"], citation["text"], qdoc)
                if identity is not None:
                    from .source_relative_accounts import _tail_holds
                    subject = _subject(query_root)
                    event_terms = {t.lemma_.casefold() for t in query_root.children
                        if t.dep_ in {"dobj", "obj"} and t.pos_ == "NOUN"}
                    if _tail_holds(base, page, b, subject,
                            predicate=query_root.lemma_.casefold(), event_terms=event_terms):
                        return control
                    literal_identity = identity
                    found = tokens, root, "WHOLE_RAW_CASE_WHITESPACE_LITERAL_ACCOUNT", [], None
                    break
            if base.case["task"] == "hypothesis":
                opposition = _opposing(qdoc, sdoc, tokens, root)
                if opposition is not None:
                    found = tokens, root, "LITERAL_OPPOSING_MODAL_ACCOUNT", [], None
                    opposing = opposition
                    break
        if found is None and base.case["task"] == "hypothesis" and _complete(qdoc, named=False):
            root = _root(sdoc)
            qr = _root(qdoc)
            if (root is not None and root.lemma_.casefold() in _ASSERTIVE and _subject(root) is not None
                    and any(t.pos_ == "PROPN" for t in _subject(root).subtree)
                    and not any(qualifiers(root).get(k) for k in ("negated", "modality", "scope", "conditional", "question", "unresolved"))
                    and any(t.tag_ == "MD" and t.lower_ in _MODALS for t in qdoc)):
                leaves = [t for t in root.children if t.dep_ == "ccomp"]
                if len(leaves) == 1 and all(c.dep_ in {"nsubj", "ccomp", "punct"} or c.is_space for c in root.children):
                    leaf = leaves[0]
                    offered = [t for t in _tokens(leaf.subtree) if not (t.dep_ == "mark" and t.head == leaf and t.lower_ == "that")]
                    variation = _equal(qdoc, sdoc, offered, leaf)
                    # Direct ccomp may be promoted to ROOT for this comparison
                    # only; the complete named reporter stays in the proof.
                    if variation is None and [t.text.casefold() for t in _tokens(qdoc)] == [t.text.casefold() for t in offered]:
                        qtokens, positions = _tokens(qdoc), {t.i: i for i, t in enumerate(offered)}
                        if all(q.dep_ == s.dep_ and q.head.i == positions.get(s.head.i)
                               or q.dep_ == "ROOT" and s == leaf for q, s in zip(qtokens, offered)):
                            variation = []
                    opposition = _opposing(qdoc, sdoc, offered, leaf) if variation is None else None
                    if variation is not None or opposition is not None:
                        found = offered, leaf, "ATTRIBUTED_LITERAL_MODAL_STANCE", variation, dict(
                            operator=_proof(root), speaker=[_proof(t) for t in _subject(root).subtree if not t.is_space],
                            complete_parent_retained=True, not_inner_event_truth=True)
                        opposing = opposition
        if found is None:
            return control
        tokens, root, mode, variations, stance = found
        lo, hi = tokens[0].idx, tokens[-1].idx + len(tokens[-1])
        raw_a = mapping[lo] if mapping is not None else lo
        raw_b = mapping[hi - 1] + 1 if mapping is not None else hi
        selected = base.policy.citation(pi, a + offset + raw_a, a + offset + raw_b)
        if literal_identity is not None:
            selected = deepcopy(citation)
        context = _report_context(base, page, selected["end"])
        if context is None:
            return control
        operator = opposing is not None or stance is not None or any(t.tag_ == "MD" for t in qdoc) or _root(qdoc).lemma_.casefold() in _REPORTS
        operator |= any(t.dep_ == "mark" and t.lower_ in {"if", "unless", "whether"} for t in qdoc)
        scope = dict(kind="QUERIED_OPERATOR_ONLY" if operator else "SOURCE_ASCRIPTION",
            inner_execution_certified=False, event_join_certified=False, world_truth_certified=False,
            physical_executor_certified=False, canonical_identity_certified=False)
        proof = dict(version=VERSION, type="ATTRIBUTED_OR_MODAL_QUERIED_ACCOUNT" if operator else "LITERAL_HISTORICAL_SOURCE_ASCRIPTION",
            query_sha256=digest(base.case["query"]), atom_sha256=digest(atom), citation=deepcopy(citation),
            parent_citation=deepcopy(parent), selected_clause_citation=selected, scope=scope,
            mode=mode, heading=heading, attribution=stance, full_source_page_sha256=page["source_sha256"],
            opposing_modal_view=opposing,
            query_normalization=qedits, source_normalization=sedits,
            query_token_proofs=[_proof(t) for t in _tokens(qdoc)], source_token_proofs=[_proof(t) for t in tokens],
            source_proof_offset_basis="NORMALIZED_SOURCE_BODY_WITH_RAW_SELECTED_CLAUSE_CITATION",
            syntax_variations=variations, qualification_context=context, source_text_modified=False,
            complete_literal_account=True, publication_date_used_as_event_time=False,
            no_alias_or_coreference_inferred=True, strict_control_sha256=digest(control))
        if literal_identity is not None:
            proof["whole_raw_unit_literal_identity"] = literal_identity
        row = deepcopy(control)
        row.update(version=VERSION, direction="COUNTER" if opposing else "SUPPORT", complete_required_frames=True,
            source_account_match_certificate=proof, strict_source_account_match_control=deepcopy(control),
            support_scope=scope["kind"], queried_account_scope=deepcopy(scope), event_bindings=[],
            source_assertion_not_world_truth=True, qualified=True,
            qualified_account="The eligible source attests this complete literal account with its operators and attribution preserved; physical execution, world truth and event joins are not certified.",
            actual_inner_event_established=False, world_truth_certified=False,
            canonical_identity_certified=False, cross_atom_or_event_join_certified=False,
            account_coverage=dict(matched_tokens=len(_tokens(qdoc)), required_tokens=len(_tokens(qdoc)),
                complete=True, probability=False, basis="LITERAL_COMPLETE_ACCOUNT_NOT_LEAF_FRAME_OVERLAP"))
        if opposing:
            row["qualified_account"] = "The eligible source records an opposing view with the identical modal, owner and arguments; only explicit root-owned negation differs. This is not world-event refutation."
        row["checks"] = dict(eligible_source="PASS", raw_quote="PASS", complete_literal_account="PASS",
            named_owner_or_attributed_speaker="PASS", quantity_polarity_modality_roles="PASS",
            raw_qualification_context="PASS", physical_execution="NOT_CERTIFIED", world_truth="NOT_CERTIFIED")
        return row


def replay(matcher, atom, page, unit, control, certificate):
    """Trusted producer can regenerate the proof; hashes alone are not authority."""
    from .source_relative_accounts import H_TYPE, M_TYPE, replay as relative_replay
    if certificate.get("type") in {H_TYPE, M_TYPE}:
        return relative_replay(matcher, atom, page, unit, control, certificate)
    result = supplement(matcher, atom, page, unit, control)
    if result.get(PROOF_FIELD) != certificate or certificate.get("version") != VERSION:
        raise ValueError("Source-account proof differs from raw producer replay")
    return deepcopy(certificate)
