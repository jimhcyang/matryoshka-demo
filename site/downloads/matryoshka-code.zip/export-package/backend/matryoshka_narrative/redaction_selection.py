"""Source-local Redaction scheduling and context-only head compatibility.

No discovery, identity dictionary, answer key or factual gate lives here.
Canonical-node families allocate opportunities; they never pool proof or merge
source assertions. Unknown nodes retain separate occurrence identities.
"""
from collections import defaultdict
from copy import deepcopy
import json
import re

from matryoshka_demo.io import digest
from matryoshka_demo.contracts import MASK
from matryoshka_next.source_label_spans import spans as source_label_spans

VERSION = "narrative-source-local-redaction-selection/1.15"
FOCAL_NAME_PRIOR_VERSION = "focal-paragraph-visible-person-negative-prior/1"
NONPERSON = {"Organization", "Government", "Location", "Country", "Military",
             "ReligiousGroup", "PoliticalGroup", "Document"}


class ContextTypeSupportError(RuntimeError):
    """A NER-only compatibility fallback cannot acquire factual authority."""
    def __init__(self, candidate, decision):
        self.candidate, self.decision = deepcopy(candidate), deepcopy(decision)
        super().__init__("Context-only head compatibility received a signed/partial decision; halt without rewriting it")


def _focal_paragraph(case):
    query, marker = case["query"], case["focal_marker"]
    if not isinstance(marker, str) or not marker or query.count(marker) != 1:
        raise ValueError("One exact focal marker is required for paragraph scope")
    at, stop = query.index(marker), query.index(marker) + len(marker)
    line = r"(?:\r\n|\r(?!\n)|(?<!\r)\n)"
    start, end = 0, len(query)
    for boundary in re.finditer(line + r"[ \t]*" + line + r"(?:[ \t]*" + line + r")*", query):
        if boundary.end() <= at:
            start = boundary.end()
        elif boundary.start() >= stop:
            end = boundary.start()
            break
        else:
            raise ValueError("Focal marker intersects a paragraph boundary")
    return dict(start=start, end=end, text=query[start:end]), dict(start=at, end=stop, text=marker)


def focal_name_context(case, parse):
    """Use the legacy full-query NER analysis, then scope its raw coordinates."""
    query, marker = case["query"], case["focal_marker"]
    window, marker_span = _focal_paragraph(case)
    # Match shared._query_features exactly; never parse an isolated paragraph.
    shadow = MASK.sub(lambda m: "thing" + " " * (len(m.group()) - 5)
        if m.group() == marker else " " * len(m.group()), query)
    doc = parse(shadow)
    if doc.text != shadow:
        raise ValueError("Full public-query analysis changed raw coordinates")
    people = []
    for entity in doc.ents:
        proper = [dict(start=t.idx, end=t.idx + len(t), text=query[t.idx:t.idx + len(t)],
            analysis_text=t.text, pos=t.pos_, lemma=t.lemma_.casefold()) for t in entity if t.pos_ == "PROPN"]
        if entity.label_ == "PERSON" and proper:
            people.append(dict(start=entity.start_char, end=entity.end_char,
                text=query[entity.start_char:entity.end_char], proper_tokens=proper))
    return dict(version=FOCAL_NAME_PRIOR_VERSION, query_sha256=digest(query), query_length=len(query),
        analysis_sha256=digest(shadow), analysis="LEGACY_FULL_QUERY_MASK_SHADOW_SAME_OFFSETS",
        focal_marker=marker_span, paragraph=window,
        single_paragraph=not query[:window["start"]].strip() and not query[window["end"]:].strip(),
        person_observations=people, isolated_paragraph_parsed=False,
        identity_or_counterevidence_certified=False)


def focal_name_prior(case, context, page, part, citation):
    """Bind the rank-only observation to this public query and source span."""
    query, window = case["query"], context["paragraph"]
    expected_window, expected_marker = _focal_paragraph(case)
    a, b = part.start_char, part.end_char
    if (context.get("version") != FOCAL_NAME_PRIOR_VERSION or context["query_sha256"] != digest(query)
            or window != expected_window or context["focal_marker"] != expected_marker
            or page["text"] != part.doc.text or digest(page["text"]) != page["source_sha256"]
            or citation["canonical_page_id"] != page["id"] or citation["page_sha256"] != page["source_sha256"]
            or citation["document_id"] != page["document_id"]
            or not citation["start"] <= a < b <= citation["end"]
            or page["text"][citation["start"]:citation["end"]] != citation["text"]):
        raise ValueError("Focal name prior lost its query/source binding")
    payload = dict(query_context=deepcopy(context), source=dict(canonical_page_id=page["id"],
        page_sha256=page["source_sha256"], document_id=page["document_id"], span=[a, b],
        wording=page["text"][a:b], citation_sha256=digest(citation),
        proper_tokens=[dict(start=t.idx, end=t.idx + len(t), text=t.text, pos=t.pos_,
            lemma=t.lemma_.casefold()) for t in part if t.pos_ == "PROPN"]))
    return dict(version=FOCAL_NAME_PRIOR_VERSION, **payload, binding_sha256=digest(payload),
        ranking_only=True, source_features_modified=False, identity_or_counterevidence_certified=False)


def _scoped_name_penalty(occurrence, prior, original):
    payload = {k: prior[k] for k in ("query_context", "source")}
    context, source = payload["query_context"], payload["source"]
    ref, span = occurrence["citation"], occurrence["source_span"]
    if (prior.get("version") != FOCAL_NAME_PRIOR_VERSION or prior["binding_sha256"] != digest(payload)
            or context.get("version") != FOCAL_NAME_PRIOR_VERSION
            or source["span"] != span or source["wording"] != occurrence["source_wording"]
            or source["citation_sha256"] != digest(ref)
            or source["canonical_page_id"] != ref["canonical_page_id"]
            or source["page_sha256"] != ref["page_sha256"]
            or source["document_id"] != ref["document_id"]):
        raise ValueError("Focal name rank observation does not replay its occurrence")
    names = set()
    for token in source["proper_tokens"]:
        a, b = token["start"], token["end"]
        if (token["pos"] != "PROPN" or not span[0] <= a < b <= span[1]
                or source["wording"][a - span[0]:b - span[0]] != token["text"]):
            raise ValueError("Focal name prior has an unbound source POS observation")
        names.add(token["lemma"])
    window = context["paragraph"]
    people = [p for p in context["person_observations"]
        if window["start"] <= p["start"] < p["end"] <= window["end"]]
    scoped = any({t["lemma"] for t in p["proper_tokens"]} <= names for p in people)
    effective = bool(original) if context["single_paragraph"] else bool(original and scoped)
    prior.update(original_whole_query_penalty=bool(original), scoped_person_match=scoped,
        effective_penalty=effective, original_key_index=5, context_rank_key_index=7,
        added_band_credit=2 if original and not effective else 0,
        negative_prior_is_counterevidence=False)
    return effective


def page_types(corpus, pi, page):
    """Own source observations only, including types outside the proposed NP."""
    values = []
    for index in corpus.occurrences_by_page.get(pi, []):
        row = corpus.occurrences[index]
        if row.get("source_type") != "entities" or row.get("page_index") != pi or row.get("node_id") not in corpus.nodes:
            continue
        a, b, label = row.get("start"), row.get("end"), row.get("label")
        if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"]) or not isinstance(label, str) or not label:
            continue
        for match in source_label_spans(page["text"], a, b, label):
            lo, hi = match["start"], match["end"]
            value = dict(start=lo, end=hi, label=page["text"][lo:hi], node_id=row["node_id"],
                source_entity_type=row.get("entity_type"), canonical_page_id=page["id"],
                page_sha256=page["source_sha256"], source_row_id=row.get("source_row_id"))
            if match["mode"] == "UNIQUE_WHITESPACE_ONLY_LAYOUT":
                value["source_label_binding"] = match
            values.append(value)
    return values


def named_example(part, reading, feature, types, *, own_role_context=None):
    applicable = (reading.get("form") == "member_example" and reading.get("role") == "member_example"
                  and feature.get("effective_target_kind") == "person")
    head = part.root
    own = [w for w in types if w["start"] <= head.idx < head.idx+len(head) <= w["end"]]
    kinds = {w["source_entity_type"] for w in own}
    person = [e for e in part.doc.ents if e.label_ == "PERSON" and
        part.start_char <= e.start_char <= head.idx < head.idx+len(head) <= e.end_char <= part.end_char]
    proper = (head.pos_ == "PROPN" and bool(person or "Person" in kinds)
              and not any(t.dep_ == "poss" and t.head in part for t in part)
              and not kinds - {"Person", "Other"})
    role_context = own_role_context or {}
    actor_context = (reading.get("form") == "nominal" and reading.get("role") in
        {"actor_argument", "patient_argument", "recipient_argument", "agent_argument"}
        and feature.get("effective_target_kind") == "any" and kinds == {"Person"}
        and role_context.get("matched") is True
        and (head.pos_ == "NOUN" or head.pos_ == "PROPN" and bool(person)))
    return dict(version=VERSION, named_example_priority=bool(applicable and proper),
        own_person_role_context_priority=bool(actor_context),
        own_role_context=deepcopy(role_context) if actor_context else None,
        raw_source_head=dict(text=head.text, span=[head.idx, head.idx+len(head)]),
        bound_head_nodes=sorted({w["node_id"] for w in own}) if len(kinds) == 1 and not kinds & {"Other",None} else [],
        source_only=True, completed_insertions_parsed=0, factual_support_certified=False,
        source_features_modified=False)


def source_rank(occurrence, original_key):
    if len(original_key) < 8:
        raise ValueError("Source-alignment ordering contract changed")
    cue = occurrence.get("selection_cue", {})
    prior = cue.get("focal_name_prior")
    if prior is not None:
        penalty = _scoped_name_penalty(occurrence, prior, original_key[5])
        original_key = (*original_key[:5], penalty, *original_key[6:])
    alignment = cue.get("property_context_opportunity", {})
    if alignment.get("matched") is True:
        # The carrier can be the head's explicit appositional referent. This
        # adds contextual ordering credit, never a same-event support feature.
        cue["property_carrier_ordering"] = dict(original_carrier_flag=original_key[3],
            source_alignment_sha256=digest(alignment), added_band_credit=8 if original_key[3] else 0,
            ranking_only=True, semantic_source_features_modified=False,
            identity_or_factual_support_certified=False)
        original_key = (*original_key[:3], False, *original_key[4:])
    distance = (cue.get("own_role_context") or {}).get("hypernym_edges")
    ordinal = distance if type(distance) is int and distance >= 0 else 999
    # Lexical role distance cannot overrule the existing source-alignment tiers.
    return (not (cue.get("named_example_priority", False) or cue.get("named_actor_priority",False) or cue.get("owned_activity_priority",False) or cue.get("owned_goal_priority",False)),
            not (cue.get("own_person_role_context_priority", False) or cue.get("owned_goal_priority",False)),
            *original_key[:7], ordinal,not cue.get("visible_anchor_context",{}).get("matched",False), *original_key[7:])


def literal_head_span(candidate, final_form):
    """Map completed head through permitted literal edits, not token search."""
    raw = candidate["source_wording"]
    value = raw
    for edit in candidate.get("insertion_edits", []):
        before, after = edit.get("before"), edit.get("after")
        if before != value:
            return None
        if edit.get("kind") == "EXAMPLE_CONNECTOR_ADDED" and after == "like "+before:
            value = after
        elif edit.get("kind") == "COORDINATE_CONNECTOR_REALIZED" and after=="and "+before:
            value=after
        elif edit.get("kind") == "POSSESSIVE_MARKER_ADDED" and after in {before+"'s", before+"'"}:
            value = after
        else:
            return None
    if value != candidate["fill"] or value.count(raw) != 1:
        return None
    head = final_form.get("entity_head", final_form["head"])
    a, b = (n-final_form["inserted_span"][0] for n in head["span"])
    offset = value.index(raw)
    if not offset <= a < b <= offset+len(raw):
        return None
    return [candidate["source_span"][0]+a-offset, candidate["source_span"][0]+b-offset]


def context_head(candidate, final_form, page, types, parse):
    """Complete source PERSON NER supplies possible slot compatibility only."""
    result = dict(version=VERSION, state="hold", reason="NOT_PERSON_EXAMPLE",
        slot_compatibility_only=True, source_type_match_added=False,
        identity_certified=False, factual_support_certified=False)
    reading = candidate["v6_reading"]
    if (reading.get("form") != "member_example" or reading.get("role") != "member_example"
            or candidate["ranking"]["features"]["effective_target_kind"] != "person"):
        return result
    if digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Source page hash changed")
    a, b = candidate["source_span"]
    if page["text"][a:b] != candidate["source_wording"]:
        raise ValueError("Source constituent changed")
    interval = literal_head_span(candidate, final_form)
    if interval is None:
        return dict(result, reason="LITERAL_COMPLETED_HEAD_MAPPING_UNRESOLVED")
    sa, sb = interval
    doc = parse(page["text"])
    part = doc.char_span(a, b, alignment_mode="strict")
    head = doc.char_span(sa, sb, alignment_mode="strict")
    completed_head = final_form.get("entity_head", final_form["head"])
    if part is None or head is None or len(head) != 1 or head.text != completed_head["text"]:
        return dict(result, reason="COMPLETED_SOURCE_TOKEN_UNRESOLVED")
    own = []
    for w in types:
        lo, hi = w["start"], w["end"]
        if (w.get("canonical_page_id") != page["id"] or w.get("page_sha256") != page["source_sha256"]
                or type(lo) is not int or type(hi) is not int or not 0 <= lo < hi <= len(page["text"])
                or page["text"][lo:hi] != w.get("label")):
            raise ValueError("Type witness is not on its exact source page/span")
        if lo <= sa < sb <= hi:
            own.append(w)
    kinds = {w["source_entity_type"] for w in own}
    result.update(mapped_source_head_span=interval, own_head_types=sorted(str(k) for k in kinds),
        own_type_witnesses=deepcopy(own))
    if kinds - {"Person", "Other"}:
        return dict(result, reason="OWN_HEAD_TYPE_CONFLICT_OR_UNINTERPRETED")
    if head[0].pos_ != "PROPN" or completed_head["pos"] != "PROPN":
        return dict(result, reason="PROPER_SOURCE_AND_COMPLETED_HEAD_REQUIRED")
    if any(t.dep_ == "poss" and t.head in part for t in part):
        return dict(result, reason="NAMED_POSSESSOR_CANNOT_TYPE_POSSESSED_HEAD")
    entities = [e for e in doc.ents if e.label_ == "PERSON" and a <= e.start_char <= sa < sb <= e.end_char <= b]
    if not entities:
        return dict(result, reason="COMPLETE_OWN_SOURCE_PERSON_NER_REQUIRED")
    return dict(result, state="possible", reason="UNKNOWN_KG_HEAD_COMPLETE_RAW_PERSON_NER_CONTEXT_ONLY",
        person_ner=[dict(start=e.start_char, end=e.end_char, text=e.text) for e in entities])


def require_context_decision(candidate, decision):
    if (decision.get("status") not in {"exploratory_contextual", "incompatible_not_viable"}
            or decision.get("support_present") or decision.get("coverage") in {"Established", "Partial"}
            or any(r.get("coverage") in {"Established", "Partial"} for r in decision.get("requirements", []))):
        raise ContextTypeSupportError(candidate, decision)


def literal_reference_kind(candidate, final_form, page, types, parse):
    """Observed same-page spelling supplies possible kind, never identity/proof."""
    result = dict(version=VERSION, state="hold", reason="NOT_NOMINAL_PERSON_REFERENCE",
        slot_compatibility_only=True, source_type_match_added=False,
        identity_certified=False, factual_support_certified=False,
        lexical_reference_only=True)
    reading = candidate["v6_reading"]
    if (reading.get("form") not in {"nominal", "member_example"}
            or candidate["ranking"]["features"]["effective_target_kind"] != "person"
            or final_form.get("state") != "pass"):
        return result
    if digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Literal kind reference lost its source page hash")
    a, b = candidate["source_span"]
    if page["text"][a:b] != candidate["source_wording"]:
        raise ValueError("Literal kind reference lost its source constituent")
    masks = [m.span() for m in MASK.finditer(page["text"])]
    if any(lo < b and a < hi for lo, hi in masks):
        return dict(result, reason="OPAQUE_SOURCE_NAME_IS_NOT_VISIBLE")
    interval = literal_head_span(candidate, final_form)
    if interval is None:
        return dict(result, reason="COMPLETED_SOURCE_HEAD_NOT_BOUND")
    doc = parse(page["text"])
    part = doc.char_span(a, b, alignment_mode="strict")
    if (part is None or part.root.pos_ != "PROPN"
            or [part.root.idx, part.root.idx + len(part.root)] != interval
            or any(t.dep_ == "poss" or t.pos_ not in {"PROPN", "PUNCT", "SPACE"} for t in part)):
        return dict(result, reason="COMPLETE_PROPER_NOMINAL_REQUIRED")
    normalize = lambda text: " ".join(text.casefold().split())
    references = []
    for witness in types:
        lo, hi = witness.get("start"), witness.get("end")
        if (witness.get("canonical_page_id") != page["id"]
                or witness.get("page_sha256") != page["source_sha256"]
                or type(lo) is not int or type(hi) is not int or not 0 <= lo < hi <= len(page["text"])
                or page["text"][lo:hi] != witness.get("label")):
            raise ValueError("Literal kind reference differs from its typed source observation")
        if any(left < hi and lo < right for left, right in masks):
            continue
        same_spelling = normalize(witness["label"]) == normalize(part.text)
        owns_head = lo <= interval[0] < interval[1] <= hi
        if same_spelling or owns_head:
            kind = witness.get("source_entity_type")
            if kind not in {"Person", "Other"}:
                return dict(result, reason="SOURCE_KIND_REFERENCE_CONFLICT")
            if same_spelling and kind == "Person":
                references.append(deepcopy(witness))
    if not references:
        return dict(result, reason="NO_COMPLETE_SAME_PAGE_PERSON_SPELLING")
    return dict(result, state="possible", reason="OBSERVED_PERSON_NAME_REFERENCE_CONTEXT_ONLY",
        source_name_span=[a, b], mapped_source_head_span=interval,
        typed_reference_observations=references, node_assigned=False,
        new_alias_or_identity_join=False)


def bind_decision_sources(decision, pages):
    """Replay legacy quotes before supplying an omitted corpus field only."""
    value = deepcopy(decision)
    additions = []
    def visit(row):
        if isinstance(row, dict):
            if {"canonical_page_id", "page_sha256", "text", "start", "end"} <= row.keys():
                page = pages.get(row["canonical_page_id"])
                a, b = row["start"], row["end"]
                if (page is None or type(a) is not int or type(b) is not int
                        or not 0 <= a < b <= len(page["text"])
                        or row["text"] != page["text"][a:b]
                        or row["page_sha256"] != page["source_sha256"]
                        or row.get("document_id") != page["document_id"] or row.get("date") != page["date"]
                        or row.get("corpus", page["corpus"]) != page["corpus"]):
                    raise ValueError("Gate citation is not bound to its inspected source page")
                if "corpus" not in row:
                    row["corpus"] = page["corpus"]
                    additions.append(dict(canonical_page_id=page["id"], start=a, end=b, corpus=page["corpus"]))
            for child in row.values():
                visit(child)
        elif isinstance(row, (list, tuple)):
            for child in row:
                visit(child)
    visit(value)
    return value, dict(version="narrative-legacy-gate-source-metadata-binding/1",
        original_gate_decision_sha256=digest(decision), bound_decision_sha256=digest(value),
        added_corpus_fields=additions, signs_or_scope_or_requirements_changed=False)


def family_key(group):
    """Same bound head, page, exact unit, argument and qualifier context only."""
    o = group["primary"]
    cue = o.get("selection_cue", {})
    nodes = cue.get("bound_head_nodes", [])
    ref = o["citation"]
    if len(nodes) != 1:
        return "unmerged_"+digest([group["reading"]["id"], ref, o["source_span"], group["fill"]])
    f = o["features"]
    context = {k: f.get(k) for k in ("effective_target_kind", "source_argument_role", "source_clause_constraints",
        "source_owner_constraints", "source_carrier", "source_owned_role_context")}
    role = context["source_owned_role_context"]
    if isinstance(role, dict):
        # A wording's debug extent is not a different owner/role assertion.
        # Keep every actual role, owner, qualification and scope discriminator.
        context["source_owned_role_context"] = {k:v for k,v in role.items() if k != "source_candidate_span"}
    return "source_family_"+digest([group["reading"]["id"], nodes[0], ref["canonical_page_id"],
        ref["page_sha256"], ref["start"], ref["end"],
        context])


def diverse_order(groups):
    families = {}
    for g in groups:
        families.setdefault(g["alternative_family"], []).append(g)
    out, depth = [], 0
    while len(out) < len(groups):
        for values in families.values():
            if depth < len(values):
                out.append(values[depth])
        depth += 1
    return out


def _opportunity_views(groups):
    from . import opportunity_allocation as opportunities
    values = [dict(reading_id=g["reading"]["id"], alternative_family=g["alternative_family"],
        node_id=g["node_id"], fill=g["fill"], rank_key=g["key"],
        original_reading=g.get("original_reading"), occurrences=[g["primary"]],
        scheduling=g.get("scheduling", {})) for g in groups]
    # Live role/scope tuples and persisted JSON lists have one declared wire
    # representation. Never mutate or substitute the original gate inputs.
    return json.loads(opportunities.canonical(values))


def source_form_opportunities(groups):
    """Interleave literal and source-licensed representations, without evidence credit."""
    literal, realized = [], []
    for group in groups:
        audit = group["primary"].get("lexical_realization")
        licensed = (isinstance(audit, dict) and audit.get("state") == "licensed"
            and audit.get("source_nominated_before_realization") is True
            and audit.get("used_as_retrieval_seed") is False
            and audit.get("factual_support_certified") is False)
        (realized if licensed else literal).append(group)
    if not realized:
        return list(groups)
    ordered = []
    for i in range(max(len(literal), len(realized))):
        if i < len(literal):
            ordered.append(literal[i])
        if i < len(realized):
            ordered.append(realized[i])
    return ordered


def source_shape_opportunities(groups):
    """Prefer source heads compatible with a declared nominal/numeric reading.

    This is an allocation hint, never an insertion pass or a factual witness.
    Incompatible hints remain in the tail; actual completed-form gates decide.
    Other families retain the existing source-form opportunity order.
    """
    groups = list(groups)
    if not groups:
        return groups
    declared = groups[0]["original_reading"]
    if any(g["original_reading"] != declared for g in groups):
        raise ValueError("Shape opportunities require one unchanged declared reading")
    family = declared.get("outer_family")
    numeric = family == "nominal_specifier" and declared.get("variant") == "numeric_quantity"
    if family != "nominal" and not numeric:
        return source_form_opportunities(groups)
    preferred, tail = [], []
    for group in groups:
        primary = group["primary"]
        head = primary.get("source_head", {})
        pos, tag = head.get("pos"), head.get("tag")
        matched = pos == "NUM" if numeric else (pos in {"NOUN", "PROPN", "PRON"}
            or bool(primary.get("activity_projection") and tag == "VBG"))
        group["source_shape_opportunity"] = dict(version="source-head-shape-opportunity/1",
            family=family, variant=declared.get("variant"), observed_pos=pos, observed_tag=tag,
            preferred=matched, allocation_only=True, completed_insertion_checked=False,
            factual_support_certified=False, incompatible_hint_excludes_candidate=False)
        group.setdefault("scheduling", {})["source_shape_opportunity"] = dict(group["source_shape_opportunity"])
        (preferred if matched else tail).append(group)
    return preferred + tail


def allocate(groups, cue_order, baseline_pages, budget, *, focal_fraction=.25,
             cue_order_mode="source_priority", supplemental_mode="legacy", query_sha256=None):
    """Fixed check cap with an explicitly declared alternative cue order."""
    if cue_order_mode not in {"source_priority", "focal_sentence", "source_alignment"}:
        raise ValueError("Unknown supplemental cue ordering")
    if supplemental_mode not in {"legacy", "source_head_opportunities", "source_form_opportunities", "source_shape_opportunities"}:
        raise ValueError("Unknown supplemental opportunity mode")
    for group in cue_order:
        if len(group["key"]) < 10:
            raise ValueError("Source-fit ordering contract changed")
        if cue_order_mode == "focal_sentence":
            scheduling = group.get("scheduling")
            score = scheduling.get("literal_sentence_score") if isinstance(scheduling, dict) else None
            if (not isinstance(score, (list, tuple)) or len(score) != 2
                    or any(type(n) is not int or n < 0 for n in score)):
                raise ValueError("Sentence cues require two observed nonnegative integer counts")
    def cue_key(row):
        i, group = row
        overlap = (tuple(-n for n in group["scheduling"]["literal_sentence_score"])
            if cue_order_mode == "focal_sentence" else ())
        alignment = (not group["primary"].get("selection_cue", {}).get("property_context_opportunity", {}).get("matched", False),) if cue_order_mode == "source_alignment" else ()
        return (group["reading"]["id"], *alignment, *overlap, *group["key"][:11], i)
    cue_order = [group for _, group in sorted(enumerate(cue_order), key=cue_key)]
    by_reading = defaultdict(list)
    for group in groups:
        group.update(alternative_family=family_key(group), evaluation_lanes=[], checked=False,
            focal_assessed=False, assessment_state="UNASSESSED", assessment_reason="NOT_ALLOCATED")
        by_reading[group["reading"]["id"]].append(group)
    if type(focal_fraction) not in (int, float) or not 0 <= focal_fraction <= 1:
        raise ValueError("Declared focal check fraction between zero and one required")
    primary_cap = max(1, budget-int(budget*focal_fraction))
    cue_cap = budget-primary_cap
    chosen = []
    for rid, values in sorted(by_reading.items()):
        base = [g for g in values if g["primary"]["citation"]["canonical_page_id"] in baseline_pages]
        base.sort(key=lambda g: g["key"])
        primary = diverse_order(base)[:primary_cap]
        if supplemental_mode == "source_head_opportunities":
            from . import opportunity_allocation as opportunities
            # The constructor already chose each primary observation. Preserve
            # all other occurrences for downstream gates, not as pooled proof.
            views = _opportunity_views(values)
            positions = {id(g): i for i, g in enumerate(values)}
            if query_sha256 is not None:
                from . import visible_apposition_order
                receipt = visible_apposition_order.allocate(views, [positions[id(g)] for g in primary],
                    query_sha256, budget=budget, primary_cap=primary_cap)
            else:
                receipt = opportunities.allocate(views, [positions[id(g)] for g in primary],
                    budget=budget, primary_cap=primary_cap)
            selected = [values[i] for i in receipt["indices"]]
            metadata = {r["index"]: r for r in receipt["selection_metadata"]}
            for i, g in enumerate(values):
                g["allocation_input_index"] = i
                g["allocation_opportunity"] = metadata.get(i)
            if selected:
                selected[0]["allocation_receipt"] = receipt
        else:
            cue = diverse_order([g for g in cue_order if g["reading"]["id"] == rid and g not in primary])
            if supplemental_mode == "source_form_opportunities":
                cue = source_form_opportunities(cue)
            elif supplemental_mode == "source_shape_opportunities":
                cue = source_shape_opportunities(cue)
            cue = cue[:cue_cap]
            selected = primary+cue
        # A scarce primary lane can use remaining unspent opportunities, with
        # exact actual checks recorded. No source or factual gate is weakened.
        if supplemental_mode in {"legacy", "source_form_opportunities", "source_shape_opportunities"} and len(selected) < budget:
            selected += diverse_order([g for g in values if g not in selected])[:budget-len(selected)]
        for g in selected:
            g["evaluation_lanes"] = ["PRIMARY_SOURCE_FAMILY" if g in primary else
                "SUPPLEMENTAL_SOURCE_HEAD_OPPORTUNITY" if supplemental_mode == "source_head_opportunities"
                else "SUPPLEMENTAL_VISIBLE_CUE"]
        chosen.extend(selected)
    for g in groups:
        g["selected_for_evaluation"] = bool(g["evaluation_lanes"])
        g["initial_opportunity_allocated"] = g["selected_for_evaluation"]
    return chosen+[g for g in cue_order if not g["selected_for_evaluation"]]


def queue_family_fallback(group, attempt, ordered, execution_order):
    options = [g for g in ordered if g is not group and not g["checked"]
               and g["alternative_family"] == group["alternative_family"]]
    if not options:
        return
    next_group = options[0]
    if next_group in execution_order:
        execution_order.remove(next_group)
    execution_order.insert(attempt,next_group)
    next_group["selected_for_evaluation"] = True
    next_group["evaluation_lanes"].append("SAME_UNIT_FAMILY_FALLBACK_WITHIN_CHECK_CAP")


def shortlist(values, top_k, *, context_keys=None, ordering_tiers=None):
    """Keep separate evidence tiers and complete raw candidate observations."""
    if context_keys is not None and (not isinstance(context_keys, dict)
            or set(context_keys) != {c["id"] for c in values}):
        raise ValueError("Context keys must bind the complete viable reading pool")
    tiers = {"evidence_backed_suggestion": 0, "partial_grounding": 1, "exploratory_contextual": 2}
    if ordering_tiers is not None:
        if (not isinstance(ordering_tiers, dict) or set(ordering_tiers) != {c["id"] for c in values}
                or any(type(ordering_tiers[c["id"]]) is not int
                    or not tiers.get(c["local_decision"]["status"], 3) <= ordering_tiers[c["id"]] <= 3
                    or c["local_decision"]["status"] == "evidence_backed_suggestion" and ordering_tiers[c["id"]] != 0
                    for c in values)):
            raise ValueError("Ordering tiers may only demote, never promote or demote full evidence")
    ordered = sorted(values, key=lambda c: (tiers.get(c["local_decision"]["status"], 3)
        if ordering_tiers is None else ordering_tiers[c["id"]],
        c["context_rank_key"] if context_keys is None else context_keys[c["id"]], c["source_rank_position"]))
    selected, families = [], {}
    for candidate in ordered:
        d = candidate["local_decision"]
        key = (candidate["alternative_family"], d["status"], d.get("scope"),
               digest([(u["id"], u.get("coverage"), u.get("direction")) for u in d.get("requirements", [])]),
               bool(d.get("counterevidence")))
        if key in families:
            families[key].setdefault("assessed_source_alternatives", []).append(dict(
                id=candidate["id"], fill=candidate["fill"], local_decision=deepcopy(d),
                sources=deepcopy(candidate["sources"]), proof_merged=False))
            continue
        families[key] = candidate
        if len(selected) < top_k:
            selected.append(candidate)
    return selected
