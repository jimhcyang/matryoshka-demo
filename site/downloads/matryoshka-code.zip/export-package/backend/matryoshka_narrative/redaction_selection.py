"""Source-local Redaction scheduling and context-only head compatibility.

No discovery, identity dictionary, answer key or factual gate lives here.
Canonical-node families allocate opportunities; they never pool proof or merge
source assertions. Unknown nodes retain separate occurrence identities.
"""
from collections import defaultdict
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_demo.contracts import MASK

VERSION = "narrative-source-local-redaction-selection/1.10"
NONPERSON = {"Organization", "Government", "Location", "Country", "Military",
             "ReligiousGroup", "PoliticalGroup", "Document"}


class ContextTypeSupportError(RuntimeError):
    """A NER-only compatibility fallback cannot acquire factual authority."""
    def __init__(self, candidate, decision):
        self.candidate, self.decision = deepcopy(candidate), deepcopy(decision)
        super().__init__("Context-only head compatibility received a signed/partial decision; halt without rewriting it")


def page_types(corpus, pi, page):
    """Own source observations only, including types outside the proposed NP."""
    values = []
    for index in corpus.occurrences_by_page.get(pi, []):
        row = corpus.occurrences[index]
        if row.get("source_type") != "entities" or row.get("page_index") != pi or row.get("node_id") not in corpus.nodes:
            continue
        a, b, label = row.get("start"), row.get("end"), row.get("label")
        if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"]) or not isinstance(label, str) or not label:
            continue
        for match in re.finditer(r"(?<!\w)"+re.escape(label)+r"(?!\w)", page["text"][a:b], re.I):
            lo, hi = a+match.start(), a+match.end()
            values.append(dict(start=lo, end=hi, label=page["text"][lo:hi], node_id=row["node_id"],
                source_entity_type=row.get("entity_type"), canonical_page_id=page["id"],
                page_sha256=page["source_sha256"], source_row_id=row.get("source_row_id")))
    return values


def named_example(part, reading, feature, types, *, own_role_context=None):
    applicable = (reading.get("form") == "member_example" and reading.get("role") == "member_example"
                  and feature.get("effective_target_kind") == "person")
    head = part.root
    own = [w for w in types if w["start"] <= head.idx < head.idx+len(head) <= w["end"]]
    kinds = {w["source_entity_type"] for w in own}
    person = [e for e in part.doc.ents if e.label_ == "PERSON" and
        part.start_char <= e.start_char <= head.idx < head.idx+len(head) <= e.end_char <= part.end_char]
    proper = (head.pos_ == "PROPN" and bool(person or "Person" in kinds)
              and not any(t.dep_ == "poss" and t.head in part for t in part)
              and not kinds - {"Person", "Other"})
    role_context = own_role_context or {}
    actor_context = (reading.get("form") == "nominal" and reading.get("role") in
        {"actor_argument", "patient_argument", "recipient_argument", "agent_argument"}
        and feature.get("effective_target_kind") == "any" and kinds == {"Person"}
        and role_context.get("matched") is True
        and (head.pos_ == "NOUN" or head.pos_ == "PROPN" and bool(person)))
    return dict(version=VERSION, named_example_priority=bool(applicable and proper),
        own_person_role_context_priority=bool(actor_context),
        own_role_context=deepcopy(role_context) if actor_context else None,
        raw_source_head=dict(text=head.text, span=[head.idx, head.idx+len(head)]),
        bound_head_nodes=sorted({w["node_id"] for w in own}) if len(kinds) == 1 and not kinds & {"Other",None} else [],
        source_only=True, completed_insertions_parsed=0, factual_support_certified=False,
        source_features_modified=False)


def source_rank(occurrence, original_key):
    if len(original_key) < 8:
        raise ValueError("Source-alignment ordering contract changed")
    cue = occurrence.get("selection_cue", {})
    distance = (cue.get("own_role_context") or {}).get("hypernym_edges")
    ordinal = distance if type(distance) is int and distance >= 0 else 999
    # Lexical role distance cannot overrule the existing source-alignment tiers.
    return (not (cue.get("named_example_priority", False) or cue.get("named_actor_priority",False) or cue.get("owned_activity_priority",False) or cue.get("owned_goal_priority",False)),
            not (cue.get("own_person_role_context_priority", False) or cue.get("owned_goal_priority",False)),
            *original_key[:7], ordinal,not cue.get("visible_anchor_context",{}).get("matched",False), *original_key[7:])


def literal_head_span(candidate, final_form):
    """Map completed head through permitted literal edits, not token search."""
    raw = candidate["source_wording"]
    value = raw
    for edit in candidate.get("insertion_edits", []):
        before, after = edit.get("before"), edit.get("after")
        if before != value:
            return None
        if edit.get("kind") == "EXAMPLE_CONNECTOR_ADDED" and after == "like "+before:
            value = after
        elif edit.get("kind") == "COORDINATE_CONNECTOR_REALIZED" and after=="and "+before:
            value=after
        elif edit.get("kind") == "POSSESSIVE_MARKER_ADDED" and after in {before+"'s", before+"'"}:
            value = after
        else:
            return None
    if value != candidate["fill"] or value.count(raw) != 1:
        return None
    head = final_form.get("entity_head", final_form["head"])
    a, b = (n-final_form["inserted_span"][0] for n in head["span"])
    offset = value.index(raw)
    if not offset <= a < b <= offset+len(raw):
        return None
    return [candidate["source_span"][0]+a-offset, candidate["source_span"][0]+b-offset]


def context_head(candidate, final_form, page, types, parse):
    """Complete source PERSON NER supplies possible slot compatibility only."""
    result = dict(version=VERSION, state="hold", reason="NOT_PERSON_EXAMPLE",
        slot_compatibility_only=True, source_type_match_added=False,
        identity_certified=False, factual_support_certified=False)
    reading = candidate["v6_reading"]
    if (reading.get("form") != "member_example" or reading.get("role") != "member_example"
            or candidate["ranking"]["features"]["effective_target_kind"] != "person"):
        return result
    if digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Source page hash changed")
    a, b = candidate["source_span"]
    if page["text"][a:b] != candidate["source_wording"]:
        raise ValueError("Source constituent changed")
    interval = literal_head_span(candidate, final_form)
    if interval is None:
        return dict(result, reason="LITERAL_COMPLETED_HEAD_MAPPING_UNRESOLVED")
    sa, sb = interval
    doc = parse(page["text"])
    part = doc.char_span(a, b, alignment_mode="strict")
    head = doc.char_span(sa, sb, alignment_mode="strict")
    completed_head = final_form.get("entity_head", final_form["head"])
    if part is None or head is None or len(head) != 1 or head.text != completed_head["text"]:
        return dict(result, reason="COMPLETED_SOURCE_TOKEN_UNRESOLVED")
    own = []
    for w in types:
        lo, hi = w["start"], w["end"]
        if (w.get("canonical_page_id") != page["id"] or w.get("page_sha256") != page["source_sha256"]
                or type(lo) is not int or type(hi) is not int or not 0 <= lo < hi <= len(page["text"])
                or page["text"][lo:hi] != w.get("label")):
            raise ValueError("Type witness is not on its exact source page/span")
        if lo <= sa < sb <= hi:
            own.append(w)
    kinds = {w["source_entity_type"] for w in own}
    result.update(mapped_source_head_span=interval, own_head_types=sorted(str(k) for k in kinds),
        own_type_witnesses=deepcopy(own))
    if kinds - {"Person", "Other"}:
        return dict(result, reason="OWN_HEAD_TYPE_CONFLICT_OR_UNINTERPRETED")
    if head[0].pos_ != "PROPN" or completed_head["pos"] != "PROPN":
        return dict(result, reason="PROPER_SOURCE_AND_COMPLETED_HEAD_REQUIRED")
    if any(t.dep_ == "poss" and t.head in part for t in part):
        return dict(result, reason="NAMED_POSSESSOR_CANNOT_TYPE_POSSESSED_HEAD")
    entities = [e for e in doc.ents if e.label_ == "PERSON" and a <= e.start_char <= sa < sb <= e.end_char <= b]
    if not entities:
        return dict(result, reason="COMPLETE_OWN_SOURCE_PERSON_NER_REQUIRED")
    return dict(result, state="possible", reason="UNKNOWN_KG_HEAD_COMPLETE_RAW_PERSON_NER_CONTEXT_ONLY",
        person_ner=[dict(start=e.start_char, end=e.end_char, text=e.text) for e in entities])


def require_context_decision(candidate, decision):
    if (decision.get("status") not in {"exploratory_contextual", "incompatible_not_viable"}
            or decision.get("support_present") or decision.get("coverage") in {"Established", "Partial"}
            or any(r.get("coverage") in {"Established", "Partial"} for r in decision.get("requirements", []))):
        raise ContextTypeSupportError(candidate, decision)


def literal_reference_kind(candidate, final_form, page, types, parse):
    """Observed same-page spelling supplies possible kind, never identity/proof."""
    result = dict(version=VERSION, state="hold", reason="NOT_NOMINAL_PERSON_REFERENCE",
        slot_compatibility_only=True, source_type_match_added=False,
        identity_certified=False, factual_support_certified=False,
        lexical_reference_only=True)
    reading = candidate["v6_reading"]
    if (reading.get("form") not in {"nominal", "member_example"}
            or candidate["ranking"]["features"]["effective_target_kind"] != "person"
            or final_form.get("state") != "pass"):
        return result
    if digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Literal kind reference lost its source page hash")
    a, b = candidate["source_span"]
    if page["text"][a:b] != candidate["source_wording"]:
        raise ValueError("Literal kind reference lost its source constituent")
    masks = [m.span() for m in MASK.finditer(page["text"])]
    if any(lo < b and a < hi for lo, hi in masks):
        return dict(result, reason="OPAQUE_SOURCE_NAME_IS_NOT_VISIBLE")
    interval = literal_head_span(candidate, final_form)
    if interval is None:
        return dict(result, reason="COMPLETED_SOURCE_HEAD_NOT_BOUND")
    doc = parse(page["text"])
    part = doc.char_span(a, b, alignment_mode="strict")
    if (part is None or part.root.pos_ != "PROPN"
            or [part.root.idx, part.root.idx + len(part.root)] != interval
            or any(t.dep_ == "poss" or t.pos_ not in {"PROPN", "PUNCT", "SPACE"} for t in part)):
        return dict(result, reason="COMPLETE_PROPER_NOMINAL_REQUIRED")
    normalize = lambda text: " ".join(text.casefold().split())
    references = []
    for witness in types:
        lo, hi = witness.get("start"), witness.get("end")
        if (witness.get("canonical_page_id") != page["id"]
                or witness.get("page_sha256") != page["source_sha256"]
                or type(lo) is not int or type(hi) is not int or not 0 <= lo < hi <= len(page["text"])
                or page["text"][lo:hi] != witness.get("label")):
            raise ValueError("Literal kind reference differs from its typed source observation")
        if any(left < hi and lo < right for left, right in masks):
            continue
        same_spelling = normalize(witness["label"]) == normalize(part.text)
        owns_head = lo <= interval[0] < interval[1] <= hi
        if same_spelling or owns_head:
            kind = witness.get("source_entity_type")
            if kind not in {"Person", "Other"}:
                return dict(result, reason="SOURCE_KIND_REFERENCE_CONFLICT")
            if same_spelling and kind == "Person":
                references.append(deepcopy(witness))
    if not references:
        return dict(result, reason="NO_COMPLETE_SAME_PAGE_PERSON_SPELLING")
    return dict(result, state="possible", reason="OBSERVED_PERSON_NAME_REFERENCE_CONTEXT_ONLY",
        source_name_span=[a, b], mapped_source_head_span=interval,
        typed_reference_observations=references, node_assigned=False,
        new_alias_or_identity_join=False)


def bind_decision_sources(decision, pages):
    """Replay legacy quotes before supplying an omitted corpus field only."""
    value = deepcopy(decision)
    additions = []
    def visit(row):
        if isinstance(row, dict):
            if {"canonical_page_id", "page_sha256", "text", "start", "end"} <= row.keys():
                page = pages.get(row["canonical_page_id"])
                a, b = row["start"], row["end"]
                if (page is None or type(a) is not int or type(b) is not int
                        or not 0 <= a < b <= len(page["text"])
                        or row["text"] != page["text"][a:b]
                        or row["page_sha256"] != page["source_sha256"]
                        or row.get("document_id") != page["document_id"] or row.get("date") != page["date"]
                        or row.get("corpus", page["corpus"]) != page["corpus"]):
                    raise ValueError("Gate citation is not bound to its inspected source page")
                if "corpus" not in row:
                    row["corpus"] = page["corpus"]
                    additions.append(dict(canonical_page_id=page["id"], start=a, end=b, corpus=page["corpus"]))
            for child in row.values():
                visit(child)
        elif isinstance(row, (list, tuple)):
            for child in row:
                visit(child)
    visit(value)
    return value, dict(version="narrative-legacy-gate-source-metadata-binding/1",
        original_gate_decision_sha256=digest(decision), bound_decision_sha256=digest(value),
        added_corpus_fields=additions, signs_or_scope_or_requirements_changed=False)


def family_key(group):
    """Same bound head, page, exact unit, argument and qualifier context only."""
    o = group["primary"]
    cue = o.get("selection_cue", {})
    nodes = cue.get("bound_head_nodes", [])
    ref = o["citation"]
    if len(nodes) != 1:
        return "unmerged_"+digest([group["reading"]["id"], ref, o["source_span"], group["fill"]])
    f = o["features"]
    context = {k: f.get(k) for k in ("effective_target_kind", "source_argument_role", "source_clause_constraints",
        "source_owner_constraints", "source_carrier", "source_owned_role_context")}
    role = context["source_owned_role_context"]
    if isinstance(role, dict):
        # A wording's debug extent is not a different owner/role assertion.
        # Keep every actual role, owner, qualification and scope discriminator.
        context["source_owned_role_context"] = {k:v for k,v in role.items() if k != "source_candidate_span"}
    return "source_family_"+digest([group["reading"]["id"], nodes[0], ref["canonical_page_id"],
        ref["page_sha256"], ref["start"], ref["end"],
        context])


def diverse_order(groups):
    families = {}
    for g in groups:
        families.setdefault(g["alternative_family"], []).append(g)
    out, depth = [], 0
    while len(out) < len(groups):
        for values in families.values():
            if depth < len(values):
                out.append(values[depth])
        depth += 1
    return out


def allocate(groups, cue_order, baseline_pages, budget, *, focal_fraction=.25,
             cue_order_mode="source_priority"):
    """Fixed check cap with an explicitly declared alternative cue order."""
    if cue_order_mode not in {"source_priority", "focal_sentence"}:
        raise ValueError("Unknown supplemental cue ordering")
    for group in cue_order:
        if len(group["key"]) < 10:
            raise ValueError("Source-fit ordering contract changed")
        if cue_order_mode == "focal_sentence":
            scheduling = group.get("scheduling")
            score = scheduling.get("literal_sentence_score") if isinstance(scheduling, dict) else None
            if (not isinstance(score, (list, tuple)) or len(score) != 2
                    or any(type(n) is not int or n < 0 for n in score)):
                raise ValueError("Sentence cues require two observed nonnegative integer counts")
    def cue_key(row):
        i, group = row
        overlap = (tuple(-n for n in group["scheduling"]["literal_sentence_score"])
            if cue_order_mode == "focal_sentence" else ())
        return (group["reading"]["id"], *overlap, *group["key"][:11], i)
    cue_order = [group for _, group in sorted(enumerate(cue_order), key=cue_key)]
    by_reading = defaultdict(list)
    for group in groups:
        group.update(alternative_family=family_key(group), evaluation_lanes=[], checked=False,
            focal_assessed=False, assessment_state="UNASSESSED", assessment_reason="NOT_ALLOCATED")
        by_reading[group["reading"]["id"]].append(group)
    if type(focal_fraction) not in (int, float) or not 0 <= focal_fraction <= 1:
        raise ValueError("Declared focal check fraction between zero and one required")
    primary_cap = max(1, budget-int(budget*focal_fraction))
    cue_cap = budget-primary_cap
    chosen = []
    for rid, values in sorted(by_reading.items()):
        base = [g for g in values if g["primary"]["citation"]["canonical_page_id"] in baseline_pages]
        base.sort(key=lambda g: g["key"])
        primary = diverse_order(base)[:primary_cap]
        cue = diverse_order([g for g in cue_order if g["reading"]["id"] == rid and g not in primary])[:cue_cap]
        selected = primary+cue
        # A scarce primary lane can use remaining unspent opportunities, with
        # exact actual checks recorded. No source or factual gate is weakened.
        if len(selected) < budget:
            selected += diverse_order([g for g in values if g not in selected])[:budget-len(selected)]
        for g in selected:
            g["evaluation_lanes"] = ["PRIMARY_SOURCE_FAMILY" if g in primary else "SUPPLEMENTAL_VISIBLE_CUE"]
        chosen.extend(selected)
    for g in groups:
        g["selected_for_evaluation"] = bool(g["evaluation_lanes"])
        g["initial_opportunity_allocated"] = g["selected_for_evaluation"]
    return chosen+[g for g in cue_order if not g["selected_for_evaluation"]]


def queue_family_fallback(group, attempt, ordered, execution_order):
    options = [g for g in ordered if g is not group and not g["checked"]
               and g["alternative_family"] == group["alternative_family"]]
    if not options:
        return
    next_group = options[0]
    if next_group in execution_order:
        execution_order.remove(next_group)
    execution_order.insert(attempt,next_group)
    next_group["selected_for_evaluation"] = True
    next_group["evaluation_lanes"].append("SAME_UNIT_FAMILY_FALLBACK_WITHIN_CHECK_CAP")


def shortlist(values, top_k, *, context_keys=None):
    """Keep separate evidence tiers and complete raw candidate observations."""
    if context_keys is not None and (not isinstance(context_keys, dict)
            or set(context_keys) != {c["id"] for c in values}):
        raise ValueError("Context keys must bind the complete viable reading pool")
    tiers = {"evidence_backed_suggestion": 0, "partial_grounding": 1, "exploratory_contextual": 2}
    ordered = sorted(values, key=lambda c: (tiers.get(c["local_decision"]["status"], 3),
        c["context_rank_key"] if context_keys is None else context_keys[c["id"]], c["source_rank_position"]))
    selected, families = [], {}
    for candidate in ordered:
        d = candidate["local_decision"]
        key = (candidate["alternative_family"], d["status"], d.get("scope"),
               digest([(u["id"], u.get("coverage"), u.get("direction")) for u in d.get("requirements", [])]),
               bool(d.get("counterevidence")))
        if key in families:
            families[key].setdefault("assessed_source_alternatives", []).append(dict(
                id=candidate["id"], fill=candidate["fill"], local_decision=deepcopy(d),
                sources=deepcopy(candidate["sources"]), proof_merged=False))
            continue
        families[key] = candidate
        if len(selected) < top_k:
            selected.append(candidate)
    return selected
