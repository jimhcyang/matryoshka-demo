"""Unadopted V5 experiment: a root operator's content is not inner execution.

The unchanged V4 matcher owns admission, quotation replay and frame analysis.
This opt-in helper only certifies a literal positive past query-root operator
whose direct xcomp content matches without assigning that content an actor.
"""
from copy import deepcopy

from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import scope_matching as scoped
from . import matching as baseline

VERSION = "narrative-root-nonfactive-content-experiment/5.1"
_OPERATORS = {"consider", "plan", "intend", "hope", "want", "wish", "expect",
    "propose", "seek", "attempt", "try", "agree"}
_GOOD = {"MATCH", "UNSPECIFIED"}


def _owned_clock(operator):
    auxiliaries = [t for t in operator.children if t.dep_ in {"aux", "auxpass", "cop"}]
    if any(t.tag_ == "MD" for t in auxiliaries):
        return None
    finite = [t for t in (operator, *auxiliaries) if t.tag_ in {"VBD", "VBP", "VBZ"}]
    if len(finite) != 1:
        return None
    return dict(tense="past" if finite[0].tag_ == "VBD" else "present",
        progressive=operator.tag_ == "VBG" and any(t.lemma_.casefold() == "be" for t in auxiliaries),
        perfect=any(t.lemma_.casefold() == "have" for t in auxiliaries),
        finite_proof=scoped.matching.proof(finite[0]),
        auxiliary_proofs=[scoped.matching.proof(t) for t in auxiliaries])


def _independent_source_branch(operator):
    if operator.dep_ == "ROOT":
        return "ROOT_WITH_OWN_SUBJECT_AND_FINITE_CLOCK"
    node = operator
    while node.dep_ == "conj":
        node = node.head
    if node.dep_ == "ROOT":
        return "INDEPENDENT_CONJ_WITH_OWN_SUBJECT_AND_FINITE_CLOCK"
    return None


def _operator_context(operator):
    q = scoped.matching.qualifiers(operator)
    if any(q.get(k) for k in ("negated", "modality", "scope", "attribution", "conditional",
            "question", "epistemic_absence", "unresolved", "role_qualifiers")):
        return None
    subjects = [t for t in operator.children if t.dep_ == "nsubj"]
    if len(subjects) != 1 or subjects[0].pos_ != "PROPN":
        return None
    phrase = scoped.matching.phrase(subjects[0])
    if not phrase["names"] or phrase["unresolved"]:
        return None
    return dict(subject=subjects[0], phrase=phrase, qualifiers=q,
        dates=scoped.matching.times(operator))


def _leaf_form(token):
    return token.tag_, tuple((t.dep_, t.lemma_.casefold(), t.tag_) for t in token.children
        if t.dep_ in {"aux", "auxpass", "cop", "neg", "mark"})


def _argument_proofs(phrase, path=()):
    yield from ((path, p) for p in phrase["proofs"])
    for modifier in phrase.get("modifiers", []):
        yield from _argument_proofs(modifier["phrase"], path + (modifier["relation"],))


def _numeric_arguments_literal(bindings):
    for row in bindings:
        wanted, offered = list(_argument_proofs(row["target"])), list(_argument_proofs(row["source"]))
        if any(p["pos"] == "NUM" for path, p in wanted + offered):
            signature = lambda values: sorted((path, scoped.native.old._term(p)) for path, p in values)
            if signature(wanted) != signature(offered):
                return False
    return True


def _projection(target, source, compared, query_doc, source_doc):
    if (compared.get("reasons") != ["EMBEDDED_EVENT_ACTOR_BINDING_UNRESOLVED_NOT_EVENT_EVIDENCE"]
            or compared["direction"] != "RELATED"
            or set(compared.get("narrative_guard_issues", [])) - {"TENSE_OR_ASPECT_NOT_ALIGNED"}
            or target["kind"] != "EVENT" or source["kind"] != "EVENT"
            or target["predicate"] != source["predicate"]
            or not target["roles"]
            or any(f["roles"].get(k) for f in (target, source) for k in ("agent", "owner"))
            or any(f.get("unbound_arguments") or f.get("passive") for f in (target, source))):
        return None
    if any(d["status"] not in _GOOD for k, d in compared["diagnostics"].items() if k != "actor"):
        return None
    bindings = compared["bindings"]["argument_matches"]
    if (len(bindings) != sum(len(v) for v in target["roles"].values())
            or any(b["status"] != "EXACT_SCOPED_ARGUMENT" for b in bindings)
            or not _numeric_arguments_literal(bindings)):
        return None
    tt, st = baseline._token(target, query_doc), baseline._token(source, source_doc)
    if tt is None or st is None or tt.dep_ != "xcomp" or st.dep_ != "xcomp":
        return None
    if _leaf_form(tt) != _leaf_form(st):
        return None
    if any(c.dep_ in {"nsubj", "nsubjpass", "csubj"} for t in (tt, st) for c in t.children):
        return None
    qt, so = tt.head, st.head
    if (qt.dep_ != "ROOT" or qt.pos_ != "VERB" or so.pos_ != "VERB"
            or qt.lemma_.casefold() != so.lemma_.casefold() or qt.lemma_.casefold() not in _OPERATORS):
        return None
    branch = _independent_source_branch(so)
    qc, sc = _operator_context(qt), _operator_context(so)
    if not branch or qc is None or sc is None:
        return None
    if ("TENSE_OR_ASPECT_NOT_ALIGNED" in compared.get("narrative_guard_issues", [])
            and branch != "INDEPENDENT_CONJ_WITH_OWN_SUBJECT_AND_FINITE_CLOCK"):
        return None
    if (not scoped.native.old._phrase_match(qc["phrase"], sc["phrase"])
            or qc["subject"].lemma_.casefold() != sc["subject"].lemma_.casefold()):
        return None
    qclock, sclock = _owned_clock(qt), _owned_clock(so)
    if (qclock is None or sclock is None or qclock["tense"] != "past"
            or any(qclock[k] != sclock[k] for k in ("tense", "progressive", "perfect"))):
        return None
    if not set(qc["qualifiers"]["manner"]) <= set(sc["qualifiers"]["manner"]):
        return None
    literal_dates = lambda values: [" ".join(p["text"].casefold().split()) for p in values]
    if qc["dates"] and literal_dates(qc["dates"]) != literal_dates(sc["dates"]):
        return None
    for frame, operator in ((target, qt), (source, so)):
        scopes = frame["qualifiers"].get("scope", [])
        if (len(scopes) != 1 or scopes[0]["relation"] != "xcomp"
                or scopes[0]["predicate"] != operator.lemma_.casefold()
                or len(scopes[0]["speakers"]) != 1 or scopes[0].get("negated") or scopes[0].get("modality")
                or frame["qualifiers"].get("negated")):
            return None
    if any(baseline._disjunctive(f, d) for f, d in ((target, query_doc), (source, source_doc))):
        return None
    return dict(kind="LITERAL_QUERY_ROOT_NONFACTIVE_CONTENT_ASCRIPTION",
        operator=qt.lemma_.casefold(),
        query_operator_proof=scoped.matching.proof(qt), source_operator_proof=scoped.matching.proof(so),
        query_holder=deepcopy(qc["phrase"]), source_holder=deepcopy(sc["phrase"]),
        query_branch_clock=qclock, source_branch_clock=sclock, source_branch_kind=branch,
        query_root_qualifiers=qc["qualifiers"], source_root_qualifiers=sc["qualifiers"],
        query_operator_dates=qc["dates"], source_operator_dates=sc["dates"],
        embedded_morphology_and_auxiliaries_preserved=True, numeric_argument_qualifiers_preserved=True,
        complete_requested_leaf_argument_bindings=deepcopy(bindings),
        target_leaf_frame=deepcopy(target), source_leaf_frame=deepcopy(source),
        legacy_ancestor_clock_guard_replaced="TENSE_OR_ASPECT_NOT_ALIGNED" in compared.get("narrative_guard_issues", []),
        ancestor_or_other_branch_clock_used=False, publication_date_used_as_event_time=False,
        inner_actor_assigned=False, inner_actor_certified=False, inner_execution_certified=False,
        canonical_identity_certified=False, cross_atom_or_event_join_certified=False)


def evaluate(matcher, atom, page, unit):
    """Return an experimental sidecar; never mutate/adopt the ordinary V4 row."""
    control = matcher.supplement(atom, page, unit)
    result = dict(version=VERSION, experimental=True, default_engine_adopted=False,
        direction="UNRESOLVED", source_attestation=None, citation=deepcopy(control["citation"]),
        support_scope="QUERY_ROOT_OPERATOR_SOURCE_ASCRIPTION_ONLY",
        v4_control=dict(version=control["version"], direction=control["direction"], sha256=digest(control)),
        event_bindings=[], actual_inner_event_established=False, world_truth_certified=False,
        source_text_modified=False, query_modified=False, ordinary_decision_modified=False,
        api_calls=0, limitations=["Literal public clause and one direct-xcomp target only.",
            "Matching positive past matrix clocks only; no inner execution, alias or joint-event certificate."])
    spans = atom.get("query_spans", [])
    if (len(spans) != 1 or atom["text"] != spans[0]["text"] or control["query_issues"]
            or atom.get("kind", "proposition") != "proposition"):
        return result
    with offline():
        targets = matcher.engine.targets(atom["text"])
        offered = matcher.engine.targets(unit.get("text", unit.get("quote")))
        if len(targets) != 1:
            return result
        target = targets[0]
        query_doc = matcher.engine.parse(atom["text"])
        source_doc = matcher.engine.parse(unit.get("text", unit.get("quote")))
        for source in offered:
            compared = scoped.compare_frames(target, source, engine=matcher.engine)
            guarded = baseline._compare(target, source, matcher.engine, query_doc, source_doc)
            if compared is None or guarded is None:
                continue
            compared = deepcopy(compared)
            compared["narrative_guard_issues"] = guarded["narrative_guard_issues"]
            certificate = _projection(target, source, compared, query_doc, source_doc)
            if certificate is not None:
                qp, sp = certificate["query_operator_proof"], certificate["source_operator_proof"]
                certificate["coordinate_contract"] = dict(query_proofs="PUBLIC_QUERY_SPAN_RELATIVE",
                    query_span_start=spans[0]["start"], source_proofs="CITATION_UNIT_RELATIVE",
                    source_unit_start=control["citation"]["start"])
                certificate["query_operator_public_proof"] = dict(qp,
                    start=spans[0]["start"] + qp["start"], end=spans[0]["start"] + qp["end"])
                certificate["source_operator_page_proof"] = dict(sp,
                    start=control["citation"]["start"] + sp["start"],
                    end=control["citation"]["start"] + sp["end"])
                result.update(direction="SUPPORT", source_attestation=certificate)
                break
    return result
