"""Unadopted literal nominal role -> historical copular source ascription.

No appointment/action inference, aliases, named-set inclusion, event identity,
or persistence at the query cutoff. Ordinary inference does not import this.
"""
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import scope_matching as scoped

VERSION = "narrative-historical-copular-role-experiment/1"
_ARTICLES = {"a", "an", "the"}
_NOMINAL_DEPS = {"compound", "amod", "det", "prep", "pobj", "case", "flat", "punct"}
_CLAUSES = {"ccomp", "xcomp", "advcl", "acl", "relcl", "parataxis"}
_QUALIFIERS = ("negated", "scope", "attribution", "modality", "conditional", "question",
    "epistemic_absence", "unresolved", "manner", "role_qualifiers")


def _proofs(tokens):
    return [scoped.matching.proof(t) for t in tokens if not t.is_space]


def _signature(tokens):
    return tuple(t.text.casefold() for t in tokens if not t.is_space and not t.is_punct
        and not (t.dep_ == "det" and t.lower_ in _ARTICLES))


@lru_cache(maxsize=256)
def _person_role(noun):
    from matryoshka_demo.roles import lexicon
    try:
        wn = lexicon()
        senses = [s.name() for s in wn.synsets(noun, pos="n") if s.lexname() == "noun.person"]
        return dict(senses=senses, wordnet_version=wn.get_version()) if senses else None
    except LookupError:
        return None


@lru_cache(maxsize=256)
def _common_role_name(text):
    from matryoshka_demo.roles import lexicon
    key = "_".join(text.casefold().split())
    try:
        return any(s.lexname() == "noun.person" and any(l.name() == key for l in s.lemmas())
            for s in lexicon().synsets(key, pos="n"))
    except LookupError:
        return True


def _nominal(tokens, head):
    return (bool(tokens) and head.pos_ in {"NOUN", "PROPN"}
        and all(t.is_space or t.is_punct or (t.pos_ in {"NOUN", "PROPN", "ADJ", "ADP", "DET"}
            and (t == head or t.dep_ in _NOMINAL_DEPS)
            and (t.pos_ != "DET" or t.lower_ in _ARTICLES)) for t in tokens)
        and not any(t != head and t.dep_ in {"cc", "conj", "poss", "appos"} for t in tokens))


def _name(tokens, head):
    content = [t for t in tokens if not t.is_space and not t.is_punct]
    return (len(content) >= 2 and head in content and all(t.pos_ == "PROPN" for t in content)
        and not any(t.ent_type_ and t.ent_type_ != "PERSON" for t in content)
        and not _common_role_name(" ".join(t.text for t in content))
        and all(t == head or (t.head == head and t.dep_ in {"compound", "flat"}) for t in content))


def _context(heads, doc):
    path = {t.i: t for head in heads for t in (head, *head.ancestors)}
    nodes = list(path.values())
    reasons = []
    if any(t.is_quote or t.text == "?" for t in doc):
        reasons.append("UNMODELED_QUOTATION_OR_QUESTION")
    if any(t.dep_ == "ROOT" and t.i not in path for t in doc):
        reasons.append("UNMODELED_DISCONNECTED_UNIT_ROOT")
    if any(t.dep_ in {"parataxis", "advcl"} for t in doc):
        reasons.append("UNMODELED_UNIT_REPORT_OR_ADVERBIAL_CLAUSE")
    if any(t.dep_ in _CLAUSES for t in nodes):
        reasons.append("EMBEDDED_OR_REPORTED_NOMINAL_SCOPE")
    verbal = [t for t in nodes if t.pos_ in {"VERB", "AUX"}]
    if len(verbal) > 1:
        reasons.append("MULTIPLE_GOVERNING_PREDICATES")
    for token in nodes:
        q = scoped.matching.qualifiers(token)
        if any(q.get(k) for k in _QUALIFIERS):
            reasons.append("QUALIFIED_GOVERNING_PATH")
        if scoped.matching.times(token):
            reasons.append("EXPLICIT_GOVERNING_TIME_NOT_PROJECTED")
        if token.pos_ in {"VERB", "AUX"}:
            if any(c.dep_ in {"aux", "auxpass", "neg", "advmod", "advcl", "parataxis"}
                    or (c.dep_ == "prep" and c.i not in path) for c in token.children):
                reasons.append("UNMODELED_GOVERNING_OPERATOR_OR_ADJUNCT")
        elif token not in heads and token.pos_ not in {"ADP", "VERB", "AUX"}:
            reasons.append("UNMODELED_NOMINAL_GOVERNOR")
    return sorted(set(reasons)), [dict(proof=scoped.matching.proof(t),
        qualifiers=scoped.matching.qualifiers(t), printed_dates=scoped.matching.times(t)) for t in nodes]


def _query(atom, case, engine):
    if atom.get("kind", "proposition") != "proposition":
        return None
    doc = engine.parse(atom["text"])
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1 or roots[0].lemma_.casefold() != "be" or roots[0].tag_ != "VBD":
        return None
    root = roots[0]
    subjects = [t for t in root.children if t.dep_ == "nsubj"]
    attrs = [t for t in root.children if t.dep_ == "attr"]
    if len(subjects) != 1 or len(attrs) != 1:
        return None
    name, role = subjects[0], attrs[0]
    nt, rt = list(name.subtree), list(role.subtree)
    lexical = _person_role(role.lemma_.casefold())
    if not _name(nt, name) or not _nominal(rt, role) or lexical is None:
        return None
    allowed = {t.i for t in (*nt, *rt, root)}
    if any(t.i not in allowed and not t.is_space and not t.is_punct for t in doc):
        return None
    issues, path = _context([name, role, root], doc)
    if issues:
        return None
    # Generated terminal punctuation may replace a clause boundary; its literal
    # core must still bind once in the selected, original public-query span.
    core = atom["text"].rstrip(". \t\r\n")
    matches = []
    for span in atom.get("query_spans", []):
        start = span["text"].find(core)
        if start >= 0 and span["text"].find(core, start + 1) < 0:
            matches.append(span["start"] + start)
    if len(set(matches)) != 1:
        return None
    public_doc = engine.parse(case["query"])
    public_root = next((t for t in public_doc if t.idx == matches[0] + root.idx
        and t.lemma_.casefold() == "be" and t.tag_ == "VBD"), None)
    if public_root is None or _context([public_root], public_doc)[0]:
        return None
    text = doc.text[min(t.idx for t in nt):max(t.idx + len(t) for t in nt)]
    return dict(name=text, name_tokens=nt, role=role, role_tokens=rt,
        role_signature=_signature(rt), public_start=matches[0], lexical=lexical,
        query_path=path, query_doc=doc)


def _candidates(wanted, doc):
    pattern = r"(?<![\w-])" + re.escape(wanted["name"]) + r"(?![\w-])"
    for match in re.finditer(pattern, doc.text, re.I):
        nt = [t for t in doc if match.start() <= t.idx and t.idx + len(t) <= match.end()]
        heads = [t for t in nt if t.head not in nt or t.head == t]
        if len(heads) != 1 or not _name(nt, heads[0]):
            continue
        name = heads[0]
        for role in doc:
            if role.lemma_.casefold() != wanted["role"].lemma_.casefold():
                continue
            grammar, group = None, name
            if role.dep_ in {"compound", "amod"} and role.head == name:
                grammar = "ROLE_PREFIX_OF_LITERAL_FULL_NAME"
            elif role.dep_ == "appos" and role.head == name:
                grammar = "ROLE_APPOSITION_TO_LITERAL_FULL_NAME"
            elif name.dep_ == "appos" and name.head == role:
                grammar, group = "LITERAL_FULL_NAME_APPOSITION_TO_ROLE", role
            if grammar is None:
                continue
            skip = {t.i for t in name.subtree} if group == role else set()
            rt = [t for t in role.subtree if t.i not in skip]
            if not _nominal(rt, role) or _signature(rt) != wanted["role_signature"]:
                continue
            if grammar == "ROLE_PREFIX_OF_LITERAL_FULL_NAME" and max(t.idx + len(t) for t in rt) > match.start():
                continue
            allowed = {t.i for t in (*nt, *rt)}
            if any(t.i not in allowed and not t.is_space and not t.is_punct
                    and not (t.dep_ == "det" and t.lower_ in _ARTICLES) for t in group.subtree):
                continue
            # No full-name suffix/prefix or other nearby person can replace the
            # explicit carrier, even if a shorter query string occurs literally.
            if name.dep_ in {"compound", "flat", "poss"}:
                continue
            issues, path = _context([name, role], doc)
            if not issues:
                yield dict(grammar=grammar, source_name_proofs=_proofs(nt), source_role_proofs=_proofs(rt),
                    source_governing_path=path)


def evaluate(matcher, atom, page, unit):
    """Experimental sidecar; source gates stay owned by the frozen V4 matcher."""
    control = matcher.supplement(atom, page, unit)
    result = dict(version=VERSION, experimental=True, default_engine_adopted=False,
        direction="UNRESOLVED", source_attestation=None, citation=deepcopy(control["citation"]),
        hold_reason="NO_EXACT_UNQUALIFIED_LITERAL_ROLE_NAME_ATTACHMENT",
        v4_control=dict(version=control["version"], direction=control["direction"], sha256=digest(control)),
        event_bindings=[], canonical_identity_certified=False, aliases_resolved=False,
        cross_atom_or_event_join_certified=False, actual_inner_event_established=False,
        world_truth_certified=False, continued_tenure_at_query_cutoff_certified=False,
        publication_date_used_as_event_time=False, source_text_modified=False, query_modified=False,
        ordinary_decision_modified=False, api_calls=0,
        support_scope="HISTORICAL_LITERAL_ROLE_SOURCE_ASCRIPTION_ONLY",
        limitations=["Exact full name and complete nominal role only; no alias or set inclusion.",
            "No appointment-to-office inference, persistence, event-time or event-join certificate.",
            "Unmodeled governing qualifiers and parser-ambiguous nominal attachments remain held."])
    with offline():
        target = _query(atom, matcher.case, matcher.engine)
        if target is None:
            result["hold_reason"] = "QUERY_OUTSIDE_NARROW_PAST_COPULAR_ROLE_CONTRACT"
            return result
        if "UNBOUND_PRECEDING_SOURCE_QUALIFICATION" in control["query_issues"]:
            result["hold_reason"] = "UNBOUND_PRECEDING_SOURCE_QUALIFICATION"
            return result
        source_doc = matcher.engine.parse(unit.get("text", unit.get("quote")))
        candidate = next(_candidates(target, source_doc), None)
        if candidate is not None:
            cert = dict(candidate, kind="EXACT_NOMINAL_ROLE_TO_UNDATED_PAST_COPULAR_ASCRIPTION",
                query_name_proofs=_proofs(target["name_tokens"]), query_role_proofs=_proofs(target["role_tokens"]),
                query_governing_path=target["query_path"], lexical_role_classification=target["lexical"],
                lexical_synonym_or_role_conversion_used=False, source_date_is_ascription_not_event_date=True,
                coordinate_contract=dict(query="ATOM_RELATIVE", public_atom_start=target["public_start"],
                    source="CITATION_UNIT_RELATIVE", source_unit_start=control["citation"]["start"]))
            result.update(direction="SUPPORT", source_attestation=cert,
                hold_reason=None,
                source_attestation_not_persistence=True, source_ascription_date=control["citation"]["date"])
    return result
