"""Historical role-subject appositions with literal personal names.

Reviewed source: phase/post_public_case_qualification_20261121/
reverse_role_prototype/v3/reverse_role_v3.py (SHA256
ac866b04d51a4443257671ac97cefea473b83bd543bd42ad7b1bdc12ceb2c38c).
Only producer version and installation metadata differ from that reviewed code.
No matrix action, continuing tenure, identity or event join is certified.
"""
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_demo.io import digest, offline
from matryoshka_demo.roles import lexicon
from matryoshka_narrative import nominal_bindings as nominal3
from matryoshka_narrative import nominal_case_bindings as prerequisites
from matryoshka_narrative import prename_role_binding as scope

VERSION = "literal-reverse-subject-role-source-ascription/1"
SCOPE_VERSION = "literal-full-page-sentence-with-attested-meta-label/2"
CERTIFICATE_KIND = "LITERAL_ROLE_SUBJECT_NAMED_PERSON_DIRECT_APPOSITION"
MAX_TOKENS = 128
PREFIX_DEPS = {"det", "compound", "amod", "nummod"}
QUALIFIED = scope._QUALIFIED | {"reported", "reputed", "presumed", "suspected", "temporary",
    "probable", "possibly", "likely", "maybe", "designated", "new", "purportedly", "interim"}
REPORT_ROOTS = {"say", "report", "claim", "allege", "believe", "suppose", "suspect", "seem", "appear"}
QUANTIFIERS = {"all", "every", "each", "any", "some", "many", "few", "several", "most", "both", "either", "neither"}
QUALIFICATION_SEEDS = frozenset({
    "alleged", "apparent", "assumed", "supposed", "nominal", "provisional",
    "temporary", "possible", "probable", "presumed", "reputed", "suspected",
    "claimed", "unconfirmed", "unverified", "unofficial", "former", "acting",
    "interim", "future", "prospective", "purported", "putative", "designated", "self-styled",
})


def tokens(doc):
    return [{"i":t.i,"text":t.text,"start":t.idx,"end":t.idx+len(t),"lemma":t.lemma_,
             "pos":t.pos_,"tag":t.tag_,"dep":t.dep_,"head":t.head.i,"morph":str(t.morph),
             "entity":t.ent_type_} for t in doc]


def span_proof(doc, values):
    a,b = values[0].idx,values[-1].idx+len(values[-1])
    return {"start":a,"end":b,"text":doc.text[a:b],
            "tokens":[nominal3.scoped.matching.proof(t) for t in values]}


def _role_prefix_base(head, *, source=False):
    allowed = head.pos_ == "NOUN" and head.tag_ == "NN" or source and head.pos_ == "PROPN" and head.tag_ == "NNP"
    if not allowed or not nominal3._personal_role(head.lemma_.casefold()):
        return None,"ROLE_HEAD_NOT_SINGULAR_COMMON_PERSON_ROLE"
    values = sorted((t for t in head.subtree if not source or t.i <= head.i),key=lambda t:t.i)
    if not scope._contiguous(values) or values[-1] != head:
        return None,"ROLE_PREFIX_NOT_COMPLETE_CONTIGUOUS_PREHEAD_NP"
    numeric = [t for t in values if t.pos_ == "NUM" or t.like_num or t.ent_type_ in {"ORDINAL","CARDINAL"}
               or re.search(r"\d",t.text)]
    designator = []
    if numeric:
        if len(numeric) != 1:
            return None,"MULTIPLE_NUMERIC_ROLE_MODIFIERS"
        number = numeric[0]
        if re.fullmatch(r"[0-9]+(?:st|nd|rd|th)",number.text,re.I):
            designator = [number]
        elif number.text.isascii() and number.text.isdigit():
            suffix = next((t for t in values if t.i == number.i+1),None)
            if (suffix is None or suffix.lower_ not in {"st","nd","rd","th"}
                    or not re.fullmatch(r"\s+",head.doc.text[number.idx+len(number):suffix.idx])):
                return None,"COUNT_WITHOUT_LITERAL_ORDINAL_SUFFIX"
            designator = [number,suffix]
        else:
            return None,"COUNT_OR_NONORDINAL_NUMBER_NOT_A_LITERAL_UNIT_DESIGNATOR"
    suffix_tokens = designator[1:]
    permitted = lambda t:t.dep_ in PREFIX_DEPS or t in suffix_tokens and t.dep_ == "nmod" and t.head in values
    if any(t != head and not permitted(t) for t in values):
        return None,"ROLE_MODIFIER_STRUCTURE_UNSUPPORTED"
    if any(t.lemma_.casefold() in QUALIFIED | QUANTIFIERS or t.pos_ in {"VERB","AUX","ADV"}
           or t.ent_type_ in {"DATE","TIME"} for t in values):
        return None,"QUALIFIED_UNCERTAIN_OR_TEMPORAL_ROLE"
    if any(t.dep_ == "poss" for t in values):
        return None,"POSSESSOR_ROLE_NOT_LICENSED"
    for t in values:
        node = t
        while node != head and permitted(node):
            node = node.head
        if node != head:
            return None,"ROLE_PREFIX_NOT_OWNED_BY_ROLE_HEAD"
    numeric_proofs = []
    if designator:
        ordinal = designator[0]
        anchors = [t for t in values if designator[-1].i < t.i < head.i and t.pos_ in {"NOUN","PROPN"}
                   and t.dep_ == "compound" and t.head == head and not nominal3._personal_role(t.lemma_.casefold())]
        if len(anchors) != 1 or ordinal.i != next((t.i for t in values if t.dep_ != "det"),None):
            return None,"ORDINAL_WITHOUT_UNIQUE_LITERAL_UNIT_COMPOUND"
        numeric_proofs = [nominal3.scoped.matching.proof(t) for t in designator+anchors]
    return (values,numeric_proofs),None


@lru_cache(maxsize=1)
def qualification_words():
    words = set(QUALIFIED) | set(QUALIFICATION_SEEDS)
    wn = lexicon()
    for seed in QUALIFICATION_SEEDS:
        for sense in wn.synsets(seed,pos="a"):
            words.update(l.name().replace("_"," ").casefold() for l in sense.lemmas())
    return frozenset(words)


def role_prefix(head, *, source=False):
    result,failed = _role_prefix_base(head,source=source)
    if failed:
        return result,failed
    values,_ = result
    if any(t != head and (t.text.casefold() in qualification_words()
                         or t.lemma_.casefold() in qualification_words()) for t in values):
        return None,"EPISTEMIC_AUTHORITY_OR_TENURE_QUALIFIED_ROLE"
    return result,None


def named_person(tokens):
    if not scope._contiguous(tokens) or len(tokens) < 2 or any(t.pos_ != "PROPN" for t in tokens):
        return False
    prefix = tokens[0].text.casefold().rstrip(".")
    titled = len(tokens) >= 3 and (nominal3._personal_role(tokens[0].lemma_.casefold())
        or 3 <= len(prefix) <= 4 and prefix.isalpha()
        and len({lemma for lemma,_ in scope._military_roles() if lemma.startswith(prefix)}) == 1)
    core = tokens[1:] if titled else tokens
    if any(t.ent_type_ in {"ORG","GPE","LOC","FAC"} for t in core):
        return False
    return sum(t.ent_type_ == "PERSON" for t in core) >= 2 or titled


def source_sentence_scope(engine,page,unit):
    ordinary,failed = scope._source_sentence_scope(engine,page,unit)
    if failed != "SOURCE_UNIT_NOT_COMPLETE_PAGE_SENTENCE":
        return ordinary,failed
    text = page["text"]
    doc = engine.parse(text)

    def trim(a,b):
        while a < b and text[a].isspace():
            a += 1
        while b > a and text[b-1].isspace():
            b -= 1
        return a,b

    a,b = trim(unit["start"],unit["end"])
    parents = [s for s in doc.sents if s.start_char <= a < b <= s.end_char]
    if len(parents) != 1:
        return None,failed
    parent = parents[0]
    lo,hi = trim(parent.start_char,parent.end_char)
    if hi != b or not lo < a or re.fullmatch(r"[0-9]+\.\s+",text[lo:a]) is None:
        return None,"SOURCE_PREFIX_NOT_EXACT_PARAGRAPH_NUMBER_METADATA"
    root = parent.root
    finite = [t for t in [root,*root.children] if "Fin" in t.morph.get("VerbForm")
              and (t == root or t.dep_ in {"aux","auxpass"})]
    if (root.head != root or root.pos_ != "VERB" or not a <= root.idx < root.idx+len(root) <= b
            or not finite or any(not a <= t.idx < t.idx+len(t) <= b for t in finite)):
        return None,"META_LABEL_NOT_ATTACHED_TO_SAME_FINITE_VERBAL_MATRIX"
    prefix = [t for t in parent if lo <= t.idx < a and not t.is_space]
    if len(prefix) != 2:
        return None,"META_PREFIX_HAS_NONLABEL_TOKENS"
    digit,dot = prefix
    if (not digit.text.isascii() or not digit.text.isdigit() or digit.pos_ != "X"
            or digit.dep_ != "meta" or digit.head != root
            or digit.ent_type_ in {"DATE","TIME"}
            or dot.text != "." or dot.pos_ != "PUNCT" or dot.dep_ != "punct" or dot.head != digit
            or {t for t in digit.children if not t.is_space} != {dot}
            or any(not t.is_space for t in dot.children)):
        return None,"PREFIX_NOT_ATTESTED_NONSEMANTIC_META_LABEL"
    source = engine.parse(unit["text"])
    roots = [t for t in source if t.dep_ == "ROOT"]
    if (len(roots) != 1 or len(list(source.sents)) != 1
            or roots[0].idx+unit["start"] != root.idx or roots[0].text != root.text):
        return None,"UNIT_AND_PARENT_MATRIX_ROOT_NOT_IDENTICAL"
    omitted = [t for t in parent if not t.is_space and t.idx < a]
    if omitted != prefix or any(t.idx+len(t) > b and not t.is_space for t in parent):
        return None,"PARENT_HAS_OTHER_OMITTED_CONTENT"
    proof = nominal3.scoped.matching.proof
    citation = dict(canonical_page_id=page["id"],corpus=page["corpus"],document_id=page["document_id"],
        date=page["date"],start=parent.start_char,end=parent.end_char,
        text=text[parent.start_char:parent.end_char],page_sha256=page["source_sha256"])
    return dict(version=SCOPE_VERSION,canonical_page_id=page["id"],page_sha256=page["source_sha256"],
        sentence_start=lo,sentence_end=hi,unit_start=unit["start"],unit_end=unit["end"],
        boundary_comparison_ignores_whitespace_only=False,
        additional_boundary_rule="EXACT_ATTESTED_NONSEMANTIC_PARAGRAPH_NUMBER_PREFIX",
        parent_full_quote=citation,parent_full_quote_sha256=digest(citation),
        prefix=dict(start=lo,end=a,text=text[lo:a],tokens=[proof(t) for t in prefix],
                    proof_offset_basis="FULL_PAGE_UNICODE_CHARACTERS",semantic_content_certified=False),
        parent_matrix_root=proof(root),finite_matrix_proofs=[proof(t) for t in finite],
        source_unit_expanded=False,source_text_modified=False,source_parse_rewritten=False,
        query_dependent_boundary=False,semantic_prefix_removed=False),None


def evaluate(matcher, atom, page, unit, control):
    result = {"version":VERSION,"prototype_only":False,"production_hook_installed":True,
              "applicable":False,"direction":"UNRESOLVED","reasons":[],"certificate":None}
    def hold(reason):
        result["reasons"] = [reason]
        return result
    failed = prerequisites._prerequisites(matcher,atom,page,unit,control)
    if failed:
        return hold(failed)
    with offline():
        engine = matcher.engine
        sentence_scope,failed = source_sentence_scope(engine,page,unit)
        if failed:
            return hold(failed)
        query,source = engine.parse(atom["text"]),engine.parse(unit["text"])
        if max(len(query),len(source)) > MAX_TOKENS:
            return hold("TOKEN_BOUND_EXCEEDED")
        qroots = [t for t in query if t.dep_ == "ROOT"]
        if len(qroots) != 1 or qroots[0].lemma_.casefold() != "be" or qroots[0].tag_ != "VBD":
            return hold("QUERY_NOT_SIMPLE_PAST_COPULAR_ROLE_ASCRIPTION")
        root = qroots[0]
        owners = [t for t in root.children if t.dep_ == "nsubj"]
        attributes = [t for t in root.children if t.dep_ == "attr"]
        if len(owners) != 1 or len(attributes) != 1:
            return hold("QUERY_OWNER_AND_NOMINAL_ROLE_NOT_UNIQUE")
        owner,wanted = owners[0],attributes[0]
        if (atom.get("kind") != "proposition" or atom.get("polarity","positive") != "positive"
                or atom.get("modality","asserted") != "asserted"
                or any(t not in [owner,wanted] and t.dep_ != "punct" for t in root.children)
                or any(t.is_quote or t.text == "?" for t in query)
                or len(engine.targets(atom["text"])) != 1):
            return hold("QUERY_SCOPE_OR_REPRESENTATION_UNSUPPORTED")
        qp,failed = role_prefix(wanted)
        if failed:
            return hold(failed)
        qname = nominal3._name_tokens(owner)
        if not named_person(qname) or set(owner.subtree) != set(qname):
            return hold("QUERY_NOT_COMPLETE_LITERAL_PERSON_NAME")
        result["applicable"] = True
        roots = [t for t in source if t.dep_ == "ROOT"]
        if (len(roots) != 1 or len(list(source.sents)) != 1
                or any(t.is_quote or t.text in {"?","(",")","[","]","--","\u2014"}
                       or t.lower_ == "according" or t.dep_ in {"parataxis","advcl","relcl"} for t in source)):
            return hold("SOURCE_QUESTION_QUOTATION_OR_EMBEDDED_SCOPE_UNSUPPORTED")
        matrix = roots[0]
        subjects = [t for t in matrix.children if t.dep_ == "nsubj"]
        if matrix.pos_ != "VERB" or len(subjects) != 1:
            return hold("NO_UNIQUE_VERBAL_ROOT_NSUBJ_ROLE")
        governing = nominal3.scoped.matching.qualifiers(matrix)
        if matrix.lemma_.casefold() in REPORT_ROOTS or any(governing.get(k) for k in scope._SCOPE_FIELDS):
            return hold("SOURCE_REPORT_NONFACTIVE_OR_QUALIFIED_SCOPE")
        if any(t.dep_ in {"ccomp","xcomp"} for t in matrix.children):
            return hold("SOURCE_CLAUSAL_CONTENT_NOT_LICENSED")
        role = subjects[0]
        appositions = [t for t in source if t.dep_ == "appos"]
        if len(appositions) != 1 or appositions[0].head != role:
            return hold("SOURCE_NEEDS_ONE_DIRECT_ROLE_PERSON_APPOSITION")
        person = appositions[0]
        if any(t.dep_ in {"conj","cc","poss"} for t in role.subtree):
            return hold("ROLE_ALTERNATIVE_POSSESSOR_OR_POSTHEAD_MODIFIER_UNSUPPORTED")
        sp,failed = role_prefix(role,source=True)
        if failed:
            return hold(failed)
        qrole,qnumeric = qp
        srole,snumeric = sp
        if any(t not in srole and t not in [person] and t.dep_ != "punct" for t in role.children):
            return hold("ROLE_POSTHEAD_MODIFIER_UNSUPPORTED")
        literal = lambda ts:" ".join(ts[0].doc.text[ts[0].idx:ts[-1].idx+len(ts[-1])].casefold().split())
        if literal(qrole) != literal(srole) or [t.text.casefold() for t in qrole] != [t.text.casefold() for t in srole]:
            return hold("FULL_ROLE_PREFIX_NOT_LITERAL_QUERY_ATTRIBUTE")
        sname = nominal3._name_tokens(person)
        if not named_person(sname) or set(person.subtree) != set(sname):
            return hold("SOURCE_APPOSITION_NOT_COMPLETE_LITERAL_PERSON_NAME")
        binding = nominal3._bound_name(owner,person)
        if binding is None:
            return hold("LITERAL_TITLED_PERSON_NAME_NOT_BOUND")
        # Layout remains in the source/citation; only this structural set ignores it.
        tail = [t for t in role.subtree if t.i > role.i and not t.is_space]
        if set(tail) != set(sname) | {t for t in tail if t.dep_ == "punct" and t.text == ","}:
            return hold("ROLE_TAIL_CONTAINS_UNBOUND_CONTENT")
        cert = {"kind":CERTIFICATE_KIND,"version":VERSION,
            "source_proof_offset_basis":"SOURCE_UNIT_UNICODE_CHARACTERS","source_unit_page_start":unit["start"],
            "source_role_prefix":span_proof(source,srole),"query_role_attribute":span_proof(query,qrole),
            "source_direct_apposition":span_proof(source,sname),"owner_binding":binding,
            "source_role_proof":nominal3.scoped.matching.proof(role),
            "source_matrix_predicate":nominal3.scoped.matching.proof(matrix),
            "numeric_unit_designator":{"query_proofs":qnumeric,"source_proofs":snumeric,
                "literal_identifier_only":True,"quantity_or_count_certified":False,"unit_entity_identity_certified":False},
            "citation":deepcopy(control["citation"]),"source_sentence_scope":sentence_scope,
            "baseline_control":deepcopy(control),"baseline_control_sha256":digest(control),
            "support_scope":"HISTORICAL_LITERAL_ROLE_SOURCE_ASCRIPTION_ONLY",
            "source_ascription_date":page["date"],"source_attestation_not_persistence":True,
            "source_matrix_claim_certified":False,"completed_action_certified":False,
            "inner_execution_certified":False,"continued_tenure_at_query_cutoff_certified":False,
            "precise_event_time_certified":False,"publication_date_used_as_event_time":False,
            "cross_atom_or_event_join_certified":False,"canonical_identity_certified":False,
            "world_truth_certified":False,"source_text_modified":False,"source_parse_rewritten":False,
            "prototype_only":False,"production_hook_installed":True}
        result.update(direction="SUPPORT",reasons=[],certificate=cert)
        return result
