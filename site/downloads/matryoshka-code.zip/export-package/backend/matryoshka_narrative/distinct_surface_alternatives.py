"""Unintegrated display-only collapsing of compatible assessed nonidentity fills.

No nomination, evaluation, sorting, rank assignment, evidence union or new
counter-clearance. The caller supplies an already ranked, trusted assessed pool.
"""
from copy import deepcopy
import hashlib
import json

from matryoshka_demo.contracts import MASK, public_case

VERSION = "assessed-distinct-nonidentity-surfaces/1"
ALTERNATIVES = "assessed_same_surface_alternatives"
MAX_CANDIDATES = 128
MAX_BYTES = 4 * 1024 * 1024


def _json(value):
    pending, nodes = [value], 0
    while pending:
        item = pending.pop()
        nodes += 1
        if nodes > 100000:
            raise ValueError("Assessment structure budget exceeded")
        if type(item) is dict:
            if any(type(k) is not str for k in item):
                raise ValueError("JSON string keys required")
            pending.extend(item.values())
        elif type(item) is list:
            pending.extend(item)
        elif type(item) not in {str, int, float, bool, type(None)}:
            raise ValueError("Exact JSON dtypes required; tuples are not lists")
    return json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False)


def _digest(value):
    return hashlib.sha256(_json(value).encode()).hexdigest()


def normalized_visible_fill(text):
    if type(text) is not str or not text.strip() or MASK.search(text):
        raise ValueError("Nonempty unmasked visible fill required")
    return " ".join(text.casefold().split())


def _checks_pass(checks):
    return (type(checks) is list and bool(checks) and all(type(c) is dict
        and type(c.get("id")) is str and c.get("state") == "pass" for c in checks))


def _inside(ref, source):
    keys = ("canonical_page_id", "document_id", "date", "corpus", "page_sha256")
    if any(type(ref.get(k)) is not str or not ref[k] or ref.get(k) != source.get(k) for k in keys):
        return False
    if len(ref["page_sha256"]) != 64 or any(c not in "0123456789abcdef" for c in ref["page_sha256"]):
        return False
    a, b, lo, hi = ref.get("start"), ref.get("end"), source.get("start"), source.get("end")
    return (all(type(n) is int for n in (a,b,lo,hi)) and 0 <= lo <= a < b <= hi
        and type(source.get("text")) is str and len(source["text"]) == hi-lo
        and source["text"][a-lo:b-lo] == ref.get("text"))


def _compatible_key(candidate, *, case, reading):
    """Missing/contradictory assessment metadata means retain separately."""
    try:
        c, d = candidate, candidate["local_decision"]
        effective, final, head_kind = c["v6_reading"], c["final_form_fit"], c["completed_head_kind_fit"]
        kind = effective["target_kind"]
        if not ((kind == "property" and effective["form"] == "modifier" and effective["role"] == "nominal_property")
                or (kind == "quantity" and effective["form"] == "quantity")):
            return None
        if (_json(c["declared_reading"]) != _json(reading) or c["reading_id"] != reading["id"]
                or effective["id"] != reading["id"] or d["reading_id"] != reading["id"]
                or reading["constructor_form"] != effective["form"]
                or reading["target_kind"] not in {kind,"any"}
                or c["ranking"]["features"]["effective_target_kind"] != kind):
            return None
        if (head_kind["state"] != "pass" or head_kind["target_kind"] != kind
                or head_kind["entity_head_kind_applicable"] is not False
                or final["state"] != "pass" or final["constructor_form"] != effective["form"]
                or final["head"]["pos"] not in ({"ADJ","ADV","VERB"} if kind == "property" else {"NUM"})
                or final["head"].get("tag") in {"NNP","NNPS"}
                or final["completed_query_sha256"] != _digest(case["query"].replace(case["focal_marker"],c["fill"],1))):
            return None
        if (d["id"] != c["id"] or d["text"] != c["fill"] or d["task"] != "redaction"
                or d["status"] != "evidence_backed_suggestion" or d["coverage"] != "Established"
                or d["scope"] not in {"FOCAL_PROPERTY_ONLY","FOCAL_CONTRIBUTION_ONLY"}
                or d["support_present"] is not True or d["required"] is not True
                or any(d[k] is not False for k in ("counterevidence","mixed_evidence","decisive_counter"))
                or not _checks_pass(d["checklist"])):
            return None
        assessment = c["support_assessment"]
        if (assessment["substantive_support"] is not True or assessment["same_scoped_counterevidence"] is not False
                or assessment["absence_is_counterevidence"] is not False or assessment["scope"] != d["scope"]):
            return None
        seal = c["local_decision_provenance_binding"]
        if (seal["bound_decision_sha256"] != _digest(d)
                or seal["signs_or_scope_or_requirements_changed"] is not False):
            return None
        sources, observations = c["sources"], c["source_occurrences"]
        if type(sources) is not list or not sources or type(observations) is not list or not observations:
            return None
        if (type(c["source_span"]) is not list or len(c["source_span"]) != 2
                or any(type(n) is not int for n in c["source_span"])
                or type(c["source_wording"]) is not str or not c["source_wording"]):
            return None
        if d["source_pages_checked"] != [s["canonical_page_id"] for s in sources]:
            return None
        primary = False
        for obs in observations:
            ref, span = obs["citation"], obs["source_span"]
            if (ref not in sources or not _inside(ref,ref) or type(span) is not list or len(span) != 2
                    or any(type(n) is not int for n in span) or not ref["start"] <= span[0] < span[1] <= ref["end"]
                    or ref["text"][span[0]-ref["start"]:span[1]-ref["start"]] != obs["source_wording"]
                    or type(obs["source_head"]["pos"]) is not str
                    or obs["source_head"]["pos"] == "PROPN" or obs["source_head"].get("tag") in {"NNP","NNPS"}
                    or ref["corpus"] != case["corpus"] or ref["date"] >= case["date"]
                    or ref["document_id"] == case["document_id"]):
                return None
            primary |= span == c["source_span"] and obs["source_wording"] == c["source_wording"]
        if not primary:
            return None
        requirements = d["requirements"]
        if type(requirements) is not list or not requirements:
            return None
        semantic_requirements = []
        for req in requirements:
            if (any(type(req.get(k)) is not str or not req[k] for k in ("id","kind","predicate","text"))
                    or req["coverage"] != "Established" or req["direction"] != "Support"
                    or req["counterevidence"] is not False or not _checks_pass(req["checks"])
                    or type(req["evidence"]) is not list or not req["evidence"]):
                return None
            for evidence in req["evidence"]:
                if (evidence["direction"] != "Support" or not _checks_pass(evidence["checks"])
                        or not evidence["citations"] or not all(any(_inside(ref,s) for s in sources)
                            for ref in evidence["citations"])):
                    return None
            semantic_requirements.append({k:v for k,v in req.items() if k not in {"evidence","context_citations"}})
        receipt = c["inspected_pool_counter_comparison"]
        descriptors = [{k:r[k] for k in ("id","kind","predicate","text")} for r in requirements]
        if (len({r["id"] for r in requirements}) != len(requirements)
                or receipt["candidate_id"] != c["id"] or type(receipt["required_count"]) is not int
                or receipt["required_count"] != len(requirements) or receipt["required_descriptors"] != descriptors
                or type(receipt["added_counter_witnesses"]) is not int or receipt["added_counter_witnesses"] != 0
                or receipt["positive_evidence_added"] is not False or receipt["candidate_origins_expanded"] is not False
                or type(receipt["full_declared_pool_compared_under_typed_model"]) is not bool
                or type(receipt["corpus_counter_cleared"]) is not bool
                or receipt["positive_citation_decision_sha256"] != _digest(c["positive_citation_decision"])
                or type(receipt["requirements"]) is not list or len(receipt["requirements"]) != len(requirements)
                or any(r["descriptor"] != descriptor or type(r["counter_witnesses"]) is not list
                    or r["counter_witnesses"] for r,descriptor in zip(receipt["requirements"],descriptors))):
            return None
        # Exclude only observation provenance and timing, never counter scope.
        counter_scope = {k:v for k,v in receipt.items() if k not in {"candidate_id",
            "positive_citation_decision_sha256","positive_citation_source_pages_checked","elapsed_seconds"}}
        decision_scope = {k:v for k,v in d.items() if k not in {"id","text","source_pages_checked","requirements"}}
        return normalized_visible_fill(c["fill"]), _json(dict(effective=effective, decision=decision_scope,
            requirements=semantic_requirements, counter_scope=counter_scope,
            support_assessment=c["support_assessment"], head_kind=head_kind))
    except (KeyError, TypeError, ValueError, IndexError):
        return None


def distinct_surface_alternatives(candidates, *, case, reading, trusted_input_binding):
    """Preserve order/ranks; attach whole assessed snapshots to the first match.

    Caller bindings are trusted construction/record-boundary digests of `case`,
    `reading`, `candidates` (not caller claims of semantic equivalence). This is
    not a new native/cache validator or source-admission authority. Ineligible
    candidates stay separate. Output must not be fed back as an assessed pool.
    """
    if type(candidates) is not list or len(candidates) > MAX_CANDIDATES:
        raise ValueError("Bounded already-ranked candidate list required")
    encoded = _json(dict(case=case,reading=reading,candidates=candidates))
    if len(encoded.encode()) > MAX_BYTES:
        raise ValueError("Assessment projection byte budget exceeded")
    if case != public_case(case) or case["task"] != "redaction":
        raise ValueError("Exact original public Redaction case required")
    expected = {k:_digest(v) for k,v in dict(case=case,reading=reading,candidates=candidates).items()}
    if trusted_input_binding != expected:
        raise ValueError("Trusted assessed-input binding changed")
    ids, previous = set(), 0
    for c in candidates:
        if (type(c) is not dict or type(c.get("id")) is not str or not c["id"] or c["id"] in ids
                or type(c.get("rank")) is not int or c["rank"] <= previous):
            raise ValueError("Distinct IDs and existing strictly increasing integer ranks required")
        if ALTERNATIVES in c:
            raise ValueError("Already projected alternatives are not an assessed input pool")
        normalized_visible_fill(c["fill"])
        ids.add(c["id"])
        previous = c["rank"]
    output, first = [], {}
    for c in candidates:
        key = _compatible_key(c,case=case,reading=reading)
        if key is not None and key in first:
            output[first[key]].setdefault(ALTERNATIVES,[]).append(deepcopy(c))
        else:
            if key is not None:
                first[key] = len(output)
            output.append(deepcopy(c))
    return output
