"""Closed reported own-military-inventory partitions; never completed movement.

The source grammar and bounded qualification audit preserve the previously
reviewed phase rules. No phase module or QA artifact is a runtime dependency.
"""
from copy import deepcopy
import re

from matryoshka_demo.io import digest, offline
from matryoshka_demo.roles import lexicon, binding
from matryoshka_demo_v6.planning import sentences
from matryoshka_next.facts import public_plan
from matryoshka_next.decisions import _prefix_blocker
from .source_qualification import raw_envelope_holds
from . import source_account_match as account

VERSION = "source-own-inventory-announcement/1"
TYPE = "ANNOUNCED_OWN_MILITARY_INVENTORY_CHANGE"
PROOF_FIELD = "source_inventory_announcement_certificate"
_REPORTS = {"announce", "declare", "state", "report", "say", "note", "confirm"}

def _p(token):
    return dict(text=token.text, start=token.idx, end=token.idx + len(token),
                lemma=token.lemma_.casefold(), dependency=token.dep_, head_start=token.head.idx)

def _lex(tokens):
    return [token for token in tokens if not token.is_space and not token.is_punct]

def _normal(text):
    return " ".join(text.casefold().split()).rstrip(".")

def _number(token):
    return int(token.text.replace(",", "")) if token.pos_ == "NUM" and re.fullmatch(
        r"(?:[1-9]\d*|[1-9]\d{0,2}(?:,\d{3})+)", token.text) else None

def _one(tokens, predicate):
    matches = [token for token in tokens if predicate(token)]
    return matches[0] if len(matches) == 1 else None

def _name(head):
    if head is None or head.pos_ != "PROPN":
        return None
    tokens = _lex(head.subtree)
    if any(token != head and not (token.dep_ == "det" and token.lower_ == "the")
           and not (token.dep_ in {"compound", "flat", "name"} and token.pos_ == "PROPN")
           for token in tokens):
        return None
    return dict(key=[token.text.casefold() for token in tokens if token.pos_ == "PROPN"],
                proofs=[_p(token) for token in tokens], tokens={token.i for token in tokens})

def _linear_location(prep, tokens):
    # Only called inside a completely replayed, closed partition grammar. A bad
    # dependency head cannot move the following numeric branch into this NP.
    names = [t for t in tokens if t.pos_ == "PROPN"]
    if (prep.pos_ != "ADP" or not names or any(t.pos_ != "PROPN"
            and not (t.pos_ == "DET" and t.lower_ == "the") for t in tokens)):
        return None
    return dict(preposition=prep.lemma_.casefold(), name=[t.text.casefold() for t in names],
                proofs=[_p(prep), *[_p(t) for t in tokens]], tokens={prep.i, *[t.i for t in tokens]})

def _matrix(doc):
    roots = [token for token in doc if token.dep_ == "ROOT"]
    if (len(roots) != 1 or roots[0].tag_ != "VBD" or roots[0].pos_ != "VERB"
            or roots[0].lemma_.casefold() not in _REPORTS
            or any(token.is_quote or token.text in {"?", ";", ":", "(", ")", "[", "]"} for token in doc)):
        return None
    root = roots[0]
    subject = _one(root.children, lambda t: t.dep_ == "nsubj")
    name = _name(subject)
    clause = _one(root.children, lambda t: t.dep_ == "ccomp")
    if name is None or clause is None or subject.right_edge.i >= root.i:
        return None
    used = name["tokens"] | {root.i}
    dates = []
    for child in root.children:
        if child == subject or child == clause or child.is_punct or child.is_space:
            continue
        if child.dep_ != "prep" or child.lower_ != "on":
            return None
        parts = _lex(child.subtree)
        # Exact literal DATE entity only; no calendar inference from publication.
        content = [t for t in parts if t != child]
        if not content or any(t.ent_type_ != "DATE" for t in content):
            return None
        dates.append(dict(text=doc.text[content[0].idx:content[-1].idx + len(content[-1])],
                          proofs=[_p(t) for t in parts]))
        used.update(t.i for t in parts)
    if len(dates) > 1:
        return None
    return dict(root=root, subject=subject, holder=name, clause=clause,
                dates=dates, used=used, prefix=doc.text[:clause.left_edge.idx])

def _inventory_report(doc):
    matrix = _matrix(doc)
    if matrix is None:
        return None
    reduce = matrix["clause"]
    if reduce.lemma_.casefold() not in {"reduce", "decrease", "cut"} or reduce.tag_ != "VBN":
        return None
    subject = _one(reduce.children, lambda t: t.dep_ == "nsubjpass" and t.pos_ == "NOUN")
    will = _one(reduce.children, lambda t: t.dep_ == "aux" and t.lower_ == "will")
    be = _one(reduce.children, lambda t: t.dep_ == "auxpass" and t.lower_ == "be")
    marker = _one(reduce.children, lambda t: t.dep_ == "mark" and t.lower_ == "that")
    by = _one(reduce.children, lambda t: t.dep_ in {"agent", "prep"} and t.lower_ == "by")
    branch = _one(reduce.children, lambda t: t.dep_ in {"advcl", "conj"} and t.pos_ == "VERB")
    if any(value is None for value in (subject, will, be, marker, by, branch)):
        return None
    possessive = _one(subject.children, lambda t: t.dep_ == "poss" and t.lower_ == "its" and t.pos_ == "PRON")
    descriptors = [t for t in subject.children if t.dep_ == "amod" and t.pos_ == "ADJ"]
    if (possessive is None or any(t != possessive and t not in descriptors for t in subject.children)
            or any(list(t.children) for t in [possessive, *descriptors])):
        return None
    unit = _one(by.children, lambda t: t.dep_ == "pobj" and t.pos_ == "NOUN")
    total = _one(unit.children, lambda t: t.dep_ == "nummod" and _number(t) is not None) if unit is not None else None
    if unit is None or total is None or list(unit.children) != [total] or list(by.children) != [unit]:
        return None
    used = matrix["used"] | {reduce.i, subject.i, will.i, be.i, marker.i, by.i, unit.i, total.i, possessive.i}
    used.update(t.i for t in descriptors)
    further = [t for t in reduce.children if t.dep_ == "advmod" and t.lower_ == "further" and not list(t.children)]
    used.update(t.i for t in further)
    if any(t.i not in used and t != branch and not t.is_punct and not t.is_space for t in reduce.children):
        return None
    if branch.tag_ != "VBN":
        return None
    with_ = _one(branch.children, lambda t: t.dep_ == "mark" and t.lower_ == "with")
    if with_ is None:
        return None
    block = _lex(doc[with_.i:])
    if (len(block) < 11 or block[0] != with_ or _number(block[1]) is None
            or block[1].dep_ != "nsubjpass" or block[1].head != branch
            or block[2].lower_ != "to" or block[2].dep_ != "aux" or block[2].head != branch
            or block[3].lower_ != "be" or block[3].dep_ != "auxpass" or block[3].head != branch
            or block[4] != branch or block[5].pos_ != "ADP"):
        return None
    ands = [i for i, token in enumerate(block) if token.lower_ == "and" and token.pos_ == "CCONJ"]
    if len(ands) != 1:
        return None
    at = ands[0]
    if at < 7 or at + 3 >= len(block) or _number(block[at + 1]) is None:
        return None
    first = _linear_location(block[5], block[6:at])
    second = _linear_location(block[at + 2], block[at + 3:])
    if first is None or second is None or first["preposition"] != second["preposition"]:
        return None
    used.update(t.i for t in block)
    tuples = [dict(quantity=_number(block[1]), location=first, quantity_proof=_p(block[1]),
        predicate_proof=_p(branch), predicate_ellipsis=False),
        dict(quantity=_number(block[at + 1]), location=second, quantity_proof=_p(block[at + 1]),
            predicate_proof=_p(branch), predicate_ellipsis=True,
            license="CLOSED_WITH_NUMBER_TO_BE_PASSIVE_PREP_NAME_AND_NUMBER_SAME_PREP_NAME_GRAMMAR")]
    if ({t.i for t in _lex(doc)} != used
            or any(tuple_["quantity"] > _number(total) for tuple_ in tuples)
            or sum(tuple_["quantity"] for tuple_ in tuples) > _number(total)):
        return None
    matrix.update(predicate=branch.lemma_.casefold(), tuples=tuples,
        inventory_text=" ".join(t.text for t in [*descriptors, subject]),
        inventory_owner_reference=dict(pronoun=_p(possessive), antecedent=matrix["holder"]["proofs"],
            candidate_count=1, not_withdrawal_agent_proof=True),
        total_measure=dict(quantity=_number(total), unit=unit.text, proof=[_p(total), _p(unit)],
            role="AGGREGATE_REDUCTION_MEASURE_NOT_PASSIVE_AGENT_OR_SUBBRANCH_AMOUNT"),
        future_inventory_scope=[_p(will), _p(be), _p(reduce), *[_p(t) for t in further]],
        complete_lexical_token_coverage=True, passive_agent_explicit=False)
    return matrix

_REPORT_NOUNS = {"announcement", "report", "statement", "claim", "declaration"}

_DISTINCT = {"previous", "earlier", "prior", "other", "another", "different", "unrelated"}

_DEICTIC = {"this", "that", "such"}

_CREATION = {"make", "issue", "occur", "exist", "publish", "announce"}

_EPISTEMIC = {"uncertain", "unclear", "unknown", "unconfirmed", "unverified", "doubtful", "unsubstantiated", "fabricated", "false"}

_REPORT_EVENTS = {"announce", "report", "state", "declare", "confirm"}

_RETRACTION = {"retract", "withdraw", "deny", "fabricate"}

def _paragraphs(text):
    spans = []
    at = 0
    for boundary in re.finditer(r"\r?\n[ \t]*\r?\n", text):
        if text[at:boundary.start()].strip():
            spans.append((at, boundary.start()))
        at = boundary.end()
    if text[at:].strip():
        spans.append((at, len(text)))
    return spans

def _reference(noun, holder, dates, anchor, *, following):
    children = list(noun.children)
    words = {t.lower_ for t in children}
    if words & _DISTINCT:
        return "DISTINCT", "EXPLICIT_PREVIOUS_OR_OTHER_REPORT"
    for poss in children:
        if poss.dep_ != "poss" or poss.pos_ != "PROPN":
            continue
        name = [t.text.casefold() for t in poss.subtree if t.pos_ == "PROPN"]
        if name and name != holder["key"]:
            return "DISTINCT", "EXPLICIT_DIFFERENT_NAMED_POSSESSOR"
    date_tokens = [t for t in noun.subtree if t.ent_type_ == "DATE"]
    if date_tokens:
        literal = _normal(" ".join(t.text for t in date_tokens))
        if literal not in {_normal(d["text"]) for d in dates}:
            return "DISTINCT", "EXPLICIT_DIFFERENT_REPORT_DATE"
    strong = bool(words & _DEICTIC)
    if strong or any(t.dep_ == "poss" and t.lower_ == "its" for t in children):
        return anchor, "LOCAL_DEICTIC_REPORT_REFERENCE"
    if not following and words & {"the", "any", "no"}:
        return anchor, "SAME_PARAGRAPH_REPORT_REFERENCE"
    return "UNBOUND", "NO_LOCAL_REPORT_REFERENCE_LICENSE"

def _material(noun):
    """Qualifiers must govern the report nominal or its creation/existence."""
    path = [noun, *noun.ancestors]
    predicates = [t for t in path[1:] if t.pos_ in {"VERB", "AUX", "ADJ"}]
    creation = [t for t in predicates if t.lemma_.casefold() in _CREATION]
    if (noun.dep_ == "attr" and noun.head.lemma_.casefold() == "be"
            and any(t.dep_ == "expl" for t in noun.head.children)):
        creation.append(noun.head)
    reasons, proofs = [], []
    negative = [t for t in noun.children if t.lower_ in {"no", "neither"}]
    negative += [c for t in creation for c in t.children if c.dep_ == "neg" or c.lower_ == "never"]
    if creation and negative:
        reasons.append("NEGATED_REPORT_CREATION_OR_EXISTENCE")
        proofs.extend([*negative, *creation])
    for event in creation:
        whether = [t for t in event.children if t.dep_ == "mark" and t.lower_ in {"whether", "if"}]
        governors = [event, *event.ancestors]
        uncertainty = [t for t in governors if t.lower_ in _EPISTEMIC or t.lemma_.casefold() in {"doubt", "question"}]
        uncertainty += [c for t in governors for c in t.children
            if c.dep_ in {"acomp", "attr", "amod"} and c.lower_ in _EPISTEMIC]
        if whether or uncertainty:
            reasons.append("REPORT_EXISTENCE_UNCERTAIN_OR_QUESTIONED")
            proofs.extend([event, *whether, *uncertainty])
    direct = [t for t in noun.children if t.dep_ == "amod" and t.lower_ in _EPISTEMIC]
    if noun.head.pos_ in {"VERB", "AUX", "ADJ"}:
        governor = noun.head
        if governor.lower_ in _EPISTEMIC or governor.lemma_.casefold() in _RETRACTION:
            direct.append(governor)
        if noun.dep_ in {"nsubj", "nsubjpass", "attr"}:
            direct += [t for t in governor.children if t.dep_ in {"acomp", "attr"} and t.lower_ in _EPISTEMIC]
    if direct:
        reasons.append("CURRENT_REPORT_QUALIFIED_FALSE_UNVERIFIED_OR_RETRACTED")
        proofs.extend(direct)
    for creation_event in creation:
        controller = creation_event
        while controller.dep_ == "xcomp" and account._subject(controller) is None:
            controller = controller.head
        if (controller.lemma_.casefold() in {"deny", "retract"}
                and not any(t.dep_ == "neg" for t in controller.children)):
            reasons.append("CURRENT_REPORT_CREATION_ASCRIPTION_DENIED")
            proofs.extend([creation_event, controller])
    unique = {(t.idx, t.text): t for t in proofs}
    return sorted(set(reasons)), [_p(t) for _, t in sorted(unique.items())]

def audit(matcher, page, unit, holder, dates=()):
    paragraphs = _paragraphs(page["text"])
    current = next(i for i, (a, b) in enumerate(paragraphs) if a <= unit["start"] < unit["end"] <= b)
    selected = paragraphs[current:current + 2]
    limit = selected[-1][1]
    anchor = "TARGET"
    holds, mentions, transitions = [], [], []
    for other in sentences(page["text"]):
        if other["start"] < unit["end"] or other["end"] > limit:
            continue
        following = other["start"] >= selected[0][1]
        doc = matcher.engine.parse(other["text"])
        report_nouns = [t for t in doc if t.pos_ == "NOUN" and t.lemma_.casefold() in _REPORT_NOUNS]
        refs = [(t, *_reference(t, holder, dates, anchor, following=following)) for t in report_nouns]
        # A newly asserted reporting event establishes its own local referent.
        # A confirmation/denial ABOUT this report does not reset that referent.
        for event in doc:
            if (event.dep_ not in {"ROOT", "conj"} or event.pos_ != "VERB"
                    or event.lemma_.casefold() not in _REPORT_EVENTS
                    or any(reference == "TARGET" for _, reference, _ in refs)):
                continue
            subjects = [t for t in event.children if t.dep_ == "nsubj"]
            if len(subjects) == 1 and _name(subjects[0]) is not None:
                anchor = "DISTINCT"
                transitions.append(dict(start=other["start"], end=other["end"],
                    kind="NEW_EXPLICIT_REPORT_EVENT", predicate=_p(event),
                    subject=_name(subjects[0])["proofs"], new_anchor=anchor))
        for noun, reference, license_ in refs:
            reasons, governing = _material(noun)
            # A different named performer's reporting act is not this holder's
            # announcement. Possession alone never assigns a physical executor.
            for action in noun.ancestors:
                owner = account._subject(action) if action.pos_ in {"VERB", "AUX"} else None
                named = _name(owner)
                if named is not None and named["key"] != holder["key"]:
                    reference, license_ = "DISTINCT", "EXPLICIT_OTHER_REPORTING_PERFORMER"
                    break
            mentions.append(dict(start=other["start"], end=other["end"], report_nominal=_p(noun),
                reference=reference, reference_license=license_, material_reasons=reasons,
                governing_proofs=governing))
            if reference == "TARGET" and reasons:
                holds.append(dict(start=other["start"], end=other["end"], text=other["text"],
                    reasons=reasons, report_nominal=_p(noun), governing_proofs=governing,
                    signed_opposition_inferred=False))
            if reference == "DISTINCT":
                anchor = "DISTINCT"
        # Preserve V2's coercion and literal-holder opposition protections, but
        # only while this discourse still concerns the selected announcement.
        lemmas = {t.lemma_.casefold() for t in doc}
        if anchor == "TARGET" and lemmas & {"withdraw", "withdrawal"}:
            reasons = []
            if any(t.pos_ == "VERB" and t.lemma_.casefold() in {"force", "coerce", "compel"} for t in doc):
                reasons.append("EXPLICIT_COERCIVE_WITHDRAWAL_QUALIFICATION")
            for event in doc:
                if event.pos_ != "VERB" or event.lemma_.casefold() not in {"oppose", "resist", "refuse"}:
                    continue
                subjects = [t for t in event.children if t.dep_ == "nsubj"]
                if len(subjects) == 1:
                    named = _name(subjects[0])
                    if (named is not None and named["key"] == holder["key"]
                            or subjects[0].pos_ == "PRON" and subjects[0].lower_ == "it"):
                        reasons.append("HOLDER_OPPOSED_THE_WITHDRAWAL")
            if reasons:
                holds.append(dict(start=other["start"], end=other["end"], text=other["text"],
                    reasons=sorted(set(reasons)), signed_opposition_inferred=False))
    return dict(version=VERSION, page_sha256=page["source_sha256"],
        selected_unit_span=[unit["start"], unit["end"]],
        checked_paragraphs=[dict(start=a, end=b, text=page["text"][a:b], text_sha256=digest(page["text"][a:b])) for a, b in selected],
        scope="SELECTED_PARAGRAPH_PLUS_IMMEDIATELY_FOLLOWING_PARAGRAPH_WITH_LOCAL_REFERENT",
        report_mentions=mentions, discourse_transitions=transitions, holds=holds,
        source_text_modified=False, signed_opposition_inferred=False,
        exhaustive_document_discourse_or_counter_screen=False)


def _personnel(noun):
    senses = lexicon().synsets(noun.text.casefold().replace(" ", "_"), pos="n")
    selected = next((s for s in senses if s.name() == "military_personnel.n.01"), None)
    return dict(synset=selected.name(), lemma=noun.text, resource=binding()) if selected else None


def _passive_report(doc):
    matrix = _matrix(doc)
    if matrix is None or matrix["root"].lemma_.casefold() != "announce":
        return None
    verb = matrix["clause"]
    body = [t for t in _lex(doc) if t.i not in matrix["used"]]
    if (verb.lemma_.casefold() != "withdraw" or verb.tag_ != "VBN" or len(body) < 8
            or body[0].lower_ != "that" or body[0].dep_ != "mark" or body[0].head != verb
            or [t.lower_ for t in body[-3:]] != ["would", "be", verb.lower_]
            or body[-3].dep_ != "aux" or body[-2].dep_ != "auxpass"
            or body[-3].head != verb or body[-2].head != verb):
        return None
    core = body[1:-3]
    if (len(core) < 4 or _number(core[0]) is None or core[1].pos_ != "NOUN"
            or core[0].dep_ != "nummod" or core[0].head != core[1]
            or core[1].dep_ != "nsubjpass" or core[1].head != verb
            or core[2].lower_ != "from" or _personnel(core[1]) is None):
        return None
    ands = [i for i, t in enumerate(core) if t.lower_ == "and" and t.pos_ == "CCONJ"]
    if len(ands) > 1:
        return None
    at = ands[0] if ands else len(core)
    first = _linear_location(core[2], core[3:at])
    if first is None:
        return None
    tuples = [dict(quantity=_number(core[0]), location=first, quantity_proof=_p(core[0]),
        predicate_ellipsis=False, personnel_head_proof=_p(core[1]))]
    if ands:
        if at + 3 >= len(core) or _number(core[at + 1]) is None or core[at + 2].lower_ != "from":
            return None
        second = _linear_location(core[at + 2], core[at + 3:])
        if second is None:
            return None
        tuples.append(dict(quantity=_number(core[at + 1]), location=second,
            quantity_proof=_p(core[at + 1]), predicate_ellipsis=True,
            personnel_head_proof=_p(core[1]),
            license="CLOSED_EXPLICIT_AND_NUM_FROM_LOCATION_INHERITS_SAME_PATIENT_HEAD_AND_PASSIVE"))
    matrix.update(tuples=tuples, patient=core[1], patient_type=_personnel(core[1]),
        predicate="withdraw", modal_proofs=[_p(t) for t in body[-3:]],
        complete_lexical_token_coverage=True)
    return matrix


def _tuple_key(row):
    return row["quantity"], row["location"]["preposition"], row["location"]["name"]


def _public_passive(base, atom):
    spans = atom.get("query_spans", [])
    if len(spans) != 1:
        return None
    span = spans[0]
    query = base.case["query"]
    if (query[span["start"]:span["end"]] != span["text"]
            or (span["start"], span["end"]) not in
                {(s["start"], s["end"]) for s in sentences(query)}):
        return None
    public = _passive_report(base.engine.parse(span["text"]))
    target = _passive_report(base.engine.parse(atom["text"]))
    if (public is None or target is None or len(target["tuples"]) != 1
            or public["holder"]["key"] != target["holder"]["key"]
            or [_normal(d["text"]) for d in public["dates"]] != [_normal(d["text"]) for d in target["dates"]]
            or public["patient"].text.casefold() != target["patient"].text.casefold()):
        return None
    matches = [i for i, t in enumerate(public["tuples"]) if _tuple_key(t) == _tuple_key(target["tuples"][0])]
    if len(matches) != 1:
        return None
    return target, dict(query_span=deepcopy(span), branch_index=matches[0],
        public_tuples=public["tuples"], full_public_operator_retained=True)


def supplement(matcher, atom, page, unit, control):
    base = getattr(matcher, "baseline", matcher)
    if (base.case["task"] not in {"reconstruction", "hypothesis"} or atom.get("kind") != "proposition"
            or control.get("direction") not in {"PARTIAL", "UNRESOLVED"}
            or any(control.get(k) for k in ("source_account_policy_withheld", "root_content_withheld",
                "root_content_policy_applicable", "potential_counter", "unbound_material_counter"))):
        return control
    public_plan(base.case, dict(atoms=[atom], query_sha256=digest(base.case["query"])))
    pi = base.positions.get(page.get("id"))
    if pi is None or page != base.corpus.pages[pi] or digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Inventory announcement requires the complete bound raw page")
    citation = base.policy.citation(pi, unit["start"], unit["end"])
    if citation != control.get("citation") or citation["text"] != unit.get("text", unit.get("quote")):
        raise ValueError("Inventory announcement citation does not replay")
    if (len(citation["text"]) > 2048 or len(atom["text"]) > 2048
            or (unit["start"], unit["end"]) not in {(s["start"], s["end"]) for s in sentences(page["text"])}):
        return control
    with offline():
        doc = base.engine.parse(citation["text"])
        if _prefix_blocker(page, unit["start"], base.engine) or raw_envelope_holds(base, page, citation, doc):
            return control
        public = _public_passive(base, atom)
        inventory = _inventory_report(doc)
        if public is None or inventory is None:
            return control
        target, projection = public
        wanted = target["tuples"][0]
        if (inventory["root"].lemma_.casefold() != "announce"
                or target["holder"]["key"] != inventory["holder"]["key"]
                or inventory["predicate"] != "withdraw"
                or inventory["inventory_text"].casefold() != "armed forces"
                or inventory["total_measure"]["unit"].casefold() != "men"
                or any(t["location"]["preposition"] != "from" for t in inventory["tuples"])
                or target["dates"] and [_normal(d["text"]) for d in target["dates"]] !=
                    [_normal(d["text"]) for d in inventory["dates"]]):
            return control
        matches = [i for i, row in enumerate(inventory["tuples"]) if _tuple_key(row) == _tuple_key(wanted)]
        if len(matches) != 1:
            return control
        qualification = audit(base, page, unit, inventory["holder"], inventory["dates"])
        if (qualification["holds"] or account._report_context(base, page, unit["end"], actor=inventory["subject"]) is None
                or account._reporting_tail_holds(base, page, unit["end"], inventory["subject"])):
            return control
        scope = dict(kind="QUERIED_OPERATOR_ONLY", contract=TYPE,
            inner_execution_certified=False, event_join_certified=False, world_truth_certified=False,
            physical_executor_certified=False, canonical_identity_certified=False,
            completed_withdrawal_certified=False, order_issuance_certified=False,
            physical_passive_agent_explicit=False)
        proof = dict(version=VERSION, type=TYPE, scope=scope, citation=deepcopy(citation),
            full_source_page_sha256=page["source_sha256"], query_sha256=digest(base.case["query"]),
            atom_sha256=digest(atom), strict_control_sha256=digest(control),
            source_holder=inventory["holder"]["proofs"], source_operator=_p(inventory["root"]),
            query_holder=target["holder"]["proofs"], query_operator=_p(target["root"]),
            source_report_dates=inventory["dates"], query_report_dates=target["dates"],
            public_projection=projection, query_tuple=wanted,
            source_inventory_reference=inventory["inventory_owner_reference"],
            source_inventory_type=dict(rule="OWN_ARMED_FORCES_COUNTED_AS_MEN_ARE_MILITARY_PERSONNEL",
                inventory_text=inventory["inventory_text"], measure=inventory["total_measure"],
                query_wordnet_same_synset=target["patient_type"], generic_possession_to_agent=False),
            source_tuples=inventory["tuples"], selected_source_tuple=matches[0],
            aggregate_measure=inventory["total_measure"], reported_future=inventory["future_inventory_scope"],
            query_future=target["modal_proofs"],
            future_scope_rule="UNCONDITIONAL_REPORTED_FUTURE_WILL_OR_TO_BE_TO_WOULD_BE_NOT_COMPLETION",
            report_qualification_audit=qualification, complete_required_account=True,
            source_text_modified=False, full_parent_operators_retained=True,
            offset_basis="RAW_SOURCE_UNIT_AND_ATOM_RELATIVE_UNICODE_CHARACTERS_PUBLIC_SPAN_RECORDED")
        # Sets are internal parser bookkeeping, not transferable proof values.
        def serial(value):
            if isinstance(value, dict):
                return {k: serial(v) for k, v in value.items() if k != "tokens"}
            if isinstance(value, list):
                return [serial(v) for v in value]
            return value
        proof = serial(proof)
        row = deepcopy(control)
        row.update(version=VERSION, direction="SUPPORT", complete_required_frames=True,
            source_inventory_announcement_certificate=proof, strict_inventory_announcement_control=deepcopy(control),
            support_scope="QUERIED_OPERATOR_ONLY", queried_account_scope=scope, qualified=True,
            qualified_account="The eligible source reports the named holder's own military-personnel inventory announcement with the exact count/from/location partition. No completed withdrawal, physical executor, orders, identity or world truth is certified.",
            source_assertion_not_world_truth=True, actual_inner_event_established=False,
            world_truth_certified=False, canonical_identity_certified=False,
            cross_atom_or_event_join_certified=False, event_bindings=[])
        row["checks"] = dict(eligible_source="PASS", raw_quote="PASS", public_branch="PASS",
            own_military_inventory="PASS", exact_quantity_from_location_tuple="PASS",
            queried_announcement="PASS", inner_execution="NOT_CERTIFIED", event_join="NOT_CERTIFIED")
        return row


def replay(matcher, atom, page, unit, control, certificate):
    produced = supplement(matcher, atom, page, unit, control)
    if certificate.get("version") != VERSION or produced.get(PROOF_FIELD) != certificate:
        raise ValueError("Inventory announcement proof differs from trusted raw producer replay")
    return deepcopy(certificate)
