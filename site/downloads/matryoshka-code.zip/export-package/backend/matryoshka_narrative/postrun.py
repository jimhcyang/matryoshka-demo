"""Source-bound model digest after local inference; cannot change its verdict."""
from copy import deepcopy

from matryoshka_demo.io import digest
from .api import call

VERSION = "narrative-source-digest/2"
PROMPT = ("Explain this saved local result in at most three short analyst-facing statements. "
    "Use only the supplied question, local decisions and original quotations. Distinguish what "
    "the sources establish from contextual suggestions and unresolved gaps; a reported claim "
    "does not establish its embedded event. Cite the supplied source IDs for each factual "
    "statement. Do not add historical knowledge, fill an unknown answer, rerank candidates or "
    "override the local verdict. Missing evidence is not opposition. Return only the schema.")


def digest_input(packet, trace):
    from .traces import decision_items, evidence_inventory
    if packet.get("native_checksum", digest(packet["result"])) != digest(packet["result"]):
        raise ValueError("Saved local result checksum changed before model review")
    if trace.get("sha256") != digest({k:v for k,v in trace.items() if k != "sha256"}):
        raise ValueError("Trace seal changed before model review")
    if trace.get("case_id") != packet["case"]["case_id"]:
        raise ValueError("Digest trace belongs to another question")
    candidates = [packet["result"]]
    if packet["case"]["task"] == "redaction":
        candidates.extend(dict(packet["result"], readings=[row]) for row in packet["result"]["readings"])
    inputs = [dict(case=packet["case"], plan=packet["plan"], result=result,
        retrieval=packet["retrieval"]) for result in candidates]
    inputs += [dict(value, inspected_page_ids=value["result"]["inspected_page_ids"])
        for value in list(inputs) if "inspected_page_ids" in value["result"]]
    matches = [value["result"] for value in inputs if trace["input_sha256"] == digest(value)]
    if not matches:
        raise ValueError("Trace does not bind the saved local result and search")
    result = matches[0]
    reading = None
    if packet["case"]["task"] == "redaction":
        if len(result.get("readings", [])) != 1:
            raise ValueError("Redaction digest requires exactly one trace-bound reading")
        reading = result["readings"][0]
        reading_id = reading.get("reading_id", reading.get("reading", {}).get("id"))
        if not reading_id or trace.get("reading_id") != reading_id:
            raise ValueError("Digest reading selector does not match the trace-bound native branch")
    items = decision_items(packet["case"], packet["plan"], result)
    inventory = evidence_inventory(items)
    sources = {}
    for row in inventory:
        for ref in row.get("source_refs", row.get("citations", [])):
            sources[digest(ref)] = ref
    # The trace already replays every exact source span against its bound index.
    for path in trace.get("paths", []):
        for ref in path.get("decision_source_refs", []):
            if digest(ref) not in sources:
                raise ValueError("Trace adds a source absent from the saved decision")
    payload = dict(task=packet.get("public_task", packet["case"]["task"]),
        query=packet["case"]["query"], packet_sha256=digest(packet),
        local_status=result.get("status"),
        decisions=[dict(id=i["id"], text=i["text"], status=i["status"]) for i in items],
        sources=[dict(id=k, **deepcopy(v)) for k, v in sources.items()],
        postrun_only=True, answers_or_historical_references_supplied=False)
    if reading is not None:
        payload.update(summary_scope="SELECTED_READING",
            reading_id=reading.get("reading_id", reading.get("reading", {}).get("id")),
            local_status=reading.get("status", result.get("status")),
            constructor_status=reading.get("reading", {}).get("constructor_status"),
            constructor_reading=deepcopy(reading.get("constructor_reading")))
    return payload


def make_digest(packet, trace, api_root):
    payload = digest_input(packet, trace)
    if payload.get("summary_scope") == "SELECTED_READING" and not payload["decisions"]:
        return dict(version=VERSION,
            status="NOT_MODELED" if payload.get("constructor_status") == "requires_new_constructor" else "NO_CANDIDATES",
            text="", statements=[], citations=[],
            reading_id=payload["reading_id"], summary_scope="SELECTED_READING",
            withholding_reason="No candidate decisions were saved for this reading; no model summary was requested. Constructor status: " + str(payload.get("constructor_status")),
            packet_sha256=digest(packet), payload_sha256=digest(payload),
            postrun_only=True, native_decisions_or_ranks_modified=False)
    schema = dict(type="object", additionalProperties=False, properties=dict(statements=dict(type="array",
        items=dict(type="object", additionalProperties=False,
            properties=dict(text=dict(type="string"), kind=dict(type="string", enum=["source_finding", "context", "gap"]),
                source_ids=dict(type="array", items=dict(type="string"))),
            required=["text", "kind", "source_ids"]))), required=["statements"])
    raw, receipt = call(api_root, "narrative_source_digest_v1", payload, PROMPT, schema,
        model="gpt-6.1-sol", max_output_tokens=2000)
    if len(raw["statements"]) > 3:
        raise ValueError("Digest exceeds its stated analyst-facing bound")
    sources = {r["id"]: {k: v for k, v in r.items() if k != "id"} for r in payload["sources"]}
    for row in raw["statements"]:
        if set(row["source_ids"]) - set(sources) or row["kind"] == "source_finding" and not row["source_ids"]:
            raise ValueError("Digest cites an absent source or an ungrounded finding")
    return dict(version=VERSION, status="COMPLETED", text="\n\n".join(r["text"] for r in raw["statements"]),
        statements=raw["statements"], citations=list(sources.values()), receipt=receipt,
        reading_id=payload.get("reading_id"), summary_scope=payload.get("summary_scope", "CASE"),
        packet_sha256=digest(packet), payload_sha256=digest(payload),
        output_sha256=digest(raw), model_assessment_not_gold=True,
        postrun_only=True, native_decisions_or_ranks_modified=False)
