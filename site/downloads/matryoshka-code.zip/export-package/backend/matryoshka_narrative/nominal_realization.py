"""Public-boundary coordination, after literal source nomination only."""
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest

VERSION = "public-coordinate-boundary/1"
NOMINAL = frozenset({"NOUN", "PROPN", "PRON", "NUM"})
FUNCTION = frozenset({"VERB", "AUX", "ADP", "SCONJ", "CCONJ", "DET", "PART"})


def coordinate_boundary(case, reading, parse):
    """Do not put AND before the first item after a verb or preposition.

    A declared coordinate reading is not evidence that a preceding member is
    actually printed. Both raw and lowercase boundary views must permit a
    nominal predecessor. The latter is a grammar control, never source text.
    No candidate contents, source, answer, identity or fact is accepted here.
    """
    marker = case["focal_marker"]
    if not marker or case["query"].count(marker) != 1:
        raise ValueError("One visible focal marker is required")
    left = case["query"].split(marker)[0]
    result = dict(version=VERSION, public_query_sha256=digest(case["query"]),
                  add_connector=False, connector="and", source_evidence_credit=False,
                  source_or_answer_read=False, factual_support_certified=False)
    if reading.get("function") != "coordinate_member":
        return dict(result, reason="NOT_A_DECLARED_COORDINATE_MEMBER")
    if re.search(r"\band\s*$", left, re.I):
        return dict(result, reason="CONNECTOR_ALREADY_VISIBLE")
    masks = list(MASK.finditer(left))
    if masks and not any(c.isalnum() for c in left[masks[-1].end():]):
        return dict(result, reason="PRECEDING_MEMBER_IS_OPAQUE")
    visible = MASK.sub(lambda m: " " * len(m.group()), left)
    views = []
    for text in (visible, visible.lower()):
        doc = parse(text)
        if doc.text != text:
            raise ValueError("Public-boundary parser changed its input")
        tokens = [t for t in doc if not t.is_space and not t.is_punct]
        if not tokens:
            return dict(result, reason="NO_VISIBLE_PRECEDING_MEMBER")
        tail = tokens[-1]
        views.append(dict(text=tail.text, start=tail.idx, end=tail.idx + len(tail), pos=tail.pos_))
    result["boundary_views"] = views
    if any(v["pos"] in FUNCTION for v in views):
        return dict(result, reason="BOUNDARY_ENDS_WITH_A_FUNCTION_OR_PREDICATE")
    if not all(v["pos"] in NOMINAL for v in views):
        return dict(result, reason="PRECEDING_NOMINAL_MEMBER_UNESTABLISHED")
    return dict(result, add_connector=True, reason="VISIBLE_NOMINAL_PREDECESSOR_FOR_COORDINATE_READING")
