"""Precision-only P1 guard layered over immutable qualified-support v1.1.

This separate opt-in control never upgrades a v1.1 row. Exact argument heads,
complete proper names, compatible aspect/clock and unapproximated quantities are
required in addition to every original source/role/qualification check.
"""
from collections import Counter
from copy import deepcopy
import re

from . import qualified_support as previous


VERSION = "narrative-qualified-source-support-control/2"
_APPROX = re.compile(r"\b(?:about|approximately|almost|around|roughly|nearly|circa|"
    r"some|over|under|at\s+least|at\s+most|up\s+to|more\s+than|less\s+than)\b", re.I)
_ARG_ROOT = {"nsubj", "csubj", "nsubjpass", "dobj", "obj", "pobj", "attr", "oprd", "acomp", "dative"}


def _heads(tokens):
    ids = {t.i for t in tokens}
    return [t for t in tokens if t.head.i not in ids or t.head.i == t.i or t.dep_ == "conj"]


def _name(root):
    """Complete proper-name compounds, never a possessor or arbitrary suffix."""
    names = []
    def visit(token):
        if token.pos_ == "PROPN":
            names.append(token)
        for child in token.children:
            if child.dep_ in {"compound", "flat", "name", "nmod"}:
                visit(child)
    visit(root)
    return tuple(previous._lemma(t) for t in sorted(names, key=lambda t:t.i))


def _compatible_head(wanted, offered):
    if previous._lemma(wanted) != previous._lemma(offered):
        return False
    if wanted.pos_ == "PROPN" or offered.pos_ == "PROPN":
        return (wanted.pos_ == offered.pos_ == "PROPN" and _name(wanted)
            and _name(wanted) == _name(offered))
    if _name(wanted) or _name(offered):
        return _name(wanted) == _name(offered)
    return True


def _argument_errors(wanted, offered):
    errors, proofs = [], {}
    for role, left, right in [("actor", wanted["agents"], offered["agents"]),
            *[(role, tokens, offered["roles"].get(role, [])) for role,tokens in wanted["roles"].items()]]:
        query_heads = _heads(left)
        raw_heads = _heads(right)
        matches = []
        if not query_heads:
            errors.append("V2_UNVERIFIED_ARGUMENT_HEAD:" + role)
            continue
        for head in query_heads:
            if role == "actor" and head.pos_ != "PROPN":
                errors.append("V2_ACTOR_HEAD_IS_NOT_A_LITERAL_PROPER_NAME")
                continue
            found = next((other for other in raw_heads if _compatible_head(head, other)), None)
            if found is None:
                errors.append("V2_EXACT_HEAD_OR_COMPLETE_NAME_MISMATCH:" + role)
            else:
                matches.append(dict(query_head=previous._proof([head]), source_head=previous._proof([found]),
                    query_complete_proper_name=list(_name(head)), source_complete_proper_name=list(_name(found))))
        proofs[role] = matches
    return errors, proofs


def _clock(token):
    auxiliaries = [c for c in token.children if c.dep_ in {"aux", "auxpass", "cop"}]
    finite = [t for t in [token, *auxiliaries] if t.tag_ in {"VBD", "VBP", "VBZ"}]
    finite = next((t for t in auxiliaries if t in finite), finite[0] if finite else None)
    tense = ("past" if finite.tag_ == "VBD" else "present") if finite is not None else "nonfinite"
    return dict(tense=tense, modals=[previous._lemma(t) for t in auxiliaries if t.tag_ == "MD"],
        perfect=any(previous._lemma(t) == "have" for t in auxiliaries),
        progressive=token.tag_ == "VBG" or any(t.tag_ == "VBG" and previous._lemma(t) == "be" for t in auxiliaries),
        infinitival=any(t.tag_ == "TO" for t in auxiliaries),
        completed_participle=token.tag_ == "VBN" and token.dep_ in {"acl", "relcl"}
            and not auxiliaries,
        predicate_tag=token.tag_, date_padding=False)


def _clock_errors(wanted, offered):
    query, source = _clock(wanted), _clock(offered)
    errors, projection = [], "EXACT_POSITIVE_CLOCK_AND_ASPECT"
    if query["modals"] != source["modals"]:
        errors.append("V2_MODAL_CLOCK_MISMATCH")
    if query["progressive"] != source["progressive"]:
        errors.append("V2_PROGRESSIVE_ASPECT_MISMATCH")
    historical = (query["tense"] == "past" and not query["modals"]
        and not query["perfect"] and not query["progressive"]
        and not source["modals"] and not source["progressive"]
        and (source["completed_participle"] or source["perfect"] and source["tense"] in {"past", "present"}))
    if historical:
        projection = "POSITIVE_HISTORICAL_COMPLETION_NOT_CONTINUED_STATE"
    elif (query["tense"] != source["tense"] or query["perfect"] != source["perfect"]
            or query["infinitival"] != source["infinitival"]):
        errors.append("V2_CLOCK_OR_PERFECT_ASPECT_MISMATCH")
    return errors, dict(query=query, source=source, positive_projection=projection,
        source_publication_is_not_event_time=True)


def _quantity_scope(frame):
    tokens = sorted({t.i:t for ts in frame["roles"].values() for t in ts}.values(), key=lambda t:t.i)
    numbers = [t for t in tokens if t.pos_ == "NUM"]
    if not numbers:
        return dict(numbers=[], approximations=[], proofs=[])
    text = " ".join(t.text for t in tokens)
    return dict(numbers=[t.text for t in numbers],
        approximations=[m.group() for m in _APPROX.finditer(text)],
        proofs=previous._proof(tokens), scalar_reasoning_implemented=False)


def evaluate(corpus, case, plan, *, inspected_page_ids, source_index,
             fact_index=None, nlp=None, record_budget=6000, candidate_budget_per_atom=80):
    """Same explicit pool/source inputs; precision-only, experimental downgrade."""
    if nlp is None:
        from matryoshka_next.readings import _model
        nlp = _model()
    result = previous.evaluate(corpus, case, plan, inspected_page_ids=inspected_page_ids,
        source_index=source_index, fact_index=fact_index, nlp=nlp,
        record_budget=record_budget, candidate_budget_per_atom=candidate_budget_per_atom)
    inherited_version = result["version"]
    pages = {p["id"]:p for p in corpus.pages}
    docs = {}
    downgraded = 0
    for atom, public in zip(result["atoms"], plan["atoms"]):
        target, error = previous._target(case, public, nlp)
        for row in atom["candidates"]:
            row["prior_control_status"] = row["status"]
            if row["status"] != "QUALIFIED_SOURCE_SUPPORT":
                continue
            reasons = []
            if target is None:
                reasons.append("V2_PUBLIC_QUERY_FRAME_UNVERIFIED:" + str(error))
            else:
                pid = row["citation"]["canonical_page_id"]
                if pid not in docs:
                    docs[pid] = nlp(pages[pid]["text"])
                bindings = row.get("raw_role_bindings", {}).get("predicates", [])
                predicate = next((t for t in docs[pid] if t.idx == bindings[0]["start"]
                    and t.idx + len(t) == bindings[0]["end"]), None) if bindings else None
                if predicate is None:
                    reasons.append("V2_LITERAL_PREDICATE_BINDING_MISSING")
                else:
                    offered = previous._frame(predicate)
                    errors, heads = _argument_errors(target, offered)
                    reasons.extend(errors)
                    errors, clock = _clock_errors(target["predicate"], predicate)
                    reasons.extend(errors)
                    q_quantity, s_quantity = _quantity_scope(target), _quantity_scope(offered)
                    if q_quantity["approximations"] or s_quantity["approximations"]:
                        reasons.append("V2_APPROXIMATE_QUANTITY_SCOPE_UNIMPLEMENTED")
                    row["v2_raw_certificate"] = dict(argument_heads=heads, clock=clock,
                        query_quantity_scope=q_quantity, source_quantity_scope=s_quantity,
                        canonical_identity_certified=False, no_title_or_name_suffix_stripping=True)
            if reasons:
                downgraded += 1
                row["status"] = "PARTIAL"
                row["reasons"] = sorted(set(row["reasons"] + reasons))
        atom["status"] = ("QUALIFIED_SOURCE_SUPPORT" if any(c["status"] == "QUALIFIED_SOURCE_SUPPORT" for c in atom["candidates"])
            else "PARTIAL" if any(c["status"] in {"PROPOSAL", "PARTIAL"} for c in atom["candidates"]) else "NO_INFO")
    result.update(version=VERSION, inherited_control_version=inherited_version,
        atom_counts=dict(Counter(a["status"] for a in result["atoms"] if a["required"])),
        precision_only_no_upgrades=True,
        p1_guards=dict(exact_argument_heads=True, exact_complete_proper_names=True,
            no_borrowed_possessor_identity=True, compatible_clock_aspect=True,
            approximation_held_not_erased=True, downgraded_rows=downgraded))
    result["limitations"] += ["V2 never upgrades v1.1 proposals; unverified title boundaries remain partial.",
        "All scalar/approximate quantity semantics remain unimplemented rather than silently normalized."]
    return result
