"""Opt-in, API0 discovery measurements. Not imported by ordinary inference.

Source and draft selectors never accept reference witnesses or gate outcomes.
The separate funnel observer accepts evaluation-only witnesses and preserves
unknown stages. Connectivity, source wording and selection are never support.
"""
from copy import deepcopy

from matryoshka_demo.io import digest
from matryoshka_next.facts import public_plan

VERSION = "narrative-requirement-discovery-diagnostics/1.1"
SOURCE_CONTROL = "atom-lexical-reserve/1"
DRAFT_CONTROL = "bound-node-round-robin/1"
STAGES = ("eligible_source", "discovered_document", "admitted_document",
          "admitted_page", "inspected_page", "inspected_unit",
          "candidate_enumerated", "candidate_checked", "focal_assessed", "shortlist")


def _integer(value, name, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def _unique(values):
    return list(dict.fromkeys(values))


def allocate_source_slots(case, plan, retrieval, *, page_budget=16,
                          supplemental_document_slots=0, supplemental_page_slots=0):
    """Compare bounded lexical reservations with unchanged BM25/graph/RRF.

    Only saved atom hits are eligible for the reserve. Document and page slots
    replace primary slots, never enlarge the total. Remaining slots retain the
    fused ordering. The return value is a sidecar, not a modified retrieval.
    """
    case = public_plan(case, plan)
    if plan.get("leads"):
        raise ValueError("Generated leads are outside this control")
    _integer(page_budget, "page_budget", 1)
    _integer(supplemental_document_slots, "supplemental_document_slots")
    _integer(supplemental_page_slots, "supplemental_page_slots")
    receipt = retrieval["receipt"]
    document_budget = _integer(receipt["document_budget"], "document_budget", 1)
    if supplemental_document_slots > document_budget or supplemental_page_slots > page_budget:
        raise ValueError("Reserve cannot exceed the total budget")
    corpus, policy = retrieval["eligible"].corpus, retrieval["source_policy"]
    if policy.corpus is not corpus or policy.case != case:
        raise ValueError("Source policy belongs to another corpus or public case")
    if receipt.get("query_sha256", digest(case["query"])) != digest(case["query"]):
        raise ValueError("Retrieval receipt belongs to another public question")
    if receipt.get("cutoff", case["date"]) != case["date"] or receipt.get(
            "whole_origin_excluded", case["document_id"]) != case["document_id"]:
        raise ValueError("Retrieval receipt has another cutoff or excluded origin")
    page_by_id = {p["id"]: i for i, p in enumerate(corpus.pages)}
    if len(page_by_id) != len(corpus.pages):
        raise ValueError("Duplicate page identities")

    def bound(pi):
        page = corpus.pages[pi]
        original = policy.bound_pages.get(page["id"])
        if (original is None or any(original.get(k) != page.get(k) for k in
                ("id", "text", "document_id", "date", "source_sha256",
                 "classification", "permitted", "visibility", "corpus"))
                or digest(page["text"]) != page["source_sha256"]):
            raise ValueError("Source page does not replay against the complete index")
        return policy.allowed(pi)

    atoms = {a["id"]: a for a in plan["atoms"]}
    searches = []
    marker = case.get("focal_marker")
    focal = {a["id"] for a in atoms.values() if marker and marker in a["text"]}
    for index, row in enumerate(receipt["search_queries"]):
        ids = set(row.get("atom_ids", []))
        if (row.get("kind") != "atom" or not ids or not ids <= atoms.keys()
                or row.get("query") not in {atoms[a]["text"] for a in ids}):
            raise ValueError("Reservation requires an unchanged saved atom search")
        hits = []
        for hit in row["top_pages"]:
            pi = page_by_id[hit["page_id"]]
            if corpus.pages[pi]["document_id"] != hit["document_id"]:
                raise ValueError("Search page/document mismatch")
            if bound(pi):
                hits.append(pi)
        searches.append((not bool(ids & focal), index, hits))
    searches.sort(key=lambda row: row[:2])
    # At each lexical depth, give every faithful atom its opportunity.
    lexical = _unique(pi for depth in range(max((len(s[2]) for s in searches), default=0))
                      for _, _, hits in searches if depth < len(hits) for pi in [hits[depth]])
    allowed = {i for i in range(len(corpus.pages)) if policy.allowed(i)}
    allowed_docs = {corpus.pages[i]["document_id"] for i in allowed}
    original_docs = _unique(receipt["document_order"])
    if len(original_docs) > document_budget or not set(original_docs) <= allowed_docs:
        raise ValueError("Original documents exceed budget or fail source policy")
    primary_docs = original_docs[:document_budget - supplemental_document_slots]
    extra_docs = []
    for pi in lexical:
        did = corpus.pages[pi]["document_id"]
        if did not in primary_docs and did not in extra_docs and len(extra_docs) < supplemental_document_slots:
            extra_docs.append(did)
    documents = _unique(primary_docs + extra_docs + original_docs)[:document_budget]
    admitted = [i for i in allowed if corpus.pages[i]["document_id"] in documents]
    admitted.sort(key=lambda i: (retrieval["page_ranks"].get(i, len(corpus.pages) + 1), corpus.pages[i]["id"]))
    primary = admitted[:page_budget - supplemental_page_slots]
    extra = [i for i in lexical if i in admitted and i not in primary][:supplemental_page_slots]
    selected = _unique(primary + extra + admitted)[:page_budget]
    for pi in admitted:
        if not bound(pi):
            raise ValueError("Admitted source fails complete policy replay")
    primary = [pi for pi in selected if pi not in extra]
    primary_admitted_documents = [d for d in documents if d not in extra_docs]
    primary_documents = _unique(corpus.pages[i]["document_id"] for i in primary)
    supplemental_documents = [d for d in _unique(corpus.pages[i]["document_id"] for i in extra)
                              if d not in primary_documents]
    return dict(version=VERSION, control=SOURCE_CONTROL, document_budget=document_budget,
        page_budget=page_budget, supplemental_document_slots=supplemental_document_slots,
        supplemental_page_slots=supplemental_page_slots, document_order=documents,
        admitted_page_ids=[corpus.pages[i]["id"] for i in admitted],
        inspected_page_ids=[corpus.pages[i]["id"] for i in selected],
        primary_admitted_document_ids=primary_admitted_documents, supplemental_admitted_document_ids=extra_docs,
        primary_document_ids=primary_documents, supplemental_document_ids=supplemental_documents,
        primary_page_ids=[corpus.pages[i]["id"] for i in primary],
        supplemental_page_ids=[corpus.pages[i]["id"] for i in extra],
        lexical_metadata_hits_considered=len(lexical), eligible_metadata_pages_considered=len(corpus.pages),
        source_binding_hashes_replayed=len(admitted),
        selection_only=True, source_text_parses=0, candidate_checks=0,
        factual_support_certified=False, ordinary_retrieval_modified=False,
        scores_unchanged=True, known_witness_input=False)


def select_diverse_drafts(drafts, *, budget=24):
    """Round-robin distinct source-bound index nodes at a fixed check budget.

    Input deliberately contains no fill text, target IDs, truth labels, graph
    mass or gate output. A bound node groups navigation identity only. Unknown
    nodes remain separate candidates. Call once per grammatical reading.
    """
    _integer(budget, "budget", 1)
    allowed = {"key", "node_id", "node_bound"}
    if any(set(d) != allowed or type(d["node_bound"]) is not bool
           or not isinstance(d["key"], str) or not d["key"]
           or (d["node_id"] is not None and not isinstance(d["node_id"], str))
           or (d["node_bound"] and not d["node_id"]) for d in drafts):
        raise ValueError("Use only explicit candidate keys and bound-node metadata")
    if len({d["key"] for d in drafts}) != len(drafts):
        raise ValueError("Duplicate candidate keys")
    buckets = {}
    for draft in drafts:
        key = ("node", draft["node_id"]) if draft["node_bound"] else ("draft", draft["key"])
        buckets.setdefault(key, []).append(draft["key"])
    ordered = []
    depth = 0
    while len(ordered) < min(budget, len(drafts)):
        for values in buckets.values():
            if depth < len(values) and len(ordered) < budget:
                ordered.append(values[depth])
        depth += 1
    return dict(version=VERSION, control=DRAFT_CONTROL, selected_keys=ordered,
        check_budget=budget, selected_count=len(ordered),
        distinct_bound_nodes=len({d["node_id"] for d in drafts if d["key"] in ordered and d["node_bound"]}),
        no_padding=True, canonical_identity_certified=False, factual_support_certified=False)


def requirement_funnel(requirement_ids, reference_witnesses, observations, *, reference_set_id,
                       qualifying_universe_known=False):
    """Evaluation-only counts over exact witnesses, never corpus recall by default.

    Observations are keyed by witness ID. Each stage is True/False/None (unknown).
    References must distinguish FULL_FOCAL_SUPPORT from CONTEXTUAL_WORDING or
    PARTIAL_GROUNDING. No fraction converts contextual/partial evidence to proof.
    A source-stage miss cannot erase a separately observed downstream failure.
    """
    if not reference_set_id or len(set(requirement_ids)) != len(requirement_ids) or not requirement_ids:
        raise ValueError("A declared reference set and fixed distinct requirements are required")
    if type(qualifying_universe_known) is not bool:
        raise ValueError("Explicit universe-known flag required")
    if len({r["id"] for r in reference_witnesses}) != len(reference_witnesses):
        raise ValueError("Duplicate reference witnesses")
    valid_kinds = {"FULL_FOCAL_SUPPORT", "PARTIAL_GROUNDING", "CONTEXTUAL_WORDING"}
    for ref in reference_witnesses:
        if ref["requirement_id"] not in requirement_ids or ref["kind"] not in valid_kinds:
            raise ValueError("Unknown requirement or reference scope")
        if ref["id"] not in observations:
            raise ValueError("Missing observation; use explicit unknown values")
        obs = observations[ref["id"]]
        if any(key not in obs or (obs[key] is not None and type(obs[key]) is not bool) for key in STAGES):
            raise ValueError("Every funnel stage needs a boolean or explicit unknown")
        rank = obs.get("rank")
        if rank is not None:
            _integer(rank, "rank", 1)
            if obs["shortlist"] is not True or obs["focal_assessed"] is not True:
                raise ValueError("A shortlist rank requires observed assessment and admission")
        for later, earlier in (("admitted_page", "admitted_document"), ("inspected_page", "admitted_page"),
                ("inspected_unit", "inspected_page"), ("candidate_enumerated", "inspected_unit"),
                ("candidate_checked", "candidate_enumerated"), ("focal_assessed", "candidate_checked"),
                ("shortlist", "focal_assessed")):
            if obs[later] is True and obs[earlier] is False:
                raise ValueError("Inconsistent witnessed funnel stages")
    rows = []
    for rid in requirement_ids:
        references = [r for r in reference_witnesses if r["requirement_id"] == rid]
        kinds = {}
        for kind in sorted(valid_kinds):
            refs = [r for r in references if r["kind"] == kind]
            values = [observations[r["id"]] for r in refs]
            stages = {s: dict(observed=sum(v[s] is True for v in values),
                missed=sum(v[s] is False for v in values), unknown=sum(v[s] is None for v in values)) for s in STAGES}
            kinds[kind] = dict(reference_count=len(refs), stages=stages,
                witness_at_k={str(k): sum(v.get("rank") is not None and v["rank"] <= k for v in values) for k in (1, 3, 5)},
                reference_recall_at_inspected_page=(sum(v["inspected_page"] is True for v in values) / len(refs)
                    if refs and all(v["inspected_page"] is not None for v in values) else None))
        rows.append(dict(requirement_id=rid, by_reference_kind=kinds,
            reference_status="DECLARED_REFERENCE_WITNESSES" if references else "UNMODELED_NO_REFERENCE_WITNESS"))
    return dict(version=VERSION, evaluation_only=True, reference_set_id=reference_set_id,
        qualifying_universe_known=qualifying_universe_known,
        recall_scope="EXHAUSTIVE_QUALIFYING_UNIVERSE" if qualifying_universe_known else "DECLARED_REFERENCE_SET_ONLY",
        required_unit_denominator=len(requirement_ids), rows=rows,
        reference_witnesses=deepcopy(reference_witnesses), observations=deepcopy(observations),
        missing_reference_is_corpus_absence=False, support_promoted=False)


def read_budget(*, primary_documents, supplemental_documents, primary_pages,
                supplemental_pages, candidate_checks, document_cap, page_cap, candidate_cap):
    """Exact distinct read sets; candidate checks are actual checked attempts."""
    for name, cap in (("document_cap", document_cap), ("page_cap", page_cap), ("candidate_cap", candidate_cap)):
        _integer(cap, name)
    for values in (primary_documents, supplemental_documents, primary_pages, supplemental_pages):
        if len(set(values)) != len(values):
            raise ValueError("Duplicate reads in one lane")
    if set(primary_documents) & set(supplemental_documents) or set(primary_pages) & set(supplemental_pages):
        raise ValueError("Read lanes must be disjoint")
    _integer(candidate_checks, "candidate_checks")
    nd = len(primary_documents) + len(supplemental_documents)
    np = len(primary_pages) + len(supplemental_pages)
    if nd > document_cap or np > page_cap or candidate_checks > candidate_cap:
        raise ValueError("Actual work exceeds a declared budget")
    return dict(primary_documents=len(primary_documents), supplemental_documents=len(supplemental_documents),
        total_documents=nd, primary_pages=len(primary_pages), supplemental_pages=len(supplemental_pages),
        total_pages=np, candidate_checks=candidate_checks, document_cap=document_cap,
        page_cap=page_cap, candidate_cap=candidate_cap)
