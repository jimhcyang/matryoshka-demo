"""Offline, descriptive source-context fit; not support or probability.

Consumes one persisted candidate's primary ranking.features only. No parsing,
retrieval, pooling of occurrences, gate changes, or sorting is performed.
Weights and saturation constants are authored rubric choices, not optimized.
"""
from copy import deepcopy
import math


VERSION = "narrative-context-fit/1.1"
FOCAL_TOKEN_CAP = 8
UNRECORDED_RANK = 10**12  # The constructor's explicit fallback, not a rank.
_WEIGHTS = (("focal_overlap", 0.40), ("own_relation", 0.25),
            ("own_role", 0.15), ("own_type", 0.10), ("retrieval_rank", 0.10))
_BANDS = {"exploratory_contextual": (0.00, 0.24),
          "partial_grounding": (0.35, 0.59),
          "evidence_backed_suggestion": (0.75, 0.99)}
_COUNTER_DIRECTIONS = {"Counterevidence", "Support + Counterevidence",
                       "COUNTER", "OPPOSED", "CONFLICTED"}


def _number(value, name, *, integer=False, minimum=0):
    allowed = (int,) if integer else (int, float)
    if type(value) not in allowed or not math.isfinite(value) or value < minimum:
        raise ValueError(f"{name} requires a finite {'integer' if integer else 'number'} >= {minimum}")
    return value


def _boolean(value, name):
    if value is not None and type(value) is not bool:
        raise ValueError(f"{name} requires an actual boolean or missing value")
    return None if value is None else float(value)


def _component(name, raw, value, path, formula, applicable=True):
    state = ("NOT_APPLICABLE" if applicable is False else
             "MISSING" if applicable is None or value is None else "RECORDED")
    return dict(id=name, state=state, raw=deepcopy(raw),
                value=value if state == "RECORDED" else None,
                provenance=path, normalization=formula)


def _counter_state(decision):
    """Retain opposition even if the summary flag and a saved unit disagree."""
    values = [decision.get("counterevidence")]
    units = decision.get("requirements", [])
    for unit in units:
        values.append(unit.get("counterevidence"))
        if unit.get("direction") in _COUNTER_DIRECTIONS or any(
                e.get("direction") in _COUNTER_DIRECTIONS for e in unit.get("evidence", [])):
            values.append(True)
    for value in values:
        _boolean(value, "native counterevidence")
    if any(value is True for value in values) or any(
            c.get("id") == "conflicts" and c.get("state") == "conflict"
            for c in decision.get("checklist", [])):
        return "PRESENT"
    return "RECORDED_ABSENT" if values[0] is False else "MISSING"


def _banded(index, decision, counter_state, requested):
    result = dict(value=None, band=None, formula="low + (high-low)*context_fit_index",
                  state="NOT_REQUESTED", confidence=False)
    if not requested:
        return result
    status = decision.get("status")
    if counter_state == "PRESENT":
        result["state"] = "WITHHELD_COUNTEREVIDENCE"
    elif status not in _BANDS:
        result["state"] = "WITHHELD_NATIVE_TIER"
    elif counter_state == "MISSING":
        result["state"] = "WITHHELD_MISSING_COUNTER_STATUS"
    else:
        checks = decision.get("checklist", [])
        # These are saved hard gates, not scored features or newly run checks.
        hard_ids = {"provenance", "grammar", "conflicts"}
        passed = all(any(c.get("id") == key and c.get("state") == "pass" for c in checks)
                     for key in hard_ids)
        failed = any(c.get("id") in hard_ids and c.get("state") != "pass" for c in checks)
        if not passed or failed or decision.get("source_failures"):
            result["state"] = "WITHHELD_HARD_GATE"
        elif status == "evidence_backed_suggestion" and (
                not decision.get("requirements") or
                any(r.get("coverage") != "Established" for r in decision["requirements"]) or
                any(c.get("state") != "pass" for c in checks)):
            result["state"] = "WITHHELD_INCONSISTENT_FULL_SUPPORT"
        else:
            low, high = _BANDS[status]
            result.update(state="RECORDED_NATIVE_TIER_BAND", band=[low, high],
                          value=low + (high-low)*index)
    return result


def score_candidate_fit(candidate, *, include_banded_aggregate=False) -> dict:
    """Return JSON-ready arithmetic without modifying a saved candidate.

    Comparable only within this version, the same public focal query, declared
    reading, inspected pool, feature producer, target kind and N/A signature.
    Missing components contribute no credit but retain their denominator weight;
    N/A components remove their weight. Missing is never an observed mismatch.
    Counterevidence and failed gates do not erase descriptive context fit, but
    never receive an optional evidence-tier-banded aggregate. No admission or
    correctness certificate is issued, including when a recorded gate passes.
    """
    if type(include_banded_aggregate) is not bool:
        raise ValueError("include_banded_aggregate requires a boolean")
    features = candidate.get("ranking", {}).get("features", {})
    decision = candidate.get("local_decision", {})
    target = features.get("effective_target_kind")
    if target is not None and target not in {"any", "person", "organization", "place", "property", "quantity"}:
        raise ValueError("Unrecognized effective_target_kind")
    prefix = "/ranking/features/"
    count = features.get("focal_context_coverage")
    if count is not None:
        _number(count, "focal_context_coverage", integer=True)
    term_count = features.get("focal_term_count")
    if term_count is not None:
        _number(term_count, "focal_term_count", integer=True)
    denominator = FOCAL_TOKEN_CAP if term_count is None else term_count
    method = "LEGACY_CAP_8_FALLBACK" if term_count is None else "ACTUAL_FOCAL_TERM_COUNT"
    if denominator == 0 and count not in (None, 0):
        raise ValueError("Zero focal_term_count cannot have positive focal_context_coverage")
    overlap = None if count is None or denominator == 0 else min(count, denominator)/denominator
    focal_normalization = dict(method=method, denominator=denominator,
        focal_term_count=term_count, term_count_state="MISSING" if term_count is None else "RECORDED",
        provenance=prefix+"focal_term_count", fallback_used=term_count is None,
        count_clipped=count is not None and count > denominator)
    rows = [_component("focal_overlap", count, overlap, prefix+"focal_context_coverage",
                       "min(count, focal_term_count)/focal_term_count; zero denominator is N/A"
                       if term_count is not None else
                       "min(count, 8)/8; LEGACY_CAP_8_FALLBACK, actual focal term count unrecorded",
                       applicable=denominator != 0)]

    relation = features.get("source_owned_relation_match")
    if features.get("query_carrier") or features.get("query_argument_role"):
        relation_applies = True
    elif "query_carrier" in features and "query_argument_role" in features:
        relation_applies = False
    else:
        relation_applies = None
    rows.append(_component("own_relation", relation, _boolean(relation, "source_owned_relation_match"),
                           prefix+"source_owned_relation_match", "float(saved boolean)", relation_applies))
    role = (features.get("source_owned_role_context") or {}).get("matched")
    rows.append(_component("own_role", role, _boolean(role, "source_owned_role_context.matched"),
                           prefix+"source_owned_role_context/matched", "float(saved boolean)",
                           None if target is None else target in {"person", "organization"}))
    kind = features.get("source_type_match")
    rows.append(_component("own_type", kind, _boolean(kind, "source_type_match"),
                           prefix+"source_type_match", "float(saved boolean); multiplied by local_anchor",
                           None if target is None else target != "any"))
    rank = features.get("retrieval_page_rank")
    if rank is not None:
        _number(rank, "retrieval_page_rank", integer=True, minimum=1)
    rank_value = None if rank in (None, UNRECORDED_RANK) else 1/rank
    rows.append(_component("retrieval_rank", rank, rank_value, prefix+"retrieval_page_rank",
                           "1/saved_rank; multiplied by local_anchor; constructor fallback is missing"))

    # Neither a type-correct unrelated quantity nor global relevance can stand
    # alone. Grammar, broad query overlap and numeric magnitudes earn no credit.
    anchor = max((r["value"] or 0.0 for r in rows[:3]), default=0.0)
    denominator = numerator = recorded_weight = applicable_weight = 0.0
    for row, (_, weight) in zip(rows, _WEIGHTS):
        row["weight"] = weight
        row["denominator_weight"] = 0.0 if row["state"] == "NOT_APPLICABLE" else weight
        multiplier = anchor if row["id"] in {"own_type", "retrieval_rank"} else 1.0
        row["multiplier"] = multiplier
        row["effective_value"] = None if row["value"] is None else row["value"]*multiplier
        row["weighted_contribution"] = weight*(row["effective_value"] or 0.0)
        denominator += row["denominator_weight"]
        numerator += row["weighted_contribution"]
        if row["state"] == "RECORDED":
            recorded_weight += weight
        if row["state"] != "NOT_APPLICABLE":
            applicable_weight += weight
    index = numerator/denominator
    relevance = features.get("retrieval_page_score")
    if relevance is not None:
        _number(relevance, "retrieval_page_score")
    counter_state = _counter_state(decision)
    return dict(version=VERSION, context_fit_index=index, components=rows,
        focal_normalization=focal_normalization,
        arithmetic=dict(formula="sum(weight*effective_value)/sum(non_NA_weight)",
            numerator=numerator, denominator=denominator, local_anchor=anchor,
            local_anchor_formula="max(recorded focal_overlap, own_relation, own_role); missing/NA give no anchor",
            missing_policy="NO_CREDIT_KEEP_WEIGHT; NOT_AN_OBSERVED_ZERO", na_policy="REMOVE_WEIGHT_NO_CREDIT",
            recorded_weight=recorded_weight, applicable_weight=applicable_weight),
        native_factual_status=decision.get("status"), native_coverage=decision.get("coverage"),
        counterevidence_state=counter_state,
        native_decision=deepcopy(decision),
        saved_insertion_gates={key: deepcopy(candidate.get(key)) for key in
            ("final_form_fit", "completed_head_kind_fit", "joint_slot_fit")},
        retrieval_relevance=dict(raw=relevance, provenance=prefix+"retrieval_page_score",
            state="MISSING" if relevance is None else "SAVED_OR_CONSTRUCTOR_DEFAULT",
            used_in_arithmetic=False, reason="Scale/channel unspecified; raw relevance cannot earn support credit"),
        comparability=dict(target_kind=target, focal_normalization=method,
            applicability_signature={r["id"]: "NA" if r["state"] == "NOT_APPLICABLE" else
                "UNKNOWN" if r["id"] in {"own_relation", "own_role", "own_type"} and
                (relation_applies is None if r["id"] == "own_relation" else target is None) else "APPLICABLE"
                for r in rows},
            scope="SAME_RUBRIC_VERSION_FOCAL_QUERY_READING_INSPECTED_POOL_FEATURE_PRODUCER_TARGET_AND_APPLICABILITY_ONLY"),
        evidence_tier_banded_aggregate=_banded(index, decision, counter_state, include_banded_aggregate),
        weights_are_authored_not_optimized=True, calibrated=False, correctness_probability=False,
        factual_support_implied=False, gates_recomputed=False, sorting_applied=False, api_calls=0)
