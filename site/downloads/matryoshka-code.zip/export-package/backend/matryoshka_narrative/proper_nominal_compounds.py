"""Source-only proper-compound nominations; not wired into construction.

Reviewed archive (preserved unchanged):
  phase/proper_nominal_compounds/proposals.py
  SHA-256 8a3f42d0b8be14da13d8f5c83db4bc9bd7a2bbac32f8e39a61e662c950c9e029
Archived policy/source handoff:
  phase/proper_nominal_compounds/HANDOFF.md
  SHA-256 882d724a8f97d0e53412949700e77bae7d0466438683065e65f456e79443d51c

Controlled production differences: source opacity now uses the shared
matryoshka_demo.contracts.MASK, including MASKED and canonical numbered markers.
The archived ad-hoc mask regex is not retained as an authority. AST parity is
not claimed after this repair; marker-free frozen-output parity is tested.
bind_proposals additionally returns strict original-Doc head/owner Tokens;
nominate remains the JSON-serializable source-certificate API.

Integration handoff for the constructor owner, not an implemented hook:
After proposal_spans supplies the original source Doc, call bind_proposals separately
for each usable row's ORIGINAL public reading, not its modifier-only adaptation.
Use the caller's already eligible page and same-offset analysis Doc. Append
returned rows without replacing baseline rows; head/owner are already rebound
to the exact original Doc by the public helper. Mark only_reading with that row's existing
constructor reading ID; the constructor already recognizes this routing field.
Its pre-reading dedup key must distinguish only_reading for these scoped rows,
otherwise identical spans from different readings can suppress one another.
Keep every existing source, unit, wording, grammar, evidence, budget and rank
check. Do not equate source/query carrier spellings or override their holds.

No query, answer, case, parser, corpus, native execution, source-policy check or
semantic equivalence is accepted/created here. The raw proper-compound forest
is construction provenance only, never a recovery or support certificate.
"""
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest


VERSION = "literal-proper-nominal-compound-proposals/1"
ROUTE = "COMPLETE_PROPN_DEPENDENTS_BEFORE_SOURCE_NOUN"
ROUTING = re.compile(r"^\s*(?:(?:FM|TO|INFO)\s+|AM(?:EMBASSY|CONSUL(?:ATE)?|MISSION)\b|SECSTATE\b)",re.I)
UNSAFE_DEPS = {"acl","relcl","advcl","ccomp","conj","cc","preconj","poss"}
UNSAFE_POS = {"VERB","AUX","ADP","SCONJ","CCONJ","X","SYM"}


def token_proof(token, raw):
    return dict(start=token.idx,end=token.idx+len(token),text=raw[token.idx:token.idx+len(token)],
        pos=token.pos_,tag=token.tag_,dependency=token.dep_,head_start=token.head.idx)


def scope_proof(head, raw):
    values=[]
    for token in (head,*head.ancestors):
        if token.sent != head.sent:break
        values.append(dict(token=token_proof(token,raw),qualifiers=[token_proof(c,raw)
            for c in token.children if c.dep_ in {"neg","aux","auxpass","cop","mark","advmod","det"}]))
    return values


def nominate(page, reading, original, *, analysis=None):
    """Return literal source-only modifier proposals for a caller-eligible page.

    The caller supplies immutable parsed Docs. This function does not parse,
    check source eligibility, inspect a query/answer, realize an insertion,
    equate carriers, score candidates, or invoke any native gate.
    """
    raw=page["text"]
    if original.text!=raw or page["source_sha256"]!=digest(raw):
        raise ValueError("Original source text/hash changed")
    result=dict(version=VERSION,proposals=[],construction_holds=[],nomination_only=True,
        source_eligibility_recomputed=False,grammar_or_factual_gates_executed=False)
    if not (reading.get("outer_family")=="nominal" and reading.get("variant")=="compound_modifier"
            and reading.get("function")=="modifier" and reading.get("form") in {"nominal","modifier"}):
        return dict(result,status="READING_NOT_APPLICABLE")
    view=original if analysis is None else analysis
    if view.text==raw:
        normalization="SUPPLIED_LITERAL_SOURCE_ANALYSIS"
    elif raw.isupper() and len(raw.lower())==len(raw) and view.text==raw.lower():
        normalization="LOWERCASE_SAME_RAW_TOKEN_OFFSETS"
    else:
        raise ValueError("Only literal or length-preserving uppercase analysis is accepted")
    if view.text==raw and (len(original)!=len(view) or any((a.idx,len(a))!=(b.idx,len(b)) for a,b in zip(original,view))):
        raise ValueError("Analysis token boundaries differ from the original source")

    for carrier in view:
        if carrier.pos_!="NOUN":continue
        roots=sorted((c for c in carrier.children if c.dep_=="compound" and c.pos_=="PROPN" and c.i<carrier.i),key=lambda t:t.i)
        if not roots:continue
        head=roots[-1]
        # A parser may attach adjacent name components as siblings. Keep every
        # complete owned subtree and certify the forest without reparenting it.
        subtrees=[list(root.subtree) for root in roots]
        selected=sorted({t.i:t for subtree in subtrees for t in subtree}.values(),key=lambda t:t.i)
        lexical=[t for t in selected if not t.is_space]
        a,b=min(t.idx for t in lexical),max(t.idx+len(t) for t in lexical)
        def hold(reason):
            result["construction_holds"].append(dict(reason=reason,source_span=[a,b],
                source_wording=raw[a:b],modifier_head=token_proof(head,raw),carrier=token_proof(carrier,raw),
                factual_counterevidence=False))
        if head.sent!=carrier.sent or max(t.i for t in selected)>=carrier.i:
            hold("DEPENDENT_SUBTREE_DOES_NOT_PRECEDE_OWN_CARRIER");continue
        part=view[min(t.i for t in lexical):max(t.i for t in lexical)+1]
        if any(not t.is_space and t.i not in {s.i for s in selected} for t in part):
            hold("NONCONTIGUOUS_COMPLETE_SUBTREE");continue
        if any(t.pos_ in UNSAFE_POS or t.dep_ in UNSAFE_DEPS or t.is_punct for t in part):
            hold("QUALIFIED_COORDINATED_OR_NONNOMINAL_SUBTREE");continue
        if carrier.dep_ in {"conj","appos"} or any(c.dep_ in {"conj","cc","preconj"} for c in carrier.children):
            hold("COORDINATED_OR_APPOSITIONAL_CARRIER");continue
        if raw[b:carrier.idx].strip():
            hold("UNSELECTED_WORD_BETWEEN_COMPOUND_AND_CARRIER");continue
        literal=original.char_span(a,b,alignment_mode="strict")
        owned_carrier=original.char_span(carrier.idx,carrier.idx+len(carrier),alignment_mode="strict")
        if literal is None or owned_carrier is None:
            hold("ORIGINAL_TOKEN_BOUNDARY_MISMATCH");continue
        if ([(t.idx,len(t)) for t in part]!=[(t.idx,len(t)) for t in literal]
                or len(owned_carrier)!=1):
            hold("LOCAL_MODIFIER_OR_CARRIER_TOKENIZATION_CHANGED");continue
        sentence=literal.root.sent
        if (owned_carrier.root.sent!=sentence or not sentence.start_char<=a<b<=carrier.idx<carrier.idx+len(carrier)<=sentence.end_char
                or re.search(r"\n[ \t]*\n",raw[a:carrier.idx+len(carrier)])):
            hold("ORIGINAL_SOURCE_UNIT_DOES_NOT_OWN_MODIFIER_AND_CARRIER");continue
        if MASK.search(sentence.text):
            hold("OPAQUE_SOURCE_UNIT");continue
        if any(t.ent_type_=="PERSON" for t in (*literal,*owned_carrier)) or any(
                t.ent_type_=="PERSON" for t in view if a<=t.idx<carrier.idx+len(carrier)):
            hold("PERSON_EXTRACTION_OVERLAPS_COMPOUND_OR_CARRIER");continue
        path=scope_proof(head,raw)
        if any(q["dependency"]=="neg" for step in path for q in step["qualifiers"]):
            hold("NEGATION_IN_OWN_SOURCE_SCOPE_NOT_DROPPED");continue
        offset=0
        routed=False
        for line in raw.splitlines(keepends=True):
            end=offset+len(line)
            if offset<carrier.idx+len(carrier) and end>a and ROUTING.match(line):routed=True
            offset=end
        if routed:
            hold("ROUTING_MATERIAL_NOT_A_SOURCE_COMPOUND");continue
        quote=dict(canonical_page_id=page["id"],document_id=page["document_id"],date=page["date"],
            start=sentence.start_char,end=sentence.end_char,text=raw[sentence.start_char:sentence.end_char],
            page_sha256=page["source_sha256"])
        certificate=dict(version=VERSION,route=ROUTE,source_span=[a,b],source_wording=raw[a:b],
            source_text_sha256=page["source_sha256"],normalization=normalization,
            modifier_head=token_proof(head,raw),carrier=token_proof(carrier,raw),
            original_modifier_head=token_proof(literal.root,raw),original_carrier=token_proof(owned_carrier.root,raw),
            dependency_shape="SINGLE_COMPLETE_SUBTREE" if len(roots)==1 else "COMPLETE_CONTIGUOUS_DEPENDENT_FOREST",
            modifier_roots=[token_proof(root,raw) for root in roots],
            complete_modifier_subtrees=[[token_proof(t,raw) for t in subtree] for subtree in subtrees],
            dependency_tokens=[token_proof(t,raw) for t in selected],
            original_source_sentence_span=[sentence.start_char,sentence.end_char],citation=quote,
            source_scope_chain=path,raw_words_modified=False,source_eligibility_certified=False,
            owner_identity_certified=False,title_equivalence_certified=False,carrier_equivalence_added=False,
            insertion_grammar_certified=False,factual_support_certified=False,nomination_only=True)
        certificate["sha256"]=digest(certificate)
        result["proposals"].append(dict(kind="modifier",start=a,end=b,text=raw[a:b],edited=raw[a:b],
            source_constituent=certificate))
    result["status"]="SOURCE_NOMINATIONS" if result["proposals"] else "NO_SOURCE_NOMINATION"
    return result


def bind_proposals(page, reading, original, analysis=None):
    """Return nominees with strict original head/owner Tokens, not analysis Tokens.

    Reading applicability, source guards and certificates come from nominate.
    Failed rebinding raises ValueError; no expanding, clipping, or fallback is
    allowed. This adds no parser, source-policy, grammar, factual or rank check.
    The returned list is empty when the reading or source has no nomination.
    """
    rows = nominate(page, reading, original, analysis=analysis)["proposals"]
    bound = []
    raw = page["text"]
    for row in rows:
        proof = row["source_constituent"]
        carrier = proof["carrier"]
        literal = original.char_span(row["start"], row["end"], alignment_mode="strict")
        owner = original.char_span(carrier["start"], carrier["end"], alignment_mode="strict")
        if (literal is None or not literal or owner is None or len(owner) != 1
                or literal.text != row["text"] or owner.text != carrier["text"]):
            raise ValueError("Nomination cannot bind its exact original modifier/carrier tokens")
        if (token_proof(literal.root, raw) != proof["original_modifier_head"]
                or token_proof(owner.root, raw) != proof["original_carrier"]):
            raise ValueError("Original modifier/carrier tokens differ from the source certificate")
        bound.append(dict(row, head=literal.root, owner=owner.root))
    return bound
