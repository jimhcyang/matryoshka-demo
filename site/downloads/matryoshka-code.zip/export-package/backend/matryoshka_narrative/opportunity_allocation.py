"""Pure check-opportunity allocation; no identities, answers, parsers or gates."""
from collections import defaultdict, deque
import hashlib
import json
import re

VERSION = "source-head-opportunity-allocation/1"
SEMANTIC_FIELDS = (
    "source_clause_constraints", "source_owner_constraints", "source_owned_role_context",
    "source_carrier", "source_subject", "source_actor", "source_polarity",
    "source_negation", "source_modality", "qualifiers", "conflict_qualifiers", "scope",
)
HEAD_POS = {"NOUN", "PROPN", "PRON", "ADJ", "ADV", "NUM", "VERB", "ADP"}
LEXICAL_TOKEN = re.compile(r"\w+(?:[.'\u2019-]\w+)*\.?", re.UNICODE)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def typed_key(value):
    """Comparable frozen rank tie-breaks, including heterogeneous JSON types."""
    if value is None:
        return (0,)
    if type(value) is bool:
        return (1, int(value))
    if type(value) in {int, float}:
        return (2, value)
    if isinstance(value, str):
        return (3, value)
    if isinstance(value, list):
        return (4, tuple(typed_key(v) for v in value))
    if isinstance(value, dict):
        return (5, canonical(value))
    raise ValueError("Non-JSON rank key")


def interval(value):
    return (isinstance(value, (list, tuple)) and len(value) == 2
            and all(type(n) is int for n in value) and 0 <= value[0] < value[1])


def semantic_context(group):
    occurrence = group["occurrences"][0]
    feature = occurrence.get("features", {})
    project = lambda values: {key:values[key] for key in SEMANTIC_FIELDS if key in values}
    # Unknown group-level source constraints must not disappear from deduplication.
    group_context = {key:value for key,value in group.items()
                     if key in SEMANTIC_FIELDS or key.startswith("source_")
                     or key.endswith(("_constraints", "_qualifiers", "_scope"))
                     or key in {"original_reading", "declared_reading"}}
    return {"features":project(feature), "occurrence":project(occurrence), "group":group_context}


def identity(group):
    # Exact duplicate observations only. Never join spellings, heads or KG nodes.
    values = {k: group.get(k) for k in
              ("reading_id", "alternative_family", "node_id", "fill", "occurrences")}
    values["preserved_context"] = semantic_context(group)
    return digest(values)


def token_bound_head(head, reference, citation):
    """Bind one lexical token to the frozen parser-root observation, no NLP rerun."""
    if not isinstance(reference, dict) or not interval(reference.get("span")):
        return False
    if reference["span"] != head.get("span") or reference.get("text") != head.get("text"):
        return False
    if any(key in reference and reference[key] != head.get(key) for key in ("pos", "tag")):
        return False
    text = head.get("text")
    if not isinstance(text, str) or LEXICAL_TOKEN.fullmatch(text) is None:
        return False
    start, end = (n-citation["start"] for n in head["span"])
    raw = citation["text"]
    word = lambda c: c.isalnum() or c == "_"
    if start and word(raw[start-1]) or end < len(raw) and word(raw[end]):
        return False
    return True


def descriptor(group, index):
    if len(group.get("occurrences", [])) != 1:
        raise ValueError("One explicit primary occurrence is required; ambiguous selection is not licensed")
    occurrence = group["occurrences"][0]
    citation = occurrence["citation"]
    feature = occurrence.get("features", {})
    supplied_head = occurrence.get("source_head")
    head = supplied_head if isinstance(supplied_head, dict) else {}
    cue = occurrence.get("selection_cue")
    cue = cue if isinstance(cue, dict) else {}
    span, hs = occurrence.get("source_span"), head.get("span")
    a, b, text = citation.get("start"), citation.get("end"), citation.get("text")
    valid = (interval(span) and interval(hs) and type(a) is int and type(b) is int
             and 0 <= a < b and isinstance(text, str) and b-a == len(text)
             and isinstance(citation.get("page_sha256"), str) and bool(citation["page_sha256"])
             and a <= span[0] <= hs[0] < hs[1] <= span[1] <= b
             and head.get("pos") in HEAD_POS
             and isinstance(head.get("text"), str) and bool(head["text"])
             and text[hs[0]-a:hs[1]-a] == head["text"]
             and text[span[0]-a:span[1]-a] == occurrence.get("source_wording")
             and token_bound_head(head, cue.get("raw_source_head"), citation))
    query_role, source_role = feature.get("query_argument_role"), feature.get("source_argument_role")
    roles_valid = lambda r: isinstance(r, list) and bool(r) and all(isinstance(v, str) and bool(v) for v in r)
    affinity = valid and roles_valid(query_role) and roles_valid(source_role) and query_role == source_role
    anchor = cue.get("visible_anchor_context") or {}
    anchor_hint = (valid and anchor.get("matched") is True and anchor.get("context_only") is True
                   and anchor.get("identity_or_action_certified") is not True)
    semantic = semantic_context(group)
    opportunity = {"reading_id": group["reading_id"],
        "page_id": citation["canonical_page_id"], "page_sha256": citation.get("page_sha256"),
        "unit": [a,b], "source_head": head, "node_id": group.get("node_id"),
        "source_role": source_role, "semantic_context": semantic}
    # Unknown/malformed heads cannot collapse otherwise distinct observations.
    if not valid:
        opportunity["invalid_head_observation"] = identity(group)
    return {"index": index, "identity": identity(group), "page_id": citation["canonical_page_id"],
        "opportunity_id": digest(opportunity), "head_valid": bool(valid),
        "role_affinity": bool(affinity), "anchor_context_hint": bool(anchor_hint),
        "tier": (not valid, not affinity, not anchor_hint),
        "source_span": span, "source_head": head,
        "tie": (typed_key(group.get("rank_key", [])), identity(group), index),
        "preliminary_shape": group.get("scheduling", {}).get("preliminary_source_form_match") is True}


def representative_order(rows, *, max_rep_tokens, groups):
    """Prefer bounded enclosing attested spans, retaining every alternative."""
    bounded = [r for r in rows if r["head_valid"] and r["preliminary_shape"]
               and len(groups[r["index"]]["occurrences"][0]["source_wording"].split()) <= max_rep_tokens]
    def score(row):
        span = row["source_span"]
        enclosing = sum(span[0] <= other["source_span"][0] and other["source_span"][1] <= span[1]
                        for other in bounded) if row in bounded else 0
        return (row not in bounded, -enclosing, -(span[1]-span[0]) if row in bounded else 0, row["tie"])
    return sorted(rows, key=score)


def allocate(groups, baseline_indices, *, budget=64, primary_cap=32, max_rep_tokens=32):
    """Return indices only. All downstream gates must consume untouched groups."""
    for value in (budget, primary_cap, max_rep_tokens):
        if type(value) is not int or value < 1:
            raise ValueError("Positive integral caps required")
    if primary_cap > budget or len(baseline_indices) > primary_cap:
        raise ValueError("Primary lane exceeds fixed cap")
    if len(set(baseline_indices)) != len(baseline_indices):
        raise ValueError("Recorded baseline contains duplicate indices")
    if any(type(i) is not int or not 0 <= i < len(groups) for i in baseline_indices):
        raise ValueError("Baseline index outside pool")
    if len({g["reading_id"] for g in groups}) > 1:
        raise ValueError("Call separately per reading to preserve its exact draft cap")
    before = digest(groups)
    rows = [descriptor(g, i) for i,g in enumerate(groups)]
    selected = list(baseline_indices)
    seen = {rows[i]["identity"] for i in selected}
    if len(seen) != len(selected):
        raise ValueError("Duplicate baseline identities require an explicit preservation policy, not silent deduplication")
    buckets = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
    for row in rows:
        if row["index"] not in set(baseline_indices):
            buckets[row["tier"]][row["page_id"]][row["opportunity_id"]].append(row)
    queues = {}
    for tier, pages in buckets.items():
        queues[tier] = {}
        for page, opportunities in pages.items():
            ordered = [representative_order(values, max_rep_tokens=max_rep_tokens, groups=groups)
                       for values in opportunities.values()]
            ordered.sort(key=lambda values: values[0]["tie"])
            # All distinct source-head/context opportunities precede their alternatives.
            page_order = [values[depth] for depth in range(max(map(len, ordered)))
                          for values in ordered if depth < len(values)]
            queues[tier][page] = deque(page_order)
    skipped_duplicates = []
    for tier in sorted(queues):
        pages = queues[tier]
        page_order = sorted(pages, key=lambda page: (pages[page][0]["tie"], page))
        while any(pages.values()) and len(selected) < budget:
            for page in page_order:
                queue = pages[page]
                # Replenish this opportunity immediately; a duplicate spends no check.
                while queue and queue[0]["identity"] in seen:
                    skipped_duplicates.append(queue.popleft()["index"])
                if queue and len(selected) < budget:
                    row = queue.popleft()
                    selected.append(row["index"])
                    seen.add(row["identity"])
    assert selected[:len(baseline_indices)] == list(baseline_indices)
    assert len(selected) <= budget and len(set(selected)) == len(selected)
    assert digest(groups) == before
    return {"version": VERSION, "indices": selected, "baseline_indices": list(baseline_indices),
        "supplemental_indices": selected[len(baseline_indices):], "budget": budget,
        "primary_cap": primary_cap, "unspent_slots": budget-len(selected),
        "duplicate_opportunities_skipped": skipped_duplicates,
        "selection_metadata": [{k:rows[i][k] for k in
            ("index", "opportunity_id", "page_id", "source_head", "head_valid", "role_affinity", "anchor_context_hint")}
            for i in selected],
        "input_pool_sha256": before, "input_pool_unchanged": True,
        "grammar_affinity_is_proof": False, "anchor_hint_is_proof": False,
        "identities_merged": False, "rank_keys_modified": False,
        "gates_modified": False, "gates_executed": False, "supported": None}
