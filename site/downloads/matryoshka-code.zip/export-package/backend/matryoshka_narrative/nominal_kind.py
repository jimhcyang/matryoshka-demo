"""Unintegrated, source-only ALL-CAPS nominal-kind diagnostic.

Call with an already eligible source page/unit, a declared nominal reading,
an exact proposed source span and the existing SourceParses callable. The
lowercase FULL source is a length/offset-preserving parser control, not source
wording, lexical authority, a new proposal, or factual evidence. diagnose uses
no query/answer/candidate ranking/case identity/native gate. The separate optional
article_context accepts only visible public left/right boundary fragments.

Supplied Docs and their Token/Span views are read only. No deepcopy, reparenting,
POS rewriting or cache mutation occurs. The returned certificate is JSON-only.
No constructor/workflow imports or default changes integrate this diagnostic.
"""
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest


VERSION = "source-nominal-kind-control/1"
NOMINAL_POS = frozenset({"NOUN", "PROPN", "NUM"})
NON_NOMINAL_POS = frozenset({"ADV", "VERB", "AUX", "DET", "ADP", "ADJ",
                            "CCONJ", "SCONJ", "PART", "PRON", "INTJ"})
SOURCE_NOMINAL_TYPES = frozenset({
    "Person", "Organization", "Government", "Military", "PoliticalGroup",
    "Country", "Location", "Place", "Quantity", "Number", "Cardinal",
    "Money", "Percent", "Date", "Time",
})
NOMINAL_NE = frozenset({"PERSON", "ORG", "GPE", "LOC", "FAC", "CARDINAL",
                        "QUANTITY", "MONEY", "PERCENT", "ORDINAL", "DATE", "TIME"})


def _span(a, b, raw):
    return dict(start=a, end=b, text=raw[a:b])


def _token(token, raw):
    return dict(_span(token.idx, token.idx+len(token), raw), parsed_text=token.text,
                pos=token.pos_, tag=token.tag_, dependency=token.dep_,
                head_start=token.head.idx, morphology=str(token.morph))


def _types(page, values):
    """Caller-bound own-source observations, not graph label/alias resolution."""
    output = []
    for value in values:
        a, b = value.get("start"), value.get("end")
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
                or value.get("canonical_page_id") != page["id"]
                or value.get("page_sha256") != page["source_sha256"]
                or value.get("label") != page["text"][a:b]
                or not isinstance(value.get("node_id"), str) or not value["node_id"]
                or not isinstance(value.get("source_entity_type"), str)):
            raise ValueError("Source entity-kind witness lost its literal page/span binding")
        if "document_id" in value and value["document_id"] != page["document_id"]:
            raise ValueError("Source entity-kind witness belongs to another document")
        output.append(dict(_span(a, b, page["text"]), node_id=value["node_id"],
                           source_entity_type=value["source_entity_type"],
                           canonical_page_id=page["id"], page_sha256=page["source_sha256"],
                           source_row_id=value.get("source_row_id")))
    return output


def diagnose(page, reading, source_span, parses, *, source_wording=None,
             original=None, control=None, source_types=()):
    """Describe whether a raw uppercase NP has a nonnominal contextual control.

    ``source_span`` is in Unicode codepoint offsets of the ENTIRE page["text"].
    ``parses`` is an existing SourceParses instance/callable, not a corpus/context.
    Optional Docs must have the same full-source text or its exact lowercase.
    ``source_types`` uses the existing page_types observation shape. A protective
    kind/NE must fit inside this constituent AND cover its CONTROL head; an
    object, possessor or nearby person's type cannot rescue a verbal head.

    A hold is a proposed future nominal-source-kind guard, not an active native
    rejection. Every other state leaves existing independent gates untouched.
    Even nominal_possible grants no grammar, type, identity or factual support.
    """
    raw = page["text"]
    if not isinstance(raw, str) or page.get("source_sha256") != digest(raw):
        raise ValueError("Source text/hash changed")
    if (not isinstance(source_span, (list, tuple)) or len(source_span) != 2
            or any(type(n) is not int for n in source_span)):
        raise ValueError("Exact source span required")
    a, b = source_span
    if not 0 <= a < b <= len(raw) or source_wording is not None and source_wording != raw[a:b]:
        raise ValueError("Source wording/span changed")
    witnesses = _types(page, source_types)
    proof = dict(version=VERSION, source=dict(canonical_page_id=page["id"],
                 document_id=page["document_id"], date=page["date"],
                 page_sha256=page["source_sha256"]), constituent=_span(a, b, raw),
                 declared_form=reading.get("form"), caller_kind_witnesses=witnesses,
                 kind_observation_scope="CALLER_SUPPLIED_OWN_OBSERVATIONS_NOT_EXHAUSTIVE_KG_AUDIT",
                 control_kind="LOWERCASE_FULL_SOURCE_SAME_CODEPOINT_OFFSETS",
                 control_text_is_source_evidence=False, source_words_modified=False,
                 token_views_read_only=True, source_eligibility_certified=False,
                 grammar_certified=False, target_type_certified=False,
                 identity_certified=False, factual_support_certified=False,
                 active_engine_integrated=False, changes_ranking=False)

    def finish(state, reason):
        proof.update(state=state, reason=reason, would_hold_nominal_proposal=state == "hold")
        proof["sha256"] = digest(proof)
        return proof

    if (reading.get("form") != "nominal"
            or reading.get("outer_family", "nominal") != "nominal"
            or reading.get("constructor_form", "nominal") != "nominal"):
        return finish("not_applicable", "READING_NOT_DECLARED_NOMINAL")
    if any(a < match.end() and match.start() < b for match in MASK.finditer(raw)):
        return finish("unresolved", "OPAQUE_SOURCE_CONSTITUENT")
    original = parses(raw) if original is None else original
    if original.text != raw:
        raise ValueError("Original parse is not the complete raw source")
    part = original.char_span(a, b, alignment_mode="strict")
    if part is None or not part:
        raise ValueError("Proposal lost strict original token boundaries")
    head = part.root
    proof.update(raw_head=_token(head, raw), original_tokens=[_token(t, raw) for t in part])
    if not (part[0].sent == part[-1].sent):
        return finish("unresolved", "CONSTITUENT_CROSSES_ORIGINAL_SOURCE_SENTENCES")
    proof["source_sentence"] = _span(part[0].sent.start_char, part[0].sent.end_char, raw)
    if not head.text.isupper() or head.pos_ not in {"NOUN", "PROPN"}:
        return finish("not_applicable", "RAW_HEAD_NOT_UPPERCASE_NOMINAL")
    chunks = [chunk for chunk in original.noun_chunks
              if chunk.start_char <= head.idx < head.idx+len(head) <= chunk.end_char and chunk.root == head]
    proof["raw_noun_chunks"] = [_span(c.start_char, c.end_char, raw) for c in chunks]
    if not chunks:
        return finish("not_applicable", "NO_RAW_NOUN_CHUNK_AT_OWN_HEAD")
    lower = raw.lower()
    if len(lower) != len(raw):
        return finish("unresolved", "LOWERCASE_CHANGES_CODEPOINT_LENGTH")
    control = parses(lower) if control is None else control
    if control.text != lower:
        raise ValueError("Control is not the exact lowercase complete source")
    viewed = control.char_span(a, b, alignment_mode="strict")
    if viewed is None or not viewed:
        return finish("unresolved", "CONTROL_CONSTITUENT_TOKEN_BOUNDARIES_CHANGED")
    raw_offsets = [(t.idx, len(t)) for t in part]
    control_offsets = [(t.idx, len(t)) for t in viewed]
    if raw_offsets != control_offsets:
        return finish("unresolved", "LOCAL_CONTROL_TOKENIZATION_CHANGED")
    if viewed[0].sent != viewed[-1].sent:
        return finish("unresolved", "CONSTITUENT_CROSSES_CONTROL_SOURCE_SENTENCES")
    other = viewed.root
    raw_other = original.char_span(other.idx, other.idx+len(other), alignment_mode="strict")
    if raw_other is None or len(raw_other) != 1:
        return finish("unresolved", "CONTROL_HEAD_CANNOT_REBIND_ORIGINAL_TOKEN")
    proof.update(control_head=_token(other, raw), control_head_original_token=_token(raw_other[0], raw),
                 control_tokens=[_token(t, raw) for t in viewed],
                 full_control_source_sha256=digest(lower), local_token_offsets_identical=True,
                 global_token_offsets_identical=[(t.idx, len(t)) for t in original] ==
                     [(t.idx, len(t)) for t in control],
                 control_source_sentence=_span(viewed[0].sent.start_char, viewed[0].sent.end_char, raw))
    lo, hi = other.idx, other.idx+len(other)
    owned = [w for w in witnesses if a <= w["start"] <= lo < hi <= w["end"] <= b
             and w["source_entity_type"] in SOURCE_NOMINAL_TYPES]
    nes = []
    for origin, doc in (("original_source_parser", original), ("lowercase_control_parser", control)):
        for entity in doc.ents:
            if entity.label_ in NOMINAL_NE and a <= entity.start_char <= lo < hi <= entity.end_char <= b:
                nes.append(dict(_span(entity.start_char, entity.end_char, raw), label=entity.label_,
                                producer=origin, nominal_possibility_only=True))
    proof.update(own_control_head_kind_witnesses=owned, own_control_head_named_entities=nes)
    if owned or nes:
        return finish("nominal_possible", "OWN_BOUND_SOURCE_KIND_OR_NAMED_ENTITY_NOT_OVERRULED")
    if other.pos_ in NOMINAL_POS:
        return finish("nominal_possible", "CONTROL_HEAD_REMAINS_NOMINAL")
    if other.pos_ in NON_NOMINAL_POS:
        return finish("hold", "UPPERCASE_NP_HAS_NONNOMINAL_CONTEXT_HEAD_WITHOUT_OWN_TYPE")
    return finish("unresolved", "CONTROL_HEAD_KIND_UNINTERPRETED")


def article_context(page, reading, source_span, left, right, parses, *, original=None,
                    source_constituent=None):
    """OPTIONAL, unintegrated source-article diagnostic; not a grammar law.

    Public boundary strings only; no case/answer/entity dictionaries. Applies
    narrowly after standalone visible THE, before an unqualified clause end or
    coordinating conjunction, to a raw PROPN-headed nominal. An own initial THE
    is attested by a complete raw NP (including the exact source_nominals
    original_np/retained_core partition when supplied). No word is added/deleted,
    no proposal is returned, and no existing quote/layout policy is overruled.
    Common nouns, example readings, postqualified or uncertain boundaries abstain.
    """
    raw = page["text"]
    if page.get("source_sha256") != digest(raw):
        raise ValueError("Source text/hash changed")
    if (not isinstance(source_span, (list, tuple)) or len(source_span) != 2
            or any(type(n) is not int for n in source_span)):
        raise ValueError("Exact source span required")
    a, b = source_span
    if not 0 <= a < b <= len(raw) or not isinstance(left, str) or not isinstance(right, str):
        raise ValueError("Literal source span and public boundaries required")
    result = dict(version=VERSION, optional_feature="SOURCE_ARTICLE_CONTEXT_ONLY",
                  source=dict(canonical_page_id=page["id"], document_id=page["document_id"],
                              date=page["date"], page_sha256=page["source_sha256"]),
                  constituent=_span(a, b, raw), public_left_sha256=digest(left),
                  public_right_sha256=digest(right), active_engine_integrated=False,
                  grammar_certified=False, target_type_certified=False, identity_certified=False,
                  factual_support_certified=False, source_eligibility_certified=False,
                  source_words_modified=False, token_views_read_only=True,
                  quote_layout_policy_overridden=False, no_new_nomination=True)

    def finish(state, reason):
        result.update(state=state, reason=reason, would_hold_nominal_proposal=state == "hold")
        result["sha256"] = digest(result)
        return result

    if (reading.get("form") != "nominal" or reading.get("outer_family", "nominal") != "nominal"
            or reading.get("constructor_form", "nominal") != "nominal"
            or reading.get("function") == "member_example" or reading.get("role") == "member_example"):
        return finish("not_applicable", "NOT_A_PLAIN_NOMINAL_READING")
    visible = re.search(r"(?<![\w'-])the\s+$", left, re.I)
    if visible is None:
        return finish("not_applicable", "NO_STANDALONE_VISIBLE_THE")
    result["visible_article"] = _span(visible.start(), visible.start()+3, left)
    if MASK.search(right) or MASK.search(raw[a:b]):
        return finish("not_applicable", "OPAQUE_BOUNDARY_OR_CONSTITUENT")
    after = right.lstrip()
    if after:
        # Only unambiguous terminators, or punctuation followed by a CCONJ/end.
        # In particular comma + PP/relative is not treated as a terminal slot.
        if after[0] not in ".!?;":
            boundary = parses(right)
            words = [t for t in boundary if not t.is_space and not t.is_punct]
            if words and words[0].pos_ != "CCONJ":
                return finish("not_applicable", "POSTQUALIFIER_OR_BOUNDARY_UNESTABLISHED")
    original = parses(raw) if original is None else original
    if original.text != raw:
        raise ValueError("Original parse is not the complete raw source")
    part = original.char_span(a, b, alignment_mode="strict")
    if part is None or not part:
        raise ValueError("Proposal lost strict original token boundaries")
    result["raw_head"] = _token(part.root, raw)
    if part.root.pos_ != "PROPN":
        return finish("not_applicable", "SOURCE_HEAD_NOT_PROPER")
    if part[0].sent != part[-1].sent:
        return finish("not_applicable", "SOURCE_SENTENCE_BOUNDARY_UNESTABLISHED")
    postmodifiers = [child for child in part.root.children
                     if child.idx > part.root.idx and child.dep_ in {"prep", "acl", "relcl", "appos"}]
    if postmodifiers:
        result["own_source_postmodifiers"] = [_token(t, raw) for t in postmodifiers]
        return finish("not_applicable", "OWN_SOURCE_POSTQUALIFIER_REQUIRES_SEPARATE_CONTEXT")
    candidates = []
    if source_constituent is not None:
        proof = source_constituent
        np, core = proof.get("original_np", {}), proof.get("retained_core", {})
        lo, hi = np.get("start"), np.get("end")
        if (proof.get("version") != "literal-visible-prefix-nominal-realization/1"
                or proof.get("page_sha256") != page["source_sha256"]
                or type(lo) is not int or type(hi) is not int or not 0 <= lo < hi <= len(raw)
                or raw[lo:hi] != np.get("text")
                or (core.get("start"), core.get("end"), core.get("text")) != (a, b, raw[a:b])):
            raise ValueError("Article partition lost its exact original NP/core binding")
        own = original.char_span(lo, hi, alignment_mode="strict")
        if own is None:
            raise ValueError("Article partition lost original token boundaries")
        candidates.append(own)
    candidates += [chunk for chunk in original.noun_chunks
                   if chunk.root == part.root and chunk.end_char == b and chunk.start_char <= a]
    for own in candidates:
        words = [t for t in own if not t.is_space]
        if (len(words) < 2 or words[0].lower_ != "the" or words[0] == own.root
                or own.root != part.root or words[0].head != own.root
                or words[0].dep_ not in {"det", "compound"}):
            continue
        if own.start_char != a and (words[1].idx != a or not raw[words[0].idx+len(words[0]):a].isspace()):
            continue
        result["attested_original_np"] = _span(own.start_char, own.end_char, raw)
        result["source_article"] = _token(words[0], raw)
        return finish("nominal_possible", "OWN_SOURCE_NP_ATTESTS_VISIBLE_ARTICLE")
    return finish("hold", "SOURCE_ARTICLE_UNESTABLISHED_NOT_UNIVERSAL_UNGRAMMATICALITY")
