"""Build-time badges from the browser's exact resource-bound decision projection."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess


VERSION = "narrative-bound-sidebar-materializer/1"
SCRIPT = """
import {pathToFileURL} from 'node:url';
import {webcrypto} from 'node:crypto';
if(!globalThis.crypto)globalThis.crypto=webcrypto;
const {decisionSummaryFor}=await import(pathToFileURL(process.argv[1]).href);
let input='';for await(const chunk of process.stdin)input+=chunk;
const output=[];
for(const row of JSON.parse(input))output.push(await decisionSummaryFor(row.record,row.case,row.record.resource_binding));
process.stdout.write(JSON.stringify(output));
"""


def summarize(root, rows):
    inputs = []
    for case, record in rows:
        if record.get("current_resource_execution") is not True or not record.get("resource_binding"):
            raise ValueError("Sidebar needs an explicitly resource-bound current execution")
        result = record["result"]
        inputs.append(dict(case=case,record=dict(config=record["config"],run_id=record["run_id"],
            native_checksum=deepcopy(record["native_checksum"]),current_resource_execution=True,
            resource_binding=deepcopy(record["resource_binding"]),
            plan=dict(atoms=deepcopy(record["plan"].get("atoms",[]))),
            result=dict(readings=[dict(reading=deepcopy(row["reading"]),
                candidates=[dict(id=c["id"],fill=c["fill"]) for c in row["candidates"]])
                for row in result.get("readings",[])]),
            local_decisions_v65=deepcopy(record["local_decisions_v65"]))))
    module = Path(root).resolve() / "narrative_demo/web/local-decisions-v65.js"
    result = subprocess.run(["node","--input-type=module","-e",SCRIPT,str(module)],
        input=json.dumps(inputs,ensure_ascii=True,allow_nan=False),text=True,
        capture_output=True,timeout=120,check=True)
    values = json.loads(result.stdout)
    if len(values) != len(rows) or any(value is None for value in values):
        raise ValueError("Incomplete resource-bound sidebar summaries")
    return values
