"""Isolated query-POS experiment; no production hook or source-parse repair.

An exact dictionary common-person compound can license one analysis-only
PROPN/NNP -> NOUN/NN correction. The unchanged nominal3 apposition evaluator
still decides whether the original source attests the literal historical role.
"""
from __future__ import annotations

from copy import deepcopy
from datetime import date
from types import SimpleNamespace

from matryoshka_demo.io import digest, offline
from matryoshka_demo.roles import binding as wordnet_binding, lexicon
from matryoshka_next.facts import public_plan
from . import nominal_bindings as nominal3

VERSION = "narrative-query-common-person-compound-analysis/1"
CERTIFICATE_KIND = "LITERAL_NAMED_SUBJECT_ROLE_APPOSITION_QUERY_COMPOUND_ANALYSIS"
REQUIRES_NOMINAL = "narrative-literal-nominal-role-bindings/3"
BASELINE_VERSION = "narrative-guarded-source-frame-matching/4"
MAX_CHARACTERS = 4096
MAX_TOKENS = 256
MAX_PAGE_CHARACTERS = 16384
MAX_PAGE_TOKENS = 4096


def _tokens(doc):
    """Control attributes, including unchanged NER/morphology and head indices."""
    return [dict(i=t.i, start=t.idx, end=t.idx + len(t), text=t.text,
                 whitespace=t.whitespace_, lemma=t.lemma_, pos=t.pos_, tag=t.tag_,
                 dependency=t.dep_, head=t.head.i, morph=str(t.morph),
                 entity_iob=t.ent_iob_, entity_type=t.ent_type_,
                 sentence_start=t.is_sent_start) for t in doc]


def _contiguous(tokens):
    return bool(tokens) and [t.i for t in tokens] == list(range(tokens[0].i, tokens[-1].i + 1))


def _prerequisites(matcher, atom, page, unit, control):
    if nominal3.VERSION != REQUIRES_NOMINAL:
        return "UNREVIEWED_NOMINAL_VERSION"
    if (control.get("version") != BASELINE_VERSION
            or control.get("direction") not in {"PARTIAL", "UNRESOLVED"}
            or control.get("query_issues") != [] or control.get("potential_counter")
            or control.get("source_text_modified") is not False
            or control.get("unit_join_performed") is not False
            or any(control.get("checks", {}).get(k) != "PASS"
                   for k in ("eligible_source", "literal_quote", "all_query_frames"))):
        return "BASELINE_PREREQUISITES_NOT_SATISFIED"
    case = matcher.case
    try:
        public_plan(case, dict(atoms=[atom], query_sha256=digest(case["query"])))
    except (KeyError, TypeError, ValueError):
        return "ATOM_NOT_BOUND_TO_PUBLIC_QUERY"
    if (page.get("permitted") is not True or page.get("corpus") != case["corpus"]
            or page.get("document_id") == case["document_id"]
            or page.get("visibility") not in {"earlier", "earlier_only", "both"}):
        return "SOURCE_OWNER_OR_ELIGIBILITY_MISMATCH"
    try:
        if date.fromisoformat(page["date"]) >= date.fromisoformat(case["date"]):
            return "SOURCE_NOT_STRICTLY_EARLIER"
    except (KeyError, TypeError, ValueError):
        return "SOURCE_DATE_MISMATCH"
    text = unit.get("text", unit.get("quote"))
    a, b = unit.get("start"), unit.get("end")
    if (not isinstance(text, str) or not text or len(text) > MAX_CHARACTERS
            or len(atom.get("text", "")) > MAX_CHARACTERS
            or type(a) is not int or type(b) is not int
            or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != text or digest(page["text"]) != page.get("source_sha256")):
        return "SOURCE_QUOTE_OR_HASH_MISMATCH"
    pi = matcher.positions.get(page["id"])
    if pi is None or page != matcher.corpus.pages[pi]:
        return "SOURCE_PAGE_DIFFERS_FROM_BOUND_INDEX"
    # Reuse the caller's actual complete-index SourcePolicy, never a new policy
    # inferred from this one page or from a supplied eligible=True flag.
    try:
        citation = matcher.policy.citation(pi, a, b)
    except (KeyError, TypeError, ValueError):
        return "SOURCE_POLICY_REPLAY_FAILED"
    if citation != control.get("citation"):
        return "BASELINE_CITATION_OWNER_MISMATCH"
    return None


def _sentence_scope(engine, page, unit):
    text = page["text"]
    if len(text) > MAX_PAGE_CHARACTERS:
        return None
    doc = engine.parse(text)
    if len(doc) > MAX_PAGE_TOKENS or doc.text != text:
        return None

    def trimmed(a, b):
        while a < b and text[a].isspace():
            a += 1
        while a < b and text[b - 1].isspace():
            b -= 1
        return a, b

    bounds = trimmed(unit["start"], unit["end"])
    try:
        matches = [s for s in doc.sents if trimmed(s.start_char, s.end_char) == bounds]
    except ValueError:
        return None
    if len(matches) != 1 or matches[0].root.head != matches[0].root:
        return None
    return dict(kind="COMPLETE_UNCHANGED_FULL_PAGE_SENTENCE", page_id=page["id"],
                page_sha256=page["source_sha256"], start=bounds[0], end=bounds[1],
                unit_start=unit["start"], unit_end=unit["end"],
                boundary_comparison_ignores_whitespace_only=True, source_unit_expanded=False)


def _dictionary_compounds(role):
    """Exact contiguous suffix, including the whole complement, not a term bag.

    Pre-head modifiers may precede the dictionary compound; nominal3 must still
    bind every modifier and the whole literal PP to this same source role.
    """
    tokens = sorted(role.subtree, key=lambda t: t.i)
    if not _contiguous(tokens) or len(tokens) > 16:
        return []
    found = []
    for start in range(tokens.index(role) + 1):
        part = tokens[start:]
        if not 2 <= len(part) <= 8 or any(not t.text.isalpha() for t in part):
            continue
        printed = role.doc.text[part[0].idx:part[-1].idx + len(part[-1])]
        words = " ".join(printed.casefold().split())
        if words != " ".join(t.text.casefold() for t in part):
            continue
        lemma = words.replace(" ", "_")
        senses = sorted(s.name() for s in lexicon().synsets(lemma, pos="n")
                        if s.lexname() == "noun.person" and any(
                            l.name() == lemma and l.name().islower() for l in s.lemmas()))
        if senses:
            found.append(dict(kind="EXACT_MULTIWORD_WORDNET_COMMON_PERSON_COMPOUND",
                              literal=printed, lemma=lemma, synsets=senses,
                              start=part[0].idx, end=part[-1].idx + len(part[-1]),
                              token_indices=[t.i for t in part], synonym_or_alias_used=False))
    return found


class _QueryOnlyEngine:
    """Two explicit parse slots; even identical strings cannot rewrite source."""
    def __init__(self, query, source, targets):
        self.query, self.source, self.target_rows = query, source, targets
        self.parse_calls = 0

    def parse(self, text):
        self.parse_calls += 1
        if self.parse_calls == 1 and text == self.query.text:
            return self.query
        if self.parse_calls == 2 and text == self.source.text:
            return self.source
        raise ValueError("Unexpected nominal3 parse route; query correction not applied")

    def targets(self, text):
        if text != self.query.text:
            raise ValueError("Unexpected nominal3 target route")
        return deepcopy(self.target_rows)


def evaluate(matcher, atom, page, unit, control):
    """Prototype-only extension after an actual unchanged text-baseline control.

    SUPPORT means a historical source-ascribed role only. It does not override
    a counter hold, completeness/qualification gate, or any ordinary decision.
    """
    result = dict(version=VERSION, prototype_only=True, applicable=False,
                  direction="UNRESOLVED", reasons=[], certificate=None)

    def reject(reason):
        result["reasons"] = [reason]
        return result

    failed = _prerequisites(matcher, atom, page, unit, control)
    if failed:
        return reject(failed)
    with offline():
        engine = matcher.engine
        query = engine.parse(atom["text"])
        if query.text != atom["text"] or len(query) > MAX_TOKENS:
            return reject("QUERY_TEXT_OR_TOKEN_BOUND_MISMATCH")
        roots = [t for t in query if t.dep_ == "ROOT"]
        if (len(roots) != 1 or roots[0].lemma_.casefold() != "be"
                or roots[0].tag_ != "VBD" or atom.get("kind") != "proposition"
                or atom.get("polarity", "positive") != "positive"
                or atom.get("modality", "asserted") != "asserted"):
            return reject("NOT_A_SIMPLE_PAST_ASSERTED_COPULAR_QUERY")
        root = roots[0]
        owners = [c for c in root.children if c.dep_ == "nsubj"]
        roles = [c for c in root.children if c.dep_ == "attr"]
        if len(owners) != 1 or len(roles) != 1:
            return reject("QUERY_OWNER_OR_ATTRIBUTE_NOT_UNIQUE")
        owner, role = owners[0], roles[0]
        if role.pos_ != "PROPN" or role.tag_ != "NNP":
            return reject("NO_SINGLE_PROPER_ATTRIBUTE_HEAD_TO_REPAIR")
        if (any(c not in [owner, role] and c.dep_ != "punct" for c in root.children)
                or any(t.is_quote or t.text == "?" or t.ent_type_ in {"DATE", "TIME"} for t in query)):
            return reject("QUERY_SCOPE_OR_CLOCK_NOT_LICENSED")
        name = nominal3._name_tokens(owner)
        if (len(name) < 2 or not _contiguous(name) or set(owner.subtree) != set(name)
                or any(t.pos_ != "PROPN" or t.ent_type_ not in {"", "PERSON"} for t in name)):
            return reject("QUERY_REQUIRES_LITERAL_MULTITOKEN_PERSON_NAME")
        compounds = _dictionary_compounds(role)
        if len(compounds) != 1:
            return reject("NO_UNIQUE_EXACT_COMMON_PERSON_COMPOUND")
        result["applicable"] = True
        scope = _sentence_scope(engine, page, unit)
        if scope is None:
            return reject("SOURCE_UNIT_NOT_COMPLETE_PAGE_SENTENCE")
        source = engine.parse(unit.get("text", unit.get("quote")))
        if source.text != unit.get("text", unit.get("quote")) or len(source) > MAX_TOKENS:
            return reject("SOURCE_TEXT_OR_TOKEN_BOUND_MISMATCH")
        targets = engine.targets(atom["text"])
        original, source_original = _tokens(query), _tokens(source)
        repaired = query.copy()
        repaired[role.i].pos_ = "NOUN"
        repaired[role.i].tag_ = "NN"
        expected = deepcopy(original)
        expected[role.i].update(pos="NOUN", tag="NN")
        if _tokens(repaired) != expected or _tokens(query) != original:
            return reject("QUERY_COPY_CHANGED_NON_POS_ATTRIBUTES")
        proxy = _QueryOnlyEngine(repaired, source, targets)
        delegated = nominal3.evaluate(SimpleNamespace(engine=proxy), atom, page, unit, control)
        if _tokens(source) != source_original or _tokens(query) != original:
            return reject("DELEGATE_CHANGED_ORIGINAL_PARSE")
        result["nominal3_audit"] = deepcopy(delegated)
        if delegated["direction"] != "SUPPORT":
            return reject("UNCHANGED_NOMINAL3_GATES_NOT_SATISFIED")
        if proxy.parse_calls != 2:
            return reject("UNREVIEWED_NOMINAL3_PARSE_ROUTE")
        certificate = deepcopy(delegated["certificate"])
        certificate.update(kind=CERTIFICATE_KIND, version=VERSION,
            delegated_nominal_certificate=deepcopy(delegated["certificate"]),
            original_public_query=matcher.case["query"], public_query_sha256=digest(matcher.case["query"]),
            original_atom=deepcopy(atom), original_atom_sha256=digest(atom),
            original_query_tokens=original, analyzed_query_tokens=expected,
            unchanged_source_tokens=source_original, dictionary_compound=compounds[0],
            wordnet_resource=wordnet_binding(), source_sentence_scope=scope,
            baseline_control=deepcopy(control), baseline_control_sha256=digest(control),
            unchanged_original_target_frames_sha256=digest(targets),
            target_frames_recomputed_with_repair=False, baseline_decision_modified=False,
            source_citation=deepcopy(control["citation"]), source_unit=deepcopy(unit),
            query_analysis_correction=dict(token_index=role.i, start=role.idx, end=role.idx + len(role),
                text=role.text, original_pos="PROPN", original_tag="NNP", analyzed_pos="NOUN", analyzed_tag="NN",
                changed_attributes=["POS", "TAG"], text_offsets_dependencies_lemmas_ner_morphology_unchanged=True),
            source_parse_rewritten=False, cached_query_doc_mutated=False,
            source_ascription_date=page["date"], source_attestation_not_persistence=True,
            counter_clearance_certified=False,
            continued_tenure_at_query_cutoff_certified=False, world_truth_certified=False,
            completed_action_certified=False, prototype_only=True, production_hook_installed=False)
        result.update(direction="SUPPORT", reasons=[], certificate=certificate)
        return result
