"""Context-only ordering observations; no nominations or evidence decisions."""
import json

from matryoshka_demo.io import digest
from . import context_relevance, opportunity_allocation

VERSION = "attested-role-context-priority/1"


def observe(candidate):
    gate = context_relevance.saved_gate(candidate)
    decision = candidate["local_decision"]
    counter = bool(decision.get("counterevidence") or decision.get("decisive_counter") or any(
        r.get("counterevidence") or r.get("direction") in {
            "Counter", "Counterevidence", "COUNTER", "OPPOSED", "CONFLICTED", "Support + Counterevidence"}
        for r in decision.get("requirements", [])))
    if not gate["eligible_for_reordering"] or counter:
        raise ValueError("Existing context admission or counter hold remains")
    established = sum(r.get("coverage") == "Established" for r in decision.get("requirements", []))
    tier = gate["support_tier"]
    effective = 2 if tier == 1 and not established else tier
    key = candidate["context_rank_key"]
    if len(key) != 20:
        raise ValueError("Unknown source context key schema")
    matches = {digest(o):o for o in candidate["source_occurrences"]
        if o.get("source_span") == candidate["source_span"]
        and o.get("source_wording") == candidate["source_wording"]
        and o["citation"].get("canonical_page_id") == key[16]}
    head_valid = affinity = False
    head = None
    if len(matches) == 1:
        occurrence = next(iter(matches.values()))
        view = dict(reading_id=candidate["reading_id"], alternative_family=candidate["alternative_family"],
            node_id=candidate.get("node_id"), fill=candidate["fill"], occurrences=[occurrence], rank_key=[])
        try:
            observation = opportunity_allocation.descriptor(
                json.loads(opportunity_allocation.canonical(view)), 0)
            head_valid, affinity = observation["head_valid"], observation["role_affinity"]
            head = observation["source_head"]
        except (KeyError, TypeError, ValueError, IndexError):
            pass
    return dict(version=VERSION, effective_ordering_tier=effective, native_tier=tier,
        established_requirements=established, source_head_valid=head_valid,
        exact_argument_role_affinity=affinity, source_head=head,
        native_status_modified=False, factual_support_certified=False)


def ordering_key(candidate, query, marker, *, lexical_observation, priority_observation):
    """Require the ordinary validated-observation path, never saved keys."""
    if priority_observation != observe(candidate):
        raise ValueError("Stale or forged role-priority observation")
    fresh_context_key = context_relevance.ordering_key(candidate, query, marker,
        observation=lexical_observation)
    if not isinstance(fresh_context_key, tuple) or len(fresh_context_key) != 23:
        raise ValueError("Expected the ordinary validated 23-field focal context key")
    return fresh_context_key[:11] + (not priority_observation["exact_argument_role_affinity"],) + fresh_context_key[11:]
