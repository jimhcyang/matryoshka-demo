"""Phase-only, source-local definite-reference assessment compression.

No inference about execution or world truth. The raw two-sentence parent is
always retained; only a literal nominal reference is made explicit in analysis.
"""
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v6.planning import sentences, SECTION
from matryoshka_demo_v61.scope_matching import _layout
from matryoshka_next.facts import public_plan
from matryoshka_narrative import source_account_match as account
from matryoshka_narrative import source_relative_accounts as relative
from matryoshka_narrative import source_prefix_accounts as prefix

VERSION = "phase-local-definite-assessment/2"
PROOF_FIELD = "source_local_assessment_certificate"
TYPE = "LITERAL_LOCAL_NOMINAL_REFERENCE_QUALIFIED_ASSESSMENT"
_ASSESS = {"feel", "consider", "deem", "judge", "find"}
_NOMINAL = {"decision", "plan", "proposal", "action", "move", "policy", "arrangement"}
_ACCOUNTS = {"assessment", "appraisal", "evaluation", "judgment", "judgement", "view", "opinion", "conclusion"}
_DISTINCT = {"earlier", "older", "old", "previous", "prior", "other", "another", "different", "unrelated", "former"}
_CREATION = {"make", "issue", "form", "reach", "deliver", "produce", "offer", "express", "record", "give", "exist", "occur"}
_VERIFICATION = {"verify", "confirm", "validate", "substantiate", "corroborate", "authenticate", "check"}
_UNKNOWN = {"uncertain", "unclear", "unknown", "unverified", "unconfirmed", "unsubstantiated", "doubtful"}


def qualification_guard(base, page, selected_end):
    """Current-account qualification in this and the adjacent paragraph.

    This is a local ascription/verification HOLD, not a claim that the embedded
    event is false. Negative words must belong to the current account's own
    creation/verification governor, not an unrelated older assessment.
    """
    text = page["text"]
    breaks = list(re.finditer(r"\n[ \t\r]*\n", text[selected_end:]))
    first_end = selected_end + breaks[0].start() if breaks else len(text)
    stop = selected_end + breaks[1].start() if len(breaks) > 1 else len(text)
    raw = text[selected_end:stop]
    audit = dict(version="current-source-assessment-qualification/1", start=selected_end, end=stop,
        text_sha256=digest(raw), scope="CURRENT_AND_IMMEDIATELY_ADJACENT_PARAGRAPH",
        inspected=[], held=False, signed_opposition_inferred=False)
    if len(raw) > 8192 or MASK.search(raw):
        return dict(audit, held=True, reason="BOUNDED_TAIL_UNKNOWN_OR_OPAQUE")
    doc = base.engine.parse(raw)
    for noun in doc:
        nominal = noun.pos_ == "NOUN" and noun.lemma_.casefold() in _ACCOUNTS
        deictic = noun.pos_ == "PRON" and noun.lower_ in {"this", "that"} and noun.dep_ in {"nsubj", "nsubjpass"}
        if not nominal and not deictic:
            continue
        children = list(noun.children)
        descriptors = {t.lower_ for t in children} | {t.lemma_.casefold() for t in children}
        distinct = bool(descriptors & _DISTINCT) or any(t.dep_ == "poss" and t.pos_ == "PROPN" for t in children)
        same_paragraph = selected_end + noun.idx < first_end
        explicit = bool(descriptors & {"this", "that", "such", "current", "present"})
        current = deictic or nominal and not distinct and (explicit or same_paragraph and bool(descriptors & {"the", "no", "any"}))
        record = dict(reference=account._proof(noun), raw_start=selected_end + noun.idx,
            current=current, distinct_reference=distinct)
        audit["inspected"].append(record)
        if not current:
            continue
        # Follow only this nominal's governing path. A negator inside another
        # action/argument is not evidence of non-realization of this assessment.
        path = list(noun.ancestors)
        actions = [t for t in path if t.pos_ in {"VERB", "AUX"}
            and t.lemma_.casefold() in _CREATION | _VERIFICATION | {"deny", "retract"}]
        for action in actions:
            direct = list(action.children)
            owner = account._subject(action)
            owner_negative = owner is not None and (owner.lower_ in {"nobody", "nothing", "none"}
                or any(t.lower_ in {"no", "neither"} for t in owner.children))
            negative = bool(descriptors & {"no", "neither"}) or owner_negative or any(
                t.dep_ == "neg" or t.lower_ == "never" for t in direct)
            negative |= any(t.lower_ in {"no", "neither", "nobody", "none"}
                for agent in direct if agent.dep_ == "agent" for t in agent.subtree)
            negative |= any(t.dep_ == "neg" or t.lower_ == "never"
                for aux in direct if aux.dep_ in {"aux", "auxpass"} for t in aux.children)
            uncertain = any(t.lower_ in _UNKNOWN or t.lower_ in {"whether", "if"} and t.dep_ == "mark"
                for head in [action, *action.ancestors] for t in [head, *head.children])
            denied = action.lemma_.casefold() in {"deny", "retract"} and not negative
            record.update(governor=account._proof(action), negative=negative, uncertain=uncertain)
            if negative or uncertain or denied:
                return dict(audit, held=True,
                    reason="CURRENT_ASSESSMENT_ASCRIPTION_OR_VERIFICATION_QUALIFIED")
    return audit


def normal(text):
    return " ".join(text.casefold().split()).removesuffix(".")


def _span(tokens):
    tokens = list(tokens)
    return min(t.idx for t in tokens), max(t.idx + len(t) for t in tokens)


def _nominal_prefix(base, head, query_subject):
    """Only a complete literal NP or a named-location shared-kind suffix.

    This is not free substring matching. The one truncation allowed is printed
    coordinated proper locations followed by a plural location-kind noun and
    an optional locative PP, e.g. A and B provinces in the uplands.
    """
    tokens = [t for t in head.subtree if not t.is_space and not t.is_punct]
    a, b = _span(tokens)
    text = head.doc.text[a:b]
    if normal(text) == normal(query_subject):
        return dict(start=a, end=b, kind="EXACT_COMPLETE_NOMINAL")
    wanted = normal(query_subject)
    if not normal(text).startswith(wanted + " "):
        return None
    # Raw offsets are normalized-text offsets here; final citations replay
    # their original offsets through the layout map below.
    endings = [t for t in tokens if normal(head.doc.text[a:t.idx + len(t)]) == wanted]
    if len(endings) != 1 or endings[0].pos_ != "PROPN":
        return None
    last = endings[0]
    after = [t for t in tokens if t.idx > last.idx]
    if not after:
        return None
    kind = after[0]
    from matryoshka_demo.roles import lexicon
    senses = lexicon().synsets(kind.text.casefold(), pos="n")
    if (kind.pos_ != "NOUN" or kind.tag_ != "NNS" or kind.dep_ != "conj"
            or last.head != kind or not any(s.lexname() == "noun.location" for s in senses)):
        return None
    rest = after[1:]
    if rest:
        prep = rest[0]
        if prep.dep_ != "prep" or prep.lower_ not in {"in", "within"}:
            return None
        if {t.i for t in prep.subtree if not t.is_space and not t.is_punct} != {t.i for t in rest}:
            return None
        if any(t.pos_ not in {"ADP", "DET", "ADJ", "NOUN", "PROPN"} or t.dep_ == "neg" for t in rest):
            return None
    return dict(start=a, end=b, kind="NAMED_COORDINATE_SHARED_LOCATION_KIND",
        complete_source_nominal=text, retained_query_nominal=query_subject,
        shared_location_kind=account._proof(kind), omitted_locative_is_context_only=True)


def supplement(matcher, atom, page, unit, control):
    base = getattr(matcher, "baseline", matcher)
    if (base.case["task"] not in {"hypothesis", "reconstruction"}
            or atom.get("kind") != "proposition"
            or control.get("direction") not in {"UNRESOLVED", "PARTIAL"}
            or any(control.get(k) for k in ("source_account_policy_withheld", "root_content_withheld",
                "root_content_policy_applicable", "potential_counter", "unbound_material_counter"))):
        return control
    public_plan(base.case, dict(atoms=[atom], query_sha256=digest(base.case["query"])))
    pi = base.positions.get(page.get("id"))
    if pi is None or page != base.corpus.pages[pi] or digest(page["text"]) != page["source_sha256"]:
        raise ValueError("Assessment needs the complete bound raw page")
    selected = base.policy.citation(pi, unit["start"], unit["end"])
    if selected != control.get("citation") or selected["text"] != unit.get("text", unit.get("quote")):
        raise ValueError("Assessment unit citation does not replay")
    parts = list(sentences(page["text"]))
    indices = [i for i, p in enumerate(parts) if (p["start"], p["end"]) == (unit["start"], unit["end"])]
    if len(indices) != 1 or indices[0] == 0 or not prefix._public(base, atom):
        return control
    previous = parts[indices[0] - 1]
    gap = page["text"][previous["end"]:unit["start"]]
    raw = page["text"][previous["start"]:unit["end"]]
    if (gap.strip() or re.search(r"\n\s*\n", raw) or len(raw) > 4096
            or MASK.search(raw) or SECTION.search(raw)):
        return control
    with offline():
        qview, _, qnorm = _layout(base.engine, atom["text"])
        parent = base.policy.citation(pi, previous["start"], unit["end"])
        view, mapping, snorm = _layout(base.engine, raw)
        qdoc, doc = base.engine.parse(qview), base.engine.parse(view)
        qr = account._root(qdoc)
        qs = account._subject(qr) if qr is not None else None
        if (qs is None or qs.lemma_.casefold() not in _NOMINAL or qs.pos_ != "NOUN"
                or qr.lemma_.casefold() not in _ASSESS or qr.tag_ != "VBN"
                or not any(c.dep_ == "auxpass" and c.tag_ == "VBD" for c in qr.children)
                or any(c.dep_ == "neg" or c.tag_ == "MD" for c in qr.children)):
            return control
        qa, qb = _span(qs.subtree)
        if qa != 0:
            return control
        query_subject, query_tail = qview[qa:qb], qview[qb:]
        source_sentences = list(doc.sents)
        if len(source_sentences) != 2:
            return control
        first, second = source_sentences
        # A unique, overt same-kind nominal in a simple source-owned matrix.
        candidates = [t for t in first if t.lemma_.casefold() == qs.lemma_.casefold()
            and t.pos_ == "NOUN" and t.dep_ in {"nsubj", "nsubjpass", "attr"}]
        if len(candidates) != 1:
            return control
        head = candidates[0]
        if (head.head.dep_ != "ROOT" or head.head.lemma_.casefold() in account._REPORTS
                or any(t.dep_ in {"neg", "mark"} or t.tag_ == "MD" or t.is_quote for t in first)):
            return control
        bound = _nominal_prefix(base, head, query_subject)
        if bound is None:
            return control
        root = second.root
        subject = account._subject(root)
        if subject is None or subject.lemma_.casefold() != head.lemma_.casefold():
            return control
        if [t.lower_ for t in subject.subtree if not t.is_space] != ["the", head.lower_]:
            return control
        assessments = [t for t in second if t.dep_ in {"ROOT", "conj"}
            and t.lemma_.casefold() == qr.lemma_.casefold()]
        if len(assessments) != 1:
            return control
        assessment = assessments[0]
        ref = account._subject(assessment)
        if assessment != root:
            if (assessment.head != root or ref is None or ref.lower_ != "it"
                    or root.lemma_.casefold() != "be"
                    or [t.lower_ for t in root.children if t.dep_ == "cc"] != ["but"]
                    or any(t.dep_ in {"neg", "ccomp", "xcomp", "advcl"} or t.tag_ == "MD"
                        for t in root.children)):
                return control
        else:
            ref = subject
        if ref is None or ref.dep_ != qs.dep_:
            return control
        end_ref = max(t.idx + len(t) for t in ref.subtree)
        if normal(view[end_ref:second.end_char]) != normal(query_tail):
            return control
        critical = [head, root, subject, assessment, ref]
        guards = relative._guard(base, page, parent, doc, critical, quoted_view=False)
        if guards is None or prefix._metadiscourse_holds(base, page, unit["end"]):
            return control
        qualification = qualification_guard(base, page, unit["end"])
        if qualification["held"]:
            return control
        if (relative._tail_holds(base, page, unit["end"], head,
                predicate=assessment.lemma_.casefold(), event_terms=(head.lemma_.casefold(), "assessment"))
                or account._reporting_tail_holds(base, page, unit["end"], head)):
            return control
        a, b = relative._raw_span(parent, mapping, bound["start"], bound["end"])
        antecedent = base.policy.citation(pi, a, b)
        scope = dict(kind="QUERIED_OPERATOR_ONLY", inner_execution_certified=False,
            event_join_certified=False, world_truth_certified=False,
            canonical_identity_certified=False, physical_executor_certified=False)
        proof = dict(version=VERSION, type=TYPE, scope=scope, citation=parent,
            selected_citation=selected, antecedent_citation=antecedent,
            full_source_page_sha256=page["source_sha256"], query_sha256=digest(base.case["query"]),
            atom_sha256=digest(atom), public_query_spans=deepcopy(atom["query_spans"]),
            strict_control_sha256=digest(control), nominal_binding=bound,
            definite_reference=account._proof(subject), assessment_reference=account._proof(ref),
            assessment=account._proof(assessment), query_assessment=account._proof(qr),
            query_normalization=qnorm, source_normalization=snorm, raw_guards=guards,
            local_assessment_qualification=qualification,
            full_parent_retained=True, assessment_tail_literal=True,
            raw_identity_claimed=False, source_text_modified=False,
            omitted_contrast_not_counter=True, named_actor_identity_inferred=False)
        row = deepcopy(control)
        row.update(direction="SUPPORT", version=VERSION, citation=parent,
            source_local_assessment_certificate=proof, strict_local_assessment_control=deepcopy(control),
            complete_required_frames=True, support_scope=scope["kind"], queried_account_scope=scope,
            qualified=True, qualified_account="The source reports this assessment of its explicitly named local nominal; the full contrast, rationale and source wording remain attached.",
            source_assertion_not_world_truth=True, actual_inner_event_established=False,
            world_truth_certified=False, event_bindings=[], cross_atom_or_event_join_certified=False)
        row["checks"] = dict(control.get("checks", {}), source_local_nominal="PASS",
            literal_assessment_tail="PASS", full_parent="PASS", execution="NOT_CERTIFIED")
        return row


def replay(matcher, atom, page, unit, control, certificate):
    produced = supplement(matcher, atom, page, unit, control)
    if certificate.get("version") != VERSION or produced.get(PROOF_FIELD) != certificate:
        raise ValueError("Local assessment proof differs from trusted raw producer replay")
    return deepcopy(certificate)
