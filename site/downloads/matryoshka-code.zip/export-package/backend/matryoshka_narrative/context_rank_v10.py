"""Opt-in full-assessed-pool context priority. No source, grammar or fact judgment."""
from copy import deepcopy
from matryoshka_demo.io import digest
from matryoshka_demo.source_view_policy import descriptor
from . import terminal_scores as terminal, candidate_identity, controller_role
from .context_priority_v10 import (VERSION, require, public_context, features, context_key, reorder_context_only, dedup)
from .context_priority_v10 import SCORE_VERSION, SCORE_UNITS, candidate_projection, make_card, replay_scorecard


def rank_pool(case,plan,result,retrieval,pages,citation,*,half_life=None,_retain_candidates=False):
    require(half_life in {None,90} and isinstance(result.get('assessed_candidates'),list),'FULL_ASSESSED_POOL_REQUIRED')
    before=digest(result['assessed_candidates'])
    full=result['assessed_candidates']
    require(len({c['id'] for c in full})==len(full),'UNIQUE_RAW_CANDIDATES_REQUIRED')
    score_cache={}
    def score(c):
        key=digest(c)
        if key not in score_cache:
            score_cache[key]=terminal.candidate_score(c,retrieval,case=case,plan=plan,version=terminal.CONTEXT_POINTS_VERSION)
        return deepcopy(score_cache[key])
    views=[]
    for row in result['readings']:
        rid=row['reading']['id']
        raw=[c for c in full if c['reading_id']==rid]
        held=[c['id'] for c in raw if controller_role.withheld_from_shortlist(c,query_sha256=digest(case['query']))]
        eligible=[c for c in raw if c['id']not in set(held) and c['local_decision']['status'] in terminal.TIERS]
        consolidated=candidate_identity.consolidate(eligible,score=score,source_local_identity=True,query_sha256=digest(case['query']))
        cards={c['id']:score(c) for c in consolidated}
        ordered=sorted(consolidated,key=lambda c:(-cards[c['id']]['score'],c.get('source_rank_position',10**9),c['id']))
        baseline=dedup(ordered)
        context=public_context(case,plan,row['reading'])
        observed={}
        if context['active']:
            for c in ordered:
                if c['local_decision']['status']=='exploratory_contextual' and cards[c['id']]['evidence_tier']==0:
                    observed[c['id']]=features(c,case,context,pages,citation,half_life)
            ranked=dedup(reorder_context_only(ordered,cards,observed))
        else:ranked=baseline
        def export(c,rank):
            card=cards[c['id']]
            return dict(id=c['id'],fill=c['fill'],rank=rank,local_status=c['local_decision']['status'],
                evidence_tier=card.get('evidence_tier'),native_v7_scorecard=card,
                context_features=observed.get(c['id']),candidate_source_gate_projection_sha256=digest(c),
                source_span=deepcopy(c.get('source_span')),source_wording=c.get('source_wording'),
                sources=deepcopy(c.get('sources',[])),identity_consolidation=deepcopy(c.get('identity_consolidation')))
        views.append(dict(reading=deepcopy(row['reading']),raw_assessed_count=len(raw),controller_withheld_ids=held,
            eligible_raw_count=len(eligible),source_local_consolidated_count=len(consolidated),public_context=context,
            native_displayed_ids=[c['id'] for c in row['candidates']],
            v7_order=[export(c,i) for i,c in enumerate(baseline,1)],v10_order=[export(c,i) for i,c in enumerate(ranked,1)],
            all_raw_source_decisions_retained=True))
        if _retain_candidates:
            views[-1]['_retained_candidates']=ranked
            views[-1]['_complete_consolidated_candidates']=consolidated
    require(before==digest(result['assessed_candidates']),'RAW_ASSESSED_SOURCE_OR_DECISION_CHANGED')
    return dict(version=VERSION,half_life_days=half_life,full_raw_assessed_count=len(full),raw_assessed_sha256=before,
        readings=views,all_original_gates_tiers_and_raw_candidates_unchanged=True,API_calls=0,native_runs=0,
        confidence_or_factual_support_claimed=False)


def annotate_result(result,retrieval,*,case,plan,pages,source_policy,source_binding,half_life_days=90,top_k=5):
    """Fresh postconstruction opt-in. Caller supplies its trusted complete source context."""
    if case['task']!='redaction':return deepcopy(result)
    require(half_life_days==90 and type(top_k)is int and 1<=top_k<=5,'V10_FIXED_90D_AND_DISPLAY_CAP')
    require(source_policy.case==case and source_policy.corpus.corpus==case['corpus'],'V10_TRUSTED_POLICY_CASE_MISMATCH')
    require(isinstance(source_binding,dict)and source_binding.get('corpus')==case['corpus']
        and isinstance(source_binding.get('resource_id'),str)and source_binding['resource_id']
        and all(isinstance(source_binding.get(k),str)and len(source_binding[k])==64
            and all(c in '0123456789abcdef'for c in source_binding[k])for k in('sha256','registry_sha256')),
        'V10_TRUSTED_SOURCE_INDEX_BINDING_REQUIRED')
    require(result.get('task')=='redaction' and result.get('query_sha256')==digest(case['query'])
        and result.get('provided_plan_sha256')==digest(plan),'V10_RESULT_PUBLIC_PLAN_BINDING')
    require(result.get('input_nomination') is None,'V10_INPUT_NOMINATION_EXTENSION_FORBIDDEN')
    require([r['reading']for r in result['readings']]==plan['readings_packet']['readings'],'V10_DECLARED_READINGS_CHANGED')
    ids=[p['id']for _,p in pages]
    require(ids==result['inspected_page_ids']and len(ids)==len(set(ids)),'V10_EXACT_COMPLETE_INSPECTED_PAGE_SEQUENCE')
    by_id={p['id']:p for _,p in pages};positions={p['id']:pi for pi,p in pages}
    for pi,p in pages:
        require(type(pi)is int and source_policy.corpus.page_index[p['id']]==pi
            and source_policy.bound_pages[p['id']]==p and p['source_sha256']==digest(p['text']),
            'V10_ACTUAL_GLOBAL_PAGE_POSITION_REQUIRED')
    def citation(pid,a,b):return source_policy.citation(positions[pid],a,b)
    raw=result.get('assessed_candidates')
    require(isinstance(raw,list),'V10_FULL_ASSESSED_POOL_REQUIRED')
    for c in raw:
        require(c.get('provenance')!='INPUT'and not c.get('input_nomination_id'),'V10_CORPUS_ONLY')
        require(c['reading_id']==c.get('declared_reading',{}).get('id'),'V10_CANDIDATE_DECLARED_READING')
        require(c['fill']==c.get('source_wording')or c.get('insertion_edits')or c.get('first_class_adjunct')is not None,
            'V10_RECORDED_REALIZATION_REQUIRED')
        for q in c.get('sources',[]):
            require(q.get('canonical_page_id')in by_id,'V10_CANDIDATE_SOURCE_OUTSIDE_INSPECTED_POOL')
            actual=citation(q['canonical_page_id'],q['start'],q['end'])
            require(all(actual.get(k)==q.get(k)for k in('canonical_page_id','document_id','date','start','end','text','page_sha256')),
                'V10_CANDIDATE_SOURCE_POLICY_REPLAY')
    before=digest(result);policy=descriptor(source_policy.source_view_policy)
    ranking=rank_pool(case,plan,result,retrieval,by_id,citation,half_life=90,_retain_candidates=True)
    held=sorted({cid for r in ranking['readings']for cid in r['controller_withheld_ids']})
    shortlist=result.get('controller_shortlist')
    if held or isinstance(shortlist,dict):
        require(isinstance(shortlist,dict)and sorted(shortlist.get('withheld_candidate_ids',[]))==held
            and shortlist.get('audit_collection')=='assessed_candidates','V10_CONTROLLER_AUDIT_INVENTORY_CHANGED')
    output=deepcopy(result);prior=deepcopy(output.get('terminal_scores'));ledgers=[]
    for row,ranked in zip(output['readings'],ranking['readings'],strict=True):
        cards={}
        for c in ranked['_complete_consolidated_candidates']:
            base=terminal.candidate_score(c,retrieval,case=case,plan=plan,version=terminal.CONTEXT_POINTS_VERSION)
            feature=(features(c,case,ranked['public_context'],by_id,citation,90)
                if ranked['public_context']['active'] and c['local_decision']['status']=='exploratory_contextual'
                and base['evidence_tier']==0 else None)
            cards[c['id']]=make_card(c,base,feature,case=case,plan=plan,context=ranked['public_context'],
                source_binding=source_binding,source_view_policy=policy)
        retained=ranked['_retained_candidates'][:10]
        for ordinal,c in enumerate(retained,1):
            card=cards[c['id']]
            c['rank']=ordinal;c['terminal_scorecard']=deepcopy(card)
            c.setdefault('ranking',{}).update(terminal_scoring_version=SCORE_VERSION,
                canonical_order='Preserved factual slots; contextual adjacent-pronoun Human category and fixed90-day own-citation merit; V7/source position break exact ties')
            require(digest(candidate_projection(c))==card['bindings']['raw_candidate_sha256'],'V10_FINAL_CANDIDATE_BINDING_CHANGED')
        row['candidates']=retained[:top_k];row['reserve_candidates']=retained[top_k:10]
        ledgers.append(dict(reading_id=row['reading']['id'],public_context=ranked['public_context'],
            v7_ranked_ids=[c['id']for c in ranked['v7_order']],ranked_ids=[c['id']for c in ranked['_retained_candidates']],
            full_consolidated_scorecards=list(cards.values()),raw_assessed_count=ranked['raw_assessed_count'],
            withheld_candidate_ids=ranked['controller_withheld_ids']))
    output['candidates']=[c for row in output['readings']for c in row['candidates']]
    output['legacy_terminal_scores_before_v10']=prior
    output['terminal_scores']=dict(version=SCORE_VERSION,probability=False,ranking_applied=True,judgments_unchanged=True,
        score_units=SCORE_UNITS,readings=[dict(reading_id=row['reading']['id'],
            candidates=[c['terminal_scorecard']for c in row['candidates']],
            reserve_candidates=[c['terminal_scorecard']for c in row['reserve_candidates']])for row in output['readings']],
        legacy_overall_auxiliary=deepcopy((prior or {}).get('overall')))
    output['context_rank_v10']=dict(version=VERSION,score_version=SCORE_VERSION,half_life_days=90,
        source_binding=deepcopy(source_binding),source_view_policy=policy,provided_plan_sha256=digest(plan),
        original_result_sha256=before,raw_assessed_pool_sha256=digest(raw),withheld_candidate_ids=held,
        inspected_page_bindings=[dict(canonical_page_id=p['id'],page_sha256=p['source_sha256'],global_page_index=pi)for pi,p in pages],
        ledger=ledgers,full_assessed_pool=True,input_or_model_nomination_used=False,
        original_gates_tiers_and_sources_unchanged=True,new_B_or_support_credit=False,
        ranking_contract='PRESERVE_NON_CONTEXTUAL_SLOTS_THEN_CONTEXTUAL_HUMAN_MERIT_V7_TIES; CLIENT_MUST_NOT_RESORT_BY_DISPLAY_FLOAT')
    output['retained_ranking']=dict(version='native-context-v10-top-ten/1',displayed_per_reading=top_k,retained_per_reading=10,
        full_assessed_pool=True,same_scoring_and_deduplication=True,extra_candidates_are_not_evidence_votes=True,
        original_top_five_selection_unchanged=False)
    if isinstance(output.get('controller_shortlist'),dict):
        output['controller_shortlist']['displayed_count']=len(output['candidates'])
        for row in output['readings']:
            own=output['controller_shortlist'].get('counts_by_reading',{}).get(row['reading']['id'])
            if isinstance(own,dict):own['displayed']=len(row['candidates'])
    require(digest(result)==before and output['assessed_candidates']==raw,'V10_RAW_NATIVE_SOURCE_OR_GATE_CHANGED')
    return output
