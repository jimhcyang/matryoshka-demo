"""Detached saved-narrative digests; never inference inputs or native rewrites."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import sqlite3

from matryoshka_current.analyst_digest import FIELDS, PROMPT, SCHEMA, make_input
from matryoshka_demo.io import digest
from .presentation import read

VERSION = "narrative-saved-digest/1"


def sealed(value):
    return value.get("sha256") == digest({k:v for k,v in value.items() if k != "sha256"})


def binding(case, config, item, native, resource, record):
    return dict(case_id=case["case_id"], config=config, query_sha256=digest(case["query"]),
        native_version=native["version"], native_checksum=native["native_checksum"],
        native_packet_sha256=digest(native), native_checkpoint=deepcopy(item["native_checkpoint"]),
        condition_ref=deepcopy(item["condition_ref"]), condition_record_sha256=digest(record),
        resource_binding_sha256=digest(resource))


def validate_text(text, count):
    if (not isinstance(text, str) or not 50 <= len(text.split()) <= 100
            or type(count) is not int or count < 0
            or any(not 1 <= int(n) <= count for n in re.findall(r"\bS(\d+)\b", text))):
        raise ValueError("Digest must contain 50-100 words and valid source labels")


def replay_sources(root, payload, index_ref, resource):
    """Open the exact saved index read-only and replay every quoted byte span."""
    root = Path(root).resolve()
    path = (root / index_ref["path"]).resolve()
    if not path.is_relative_to(root) or index_ref["sha256"] != resource["index_sha256"]:
        raise ValueError("Digest index/resource mismatch")
    with path.open("rb") as stream:
        if hashlib.file_digest(stream, "sha256").hexdigest() != index_ref["sha256"]:
            raise ValueError("Digest immutable source index changed")
    with sqlite3.connect(path.as_uri() + "?mode=ro&immutable=1", uri=True) as db:
        db.execute("PRAGMA query_only=ON")
        for i, source in enumerate(payload["sources"], 1):
            if (not set(FIELDS).issubset(source) or source.get("id") != "S" + str(i)
                    or type(source["start"]) is not int or type(source["end"]) is not int
                    or not 0 <= source["start"] < source["end"]):
                raise ValueError("Invalid digest source span")
            row = db.execute("SELECT payload FROM page WHERE id=?", (source["canonical_page_id"],)).fetchone()
            if row is None:
                raise ValueError("Digest source page absent from saved index")
            page = json.loads(row[0])
            if (page.get("permitted") is not True or page.get("visibility") not in {"earlier", "both"}
                    or page.get("corpus") != resource["corpus"]
                    or page["document_id"] != source["document_id"] or page["date"] != source["date"]
                    or not page["date"] < payload["evidence_strictly_before"]
                    or digest(page["text"]) != source["page_sha256"]
                    or page["text"][source["start"]:source["end"]] != source["text"]):
                raise ValueError("Digest source bytes or eligibility changed")


def prepare_input(root, case, config, item, native, resource):
    """Validate real attachments and reuse the existing strict input whitelist."""
    actual = read(root, item["native_checkpoint"])
    condition = read(root, item["condition_ref"])
    record = condition["configurations"][config]
    engine_case = dict(case, task="reconstruction" if case["task"] == "mosaic" else case["task"])
    if (actual != native or native.get("version") not in {"narrative-local-execution/2", "narrative-local-execution/3"}
            or native["public_case"] != case or native["case"] != engine_case
            or native["native_checksum"] != digest(native["result"])
            or native["query_sha256"] != digest(case["query"])
            or condition["case"] != case or condition["resource_binding"] != resource
            or record["case"] != case or record["config"] != config
            or record["native_checkpoint"] != item["native_checkpoint"]
            or record["native_checksum"] != native["native_checksum"]
            or record["native_record_sha256"] != digest(native)
            or record["resource_binding"] != resource or record["index_ref"] != native["binding"]):
        raise ValueError("Digest native/condition/question/resource attachment changed")
    payload = make_input(native, record, resource)
    if any(s["document_id"] == case["document_id"] for s in payload["sources"]):
        raise ValueError("Whole origin must remain excluded from digest evidence")
    replay_sources(root, payload, record["index_ref"], resource)
    return payload, binding(case, config, item, native, resource, record)


def read_for_case(root, index_ref, report_ref, case, config, item, native, resource):
    """Server API: exact report/case/config/native/condition/resource selection."""
    envelope = dict(version=VERSION, case_id=case["case_id"], config=config,
        public_case=deepcopy(native["public_case"]),
        resource_binding=deepcopy(resource), native_version=native.get("version"),
        native_checkpoint=deepcopy(item["native_checkpoint"]),
        condition_ref=deepcopy(item["condition_ref"]), report_ref=deepcopy(report_ref),
        native_checksum=native["native_checksum"], native_packet_sha256=digest(native),
        execution_kind="saved_narrative", current_native_execution=False,
        postrun=True, used_for_inference=False, api_calls=0)
    unavailable = dict(envelope, available=False, status="NO_SAVED_DIGEST")
    if index_ref is None:
        return unavailable
    index = read(root, index_ref)
    if (index.get("version") != VERSION or not sealed(index) or index.get("report_ref") != report_ref
            or index.get("used_for_inference") is not False):
        raise ValueError("Digest index/report binding changed")
    report = read(root, report_ref)
    row = next((r for r in report["cases"] if r["case"]["case_id"] == case["case_id"]), None)
    if row is None or row["case"] != case or row["resource_binding"] != resource or row["configurations"][config] != item:
        raise ValueError("Digest request does not match the pinned report")
    entry = index["entries"].get(case["case_id"] + "/" + config)
    if entry is None:
        return unavailable
    if entry["native_checkpoint"] != item["native_checkpoint"] or entry["condition_ref"] != item["condition_ref"]:
        raise ValueError("Digest entry attachment changed")
    value = read(root, entry["ref"])
    payload, expected = prepare_input(root, case, config, item, native, resource)
    if (value.get("version") != VERSION or not sealed(value) or value.get("binding") != expected
            or value.get("used_for_inference") is not False or value.get("report_ref") != report_ref
            or read(root, value["input_ref"]) != payload or value.get("input_sha256") != digest(payload)
            or value.get("source_count") != len(payload["sources"])):
        raise ValueError("Digest saved input or native binding changed")
    validate_text(value.get("text"), value["source_count"])
    return dict(envelope, available=True, status="SAVED_DIGEST", text=value["text"],
        sources=deepcopy(payload["sources"]), source_count=value["source_count"],
        binding=expected, input_sha256=digest(payload))
