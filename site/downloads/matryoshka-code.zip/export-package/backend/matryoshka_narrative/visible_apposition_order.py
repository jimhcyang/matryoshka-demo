"""Supplemental opportunities for source-owned roles of explicitly visible names."""
from types import FunctionType

from matryoshka_demo.io import digest
from . import opportunity_allocation as allocator
from . import context_relevance, candidate_salience, context_priority
from .visible_apposition_context import binds_occurrence

VERSION = "visible-owner-apposition-opportunity-order/2"


def _matched(observed, occurrence, query_sha256, head, reading):
    if (not observed or not binds_occurrence(observed, occurrence, query_sha256)
            or not isinstance(reading, dict)
            or observed["public_binding"].get("reading_sha256") != digest(reading)):
        return False
    role = observed["source_role_head"]
    return head.get("span") == [role["start"], role["end"]] and head.get("text") == role["text"]


def allocate(groups, primary_indices, query_sha256, *, budget, primary_cap, max_rep_tokens=32):
    before = digest(groups)
    def descriptor(group, index):
        row = allocator.descriptor(group, index)
        occurrence = group["occurrences"][0]
        observed = occurrence.get("selection_cue", {}).get("visible_apposition_context")
        matched = row["head_valid"] and _matched(observed, occurrence,
            query_sha256, row["source_head"], group.get("original_reading"))
        row["tier"] = row["tier"][:1] + (not matched,) + row["tier"][1:]
        return row
    local = FunctionType(allocator.allocate.__code__, {**vars(allocator), "descriptor":descriptor},
        allocator.allocate.__name__, allocator.allocate.__defaults__, allocator.allocate.__closure__)
    local.__kwdefaults__ = allocator.allocate.__kwdefaults__.copy()
    result = local(groups, primary_indices, budget=budget, primary_cap=primary_cap,
        max_rep_tokens=max_rep_tokens)
    result.update(visible_owner_order_version=VERSION, visible_owner_context_is_proof=False,
        visible_owner_context_indices=[i for i, group in enumerate(groups)
            if len(group["occurrences"]) == 1 and descriptor(group, i)["tier"][1] is False],
        primary_lane_preserved=True)
    assert result["indices"][:len(primary_indices)] == primary_indices and digest(groups) == before
    return result


def matches_candidate(candidate, query_sha256):
    gate = context_relevance.saved_gate(candidate)
    if not gate["eligible_for_reordering"] or candidate_salience.recorded_counter(candidate["local_decision"]):
        raise ValueError("Saved source/grammar/factual/counter hold remains")
    raw = candidate["context_rank_key"]
    if len(raw) != 20:
        raise ValueError("Original source priority schema required")
    primary = {digest(o):o for o in candidate["source_occurrences"]
        if o["source_span"] == candidate["source_span"]
        and o["source_wording"] == candidate["source_wording"]
        and o["citation"]["canonical_page_id"] == raw[16]}
    if len(primary) != 1:
        return False
    occurrence = next(iter(primary.values()))
    observed = occurrence.get("selection_cue", {}).get("visible_apposition_context")
    if not context_priority.observe(candidate)["source_head_valid"]:
        return False
    return _matched(observed, occurrence, query_sha256, occurrence.get("source_head", {}),
        candidate.get("declared_reading"))
