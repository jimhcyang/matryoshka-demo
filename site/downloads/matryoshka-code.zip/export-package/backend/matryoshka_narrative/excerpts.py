"""Order recorded quotations within unchanged document/direction families."""
from collections import defaultdict, deque
import re

VERSION = "recorded-excerpt-content-coverage/2"
_FUNCTION = frozenset("a an the and or of to in at on by for from with as is are was were be been being has have had that this it its their his her".split())


def content_words(text):
    return {word.casefold() for word in re.findall(r"[A-Za-z0-9]+", text)
            if word.casefold() not in _FUNCTION}


def quality(item, reference):
    requested = content_words(item["text"])
    matched = requested & content_words(reference["text"])
    return dict(version=VERSION, fraction=len(matched) / len(requested) if requested else 0.,
                requested=sorted(requested), matched=sorted(matched),
                word_count=len(re.findall(r"\S+", reference["text"])),
                factual_support_certified=False, native_score_modified=False)


def _references(row):
    return ([row["citation"]] if "citation" in row else []) + list(row.get("citations", []))


def order_rows(atom, rows):
    """A fuller body can precede a heading without acquiring support credit."""
    groups, schedule = defaultdict(list), []
    for index, row in enumerate(rows):
        refs = _references(row)
        documents = {ref["document_id"] for ref in refs}
        # Multi-document certificates retain their exact original position.
        key = (row["direction"], next(iter(documents))) if len(documents) == 1 else ("fixed", index)
        assessments = [quality(atom, ref) for ref in refs]
        best = max(assessments, key=lambda a: (a["fraction"], -a["word_count"]),
                   default=dict(fraction=0., word_count=0))
        groups[key].append((row, best, index))
        schedule.append(key)
    queues = {key: deque(sorted(group, key=lambda x: (-x[1]["fraction"], x[1]["word_count"], x[2])))
              for key, group in groups.items()}
    selected = [queues[key].popleft() for key in schedule]
    return [row for row, _, _ in selected], dict(version=VERSION,
        rule="CONTENT_COVERAGE_WITHIN_UNCHANGED_DIRECTION_DOCUMENT_SLOTS",
        original_row_indices=[index for _, _, index in selected],
        source_objects_modified=False, factual_judgments_modified=False,
        terminal_formula_modified=False)


def select_witnesses(items, inventory, max_paths):
    """Replay happens upstream; selection never introduces a new quotation."""
    by_item = {item["id"]: item for item in items}
    proposals = [(row, ref) for row in inventory for ref in row["source_refs"]]
    groups, primary_slots, tail_slots, seen = defaultdict(list), [], [], set()
    for index, (row, ref) in enumerate(proposals):
        key = row["item_id"], row["direction"], ref["document_id"]
        item = by_item[row["item_id"]]
        # Redaction item text is a proposed fill, not a public input fact.
        assessment = quality(item, ref) if item.get("query_atom_id") else None
        groups[key].append((row, ref, assessment, index))
        (tail_slots if key in seen else primary_slots).append(key)
        seen.add(key)
    queues = {key: deque(sorted(group, key=lambda x: (
        -x[2]["fraction"], x[2]["word_count"], x[3])) if group[0][2] is not None else group)
        for key, group in groups.items()}
    by_id = defaultdict(deque)
    for key in primary_slots:
        by_id[key[0]].append(key)
    schedule = []
    while any(by_id.values()):
        for item in items:
            if by_id[item["id"]]:
                schedule.append(by_id[item["id"]].popleft())
    # Keep the old cross-family allocation, including its deferred tail.
    schedule.extend(tail_slots)
    chosen = [queues[key].popleft() for key in schedule[:max_paths]]
    return [(row, ref) for row, ref, _, _ in chosen], [dict(
        item_id=row["item_id"], direction=row["direction"], document_id=ref["document_id"],
        canonical_page_id=ref["canonical_page_id"], start=ref["start"], end=ref["end"],
        assessment=assessment, original_proposal_index=index)
        for row, ref, assessment, index in chosen]
