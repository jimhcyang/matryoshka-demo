"""Read-only inventory of sealed development conditions, not accuracy estimates."""
from collections import Counter
import hashlib
from pathlib import Path

from matryoshka_demo.io import digest
from matryoshka_next.workflow import read

VERSION = "narrative-condition-inventory/1"


def summarize(path, root):
    root = Path(root).resolve()
    path = Path(path).resolve()
    if not path.is_relative_to(root):
        raise ValueError("Native checkpoint must be inside the demo root")
    packet = read(path)
    if packet.get("version") != "narrative-local-execution/1":
        raise ValueError("Only explicitly sealed narrative conditions are inventoried")
    result, case = packet["result"], packet["public_case"]
    if (("native_checksum" in packet and packet["native_checksum"] != digest(result))
            or packet["query_sha256"] != digest(case["query"])):
        raise ValueError("Native result or public question seal changed")
    if packet.get("code_pins") is None:
        raise ValueError("Native code epoch is missing")
    atoms = result.get("atoms", [])
    readings = result.get("readings", [])
    return dict(native_ref=dict(path=str(path.relative_to(root)),
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()),
        case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
        query=case["query"], document_id=case["document_id"], cutoff=case["date"],
        query_sha256=packet["query_sha256"], code_epoch=digest(packet["code_pins"]),
        result_seal_recorded="native_checksum" in packet,
        settings=packet.get("configuration"), settings_recorded="configuration" in packet,
        publication_eligibility_certified=False,
        status=result.get("status"), timings=packet["timings"],
        atoms=[dict(id=a["id"], text=a["text"], status=a["status"],
            supporting_quotes=len(a.get("positive_evidence", [])),
            opposing_quotes=len(a.get("counterevidence", [])),
            partial_quotes=len(a.get("partial_evidence", []))) for a in atoms],
        readings=[dict(reading_id=r["reading"]["id"], candidates=[dict(rank=c["rank"],
            fill=c["fill"], node_id=c.get("node_id"),
            support=c.get("support_assessment", {}).get("label"),
            factual_recommendation=c.get("local_decision", {}).get("status") == "evidence_backed_suggestion")
            for c in r["candidates"]]) for r in readings])


def inventory(paths, root):
    rows = [summarize(path, root) for path in paths]
    rows.sort(key=lambda r:(r["corpus"], r["task"], r["case_id"], r["native_ref"]["path"]))
    cells = Counter((r["corpus"], r["task"]) for r in rows)
    return dict(version=VERSION, conditions=rows, condition_count=len(rows),
        question_versions=len({r["case_id"] for r in rows}),
        sealed_result_conditions=sum(r["result_seal_recorded"] for r in rows),
        historical_checkpoints_without_result_seal=sum(not r["result_seal_recorded"] for r in rows),
        code_epochs=len({r["code_epoch"] for r in rows}),
        cells=[dict(corpus=c, task=t, conditions=n,
            question_versions=len({r["case_id"] for r in rows if (r["corpus"],r["task"]) == (c,t)}))
            for (c,t),n in sorted(cells.items())],
        all_conditions_retained=True, latest_condition_auto_selected=False,
        historical_case_independence_certified=False, accuracy_denominator=False,
        source_aware_development=True, blind_evaluation=False)


def markdown(value):
    lines = ["# Narrative Development Condition Ledger", "",
        "Source-aware development and wording variants; not a blind accuracy denominator.",
        "Every row records the inspected native bytes and their hash. No latest run is silently selected.",
        "Missing historical result seals or settings are reported, never retroactively supplied.", "",
        f"{value['question_versions']} question versions; {value['condition_count']} conditions; "
        f"{value['code_epochs']} code epochs. "
        f"{value['historical_checkpoints_without_result_seal']} historical checkpoints lack a result seal.", "",
        "| Corpus | Task | Question | Local result | Details | Native |",
        "| --- | --- | --- | --- | --- | --- |"]
    clean = lambda text: " ".join(str(text).split()).replace("|", "\\|")
    for row in value["conditions"]:
        if row["task"] == "redaction":
            detail = "; ".join(f"{r['reading_id']}: " + ", ".join(
                f"{c['rank']}. {c['fill']} [{c['support']}]" for c in r["candidates"])
                for r in row["readings"]) or "No candidate fills"
        else:
            detail = "; ".join(f"{a['id']} {a['status']} "
                f"(+{a['supporting_quotes']}/-{a['opposing_quotes']}/partial {a['partial_quotes']})"
                for a in row["atoms"])
        ref = row["native_ref"]
        lines.append("| " + " | ".join(map(clean, (row["corpus"],row["task"],row["query"],
            row["status"],detail,ref["path"]))) + " |")
    return "\n".join(lines) + "\n"
