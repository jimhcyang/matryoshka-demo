"""Declared focal/background retrieval controls, never answer-conditioned seeds."""
from collections import defaultdict
from types import SimpleNamespace
import math

import numpy as np

from matryoshka_demo.corpus import ordered
from matryoshka_demo.corpus_policy_v5 import policy_view
from matryoshka_demo.graph_kernel import normalize_prior, transition
from matryoshka_demo.hierarchy import HierarchyBundle, build_hierarchy, diffuse
from matryoshka_demo.io import digest
from matryoshka_demo.retrieval import rrf
from matryoshka_demo.retrieval_v2 import node_matches
from matryoshka_demo.retrieval_v5 import searches
from matryoshka_demo.source_view_policy import descriptor, policy_of

VERSION = "focal-background-source-discovery/1"


def weighted_rrf(rankings, weights, constant=60):
    if len(rankings) != len(weights) or constant < 1:
        raise ValueError("Rankings, weights and positive rank constant required")
    scores = defaultdict(float)
    for ranking, weight in zip(rankings, weights):
        if type(weight) not in (int, float) or not math.isfinite(weight) or not 0 <= weight <= 1:
            raise ValueError("Finite fusion weights between zero and one required")
        if not weight:
            continue
        seen = set()
        for rank, item in enumerate(dict.fromkeys(ranking), 1):
            if item in seen:
                continue
            seen.add(item)
            scores[item] += weight / (constant + rank)
    return sorted(scores, key=lambda item: (-scores[item], str(item))), dict(scores)


def grouped_searches(plan, case):
    focal = {a["id"] for a in plan["atoms"] if case.get("focal_marker") and (
        case["focal_marker"] in a["text"] or any(case["focal_marker"] in s.get("text", "")
            for s in a.get("query_spans", [])))}
    rows = []
    for original in searches(plan, case):
        row = dict(original)
        identities = set(row.get("atom_ids", []))
        for other in row.get("also_serves", []):
            identities.update(other.get("atom_ids", []))
        row["kind"] = "focal" if identities & focal else "background"
        row["focal_atom_ids"] = sorted(identities & focal)
        rows.append(row)
    return rows


def retrieve(corpus, case, plan, *, document_budget=40, passage_budget=80,
             focal_share=.5, graph_share=.5, alpha=.85, hierarchy=True):
    for value in (focal_share, graph_share):
        if type(value) not in (float, int) or not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError("Focal and graph shares must be between zero and one")
    if type(alpha) not in (int, float) or not math.isfinite(alpha) or not 0 < alpha < 1:
        raise ValueError("Restart travel alpha must be strictly between zero and one")
    corpus = policy_view(corpus)
    eligible = corpus.eligible(case)
    rows = grouped_searches(plan, case)
    orders, priors, executed = defaultdict(list), defaultdict(list), []
    group_weights = {"focal": float(focal_share), "background": 1-float(focal_share)}
    if not any(row["kind"] == "focal" for row in rows):
        group_weights = {"background": 1.}
    if not any(row["kind"] == "background" for row in rows):
        group_weights = {"focal": 1.}
    for row in rows:
        page_scores = corpus.page_bm25.score(row["query"], eligible.page_mask, eligible.page_stats)
        ranking = ordered(page_scores, corpus.page_ids)
        orders[row["kind"]].append(ranking)
        node_scores, seeds = node_matches(eligible, row["query"]) if graph_share else (np.zeros(len(corpus.nodes)), [])
        prior = normalize_prior(node_scores, eligible.active)
        if prior.any():
            priors[row["kind"]].append((row, prior))
        executed.append(dict(row, pages_scored=int(eligible.page_mask.sum()), positive_pages=len(ranking),
            family_weight=group_weights.get(row["kind"], 0),
            top_pages=[dict(page_id=corpus.page_ids[i], document_id=corpus.pages[i]["document_id"],
                bm25=float(page_scores[i])) for i in ranking[:5]], top_nodes=seeds,
            positive_seed_nodes=int(np.count_nonzero(node_scores))))
    families = sorted(orders)
    lexical, lexical_scores = weighted_rrf([rrf(orders[f])[0] for f in families],
        [group_weights.get(f, 0) for f in families])
    prior = np.zeros(len(corpus.nodes))
    starters = []
    for family, values in priors.items():
        weight = group_weights.get(family, 0)
        for row, values in values:
            contribution = values * weight / len(priors[family])
            prior += contribution
            if contribution.any():
                starters.append(dict(id=row["id"], label=row["query"], kind=family, values=contribution))
    prior_sum = float(prior.sum())
    prior = normalize_prior(prior, eligible.active)
    if prior_sum:
        for row in starters:
            row["values"] /= prior_sum
    bundle = None
    if graph_share and prior.any():
        if hierarchy:
            bundle = build_hierarchy(eligible, prior)
        else:
            kernel = transition(eligible.adjacency, prior, active=eligible.active)
            edges = {(u, int(v)): dict(kind="SOURCE" if u != v else "NUMERICAL_SELF_LOOP", transition=float(w), weight=float(w))
                for u in range(len(corpus.nodes)) for v, w in zip(kernel.indices[kernel.indptr[u]:kernel.indptr[u+1]],
                    kernel.data[kernel.indptr[u]:kernel.indptr[u+1]])}
            bundle = HierarchyBundle(kernel, prior, len(prior), list(corpus.node_ids), ["semantic"]*len(prior), edges,
                dict(version="eligible-flat-focal/1", groups=[], retrospective_hierarchy=False))
    walk = diffuse(bundle, alpha=float(alpha)) if bundle else SimpleNamespace(node_mass=np.zeros(len(corpus.nodes)),
        full_mass=None, trace=dict(status="LEXICAL_ONLY", snapshots=[], metadata={}, iterations=0))
    degree, mass = np.zeros(len(corpus.nodes)), np.zeros(len(corpus.pages))
    for ui, ni in corpus.membership:
        if eligible.unit_mask[ui]:
            degree[ni] += 1
    for ui, ni in corpus.membership:
        if eligible.unit_mask[ui] and degree[ni]:
            mass[corpus.units[ui]["pi"]] += walk.node_mass[ni] / degree[ni]
    graph_order = ordered(mass, corpus.page_ids)
    combined, scores = weighted_rrf([lexical, graph_order], [1-float(graph_share), float(graph_share)])
    documents = list(dict.fromkeys(corpus.pages[i]["document_id"] for i in combined))[:document_budget]
    admitted = set(documents)
    pages = [i for i in combined if corpus.pages[i]["document_id"] in admitted]
    known = set(pages)
    pages.extend(i for i, p in enumerate(corpus.pages) if eligible.page_mask[i] and p["document_id"] in admitted and i not in known)
    page_ranks = {p: i for i, p in enumerate(combined, 1)}
    node_ranks = {n: i for i, n in enumerate(ordered(walk.node_mass, corpus.node_ids), 1)}
    seeded, seen = [], set()
    for pi in lexical:
        page = corpus.pages[pi]
        if page["document_id"] in seen:
            continue
        seen.add(page["document_id"])
        units = [ui for ui, unit in enumerate(corpus.units) if unit["pi"] == pi and eligible.unit_mask[ui]]
        if units:
            seeded.append(dict(document_id=page["document_id"], page_id=page["id"], date=page["date"],
                citation=eligible.citation(units[0]), lexical_rrf=lexical_scores[pi], lexical_rank=len(seeded)+1,
                matched_searches=[], meaning="Lexical discovery, not a support verdict"))
        if len(seen) >= 20:
            break
    receipt = dict(method=VERSION, text_matcher="BM25", search_queries=executed,
        eligible_pages=int(eligible.page_mask.sum()), eligible_documents=len(set(corpus.page_docs[eligible.page_mask])),
        eligible_nodes=int(eligible.active.sum()), document_budget=document_budget, construction_passage_budget=passage_budget,
        documents_admitted=len(admitted), pages_admitted=len(pages), document_order=documents,
        top_sources=[dict(page_id=corpus.pages[pi]["id"], document_id=corpus.pages[pi]["document_id"],
            date=corpus.pages[pi]["date"], page_rank=page_ranks.get(pi), rrf=scores.get(pi, 0)) for pi in pages[:passage_budget]],
        seeded_documents=seeded, diffusion=walk.trace, hierarchy_active=bool(bundle and hierarchy),
        query_only=True, generated_leads=False, whole_query_search_executed=False,
        focal_share=float(focal_share), graph_share=float(graph_share), alpha=float(alpha),
        query_fusion="Within-group RRF, weighted focal/background ranks, weighted lexical/graph ranks; k=60",
        node_seed_policy="Normalized per-query mass, then normalized declared focal/background shares",
        edge_strength="Distinct eligible source documents per undirected endpoint pair; not truth confidence",
        source_page_policy="Eligible unit membership readout, not document-state transitions",
        cutoff=case["date"], source_view_policy=descriptor(policy_of(corpus)),
        whole_origin_excluded=(case["document_id"] if case["corpus"] != "cib"
            or policy_of(corpus).value == "strict_prior" else None),
        source_policy_version="strict-cable-internal-handling-veto/5", handling_veto_documents=corpus.excluded_documents,
        score_interpretation="Declared retrieval utility, not factual confidence", api_calls=0)
    return dict(eligible=eligible, pages=pages, page_ranks=page_ranks, node_ranks=node_ranks,
        page_scores=scores, node_mass=walk.node_mass, receipt=receipt,
        hierarchy_bundle=bundle, kernel=bundle.kernel if bundle else None,
        prior=bundle.prior if bundle else prior, _full_mass=walk.full_mass, _starter_priors=starters)
