"""Guarded local appraisal, retaining the strict baseline as a separate control."""
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_demo_v6.planning import sentences
from matryoshka_next import decisions as strict
from matryoshka_next.facts import fact_index, public_plan
from .assertion_matching import MatcherCase
from . import source_sentences

VERSION = "narrative-local-source-decisions/12"


def _replay_retained_proof(ref, policy):
    fields = ("canonical_page_id", "document_id", "date", "start", "end", "text", "page_sha256")
    if not isinstance(ref, dict) or any(key not in ref for key in fields):
        raise ValueError("Retained certificate is missing source provenance")
    pi = policy.corpus.page_index.get(ref["canonical_page_id"])
    if pi is None:
        raise ValueError("Retained certificate belongs to an unknown source page")
    checked = policy.citation(pi, ref["start"], ref["end"])
    if (any(ref[key] != checked[key] for key in fields)
            or any(key in ref and ref[key] != checked.get(key) for key in ("corpus", "earlier_page"))):
        raise ValueError("Retained certificate differs from the bound source metadata or span")
    return checked


def _replay_retained_certificate(value, policy):
    if isinstance(value, dict):
        if "canonical_page_id" in value and "start" in value and "text" in value:
            _replay_retained_proof(value, policy)
        for item in value.values():
            _replay_retained_certificate(item, policy)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _replay_retained_certificate(item, policy)


def _historical_role_certificates(case, plan, retrieval, source_index, policy):
    """Re-execute exact H-owned historical role certificates, not old verdicts."""
    if case["task"] != "hypothesis":
        return {}, None
    from matryoshka_current import planning as classic, hypothesis_claims
    from matryoshka_current import reconstruction as certificates
    atoms, text = [], ""
    for atom in plan["atoms"]:
        if not atom.get("required") or atom.get("kind") != "proposition":
            continue
        if text:
            text += " "
        start = len(text)
        text += atom["text"]
        atoms.append(dict(id=atom["id"], text=atom["text"], source_quote=atom["text"],
            start=start, end=len(text), required=True))
    if not atoms:
        return {}, None
    projected_case = dict(case, query=text)
    projected_plan = classic.literal_plan(projected_case, atoms)
    index, admitted, _, _ = certificates._sources(projected_case, retrieval, source_index)
    bindings = hypothesis_claims.role_claim_bindings(projected_case, projected_plan, admitted, index)
    output = {}
    for binding in bindings:
        if binding["direction"] != "SUPPORT" or any(c["state"] != "pass" for c in binding["checks"]):
            continue
        for certificate in binding["certificates"]:
            ref = certificate["citation"]
            _replay_retained_certificate(certificate, policy)
            checked = _replay_retained_proof(ref, policy)
            output.setdefault(binding["atom_id"], []).append(dict(direction="SUPPORT",
                citation=checked, certificate=deepcopy(certificate), checks=deepcopy(binding["checks"]),
                claim_binding_id=binding["id"], source_assertion_not_world_truth=True,
                qualified=True, qualified_account=binding["qualified_assertion"],
                support_scope="HISTORICAL_SOURCE_ROLE_ASCRIPTION", event_bindings=[],
                actual_inner_event_established=False, canonical_identity_certified=False,
                source_frame_guard_version=VERSION,
                query_projection=dict(kind="VALIDATED_QUERY_ATOMS_TO_LITERAL_ENGINE_VIEW",
                    original_query_sha256=digest(case["query"]), projection_query_sha256=digest(text),
                    same_source_pool=True, no_answer_or_new_fact_supplied=True)))
    return output, dict(version=hypothesis_claims.VERSION, bindings=deepcopy(bindings),
        source_groups_used=False, old_native_results_or_grades_read=False,
        scope="BARE_POSITIVE_PAST_ROLES_ONLY_NOT_CONTINUING_TENURE_OR_ACTION")


def _assembly_certificates(case, plan, retrieval, source_index, policy):
    """Retain 8941's checked source ascriptions without adopting a legacy rank."""
    if case["task"] != "reconstruction":
        return {}, None
    from matryoshka_current import planning as classic, reconstruction
    atoms, text = [], ""
    for atom in plan["atoms"]:
        if not atom.get("required") or atom.get("kind") != "proposition":
            continue
        if text:
            text += " "
        start = len(text)
        text += atom["text"]
        atoms.append(dict(id=atom["id"], text=atom["text"], source_quote=atom["text"],
            start=start, end=len(text), required=True))
    if not atoms:
        return {}, None
    projected_case = dict(case, query=text)
    projected_plan = classic.literal_plan(projected_case, atoms)
    assembled = reconstruction.assemble(projected_case, projected_plan, retrieval, source_index)
    output = {}
    for atom in assembled["atoms"]:
        rows = []
        from matryoshka_next.readings import _model
        doc = _model()(atom["text"])
        bare_matrix_negation = any(t.dep_ == "ROOT" and any(c.dep_ == "neg" for c in t.children)
            for t in doc)
        for evidence in atom["positive_evidence"]:
            certificate = evidence.get("certificate")
            if (not certificate or not evidence.get("source_assertion_not_world_truth") or
                    not all(c["state"] == "pass" for c in evidence.get("checks", []))):
                continue
            expected_atom = next(a for a in atoms if a["id"] == atom["id"])
            identification_only = (certificate.get("kind") == "RAW_SOURCE_ROLE_IDENTIFICATION"
                and certificate.get("query_atom") == expected_atom
                and certificate.get("query_sha256") == digest(text)
                and certificate.get("source_identification_only") is True
                and all(certificate.get(key) is False for key in
                    ("source_role_truth_certified", "continuous_tenure_established",
                     "appointment_established", "other_event_established")))
            if re.search(r"\b(?:is|are|currently|now)\b", atom["text"], re.I) and not identification_only:
                continue
            if bare_matrix_negation:
                # The compatibility channel cannot supply a missing event clock.
                # A scoped negative needs the guarded matcher's own certificate.
                continue
            _replay_retained_certificate(certificate, policy)
            checked_refs = [_replay_retained_proof(ref, policy)
                for ref in evidence.get("citations", [])]
            for checked in checked_refs:
                # Every row retains the complete joint proof, not just its display anchor.
                rows.append(dict(evidence, citation=checked, citations=deepcopy(checked_refs), qualified=True,
                    qualified_account=("The eligible source explicitly identifies the named subject with this role. Its truth at the question date, appointment and continuous tenure are not established."
                        if identification_only else "The eligible source attests this complete historical account; no continuing tenure or independent embedded event is certified."),
                    support_scope="SOURCE_IDENTIFICATION_ONLY" if identification_only else evidence.get("support_scope", "SOURCE_ASCRIPTION_NOT_WORLD_TRUTH"),
                    source_frame_guard_version=VERSION, event_bindings=[],
                    query_projection=dict(kind="VALIDATED_QUERY_ATOMS_TO_LITERAL_ENGINE_VIEW",
                        original_query_sha256=digest(case["query"]), projection_query_sha256=digest(text),
                        same_source_pool=True, no_answer_or_new_fact_supplied=True)))
        output[atom["id"]] = rows
    return output, dict(version=assembled["version"], original_query_sha256=digest(case["query"]),
        normalized_query_sha256=digest(text), atoms=[dict(id=a["id"], status=a["status"])
            for a in assembled["atoms"]], raw_control_output_sha256=digest(assembled))


def execute(case, plan, retrieval, *, source_index, passage_budget=80):
    public_plan(case, plan)
    baseline = strict.execute(case, plan, retrieval, source_index=source_index,
        passage_budget=passage_budget)
    result = deepcopy(baseline)
    corpus, policy = retrieval["eligible"].corpus, retrieval["source_policy"]
    index = fact_index(corpus)
    engine = index.linguistic_engine()
    matcher = MatcherCase(case, source_index, engine=engine, corpus=corpus, source_policy=policy)
    inspected = baseline["inspected_page_ids"]
    bounded = dict(retrieval, passage_budget=passage_budget,
        inspected_page_ids=inspected, source_pages_inspected=len(inspected))
    certificates, certificate_audit = _assembly_certificates(case, plan, bounded, source_index, policy)
    historical_roles, historical_role_audit = _historical_role_certificates(
        case, plan, bounded, source_index, policy)
    for atom_id, rows in historical_roles.items():
        certificates.setdefault(atom_id, []).extend(rows)
    positions = [corpus.page_index[pid] for pid in baseline["inspected_page_ids"]]
    diagnostics, potential_counters, boundary_proofs = [], [], {}
    source_units = {}
    for pi in positions:
        page = corpus.pages[pi]
        units = list(sentences(page["text"]))
        augmented = list(units)
        for unit in units:
            recovered = source_sentences.recover(page, unit, matcher.baseline.engine.parse)
            for part in recovered:
                proof = deepcopy(part["source_boundary"])
                parent = proof["parent"]
                proof["parent_policy_citation"] = policy.citation(pi, parent["start"], parent["end"])
                boundary_proofs[digest(proof)] = proof
                augmented.append(dict(part, source_boundary=proof))
        source_units[pi] = augmented
    for atom, original in zip(result["atoms"], plan["atoms"]):
        if original.get("kind") == "context":
            continue
        inspected = {}
        # A lexical screen only schedules local parsing. It cannot create a
        # positive or negative assertion decision.
        terms = set(re.findall(r"[a-z0-9]+", (original.get("subject") or original["text"]).casefold()))
        terms -= {"the", "a", "an", "of", "and", "is", "was", "were"}
        for pi in positions:
            page = corpus.pages[pi]
            for unit in source_units[pi]:
                if terms and not terms.intersection(re.findall(r"[a-z0-9]+", unit["text"].casefold())):
                    continue
                try:
                    row = matcher.supplement(original, page, unit)
                except ValueError as error:
                    if "Opaque" in str(error):
                        continue
                    raise
                if unit.get("source_boundary"):
                    row["source_boundary_certificate"] = deepcopy(unit["source_boundary"])
                if row["direction"] in {"SUPPORT", "COUNTER", "CONFLICTED", "PARTIAL"}:
                    inspected[digest([row["citation"], row["direction"]])] = row
                elif row.get("comparisons") and len(diagnostics) < 100:
                    diagnostics.append(dict(atom_id=atom["id"], citation=row["citation"],
                        query_issues=row["query_issues"], comparisons=row["comparisons"]))
        # Strict raw/role certificates remain visible as control evidence. Do
        # not bypass the new referent/scope gates solely because that old
        # engine happened to label an identical generic-title sentence true.
        compatible = []
        for certificate in certificates.get(atom["id"], []):
            ref = certificate["citation"]
            page = corpus.pages[corpus.page_index[ref["canonical_page_id"]]]
            audited = matcher.supplement(original,page,dict(start=ref["start"],end=ref["end"],text=ref["text"]))
            # Root/content claims have one audited channel. A legacy assembly
            # certificate cannot restore a withheld qualifier or inner event.
            if (not audited.get("root_content_policy_applicable")
                    and not audited.get("source_account_policy_withheld")
                    and not audited.get("potential_counter")):
                compatible.append(certificate)
        rows = list(inspected.values()) + compatible
        rows = list({digest([r["citation"], r["direction"], r.get("certificate")]):r for r in rows}.values())
        potential_counters.extend(dict(atom_id=atom["id"], evidence=deepcopy(row)) for row in rows
            if row.get("potential_counter") is True and row.get("counter_scope") == "UNMODELED")
        positive = [r for r in rows if r["direction"] in {"SUPPORT", "CONFLICTED"}]
        negative = [r for r in rows if r["direction"] in {"COUNTER", "CONFLICTED"}]
        partial = [r for r in rows if r["direction"] == "PARTIAL"]
        state = "CONFLICTED" if positive and negative else "SUPPORTED" if positive else "OPPOSED" if negative else "FEASIBLE" if partial else "NO_INFO"
        status = {"SUPPORTED": "SUPPORT" if case["task"] == "hypothesis" else "ESTABLISHED",
            "OPPOSED": "OPPOSED", "CONFLICTED": "CONFLICTED", "FEASIBLE": "PARTIAL",
            "NO_INFO": "UNRESOLVED" if case["task"] == "hypothesis" else "INSUFFICIENT"}[state]
        atom.update(status=status, criterion_state=state, evidence=rows, positive_evidence=positive,
            counterevidence=negative, partial_evidence=partial,
            qualified_accounts=[dict(text=r["qualified_account"], citations=[r["citation"]],
                scope=r.get("support_scope", "SOURCE_ASCRIPTION_NOT_WORLD_TRUTH"),
                actual_inner_event_established=False) for r in rows if r.get("qualified_account")],
            complete_role_or_raw_clause_certificate=bool(positive) and not negative,
            strict_baseline_status=atom["status"], source_frame_guard_version=VERSION)
        atom["requirements"] = [dict(id=atom["id"] + ".criterion", text=atom["text"],
            kind=atom["kind"], status=status, criterion_state=state,
            coverage=dict(complete=bool(positive) and not negative, issues=[] if positive else
                ["NO_COMPLETE_SOURCE_FRAME_WITNESS"], source_actor_predicate_object_verified=bool(positive)),
            evidence=rows, opposition_is_not_missing=bool(negative))]
    scope = strict._scope(case, plan, result["atoms"], corpus, engine)
    scope_control = deepcopy(scope)
    if potential_counters:
        # A complete positive account stays observed. An unbound material
        # opponent is neither erased nor relabelled as signed opposition.
        scope = deepcopy(scope)
        scope.update(complete=False, counter_scope_complete=False,
            material_counter_policy="narrative-unresolved-material-counter-hold/1")
        scope.setdefault("checks", []).append(dict(kind="potential_material_counter",
            state="UNRESOLVED", atom_ids=sorted({r["atom_id"] for r in potential_counters}),
            reason="UNMODELED_MATERIAL_COUNTER_SCOPE_WITHHOLDS_WHOLE_QUERY_SUFFICIENCY",
            potential_counter_count=len(potential_counters), signed_opposition_invented=False))
    result.update(version=VERSION, atoms=result["atoms"], query_requirements=scope,
        overall=strict._summary(result["atoms"], case["task"], scope["complete"]))
    result["status"] = result["overall"]["status"]
    result["strict_baseline"] = dict(version=baseline["version"], status=baseline["status"],
        atoms=[dict(id=a["id"], status=a["status"], evidence=deepcopy(a["evidence"])) for a in baseline["atoms"]])
    result["frame_diagnostics"] = diagnostics
    result["source_boundary_policy"] = dict(version=source_sentences.VERSION,
        query_or_answer_used=False, complete_parent_quotes_retained=True,
        recoveries=list(boundary_proofs.values()), source_text_modified=False,
        event_dates_moved=False, independent_support_still_requires_matcher=True)
    result["potential_material_counterevidence"] = potential_counters
    result["binding_scope_control_before_counter_hold"] = scope_control
    result["counter_scope_disposition"] = dict(version="narrative-unresolved-material-counter-hold/1",
        status="INCOMPLETE" if potential_counters else "NO_MATCHED_UNMODELED_COUNTER_IN_INSPECTED_POOL",
        potential_counters=len(potential_counters), positive_judgments_and_counts_preserved=True,
        signed_opposition_invented=False, exhaustive_semantic_counter_clearance_claimed=False)
    result["retained_8941_certificate_audit"] = certificate_audit
    result["retained_hypothesis_role_certificate_audit"] = historical_role_audit
    result["source_cited_account"] = [dict(atom_id=a["id"], text=a["text"], status=a["status"],
        citations=[r["citation"] for r in a["positive_evidence"]],
        embedded_events_in_qualified_reports_not_independently_established=True)
        for a in result["atoms"] if a["positive_evidence"]]
    result["gaps"] = [dict(atom_id=a["id"], text=a["text"], status=a["status"])
        for a in result["atoms"] if not a["positive_evidence"]]
    result["candidate_casefile"] = dict(version=VERSION, criteria=deepcopy(result["atoms"]),
        scope=scope, binding=dict(query_sha256=digest(case["query"]), plan_sha256=digest(plan)))
    return result
