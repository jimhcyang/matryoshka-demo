"""Retain 8941's source retrieval; compare directed expansion explicitly."""
import numpy as np

from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy, fact_index, public_plan
from matryoshka_demo.source_view_policy import descriptor, policy_of

VERSION = "narrative-source-discovery/3"
WITNESS_VERSION = "narrative-source-discovery/4"
from matryoshka_next.retrieval import METHODS as DIRECTED_METHODS
METHOD_CHOICES = ("current_hierarchy", "current_hierarchy_witnesses", "current_hierarchy_numeric_ranges", *sorted(DIRECTED_METHODS))


def retrieve(corpus, case, plan, *, source_index, method="current_hierarchy", passage_budget=80,
             document_budget=40, discovery_profile=None, source_index_ref=None):
    public_plan(case, plan)
    if plan.get("leads"):
        raise ValueError("This phase uses atoms and visible query context, not generated leads")
    if method not in {"current_hierarchy", "current_hierarchy_witnesses", "current_hierarchy_numeric_ranges"}:
        from matryoshka_next.retrieval import retrieve as directed
        return directed(corpus, case, plan, source_index=source_index, method=method,
            passage_budget=passage_budget, document_budget=document_budget)
    if method == "current_hierarchy_witnesses":
        from .source_witnesses import configuration
        configuration(passage_budget=passage_budget, document_budget=document_budget,
            source_view_policy=descriptor(policy_of(corpus)))
        if case["corpus"] not in {"iran", "vietnam"} or case["task"] not in {"reconstruction", "hypothesis"} or source_index_ref is None:
            raise ValueError("Source-owned witnesses require cable M/H and a trusted execution index reference")
    if method == "current_hierarchy_numeric_ranges":
        from .numeric_source_opportunities import configuration
        configuration(passage_budget=passage_budget,document_budget=document_budget,
            source_view_policy=descriptor(policy_of(corpus)))
        if case["task"] != "redaction" or case["corpus"] not in {"iran", "vietnam"} or source_index_ref is None:
            raise ValueError("Numeric range opportunities require cable Redaction and a trusted source index")
    from matryoshka_demo.retrieval_v5 import retrieve as established
    if discovery_profile is None:
        value = established(corpus, case, plan, passage_budget=passage_budget,
            document_budget=document_budget, hierarchy=True, graph=True)
    else:
        from .focal_retrieval import retrieve as focal
        if set(discovery_profile) - {"focal_share", "graph_share", "alpha", "hierarchy"}:
            raise ValueError("Unknown discovery profile field")
        value = focal(corpus, case, plan, passage_budget=passage_budget,
            document_budget=document_budget, **discovery_profile)
    selected = value["eligible"].corpus
    # NumPy ranking indices cross into a stricter JSON-compatible constructor.
    # Normalize their representation, not their order or membership.
    if any(isinstance(i, (bool, np.bool_)) or not isinstance(i, (int, np.integer))
           for i in value["pages"]):
        raise ValueError("Retrieval returned a non-integral page index")
    pages = [int(i) for i in value["pages"]]
    if len(pages) != len(set(pages)) or any(not 0 <= i < len(selected.pages) for i in pages):
        raise ValueError("Retrieval returned duplicate or out-of-range page indices")
    value["pages"] = pages
    policy = SourcePolicy(selected, case, source_index)
    if np.any(np.asarray(value["eligible"].page_mask, dtype=bool) & ~policy.mask()):
        raise ValueError("The established kernel admitted a source vetoed by the complete index")
    value.update(source_policy=policy, source_index=source_index,
        passage_budget=passage_budget, fact_index=fact_index(selected))
    if case["task"] in {"hypothesis", "reconstruction"}:
        from .inspection import schedule
        value["pages"], inspection = schedule(selected, plan, value, budget=passage_budget)
        value["receipt"]["fact_document_inspection"] = inspection
    value["receipt"].update(narrative_discovery_version=VERSION, query_sha256=digest(case["query"]),
        source_view_policy=descriptor(policy_of(selected)),
        whole_origin_excluded=(case["document_id"] if case["corpus"] != "cib"
            or policy_of(selected).value == "strict_prior" else None),
        source_scope="ORIGINAL_8941_BM25_QUERY_CONDITIONED_HIERARCHY_KERNEL",
        source_edges=[], navigation_edges=[],
        stepwise_display_is_selected_evidence_inspection=True,
        original_kernel_is_not_relabelled_as_a_directed_tree=True,
        old_saved_ranks_or_sources_reused=False)
    if method == "current_hierarchy_witnesses":
        from .source_witnesses import apply_source_owned_opportunities
        value = apply_source_owned_opportunities(selected, case, plan, value,
            source_index_ref=source_index_ref, passage_budget=passage_budget, document_budget=document_budget)
        value["receipt"]["narrative_discovery_version"] = WITNESS_VERSION
    if method == "current_hierarchy_numeric_ranges":
        from .numeric_source_opportunities import discover
        value = discover(selected,case,plan,value,source_index_ref=source_index_ref,
            passage_budget=passage_budget,document_budget=document_budget)
    return value
