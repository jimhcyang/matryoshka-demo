"""Bounded literal-controller feasibility, never factual support or a new reading.

Callers may exclude only ``result.excludes_insertion``. HOLD is non-excluding.
No production hook, parser mutation, extraction, model call, or ranking occurs.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, field
import hashlib
from typing import Any, Callable, Literal, Mapping, Sequence

from matryoshka_demo.io import digest

VERSION = 'query-frame-literal-controller-compatibility/2'
SHORTLIST_POLICY_VERSION = 'controller-compatibility-shortlist/1'
OPAQUE_NOMINAL = 'SLOTCONTROLLERNOUN'
State = Literal['compatible', 'reject', 'hold', 'not_applicable']
ACTOR_KINDS = frozenset({'person', 'organization'})
PROTECTED_LEXNAMES = frozenset({
    'noun.artifact', 'noun.communication', 'noun.group', 'noun.location',
    'noun.animal', 'noun.plant',
})


@dataclass(frozen=True)
class SourceKindWitness:
    source_entity_type: str
    label: str
    start: int
    end: int
    canonical_page_id: str
    document_id: str
    page_sha256: str


@dataclass(frozen=True)
class SourceInsertion:
    fill: str
    text: str
    start: int
    end: int
    canonical_page_id: str
    document_id: str
    source_sha256: str
    hash_encoding: Literal['json-string', 'utf8'] = 'json-string'
    kind_witnesses: tuple[SourceKindWitness, ...] = ()
    metonymy_unresolved: bool = False


@dataclass(frozen=True)
class QueryControllerFrame:
    state: Literal['actor_control_hypothesis', 'hold', 'not_applicable']
    reason: str
    query_sha256: str
    reading_sha256: str
    details: Mapping[str, Any] = field(default_factory=dict)
    query_only: bool = True
    source_access: bool = False
    candidate_access: bool = False
    reading_modified: bool = False


@dataclass(frozen=True)
class ControllerRoleResult:
    state: State
    reason: str
    query_frame: QueryControllerFrame
    heads: tuple[Mapping[str, Any], ...] = ()
    details: Mapping[str, Any] = field(default_factory=dict)
    version: str = VERSION
    reading_modified: bool = False
    factual_support_certified: bool = False
    identity_certified: bool = False
    source_eligibility_certified: bool = False
    support_promotion_permitted: bool = False
    rank_changed: bool = False
    model_calls: int = 0

    @property
    def excludes_insertion(self) -> bool:
        return self.state == 'reject'

    def as_dict(self) -> dict[str, Any]:
        return dict(asdict(self), excludes_insertion=self.excludes_insertion)


def _verb_frames(wordnet: Any, lemma: str) -> list[dict[str, Any]]:
    rows = []
    for sense in wordnet.synsets(lemma, pos='v'):
        if sense.instance_hypernyms():
            continue
        for entry in sense.lemmas():
            if entry.name() != lemma or not entry.name().islower():
                continue
            for number, frame in zip(entry.frame_ids(), entry.frame_strings()):
                rows.append(dict(synset=sense.name(), lexname=sense.lexname(), frame_id=number, frame=frame))
    return rows


def _bound_actor_frame(frame: Any, case: Mapping[str, Any], reading: Mapping[str, Any]) -> bool:
    if (not isinstance(frame, dict) or frame.get('state') != 'actor_control_hypothesis'
            or frame.get('query_sha256') != digest(case['query'])
            or frame.get('reading_sha256') != digest(reading)
            or frame.get('query_only') is not True or frame.get('source_access') is not False
            or frame.get('candidate_access') is not False or frame.get('reading_modified') is not False
            or reading.get('outer_family') != 'nominal' or reading.get('role') != 'patient_argument'
            or reading.get('target_kind') not in {'any', 'person', 'organization'}):
        return False
    details = frame.get('details')
    if not isinstance(details, dict):
        return False
    for name in ('matrix', 'embedded'):
        span = details.get(name)
        if not isinstance(span, dict):
            return False
        a, b = span.get('start'), span.get('end')
        if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(case['query'])
                or case['query'][a:b] != span.get('text') or not span.get('lemma')):
            return False
    control = details.get('control_frames')
    embedded = details.get('embedded_frames')
    return (isinstance(control, list) and bool(control) and all(isinstance(row, dict)
        and type(row.get('frame_id')) is int and row['frame_id'] == 24 for row in control)
        and isinstance(embedded, list) and any(isinstance(row, dict)
            and row.get('lexname') in {'verb.communication', 'verb.cognition'}
            and isinstance(row.get('frame'), str) and row['frame'].startswith('Somebody ') for row in embedded))


def shortlist_eligibility(case: Mapping[str, Any], reading: Mapping[str, Any], controller: Any) -> dict[str, Any]:
    """Separate reviewed display abstention; never change helper or fact decisions."""
    value = dict(version=SHORTLIST_POLICY_VERSION, state='eligible', reason='CONTROLLER_POLICY_NOT_APPLICABLE',
        query_sha256=digest(case['query']), reading_sha256=digest(reading),
        controller_receipt_sha256=digest(controller), factual_rejection=False, factual_counterevidence=False,
        local_decision_modified=False, raw_candidate_retained=True)
    if (not isinstance(controller, dict) or controller.get('state') != 'hold'
            or controller.get('excludes_insertion') is not False
            or controller.get('factual_support_certified') is not False
            or controller.get('support_promotion_permitted') is not False
            or controller.get('reading_modified') is not False
            or not _bound_actor_frame(controller.get('query_frame'), case, reading)):
        return value
    return dict(value, state='withheld_unresolved', reason='VALID_CONTROLLER_ROLE_COMPATIBILITY_UNRESOLVED',
        query_frame_sha256=digest(controller['query_frame']), withholding_is_not_proof_of_incompatibility=True)


def withheld_from_shortlist(candidate: Mapping[str, Any], *, query_sha256: str | None = None) -> bool:
    """Shared constructor/terminal selector. Never reinterpret older unmarked pools."""
    saved = candidate.get('controller_shortlist_eligibility', {})
    if saved.get('state') != 'withheld_unresolved':
        return False
    controller = candidate.get('controller_role_fit', {})
    frame = controller.get('query_frame', {})
    if (saved.get('version') != SHORTLIST_POLICY_VERSION
            or saved.get('query_sha256') != frame.get('query_sha256')
            or query_sha256 is not None and saved.get('query_sha256') != query_sha256
            or saved.get('reading_sha256') != digest(candidate.get('declared_reading'))
            or saved.get('controller_receipt_sha256') != digest(controller)
            or saved.get('query_frame_sha256') != digest(frame)
            or controller.get('state') != 'hold' or controller.get('excludes_insertion') is not False
            or frame.get('state') != 'actor_control_hypothesis'):
        raise ValueError('Controller shortlist withholding lost its bound producer receipt')
    return True


def query_controller_frame(
    case: Mapping[str, Any], reading: Mapping[str, Any], *,
    parse: Callable[[str], Any], wordnet: Any,
) -> QueryControllerFrame:
    """Infer only the bounded public attachment hypothesis; no candidate argument."""
    query, marker = case.get('query'), case.get('focal_marker')
    query_hash, reading_hash = digest(query), digest(reading)

    def result(state: str, reason: str, **details: Any) -> QueryControllerFrame:
        return QueryControllerFrame(state, reason, query_hash, reading_hash, details)

    if not isinstance(query, str) or not isinstance(marker, str) or not marker or query.count(marker) != 1 or OPAQUE_NOMINAL in query:
        return result('hold', 'FOCAL_MARKER_NOT_UNIQUE')
    if (reading.get('outer_family', reading.get('form')) != 'nominal'
            or reading.get('role') != 'patient_argument'
            or reading.get('target_kind') not in {'any', 'person', 'organization'}):
        return result('not_applicable', 'DECLARED_READING_NOT_CHANGED')
    try:
        start = query.index(marker)
        doc = parse(query.replace(marker, OPAQUE_NOMINAL))
        slots = [token for token in doc if token.text == OPAQUE_NOMINAL]
        if len(slots) != 1:
            return result('hold', 'OPAQUE_ANALYSIS_TOKEN_NOT_UNIQUE')
        slot, matrix = slots[0], slots[0].head
        if slot.dep_ not in {'obj', 'dobj', 'iobj'} or matrix.pos_ != 'VERB':
            return result('not_applicable', 'GAP_NOT_MATRIX_OBJECT')
        complements = [token for token in matrix.children if token.dep_ == 'xcomp' and token.pos_ == 'VERB'
            and any(child.lower_ == 'to' and child.dep_ == 'aux' for child in token.children)]
        if len(complements) != 1:
            return result('hold', 'UNIQUE_ACTIVE_INFINITIVE_NOT_ESTABLISHED')
        embedded = complements[0]
        if (any(child.dep_ in {'auxpass', 'nsubjpass', 'nsubj', 'csubj', 'expl'} for child in embedded.children)
                or 'Pass' in embedded.morph.get('Voice')):
            return result('not_applicable', 'PASSIVE_OR_OWN_SUBJECT_NOT_ACTOR_CONTROL')
        matrix_frames = _verb_frames(wordnet, matrix.lemma_.casefold())
        control = [row for row in matrix_frames if row['frame_id'] == 24]
        embedded_frames = _verb_frames(wordnet, embedded.lemma_.casefold())
        mental_or_communication = [row for row in embedded_frames
            if row['lexname'] in {'verb.communication', 'verb.cognition'} and row['frame'].startswith('Somebody ')]
        if not control or not mental_or_communication:
            return result('not_applicable', 'NO_LEXICAL_ACTIVE_ACTOR_CONTROL_FRAME')
        negative_ambiguity = []
        if any(row['frame_id'] != 24 for row in matrix_frames):
            negative_ambiguity.append('ALTERNATE_MATRIX_VERB_FRAMES')
        if any(row['lexname'] not in {'verb.communication', 'verb.cognition'}
                or not row['frame'].startswith('Somebody ') for row in embedded_frames):
            negative_ambiguity.append('ALTERNATE_EMBEDDED_VERB_SENSE_OR_SUBJECT_FRAME')

        def visible(token: Any) -> dict[str, Any]:
            offset = token.idx + (len(marker) - len(OPAQUE_NOMINAL) if token.idx > start else 0)
            if query[offset:offset + len(token)] != token.text:
                raise ValueError('Visible query frame does not replay')
            return dict(start=offset, end=offset + len(token), text=token.text, lemma=token.lemma_.casefold())

        return result('actor_control_hypothesis', 'FRAME_24_AND_ACTIVE_MENTAL_OR_COMMUNICATION_COMPLEMENT',
            matrix=visible(matrix), embedded=visible(embedded), control_frames=control,
            matrix_frames=matrix_frames, embedded_frames=embedded_frames, compatible_kinds=sorted(ACTOR_KINDS),
            negative_controller_kind_license=dict(established_within_resource=not negative_ambiguity,
                ambiguity_reasons=negative_ambiguity, actual_word_sense_disambiguation_performed=False,
                lexical_examples_are_not_complete_english_selectional_restrictions=True),
            organization_agency_policy='PROPOSED_PERSON_OR_ORGANIZATION_CONTROLLER_COMPATIBILITY',
            wordnet_version=wordnet.get_version(),
            wordnet_frames_are_complete_selectional_restrictions=False)
    except (LookupError, OSError, ValueError, AttributeError, TypeError) as error:
        return result('hold', 'QUERY_FRAME_OR_LEXICAL_RESOURCE_UNAVAILABLE', error_type=type(error).__name__)


def check_completed_insertion(
    case: Mapping[str, Any], reading: Mapping[str, Any], insertion: SourceInsertion, *,
    parse: Callable[[str], Any], wordnet: Any, noun_resource: Any,
) -> ControllerRoleResult:
    """Check literal source-head compatibility. Only REJECT permits exclusion.

    Caller retains all existing source policy, extraction, literal provenance,
    declared-reading and factual gates. A compatible result cannot upgrade support.
    """
    frame = query_controller_frame(case, reading, parse=parse, wordnet=wordnet)

    def outcome(state: State, reason: str, heads: Sequence[Mapping[str, Any]] = (), **details: Any) -> ControllerRoleResult:
        return ControllerRoleResult(state, reason, frame, tuple(deepcopy(list(heads))), details)

    if frame.state != 'actor_control_hypothesis':
        return outcome('not_applicable' if frame.state == 'not_applicable' else 'hold', frame.reason)
    if (not isinstance(insertion, SourceInsertion) or not isinstance(insertion.text, str)
            or not isinstance(insertion.fill, str) or not isinstance(insertion.hash_encoding, str)
            or not isinstance(insertion.canonical_page_id, str) or not isinstance(insertion.document_id, str)):
        return outcome('hold', 'INVALID_TYPED_SOURCE_INSERTION_RETAINS_CANDIDATE')
    if insertion.metonymy_unresolved:
        return outcome('hold', 'UNRESOLVED_METONYMY_RETAINS_INSERTION')
    if insertion.hash_encoding not in {'json-string', 'utf8'}:
        return outcome('hold', 'UNSUPPORTED_SOURCE_HASH_ENCODING')
    actual = digest(insertion.text) if insertion.hash_encoding == 'json-string' else hashlib.sha256(insertion.text.encode()).hexdigest()
    a, b = insertion.start, insertion.end
    if (not insertion.canonical_page_id or not insertion.document_id or actual != insertion.source_sha256
            or type(a) is not int or type(b) is not int or not 0 <= a < b <= len(insertion.text)
            or not insertion.fill or insertion.text[a:b] != insertion.fill):
        return outcome('hold', 'LITERAL_SOURCE_INSERTION_BINDING_NOT_ESTABLISHED')
    try:
        left, right = case['query'].split(case['focal_marker'])
        completed = parse(left + insertion.fill + right)
        part = completed.char_span(len(left), len(left) + len(insertion.fill), alignment_mode='strict')
        if part is None or part.root.pos_ not in {'NOUN', 'PROPN', 'PRON'}:
            return outcome('hold', 'COMPLETED_NOMINAL_HEAD_NOT_ESTABLISHED')
        if (part.root.dep_ not in {'obj', 'dobj', 'iobj'} or part.root.head in part
                or part.root.head.lemma_.casefold() != frame.details['matrix']['lemma']):
            return outcome('hold', 'COMPLETED_MATRIX_OBJECT_ATTACHMENT_NOT_ESTABLISHED')
        delta = len(insertion.fill) - len(case['focal_marker'])
        marker_end = len(left) + len(case['focal_marker'])
        def completed_visible(span: Mapping[str, Any]) -> Any:
            shift = delta if span['start'] >= marker_end else 0
            found = completed.char_span(span['start'] + shift, span['end'] + shift, alignment_mode='strict')
            return found[0] if found is not None and len(found) == 1 and found.text == span['text'] else None
        matrix_token = completed_visible(frame.details['matrix'])
        embedded_token = completed_visible(frame.details['embedded'])
        if (matrix_token is None or embedded_token is None or part.root.head != matrix_token
                or embedded_token.dep_ != 'xcomp' or embedded_token.head != matrix_token):
            return outcome('hold', 'COMPLETED_EMBEDDED_PREDICATE_OWNERSHIP_NOT_ESTABLISHED')
        source = parse(insertion.text)
        wanted = ACTOR_KINDS if reading['target_kind'] == 'any' else {reading['target_kind']}
        heads = []
        for head in [part.root] + list(part.root.conjuncts):
            if head not in part:
                return outcome('hold', 'COORDINATION_ESCAPES_INSERTION')
            lo, hi = a + head.idx - len(left), a + head.idx - len(left) + len(head)
            source_head = source.char_span(lo, hi, alignment_mode='strict')
            if source_head is None or source_head.text != head.text:
                return outcome('hold', 'SOURCE_COMPLETED_HEAD_ALIGNMENT_NOT_ESTABLISHED')
            row = dict(head=head.text, source_head_span=[lo, hi], completed_dependency=head.dep_,
                completed_governor=head.head.text, source_dependency=source_head.root.dep_)
            kinds = set()
            for witness in insertion.kind_witnesses:
                if (witness.canonical_page_id != insertion.canonical_page_id or witness.document_id != insertion.document_id
                        or witness.page_sha256 != insertion.source_sha256 or type(witness.start) is not int
                        or type(witness.end) is not int or not 0 <= witness.start < witness.end <= len(insertion.text)
                        or insertion.text[witness.start:witness.end] != witness.label):
                    return outcome('hold', 'SOURCE_KIND_WITNESS_BINDING_NOT_ESTABLISHED')
                if witness.start <= lo < hi <= witness.end:
                    kinds.add(witness.source_entity_type)
            row['source_entity_types'] = sorted(kinds)
            if kinds:
                mapped = {'Person': 'person', 'Organization': 'organization'}
                actor_kinds = {mapped[kind] for kind in kinds if kind in mapped}
                if len(kinds) == 1 and actor_kinds and actor_kinds <= wanted:
                    row.update(state='compatible', reason='BOUND_SOURCE_ACTOR_KIND_COMPATIBILITY_ONLY')
                else:
                    row.update(state='hold', reason='CONFLICT_UNKNOWN_OR_COLLECTIVE_SOURCE_KIND_RETAINS_INSERTION')
            elif source_head.root.pos_ != 'NOUN' or source_head.root.ent_type_:
                row.update(state='hold', reason='UNKNOWN_NAME_OR_NONCOMMON_HEAD_NO_DICTIONARY_LOOKUP')
            else:
                lookup = noun_resource.lookup(source_head.root.lemma_.casefold())
                row['noun_lookup'] = deepcopy(lookup)
                senses = lookup.get('senses', [])
                if lookup.get('status') != 'SENSES_AVAILABLE' or not senses:
                    row.update(state='hold', reason='ORDINARY_NOUN_SENSES_UNAVAILABLE')
                elif any(not isinstance(sense.get('possible_kinds'), dict)
                        or any(type(sense['possible_kinds'].get(kind)) is not bool
                            for kind in ('person', 'organization', 'place')) for sense in senses):
                    row.update(state='hold', reason='ORDINARY_NOUN_KIND_INVENTORY_INCOMPLETE')
                else:
                    sense_kinds = [{kind for kind, possible in sense['possible_kinds'].items() if possible} for sense in senses]
                    lexnames = {wordnet.synset(sense['synset']).lexname() for sense in senses}
                    row['ordinary_lexnames'] = sorted(lexnames)
                    all_wanted = all(bool(kinds & wanted) for kinds in sense_kinds)
                    any_actor = any(bool(kinds & ACTOR_KINDS) for kinds in sense_kinds)
                    any_place = any('place' in kinds for kinds in sense_kinds)
                    if all_wanted:
                        row.update(state='compatible', reason='ALL_ORDINARY_SOURCE_HEAD_SENSES_CONTROLLER_COMPATIBLE')
                    elif any_actor or any_place or lexnames & PROTECTED_LEXNAMES:
                        row.update(state='hold', reason='AMBIGUOUS_ACTOR_ARTIFACT_LOCATION_OR_COLLECTIVE_RETAINS_INSERTION')
                    else:
                        license = frame.details.get('negative_controller_kind_license', {})
                        if license.get('established_within_resource') is not True:
                            row.update(state='hold', reason='VERB_SENSE_OR_CAUSATIVE_AMBIGUITY_PREVENTS_NEGATIVE_CERTIFICATE')
                        else:
                            row.update(state='reject', reason='ALL_ORDINARY_SOURCE_HEAD_CLASSES_DISJOINT_FROM_CONTROLLERS')
            heads.append(row)
        state = 'reject' if any(row['state'] == 'reject' for row in heads) else 'hold' if any(row['state'] == 'hold' for row in heads) else 'compatible'
        return outcome(state, 'BOUNDED_LITERAL_CONTROLLER_COMPATIBILITY_ONLY', heads,
            completed_query_sha256=digest(completed.text), source_sha256=insertion.source_sha256,
            source_id=insertion.canonical_page_id, document_id=insertion.document_id,
            noun_resource=deepcopy(getattr(noun_resource, 'resource', {})), proper_name_dictionary_lookup=False,
            existing_source_and_factual_gates_required=True,
            parser_attachment_certifies_full_english_grammar=False)
    except (LookupError, OSError, ValueError, AttributeError, TypeError, KeyError) as error:
        return outcome('hold', 'COMPLETED_CONTROLLER_OR_LEXICAL_RESOURCE_UNAVAILABLE', error_type=type(error).__name__)
