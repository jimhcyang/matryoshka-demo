"""Compare an explicitly attributed view with a modal Hypothesis, not an event.

Only one directly asserted reporting/cognition scope may be projected. Its
speaker, original qualifiers and complete quotation remain in the certificate.
No projection is available for Mosaic or unqualified historical event queries.
"""
from copy import deepcopy

from matryoshka_demo.io import digest
from .matching import scoped, _token, _disjunctive, _named_actor

VERSION = "attributed-modal-hypothesis-stance/1"
_OPERATORS = {"believe", "think", "expect", "predict", "estimate", "say", "argue",
              "contend", "maintain", "judge", "conclude", "assert"}
_MODALS = {"can", "could", "may", "might", "will", "would"}


def supplement(matcher, atom, page, unit, control):
    if (matcher.case["task"] != "hypothesis" or atom.get("kind") != "proposition"
            or control["direction"] not in {"UNRESOLVED", "PARTIAL"}
            or control.get("query_issues") or control.get("uncovered_query_tokens")
            or control.get("potential_counter") or control.get("source_account_policy_withheld")):
        return control
    cached_query = matcher.query_cache.get(digest(atom))
    cached_source = matcher.unit_cache.get((page["id"], page["source_sha256"], unit["start"], unit["end"]))
    if not cached_query or not cached_source:
        return control
    _, targets, query_doc = cached_query
    sources, source_doc = cached_source
    from .source_qualification import raw_envelope_holds
    envelope = raw_envelope_holds(matcher, page, unit, source_doc)
    if envelope:
        row = deepcopy(control)
        row["source_account_policy_withheld"] = True
        row["stance_projection_scope_holds"] = envelope
        return row
    if len(targets) != 1:
        return control
    target = targets[0]
    tq = target["qualifiers"]
    if (not tq.get("modality") or not set(tq["modality"]) <= _MODALS
            or any(tq.get(k) for k in ("scope", "attribution", "conditional", "question", "epistemic_absence", "unresolved"))
            or target.get("unbound_arguments") or not _named_actor(target) or _disjunctive(target, query_doc)):
        return control
    records = []
    for source in sources:
        sq = source["qualifiers"]
        scopes = sq.get("scope", [])
        if (source["predicate"] != target["predicate"] or source["kind"] != target["kind"]
                or len(scopes) != 1 or source.get("unbound_arguments")
                or _disjunctive(source, source_doc)):
            continue
        scope = scopes[0]
        if (scope.get("relation") != "ccomp" or scope.get("predicate") not in _OPERATORS
                or scope.get("negated") or scope.get("modality")
                or not scope.get("speakers") or any(p.get("unresolved") or not p.get("terms")
                    for p in scope["speakers"])):
            continue
        token = _token(source, source_doc)
        if (token is None or token.dep_ != "ccomp"
                or any(t.dep_ == "cc" and t.lower_ in {"or", "nor"} for t in token.subtree)):
            continue
        operator = token.head
        if (operator.dep_ != "ROOT" or operator.lemma_.casefold() != scope["predicate"]
                or operator.tag_ not in {"VBD", "VBP", "VBZ"}
                or any(c.dep_ in {"neg", "aux", "auxpass", "advmod"} for c in operator.children)):
            continue
        projected = deepcopy(source)
        projected["qualifiers"]["scope"] = []
        projected["qualifiers"]["attribution"] = []
        comparison = scoped.compare_frames(target, projected, engine=matcher.engine)
        if comparison is None:
            continue
        # Both the proposition and its opinion must retain exactly the same
        # explicit modal scope. Possibility is not certainty or permission.
        if tq["modality"] != projected["qualifiers"].get("modality"):
            continue
        direction = comparison["direction"]
        opposing_view = (direction == "PARTIAL"
            and comparison["reasons"] == ["OPPOSITION_SCOPE_OR_EVENT_IDENTITY_NOT_ESTABLISHED"]
            and set(tq["modality"]) <= {"can", "could", "will", "would"}
            and comparison["diagnostics"]["polarity"]["status"] == "OPPOSED"
            and all(v["status"] in {"MATCH", "UNSPECIFIED"}
                for k, v in comparison["diagnostics"].items() if k != "polarity"))
        if opposing_view:
            direction = "COUNTER"
        if direction not in {"SUPPORT", "COUNTER"}:
            continue
        records.append(dict(direction=direction, source_frame=deepcopy(source),
            target_frame=deepcopy(target), projected_content_frame=projected,
            comparison=comparison, attribution=deepcopy(scope),
            opposing_view_not_same_event_contradiction=opposing_view,
            operator_proof=scoped.matching.proof(operator)))
    if not records:
        return control
    directions = {r["direction"] for r in records}
    direction = "CONFLICTED" if len(directions) > 1 else next(iter(directions))
    row = deepcopy(control)
    row.update(version=VERSION, direction=direction, complete_required_frames=True,
        hypothesis_stance=dict(version=VERSION, records=records,
            citation=deepcopy(control["citation"]), source_text_modified=False,
            speaker_or_scope_discarded=False, inner_event_execution_certified=False),
        qualified=True, source_assertion_not_world_truth=True,
        support_scope="ATTRIBUTED_VIEW_ON_MODAL_HYPOTHESIS_NOT_EVENT_EXECUTION",
        qualified_account="The source records an attributed view on this modal proposition. This is evidence of a stance, not proof that the anticipated event occurred.",
        event_bindings=[], actual_inner_event_established=False,
        canonical_identity_certified=False, cross_atom_or_event_join_certified=False,
        strict_stance_control=deepcopy(control))
    row["checks"].update(attributed_hypothesis_stance="PASS", literal_modal_scope="PASS",
        same_requested_arguments="PASS", inner_event_execution="NOT_CERTIFIED")
    return row
