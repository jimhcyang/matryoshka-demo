"""Separate, fail-closed qualifier audit for the frozen 5.1 root projection.

Only an attested query-root operator is certified, never its inner execution.
The earlier helper and ordinary V4 matcher remain immutable controls.
"""
from copy import deepcopy
import re

from matryoshka_demo.io import offline
from matryoshka_demo_v61 import scope_matching as scoped
from . import matching as baseline
from . import nonfactive_content as previous

VERSION = "narrative-root-nonfactive-content-experiment/5.2"
_ORDINALS = {"first", "second", "third", "fourth", "fifth", "sixth", "seventh",
    "eighth", "ninth", "tenth", "eleventh", "twelfth"}
_FUNCTIONAL = {"aux", "auxpass", "cop", "neg", "mark"}


def _lexical_tree(token):
    return (token.dep_, token.lemma_.casefold(), token.pos_, token.tag_,
        tuple(_lexical_tree(c) for c in token.children if not c.is_space and not c.is_punct))


def _enumerator(token, operator):
    if (token.dep_ != "advmod" or token.head != operator or list(token.children)
            or not (token.lower_ in _ORDINALS or re.fullmatch(r"\d+(?:st|nd|rd|th)", token.lower_))):
        return False
    doc = token.doc
    following = next((t for t in doc[token.i + 1:] if not t.is_space), None)
    preceding = next((t for t in reversed(doc[:token.i]) if not t.is_space), None)
    subjects = [c for c in operator.children if c.dep_ == "nsubj"]
    return (len(subjects) == 1 and token.i < subjects[0].left_edge.i
        and following is not None and following.text == ","
        and (preceding is None or preceding.text in {",", ";", ":", "."}))


def _enumerated_previous_branch(child, operator):
    markers = [c for c in operator.children if _enumerator(c, operator)]
    earlier_markers = [c for c in child.children if _enumerator(c, child)]
    subjects = [c for c in child.children if c.dep_ == "nsubj"]
    clock = previous._owned_clock(child)
    # NLP may attach an earlier list item as ccomp. Only disjoint, explicitly
    # enumerated finite clauses are exempt; a genuine report is not a list item.
    boundary = list(child.doc[child.right_edge.i:markers[0].i]) if len(markers) == 1 else []
    return (child.dep_ == "ccomp" and len(markers) == len(earlier_markers) == len(subjects) == 1
        and clock is not None and child.right_edge.i < markers[0].i
        and any(t.text in {",", ";", "."} for t in boundary)
        and all(t.is_space or t.is_punct for t in boundary[1:])
        and not any(c.dep_ in {"mark", "advcl"} for c in child.children))


def _adverbs(operator, *, enumerated=False):
    return sorted(_lexical_tree(c) for c in operator.children if c.dep_ == "advmod"
        and not (enumerated and _enumerator(c, operator)))


def _attachment_issues(operator, leaf, frame, *, root):
    issues = []
    roles = frame["roles"]
    for child in operator.children:
        if child.is_space or child.is_punct or child.dep_ in _FUNCTIONAL | {"advmod"}:
            continue
        if root and (child == leaf or child.dep_ == "nsubj"):
            continue
        if root and _enumerated_previous_branch(child, operator):
            continue
        if not root and child.dep_ in {"dobj", "obj", "iobj"}:
            if any(p["start"] == child.idx for values in roles.values() for phrase in values
                    for p in phrase["proofs"]):
                continue
        if not root and child.dep_ == "prep":
            key = "prep:" + child.lemma_.casefold()
            objects = [c for c in child.children if c.dep_ == "pobj"]
            if (key in roles and objects and all(any(p["start"] == obj.idx
                    for phrase in roles[key] for p in phrase["proofs"]) for obj in objects)
                    and all(c.dep_ == "pobj" or c.is_space or c.is_punct for c in child.children)):
                continue
        issues.append(dict(kind="UNMODELED_ROOT_ATTACHMENT" if root else "UNMODELED_LEAF_ATTACHMENT",
            proof=scoped.matching.proof(child)))
    return issues


def _nominal_issues(phrase, target=None):
    issues = []
    if phrase.get("role_qualifiers") or phrase.get("unresolved"):
        issues.append("QUALIFIED_OR_UNBOUND_NOMINAL_ARGUMENT")
    for modifier in phrase.get("modifiers", []):
        # Extra noun-internal properties (Court OF Justice) are not operator
        # roles. Unmodeled attribution/location/conditional attachments are.
        candidates = [m["phrase"] for m in (target or {}).get("modifiers", [])
            if m["relation"] == modifier["relation"]]
        signature = lambda p: (p["head"], sorted(p["terms"]), sorted(p["names"]))
        matched = next((p for p in candidates if signature(p) == signature(modifier["phrase"])), None)
        if modifier["relation"] != "of" and matched is None:
            issues.append("UNMODELED_NOMINAL_ATTACHMENT")
        issues.extend(_nominal_issues(modifier["phrase"], matched))
    return issues


def _audit(certificate, query_doc, source_doc):
    target, source = certificate["target_leaf_frame"], certificate["source_leaf_frame"]
    qt, st = baseline._token(target, query_doc), baseline._token(source, source_doc)
    if qt is None or st is None:
        return [dict(kind="LEAF_PROOF_NOT_REPLAYABLE")], None
    qr, sr = qt.head, st.head
    issues = []
    for label, q, s, root in (("ROOT", qr, sr, True), ("LEAF", qt, st, False)):
        if _adverbs(q, enumerated=root) != _adverbs(s, enumerated=root):
            issues.append(dict(kind=label + "_ADVERB_QUALIFIERS_NOT_EQUAL"))
        functional = lambda token: sorted(_lexical_tree(c) for c in token.children if c.dep_ in _FUNCTIONAL)
        if functional(q) != functional(s):
            issues.append(dict(kind=label + "_AUXILIARY_OR_MARKER_QUALIFIERS_NOT_EQUAL"))
    if {k: len(v) for k, v in target["roles"].items()} != {k: len(v) for k, v in source["roles"].items()}:
        issues.append(dict(kind="UNMODELED_SOURCE_OR_QUERY_LEAF_ROLES"))
    for doc_label, root, leaf, frame in (("QUERY", qr, qt, target), ("SOURCE", sr, st, source)):
        for item in (_attachment_issues(root, leaf, frame, root=True)
                + _attachment_issues(leaf, None, frame, root=False)):
            issues.append(dict(item, side=doc_label))
        for role, values in frame["roles"].items():
            wanted = target["roles"].get(role, [])
            for i, phrase in enumerate(values):
                paired = wanted[i] if i < len(wanted) else None
                issues.extend(dict(kind=k, side=doc_label) for k in _nominal_issues(phrase, paired))
    # Attribution adjuncts may attach below a requested NP, not just to a verb.
    # No lexical holder or corpus identity is inferred from their presence.
    for token in source_doc:
        if token.dep_ == "prep" and token.lemma_.casefold() in {"accord", "according", "per"}:
            issues.append(dict(kind="UNMODELED_SOURCE_ATTRIBUTION_ADJUNCT", proof=scoped.matching.proof(token)))
    proof = dict(root_adverbs_equal=True, leaf_adverbs_equal=True,
        extra_leaf_roles_ignored=False, unmodeled_root_or_leaf_attachments_ignored=False,
        enumerated_source_markers=[scoped.matching.proof(c) for c in sr.children if _enumerator(c, sr)],
        separately_enumerated_previous_branches=[scoped.matching.proof(c) for c in sr.children
            if _enumerated_previous_branch(c, sr)],
        source_root_adverb_proofs=[scoped.matching.proof(c) for c in sr.children if c.dep_ == "advmod"],
        source_leaf_adverb_proofs=[scoped.matching.proof(c) for c in st.children if c.dep_ == "advmod"])
    return issues, proof


def evaluate(matcher, atom, page, unit):
    """Unadopted sidecar, with unchanged source gates and no event joins.

    A caller must not fall back to a signed V4 result for an applicable root
    claim when this audit withholds it. V4 remains available as a labeled control.
    """
    result = deepcopy(previous.evaluate(matcher, atom, page, unit))
    result.update(version=VERSION, qualifier_audit_issues=[], root_content_policy_applicable=False)
    with offline():
        query_doc = matcher.engine.parse(atom["text"])
        roots = [t for t in query_doc if t.dep_ == "ROOT" and t.pos_ == "VERB"
            and t.lemma_.casefold() in previous._OPERATORS
            and any(c.dep_ == "xcomp" for c in t.children)]
        result["root_content_policy_applicable"] = len(roots) == 1
        if result["direction"] != "SUPPORT":
            return result
        source_doc = matcher.engine.parse(unit.get("text", unit.get("quote")))
        issues, proof = _audit(result["source_attestation"], query_doc, source_doc)
    if issues:
        result.update(direction="UNRESOLVED", source_attestation=None, qualifier_audit_issues=issues)
    else:
        result["source_attestation"]["qualifier_audit"] = proof
    return result
