"""Source-owned full-assessed-pool context priority, never factual confidence."""
from copy import deepcopy
from functools import lru_cache
import math

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest, offline
from matryoshka_demo.corpus import ENGLISH_STOP_WORDS
from matryoshka_demo.source_view_policy import descriptor
from matryoshka_narrative import terminal_scores as terminal
from matryoshka_narrative import controller_role, candidate_identity
from matryoshka_narrative.contextual_scores import licensed_form
from matryoshka_narrative.context_relevance import focal_sentence

VERSION = "phase-source-page-context-rank/8"
SCORE_VERSION = "terminal-evidence-fit/8"
WEIGHTS = {"page_local_75_25": (.75, .25, 0.), "page_local_information_55_25_20": (.55, .25, .20)}


def candidate_projection(candidate):
    """Final consolidated entity, excluding only derived presentation fields."""
    value = deepcopy(candidate)
    for field in ("rank", "terminal_scorecard"):
        value.pop(field, None)
    if isinstance(value.get("ranking"), dict):
        value["ranking"].pop("terminal_scoring_version", None)
        value["ranking"].pop("canonical_order", None)
        if not value["ranking"]:
            value.pop("ranking")
    return value


def replay_scorecard(card):
    """Arithmetic contract for a strict UI adapter, not semantic authority."""
    if card.get("version") != SCORE_VERSION or card.get("rubric") not in WEIGHTS:
        raise ValueError("Unknown v8 context score contract")
    expected_weights = list(WEIGHTS[card["rubric"]])
    if card.get("weights") != expected_weights:
        raise ValueError("V8 rubric weights differ")
    raw = card["raw_features"]
    if set(raw) != {"page_focal_content_containment", "previous_local_fit", "bounded_previous_local_fit", "nonrepeated_candidate_content_fraction"}:
        raise ValueError("Unexpected v8 feature schema")
    values = [raw[k] for k in ("page_focal_content_containment", "previous_local_fit",
        "bounded_previous_local_fit", "nonrepeated_candidate_content_fraction")]
    if any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
        raise ValueError("V8 features must be finite numbers")
    page, prior, local, info = values
    if not 0 <= page <= 1 or not 0 <= info <= 1 or local != min(1., max(0., prior)):
        raise ValueError("V8 feature bounds differ")
    expected = dict(page_focal_content=expected_weights[0] * page,
        bounded_prior_local_fit=expected_weights[1] * local,
        nonrepeated_candidate_content=expected_weights[2] * info)
    tier = card.get("evidence_tier")
    if type(tier) is not int or tier not in (0, 1, 2) or card.get("native_evidence_tier") != tier:
        raise ValueError("V8 native evidence tier differs")
    context_index = sum(expected.values())
    index = (tier + .99 * context_index) / 3
    components = dict(evidence_tier_contribution=tier / 3,
        context_contribution=.99 * context_index / 3, context_index=context_index,
        context_scale=.99, tier_divisor=3)
    def equal(actual, wanted):
        return type(actual) in (int, float) and math.isfinite(actual) and abs(actual-wanted) <= 1e-12
    if (set(card.get("components", {})) != set(expected)
            or any(not equal(card["components"][k], v) for k, v in expected.items())
            or set(card.get("ranking_components", {})) != set(components)
            or any(not equal(card["ranking_components"][k], v) for k, v in components.items())
            or not equal(card.get("context_index"), context_index) or not equal(card.get("score"), index)
            or card.get("calibrated_probability") is not False
            or card.get("score_units") != "TIERED_CONTEXT_PRIORITY_INDEX_NOT_PROBABILITY"):
        raise ValueError("V8 score arithmetic or units differ")
    legacy = card.get("legacy_native_features", {})
    if (legacy.get("evidence_tier") != tier or card.get("native_score_version") != legacy.get("version")
            or not equal(card.get("native_score"), legacy.get("score"))
            or any(not equal(card.get(k), legacy.get(k, 0.)) for k in ("support", "oppose", "context", "fit", "criteria_coverage"))
            or card.get("contributions") != legacy.get("contributions", [])):
        raise ValueError("V8 legacy evidence values were changed or rescaled")
    contents, repeated = card["candidate_content_terms"], card["repeated_visible_content_terms"]
    if (len(contents) != len(set(contents)) or len(repeated) != len(set(repeated))
            or not set(repeated) <= set(contents)
            or not equal(info, (len(contents)-len(repeated))/len(contents) if contents else 0.)):
        raise ValueError("V8 content-fraction arithmetic differs")
    observations = card["source_page_observations"]
    if (not observations or any(not equal(o["containment"], len(o["matched_focal_terms"])/o["focal_term_count"]
            if o["focal_term_count"] else 0.) for o in observations)
            or not equal(page, max(o["containment"] for o in observations))
            or not any(o["canonical_page_id"] == card["selected_source_page"] and equal(o["containment"], page) for o in observations)):
        raise ValueError("V8 own-page MAX containment arithmetic differs")
    return index


class Ranker:
    def __init__(self, parser):
        self.parse = parser

    @lru_cache(maxsize=8192)
    def terms(self, text):
        shadow = MASK.sub(lambda m: " " * len(m.group()), text)
        doc = self.parse(shadow.lower())
        result = {t.lemma_.casefold() for t in doc if (t.is_alpha or t.like_num)
            and not t.is_stop and t.lemma_.casefold() not in ENGLISH_STOP_WORDS
            and t.lemma_.casefold() not in {"-pron-", ""}}
        return frozenset(result)

    def card(self, candidate, *, case, plan, retrieval, pages, policy, mode, native_card=None, source_binding=None):
        if mode not in WEIGHTS:
            raise ValueError("Predeclared convex rubric required")
        if policy.case != case:
            raise ValueError("Context source policy belongs to another public input")
        if candidate.get("reading_id") != candidate.get("declared_reading", {}).get("id"):
            raise ValueError("Candidate lost its declared reading")
        if candidate.get("provenance") == "INPUT" or candidate.get("input_nomination_id"):
            raise ValueError("Input nominations are outside this corpus-source probe")
        if (candidate["fill"] != candidate.get("source_wording")
                and not candidate.get("insertion_edits") and candidate.get("first_class_adjunct") is None):
            raise ValueError("Nonliteral fill lacks its recorded native source transformation")
        if candidate["local_decision"].get("status") not in terminal.TIERS:
            raise ValueError("Unknown or ineligible native evidence class")
        native_card = native_card or terminal.candidate_score(candidate, retrieval, plan=plan,
            version=terminal.CONTEXT_POINTS_VERSION, case=case)
        local_raw = native_card["fit"]
        if isinstance(local_raw, bool) or not isinstance(local_raw, (int, float)) or not math.isfinite(local_raw):
            raise ValueError("Missing actual prior local-fit feature")
        local = min(1., max(0., local_raw))
        focal = focal_sentence(case["query"], case["focal_marker"], self.parse)
        query_terms = self.terms(focal["text"])
        visible_terms = self.terms(case["query"])
        content = self.terms(candidate["fill"])
        equivalent_visible = set()
        lexical = None
        if candidate.get("lexical_realization", {}).get("state") == "licensed":
            lexical = licensed_form(candidate)
            if not lexical["eligible"]:
                raise ValueError("Existing licensed WordNet realization does not replay its gates")
            # A resource-licensed source noun already visible in the input is
            # not new content merely because an adjective spells it differently.
            if len(content) == 1 and self.terms(candidate["source_wording"]) & visible_terms:
                equivalent_visible.update(content)
        repeated = set(content) & set(visible_terms) | equivalent_visible
        information = len(set(content) - repeated) / len(content) if content else 0.
        owned = []
        positions = {p["id"]: pi for pi, p in pages}
        for ref in candidate.get("sources", []):
            occurrences = [o for o in candidate.get("source_occurrences", []) if o.get("citation") == ref]
            for occurrence in occurrences:
                span, wording = occurrence.get("source_span"), occurrence.get("source_wording")
                if (not isinstance(span, list) or len(span) != 2 or any(type(n) is not int for n in span)
                        or not isinstance(wording, str) or not wording):
                    raise ValueError("Own source occurrence has no literal span/wording")
                pi = positions.get(ref.get("canonical_page_id"))
                if pi is None:
                    raise ValueError("Candidate citation page was not actually inspected")
                page = policy.corpus.pages[pi]
                if page != next(p for j, p in pages if j == pi):
                    raise ValueError("Inspected page differs from policy binding")
                if digest(page["text"]) != page["source_sha256"]:
                    raise ValueError("Full source page hash differs")
                actual = policy.citation(pi, ref["start"], ref["end"])
                if ref != actual or not actual["start"] <= span[0] < span[1] <= actual["end"] or page["text"][span[0]:span[1]] != wording:
                    raise ValueError("Candidate source wording/quote does not replay")
                # Only a page containing an actual own occurrence may supply
                # context. Another candidate's page or a report-wide word bag
                # cannot provide this feature.
                page_terms = self.terms(page["text"])
                matched = set(query_terms) & set(page_terms)
                coverage = len(matched) / len(query_terms) if query_terms else 0.
                owned.append(dict(citation=deepcopy(ref), source_span=deepcopy(span), source_wording=wording,
                    canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
                    full_page_sha256=page["source_sha256"],
                    full_page_utf8_sha256=__import__("hashlib").sha256(page["text"].encode()).hexdigest(),
                    page_content_term_count=len(page_terms), focal_term_count=len(query_terms),
                    matched_focal_terms=sorted(matched), containment=coverage))
        if not owned:
            raise ValueError("No citation-owned inspected source occurrence; no ranking fallback")
        winner = max(owned, key=lambda row: row["containment"])
        page_fit = winner["containment"]
        weights = WEIGHTS[mode]
        components = dict(page_focal_content=weights[0] * page_fit,
            bounded_prior_local_fit=weights[1] * local,
            nonrepeated_candidate_content=weights[2] * information)
        context_index = sum(components.values())
        tier = native_card["evidence_tier"]
        if type(tier) is not int or tier not in (0, 1, 2):
            raise ValueError("Only existing admitted evidence tiers may be ranked")
        score = (tier + .99 * context_index) / 3
        legacy_fields = ("version", "score", "evidence_tier", "support", "oppose", "context", "fit", "fit_components",
            "criteria_coverage", "contributions", "source_function_band", "source_function_context", "ranking_components")
        card = dict(version=SCORE_VERSION, rubric=mode, id=candidate["id"], candidate_id=candidate["id"], fill=candidate["fill"],
            score=score, context_index=context_index, evidence_tier=tier,
            score_units="TIERED_CONTEXT_PRIORITY_INDEX_NOT_PROBABILITY", weights=list(weights),
            components=components, raw_features=dict(page_focal_content_containment=page_fit,
                previous_local_fit=local_raw, bounded_previous_local_fit=local,
                nonrepeated_candidate_content_fraction=information),
            focal_query_span=focal, focal_content_terms=sorted(query_terms),
            candidate_content_terms=sorted(content), repeated_visible_content_terms=sorted(repeated),
            visible_content_terms=sorted(visible_terms), source_page_observations=owned,
            selected_source_page=winner["canonical_page_id"], source_page_union_used=False,
            lexical_provenance=deepcopy(lexical),
            native_score=native_card["score"], native_score_version=native_card["version"],
            native_evidence_tier=tier, native_status=candidate["local_decision"]["status"],
            native_source_function_band=deepcopy(native_card.get("source_function_band")),
            native_decision_sha256=digest(candidate["local_decision"]),
            raw_candidate_sha256=digest(candidate_projection(candidate)),
            candidate_binding_contract="FINAL_CONSOLIDATED_ENTITY_EXCLUDING_RANK_SCORECARD_AND_RANKING_DISPLAY_FIELDS",
            legacy_native_features={k: deepcopy(native_card[k]) for k in legacy_fields if k in native_card},
            support=deepcopy(native_card.get("support", 0.)), oppose=deepcopy(native_card.get("oppose", 0.)),
            context=deepcopy(native_card.get("context", 0.)), fit=local_raw,
            criteria_coverage=deepcopy(native_card.get("criteria_coverage", 0.)),
            contributions=deepcopy(native_card.get("contributions", [])),
            legacy_evidence_features_are_not_v8_score_components=True,
            ranking_components=dict(evidence_tier_contribution=tier / 3,
                context_contribution=.99 * context_index / 3, context_index=context_index,
                context_scale=.99, tier_divisor=3),
            formula="(tier + 0.99*(w_page*page_containment + w_local*bounded_previous_local_fit + w_information*nonrepeated_candidate_content_fraction))/3",
            score_range=[0., 2.99/3], query_sha256=digest(case["query"]), plan_sha256=digest(plan),
            source_view_policy=descriptor(policy.source_view_policy), source_context_binding=deepcopy(source_binding),
            BM25_or_retrieval_weight_in_context_index=False, calibrated_probability=False,
            truth_support_or_eligibility_changed=False, visible_repetition_is_not_factual_rejection=True,
            normalization="OPAQUE_MASK_TO_SPACES_THEN_LOWERCASE_CONTENT_LEMMAS_MINUS_STOPWORDS")
        replay_scorecard(card)
        return card

    def rerank(self, native, snapshot, policy, *, mode, inspected_pages=None, _retain_candidates=False):
        if mode not in {*WEIGHTS, "native_v7_replay"}:
            raise ValueError("Unknown declared ranking arm")
        case, plan, result, retrieval = native["case"], native["plan"], native["result"], native["retrieval"]
        if case["task"] != "redaction":
            return dict(version=VERSION, mode=mode, case_id=case["case_id"], not_applicable="NON_REDACTION_UNCHANGED",
                native_result_sha256=digest(result), atoms_unchanged=True)
        if not isinstance(result.get("assessed_candidates"), list):
            raise ValueError("Full actual assessed pool required; no displayed-array fallback")
        pages = inspected_pages if inspected_pages is not None else list(enumerate(snapshot["pages"]))
        if [p["id"] for _, p in pages] != result["inspected_page_ids"]:
            raise ValueError("Source snapshot differs from actual inspected sequence")
        if policy.case != case or any(policy.corpus.pages[i] != p for i, p in pages):
            raise ValueError("Native case/pages differ from source policy")
        if result["query_sha256"] != digest(case["query"]):
            raise ValueError("Result public query binding differs")
        before = digest(result)
        pool = result["assessed_candidates"]
        if len({c["id"] for c in pool}) != len(pool):
            raise ValueError("Duplicate raw assessed candidate ID")
        withheld = {c["id"] for c in pool if controller_role.withheld_from_shortlist(c, query_sha256=result["query_sha256"])}
        shortlist = result.get("controller_shortlist")
        if withheld or isinstance(shortlist, dict):
            saved_ids = shortlist.get("withheld_candidate_ids") if isinstance(shortlist, dict) else None
            if (not isinstance(saved_ids, list) or len(set(saved_ids)) != len(saved_ids)
                    or set(saved_ids) != withheld or shortlist.get("audit_collection") != "assessed_candidates"):
                raise ValueError("Existing controller withheld inventory differs")
        base_cards, cards = {}, {}
        for candidate in pool:
            if candidate["id"] in withheld or candidate.get("local_decision", {}).get("status") not in terminal.TIERS:
                continue
            base = terminal.candidate_score(candidate, retrieval, plan=plan, version=terminal.CONTEXT_POINTS_VERSION, case=case)
            base_cards[candidate["id"]] = base
        branches = []
        for branch in result["readings"]:
            candidates = [c for c in pool if c["reading_id"] == branch["reading"]["id"] and c["id"] in base_cards]
            # Reuse the exact existing source-local consolidation producer and
            # its native evidence audits. Context scores never merge identities.
            candidates = candidate_identity.consolidate(candidates, score=lambda c: base_cards[c["id"]],
                source_local_identity=True, query_sha256=result["query_sha256"])
            # A representative can have a changed source/identity inventory.
            # Score and bind THAT entity, never the earlier raw-pool object.
            for candidate in candidates:
                base = terminal.candidate_score(candidate, retrieval, plan=plan,
                    version=terminal.CONTEXT_POINTS_VERSION, case=case)
                base_cards[candidate["id"]] = base
                if mode != "native_v7_replay":
                    cards[candidate["id"]] = self.card(candidate, case=case, plan=plan, retrieval=retrieval,
                        pages=pages, policy=policy, mode=mode, native_card=base, source_binding=native.get("binding"))
            if mode == "native_v7_replay":
                key = lambda c: (-base_cards[c["id"]]["score"], c.get("source_rank_position", 10**9), c["id"])
            else:
                key = lambda c: (-base_cards[c["id"]]["evidence_tier"], -cards[c["id"]]["score"], c.get("source_rank_position", 10**9), c["id"])
            ordered = sorted(candidates, key=key)
            selected, seen, families = [], set(), set()
            for c in ordered:
                decision = c["local_decision"]
                surface = (" ".join(c["fill"].casefold().split()), decision.get("scope"))
                family = (c.get("alternative_family", c["id"]), decision.get("status"), decision.get("scope"),
                    tuple((r.get("id"), str(r.get("coverage")), r.get("direction")) for r in decision.get("requirements", [])), bool(decision.get("counterevidence")))
                if surface in seen or family in families:
                    continue
                seen.add(surface)
                families.add(family)
                selected.append(c)
            projected = dict(reading_id=branch["reading"]["id"],
                native_displayed_ids=[c["id"] for c in branch["candidates"]],
                ranked_ids=[c["id"] for c in selected],
                top5=[dict(id=c["id"], fill=c["fill"], status=c["local_decision"]["status"],
                    evidence_tier=base_cards[c["id"]]["evidence_tier"],
                    score=base_cards[c["id"]]["score"] if mode == "native_v7_replay" else cards[c["id"]]["score"],
                    identity_consolidation=deepcopy(c.get("identity_consolidation"))) for c in selected[:5]],
                consolidated_pool_count=len(candidates), selected_after_existing_surface_family_dedup=len(selected))
            if _retain_candidates:
                projected["retained_candidates"] = selected[:10]
            branches.append(projected)
        if digest(result) != before:
            raise ValueError("Context ranking changed the saved native result")
        return dict(version=VERSION, mode=mode, case_id=case["case_id"], full_assessed_pool_count=len(pool),
            withheld_candidate_ids=sorted(withheld), cards=cards, readings=branches,
            native_result_sha256=before, factual_decisions_unchanged=True,
            ranking_scope="WITHIN_EXISTING_NATIVE_EVIDENCE_TIER", source_function_bonus_removed_from_context_priority=True,
            consolidation_and_controller_guards_unchanged=True, native_packet_modified=False)


def annotate_result(result, retrieval, *, case, plan, pages, source_policy, source_binding, parser,
                    mode="page_local_information_55_25_20", top_k=5):
    """Fresh-execution postprocessor; pure copy, no historical storage writes.

    The production caller must pass its existing trusted SourcePolicy and exact
    execution index binding, never a query- or model-supplied policy descriptor.
    """
    if type(top_k) is not int or not 1 <= top_k <= 5 or mode not in WEIGHTS:
        raise ValueError("One-to-five displayed candidates and a declared v8 mode required")
    if (not isinstance(source_binding, dict) or source_binding.get("corpus") != case["corpus"]
            or not isinstance(source_binding.get("resource_id"), str) or not source_binding["resource_id"]
            or any(not isinstance(source_binding.get(k), str) or len(source_binding[k]) != 64
                or any(c not in "0123456789abcdef" for c in source_binding[k]) for k in ("sha256", "registry_sha256"))):
        raise ValueError("Exact native execution index/resource binding required")
    if case["task"] != "redaction":
        return deepcopy(result)
    before = digest(result)
    wrapper = dict(case=case, plan=plan, result=result, retrieval=retrieval, binding=source_binding)
    snapshot = dict(pages=[p for _,p in pages])
    ranking = Ranker(parser).rerank(wrapper, snapshot, source_policy, mode=mode,
        inspected_pages=pages, _retain_candidates=True)
    output = deepcopy(result)
    prior_scores = deepcopy(output.get("terminal_scores"))
    output["legacy_terminal_scores_before_v8"] = prior_scores
    for branch, ordered in zip(output["readings"], ranking["readings"], strict=True):
        selected = ordered["retained_candidates"]
        for rank, candidate in enumerate(selected, 1):
            card = ranking["cards"][candidate["id"]]
            candidate["rank"] = rank
            candidate["terminal_scorecard"] = deepcopy(card)
            candidate.setdefault("ranking", {}).update(terminal_scoring_version=SCORE_VERSION,
                canonical_order="Native evidence tier, then citation-owned page/local/nonrepeated-content context index; source position breaks exact ties")
            if digest(candidate_projection(candidate)) != card["raw_candidate_sha256"]:
                raise ValueError("V8 card no longer binds the final annotated consolidated candidate")
        branch["candidates"] = selected[:top_k]
        branch["reserve_candidates"] = selected[top_k:10]
    output["candidates"] = [c for b in output["readings"] for c in b["candidates"]]
    output["retained_ranking"] = dict(version="native-context-v8-top-ten/1", displayed_per_reading=top_k,
        retained_per_reading=10, full_assessed_pool=True, same_scoring_and_deduplication=True,
        extra_candidates_are_not_evidence_votes=True, original_top_five_selection_unchanged=False)
    output["terminal_scores"] = dict(version=SCORE_VERSION, probability=False, ranking_applied=True,
        judgments_unchanged=True, source_function_bonus_applied=False,
        readings=[dict(reading_id=b["reading"]["id"], candidates=[c["terminal_scorecard"] for c in b["candidates"]],
            reserve_candidates=[c["terminal_scorecard"] for c in b["reserve_candidates"]]) for b in output["readings"]],
        legacy_overall_auxiliary=deepcopy((prior_scores or {}).get("overall")))
    output["context_rank_v8"] = dict(version=VERSION, score_version=SCORE_VERSION, rubric=mode,
        weights=list(WEIGHTS[mode]), source_binding=deepcopy(source_binding),
        source_view_policy=descriptor(source_policy.source_view_policy),
        inspected_page_bindings=[dict(canonical_page_id=p["id"], page_sha256=p["source_sha256"]) for _,p in pages],
        original_result_sha256=before, raw_assessed_pool_sha256=digest(result["assessed_candidates"]),
        withheld_candidate_ids=ranking["withheld_candidate_ids"], input_or_model_nomination_used=False,
        facts_classes_gates_unchanged=True, legacy_evidence_values_rescaled=False,
        candidates_scored_after_source_local_consolidation=True)
    shortlist = output.get("controller_shortlist")
    if isinstance(shortlist, dict):
        shortlist["displayed_count"] = len(output["candidates"])
        for b in output["readings"]:
            counts = shortlist.get("counts_by_reading", {}).get(b["reading"]["id"])
            if isinstance(counts, dict):
                counts["displayed"] = len(b["candidates"])
    if digest(result) != before or output["assessed_candidates"] != result["assessed_candidates"]:
        raise ValueError("Fresh v8 annotation changed the raw native pool")
    return output
