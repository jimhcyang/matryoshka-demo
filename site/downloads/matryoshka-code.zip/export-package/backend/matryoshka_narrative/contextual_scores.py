"""Source-bound contextual fit arithmetic, never factual or identity evidence."""
from copy import deepcopy
from functools import lru_cache
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from matryoshka_demo.corpus import words, ENGLISH_STOP_WORDS

SCOPE_TYPE_CONTRACT = "literal-visible-source-class-anchor/2"


def _terms(text):
    return set(words(text))-set(ENGLISH_STOP_WORDS)


@lru_cache(maxsize=256)
def resource_replay(noun):
    from .lexical_realization import LexicalRealizer
    realizer = LexicalRealizer()
    lookup = realizer.forms(noun)
    if realizer.resource.get("availability") != "AVAILABLE":
        raise ValueError("Actual WordNet resource unavailable; no realized fit")
    return lookup, deepcopy(realizer.resource)


def bound_occurrences(candidate, quote):
    from . import terminal_scores as s
    if not s._citation(quote):
        return []
    matched = []
    for occurrence in candidate.get("source_occurrences", []):
        span = occurrence.get("source_span", [])
        if (occurrence.get("citation") != quote or len(span) != 2
                or any(type(n) is not int for n in span)
                or not quote["start"] <= span[0] < span[1] <= quote["end"]
                or quote["text"][span[0]-quote["start"]:span[1]-quote["start"]] != occurrence.get("source_wording")):
            continue
        matched.append(occurrence)
    return matched


def licensed_form(candidate):
    """Replay an existing source-only lexical license, not caller truth flags."""
    from . import lexical_realization as lexical
    from . import terminal_scores as s
    audit = candidate.get("lexical_realization",{})
    if audit.get("state") != "licensed":
        return dict(eligible=False,reason="NO_LICENSED_SOURCE_AUDIT")
    quote,span = audit.get("original_quote",{}),audit.get("source_span",[])
    source = candidate.get("source_wording")
    if (s._citation(quote) is None or span != candidate.get("source_span")
            or source != audit.get("source_identity") or not isinstance(source,str) or not source
            or audit.get("proposed_insertion") != candidate.get("fill")
            or audit.get("transformations") != candidate.get("insertion_edits")
            or quote not in candidate.get("sources",[]) or len(span) != 2
            or not all(type(v) is int for v in span)
            or not quote["start"] <= span[0] < span[1] <= quote["end"]
            or quote["text"][span[0]-quote["start"]:span[1]-quote["start"]] != source):
        raise ValueError("Licensed source quote/span/surface binding failed")
    if (audit.get("context_only") is not True or audit.get("factual_support_certified") is not False
            or audit.get("same_owner_or_event_certified") is not False
            or audit.get("source_wording_modified") is not False
            or audit.get("used_as_retrieval_seed") is not False
            or audit.get("source_nominated_before_realization") is not True
            or audit.get("verbatim_source_fill") is not False
            or audit.get("lexical_resource_does_not_certify_ner") is not True):
        raise ValueError("Lexical license is not source-nominated context only")
    lookup, resource = resource_replay(source)
    form = audit.get("selected_form",{})
    if (audit.get("version") != lexical.VERSION or audit.get("lexical_lookup") != lookup
            or audit.get("resource") != resource or form not in lookup["forms"]
            or form.get("fill") != candidate["fill"]
            or audit.get("ambiguity_unresolved") != lookup["ambiguity_unresolved"]
            or not form.get("derivations") or form.get("operation") != lexical.OPERATION):
        raise ValueError("Lexical WordNet resource/derivation replay failed")
    edits = audit.get("transformations",[])
    expected = dict(kind=lexical.OPERATION, before=source, after=form["fill"],
        resource=resource, derivations=form["derivations"], grammar_only=True,
        source_modified=False, source_evidence_credit=False, source_is_verbatim_adjective=False,
        identity_or_event_certified=False)
    if edits != [expected]:
        raise ValueError("Lexical grammar-only transformation replay failed")
    if not any(o.get("source_span") == span and o.get("source_wording") == source
            and o.get("lexical_realization") == audit for o in bound_occurrences(candidate, quote)):
        raise ValueError("Lexical audit lacks its own provenance-bound source occurrence")
    passed = all(candidate.get(key,{}).get("state") == "pass" for key in
        ("final_form_fit","completed_head_kind_fit","joint_slot_fit"))
    final = candidate.get("final_form_fit",{})
    eligible = (passed and final.get("head",{}).get("pos") == "ADJ"
        and final.get("head",{}).get("text") == candidate["fill"]
        and final.get("outer_family") == "adjectival"
        and candidate.get("ranking",{}).get("features",{}).get("effective_target_kind") == "property")
    return dict(eligible=eligible,reason="PASSED_REALIZED_ADJECTIVAL_FORM" if eligible else
        "ACTUAL_FINAL_HEAD_JOINT_PASSES_REQUIRED",source_identity=source,source_quote=deepcopy(quote),
        audit_sha256=digest(audit),ambiguity_unresolved=audit.get("ambiguity_unresolved"),
        actual_wordnet_replayed=True,resource=deepcopy(resource))


def exact_spans(query, rows):
    for span in rows:
        a,b = span.get("start"),span.get("end")
        if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(query) or query[a:b] != span.get("text"):
            raise ValueError("Provided public-input span failed")
    return rows


def atom_overlap(candidate,case,plan,mode="balanced"):
    from . import terminal_scores as s
    if mode not in {"balanced","max_atom"}:
        raise ValueError("Unknown contextual overlap mode")
    feature = candidate.get("ranking",{}).get("features",{})
    denominator = s._finite(feature.get("focal_term_count"))
    focal = min(1.,s._finite(feature.get("focal_context_coverage"))/denominator) if denominator > 0 else 0.
    citations = [(ref,_terms(MASK.sub(" ",ref["text"]))) for ref in candidate.get("sources",[]) if s._citation(ref)]
    marker = case["query"].index(case["focal_marker"])
    atoms = []
    for atom in plan.get("atoms",[]):
        spans = exact_spans(case["query"],atom.get("query_spans",[]))
        if not spans:
            raise ValueError("Atom has no exact input span")
        terms = _terms(MASK.sub(" "," ".join(span["text"] for span in spans)))
        if not terms:
            continue
        pairs = [dict(coverage=len(terms & observed)/len(terms),citation=deepcopy(ref),
            matched_terms=sorted(terms & observed)) for ref,observed in citations]
        winner = max(pairs,key=lambda p:p["coverage"],default=dict(coverage=0.,citation=None,matched_terms=[]))
        atoms.append(dict(id=atom["id"],**winner,term_count=len(terms),
            contains_focal=any(p["start"] <= marker < p["end"] for p in spans)))
    background = [a["coverage"] for a in atoms if not a["contains_focal"]]
    best = max((a["coverage"] for a in atoms),default=focal)
    balanced = .5*focal+.5*max(background,default=focal)
    winners = [a for a in atoms if a["coverage"] == (best if mode=="max_atom" else max(background,default=focal))
        and (mode=="max_atom" or not a["contains_focal"])]
    return dict(value=best if mode=="max_atom" else balanced,focal=focal,
        citation_atom_pairs_never_joined=True,winning_atom_citation=winners[0] if winners else None,
        best_atom=best,best_background=max(background,default=focal),atoms=atoms)


def visible_scope(candidate,case,plan,license):
    from . import terminal_scores as s
    scope = deepcopy(s._scope_fit(candidate,plan))
    if not license["eligible"]:
        return scope
    audit,identity = candidate["lexical_realization"],license["source_identity"]
    norp = audit.get("source_class_observation",{}).get("norp_observations",[])
    if not any(n.get("label")=="NORP" and n.get("text")==identity
            and [n.get("start"),n.get("end")]==audit["source_span"] for n in norp):
        return scope
    for entity in plan.get("extractions",{}).get("entities",[]):
        if (entity.get("contains_unknown_slot") is not False or entity.get("label") != identity
                or entity.get("type") not in ("Other","group")):
            continue
        spans = exact_spans(case["query"],entity.get("query_spans",[]))
        valid = [p for p in spans if re.search(r"(?<!\w)"+re.escape(identity)+r"(?!\w)",p["text"])]
        if valid:
            scope["matches"].append(dict(label=identity,query_entity=entity.get("local_id"),
                original_model_type=entity["type"],original_type_not_rewritten=True,query_spans=deepcopy(valid),
                type_contract=SCOPE_TYPE_CONTRACT,relevance_only=True,identity_or_event_certified=False,
                factual_support_certified=False,
                canonical_page_id=license["source_quote"]["canonical_page_id"],start=audit["source_span"][0],
                end=audit["source_span"][1],text=identity,exact_source_norp_identity=True,source_owned_action_certified=False))
    scope["value"] = float(bool(scope["matches"]))
    return scope


def recorded_ranks(retrieval, *, atom_ids):
    from . import terminal_scores as s
    ranks,observations = s._rank_map(retrieval),[]
    for search in retrieval.get("search_queries",[]):
        if search.get("kind") != "atom":
            continue
        ids = search.get("atom_ids")
        if (not isinstance(ids,list) or not ids or any(not isinstance(v,str) or not v for v in ids)
                or not set(ids) <= set(atom_ids)):
            raise ValueError("Recorded BM25 search lacks known public plan atom IDs")
        seen = set()
        for rank,page in enumerate(search.get("top_pages",[]),1):
            pid = page["page_id"]
            if pid in seen:
                raise ValueError("Duplicate page in recorded BM25 prefix")
            seen.add(pid)
            ranks[pid] = min(rank,ranks.get(pid,rank))
            observations.append(dict(page_id=pid,atom_ids=deepcopy(search["atom_ids"]),recorded_position=rank))
    return ranks,observations


def score(candidate,case,plan,retrieval,*,mode="balanced"):
    """V7 arithmetic only. Native source and factual gates have already run."""
    from . import terminal_scores as s
    if not isinstance(case,dict) or not isinstance(plan,dict) or not case.get("focal_marker"):
        raise ValueError("Context v7 needs its bound public case and plan")
    if plan.get("query_sha256",digest(case["query"])) != digest(case["query"]):
        raise ValueError("Context v7 public query/plan binding failed")
    before = digest(candidate)
    base = s.candidate_score(candidate,retrieval,plan=plan,version=s.SOURCE_POINTS_VERSION)
    license = licensed_form(candidate)
    primary_quotes = [ref for ref in candidate.get("sources",[]) if any(
        o.get("source_span")==candidate.get("source_span") and o.get("source_wording")==candidate.get("source_wording")
        for o in bound_occurrences(candidate,ref))]
    if not primary_quotes:
        raise ValueError("Candidate has no provenance-bound primary source occurrence")
    primary_view = dict(candidate,sources=primary_quotes)
    overlap = atom_overlap(primary_view,case,plan,mode)
    scope = visible_scope(primary_view,case,plan,license)
    components = deepcopy(base["fit_components"])
    components.update(licensed_realized_form_fit=.16 if license["eligible"] and components["source_type"]==0 else 0.,
        focal_terms=.16*overlap["value"],visible_scope=.2*scope["value"])
    fit = sum(components.values())
    ranks,rank_proof = recorded_ranks(retrieval,atom_ids=[a["id"] for a in plan.get("atoms",[])])
    observations,local_fits = [],{}
    fallback = candidate.get("ranking",{}).get("features",{}).get("retrieval_page_rank")
    for ref in candidate.get("sources",[]):
        occurrences = bound_occurrences(candidate,ref)
        primary = any(o.get("source_span")==candidate.get("source_span")
            and o.get("source_wording")==candidate.get("source_wording") for o in occurrences)
        if not occurrences:
            local_fits[digest(ref)] = dict(citation=ref,fit=0.,components={},
                reason="NO_OWN_SOURCE_OCCURRENCE_CITATION",licensed_quote=False)
            continue
        # Structural features and lexical fit belong to this occurrence alone.
        occurrence = next((o for o in occurrences if o.get("source_span")==candidate.get("source_span")
            and o.get("source_wording")==candidate.get("source_wording")),occurrences[0])
        view = dict(candidate,sources=[ref],source_occurrences=[occurrence],
            ranking=dict(candidate.get("ranking",{}),features=occurrence.get("features",{})))
        local_base = base if primary else s.candidate_score(view,retrieval,plan=plan,version=s.SOURCE_POINTS_VERSION)
        local_overlap = atom_overlap(view,case,plan,mode)
        own_license = license["eligible"] and license.get("source_quote")==ref
        local_scope = visible_scope(view,case,plan,license if own_license else dict(eligible=False))
        local = deepcopy(local_base["fit_components"])
        local.update(licensed_realized_form_fit=.16 if own_license and local["source_type"]==0 else 0.,
            focal_terms=.16*local_overlap["value"],visible_scope=.2*local_scope["value"])
        local_fits[digest(ref)] = dict(citation=ref,fit=sum(local.values()),components=local,
            licensed_quote=own_license,reason="OWN_SOURCE_OCCURRENCE",atom_overlap=local_overlap,visible_scope=local_scope)
    for ref in candidate.get("sources",[]):
        observations.append(("context",ref,local_fits[digest(ref)]["fit"],fallback))
    for unit in candidate.get("local_decision",{}).get("requirements",[]):
        complete = unit.get("coverage")=="Established"
        for item in unit.get("evidence",[]):
            direction = str(item.get("direction",unit.get("direction",""))).upper()
            target = "oppose" if direction in s.OPPOSED or "COUNTEREVIDENCE" in direction else (
                "support" if complete and direction in {"SUPPORT","SUPPORTED"} else "context")
            for ref in [item.get("citation"),*item.get("citations",[])]:
                observations.append((target,ref,1. if target!="context" else s.criteria_fraction(unit),None))
        if complete and unit.get("direction")=="Support":
            for ref in unit.get("citations",[]):
                observations.append(("support",ref,1.,None))
        for ref in unit.get("context_citations",[]):
            observations.append(("context",ref,local_fits.get(digest(ref),{}).get("fit",0.),fallback))
    totals,contributions = s._sum_documents(observations,ranks)
    utility = max(0.,(totals["support"]+fit+.5*totals["context"])/(1+totals["oppose"]))
    residual = utility/(1+utility)
    points = deepcopy(base["ranking_components"])
    points.update(evidence_fit_points=35*residual,utility=utility,saturated_utility=residual)
    total = sum(points[k] for k in ("evidence_tier_points","source_function_points","evidence_fit_points")) if base["evidence_tier"]>=0 else 0.
    if digest(candidate) != before:
        raise ValueError("Context scorer changed its candidate")
    return dict(base,version=s.CONTEXT_POINTS_VERSION,score=total,ranking_components=points,
        fill=candidate["fill"],v6_score=base["score"],mode=mode,
        fit=fit,fit_components=components,visible_scope=scope,atom_overlap=overlap,
        realized_form_license=license,contributions=contributions,**totals,
        recorded_rank_proof=[p for p in rank_proof if p["page_id"] in {c["citation"]["canonical_page_id"] for c in contributions}],
        citation_local_fits=deepcopy(list(local_fits.values())),raw_type_and_band_unchanged=True,factual_decisions_unchanged=True,
        citations_unchanged=True,input_candidate_unchanged=True,support_directions_unchanged=True,
        contextual_arithmetic="BALANCED_FOCAL_AND_SINGLE_CITATION_BACKGROUND; SEPARATE_REALIZED_FORM; RECORDED_ATOM_POSITION")
