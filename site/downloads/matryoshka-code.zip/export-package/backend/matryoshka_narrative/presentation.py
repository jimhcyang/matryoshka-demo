"""New display projections; never reseal or modify a prior native release."""
from copy import deepcopy
import hashlib
from pathlib import Path
import re

from matryoshka_demo.io import digest
from matryoshka_demo.contracts import public_case as validate_engine_public_case
from matryoshka_current import reporting, inspection, planning as current_planning
from matryoshka_next.workflow import read as load, put_immutable
from .contracts import engine_case

VERSION = "narrative-workbench-publication/1"
PREFIX = "experiments/narrative_demo/publication/"
PUBLIC_CASE_FIELDS = ("case_id", "corpus", "task", "query", "date", "document_id", "focal_marker")


def _native_public_case_binding(case, native, native_ref):
    """Bind public identity/admission scope without rerunning any engine.

    Exact public-task packets remain usable. The legacy reconstruction spelling
    is accepted only with the workflow's explicit, consistent Mosaic bridge.
    No representation can override a conflicting second representation.
    """
    if not isinstance(case, dict) or set(case) != set(PUBLIC_CASE_FIELDS):
        raise ValueError("Qualified publication requires an exact seven-field public case")
    if not all(isinstance(case[field], str) for field in PUBLIC_CASE_FIELDS if field != "focal_marker"):
        raise ValueError("Qualified publication public case fields must be strings")
    if case["focal_marker"] is not None and not isinstance(case["focal_marker"], str):
        raise ValueError("Public focal marker must be a string or null")
    adapted = engine_case(case)
    issues = []
    try:
        validate_engine_public_case(adapted)
    except ValueError:
        issues.append("condition.PUBLIC_CASE_SCHEMA_INVALID")
    if any(not case[field].strip() for field in PUBLIC_CASE_FIELDS if field != "focal_marker"):
        issues.append("condition.PUBLIC_CASE_SCHEMA_INVALID")
    native_case = native.get("case")
    if not isinstance(native_case, dict) or set(native_case) != set(PUBLIC_CASE_FIELDS):
        issues.append("native.case.SEVEN_FIELD_CASE_REQUIRED")
        native_case = native_case if isinstance(native_case, dict) else {}
    for field in PUBLIC_CASE_FIELDS:
        expected = adapted[field] if field == "focal_marker" else case[field]
        if field != "task" and native_case.get(field) != expected:
            issues.append("native.case." + field)
    declared_public = native.get("public_case")
    if "public_case" in native:
        if not isinstance(declared_public, dict) or set(declared_public) != set(PUBLIC_CASE_FIELDS):
            issues.append("native.public_case.SEVEN_FIELD_CASE_REQUIRED")
        else:
            issues.extend("native.public_case." + field for field in PUBLIC_CASE_FIELDS
                if declared_public[field] != case[field])
    if "public_task" in native and native["public_task"] != case["task"]:
        issues.append("native.public_task")
    expected_compatibility = dict(version="public-mosaic-legacy-engine/1", public_task=case["task"],
        engine_task=adapted["task"], frozen_outputs_modified=False)
    compatibility = native.get("compatibility")
    compatible = (isinstance(compatibility, dict) and compatibility == expected_compatibility
        and compatibility.get("frozen_outputs_modified") is False)
    if "compatibility" in native and (not compatible
            or native_case.get("task") != adapted["task"]):
        issues.append("native.compatibility")
    mode = "EXACT_SAME_PUBLIC_TASK"
    if native_case.get("task") != case["task"] or native_case.get("focal_marker") != case["focal_marker"]:
        mode = ("EXPLICIT_PUBLIC_MOSAIC_LEGACY_ENGINE_BRIDGE" if native_case.get("task") != case["task"]
            else "EXPLICIT_PUBLIC_ENGINE_MARKER_ADAPTATION")
        if native_case.get("task") != case["task"] and (
                case["task"] != "mosaic" or native_case.get("task") != adapted["task"]):
            issues.append("native.case.task")
        if not compatible:
            issues.append("native.compatibility")
        if declared_public != case:
            issues.append("native.public_case")
        if native.get("public_task") != case["task"]:
            issues.append("native.public_task")
    query_hash = digest(case["query"])
    for name, packet in (("native", native), ("native.plan", native.get("plan", {})),
            ("native.result", native.get("result", {}))):
        if isinstance(packet, dict) and "query_sha256" in packet and packet["query_sha256"] != query_hash:
            issues.append(name + ".query_sha256")
    result = native["result"]
    result_checksum = digest(result)
    if "case_id" in result and result["case_id"] != case["case_id"]:
        issues.append("native.result.case_id")
    if "native_checksum" in native and native["native_checksum"] != result_checksum:
        issues.append("native.native_checksum")
    return dict(version="narrative-native-public-case-binding/1", state="HOLD" if issues else "PASS",
        issues=sorted(set(issues)), checked_public_fields=list(PUBLIC_CASE_FIELDS), task_binding=mode,
        public_case_sha256=digest(case), native_case_sha256=digest(native.get("case")),
        native_public_case_sha256=digest(declared_public) if "public_case" in native else None,
        query_sha256=query_hash, native_result_checksum=result_checksum, native_checkpoint=deepcopy(native_ref),
        source_admission_scope_bound_not_recomputed=True, native_packet_modified=False)


def question_signature(text):
    """A duplicate screen, not semantic equivalence or a factual identity test."""
    return tuple(re.findall(r"\w+", text.casefold()))


def duplicate_questions(entries):
    seen, blockers = {}, []
    for case, native in entries:
        signatures = [("public_text", question_signature(case["query"]))]
        if case["task"] != "redaction":
            atoms = native.get("plan", {}).get("atoms", [])
            required = [a for a in atoms if a.get("required", True) and a.get("kind") != "context"]
            if required:
                signatures.append(("required_atoms", tuple(sorted(
                    question_signature(a["text"]) for a in required))))
        previous = set()
        for channel, signature in signatures:
            key = case["corpus"], channel, signature
            if key in seen:
                previous.add(seen[key])
            seen.setdefault(key, case["case_id"])
        if previous:
            blockers.append(dict(case_id=case["case_id"], reason="DUPLICATE_QUESTION_OR_REQUIRED_ATOMS",
                duplicates=sorted(previous), semantic_distinctness_certified=False))
    return blockers


def read(root, ref):
    root = Path(root).resolve()
    path = (root / ref["path"]).resolve()
    if not path.is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest() != ref["sha256"]:
        raise ValueError("Narrative source/reference bytes changed")
    return load(path)


def write(root, relative, value):
    from .guards import require_headroom
    require_headroom(Path(root) / relative)
    if not relative.startswith(PREFIX) or ".." in Path(relative).parts:
        raise ValueError("Narrative publications require their own namespace")
    ref = put_immutable(Path(root) / relative, value)
    return dict(path=relative, sha256=ref["sha256"])


def display_record(packet, native_ref, context, *, config="llm_readings"):
    """Reuse the established decision DTO, not its old execution identity."""
    from matryoshka_demo.source_view_policy import apply_source_view, packet_policy, descriptor
    policy = packet_policy(packet)
    context = apply_source_view(context, descriptor(policy))
    case = deepcopy(packet["public_case"])
    binding = inspection._resource_binding(context, packet["case"])
    record = dict(version="narrative-condition-projection/1", case=deepcopy(packet["case"]),
        config=config, run_id="narrative_" + digest(packet)[:24], plan=deepcopy(packet["plan"]),
        result=deepcopy(packet["result"]), registry_ref=deepcopy(context.registry_ref),
        index_ref=deepcopy(context.index_ref), resource_binding=current_planning.validate_registry(
            context.registry, context.index_ref, packet["case"]),
        native_checksum=digest(packet["result"]), sha256=digest(packet),
        native_checkpoint=native_ref, current_resource_execution=True,
        configuration=deepcopy(packet.get("configuration", {})))
    # The established assertion projection checks source quotations again. Red
    # has already saved the same scoped candidate gate during local execution.
    if case["task"] != "redaction":
        gate = reporting.derive(record, context.registry, context.source_index)
        original_gate_sha256 = digest(gate)
        whole_query = packet["result"].get("query_requirements", {}).get("complete") is True
        restricted = not whole_query and gate["overall"]["status"] == "evidence_backed_suggestion"
        if restricted:
            # The legacy wire's all-atomic-certificates fallback cannot repair
            # a missing join or unresolved material counter in the native run.
            gate["overall"].update(status="partial_grounding", coverage="Partial")
            for check in gate["overall"].get("checklist", []):
                if check.get("id") == "query_coverage":
                    check.update(state="missing", detail="The native whole-query scope remains incomplete; atomic support does not close its joins or counter scope.")
        gate["narrative_scope_projection"] = dict(version="narrative-native-scope-projection/1",
            original_projection_sha256=original_gate_sha256, native_query_scope_complete=whole_query,
            conservative_restriction_applied=restricted, native_atom_judgments_changed=False)
    else:
        units = {c["id"]: deepcopy(c["local_decision"]) for r in record["result"]["readings"]
            for c in r["candidates"]}
        overview = {}
        for row in record["result"]["readings"]:
            backed = [c["id"] for c in row["candidates"]
                if units[c["id"]]["status"] == "evidence_backed_suggestion"]
            overview[row["reading"]["id"]] = dict(status="evidence_backed_suggestion" if backed else
                "exploratory_contextual", recommended_candidate_ids=backed, evidence_backed_candidates=backed,
                candidate_count=len(row["candidates"]), abstain_from_factual_recommendation=not bool(backed))
        gate = dict(version=reporting.VERSION, case_id=case["case_id"], task="redaction", config=config,
            query_sha256=digest(case["query"]), resource_binding=binding, derived=True,
            frozen_native_unchanged=True, keys_read=False, grades_read=False, model_calls=0,
            candidates=units, atoms={}, decisions=list(units.values()), reading_overviews=overview,
            overall=dict(status="evidence_backed_suggestion" if any(v["recommended_candidate_ids"]
                for v in overview.values()) else "exploratory_contextual"),
            binding=dict(case_id=case["case_id"], query_sha256=digest(case["query"]), config=config,
                native_run_id=record["run_id"], native_checksum=record["native_checksum"],
                resource_binding_sha256=digest(binding)))
    record["case"] = case
    gate["task"] = case["task"]
    for unit in gate.get("decisions", []):
        unit["task"] = case["task"]
    record.update(local_decisions_v65=gate, display_projection_only=True, resource_binding=binding,
        native_record_sha256=record.pop("sha256"), task_compatibility=deepcopy(packet["compatibility"]))
    record["plan"]["slot_readings"] = [deepcopy(r["reading"]) for r in record["result"].get("readings", [])]
    for row in record["plan"]["slot_readings"]:
        row.setdefault("form", row.get("outer_family", "unknown"))
    record["plan"]["leads"] = []
    record["result"]["retrieval"] = deepcopy(packet["retrieval"])
    record["result"].pop("_candidate_audit", None)
    record["result"]["flow_targets"] = [dict(id=a["id"], atom_id=a["id"], fill=a["text"],
        label=a["text"], sources=[e["citation"] for e in a.get("evidence", []) if "citation" in e])
        for a in record["result"].get("atoms", []) if a.get("evidence")]
    record["result"]["task"] = case["task"]
    return dict(case=case, resource_binding=binding, selected_arm=config,
        configurations={config: record}, presentation_pipeline_version=VERSION)


def _release_case_gate(case, result, collection, review):
    """Check observable per-case gates; independent semantic review is also required."""
    if collection not in {"starter", "bench", "additional_real_redaction"}:
        return "UNKNOWN_RELEASE_COLLECTION"
    if case["task"] == "redaction":
        if not review or review.get("correctness") not in {"CORRECT", "EQUIVALENT"}:
            return "INDEPENDENT_EXACT_OR_EQUIVALENT_RECOVERY_REQUIRED"
        readings = result.get("readings", [])
        if any(len(r.get("candidates", [])) > 5 for r in readings):
            return "PER_READING_DISPLAY_CAP_EXCEEDED"
        candidates = [c for r in readings if r["reading"]["id"] == review.get("reading_id")
            for c in r["candidates"] if c["id"] == review.get("candidate_id")]
        if len(candidates) != 1 or candidates[0].get("rank") != review.get("rank"):
            return "REVIEW_READING_CANDIDATE_OR_RANK_MISMATCH"
        candidate = candidates[0]
        if not 1 <= candidate["rank"] <= 5:
            return "CORRECT_FILL_NOT_IN_DISPLAYED_TOP_FIVE"
        if collection == "starter" and (candidate["rank"] != 1 or
                candidate["local_decision"]["status"] != "evidence_backed_suggestion"):
            return "STARTER_REQUIRES_EVIDENCE_BACKED_RANK_ONE"
        return None
    if collection == "additional_real_redaction":
        return "EXTRAS_MUST_BE_AUTHENTIC_REDACTIONS"
    required = [a for a in result.get("atoms", []) if a.get("required")]
    if (not required or type(result.get("overall", {}).get("required_atoms")) is not int
            or result["overall"]["required_atoms"] != len(required)
            or len({a["id"] for a in required}) != len(required)):
        return "REQUIRED_ATOM_DENOMINATOR_MISMATCH"
    if case["task"] == "hypothesis":
        if result.get("status") not in {"SUPPORTED", "OPPOSED"}:
            return "DEFINITIVE_NATIVE_HYPOTHESIS_VERDICT_REQUIRED"
        if result["status"] == "SUPPORTED" and any(a.get("criterion_state") != "SUPPORTED" for a in required):
            return "SUPPORTED_HYPOTHESIS_HAS_UNESTABLISHED_REQUIRED_CONTENT"
        if result["status"] == "OPPOSED" and not any(a.get("counterevidence") for a in required):
            return "OPPOSED_HYPOTHESIS_HAS_NO_SIGNED_COUNTER"
        if collection == "bench" and sum(a.get("criterion_state") not in {
                "SUPPORTED", "OPPOSED", "CONFLICTED"} for a in required) > 1:
            return "BENCH_HYPOTHESIS_HAS_TOO_MANY_UNRESOLVED_ATOMS"
        if collection == "starter" and result["status"] == "OPPOSED":
            counter = (review or {}).get("counterhypothesis") or {}
            inverted, unchanged = counter.get("inverted_atom_ids", []), counter.get("unchanged_atom_ids", [])
            by_id = {a["id"]:a for a in required}
            if (counter.get("deliberately_inverted") is not True
                    or not counter.get("original_proposition")
                    or counter.get("altered_proposition") != case["query"]
                    or counter.get("original_proposition") == case["query"]
                    or not inverted or len(inverted + unchanged) != len(set(inverted + unchanged))
                    or set(inverted + unchanged) != set(by_id)
                    or any(by_id[i].get("criterion_state") != "OPPOSED" for i in inverted)
                    or any(by_id[i].get("criterion_state") != "SUPPORTED" for i in unchanged)):
                return "STARTER_OPPOSITION_REQUIRES_EXPLICIT_VERIFIED_COUNTERHYPOTHESIS"
        return None
    documents = {e["citation"]["document_id"] for a in required for e in a.get("positive_evidence", [])
        if e.get("citation")}
    if len(documents) < 2:
        return "MOSAIC_REQUIRES_COMPLEMENTARY_DISTINCT_DOCUMENTS"
    missing = sum(a.get("criterion_state") != "SUPPORTED" for a in required)
    complete = (result.get("status") == "EVIDENCE_BACKED_RECONSTRUCTION" and missing == 0
        and result.get("query_requirements", {}).get("complete") is True
        and result.get("overall", {}).get("joint_bindings_established") is True)
    if not complete and not (collection == "bench" and missing == 1 and
            not any(a.get("counterevidence") for a in required)):
        return "MOSAIC_COMPLETION_GATE_NOT_MET"
    return None


def _primary_nine_requirements(cases, native_results, counts):
    """Explicit nine-primary/five-authentic-extra scope, not legacy bench rules."""
    groups = {name:[r for r in cases if r["collection"] == name]
        for name in ("starter", "bench", "additional_real_redaction")}
    starters, extras = groups["starter"], groups["additional_real_redaction"]
    inventory = ([len(groups[n]) for n in groups] == [9, 0, 5]
        and len(cases) == 14 and all(n == 1 for (collection, _, _), n in counts.items()
            if collection == "starter")
        and all(r["case"]["corpus"] == "cib" and r["case"]["task"] == "redaction" for r in extras))
    pending = [] if inventory else ["EXACT_NINE_STARTERS_ZERO_BENCH_FIVE_CIB_EXTRAS_PENDING"]

    def distinct_strings(values, expected):
        return (len(values) == expected and all(isinstance(v, str) and v.strip() for v in values)
            and len(set(values)) == expected)

    redactions = [r for r in cases if r["case"]["task"] == "redaction"]
    if not distinct_strings([(r.get("showcase_review") or {}).get("target_identity")
            for r in redactions], 8):
        pending.append("EIGHT_DISTINCT_SOURCE_BOUND_REDACTION_TARGETS_PENDING")
    primary_red = [r for r in starters if r["case"]["task"] == "redaction"]
    if (not distinct_strings([r.get("source_target_id") for r in extras], 5)
            or not distinct_strings([r.get("family_id") for r in extras], 5)
            or any(r.get("query_kind") != "authentic_paired_redaction"
                or r.get("reference_answer_kind") not in {
                    "paired_release_reveal", "paired_earlier_redacted_later_revealed"} for r in extras)
            or any(r.get(key) and r[key] == extra.get(key)
                for key in ("source_target_id", "family_id") for r in primary_red for extra in extras)):
        pending.append("FIVE_DISTINCT_AUTHENTIC_CIB_REDACTION_EXTRAS_PENDING")
    stories = []
    for corpus in ("iran", "vietnam", "cib"):
        rows = [r for r in starters if r["case"]["corpus"] == corpus]
        names = [r["narrative_id"] for r in rows]
        if (len(rows) != 3 or {r["case"]["task"] for r in rows} != {"mosaic", "hypothesis", "redaction"}
                or not all(isinstance(n, str) and n.strip() for n in names) or len(set(names)) != 1):
            pending.append("THREE_COHERENT_PRIMARY_CORPUS_TRIOS_PENDING")
            break
        stories.append(names[0])
    if len(stories) == 3 and len(set(stories)) != 3:
        pending.append("THREE_COHERENT_PRIMARY_CORPUS_TRIOS_PENDING")
    mosaics = [native_results[r["case"]["case_id"]] for r in starters if r["case"]["task"] == "mosaic"]
    if len(mosaics) != 3 or not all(r.get("status") == "EVIDENCE_BACKED_RECONSTRUCTION"
            and r.get("query_requirements", {}).get("complete") is True
            and r.get("overall", {}).get("joint_bindings_established") is True for r in mosaics):
        pending.append("THREE_COMPLETE_PRIMARY_MOSAICS_PENDING")
    return inventory, pending


def publish(root, items, *, investigations, expected_count=None, pdf_catalog_ref=None,
            release_scope="diagnostic", presentation_context=None, privacy_contract=None,
            presentation_tours=None, release_profile=None):
    """Explicit refs only. Omitted count defaults to legacy 18 or primary_nine 14.

    An explicit expected_count remains authoritative for either profile.
    Omit release_profile to retain the legacy diagnostic/18+5 qualified gates.
    """
    if release_profile not in {None, "primary_nine"}:
        raise ValueError("Unknown narrative release profile")
    if expected_count is None:
        expected_count = 14 if release_profile == "primary_nine" else 18
    cases, blockers, entries, native_results, primary_case_qualified = [], [], [], {}, {}
    ids = set()
    for item in items:
        condition = read(root, item["condition_ref"])
        c = condition["case"]
        if c["case_id"] in ids:
            raise ValueError("One explicit item per showcase question")
        ids.add(c["case_id"])
        review = item.get("showcase_review")
        native = read(root, item["native_checkpoint"])
        identity_binding = None
        if release_scope == "qualified" or release_profile == "primary_nine":
            identity_binding = _native_public_case_binding(c, native, item["native_checkpoint"])
            if identity_binding["state"] != "PASS":
                blockers.append(dict(case_id=c["case_id"], reason="NATIVE_PUBLIC_CASE_BINDING_NOT_VERIFIED",
                    binding_issues=deepcopy(identity_binding["issues"])))
        entries.append((c, native))
        result = native["result"]
        native_results[c["case_id"]] = result
        useful = (any(r.get("candidates") for r in result.get("readings", [])) if c["task"] == "redaction"
            else any(a.get("positive_evidence") or a.get("counterevidence") for a in result.get("atoms", [])))
        if not useful:
            blockers.append(dict(case_id=c["case_id"], reason="NO_SIGNED_COMPONENT_OR_SOURCE_GROUNDED_FILL"))
        if review is not None and review.get("native_checksum") != digest(native["result"]):
            raise ValueError("Showcase review belongs to another native decision")
        if not review or review.get("qualified") is not True:
            blockers.append(dict(case_id=c["case_id"], reason=(review or {}).get("reason",
                "SOURCE_AND_OUTCOME_SHOWCASE_REVIEW_PENDING")))
        if release_scope == "qualified" or release_profile == "primary_nine":
            reason = _release_case_gate(c, result, item["collection"], review)
            if reason and release_scope == "qualified":
                blockers.append(dict(case_id=c["case_id"], reason=reason))
            if release_profile == "primary_nine":
                primary_case_qualified[c["case_id"]] = (reason is None and useful
                    and (review or {}).get("qualified") is True
                    and identity_binding is not None and identity_binding["state"] == "PASS")
        row = dict(case=deepcopy(c), resource_binding=condition["resource_binding"],
            current_resource_execution=True, selected_demo=item["collection"] == "starter",
            selected_bench=item["collection"] == "bench", presentation_title=item["title"],
            collection=item["collection"], selected_additional=item["collection"] == "additional_real_redaction",
            narrative_id=item["narrative_id"], configurations=deepcopy(item["configurations"]),
            origin_refs=deepcopy(item["origin_refs"]), reference_answer_kind=item.get("reference_answer_kind"),
            query_kind=item.get("query_kind", "source_derived"),
            query_version=item.get("query_version"),
            presentation_caveats=deepcopy(item.get("presentation_caveats", [])),
            showcase_review={k:deepcopy(v) for k,v in (review or {}).items() if k in {
                "qualified", "native_checksum", "correctness", "reading_id", "candidate_id", "rank",
                "assessment_ref", "counterhypothesis", "target_identity"}},
            reporting_profile=deepcopy(item.get("reporting_profile")))
        if identity_binding is not None:
            row["native_public_case_binding"] = identity_binding
        for name in ("source_target_id", "family_id"):
            if item.get(name) is not None:
                row[name] = deepcopy(item[name])
        configurations = condition.get("configurations", {})
        if configurations:
            from .sidebar import summarize
            names = sorted(configurations)
            summaries = summarize(root,
                [(c,configurations[name]) for name in names])
            row["decision_summary_by_arm"] = dict(zip(names,summaries))
        cases.append(row)
    blockers.extend(duplicate_questions(entries))
    counts = {(collection, corpus, task): sum(r["selected_demo" if collection == "starter" else "selected_bench"]
        and r["case"]["corpus"] == corpus and r["case"]["task"] == task for r in cases)
        for collection in ("starter", "bench") for corpus in ("iran", "vietnam", "cib")
        for task in ("mosaic", "hypothesis", "redaction")}
    executed = len(cases) == expected_count and all(n == 1 for n in counts.values())
    global_pending = []
    if release_profile == "primary_nine":
        inventory, profile_pending = _primary_nine_requirements(cases, native_results, counts)
        executed = len(cases) == expected_count and inventory
        if release_scope == "qualified":
            global_pending.extend(profile_pending)
    if release_scope == "qualified" and release_profile is None:
        collections = {name:[r for r in cases if r["collection"] == name]
            for name in ("starter", "bench", "additional_real_redaction")}
        if [len(collections[n]) for n in collections] != [9, 9, 5] or not all(n == 1 for n in counts.values()):
            global_pending.append("EXACT_NINE_STARTERS_NINE_BENCH_FIVE_EXTRAS_PENDING")
        redactions = [r for r in cases if r["case"]["task"] == "redaction"]
        targets = [(r.get("showcase_review") or {}).get("target_identity") for r in redactions]
        if len(targets) != 11 or any(not isinstance(t, str) or not t for t in targets) or len(set(targets)) != len(targets):
            global_pending.append("ELEVEN_DISTINCT_SOURCE_BOUND_REDACTION_TARGETS_PENDING")
        bench_red = [r for r in collections["bench"] if r["case"]["task"] == "redaction"]
        first = [r for r in bench_red if (r.get("showcase_review") or {}).get("rank") == 1]
        if len(first) < 2:
            global_pending.append("TWO_DISTINCT_BENCH_REDACTIONS_AT_RANK_ONE_PENDING")
        if not any(any(c["id"] == r["showcase_review"].get("candidate_id") and
                c["local_decision"]["status"] == "evidence_backed_suggestion"
                for reading in native_results[r["case"]["case_id"]].get("readings", [])
                for c in reading["candidates"]) for r in first):
            global_pending.append("EVIDENCE_BACKED_RANK_ONE_BENCH_REDACTION_PENDING")
        mosaics = [r for r in cases if r["case"]["task"] == "mosaic"]
        if sum(native_results[r["case"]["case_id"]].get("status") == "EVIDENCE_BACKED_RECONSTRUCTION"
                for r in mosaics) < 5:
            global_pending.append("FIVE_COMPLETE_CORE_MOSAICS_PENDING")
        hypotheses = [r for r in cases if r["case"]["task"] == "hypothesis"]
        altered = [r for r in hypotheses if (r.get("showcase_review") or {}).get("counterhypothesis", {}).get("deliberately_inverted") is True]
        if len(altered) != 1:
            global_pending.append("EXACTLY_ONE_DECLARED_CORE_COUNTERHYPOTHESIS_PENDING")
        if not any(any(a.get("criterion_state") == "SUPPORTED" for a in native_results[r["case"]["case_id"]].get("atoms", []))
                and any(a.get("criterion_state") == "OPPOSED" for a in native_results[r["case"]["case_id"]].get("atoms", []))
                for r in hypotheses):
            global_pending.append("SIGNED_MIXED_COMPONENT_HYPOTHESIS_PENDING")
    ready = executed and not blockers and not global_pending
    blocked_case_ids = {r["case_id"] for r in blockers}
    narratives = {}
    for row in cases:
        key = (row["collection"], row["case"]["corpus"], row["narrative_id"])
        narratives.setdefault(key, []).append(row)
    complete_chains = [dict(collection=key[0], corpus=key[1], narrative_id=key[2],
        case_ids=[r["case"]["case_id"] for r in rows]) for key, rows in narratives.items()
        if len(rows) == 3 and {r["case"]["task"] for r in rows} == {"mosaic", "hypothesis", "redaction"}
        and any(native_results[r["case"]["case_id"]].get("status") == "EVIDENCE_BACKED_RECONSTRUCTION"
            for r in rows if r["case"]["task"] == "mosaic")
        and (release_profile != "primary_nine" or key[0] == "starter" and all(
            primary_case_qualified.get(r["case"]["case_id"], False)
            and r["case"]["case_id"] not in blocked_case_ids for r in rows))]
    report = dict(version=VERSION, status="COMPLETE" if ready else "PARTIAL", cases=cases,
        completed_cases=len(cases), pending_cases=max(0, expected_count-len(cases)),
        complete_execution_grid=executed, showcase_ready=ready, quality_blockers=blockers,
        investigations=investigations, full_benchmark_launched=False, outcome_informed_demo=True,
        benchmark_accuracy=False, native_outputs_modified=False, local_execution_after_planning=True,
        no_live_api=True, selection_rule="One executed starter and distinct bench per corpus/task; outcome-informed showcase")
    if release_profile is not None:
        report.update(release_profile=release_profile,
            selection_rule="One executed starter per corpus/task and five distinct authentic CIB redaction extras; no bench scope")
    report.update(release_scope=release_scope, qualified_release_ready=release_scope == "qualified"
        and ready and bool(complete_chains), qualified_narratives=complete_chains,
        collection_wide_requirements_pending=not ready,
        collection_wide_pending_gates=global_pending,
        collection_counts={name:sum(r["collection"] == name for r in cases)
            for name in ("starter", "bench", "additional_real_redaction")})
    if presentation_context is not None:
        context = deepcopy(presentation_context)
        if context.get("presentation_only") is not True:
            raise ValueError("Historical introductions must be explicitly presentation-only")
        sources = dict(version="narrative-presentation-context-sources/1", presentation_only=True,
            corpora={k:dict(citations=v.pop("citations", [])) for k,v in context.get("corpora", {}).items()},
            narratives={k:dict(citations=v.pop("citations", [])) for k,v in context.get("narratives", {}).items()})
        source_ref = write(root, PREFIX + "context_sources_" + digest(sources)[:24] + ".json.gz", sources)
        for group in (context.get("corpora", {}), context.get("narratives", {})):
            for value in group.values():
                value["sources_ref"] = deepcopy(source_ref)
        report["presentation_context"] = context
        report["presentation_context_sources_ref"] = source_ref
    if presentation_tours is not None:
        report["presentation_tours"] = deepcopy(presentation_tours)
    if release_scope == "qualified" and privacy_contract is None:
        raise ValueError("Qualified saved stories require an explicit attempt/privacy contract")
    if privacy_contract is not None:
        expected_stories = {r["narrative_id"] for r in cases}
        actual_stories = privacy_contract.get("story_case_ids", {})
        if (privacy_contract.get("version") != "narrative-story-attempts/1"
                or privacy_contract.get("require_story_attempts_before_privileged_sources") is not True
                or set(actual_stories) != expected_stories
                or any(not isinstance(values, list) or not values or len(values) != len(set(values))
                    or set(values) != {r["case"]["case_id"] for r in cases if r["narrative_id"] == name}
                    for name, values in actual_stories.items())):
            raise ValueError("Story attempt/privacy binding changed")
        report["privacy_contract"] = deepcopy(privacy_contract)
    report["distinctness_screen"] = dict(version="narrative-question-duplicate-screen/1",
        normalized_public_text=True, identical_required_atom_sets=True,
        semantic_distinctness_requires_source_review=True)
    if pdf_catalog_ref is not None:
        read(root, pdf_catalog_ref)
        report["pdf_catalog_ref"] = deepcopy(pdf_catalog_ref)
    report["run_id"] = "narrative_publication_" + digest(report)[:24]
    report["sha256"] = digest(report)
    return write(root, PREFIX + report["run_id"] + "/report.json", report)
