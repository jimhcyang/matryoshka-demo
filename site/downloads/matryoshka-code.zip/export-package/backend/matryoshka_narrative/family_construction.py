"""First-class adjunct suggestions; lexical relevance never grants factual support.

This extension fills only explicitly declared readings without a legacy
constructor. Existing nominal/adjectival judgments and candidates are untouched.
"""
from collections import Counter
from copy import deepcopy
import math

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest


VERSION = "native-source-owned-adjunct-construction/1"
SCORE_VERSION = "native-own-complement-context-fit/1"
SCOPED_VERSION = "native-source-owned-scoped-construction/2"


def _candidate_projection(candidate):
    fields = ("id", "reading_id", "declared_reading", "fill", "source_wording", "source_span",
              "insertion_edits", "sources", "source_occurrences", "final_form_fit",
              "completed_head_kind_fit", "joint_slot_fit", "local_decision")
    record = deepcopy(candidate["first_class_adjunct"])
    record.pop("candidate_projection_sha256", None)
    return dict(candidate={k:deepcopy(candidate.get(k)) for k in fields}, producer=record)


def _seal_candidate(candidate):
    # Mutation detection within a trusted native execution, not authentication
    # of an arbitrary submitted dictionary or a historical-truth certificate.
    candidate["first_class_adjunct"]["candidate_projection_sha256"] = digest(_candidate_projection(candidate))


def _context_decision(candidate):
    """A new unsupported family has no authority to assert the focal event."""
    ref = candidate["sources"][0]
    explanation = "An eligible source supplies this wording and local insertion checks pass; the focal attribution and event are not established."
    checks = [dict(id="provenance", state="pass", detail="Exact admitted source span and sentence replayed."),
              dict(id="binding", state="unmodeled", detail="Same focal actor/event attribution is not certified by this constructor."),
              dict(id="facts", state="unmodeled", detail="Lexical complement similarity is not factual entailment."),
              dict(id="conflicts", state="unmodeled", detail="No complete signed counterevidence assessment for this family."),
              dict(id="grammar", state="pass", detail="Declared local adjunct attachment passed; not full English grammar certification.")]
    return dict(version=VERSION, id=candidate["id"], reading_id=candidate["reading_id"],
                task="redaction", text=candidate["fill"], status="exploratory_contextual",
                label="Contextual suggestion", scope="FOCAL_CONTRIBUTION_ONLY",
                coverage="Missing", support_present=False, counterevidence=False,
                source_failures=[], checklist=checks,
                requirements=[dict(id="focal_contribution", kind="FOCAL_CONTRIBUTION",
                    predicate="UNMODELED", text="The proposed insertion establishes the focal contribution in its stated context.",
                    coverage="Missing", direction="Unresolved", counterevidence=False,
                    checks=deepcopy(checks[1:4]), evidence=[], context_citations=[deepcopy(ref)])],
                explanation=explanation, what_would_suffice=[
                    "Eligible evidence must bind the proposed wording to the same actor, event, attribution, polarity and qualifications as the focal input."],
                local_attachment_only=True, factual_support_certified=False,
                unmodeled_counterevidence_is_absence=False)


def candidate_score(candidate, *, case, plan, retrieval=None):
    """Report the own-clause lexical score, not a native support probability."""
    if not isinstance(case, dict) or not isinstance(plan, dict):
        raise ValueError("Adjunct scoring needs its bound public input and plan")
    record = candidate.get("first_class_adjunct")
    if (not isinstance(record, dict) or record.get("version") != VERSION
            or record.get("query_sha256") != digest(case["query"])
            or record.get("reading_sha256") != digest(candidate["declared_reading"])
            or candidate["local_decision"]["status"] != "exploratory_contextual"
            or candidate["local_decision"].get("support_present") is not False
            or candidate["local_decision"].get("counterevidence") is not False
            or candidate["local_decision"]["coverage"] != "Missing"):
        raise ValueError("Adjunct relevance cannot authorize a signed factual decision")
    if (record.get("candidate_projection_sha256") != digest(_candidate_projection(candidate))
            or candidate["local_decision"] != _context_decision(candidate)):
        raise ValueError("Adjunct producer projection or unmodeled decision changed")
    observation = record["context_order"]["best_single_occurrence"]
    query, source = set(observation["query_terms"]), set(observation["source_terms"])
    common = query & source
    coverage = len(common) / max(1, len(query))
    jaccard = len(common) / max(1, len(query | source))
    fit = .75 * coverage + .25 * jaccard
    relative = record.get("source_realization_kind")=="SOURCE_COPULAR_RELATIVE"
    if relative:
        from .context_document_idf import score_terms
        stats = record["context_document_statistics"]
        measured = score_terms(query,source,stats)
        coverage,jaccard,fit = measured["coverage"],measured["jaccard"],measured["score"]
    if (not math.isfinite(fit) or abs(fit - observation["score"]) > 1e-12
            or sorted(common) != observation["matched_terms"]):
        raise ValueError("Own-clause context arithmetic differs from its producer")
    ref = candidate["sources"][0]
    raw_span = candidate["source_span"]
    a, b = raw_span[0] - ref["start"], raw_span[1] - ref["start"]
    raw_wording = ref["text"][a:b]
    if relative:
        shape = candidate["source_occurrences"][0]["source_shape"]
        if shape["source_sentence"]!=raw_wording or candidate["source_wording"]!=raw_wording:
            raise ValueError("Relative source body does not replay in its own citation")
        generated = raw_wording
        for edit in reversed(shape["operation_license"]["replacements"]):
            lo,hi = edit["span"][0]-raw_span[0],edit["span"][1]-raw_span[0]
            if not 0<=lo<hi<=len(raw_wording) or raw_wording[lo:hi]!=edit["before"]:
                raise ValueError("Relative operation does not replay exact source coordinates")
            generated = generated[:lo]+edit["after"]+generated[hi:]
        if generated!=candidate["fill"] or shape["fill"]!=generated:
            raise ValueError("Relative generated surface changed")
        parent = shape["source_parent_quote"]
        if shape["source_parent_scope_complete"] and (
                [ref["start"],ref["end"]]!=parent["span"] or ref["text"]!=parent["text"]):
            raise ValueError("Relative assessment or whole parent qualification was clipped")
    if (not 0 <= a < b <= len(ref["text"]) or not relative and (raw_wording != candidate["fill"]
            or candidate["source_wording"] != candidate["fill"])
            or digest(ref) != record["primary_citation_sha256"]
            or candidate["final_form_fit"].get("state") != "pass"):
        raise ValueError("Adjunct score lost its exact source or syntax binding")
    # Use an explicit family-specific point scale. No observed support or
    # opposition is invented to make this look like a completed factual gate.
    return dict(version="native-source-relative-context-fit/1" if relative else SCORE_VERSION, id=candidate["id"], fill=candidate["fill"],
                score=100*fit, native_status="exploratory_contextual", evidence_tier=0,
                fit=fit, coverage=coverage, jaccard=jaccard, support=0., oppose=0.,
                context=fit, criteria_coverage=0., contributions=[dict(
                    direction="context", document_id=ref["document_id"], citation=deepcopy(ref),
                    fit=fit, contribution=fit, source_owned_lexical_context_only=True)],
                ranking_components=dict(query_coverage_points=75*coverage,
                                        source_precision_points=25*jaccard),
                score_units="OWN_CLAUSE_LEXICAL_RELEVANCE_POINTS_NOT_CONFIDENCE",
                source_function_band=None, factual_tier_applied_separately=True,
                calibrated_probability=False, factual_decisions_unchanged=True,
                formula="100*(0.75*coverage+0.25*Jaccard), one own source occurrence",
                native_support_gate_executed=False)


def extend(result, case, plan, pages, policy, parser, *, draft_budget, top_k=5, source_phrase_mode="legacy",coordinate_member_mode="legacy"):
    """Construct from the same ordinary inspected pages, never a QA witness set."""
    from . import adjunct_candidates as adjuncts
    if source_phrase_mode not in {"legacy","scoped"}:
        raise ValueError("Unknown source phrase mode")
    if coordinate_member_mode not in {"legacy","literal_source"}:
        raise ValueError("Unknown coordinate member mode")
    from . import nominal_relative,context_document_idf
    case = public_case(case)
    if result["query_sha256"] != digest(case["query"]):
        raise ValueError("Extension input/result mismatch")
    if type(draft_budget) is not int or not 1 <= draft_budget <= 128:
        raise ValueError("Adjunct compatibility check budget must be one to 128")
    if type(top_k) is not int or not 1 <= top_k <= 5:
        raise ValueError("Adjunct displayed candidate count must be one to five")
    declared = plan["readings_packet"]["readings"]
    if [r["reading"] for r in result["readings"]] != declared:
        raise ValueError("Declared reading identities must remain unchanged")
    by_page = {page["id"]: (pi, page) for pi, page in pages}
    if list(by_page) != result["inspected_page_ids"]:
        raise ValueError("Extension must reuse the exact inspected-page sequence")
    engine = adjuncts.Constructor(parser,scoped_phrases=source_phrase_mode=="scoped")
    relative_engine = nominal_relative.Constructor(parser) if source_phrase_mode=="scoped" else None
    coordinate_engine = adjuncts.CoordinateMemberConstructor(parser) if coordinate_member_mode=="literal_source" else None
    relative_profile = None
    counts, receipts, added = Counter(), [], []
    for branch in result["readings"]:
        reading = branch["reading"]
        relative = relative_engine is not None and nominal_relative.eligible(reading)
        coordinate = coordinate_engine is not None and adjuncts.coordinate_member_eligible(reading)
        if branch["constructor_reading"] is not None or not (adjuncts.eligible(reading) or relative or coordinate):
            continue
        active = relative_engine if relative else coordinate_engine if coordinate else engine
        pool = active.pool(case, reading, [page for _, page in pages], defer_compatibility=True)
        if not pool.get("compatibility_deferred") or pool.get("eager_compatibility_checks") != 0:
            raise ValueError("Adjunct enumeration must not consume unrecorded insertion checks")
        if relative:
            if relative_profile is None:
                relative_profile = context_document_idf.build_profile([p for _,p in pages],parser,
                    expected_page_ids=result["inspected_page_ids"],case=case)
            pool = context_document_idf.order_pool(pool,query_text=pool["query_context"]["text"],parser=parser,
                profile=relative_profile,case=case,reading=reading,inspected_pages=[p for _,p in pages],issuer=active)
            ranked_ids = pool["idf_context_order_ids"]
        elif coordinate:
            pool = adjuncts.coordinate_member_order(pool,case,reading,parser)
            ranked_ids = pool["context_order_ids"]
        else:
            pool = adjuncts.order(pool, case, reading, parser)
            ranked_ids = pool["context_order_ids"]
        if not pool["eligible"]:
            continue
        proposals = {p["id"]: p for p in pool["proposals"]}
        evaluated, viable = [], []
        for source_rank, identity in enumerate(ranked_ids[:draft_budget], 1):
            proposal = proposals[identity]
            order = proposal["idf_context_order"] if relative else proposal.get("context_order", proposal.get("phase_context_order"))
            best = order["best_single_occurrence"]
            if not best["matched_terms"]:
                counts["no_visible_context_match_holds"] += 1
                evaluated.append(dict(id=identity, fill=proposal["fill"], compatibility=dict(
                    state="HOLD", reason="NO_OWN_CONTEXT_CONTENT_TERM_MATCH")))
                continue
            occurrence = proposal["source_occurrences"][best["occurrence_index"]]
            compatibility = active.compatibility(case, reading, occurrence)
            counts["compatibility_checks"] += 1
            evaluated.append(dict(id=identity, fill=proposal["fill"], compatibility=compatibility))
            if compatibility["state"] != "PASS_SYNTAX_ONLY":
                counts["compatibility_holds"] += 1
                continue
            pi, page = by_page[occurrence["source_page_id"]]
            a,b = ((occurrence["source_sentence_start"],occurrence["source_sentence_end"]) if relative
                else (occurrence["source_start"], occurrence["source_end"]))
            wording = page["text"][a:b] if relative else proposal["fill"]
            if (page["text"][a:b] != wording
                    or occurrence["source_page_sha256"] != page["source_sha256"]):
                raise ValueError("Adjunct source nomination lost its exact source span")
            # A relative may partition a Comment heading for parsing, but its
            # published context must retain the assessment and later vetoes.
            parent = occurrence.get("source_parent_quote") if relative and occurrence["source_parent_scope_complete"] else None
            ca,cb = parent["span"] if parent else (occurrence["source_sentence_start"],occurrence["source_sentence_end"])
            quote = parent["text"] if parent else occurrence["source_sentence"]
            ref = policy.citation(pi,ca,cb)
            expected = dict(canonical_page_id=page["id"], document_id=page["document_id"],
                corpus=page["corpus"], date=page["date"], page_sha256=page["source_sha256"],
                start=ca, end=cb, text=quote)
            if any(ref.get(key) != value for key,value in expected.items()):
                raise ValueError("Own source sentence or citation metadata changed")
            edits = deepcopy(occurrence["operation_license"]["replacements"]) if relative else []
            saved_occurrence = dict(source_span=[a,b], source_wording=wording, citation=ref,
                                    insertion_edits=edits, features={}, source_shape=deepcopy(occurrence))
            cid = "adjunct_fill_" + digest([VERSION, case["case_id"], reading["id"],
                                           page["source_sha256"], a, b])[:28]
            candidate = dict(id=cid, reading_id=reading["id"], fill=proposal["fill"],
                source_wording=wording, source_span=[a,b], insertion_edits=edits,
                node_id=None, sources=[ref], source_occurrences=[saved_occurrence],
                source_rank_position=source_rank, declared_reading=deepcopy(reading),
                v6_reading=dict(id=reading["id"], form=reading["outer_family"],
                                role=reading["role"], target_kind=reading["target_kind"]),
                ranking=dict(features={}, calibrated_probability=False),
                alternative_family=cid,
                final_form_fit=dict(state="pass", version=adjuncts.VERSION,
                    outer_family=reading["outer_family"], inserted_span=compatibility["inserted_span"],
                    completed_query_sha256=compatibility["completed_query_sha256"],
                    local_attachment_only=True, full_english_grammar_certified=False,
                    factual_support_certified=False, compatibility=compatibility),
                completed_head_kind_fit=dict(state="pass", reason=("DECLARED_UNTYPED_COORDINATE_MEMBER_SUBSET_ONLY" if coordinate else "DECLARED_UNTYPED_RELATIVE_SUBSET_ONLY" if relative
                    else "DECLARED_UNTYPED_ADJUNCT_SUBSET_ONLY")),
                joint_slot_fit=dict(state="pass", context_only=True, factual_support_certified=False),
                support="SOURCE_WORDING_CONTEXT_ONLY",
                first_class_adjunct=dict(version=VERSION, query_sha256=digest(case["query"]),
                    reading_sha256=digest(reading), context_order=deepcopy(order),
                    nomination_id=proposal["id"], primary_citation_sha256=digest(ref),
                    syntax_certifies_factual_support=False))
            candidate["local_decision"] = _context_decision(candidate)
            if coordinate:
                candidate["first_class_adjunct"].update(constructor_kind="SOURCE_LITERAL_COORDINATE_MEMBER",
                    constructor_version=adjuncts.COORDINATE_MEMBER_VERSION,model_outer_family_preserved=True,
                    connector_is_literal_source_word=True)
            if relative:
                terms = set(best["query_terms"])|set(best["source_terms"])
                candidate["first_class_adjunct"].update(source_realization_kind="SOURCE_COPULAR_RELATIVE",
                    scoped_construction_version=SCOPED_VERSION,
                    exact_public_binding_sha256=digest(pool["public_binding"]),context_document_statistics=dict(
                        document_count=relative_profile["document_count"],
                        document_frequency={t:relative_profile["document_frequency"].get(t,0) for t in terms},
                        profile_sha256=relative_profile["profile_sha256"]))
            _seal_candidate(candidate)
            candidate["terminal_scorecard"] = candidate_score(candidate, case=case, plan=plan)
            viable.append(candidate)
            counts["contextual_candidates"] += 1
        viable.sort(key=lambda c: (-c["terminal_scorecard"]["score"], c["source_rank_position"], c["id"]))
        for rank, candidate in enumerate(viable[:top_k], 1):
            candidate["rank"] = rank
        branch["candidates"] = viable[:top_k]
        branch["first_class_constructor"] = dict(version=VERSION, factual_support_gate="UNMODELED_CONTEXT_ONLY")
        branch["shortlist_status"] = "CANDIDATE_SUGGESTIONS" if viable else "NO_SOURCE_GROUNDED_SUGGESTIONS"
        result["assessed_candidates"].extend(viable)
        added.extend(viable)
        rid = reading["id"]
        stage = dict(generated=len(proposals), allocated=min(draft_budget,len(proposals)),
            checked=len(evaluated), focal_assessed=0, gate_holds_or_rejections=len(evaluated)-len(viable),
            assessed=len(viable), eligible=len(viable), withheld=0, displayed=len(branch["candidates"]),
            withheld_candidate_ids=[])
        result["execution"]["candidate_stage_counts_by_reading"][rid] = deepcopy(stage)
        result["execution"].setdefault("checked_per_reading", {})[rid] = len(evaluated)
        if isinstance(result.get("controller_shortlist"), dict):
            result["controller_shortlist"]["counts_by_reading"][rid] = deepcopy(stage)
        receipts.append(dict(reading_id=rid, nominated=len(proposals), evaluated=evaluated,
                             source_shape_holds=pool.get("source_shape_holds", {}),
                             context_only=True, focal_gate_executed=False,
                             proposal_cap=pool.get("proposal_cap")))
    result["candidates"] = [c for branch in result["readings"] for c in branch["candidates"]]
    if result["candidates"]:
        result["status"] = "CANDIDATE_SUGGESTIONS"
    extended_ids = {r["reading_id"] for r in receipts}
    result["unsupported_readings"] = [r for r in result["unsupported_readings"] if r["reading_id"] not in extended_ids]
    result["first_class_construction"] = dict(version=VERSION, helper_version=adjuncts.VERSION,
        counts=dict(counts), reading_receipts=receipts, exact_inspected_pool_reused=True,
        source_policy_changed=False, legacy_decisions_changed=False,
        new_readings_generated=False, known_answers_used=False,
        source_span_and_syntax_are_not_focal_support=True)
    if source_phrase_mode=="scoped":
        result["first_class_construction"].update(scoped_version=SCOPED_VERSION,source_phrase_mode="scoped",
            relative_helper_version=nominal_relative.VERSION,context_profile_version=context_document_idf.VERSION)
    if coordinate_member_mode=="literal_source":
        result["first_class_construction"].update(coordinate_member_mode=coordinate_member_mode,
            coordinate_member_helper_version=adjuncts.COORDINATE_MEMBER_VERSION)
    audit = result.setdefault("_candidate_audit", {})
    audit["first_class_reading_receipts"] = deepcopy(receipts)
    audit.setdefault("checked_viable", []).extend(dict(id=c["id"], reading_id=c["reading_id"],
        fill=c["fill"], local_decision=deepcopy(c["local_decision"])) for c in added)
    result["display_budgets"]["actual_total"] = len(result["candidates"])
    shortlist = result.get("controller_shortlist")
    if isinstance(shortlist, dict):
        shortlist["assessed_count"] += len(added)
        shortlist["eligible_count"] += len(added)
        shortlist["displayed_count"] = len(result["candidates"])
    return result
