"""Source-cited reconstruction, separately from hypothesis/world-truth coverage.

Only explicit input pages and source-local objects are used. Linguistic engines
and immutable role-boundary helpers are reused, never their registry loaders,
evaluate functions, saved decisions or inferred alias/rank authority.
"""
from collections.abc import Mapping
from copy import deepcopy
from datetime import date
from numbers import Integral
import re

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import scope_matching as linguistic
from matryoshka_demo_v61 import role_alignment
from matryoshka_demo_v6 import planning as literal
from matryoshka_demo_v6 import reporting_local_decisions_v65 as provenance
from matryoshka_demo_v6 import reporting_role_identification_prototype_v2 as roles
from matryoshka_demo_v6 import reporting_fixed_pool_role_projection_v2 as past_roles
from . import planning


VERSION = "current-source-reconstruction-assembly/1.3"
SourceEngine = linguistic.Engine
FIELDS = provenance.FIELDS
BACKED = "EVIDENCE_BACKED_RECONSTRUCTION"
PARTIAL = "PARTIAL_RECONSTRUCTION"
CONFLICTED = "CONFLICTED_RECONSTRUCTION"
UNRESOLVED = "UNRESOLVED_RECONSTRUCTION"
_DEICTIC = re.compile(r"\b(?:today|yesterday|tomorrow|now|currently|recently|soon|ago)\b|\b(?:last|next|this)\s+(?:week|month|year|day)\b", re.I)


def _normal(text):
    return " ".join(text.casefold().split())


def _check_all(reason):
    return [dict(id=key, state="pass", detail=reason) for key in FIELDS]


def _citation(page, start, end, index, case):
    value = provenance._citation(page, start, end)
    provenance._quote(value, *index, case)
    return value


def _sources(case, retrieval, source_index):
    pages, masks, veto = provenance._pages(source_index, case)
    veto = set(veto)
    for page in pages.values():
        # Public CIB release eligibility is not the cable classification policy.
        if case["corpus"] != "cib" and (re.search(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM", page["text"], re.I)
                or any(re.search(r"NOFORN|NO\s+FOREIGN\s+DISSEM", str(h), re.I)
                       for h in page.get("handling", []))):
            veto.add(page["document_id"])
    index = pages, masks, veto
    budget = retrieval.get("passage_budget", 100)
    if type(budget) is not int or budget < 1:
        raise ValueError("Positive explicit source inspection budget required")
    if "inspected_page_ids" in retrieval:
        ids = retrieval["inspected_page_ids"]
        if not isinstance(ids, list) or retrieval.get("source_pages_inspected") != len(ids):
            raise ValueError("Exact inspected-source count required")
        corpus = None
    else:
        corpus = retrieval["eligible"].corpus
        positions = retrieval["pages"][:budget]
        if any(not isinstance(pi, Integral) or isinstance(pi, bool) for pi in positions):
            raise ValueError("Only explicit retrieved page indices are accepted")
        ids = [corpus.pages[int(pi)]["id"] for pi in positions]
    if (any(not isinstance(pid, str) for pid in ids) or len(ids) != len(set(ids))
            or len(ids) > budget):
        raise ValueError("Duplicate or over-budget inspected pool")
    admitted = {}
    for pid in ids:
        if pid not in pages:
            raise ValueError("Inspected page absent from explicit source index")
        page = pages[pid]
        if page.get("visibility") not in {"earlier", "both"}:
            raise ValueError("Inspected source needs explicit earlier-release visibility")
        _citation(page, 0, len(page["text"]), index, case)
        if corpus is not None:
            original = corpus.pages[corpus.page_index[pid]]
            if any(original[k] != page[k] for k in ("text", "document_id", "date", "source_sha256")):
                raise ValueError("Retrieval and source-index bytes differ")
        admitted[pid] = page
    return index, admitted, ids, budget


def _groups(groups, admitted, case, index):
    """No files or generated labels are opened to complete a missing group."""
    if groups is None:
        return {}
    if not isinstance(groups, Mapping) or set(groups) - set(admitted):
        raise ValueError("Source-local groups must belong to inspected pages")
    result = deepcopy(dict(groups))
    for pid, values in result.items():
        if not isinstance(values, list):
            raise ValueError("Page-keyed source-local object lists required")
        for group in values:
            if public_case(group["case"]) != case:
                raise ValueError("Source-local group belongs to another public case")
            role_alignment._source_context(admitted[pid], group["objects"], group["scope"], case)
            for obj in group["objects"]:
                provenance._quote(obj["citation"], *index, case)
    return result


def _prefix(page, start, engine):
    text = page["text"][:start]
    if literal._open_reporting_context(text):
        return "OPEN_SOURCE_QUOTE_OR_REPORT_SCOPE"
    _, reason = roles._outer_scope(text, engine)
    return reason


def _tense(token):
    verbs = [token, *[c for c in token.children if c.dep_ in {"aux", "auxpass", "cop"}]]
    return tuple(sorted({value for t in verbs for value in t.morph.get("Tense")}))


def _frame_tense(text, raw_start, engine):
    view, offsets, _ = engine.source_view(text)
    for token in engine.parse(view):
        if (offsets[token.idx] if offsets is not None else token.idx) == raw_start:
            return _tense(token)
    return None


def _structure(text, engine):
    """Ordered dependency certificate, not a lemma bag or an entailment model."""
    doc = engine.parse(text)
    tokens = [t for t in doc if not t.is_space and not t.is_punct]
    lexical = [t for t in tokens if not (t.dep_ == "neg" or t.dep_ == "aux" and t.lemma_.casefold() == "do")]
    positions = {t.i:i for i, t in enumerate(lexical)}
    nodes = []
    for t in lexical:
        head = t.head
        while head.i not in positions and head != head.head:
            head = head.head
        nodes.append((t.lemma_.casefold(), t.dep_, positions.get(head.i, -1), _tense(t)))
    negation = sorted((positions.get(t.head.i, -1), t.lower_) for t in tokens if t.dep_ == "neg")
    roots = [t for t in tokens if t.dep_ == "ROOT"]
    finite = bool(roots) and all(t.tag_ in {"VBD", "VBP", "VBZ"} or any(
        c.dep_ in {"aux", "auxpass", "cop"} and c.tag_ in {"VBD", "VBP", "VBZ"} for c in t.children) for t in roots)
    unresolved = [t.text for t in tokens if t.pos_ == "PRON" or t.lower_ in {"if", "unless", "whether"}]
    operators = []
    for t in tokens:
        if any(c.dep_ in {"ccomp", "xcomp"} for c in t.children):
            subjects = [c for c in t.children if c.dep_ in {"nsubj", "nsubjpass"}]
            holders = [x for c in subjects for x in c.subtree if not x.is_punct and not x.is_space]
            if (not subjects or not any(h.pos_ == "PROPN" for h in holders)
                    or any(c.dep_ == "det" for subject in subjects for c in subject.children)):
                unresolved.append("UNBOUND_OPERATOR_HOLDER")
            operators.append(dict(predicate=t.lemma_.casefold(), text=t.text, start=t.idx,
                end=t.idx+len(t), holder_text=" ".join(x.text for x in holders),
                content_complete=True, inner_event_established=False))
    if re.search(r'"|[\u201c\u201d]|(?<!\w)[\x27\u2018]', text) and not operators:
        unresolved.append("QUOTATION_WITHOUT_COMPLETE_BOUND_HOLDER")
    if not operators:
        for subject in (t for t in tokens if t.dep_ in {"nsubj", "nsubjpass"}):
            if (any(c.dep_ == "det" and c.lower_ == "the" for c in subject.children)
                    and not any(t.pos_ == "PROPN" for t in subject.subtree)):
                unresolved.append("UNBOUND_DEFINITE_SOURCE_REFERENT")
    return dict(nodes=nodes, negation=negation, finite=finite, unresolved=unresolved,
        operators=operators, tokens=[dict(text=t.text, lemma=t.lemma_.casefold(), start=t.idx,
            end=t.idx+len(t), dependency=t.dep_, head_start=t.head.idx) for t in tokens],
        deictic=bool(_DEICTIC.search(text)), main_predicates=[dict(text=t.text, lemma=t.lemma_.casefold(),
            start=t.idx, end=t.idx+len(t), dependency=t.dep_) for t in roots])


def _raw_match(text, page, unit, engine, index, case, *, target=None):
    target = target if target is not None else _structure(text, engine)
    source = _structure(unit["text"], engine)
    if not target["finite"] or not source["finite"] or target["nodes"] != source["nodes"]:
        return None
    problems = list(dict.fromkeys(target["unresolved"] + source["unresolved"]))
    scope = _prefix(page, unit["start"], engine)
    if scope:
        problems.append(scope)
    if target["deictic"] or source["deictic"]:
        problems.append("DEICTIC_EVENT_CLOCK_NOT_BOUND")
    same = target["negation"] == source["negation"]
    # Reported opposite content is not denial that the holder uttered P.
    roots = {i for i, node in enumerate(target["nodes"]) if node[1] == "ROOT"}
    counter = (not same and not target["operators"] and not source["operators"]
        and all(position in roots for position, _ in target["negation"] + source["negation"]))
    direction = "CONTEXT" if problems or not same and not counter else "SUPPORT" if same else "COUNTER"
    checks = _check_all("Complete ordered raw clause and dependency roles replay; source assertion only.")
    if counter:
        next(c for c in checks if c["id"] == "polarity").update(state="conflict", detail="Same complete unqualified clause with opposite explicit negation.")
    if problems:
        for check in checks:
            if check["id"] in {"attribution", "event_date"}:
                check.update(state="missing", detail="; ".join(problems))
    return dict(direction=direction, checks=checks,
        citations=[_citation(page, unit["start"], unit["end"], index, case)],
        certificate=dict(kind="COMPLETE_ORDERED_RAW_CLAUSE", target=target, source=source,
            same_negation_scope=same, whole_content_matched=True, source_qualifications_retained=True),
        blockers=problems, source_assertion_not_world_truth=True,
        actual_inner_event_established=False if target["operators"] else None)


_ACCOUNT = re.compile(r"(?P<article>A|The)\s+statement(?P<qualification>\s+issued\s+"
    r"(?P<mode>on behalf of|by)\s+(?P<holder>.+?))?\s+says\s+that\s*,?\s*"
    r"(?P<content>.+?)\s*[.]?\s*\Z", re.I | re.S)


def _literal_holder(text, engine):
    tokens = [t for t in engine.parse(text) if not t.is_space]
    if (not tokens or any(t.is_punct or t.pos_ not in {"NOUN", "PROPN", "DET", "ADJ", "NUM", "ADP", "CCONJ"}
            or t.lower_ in {"if", "unless", "whether", "not", "no"} for t in tokens)
            or not any(t.pos_ in {"NOUN", "PROPN"} for t in tokens)):
        return None
    return tuple(t.lower_ for t in tokens)


def _account_queries(plan, engine):
    """One explicit public antecedent; no inferred person or artifact identity."""
    parsed = [(atom, _ACCOUNT.fullmatch(atom["text"])) for atom in plan["atoms"]]
    antecedents = [(a, m) for a, m in parsed if m and m["qualification"]
                   and m["article"].casefold() == "a"]
    if len(antecedents) != 1 or any(not m and re.search(r"\bstatement\b", a["text"], re.I)
                                  for a, m in parsed):
        return {}
    first, explicit = antecedents[0]
    if any(m and a is not first and (m["qualification"] or m["article"].casefold() != "the")
           for a, m in parsed):
        return {}
    holder = _literal_holder(explicit["holder"], engine)
    if holder is None:
        return {}
    result = {}
    for atom, match in parsed:
        if (not match or atom["start"] < first["start"]
                or atom is not first and (match["qualification"] or match["article"].casefold() != "the")):
            continue
        result[atom["id"]] = dict(content=match["content"],
            content_start=match.start("content"), holder=holder, mode=explicit["mode"].casefold(),
            antecedent=dict(atom_id=first["id"], start=first["start"],
                end=first["start"]+explicit.end("qualification"),
                text=first["text"][:explicit.end("qualification")]),
            matrix=dict(predicate="say", subject="statement", polarity="positive",
                raw_text=atom["text"][:match.start("content")]))
    return result


def _content_signature(tokens, root, overrides=None):
    overrides = overrides or {}
    kept = [t for t in tokens if not t.is_space and not t.is_punct]
    if (not kept or any(t.pos_ == "PRON" for t in kept)
            or any(t.text in {'"', "\u201c", "\u201d", ":", ";", "?"} for t in tokens)
            or _DEICTIC.search(" ".join(t.text for t in kept))):
        return None
    positions = {t.i:i for i, t in enumerate(kept)}
    rows = []
    for token in kept:
        head, dep = overrides.get(token.i, (token.head.i, token.dep_))
        if token == root:
            head, dep = token.i, "ROOT"
        if head not in positions:
            return None
        features = tuple(sorted((k, v) for k, v in token.morph.to_dict().items()
            if k in {"Number", "Degree", "Tense", "Aspect", "Voice", "VerbForm", "Mood", "Person"}))
        rows.append((token.lemma_.casefold(), dep, positions[head], _tense(token), features))
    return rows


def _content_views(text, engine):
    """Whole propositions, plus conservative explicit-AND clause projection.

    Inherited subject and initial as-reporting adjunct remain raw token proofs.
    Root negation/modality and other shared adjuncts block distribution entirely.
    """
    doc = engine.parse(text)
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1 or MASK.search(text):
        return []
    root = roots[0]
    finite = lambda t: t.tag_ in {"VBD", "VBP", "VBZ"} or any(
        c.dep_ in {"aux", "auxpass", "cop"} and c.tag_ in {"VBD", "VBP", "VBZ"} for c in t.children)
    if not finite(root):
        return []
    def proof(token):
        return dict(text=token.text, start=token.idx, end=token.idx+len(token),
            dependency=token.dep_, head_start=token.head.idx)
    result = []
    signature = _content_signature(list(doc), root)
    if signature is not None:
        result.append(dict(signature=signature, tokens=[proof(t) for t in doc if not t.is_space],
            inherited=[], omitted_coordinate_predicates=[], projection="WHOLE_PRINTED_PROPOSITION"))
    conjuncts = [c for c in root.children if c.dep_ == "conj"]
    cc = [c for c in root.children if c.dep_ == "cc"]
    if (not conjuncts or len(cc) != 1 or cc[0].lower_ != "and"
            or any(not finite(c) or any(x.dep_ in {"conj", "cc"} for x in c.children) for c in conjuncts)
            or any(c.dep_ in {"neg", "aux", "auxpass", "advmod", "prep"} for c in root.children)):
        return result
    subjects = [c for c in root.children if c.dep_ in {"nsubj", "nsubjpass"}]
    adjuncts = [c for c in root.children if c.dep_ == "advcl"]
    if len(subjects) != 1 or len(adjuncts) > 1:
        return result
    if adjuncts:
        adjunct = adjuncts[0]
        if (adjunct.idx >= subjects[0].idx or adjunct.lemma_.casefold() not in {"say", "state", "report"}
                or not any(c.dep_ == "mark" and c.lower_ == "as" for c in adjunct.children)
                or not any(c.dep_ == "agent" and c.lower_ == "by" for c in adjunct.children)
                or any(c.dep_ == "neg" or c.tag_ == "MD" for c in adjunct.subtree)):
            return result
    branches = [root, *conjuncts]
    for selected in branches:
        excluded = {t.i for branch in conjuncts for t in branch.subtree} | {c.i for c in cc}
        if selected == root:
            tokens = [t for t in doc if t.i not in excluded]
            overrides, inherited = {}, []
        else:
            tokens = list(selected.subtree)
            overrides, inherited = {}, []
            own_subject = [c for c in selected.children if c.dep_ in {"nsubj", "nsubjpass"}]
            if not own_subject:
                tokens.extend(subjects[0].subtree)
                overrides[subjects[0].i] = (selected.i, subjects[0].dep_)
                inherited.append(dict(kind="EXPLICIT_AND_SHARED_SUBJECT", tokens=[proof(t) for t in subjects[0].subtree],
                    from_predicate=proof(root), to_predicate=proof(selected)))
            if adjuncts:
                if any(c.dep_ == "advcl" for c in selected.children):
                    continue
                tokens.extend(adjuncts[0].subtree)
                overrides[adjuncts[0].i] = (selected.i, "advcl")
                inherited.append(dict(kind="INITIAL_AS_REPORTING_SCOPE_OVER_AND", tokens=[proof(t) for t in adjuncts[0].subtree],
                    from_predicate=proof(root), to_predicate=proof(selected)))
        tokens = sorted({t.i:t for t in tokens}.values(), key=lambda t:t.i)
        signature = _content_signature(tokens, selected, overrides)
        if signature is not None:
            result.append(dict(signature=signature, tokens=[proof(t) for t in tokens if not t.is_space],
                inherited=inherited, omitted_coordinate_predicates=[proof(t) for t in branches if t != selected],
                projection="EXPLICIT_AND_COMPLETE_CLAUSE"))
    return result


def _statement_binding(text, wanted, engine):
    """Only a whole unqualified, completed issuance matrix can bind an issuer."""
    text = re.sub(r"^\s*\d+[.)]\s*", "", text).strip()
    passive = re.fullmatch(r"(?:The following|The|This)\s+(?:policy\s+)?statement\s+"
        r"(?:was|is|has been)\s+issued\s+(?P<mode>on behalf of|by)\s+(?P<holder>.+?)\s*[:.]?", text, re.I | re.S)
    active = re.fullmatch(r"(?P<holder>.+?)\s+(?:issued|has issued)\s+the\s+following\s+statement\s*:", text, re.I | re.S)
    match = passive or active
    if match is None:
        return None
    holder = _literal_holder(match["holder"].rstrip(".: "), engine)
    mode = passive["mode"].casefold() if passive else "by"
    if holder != tuple(wanted["holder"]) or mode != wanted["mode"]:
        return None
    doc = engine.parse(text)
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1 or roots[0].lemma_.casefold() != "issue":
        return None
    if any(t.dep_ == "neg" or t.tag_ == "MD" or t.lower_ in {"if", "unless", "whether"} for t in doc):
        return None
    return dict(mode=mode, literal_holder=list(holder), whole_unqualified_issuance_matrix=True,
        person_identity_inferred=False, requested_or_future_issuance_used=False)


def _statement_issuer_denial(text, wanted, engine):
    match = re.fullmatch(r"(?:The|This)\s+(?:policy\s+)?statement\s+"
        r"(?:was not|is not|has not been)\s+issued\s+(?P<mode>on behalf of|by)\s+"
        r"(?P<holder>.+?)\s*[.]?", text, re.I | re.S)
    if (not match or match["mode"].casefold() != wanted["mode"]
            or _literal_holder(match["holder"], engine) != tuple(wanted["holder"])):
        return False
    doc = engine.parse(text)
    roots = [t for t in doc if t.dep_ == "ROOT"]
    return bool(len(roots) == 1 and roots[0].lemma_.casefold() == "issue"
        and any(t.dep_ == "neg" for t in doc) and not any(t.tag_ == "MD" for t in doc))


def _statement_envelopes(page, wanted, engine):
    # One complete quote only: repeated/competing artifacts cannot share a
    # definite antecedent merely because they have the same issuer or words.
    quotes = list(re.finditer(r'"([^"\u201c\u201d]+)"|\u201c([^"\u201c\u201d]+)\u201d', page["text"], re.S))
    if len(quotes) != 1 or len(re.findall(r'["\u201c\u201d]', page["text"])) != 2:
        return []
    quote = quotes[0]
    body_start, body_end = quote.span(1 if quote.group(1) is not None else 2)
    units = list(literal.sentences(page["text"][:quote.start()]))
    if (not units or not re.search(r"\bstatement\b", units[-1]["text"], re.I)
            or not units[-1]["text"].rstrip().endswith(":")):
        return []
    header = units[-1]
    binding = _statement_binding(header["text"], wanted, engine)
    binding_units = [header] if binding else []
    blockers = []
    outside = page["text"][:quote.start()] + page["text"][quote.end():]
    if re.search(r"\b(?:another|a|an|different|second|other|new)\s+(?:policy\s+)?statement\b", outside, re.I):
        blockers.append("COMPETING_SOURCE_STATEMENT_REFERENT")
    if re.search(r"\bstatement\b[^.!?]*:", page["text"][quote.end():], re.I):
        blockers.append("COMPETING_SOURCE_STATEMENT_INTRODUCTION")
    if _prefix(page, header["start"], engine):
        blockers.append("SOURCE_STATEMENT_ENVELOPE_UNDER_UNPROVED_OUTER_SCOPE")
    if not binding:
        # A literal supplemental ascription must itself be unqualified and
        # finite; "will confirm that ..." cannot supply this certificate.
        for unit in literal.sentences(page["text"][quote.end():]):
            candidate = _statement_binding(unit["text"], wanted, engine)
            if candidate:
                shifted = dict(unit, start=quote.end()+unit["start"], end=quote.end()+unit["end"])
                # The verified closing delimiter ends this quote's scope.
                # Earlier enclosing scope remains a blocker on the envelope.
                if not _prefix(dict(text=page["text"][quote.end():]), unit["start"], engine):
                    # Still require a direct issuance header, not a forecast,
                    # fabrication, nested report, or hypothetical quotation.
                    generic = re.fullmatch(r"(?P<holder>.+?)\s+(?:issued|has issued)\s+the\s+following\s+statement\s*:", header["text"], re.I | re.S)
                    if generic and _literal_holder(generic["holder"], engine):
                        binding, binding_units = candidate, [header, shifted]
        if binding is None:
            blockers.append("COMPLETE_SOURCE_STATEMENT_ISSUER_OR_ISSUANCE_NOT_PROVED")
    return [dict(start=header["start"], end=quote.end(), body_start=body_start, body_end=body_end,
        body=page["text"][body_start:body_end], binding=binding, binding_units=binding_units, blockers=blockers)]


def _attributed_matches(wanted, page, engine, index, case):
    if wanted is None:
        return []
    target_views = [v for v in _content_views(wanted["content"], engine)
                    if v["projection"] == "WHOLE_PRINTED_PROPOSITION"]
    if len(target_views) != 1:
        return []
    target = target_views[0]
    result = []
    for envelope in _statement_envelopes(page, wanted, engine):
        for unit in literal.sentences(envelope["body"]):
            for source in _content_views(unit["text"], engine):
                if source["signature"] != target["signature"]:
                    continue
                blockers = envelope["blockers"]
                checks = _check_all("Whole source-qualified content, exact roles/operators/tense and separately bound statement matrix; not world truth.")
                if blockers:
                    for check in checks:
                        if check["id"] == "attribution":
                            check.update(state="missing", detail="; ".join(blockers))
                citations = [_citation(page, envelope["start"], envelope["end"], index, case)]
                citations.extend(_citation(page, u["start"], u["end"], index, case)
                    for u in envelope["binding_units"] if u["end"] > envelope["end"])
                certificate = dict(kind="COMPLETE_SOURCE_ATTRIBUTED_ACCOUNT", query_matrix=wanted["matrix"],
                    query_antecedent=wanted["antecedent"], source_matrix=envelope["binding"],
                    target=target, source=source,
                    source_content_unit=dict(start=envelope["body_start"]+unit["start"],
                        end=envelope["body_start"]+unit["end"], text=unit["text"]),
                    whole_content_matched=True, source_qualifications_retained=True,
                    compiler_result_overridden=False, issued_on_behalf_inferred_from_request=False)
                result.append(dict(direction="CONTEXT" if blockers else "SUPPORT", checks=checks,
                    citations=citations, certificate=certificate, blockers=list(blockers),
                    source_assertion_not_world_truth=True, actual_inner_event_established=False,
                    issuance_event_established=False))
                if blockers:
                    continue
                for denial in literal.sentences(page["text"][envelope["end"]:]):
                    matched = re.fullmatch(r"(?:The|This)\s+statement\s+does\s+not\s+(?:say|state)\s+that\s*,?\s*(.+?)\s*[.]?", denial["text"], re.I | re.S)
                    issuer_denial = _statement_issuer_denial(denial["text"], wanted, engine)
                    content_denial = bool(matched and any(v["signature"] == target["signature"]
                        and v["projection"] == "WHOLE_PRINTED_PROPOSITION" for v in _content_views(matched[1], engine)))
                    if not issuer_denial and not content_denial:
                        continue
                    start = envelope["end"]+denial["start"]
                    if _prefix(dict(text=page["text"][envelope["end"]:]), denial["start"], engine):
                        continue
                    opposite = deepcopy(result[-1])
                    opposite.update(direction="COUNTER", citations=citations+[_citation(page, start,
                        envelope["end"]+denial["end"], index, case)])
                    opposite["certificate"]["kind"] = ("EXPLICIT_SAME_STATEMENT_ISSUER_DENIAL" if issuer_denial
                        else "EXPLICIT_SAME_STATEMENT_MATRIX_DENIAL")
                    next(c for c in opposite["checks"] if c["id"] == "polarity").update(
                        state="conflict", detail="Explicit same-local-statement denial of the complete matched content; not opposite inner content.")
                    result.append(opposite)
    return list({digest(e):e for e in result}.values())


def _role_spec(atom):
    return roles.query_spec(atom)


def _role_certificate(page, kind, match, spec, engine, index, case):
    certificate, reason = roles._certificate(page, kind, match, spec, engine, index, case)
    if certificate:
        return certificate, None
    view, offsets, edits = engine.source_view(page["text"])
    if offsets is None or view == page["text"]:
        return None, reason
    analysis = dict(page, text=view, source_sha256=digest(view))
    analysis_pages = dict(index[0], **{page["id"]:analysis})
    def restore(value):
        if isinstance(value, list):
            return [restore(v) for v in value]
        if not isinstance(value, dict):
            return value
        if "canonical_page_id" in value and {"start", "end", "text"} <= value.keys():
            return _citation(page, offsets[value["start"]], offsets[value["end"]-1]+1, index, case)
        result = {k:(deepcopy(v) if k == "query_atom" else restore(v)) for k,v in value.items()}
        if {"start", "end", "text"} <= result.keys() and type(result["start"]) is int:
            a,b = offsets[result["start"]], offsets[result["end"]-1]+1
            result.update(start=a, end=b, text=page["text"][a:b])
        if "unit_start" in result and "unit_end" in result:
            result["unit_start"], result["unit_end"] = offsets[result["unit_start"]], offsets[result["unit_end"]-1]+1
        return result
    for projected_kind, projected in roles.previous._matches(view, spec):
        if (offsets[projected.start("name")] != match.start("name")
                or offsets[projected.end("name")-1]+1 != match.end("name")):
            continue
        checked, _ = roles._certificate(analysis, projected_kind, projected, spec, engine,
                                       (analysis_pages, index[1], index[2]), case)
        if checked:
            checked = restore(checked)
            checked.pop("sha256", None)
            checked["source_analysis_projection"] = dict(kind="EXISTING_DICTIONARY_ATTESTED_LAYOUT_VIEW",
                edits=edits, raw_source_modified=False, named_identity_inferred=False,
                raw_source_sha256=page["source_sha256"], analysis_view_sha256=digest(view),
                all_citation_offsets_restored_and_rechecked=True)
            checked["sha256"] = digest(checked)
            return checked, None
    return None, reason


def _role_matches(atom, case, admitted, index, engine, groups, plan):
    spec = _role_spec(atom)
    matches, rejections = [], []
    if spec is not None:
        for page in admitted.values():
            for kind, match in roles.previous._matches(page["text"], spec):
                certificate, reason = _role_certificate(page, kind, match, spec, engine, index, case)
                if certificate:
                    matches.append(_role_evidence(certificate))
                else:
                    rejections.append(dict(page_id=page["id"], reason=reason))
        return matches, rejections, spec
    # The generic positive past-role grammar is narrower than a current-tenure
    # assertion. Complete local objects locate a name; raw apposition proves it.
    old_spec = past_roles.query_spec(case, plan, atom["id"])
    if old_spec is None:
        return [], [], None
    observed = past_roles.observe(case, plan, atom["id"], admitted, index, engine=engine, local_groups=groups)
    for certificate in observed["certificates"]:
        page = admitted[certificate["citation"]["canonical_page_id"]]
        full_name = certificate["person"]["text"]
        query = full_name + " is identified as " + old_spec["role"] + " of " + old_spec["organization"] + "."
        projected = roles.query_spec(dict(atom, text=query))
        if projected is None:
            continue
        for kind, match in roles.previous._matches(page["text"], projected):
            checked, reason = _role_certificate(page, kind, match, projected, engine, index, case)
            if (checked and checked["source_parts"]["name"]["start"] == certificate["person"]["start"]
                    and checked["source_parts"]["name"]["end"] == certificate["person"]["end"]):
                checked["source_local_identity"] = deepcopy(certificate["identity_binding"])
                checked["public_past_role_atom"] = deepcopy(atom)
                matches.append(_role_evidence(checked))
            elif reason:
                rejections.append(dict(page_id=page["id"], reason=reason))
    spec = dict(name=old_spec["person"], role=old_spec["role"], unit=old_spec["organization"], atom=atom)
    return matches, rejections, spec


def _role_evidence(certificate):
    certificate = deepcopy(certificate)
    certificate.pop("sha256", None)
    certificate["sha256"] = digest(certificate)
    return dict(direction="SUPPORT", checks=_check_all("Complete V2 raw name/title/unit ascription; no tenure, appointment or surrounding action is certified."),
        citations=[deepcopy(certificate["citation"])], certificate=deepcopy(certificate),
        blockers=[], source_identification_only=True, actual_inner_event_established=False,
        source_assertion_not_world_truth=True)


def _role_counters(spec, page, unit, engine, index, case):
    """Only explicit same-owner/complete-title negative copulas are signed."""
    if spec is None:
        return []
    parsed = engine.parse(unit["text"])
    results = []
    for root in parsed:
        if root.dep_ != "ROOT" or root.lemma_.casefold() != "be":
            continue
        owners = [c for c in root.children if c.dep_ == "nsubj"]
        attributes = [c for c in root.children if c.dep_ in {"attr", "acomp"}]
        if len(owners) != 1 or len(attributes) != 1:
            continue
        owner = owners[0]
        owner_tokens = [t for t in owner.subtree if not t.is_punct and not t.is_space]
        owner_text = " ".join(t.text for t in owner_tokens)
        if _normal(owner_text) != _normal(spec["name"]):
            continue
        title = attributes[0]
        tokens = [t for t in title.subtree if not t.is_punct and not t.is_space and t.dep_ != "det"]
        offered = _normal(" ".join(t.text for t in tokens))
        wanted = [_normal(spec["role"] + " of " + (spec["unit"] or "")),
                  _normal((spec["unit"] or "") + " " + spec["role"])]
        if offered not in wanted:
            continue
        negative = any(t.dep_ == "neg" for t in root.children)
        if not negative:
            continue
        problems = []
        if _prefix(page, unit["start"], engine):
            problems.append("EXTERNAL_SOURCE_SCOPE")
        if any(t.tag_ == "MD" for t in parsed) or _DEICTIC.search(unit["text"]):
            problems.append("UNALIGNED_MODAL_OR_EVENT_TIME")
        if any(m[0].casefold() != "not" for m in roles.previous._QUALIFIER.finditer(unit["text"])):
            problems.append("SOURCE_ROLE_QUALIFICATION_NOT_ALIGNED")
        _, quoted = roles._quote_scope(page["text"], unit["start"] + owner.idx,
                                       unit["start"] + title.idx + len(title))
        if quoted:
            problems.append(quoted)
        checks = _check_all("Explicit same literal holder and full role/unit; negative source assertion retained.")
        next(c for c in checks if c["id"] == "polarity").update(state="conflict", detail="Source explicitly denies the same role assertion; identification witness remains inspectable.")
        results.append(dict(direction="CONTEXT_CONFLICT" if problems else "COUNTER", checks=checks,
            citations=[_citation(page, unit["start"], unit["end"], index, case)],
            certificate=dict(kind="SIGNED_LITERAL_ROLE_DENIAL", name=owner_text, title=offered,
                source_date_not_tenure_date=True, ascription_vs_role_truth_distinct=True),
            blockers=problems, source_assertion_not_world_truth=True))
    return results


def _identity_frame_boundary(page, source, link, index, case):
    """Extend local identity scope over verified layout only, never content."""
    text = page["text"]
    a, b = source["start"], source["end"]
    lo, hi = link["clause_start"], link["clause_end"]
    if (link["page_id"] != page["id"] or link["page_sha256"] != page["source_sha256"]
            or any(type(value) is not int for value in (a, b, lo, hi))
            or not (0 <= a < b <= len(text) and 0 <= lo < hi <= len(text))
            or source["quote"] != text[a:b]):
        return None
    frame_citation = _citation(page, a, b, index, case)
    certificate_citation = _citation(page, lo, hi, index, case)
    if lo <= a and b <= hi:
        return dict(kind="EXACT_CERTIFICATE_CONTAINMENT", frame_citation=frame_citation,
                    certificate_citation=certificate_citation, source_modified=False)
    if not a <= lo < hi <= b:
        return None
    prefix, suffix = text[a:lo], text[hi:b]
    def terminal_only(tail):
        return (not tail.strip() or bool(re.fullmatch(r"\s*\.\s*", tail))
                and not text[lo:hi].rstrip().endswith((".", "!", "?")))
    if not terminal_only(suffix):
        return None
    units = list(literal.sentences(text))
    unit = next((u for u in units if u["start"] == lo and hi <= u["end"] <= b
                 and terminal_only(text[hi:u["end"]])), None)
    if unit is None:
        return None
    marker_proof = None
    if prefix.strip():
        marker = re.fullmatch(r"\s*(?P<number>[1-9][0-9]{0,2})\.[ \t\r\n]+", prefix)
        if marker is None:
            return None
        start = a + marker.start("number")
        end = a + marker.end("number") + 1
        # A number-like token alone is not a list certificate. Require its own
        # line-start unit and an adjacent sequential label in the same layout.
        labels = list(re.finditer(r"(?m)^[ \t]*(?P<number>[1-9][0-9]{0,2})\.(?=[ \t]|$)", text))
        position = next((i for i, m in enumerate(labels) if m.start("number") == start), None)
        if position is None or not any(u["start"] == start and u["end"] == end for u in units):
            return None
        number = int(marker["number"])
        neighbors = [labels[i] for i in (position-1, position+1) if 0 <= i < len(labels)
                     and int(labels[i]["number"]) == number + (1 if i > position else -1)]
        if not neighbors:
            return None
        neighbor = neighbors[0]
        marker_proof = dict(kind="SEQUENCED_LINE_START_NUMERIC_LIST_LABEL",
            label=_citation(page, start, end, index, case),
            adjacent_label=_citation(page, neighbor.start("number"), neighbor.end("number")+1, index, case),
            not_a_numeric_fact_or_event_date=True)
    return dict(kind="VERIFIED_SOURCE_UNIT_LAYOUT_EXTENSION", frame_citation=frame_citation,
        certificate_citation=certificate_citation, source_unit=_citation(page, unit["start"], unit["end"], index, case),
        leading_layout=_citation(page, a, lo, index, case) if a < lo else None,
        trailing_layout=_citation(page, hi, b, index, case) if hi < b else None,
        marker_proof=marker_proof, source_modified=False, content_removed=False,
        operator_or_identity_scope_expanded=False, tense_or_date_check_changed=False)


def _identity_name_boundary(phrase, link):
    if _normal(phrase["text"]) == _normal(link["full_name"]):
        return dict(kind="EXACT_COMPLETE_NAME")
    boundary = link.get("frame_boundary", {})
    marker = boundary.get("marker_proof")
    if boundary.get("kind") != "VERIFIED_SOURCE_UNIT_LAYOUT_EXTENSION" or not marker:
        return None
    label = marker["label"]
    number = label["text"][:-1]
    # A parser's display phrase can absorb a paragraph label. No numeric
    # semantic field is erased: a real term/quantity/modifier still refuses.
    for key in ("terms", "names", "quantifiers", "descriptive_terms", "role_qualifiers"):
        if number in {str(value) for value in phrase.get(key, [])}:
            return None
    if phrase.get("modifiers"):
        return None
    removed, retained = [], []
    for proof in phrase["proofs"]:
        if (proof["start"] == label["start"] and proof["end"] == label["end"]-1
                and proof["text"] == number and proof["end"] <= link["clause_start"]):
            removed.append(proof)
        else:
            retained.append(proof)
    if (len(removed) != 1 or not retained
            or _normal(" ".join(p["text"] for p in retained)) != _normal(link["full_name"])):
        return None
    return dict(kind="VERIFIED_LIST_LABEL_IN_PARSER_DISPLAY_ONLY", layout_proof=deepcopy(removed[0]),
        full_name_proofs=deepcopy(retained), numeric_semantic_fields_changed=False,
        raw_phrase_text=phrase["text"], raw_phrase_text_changed=False)


def _frame_matches(atom, page, engine, index, case, identity_links):
    targets = engine.targets(atom["text"])
    sources = engine.frames(page["text"], antecedents=True)
    result = []
    for target in targets:
        for raw_source in sources:
            source = deepcopy(raw_source)
            links = []
            for link in identity_links:
                if link["page_id"] != page["id"]:
                    continue
                boundary = _identity_frame_boundary(page, raw_source, link, index, case)
                if boundary is not None:
                    links.append(dict(link, frame_boundary=boundary))
            projections = []
            for link in links:
                for role, phrases in source["roles"].items():
                    for i, phrase in enumerate(phrases):
                        name_boundary = _identity_name_boundary(phrase, link)
                        if (name_boundary is not None
                                and any(_normal(p["text"]) == _normal(link["query_name"])
                                        for values in target["roles"].values() for p in values)):
                            source["roles"][role][i] = dict(deepcopy(phrase),
                                names=[p for p in phrase["names"] if p in _normal(link["query_name"]).split()],
                                terms=[p for p in phrase["terms"] if p in _normal(link["query_name"]).split()],
                                proofs=[p for p in phrase["proofs"] if p["lemma"] in _normal(link["query_name"]).split()])
                            projections.append(dict(link, name_boundary=name_boundary))
            matched = provenance._match(target, source, page, engine, linguistic)
            if matched is None:
                continue
            # Every query frame needs its own positive witness; a leaf is never
            # promoted because the surrounding source has no detected counter.
            matched["target_predicate_start"] = target["predicate_proof"]["start"]
            matched["direction"] = {"Support":"SUPPORT", "Counterevidence":"COUNTER", "Partial":"PARTIAL"}.get(matched["direction"], "CONTEXT")
            matched["source_local_identity_projections"] = deepcopy(projections)
            matched["source_assertion_not_world_truth"] = True
            matched["actual_inner_event_established"] = False if target["qualifiers"]["scope"] else None
            if target["kind"] == "EVENT":
                wanted_time = _frame_tense(atom["text"], target["predicate_proof"]["start"], engine)
                source_time = _frame_tense(page["text"], raw_source["predicate_proof"]["start"], engine)
                if wanted_time != source_time and matched["direction"] in {"SUPPORT", "COUNTER"}:
                    matched["direction"] = "CONTEXT"
                    next(c for c in matched["checks"] if c["id"] == "event_date").update(
                        state="missing", detail="Event tense differs or is unresolved; publication is not an event-time bridge.")
            scope = _prefix(page, source["start"], engine)
            _, quoted = roles._quote_scope(page["text"], source["predicate_proof"]["start"],
                source["predicate_proof"]["end"])
            if quoted:
                scope = quoted
            if scope and matched["direction"] in {"SUPPORT", "COUNTER"}:
                matched["direction"] = "CONTEXT"
                matched["blockers"] = [scope]
            result.append(matched)
    return result


def _identity_links(role_evidence, spec):
    links = []
    for evidence in role_evidence:
        cert = evidence["certificate"]
        if not cert.get("source_local_identity"):
            continue
        cite = cert["citation"]
        links.append(dict(page_id=cite["canonical_page_id"], page_sha256=cite["page_sha256"],
            query_name=spec["name"], full_name=cert["source_parts"]["name"]["text"],
            clause_start=cite["start"], clause_end=cite["end"],
            proof=deepcopy(cert["source_local_identity"]), global_alias=False))
    return links


def _qualified_account(atom, evidence, engine):
    citation = evidence["citations"][0]
    structure = _structure(citation["text"], engine)
    doc = engine.parse(citation["text"])
    result = dict(atom_id=atom["id"], required_content=atom["text"], source_id=citation["canonical_page_id"],
        document_id=citation["document_id"], source_date=citation["date"],
        wording="The cited source asserts or identifies: " + atom["text"],
        full_source_quote=citation["text"], citations=deepcopy(evidence["citations"]),
        source_qualifications=dict(operators=structure["operators"],
            event_clock_unresolved=structure["deictic"], publication_date_used_as_event_date=False,
            modality_tokens=[t.text for t in doc if t.tag_ == "MD"],
            printed_time_expressions=[entity.text for entity in doc.ents if entity.label_ in {"DATE", "TIME"}],
            source_negation=structure["negation"], full_source_context_retained=True),
        source_qualifications_retained=True, qualifications_not_erased=True,
        actual_inner_event_established=evidence.get("actual_inner_event_established"),
        source_identification_only=evidence.get("source_identification_only", False),
        world_truth_certified=False, continuous_tenure_established=False,
        purpose_or_requested_goal_performed=False, independent_corroboration_claimed=False)
    certificate = evidence.get("certificate", {})
    if certificate.get("kind") == "COMPLETE_SOURCE_ATTRIBUTED_ACCOUNT":
        result["source_attribution"] = dict(query_antecedent=deepcopy(certificate["query_antecedent"]),
            matrix=deepcopy(certificate["source_matrix"]),
            inherited_scope_proofs=deepcopy(certificate["source"]["inherited"]),
            issuance_event_established=False, statement_contents_only=True)
    return result


def assemble(case, plan, retrieval, source_index, *, base_packet=None, source_groups=None):
    """Assemble required source contributions; no evaluation/retrieval side effect."""
    case = public_case(case)
    if case["task"] != "reconstruction" or case["focal_marker"]:
        raise ValueError("An exact complete reconstruction question is required")
    planning.validate_plan(plan, case)
    planning.check_atoms(case, plan["atoms"])
    input_sha = digest(dict(case=case, plan=plan))
    with offline():
        index, admitted, ids, budget = _sources(case, retrieval, source_index)
        groups = _groups(source_groups, admitted, case, index)
        if base_packet is not None:
            if (base_packet.get("case_id") != case["case_id"] or base_packet.get("query_sha256") != digest(case["query"])
                    or base_packet.get("provided_plan_sha256") != digest(plan)
                    or base_packet.get("inspected_page_ids") != ids
                    or base_packet.get("keys_read") is not False or base_packet.get("grades_read") is not False):
                raise ValueError("Base packet differs from exact public plan/pool or reads private assessments")
        engine = SourceEngine()
        compiled = planning.compile_requirements(case, plan, engine=engine)
        account_queries = _account_queries(plan, engine)
        role_results, links = {}, []
        for atom in plan["atoms"]:
            role_results[atom["id"]] = _role_matches(atom, case, admitted, index, engine, groups, plan)
            role_evidence, _, spec = role_results[atom["id"]]
            if spec:
                links.extend(_identity_links(role_evidence, spec))
        atoms = []
        for atom in plan["atoms"]:
            role_evidence, rejected, spec = role_results[atom["id"]]
            evidence = list(role_evidence)
            counter_scan, raw_complete, frame_evidence, attributed = [], [], [], []
            target_structure = _structure(atom["text"], engine)
            names = [t.text for t in engine.parse(atom["text"]) if t.pos_ == "PROPN"]
            def candidate(text):
                # This is lexical shortlisting for expensive parsing, never a
                # support/identity certificate. Unknown aliases cannot enter.
                return not names or any(re.search(r"(?<!\w)" + re.escape(name) + r"(?!\w)", text, re.I) for name in names)
            for page in admitted.values():
                if not candidate(page["text"]):
                    continue
                attributed.extend(_attributed_matches(account_queries.get(atom["id"]), page, engine, index, case))
                for unit in literal.sentences(page["text"]):
                    if MASK.search(unit["text"]):
                        continue
                    if not candidate(unit["text"]):
                        continue
                    if spec and not re.search(roles.previous._pattern(spec["name"]), unit["text"], re.I):
                        continue
                    match = _raw_match(atom["text"], page, unit, engine, index, case, target=target_structure)
                    if match:
                        raw_complete.append(match)
                    counter_scan.extend(_role_counters(spec, page, unit, engine, index, case))
                if spec is None:
                    frame_evidence.extend(_frame_matches(atom, page, engine, index, case, links))
            requirements = [r for r in compiled["requirements"] if r["atom_id"] == atom["id"]]
            query_complete = bool(requirements) and all(r["coverage"]["complete"] for r in requirements)
            evidence.extend(raw_complete)
            evidence.extend(attributed)
            targets = engine.targets(atom["text"])
            qualified = any(t["qualifiers"].get(key) for t in targets
                for key in ("scope", "attribution", "modality", "conditional", "question"))
            frame_complete = bool(targets) and query_complete and not qualified and all(any(
                e["direction"] == "SUPPORT" and e["target_predicate_start"] == t["predicate_proof"]["start"]
                for e in frame_evidence) for t in targets)
            if frame_complete:
                evidence.extend(e for e in frame_evidence if e["direction"] == "SUPPORT")
            def signed_complete(value):
                return (value["direction"] == "COUNTER"
                    and all(c["state"] == "pass" or c["id"] == "polarity" and c["state"] == "conflict"
                            for c in value["checks"]) and any(c["id"] == "polarity"
                            and c["state"] == "conflict" for c in value["checks"]))
            signed = [e for e in counter_scan + raw_complete + attributed + ([] if qualified else frame_evidence) if signed_complete(e)]
            support = [e for e in evidence if e["direction"] == "SUPPORT" and all(c["state"] == "pass" for c in e["checks"])]
            signed = list({digest(e):e for e in signed}.values())
            conflict = bool(support and signed)
            context_conflicts = [e for e in counter_scan if e["direction"] == "CONTEXT_CONFLICT"]
            state = "CONFLICTED" if conflict else "OPPOSED" if signed else "SUPPORT" if support and not context_conflicts else "UNRESOLVED"
            accounts = [_qualified_account(atom, e, engine) for e in support]
            gaps = [] if state == "SUPPORT" else ["SOURCE_CONFLICT_REQUIRES_QUALIFICATION" if conflict
                else "SIGNED_OPPOSING_SOURCE" if signed else "COMPLETE_REQUIRED_SOURCE_CONTENT_NOT_GROUNDED"]
            account_complete = any(e["direction"] == "SUPPORT" for e in attributed)
            if not query_complete and not role_evidence and not account_complete and not any(e["direction"] == "SUPPORT" for e in raw_complete):
                gaps.append("RAW_MAIN_CLAUSE_OR_COMPLETE_SCOPE_NOT_REPRESENTED")
            atoms.append(dict(id=atom["id"], text=atom["text"], required=True, status=state,
                coverage="Established" if state == "SUPPORT" else "Partial" if support or any(e["direction"] == "PARTIAL" for e in frame_evidence) else "Missing",
                qualified_accounts=accounts, positive_evidence=support, counterevidence=signed,
                evidence=support+signed,
                evidence_semantics="SIGNED_ALIAS_OF_POSITIVE_AND_COUNTER_ROWS_NOT_ADDITIONAL_WITNESSES",
                context_evidence=[e for e in frame_evidence + raw_complete + attributed if e["direction"] not in {"SUPPORT", "COUNTER"}],
                source_context_conflicts=context_conflicts,
                signed_countercheck=dict(performed=True, inspected_pages=len(ids), whole_inspected_pool=True,
                    positive_evidence_required=True, no_counter_is_not_support=True,
                    scope="Bounded explicit signed clauses/role denials; not all possible semantic contradictions."),
                query_requirements=requirements, query_compiler_complete=query_complete,
                requirements_semantics="PUBLIC_QUERY_STRUCTURE_NOT_AUTOMATIC_FIELD_PASS_OR_SUPPORT",
                complete_role_or_raw_clause_certificate=bool(role_evidence or any(e["direction"] == "SUPPORT" for e in raw_complete)),
                complete_attributed_account_certificate=account_complete,
                role_rejections=rejected, gaps=gaps, world_truth_certified=False))
    required = len(atoms)
    counts = {s:sum(a["status"] == s for a in atoms) for s in ("SUPPORT", "OPPOSED", "CONFLICTED", "UNRESOLVED")}
    status = CONFLICTED if counts["CONFLICTED"] or counts["OPPOSED"] else BACKED if required and counts["SUPPORT"] == required else PARTIAL if any(a["positive_evidence"] for a in atoms) else UNRESOLVED
    if input_sha != digest(dict(case=case, plan=plan)):
        raise ValueError("Caller-owned public inputs changed during assembly")
    return dict(version=VERSION, task="reconstruction", case_id=case["case_id"], query_sha256=digest(case["query"]),
        provided_plan_sha256=digest(plan), inspected_page_ids=ids, source_pages_inspected=len(ids), passage_budget=budget,
        status=status, atoms=atoms, overall=dict(status=status, required_atoms=required,
            established_components=counts["SUPPORT"], counts=counts, fractions_are_probabilities=False),
        assembly=dict(status=status, complete_required_content=status == BACKED,
            qualified_accounts=[account for a in atoms for account in a["qualified_accounts"]],
            gaps=[dict(atom_id=a["id"], reasons=a["gaps"]) for a in atoms if a["gaps"]],
            source_counterchecks_performed=True, no_counter_is_not_positive_evidence=True,
            qualifications_in_output=True, unqualified_world_truth=False,
            continuous_tenure_or_joint_event_inferred=False, independent_corroboration_claimed=False),
        base_packet_sha256=digest(base_packet) if base_packet is not None else None,
        base_packet_used_as_support=False, source_groups_sha256=digest(groups), query_requirements=compiled,
        new_retrieval=False, old_native_result_reused=False, keys_read=False, grades_read=False, api_calls=0,
        kernel_mass_used_as_confidence=False, world_truth_certified=False,
        limitations=["Source-backed reconstruction is an attributed account, not independent world-truth verification.",
            "Only the supplied inspected pool and bounded signed/grammatical constructions are checked.",
            "Unknown referents, clocks, complete contents and main clauses remain gaps; publication is not event time."])
