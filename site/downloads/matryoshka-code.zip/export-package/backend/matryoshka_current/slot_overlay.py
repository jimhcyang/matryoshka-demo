"""Lazy opaque-source census. Navigation only, outside semantic topology."""
from collections import OrderedDict
from copy import deepcopy
import hashlib
import json
import re
from urllib.parse import urlencode

from .slot_context import (MARKER, POLICY, VisibleVocabulary,
                           context_preview, label_context)

VERSION = "current-opaque-source-slots/2"
NOTICE = ("Observed opaque boundaries and literal context links are navigation only, not semantic "
          "evidence or concealed-identity claims. Published memberships, weights and metrics are "
          "unchanged. Marker width is not concealed-text length.")
MAX_LIMIT = 64


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def normalized(text):
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


class CorpusSlots:
    def __init__(self, owner, corpus):
        self.owner, self.corpus = owner, corpus
        self.audit = OrderedDict()
        self.binding = self.read("/api/graph-v4-viewer?corpus=" + corpus)
        self.base = "/graph-assets-v4/" + corpus + "/"
        if self.binding["asset_base"] != self.base:
            raise ValueError("Unexpected opaque-source asset binding")
        comparison = self.read(self.base + self.binding["comparison_asset"])
        search = self.read(self.base + self.binding["search_asset"])
        for value in (comparison, search):
            if any(value[k] != self.binding[k] for k in ("graph_run_id", "hierarchy_run_id")):
                raise ValueError("Opaque-source graph/search bindings differ")
        self.view = "current_earlier" if corpus == "cib" else "current_redaction"
        self.release = "earlier" if corpus == "cib" else "confidential"
        catalog = comparison["source_catalogs"]["views"][self.view]
        if catalog["release"] != self.release:
            raise ValueError("Opaque census requires the base visible projection")
        self.documents = catalog["files_by_document"]
        self.files = sorted(set(self.documents.values()))
        self.entity_file = search["view_files"][self.view]
        self.cursor = self.scanned_documents = self.scanned_pages = 0
        self.documents_with_pages = self.pages_with_markers = 0
        self.marker_counts = {"transport_slot": 0, "literal_redacted": 0}
        self.rows, self.by_id, self.pages = [], {}, {}
        self.labels = None
        self.trie = {}
        self.source_cache = OrderedDict()

    def read(self, path):
        if not (path == "/api/graph-v4-viewer?corpus=" + self.corpus or
                path.startswith("/graph-assets-v4/" + self.corpus + "/")):
            raise ValueError("Unbound opaque-source path")
        if any(term in path for term in ("current_later", "current_reveal", "..", "\\")):
            raise ValueError("Later/reveal sources cannot supply opaque navigation")
        raw, _ = self.owner.maps.packet(path)
        self.audit[path] = sha(raw)
        return json.loads(raw)

    def source(self, filename):
        if filename not in self.files:
            raise ValueError("Unbound source shard")
        if filename not in self.source_cache:
            value = self.read(self.base + filename)
            if value.get("view_key") != self.view or value.get("release") != self.release:
                raise ValueError("Source shard is not the base visible projection")
            self.source_cache[filename] = value
            while len(self.source_cache) > 2:
                self.source_cache.popitem(last=False)
        self.source_cache.move_to_end(filename)
        return self.source_cache[filename]

    def vocabulary(self):
        if self.labels is not None:
            return
        value = self.read(self.base + self.entity_file)
        if value.get("view_key") != self.view:
            raise ValueError("Vocabulary is not the base visible projection")
        self.visible_vocabulary = VisibleVocabulary(value["records"])
        self.labels = self.visible_vocabulary.labels
        self.trie = self.visible_vocabulary.trie

    def anchors(self, text, start, end):
        self.vocabulary()
        return self.visible_vocabulary.anchors(text, start, end)

    def scan_one(self):
        if self.cursor == len(self.files):
            return
        filename = self.files[self.cursor]
        shard = self.source(filename)
        # Stage before committing progress, so a failed request can safely retry.
        staged, page_rows = [], {}
        documents = pages = with_pages = marker_pages = 0
        counts = dict.fromkeys(self.marker_counts, 0)
        for document, source in sorted(shard["documents"].items()):
            if self.documents.get(document) != filename:
                continue
            if source["document_id"] != document or source["release"] != self.release:
                raise ValueError("Mixed document or release in source catalog")
            documents += 1
            with_pages += bool(source["pages"])
            for page in source["pages"]:
                pages += 1
                raw = page["text"]
                markers = list(MARKER.finditer(raw))
                if not markers:
                    continue
                text = MARKER.sub("[REDACTED]", raw)
                visible = list(MARKER.finditer(text))
                if len(markers) != len(visible):
                    raise ValueError("Normalization changed boundary count")
                marker_pages += 1
                page_key = (document, page["canonical_page_id"])
                page_rows[page_key] = dict(document_id=document, canonical_page_id=page_key[1],
                    source_page=page["source_page"], sequence_in_document=page["sequence_in_document"],
                    date=source.get("document_date_iso", ""), release=self.release,
                    text_sha256=sha(text.encode()), transport_text_sha256=sha(raw.encode()))
                for ordinal, (original, marker) in enumerate(zip(markers, visible), 1):
                    identity = "opaque_slot_" + sha(f"{document}|{page_key[1]}|{ordinal}".encode())[:24]
                    counts["transport_slot" if original.group(1) else "literal_redacted"] += 1
                    anchors = self.anchors(text, marker.start(), marker.end())
                    staged.append(dict(id=identity, page_key=page_key, ordinal=ordinal,
                        slot_id=original.group(1), marker_start=marker.start(), marker_end=marker.end(),
                        context_preview=context_preview(text, marker.start(), marker.end()),
                        label_context=label_context(text, marker.start(), marker.end(), anchors),
                        anchors=anchors))
        if len({r["id"] for r in staged}) != len(staged) or any(r["id"] in self.by_id for r in staged):
            raise ValueError("Duplicate canonical opaque slot")
        if self.cursor + 1 == len(self.files) and self.scanned_documents + documents != len(self.documents):
            raise ValueError("Bound source catalog is incomplete; no complete census can be reported")
        self.pages.update(page_rows)
        self.by_id.update((row["id"], row) for row in staged)
        self.rows.extend(staged)
        self.scanned_documents += documents
        self.scanned_pages += pages
        self.documents_with_pages += with_pages
        self.pages_with_markers += marker_pages
        for key, count in counts.items():
            self.marker_counts[key] += count
        self.cursor += 1

    def status(self):
        complete = self.cursor == len(self.files)
        return dict(version=VERSION, context_policy=POLICY, corpus=self.corpus, graph_run_id=self.binding["graph_run_id"],
            hierarchy_run_id=self.binding["hierarchy_run_id"], map_index_sha256=self.owner.maps.index_sha256,
            source_view=self.view, release=self.release, notice=NOTICE,
            scope="All bound base-visible source documents; explicit opaque syntax only.",
            semantic_graph_modified=False, hidden_values_read=False,
            coverage=dict(complete=complete, scanned_shards=self.cursor, total_shards=len(self.files),
                catalog_documents=len(self.documents), scanned_documents=self.scanned_documents,
                documents_with_pages=self.documents_with_pages, scanned_pages=self.scanned_pages,
                pages_with_markers=self.pages_with_markers, observed_slots=len(self.rows),
                marker_counts=self.marker_counts.copy(), total_slots=len(self.rows) if complete else None,
                note="Incomplete is not zero; absent/classification-only masks are not invented."),
            source_audit=[dict(path=path, sha256=value) for path, value in self.audit.items()])

    def record(self, row):
        page = self.pages[row["page_key"]]
        document = page["document_id"]
        anchors = [dict(entity, visibility="both", minimum_document_date=page["date"],
            summary="Literal base-visible vocabulary navigation; not concealed-entity identity.",
            visible_proof=dict(document_id=document, canonical_page_id=page["canonical_page_id"],
                release=self.release, text=literal, start=start, end=end,
                match_kind="EXACT_VISIBLE_TERM_CASE_INSENSITIVE", semantic=False, identity_certified=False))
            for entity, start, end, literal in row["anchors"]]
        primary = next((a for a in anchors if a.get("community_id")), {})
        slot = {k: row[k] for k in ("id", "ordinal", "slot_id", "marker_start", "marker_end", "context_preview")}
        excerpt = row.get("label_context")
        display_context = " ".join(excerpt[2].split()) if excerpt else ""
        context_prefix = " / near " if anchors else " / "
        slot.update(type="RedactionSlot", kind="slot_overlay", overlay_slot=True,
            label="Redacted Slot" + (context_prefix + display_context if display_context else ""),
            context_policy=POLICY,
            article_title=f"{document} / page {page['source_page']}", document_id=document, document_count=1,
            canonical_page_id=page["canonical_page_id"], source_page=page["source_page"], date=page["date"],
            minimum_document_date=page["date"], visibility="redacted_placeholder", mass=1,
            semantic=False, eligible_evidence=False, anchors=anchors, page_provenance=page.copy(),
            summary="Opaque boundary; concealed wording and length are unavailable.",
            hierarchy_placement="visible_lexical_context_navigation_only" if primary else "unplaced_no_verified_visible_anchor",
            **{k: primary.get(k) for k in ("domain_id", "theme_id", "community_id")})
        slot["label_context"] = (dict(document_id=document, canonical_page_id=page["canonical_page_id"],
            release=self.release, start=excerpt[0], end=excerpt[1], text=excerpt[2],
            match_kind="VISIBLE_CONTEXT_EXCERPT", semantic=False, identity_certified=False) if excerpt else None)
        slot["context_links"] = [dict(id=row["id"] + "_context_" + str(i), source=row["id"], target=a["id"],
            edge_type="VISIBLE_CONTEXT_NAVIGATION", edge_class="provenance_context", slot_navigation=True,
            semantic=False, eligible_evidence=False, weight=0, layout_weight=0,
            visibility="redacted_placeholder", minimum_document_date=page["date"],
            supporting_document_ids=[document], source_proof=a["visible_proof"],
            description="Literal visible-term navigation, not a semantic relation to the hidden span.")
            for i, a in enumerate(anchors)]
        slot["workbench_links"] = self.owner.workbench_links(document)
        return slot

    def detail(self, identity):
        if identity not in self.by_id:
            raise ValueError("Unknown opaque slot in scanned catalog; no identity substitute")
        row = self.by_id[identity]
        document, page_id = row["page_key"]
        source = self.source(self.documents[document])["documents"][document]
        page = next(p for p in source["pages"] if p["canonical_page_id"] == page_id)
        return self.record(row), dict(self.pages[row["page_key"]], text=MARKER.sub("[REDACTED]", page["text"]))


class SlotOverlay:
    def __init__(self, maps, cases=()):
        self.maps, self.cases = maps, list(cases)
        self.corpora = {}

    def workbench_links(self, document):
        return [dict(case_id=row["case"]["case_id"], binding="same_document_only_not_exact_focal_mask",
            href="/workbench-v6.html?" + urlencode(dict(case=row["case"]["case_id"], arm="A")),
            label="Saved question from this document / not an exact slot binding")
            for row in self.cases if row["case"]["document_id"] == document]

    def packet(self, params):
        allowed = {"corpus", "graph_id", "hierarchy_id", "slot_id", "scan", "q", "offset", "limit",
                   "anchor_id", "domain_id", "theme_id", "community_id"}
        if set(params) - allowed or any(len(v) != 1 for v in params.values()):
            raise ValueError("Unknown or repeated opaque-slot selector")
        p = {key: value[0] for key, value in params.items()}
        corpus = p.get("corpus")
        if corpus not in {"cib", "iran", "vietnam"}:
            raise ValueError("Unknown opaque-source corpus")
        try:
            offset, limit = int(p.get("offset", "0")), int(p.get("limit", "32"))
        except ValueError:
            raise ValueError("Invalid opaque-slot pagination") from None
        if offset < 0 or not 1 <= limit <= MAX_LIMIT or len(p.get("q", "")) > 200:
            raise ValueError("Opaque-slot request exceeds pagination/search bounds")
        if p.get("scan", "0") not in {"0", "1"}:
            raise ValueError("Invalid opaque-slot scan selector")
        if corpus not in self.corpora:
            self.corpora[corpus] = CorpusSlots(self, corpus)
        index = self.corpora[corpus]
        if any(p.get(key) != index.binding[name] for key, name in
               (("graph_id", "graph_run_id"), ("hierarchy_id", "hierarchy_run_id"))):
            raise ValueError("Opaque slots require exact current graph and hierarchy pins")
        if p.get("scan") == "1":
            index.scan_one()
        value = index.status()
        if "slot_id" in p:
            value["slot"], value["page"] = index.detail(p["slot_id"])
            return value
        query = normalized(p.get("q", ""))
        matches = []
        for row in index.rows:
            page = index.pages[row["page_key"]]
            if query:
                surface = normalized(" ".join((row["id"], row["slot_id"] or "", "opaque slot redacted slot",
                    page["document_id"], page["date"], row["context_preview"])))
                if not all(term in surface.split() for term in query.split()):
                    continue
            if "anchor_id" in p and not any(a[0]["id"] == p["anchor_id"] for a in row["anchors"]):
                continue
            primary = next((a[0] for a in row["anchors"] if a[0].get("community_id")), {})
            if any(primary.get(key) != p[key] for key in ("domain_id", "theme_id", "community_id") if key in p):
                continue
            matches.append(row)
        value.update(slots=[index.record(row) for row in matches[offset:offset+limit]], offset=offset, limit=limit,
            matched_count=len(matches), next_offset=offset+limit if offset+limit < len(matches) else None)
        return deepcopy(value)


def recontextualize_record(record, page, vocabulary):
    """Rebuild only navigation context from an existing, hash-pinned visible page."""
    if (record.get("type") != "RedactionSlot" or record.get("semantic") is not False
            or record.get("eligible_evidence") is not False or record.get("overlay_slot") is not True
            or record.get("visibility") != "redacted_placeholder"):
        raise ValueError("Slot is not a nonsemantic navigation record")
    if (page.get("release") not in {"earlier", "confidential"}
            or sha(page["text"].encode()) != page["text_sha256"]
            or record["page_provenance"] != {k: v for k, v in page.items() if k != "text"}
            or any(record[k] != page[k] for k in ("document_id", "canonical_page_id", "source_page"))):
        raise ValueError("Slot page provenance changed or is not base-visible")
    text = page["text"]
    markers = list(MARKER.finditer(text))
    ordinal = record["ordinal"]
    if not 1 <= ordinal <= len(markers):
        raise ValueError("Slot ordinal is not present in the saved visible page")
    marker = markers[ordinal - 1]
    expected_id = "opaque_slot_" + sha(
        f"{page['document_id']}|{page['canonical_page_id']}|{ordinal}".encode())[:24]
    if (record["id"] != expected_id or marker.group() != "[REDACTED]"
            or (record["marker_start"], record["marker_end"]) != marker.span()):
        raise ValueError("Slot ID or observed marker boundary changed")
    for anchor in record["anchors"]:
        proof = anchor["visible_proof"]
        if (any(proof[k] != page[k] for k in ("document_id", "canonical_page_id", "release"))
                or proof.get("semantic") is not False or proof.get("identity_certified") is not False
                or not 0 <= proof["start"] < proof["end"] <= len(text)
                or text[proof["start"]:proof["end"]] != proof["text"]):
            raise ValueError("Existing slot source proof changed")
    anchors = vocabulary.anchors(text, marker.start(), marker.end())
    key = (page["document_id"], page["canonical_page_id"])
    row = dict(record, page_key=key, anchors=anchors,
        context_preview=context_preview(text, marker.start(), marker.end()),
        label_context=label_context(text, marker.start(), marker.end(), anchors))
    index = CorpusSlots.__new__(CorpusSlots)
    index.release, index.pages, index.owner = page["release"], {key: record["page_provenance"]}, SlotOverlay(None)
    rebuilt = index.record(row)
    result = deepcopy(record)
    for field in ("label", "label_context", "context_policy", "context_preview", "anchors", "context_links",
                  "hierarchy_placement", "domain_id", "theme_id", "community_id"):
        result[field] = rebuilt[field]
    return result
