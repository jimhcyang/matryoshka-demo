"""Bounded H ClaimBindings; evidence reuse, never R verdict transfer.

The role route certifies an earlier source's complete historical title
ascription. It does not certify case-date tenure, appointment or a surrounding
action. Unknown state intervals in explicit denials remain unresolved.
"""
from copy import deepcopy
from datetime import date
import re

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest,offline
from matryoshka_demo_v6 import reporting_local_decisions_v65 as provenance
from matryoshka_demo_v6 import planning as literal
from matryoshka_demo_v61.scope_matching import Engine
from . import reconstruction as certificates

VERSION='current-h-claim-bindings/5'
EVENT_VERSION='current-h-passive-field-bindings/1'
STATES=('SUPPORT','PARTIAL','OPPOSED','CONFLICTED','UNRESOLVED')


def _normal(text):
    value=' '.join(text.casefold().split())
    return value[4:] if value.startswith('the ') else value


def needs_source_groups(case,plan):
    return any(certificates.past_roles.query_spec(case,plan,a['id']) is not None for a in plan['atoms'])


def _check(name,passed,detail):
    return dict(id=name,state='pass' if passed else 'missing',detail=detail)


def _matrix_scope_error(governor):
    if governor.lemma_.casefold() in certificates.roles._MATRIX_NONFACTIVE:return 'NONFACTIVE_MATRIX'
    if any(c.dep_=='neg' or c.tag_=='MD' or c.lower_ in {'reportedly','allegedly','perhaps','possibly','probably'}
            or c.dep_=='mark' and c.lower_ in {'if','unless','whether'} for c in governor.children):
        return 'NEGATED_MODAL_OR_UNCERTAIN_MATRIX'
    if any(t.lower_ in {'if','unless','whether'} for branch in governor.children if branch.dep_=='advcl' for t in branch.subtree):
        return 'CONDITIONAL_MATRIX_SCOPE'
    return None


def _finite_matrix(governor):
    return governor.tag_ in {'VBD','VBP','VBZ'} or any(
        c.dep_ in {'aux','auxpass'} and c.tag_ in {'VBD','VBP','VBZ'} for c in governor.children)


def _leading_title_certificate(page,unit,match,spec,atom,index,case,engine):
    """Exact raw ORG ROLE PERSON subject NP, not a repaired apposition."""
    guards=certificates.roles;old=guards.previous
    raw=unit['text'];offset=unit['start'];begin=match.start('unit');end=match.end('name')
    if not re.search(r'[.!]["\')\]]*$',raw) or old.MASK.search(raw):
        return None,'INCOMPLETE_OR_OPAQUE_SOURCE_SENTENCE'
    if raw[:begin-offset].strip().casefold() not in {'','the'}:
        return None,'LEADING_TITLE_NOT_COMPLETE_SENTENCE_SUBJECT'
    quotes,reason=guards._quote_scope(page['text'],begin,end)
    if reason:return None,reason
    outer,reason=guards._outer_scope(page['text'][:begin],engine)
    if reason:return None,reason
    prior=list(literal.sentences(page['text'][:offset]))
    if prior and (re.search(r'\b(?:if|unless|following|quotation|quoted|allegation)\b',prior[-1]['text'],re.I)
            or old._QUALIFIER.search(prior[-1]['text']) or prior[-1]['text'].rstrip().endswith(':')):
        return None,'UNBOUND_PRECEDING_OPERATOR'
    doc=engine.parse(raw)
    def tokens(field):
        a,b=match.span(field)
        found={t for t in doc if a<=t.idx+offset<b and not t.is_space}
        if not found or min(t.idx for t in found)+offset!=a or max(t.idx+len(t) for t in found)+offset!=b:
            return set()
        return found
    names=tokens('name');units=tokens('unit');titles=tokens('role')
    heads=[t for t in names if t.head not in names]
    if len(heads)!=1 or len(titles)!=1 or not units:return None,'INEXACT_RAW_NP_TOKEN_BOUNDARIES'
    name=heads[0];role=next(iter(titles));governor=name.head
    if (name.dep_!='nsubj' or governor.dep_!='ROOT' or governor.pos_ not in {'VERB','AUX'}
            or [c for c in governor.children if c.dep_ in {'nsubj','nsubjpass','csubj'}]!=[name]
            or role.dep_!='compound' or role.head!=name or role.pos_ not in {'NOUN','PROPN'}):
        return None,'TITLE_NOT_OWNED_BY_UNIQUE_NAMED_MATRIX_SUBJECT'
    nominal=old._NAME_DEPS|{'nummod'}
    if any(t!=name and (t.head not in names or t.dep_ not in old._NAME_DEPS) for t in names):
        return None,'NAME_NOT_ONE_COMPLETE_NOMINAL_CONSTITUENT'
    if any(t.head not in units|{role} or t.dep_ not in nominal for t in units):
        return None,'ORGANIZATION_NOT_COMPLETE_ATTACHED_TITLE_CONSTITUENT'
    articles={t for t in doc if t.idx+offset<begin and not t.is_space and not t.is_punct}
    if any(t.lower_!='the' or t.dep_!='det' or t.head not in {role,name} for t in articles):
        return None,'UNLICENSED_TITLE_PREFIX'
    complete=names|units|{role}|articles
    actual={t for t in name.subtree if not t.is_space and not t.is_punct}
    if actual!=complete or {t for t in role.subtree if not t.is_space and not t.is_punct}!=units|{role}|(articles&set(role.subtree)):
        return None,'NAME_OR_TITLE_HAS_UNMATCHED_CONSTITUENTS'
    if old._QUALIFIER.search(page['text'][begin:end]):return None,'QUALIFIED_TITLE_OR_UNIT'
    reason=_matrix_scope_error(governor)
    if reason:return None,reason
    finite_governor=governor;finite_analysis='EXISTING_TOKEN_LOCAL_CASE_ANALYSIS'
    if not _finite_matrix(governor):
        # A finite tag may be lost by the existing uppercase analysis. Only
        # the same raw root and unique named subject can supply that slot.
        original=engine.analysis_parser.identity.parser(raw)
        roots=[t for t in original if t.dep_=='ROOT' and t.idx==governor.idx
            and t.lemma_.casefold()==governor.lemma_.casefold()]
        if original.text!=raw or len(roots)!=1:return None,'NO_FINITE_MATRIX_CLAUSE'
        finite_governor=roots[0]
        subjects=[c for c in finite_governor.children if c.dep_ in {'nsubj','nsubjpass','csubj'}]
        if (len(subjects)!=1 or subjects[0].idx!=name.idx or subjects[0].text!=name.text
                or subjects[0].dep_!='nsubj' or not _finite_matrix(finite_governor)):
            return None,'NO_FINITE_MATRIX_CLAUSE'
        reason=_matrix_scope_error(finite_governor)
        if reason:return None,reason
        finite_analysis='ORIGINAL_CASE_SAME_RAW_ROOT_AND_UNIQUE_NAMED_SUBJECT'
    citation=provenance._citation(page,unit['start'],unit['end'])
    parts={field:provenance._citation(page,*match.span(field)) for field in ('name','role','unit')}
    for proof in [citation,*parts.values()]:provenance._quote(proof,*index,case)
    def proof(t):
        return dict(text=t.text,start=t.idx+offset,end=t.idx+offset+len(t),dependency=t.dep_,head=t.head.text,lemma=t.lemma_)
    certificate=dict(version=VERSION,kind='RAW_SOURCE_ROLE_IDENTIFICATION',
        pattern='H_ONLY_LEADING_ORGANIZATION_ROLE_PERSON_NP',public_past_role_atom=deepcopy(atom),
        query_atom=deepcopy(atom),query_sha256=digest(case['query']),citation=citation,source_parts=parts,
        complete_source_unit=deepcopy(parts['unit']),
        complete_literal_constituents=dict(name=[proof(t) for t in sorted(names,key=lambda t:t.i)],
            unit=[proof(t) for t in sorted(units,key=lambda t:t.i)],omitted_name_or_unit_constituents=False),
        nominal_title_ownership=dict(unique_named_matrix_subject=True,
            subject=proof(name),title=proof(role),organization=[proof(t) for t in sorted(units,key=lambda t:t.i)],
            complete_subject_np=[proof(t) for t in sorted(complete,key=lambda t:t.i)]),
        quotation_boundary_check=quotes,external_operator_check=outer,
        narrator_title_outside_reported_complement=True,literal_full_name=True,partial_name_or_alias_used=False,
        raw_source_unchanged=True,source_identification_only=True,source_role_truth_certified=False,
        continuous_tenure_established=False,appointment_established=False,other_event_established=False,
        publication_date_not_an_inferred_tenure_date=True,reported_or_future_content_retained_not_certified=True,
        matrix=dict(proof(governor),tag=governor.tag_),
        finite_matrix_proof=dict(proof(finite_governor),tag=finite_governor.tag_,analysis=finite_analysis,
            same_raw_root_and_named_subject=True,source_characters_changed=False),world_truth_certified=False)
    certificate['sha256']=digest(certificate)
    return certificate,None


def _leading_title_candidates(spec,atom,admitted,index,case,engine):
    pattern=re.compile(r"(?<![\w'-])(?P<unit>"+certificates.roles.previous._pattern(spec['organization'])
        +r')\s+(?P<role>'+re.escape(spec['role'])+r')\s+(?P<name>'
        +certificates.roles.previous._pattern(spec['person'])+r")(?![\w'-])",re.I)
    found=[];rejected=[]
    for page in admitted.values():
        matches=list(pattern.finditer(page['text']))
        if not matches:continue
        sentences=list(literal.sentences(page['text']))
        for match in matches:
            units=[s for s in sentences if s['start']<=match.start() and match.end()<=s['end']]
            if len(units)!=1:
                rejected.append(dict(page_id=page['id'],reason='NO_COMPLETE_LITERAL_SOURCE_SENTENCE'))
                continue
            certificate,reason=_leading_title_certificate(page,units[0],match,spec,atom,index,case,engine)
            if certificate:found.append(dict(certificate=certificate))
            else:rejected.append(dict(page_id=page['id'],reason=reason,start=match.start(),end=match.end()))
    return found,rejected


def _role_denials(spec,names,admitted,index,case,engine):
    """Whole-pool explicit tuple denials, not an assertion of aligned tenure."""
    contexts=[]
    wanted={_normal(spec['role']+' of '+spec['organization']),_normal(spec['organization']+' '+spec['role'])}
    names={_normal(n) for n in names}
    for page in admitted.values():
        for unit in literal.sentences(page['text']):
            view,_,_=engine.source_view(unit['text'])
            parsed=engine.parse(view)
            for root in parsed:
                if root.dep_!='ROOT' or root.lemma_.casefold()!='be':continue
                owners=[c for c in root.children if c.dep_ in {'nsubj','nsubjpass'}]
                attributes=[c for c in root.children if c.dep_ in {'attr','acomp'}]
                if len(owners)!=1 or len(attributes)!=1:continue
                owner=' '.join(t.text for t in owners[0].subtree if not t.is_space and not t.is_punct)
                if _normal(owner) not in names:continue
                title=attributes[0]
                offered=' '.join(t.text for t in title.subtree if not t.is_space and not t.is_punct and t.dep_!='det')
                if _normal(offered) not in wanted:continue
                negative=any(t.dep_=='neg' or t.lemma_.casefold() in {'never','no'}
                    for t in [*root.children,*title.children])
                if not negative:continue
                citation=provenance._citation(page,unit['start'],unit['end'])
                provenance._quote(citation,*index,case)
                contexts.append(dict(direction='CONTEXT_CONFLICT',citation=citation,
                    holder=owner,role_unit=offered,
                    reason='EXPLICIT_ROLE_DENIAL_STATE_INTERVAL_NOT_BOUND',
                    source_date_is_attestation_not_tenure_date=True,decisive_h_opposition=False))
    return contexts


def role_claim_bindings(case,plan,admitted,index,*,source_groups=None,engine=None):
    """Return H-owned ClaimBindings for exact whole positive past-role atoms.

    `index` is the complete bound policy tuple; `admitted` is the original
    inspected pool. Source-local groups must be complete verified job objects.
    No registry, alias table, source critic, key or saved verdict is consulted.
    """
    case=public_case(case)
    if case['task']!='hypothesis':raise ValueError('Historical H ClaimBindings require an H case')
    engine=engine or Engine();groups=certificates._groups(source_groups,admitted,case,index)
    before=digest(dict(case=case,plan=plan));result=[]
    for atom in plan['atoms']:
        spec=certificates.past_roles.query_spec(case,plan,atom['id'])
        if spec is None:continue
        candidates,rejected,_=certificates._role_matches(atom,case,admitted,index,engine,groups,plan)
        # The old past-role observer only locates post-name appositions. The
        # same frozen raw certificate also licenses a literal pre-name title.
        projected=certificates.roles.query_spec(dict(atom,text=spec['person']+' is identified as '
            +spec['role']+' of '+spec['organization']+'.'))
        if projected:
            for page in admitted.values():
                for kind,match in certificates.roles.previous._matches(page['text'],projected):
                    checked,reason=certificates._role_certificate(page,kind,match,projected,engine,index,case)
                    if checked:
                        checked.pop('sha256',None);checked['public_past_role_atom']=deepcopy(atom)
                        checked['sha256']=digest(checked)
                        candidates.append(dict(certificate=checked))
                    elif reason:rejected.append(dict(page_id=page['id'],reason=reason))
        leading,leading_rejected=_leading_title_candidates(spec,atom,admitted,index,case,engine)
        candidates.extend(leading);rejected.extend(leading_rejected)
        candidates=list({digest(c['certificate']):c for c in candidates}.values())
        bindings=[];names=[spec['person']]
        for candidate in candidates:
            # Ignore the R direction, its all-pass vector and overall verdict.
            certificate=deepcopy(candidate['certificate']);parts=certificate['source_parts']
            for proof in [certificate['citation'],certificate['complete_source_unit'],*parts.values()]:
                provenance._quote(proof,*index,case)
            complete=certificate.get('complete_literal_constituents',{})
            identity=certificate.get('source_local_identity',{})
            name_match=(_normal(parts['name']['text'])==_normal(spec['person']) or
                identity.get('kind')=='PINNED_SOURCE_LOCAL_LABEL_AND_RAW_APPOSITION')
            checks=[
                _check('public_scope',certificate.get('public_past_role_atom')==atom,
                    'Exact complete positive past-role atom; no omitted public restriction.'),
                _check('actor',name_match,'Complete literal name or verified source-job identity; no global alias.'),
                _check('predicate',_normal(parts['role']['text'])==_normal(spec['role']),
                    'Exact required title, not a meeting/reporting predicate or a source label.'),
                _check('organization',_normal(certificate['complete_source_unit']['text'])==_normal(spec['organization']),
                    'Complete organization constituent, not a prefix or numeric namespace suffix.'),
                _check('constituents',complete.get('omitted_name_or_unit_constituents') is False,
                    'Complete raw name and unit boundaries independently certified.'),
                _check('qualification',(certificate.get('narrator_apposition_outside_reported_complement') is True
                    or certificate.get('narrator_title_outside_reported_complement') is True
                    and certificate.get('nominal_title_ownership',{}).get('unique_named_matrix_subject') is True)
                    and certificate.get('quotation_boundary_check',{}).get('quote_scope_open') is False
                    and certificate.get('external_operator_check',{}).get('colon_or_following_scope_open') is False,
                    'Title itself is unqualified narrator ascription, outside reported/quoted/conditional content.'),
                _check('source_scope',True,'Original source bytes/spans, cutoff, whole-origin and handling replay.'),
                _check('temporal_reading',True,
                    'Bare positive past role is supported only as historical source ascription; no current tenure.'),
            ]
            names.append(parts['name']['text'])
            bindings.append(dict(certificate=certificate,checks=checks,
                complete=all(c['state']=='pass' for c in checks)))
        denials=_role_denials(spec,names,admitted,index,case,engine)
        passing=[b for b in bindings if b['complete']]
        direction='SUPPORT' if passing and not denials else 'UNRESOLVED'
        proof=passing[0] if passing else bindings[0] if bindings else None
        checks=deepcopy(proof['checks']) if proof else [
            _check('raw_role_certificate',False,'No complete eligible raw title/name/organization ascription.')]
        checks.append(_check('counter_scope',not denials,
            'No positive credit comes from absence of a counter; a raw positive certificate is mandatory.'
            if not denials else 'Explicit denial retained; its state interval is unbound, not decisive H opposition.'))
        entry=dict(version=VERSION,id=atom['id']+':historical_role',atom_id=atom['id'],
            kind='HISTORICAL_ROLE_ASCRIPTION',direction=direction,
            query=dict(text=atom['text'],start=atom['start'],end=atom['end'],
                person=spec['person'],role=spec['role'],organization=spec['organization'],
                whole_atom_consumed=True),
            time=dict(mode='HISTORICAL_ASCRIPTION_NOT_CASE_DATE_TENURE',
                source_dates=sorted({b['certificate']['citation']['date'] for b in passing}),
                case_date_is_eligibility_cutoff=True,publication_is_event_or_tenure_date=False),
            checks=checks,certificates=[b['certificate'] for b in passing],rejections=rejected,
            countercheck=dict(performed=True,inspected_pages=len(admitted),inspected_page_ids=list(admitted),
                contexts=denials,state_interval_conflict_proved=False,
                scope='Explicit same literal holder/full role/unit copular denials; not universal contradiction completeness.'),
            gaps=[] if direction=='SUPPORT' else ['ROLE_DENIAL_WITH_UNBOUND_INTERVAL' if denials else 'NO_COMPLETE_RAW_ROLE_CERTIFICATE'],
            qualified_assertion='An eligible earlier source identifies '+spec['person']+' as '+spec['role']+' of '+spec['organization']+'.',
            stronger_readings_unresolved=['CASE_DATE_TENURE','CONTINUOUS_TENURE','APPOINTMENT','SURROUNDING_ACTION'],
            current_tenure_established=False,governing_action_established=False,world_truth_certified=False,
            r_verdict_transferred=False,graph_or_description_as_fact=False)
        entry['sha256']=digest(entry);result.append(entry)
    if before!=digest(dict(case=case,plan=plan)):raise ValueError('Public query/plan changed during binding')
    return result


def _summarize(atoms):
    from . import decisions
    counts={state:sum(a['status']==state for a in atoms if a.get('required',True)) for state in STATES}
    proxy=[dict(a,status='UNRESOLVED' if a['status']=='PARTIAL' else a['status']) for a in atoms]
    result=decisions.summarize(proxy);n=result['required_atoms']
    if result['status']=='UNRESOLVED' and counts['PARTIAL']:result['status']='PARTIAL'
    result.update(counts=counts,fractions={s:dict(numerator=v,denominator=n,label=f'{v}/{n}') for s,v in counts.items()},
        partial_atom_ids=[a['id'] for a in atoms if a['status']=='PARTIAL'],
        all_required_atoms_supported=bool(n) and counts['SUPPORT']==n,
        partial_counts_as_full_support=False)
    return result


def _calendar_day(text):
    from . import proposition_matching as pm
    match=re.fullmatch(r'('+pm._MONTH+r')\s+(\d{1,2})(?:,?\s+(\d{4}))?',text,re.I)
    if not match:return None
    month=next(i for i,m in enumerate(pm._MONTHS,1) if m.casefold()==match[1].casefold())
    year=int(match[3]) if match[3] else None
    try:date(year or 2000,month,int(match[2]))
    except ValueError:return None
    return dict(month=month,day=int(match[2]),year=year)


def _passive_form(text,engine,*,source=False):
    from . import proposition_matching as pm
    distribution=r'(?:(?P<distribution>separate\s+incidents)\s+in\s+)?' if source else ''
    clock=r'(?:(?:about|at)\s+(?P<clock>\d{3,4})\s+)?' if source else ''
    on=r'(?:on\s+)?' if source else r'on\s+'
    pattern=(r'(?P<patient>.+?)\s+(?P<aux>was|were)\s+(?:(?P<neg>not)\s+)?'
        r'(?P<verb>[A-Za-z]+)\s+in\s+'+distribution+r'(?P<place>[A-Za-z]+(?:[-\s][A-Za-z]+)*?)\s+'
        +clock+on+r'(?P<day>'+pm._MONTH+r'\s+\d{1,2}(?:,?\s+\d{4})?)\.')
    match=re.fullmatch(pattern,text,re.I|re.S)
    if not match or pm._OPAQUE.search(text) or certificates.roles.previous._PREFIX_SCOPE.search(text):return None
    day=_calendar_day(match['day'])
    if not day:return None
    doc=engine.parse(text)
    roots=[t for t in doc if t.dep_=='ROOT' and t.idx==match.start('verb') and t.pos_=='VERB']
    if len(roots)!=1:return None
    root=roots[0]
    auxiliary=[c for c in root.children if c.idx==match.start('aux') and c.dep_=='auxpass' and c.tag_=='VBD']
    if len(auxiliary)!=1:return None
    if any(c.tag_=='MD' or c.dep_ in {'ccomp','xcomp','advcl'} or
            c.dep_=='advmod' and c.idx<match.start('day') and c.lower_ not in {'about'} for c in root.children):return None
    negatives=[c for c in root.children if c.dep_=='neg']
    if bool(negatives)!=bool(match['neg']) or len(negatives)>1:return None
    if root.lemma_.casefold() in certificates.roles._MATRIX_NONFACTIVE:return None
    subjects=[c for c in root.children if c.dep_ in {'nsubjpass','nsubj:pass'}]
    if not subjects:return None
    if not source and (len(subjects)!=1 or any(t.pos_ in {'PRON','NUM','VERB','AUX'}
            or t.lower_ in {'every','each','all','some','any','no','neither','either'}
            for t in doc if match.start('patient')<=t.idx<match.end('patient'))):return None
    if not source:
        compiled=pm.compile_proposition(text,engine=engine)
        if not compiled['complete'] or len(compiled['propositions'])!=1:return None
    # Place/date slots must belong to this matrix, not an embedded action.
    for field in ('place','day'):
        tokens=[t for t in doc if match.start(field)<=t.idx<match.end(field) and not t.is_space and not t.is_punct]
        if not tokens or any(root not in t.ancestors or any(a.pos_ in {'VERB','AUX'} and a!=root for a in t.ancestors) for t in tokens):return None
    return dict(match=match,doc=doc,root=root,subjects=subjects,day=day,
        negated=bool(match['neg']),distributed=bool(match.groupdict().get('distribution')))


def _event_patient(query,source):
    offered=source['match'];wanted=query['match']['patient'];doc=source['doc'];root=source['root']
    coordinate=any(t.lower_ in {'and','or'} and t.idx<offered.start('aux') for t in doc)
    if coordinate and (not source['distributed'] or source['negated'] or
            any(t.lower_=='or' and t.idx<offered.start('aux') for t in doc)):return None
    if not coordinate and len(source['subjects'])!=1:return None
    if _normal(wanted)==_normal(offered['patient']):
        return dict(apposition_owned_by_event_patient=False,source_span=offered.span('patient'),
            exact_complete_description=True,coordinate=coordinate)
    pattern=re.compile(r',\s*(?:the\s+)?(?P<title>'+certificates.roles.previous._pattern(
        wanted[4:] if wanted.casefold().startswith('the ') else wanted)+r')\s*,',re.I)
    found=[]
    for match in pattern.finditer(offered['patient']):
        tokens={t for t in doc if match.start('title')<=t.idx<match.end('title') and not t.is_space}
        heads=[t for t in tokens if t.head not in tokens]
        if len(heads)!=1:continue
        title=heads[0];owner=title.head
        if title.dep_!='appos' or owner not in source['subjects']:continue
        omitted={t for c in title.children if c.dep_ in {'cc','conj'} for t in c.subtree} if coordinate else set()
        complete={t for t in title.subtree if not t.is_space and not t.is_punct and t.dep_!='det'}-omitted
        if complete!=tokens:continue
        names=certificates.roles._name_constituent(owner,title)
        if any(t.pos_ not in {'NOUN','PROPN'} for t in names):continue
        found.append(dict(apposition_owned_by_event_patient=True,source_span=match.span('title'),
            holder_span=(min(t.idx for t in names),max(t.idx+len(t) for t in names)),
            exact_complete_description=True,coordinate=coordinate))
    return found[0] if len(found)==1 else None


def _predicate_fields(wanted,offered):
    if wanted==offered:return dict(state='pass',kind='EXACT_LITERAL_PREDICATE_LEMMA',query=wanted,source=offered)
    from matryoshka_demo.roles import lexicon,binding
    wn=lexicon();targets={s.name() for s in wn.synsets(wanted,pos='v')};links=[]
    for sense in wn.synsets(offered,pos='v'):
        for parent in sense.hypernyms():
            if parent.name() in targets:links.append(dict(source_synset=sense.name(),target_synset=parent.name()))
    return dict(state='missing',kind='LEXICAL_CANDIDATE_IS_NOT_ENTAILMENT_PROOF',query=wanted,source=offered,
        lexical_candidates=links,sense_disambiguated=False,resource=binding() if links else None)


def passive_claim_bindings(case,plan,admitted,index,engine):
    """Complete passive slots; lexical suggestions never become full support."""
    bindings=[]
    for atom in plan['atoms']:
        if atom['text']!=case['query'][atom['start']:atom['end']] or atom.get('source_quote')!=atom['text']:continue
        query=_passive_form(atom['text'],engine)
        if not query:continue
        for page in admitted.values():
            for unit in literal.sentences(page['text']):
                source=_passive_form(unit['text'],engine,source=True)
                if not source:continue
                patient=_event_patient(query,source)
                if not patient:continue
                qday=query['day'];sday=source['day']
                day_matches=(qday['month']==sday['month'] and qday['day']==sday['day']
                    and (qday['year'] is None or qday['year']==sday['year']))
                if not day_matches or _normal(query['match']['place'])!=_normal(source['match']['place']):continue
                if any(d['year'] and date(d['year'],d['month'],d['day'])>=date.fromisoformat(case['date']) for d in (qday,sday)):continue
                quotes,reason=certificates.roles._quote_scope(page['text'],unit['start'],unit['end'])
                if reason:continue
                outer,reason=certificates.roles._outer_scope(page['text'][:unit['start']],engine)
                if reason:continue
                predicate=_predicate_fields(query['root'].lemma_.casefold(),source['root'].lemma_.casefold())
                if predicate['state']!='pass' and not predicate['lexical_candidates']:continue
                opposite=query['negated']!=source['negated']
                named_query=all(t.pos_=='PROPN' for t in query['doc']
                    if query['match'].start('patient')<=t.idx<query['match'].end('patient') and not t.is_space)
                if (opposite or source['negated']) and (not qday['year'] or not sday['year']
                        or patient['coordinate'] or predicate['state']!='pass' or not named_query
                        or patient['apposition_owned_by_event_patient']):continue
                direction='COUNTER' if opposite else 'SUPPORT' if predicate['state']=='pass' else 'PARTIAL'
                fields=dict(patient=dict(state='pass',description=query['match']['patient']),predicate=predicate,
                    place=dict(state='pass',literal=query['match']['place']),
                    event_date=dict(state='pass',requested=qday,source=sday,publication_date_used_as_event_date=False,
                        unrequested_year_inferred=False))
                citation=provenance._citation(page,unit['start'],unit['end']);provenance._quote(citation,*index,case)
                a,b=patient['source_span'];participant=provenance._citation(page,a+unit['start'],b+unit['start'])
                provenance._quote(participant,*index,case)
                patient=dict(patient,citation=participant,source_span=(a+unit['start'],b+unit['start']),
                    source_coordinate_system='PAGE_CHAR_OFFSETS')
                if 'holder_span' in patient:
                    a,b=patient['holder_span'];patient['holder_span']=(a+unit['start'],b+unit['start'])
                    patient['holder_citation']=provenance._citation(page,*patient['holder_span'])
                    provenance._quote(patient['holder_citation'],*index,case)
                fields['patient']['citation']=deepcopy(participant)
                for field,slot in [('predicate','verb'),('place','place'),('event_date','day')]:
                    a,b=source['match'].span(slot)
                    fields[field]['citation']=provenance._citation(page,a+unit['start'],b+unit['start'])
                    provenance._quote(fields[field]['citation'],*index,case)
                passed=sum(f['state']=='pass' for f in fields.values())
                entry=dict(version=EVENT_VERSION,id=atom['id']+':passive:'+page['id']+':'+str(unit['start']),
                    atom_id=atom['id'],direction=direction,fields=fields,
                    field_fraction=dict(numerator=passed,denominator=4,label=f'{passed}/4'),
                    whole_public_atom_consumed=True,whole_source_grammar_consumed=True,
                    source_owned_participant=patient,citation=citation,
                    distribution=dict(explicit_separate_incidents=source['distributed'],
                        individual_projection_permitted=not patient['coordinate'] or source['distributed']),
                    operator_scope=dict(query_negated=query['negated'],source_negated=source['negated'],
                        quotation=quotes,external=outer,unresolved_operators_dropped=False),
                    qualified_account='An eligible earlier source asserts: '+citation['text'],
                    unresolved_fields=[] if direction!='PARTIAL' else ['PREDICATE_ENTAILMENT_SENSE_NOT_DISAMBIGUATED'],
                    counter_identity_policy='EXACT_LITERAL_NAMED_PATIENT_NOT_A_PROJECTED_ROLE_DESCRIPTION',
                    field_counts_are_not_probabilities=True,world_truth_certified=False,
                    source_label_or_navigation_as_fact=False,actual_inner_event_established=False)
                entry['sha256']=digest(entry);bindings.append(entry)
    return bindings


def execute(case,plan,retrieval,*,source_index,passage_budget=100,engine=None,source_groups=None):
    """Newly execute v2 guards, then add independently checked ClaimBindings."""
    from . import decisions
    engine=engine or Engine()
    with offline():
        result=decisions._execute_v2(case,plan,retrieval,source_index=source_index,
            passage_budget=passage_budget,engine=engine)
        index,admitted,ids,_=certificates._sources(case,dict(retrieval,passage_budget=passage_budget),source_index)
        bindings=role_claim_bindings(case,plan,admitted,index,source_groups=source_groups,engine=engine)
        event_bindings=passive_claim_bindings(case,plan,admitted,index,engine)
        by_atom={b['atom_id']:b for b in bindings}
        for atom in result['atoms']:
            binding=by_atom.get(atom['id']);atom['qualified_accounts']=[]
            if binding and binding['direction']=='SUPPORT' and atom['status'] not in {'OPPOSED','CONFLICTED'}:
                evidence=[dict(direction='SUPPORT',citation=deepcopy(c['citation']),
                    claim_binding_id=binding['id'],checks=deepcopy(binding['checks']),comparisons=[],
                    certificate=deepcopy(c),evidence_semantics='HISTORICAL_SOURCE_ASCRIPTION_NOT_CASE_DATE_ROLE_TRUTH',
                    actual_inner_event_established=False,world_truth_certified=False) for c in binding['certificates']]
                for requirement in atom['requirements']:
                    requirement.update(status='SUPPORT',evidence=deepcopy(evidence),
                        qualified_scope='HISTORICAL_ROLE_ASCRIPTION',claim_binding_id=binding['id'])
                atom['qualified_accounts']=[dict(text=binding['qualified_assertion'],scope=binding['kind'],
                    no_current_tenure=True,claim_binding_id=binding['id'])]
            events=[e for e in event_bindings if e['atom_id']==atom['id']]
            if events and len(atom['requirements'])==1 and atom['requirements'][0]['coverage']['complete']:
                requirement=atom['requirements'][0]
                for event in events:
                    requirement['evidence'].append(dict(direction=event['direction'],citation=deepcopy(event['citation']),
                        claim_binding_id=event['id'],checks=deepcopy(event['fields']),certificate=deepcopy(event),comparisons=[],
                        evidence_semantics='SOURCE_OWNED_PASSIVE_FIELDS_NOT_WORLD_TRUTH',world_truth_certified=False))
                    atom['qualified_accounts'].append(dict(text=event['qualified_account'],scope='SOURCE_OWNED_PASSIVE_FIELDS',
                        claim_binding_id=event['id'],unresolved_fields=deepcopy(event['unresolved_fields'])))
                directions={e['direction'] for e in requirement['evidence']}
                requirement['status']=('CONFLICTED' if {'SUPPORT','COUNTER'}<=directions else 'SUPPORT' if 'SUPPORT' in directions
                    else 'OPPOSED' if 'COUNTER' in directions else 'PARTIAL' if 'PARTIAL' in directions else requirement['status'])
                requirement['field_bindings']=deepcopy(events)
            units=atom['requirements'];states=[r['status'] for r in units]
            if 'CONFLICTED' in states:status='CONFLICTED'
            elif 'OPPOSED' in states:status='OPPOSED'
            elif states and all(s=='SUPPORT' for s in states):status='SUPPORT'
            elif any(s in {'SUPPORT','PARTIAL'} for s in states):status='PARTIAL'
            else:status='UNRESOLVED'
            if binding and binding['countercheck']['contexts'] and status=='SUPPORT':status='UNRESOLVED'
            atom.update(status=status,evidence=[dict(e,atom_requirement_id=r['id']) for r in units for e in r['evidence']],
                requirement_counts=dict(required=len(units),**{s:states.count(s) for s in STATES}),
                requirement_fraction={s:dict(numerator=states.count(s),denominator=len(units),label=f'{states.count(s)}/{len(units)}') for s in STATES},
                partial_counts_as_full_support=False)
        overall=_summarize(result['atoms'])
        result.update(version=VERSION,status=overall['status'],overall=overall,claim_bindings=bindings,event_claim_bindings=event_bindings,
            event_claim_binding_version=EVENT_VERSION,
            partial_semantics='Complete required subclauses or typed source-owned passive fields with an explicit unresolved predicate; never full SUPPORT.',
            partial_implementation_scope='COMPLETE_REQUIRED_SUBCLAUSES_OR_BOUND_PASSIVE_FIELDS',
            inspected_page_ids=ids,source_pages_inspected=len(ids),old_h_negative_cohort_resealed=False)
    return result
