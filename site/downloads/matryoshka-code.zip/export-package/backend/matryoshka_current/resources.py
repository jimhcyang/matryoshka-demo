"""Explicit current-resource registries; never resolve a process-global latest."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import re
from types import SimpleNamespace
import uuid

VERSION = "matryoshka-current-resource-registry/1"
AUTHORITY_VERSION = "native-reference-authority-mapping/2"


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def safe_path(workspace, value, *, must_exist=True):
    root = Path(workspace).absolute()
    path = Path(value)
    if ".." in path.parts or "\\" in str(value) or "://" in str(value):
        raise ValueError("Unsafe resource path")
    path = path if path.is_absolute() else root / path
    if not path.is_relative_to(root):
        raise ValueError("Resource path is outside explicit workspace")
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError("Symlinks are not resource authority")
        if part == root:
            break
    if must_exist and not path.exists():
        raise ValueError(f"Missing resource: {path}")
    return path


def relative(workspace, path):
    return str(safe_path(workspace, path, must_exist=False).relative_to(Path(workspace).absolute()))


def load_json(path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key")
            result[key] = value
        return result
    def invalid(value):
        raise ValueError(f"Nonfinite JSON value: {value}")
    return json.loads(Path(path).read_text(), object_pairs_hook=unique, parse_constant=invalid)


def immutable_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if load_json(path) != value:
            raise ValueError("Refusing to overwrite immutable resource artifact")
        return
    temporary = path.with_name(path.name + ".pending_" + uuid.uuid4().hex)
    with temporary.open("x") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(temporary, path)
    except FileExistsError:
        if load_json(path) != value:
            raise ValueError("Concurrent immutable publication differs")
    finally:
        temporary.unlink()


def authority(record):
    """Missing, mixed or mistyped authority is inspectable but never upgraded."""
    scope = record.get("reference_scope")
    kinds = record.get("reference_scope_kinds")
    flag = record.get("instance_identity_asserted")
    result = dict(route_class="UNKNOWN_WITHHELD", global_identity_authorized=False,
        source_identity_authorized=False, reference_scope=scope,
        reference_scope_kinds=deepcopy(kinds), instance_identity_asserted=flag, active=record.get("active"))
    if record.get("active") is False:
        result["route_class"] = "INACTIVE_WITHHELD"
        return result
    if record.get("active") is not True:
        return result
    if type(flag) is not bool or not isinstance(kinds, list) or any(not isinstance(x, str) for x in kinds):
        return result
    if scope == "source_referent" and kinds == ["global_identity"] and flag is True:
        result.update(route_class="GLOBAL_IDENTITY", global_identity_authorized=True)
    elif flag is True and ((scope == "model_source_context" and kinds == [scope])
            or (scope == "source_referent" and kinds == ["source_model_occurrence_scope"])):
        result.update(route_class="SOURCE_SCOPED_REFERENCE", source_identity_authorized=True)
    elif flag is False and scope in {"lexical_reference", "source_scoped_vocabulary"} and kinds == [scope]:
        result["route_class"] = "LEXICAL_REFERENCE"
    elif flag is False and scope in {"unresolved_contextual_reference", "unresolved_source_reference"} and kinds == [scope]:
        result["route_class"] = "UNRESOLVED_REFERENCE"
    return result


def alias_authority(record):
    if (record.get("decision") == "same" and record.get("authority") == "global_identity"
            and record.get("equivalence_scope") == "named_entity" and record.get("instance_identity_asserted") is True):
        return "GLOBAL_IDENTITY"
    if (record.get("decision") == "same" and record.get("authority") == "lexical_equivalence"
            and record.get("equivalence_scope") == "lexical_reference" and record.get("instance_identity_asserted") is False):
        return "LEXICAL_REFERENCE"
    return "UNKNOWN_WITHHELD"


def check_registry(registry):
    if registry.get("version") != VERSION or registry.get("corpus") != "cib":
        raise ValueError("Unsupported current resource registry")
    expected = digest({k: v for k, v in registry.items() if k != "registry_digest"})
    if registry.get("registry_digest") != expected:
        raise ValueError("Registry canonical digest mismatch")
    if registry.get("authority_contract") != AUTHORITY_VERSION:
        raise ValueError("Unsupported authority mapping")
    return registry


def create_registry(workspace, handoff_manifest, *, expected_sha256):
    root = Path(workspace).absolute()
    completion = safe_path(root, handoff_manifest)
    if file_sha(completion) != expected_sha256:
        raise ValueError("Handoff completion manifest changed")
    marker = load_json(completion)
    if marker.get("version") != "corpus-resource-handoff-bundle/1" or set(marker["files"]) != {"handoff-v1.json", "OWNER_HANDOFF.md"}:
        raise ValueError("Unsupported/incomplete handoff bundle")
    for name, ref in marker["files"].items():
        path = safe_path(root, completion.parent / name)
        if path.stat().st_size != ref["bytes"] or file_sha(path) != ref["sha256"]:
            raise ValueError("Handoff packet changed")
    handoff = load_json(completion.parent / "handoff-v1.json")
    if handoff.get("corpus") != "cib" or handoff.get("errors"):
        raise ValueError("Handoff is not a valid CIB resource inspection")
    current = handoff["resource"]
    resource_ref = current["manifest"]
    manifest_path = safe_path(root, resource_ref["path"])
    if file_sha(manifest_path) != resource_ref["sha256"]:
        raise ValueError("Resource manifest changed")
    manifest = load_json(manifest_path)
    if (manifest.get("version") != "current-source-only-cib-resource/1.1"
            or manifest.get("status") != "READY_FOR_NEW_CIB_ANALYSIS"
            or current["release_id"] != "cib_resource_" + digest(manifest)[:20]
            or manifest_path.parent.name != current["release_id"]):
        raise ValueError("Resource identity or producer contract mismatch")
    paths = {k: relative(root, v) for k, v in current["resources"].items()}
    for kind, path in manifest["resources"].items():
        if paths.get(kind) != relative(root, path):
            raise ValueError("Resource stage path mismatch")
    declared = {relative(root, path): checksum for path, checksum in manifest["source_bindings"].items()}
    if len(declared) != 9:
        raise ValueError("Expected nine direct producer proof bindings")
    proofs = []
    for path, checksum in declared.items():
        actual = file_sha(safe_path(root, path))
        if actual != checksum:
            raise ValueError("Producer proof changed")
        proofs.append(dict(path=path, sha256=actual, verification="producer_declared_bytes_reverified"))
    alias_manifest = load_json(safe_path(root, Path(paths["aliases"]) / "run_manifest.json"))
    graph = load_json(safe_path(root, Path(paths["graph"]) / "summary.json"))
    hierarchy = load_json(safe_path(root, Path(paths["hierarchy"]) / "summary.json"))
    extraction = load_json(safe_path(root, Path(paths["semantic"]) / "run_manifest.json"))
    if (graph["run_id"] != Path(paths["graph"]).name or hierarchy["run_id"] != Path(paths["hierarchy"]).name
            or graph["status"] != "PASS" or hierarchy["status"] != "PASS"
            or graph["source_fingerprint"]["alias_run_id"] != Path(paths["aliases"]).name
            or hierarchy["source_fingerprint"]["graph_run_id"] != graph["run_id"]
            or hierarchy["source_fingerprint"]["graph_summary_sha256"] != declared[paths["graph"] + "/summary.json"]
            or extraction["run_id"] != Path(paths["semantic"]).name
            or extraction["extraction_contract_version"] != "cib-visibility-semantic-extraction/2.32"):
        raise ValueError("Mixed graph/hierarchy/alias/extraction lineage")
    for name, checksum in alias_manifest["output_sha256"].items():
        declared[relative(root, Path(paths["aliases"]) / name)] = checksum
    for path, checksum in graph["source_fingerprint"]["source_hashes"].items():
        declared[relative(root, Path("src-redaction") / path)] = checksum
    artifacts = {}
    for ref in current["required_artifacts"]:
        path = relative(root, ref["path"])
        if path in artifacts:
            if artifacts[path]["sha256"] != ref["sha256"]:
                raise ValueError("Conflicting artifact hashes")
            continue
        actual = file_sha(safe_path(root, path))
        expected = declared.get(path)
        if actual != ref["sha256"] or expected is not None and actual != expected:
            raise ValueError(f"Artifact changed: {path}")
        artifacts[path] = dict(path=path, sha256=actual, bytes=safe_path(root, path).stat().st_size,
            handoff_expected_sha256=ref["sha256"], producer_expected_sha256=expected,
            role=ref["role"], verification="producer_declared_bytes_reverified" if expected else
            "handoff_observed_bytes_reverified_not_producer_anchored")
    selected = {}
    def choose(name, base, suffix):
        path = str(Path(paths[base]) / suffix)
        if path not in artifacts:
            raise ValueError(f"Required consumer artifact missing from handoff: {path}")
        selected[name] = deepcopy(artifacts[path])
    for name, suffix in {"documents": "documents.jsonl", "pages": "views/earlier/pages.jsonl", "jobs": "extraction_jobs.jsonl",
            "quarantine": "canonical_page_quarantine.jsonl"}.items():
        choose(name, "prepared", suffix)
    for name in ("entity_mentions", "event_mentions", "claim_mentions", "relation_evidence"):
        choose(name, "semantic", "ledgers/" + name + ".jsonl")
    for name in ("canonical_entities", "mention_assignments", "reference_routes", "contextual_source_contexts",
            "accepted_alias_edges", "candidate_decisions", "projection_holds", "withheld_source_contexts", "identity_provenance"):
        choose(name, "aliases", name + ".jsonl")
    for name in ("semantic_nodes", "semantic_edge_evidence", "topology_edges"):
        choose(name, "graph", "views/earlier/" + name + ".jsonl")
    choose("memberships", "hierarchy", "views/earlier/node_assignments.jsonl")
    incumbent_path = safe_path(root, "src-demo-day/data/bindings.json")
    incumbents = load_json(incumbent_path)
    quarantine_ref = incumbents["corpora"]["cib"]["files"]["source_policy"]
    quarantine_path = safe_path(root, quarantine_ref["path"])
    if file_sha(quarantine_path) != quarantine_ref["sha256"]:
        raise ValueError("Incumbent conservative source quarantine changed")
    guard = load_json(quarantine_path)
    anchors = guard["source_pins"]
    for basename in ("canonical_pages.jsonl", "documents.jsonl"):
        current_path = paths["prepared"] + "/" + basename
        old_hashes = {v for k, v in anchors.items() if Path(k).name == basename}
        if old_hashes != {artifacts[current_path]["sha256"]}:
            raise ValueError("Quarantine cannot transfer across different prepared sources")
    selected["source_quarantine_policy"] = dict(path=relative(root, quarantine_path), sha256=quarantine_ref["sha256"],
        verification="consumer_conservative_guard_same_source_hashes_not_producer_clearance")
    registry = dict(version=VERSION, corpus="cib", resource_id=current["release_id"],
        resource_manifest=dict(path=relative(root, manifest_path), sha256=resource_ref["sha256"]),
        handoff_manifest=dict(path=relative(root, completion), sha256=expected_sha256),
        alias_id=Path(paths["aliases"]).name, graph_id=graph["run_id"], hierarchy_id=hierarchy["run_id"],
        extraction_contract=extraction["extraction_contract_version"], paths=paths,
        authority_contract=AUTHORITY_VERSION, files=selected, artifact_inventory=list(artifacts.values()),
        producer_proofs=proofs, evidence_policy="paired_earlier_strict_prior_whole_origin_quarantine",
        incumbent_registry_ref=dict(path=relative(root, incumbent_path), sha256=file_sha(incumbent_path)),
        incumbent_corpora={k: dict(status="INCUMBENT_NOT_MIGRATED", binding=deepcopy(incumbents["corpora"][k])) for k in ("iran", "vietnam")},
        ancestor_hashes_replayed=False, publication_shards_replayed=False,
        independent_identity_accuracy_established=False, retrospective_identities_and_hierarchy=True,
        benchmark_authorized=False, consumer_execution_accepted=False,
        limitations=["Pinned observations are not producer output commitments unless explicitly labelled.",
            "No cold rebuild, ancestor opinion replay, task evaluation or identity-accuracy claim.",
            "Iran/Vietnam successors are not adopted by this CIB migration."], api_calls=0)
    registry["registry_digest"] = digest(registry)
    check_registry(registry)
    if file_sha(completion) != expected_sha256:
        raise ValueError("Handoff changed during registry creation")
    return registry


def write_registry(registry, new_registry_path):
    check_registry(registry)
    immutable_json(new_registry_path, registry)
    return dict(path=str(new_registry_path), sha256=file_sha(new_registry_path), registry_digest=registry["registry_digest"])


def load_registry(workspace, path, *, expected_sha256):
    path = safe_path(workspace, path)
    if file_sha(path) != expected_sha256:
        raise ValueError("Registry file byte hash mismatch")
    return check_registry(load_json(path))


def verify_files(workspace, registry):
    check_registry(registry)
    for ref in registry["files"].values():
        if file_sha(safe_path(workspace, ref["path"])) != ref["sha256"]:
            raise ValueError(f"Consumer source artifact changed: {ref['path']}")
    if "registered_supplied_documents" in registry:
        from .supplemental_sources import Registration
        Registration(workspace,registry)
    return True


def create_supplied_registry(workspace, parent_registry_ref, source_manifest_ref):
    """New source availability edition; canonical KG resource identity is unchanged."""
    parent = load_registry(workspace,parent_registry_ref["path"],expected_sha256=parent_registry_ref["sha256"])
    if "registered_supplied_documents" in parent:
        raise ValueError("Use the canonical parent and a complete combined supplied-document manifest")
    from .supplemental_sources import Registration, VERSION as supplied_version
    source_path = safe_path(workspace,source_manifest_ref["path"])
    if file_sha(source_path) != source_manifest_ref["sha256"]:
        raise ValueError("Supplied source manifest changed")
    child = deepcopy(parent)
    child.pop("registry_digest")
    child.update(parent_registry_ref=deepcopy(parent_registry_ref),
        source_edition_id="source_edition_"+digest([parent["registry_digest"],source_manifest_ref])[:24],
        registered_supplied_documents=dict(version=supplied_version,manifest_ref=deepcopy(source_manifest_ref)),
        source_edition_scope="REGISTERED_FULL_PUBLIC_DOCUMENTS_RAW_ONLY_NOT_NEW_SEMANTIC_KG")
    child["files"]["supplied_documents"] = deepcopy(source_manifest_ref)
    child["registry_digest"] = digest(child)
    Registration(workspace,child)
    return check_registry(child)


def create_execution_registry(workspace, native_registry, incumbent_indexes):
    """Separate shared-digest envelope; native and file digests are not relabelled."""
    from matryoshka_demo.io import digest as shared_digest
    check_registry(native_registry)
    incumbent = load_json(safe_path(workspace, native_registry["incumbent_registry_ref"]["path"]))
    if file_sha(safe_path(workspace, native_registry["incumbent_registry_ref"]["path"])) != native_registry["incumbent_registry_ref"]["sha256"]:
        raise ValueError("Incumbent registry changed")
    result = dict(version="matryoshka-current-execution-registry/1", digest_contract="shared-json-ensure-ascii-true/sha256",
        native_registry_digest_contract="canonical-json-ensure-ascii-false/sha256", corpora={})
    result["corpora"]["cib"] = dict(corpus="cib", resource_id=native_registry["resource_id"],
        graph_id=native_registry["graph_id"], hierarchy_id=native_registry["hierarchy_id"],
        status="CURRENT_NATIVE_RESOURCE_EXPLICIT", identity_policy="source_only_typed_authority",
        native_registry=deepcopy(native_registry), native_registry_digest=native_registry["registry_digest"])
    if "source_edition_id" in native_registry:
        result["corpora"]["cib"]["source_edition_id"] = native_registry["source_edition_id"]
    result["corpora"]["cib"]["files"] = {name: deepcopy(native_registry["files"][source]) for name, source in {
        "documents": "documents", "pages": "pages", "nodes": "semantic_nodes", "edges": "semantic_edge_evidence",
        "entities": "entity_mentions", "events": "event_mentions", "claims": "claim_mentions",
        "relations": "relation_evidence", "assignments": "mention_assignments", "hierarchy": "memberships",
        "source_policy": "source_quarantine_policy"}.items()}
    for corpus in ("iran", "vietnam"):
        native = incumbent["corpora"][corpus]
        ref = deepcopy(incumbent_indexes[corpus])
        path = safe_path(Path(workspace) / "src-demo-day", ref["path"])
        if file_sha(path) != ref["sha256"] or ref["binding"] != native:
            raise ValueError("Explicit incumbent index is not bound to incumbent corpus")
        manifest = load_json(path.parent / "manifest.json")
        if manifest["binding"] != native or manifest["sha256"] != ref["sha256"]:
            raise ValueError("Incumbent completion manifest mismatch")
        result["corpora"][corpus] = dict(corpus=corpus, status="INCUMBENT_NOT_MIGRATED", graph_id=native["graph_id"],
            hierarchy_id=native["hierarchy_id"], identity_policy=native["identity_policy"],
            incumbent_binding=deepcopy(native), incumbent_index_ref=ref)
    result["sha256"] = shared_digest(result)
    return result


def execution_index_ref(registry, corpus_id, native_index_ref):
    from matryoshka_demo.io import digest as shared_digest
    if registry["sha256"] != shared_digest({k: v for k, v in registry.items() if k != "sha256"}):
        raise ValueError("Combined execution registry changed")
    binding = registry["corpora"][corpus_id]
    native = deepcopy(native_index_ref)
    path = native["path"]
    if corpus_id == "cib":
        prefix = "src-demo-day/"
        if not path.startswith(prefix):
            raise ValueError("Current execution index must be under explicit demo root")
        path = path[len(prefix):]
    elif native != binding["incumbent_index_ref"]:
        raise ValueError("Incumbent native index differs from envelope")
    return dict(path=path, sha256=native["sha256"], registry_sha256=registry["sha256"], corpus=corpus_id,
        source_binding_sha256=shared_digest(binding), native_index_ref=native,
        resource_id=binding.get("resource_id"), source_status=binding["status"])


class ResourceContext(SimpleNamespace):
    def __enter__(self):
        return self

    def close(self):
        if getattr(self, "index", None) is not None:
            self.index.__exit__(None, None, None)
            self.index = None

    def __exit__(self, *args):
        self.close()


def open_context(root, registry_ref, index_ref, corpus_id):
    """Herschel execution handshake. Root and reference paths use src-demo-day."""
    from matryoshka_demo.io import digest as shared_digest
    from .index import CorpusIndex, IndexedCorpus
    root = Path(root).absolute()
    registry_path = safe_path(root, registry_ref["path"])
    if file_sha(registry_path) != registry_ref["sha256"]:
        raise ValueError("Execution envelope file byte pin changed")
    registry = load_json(registry_path)
    if (registry.get("version") != "matryoshka-current-execution-registry/1"
            or registry.get("sha256") != shared_digest({k: v for k, v in registry.items() if k != "sha256"})):
        raise ValueError("Execution envelope contract or canonical hash mismatch")
    binding = registry["corpora"][corpus_id]
    if (index_ref.get("corpus") != corpus_id or index_ref.get("registry_sha256") != registry["sha256"]
            or index_ref.get("source_binding_sha256") != shared_digest(binding)):
        raise ValueError("Mixed execution registry/index/corpus")
    path = safe_path(root, index_ref["path"])
    if file_sha(path) != index_ref["sha256"]:
        raise ValueError("Execution index byte pin changed")
    native = index_ref["native_index_ref"]
    if native["sha256"] != index_ref["sha256"]:
        raise ValueError("Native and envelope index byte pins differ")
    if corpus_id == "cib":
        current = binding["native_registry"]
        check_registry(current)
        if current["registry_digest"] != binding["native_registry_digest"] or current["resource_id"] != binding["resource_id"]:
            raise ValueError("Nested native resource changed")
        if safe_path(root.parent, native["path"]) != path:
            raise ValueError("CIB index root adaptation changed target")
        source_index = CorpusIndex(root.parent, current, native)
        try:
            corpus = IndexedCorpus(source_index, binding)
        except Exception:
            source_index.__exit__(None, None, None)
            raise
        return ResourceContext(registry=registry, registry_ref=deepcopy(registry_ref), index_ref=deepcopy(index_ref),
            corpus=corpus, source_index=source_index.db, index=source_index)
    if corpus_id not in {"iran", "vietnam"} or binding["status"] != "INCUMBENT_NOT_MIGRATED" or native != binding["incumbent_index_ref"]:
        raise ValueError("Unsupported or silently replaced incumbent")
    manifest = load_json(path.parent / "manifest.json")
    if manifest["binding"] != binding["incumbent_binding"] or manifest["sha256"] != native["sha256"]:
        raise ValueError("Incumbent index manifest changed")
    from matryoshka_demo.corpus import Corpus
    from matryoshka_demo.corpus_policy_v5 import policy_view
    corpus = policy_view(Corpus(root.parent, binding["incumbent_binding"]))
    return ResourceContext(registry=registry, registry_ref=deepcopy(registry_ref), index_ref=deepcopy(index_ref),
        corpus=corpus, source_index={p["id"]: p for p in corpus.pages}, index=None)
