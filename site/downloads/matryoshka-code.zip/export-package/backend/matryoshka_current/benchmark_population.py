"""Exposure-aware CIB population preflight, without inference or API calls."""
from copy import deepcopy
from pathlib import Path

from . import exposure, index, planning, resources

VERSION = "current-cib-population-preflight/1"


def _reference(value):
    return {key: value[key] for key in ("path", "sha256")}


def load(demo_root, *, registry_ref, index_ref, base_ref, overlay_ref):
    """The current benchmark input path; frozen base partitions never suffice.

    This certifies local source/exposure consistency, not readiness, historical
    availability, absence of other exposure, or permission to launch evaluation.
    """
    root = Path(demo_root).resolve()
    population = exposure.load_population(root.parent, base_ref, overlay_ref)
    registry = planning.read_ref(root, registry_ref)
    cases = [dict(row["case"], task="redaction", corpus="cib") for row in population["cases"]]
    bindings = [planning.validate_registry(registry, index_ref, case) for case in cases]
    if not bindings or any(binding != bindings[0] for binding in bindings):
        raise ValueError("One explicit CIB resource must bind the complete population")
    binding = bindings[0]
    if binding["status"] != "CURRENT_NATIVE_RESOURCE_EXPLICIT":
        raise ValueError("Current benchmark cannot silently use an incumbent CIB resource")
    native = binding["native_registry"]
    if resources.execution_index_ref(registry, "cib", index_ref["native_index_ref"]) != index_ref:
        raise ValueError("Native and execution index references differ")
    resources.verify_files(root.parent, native)
    canonical = [ref for ref in native["artifact_inventory"]
        if ref["path"] == native["paths"]["prepared"] + "/canonical_pages.jsonl"]
    if len(canonical) != 1:
        raise ValueError("Exactly one bound canonical prepared-page inventory is required")
    source_refs = dict(canonical_pages=_reference(canonical[0]),
        documents=_reference(native["files"]["documents"]),
        quarantine=_reference(native["files"]["source_quarantine_policy"]))
    scope = exposure.validate_dataset_scope(root.parent, base_ref, overlay_ref, source_refs)
    with index.open_index(root.parent, native, index_ref["native_index_ref"]) as opened:
        origins = {row["id"]: row["date"] for row in opened.db.execute("SELECT id,date FROM document")}
        for case in cases:
            if origins.get(case["document_id"]) != case["date"]:
                raise ValueError("Population origin/date is missing from the pinned source index")
            opened._case(case)
        source_binding = deepcopy(opened.binding)
    if planning.read_ref(root, registry_ref) != registry:
        raise ValueError("Registry changed during population preflight")
    return dict(population=population, source_scope=scope, registry_ref=deepcopy(registry_ref),
        index_ref=deepcopy(index_ref), resource_binding=source_binding,
        version=VERSION, status="SOURCE_AND_EXPOSURE_CONSISTENT_NOT_EVALUATION_READY",
        source_eligibility_must_be_applied_per_query=True,
        algorithm_or_assessment_frozen=False, full_evaluation_authorized=False,
        untouched_reserved_certified=False, native_outputs_modified=False, api_calls=0)


def main(argv=None):
    import argparse
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--refs", required=True)
    parser.add_argument("--refs-sha256", required=True)
    parser.add_argument("--overlay", required=True)
    parser.add_argument("--overlay-sha256", required=True)
    args = parser.parse_args(argv)
    refs = planning.read_ref(args.root, dict(path=args.refs, sha256=args.refs_sha256))
    value = load(args.root, registry_ref=refs["registry_ref"], index_ref=refs["index_refs"]["cib"],
        base_ref=exposure.POLICY["base_ref"], overlay_ref=dict(path=args.overlay, sha256=args.overlay_sha256))
    population = value.pop("population")
    value.update(targets=population["targets"], documents=population["documents"],
        effective_partition_counts=population["partition_counts"],
        base_partition_counts=population["base_partition_counts"],
        newly_exposed_documents=population["newly_exposed_documents"],
        newly_exposed_targets=population["newly_exposed_targets"])
    print(json.dumps(value, sort_keys=True))


if __name__ == "__main__":
    main()
