"""Current-only additive compound proposals; shared V6 code stays immutable.

Literal attachment is construction provenance, not owner identity, title
equivalence, factual support, or permission to discard source operators.
The caller still supplies the already policy-checked native source pool.
"""
from copy import deepcopy
import re
from types import SimpleNamespace

from matryoshka_demo import source_constituents_v23 as baseline
from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo_v61 import candidates
from . import planning, degree_checks
from .arm_controls import matched_display


VERSION = "current-owned-compound-construction/2.2"
ROUTE = "COMPLETE_SOURCE_ATTACHED_NOMINAL_COMPOUND"


def _proof(token, raw):
    return dict(start=token.idx, end=token.idx + len(token),
                text=raw[token.idx:token.idx + len(token)], dependency=token.dep_,
                head_start=token.head.idx, pos=token.pos_, tag=token.tag_)


def _scope(head, raw):
    path = []
    for token in (head, *head.ancestors):
        if token.sent != head.sent:
            break
        operators = [c for c in token.children if c.dep_ in
                     {"neg", "aux", "auxpass", "cop", "mark", "advmod", "det"}]
        path.append(dict(token=_proof(token, raw),
                         qualifiers=[_proof(c, raw) for c in operators]))
    return path


def _compound(head, original, raw, *, rejections=None):
    carrier = head.head
    if (head.dep_ != "compound" or head.pos_ != "NOUN" or carrier.pos_ not in {"NOUN", "PROPN"}
            or head.ent_type_ == "PERSON" or carrier.ent_type_ == "PERSON" or head.i >= carrier.i
            or head.sent != carrier.sent):
        return None
    selected = list(head.subtree)
    if not selected or max(t.i for t in selected) >= carrier.i:
        return None
    part = head.doc[min(t.i for t in selected):max(t.i for t in selected) + 1]
    if part[0].sent != part[-1].sent:
        return None
    # An entire dependent subtree is required; no clipped complements or
    # uncertain coordination is turned into a new bare modifier.
    if any(not t.is_space and t.i not in {s.i for s in selected} for t in part):
        return None
    if any(t.pos_ in {"VERB", "AUX", "ADP", "SCONJ", "CCONJ", "X", "SYM"}
           or t.dep_ in {"acl", "relcl", "advcl", "ccomp", "conj", "cc", "preconj"}
           or t.is_punct and t.text not in {"-"} for t in part):
        return None
    if MASK.search(raw[part.start_char:carrier.idx + len(carrier)]):
        return None
    literal = original.char_span(part.start_char, part.end_char, alignment_mode="strict")
    raw_carrier = original.char_span(carrier.idx, carrier.idx + len(carrier), alignment_mode="strict")
    if literal is None or raw_carrier is None or any(t.ent_type_ == "PERSON" for t in literal):
        return None
    sentence = literal.root.sent
    # Native quotations come from this original-Doc head, not the lowercase
    # dependency view. Both the complete modifier and its carrier must belong
    # to that exact source unit before the new proposal can be constructed.
    if (not sentence.start_char <= literal.start_char < literal.end_char <= sentence.end_char
            or not sentence.start_char <= raw_carrier.start_char < raw_carrier.end_char <= sentence.end_char):
        if rejections is not None:
            rejections.append(dict(version=VERSION,route=ROUTE,
                reason="ORIGINAL_SOURCE_SENTENCE_DOES_NOT_OWN_COMPLETE_MODIFIER_AND_CARRIER",
                source_text_sha256=digest(raw),source_span=[literal.start_char,literal.end_char],
                source_wording=raw[literal.start_char:literal.end_char],
                modifier_head=_proof(head,raw),carrier=_proof(carrier,raw),
                normalized_sentence_span=[head.sent.start_char,head.sent.end_char],
                original_head_sentence_span=[sentence.start_char,sentence.end_char],
                original_carrier_sentence_span=[raw_carrier.root.sent.start_char,raw_carrier.root.sent.end_char],
                accepted=False,source_text_modified=False,native_exception_suppressed=False))
        return None
    return part, carrier, literal, raw_carrier


def proposal_spans(text, parse, *, rejections=None):
    """Append raw-owned noun compounds without changing baseline rows/order."""
    original, old = baseline.proposal_spans(text, parse)
    values = list(old)
    seen = {(r["start"], r["end"], r["kind"]) for r in old}
    view, normalization = original, "ORIGINAL_PAGE_ANALYSIS"
    lowered = text.lower()
    if text.isupper() and lowered != text and len(lowered) == len(text):
        view, normalization = parse(lowered), "LOWERCASE_PAGE_SAME_RAW_OFFSETS"
    routing, sections = baseline.format_regions(text, view)
    source_hash = None
    for head in view:
        found = _compound(head, original, text, rejections=rejections)
        if found is None:
            continue
        part, carrier, literal, raw_carrier = found
        a, b = part.start_char, part.end_char
        key = a, b, "modifier"
        if key in seen or any(a < hi and carrier.idx + len(carrier) > lo for lo, hi in routing + sections):
            continue
        source_hash = source_hash or digest(text)
        certificate = dict(version=VERSION, route=ROUTE, source_span=[a, b],
            source_text_sha256=source_hash, normalization=normalization,
            modifier_head=_proof(head, text), carrier=_proof(carrier, text),
            source_sentence_span=[head.sent.start_char, head.sent.end_char],
            original_source_sentence_span=[literal.root.sent.start_char,literal.root.sent.end_char],
            original_quote_owns_complete_modifier_and_carrier=True,
            source_scope_chain=_scope(head, text), complete_modifier_subtree=True,
            raw_words_modified=False, owner_identity_certified=False,
            title_equivalence_certified=False, factual_support_certified=False)
        values.append(dict(kind="modifier", head=literal.root, owner=raw_carrier.root,
            text=text[a:b], edited=text[a:b], start=a, end=b,
            source_constituent=certificate))
        seen.add(key)
    return original, values


def _lemma(token):
    return (token.lemma_ or token.text).casefold()


def _nominal_carrier(part):
    head = part.root
    if head.dep_ in {"amod", "compound", "acl"} and head.head not in part and head.head.pos_ in {"NOUN", "PROPN"}:
        return head.head
    governor = head.head if head.dep_ in {"acomp", "attr"} and _lemma(head.head) == "be" else head
    subjects = [c for c in governor.children if c.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"}
                and c.pos_ in {"NOUN", "PROPN"}]
    predicative = head.pos_ == "ADJ" and _lemma(governor) == "be"
    passive = head.tag_ == "VBN" and any(c.dep_ in {"auxpass", "aux:pass"} for c in head.children)
    return subjects[0] if len(subjects) == 1 and (predicative or passive) else None


def _query_carrier(case, reading, completed, part, parse):
    left, right = case["query"].split(case["focal_marker"])
    quote = reading.get("attachment_quote", "").strip()
    # A grammar annotation locates literal adjacent words, never an entity
    # alias or a semantic title. B's empty annotation uses the completed parse.
    if quote:
        words = quote.split()
        match = re.match(r"\s*(" + r"\s+".join(re.escape(w) for w in words) + r")(?!\w)", right, re.I)
        if match:
            raw = right[match.start(1):match.end(1)]
            view = raw.lower() if raw.isupper() and len(raw.lower()) == len(raw) else raw
            doc = parse(view)
            roots = [t for t in doc if t.dep_ == "ROOT" and t.pos_ in {"NOUN", "PROPN"}]
            if len(roots) == 1 and not any(t.pos_ in {"VERB", "AUX", "PRON"} for t in doc):
                head = roots[0]
                offset = len(left) + len(part.text) + match.start(1)
                bound = completed.char_span(offset + head.idx, offset + head.idx + len(head), alignment_mode="strict")
                if bound is not None:
                    return bound.root, dict(kind="LITERAL_ADJACENT_ATTACHMENT_HEAD",
                        query_span=[len(left) + len(part.text) + match.start(1), len(left) + len(part.text) + match.end(1)],
                        text=raw, lemma=_lemma(head))
    head = _nominal_carrier(part)
    if head is not None and head.idx >= part.end_char:
        while head.dep_ == "compound" and head.head.pos_ == "NOUN" and head.head.idx > head.idx:
            head = head.head
        return head, dict(kind="COMPLETED_LOCAL_NOMINAL_HEAD", lemma=_lemma(head))
    return None, dict(kind="LOCAL_HEAD_UNRESOLVED")


def _nominal_tokens(carrier):
    root = carrier
    while root.dep_ in {"compound", "flat", "flat:name", "appos"} and root.head.pos_ in {"NOUN", "PROPN"}:
        root = root.head
    selected, pending = {root}, [root]
    while pending:
        token = pending.pop()
        for child in token.children:
            if child.dep_ in {"compound", "flat", "flat:name", "appos", "conj"} and child not in selected:
                selected.add(child)
                pending.append(child)
    return selected


def _owners(carrier):
    selected = _nominal_tokens(carrier)
    names = {" ".join(_lemma(t) for t in entity) for entity in carrier.doc.ents
             if entity.label_ == "PERSON" and all(t in selected for t in entity)}
    possessors = [tuple(_lemma(t) for t in child.subtree if not t.is_space and not t.is_punct)
                  for child in carrier.children if child.dep_ in {"poss", "nmod:poss"}]
    preps = {_lemma(child):tuple(_lemma(t) for t in child.subtree if not t.is_space and not t.is_punct)
             for child in carrier.children if child.dep_ == "prep"}
    quantities = [tuple(_lemma(t) for t in child.subtree if not t.is_space and not t.is_punct)
                  for child in carrier.children if child.dep_ in {"nummod", "quantmod"}
                  or child.dep_ == "det" and "Art" not in child.morph.get("PronType")]
    return dict(names=sorted(names), possessors=possessors, identifying_prepositions=preps,
                quantities=quantities)


def modifier_checks(case, reading, proposal, context):
    """Positive syntactic relevance and a bounded comparative license only."""
    neutral = dict(positive=False, reason="NOT_A_MODIFIER", factual_support_certified=False,
                   named_identity_certified=False, title_equivalence_certified=False,
                   absence_is_counterevidence=False)
    degree = dict(applies=False, omit=False, status="NOT_APPLICABLE", factual_support_certified=False,
                  english_ungrammaticality_certified=False, absence_is_counterevidence=False)
    is_modifier = reading.get("form") == "modifier"
    page = context.replay(proposal["sources"][0])
    context.phrase(proposal)
    source, normalization = context.grammar_phrase(proposal)
    left, right = case["query"].split(case["focal_marker"])
    raw = left + proposal["fill"] + right
    doc = context.parse(raw)
    part = doc.char_span(len(left),len(left) + len(proposal["fill"]),alignment_mode="strict")
    if part is None:
        return dict(alignment=dict(neutral,reason="COMPLETED_TOKEN_ALIGNMENT_UNRESOLVED"), comparative=degree)
    source_carrier = _nominal_carrier(source)
    query_carrier, binding = _query_carrier(case,reading,doc,part,context.parse)
    aligned = dict(neutral,reason="CARRIER_ALIGNMENT_UNRESOLVED",query_binding=binding,
        source_span=list(proposal.get("fitted_source_span") or proposal["source_span"]),
        source_page_id=page["id"],source_sha256=page["source_sha256"],source_analysis=normalization,
        source_scope_chain=_scope(source.root,page["text"]))
    if is_modifier and source_carrier is not None and query_carrier is not None:
        wanted, offered = _owners(query_carrier), _owners(source_carrier)
        same = binding.get("lemma",_lemma(query_carrier)) == _lemma(source_carrier)
        owner_missing = (wanted["names"] and offered["names"] and not set(wanted["names"]) & set(offered["names"]))
        owner_missing = owner_missing or (wanted["possessors"] and offered["possessors"]
                                         and wanted["possessors"] != offered["possessors"])
        owner_missing = owner_missing or (wanted["quantities"] and wanted["quantities"] != offered["quantities"])
        owner_missing = owner_missing or any(k in offered["identifying_prepositions"]
            and v != offered["identifying_prepositions"][k] for k,v in wanted["identifying_prepositions"].items())
        aligned.update(positive=bool(same and not owner_missing),
            reason="OWNED_LOCAL_CARRIER_HEAD_ALIGNED" if same and not owner_missing else
                "EXPLICIT_LOCAL_OWNER_NOT_ALIGNED_NEUTRAL" if owner_missing else "CARRIER_HEAD_NOT_ALIGNED_NEUTRAL",
            source_carrier=_proof(source_carrier,page["text"]),query_carrier=_proof(query_carrier,raw),
            query_owner_constraints=wanted,source_owner_constraints=offered,
            complete_named_owner_binding_certified=False)
    shell = re.search(r"\b(?:a|an)\s+(more|less)\s*$",left,re.I)
    after = next((t for t in doc if t.idx >= part.end_char and not t.is_space),None)
    singular = after is not None and after.pos_ == "NOUN" and (after.tag_ == "NN" or "Sing" in after.morph.get("Number"))
    if not (shell and singular):
        return dict(alignment=aligned,comparative=degree)
    degree_part = doc.char_span(shell.start(1),shell.end(1),alignment_mode="strict")
    if degree_part is None:
        return dict(alignment=aligned,comparative=dict(degree,status="UNRESOLVED_DEGREE_TOKEN"))
    operator = degree_part.root
    property_head = lambda t:t.pos_ == "ADJ" or t.tag_ in {"VBN", "VBG"}
    modifies_property = operator.dep_ == "advmod" and operator.head in part
    degree.update(applies=True,status="UNRESOLVED",source_head=_proof(source.root,page["text"]),
        query_head=_proof(part.root,raw),visible_carrier=_proof(after,raw),degree=_proof(operator,raw),
        degree_modifies_inserted_property=modifies_property)
    source_modifier = source.root.dep_ in {"amod", "acl", "compound"} and source_carrier is not None
    if (property_head(part.root) and (property_head(source.root) or source_modifier)
            and part.root.dep_ in {"amod", "acl"} and part.root.head == after and modifies_property):
        degree["status"] = "LICENSED_ADJECTIVAL_PARTICIPIAL_OR_SOURCE_MODIFIER"
    elif source.root.pos_ in {"NOUN", "PROPN", "PRON"} and not property_head(part.root):
        prior = [t for t in source.doc[:source.root.i] if not t.is_space][-2:]
        attested = (source_modifier and source_carrier is not None and _lemma(source_carrier) == _lemma(after)
            and part.root.dep_ in {"amod","compound"} and part.root.head == after
            and len(prior) == 2 and prior[0].lower_ in {"a","an"} and prior[1].lower_ == shell.group(1).casefold()
            and prior[1].head in {source.root,source_carrier})
        degree.update(status="LICENSED_SOURCE_ATTESTED_NOMINAL_DEGREE" if attested else
                      "UNLICENSED_NOMINAL_COMPARATIVE_PROPERTY",omit=not attested)
    return dict(alignment=aligned,comparative=degree)


def _construct(case, derived, retrieval, *, passage_budget, top_k):
    registry = {}
    boundary_rejections = {}

    def spans(text, parse):
        rejected = []
        doc, rows = proposal_spans(text, parse,rejections=rejected)
        for rejection in rejected:
            key = (rejection["source_text_sha256"],*rejection["source_span"],rejection["carrier"]["start"])
            boundary_rejections[key] = rejection
        for row in rows:
            proof = row.get("source_constituent", {})
            if proof.get("version") == VERSION:
                registry[proof["source_text_sha256"], row["start"], row["end"]] = proof
        return doc, rows

    native = candidates.native_candidates

    def joint_fit(proposal, reading, context):
        value = native.joint_fit(proposal,reading,context)
        if value["admissible"]:
            checks = modifier_checks(case,reading,proposal,context)
            degree = degree_checks.check(case,reading,proposal,context)
            value = dict(value,current_modifier_checks=checks,current_degree_checks=degree,
                native_joint_fit_admissible=True)
            if checks["comparative"]["omit"]:
                value.update(admissible=False,reasons=value["reasons"] + ["CURRENT_COMPARATIVE_PROPERTY_LICENSE_MISSING"])
            if degree["omit"]:
                value.update(admissible=False,reasons=value["reasons"] + ["CURRENT_DUPLICATED_SCOPED_DEGREE_WITHHELD"])
        return value

    def features(proposal, context, *, reading=None, source_fit=None):
        value = native.features(proposal,context,reading=reading,source_fit=source_fit)
        value["current_modifier_carrier_aligned"] = bool((source_fit or {}).get(
            "current_modifier_checks",{}).get("alignment",{}).get("positive"))
        return value

    def rank_key(proposal, values, index):
        original = native.rank_key(proposal,values,index)
        return (*original[:2],not values.get("current_modifier_carrier_aligned",False),*original[2:])

    _, functions = clone(native, dict(
        __package__="matryoshka_current", boundary_fit=candidates.boundary_fit,
        Context=candidates.Context, task_execution=candidates._admission,
        constituents=SimpleNamespace(proposal_spans=spans), VERSION=VERSION,
        joint_fit=joint_fit,features=features,rank_key=rank_key,
        RANK_TIERS=(*native.RANK_TIERS[:2],"source_owned_local_modifier_carrier",*native.RANK_TIERS[2:])))
    value = functions["construct"](case, derived, retrieval,
                                    passage_budget=passage_budget, top_k=top_k)
    count = 0
    for row in value["_candidate_audit"]["readings"]:
        for candidate in row["proposals"]:
            source = candidate["sources"][0]
            proof = registry.get((source["page_sha256"], *candidate["source_span"]))
            if proof is not None:
                candidate["current_owned_modifier"] = deepcopy(proof)
                count += 1
    by_id = {c["id"]:c for row in value["_candidate_audit"]["readings"] for c in row["proposals"]}
    for row in value["readings"]:
        for candidate in row["candidates"]:
            proof = by_id[candidate["id"]].get("current_owned_modifier")
            if proof is not None:
                candidate["current_owned_modifier"] = deepcopy(proof)
    value["current_owned_modifier_construction"] = dict(version=VERSION,
        source_enumerated_additions=len(registry), admitted_proposals=count,
        baseline_constituents_preserved=True, baseline_order_preserved=True,
        shared_native_modules_changed=False, rank_rules_changed=True,
        source_policy_changed=False, identity_rules_changed=False,
        comparative_grammar_changed=True, factual_support_certified=False,
        degree_guard_version=degree_checks.VERSION,
        precedence="Existing boundary tiers; positive owned local carrier; unchanged remaining rank tuple",
        missing_alignment_is_neutral=True,comparative_is_bounded_insertion_policy=True,
        newly_displayed_candidates_use_unchanged_native_counter_assessor=True)
    value["current_owned_modifier_construction"]["source_boundary_rejections"] = list(boundary_rejections.values())
    return value


def construct_redaction(case, plan, retrieval, *, passage_budget=100, top_k=5):
    """Drop-in current redaction entry; lead wires it after this module freezes."""
    case = public_case(case)
    if case["task"] != "redaction":
        raise ValueError("Current compound construction is redaction-only")
    derived = planning.construction_plan(case, plan)
    control = derived["current_derivation"]["controls"]
    if plan["arm"] == "llm_readings" and not control["saved_readings"]:
        return dict(version=VERSION, task="redaction", status="MODEL_READING_ABSTENTION", readings=[],
            arm_controls=control, matched_display=[], inspected_page_ids=[],
            source_pages_inspected=0, passage_budget=passage_budget,
            api_calls=0, keys_read=False, grades_read=False)
    with offline():
        result = _construct(case, derived, retrieval, passage_budget=passage_budget, top_k=top_k)
        result = candidates.filter_redaction(case, result, top_k=top_k,
            retrieval=retrieval, passage_budget=passage_budget)
    result.update(current_construction_version=planning.CONSTRUCTION_VERSION,
        arm_controls=control, construction_plan_sha256=digest(derived),
        saved_query_plan_sha256=digest(plan), matched_display=matched_display(result["readings"], budget=5),
        per_branch_display_total=sum(len(r["candidates"]) for r in result["readings"]),
        global_diagnostic_display_budget=5, mechanical_branches_collapsed=False,
        old_ranks_reused=False)
    return result


construct = construct_redaction
