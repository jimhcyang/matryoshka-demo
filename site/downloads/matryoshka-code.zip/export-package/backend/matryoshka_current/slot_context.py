"""Literal base-visible slot context, never a concealed-value inference."""
import re

POLICY = "source-visible-slot-context/1"
MARKER = re.compile(r"\[\[REDACTION_SLOT:\d+:(slot_[a-f0-9]+)\]\]|\[REDACTED\]")
TOKEN = re.compile(r"\w+", re.UNICODE)
ANCHOR_KEYS = ("id", "type", "label", "domain_id", "theme_id", "community_id",
               "reference_scope", "instance_identity_asserted")
FUNCTION_WORDS = frozenset("""a an the this that these those all any both each either every neither no some
another other such what whatever which whichever who whom whose whoever
i me my mine myself we us our ours ourselves you your yours yourself yourselves
he him his himself she her hers herself it its itself they them their theirs themselves
and or but nor so yet for as if than because although though while unless until
of to in on at by from with without into onto upon about above below over under
between among through throughout during before after since around near beyond
is am are was were be been being do does did doing have has had having
can could may might must shall should will would not never only also even just
very too quite rather much more most less least many few several enough
here there where when why how then now once again still already almost
""".split())
# Standalone roles, directions and modifiers do not identify a source referent.
# They remain valid inside complete names/titles (e.g. General + surname).
FRAGMENTS = frozenset("""
general major chief president minister secretary director chairman commander
deputy assistant acting former latter first second third last next new old
north south east west northern southern eastern western central foreign
national international federal regional local state government public official
military political economic current intelligence office department ministry
committee council party army force forces united supreme report march june july
august september october november december january february april
mr mrs ms dr professor sir madam captain colonel lieutenant marshal
city town country capital province region area place nation people person
man woman men women member members official officials group organization
""".split())


def substantive(label):
    if (not isinstance(label, str) or not 3 <= len(label) <= 120
            or not label[0].isalnum() or not label[-1].isalnum()
            or "redact" in label.casefold()):
        return False
    words = TOKEN.findall(label.casefold())
    content = [word for word in words if word not in FUNCTION_WORDS]
    return bool(content and any(any(c.isalpha() for c in w) for w in content)
                and not (len(content) == 1 and content[0] in FRAGMENTS)
                and words[-1] not in FUNCTION_WORDS)


def context_preview(text, start, end):
    left, right = max(0, start - 960), min(len(text), end + 960)
    # Do not manufacture partial words at the search-window boundary.
    while left and left < start and text[left - 1].isalnum():
        left += 1
    while right < len(text) and right > end and text[right - 1].isalnum():
        right -= 1
    return text[left:right]


def _name_fragment(text, start, end):
    """A bare token in a visibly longer capitalized name is not a whole term."""
    before = re.search(r"(\w+)[ \t-]+$", text[:start])
    after = re.match(r"[ \t-]+(\w+)", text[end:])
    for neighbor in (before.group(1) if before else "", after.group(1) if after else ""):
        if neighbor and neighbor[0].isupper() and neighbor.casefold() not in FUNCTION_WORDS:
            return True
    return False


class VisibleVocabulary:
    def __init__(self, records):
        labels = {}
        for row in records:
            label = row.get("label", "")
            if (row.get("type") != "Entity" or row.get("visibility") == "later_only"
                    or not substantive(label)):
                continue
            key = label.casefold()
            labels[key] = None if key in labels else {k: row.get(k) for k in ANCHOR_KEYS}
        self.labels = {key: row for key, row in labels.items() if row is not None}
        self.trie = {}
        for key, row in self.labels.items():
            branch = self.trie
            for word in TOKEN.findall(key):
                branch = branch.setdefault(word, {})
            branch.setdefault("", []).append(row)

    def anchors(self, text, start, end):
        left, right = max(0, start - 320), min(len(text), end + 320)
        tokens = list(TOKEN.finditer(text, left, right))
        candidates = []
        for i, token in enumerate(tokens):
            branch = self.trie
            for j in range(i, len(tokens)):
                branch = branch.get(tokens[j].group().casefold())
                if branch is None:
                    break
                for row in branch.get("", ()):
                    # Whitespace can wrap on a source page; punctuation cannot disappear.
                    pattern = r"\s+".join(re.escape(p) for p in row["label"].split()) + r"(?!\w)"
                    match = re.match(pattern, text[token.start():], re.I)
                    if not match:
                        continue
                    a, b = token.start(), token.start() + match.end()
                    if (b > right or a and (text[a - 1].isalnum() or text[a - 1] == "_")
                            or a < end and b > start or MARKER.search(text[a:b])):
                        continue
                    multi = len(TOKEN.findall(row["label"])) > 1
                    if not multi and _name_fragment(text, a, b):
                        continue
                    distance = min(abs(a - end), abs(b - start))
                    candidates.append((not multi, distance, -(b - a), a, row["id"], row, b))
        # Suppress nested fragments before deduplication or the six-anchor cap.
        spans = [(c[3], c[6]) for c in candidates if not c[0]]
        matches = {}
        for item in candidates:
            _, _, _, a, identity, _, b = item
            if any(c <= a and b <= d and (c, d) != (a, b) for c, d in spans):
                continue
            if identity not in matches or item[:5] < matches[identity][:5]:
                matches[identity] = item
        return [(row, a, b, text[a:b]) for _, _, _, a, _, row, b in
                sorted(matches.values(), key=lambda item: item[:5])[:6]]


def label_context(text, start, end, anchors):
    """Choose one short, verbatim, mask-free excerpt, preferably around an anchor."""
    if anchors:
        _, a, b, literal = anchors[0]
        return a, b, literal
    regions, cursor = [], max(0, start - 320)
    right = min(len(text), end + 320)
    for marker in MARKER.finditer(text, cursor, right):
        regions.append((cursor, marker.start()))
        cursor = marker.end()
    regions.append((cursor, right))
    choices = []
    for c, d in regions:
        for part in re.finditer(r"[^\n.!?;]+", text[c:d]):
            a, b = c + part.start(), c + part.end()
            if any(w.casefold() not in FUNCTION_WORDS for w in TOKEN.findall(text[a:b])):
                choices.append((min(abs(a - end), abs(b - start)), a, b))
    if not choices:
        return None
    _, a, b = min(choices)
    if b - a > 88:
        if b <= start:
            a = b - 88
            while a < b and a and text[a - 1].isalnum():
                a += 1
        else:
            b = a + 88
            while b > a and b < len(text) and text[b - 1].isalnum() and text[b].isalnum():
                b -= 1
    region = (a, b)
    c, d = region
    # Sentence/line boundaries keep unrelated headers out of short display names.
    before = list(re.finditer(r"[\n.!?;]", text[c:a]))
    if before:
        c += before[-1].end()
    after = re.search(r"[\n.!?;]", text[b:d])
    if after:
        d = b + after.start()
    c = max(c, a - 28)
    d = min(d, max(b, c + 88))
    if d - c > 120:
        c, d = a, b
    while c < a and c and text[c - 1].isalnum():
        c += 1
    while d > b and d < len(text) and text[d - 1].isalnum() and text[d].isalnum():
        d -= 1
    while c < d and text[c].isspace():
        c += 1
    while d > c and text[d - 1].isspace():
        d -= 1
    return (c, d, text[c:d]) if c < d else None
