"""Detached, explicitly pinned postrun origin display. Never inference input."""
from copy import deepcopy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import re

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest
from . import planning

VERSION = "current-bound-origin-display/1"
_PUBLIC = {"case_id", "corpus", "task", "document_id", "date", "query", "focal_marker"}
_HASH = re.compile(r"[0-9a-f]{64}")
_PENDING = "Lead must attach and independently validate exact completed current checkpoint, case/query, registry/index and plan bindings before serving a postrun route."


def _require(test, message):
    if not test:
        raise ValueError(message)


def _path(root, ref):
    _require(isinstance(ref, dict) and isinstance(ref.get("path"), str)
        and isinstance(ref.get("sha256"), str) and _HASH.fullmatch(ref["sha256"]), "Byte-pinned origin reference required")
    path = planning.bound(root, ref["path"])
    _require(planning.byte_sha(path) == ref["sha256"], "Origin/source/index bytes changed: " + ref["path"])
    return path


def _read(root, ref):
    path = _path(root, ref)
    raw = path.read_bytes()
    _require(hashlib.sha256(raw).hexdigest() == ref["sha256"], "Reference changed during origin read")
    return json.loads(gzip.decompress(raw) if path.suffix == ".gz" else raw)


def _rows(path, field, value):
    with path.open() as stream:
        return [row for line in stream if line.strip() for row in [json.loads(line)] if row.get(field) == value]


def _span(span, text):
    a, b = span.get("start"), span.get("end")
    _require(type(a) is int and type(b) is int and 0 <= a < b <= len(text)
        and text[a:b] == span.get("text"), "Original birth span does not replay")
    _require(span.get("quote_sha256") == digest(span["text"]), "Original birth quote hash changed")


def _view(view):
    text = view.get("text")
    _require(isinstance(text, str) and view.get("text_sha256") == digest(text), "Full origin text hash changed")
    if "text_utf8_sha256" in view:
        _require(view["text_utf8_sha256"] == hashlib.sha256(text.encode()).hexdigest(), "Full origin UTF-8 hash changed")
    _require(bool(view.get("anchors")), "Explicit original birth spans required")
    for span in view["anchors"]:
        _span(span, text)
    return text


def _record(root, record):
    case = record.get("case")
    _require(isinstance(case, dict) and set(case) == _PUBLIC and public_case(case) == case
        and case["task"] == "hypothesis", "Exact seven-field H case required")
    _require(record.get("version") == "current-native-condition/1"
        and all(record.get(k) is False for k in ("keys_read", "grades_read", "old_native_resealed", "old_ranks_or_grades_reused")),
        "Only an unchanged current postrun record may acquire an origin display")
    _require(record.get("sha256") == digest({k:v for k,v in record.items() if k != "sha256"})
        and record.get("native_checksum") == digest(record["result"]), "Current record/result seal changed")
    plan, identity = record["plan"], record["identity"]
    _require(plan["query_sha256"] == digest(case["query"]) and plan["task"] == case["task"]
        and plan["arm"] == record["config"] and identity["case"] == case and identity["config"] == record["config"]
        and identity["plan_sha256"] == digest(plan) and identity["code_sha256"] == digest(record["code"]), "Current case/query/plan identity differs")
    _require(record["result"]["query_sha256"] == digest(case["query"])
        and record["result"]["provided_plan_sha256"] == digest(plan), "Native result belongs to another question/plan")
    _require(record["run_id"] == "current_" + digest(identity)[:24], "Current run identity changed")
    for name in ("registry_ref", "index_ref", "plan_release_ref", "source_binding_sha256"):
        _require(record[name] == identity[name], "Record and execution identity differ: " + name)
    # This is an exact record-derived completion path, never a latest/run search.
    prefix = "experiments/current_refresh/execution/runs/" + record["run_id"] + "/"
    completion_path = planning.bound(root, prefix + "completion.json.gz")
    completion = json.loads(gzip.decompress(completion_path.read_bytes()))
    _require(completion.get("version") == "current-execution-completion/1"
        and completion.get("sha256") == digest({k:v for k,v in completion.items() if k != "sha256"})
        and completion["identity"] == identity and completion["run_id"] == record["run_id"]
        and completion["native_checksum"] == record["native_checksum"]
        and completion["task_status"] == record["result"]["status"], "Exact completed postrun commitment differs")
    checkpoint = completion["checkpoint"]
    _require(checkpoint["path"] == prefix + case["case_id"] + "__" + record["config"] + ".json.gz", "Completion points outside the exact current condition")
    _path(root, checkpoint)
    encoded = (json.dumps(record, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    _require(hashlib.sha256(encoded).hexdigest() == checkpoint["decoded_sha256"], "Provided record is not the committed checkpoint")
    registry = _read(root, record["registry_ref"])
    binding = planning.validate_registry(registry, record["index_ref"], case)
    _require(record["resource_binding"] == binding and record["source_binding_sha256"] == digest(binding)
        and identity["registry_sha256"] == registry["sha256"], "Current native registry/resource differs")
    _path(root, record["index_ref"])
    release = _read(root, record["plan_release_ref"])
    _require(release.get("version") == "current-planning-release/1"
        and release.get("sha256") == digest({k:v for k,v in release.items() if k != "sha256"})
        and release["case"] == case and release["case_sha256"] == digest(case) and release["plan"] == plan
        and release["plan_sha256"] == digest(plan) and release["registry_sha256"] == registry["sha256"]
        and release["index_ref"] == record["index_ref"] and release["source_binding_sha256"] == digest(binding),
        "Current saved planning release differs")
    return case, binding, checkpoint


def _canonical_binding(root, record, resource, canonical_ref):
    native = record["index_ref"]["native_index_ref"]
    core = {k:canonical_ref[k] for k in ("path", "sha256")}
    if resource["status"] == "INCUMBENT_NOT_MIGRATED":
        files = resource["incumbent_binding"]["files"]
        _require(core == files["pages"] and native == resource["incumbent_index_ref"]
            and native["binding"] == resource["incumbent_binding"]
            and native["path"] == record["index_ref"]["path"] and native["sha256"] == record["index_ref"]["sha256"],
            "Canonical origin source is not the native incumbent prepared source")
        return "INCUMBENT_PREPARED_PAGES_PIN"
    _require(resource["status"] == "CURRENT_NATIVE_RESOURCE_EXPLICIT", "Unknown native origin resource status")
    registry = resource["native_registry"]
    _require(registry["registry_digest"] == digest({k:v for k,v in registry.items() if k != "registry_digest"})
        and resource["native_registry_digest"] == registry["registry_digest"]
        and native["registry_digest"] == registry["registry_digest"] and native["resource_id"] == resource["resource_id"]
        and native["path"] == root.name + "/" + record["index_ref"]["path"]
        and native["sha256"] == record["index_ref"]["sha256"], "Native resource/index lineage differs")
    inventory = {}
    for ref in registry["artifact_inventory"]:
        _require(ref["path"] not in inventory or inventory[ref["path"]] == ref["sha256"], "Conflicting native artifact pins")
        inventory[ref["path"]] = ref["sha256"]
    _require(core["path"] == registry["paths"]["prepared"] + "/canonical_pages.jsonl"
        and inventory.get(core["path"]) == core["sha256"], "Canonical origin differs from native prepared artifact inventory")
    for key in ("pages", "documents"):
        file_ref = resource["files"][key]
        _require(file_ref == registry["files"][key] and inventory.get(file_ref["path"]) == file_ref["sha256"], "Prepared source view pin differs")
        _path(root.parent, file_ref)
    manifest = _read(root.parent, native["manifest"])
    _require(manifest["registry_digest"] == registry["registry_digest"] and manifest["index_sha256"] == native["sha256"]
        and manifest["resource_id"] == resource["resource_id"] and manifest["index_id"] == native["index_id"], "Native source index manifest differs")
    return "CURRENT_PREPARED_CANONICAL_ARTIFACT_INVENTORY_PIN"


def _original(root, case, dto, proof, source_paths):
    audit = proof["source_origin_audit"]
    original = _view(dto["full_transcription"])
    projection = _view(dto)
    origin = proof["origin"]
    _require(projection == origin["text"] and origin["source_text_sha256"] == digest(projection)
        and origin["document_id"] == case["document_id"] and origin["date"] == case["date"]
        and origin["permitted"] is False and audit["whole_origin_document_excluded"], "Origin body/category differs")
    _require(dto["source_id"] == origin["source_id"] and dto["classification"] == origin["classification"]
        and all(dto[k] == case[k] for k in ("document_id","date","corpus","task")), "Displayed origin identity/date/classification differs")
    expected_anchors = [dict(start=a["start"], end=a["end"], text=a["text"], atom_id=a.get("atom_id"),
        source_id=a.get("source_id"), quote_sha256=digest(a["text"])) for a in proof["origin_anchors"]]
    _require(dto["anchors"] == expected_anchors, "Prepared origin highlights differ from source proof")
    if case["corpus"] != "cib":
        with source_paths["raw_csv_ref"].open(newline="") as stream:
            raw = [r for r in csv.DictReader(stream) if r["id"] == case["document_id"]]
        _require(len(raw) == 1 and raw[0] == audit["original_raw_documents"][case["document_id"]]
            and original == projection == raw[0]["body"], "Complete raw cable origin differs")
        checks = [c for c in audit["document_checks"] if c["document_id"] == case["document_id"]]
        _require(len(checks) == 1 and checks[0]["valid"] and checks[0]["classification"] == "SECRET"
            and checks[0]["whole_body_noforn"] is False and checks[0]["raw_body_sha256"] == digest(original), "Original SECRET body proof differs")
        rows = _rows(source_paths["canonical_ref"], "document_id", case["document_id"])
        _require(rows == audit["canonical_origin_rows"] and [r["segment_id"] for r in rows] == audit["excluded_canonical_source_ids"], "Canonical origin sibling exclusion differs")
        segments = dto["full_transcription"]["segments"]
        _require(len(segments) == len(rows) and dto["full_transcription"]["anchors"] == expected_anchors, "Complete original segments or highlights differ")
        for segment,row in zip(segments, rows):
            _require(segment["start"] == row["source_char_start"] and segment["end"] == row["source_char_end"]
                and segment["source_id"] == row["segment_id"] and original[segment["start"]:segment["end"]] == row["text"]
                and segment["physical_pdf_page"] is False, "Raw cable segment/page mapping differs")
        return
    canonical, = _rows(source_paths["canonical_ref"], "canonical_page_id", origin["source_id"])
    pair, = _rows(source_paths["paired_transcript_ref"], "canonical_page_id", origin["source_id"])
    raw, = _rows(source_paths["raw_document_ref"], "document_id", case["document_id"])
    _require(canonical == audit["canonical_row"] and pair == audit["paired_record"], "Pinned canonical/paired CIB row differs")
    earlier, later = raw["raw_ocr"]["redacted"], raw["raw_ocr"]["unredacted"]
    early_page, late_page = audit["earlier_physical_pdf_page"], audit["later_physical_pdf_page"]
    _require(type(early_page) is int and type(late_page) is int and 1 <= early_page <= len(earlier)
        and 1 <= late_page <= len(later) and pair["earlier_page"] == early_page and pair["later_page"] == late_page
        and pair["earlier_text"] == earlier[early_page-1] and pair["later_text"] == later[late_page-1], "Physical CIB page mapping differs")
    _require(original == "\n\n".join(later) and audit["whole_earlier_origin_text"] == "\n\n".join(earlier)
        and hashlib.sha256(audit["whole_earlier_origin_text"].encode()).hexdigest() == audit["whole_earlier_sha256"], "Complete paired original transcript differs")
    segments = dto["full_transcription"]["segments"]
    _require(len(segments) == len(later) and dto["pdf"] == dict(release="later", page=late_page), "Full CIB page count/locator differs")
    cursor = 0
    for number,(page,segment) in enumerate(zip(later,segments),1):
        _require(segment["start"] == cursor and segment["end"] == cursor+len(page) and segment["physical_pdf_page"] == number
            and segment["text_sha256"] == digest(page) and segment["text_utf8_sha256"] == hashlib.sha256(page.encode()).hexdigest(), "Original CIB page/hash differs")
        cursor += len(page)+2
    mappings, highlights = [], []
    for birth in proof["origin_anchors"]:
        unit = canonical["units"][birth["unit_index"]]
        text = birth["text"]
        _require(unit["unit_type"] == "redaction_zone" and unit["later_text"][birth["unit_local_start"]:birth["unit_local_end"]] == text
            and text not in audit["whole_earlier_origin_text"] and later[late_page-1].count(text) == 1, "CIB birth is not an exact revealed/earlier-absent claim")
        a = later[late_page-1].index(text); offset = segments[late_page-1]["start"]
        highlights.append(dict(start=offset+a,end=offset+a+len(text),text=text,atom_id=birth.get("atom_id"),
            source_id=origin["source_id"],quote_sha256=digest(text)))
        mappings.append(dict(atom_id=birth.get("atom_id"),canonical_page_id=origin["source_id"],
            canonical_projection_span=[birth["start"],birth["end"]],raw_later_physical_pdf_page=late_page,
            raw_later_page_span=[a,a+len(text)],original_document_span=[offset+a,offset+a+len(text)],text=text,
            mapping="EXACT_LITERAL_SUBSTRING_ON_PINNED_RAW_LATER_PAGE"))
    _require(dto["full_transcription"]["anchors"] == highlights and dto["exact_original_birth_mappings"] == mappings,
        "CIB original birth mappings differ")


def bind(root, record, source_index_ref):
    """Bind an explicit prepared origin index to one exact completed native H.

    source_index_ref is the origin-display JSON index {path, sha256}, NOT the
    native SQLite index. The native index is bound inside the completed record.
    No ambient report, registry, latest run, source rebuild or inference is used.
    """
    root = Path(root).resolve()
    case, resource, checkpoint = _record(root, record)
    index = _read(root, source_index_ref)
    _require(index.get("version") == "explicit-h5-origin-display-index/1"
        and index["case_count"] == len(index["cases"]) and len({r["case_id"] for r in index["cases"]}) == len(index["cases"]), "Typed explicit origin index required")
    entries = [r for r in index["cases"] if r["case_id"] == case["case_id"]]
    _require(len(entries) == 1, "Exact current case is absent from explicit origin index")
    entry = entries[0]; dto = _read(root, entry["dto_ref"])
    _require(dto.get("version") == "privileged-query-origin/6.3" and dto.get("preparation_version") == "explicit-h5-source-display/1"
        and dto["case"] == case and dto["query"] == case["query"] and dto["case_id"] == case["case_id"]
        and dto["case_sha256"] == entry["case_sha256"] == digest(case)
        and dto["query_sha256"] == entry["query_sha256"] == digest(case["query"]), "Origin DTO differs from exact public case/query")
    refs = dto["source_bindings"]
    _require(refs["source_catalog_ref"] == entry["source_catalog_ref"] == index["public_catalog_ref"]
        and refs["source_proof_ref"] == entry["source_proof_ref"] == index["source_proof_ref"]
        and refs["source_packet_ref"] == entry["origin_parent_ref"] == dto["origin_parent_ref"], "Origin parent reference chain differs")
    catalog = _read(root, refs["source_catalog_ref"])
    _require([c for c in catalog["cases"] if c["case_id"] == case["case_id"]] == [case], "Source catalog case differs")
    proofs = _read(root, refs["source_proof_ref"])
    packet = _read(root, refs["source_packet_ref"])
    proof = proofs["cases"][case["case_id"]]
    _require(packet["case"] == case and packet["proof"] == proof and dto["proof_sha256"] == refs["source_proof_ref"]["sha256"]
        and refs["source_origin_audit_sha256"] == digest(proof["source_origin_audit"]), "Pinned source proof/packet differs")
    planned = _read(root, refs["questiononly_planning_handoff_ref"])
    rows = [r for r in planned["cases"] if r["case_id"] == case["case_id"]]
    _require(len(rows) == 1 and rows[0]["status"] == "READY" and rows[0]["case_sha256"] == digest(case), "Original question-only planning parent differs")
    source_plan = record["plan"]
    if source_plan.get("version") == "current-local-query-plan/2":
        source_plan = source_plan["local_planning"]["source_plan"]
    _require(_read(root, rows[0]["plan_refs"][record["config"]]) == source_plan, "Current plan is not the pinned public planning parent")
    bundle = _read(root, rows[0]["bundle_ref"])
    _require(bundle["case"] == case and bundle["plans"][record["config"]] == source_plan, "Question-only planning bundle differs")
    audit = proof["source_origin_audit"]
    expected = {k:audit[k] for k in ("raw_csv_ref","canonical_ref","paired_transcript_ref","raw_document_ref") if k in audit}
    pins = refs["original_source_pins"]
    _require(len(pins) == len(expected) and {p["role"] for p in pins} == set(expected), "Original source pin roles differ")
    paths = {}
    for pin in pins:
        role = pin["role"]
        _require(pin["root"] == "IARPA_WORKSPACE" and {k:pin[k] for k in ("path","sha256")} == expected[role], "Original source file pin differs")
        paths[role] = _path(root.parent, pin)
    policy = _canonical_binding(root, record, resource, audit["canonical_ref"])
    _original(root, case, dto, proof, paths)
    _require(entry["original_text_sha256"] == dto["full_transcription"]["text_sha256"]
        and entry["exact_birth_spans_in_display"] == dto["anchors"]
        and entry["exact_birth_spans_in_complete_original"] == dto["full_transcription"]["anchors"]
        and refs["origin_text_sha256"] == proof["origin"]["source_text_sha256"], "Origin index full body/birth/source hash differs")
    for pin in pins:
        _path(root.parent, pin)
    _require(dto["eligible_evidence"] is False and dto["not_an_inference_input"] is True
        and dto["source_display_only"] is True and dto["execution_binding"] is None
        and entry["execution_bound"] is False and dto["no_legacy_report_fallback"] is True, "Prepared origin privilege/display contract differs")
    result = deepcopy(dto)
    result.update(binding_version=VERSION,binding_status="EXPLICIT_COMPLETED_CURRENT_NATIVE_POSTRUN_BOUND",
        preparation_metadata_gaps=deepcopy(dto.get("metadata_gaps",[])),
        metadata_gaps=[g for g in dto.get("metadata_gaps",[]) if g != _PENDING],
        execution_binding=dict(version=VERSION,native_checksum=record["native_checksum"],record_sha256=record["sha256"],
            plan_sha256=digest(record["plan"]),registry_ref=deepcopy(record["registry_ref"]),index_ref=deepcopy(record["index_ref"]),
            plan_release_ref=deepcopy(record["plan_release_ref"]),native_checkpoint_ref=deepcopy(checkpoint),
            run_id=record["run_id"],config=record["config"],case_sha256=digest(case),query_sha256=digest(case["query"]),
            origin_index_ref=deepcopy(source_index_ref),prepared_origin_ref=deepcopy(entry["dto_ref"]),
            canonical_source_binding_policy=policy,postrun_only=True,used_for_inference=False),
        postrun_only=True,detached=True,inference_outputs_modified=False)
    return result
