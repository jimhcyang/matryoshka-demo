"""Current-resource execution with explicit registry/index/plan/run lineage."""
from contextlib import contextmanager, nullcontext
from copy import deepcopy
import gzip
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest,offline
from . import planning

VERSION='current-resource-execution/1'
RUN_PREFIX='experiments/current_refresh/execution/runs/'
ENVIRONMENT=dict(PYTHONHASHSEED='0',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',
    MKL_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
NATIVE83_SHA256='b470bf1b7917d02727bef7b94e373a9f3a9f978bd9aaf78a6186fee3d5fcff39'
INFERENCE_MODULES=('execution','planning','resources','index','decisions','reconstruction',
    'arm_controls','local_readings','proposition_matching','construction','degree_checks','source_context','hypothesis_claims')
TASK_ONLY_MODULES={'redaction':{'construction','degree_checks'},
    'hypothesis':{'proposition_matching','hypothesis_claims','reconstruction','source_context'},
    'reconstruction':{'reconstruction','proposition_matching','source_context'}}
TASK_SPECIFIC=frozenset().union(*TASK_ONLY_MODULES.values())


def _modules(task):
    if task is None:return set(INFERENCE_MODULES)
    if task not in TASK_ONLY_MODULES:raise ValueError('Unknown execution task dependency scope')
    return (set(INFERENCE_MODULES)-TASK_SPECIFIC)|TASK_ONLY_MODULES[task]


def _dependency_files(root,task=None):
    root=Path(root).resolve();paths=set()
    for name in _modules(task):
        path=root/'matryoshka_current'/(name+'.py')
        if path.is_file():paths.add(path)
    for package in ('matryoshka_demo','matryoshka_demo_v6','matryoshka_demo_v61'):
        paths.update((root/package).rglob('*.py'))
    for folder in ('src/scripts/common','src/scripts/matryoshka_workbench/release_v0421/matryoshka_v0420'):
        paths.update((root.parent/folder).rglob('*.py'))
    resource=root.parent/'src/scripts/matryoshka_workbench/release_v0421/semantic_resources/core_semantic_resources_v2.json'
    if resource.is_file():paths.add(resource)
    return {str(path.relative_to(root.parent)):planning.byte_sha(path) for path in sorted(paths) if path.is_file()}


def _pinned_dependencies(task=None):
    prefix=str(_CODE_ROOT.relative_to(_CODE_ROOT.parent))+'/matryoshka_current/'
    return {name:sha for name,sha in _IMPORTED_DEPENDENCIES.items()
        if not name.startswith(prefix) or Path(name).stem in _modules(task)}


def _check_imports(task=None):
    if _dependency_files(_CODE_ROOT,task)!=_pinned_dependencies(task):
        raise RuntimeError('Execution dependency bytes/file set changed after import; restart a fresh worker')


def pinned_environment():
    if sys.flags.ignore_environment or any(os.environ.get(k)!=v for k,v in ENVIRONMENT.items()):
        raise RuntimeError('Run current execution in a fresh seed-zero, one-thread process')
    probe='matryoshka-current/execution-hash-probe/1'
    result=subprocess.run([sys.executable,'-S','-B','-c','print(hash('+repr(probe)+'))'],
        env=dict(os.environ,**ENVIRONMENT),capture_output=True,text=True,check=True,timeout=15)
    if int(result.stdout.strip())!=hash(probe):
        raise RuntimeError('Current process hash seed differs from declared seed zero')
    return dict(variables=deepcopy(ENVIRONMENT),hash_probe_verified=True)


def _code(workspace,task=None):
    _check_imports(task)
    if Path(workspace).resolve()!=_CODE_ROOT:
        raise ValueError('Execution code must belong to its explicit demo root')
    from matryoshka_demo_v61.study import binding
    code=binding(workspace)
    if len(code)!=83 or digest(code)!=NATIVE83_SHA256:raise ValueError('Frozen shared native83 changed')
    return dict(dependency_sources=deepcopy(_pinned_dependencies(task)),task_dependency_scope=task,
        reused_native83=code,native83_sha256=digest(code),
        closure_policy='EXPLICIT_CURRENT_INFERENCE_PLUS_ALL_SHARED_PYTHON_MATCHED_ORIGINAL_AND_SEMANTIC_RESOURCE')


def _source_bytes(root,binding):
    if binding.get('status')=='CURRENT_NATIVE_RESOURCE_EXPLICIT':
        from .resources import verify_files
        verify_files(root.parent,binding['native_registry'])
    elif binding.get('status')=='INCUMBENT_NOT_MIGRATED':
        for ref in binding['incumbent_binding']['files'].values():
            if planning.byte_sha(planning.bound(root.parent,ref['path']))!=ref['sha256']:
                raise ValueError('Explicit incumbent source bytes changed')
    else:raise ValueError('Unsupported current/incumbent resource status')


def _index_bytes(workspace,index_ref):
    if planning.byte_sha(planning.bound(workspace,index_ref['path']))!=index_ref['sha256']:
        raise ValueError('Current source index bytes changed')
    if 'manifest' in index_ref:planning.read_ref(workspace,index_ref['manifest'])


def _context(workspace,registry_ref,index_ref,corpus_id,loader):
    if loader is None:
        resources=importlib.import_module('matryoshka_current.resources')
        loader=getattr(resources,'open_context',None)
        if loader is None:
            raise RuntimeError('Explicit execution resource adapter is not ready; no fixed-registry fallback')
    value=loader(workspace,registry_ref,index_ref,corpus_id)
    return value if hasattr(value,'__enter__') else nullcontext(value)


def _get(context,name):
    value=context.get(name) if isinstance(context,dict) else getattr(context,name,None)
    if value is None:raise ValueError('Verified current context lacks '+name)
    return value


def retrieve(corpus,case,plan,*,document_budget=100,passage_budget=100):
    """The existing shared kernel receives only the explicit verified Corpus."""
    planning.validate_plan(plan,case)
    from matryoshka_demo.retrieval_v5 import retrieve as shared_retrieve
    value=shared_retrieve(corpus,case,plan,document_budget=document_budget,
        passage_budget=passage_budget,hierarchy=True,graph=True)
    if value['eligible'].case!=public_case(case):
        raise ValueError('Retrieval eligibility belongs to another exact case')
    value['receipt'].update(current_execution=VERSION,ambient_registry_used=False,
        shared_hierarchy_kernel=True,navigation_is_factual_support=False)
    return value


def flow_projection(retrieval,result,case,*,state_budget=2048):
    """A fresh numerical replay, never a larger label on an old saved view."""
    if type(state_budget) is not int or not 32<=state_budget<=2048:
        raise ValueError('Current flow drawing budget must be between 32 and 2048')
    from matryoshka_demo_v6.flow import replay
    value=replay(retrieval,result,case=case,compact_budget=48,expanded_budget=state_budget)
    bundle=retrieval.get('hierarchy_bundle')
    if bundle is None:raise ValueError('Current flow requires the actual shared hierarchy kernel')
    known=set(bundle.state_ids)
    actual=value.get('expanded',{}).get('nodes',[])
    if len(actual)>state_budget or any(n['id'] not in known for n in actual):
        raise ValueError('Flow projection contains a fabricated/padded kernel state')
    if len({n['id'] for n in actual})!=len(actual):
        raise ValueError('Duplicate current-flow state')
    eligible=retrieval['eligible'];corpus=eligible.corpus
    for view in (value,value['expanded']):
        for node in view['nodes']:
            source=corpus.nodes.get(node['id'])
            node['native_reference_authority']=deepcopy(source.get('native_reference_authority',
                dict(route_class='LEGACY_OR_UNKNOWN_WITHHELD',global_identity_authorized=False))) if source else None
            node['identity_or_task_support_certified']=False
        by_pair={}
        for row in corpus.edge_rows:
            if not eligible.unit_mask[row['ui']]:continue
            a,b=corpus.node_ids[row['a']],corpus.node_ids[row['b']]
            by_pair.setdefault(frozenset((a,b)),[]).append(dict(
                native_source=a,native_target=b,relation=row['relation'],source_row_id=row['source_row_id'],
                route_class=row.get('route_class','LEGACY_SOURCE_ASSERTION_NO_IDENTITY_AUTHORITY'),
                native_assertion_mode=row.get('native_assertion_mode'),
                source_observation_id=row.get('source_observation_id'),target_observation_id=row.get('target_observation_id'),
                citation=eligible.citation(row['ui']),actor_identity_or_task_support_certified=False))
        for edge in view['edges']:
            edge['factual_relation_certified']=False
            if edge['kind']=='SOURCE':
                edge['native_source_assertions']=deepcopy(by_pair.get(frozenset((edge['source'],edge['target'])),[]))
                if edge['source']!=edge['target'] and not edge['native_source_assertions']:
                    raise ValueError('Displayed source transition lacks eligible native assertion proof')
                edge['numerical_reverse_is_new_historical_edge']=False
    value.update(version='current-kernel-flow/1',requested_states=state_budget,drawn_states=len(actual),
        real_kernel_states=len(bundle.state_ids),padded_states=0,
        reused_old_saved_projection=False,authority_from_labels=False)
    return value


def _decision_flow(result):
    # New decision labels are not inherited native status labels. The flow
    # adapter receives only signed, inspected source citations from this run.
    proxy=deepcopy(result)
    for atom in proxy.get('atoms',[]):
        # R's signed arrays can also have an `evidence` alias. Never count
        # that alias twice or turn context/conflict diagnostics into support.
        rows=atom.get('evidence',[])
        if 'positive_evidence' in atom or 'counterevidence' in atom:
            rows=atom.get('positive_evidence',[])+atom.get('counterevidence',[])
        evidence={}
        for row in rows:
            if row.get('direction') not in {'SUPPORT','COUNTER','PARTIAL'}:continue
            citations=row.get('citations',[row['citation']] if 'citation' in row else [])
            if not citations:raise ValueError('Signed flow evidence lacks its inspected source citation')
            for citation in citations:
                item=dict(direction=row['direction'],citation=deepcopy(citation))
                if 'node_id' in row:item['node_id']=row['node_id']
                evidence[digest(item)]=item
        atom['evidence']=list(evidence.values())
    return proxy


def _save(workspace,relative,value):
    if not relative.startswith(RUN_PREFIX):raise ValueError('Current output is outside its new run namespace')
    if shutil.disk_usage(workspace).free<8*1024**3:raise OSError('8 GiB free-disk guard required')
    path=planning.bound(workspace,relative);path.parent.mkdir(parents=True,exist_ok=True)
    raw=(json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False)+'\n').encode()
    wire=gzip.compress(raw,compresslevel=1,mtime=0)
    if path.exists():
        if path.read_bytes()!=wire:raise ValueError('Refusing to reseal an existing current checkpoint')
    else:
        # The public name never refers to an incomplete stream. Hard-link
        # publication is exclusive even if another writer wins this race.
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='wb',dir=path.parent,prefix='.current-checkpoint-',delete=False) as stream:
                temporary=Path(stream.name)
                stream.write(wire);stream.flush();os.fsync(stream.fileno())
            try:
                os.link(temporary,path)
            except FileExistsError:
                if path.read_bytes()!=wire:raise ValueError('Refusing to reseal an existing current checkpoint') from None
            directory=os.open(path.parent,os.O_RDONLY)
            try:os.fsync(directory)
            finally:os.close(directory)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)
    return dict(path=relative,sha256=hashlib.sha256(wire).hexdigest(),decoded_sha256=hashlib.sha256(raw).hexdigest())


def load_checkpoint(root,reference):
    """Read a sealed current record, without invoking inference or old reports."""
    if not reference['path'].startswith(RUN_PREFIX):raise ValueError('Not a current checkpoint namespace')
    raw=planning.bound(root,reference['path']).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=reference['sha256']:
        raise ValueError('Current checkpoint wire bytes changed')
    decoded=gzip.decompress(raw)
    if hashlib.sha256(decoded).hexdigest()!=reference['decoded_sha256']:
        raise ValueError('Current checkpoint decoded bytes changed')
    record=json.loads(decoded)
    if (record.get('version')!='current-native-condition/1'
            or record.get('sha256')!=digest({k:v for k,v in record.items() if k!='sha256'})
            or record.get('native_checksum')!=digest(record['result'])):
        raise ValueError('Current checkpoint record/result seal changed')
    return record


def _paths(identity):
    run_id='current_'+digest(identity)[:24]
    folder=RUN_PREFIX+run_id+'/'
    return run_id,folder+identity['case']['case_id']+'__'+identity['config']+'.json.gz',folder+'completion.json.gz'


def _completed(workspace,identity):
    run_id,checkpoint,completion=_paths(identity)
    path=planning.bound(workspace,completion)
    if not path.exists():
        if planning.bound(workspace,checkpoint).exists():
            raise ValueError('Uncommitted current checkpoint: explicit recovery review required')
        return None
    value=json.loads(gzip.decompress(path.read_bytes()))
    if (value.get('version')!='current-execution-completion/1' or value.get('identity')!=identity
            or value.get('sha256')!=digest({k:v for k,v in value.items() if k!='sha256'})
            or value['checkpoint']['path']!=checkpoint):
        raise ValueError('Current completion identity/seal changed')
    record=load_checkpoint(workspace,value['checkpoint'])
    if (record['identity']!=identity or record['run_id']!=run_id
            or record['case']!=identity['case'] or record['config']!=identity['config']
            or record['native_checksum']!=value['native_checksum']
            or digest(record['code'])!=identity['code_sha256']):
        raise ValueError('Current completion differs from its checkpoint')
    return value


@contextmanager
def _lock(workspace,identity):
    run_id,_,_=_paths(identity)
    path=planning.bound(workspace,RUN_PREFIX+run_id+'/execution.lock')
    path.parent.mkdir(parents=True,exist_ok=True)
    try:
        stream=path.open('x')
    except FileExistsError:
        raise ValueError('Current execution lock exists; explicit owner/recovery review required') from None
    try:
        with stream:
            stream.write(json.dumps(dict(pid=os.getpid(),identity_sha256=digest(identity))))
            stream.flush();os.fsync(stream.fileno())
        yield
    finally:
        path.unlink()


def _response(value,*,resumed):
    return dict(version=VERSION,status='COMPLETE',run_id=value['run_id'],checkpoint=value['checkpoint'],
        task_status=value['task_status'],drawn_flow_states=value['drawn_flow_states'],
        registry_sha256=value['identity']['registry_sha256'],index_ref=value['identity']['index_ref'],
        resumed=resumed,inference_performed=not resumed,api_calls=0)


def run(root,registry_ref,case,plan_release_ref,index_ref,*,document_budget=100,
        passage_budget=100,flow_states=2048,execute=False,resource_loader=None):
    """Root is explicit src-demo-day; no ambient bindings/report/index lookup."""
    workspace=Path(root).resolve();case=public_case(case)
    registry=planning.read_ref(workspace,registry_ref)
    binding=planning.validate_registry(registry,index_ref,case)
    release=planning.read_ref(workspace,plan_release_ref)
    plan=planning.validate_release(release,case,registry,index_ref)
    identity=dict(version=VERSION,case=case,config=plan['arm'],registry_ref=deepcopy(registry_ref),
        registry_sha256=registry['sha256'],index_ref=deepcopy(index_ref),
        source_binding_sha256=digest(binding),plan_release_ref=deepcopy(plan_release_ref),
        plan_sha256=digest(plan),document_budget=document_budget,passage_budget=passage_budget,
        flow_states=flow_states)
    if not execute:
        return dict(version=VERSION,status='PREVIEW_NO_RETRIEVAL_OR_WRITES',identity=identity,api_calls=0)
    environment=pinned_environment()
    if shutil.disk_usage(workspace).free<8*1024**3:raise OSError('8 GiB free-disk guard required')
    code=_code(workspace,task=case['task']);identity['code_sha256']=digest(code)
    _index_bytes(workspace,index_ref);_source_bytes(workspace,binding)
    with _lock(workspace,identity):
        completed=_completed(workspace,identity)
        if completed is not None:return _response(completed,resumed=True)
        return _execute(workspace,registry_ref,registry,binding,case,plan_release_ref,release,plan,index_ref,
            identity,code,environment,resource_loader)


def _execute(workspace,registry_ref,registry,binding,case,plan_release_ref,release,plan,index_ref,
        identity,code,environment,resource_loader):
    document_budget=identity['document_budget'];passage_budget=identity['passage_budget'];flow_states=identity['flow_states']
    source_context=None
    with _context(workspace,registry_ref,index_ref,case['corpus'],resource_loader) as context:
        if (_get(context,'registry')!=registry or _get(context,'index_ref')!=index_ref
                or _get(context,'registry_ref')!=registry_ref):
            raise ValueError('Opened execution context belongs to a different registry/index')
        corpus=_get(context,'corpus');source_index=_get(context,'source_index')
        corpus_binding=binding.get('incumbent_binding',binding)
        if corpus.corpus!=case['corpus'] or corpus.binding!=corpus_binding:
            raise ValueError('Explicit current Corpus differs from selected binding')
        with offline():
            found=retrieve(corpus,case,plan,document_budget=document_budget,passage_budget=passage_budget)
            found['passage_budget']=passage_budget
            if case['task']=='redaction':
                from .construction import construct_redaction
                result=construct_redaction(case,plan,found,passage_budget=passage_budget,top_k=5)
            else:
                from . import decisions
                arguments=dict(source_index=source_index,passage_budget=passage_budget)
                need_groups=case['task']=='reconstruction'
                if case['task']=='hypothesis':
                    from .hypothesis_claims import needs_source_groups
                    need_groups=needs_source_groups(case,plan)
                if need_groups:
                    from .source_context import groups_for_inspected
                    groups=groups_for_inspected(context,case,found)
                    source_context=dict(groups=deepcopy(dict(groups)),receipt=deepcopy(groups.receipt))
                    arguments['source_groups']=groups
                result=decisions.execute(case,plan,found,**arguments)
                if source_context is not None:result['source_context_sha256']=digest(source_context)
                from .arm_controls import controls_for
                result['arm_controls']=controls_for(case,plan)
            result['retrieval']=deepcopy(found['receipt'])
            result['flow']=flow_projection(found,_decision_flow(result),case,state_budget=flow_states)
            result['flow']['binding']=dict(registry_ref=deepcopy(registry_ref),index_ref=deepcopy(index_ref),
                registry_sha256=registry['sha256'],source_binding_sha256=digest(binding))
    if (planning.read_ref(workspace,registry_ref)!=registry or planning.read_ref(workspace,plan_release_ref)!=release
            or _code(workspace,task=case['task'])!=code):
        raise ValueError('Current run code/registry/planning bytes changed during execution')
    _index_bytes(workspace,index_ref);_source_bytes(workspace,binding)
    from threadpoolctl import threadpool_info
    pools=[{k:row.get(k) for k in ('user_api','internal_api','num_threads','version')} for row in threadpool_info()]
    if any(row['num_threads']!=1 for row in pools):raise RuntimeError('Detected numerical pool is not one-thread')
    environment['numerical_pools']=pools
    run_id,checkpoint_path,completion_path=_paths(identity)
    record=dict(version='current-native-condition/1',run_id=run_id,case=case,config=plan['arm'],
        identity=identity,registry_ref=registry_ref,index_ref=index_ref,resource_binding=deepcopy(binding),
        plan=plan,plan_release_ref=plan_release_ref,source_binding_sha256=digest(binding),
        inspected_page_ids=result.get('inspected_page_ids',[corpus.pages[pi]['id'] for pi in found['pages'][:passage_budget]]),
        result=result,native_checksum=digest(result),code=code,execution_environment=environment,
        keys_read=False,grades_read=False,inference_network_access=False,api_calls=0,
        old_native_resealed=False,old_ranks_or_grades_reused=False,
        current_resource_acceptance='NEW_EXECUTION_NOT_A_BENCHMARK_OR_PUBLICATION_APPROVAL')
    if source_context is not None:record['source_context']=source_context
    record['sha256']=digest(record)
    checkpoint=_save(workspace,checkpoint_path,record)
    completion=dict(version='current-execution-completion/1',run_id=run_id,checkpoint=checkpoint,identity=identity,
        native_checksum=record['native_checksum'],
        task_status=result.get('status'),drawn_flow_states=result['flow']['drawn_states'],
        api_calls=0)
    completion['sha256']=digest(completion)
    _save(workspace,completion_path,completion)
    return _response(completion,resumed=False)


_CODE_ROOT=Path(__file__).resolve().parents[1]
_IMPORTED_DEPENDENCIES=_dependency_files(_CODE_ROOT)
