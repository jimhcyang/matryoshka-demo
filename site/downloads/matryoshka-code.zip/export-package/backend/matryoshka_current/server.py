"""Loopback, read-only viewer for an explicit current-resource publication."""
import argparse
from collections import OrderedDict
from copy import deepcopy
from functools import partial
import gzip
from http.server import HTTPServer, SimpleHTTPRequestHandler
import json
import mimetypes
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlencode, urlsplit

from matryoshka_demo.io import digest
from . import planning, publication, reporting


ARMS = {"A": "llm_readings", "B": "llm_atoms", "C": "llm_local"}
ASSETS = {"corpus-home.html", "corpus-home.css", "corpus-home.js", "workbench-v6.html", "workbench-v6.js", "workbench-v6.css", "app-theme-v6.css",
    "app-navigation.js", "app-navigation.css",
    "local-decisions-v65.js", "verdict-v64.js", "postrun-review-v74.js", "viewport-anchor-v64.js", "flow-view-v6.js", "flow-view-v6.css",
    "flow-layout-v4.js", "graph-full-v6.html", "graph-full-v6.js", "graph-full-v6.css", "workbench-visuals.js"}


def one(params, key, default=None):
    values = params.get(key, [default])
    if len(values) != 1:
        raise ValueError("Duplicate API parameter")
    return values[0]


def asset_name(path, params):
    if path in {"/", "/index.html"}:
        legacy_case = "case" in params and one(params, "view") != "home"
        return "workbench-v6.html" if legacy_case else "corpus-home.html"
    return path.lstrip("/")


def origin_matches(value, case):
    return (value.get("eligible_evidence") is False and value.get("query_sha256") == digest(case["query"])
        and all(value.get(key) == case[key] for key in ("case_id", "document_id", "corpus", "task", "date")))


class Viewer:
    def __init__(self, root, report_ref, *, maps=None, digest_ref=None, ui_root=None, casebook_ref=None):
        self.root = Path(root).resolve()
        self.report_ref = deepcopy(report_ref)
        report = publication.read(self.root, report_ref)
        if (report.get("version") != publication.VERSION
                or report.get("sha256") != digest({k:v for k,v in report.items() if k != "sha256"})):
            raise ValueError("Current publication contract/hash changed")
        self.report = report
        self.cases = {r["case"]["case_id"]:r for r in report["cases"]}
        if len(self.cases) != len(report["cases"]):
            raise ValueError("Repeated public question")
        self.maps = maps
        self.digest_ref = deepcopy(digest_ref)
        self.casebook_ref = deepcopy(casebook_ref)
        self.ui_root = Path(ui_root).resolve() if ui_root else None
        self.context = None
        self.loaded = OrderedDict()
        self.flow_cache = OrderedDict()
        self.slots = None

    def close(self):
        if self.context is not None:
            self.context.close()
            self.context = None

    def casebook(self):
        if publication.read(self.root,self.report_ref)!=self.report or self.casebook_ref is None:
            raise ValueError("No exact casebook selected")
        value=publication.read(self.root,self.casebook_ref)
        if (value.get("version")!="workbench-casebook/1"
                or value.get("source_report_sha256")!=self.report_ref["sha256"]
                or value.get("source_report_run")!=self.report["run_id"]):
            raise ValueError("Casebook belongs to another publication")
        for group in ("primary","special_redactions"):
            entries=value.get(group)
            if not isinstance(entries,list):
                raise ValueError("Explicit casebook collections are required")
            seen=set()
            for entry in entries:
                row=self.cases[entry["case_id"]]
                case=row["case"]
                if (case["case_id"] in seen or entry.get("corpus")!=case["corpus"]
                        or entry.get("task")!=case["task"]
                        or entry.get("case",case)!=case
                        or entry.get("resource_binding",row["resource_binding"])!=row["resource_binding"]
                        or group=="special_redactions" and (case["corpus"],case["task"])!=("cib","redaction")):
                    raise ValueError("Casebook changes or repeats a saved question/resource")
                seen.add(case["case_id"])
        return value

    def select(self, params):
        # The report pin is checked even after a warm browser/cache load.
        if publication.read(self.root, self.report_ref) != self.report:
            raise ValueError("Active explicitly selected report changed")
        row = self.cases[one(params, "case_id", "")]
        binding = row["resource_binding"]
        for key in ("resource_id", "registry_sha256", "index_sha256"):
            if one(params, key) != binding[key]:
                raise ValueError("Missing or mixed current source resource pin")
        arm = one(params, "config", "llm_readings")
        arm = ARMS.get(arm, arm)
        if arm not in ARMS.values():
            raise ValueError("Unknown active comparison arm")
        item = row["configurations"][arm]
        stamps = []
        for ref in (item["condition_ref"], item["native_checkpoint"]):
            stat = planning.bound(self.root, ref["path"]).stat()
            stamps.append((ref["path"], ref["sha256"], stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns, stat.st_ino))
        key = tuple(stamps)
        cached = self.loaded.get(key)
        if cached is not None:
            self.check_condition(row, arm, item, cached[0], cached[1])
            self.loaded.move_to_end(key)
            return row, arm, item, cached[0], cached[1]
        condition = publication.read(self.root, item["condition_ref"])
        if condition["case"] != row["case"] or condition["resource_binding"] != binding:
            raise ValueError("Saved condition belongs to another question/resource")
        native = reporting.checkpoint(self.root, item["native_checkpoint"])
        self.check_condition(row, arm, item, condition, native)
        descriptor = {k:deepcopy(native[k]) for k in ("case", "config", "run_id", "registry_ref", "index_ref", "resource_binding", "sha256", "native_checksum")}
        self.loaded[key] = condition, descriptor
        while len(self.loaded) > 3:
            self.loaded.popitem(last=False)
        return row, arm, item, condition, descriptor

    def check_condition(self, row, arm, item, condition, native):
        saved = condition["configurations"][arm]
        if (native["case"] != row["case"] or native["config"] != arm or item["config"] != arm
                or saved["native_checkpoint"] != item["native_checkpoint"]
                or native["native_checksum"] != saved["native_checksum"]):
            raise ValueError("Condition and current native question/arm/output differ")
        registry = planning.read_ref(self.root, native["registry_ref"])
        if reporting.resource_binding(native, registry) != row["resource_binding"]:
            raise ValueError("Condition and derived native source resource differ")

    def source_context(self, native):
        identity = native["registry_ref"], native["index_ref"]
        if self.context is None or (self.context.registry_ref, self.context.index_ref) != identity:
            self.close()
            from .resources import open_context
            self.context = open_context(self.root, native["registry_ref"], native["index_ref"], native["case"]["corpus"])
        return self.context

    def published_flow(self, reference):
        path=planning.bound(self.root,reference["path"])
        stat=path.stat()
        key=(reference["path"],reference["sha256"],stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns,stat.st_ino)
        if key not in self.flow_cache:
            self.flow_cache[key]=publication.read(self.root,reference)
        self.flow_cache.move_to_end(key)
        while len(self.flow_cache)>3:
            self.flow_cache.popitem(last=False)
        return self.flow_cache[key]

    def pdf(self, params):
        allowed = {"case_id", "config", "resource_id", "registry_sha256", "index_sha256", "doc_id", "release"}
        if set(params)-allowed or any(len(values) != 1 for values in params.values()):
            raise ValueError("Unknown or repeated current PDF selector")
        row, arm, item, _, native = self.select(params)
        case = row["case"]
        document, release = one(params, "doc_id"), one(params, "release")
        if case["corpus"] != "cib" or release not in {"earlier", "later"} or self.maps is None:
            raise ValueError("No bound CIB PDF export for this request")
        if document == case["document_id"]:
            reference = publication.origins_for(row.get("origin_refs", {}), arm).get("masked")
            if not reference:
                raise ValueError("Original PDF requires independently verified source provenance")
            original = publication.read(self.root, reference)
            if not origin_matches(original, case) or not publication.origin_binding_matches(original, native, arm, item["native_checkpoint"]):
                raise ValueError("Original PDF belongs to another query-origin proof")
        else:
            if release != "earlier":
                raise ValueError("A later non-origin PDF is not an eligible evidence readout")
            context = self.source_context(native)
            eligible = context.corpus.eligible(case)
            if not any(p["document_id"] == document and eligible.page_mask[i]
                    for i,p in enumerate(context.corpus.pages)):
                raise ValueError("PDF document has no eligible page in this exact source view")
        query = urlencode(sorted(dict(doc_id=document, release=release).items()))
        raw, mime = self.maps.packet("/api/cib-pdf?" + query)
        if not mime.startswith("application/pdf") or not raw.startswith(b"%PDF-"):
            raise ValueError("Saved PDF export returned a different content contract")
        return raw, mime

    def api(self, path, params):
        common = {"case_id", "config", "resource_id", "registry_sha256", "index_sha256"}
        selectors = {
            "condition-v6": set(), "native-v6": set(), "origin-v63": {"reveal_focal"},
            "postrun-review": {"reveal"}, "analyst-digest": set(),
            "source-v6": {"source_id"}, "node-v6": {"node_id"}, "flow-v6": {"reading", "limit"},
            "guide-v6": {"reading", "candidate_id", "route_index"},
            "guide-overlay-v63": {"reading", "candidate_id", "route_index"},
            "guide-overlay-v64": {"reading", "candidate_id", "route_index"},
            "guide-view-v6": {"reading", "candidate_id", "route_index", "phase", "source_id", "node_id", "hop_index", "limit", "offset", "page_size"}}
        if path not in selectors or set(params)-common-selectors[path]:
            raise ValueError("Unsupported current API selector")
        if path == "analyst-digest" and not common.issubset(params):
            raise ValueError("Analyst digest requires an explicit question, arm and resource binding")
        for key in params:
            one(params, key)
        row, arm, item, condition, native = self.select(params)
        binding = row["resource_binding"]
        if path == "condition-v6":
            return condition
        if path == "native-v6":
            return dict(native=reporting.checkpoint(self.root, item["native_checkpoint"]), resource_binding=binding)
        if path == "analyst-digest":
            from .analyst_digest import read_for_case
            return read_for_case(self.root,self.digest_ref,self.report_ref,row["case"],arm,item,native,binding)
        if path == "postrun-review":
            reveal = one(params, "reveal", "0")
            if reveal not in {"0", "1"}:
                raise ValueError("Explicit post-run reveal selector required")
            reference = item.get("postrun_review_ref")
            saved = condition["configurations"][arm]
            if reference != saved.get("postrun_review_ref"):
                raise ValueError("Independent review attachment differs from its saved view")
            if reference is None:
                return dict(available=False, answer_aware=True, used_for_inference=False,
                    resource_binding=binding)
            from .postrun_review import read_for_native
            record = reporting.checkpoint(self.root, item["native_checkpoint"])
            value = read_for_native(self.root, reference, record, reveal=reveal == "1")
            return dict(value, resource_binding=binding)
        if path == "origin-v63":
            key = "revealed" if one(params, "reveal_focal", "0") == "1" else "masked"
            refs = publication.origins_for(row.get("origin_refs", {}), arm)
            if key not in refs:
                raise ValueError("No independently source-verified original is published for this case")
            value = publication.read(self.root, refs[key])
            if (not origin_matches(value, row["case"])
                    or not publication.origin_binding_matches(value, native, arm, item["native_checkpoint"])):
                raise ValueError("Original-source packet belongs to another question")
            return dict(value, resource_binding=binding)
        if path in {"flow-v6", "guide-v6", "guide-overlay-v64", "guide-overlay-v63", "guide-view-v6"}:
            reading = one(params, "reading", "")
            if not reading and reading not in item["flow_refs"]:
                reading = next(iter(item["flow_refs"]))
            reference = item["flow_refs"][reading]
            limit = int(one(params, "limit", "1024")) if path == "flow-v6" else 2048
            if not 32 <= limit <= 2048:
                raise ValueError("Invalid inspection bound")
            if path == "flow-v6" and limit <= 1024 and item.get("compact_flow_refs", {}).get(reading):
                reference = item["compact_flow_refs"][reading]
            flow = self.published_flow(reference)
            if flow["resource_binding"] != binding or flow["source_case_sha256"] != native["sha256"]:
                raise ValueError("Current flow belongs to another native/source pair")
            if path == "flow-v6":
                return flow
            from .visualization import guide
            packet = guide(flow, one(params, "candidate_id", ""), int(one(params, "route_index", "0")))
            if path == "guide-v6":
                return packet
            from . import inspection
            context = self.source_context(native)
            value = inspection.guide_view(context, row["case"], packet, params) if path == "guide-view-v6" else inspection.guide_overlay(context, row["case"], packet)
            return dict(value, resource_binding=binding)
        from . import inspection
        context = self.source_context(native)
        if path == "source-v6":
            value = inspection.source(context, row["case"], one(params, "source_id", ""))
        elif path == "node-v6":
            value = inspection.node(context, row["case"], one(params, "node_id", ""))
        else:
            raise ValueError("Unsupported current source API")
        return dict(value, resource_binding=binding)


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, viewer, **kwargs):
        self.viewer = viewer
        super().__init__(*args, directory=str(viewer.root / "web"), **kwargs)

    def send_bytes(self, raw, mime="application/json; charset=utf-8"):
        if "gzip" in self.headers.get("Accept-Encoding", "") and len(raw) > 2048 and not mime.startswith("application/pdf"):
            raw = gzip.compress(raw, compresslevel=1, mtime=0)
            encoding = "gzip"
        else:
            encoding = None
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        if encoding:
            self.send_header("Content-Encoding", encoding)
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = unquote(parsed.path)
        try:
            if path == "/api/health":
                value = dict(status="ok", service="current-resource-workbench", report_ref=self.viewer.report_ref,
                    cases=len(self.viewer.cases), api_calls=0, live_inference=False)
            elif path == "/api/current/cib-pdf":
                raw, mime = self.viewer.pdf(parse_qs(parsed.query, keep_blank_values=True))
                return self.send_bytes(raw, mime)
            elif path == "/api/current/slots-v1":
                if self.viewer.maps is None:
                    raise ValueError("Opaque slots require the explicitly pinned immutable corpus map")
                if self.viewer.slots is None:
                    from .slot_overlay import SlotOverlay
                    self.viewer.slots = SlotOverlay(self.viewer.maps, self.viewer.report["cases"])
                value = self.viewer.slots.packet(parse_qs(parsed.query, keep_blank_values=True))
            elif path == "/api/current/casebook":
                if parsed.query:
                    raise ValueError("Casebook has no case selectors")
                value = self.viewer.casebook()
            elif path.startswith("/api/current/"):
                value = self.viewer.api(path.removeprefix("/api/current/"), parse_qs(parsed.query, keep_blank_values=True))
            elif path == "/data/report-v6.json":
                return self.send_bytes(planning.bound(self.viewer.root, self.viewer.report_ref["path"]).read_bytes())
            elif path.startswith("/graph-assets-v4/") or path in {"/api/graph-v4-viewer", "/api/cib-pdf"}:
                if self.viewer.maps is None:
                    raise ValueError("An immutable corpus-map export must be selected explicitly")
                params = parse_qs(parsed.query, keep_blank_values=True)
                query = urlencode(sorted((k, one(params, k)) for k in params))
                raw, mime = self.viewer.maps.packet(path+("?"+query if query else ""))
                return self.send_bytes(raw, mime)
            elif path == "/docs/matryoshka-guide.pdf":
                target = planning.bound(self.viewer.root, "docs/demo-guide/guide.pdf")
                return self.send_bytes(target.read_bytes(), "application/pdf")
            else:
                name = asset_name(path, parse_qs(parsed.query, keep_blank_values=True))
                if name not in ASSETS:
                    return self.send_error(404, "No allowlisted public asset")
                target = planning.bound(self.viewer.root, "web/"+name)
                if self.viewer.ui_root is not None:
                    archived = self.viewer.ui_root/name
                    if archived.exists():
                        if archived.resolve()!=archived or not archived.is_file():
                            raise ValueError("Unsafe preview UI snapshot")
                        target=archived
                return self.send_bytes(target.read_bytes(), mimetypes.guess_type(name)[0] or "application/octet-stream")
            self.send_bytes(json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())
        except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
            self.log_error("Current resource request rejected: %s", str(error))
            self.send_error(409, "The exact current question/source artifact is unavailable; no old run was substituted")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--report", required=True)
    parser.add_argument("--report-sha256", required=True)
    parser.add_argument("--map-root", type=Path)
    parser.add_argument("--map-index-sha256")
    parser.add_argument("--digest-index")
    parser.add_argument("--digest-index-sha256")
    parser.add_argument("--source-workspace")
    parser.add_argument("--ui-root", help="Optional local UI snapshot; never changes saved data or inference")
    parser.add_argument("--casebook")
    parser.add_argument("--casebook-sha256")
    parser.add_argument("--pdf-catalog")
    parser.add_argument("--pdf-catalog-sha256")
    parser.add_argument("--port", type=int, default=8941)
    args = parser.parse_args(argv)
    if bool(args.map_root) != bool(args.map_index_sha256):
        parser.error("Both immutable corpus-map root and index pin are required")
    if bool(args.digest_index) != bool(args.digest_index_sha256):
        parser.error("Both immutable digest index path and pin are required")
    if bool(args.casebook) != bool(args.casebook_sha256):
        parser.error("Both casebook path and byte pin are required")
    pdf_args=(args.source_workspace,args.pdf_catalog,args.pdf_catalog_sha256)
    if any(pdf_args) and (not all(pdf_args) or not args.map_root):
        parser.error("Local PDF inspection requires workspace, catalog, catalog pin and corpus map")
    pdfs=None
    if all(pdf_args):
        from .local_pdfs import LocalPDFs
        pdfs=LocalPDFs(args.source_workspace,args.root,dict(path=args.pdf_catalog,sha256=args.pdf_catalog_sha256))
    if args.map_root:
        from .map_transport import SavedMaps
        maps = SavedMaps(args.map_root, args.map_index_sha256,pdfs=pdfs)
    else:
        maps = None
    digest_ref=dict(path=args.digest_index,sha256=args.digest_index_sha256) if args.digest_index else None
    casebook_ref=dict(path=args.casebook,sha256=args.casebook_sha256) if args.casebook else None
    viewer = Viewer(args.root, dict(path=args.report, sha256=args.report_sha256), maps=maps,digest_ref=digest_ref,ui_root=args.ui_root,casebook_ref=casebook_ref)
    server = HTTPServer(("127.0.0.1", args.port), partial(Handler, viewer=viewer))
    print(f"Current resource workbench: http://127.0.0.1:{args.port}/", flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()
        viewer.close()


if __name__ == "__main__":
    main()
