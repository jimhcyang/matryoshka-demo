"""Opt-in complete-clause structural matching, independent of decisions.py.

Literal dependency structure can establish a reported proposition, not world
truth. Source policy is replayed by match_source; callers must still provide
the complete bound index and whole-original-document policy admission.
"""
from copy import deepcopy
import json
import re

VERSION = "current-complete-proposition-matching/1.1"
_MONTHS = "January February March April May June July August September October November December".split()
_MONTH = "(?:" + "|".join(_MONTHS) + ")"
_DATES = re.compile(r"\b(?:\d{4}-\d{2}-\d{2}|" + _MONTH + r"\s+\d{1,2}(?:,?\s+\d{4})?|\d{1,2}\s+" + _MONTH + r"(?:\s+\d{4})?)\b", re.I)
_OPAQUE = re.compile(r"\[(?:\[)?(?:MASK|REDACT|UNKNOWN|ILLEGIBLE|UNREADABLE)|\b25X1\b", re.I)
_SUBJECTS = {"nsubj", "nsubjpass", "nsubj:pass", "csubj", "csubjpass"}
_PATIENTS = {"dobj", "obj", "nsubjpass", "nsubj:pass", "csubjpass"}
_QUALIFIED = {"ccomp", "xcomp", "advcl"}


def _lemma(token):
    return (token.lemma_ or token.text).casefold()


def _proof(token, raw):
    return dict(start=token.idx, end=token.idx+len(token), text=raw[token.idx:token.idx+len(token)],
                lemma=_lemma(token), dependency=token.dep_, pos=token.pos_, tag=token.tag_)


def _article(token):
    return token.dep_ == "det" and "Art" in token.morph.get("PronType")


def _ignored(token):
    return token.is_space or token.is_punct or token.dep_ == "meta" or _article(token)


def _tree(token, *, root=False, excluded=()):
    children = []
    for child in token.children:
        if _ignored(child) or child.i in excluded:
            continue
        if root and child.dep_ in {"neg", "aux", "auxpass", "cop"}:
            continue
        relation = child.dep_
        value = _tree(child)
        if root:
            if relation in _PATIENTS:
                relation = "patient"
            elif relation in _SUBJECTS:
                relation = "owner" if _lemma(token) == "be" else "actor"
            elif relation == "agent" and _lemma(child) == "by":
                objects = [t for t in child.children if t.dep_ == "pobj"]
                if len(objects) == 1:
                    relation, value = "actor", _tree(objects[0])
        children.append((relation, value))
    children.sort(key=lambda x:json.dumps(x, sort_keys=True, ensure_ascii=True))
    return dict(lemma=_lemma(token), name=token.pos_ == "PROPN", children=children)


def _event_dates(root, raw):
    result = []
    for child in root.children:
        if child.dep_ not in {"prep", "npadvmod", "tmod"}:
            continue
        tokens = [t for t in child.subtree if not t.is_space and not t.is_punct]
        if not tokens:
            continue
        lo, hi = min(t.idx for t in tokens), max(t.idx+len(t) for t in tokens)
        matches = list(_DATES.finditer(raw, lo, hi))
        if len(matches) != 1:
            continue
        match = matches[0]
        extras = [t for t in tokens if not (match.start() <= t.idx and t.idx+len(t) <= match.end())
                  and not (t == child and t.dep_ == "prep" and _lemma(t) in {"on", "in", "at", "during"})]
        if extras:
            continue
        literal = " ".join(match.group().casefold().split())
        # No year is inferred from case.date or the source publication date.
        complete_day = bool(re.search(r"\b\d{4}\b", match.group()))
        result.append(dict(start=match.start(), end=match.end(), text=match.group(),
                           literal=literal, explicit_calendar_day_with_year=complete_day,
                           attachment_child=child.i, attachment=_proof(child, raw)))
    return result


def compile_proposition(text, *, engine=None):
    """Retain whole finite main clauses, not a selected leaf frame or label."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("Nonempty literal proposition required")
    if engine is None:
        from matryoshka_demo_v61.scope_matching import Engine
        engine = Engine()
    doc = engine.parse(text)
    issues = []
    if _OPAQUE.search(text):
        issues.append("OPAQUE_CONTENT_NOT_ESTABLISHED")
    if "?" in text:
        issues.append("QUESTION_NOT_NORMALIZED_TO_ASSERTION")
    if any(c in text for c in ('"', "\u201c", "\u201d")):
        issues.append("QUOTATION_REQUIRES_SEPARATE_BOUND_HOLDER_POLICY")
    unresolved = [t for t in doc if t.pos_ == "PRON" or t.dep_ == "det" and t.lower_ in {"this", "that", "these", "those"}]
    if unresolved:
        issues.append("PRONOUN_OR_DEICTIC_REFERENCE_UNRESOLVED")
    roots = [t for t in doc if t.dep_ == "ROOT" and not _ignored(t)]
    propositions = []
    for root in roots:
        auxiliaries = [t for t in root.children if t.dep_ in {"aux", "auxpass", "cop"}]
        finite = root.tag_ in {"VBD", "VBP", "VBZ", "MD"} or any(t.tag_ in {"VBD", "VBP", "VBZ", "MD"} for t in auxiliaries)
        copular = _lemma(root) == "be" or any(t.dep_ == "cop" and _lemma(t) == "be" for t in auxiliaries)
        if not finite or root.pos_ not in {"VERB", "AUX"} and not copular:
            issues.append("NO_FINITE_MATRIX_PROPOSITION")
            continue
        subjects = [t for t in root.children if t.dep_ in _SUBJECTS]
        if len(subjects) != 1:
            issues.append("MATRIX_SUBJECT_NOT_UNIQUELY_BOUND")
        negatives = [t for t in root.children if t.dep_ == "neg"]
        if len(negatives) > 1:
            issues.append("MULTIPLE_MATRIX_NEGATIONS_UNRESOLVED")
        modals = [_lemma(t) for t in auxiliaries if t.tag_ == "MD"]
        other_aux = [_lemma(t) for t in auxiliaries if t.tag_ != "MD" and _lemma(t) not in {"be", "do"}]
        progressive = root.tag_ == "VBG" and any(_lemma(t) == "be" for t in auxiliaries)
        tense = "past" if root.tag_ == "VBD" or any(t.tag_ == "VBD" for t in auxiliaries) else "present"
        dates = _event_dates(root, text)
        full_tree = _tree(root, root=True)
        core = _tree(root, root=True, excluded={d["attachment_child"] for d in dates})
        has_qualification = any(t.dep_ in _QUALIFIED or t.tag_ == "MD" for t in root.subtree)
        matrix_adverbs = [_lemma(t) for t in root.children if t.dep_ == "advmod"]
        propositions.append(dict(matrix=_proof(root, text), kind="STATE" if copular or progressive else "EVENT",
            subject=[_proof(t, text) for t in subjects], full_tree=full_tree, core_tree=core,
            negated=bool(negatives), negation_proofs=[_proof(t, text) for t in negatives],
            modality=modals, other_auxiliaries=other_aux, progressive=progressive, tense=tense,
            matrix_adverbs=matrix_adverbs, event_dates=dates,
            qualified_content=has_qualification,
            actual_inner_event_established=False,
            all_subordinate_content_retained=True))
    if not propositions:
        issues.append("NO_COMPLETE_MAIN_PROPOSITION")
    return dict(version=VERSION, text=text, propositions=propositions, complete=not issues,
        issues=sorted(set(issues)), unresolved_reference_proofs=[_proof(t, text) for t in unresolved],
        raw_token_proofs=[_proof(t, text) for t in doc if not t.is_space],
        lexical_synonyms_or_entity_aliases_used=False, publication_date_used_as_event_date=False,
        leaf_frames_or_generated_annotations_used_as_main_clause=False)


def _pair(query, source):
    reasons = []
    for field in ("core_tree", "modality", "other_auxiliaries", "progressive", "tense"):
        if query[field] != source[field]:
            reasons.append("COMPLETE_" + field.upper() + "_NOT_ALIGNED")
    qdates = [d["literal"] for d in query["event_dates"]]
    sdates = [d["literal"] for d in source["event_dates"]]
    if qdates and qdates != sdates:
        reasons.append("EXPLICIT_EVENT_TIME_NOT_ALIGNED")
    opposite = query["negated"] != source["negated"]
    # V1 has no trusted discourse/event-time resolver. Do not infer a shared
    # event clock, even for an undated positive historical-looking sentence.
    if not (qdates == sdates and qdates and
            all(d["explicit_calendar_day_with_year"] for d in query["event_dates"] + source["event_dates"])):
        reasons.append("SAME_EXPLICIT_EVENT_DAY_NOT_ESTABLISHED")
    if opposite and (query["kind"] == "STATE" or source["kind"] == "STATE"):
        reasons.append("STATE_OPPOSITION_NEEDS_BOUND_SAME_INSTANT_OR_INTERVAL")
    if opposite and (query["modality"] or source["modality"] or query["matrix_adverbs"] or source["matrix_adverbs"]
                     or any(t[0] == "advcl" for t in query["core_tree"]["children"] + source["core_tree"]["children"])):
        reasons.append("UNCERTAIN_OR_CONDITIONAL_MATRIX_NOT_DECISIVE_OPPOSITION")
    if reasons:
        direction = "UNRESOLVED"
    else:
        direction = "COUNTER" if opposite else "SUPPORT"
    return dict(direction=direction, reasons=reasons, query_matrix=query["matrix"], source_matrix=source["matrix"],
        complete_matrix_roles_and_content=not any(r.startswith("COMPLETE_") for r in reasons),
        source_uncertainty_not_erased=True, actual_inner_event_established=False,
        world_truth_certified=False)


def compare_propositions(query_text, source_text, *, engine=None):
    """No noun-category difference is a contradiction; no cross-source joining."""
    if engine is None:
        from matryoshka_demo_v61.scope_matching import Engine
        engine = Engine()
    query = compile_proposition(query_text, engine=engine)
    source = compile_proposition(source_text, engine=engine)
    comparisons = []
    if query["complete"] and source["complete"]:
        for wanted in query["propositions"]:
            comparisons.append([_pair(wanted, offered) for offered in source["propositions"]])
    supported = bool(comparisons) and all(any(p["direction"] == "SUPPORT" for p in row) for row in comparisons)
    opposed = any(any(p["direction"] == "COUNTER" for p in row) for row in comparisons)
    direction = "UNRESOLVED" if supported and opposed else "SUPPORT" if supported else "COUNTER" if opposed else "UNRESOLVED"
    return dict(version=VERSION, direction=direction, query=query, source=source, comparisons=comparisons,
        prototype_only=True, source_policy_replayed=False, main_proposition_not_leaf_only=True,
        source_claim_not_world_truth=True, actual_inner_event_established=False,
        keys_read=False, grades_read=False, model_calls=0,
        limitations=["Literal structural scope only; no synonyms, global aliases, discourse anaphora or category-exclusivity oracle.",
                     "V1 requires the same explicit root-attached full calendar day; no undated discourse-event or publication-date inference.",
                     "State opposition additionally needs a bound same instant/interval, not merely the same day, and is not certified in V1.",
                     "Complete raw source policy and independent semantic validation remain caller obligations."])


def match_source(case, requirement, page, unit, eligible_index, *, engine=None):
    """Replay exact public-query and seven-field source spans before matching.

    Handoff API for the execution owner. No decisions.py import or mutation.
    eligible_index must be the complete bound index, not a favorable page subset.
    """
    from matryoshka_demo.contracts import public_case
    from matryoshka_demo_v6 import planning as literal
    from matryoshka_demo_v6 import reporting_local_decisions_v65 as provenance
    case = public_case(case)
    if case["task"] not in {"hypothesis", "reconstruction"}:
        raise ValueError("Complete proposition matching is H/R only")
    a, b = requirement["start"], requirement["end"]
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(case["query"])
            or case["query"][a:b] != requirement["text"]):
        raise ValueError("Public proposition offsets do not replay")
    start, end = unit["start"], unit["end"]
    if (type(start) is not int or type(end) is not int or not 0 <= start < end <= len(page["text"])
            or page["text"][start:end] != unit["text"]):
        raise ValueError("Source proposition offsets do not replay")
    index = provenance._pages(eligible_index, case)
    bound = index[0].get(page["id"])
    if bound is None or any(bound.get(k) != page.get(k) for k in
            ("id", "document_id", "date", "text", "source_sha256", "corpus", "classification", "handling", "visibility", "permitted")):
        raise ValueError("Source proposition differs from bound index")
    citation = provenance._citation(page, start, end)
    provenance._quote(citation, *index, case)
    result = compare_propositions(requirement["text"], unit["text"], engine=engine)
    outside_scope = literal._open_reporting_context(case["query"][:a]) or literal._open_reporting_context(page["text"][:start])
    if outside_scope:
        result["direction"] = "UNRESOLVED"
        result["external_scope_blocker"] = "OPEN_QUOTATION_OR_REPORTING_BLOCK"
    result.update(citation=citation, source_policy_replayed=True,
        source_policy_scope="Exact indexed pages/visibility/cutoff/whole-origin/sibling handling replay; full original-body admission and resource binding remain caller-owned.",
        requirement_id=requirement.get("id"), source_words_modified=False,
        saved_native_or_gate_verdict_rewritten=False)
    return result
