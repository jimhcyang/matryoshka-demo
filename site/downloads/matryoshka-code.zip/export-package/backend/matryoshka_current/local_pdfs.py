"""Explicit, byte-pinned local originals; never an inference evidence source."""
import hashlib
import json
from pathlib import Path, PurePosixPath
from urllib.parse import parse_qs, urlsplit

from matryoshka_demo.io import digest
from . import publication

VERSION = "current-local-source-pdfs/1"
PREFIX = "src-redaction/data/source/pdfs/"


def safe_path(root, name):
    if (not isinstance(name, str) or "\\" in name or PurePosixPath(name).is_absolute()
            or any(p in {"", ".", ".."} for p in name.split("/"))):
        raise ValueError("Unsafe local source path")
    target = Path(root).resolve() / name
    if target.resolve() != target or not target.is_file():
        raise ValueError("Missing or symlinked local source")
    return target


class LocalPDFs:
    def __init__(self, workspace, catalog_root, ref):
        self.root = Path(workspace).resolve()
        self.catalog_root = Path(catalog_root).resolve()
        self.ref = ref
        catalog = publication.read(self.catalog_root, ref)
        if (catalog.get("version") != VERSION
                or catalog.get("sha256") != digest({k:v for k,v in catalog.items() if k != "sha256"})):
            raise ValueError("Local source catalog changed")
        document_ref = catalog["documents_ref"]
        raw = safe_path(self.root, document_ref["path"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != document_ref["sha256"]:
            raise ValueError("Original document inventory changed")
        documents = [json.loads(line) for line in raw.splitlines() if line]
        self.documents = {row["document_id"]:row for row in documents}
        if len(documents) != len(self.documents):
            raise ValueError("Repeated source document identity")
        self.entries = catalog["entries"]
        self.resource_id = catalog["resource_id"]
        for document, releases in self.entries.items():
            if set(releases) != {"earlier", "later"} or document not in self.documents:
                raise ValueError("Unbound source PDF pair")
            for release, entry in releases.items():
                if (entry["path"] != "src-redaction/"+self.documents[document][release+"_pdf"]
                        or not entry["path"].startswith(PREFIX+release+"/")
                        or not 5 <= entry["bytes"] <= 32*1024**2):
                    raise ValueError("Source PDF escaped its recorded document/release")
                safe_path(self.root, entry["path"])

    def packet(self, key):
        parsed = urlsplit(key)
        params = parse_qs(parsed.query, keep_blank_values=True)
        if (parsed.path != "/api/cib-pdf" or set(params) != {"doc_id", "release"}
                or any(len(v) != 1 for v in params.values())):
            raise ValueError("Explicit, unique source PDF selectors required")
        document, release = params["doc_id"][0], params["release"][0]
        if release not in {"earlier", "later"}:
            raise ValueError("Unknown source PDF release")
        entry = self.entries[document][release]
        raw = safe_path(self.root, entry["path"]).read_bytes()
        if (len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]
                or not raw.startswith(b"%PDF-")):
            raise ValueError("Original source PDF bytes changed")
        return raw, "application/pdf"
