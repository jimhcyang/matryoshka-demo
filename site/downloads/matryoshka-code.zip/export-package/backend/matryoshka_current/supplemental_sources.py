"""Registered complete released-document editions, not query/page authority flags."""
from copy import deepcopy
from datetime import date
import hashlib
import json
from types import MappingProxyType

from matryoshka_demo.io import digest as shared_digest
from . import resources as r

VERSION = "registered-full-source-documents/1"
VISIBILITY = "supplied_registered"
_TOKEN = object()
_PRIVATE = {"answer","gold","gold_QA_ONLY","reference_answer","prediction","predicted_fill","evaluation_keys","grades"}


def _source_only(value):
    if isinstance(value,dict):
        _check(not _PRIVATE.intersection(value),"Answer/prediction/grade fields are not source authority")
        for child in value.values():
            _source_only(child)
    elif isinstance(value,list):
        for child in value:
            _source_only(child)


def _check(value, message):
    if not value:
        raise ValueError(message)


def _ref(workspace, reference):
    _check(isinstance(reference,dict) and isinstance(reference.get("path"),str)
        and isinstance(reference.get("sha256"),str) and len(reference["sha256"]) == 64,
        "Hash-bound supplied source reference required")
    path = r.safe_path(workspace,reference["path"])
    _check(path.is_file() and r.file_sha(path) == reference["sha256"],"Supplied source file changed")
    if "bytes" in reference:
        _check(type(reference["bytes"]) is int and path.stat().st_size == reference["bytes"],"Supplied byte count changed")
    return path


def _rows(path):
    def unique(pairs):
        value = {}
        for key, child in pairs:
            _check(key not in value,"Duplicate supplied page field")
            value[key] = child
        return value
    with path.open() as stream:
        return [json.loads(line,object_pairs_hook=unique) for line in stream if line.strip()]


class _RegisteredPage(dict):
    def __init__(self, value, authority, token):
        _check(token is _TOKEN,"Only verified source registration can bind supplied pages")
        super().__init__(value)
        self._registered_supplied_source = authority

    def __deepcopy__(self, memo):
        result = _RegisteredPage(deepcopy(dict(self),memo),self._registered_supplied_source,_TOKEN)
        memo[id(self)] = result
        return result


def registered_page(page):
    """A JSON flag or self-recomputed text hash is not a registration witness."""
    return (type(page) is _RegisteredPage
        and type(page._registered_supplied_source) is Registration
        and page._registered_supplied_source.matches(page))


class Registration:
    """Explicit immutable registry capability; serialized rows alone cannot mint it."""
    def __init__(self, workspace, registry):
        r.check_registry(registry)
        registered = registry.get("registered_supplied_documents")
        _check(isinstance(registered,dict) and registered.get("version") == VERSION,
            "Explicit supplied-document registry binding required")
        self.registry_digest = registry["registry_digest"]
        self.edition_id = registry["source_edition_id"]
        self.manifest_ref = deepcopy(registered["manifest_ref"])
        manifest = r.load_json(_ref(workspace,self.manifest_ref))
        _source_only(manifest)
        _check(set(manifest) == {"version","corpus","documents"},"Source manifest cannot carry query/answer selection data")
        _check(manifest.get("version") == VERSION and manifest.get("corpus") == "cib"
            and isinstance(manifest.get("documents"),list) and manifest["documents"],
            "Complete public CIB document manifest required")
        pages, documents = {}, {}
        for document in manifest["documents"]:
            did, when = document["document_id"], document["document_date"]
            _check(isinstance(did,str) and did and did not in documents,"Duplicate supplied document")
            _check(date.fromisoformat(when).isoformat() == when,"Actual ISO document date required")
            release = document["source_release"]
            _check(release.get("public_release") is True and release.get("edition") == document["edition"]
                and document["edition"] in {"earlier","later"},"Released edition provenance required")
            _check(date.fromisoformat(release["release_date"]).isoformat() == release["release_date"],
                "Actual release date required separately from historical document date")
            pdf = _ref(workspace,document["pdf_ref"])
            from pypdf import PdfReader
            with pdf.open("rb") as stream:
                count = len(PdfReader(stream).pages)
            _check(type(document["physical_page_count"]) is int and count == document["physical_page_count"],
                "Physical PDF completeness changed")
            rows = _rows(_ref(workspace,document["pages_ref"]))
            _check(len(rows) == count and [p["physical_page"] for p in rows] == list(range(1,count+1)),
                "All physical pages, including covers and empty transcripts, are required")
            if document.get("classification_review_ref"):
                _ref(workspace,document["classification_review_ref"])
            markings = document.get("historical_page_markings",{})
            _check(all(str(int(k)) == k and 1 <= int(k) <= count and isinstance(v,str) and v
                for k,v in markings.items()),"Unbound page classification marking")
            documents[did] = deepcopy(document)
            for raw in rows:
                _source_only(raw)
                n, text = raw["physical_page"],raw["text"]
                _check(raw["document_id"] == did and raw["document_date"] == when
                    and raw["edition"] == document["edition"]
                    and raw["source_edition_id"] == document["original_source_edition_id"]
                    and raw["pdf_ref"]["sha256"] == document["pdf_ref"]["sha256"]
                    and raw.get("remaining_unknowns_filled") is False,
                    "Supplied page document/date/edition/PDF/unknown-text binding changed")
                _check(isinstance(text,str) and hashlib.sha256(text.encode()).hexdigest() == raw["text_sha256_utf8"],
                    "Supplied raw page text changed")
                _check(_ref(workspace,raw["clean_text_ref"]).read_bytes() == text.encode(),
                    "Supplied page is not the full existing clean transcript")
                _check(raw["pdf_ref"] == document["pdf_ref"],"Physical page PDF reference changed")
                original = raw.get("existing_canonical_page_ids",[])
                _check(isinstance(original,list) and all(isinstance(v,str) and v for v in original),
                    "Original canonical mappings must remain explicit")
                pid = "supplied_page_"+shared_digest([self.edition_id,self.manifest_ref,did,n,raw["text_sha256_utf8"]])[:24]
                page = dict(id=pid,canonical_page_id=pid,corpus="cib",document_id=did,date=when,text=text,
                    source_sha256=shared_digest(text),source_hash_contract="shared-json-string-ensure-ascii-true/sha256",
                    raw_text_sha256=raw["text_sha256_utf8"],permitted=True,visibility=VISIBILITY,
                    view=document["edition"],earlier_page=None,source_page=n,pdf_page=n,
                    original_canonical_page_ids=deepcopy(original),
                    original_canonical_page_id=original[0] if len(original)==1 else None,
                    classification=markings.get(str(n),raw["classification_level"]),
                    structured_classification=raw["classification_level"],
                    handling=deepcopy(document.get("distribution_controls",[])),native_page=deepcopy(raw),
                    supplied_source=dict(version=VERSION,source_edition_id=self.edition_id,
                        source_manifest_ref=deepcopy(self.manifest_ref),
                        original_source_edition_id=raw["source_edition_id"],original_source_page_id=raw["source_page_id"],
                        physical_page=n,pdf_ref=deepcopy(document["pdf_ref"]),
                        source_release=deepcopy(release),original_canonical_page_ids=deepcopy(original),
                        classification_evidence_ref=deepcopy(document.get("classification_review_ref")),
                        document_historical_marking=document.get("document_historical_marking"),
                        semantic_observations_added=False,identity_or_task_support_certified=False))
                _check(pid not in pages,"Duplicate registered supplied page")
                pages[pid] = page
        self._pages = pages
        self.page_hashes = MappingProxyType({pid:shared_digest(page) for pid,page in pages.items()})
        self.documents = documents

    def matches(self, page):
        return self.page_hashes.get(page.get("id")) == shared_digest(dict(page))

    def bind(self, page):
        _check(self.matches(page),"Supplied page is not the exact registered edition row")
        return _RegisteredPage(deepcopy(dict(page)),self,_TOKEN)

    def pages(self):
        return [self.bind(page) for page in self._pages.values()]
