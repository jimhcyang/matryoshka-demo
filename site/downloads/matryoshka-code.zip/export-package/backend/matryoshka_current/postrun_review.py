"""Offline, detached review projection. No inference, API, grader import or writes."""
from copy import deepcopy
from datetime import date
import gzip
import hashlib
import json
import math
from pathlib import Path
import re
import sqlite3

VERSION='current-postrun-review-projection/1'
PROTOCOL=dict(version='independent-redaction-assessment/2',stage='current_red_independent_review_v2',
    model='gpt-6.1-sol',max_output_tokens=6000,
    prompt_sha256='aae7a7b5445842baeb09be296df936389f3e0691ecd1a657cbf2f4866564e0cc',
    schema_sha256='13c9c95759853381d840373038360637f2b55ca37821daa879a177327601c7e6',
    api_version='demo-paid-stages/2',native_claim_status_supplied=False,
    judgment_policy='UNCLEAR_WITHOUT_NATIVE_ASSERTION',
    protocol_code_sha256='8dd1d5daa8bd5736ac364adee1b873fa2eb3f2ca83b9ceb66b5abe5475074e98',
    legacy_assessment_compatibility_asserted=False)
FIELDS=('canonical_page_id','document_id','date','start','end','text','page_sha256')


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


_SELF_SHA=_sha(Path(__file__))


def _require(ok,message):
    if not ok:raise ValueError(message)


def _path(root,relative):
    _require(isinstance(relative,str) and relative and '\\' not in relative,'Literal relative path required')
    _require(not Path(relative).is_absolute() and all(p not in {'','.','..'} for p in relative.split('/')),'Path traversal rejected')
    path=root/relative
    _require(path.resolve(strict=True)==path,'Symlink or redirected review path rejected')
    return path


def _pin(ref):
    _require(isinstance(ref,dict) and set(ref)>={'path','sha256'} and
        isinstance(ref['sha256'],str) and re.fullmatch('[a-f0-9]{64}',ref['sha256']),'Explicit byte reference required')
    return {k:ref[k] for k in ('path','sha256')}


def _read(root,ref,pins,*,json_value=True):
    ref=_pin(ref);path=_path(root,ref['path']);wire=path.read_bytes()
    _require(hashlib.sha256(wire).hexdigest()==ref['sha256'],'Review/source/artifact byte pin differs: '+ref['path'])
    _require(ref['path'] not in pins or pins[ref['path']]==ref['sha256'],'Conflicting explicit byte pins')
    pins[ref['path']]=ref['sha256']
    return json.loads(gzip.decompress(wire) if path.suffix=='.gz' else wire) if json_value else wire


def _sealed(value):
    _require(value.get('sha256')==_digest({k:v for k,v in value.items() if k!='sha256'}),'Artifact self-seal differs')


def _native_binding(native):
    _sealed(native)
    _require(native.get('version')=='current-native-condition/1' and native['case']['task']=='redaction'
        and native['native_checksum']==_digest(native['result']),'Full current redaction native required')
    _require(all(native.get(k) is False for k in ('old_native_resealed','old_ranks_or_grades_reused','keys_read','grades_read')),
        'Not an answer-blind current native condition')
    identity=native['identity'];case=native['case'];binding=native['resource_binding']
    _require(identity['case']==case and identity['config']==native['config']
        and identity['registry_ref']==native['registry_ref'] and identity['index_ref']==native['index_ref']
        and identity['plan_release_ref']==native['plan_release_ref'] and identity['plan_sha256']==_digest(native['plan'])
        and identity['source_binding_sha256']==native['source_binding_sha256']
        and identity['code_sha256']==_digest(native['code']),'Native identity/resource/plan binding differs')
    _require(native['run_id']=='current_'+_digest(identity)[:24],'Native run/identity differs')
    return dict(case_id=case['case_id'],config=native['config'],resource_id=binding.get('resource_id') or binding['graph_id'],
        registry_sha256=identity['registry_sha256'],index_sha256=native['index_ref']['sha256'],
        source_binding_sha256=native['source_binding_sha256'],native_run_id=native['run_id'],
        native_checksum=native['native_checksum'],native_record_sha256=native['sha256'],
        case_sha256=_digest(case),query_sha256=_digest(case['query']),code_sha256=identity['code_sha256'])


def _sources(candidate):
    offered=list(candidate.get('sources',[]))+[e['citation'] for e in candidate.get('support_assessment',{}).get('evidence',[])]
    unique={};pages={}
    for row in offered:
        ref=row.get('citation',row)
        _require(all(k in ref for k in FIELDS),'Incomplete source citation')
        _require(all(k not in row or row[k]==ref[k] for k in FIELDS),'Nested source bindings disagree')
        pid=ref['canonical_page_id'];binding=tuple(ref[k] for k in ('document_id','date','page_sha256'))
        _require(pid not in pages or pages[pid]==binding,'Conflicting canonical page identity');pages[pid]=binding
        key=(pid,ref['start'],ref['end'])
        _require(key not in unique or unique[key]['text']==ref['text'],'Conflicting quotation for a source span')
        if key not in unique:unique[key]=deepcopy(ref)
    return sorted(unique.values(),key=lambda x:tuple(x[k] for k in ('date','document_id','canonical_page_id','start','end')))


def _items(native):
    case=native['case'];items={};rows=[]
    _require(case['focal_marker'] and case['query'].count(case['focal_marker'])==1,'Unique focal marker required')
    seen=set()
    for reading in native['result']['readings']:
        rid=reading['reading']['id']
        for rank,candidate in enumerate(reading['candidates'][:5],1):
            key=(rid,candidate['id']);_require(key not in seen,'Duplicate native candidate identity');seen.add(key)
            refs=_sources(candidate)
            value=dict(kind='redaction_fill',assessment_unit='inserted_fill',candidate_fill=candidate['fill'],
                completed_sentence=case['query'].replace(case['focal_marker'],candidate['fill']),
                sources=[dict(id='S'+str(i),text=s['text'],date=s['date']) for i,s in enumerate(refs,1)],
                packet_version='source-complete-assessment-packets/3')
            item=dict(id='item_'+_digest(value)[:24],**value);items[item['id']]=item
            rows.append(dict(reading_id=rid,candidate_id=candidate['id'],rank=rank,fill=candidate['fill'],
                item_id=item['id'],sources=refs))
    _require(rows,'No saved top-five candidate items')
    return sorted(items.values(),key=lambda x:x['id']),rows


def _source_replay(root,native,rows,pins):
    reference=native['index_ref'];path=_path(root,reference['path'])
    _require(_sha(path)==reference['sha256'],'Native source index changed');pins[reference['path']]=reference['sha256']
    case=native['case'];docs={s['document_id'] for row in rows for s in row['sources']};veto=set()
    db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)
    try:
        for doc in sorted(docs):
            for (payload,) in db.execute('SELECT payload FROM page WHERE doc=?',(doc,)):
                page=json.loads(payload)
                if (re.search(r'\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM',page['text'],re.I)
                        or any(re.search(r'NOFORN|NO\s+FOREIGN\s+DISSEM',str(h),re.I) for h in page.get('handling',[]))):veto.add(doc)
        admitted_docs={d if isinstance(d,str) else d['document_id'] for d in native['result']['retrieval']['document_order']}
        for row in rows:
            for ref in row['sources']:
                values=list(db.execute('SELECT payload FROM page WHERE id=?',(ref['canonical_page_id'],)))
                _require(len(values)==1,'Canonical source page missing/ambiguous');page=json.loads(values[0][0])
                a,b=ref['start'],ref['end'];date.fromisoformat(page['date'])
                _require(page.get('canonical_page_id',page['id'])==ref['canonical_page_id']
                    and page.get('permitted') is True and page['corpus']==case['corpus']
                    and page['document_id']!=case['document_id'] and page['date']<case['date']
                    and page.get('visibility') in {None,'earlier','both'} and page['document_id'] not in veto
                    and (case['corpus']=='cib' or page.get('classification')=='CONFIDENTIAL'),'Quotation source policy failed')
                _require(type(a) is int and type(b) is int and 0<=a<b<=len(page['text'])
                    and page['text'][a:b]==ref['text'] and _digest(page['text'])==page['source_sha256']==ref['page_sha256']
                    and page['document_id']==ref['document_id'] and page['date']==ref['date'],'Source text/offset/hash differs')
                _require(ref['canonical_page_id'] in native['inspected_page_ids'] or ref['document_id'] in admitted_docs,
                    'Saved quote outside native page/document scope')
    finally:db.close()


def _reference_answer(root,native,selected,stage,pins):
    case=native['case'];manifest_ref=selected['source_manifest_ref']
    _require(manifest_ref==stage['spec']['source'],'Source manifest changed between review and preparation')
    manifest=_read(root,manifest_ref,pins);directory=Path(manifest_ref['path']).parent
    def artifact(name):return dict(path=str(directory/name),sha256=manifest['artifacts'][name])
    catalog_ref=artifact('candidate_public_catalog.json');catalog=_read(root,catalog_ref,pins)
    _require(catalog_ref['sha256']==manifest['public_catalog_sha256']
        and [c for c in catalog['cases'] if c['case_id']==case['case_id']]==[case],'Key catalog/case differs')
    key_ref=artifact('private/evaluation_keys.json');proof_ref=artifact('private/source_proofs.json')
    _require(proof_ref['sha256']==manifest['source_proofs_sha256'],'Source proof manifest binding differs')
    _require(_pin(selected['key_ref'])==key_ref and selected['key_ref']==stage['key_ref']
        and selected['key_ref']['used_for_inference'] is False
        and selected['key_ref']['commitment_refs']==[manifest_ref,catalog_ref]
        and selected['source_proof_ref']==stage['proof_ref']==proof_ref,'Explicit key/source proof commitments differ')
    answer=_read(root,key_ref,pins)[case['case_id']]['answer'];proof=_read(root,proof_ref,pins)['cases'][case['case_id']]
    origin=proof['origin'];_require(origin['document_id']==case['document_id'] and origin['date']==case['date']
        and _digest(origin['text'])==origin.get('quote_sha256',origin.get('source_text_sha256')),'Original key source differs')
    anchors=[a for a in proof.get('origin_anchors',[]) if a.get('focal')] if case['corpus']=='cib' else [proof['hidden_span']]
    _require(len(anchors)==1,'Unique committed focal interval required');anchor=anchors[0]
    a=anchor['start']-origin.get('start',0);b=anchor['end']-origin.get('start',0)
    window=case['query'].replace(case['focal_marker'],answer)
    _require(isinstance(answer,str) and answer and origin['text'][a:b]==anchor['text']==answer
        and origin['text'].count(window)==1 and origin['text'].index(window)+case['query'].index(case['focal_marker'])==a,
        'Held-out key/focal bytes/public query window differ')
    return answer


def _paid(root,api_root,selected,packet,pins):
    assessment=selected['assessment'];verification=selected['verification']
    _require(assessment['version']==PROTOCOL['version'] and assessment['contract']==PROTOCOL
        and assessment['packet_sha256']==_digest(packet) and assessment['used_for_inference'] is False
        and assessment['answer_aware'] is True
        and verification['contract']==PROTOCOL and verification['status']=='VERIFIED_LOCAL_ARTIFACT_CONSISTENCY',
        'Unsupported or stale independent assessment protocol')
    hashes=verification['artifact_sha256']
    def read(relative):
        _require(relative in hashes,'Unpinned paid artifact')
        return _read(root,dict(path=api_root+'/'+relative,sha256=hashes[relative]),pins)
    ref=assessment['receipt'];key=ref['request_sha256'];cache=read('cache/'+key+'.json')
    _require(re.fullmatch('[a-f0-9]{64}',key) and re.fullmatch(r'receipts/[a-f0-9]+\.json',ref['receipt'])
        and set(hashes)=={'cache/'+key+'.json','requests/'+key+'.json','responses/'+key+'.json',ref['receipt']},
        'Paid artifact inventory differs')
    wire=cache['request'];schema=wire['text']['format']['schema'];prompt=wire['instructions']
    _require(_digest(prompt)==PROTOCOL['prompt_sha256'] and _digest(schema)==PROTOCOL['schema_sha256'],
        'Prompt/schema do not match the pinned v2 protocol')
    expected=dict(model=PROTOCOL['model'],instructions=prompt,input=[dict(role='user',content=[dict(type='input_text',
        text=json.dumps(packet,ensure_ascii=True,sort_keys=True))])],text=dict(format=dict(type='json_schema',
        name=PROTOCOL['stage'],strict=True,schema=schema)),max_output_tokens=6000,store=False,reasoning=dict(effort='low'))
    _require(wire==expected and key==_digest(dict(version=PROTOCOL['api_version'],endpoint='https://api.openai.com/v1',
        stage=PROTOCOL['stage'],request=wire)),'Paid request/ordered packet differs')
    request=read('requests/'+key+'.json')
    _require(request==dict(version=PROTOCOL['api_version'],stage=PROTOCOL['stage'],request=wire,request_sha256=key)
        and cache['version']==PROTOCOL['api_version'] and cache['receipt_path']==ref['receipt'],'Paid envelope/cache binding differs')
    _require(ref['receipt'].startswith('receipts/'),'Receipt outside declared ledger')
    receipt=read(ref['receipt']);response=read('responses/'+key+'.json');output=cache['output']
    _require(cache['output_sha256']==_digest(output) and output['grades']==assessment['grades'],'Paid grades changed')
    _require(response['status']=='completed' and response.get('error') is None and response.get('incomplete_details') is None,
        'Paid response did not complete')
    for field in ('model','instructions','max_output_tokens','store'):
        _require(response[field]==wire[field],'Paid response echo differs: '+field)
    _require(response['reasoning']['effort']==wire['reasoning']['effort'],'Paid response reasoning effort differs')
    fmt=response['text']['format'];aliases=[fmt[k] for k in ('schema','schema_') if k in fmt]
    _require(all(fmt[k]==wire['text']['format'][k] for k in ('type','name','strict'))
        and aliases and all(s==schema for s in aliases),'Response schema/prompt contract differs')
    texts=[]
    for item in response['output']:
        if item['type']!='message':continue
        _require(item['role']=='assistant' and item['status']=='completed'
            and not any(p['type']=='refusal' for p in item['content']),'Invalid paid assistant output')
        texts.extend(p['text'] for p in item['content'] if p['type']=='output_text')
    _require(len(texts)==1 and json.loads(texts[0])==output,'Raw paid output differs')
    usage=response['usage'];_require(all(type(usage[k]) is int and usage[k]>=0 for k in ('input_tokens','output_tokens')),'Invalid paid usage')
    _require('total_tokens' not in usage or type(usage['total_tokens']) is int
        and usage['total_tokens']==usage['input_tokens']+usage['output_tokens'],'Invalid paid total usage')
    cost=(usage['input_tokens']*2+usage['output_tokens']*10)/1e6
    _require(receipt['status']=='PASS' and receipt['request_sha256']==_digest(wire) and receipt['model']==wire['model']
        and receipt['response_id']==response['id'] and receipt['usage']==usage and receipt['rates']==[2.,10.]
        and isinstance(response['id'],str) and response['id']
        and type(receipt['cap_usd']) in (int,float) and 0<receipt['cap_usd']<=25
        and type(receipt['charged_or_reserved_usd']) in (int,float) and 0<=cost<=receipt['cap_usd']
        and math.isclose(receipt['charged_or_reserved_usd'],cost,rel_tol=1e-12,abs_tol=1e-12),
        'Paid usage/receipt differs')
    grades=output['grades'];ids={item['id']:item for item in packet['items']}
    _require(1<=len(ids)<=20 and verification['grades']==len(ids)
        and verification['version']==PROTOCOL['version']+'/replay' and verification['api_calls']==0
        and verification['artifacts_modified'] is False and verification['provider_authenticity_certified'] is False,
        'Paid replay scope/certification differs')
    _require(set(output)=={'grades'} and len(grades)==len(ids) and {g['id'] for g in grades}==set(ids),'Grade/item cross-product differs')
    for grade in grades:
        _require(set(grade)=={'id','answer_match','evidence_support','grammatical','judgment','cited_source_ids','explanation'}
            and grade['answer_match'] in {'correct','partial','incorrect'} and grade['judgment']=='unclear'
            and grade['evidence_support'] in {'direct','partial','context','contradicted','none'}
            and (type(grade['grammatical']) is bool or grade['grammatical'] is None)
            and isinstance(grade['explanation'],str) and isinstance(grade['cited_source_ids'],list),'Invalid independent grade')
        _require(set(grade['cited_source_ids'])<={s['id'] for s in ids[grade['id']]['sources']}
            and (grade['evidence_support']=='none' or grade['cited_source_ids']),'Invented/absent assessment citation')
    return {g['id']:g for g in grades}


def _verify(root,native,reference):
    binding=_native_binding(native);pins={}
    _require(set(reference)=={'assessment_ref','prepared_ref','protocol_ref','api_root'},'Explicit four-part review descriptor required')
    protocol_bytes=_read(root,reference['protocol_ref'],pins,json_value=False)
    _require(hashlib.sha256(protocol_bytes).hexdigest()==PROTOCOL['protocol_code_sha256'],'Unsupported pinned protocol source')
    review=_read(root,reference['assessment_ref'],pins);prepared=_read(root,reference['prepared_ref'],pins)
    _require(review['version']=='current-independent-redaction-review/2' and review['status']=='COMPLETE'
        and review['protocol']==prepared['protocol']==PROTOCOL and review['prepared_sha256']==_digest(prepared)
        and review['used_for_inference'] is False and review['native_outputs_modified'] is False
        and prepared['native_status_not_sent'] is True and prepared['used_for_inference'] is False
        and PROTOCOL['protocol_code_sha256'] in prepared['code_pins'].values(),'Review/preparation/protocol binding differs')
    folder='experiments/current_refresh/execution/runs/'+native['run_id']+'/'
    checkpoint=folder+native['case']['case_id']+'__'+native['config']+'.json.gz'
    selected=[r for r in review['results'] if r['native_checkpoint']['path']==checkpoint]
    _require(len(selected)==1,'No unique assessment for this exact native');result=selected[0]
    saved=_read(root,result['native_checkpoint'],pins)
    _require(saved==native,'Review belongs to a different native/checkpoint')
    completion=_read(root,result['completion_ref'],pins);_sealed(completion)
    _require(result['completion_ref']['path']==folder+'completion.json.gz'
        and completion['version']=='current-execution-completion/1' and completion['api_calls']==0
        and _pin(completion['checkpoint'])==_pin(result['native_checkpoint']) and completion['identity']==native['identity']
        and completion['native_checksum']==native['native_checksum'] and completion['run_id']==native['run_id'],'Native completion differs')
    _require(completion['checkpoint']['decoded_sha256']==hashlib.sha256(gzip.decompress(
        _path(root,checkpoint).read_bytes())).hexdigest(),'Decoded checkpoint bytes differ')
    stages=[s for s in prepared['conditions'] if s['spec']['native']==result['native_checkpoint']]
    _require(len(stages)==1,'No unique prepared native packet');stage=stages[0]
    _require(stage['completion']==result['completion_ref'],'Preparation completion differs')
    registry=_read(root,native['registry_ref'],pins);_sealed(registry)
    _require(registry['sha256']==binding['registry_sha256'] and registry['corpora'][native['case']['corpus']]==native['resource_binding']
        and _digest(native['resource_binding'])==binding['source_binding_sha256']
        and native['index_ref']['registry_sha256']==binding['registry_sha256']
        and native['index_ref']['corpus']==native['case']['corpus']
        and native['index_ref']['source_binding_sha256']==binding['source_binding_sha256'],'Case/query/resource registry differs')
    plan=_read(root,native['plan_release_ref'],pins);_sealed(plan)
    _require(plan['case']==native['case'] and plan['plan']==native['plan'] and plan['index_ref']==native['index_ref']
        and plan['registry_sha256']==binding['registry_sha256'],'Saved exact plan/resources differ')
    items,rows=_items(native);_source_replay(root,native,rows,pins)
    answer=_reference_answer(root,native,result,stage,pins)
    case=native['case'];packet=dict(version='source-complete-assessment-packets/3',task='redaction',question=case['query'],
        question_date=case['date'],focal_marker=case['focal_marker'],reference_answer=answer,items=items)
    _require(stage['packet']==packet and result['packet_sha256']==_digest(packet),'Case/query/fill/ordered quotations/item IDs differ')
    _require(len(stage['rows'])==len(result['candidates'])==len(rows),'Missing/extra reviewed candidate')
    grades=_paid(root,reference['api_root'],result,packet,pins);revealed=[]
    key=result['assessment']['receipt']['request_sha256']
    _require(stage['independent_request_key']==key and stage['independent_wire_sha256']==_digest(
        _read(root,dict(path=reference['api_root']+'/cache/'+key+'.json',
            sha256=result['verification']['artifact_sha256']['cache/'+key+'.json']),pins)['request'])
        and result['assessment']['receipt']['receipt'] in review['receipt_refs'],
        'Prepared v2 wire/receipt binding differs')
    for expected,prepared_row,reviewed in zip(rows,stage['rows'],result['candidates']):
        _require(all(prepared_row.get(k)==v and reviewed.get(k)==v for k,v in expected.items()),'Reading/candidate/rank/fill/source mapping changed')
        outside=sorted({s['canonical_page_id'] for s in expected['sources'] if s['canonical_page_id'] not in native['inspected_page_ids']})
        _require(prepared_row['saved_quote_pages_outside_initial_inspected_ids']==reviewed['saved_quote_pages_outside_initial_inspected_ids']==outside
            and prepared_row['verbatim_reference_match']==reviewed['verbatim_reference_match']==(expected['fill']==answer),
            'Prepared quote scope/reference comparison differs')
        grade=grades[expected['item_id']];_require(reviewed['grade']==grade,'Mapped candidate grade differs')
        revealed.append(dict(expected,grade=deepcopy(grade)))
    for path,pin in pins.items():
        _require(_sha(_path(root,path))==pin,'Verified input changed during replay: '+path)
    _require(_sha(Path(__file__))==_SELF_SHA,'Verifier changed during replay')
    binding['native_checkpoint_ref']=_pin(result['native_checkpoint'])
    return binding,pins,revealed,_digest(packet)


def _artifact(reference,binding,pins,items,packet_sha):
    value=dict(version=VERSION,verifier_sha256=_SELF_SHA,binding=binding,review_ref=deepcopy(reference),
        protocol=deepcopy(PROTOCOL),item_count=len(items),packet_sha256=packet_sha,
        verified_inputs_sha256=_digest(pins),verified_input_count=len(pins),used_for_inference=False,
        automatic_support_upgrade=False,native_outputs_modified=False)
    return dict(value,sha256=_digest(value))


def _metadata(projection):
    return dict(version=VERSION,available=True,verified=True,grades_revealed=False,binding=deepcopy(projection['binding']),
        item_count=projection['item_count'],review_sha256=projection['review_ref']['assessment_ref']['sha256'],
        protocol_version=PROTOCOL['version'],judgment_policy=PROTOCOL['judgment_policy'],
        native_claim_status_supplied=False,calibration_judgment='NOT_ASSESSED',
        source_scope='ALL_SAVED_TOP5_QUOTATIONS_NOT_FULL_NATIVE_POOL_RECERTIFICATION',
        provider_authenticity_certified=False,
        used_for_inference=False,automatic_support_upgrade=False,native_outputs_modified=False,
        notice='Separate post-run model opinions; not native assertions or benchmark accuracy.')


def build_verified_projection(root,native,explicit_review_ref):
    """Return an answer/grade-free detached manifest; caller owns publication."""
    try:
        root=Path(root).resolve();_require(_sha(Path(__file__))==_SELF_SHA,'Verifier changed after import')
        binding,pins,items,packet_sha=_verify(root,native,explicit_review_ref)
        return _artifact(explicit_review_ref,binding,pins,items,packet_sha)
    except (KeyError,TypeError,IndexError,AttributeError,OSError,sqlite3.Error) as error:
        raise ValueError('Malformed or mismatched explicit post-run review') from error


def _validated(root,projection,native):
    _sealed(projection)
    _require(projection['version']==VERSION and projection['verifier_sha256']==_SELF_SHA,'Unsupported projection/verifier version')
    binding,pins,items,packet_sha=_verify(root,native,projection['review_ref'])
    _require(projection==_artifact(projection['review_ref'],binding,pins,items,packet_sha),'Stale or modified review projection')
    return _metadata(projection),items


def validate_for_native(root,projection,native):
    """Replay a detached manifest against a full native; return safe metadata."""
    try:
        _require(_sha(Path(__file__))==_SELF_SHA,'Verifier changed after import')
        return _validated(Path(root).resolve(),projection,native)[0]
    except (KeyError,TypeError,IndexError,AttributeError,OSError,sqlite3.Error) as error:
        raise ValueError('Malformed or mismatched post-run projection') from error


def read_for_native(root,projection_ref,native,*,reveal=False):
    """Read only an explicit stored reference. Default output has no grade data."""
    try:
        _require(type(reveal) is bool,'Reveal must be an explicit boolean')
        _require(_sha(Path(__file__))==_SELF_SHA,'Verifier changed after import')
        root=Path(root).resolve();projection=_read(root,projection_ref,{})
        metadata,items=_validated(root,projection,native)
        _require(_sha(_path(root,projection_ref['path']))==projection_ref['sha256'],'Projection changed during replay')
        return dict(metadata,grades_revealed=True,items=deepcopy(items)) if reveal else metadata
    except (KeyError,TypeError,IndexError,AttributeError,OSError,sqlite3.Error) as error:
        raise ValueError('Malformed or mismatched post-run projection') from error
