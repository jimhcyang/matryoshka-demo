"""Source-bound, all-arm double-degree withholding; never edits a fill.

This supplements, rather than replaces, the frozen comparative property check.
It runs before rank/display selection, with the original source guards. Missing a duplicate
degree is not a grammar certificate, factual support or counterevidence.
"""
import re


VERSION = "current-source-bound-degree-check/1"


def _proof(token):
    return dict(text=token.text,start=token.idx,end=token.idx+len(token),pos=token.pos_,
        tag=token.tag_,degree=list(token.morph.get("Degree")),dependency=token.dep_,head_start=token.head.idx)


def _degree_targets(part):
    root = part.root
    return [root]+[t for t in root.children if t in part and t.dep_ == "advmod"]


def _inflected_degree(token):
    return token.tag_ in {"JJR","JJS","RBR","RBS"} or bool({"Cmp","Sup"} & set(token.morph.get("Degree")))


def _property(token):
    return token.pos_ == "ADJ" or token.tag_ in {"VBN","VBG"}


def _same_head_pairs(source, part, page, fill):
    raw = page["text"][source.start_char:source.end_char]
    if len(raw) != len(fill) or raw.casefold() != fill.casefold():
        return None
    pairs = []
    for token in _degree_targets(source):
        start = part.start_char+token.idx-source.start_char
        bound = part.doc.char_span(start,start+len(token),alignment_mode="strict")
        if bound is None or len(bound) != 1 or bound[0] not in part:
            return None
        other = bound[0]
        if token == source.root:
            if other != part.root:
                return None
        elif other.dep_ != "advmod" or other.head != part.root:
            return None
        pairs.append((token,other))
    source_offsets = {other.idx for _,other in pairs}
    if any(t.idx not in source_offsets for t in _degree_targets(part)):
        return None
    return pairs


def _scope_unresolved(part):
    targets = set(_degree_targets(part))
    return any((t.dep_ in {"neg","preconj"} or "Neg" in t.morph.get("Polarity"))
        and (t in targets or t.head in targets) for t in part)


def check(case, reading, proposal, context):
    """Use the unchanged Context's source replay and exact-span guards.

    The visible operator must directly govern the inserted property head, and
    that same literal source head must survive the completed parse. An envelope
    alone is not scope proof. Unresolved/negated scope and plural quantity
    ambiguity remain untouched, equally for every arm and operation form.
    """
    value = dict(version=VERSION,applies=False,omit=False,status="NOT_APPLICABLE",
        fill_rewritten=False,source_text_modified=False,factual_support_certified=False,
        absence_is_counterevidence=False,english_grammar_certified=False,
        arm_or_reading_semantics_used=False)
    left,right = case["query"].split(case["focal_marker"])
    match = re.search(r"\b(more|less)\s*$",left,re.I)
    if match is None:
        return value
    page = context.replay(proposal["sources"][0])
    context.phrase(proposal)
    source,normalization = context.grammar_phrase(proposal)
    filled = left+proposal["fill"]+right
    doc = context.parse(filled)
    part = doc.char_span(len(left),len(left)+len(proposal["fill"]),alignment_mode="strict")
    degree = doc.char_span(match.start(1),match.end(1),alignment_mode="strict")
    if part is None or degree is None:
        return dict(value,status="UNRESOLVED_EXACT_TOKEN_ALIGNMENT")
    operator = degree.root
    after = next((t for t in doc if t.idx >= part.end_char and not t.is_space),None)
    singular = after is not None and after.pos_ == "NOUN" and (after.tag_ == "NN" or "Sing" in after.morph.get("Number"))
    envelope = bool(re.search(r"\b(?:a|an)\s+(?:more|less)\s*$",left,re.I) and singular)
    same_property_head = operator.dep_ == "advmod" and operator.head == part.root and _property(part.root)
    metadata = dict(visible_degree=_proof(operator),property_envelope=envelope,
        source_head=_proof(source.root),query_head=_proof(part.root),source_analysis=normalization,
        external_degree_targets_property_head=same_property_head,
        source_page_id=page["id"],source_sha256=page["source_sha256"],
        source_span=list(proposal.get("fitted_source_span") or proposal["source_span"]))
    if not same_property_head:
        return dict(value,**metadata,status="UNRESOLVED_EXTERNAL_DEGREE_PROPERTY_HEAD_SCOPE")
    bound_predicate = (same_property_head
        and part.root.dep_ in {"acomp","attr","oprd","ROOT"}
        and not (after is not None and after.pos_ in {"NOUN","PROPN","PRON","NUM"}))
    if not (envelope or bound_predicate):
        return dict(value,**metadata,status="UNRESOLVED_OR_QUANTITY_AMBIGUOUS_DEGREE")
    if not _property(source.root):
        return dict(value,**metadata,status="UNRESOLVED_SOURCE_PROPERTY_HEAD")
    pairs = _same_head_pairs(source,part,page,proposal["fill"])
    if pairs is None:
        return dict(value,**metadata,status="UNRESOLVED_LITERAL_SAME_HEAD_MAP")
    if _scope_unresolved(source) or _scope_unresolved(part):
        return dict(value,**metadata,status="UNRESOLVED_NEGATED_OR_PRECOORDINATED_DEGREE_SCOPE")
    source_marked = [s for s,q in pairs if _inflected_degree(s)]
    query_marked = [q for s,q in pairs if _inflected_degree(q)]
    omit = bool(source_marked or query_marked)
    return dict(value,**metadata,applies=True,omit=omit,status="DUPLICATED_SCOPED_DEGREE_WITHHELD" if omit else
        "NO_SCOPED_DUPLICATED_DEGREE_FOUND_NOT_A_GENERAL_LICENSE",
        predicative_binding=bound_predicate,literal_source_property_head_map_verified=True,
        source_degree_witnesses=[_proof(t) for t in source_marked],query_degree_witnesses=[_proof(t) for t in query_marked],
        source_scope_modified_by_this_check=False,source_provenance_rechecked_by_unchanged_context=True)
