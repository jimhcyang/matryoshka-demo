"""Read the existing immutable public graph export, without network fallback."""
from bisect import bisect_right
from collections import OrderedDict
import gzip
import hashlib
import json
from pathlib import Path
import re


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class SavedMaps:
    def __init__(self, root, index_sha256, *, pdfs=None):
        self.root = Path(root).resolve()
        self.index_sha256 = index_sha256
        raw = self._bytes("site/data/api-index.json", index_sha256)
        self.entries = json.loads(raw)["entries"]
        self.chunks = OrderedDict()
        self.pdfs = pdfs

    def _bytes(self, name, expected):
        relative = Path(name)
        target = self.root / relative
        if (relative.is_absolute() or ".." in relative.parts or "\\" in name
                or target.resolve() != target or not target.is_file()):
            raise ValueError("Unsafe immutable public-map path")
        raw = target.read_bytes()
        if sha(raw) != expected:
            raise ValueError("Public graph export bytes changed")
        return raw

    def _chunk(self, directory, row):
        if not re.fullmatch(r"chunks/[a-f0-9]{64}\.json\.gz", row["path"]):
            raise ValueError("Unsafe graph fragment chunk")
        key = directory + "/" + row["path"], row["wire_sha256"]
        if key not in self.chunks:
            wire = self._bytes(*key)
            if len(wire) != row["wire_bytes"] or not 0 <= row["decoded_bytes"] <= 16*1024**2:
                raise ValueError("Graph fragment chunk exceeds its bound")
            raw = gzip.decompress(wire)
            if len(raw) != row["decoded_bytes"] or sha(raw) != row["sha256decoded"]:
                raise ValueError("Graph fragment decoded pin changed")
            value = json.loads(raw)
            if (value["version"] != "graph-fragment-dag-chunk/1" or value["first_id"] != row["first_id"]
                    or len(value["fragments"]) != row["last_id"]-row["first_id"]+1):
                raise ValueError("Malformed graph fragment chunk")
            self.chunks[key] = value["fragments"]
            if len(self.chunks) > 4:
                self.chunks.popitem(last=False)
        self.chunks.move_to_end(key)
        return self.chunks[key]

    @staticmethod
    def _template(pieces, parent=None):
        if not isinstance(pieces, list) or len(pieces) % 2 != 1:
            raise ValueError("Malformed graph fragment template")
        for i, part in enumerate(pieces):
            if i % 2:
                if type(part) is not int or part <= 0 or parent is not None and part >= parent:
                    raise ValueError("Invalid or forward graph fragment reference")
            elif not isinstance(part, str) or not part.isascii():
                raise ValueError("Graph fragment literal is not ASCII text")

    def _fragments(self, entry):
        raw = self._bytes("site/"+entry["path"], entry["manifest_sha256"])
        manifest = json.loads(raw)
        if manifest.get("version") != "graph-fragment-dag/1":
            raise ValueError("Unknown graph fragment contract")
        chunks = manifest["chunks"]
        for i, chunk in enumerate(chunks):
            if chunk["id"] != i or chunk["first_id"] != (chunks[i-1]["last_id"]+1 if i else 1):
                raise ValueError("Noncontiguous fragment catalog")
        starts = [c["first_id"] for c in chunks]
        root = manifest["assets"][entry["asset"]]
        if not 0 <= root["decoded_bytes"] <= 512*1024**2 or root["sha256decoded"] != entry["sha256"]:
            raise ValueError("Graph root byte bounds or decoded pin differ")
        allowed = set(root["dependencies"])
        self._template(root["pieces"])
        directory = "site/"+str(Path(entry["path"]).parent)
        output, length, stack = [], 0, [iter(root["pieces"])]
        operations = 0
        while stack:
            operations += 1
            if operations > 50000000 or len(stack) > 16384:
                raise ValueError("Graph fragment complexity exceeds safe decoder bounds")
            part = next(stack[-1], None)
            if part is None:
                stack.pop()
            elif isinstance(part, str):
                output.append(part)
                length += len(part)
                if length > root["decoded_bytes"]:
                    raise ValueError("Graph root exceeds declared byte bound")
            else:
                index = bisect_right(starts, part)-1
                if index not in allowed or part > chunks[index]["last_id"]:
                    raise ValueError("Undeclared graph fragment dependency")
                pieces = self._chunk(directory, chunks[index])[part-chunks[index]["first_id"]]
                self._template(pieces, part)
                stack.append(iter(pieces))
        raw = "".join(output).encode("ascii")
        if len(raw) != root["decoded_bytes"] or sha(raw) != entry["sha256"]:
            raise ValueError("Reconstructed graph root pin changed")
        return raw

    def packet(self, key):
        if not (key.startswith("/graph-assets-v4/") or key.startswith("/api/graph-v4-viewer?") or key.startswith("/api/cib-pdf?")):
            raise ValueError("Old workbench responses cannot substitute for current inference")
        if key.startswith("/api/cib-pdf?") and self.pdfs is not None:
            # Validate the resource even if the caller never requested metadata.
            self.packet("/api/graph-v4-viewer?corpus=cib")
            return self.pdfs.packet(key)
        entry = self.entries[key]
        if entry["encoding"] == "fragment-dag":
            return self._fragments(entry), entry["mime"]
        if entry.get("external_url"):
            match = re.fullmatch(r"https://raw\.githubusercontent\.com/jimhcyang/matryoshka-demo/[a-f0-9]{40}/datasets/(cib|iran|vietnam)/([a-f0-9]{64}\.json\.gz)", entry["external_url"])
            if not match or match[2] != entry["wire_sha256"]+".json.gz":
                raise ValueError("Graph dataset is not an approved immutable local export")
            wire = self._bytes("datasets/"+match[1]+"/"+match[2], entry["wire_sha256"])
        else:
            wire = self._bytes("site/"+entry["path"], entry["wire_sha256"])
        raw = gzip.decompress(wire) if entry["encoding"] == "gzip" else wire
        if sha(raw) != entry["sha256"]:
            raise ValueError("Public graph decoded bytes changed")
        if key == "/api/graph-v4-viewer?corpus=cib" and self.pdfs is not None:
            metadata = json.loads(raw)
            if metadata.get("source_resource",{}).get("id") != self.pdfs.resource_id:
                raise ValueError("Local originals belong to another graph resource")
            metadata.update(pdf_available=True,pdf_transport="explicit_byte_pinned_local_originals")
            raw = json.dumps(metadata,sort_keys=True).encode()
        return raw, entry["mime"]
