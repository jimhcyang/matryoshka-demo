"""Read-only, explicitly bound presentation of new current-resource decisions.

This is not an adapter that reseals historical runs. Its inputs are newly
executed current checkpoints and a complete, verified source index.
"""
from copy import deepcopy
import gzip
import hashlib
import json

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest, offline
from . import planning


VERSION = "current-evidence-decision/1"
BACKED = "evidence_backed_suggestion"
PARTIAL = "partial_grounding"
CONTEXT = "exploratory_contextual"
INCOMPATIBLE = "incompatible_not_viable"


def resource_binding(record, registry):
    case = public_case(record["case"])
    ref = record["index_ref"]
    selected = planning.validate_registry(registry, ref, case)
    if record["resource_binding"] != selected:
        raise ValueError("Native record belongs to a different source resource")
    return dict(resource_id=selected.get("resource_id") or selected["graph_id"],
        registry_sha256=registry["sha256"], index_sha256=ref["sha256"],
        corpus=case["corpus"], graph_id=selected["graph_id"],
        hierarchy_id=selected["hierarchy_id"], source_status=selected["status"])


def checkpoint(root, reference):
    path = planning.bound(root, reference["path"])
    if not reference["path"].startswith("experiments/current_refresh/execution/runs/"):
        raise ValueError("Only a new current-execution checkpoint may be displayed")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != reference["sha256"]:
        raise ValueError("Current checkpoint byte pin changed")
    value = json.loads(gzip.decompress(raw))
    if (value.get("version") != "current-native-condition/1"
            or value.get("sha256") != digest({k: v for k, v in value.items() if k != "sha256"})
            or value.get("native_checksum") != digest(value["result"])
            or value.get("old_native_resealed") is not False
            or value.get("old_ranks_or_grades_reused") is not False):
        raise ValueError("New execution/checksum contract does not replay")
    return value


def _check(identity, label, passed, detail):
    return dict(id=identity, label=label, state="pass" if passed else "missing", detail=detail)


def _evidence(rows):
    output = []
    for row in rows:
        refs = row.get("citations", [row["citation"]] if "citation" in row else [])
        if not refs and row.get("direction") in {"SUPPORT", "COUNTER", "PARTIAL"}:
            raise ValueError("Signed current evidence has no original quotation")
        output.extend(dict(deepcopy(row), citation=deepcopy(ref)) for ref in refs)
    return output


def _assertion_unit(atom, task):
    state = atom["status"]
    if state not in {"SUPPORT", "OPPOSED", "CONFLICTED", "PARTIAL", "UNRESOLVED", "ESTABLISHED", "INSUFFICIENT"}:
        raise ValueError("Unknown new assertion decision; no implicit support mapping")
    supported = state in {"SUPPORT", "ESTABLISHED"}
    counter = state in {"OPPOSED", "CONFLICTED"}
    status = BACKED if supported else INCOMPATIBLE if state == "OPPOSED" else PARTIAL if state in {"PARTIAL", "CONFLICTED"} else CONTEXT
    raw_evidence = _evidence(atom.get("evidence", atom.get("positive_evidence", []) + atom.get("counterevidence", [])))
    raw_requirements = atom.get("requirements", atom.get("query_requirements", []))
    requirements = []
    for requirement in raw_requirements:
        evidence = []
        for row in _evidence(requirement["evidence"]) if "evidence" in requirement else raw_evidence:
            if row["direction"] not in {"SUPPORT", "COUNTER", "PARTIAL"}:
                raise ValueError("Unknown signed source decision")
            evidence.append(dict(direction={"SUPPORT": "Support", "COUNTER": "Counterevidence", "PARTIAL": "Partial"}[row["direction"]],
                citations=[deepcopy(row["citation"])], checks=deepcopy(row.get("checks", {})),
                comparisons=deepcopy(row.get("comparisons", [])),
                evidence_semantics=row.get("evidence_semantics"),
                claim_binding_id=row.get("claim_binding_id"),
                actual_inner_event_established=row.get("actual_inner_event_established"),
                world_truth_certified=False))
        requirements.append(dict(id=requirement["id"], text=requirement["text"], predicate=requirement.get("predicate", requirement["text"]),
            kind=requirement["kind"], coverage="Established" if requirement.get("status", state) in {"SUPPORT", "ESTABLISHED"}
                else "Partial" if requirement.get("status", state) in {"PARTIAL", "CONFLICTED"} else "Missing",
            counterevidence=requirement.get("status", state) in {"OPPOSED", "CONFLICTED"}, evidence=evidence,
            context_citations=[], checks=[_check("whole_clause", "Complete required clause", requirement.get("coverage", {}).get("complete", False),
                "Main clause, participants and every attached operator must be retained.")],
            unresolved_checks=deepcopy(requirement.get("unresolved_checks", [])),
            operator_path=deepcopy(requirement.get("operator_path", [])),
            source_identification_only=requirement.get("source_identification_only", False),
            qualified_scope=requirement.get("qualified_scope"),
            claim_binding_id=requirement.get("claim_binding_id"),
            field_bindings=deepcopy(requirement.get("field_bindings", []))))
    evidence = deepcopy(raw_evidence)
    bound = bool(raw_requirements) and all(r.get("coverage", {}).get("complete", False) for r in raw_requirements)
    if task == "reconstruction":
        bound = bound or atom.get("complete_role_or_raw_clause_certificate") is True
    return dict(id=atom["id"], text=atom["text"], task=task, required=atom.get("required", True),
        status=status, native_current_status=state,
        coverage="Established" if supported else "Partial" if state in {"PARTIAL", "CONFLICTED"} else "Missing",
        counterevidence=counter, decisive_counter=state == "OPPOSED",
        support_present=state in {"SUPPORT", "ESTABLISHED", "CONFLICTED"}, requirements=requirements,
        source_pages_checked=sorted({r["citation"]["canonical_page_id"] for r in evidence if "citation" in r}),
        evidence=evidence, scope="COMPLETE_SCOPED_ASSERTION_NOT_BROADER_WORLD_TRUTH",
        qualified_accounts=deepcopy(atom.get("qualified_accounts", [])),
        actual_inner_event_established=atom.get("actual_inner_event_established"),
        checklist=[_check("provenance", "Eligible original quotations", bool(evidence),
            "Inspect the cited source spans and their dates; navigation does not certify this assertion."),
            _check("binding", "Complete assertion and scope", bound,
                "Every required clause, attribution, qualifier and event-time constraint must be retained."),
            _check("facts", "Sufficient evidence", supported,
                "The complete assertion is source-backed." if supported else "Opposing evidence exists." if counter else "The available evidence does not establish the complete assertion.")],
        what_would_suffice=[] if supported else ["An eligible source establishing this complete assertion with matching participants, event, time, uncertainty and attribution."],
        world_truth_certified=False)


def derive(record, registry, source_index):
    """Pure projection; source decisions cannot be supplied by model assessment."""
    from matryoshka_demo.source_view_policy import packet_policy, source_index_view
    source_index = source_index_view(source_index, packet_policy(record))
    case = public_case(record["case"])
    if record["native_checksum"] != digest(record["result"]):
        raise ValueError("Current native result changed before presentation")
    binding = resource_binding(record, registry)
    if case["task"] == "redaction":
        from matryoshka_demo_v6.reporting_fixed_pool_decisions_presentation_v3 import derive as redaction_gate
        with offline():
            gate = redaction_gate(deepcopy(record), case, source_index)
        gate["source_decision_engine"] = gate["version"]
    else:
        from matryoshka_demo_v6 import reporting_local_decisions_v65 as provenance
        index = provenance._pages(source_index, case)
        for atom in record["result"]["atoms"]:
            for row in _evidence(atom.get("evidence", atom.get("positive_evidence", []) + atom.get("counterevidence", []))):
                provenance._quote(row["citation"], *index, case)
        units = [_assertion_unit(a, case["task"]) for a in record["result"]["atoms"]]
        if [u["id"] for u in units] != [a["id"] for a in record["plan"]["atoms"]]:
            raise ValueError("Current verdict omits or adds a planned assertion")
        required = [u for u in units if u["required"]]
        if not required:
            raise ValueError("Cannot present an empty decision as sufficient")
        backed = [u["id"] for u in required if u["status"] == BACKED]
        opposed = [u["id"] for u in required if u["decisive_counter"]]
        conflicted = [u["id"] for u in required if u["native_current_status"] == "CONFLICTED"]
        partial = [u["id"] for u in required if u["native_current_status"] == "PARTIAL"]
        whole_query = record["result"].get("query_requirements", {}).get("complete", False)
        if case["task"] == "reconstruction":
            whole_query = whole_query or all(a.get("complete_role_or_raw_clause_certificate") is True for a in record["result"]["atoms"])
        complete = len(backed) == len(required) and whole_query
        overall = BACKED if complete else "mixed_evidence" if backed and opposed else INCOMPATIBLE if opposed else PARTIAL if backed or conflicted or partial else CONTEXT
        gate = dict(decisions=units, atoms={u["id"]: u for u in units}, candidates={}, reading_overviews={},
            overall=dict(status=overall, coverage="Established" if complete else "Partial" if backed or partial else "Missing",
                supported_components=backed, opposed_components=opposed, conflicted_components=conflicted, partial_components=partial,
                required_components=len(required),
                checklist=[_check("required_units", "All required assertions resolved", len(backed) + len(opposed) == len(required),
                    "Supported and opposed assertions are counted separately. Missing evidence is not opposition."),
                    _check("query_coverage", "Whole-query coverage", whole_query,
                    "Complete question coverage is checked separately from matching individual assertions.")]),
            source_scope="Exactly the newly recorded inspected source pool; retrospective names and hierarchy are navigation only.",
            limitations=["MIXED across assertions is not conflicting witnesses for a single assertion.",
                "A qualified reported statement does not establish its embedded event as world truth."])
    gate.update(version=VERSION, case_id=case["case_id"], task=case["task"], config=record["config"],
        query_sha256=digest(case["query"]), resource_binding=binding,
        derived=True, frozen_native_unchanged=True, keys_read=False, grades_read=False, model_calls=0,
        binding=dict(case_id=case["case_id"], query_sha256=digest(case["query"]), config=record["config"],
            native_run_id=record["run_id"], native_checksum=record["native_checksum"],
            resource_binding_sha256=digest(binding)))
    return gate


def condition(record, registry, gate, checkpoint_ref):
    binding = resource_binding(record, registry)
    if (gate.get("version") != VERSION or gate.get("resource_binding") != binding
            or gate.get("binding", {}).get("native_checksum") != record["native_checksum"]):
        raise ValueError("Displayed decision does not bind this current native result")
    value = deepcopy(record)
    value.update(current_resource_execution=True, resource_binding=binding,
        native_checkpoint=deepcopy(checkpoint_ref), local_decisions_v65=deepcopy(gate),
        local_decision_assessment_v65=dict(status="PENDING", used_for_inference=False,
            reason="No separate assessment of this exact new source/decision packet is attached."))
    return dict(case=deepcopy(record["case"]), resource_binding=binding,
        selected_arm=record["config"], configurations={record["config"]: value},
        presentation_pipeline_version=VERSION)
