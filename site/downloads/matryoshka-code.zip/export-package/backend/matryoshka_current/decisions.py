"""Current H appraisal and explicit R delegation; no world-truth oracle."""
from copy import deepcopy
from datetime import date,datetime
import re
from types import FunctionType

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import scope_matching as scoped
from matryoshka_demo_v6 import planning as literal
from matryoshka_demo_v6 import reporting_local_decisions_v65 as provenance
from . import planning

VERSION='current-source-decisions/2'
ATOM_STATES=('SUPPORT','OPPOSED','CONFLICTED','UNRESOLVED')


def construct_redaction(case,plan,retrieval,*,passage_budget=100,top_k=5):
    """New per-branch presentation with unchanged source/fit/counter gates."""
    from .arm_controls import matched_display
    from matryoshka_demo_v61 import candidates
    derived=planning.construction_plan(case,plan)
    control=derived['current_derivation']['controls']
    if plan['arm']=='llm_readings' and not control['saved_readings']:
        return dict(version=VERSION,task='redaction',status='MODEL_READING_ABSTENTION',readings=[],
            arm_controls=control,matched_display=[],inspected_page_ids=[],source_pages_inspected=0,
            passage_budget=passage_budget,api_calls=0,keys_read=False,grades_read=False)
    original=candidates._functions['construct']
    scope=dict(original.__globals__,__package__='matryoshka_current')
    local=FunctionType(original.__code__,scope,original.__name__,original.__defaults__,original.__closure__)
    local.__kwdefaults__=deepcopy(original.__kwdefaults__)
    with offline():
        result=local(case,derived,retrieval,passage_budget=passage_budget,top_k=top_k)
        result=candidates.filter_redaction(case,result,top_k=top_k,retrieval=retrieval,passage_budget=passage_budget)
    # No finalize_untyped collapse: five mechanical operations are branches,
    # not a claim that B predicted five grammatical hypotheses.
    result.update(current_construction_version=planning.CONSTRUCTION_VERSION,arm_controls=control,
        construction_plan_sha256=digest(derived),saved_query_plan_sha256=digest(plan),
        matched_display=matched_display(result['readings'],budget=5),
        per_branch_display_total=sum(len(r['candidates']) for r in result['readings']),
        global_diagnostic_display_budget=5,mechanical_branches_collapsed=False,
        old_ranks_reused=False)
    return result


def summarize(atoms):
    """Cross-atom MIXED is distinct from conflicting sources for one atom."""
    required=[a for a in atoms if a.get('required',True)]
    counts={state:sum(a['status']==state for a in required) for state in ATOM_STATES}
    if any(a['status'] not in ATOM_STATES for a in required):
        raise ValueError('Unknown current atom decision')
    n=len(required)
    if counts['SUPPORT'] and counts['OPPOSED']:status='MIXED'
    elif counts['CONFLICTED']:status='CONFLICTED'
    elif n and counts['SUPPORT']==n:status='SUPPORTED'
    elif n and counts['OPPOSED']==n:status='OPPOSED'
    elif counts['SUPPORT']:status='PARTIAL_SUPPORT'
    elif counts['OPPOSED']:status='PARTIAL_OPPOSITION'
    else:status='UNRESOLVED'
    return dict(status=status,required_atoms=n,counts=counts,
        fractions={key:dict(numerator=value,denominator=n,label=f'{value}/{n}') for key,value in counts.items()},
        supported_atom_ids=[a['id'] for a in required if a['status']=='SUPPORT'],
        opposed_atom_ids=[a['id'] for a in required if a['status']=='OPPOSED'],
        conflicted_atom_ids=[a['id'] for a in required if a['status']=='CONFLICTED'],
        unresolved_atom_ids=[a['id'] for a in required if a['status']=='UNRESOLVED'],
        cross_atom_mixed=bool(counts['SUPPORT'] and counts['OPPOSED']),
        within_atom_source_conflict=bool(counts['CONFLICTED']),
        counts_are_probabilities=False,world_truth_certified=False)


def _citation(page,start,end):
    return provenance._citation(page,start,end)


def _normalize(text):
    # No synonym, article, number, actor identity or punctuation rewriting.
    if any(len(c.casefold())!=1 for c in text):return None
    return ' '.join(text.casefold().split())


def _prefix_scope(text,start,engine):
    prefix=text[:start]
    if literal._open_reporting_context(prefix):return 'OPEN_SOURCE_REPORT_OR_QUOTATION'
    from matryoshka_demo_v6.reporting_fixed_pool_role_projection_v2 import NONFACTIVE
    for colon in re.finditer(':',prefix):
        at=colon.start()
        if at and at+1<len(prefix) and prefix[at-1].isdigit() and prefix[at+1].isdigit():continue
        before=re.split(r'[.!?]\s+|\n\s*\n',prefix[:at])[-1]
        if any(t.lemma_.casefold() in NONFACTIVE for t in engine.parse(before)):
            return 'UNRESOLVED_EXTERNAL_SOURCE_OPERATOR'
    return None


def _temporal_check(requirement,source_frames,case,engine):
    """Publication eligibility never establishes persistence at the query date."""
    target=requirement['frames']
    universal=bool(re.search(r'\b(?:never|ever|at any time)\b',requirement['text'],re.I))
    doc=engine.parse(requirement['text'])
    progressive=any(t.tag_=='VBG' and any(c.dep_ in {'aux','auxpass'} and c.lemma_.casefold()=='be'
        for c in t.children) for t in doc)
    state=any(f['kind'] in {'PROPERTY','NOMINAL_RELATION'} for f in target) or progressive
    explicit=any(f.get('event_dates') for f in target)
    unresolved=any(f.get('deictic_time') for f in target)
    if unresolved:return dict(state='UNRESOLVED',reason='QUERY_DEICTIC_TIME_NOT_BOUND_TO_EVENT_CLOCK')
    if state and not universal and not explicit:
        return dict(state='UNRESOLVED',reason='EARLIER_STATE_DOES_NOT_PROVE_CASE_DATE_STATE',case_date=case['date'])
    if any(f['qualifiers'].get('negated') for f in target) and not universal and not explicit:
        return dict(state='UNRESOLVED',reason='NONUNIVERSAL_NEGATIVE_CLAIM_TIME_NOT_BOUND',case_date=case['date'])
    return dict(state='PASS',reason='EXPLICIT_TIME_CHECKS_REMAIN_IN_MATCHER' if explicit else
        'UNBOUNDED_COUNTEREXAMPLE_SCOPE' if universal else 'UNDATED_EVENT_NOT_PERSISTENT_STATE',
        publication_date_used_as_event_date=False)


def _match(requirement,page,unit,case,index,engine):
    proof=_citation(page,unit['start'],unit['end'])
    provenance._quote(proof,*index,case)
    source_text=unit['text'];frames=engine.targets(source_text)
    blockers=[]
    outer=_prefix_scope(page['text'],unit['start'],engine)
    if outer:blockers.append(outer)
    source_plan=planning.literal_plan(dict(case,query=source_text),[dict(id='source',text=source_text,
        source_quote=source_text,start=0,end=len(source_text),required=True)])
    source_compile=planning.compile_requirements(dict(case,query=source_text),source_plan,engine=engine)
    if not source_compile['complete']:blockers.append('SOURCE_MAIN_CLAUSE_OR_CONTENT_NOT_COMPLETE')
    wanted_particles=[p['lemma'] for p in requirement['predicate_particles']]
    got_particles=[t.lemma_.casefold() for t in engine.parse(source_text) if t.dep_=='prt']
    if wanted_particles!=got_particles:blockers.append('PHRASAL_PREDICATE_PARTICLES_DIFFER')
    temporal=_temporal_check(requirement,frames,case,engine)
    if temporal['state']!='PASS' and case['task']=='hypothesis':blockers.append(temporal['reason'])
    normalized=_normalize(requirement['text'])
    exact=normalized is not None and normalized==_normalize(source_text)
    comparisons=[]
    for target in requirement['frames']:
        matches=[]
        for source in frames:
            value=scoped.compare_frames(target,source,engine=engine)
            if value is not None:matches.append(value)
        comparisons.append(matches)
    directions=[]
    for matches in comparisons:
        if any(m['direction']=='SUPPORT' for m in matches) and any(m['direction']=='COUNTER' for m in matches):directions.append('CONFLICTED')
        elif any(m['direction']=='SUPPORT' for m in matches):directions.append('SUPPORT')
        elif any(m['direction']=='COUNTER' for m in matches):directions.append('COUNTER')
        else:directions.append('UNRESOLVED')
    if blockers:direction='UNRESOLVED'
    elif 'CONFLICTED' in directions:direction='CONFLICTED'
    elif exact:direction='SUPPORT'
    elif requirement['kind']=='QUALIFIED_PROPOSITION':
        # This first implementation requires complete literal qualified content;
        # a retained leaf match may not silently erase an outer operator.
        direction='UNRESOLVED';blockers.append('NONLITERAL_QUALIFIED_CONTENT_OR_OPERATOR_NOT_CERTIFIED')
    elif directions and all(d=='SUPPORT' for d in directions):direction='SUPPORT'
    elif 'COUNTER' in directions and all(d in {'SUPPORT','COUNTER'} for d in directions):direction='COUNTER'
    else:direction='UNRESOLVED'
    if direction in {'COUNTER','CONFLICTED'} and not any(f.get('event_dates') for f in requirement['frames']) and not re.search(
            r'\b(?:never|ever|at any time)\b',requirement['text'],re.I):
        direction='UNRESOLVED';blockers.append('NONUNIVERSAL_OPPOSITION_EVENT_ALIGNMENT_NOT_ESTABLISHED')
    return dict(direction=direction,citation=proof,checks=dict(source_scope='PASS',
        query_main_clause=requirement['coverage'],source_main_clause=source_compile['complete'],
        operator_and_complete_content='PASS' if direction!='UNRESOLVED' else 'UNRESOLVED',
        exact_complete_source_unit=exact,temporal=temporal,blockers=blockers),
        comparisons=comparisons,source_identification_or_navigation_used_as_fact=False,
        qualification_preserved=requirement['kind']=='QUALIFIED_PROPOSITION',
        actual_inner_event_established=False if requirement['kind']=='QUALIFIED_PROPOSITION' else None,
        world_truth_certified=False)


def _h_requirements(case,plan,engine):
    from . import proposition_matching as pm
    planning.validate_plan(plan,case)
    try:planning.check_atoms(case,plan['atoms'])
    except ValueError:
        # Older valid planners may quote a context prefix for several atoms.
        # Appraise only uniquely located literal public clauses. A paraphrase
        # needing discourse resolution stays explicit, never silently rewritten.
        raw_plan=planning.literal_plan(case,[dict(id='raw',text=case['query'],source_quote=case['query'],
            start=0,end=len(case['query']),required=True)],arm=plan['arm'])
        raw=planning.compile_requirements(case,raw_plan,engine=engine)
        compiled=dict(raw,plan_sha256=digest(plan),raw_query_analysis_plan_sha256=digest(raw_plan),requirements=[])
        covered=set()
        for atom in plan['atoms']:
            spans=[m.span() for m in re.finditer(re.escape(atom['text']),case['query'])
                if atom['start']<=m.start() and m.end()<=atom['end']]
            selected=[]
            if len(spans)==1:
                a,b=spans[0]
                selected=[deepcopy(r) for r in raw['requirements'] if a<=r['start'] and r['end']<=b]
                for requirement in selected:covered.update(range(requirement['start'],requirement['end']))
            if not selected:
                selected=[dict(text=atom['text'],start=atom['start'],end=atom['end'],frames=[],
                    predicate_particles=[],operator_path=[],whole_content_required=True,
                    public_atom_binding_complete=False,source_context_quote=atom['source_quote'])]
            for i,requirement in enumerate(selected,1):
                requirement.update(id=atom['id']+'.q'+str(i),atom_id=atom['id'])
                compiled['requirements'].append(requirement)
        compiled['raw_query_complete']=all(i in covered or c.isspace() for i,c in enumerate(case['query']))
        compiled['context_quote_overlap_supported']=True
        compiled['planner_paraphrases_mechanically_resolved']=False
    else:
        compiled=planning.compile_requirements(case,plan,engine=engine)
    compiled['version']='current-complete-h-query-requirements/2'
    for requirement in compiled['requirements']:
        full=pm.compile_proposition(requirement['text'],engine=engine)
        requirement['legacy_frame_coverage']=deepcopy(requirement.get('coverage'))
        requirement['complete_proposition']=full
        binding=requirement.get('public_atom_binding_complete',True)
        requirement['coverage']=dict(complete=full['complete'] and binding,
            issues=full['issues']+([] if binding else ['NONLITERAL_PUBLIC_ATOM_SCOPE_NOT_MECHANICALLY_CERTIFIED']),
            unbound_tokens=full['unresolved_reference_proofs'])
        qualified=any(p['qualified_content'] or p['matrix_adverbs'] for p in full['propositions'])
        requirement['kind']='QUALIFIED_PROPOSITION' if qualified else 'SOURCE_PROPOSITION'
        requirement['actual_inner_event_required']=not qualified
    compiled['complete']=bool(compiled['requirements']) and compiled.get('raw_query_complete',True) and all(
        r['coverage']['complete'] for r in compiled['requirements'])
    return compiled


def _future_event_clock(proposition,case):
    for proof in proposition['event_dates']:
        if not proof['explicit_calendar_day_with_year']:continue
        literal=' '.join(proof['literal'].replace(',','').split())
        value=None
        for fmt in ('%Y-%m-%d','%B %d %Y','%d %B %Y'):
            try:value=datetime.strptime(literal,fmt).date();break
            except ValueError:pass
        if value is None:return 'INVALID_OR_UNRESOLVED_EXPLICIT_EVENT_DAY'
        if value>=date.fromisoformat(case['date']):return 'EVENT_DAY_NOT_STRICTLY_BEFORE_CASE_CUTOFF'
    return None


def _h_pair(pair,query,source,case):
    reasons=list(pair['reasons'])
    for proposition in (query,source):
        clock=_future_event_clock(proposition,case)
        if clock:reasons.append(clock)
    existential=False
    if reasons==['SAME_EXPLICIT_EVENT_DAY_NOT_ESTABLISHED']:
        # A complete affirmative simple-past event can be attested before the
        # cutoff without claiming the source/event is at the case date. This
        # exception never supplies a counterexample, ongoing state or tenure.
        existential=(not query['event_dates'] and query['kind']==source['kind']=='EVENT'
            and query['tense']==source['tense']=='past' and not query['negated'] and not source['negated']
            and not query['modality'] and not source['modality']
            and not re.search(r'\b(?:today|yesterday|tomorrow|now|currently|recently|soon|ago)\b|\b(?:last|next|this)\s+(?:day|week|month|year)\b',
                case['query'],re.I))
        if existential:reasons=[]
    direction=('COUNTER' if query['negated']!=source['negated'] else 'SUPPORT') if not reasons else 'UNRESOLVED'
    return dict(pair,direction=direction,reasons=reasons,
        temporal_policy='BOUNDED_PAST_EVENT_ATTESTATION_NOT_CASE_DATE_ALIGNMENT' if existential else 'EXPLICIT_EVENT_ALIGNMENT_REQUIRED',
        publication_date_used_as_event_date=False,case_date_state_or_tenure_established=False)


def _h_match(requirement,page,unit,case,index,engine):
    from . import proposition_matching as pm
    proof=_citation(page,unit['start'],unit['end']);provenance._quote(proof,*index,case)
    raw=pm.compare_propositions(requirement['text'],unit['text'],engine=engine)
    comparisons=[]
    for qi,row in enumerate(raw['comparisons']):
        comparisons.append([_h_pair(pair,raw['query']['propositions'][qi],raw['source']['propositions'][si],case)
            for si,pair in enumerate(row)])
    blockers=[]
    outer=_prefix_scope(page['text'],unit['start'],engine) or _prefix_scope(case['query'],requirement['start'],engine)
    if outer:blockers.append(outer)
    if not raw['query']['complete']:blockers.append('QUERY_COMPLETE_MAIN_PROPOSITION_UNRESOLVED')
    if not raw['source']['complete']:blockers.append('SOURCE_COMPLETE_MAIN_PROPOSITION_UNRESOLVED')
    support=bool(comparisons) and all(any(p['direction']=='SUPPORT' for p in row) for row in comparisons)
    counter=any(any(p['direction']=='COUNTER' for p in row) for row in comparisons)
    direction='UNRESOLVED' if blockers else 'CONFLICTED' if support and counter else 'SUPPORT' if support else 'COUNTER' if counter else 'UNRESOLVED'
    unresolved_reasons=sorted({r for row in comparisons for p in row for r in p['reasons']})
    state=any(p['kind']=='STATE' for p in raw['query']['propositions'])
    temporal_reason=('EARLIER_STATE_DOES_NOT_PROVE_CASE_DATE_STATE' if state
        and 'SAME_EXPLICIT_EVENT_DAY_NOT_ESTABLISHED' in unresolved_reasons else
        'COMPLETE_SIGNED_EVENT_ALIGNMENT_CHECKED' if direction!='UNRESOLVED' else 'EVENT_OR_COMPLETE_CONTENT_ALIGNMENT_UNRESOLVED')
    return dict(direction=direction,citation=proof,comparisons=comparisons,
        checks=dict(source_scope='PASS',query_main_clause=requirement['coverage'],
            source_main_clause=raw['source']['complete'],operator_and_complete_content='PASS' if direction!='UNRESOLVED' else 'UNRESOLVED',
            exact_complete_source_unit=_normalize(requirement['text'])==_normalize(unit['text']),
            temporal=dict(state='PASS' if direction!='UNRESOLVED' else 'UNRESOLVED',reason=temporal_reason,
                publication_date_used_as_event_date=False),blockers=blockers+unresolved_reasons),
        complete_proposition=dict(query=raw['query'],source=raw['source'],frozen_helper_direction=raw['direction'],
            current_direction=direction,temporal_policy_version=VERSION),
        source_identification_or_navigation_used_as_fact=False,
        qualification_preserved=requirement['kind']=='QUALIFIED_PROPOSITION',
        actual_inner_event_established=False,world_truth_certified=False)


def _execute_v2(case,plan,retrieval,*,source_index,passage_budget=100,engine=None,source_groups=None):
    case=public_case(case)
    if case['task']=='reconstruction':
        from .reconstruction import assemble
        args=dict(source_index=source_index)
        if source_groups is not None:args['source_groups']=source_groups
        return assemble(case,plan,retrieval,**args)
    if case['task']!='hypothesis':
        raise ValueError('Current typed decisions accept H/reconstruction, not redaction proposals')
    if type(passage_budget) is not int or passage_budget<1:
        raise ValueError('Positive inspected-source budget required')
    engine=engine or scoped.Engine()
    with offline():
        compiled=_h_requirements(case,plan,engine)
        index=provenance._pages(source_index,case)
        pages=index[0];corpus=retrieval['eligible'].corpus
        ids=[corpus.pages[pi]['id'] for pi in retrieval['pages'][:passage_budget]]
        if len(ids)!=len(set(ids)):raise ValueError('Duplicate inspected source identity')
        inspected={}
        for pid in ids:
            if pid not in pages:raise ValueError('Retrieved page absent from bound source index')
            page=pages[pid]
            original=corpus.pages[corpus.page_index[pid]]
            for field in ('text','document_id','date','source_sha256'):
                if original[field]!=page[field]:raise ValueError('Retrieval/source index page differs')
            provenance._quote(_citation(page,0,len(page['text'])),*index,case)
            inspected[pid]=page
        requirements=[]
        for wanted in compiled['requirements']:
            evidence=[]
            if wanted['coverage']['complete']:
                for page in inspected.values():
                    for unit in literal.sentences(page['text']):
                        evidence.append(_h_match(wanted,page,unit,case,index,engine))
            support=[dict(e,direction='SUPPORT') for e in evidence if e['direction'] in {'SUPPORT','CONFLICTED'}]
            opposed=[dict(e,direction='COUNTER') for e in evidence if e['direction'] in {'COUNTER','CONFLICTED'}]
            state='CONFLICTED' if support and opposed else 'SUPPORT' if support else 'OPPOSED' if opposed else 'UNRESOLVED'
            requirements.append(dict(id=wanted['id'],atom_id=wanted['atom_id'],status=state,
                text=wanted['text'],kind=wanted['kind'],coverage=wanted['coverage'],operator_path=wanted['operator_path'],
                evidence=support+opposed,unresolved_checks=[e for e in evidence if e['direction']=='UNRESOLVED'],
                source_identification_only=False,world_truth_certified=False))
        atoms=[]
        for atom in plan['atoms']:
            units=[r for r in requirements if r['atom_id']==atom['id']]
            states=[u['status'] for u in units]
            state='CONFLICTED' if 'CONFLICTED' in states else 'OPPOSED' if 'OPPOSED' in states else (
                'SUPPORT' if states and all(s=='SUPPORT' for s in states) else 'UNRESOLVED')
            evidence=[]
            for unit in units:
                for row in unit['evidence']:
                    evidence.append(dict(row,atom_requirement_id=unit['id']))
            atoms.append(dict(id=atom['id'],text=atom['text'],required=atom.get('required',True),
                status=state,requirements=units,evidence=evidence,
                actual_inner_event_established=False if any(u['kind']=='QUALIFIED_PROPOSITION' for u in units) else None))
    overall=summarize(atoms)
    return dict(version=VERSION,case_id=case['case_id'],task=case['task'],status=overall['status'],
        atoms=atoms,overall=overall,query_requirements=compiled,
        inspected_page_ids=ids,source_pages_inspected=len(ids),source_pages_admitted=len(retrieval['pages']),
        passage_budget=passage_budget,query_sha256=digest(case['query']),provided_plan_sha256=digest(plan),
        keys_read=False,grades_read=False,api_calls=0,world_truth_certified=False,
        kernel_mass_used_as_confidence=False,old_native_result_reused=False,
        limitations=['Qualified literal content is retained as qualified, not as an occurred inner event.',
            'Unknown main-clause, actor, discourse, lexical or time bindings remain unresolved.',
            'Source publication cutoff is not event-time alignment; temporal state persistence is not inferred.'])


def execute(case,plan,retrieval,*,source_index,passage_budget=100,engine=None,source_groups=None):
    if case['task']=='hypothesis':
        from .hypothesis_claims import execute as execute_h
        return execute_h(case,plan,retrieval,source_index=source_index,passage_budget=passage_budget,
            engine=engine,source_groups=source_groups)
    return _execute_v2(case,plan,retrieval,source_index=source_index,passage_budget=passage_budget,
        engine=engine,source_groups=source_groups)
