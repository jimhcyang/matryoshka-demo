"""Versioned source-document exposure, separate from frozen source admission.

Public entry points take the IARPA workspace root, not the src-demo-day root.
The policy pins are an approved minimum, not an ambient latest pointer. A new
evidence generation needs a new policy version; callers cannot select a weaker
policy by passing a resealed overlay. No keys, outcomes, grades or corpus text
are decoded here.
"""
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import date
import hashlib
import json
from pathlib import Path
import re


VERSION = "current-source-document-exposure/1"
PARTITIONS = frozenset({"development", "validation", "holdout"})
POLICY = {
    "version": "cib-source-document-exposure-policy/1",
    "base_ref": {
        "path": "matryoshka_redaction/data/canonical_redaction/jobs/cib_r6_top5_v1/public_population.json",
        "sha256": "fcc61a71022a3cae92e9635ec095bd14253d9d552cc0d2f3eb475363398c46ea",
    },
    "population_id": "cib_source_bbe696582fa98c27",
    "evidence": {
        "v64_inventory": {
            "path": "src-demo-day/experiments/curation_v64_cib/source_exposure_all332_v01.json",
            "sha256": "2abc6e0d969ef45988b0633936e497b38e8e1a0de894e318e95b34b3dc249169",
        },
        "v64_nominees": {
            "path": "src-demo-day/experiments/curation_v64_cib/nominees_v01.json",
            "sha256": "114f28070253c9e21c9751fab9cd0fe46c577691ac3e5ca0e43549bcee8ff9a7",
        },
        "v64_named_nominees": {
            "path": "src-demo-day/experiments/curation_v64_cib/nominees_names_v01.json",
            "sha256": "0d3ae8fbcaa1486573506511a658d824e7296a1b852383df6a5a525c21cc9b43",
        },
        "v65_parent": {
            "path": "src-demo-day/experiments/curation_v65_cib/source_exposure_v65.json",
            "sha256": "087c1f11324fe23ba0bd90ca92202406490ead2442f1d0f8db9e495d58c10360",
        },
        "v65_inspected": {
            "path": "src-demo-day/experiments/curation_v65_cib/source_exposure_v65_v02.json",
            "sha256": "72e5cc97a37a6245171d8852d706b4a3cd67ba001c8f0165f3de4885fd62efd0",
        },
    },
    "blanket_all332_flags_are_not_human_or_oracle_exposure": True,
    "evidence_scope": "EXPLICIT_V64_NOMINATIONS_AND_V65_INSPECTED_SOURCE_PACKS",
    "monotone_document_rule": "HOLDOUT_TO_DEVELOPMENT_ONLY_ALREADY_EXPOSED_BASE_LABELS_RETAINED",
    "untouched_reserved_certified": False,
}


class ExposureError(ValueError):
    """Missing, stale or inconsistent exposure preflight inputs."""


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _require(ok, message):
    if not ok:
        raise ExposureError(message)


def _path(root, relative):
    _require(isinstance(relative, str) and relative and "\\" not in relative,
        "An explicit workspace-relative path is required")
    _require(not Path(relative).is_absolute() and all(p not in {"", ".", ".."}
        for p in relative.split("/")), "Exposure path traversal rejected")
    path = root / relative
    _require(path.resolve(strict=True) == path and path.is_file(),
        "Symlink, redirected or missing exposure input")
    return path


def _ref(value):
    _require(isinstance(value, dict) and {"path", "sha256"} <= set(value)
        and not set(value) - {"path", "sha256", "bytes"}
        and isinstance(value["sha256"], str) and re.fullmatch("[a-f0-9]{64}", value["sha256"]),
        "An explicit byte-pinned reference is required")
    if "bytes" in value:
        _require(type(value["bytes"]) is int and value["bytes"] >= 0, "Invalid byte length")
    return {k:value[k] for k in ("path", "sha256")}


def _pairs(values):
    result = {}
    for key, value in values:
        _require(key not in result, "Duplicate JSON field")
        result[key] = value
    return result


def _loads(raw):
    def invalid(_):
        raise ExposureError("Nonfinite JSON value")
    return json.loads(raw, object_pairs_hook=_pairs, parse_constant=invalid)


def _read(root, reference, verified, *, text=False):
    ref = _ref(reference)
    raw = _path(root, ref["path"]).read_bytes()
    _require(hashlib.sha256(raw).hexdigest() == ref["sha256"]
        and ("bytes" not in reference or len(raw) == reference["bytes"]),
        "Pinned exposure/source bytes changed: " + ref["path"])
    _require(ref["path"] not in verified or verified[ref["path"]] == ref["sha256"],
        "Conflicting byte pins")
    verified[ref["path"]] = ref["sha256"]
    return raw.decode("utf-8") if text else _loads(raw)


def _source_ref(population_root, ref):
    return dict(_ref(ref), path=str(population_root / ref["path"]))


def _base(root, base_ref, verified):
    _require(_ref(base_ref) == POLICY["base_ref"], "Base population is outside the current exposure policy")
    base = _read(root, base_ref, verified)
    _require(base["population_id"] == POLICY["population_id"]
        and base["eligibility_used_recovery"] is False and base["private_records_decoded"] == 0,
        "Only the unchanged source-only base population is supported")
    source_root = Path(base_ref["path"]).parents[4]
    refs = {key:_source_ref(source_root, ref) for key, ref in base["source_refs"].items()}
    _require(set(refs) == {"metadata", "public", "quarantine", "release", "resources"},
        "Base source-reference schema changed")
    metadata = _read(root, refs["metadata"], verified)
    public = [_loads(line) for line in _read(root, refs["public"], verified, text=True).splitlines() if line.strip()]
    release = _read(root, refs["release"], verified)
    _read(root, refs["quarantine"], verified)
    resources = _read(root, refs["resources"], verified)
    _require(release["stage"] == "SOURCE_RELEASE_FROZEN"
        and release["source_selection_used_recovery_results"] is False
        and release["full_population_api_authorized"] is False
        and metadata["public_sha256"] == refs["public"]["sha256"], "Base source release differs")
    byid, documents = {}, {}
    for row in base["cases"]:
        _require(set(row) == {"case", "origin_partition", "payload_sha256"}, "Base row schema differs")
        case, partition = row["case"], row["origin_partition"]
        _require(set(case) == {"case_id", "date", "document_id", "focal_marker", "query"}
            and all(isinstance(v, str) and v for v in case.values()) and partition in PARTITIONS,
            "Invalid public case/partition")
        _require(date.fromisoformat(case["date"]).isoformat() == case["date"]
            and case["query"].count(case["focal_marker"]) == 1
            and row["payload_sha256"] == digest({k:case[k] for k in ("query", "focal_marker")}),
            "Public payload changed")
        _require(case["case_id"] not in byid, "Duplicate base case ID")
        byid[case["case_id"]] = row
        did = case["document_id"]
        _require(documents.setdefault(did, partition) == partition, "Base document crosses partitions")
    _require(len(byid) == base["targets"] == release["targets"] == metadata["case_count"]
        and len(documents) == base["documents"] == release["source_documents"]
        and digest(base["cases"]) == base["population_sha256"]
        and dict(Counter(row["origin_partition"] for row in base["cases"]))
            == base["partition_counts"] == release["origin_partitions"] == metadata["origin_partitions"],
        "Base membership, documents, digest or partition counts differ")
    meta_byid = {m["case_id"]:m for m in metadata["cases"]}
    public_byid = {p["case_id"]:p for p in public}
    _require(len(meta_byid) == len(metadata["cases"]) == len(public_byid) == len(public) == len(byid)
        and set(meta_byid) == set(public_byid) == set(byid), "Source membership differs")
    for cid, row in byid.items():
        case, meta, original = row["case"], meta_byid[cid], public_byid[cid]
        _require(meta["document_id"] == original["document_id"] == case["document_id"]
            and meta["document_date_iso"] == original["document_date_iso"] == case["date"]
            and meta["origin_partition"] == row["origin_partition"]
            and meta["query_sha256"] == hashlib.sha256(case["query"].encode()).hexdigest()
            and original["query"] == case["query"] and original["focal_marker"] == case["focal_marker"],
            "Source case/query/partition does not replay")
    dataset = {}
    for key in ("canonical_pages", "documents"):
        reference = _source_ref(source_root, resources["artifacts"][key])
        # Only hashes are needed; never decode revealed source text or keys.
        path = _path(root, reference["path"])
        with path.open("rb") as stream:
            actual = hashlib.file_digest(stream, "sha256").hexdigest()
        _require(actual == reference["sha256"], "Prepared dataset source hash changed")
        verified[reference["path"]] = actual
        dataset[key] = reference
    dataset["quarantine"] = _ref(refs["quarantine"])
    return base, byid, documents, refs, dataset


def _events(root, byid, verified):
    sources = POLICY["evidence"]
    values = {key:_read(root, ref, verified) for key, ref in sources.items()}
    inventory = values["v64_inventory"]
    _require(inventory["version"] == "v64-cib-all-scout-source-exposure/1"
        and inventory["source_curator_scope_only"] is True
        and inventory["upstream_benchmark_split_or_graph_modified"] is False,
        "Unexpected v64 exposure inventory")
    identities = {c["legacy_case_id"]:c["document_id"] for c in inventory["cases"]}
    _require(len(identities) == len(inventory["cases"]) == inventory["cases_count"] == len(byid)
        and identities == {cid:row["case"]["document_id"] for cid,row in byid.items()},
        "V64 inventory and base origins differ")
    events = []
    for key in ("v64_nominees", "v64_named_nominees"):
        nominations = values[key]
        _require(nominations["version"] == "source-aware-shortlist-spec/6.4.1"
            and nominations["exposure"] == "EXPOSED_SOURCE_AND_OUTCOME_INFORMED_CURATION_NOT_BLIND_EVALUATION",
            "Unrecognized v64 explicit nomination")
        seen = set()
        for nominee in nominations["cases"]:
            cid = nominee["legacy_case_id"]
            _require(cid in identities and cid not in seen, "Unknown or duplicate nominated origin case")
            seen.add(cid)
            events.append(dict(document_id=identities[cid], evidence_kind="EXPLICIT_ANSWER_AWARE_SOURCE_NOMINATION",
                evidence_id=cid, source_id=nominee["slug"], source_refs=[deepcopy(sources[key]), deepcopy(sources["v64_inventory"])]))
    parent, current = values["v65_parent"], values["v65_inspected"]
    curator_root = Path(sources["v65_inspected"]["path"]).parents[2]
    _require(parent["version"] == "v65-all-scouted-source-exposure/1"
        and current["version"] == "all-scouted-source-exposure/6.5.2"
        and _source_ref(curator_root, current["parent_exposure_ref"]) == sources["v65_parent"],
        "V65 exposure lineage differs")
    units = current["inspected_source_units"]
    seen = set()
    for unit in units:
        uid = unit["source_id"]
        _require(uid not in seen and isinstance(unit["document_id"], str) and unit["document_id"]
            and unit["source_material_seen_by_curation"] is True and unit["untouched_holdout"] is False,
            "Invalid explicit inspected-source exposure")
        seen.add(uid)
        if uid in byid:
            _require(unit["document_id"] == byid[uid]["case"]["document_id"], "Inspected case/origin mismatch")
        events.append(dict(document_id=unit["document_id"], evidence_kind="EXPLICIT_INSPECTED_REVEALED_SOURCE_PACK",
            evidence_id=uid, source_id=uid, source_refs=[deepcopy(sources["v65_inspected"]), deepcopy(sources["v65_parent"])]))
    current_units = {u["source_id"]:u for u in units}
    for old in parent["sources"]:
        _require(old["local_source_curation_exposed"] is True and old["source_material_sent_to_blue"] is True
            and old["untouched_holdout"] is False and old["source_id"] in current_units,
            "V65 parent exposure cannot disappear")
        new = current_units[old["source_id"]]
        _require(old["document_id"] == new["document_id"] and old["page_id"] == new["canonical_page_id"]
            and old["unit_index"] == new["unit_index"], "V65 parent source identity changed")
    return sorted(events, key=lambda e:(e["document_id"], e["evidence_kind"], e["evidence_id"]))


def _derive(root, base_ref):
    verified = {}
    base, byid, documents, source_refs, dataset = _base(root, base_ref, verified)
    events = _events(root, byid, verified)
    groups = defaultdict(list)
    for event in events:
        groups[event["document_id"]].append(event)
    rows = []
    for original in base["cases"]:
        case, old = original["case"], original["origin_partition"]
        evidence = groups.get(case["document_id"], [])
        effective = "development" if old == "holdout" and evidence else old
        reasons = (["WHOLE_ORIGIN_ANSWER_AWARE_DEVELOPMENT_EXPOSURE"] if effective != old else
            ["BASE_ALREADY_EXPOSED"] if old != "holdout" else ["NO_EXPOSURE_FOUND_IN_THIS_BOUNDED_LEDGER_NOT_A_CERTIFICATE"])
        refs = {digest(ref):ref for event in evidence for ref in event["source_refs"]}
        rows.append(dict(base_case_id=case["case_id"], document_id=case["document_id"],
            base_partition=old, effective_partition=effective,
            effective_exposure="development_exposed" if effective != "holdout" else "potentially_reserved_not_certified",
            reasons=reasons, source_refs=sorted(refs.values(), key=lambda ref:ref["path"]),
            source_event_ids=[digest(event) for event in evidence]))
    document_rows = []
    for did, old in sorted(documents.items()):
        members = [row for row in rows if row["document_id"] == did]
        document_rows.append(dict(document_id=did, base_partition=old,
            effective_partition=members[0]["effective_partition"], case_ids=[row["base_case_id"] for row in members],
            source_event_ids=[digest(event) for event in groups.get(did, [])]))
    changed = [row for row in rows if row["base_partition"] != row["effective_partition"]]
    counts = dict(Counter(row["effective_partition"] for row in rows))
    value = dict(version=VERSION, policy=deepcopy(POLICY), policy_sha256=digest(POLICY),
        base_population_ref=_ref(base_ref), base_population_id=base["population_id"],
        base_population_sha256=base["population_sha256"], base_source_refs=source_refs,
        dataset_source_refs=dataset, base_partition_counts=deepcopy(base["partition_counts"]),
        effective_partition_counts=counts, targets=base["targets"], documents=base["documents"],
        newly_exposed_targets=len(changed), newly_exposed_documents=len({r["document_id"] for r in changed}),
        potentially_reserved_targets=counts.get("holdout", 0), untouched_reserved_certified=False,
        source_membership_changed=False, source_admission_changed=False,
        graph_alias_or_hierarchy_binding_required=False,
        resource_scope="DATASET_SOURCE_HASHES_NOT_ALIAS_GRAPH_ID_EXPOSURE_SURVIVES_REBUILD",
        blanket_all332_flags_used=False, benchmark_answer_keys_read=False,
        answer_values_used_for_partitioning=False, outcomes_read=False, grades_read=False,
        source_events=events, out_of_population_event_ids=[digest(e) for e in events if e["document_id"] not in documents],
        cases=rows, origin_documents=document_rows,
        verified_inputs_sha256=verified)
    return dict(value, sha256=digest(value)), base


def _recheck(root, pins):
    for path, expected in pins.items():
        with _path(root, path).open("rb") as stream:
            _require(hashlib.file_digest(stream, "sha256").hexdigest() == expected,
                "Input changed during exposure validation: " + path)


def build_overlay(workspace_root, base_ref):
    """Derive the current minimum overlay without writing or loading any keys."""
    try:
        root = Path(workspace_root).resolve()
        overlay, _ = _derive(root, base_ref)
        _recheck(root, overlay["verified_inputs_sha256"])
        return overlay
    except (KeyError, TypeError, IndexError, OSError, json.JSONDecodeError) as error:
        raise ExposureError("Malformed or unavailable exposure evidence") from error


def load_population(workspace_root, base_ref, overlay_ref):
    """Fail-closed future benchmark entry: preserve questions, use effective split.

    A byte-pinned overlay is mandatory even when a caller only wants reserved
    cases. ``origin_partition`` in the returned rows is effective; the frozen
    label remains in ``base_origin_partition``. Remaining holdout is potential,
    never an assertion that no other development exposure has occurred.
    """
    try:
        root = Path(workspace_root).resolve()
        verified = {}
        overlay = _read(root, overlay_ref, verified)
        expected, base = _derive(root, base_ref)
        _require(overlay == expected, "Missing/stale overlay or nonmonotone/mismatched document exposure")
        _recheck(root, {**expected["verified_inputs_sha256"], **verified})
        result = deepcopy(base)
        for original, exposure in zip(result["cases"], overlay["cases"], strict=True):
            original.update(base_origin_partition=original["origin_partition"],
                origin_partition=exposure["effective_partition"],
                effective_origin_partition=exposure["effective_partition"],
                effective_exposure=exposure["effective_exposure"],
                exposure_reasons=deepcopy(exposure["reasons"]),
                exposure_source_refs=deepcopy(exposure["source_refs"]))
        result.update(base_partition_counts=deepcopy(base["partition_counts"]),
            partition_counts=deepcopy(overlay["effective_partition_counts"]),
            base_population_ref=_ref(base_ref), base_population_sha256=base["population_sha256"],
            population_sha256=digest(result["cases"]), exposure_overlay_ref=_ref(overlay_ref),
            exposure_overlay_sha256=overlay["sha256"], exposure_policy_sha256=digest(POLICY),
            potentially_reserved_targets=overlay["potentially_reserved_targets"],
            untouched_reserved_certified=False, source_membership_changed=False, source_admission_changed=False,
            newly_exposed_targets=overlay["newly_exposed_targets"], newly_exposed_documents=overlay["newly_exposed_documents"])
        return result
    except (KeyError, TypeError, IndexError, OSError, json.JSONDecodeError) as error:
        raise ExposureError("Malformed or unavailable required population exposure overlay") from error


def validate_dataset_scope(workspace_root, base_ref, overlay_ref, source_refs):
    """Check the prepared-source identity for a separately verified resource.

    Callers must still validate their native resource registry/index normally.
    Alias/graph IDs are intentionally not inputs: identical source bytes retain
    exposure across a rebuild. Changed prepared sources require a new migration
    review, not a silently reused split.
    """
    root = Path(workspace_root).resolve()
    population = load_population(root, base_ref, overlay_ref)
    pins = {}
    overlay = _read(root, overlay_ref, pins)
    expected = overlay["dataset_source_refs"]
    _require(isinstance(source_refs, dict) and set(source_refs) == set(expected),
        "Exact canonical pages/documents/quarantine source refs required")
    for key, ref in source_refs.items():
        clean = _ref(ref)
        _require(clean["sha256"] == expected[key]["sha256"], "Resource dataset differs from exposed source population")
        path = _path(root, clean["path"])
        with path.open("rb") as stream:
            _require(hashlib.file_digest(stream, "sha256").hexdigest() == clean["sha256"],
                "Current resource source bytes changed")
        pins[clean["path"]] = clean["sha256"]
    _recheck(root, pins)
    return dict(version=VERSION + "/dataset-scope", source_hashes_match=True,
        native_resource_authority_certified=False, source_admission_changed=False,
        exposure_overlay_ref=population["exposure_overlay_ref"], source_refs=deepcopy(source_refs),
        graph_alias_or_hierarchy_binding_required=False, untouched_reserved_certified=False)
