"""Strict, detached postrun origins for two exact new source6.4 releases only."""
from copy import deepcopy
import gzip
import hashlib
import json
from pathlib import Path
import re
from types import FunctionType

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest
from matryoshka_demo_v6 import server_origin_v63 as legacy
from matryoshka_demo_v6 import server_origin_v65 as paired
from matryoshka_demo_v6 import server_origin_reaudit_v65 as reaudit
from . import origin_display as frozen_h
from . import planning

VERSION = "current-bound-sealed-source-origin/1"
RELEASES = {
    "experiments/current_refresh/curation/releases/current_red_source_5e774faf44cbb5a3e502/release_manifest.json":
        "00f274fe02e81e63ff22b332aefcd2493897889b220f9897226c2a0285944af9",
    "experiments/current_refresh/curation/r_nominees_v01/releases/r_source_c1f576059130a5fae000/release_manifest.json":
        "89cf4b9309584cc6f124cc2ca6a2681d3724fc4485ee9525b1096caff65757b9",
}
SOURCE_AUDIT = dict(path="experiments/current_refresh/curation/source_quality_audit_v04/receipt.json",
                    sha256="bb789fecd5cc91155a76d11271a8400331e67f69a631f9751595d648033c5663")
H_SHA256 = "e487896a3f29d2b857e01c41b02e15db6033d6de51acd2d80a2e4d7bb91719c1"
PUBLIC = frozenset({"case_id", "corpus", "task", "document_id", "date", "query", "focal_marker"})


def require(value, message):
    if not value:
        raise ValueError(message)


def _path(root, ref):
    return frozen_h._path(root, ref)


def _read(root, ref):
    return frozen_h._read(root, ref)


def _completed(root, record):
    """Same completion/identity guards as frozen H1, separate R/Red task guard."""
    case = record.get("case")
    require(isinstance(case, dict) and set(case) == PUBLIC and public_case(case) == case
        and case["task"] in {"redaction", "reconstruction"}, "Exact seven-field R/Red case required")
    require(record.get("version") == "current-native-condition/1"
        and all(record.get(k) is False for k in ("keys_read", "grades_read", "old_native_resealed", "old_ranks_or_grades_reused")),
        "Only unchanged current postrun records may acquire origins")
    require(record.get("sha256") == digest({k:v for k,v in record.items() if k != "sha256"})
        and record.get("native_checksum") == digest(record["result"]), "Current record/result seal changed")
    plan, identity = record["plan"], record["identity"]
    require(plan["query_sha256"] == digest(case["query"]) and plan["task"] == case["task"]
        and plan["arm"] == record["config"] and identity["case"] == case and identity["config"] == record["config"]
        and identity["plan_sha256"] == digest(plan) and identity["code_sha256"] == digest(record["code"]),
        "Current case/query/plan identity differs")
    result = record["result"]
    if case["task"] == "redaction":
        require(result["task"] == "redaction" and result["planning_arm"] == record["config"]
            and result["saved_query_plan_sha256"] == digest(plan)
            and result["arm_controls"]["query_sha256"] == digest(case["query"])
            and result["task_execution_v6"]["focal_context"]["query_sha256"] == digest(case["query"]),
            "Red result belongs to another question/plan")
    else:
        require(result["query_sha256"] == digest(case["query"])
            and result["provided_plan_sha256"] == digest(plan), "R result belongs to another question/plan")
    require(record["run_id"] == "current_" + digest(identity)[:24], "Current run identity changed")
    for name in ("registry_ref", "index_ref", "plan_release_ref", "source_binding_sha256"):
        require(record[name] == identity[name], "Execution identity differs: " + name)
    prefix = "experiments/current_refresh/execution/runs/" + record["run_id"] + "/"
    completion_path = planning.bound(root, prefix + "completion.json.gz")
    completion = json.loads(gzip.decompress(completion_path.read_bytes()))
    require(completion.get("version") == "current-execution-completion/1"
        and completion.get("sha256") == digest({k:v for k,v in completion.items() if k != "sha256"})
        and completion["identity"] == identity and completion["run_id"] == record["run_id"]
        and completion["native_checksum"] == record["native_checksum"]
        and completion["task_status"] == record["result"].get("status"), "Completed commitment differs")
    checkpoint = completion["checkpoint"]
    require(checkpoint["path"] == prefix + case["case_id"] + "__" + record["config"] + ".json.gz",
        "Completion points outside the exact current condition")
    checkpoint_path = _path(root, checkpoint)
    encoded = (json.dumps(record, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    require(hashlib.sha256(encoded).hexdigest() == checkpoint["decoded_sha256"]
        and gzip.decompress(checkpoint_path.read_bytes()) == encoded, "Record is not the committed checkpoint")
    registry = _read(root, record["registry_ref"])
    resource = planning.validate_registry(registry, record["index_ref"], case)
    require(record["resource_binding"] == resource and record["source_binding_sha256"] == digest(resource)
        and identity["registry_sha256"] == registry["sha256"], "Current registry/resource differs")
    _path(root, record["index_ref"])
    release = _read(root, record["plan_release_ref"])
    require(release.get("version") == "current-planning-release/1"
        and release.get("sha256") == digest({k:v for k,v in release.items() if k != "sha256"})
        and release["case"] == case and release["case_sha256"] == digest(case) and release["plan"] == plan
        and release["plan_sha256"] == digest(plan) and release["registry_sha256"] == registry["sha256"]
        and release["index_ref"] == record["index_ref"] and release["source_binding_sha256"] == digest(resource),
        "Current saved planning release differs")
    return case, resource, checkpoint


def _sealed(root, case, ref):
    require(isinstance(ref, dict) and set(ref) == {"path", "sha256"}
        and RELEASES.get(ref.get("path")) == ref.get("sha256"), "Unsupported exact source6.4 release")
    manifest = _read(root, ref)
    require(manifest.get("version") == "source-curation-release/6.4", "Source manifest version differs")
    directory = Path(ref["path"]).parent
    artifacts = manifest["artifacts"]
    for name, expected in artifacts.items():
        require(isinstance(name, str) and not Path(name).is_absolute() and ".." not in Path(name).parts,
            "Source artifact escapes sealed directory")
        _path(root, dict(path=str(directory / name), sha256=expected))
    catalog_ref = dict(path=str(directory / "candidate_public_catalog.json"), sha256=artifacts["candidate_public_catalog.json"])
    proof_ref = dict(path=str(directory / "private/source_proofs.json"), sha256=artifacts["private/source_proofs.json"])
    require(manifest.get("public_catalog_sha256") == catalog_ref["sha256"]
        and manifest.get("source_proofs_sha256") == proof_ref["sha256"], "Manifest proof/catalog commitments disagree")
    catalog, proofs = _read(root, catalog_ref), _read(root, proof_ref)
    require([c for c in catalog["cases"] if c["case_id"] == case["case_id"]] == [case],
        "Exact public case/query is absent from sealed catalog")
    require(proofs.get("version") == "source-curation-proofs/6.4", "Source proof version differs")
    if "sha256" in proofs:
        require(proofs["sha256"] == digest({k:v for k,v in proofs.items() if k != "sha256"}), "Source proof self-seal differs")
    proof = deepcopy(proofs["cases"][case["case_id"]])
    if "sha256" in proof:
        require(proof["sha256"] == digest({k:v for k,v in proof.items() if k != "sha256"}), "Proof item self-seal differs")
    require(proof["source_origin_audit"].get("whole_origin_document_excluded") is True,
        "Whole origin exclusion proof required")
    return proof, proof_ref, catalog_ref


def _cable(root, case, proof, resource):
    source_audit = _read(root, SOURCE_AUDIT)
    require(source_audit["status"] == "PASS_NO_ADOPTED_RESOURCE_OR_SOURCE_PIN_DRIFT", "Pinned source-audit status differs")
    audited = {r["path"]:r["expected_sha256"] for r in source_audit["files"] if r["matches"]}
    files = resource["incumbent_binding"]["files"]
    refs = dict(binding=dict(path="data/bindings.json", sha256=audited[root.name + "/data/bindings.json"]),
        raw=dict(path=f"src/data/raw/{case['corpus']}/source_input.csv",
                 sha256=audited[f"src/data/raw/{case['corpus']}/source_input.csv"]),
        metadata=dict(path=reaudit.METADATA_PATH, sha256=audited[reaudit.METADATA_PATH]),
        canonical=files["pages"], projection=files["projection"], documents=files["documents"])
    audit = proof["source_origin_audit"]
    if "source_file_refs" in audit:
        require(audit["source_file_refs"] == refs, "Sealed full source-file pins differ")
    else:
        require(audit["raw_csv_ref"] == refs["raw"], "Sealed raw-file pin differs")
    require(audit["canonical_ref"] == refs["canonical"], "Sealed canonical source pin differs")
    bundle = reaudit.source_bundle(root, case["corpus"], refs)
    actual = reaudit.audit_case(case, proof, bundle)
    did = case["document_id"]
    require(audit["original_raw_documents"][did] == bundle["originals"][did]
        and [c for c in audit["document_checks"] if c["document_id"] == did] == actual["document_checks"]
        and audit["canonical_origin_rows"] == actual["canonical_origin_rows"]
        and len(set(audit["excluded_canonical_source_ids"])) == len(audit["excluded_canonical_source_ids"])
        and set(audit["excluded_canonical_source_ids"]) == set(actual["excluded_canonical_source_ids"]),
        "Original raw body, metadata or all-sibling source proof differs")
    require(not re.search(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM", bundle["originals"][did]["body"], re.I),
        "Whole original handling veto")
    return dict(source_category="SECRET_CABLE_RAW_BODY_VERIFIED", unit_verified=True,
        secret_derived=True, units=[], warning="", whole_original_source_replayed=True)


def _cib(root, case, proof, resource):
    require(case["task"] == "reconstruction", "Only the exact admitted CIB R release is supported")
    category = legacy._source_category(root, {}, case, proof, proof["origin"])
    require(category["source_category"] == "CIB_VERIFIED_REVEAL" and category["secret_derived"], "CIB reveal proof failed")
    paired._paired_transcript(root, case, proof)
    audit = proof["source_origin_audit"]
    documents_path = _path(root.parent, resource["files"]["documents"])
    documents = frozen_h._rows(documents_path, "document_id", case["document_id"])
    require(documents == [audit["origin_document_metadata"]]
        and documents[0]["document_date_iso"] == case["date"], "Original CIB document/date differs")
    raw_path = _path(root.parent, audit["raw_document_ref"])
    rows = frozen_h._rows(raw_path, "document_id", case["document_id"])
    require(len(rows) == 1, "Unique raw CIB original required")
    raw = rows[0]; pair = audit["paired_record"]
    require(raw["document_id"] == case["document_id"], "Raw CIB identity differs")
    originals = raw["raw_ocr"]
    for side, key in (("earlier", "redacted"), ("later", "unredacted")):
        page = audit[side + "_physical_pdf_page"]
        require(type(page) is int and 1 <= page <= len(originals[key])
            and pair[side + "_text"] == originals[key][page-1]
            and hashlib.sha256(pair[side + "_text"].encode()).hexdigest() == audit["raw_paired_" + side + "_page_sha256"],
            "Original paired physical page/hash differs")
    whole_earlier = "\n\n".join(originals["redacted"])
    require(whole_earlier == audit["whole_earlier_origin_text"]
        and hashlib.sha256(whole_earlier.encode()).hexdigest() == audit["whole_earlier_sha256"], "Whole earlier origin differs")
    segments, cursor = [], 0
    for number, text in enumerate(originals["unredacted"], 1):
        segments.append(dict(start=cursor, end=cursor+len(text), physical_pdf_page=number,
            text_sha256=digest(text), text_utf8_sha256=hashlib.sha256(text.encode()).hexdigest()))
        cursor += len(text)+2
    highlights, mappings = [], []
    page = audit["later_physical_pdf_page"]
    for birth in proof["origin_anchors"]:
        text = birth["text"]
        unit = audit["canonical_row"]["units"][birth["unit_index"]]
        require(unit["unit_type"] == "redaction_zone"
            and unit["later_text"][birth["unit_local_start"]:birth["unit_local_end"]] == text
            and " ".join(text.split()).casefold() not in " ".join(whole_earlier.split()).casefold()
            and pair["later_text"].count(text) == 1,
            "Complete birth is not an exact earlier-absent revealed claim")
        offset = pair["later_text"].index(text)
        start = segments[page-1]["start"] + offset
        highlights.append(dict(start=start, end=start+len(text), text=text, atom_id=birth.get("atom_id")))
        mappings.append(dict(canonical_page_id=proof["origin"]["source_id"],
            canonical_span=[birth["start"],birth["end"]], raw_later_physical_pdf_page=page,
            raw_page_span=[offset,offset+len(text)], full_original_span=[start,start+len(text)]))
    whole_later = "\n\n".join(originals["unredacted"])
    full = dict(text=whole_later, text_sha256=digest(whole_later), anchors=highlights, segments=segments,
        scope="ALL_ORIGINAL_LATER_OCR_PAGES_UNKNOWN_SPANS_PRESERVED", entirely_unredacted_or_fully_known=False)
    return category, full, mappings


def bind(root, record, source_manifest_ref, *, reveal_focal=False):
    """Attach a source6.4 origin only after exact completed R/Red execution."""
    root = Path(root).resolve()
    require(type(reveal_focal) is bool, "Explicit boolean focal reveal required")
    require(planning.byte_sha(Path(frozen_h.__file__)) == H_SHA256, "Frozen H origin helper changed")
    before = digest(record)
    case, resource, checkpoint = _completed(root, record)
    proof, proof_ref, catalog_ref = _sealed(root, case, source_manifest_ref)
    canonical_policy = frozen_h._canonical_binding(root, record, resource, proof["source_origin_audit"]["canonical_ref"])
    full, mappings = None, []
    if case["corpus"] == "cib":
        category, full, mappings = _cib(root, case, proof, resource)
    else:
        category = _cable(root, case, proof, resource)
    def resolver(local_root, row):
        require(Path(local_root).resolve() == root and row["case"] == case
            and row["source_manifest_ref"] == source_manifest_ref, "Isolated origin resolver binding differs")
        return deepcopy(proof), proof_ref["sha256"]
    def source_category(*args):
        return deepcopy(category)
    # Clone only this reader's global namespace; never mutate a legacy module.
    namespace = dict(legacy.origin.__globals__, _proof=resolver, _source_category=source_category)
    reader = FunctionType(legacy.origin.__code__, namespace, legacy.origin.__name__, legacy.origin.__defaults__, legacy.origin.__closure__)
    report = dict(cases=[dict(case=case, source_manifest_ref=source_manifest_ref)])
    dto = reader(root, report, case["case_id"], reveal_focal=reveal_focal)
    if full is not None:
        dto["full_transcription"] = full
        dto["exact_original_birth_mappings"] = mappings
    if case["task"] == "redaction" and not reveal_focal:
        dto["source_review"] = "Source proof verified postrun; focal source span remains masked."
    dto.update(binding_version=VERSION, binding_status="EXPLICIT_COMPLETED_CURRENT_NATIVE_POSTRUN_BOUND",
        case=deepcopy(case), case_sha256=digest(case), proof_record_sha256=digest(proof),
        source_manifest_ref=deepcopy(source_manifest_ref), source_catalog_ref=catalog_ref,
        source_proof_ref=proof_ref, postrun_only=True, detached=True, not_an_inference_input=True,
        source_display_only=True, inference_outputs_modified=False,
        execution_binding=dict(version=VERSION, native_checksum=record["native_checksum"],
            record_sha256=record["sha256"], plan_sha256=digest(record["plan"]),
            native_checkpoint_ref=deepcopy(checkpoint), registry_ref=deepcopy(record["registry_ref"]),
            index_ref=deepcopy(record["index_ref"]), plan_release_ref=deepcopy(record["plan_release_ref"]),
            run_id=record["run_id"], config=record["config"], case_sha256=digest(case),
            query_sha256=digest(case["query"]), canonical_source_binding_policy=canonical_policy,
            source_manifest_ref=deepcopy(source_manifest_ref), source_proof_ref=proof_ref,
            proof_record_sha256=digest(proof), postrun_only=True, used_for_inference=False))
    require(digest(record) == before and planning.byte_sha(Path(frozen_h.__file__)) == H_SHA256,
        "Native record or frozen H helper changed during origin display")
    return dto
