"""Query-only spaCy grammar adapter. No evidence, names, keys or model calls.

The existing offset-preserving compiler supplies conservative alternatives.
This adapter retains its boundaries/abstentions, while distinguishing syntactic
subject, patient and recipient roles that the old planner collapsed to unknown.
"""
from copy import deepcopy
import re

from matryoshka_demo import local_readings_v21 as baseline

VERSION = "current-local-spacy-readings/2"
BASE_VERSION = baseline.VERSION
_ROLES = {"nsubj":"actor_argument", "nsubjpass":"patient_argument", "nsubj:pass":"patient_argument",
    "dobj":"patient_argument", "obj":"patient_argument", "iobj":"recipient_argument",
    "dative":"recipient_argument", "pobj":"prepositional_argument"}


def _personal_possessor_cue(query, marker, language):
    at,end = query.index(marker),query.index(marker)+len(marker)
    intervals = [m.span() for m in baseline.MASK.finditer(query)]
    blank = baseline.MASK.sub(lambda m:" "*len(m.group()),query)
    doc,_ = baseline._parse(language,blank,intervals,uppercase=query.isupper())
    right = [t for t in doc if t.idx >= end and not t.is_space]
    if len(right) < 3:
        return None
    carrier,separator,pronoun = right[:3]
    if pronoun.lower_ in {"he","she"} and pronoun.pos_ != "PRON" and pronoun.text != pronoun.lower_:
        # Reparse only this closed-class subject's casing; retain raw quotes
        # and all other entity spelling so a competing name cannot disappear.
        normalized = blank[:pronoun.idx]+pronoun.lower_+blank[pronoun.idx+len(pronoun):]
        doc,_ = baseline._parse(language,normalized,intervals,uppercase=query.isupper())
        carrier,separator,pronoun = [t for t in doc if t.idx >= end and not t.is_space][:3]
    if (carrier.pos_ != "NOUN" or carrier.tag_ != "NN" or separator.text != ";"
            or pronoun.lower_ not in {"he","she"} or pronoun.pos_ != "PRON"
            or pronoun.dep_ not in {"nsubj","nsubjpass","nsubj:pass"}
            or pronoun.head.pos_ not in {"VERB","AUX"}
            or carrier.sent != pronoun.sent or query[end:carrier.idx].strip()
            or re.search(r"\r?\n[ \t\r]*\n",query[end:pronoun.idx])):
        return None
    finite = pronoun.head.tag_ in {"VBD","VBP","VBZ","MD"} or any(
        c.dep_ in {"aux","auxpass","cop"} and c.tag_ in {"VBD","VBP","VBZ","MD"} for c in pronoun.head.children)
    if not finite:
        return None
    predicate_subjects = [c for c in pronoun.head.children if c.dep_ in {"nsubj","nsubjpass","nsubj:pass"}]
    if len(predicate_subjects) != 1 or predicate_subjects[0] != pronoun:
        return None
    subjects = [t for t in carrier.sent if t.idx < at and t.dep_ in {"nsubj","nsubjpass","nsubj:pass"}]
    if len(subjects) != 1 or subjects[0].pos_ != "NOUN":
        return None
    subject = subjects[0]
    # An explicit active actor can itself be the pronoun's antecedent. This
    # conservative query-only rule never consults a dictionary of human nouns.
    if subject.dep_ not in {"nsubjpass","nsubj:pass"}:
        return None
    if any((a,b) != (at,end) and subject.idx <= a < pronoun.idx for a,b in intervals):
        return None
    paragraph_start = max([m.end() for m in re.finditer(r"\r?\n[ \t\r]*\n",query[:at])] or [0])
    host_chunk = next((c for c in doc.noun_chunks if c.root == subject),None)
    if host_chunk is None or any((a,b) != (at,end) and paragraph_start <= a < subject.idx
            and query[b:host_chunk.start_char].strip() for a,b in intervals):
        return None
    competing = [t for t in doc if paragraph_start <= t.idx < pronoun.idx]
    if any(t.pos_ in {"PROPN","PRON"} or t.ent_type_ in {"PERSON","ORG","GPE","LOC","FAC","NORP"} for t in competing):
        return None
    if any(c.root not in {subject,carrier} and c.root.pos_ in {"NOUN","PROPN","PRON"}
            and paragraph_start <= c.start_char and c.end_char <= pronoun.idx for c in doc.noun_chunks):
        return None
    if any(t.i != pronoun.i and (t.pos_ in {"PROPN","PRON"} or t.dep_ in {"conj","cc"}) for t in pronoun.subtree):
        return None
    return dict(carrier=query[carrier.idx:carrier.idx+len(carrier)],pronoun=query[pronoun.idx:pronoun.idx+len(pronoun)],
        start=pronoun.idx,end=pronoun.idx+len(pronoun))


def compile_readings(query, marker="[MASK]", *, nlp=None):
    """Return local reading rows only; unknown remains an explicit abstention."""
    language = baseline._model() if nlp is None else nlp
    rows = deepcopy(baseline.compile_readings(query, marker, nlp=language))
    at, end = query.index(marker), query.index(marker) + len(marker)
    if any(r["form"] == "nominal" and r["role"] in {"actor_argument","unknown"} for r in rows):
        intervals = [m.span() for m in baseline.MASK.finditer(query)]
        doc, _ = baseline._parse(language, baseline._shadow(query, intervals), intervals, uppercase=query.isupper())
        slot = next(t for t in doc if t.idx == at and t.text == "thing")
        for row in rows:
            if row["form"] == "nominal" and row["role"] in {"actor_argument","unknown"}:
                row["role"] = _ROLES.get(slot.dep_, "unknown")
    for row in rows:
        row.update(left_quote=query[:at],right_quote=query[end:])
        row.setdefault("grammatical_number",row.get("number","unknown"))
        row["notes"] = (f"{VERSION}; inherited={BASE_VERSION}; syntactic_role_only; "
            "no_external_facts_or_coreference; " + row["notes"])
    possessives = [r for r in rows if r["form"] == "possessive" and r["target_kind"] == "any"
        and r["grammatical_number"] in {"unknown","singular"}]
    cue = _personal_possessor_cue(query,marker,language) if possessives else None
    alternatives = []
    if cue:
        for row in possessives:
            if row["attachment_quote"] != cue["carrier"] or any(r["form"] == "possessive" and r["target_kind"] == "person"
                    and r["grammatical_number"] == "singular" and r["attachment_quote"] == row["attachment_quote"] for r in rows):
                continue
            identity = row["id"]+"_personal_v1"
            while any(r["id"] == identity for r in rows+alternatives):
                identity += "_"
            alternatives.append(dict(row,id=identity,target_kind="person",grammatical_number="singular",
                kind_cue_quote=cue["pronoun"],notes=row["notes"]+
                    f"; tentative_person_possessor_from_adjacent_subject; cue=[{cue['start']},{cue['end']}); "
                    "pronoun_referent_unresolved; coreference_not_established; ANY_alternative_retained; not_evidence_or_action_proof"))
    return alternatives+rows


def for_case(case, *, nlp=None):
    if case["task"] not in {"redaction", "hypothesis", "reconstruction"}:
        raise ValueError("Unknown task")
    return compile_readings(case["query"],case["focal_marker"],nlp=nlp) if case["task"] == "redaction" else []
