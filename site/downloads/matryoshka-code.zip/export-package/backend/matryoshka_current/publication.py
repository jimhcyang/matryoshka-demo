"""Explicit new-release artifacts, with no ambient latest or old-run relabeling."""
from copy import deepcopy
import gzip
import hashlib
import json
import os
from pathlib import Path
import tempfile

from matryoshka_demo.io import digest
from . import planning, reporting


VERSION = "current-workbench-publication/1"
PREFIX = "experiments/current_refresh/publication/"
ORIGIN_BINDING_VERSIONS = frozenset({
    "current-bound-origin-display/1", "current-bound-sealed-source-origin/1",
})


def origin_entries(origins):
    """Yield arm, display state and exact ref; never substitute another arm."""
    if not isinstance(origins, dict):
        raise ValueError("Original-source references must be explicit")
    groups = origins.get("by_arm", {None:origins})
    if "by_arm" in origins and (set(origins) != {"by_arm"} or not isinstance(groups, dict)
            or set(groups)-{"llm_readings", "llm_atoms", "llm_local"}):
        raise ValueError("Unknown or mixed original-source arm references")
    rows = []
    for arm, states in groups.items():
        if not isinstance(states, dict) or set(states)-{"masked", "revealed"}:
            raise ValueError("Unknown original-source display state")
        rows.extend((arm, state, ref) for state, ref in states.items())
    return rows


def origins_for(origins, arm):
    return {state:ref for owner,state,ref in origin_entries(origins) if owner is None or owner == arm}


def origin_binding_matches(value, native, arm, checkpoint):
    if "execution_binding" not in value:
        return True
    binding = value["execution_binding"]
    expected = dict(config=arm, native_checksum=native["native_checksum"],
        record_sha256=native["sha256"], registry_ref=native["registry_ref"], index_ref=native["index_ref"],
        case_sha256=digest(native["case"]), query_sha256=digest(native["case"]["query"]),
        postrun_only=True, used_for_inference=False)
    return (isinstance(binding, dict) and binding.get("version") in ORIGIN_BINDING_VERSIONS
        and binding.get("postrun_only") is True and binding.get("used_for_inference") is False
        and all(binding.get(k) == v for k,v in expected.items())
        and isinstance(binding.get("native_checkpoint_ref"), dict)
        and all(binding["native_checkpoint_ref"].get(k) == checkpoint[k] for k in ("path", "sha256")))


def producer_code():
    package = Path(__file__).parent
    return {"matryoshka_current/"+name: planning.byte_sha(package/name)
        for name in ("publication.py", "reporting.py", "visualization.py", "arm_controls.py")}


def write(root, relative, value):
    if not relative.startswith(PREFIX):
        raise ValueError("Current presentation artifacts require their own namespace")
    target = planning.bound(root, relative)
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    wire = gzip.compress(raw, compresslevel=1, mtime=0) if relative.endswith(".gz") else raw
    if target.exists():
        if target.read_bytes() != wire:
            raise ValueError("Existing current publication artifact differs")
    else:
        descriptor, name = tempfile.mkstemp(prefix=".current-publish-", dir=target.parent)
        temporary = Path(name)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(wire)
                stream.flush()
                os.fsync(stream.fileno())
            try:
                os.link(temporary, target)
            except FileExistsError:
                if target.read_bytes() != wire:
                    raise ValueError("Another writer published different immutable bytes")
        finally:
            temporary.unlink(missing_ok=True)
    return dict(path=relative, sha256=hashlib.sha256(wire).hexdigest())


def read(root, reference):
    target = planning.bound(root, reference["path"])
    wire = target.read_bytes()
    if hashlib.sha256(wire).hexdigest() != reference["sha256"]:
        raise ValueError("Current publication reference changed")
    return json.loads(gzip.decompress(wire) if reference["path"].endswith(".gz") else wire)


def check_construction_operations(record):
    """Replay declared operations, not a new local or model interpretation."""
    if record["case"]["task"] != "redaction":
        return
    from .arm_controls import controls_for
    if record["config"] != record["plan"]["arm"]:
        raise ValueError("Saved construction arm differs from the declared query plan")
    expected = controls_for(record["case"], record["plan"])
    saved = record["result"].get("arm_controls")
    if not isinstance(saved, dict) or any(saved.get(k) != v for k, v in expected.items()):
        raise ValueError("Saved construction controls differ from their declared query plan")
    if saved.get("saved_query_plan_sha256") != digest(record["plan"]):
        raise ValueError("Saved construction controls have another query plan")
    executed = [row["reading"] for row in record["result"]["readings"]]
    if executed != expected["construction_operations"]:
        raise ValueError("Saved and executed construction operations differ; preserve this diagnostic, do not publish it as a clean arm")


def publish_condition(root, record_ref, context, *, flows=True):
    code = producer_code()
    record = reporting.checkpoint(root, record_ref)
    check_construction_operations(record)
    if record["registry_ref"] != context.registry_ref or record["index_ref"] != context.index_ref:
        raise ValueError("Publication context belongs to another native source release")
    name = PREFIX + record["run_id"] + "/view_" + digest(code)[:16] + "/" + record["case"]["case_id"] + "__" + record["config"]
    existing = planning.bound(root, name + "__condition.json.gz")
    if existing.is_file():
        reference = dict(path=name+"__condition.json.gz", sha256=planning.byte_sha(existing))
        detail = read(root, reference)
        saved = detail["configurations"][record["config"]]
        if (detail["publication_code"] != code or saved["native_checkpoint"] != record_ref
                or saved["native_checksum"] != record["native_checksum"]
                or detail["resource_binding"] != reporting.resource_binding(record, context.registry)
                or flows and not detail["flow_refs"]):
            raise ValueError("Existing current view has another producer/native/resource binding")
        for flow_ref in detail["flow_refs"].values():
            flow = read(root, flow_ref)
            if flow["source_case_sha256"] != record["sha256"] or flow["resource_binding"] != detail["resource_binding"]:
                raise ValueError("Saved flow does not bind this current run")
        return _summary(record, record_ref, detail, reference, code)
    gate = reporting.derive(record, context.registry, context.source_index)
    detail = reporting.condition(record, context.registry, gate, record_ref)
    saved = detail["configurations"][record["config"]]
    # Native bytes remain under record_ref. The display DTO omits the huge
    # full kernel, rather than pretending this smaller DTO has its native seal.
    saved["native_record_sha256"] = saved.pop("sha256")
    audit = saved["result"].pop("_candidate_audit", None)
    if audit is not None:
        saved["candidate_audit_available_in_native_checkpoint"] = True
        saved["candidate_audit_sha256"] = digest(audit)
    saved["result"]["flow"] = {k: v for k, v in saved["result"]["flow"].items()
        if k not in {"expanded", "frames", "candidate_flows"}}
    saved["display_projection_only"] = True
    flow_refs = {}
    compact_refs = {}
    if flows:
        from .visualization import project, compact
        readings = [r["reading"]["id"] for r in record["result"].get("readings", [])] or [""]
        for reading in readings:
            value = project(record, context, reading=reading or None, limit=2048)
            flow_refs[reading] = write(root, name + "__flow_" + (reading or "assertions") + ".json.gz", value)
            compact_refs[reading] = write(root, name + "__compact_" + (reading or "assertions") + ".json.gz", compact(value))
    detail["flow_refs"] = flow_refs
    detail["compact_flow_refs"] = compact_refs
    if producer_code() != code:
        raise ValueError("Publication code changed while deriving this current presentation")
    detail["publication_code"] = code
    reference = write(root, name + "__condition.json.gz", detail)
    return _summary(record, record_ref, detail, reference, code)


def _summary(record, record_ref, detail, reference, code):
    gate = detail["configurations"][record["config"]]["local_decisions_v65"]
    return dict(case=deepcopy(record["case"]), config=record["config"], resource_binding=detail["resource_binding"],
        native_checkpoint=deepcopy(record_ref), condition_ref=reference, flow_refs=detail["flow_refs"], compact_flow_refs=detail.get("compact_flow_refs", {}),
        result=dict(status=record["result"].get("status")), local_decision_status=gate.get("overall", {}).get("status"),
        gate_sha256=digest(gate), run_id=record["run_id"], publication_code=code)


def create_report(root, conditions, *, titles=None, starter_ids=(), origin_refs=None, display_metadata=None):
    if not conditions:
        raise ValueError("Cannot publish an empty current casebook")
    titles, origin_refs, display_metadata = titles or {}, origin_refs or {}, display_metadata or {}
    by_case = {}
    for item in conditions:
        case = item["case"]
        detail = read(root, item["condition_ref"])
        if detail["case"] != case or detail["resource_binding"] != item["resource_binding"]:
            raise ValueError("Current condition summary differs from its saved DTO")
        row = by_case.setdefault(case["case_id"], dict(case=deepcopy(case), configurations={},
            resource_binding=deepcopy(item["resource_binding"]), presentation_title=titles.get(case["case_id"], case["query"]),
            selected_demo=case["case_id"] in starter_ids, selected_bench=case["case_id"] not in starter_ids,
            current_resource_execution=True))
        if row["case"] != case or row["resource_binding"] != item["resource_binding"] or item["config"] in row["configurations"]:
            raise ValueError("Mixed query/resource or duplicate current condition")
        row["configurations"][item["config"]] = deepcopy({k: v for k, v in item.items() if k != "case"})
        if case["case_id"] in origin_refs:
            row["origin_refs"] = deepcopy(origin_refs[case["case_id"]])
        metadata = display_metadata.get(case["case_id"], {})
        allowed = {"reference_answer", "reference_answer_kind", "source_admission", "source_catalog_ref", "source_manifest_ref", "post_run_origin_reuse"}
        if set(metadata)-allowed:
            raise ValueError("Review outcomes/ranking cannot enter source display metadata")
        row.update(deepcopy(metadata))
    report = dict(version=VERSION,
        status="PARTIAL", cases=list(by_case.values()), completed_cases=len(by_case), pending_cases=0,
        presentation_version="CURRENT_EXPLICIT_RESOURCE", full_benchmark_launched=False,
        outcome_informed_demo=True, benchmark_accuracy=False, native_outputs_modified=False,
        local_execution_after_planning=True, no_live_api=True)
    # Presentation metadata and original-source bindings are part of identity,
    # not merely the underlying native conditions.
    report["run_id"] = "current_publication_" + digest(report)[:24]
    report["sha256"] = digest(report)
    ref = write(root, PREFIX + report["run_id"] + "/report.json", report)
    return dict(report_ref=ref, case_count=len(by_case), condition_count=len(conditions), api_calls=0)
