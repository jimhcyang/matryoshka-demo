"""Explicit query-only plans and releases for current-resource execution."""
from copy import deepcopy
from datetime import date
import hashlib
import json
import re
from pathlib import Path, PurePosixPath

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest


VERSION = 'current-query-plan/1'
RELEASE_VERSION = 'current-planning-release/1'
CONSTRUCTION_VERSION='current-source-construction-plan/1'
LOCAL_PLAN_VERSION='current-local-query-plan/2'
LOCAL_DERIVATION_VERSION='current-local-planning-derivation/2'
LOCAL_COMPILER_FILES=('matryoshka_current/local_readings.py','matryoshka_demo/local_readings_v21.py')
PRIVATE_FIELDS = frozenset({'answer', 'reference_answer', 'reference_answers', 'answer_keys',
    'evaluation_keys', 'evaluation_keys_ref', 'grades', 'grade', 'assessments', 'llm_assessment',
    'local_decisions_v65', 'local_decisions_presentation', 'native_checkpoint', 'native_result',
    'candidate_ranks', 'retrieved_pages'})


def bound(root, name):
    if not isinstance(name, str) or '\\' in name:
        raise ValueError('Canonical relative current-resource path required')
    parts = name.split('/')
    if any(p in {'', '.', '..'} for p in parts) or PurePosixPath(name).is_absolute():
        raise ValueError('Current-resource path escapes explicit root')
    path = Path(root).resolve()/name
    if path.resolve() != path or path.is_symlink():
        raise ValueError('Symlinked current-resource path')
    return path


def byte_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_ref(root, ref):
    if not isinstance(ref, dict) or not isinstance(ref.get('sha256'), str):
        raise ValueError('Explicit byte-pinned reference required')
    path = bound(root, ref['path']); raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != ref['sha256']:
        raise ValueError('Current-resource reference bytes changed')
    return json.loads(raw)


def no_private(value):
    if isinstance(value, dict):
        if PRIVATE_FIELDS.intersection(value):
            raise ValueError('Answer/review/saved-result input is not a query-only plan')
        for item in value.values():
            no_private(item)
    elif isinstance(value, list):
        for item in value:
            no_private(item)


def validate_registry(registry, index_ref, case):
    case = public_case(case)
    if (registry.get('version')!='matryoshka-current-execution-registry/1'
            or registry.get('sha256') != digest({k:v for k,v in registry.items() if k!='sha256'})):
        raise ValueError('Current registry content hash changed')
    corpus = registry['corpora'].get(case['corpus'])
    if not isinstance(corpus, dict) or corpus.get('corpus') != case['corpus']:
        raise ValueError('Case corpus is outside the explicit current registry')
    if corpus.get('status') not in {'CURRENT_NATIVE_RESOURCE_EXPLICIT','INCUMBENT_NOT_MIGRATED'}:
        raise ValueError('Unknown current execution resource status')
    if (index_ref.get('registry_sha256') != registry['sha256']
            or index_ref.get('corpus') != case['corpus']
            or index_ref.get('source_binding_sha256') != digest(corpus)):
        raise ValueError('Current registry/index/corpus pair differs')
    return corpus


def validate_plan(plan, case):
    case = public_case(case); no_private(plan)
    if plan.get('version')==LOCAL_PLAN_VERSION:
        return _validate_local_plan(plan,case)
    if plan.get('version')==CONSTRUCTION_VERSION:
        parent=plan.get('current_derivation',{}).get('source_plan')
        if not isinstance(parent,dict) or parent.get('version')==CONSTRUCTION_VERSION:
            raise ValueError('Construction requires an original query-only source plan')
        if plan!=construction_plan(case,parent):
            raise ValueError('Derived construction operations differ from their public query compiler')
        return plan
    if plan.get('version') != VERSION:
        # Existing planners are query-only. Reuse their validation, not their
        # retrieval registry, source answers, run IDs or planning provider.
        from matryoshka_demo_v61.planning import validate_plan as old_validate
        old_validate(plan, case)
        return plan
    if (set(plan) != {'version','arm','task','query_sha256','atoms','leads','keys_read','grades_read','extractions','slot_readings'}
            or plan.get('task') != case['task'] or plan.get('query_sha256') != digest(case['query'])
            or plan.get('keys_read') is not False or plan.get('grades_read') is not False
            or plan.get('arm') not in {'llm_readings','llm_atoms','llm_local'}):
        raise ValueError('Invalid current query-only planning binding')
    if plan['leads']:
        raise ValueError('Current literal-plan constructor does not invent search questions')
    if plan['slot_readings'] or plan['extractions'] != {key:[] for key in ('entities','events','claims','relations')}:
        raise ValueError('Literal current-plan controls cannot invent extraction or reading annotations')
    check_atoms(case, plan['atoms'])
    return plan


def check_atoms(case, atoms):
    if not isinstance(atoms, list) or not atoms:
        raise ValueError('Complete literal public atoms required')
    if len({a['id'] for a in atoms}) != len(atoms):
        raise ValueError('Duplicate query atom identity')
    end = 0
    for atom in sorted(atoms, key=lambda a:a['start']):
        a,b = atom['start'],atom['end']
        if (type(a) is not int or type(b) is not int or not end <= a < b <= len(case['query'])
                or case['query'][end:a].strip() or atom.get('required') is not True
                or atom.get('text') != case['query'][a:b] or atom.get('source_quote') != atom['text']):
            raise ValueError('Lost, overlapping, optional or paraphrased query coverage')
        end=b
    if case['query'][end:].strip():
        raise ValueError('Unconsumed public query content')


def literal_plan(case, atoms, *, arm='llm_atoms'):
    """Explicit source-span control; not a new provider or answer-derived planner."""
    case=public_case(case); check_atoms(case,atoms)
    plan=dict(version=VERSION, arm=arm, task=case['task'], query_sha256=digest(case['query']),
        atoms=deepcopy(atoms), leads=[], keys_read=False, grades_read=False,
        extractions={key:[] for key in ('entities','events','claims','relations')},slot_readings=[])
    return validate_plan(plan,case)


def bind_saved_plan(case, plan, registry, index_ref, parent=None):
    if plan.get('version')==CONSTRUCTION_VERSION:
        raise ValueError('A transient construction plan is not a saved query-planning release')
    case=public_case(case);validate_plan(plan,case);validate_registry(registry,index_ref,case)
    if parent is not None:
        if set(parent)-{'plan_sha256','case_sha256','source_release_sha256'}:
            raise ValueError('Only original query-plan hash lineage may be reused')
        if parent.get('plan_sha256') != digest(plan) or parent.get('case_sha256') != digest(case):
            raise ValueError('Saved query-only plan belongs to a different exact public case')
    release=dict(version=RELEASE_VERSION,case=case,case_sha256=digest(case),plan=deepcopy(plan),
        plan_sha256=digest(plan),registry_sha256=registry['sha256'],index_ref=deepcopy(index_ref),
        source_binding_sha256=digest(registry['corpora'][case['corpus']]),
        parent_query_plan=deepcopy(parent),old_inference_reused=False,old_grades_reused=False,
        model_calls=0,query_only=True)
    release['sha256']=digest(release)
    return release


def validate_release(release, case, registry, index_ref):
    if (release.get('version') != RELEASE_VERSION
            or release.get('sha256') != digest({k:v for k,v in release.items() if k!='sha256'})
            or release.get('case') != public_case(case)):
        raise ValueError('Current planning release or exact case changed')
    expected=bind_saved_plan(case,release['plan'],registry,index_ref,release.get('parent_query_plan'))
    if release != expected:
        raise ValueError('Current planning release differs from registry/index/plan pair')
    return deepcopy(release['plan'])


def _local_compiler_files():
    root=Path(__file__).resolve().parents[1]
    return {name:byte_sha(bound(root,name)) for name in LOCAL_COMPILER_FILES}


def _local_envelope(case,source_plan,readings,compiler,source_release_sha256):
    return dict(version=LOCAL_PLAN_VERSION,arm='llm_local',task=case['task'],
        query_sha256=digest(case['query']),atoms=deepcopy(source_plan['atoms']),
        extractions=deepcopy(source_plan['extractions']),leads=[],slot_readings=deepcopy(readings),
        keys_read=False,grades_read=False,local_planning=dict(version=LOCAL_DERIVATION_VERSION,
            source_plan=deepcopy(source_plan),source_plan_sha256=digest(source_plan),
            source_release_sha256=source_release_sha256,case_sha256=digest(case),
            compiler=deepcopy(compiler),compiler_input_sha256=digest(dict(query=case['query'],
                focal_marker=case['focal_marker'])),readings_sha256=digest(readings),
            model_calls=0,query_only=True,compiled_before_inference=True))


def _validate_local_plan(plan,case):
    provenance=plan.get('local_planning',{})
    source=provenance.get('source_plan')
    if (not isinstance(source,dict) or source.get('version') in {LOCAL_PLAN_VERSION,CONSTRUCTION_VERSION}
            or source.get('arm')!='llm_local'):
        raise ValueError('New local planning requires an original C query plan, never A annotations')
    validate_plan(source,case)
    compiler=provenance.get('compiler',{})
    if (set(compiler)!={'version','files'} or not isinstance(compiler['version'],str) or not compiler['version']
            or compiler['files']!=_local_compiler_files()):
        raise ValueError('Local planning compiler byte pins changed; derive a new planning release')
    parent=provenance.get('source_release_sha256')
    if parent is not None and (not isinstance(parent,str) or not re.fullmatch('[0-9a-f]{64}',parent)):
        raise ValueError('Invalid original query-planning release hash')
    rows=plan.get('slot_readings')
    if not isinstance(rows,list) or len({r.get('id') for r in rows})!=len(rows):
        raise ValueError('Unique explicitly saved local readings required')
    required={'id','form','role','target_kind','left_quote','right_quote','attachment_quote','finite','notes'}
    optional={'grammatical_number','kind_cue_quote','number','cue_quote'}
    if case['task']!='redaction' and rows:raise ValueError('H/R local plans have no redaction readings')
    if case['task']=='redaction':
        if not case['focal_marker'] or case['query'].count(case['focal_marker'])!=1:
            raise ValueError('One exact local planning focal marker required')
        left,right=case['query'].split(case['focal_marker'])
        for row in rows:
            if (not required<=set(row) or set(row)-required-optional
                    or not all(isinstance(row[k],str) for k in required-{'finite'}) or not row['id']
                    or row['form'] not in {'nominal','modifier','quantity','possessive','member_example','verbal','adjunct','clause','unknown'}
                    or row['left_quote']!=left or row['right_quote']!=right
                    or row['attachment_quote'] not in case['query']
                    or row['finite'] is not None and type(row['finite']) is not bool):
                raise ValueError('Local reading shape or exact public-query boundaries changed')
    expected=_local_envelope(case,source,rows,compiler,parent)
    if plan!=expected:raise ValueError('Local planning derivation/input/output seal changed')
    return plan


def bind_current_local_plan(case,source_plan,registry,index_ref,*,source_release_sha256=None):
    """Compile C once during explicit planning, never during source solving."""
    case=public_case(case);validate_plan(source_plan,case)
    if source_plan.get('arm')!='llm_local' or source_plan.get('version') in {LOCAL_PLAN_VERSION,CONSTRUCTION_VERSION}:
        raise ValueError('Compile a new local release from the original C query plan only')
    pins=_local_compiler_files()
    if pins!=_LOCAL_COMPILER_IMPORT_PINS:
        raise RuntimeError('Local compiler bytes changed after planning import; use a fresh planning worker')
    from . import local_readings
    from matryoshka_demo.io import offline
    before=digest(dict(case=case,plan=source_plan))
    with offline():readings=local_readings.for_case(deepcopy(case))
    if _local_compiler_files()!=pins or before!=digest(dict(case=case,plan=source_plan)):
        raise ValueError('Local compiler/public query changed during explicit planning')
    compiler=dict(version=local_readings.VERSION,files=pins)
    plan=_local_envelope(case,source_plan,readings,compiler,source_release_sha256)
    validate_plan(plan,case)
    return bind_saved_plan(case,plan,registry,index_ref)


def construction_plan(case,source_plan):
    """Derive grammar operations without changing saved model/query identities."""
    validate_plan(source_plan,case)
    from .arm_controls import controls_for
    control=controls_for(case,source_plan)
    if source_plan.get('version')==LOCAL_PLAN_VERSION:
        control.update(local_planning_version=LOCAL_PLAN_VERSION,
            local_compiler=deepcopy(source_plan['local_planning']['compiler']),
            solver_recompiled_local_readings=False)
    control['saved_query_plan_sha256']=digest(source_plan)
    derived=deepcopy(source_plan)
    derived.update(version=CONSTRUCTION_VERSION,slot_readings=deepcopy(control['construction_operations']),leads=[],
        current_derivation=dict(source_plan=deepcopy(source_plan),controls=control,
            source_plan_sha256=digest(source_plan),retrieval_uses_original_plan=True,
            model_A_readings_supplemented=False))
    return derived


def token_proof(token, offset=0):
    return dict(text=token.text,lemma=token.lemma_.casefold(),start=token.idx+offset,
        end=token.idx+offset+len(token),dependency=token.dep_,pos=token.pos_,tag=token.tag_)


def compile_requirements(case, plan, *, engine=None):
    """Audit all finite matrix/conjunct predicates, including qualified content.

    Fallible extraction annotations never stand in for raw-query coverage. A
    dropped action or slash-name component prevents complete assembly, even
    if an incidental property has a superficially matching source frame.
    """
    case=public_case(case);validate_plan(plan,case);check_atoms(case,plan['atoms'])
    from matryoshka_demo_v61.scope_matching import Engine
    from matryoshka_demo_v6.planning import sentences
    engine=engine or Engine();result=[]
    for atom in plan['atoms']:
        units=list(sentences(atom['text']))
        for number,unit in enumerate(units,1):
            raw=unit['text'];offset=atom['start']+unit['start'];doc=engine.parse(raw)
            frames=engine.targets(raw);issues=[];main=[];operators=[]
            if raw.rstrip().endswith('?'):
                issues.append('QUESTION_SPEECH_ACT_NOT_NORMALIZED')
            for token in doc:
                if token.dep_ not in {'ROOT','conj'}:
                    continue
                if token.dep_=='conj' and token.head.dep_ not in {'ROOT','conj'}:
                    continue
                finite=token.tag_ in {'VBD','VBP','VBZ','MD'} or any(
                    t.dep_ in {'aux','auxpass','cop'} and t.tag_ in {'VBD','VBP','VBZ','MD'} for t in token.children)
                copular=any(c.dep_=='cop' and c.lemma_.casefold()=='be' for c in token.children)
                if token.pos_ not in {'VERB','AUX'} and not copular or not finite:
                    continue
                direct=any(f['predicate_proof']['start']==token.idx for f in frames)
                if token.lemma_.casefold()=='be':
                    direct=direct or any(f['kind'] in {'PROPERTY','NOMINAL_RELATION'} and f.get('copula')=='be'
                        and any(c.idx==f['predicate_proof']['start'] for c in token.children) for f in frames)
                scoped=any(any(q['predicate']==token.lemma_.casefold() for q in f['qualifiers'].get('scope',[]))
                    and any(a==token for a in next((t for t in doc if t.idx==f['predicate_proof']['start']),token).ancestors)
                    for f in frames)
                proof=token_proof(token,offset)
                main.append(dict(proof=proof,represented=direct or scoped,representation='FRAME' if direct else 'OUTER_OPERATOR' if scoped else 'MISSING'))
                if scoped:
                    holder=[t for child in token.children if child.dep_ in {'nsubj','nsubjpass','csubj'}
                        for t in child.subtree if t.dep_ not in {'punct'}]
                    operators.append(dict(predicate=token.lemma_.casefold(),predicate_proof=proof,
                        holders=[token_proof(t,offset) for t in holder],content_scope_retained=True,
                        inner_event_established=False))
            for token in doc:
                if token.lemma_.casefold()=='accord' and token.dep_=='prep':
                    holders=[t for prep in token.children if prep.lower_=='to'
                        for obj in prep.children if obj.dep_=='pobj' for t in obj.subtree if not t.is_punct]
                    if holders:
                        operators.append(dict(predicate='according_to',predicate_proof=token_proof(token,offset),
                            holders=[token_proof(t,offset) for t in holders],content_scope_retained=True,
                            inner_event_established=False))
                        frames=[f for f in frames if not (f['predicate']=='accord' and f['predicate_proof']['start']==token.idx)]
            if not main:
                issues.append('NO_FINITE_MAIN_CLAUSE_REPRESENTATION')
            if any(not row['represented'] for row in main):
                issues.append('MAIN_CLAUSE_PREDICATE_DROPPED')
            if not frames:
                issues.append('NO_COMPLETE_TYPED_REQUIREMENT')
            def unresolved(value):
                if isinstance(value,dict):
                    if value.get('unresolved'):return True
                    return any(unresolved(v) for v in value.values())
                if isinstance(value,list):return any(unresolved(v) for v in value)
                return False
            if any(unresolved(f) for f in frames):issues.append('UNRESOLVED_QUERY_ARGUMENT_OR_SCOPE')
            quoted=bool(re.search(r'"|[\u201c\u201d]|(?<!\w)[\x27\u2018]|[\x27\u2019](?!\w)',raw))
            if quoted and not operators:issues.append('QUOTATION_WITHOUT_BOUND_HOLDER')
            covered=set()
            def proofs(value):
                if isinstance(value,dict):
                    if {'start','end','text'}<=value.keys() and type(value['start']) is int:
                        yield value
                    for key,item in value.items():
                        if key not in {'query_context','quote','fixed_pool_raw_text'}:
                            yield from proofs(item)
                elif isinstance(value,list):
                    for item in value:yield from proofs(item)
            for frame in frames:
                for proof in proofs(frame):
                    covered.update(range(proof['start'],proof['end']))
            for row in main:
                p=row['proof'];covered.update(range(p['start']-offset,p['end']-offset))
            for operator in operators:
                p=operator['predicate_proof'];covered.update(range(p['start']-offset,p['end']-offset))
                for p in operator['holders']:covered.update(range(p['start']-offset,p['end']-offset))
            # Preserve phrasal-predicate particles explicitly, not by changing
            # a lemma or pretending a geographic property covers the action.
            particles=[token_proof(t,offset) for t in doc if t.dep_=='prt']
            uncovered=[token_proof(t,offset) for t in doc if t.pos_ in {'PROPN','NOUN','VERB','ADJ','NUM'}
                and t.dep_ not in {'aux','auxpass','cop'} and not all(i in covered for i in range(t.idx,t.idx+len(t)))]
            if uncovered:issues.append('UNBOUND_QUERY_CONTENT_TOKENS')
            qualified=bool(operators or any(f['qualifiers'].get(k) for f in frames
                for k in ('scope','attribution','modality','conditional','question')))
            result.append(dict(id=atom['id']+':clause'+str(number),atom_id=atom['id'],
                start=offset,end=offset+len(raw),text=raw,frames=frames,main_clauses=main,
                predicate_particles=particles,operator_path=operators,
                kind='QUALIFIED_PROPOSITION' if qualified else 'SOURCE_PROPOSITION',
                whole_content_required=True,actual_inner_event_required=not qualified,
                coverage=dict(complete=not issues,issues=issues,unbound_tokens=uncovered)))
    return dict(version='current-typed-query-requirements/1',case_sha256=digest(case),
        query_sha256=digest(case['query']),plan_sha256=digest(plan),requirements=result,
        complete=bool(result) and all(r['coverage']['complete'] for r in result),
        extraction_annotations_are_proof=False,model_calls=0)


_LOCAL_COMPILER_IMPORT_PINS=_local_compiler_files()
