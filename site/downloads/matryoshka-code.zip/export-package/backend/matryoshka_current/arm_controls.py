"""Public A/B/C contracts and explicit execution/display controls, never a solver.

No API, source lookup, candidate ranking, factual decision or active switching.
The caller separately validates the planner's semantic faithfulness and source
registry. No current resource authority is inferred from old case IDs or runs.
"""
from copy import deepcopy
import hashlib
import json
import re
from datetime import date
import time

VERSION = "current-arm-controls/2"
ARMS = ("llm_readings", "llm_atoms", "llm_local")
MECHANICAL_OPERATIONS = ("nominal", "modifier", "quantity", "possessive", "member_example", "verbal", "adjunct", "clause")
SOURCE_FORMS_VERSION = "current-literal-source-forms/1"
_TASKS = {"redaction", "hypothesis", "reconstruction"}
_PUBLIC = ("case_id", "task", "corpus", "document_id", "date", "query", "focal_marker")


def _digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()


def _bound(case, plan):
    public = {k:case[k] for k in _PUBLIC}
    if public["task"] not in _TASKS or not isinstance(public["query"],str) or not public["query"].strip():
        raise ValueError("A public task/query is required")
    if plan.get("arm") not in ARMS or plan.get("task") != public["task"] or plan.get("query_sha256") != _digest(public["query"]):
        raise ValueError("Plan arm/task/query binding differs")
    if plan.get("keys_read",False) is not False or plan.get("grades_read",False) is not False:
        raise ValueError("Nonpublic planner inputs are not allowed")
    view = {k:deepcopy(plan[k]) for k in ("arm","task","query_sha256","atoms","leads")}
    view.update(extractions=deepcopy(plan.get("extractions")),slot_readings=deepcopy(plan.get("slot_readings",[])))
    if not view["atoms"]:
        raise ValueError("No shared atomic retrieval input; no silent whole-query fallback")
    if plan.get("shared_atoms_sha256",_digest(view["atoms"])) != _digest(view["atoms"]):
        raise ValueError("Declared shared atom hash differs")
    if plan.get("shared_extraction_sha256",_digest(view["extractions"])) != _digest(view["extractions"]):
        raise ValueError("Declared shared extraction hash differs")
    for atom in view["atoms"]:
        if not atom.get("text","").strip():
            raise ValueError("Empty atom cannot be an executed search")
        quote = atom["source_quote"]
        a,b = atom["start"],atom["end"]
        if not (type(a) is int and type(b) is int and 0 <= a < b <= len(public["query"]) and public["query"][a:b] == quote):
            raise ValueError("Atom source quote/offset does not replay")
    if view["arm"] != "llm_readings" and view["leads"]:
        raise ValueError("Only A may execute saved model context questions")
    if view["arm"] == "llm_atoms" and view["slot_readings"]:
        raise ValueError("B must not acquire saved slot readings")
    if public["task"] != "redaction" and view["slot_readings"]:
        raise ValueError("H/R have no redaction slot readings")
    if public["task"] == "redaction":
        marker = public["focal_marker"]
        if not marker or public["query"].count(marker) != 1:
            raise ValueError("Exactly one opaque focal marker is required")
    return public,view


def controls_for(case, plan):
    """Expose saved interpretation versus source operations without mutation.

    This is an integration proposal, not permission to bypass fit/counter/source
    checks. Unknown C falls back explicitly to B's operations, not a typed claim.
    A abstention is retained; no local compiler silently supplements model A.
    """
    case,view = _bound(case,plan)
    reads = deepcopy(view["slot_readings"])
    operations = reads
    mode = "NO_REDACTION_SLOT"
    if case["task"] == "redaction":
        mode = "SAVED_MODEL_READINGS" if view["arm"] == "llm_readings" else "SAVED_LOCAL_READINGS"
        if view["arm"] == "llm_atoms" or view["arm"] == "llm_local" and (not reads or all(r["form"] == "unknown" for r in reads)):
            mode = "MECHANICAL_SOURCE_OPERATIONS" if view["arm"] == "llm_atoms" else "LOCAL_ABSTENTION_MECHANICAL_FALLBACK"
            left,right = case["query"].split(case["focal_marker"])
            operations = [dict(id="operation_"+form,form=form,role="unknown",target_kind="any",
                left_quote=left,right_quote=right,attachment_quote="",finite=None,
                notes="Mechanical source-phrase operation, not a predicted slot reading") for form in MECHANICAL_OPERATIONS]
    searches = [dict(id=a["id"],kind="atom",query=a["text"],atom_ids=[a["id"]]) for a in view["atoms"]]
    atom_ids = {a["id"] for a in view["atoms"]}
    reading_ids = {r["id"] for r in reads}
    for lead in view["leads"]:
        if not lead.get("question","").strip() or not set(lead.get("atom_ids",[])) <= atom_ids or not set(lead.get("reading_ids",[])) <= reading_ids:
            raise ValueError("Unbound saved context question")
        searches.append(dict(id=lead["id"],kind="question",query=lead["question"],
            atom_ids=deepcopy(lead.get("atom_ids",[])),reading_ids=deepcopy(lead.get("reading_ids",[]))))
    return dict(version=VERSION,arm=view["arm"],task=case["task"],query_sha256=view["query_sha256"],
        shared_atoms_sha256=_digest(view["atoms"]),shared_extraction_sha256=_digest(view["extractions"]),
        saved_readings=reads,construction_operations=operations,construction_mode=mode,retrieval_inputs=searches,
        operation_labels={form:("statement" if form == "clause" else form) for form in MECHANICAL_OPERATIONS},
        source_forms_version=SOURCE_FORMS_VERSION,common_fit_required=True,
        branch_kind="mechanical_operation" if mode in {"MECHANICAL_SOURCE_OPERATIONS","LOCAL_ABSTENTION_MECHANICAL_FALLBACK"}
            else "model_reading" if mode == "SAVED_MODEL_READINGS" else "local_reading" if mode == "SAVED_LOCAL_READINGS" else "not_applicable",
        presentation_budget=dict(per_branch=5,branch_count=len(operations),global_diagnostic=5,
            collapse_mechanical_branches=False,meaning="Display bounds, not retrieval or factual support"),
        shared_model_extraction_present=view["extractions"] is not None and plan.get("version") != "current-query-plan/1",
        saved_plan_mutated=False,source_eligibility_or_factual_support_certified=False,
        planning_semantic_faithfulness_replayed=False,source_registry_must_be_explicit=True,
        generated_keywords_used=False,model_calls=0)


def audit_shared(case, plans):
    if set(plans) != set(ARMS):
        raise ValueError("Exact A/B/C cohort required")
    values = {arm:controls_for(case,plans[arm]) for arm in ARMS}
    if not all(v["shared_model_extraction_present"] for v in values.values()):
        raise ValueError("Literal source controls are not a shared-model A/B/C extraction cohort")
    if any(v["arm"] != arm for arm,v in values.items()):
        raise ValueError("Arm keys and declared plans differ")
    for key in ("shared_atoms_sha256","shared_extraction_sha256","query_sha256"):
        if len({v[key] for v in values.values()}) != 1:
            raise ValueError("Shared query/extraction/atoms differ across arms")
    if values["llm_atoms"]["retrieval_inputs"] != values["llm_local"]["retrieval_inputs"]:
        raise ValueError("B/C discovery inputs differ")
    return dict(version=VERSION,shared_inputs_equal=True,BC_retrieval_inputs_equal=True,controls=values,
        native_per_reading_display_budget_is_not_global_budget=True,model_calls=0,
        semantic_faithfulness_replayed=False)


def matched_display(readings, budget=5):
    """Diagnostic global-budget slice of saved display rows, not full-pool rank.

    Round-robin by rank and saved reading order. Identical candidate IDs are
    suppressed, but citations/statuses/ranks are never rewritten or merged.
    """
    if type(budget) is not int or not 1 <= budget <= 5:
        raise ValueError("Matched diagnostic budget must be one to five")
    selected,seen = [],set()
    for rank in range(max((len(r["candidates"]) for r in readings),default=0)):
        for row in readings:
            if rank >= len(row["candidates"]):
                continue
            candidate = row["candidates"][rank]
            key = candidate["id"]
            if key in seen:
                continue
            seen.add(key)
            selected.append(dict(display_position=len(selected)+1,reading_id=row["reading"]["id"],
                candidate=deepcopy(candidate)))
            if len(selected) == budget:
                return selected
    return selected


def _checked_page(page, case=None, *, source_view_policy=None):
    from matryoshka_demo.contracts import MASK
    from matryoshka_demo.source_view_policy import STRICT_PRIOR, source_page_allowed
    policy = STRICT_PRIOR if source_view_policy is None else source_view_policy
    if not isinstance(page.get("text"),str) or not page.get("id") or _digest(page["text"]) != page.get("source_sha256"):
        raise ValueError("Source page ID/text/hash binding differs")
    if page.get("permitted") is not True:
        raise ValueError("Source page is not explicitly permitted")
    if case is not None:
        if not source_page_allowed(page, case, policy):
            raise ValueError("Source corpus/date/whole-origin policy differs")
        if case["corpus"] == "cib" and page.get("visibility") not in {"earlier","both"}:
            raise ValueError("CIB source is not explicitly earlier-visible")
        if case["corpus"] != "cib" and (page.get("classification") != "CONFIDENTIAL"
                or re.search(r"\bNOFORN\b|NO\s+FOREIGN\s+DISSEMINATION",page["text"],re.I)
                or any(re.search(r"\bNOFORN\b|NO\s+FOREIGN\s+DISSEMINATION",str(h),re.I) for h in page.get("handling",[]))):
            raise ValueError("Source cable handling/classification is ineligible")
    return MASK


def source_form_inventory(page, *, parse=None):
    """Query-independent literal source spans for the common arm constructor.

    This is not eligibility/identity authorization, insertion fit, or factual
    support. Callers must use checked current resources; diagnose_controls also
    rechecks selected-page cutoff/origin/handling. Whole-document policy remains
    inherited. No A/C reading, query, result, answer or grade is an input.
    """
    mask = _checked_page(page)
    from matryoshka_demo import source_constituents_v23 as baseline
    if parse is None:
        from matryoshka_demo_v6.task_execution import _raw_parser
        parse = _raw_parser()
    raw = page["text"]
    original,old_rows = baseline.proposal_spans(raw,parse)
    lower = raw.lower()
    doc = parse(lower) if raw.isupper() and len(lower) == len(raw) else original
    values = {}

    def add(kind,a,b,head,route):
        part = doc.char_span(a,b,alignment_mode="strict")
        if part is None or part[0].sent != part[-1].sent or mask.search(raw[a:b]):
            return
        full = head.sent
        bounds = [a,b]
        key = kind,a,b
        operators = []
        for token in [head,*head.ancestors]:
            if token.sent != full:
                break
            attached = [c for c in token.children if c.dep_ in {"neg","aux","auxpass","mark","advmod"}]
            operators.append(dict(start=token.idx,end=token.idx+len(token),text=raw[token.idx:token.idx+len(token)],
                dependency=token.dep_,qualifiers=[dict(start=c.idx,end=c.idx+len(c),text=raw[c.idx:c.idx+len(c)],dependency=c.dep_) for c in attached]))
        required = [t for c in head.children if c.dep_ in {"prep","xcomp","ccomp","acl","relcl","advcl","conj","cc","neg","advmod","aux","auxpass","det"}
            for t in c.subtree if not t.is_space and not t.is_punct]
        values[key] = dict(id="source_form_"+_digest([page["id"],page["source_sha256"],kind,bounds])[:24],
            source_kind=kind,source_span=bounds,source_wording=raw[a:b],fill=raw[a:b],
            source_head=dict(start=head.idx,end=head.idx+len(head),text=raw[head.idx:head.idx+len(head)],
                pos=head.pos_,tag=head.tag_,dependency=head.dep_),
            source_structure_complete=all(a <= t.idx and t.idx+len(t) <= b for t in required),
            source_scope_chain=operators,source_route=route,
            sources=[dict(canonical_page_id=page["id"],document_id=page["document_id"],date=page["date"],
                page_sha256=page["source_sha256"],start=full.start_char,end=full.end_char,text=raw[full.start_char:full.end_char])],
            literal_source_only=True,grammatical_insertion_certified=False,factual_support_certified=False)

    def region(kind,tokens,head,route):
        tokens = sorted({t.i:t for t in tokens if not t.is_space and not t.is_punct}.values(),key=lambda t:t.i)
        if not tokens:
            return
        a,b = tokens[0].idx,tokens[-1].idx+len(tokens[-1])
        part = doc.char_span(a,b,alignment_mode="strict")
        if part is not None and {t.i for t in part if not t.is_space and not t.is_punct} == {t.i for t in tokens}:
            add(kind,a,b,head,route)

    for row in old_rows:
        part = doc.char_span(row["start"],row["end"],alignment_mode="strict")
        if part is not None and not row.get("source_format_rejection"):
            add(row["kind"],row["start"],row["end"],part.root,"INHERITED_LITERAL_CONSTITUENT")
    for chunk in doc.noun_chunks:
        if chunk.root.pos_ in {"NOUN","PROPN"}:
            region("nominal",chunk.root.subtree,chunk.root,"FULL_SOURCE_NOMINAL_SUBTREE")
            if any(t.dep_ == "nummod" for t in chunk.root.subtree):
                region("quantity",chunk.root.subtree,chunk.root,"SOURCE_QUANTIFIED_NOMINAL_SUBTREE")
    for token in doc:
        if token.pos_ in {"NOUN","PROPN"} and any(c.dep_ == "nummod" for c in token.children):
            region("quantity",token.subtree,token,"SOURCE_NUMERIC_NOMINAL_INCLUDING_MEASURE_ADVERBIAL")
        if token.pos_ in {"VERB","AUX"}:
            if token.dep_ in {"aux","auxpass","cop"}:
                continue
            selected = [token]
            for child in token.children:
                if child.dep_ not in {"nsubj","nsubjpass","nsubj:pass","punct","mark"}:
                    selected.extend(child.subtree)
            region("verbal",selected,token,"SOURCE_VERBAL_DEPENDENTS_OWNER_RETAINED_IN_CITATION")
            finite = token.tag_ in {"VBD","VBP","VBZ","MD"} or any(c.dep_ in {"aux","auxpass","cop"}
                and c.tag_ in {"VBD","VBP","VBZ","MD"} for c in token.children)
            if finite and any(c.dep_ in {"nsubj","nsubjpass","nsubj:pass"} for c in token.children):
                region("clause",token.subtree,token,"SOURCE_CLAUSE_WITH_OWN_SUBJECT")
        if token.pos_ == "ADP" and token.dep_ in {"prep","agent"} or token.pos_ == "ADV" and token.dep_ == "advmod":
            region("adjunct",token.subtree,token,"SOURCE_PREPOSITIONAL_OR_ADVERBIAL_SUBTREE")
    return dict(version=SOURCE_FORMS_VERSION,page_id=page["id"],source_sha256=page["source_sha256"],
        spans=[values[k] for k in sorted(values,key=lambda k:(k[1],k[2],k[0]))],
        query_used=False,model_or_local_readings_used=False,source_text_modified=False,
        whole_document_policy_replayed=False,identity_authorized=False)


def unchanged_native_admission(*, parse=None):
    """One shared source/boundary/grammar admission callback for all arms.

    The old unimplemented-form sentinel remains a capability failure, NOT a
    linguistic rejection. It is not erased to manufacture a pass. This callback
    does not run the factual/counter assessor or rank/display the resulting pool.
    """
    from matryoshka_demo_v61.candidates import _admission as native
    from matryoshka_demo_v61.candidates import boundary_fit
    from matryoshka_demo.fill_wording_v23 import modifier_wording
    engine = native._Engine(parse)

    def fit(case,operation,proposal):
        case = {k:case[k] for k in _PUBLIC}
        source = proposal["sources"][0]
        a,b = proposal["source_span"]
        if source["text"][a-source["start"]:b-source["start"]] != proposal["source_wording"]:
            raise ValueError("Source occurrence does not replay")
        doc = engine.parse(source["text"])
        part = doc.char_span(a-source["start"],b-source["start"],alignment_mode="strict")
        if part is None:
            return dict(admissible=False,status="SOURCE_TOKEN_ALIGNMENT_UNRESOLVED",capability_failure=False)
        fill,edits = proposal["source_wording"],[]
        if operation["form"] == "modifier":
            fill,edits = modifier_wording(fill,part)
        boundary = boundary_fit(case,fill)
        fill = boundary["fill"]
        right = case["query"].split(case["focal_marker"])[1]
        if operation["form"] == "possessive" and not re.match(r"['\u2019]s\b",right):
            if not fill.endswith(("'s","\u2019s")):
                fill += "'s"
                edits.append(dict(kind="POSSESSIVE_FUNCTION_WORD_ADDED",text="'s"))
        if operation["form"] == "member_example":
            fill = "like " + fill
            edits.append(dict(kind="MEMBER_EXAMPLE_FUNCTION_WORD_ADDED",text="like "))
        constructed = dict(deepcopy(proposal),fill=fill,insertion_edits=deepcopy(edits+boundary["edits"]))
        constructed["id"] = "constructed_operation_"+_digest([case["query"],proposal["id"],operation["form"],fill])[:24]
        grammar = native.grammar_admission(case,operation,fill,parse=engine.parse)
        source_grammar = native._source_grammar_admission(case,constructed,engine)
        constraints = native._construction_constraints(case,operation,constructed,grammar,engine)
        capability = "UNIMPLEMENTED_FORM_WITHHELD_NOT_PADDED" in grammar["reasons"]
        reasons = list(dict.fromkeys(grammar["reasons"]+source_grammar["reasons"]+constraints["reasons"]))
        admissible = bool(boundary["admissible"] and grammar["admissible"] and source_grammar["admissible"] and constraints["admissible"])
        return dict(admissible=admissible,status="FORM_CAPABILITY_NOT_IMPLEMENTED" if capability else
            "COMMON_ADMISSION_PASS" if admissible else "COMMON_ADMISSION_WITHHELD",
            capability_failure=capability,grammar_reasons=[r for r in reasons if r != "UNIMPLEMENTED_FORM_WITHHELD_NOT_PADDED"],
            native_grammar=grammar,source_grammar=source_grammar,source_constraints=constraints,boundary=boundary,
            constructed_proposal=constructed,native_admission_unchanged=True,factual_support_certified=False)
    return fit


def diagnose_controls(case, plan, pages=(), *, parse=None, fit=None, operation_forms=None):
    """Executable offline construction diagnostic; no ranking or task decision.

    fit(case, operation, proposal) must return {'admissible': bool, ...}; it is
    the SAME common fitter for A/B/C. With fit=None, no proposal is accepted.
    All passed pages must already belong to the caller's checked source budget.
    Returns full source-span ledgers and fit counts, not recommendations/top5.
    """
    control = controls_for(case,plan)
    case = {k:case[k] for k in _PUBLIC}
    page_list = list(pages.values()) if isinstance(pages,dict) else list(pages)
    if len({p["id"] for p in page_list}) != len(page_list):
        raise ValueError("Duplicate source page identity")
    started = time.perf_counter()
    inventories = []
    for page in page_list:
        _checked_page(page,case)
        inventories.append(source_form_inventory(page,parse=parse))
    branches = []
    if operation_forms is not None and (len(set(operation_forms)) != len(operation_forms) or not set(operation_forms) <= set(MECHANICAL_OPERATIONS)):
        raise ValueError("Diagnostic operation subset must be unique declared source forms")
    for operation in control["construction_operations"]:
        if operation_forms is not None and operation["form"] not in operation_forms:
            continue
        kind = "nominal" if operation["form"] in {"possessive","member_example"} else operation["form"]
        branch_start = time.perf_counter()
        proposals = [deepcopy(p) for inventory in inventories for p in inventory["spans"] if p["source_kind"] == kind]
        for proposal in proposals:
            proposal["source_form_id"] = proposal["id"]
            proposal["id"] = "operation_proposal_"+_digest([control["query_sha256"],operation["id"],proposal["source_form_id"]])[:24]
        checks = []
        for proposal in proposals:
            if fit is None:
                result = dict(status="NOT_RUN_COMMON_FIT_REQUIRED",admissible=False)
            else:
                result = fit(deepcopy(case),deepcopy(operation),deepcopy(proposal))
                if not isinstance(result,dict) or type(result.get("admissible")) is not bool:
                    raise ValueError("Common fitter must return an explicit boolean admissible field")
            checks.append(dict(proposal_id=proposal["id"],fit=deepcopy(result)))
        branches.append(dict(operation=deepcopy(operation),proposals=proposals,fit_checks=checks,
            source_proposals=len(proposals),fit_passed=sum(c["fit"]["admissible"] for c in checks),
            capability_failures=sum(c["fit"].get("capability_failure") is True for c in checks),
            insertion_transforms_applied=any(c["fit"].get("constructed_proposal",{}).get("insertion_edits") for c in checks),
            branch_status="NO_ATTESTED_SOURCE_SPANS" if not proposals else "COMMON_FIT_NOT_RUN" if fit is None
                else "FORM_CAPABILITY_NOT_IMPLEMENTED" if all(c["fit"].get("capability_failure") is True for c in checks)
                else "COMMON_ADMISSION_PROCESSED",elapsed_seconds=time.perf_counter()-branch_start,
            ranked=False,factual_support_certified=False))
    return dict(version=VERSION,source_forms_version=SOURCE_FORMS_VERSION,controls=control,
        source_pages=len(page_list),inventories=inventories,branches=branches,elapsed_seconds=time.perf_counter()-started,
        common_fit_executed=fit is not None,mechanical_operation_transforms_not_applied=not any(b["insertion_transforms_applied"] for b in branches),
        all_declared_branches_processed=operation_forms is None,full_source_pool_not_display_truncated=True,
        operation_subset=list(operation_forms) if operation_forms is not None else None,
        no_recommendations_or_task_decisions=True,presentation_budget=control["presentation_budget"],
        whole_document_policy_replayed=False,API_calls=0,new_retrieval=False)
