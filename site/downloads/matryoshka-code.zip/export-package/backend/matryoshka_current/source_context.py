"""Pinned, complete source-local job locators for an explicit inspected pool.

No Corpus construction, registry discovery, graph labels, planning, inference,
API, source-field repair or trust cache. Returned metadata is never support.
"""
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import date
import hashlib
import json
from numbers import Integral
from pathlib import Path, PurePosixPath
import re
import zlib

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61 import role_alignment as local
from matryoshka_demo_v6 import reporting_local_decisions_v65 as provenance


VERSION = "current-inspected-source-context/1"
_IMPORTED_SHA256 = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
MAX_PAGES = 100
KINDS = {"entities":"mention_id", "events":"event_mention_id", "claims":"claim_mention_id", "relations":"relation_evidence_id"}
_NOFORN = re.compile(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM", re.I)


class SourceGroups(dict):
    """Drop-in assembler mapping; persist receipt separately in the checkpoint."""
    def __init__(self, groups, receipt):
        super().__init__(groups)
        self.receipt = receipt


def _stamp(path):
    stat = path.stat()
    return stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns


def _path(root, name):
    if (not isinstance(name, str) or not name or "\\" in name or PurePosixPath(name).is_absolute()
            or any(p in {"", ".", ".."} for p in name.split("/"))):
        raise ValueError("Explicit canonical workspace-relative source path required")
    path = root / name
    if path.resolve(strict=True) != path or not path.is_file():
        raise ValueError("Source input cannot redirect through a symlink or private path")
    return path


def _pin(root, reference, actual=None):
    if not isinstance(reference, dict) or not re.fullmatch(r"[a-f0-9]{64}", str(reference.get("sha256", ""))):
        raise ValueError("Source input requires an explicit SHA-256 pin")
    path = _path(root, reference.get("path"))
    if actual is not None and Path(actual).absolute() != path:
        raise ValueError("Corpus.files path differs from its explicit binding")
    return dict(reference=deepcopy(reference), path=path, stamp=_stamp(path))


def _read(pin, callback=None, *, jsonl=False):
    """Hash exactly the bytes read, not a preceding separate read of a path."""
    if _stamp(pin["path"]) != pin["stamp"]:
        raise ValueError("Pinned source changed before read")
    hasher = hashlib.sha256()
    if jsonl:
        with pin["path"].open("rb") as stream:
            for raw in stream:
                hasher.update(raw)
                if raw.strip():
                    callback(json.loads(raw))
        value = None
    else:
        with pin["path"].open("rb") as stream:
            raw = stream.read()
        hasher.update(raw)
        value = json.loads(raw) if callback == "json" else None
    if hasher.hexdigest() != pin["reference"]["sha256"] or _stamp(pin["path"]) != pin["stamp"]:
        raise ValueError("Pinned source bytes changed during read")
    return value


def _final_pins(pins):
    for pin in pins.values():
        if _stamp(pin["path"]) != pin["stamp"]:
            raise ValueError("Source input changed during context assembly")
        with pin["path"].open("rb") as stream:
            actual = hashlib.file_digest(stream, "sha256").hexdigest()
        if actual != pin["reference"]["sha256"] or _stamp(pin["path"]) != pin["stamp"]:
            raise ValueError("Source input end pin changed")


def _selection(corpus, case, retrieval):
    if corpus.corpus != case["corpus"] or corpus.binding.get("corpus") != case["corpus"]:
        raise ValueError("Source corpus and public case differ")
    budget = retrieval.get("passage_budget", MAX_PAGES)
    if type(budget) is not int or not 1 <= budget <= MAX_PAGES:
        raise ValueError("Source context budget must be an integer from 1 to 100")
    if "inspected_page_ids" in retrieval:
        ids = retrieval["inspected_page_ids"]
        if (not isinstance(ids, list) or type(retrieval.get("source_pages_inspected")) is not int
                or retrieval["source_pages_inspected"] != len(ids) or len(ids) > budget):
            raise ValueError("Exact budgeted inspected-source identities required")
    else:
        original = retrieval["eligible"].corpus
        if digest(original.binding) != digest(corpus.binding):
            raise ValueError("Retrieval belongs to another bound corpus")
        positions = retrieval["pages"][:budget]
        if any(not isinstance(i, Integral) or isinstance(i, bool) or not 0 <= i < len(original.pages) for i in positions):
            raise ValueError("Invalid inspected source index")
        ids = [original.pages[int(i)]["id"] for i in positions]
        for pid in ids:
            a, b = original.pages[original.page_index[pid]], corpus.pages[corpus.page_index[pid]]
            if any(a[key] != b[key] for key in ("text", "document_id", "date", "source_sha256")):
                raise ValueError("Retrieval/source-context bytes differ")
    if any(not isinstance(pid, str) for pid in ids) or len(set(ids)) != len(ids):
        raise ValueError("Duplicate or malformed inspected source identity")
    pages = {}
    for pid in ids:
        if pid not in corpus.page_index:
            raise ValueError("Inspected source missing from explicit corpus")
        page = corpus.pages[corpus.page_index[pid]]
        index = {pid:page}, {pid:True}, set()
        provenance._quote(provenance._citation(page, 0, len(page["text"])), *index, case)
        if _NOFORN.search(page["text"] + " " + " ".join(page.get("handling", []))):
            raise ValueError("Whole inspected source handling veto")
        pages[pid] = deepcopy(page)
    return pages, list(ids), budget


def _context_binding(context, corpus, case):
    if context is None:
        return None
    registry, reference = context.registry, context.index_ref
    if registry.get("sha256") != digest({k:v for k,v in registry.items() if k != "sha256"}):
        raise ValueError("Context execution registry canonical pin differs")
    selected = registry["corpora"][case["corpus"]]
    if (reference.get("registry_sha256") != registry["sha256"] or reference.get("corpus") != case["corpus"]
            or reference.get("source_binding_sha256") != digest(selected)):
        raise ValueError("Context registry/index/corpus mixed")
    expected = selected.get("incumbent_binding", selected)
    if expected != corpus.binding:
        raise ValueError("Context corpus differs from selected execution binding")
    return dict(registry_sha256=registry["sha256"], index_ref=deepcopy(reference),
        registry_ref=deepcopy(context.registry_ref),
        registry_ref_bytes_reopened=False, registry_ref_verified_by="CALLER_RESOURCE_CONTEXT")


def _audit_page(page):
    return dict(canonical_page_id=page["id"], raw_text_utf8_sha256=hashlib.sha256(page["text"].encode()).hexdigest(),
                standalone_noforn=bool(_NOFORN.search(page["text"])))


def _file_inputs(corpus, pages, pins):
    root = Path(corpus.workspace).resolve()
    required = [*KINDS, "pages", "projection"]
    for key in required:
        if key not in corpus.binding["files"] or key not in corpus.files:
            raise ValueError("Complete explicit cable source files required: " + key)
        pins[key] = _pin(root, corpus.binding["files"][key], corpus.files[key])
    jobs = set()
    for kind in KINDS:
        def select(row):
            if row.get("canonical_page_id") in pages:
                if not isinstance(row.get("job_id"), str) or not row["job_id"]:
                    raise ValueError("Selected source record has no extraction job")
                jobs.add(row["job_id"])
        _read(pins[kind], select, jsonl=True)
    records = {job:{kind:[] for kind in KINDS} for job in sorted(jobs)}
    for kind in KINDS:
        def collect(row):
            if row.get("job_id") in jobs:
                records[row["job_id"]][kind].append(dict(record=row, index_eligible=None))
        _read(pins[kind], collect, jsonl=True)
    documents = {p["document_id"] for p in pages.values()}
    audits, seen = defaultdict(list), set()
    def canonical(row):
        if row["document_id"] not in documents:
            return
        pid, text = row["segment_id"], row["text"]
        audits[row["document_id"]].append(dict(canonical_page_id=pid,
            raw_text_utf8_sha256=hashlib.sha256(text.encode()).hexdigest(), standalone_noforn=bool(_NOFORN.search(text))))
        if pid in pages:
            if pid in seen or text != pages[pid]["text"] or row["document_date_iso"] != pages[pid]["date"]:
                raise ValueError("Canonical source duplicates or inspected bytes/date differ")
            seen.add(pid)
    _read(pins["pages"], canonical, jsonl=True)
    if seen != set(pages):
        raise ValueError("Inspected page absent from bound complete canonical source")
    metadata = _read(pins["projection"], "json")["document_metadata"]
    for page in pages.values():
        meta = metadata.get(page["document_id"], {})
        if (meta.get("classification") != "CONFIDENTIAL" or meta.get("policy_role") != "confidential_evidence"
                or meta.get("date_iso") != page["date"] or _NOFORN.search(" ".join(meta.get("handling", [])))
                or any(a["standalone_noforn"] for a in audits[page["document_id"]])):
            raise ValueError("Whole-document cable classification/handling policy failed")
    return records, dict(audits), {}, deepcopy(corpus.binding["files"]["entities"]), "EXPLICIT_BOUND_CABLE_LEDGERS"


def _indexed_inputs(corpus, current, pages, pins, case):
    root = Path(current.root).resolve()
    reference = current.reference
    pins["index"] = _pin(root, reference)
    _read(pins["index"])
    pins["index_manifest"] = _pin(root, reference["manifest"])
    manifest = _read(pins["index_manifest"], "json")
    if (manifest.get("index_sha256") != reference["sha256"]
            or manifest.get("resource_id") != reference["resource_id"]
            or manifest.get("registry_digest") != reference["registry_digest"]
            or current.registry["registry_digest"] != reference["registry_digest"]):
        raise ValueError("Current source index/resource/manifest mismatch")
    db = current.db
    database = next((row[2] for row in db.execute("PRAGMA database_list") if row[1] == "main"), None)
    if not database or Path(database).resolve() != pins["index"]["path"]:
        raise ValueError("Current connection is not the explicitly pinned source database")
    stored = json.loads(db.execute("SELECT payload FROM metadata WHERE key='identity'").fetchone()[0])
    if stored != manifest["identity"]:
        raise ValueError("Index identity differs from completion manifest")
    records, job_metadata = {}, {}
    jobs = set()
    for pid in pages:
        current_page = current.source(case, pid)["page"]
        if current_page != pages[pid]:
            raise ValueError("Current index/corpus source page mismatch")
        for row in db.execute("SELECT DISTINCT job FROM observation WHERE page=?", (pid,)):
            jobs.add(row[0])
    native_kinds = {"Entity":"entities", "Event":"events", "Claim":"claims"}
    for job in sorted(jobs):
        found = db.execute("SELECT payload FROM job WHERE id=?", (job,)).fetchone()
        if found is None:
            raise ValueError("Source observation has no complete pinned job")
        payload = json.loads(zlib.decompress(found[0]))
        job_metadata[job] = payload
        records[job] = {kind:[] for kind in KINDS}
        for row in db.execute("SELECT * FROM observation WHERE job=? ORDER BY id", (job,)):
            raw = json.loads(zlib.decompress(row["payload"]))
            kind = native_kinds[row["kind"]]
            if (raw.get(KINDS[kind]) != row["id"] or raw.get("job_id") != job
                    or raw.get("local_id") != row["local"] or raw.get("canonical_page_id") != row["page"]
                    or raw.get("document_id") != row["doc"] or raw.get("document_date_iso") != row["date"]):
                raise ValueError("Index observation/raw source record mismatch")
            records[job][kind].append(dict(record=raw, index_eligible=bool(row["eligible"]), index_reason=row["reason"]))
    # The relation table has no job index. Read the explicit bound relation
    # ledger as a stream, retaining only these exact jobs (no graph-edge filter).
    relation_ref = current.registry["files"]["relation_evidence"]
    pins["relations"] = _pin(root, relation_ref)
    def relation(row):
        if row.get("job_id") in jobs:
            records[row["job_id"]]["relations"].append(dict(record=row, index_eligible=None))
    _read(pins["relations"], relation, jsonl=True)
    audits = defaultdict(list)
    for did in sorted({p["document_id"] for p in pages.values()}):
        for row in db.execute("SELECT payload FROM page WHERE doc=? ORDER BY id", (did,)):
            audits[did].append(_audit_page(json.loads(row[0])))
    return records, dict(audits), job_metadata, deepcopy(current.registry["files"]["entity_mentions"]), "PINNED_CURRENT_JOB_OBSERVATIONS"


def _entry(kind, item, page, job, case):
    row = item["record"]
    identity = row.get(KINDS[kind])
    reason = None
    if (not isinstance(identity, str) or not identity or row.get("job_id") != job
            or row.get("canonical_page_id") != page["id"] or row.get("document_id") != page["document_id"]
            or row.get("document_date_iso") != page["date"]):
        reason = "SOURCE_JOB_PAGE_DOCUMENT_DATE_MISMATCH"
    elif item.get("index_eligible") is False:
        reason = "INDEX_WITHHELD:" + str(item.get("index_reason"))
    elif row.get("visibility") not in {"both", "earlier_only"} or row.get("introduced_by_slot_id"):
        reason = "NOT_EARLIER_SOURCE_VISIBLE"
    a,b = row.get("char_start"), row.get("char_end")
    if reason is None and (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != row.get("evidence_quote") or MASK.search(page["text"][a:b])):
        reason = "SOURCE_QUOTE_NOT_LITERAL_OR_OPAQUE"
    if reason:
        return dict(row_id=identity, record_sha256=digest(row), status="WITHHELD", reason=reason,
                    raw_record_returned=False, factual_support_credit=False)
    citation = provenance._citation(page, a, b)
    provenance._quote(citation, {page["id"]:page}, {page["id"]:True}, set(), case)
    return dict(row_id=identity, record=deepcopy(row), citation=citation, status="SOURCE_LOCATOR_ONLY",
                record_sha256=digest(row), factual_support_credit=False)


def groups_for_inspected(context_or_corpus, case, retrieval):
    """Return page->complete local entity groups plus a separate .receipt.

    Persist both ``dict(result)`` and ``result.receipt``. Ineligible raw records
    are never returned; their ID/hash/reason remain in the receipt. No group
    with a missing/ineligible/duplicated entity can be promoted by dropping it.
    """
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != _IMPORTED_SHA256:
        raise ValueError("Source-context helper changed since import")
    claimed_resource = case.get("resource_id")
    case = public_case(case)
    context = None if hasattr(context_or_corpus, "pages") else context_or_corpus
    corpus = context_or_corpus if context is None else context.corpus
    before_binding = digest(corpus.binding)
    context_ref = _context_binding(context, corpus, case)
    pages, ids, budget = _selection(corpus, case, retrieval)
    current = getattr(corpus, "current_index", None) or (getattr(context, "index", None) if context else None)
    if claimed_resource is not None and (current is None or claimed_resource != current.registry.get("resource_id")):
        raise ValueError("Case resource identity differs from explicit source context")
    pins = {}
    with offline():
        if case["corpus"] == "cib":
            if current is None:
                raise ValueError("CIB source groups require the explicit current source index")
            records, audits, jobs, ledger, backend = _indexed_inputs(corpus, current, pages, pins, case)
        else:
            if current is not None:
                raise ValueError("Cable context cannot silently use a CIB current source index")
            records, audits, jobs, ledger, backend = _file_inputs(corpus, pages, pins)
        groups, declined, withheld = defaultdict(list), [], []
        for job, raw in records.items():
            entity_pids = {x["record"].get("canonical_page_id") for rows in raw.values() for x in rows}
            if len(entity_pids) != 1 or not entity_pids <= set(pages):
                declined.append(dict(job_id=job, reason="JOB_OUTSIDE_ONE_INSPECTED_PAGE", raw_job_sha256=digest(raw)))
                continue
            pid = next(iter(entity_pids)); page = pages[pid]
            typed = {kind:[_entry(kind, item, page, job, case) for item in rows] for kind,rows in raw.items()}
            all_rows = [x for values in typed.values() for x in values]
            withheld.extend(dict(job_id=job, kind=kind, **x) for kind,values in typed.items() for x in values if x["status"] == "WITHHELD")
            objects = [dict(row_id=x["row_id"], record=x["record"], citation=x["citation"])
                       for x in typed["entities"] if x["status"] != "WITHHELD"]
            scope = dict(kind="SOURCE_LOCAL_ENTITY_RECORDS", corpus=case["corpus"], canonical_page_id=pid,
                document_id=page["document_id"], date=page["date"], page_sha256=page["source_sha256"], job_id=job,
                source_objects={}, whole_document_audit=audits[page["document_id"]])
            reason = None
            if len(objects) != len(typed["entities"]):
                reason = "INCOMPLETE_OR_WITHHELD_ENTITY_JOB_NO_SUBSET_REPAIR"
            elif len({x["row_id"] for x in all_rows}) != len(all_rows):
                reason = "DUPLICATE_SOURCE_RECORD_ID"
            else:
                try:
                    scope["source_objects"] = {o["row_id"]:local.pointer(o) for o in objects}
                    local._source_context(page, objects, scope, case)
                except (ValueError, KeyError, TypeError) as error:
                    reason = "SOURCE_CONTEXT_REFUSED:" + str(error)
            if reason:
                declined.append(dict(job_id=job, page_id=pid, reason=reason,
                    raw_entity_count=len(typed["entities"]), usable_entity_count=len(objects), raw_job_sha256=digest(raw)))
                continue
            groups[pid].append(dict(objects=objects, scope=scope, case=deepcopy(case), ledger_ref=ledger,
                source_records=typed, job_metadata=deepcopy(jobs.get(job)),
                metadata_scope="COMPLETE_BOUND_JOB_RECORDS_FOR_INSPECTED_PAGE_NOT_SUPPORT",
                source_context_provenance=dict(version=VERSION, backend=backend,
                    verified_input_pins={k:deepcopy(v["reference"]) for k,v in pins.items()},
                    entity_ledger_ref_reopened=backend == "EXPLICIT_BOUND_CABLE_LEDGERS",
                    declared_entity_ledger_ref=deepcopy(ledger), raw_job_sha256=digest(raw),
                    description_is_locator_only=True, quarantined_fields_restored=False)))
        _final_pins(pins)
        if digest(corpus.binding) != before_binding or _context_binding(context, corpus, case) != context_ref:
            raise ValueError("Explicit source context binding changed during read")
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != _IMPORTED_SHA256:
            raise ValueError("Source-context helper changed during read")
    result = dict(groups)
    receipt = dict(version=VERSION, case_sha256=digest(case), corpus=case["corpus"], backend=backend,
        source_binding_sha256=before_binding, context_binding=context_ref, inspected_page_ids=ids,
        source_pages_inspected=len(ids), passage_budget=budget,
        verified_input_pins={k:deepcopy(v["reference"]) for k,v in pins.items()},
        groups_sha256=digest(result), complete_job_count=len(records), returned_group_count=sum(map(len,result.values())),
        declined_jobs=declined, withheld_records=withheld, helper_sha256=_IMPORTED_SHA256,
        registry_discovery=False, graph_labels_as_facts=False, factual_support_credit=False,
        raw_source_records_modified=False, quarantined_fields_restored=False,
        context_registry_ref_bytes_reopened=False, original_raw_cable_admission_repeated=False,
        api_calls=0, new_retrieval=False, persistent_trust_cache=False)
    receipt["sha256"] = digest(receipt)
    return SourceGroups(result, receipt)
