"""Bounded inspection of the actual current run's finite diffusion kernel."""
from collections import deque
from copy import deepcopy
import math
import re
from types import FunctionType

import numpy as np

from matryoshka_demo.io import digest
from matryoshka_demo_v6 import flow as accounting
from matryoshka_demo_v6.flow_projection import targets, _apply_routes, routes_for
from matryoshka_demo_v6.flow_projection_statistics import CategoryReference
from matryoshka_demo_v6.flow_projection_v63 import with_solver_stopping
from matryoshka_demo_v6.flow_projection_v64 import contributor_cone
from .reporting import resource_binding


VERSION = "current-kernel-inspection/2"
LEVELS = ("community", "theme", "domain")


def _route_renderer(snapshot, numerical):
    """Inject one already-verified snapshot into isolated display helpers.

    The legacy functions and module globals are never changed. This reader is
    local to one projection and refuses every other snapshot, avoiding repeated
    decoding/hashing of the same large kernel for each displayed candidate.
    """
    from matryoshka_demo_v6.flow_projection_v65 import _routes
    from matryoshka_demo_v6.guide_route_selection_v65 import candidate_routes

    class VerifiedAccounting:
        def read_snapshot(self, value):
            if value is not snapshot:
                raise ValueError("Display route helper requested another snapshot")
            return numerical

        def __getattr__(self, name):
            return getattr(accounting, name)

    adapter = VerifiedAccounting()

    def isolated(function):
        namespace = dict(function.__globals__, accounting=adapter)
        return FunctionType(function.__code__, namespace, function.__name__, function.__defaults__, function.__closure__)

    render, select = isolated(_routes), isolated(candidate_routes)
    return lambda value, candidate: render(value, candidate, snapshot, selector=select)


def source_representative(candidate, corpus, eligible, indices, final):
    """Locate an existing state in the candidate's own literal source span.

    A source-local name occurrence is not a global alias join, a replacement
    native answer endpoint, or evidence for the proposed missing action.
    """
    sources, span = candidate.get("sources", []), candidate.get("source_span")
    if not sources or not isinstance(span, (list, tuple)) or len(span) != 2:
        return None
    proof = sources[0]
    pi = corpus.page_index.get(proof.get("canonical_page_id"))
    if pi is None or not eligible.page_mask[pi]:
        raise ValueError("Candidate representative is outside its eligible source page")
    page = corpus.pages[pi]
    qa, qb = proof.get("start"), proof.get("end")
    if (proof.get("document_id") != page["document_id"] or proof.get("date") != page["date"]
            or proof.get("page_sha256") != page["source_sha256"]
            or page["source_sha256"] != digest(page["text"])
            or type(qa) is not int or type(qb) is not int or not 0 <= qa < qb <= len(page["text"])
            or proof.get("text") != page["text"][qa:qb]):
        raise ValueError("Candidate representative quotation does not replay on its bound source")
    a, b = span
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != candidate.get("source_wording")):
        return None
    if not qa <= a < b <= qb:
        raise ValueError("Candidate representative wording is outside its cited quotation")
    rows = []
    for oi in corpus.occurrences_by_page.get(pi, []):
        occurrence = corpus.occurrences[oi]
        identity = occurrence["node_id"]
        if identity not in indices or final[indices[identity]] <= 0 or not eligible.unit_mask[occurrence["unit_index"]]:
            continue
        entity = occurrence.get("source_type") == "entities"
        covers = occurrence["start"] <= a < b <= occurrence["end"]
        inside = a <= occurrence["start"] < occurrence["end"] <= b
        if not (covers or entity and inside):
            continue
        label = occurrence.get("label", "")
        if entity and (not label or not re.search(r"(?<!\w)"+re.escape(label)+r"(?!\w)", page["text"][a:b], re.I)):
            continue
        rows.append((not entity, occurrence.get("entity_type") != "Person", -len(label.split()),
            occurrence["end"]-occurrence["start"], -float(final[indices[identity]]), identity, occurrence))
    if not rows:
        return None
    rows.sort(key=lambda r:r[:-1])
    selected = rows[0]
    occurrence = selected[-1]
    return dict(node_ids=[selected[-2]], label=page["text"][a:b],
        kind="SOURCE_LOCAL_LITERAL_OCCURRENCE_NOT_GLOBAL_IDENTITY", identity_proofs=[eligible.citation(occurrence["unit_index"])],
        source_span=list(span), source_observation_id=occurrence["source_row_id"],
        eligible_matching_identity_count=len({r[-2] for r in rows if r[0] == selected[0]}),
        global_identity_authorized=False, factual_support_implied=False, native_endpoint_replaced=False,
        meaning="An existing source-local state containing the candidate wording; its source clause, not global spelling, supplies the association.")


def _kind(a, b):
    if a == b:
        return "NUMERICAL_SELF_LOOP"
    if a.startswith("hierarchy:") and b.startswith("hierarchy:"):
        return "SOURCE_AGGREGATE" if a.split(":")[1] == b.split(":")[1] else "NAVIGATION"
    return "NAVIGATION" if a.startswith("hierarchy:") or b.startswith("hierarchy:") else "SOURCE"


def project(record, context, *, reading=None, limit=2048):
    if type(limit) is not int or not 32 <= limit <= 2048:
        raise ValueError("Drawing bound must be 32 through 2048 actual items")
    case, result = record["case"], record["result"]
    binding = resource_binding(record, context.registry)
    flow = result["flow"]
    expanded = flow["expanded"]
    snapshot = expanded["walk_snapshot"]
    if (flow.get("walk_snapshot_sha256") != snapshot["sha256"]
            or flow.get("binding", {}).get("registry_sha256") != context.registry["sha256"]):
        raise ValueError("Current flow snapshot/resource differs from native execution")
    matrix, prior, final, indices = accounting.read_snapshot(snapshot)
    ids, horizon, alpha = snapshot["state_ids"], snapshot["iterations"], snapshot["alpha"]
    corpus = context.corpus
    eligible = corpus.eligible(case)
    incoming = matrix.tocsc()
    old = {n["id"]: n for n in expanded["nodes"]}
    parents = {}
    for node, membership in corpus.hierarchy.items():
        chain = [node] + ["hierarchy:" + kind + ":" + membership[kind + "_id"]
            for kind in LEVELS if membership.get(kind + "_id")]
        for a, b in zip(chain, chain[1:]):
            if a in parents and parents[a] != b:
                raise ValueError("A current hierarchy member has conflicting parents")
            parents[a] = b
    candidates = targets(result, reading)
    if not result.get("readings"):
        candidates = [dict(deepcopy(t), rank=i) for i, t in enumerate(flow.get("targets", []), 1)]
    for candidate in candidates:
        _apply_routes(candidate, flow["candidate_flows"].get(candidate["id"], {}), (matrix, prior, final, indices))
        for route in candidate.get("represented_routes", []):
            route.pop("_path_indices", None)
        candidate["native_readout"] = {k:deepcopy(candidate.get(k)) for k in
            ("binding", "endpoint_ids", "source_contributor_ids", "endpoint_mass", "selected_walk_metrics")}
        candidate["presentation_target_ids"] = list(candidate.get("endpoint_ids") or candidate.get("source_contributor_ids") or [])
        if not candidate.get("endpoint_ids"):
            representative = source_representative(candidate, corpus, eligible, indices, final)
            if representative:
                candidate["source_semantic_representative"] = representative
                candidate["presentation_target_ids"] = representative["node_ids"]
    selected, order = set(), []
    capacity = limit - len(flow["starters"]) - 1
    if capacity < 1:
        raise ValueError("Query inputs exceed this drawing budget")

    def admit(identity):
        chain, seen, at = [], set(), identity
        while at:
            if at in seen:
                raise ValueError("Cyclic hierarchy")
            seen.add(at)
            if at not in indices:
                break
            chain.append(at)
            at = parents.get(at)
        if len(selected | set(chain)) > capacity:
            return False
        for at in chain:
            if at not in selected:
                selected.add(at)
                order.append(at)
        return bool(chain)

    endpoints = list(dict.fromkeys(n for c in candidates for n in c["presentation_target_ids"]))
    for identity in endpoints:
        if identity not in indices or not admit(identity):
            raise ValueError("Actual result endpoint is absent or exceeds the drawing capacity")
    for starter in flow["starters"]:
        for target in sorted(starter["targets"], key=lambda r: (-r["mass"], r["id"])):
            if target["mass"] > 0 and admit(target["id"]):
                break
    for candidate in candidates:
        for route in routes_for(candidate):
            if route.get("route_kind") != "LEXICAL_SOURCE_READOUT":
                for node in route["nodes"]:
                    admit(node["id"])
    queue, seen = deque(endpoints), set(endpoints)
    while queue and len(selected) < capacity:
        at = queue.popleft()
        j = indices[at]
        predecessors = sorted(zip(incoming.indices[incoming.indptr[j]:incoming.indptr[j+1]],
            incoming.data[incoming.indptr[j]:incoming.indptr[j+1]]),
            key=lambda r: (-float(final[r[0]]) * r[1], ids[r[0]]))
        for i, weight in predecessors:
            identity = ids[i]
            if weight > 0 and final[i] > 0 and identity not in seen:
                seen.add(identity)
                if admit(identity):
                    queue.append(identity)
    for starter in flow["starters"]:
        for target in sorted(starter["targets"], key=lambda r: (-r["mass"], r["id"])):
            if target["mass"] > 0:
                admit(target["id"])

    local_readouts = {}
    for candidate in candidates:
        representative = candidate.get("source_semantic_representative")
        if representative:
            for identity in representative["node_ids"]:
                local_readouts.setdefault(identity, []).append(dict(candidate_id=candidate["id"],
                    label=representative["label"], source_span=representative["source_span"],
                    source_observation_id=representative["source_observation_id"],
                    global_identity_authorized=False, factual_support_implied=False))

    def metadata(identity):
        if identity in old:
            return deepcopy(old[identity])
        if identity.startswith("hierarchy:"):
            return dict(id=identity, type=identity.split(":")[1], label=identity.split(":")[1].capitalize() + " group")
        found = [corpus.occurrences[i] for i in corpus.occurrences_by_node.get(identity, [])
            if eligible.unit_mask[corpus.occurrences[i]["unit_index"]]]
        if not found:
            raise ValueError("Displayed semantic state has no eligible source occurrence")
        occurrence = min(found, key=lambda r: (r["label"], r["source_row_id"]))
        return dict(id=identity, type=corpus.nodes[identity]["kind"], label=occurrence["label"])

    nodes = [dict(metadata(identity), mass_index=i, parent_id=parents.get(identity) if parents.get(identity) in selected else None,
        layout_only=False, candidate_ranks=[], source_candidate_ranks=[], final_mass=float(final[indices[identity]]))
        for i, identity in enumerate(order)]
    for node in nodes:
        if node["id"] in local_readouts:
            node["source_candidate_readouts"] = deepcopy(local_readouts[node["id"]])
    node_map = {n["id"]: n for n in nodes}
    proofs = {}
    for row in corpus.edge_rows:
        if not eligible.unit_mask[row["ui"]]:
            continue
        a, b = corpus.node_ids[row["a"]], corpus.node_ids[row["b"]]
        if a in selected and b in selected:
            proofs.setdefault(frozenset((a, b)), []).append(dict(citation=eligible.citation(row["ui"]),
                relation=row["relation"], source_row_id=row["source_row_id"],
                source=a, target=b, original_direction_preserved=True,
                assertion_mode=row.get("native_assertion_mode"),
                assertion_mode_recorded=row.get("native_assertion_mode") is not None,
                source_observation_id=row.get("source_observation_id"),
                target_observation_id=row.get("target_observation_id"),
                route_class=row.get("route_class", "SOURCE_ASSERTION_NO_IDENTITY_AUTHORITY")))
    edges = []
    for a in order:
        i = indices[a]
        for j, weight in zip(matrix.indices[matrix.indptr[i]:matrix.indptr[i+1]], matrix.data[matrix.indptr[i]:matrix.indptr[i+1]]):
            b = ids[j]
            if b not in selected or weight <= 0:
                continue
            kind = _kind(a, b)
            source = proofs.get(frozenset((a, b)), [])
            if kind == "SOURCE" and not source:
                raise ValueError("Semantic numerical transition lacks an eligible native source assertion")
            edges.append(dict(source=a, target=b, kind=kind, transition=float(weight),
                citations=[deepcopy(r["citation"]) for r in source], native_source_assertions=deepcopy(source),
                numerical_transition=True, factual_relation_certified=False))
    source_positions = np.asarray([indices[e["source"]] for e in edges], dtype=int)
    transitions = np.asarray([e["transition"] for e in edges])
    positions = [indices[n] for n in order]
    reference = CategoryReference(matrix, prior, ids)
    before, values, frames = prior.copy(), prior.copy(), []
    transpose = matrix.T.tocsr()
    for iteration in range(horizon + 1):
        if iteration:
            before = values
            values = (1-alpha)*prior + alpha*(transpose @ before)
        weights = values[positions]
        edge_mass = alpha*before[source_positions]*transitions if iteration else np.zeros(len(edges))
        total, shown = float(values.sum()), float(weights.sum())
        if shown > total + 1e-12:
            raise ValueError("Projected mass exceeds actual full mass")
        frames.append(dict(iteration=iteration, weights=weights.tolist(), edge_mass=edge_mass.tolist(),
            total_mass=total, other_mass=max(0., total-shown), restart_mass=float((1-alpha)*prior.sum()) if iteration else 0.,
            unshown_transport=max(0., alpha*float(before.sum())-float(edge_mass.sum())) if iteration else 0.,
            category_reference=reference.frame(values)))
    if not np.allclose(values, final, rtol=1e-12, atol=1e-14):
        raise ValueError("Current visualization does not reproduce the native final vector")
    starters = deepcopy(flow["starters"])
    for starter in starters:
        starter["targets"] = [t for t in starter["targets"] if t["id"] in selected]
        starter["omitted_target_mass"] = max(0., starter["total_mass"]-math.fsum(t["mass"] for t in starter["targets"]))
    documents = {}
    for node in nodes:
        for oi in corpus.occurrences_by_node.get(node["id"], []):
            occurrence = corpus.occurrences[oi]
            if not eligible.unit_mask[occurrence["unit_index"]]:
                continue
            proof = eligible.citation(occurrence["unit_index"])
            document = documents.setdefault(proof["document_id"], dict(id=proof["document_id"], title=proof["document_id"],
                date=proof["date"], visible_node_ids=[], candidate_ids=[], source=proof))
            if node["id"] not in document["visible_node_ids"]:
                document["visible_node_ids"].append(node["id"])
    value = dict(version=VERSION, status="RECORDED", task=case["task"], case_id=case["case_id"], config=record["config"],
        reading_id=reading, nodes=nodes, edges=edges, frames=frames, starters=starters, candidates=candidates,
        documents=list(documents.values()), iterations=horizon, alpha=alpha, drawing_limit=limit,
        drawing_count=len(nodes)+len(starters)+1, real_kernel_states=len(ids), padded_states=0,
        ranking_changed=False, answer_key_used=False, correctness_probability=False,
        source_pages_are_states=flow.get("source_pages_are_states", False),
        scope=dict(corpus=case["corpus"], strictly_before=case["date"], whole_origin_excluded=case["document_id"],
            binding=deepcopy(record["resource_binding"])),
        resource_binding=binding, source_case_sha256=record["sha256"], source_expanded_sha256=digest(expanded),
        native_snapshot_sha256=snapshot["sha256"],
        disclosures=["Graph mass measures discovery relevance. Support is decided from original eligible quotations."])
    for candidate in candidates:
        for key, field in (("endpoint_ids", "candidate_ranks"), ("source_contributor_ids", "source_candidate_ranks")):
            for identity in candidate.get(key, []):
                if identity in node_map:
                    node_map[identity][field].append(candidate["rank"])
        observed = dict(candidate, endpoint_ids=candidate["presentation_target_ids"], source_contributor_ids=[])
        candidate["contributor_explanation"] = dict(contributor_cone(value, observed, horizon),
            native_readout_unchanged=True, endpoint_ids=candidate["presentation_target_ids"],
            mass_basis="Actual presentation source-context states, not constructed-fill correctness")
        if candidate.get("source_semantic_representative"):
            for identity in candidate["presentation_target_ids"]:
                if identity in node_map:
                    node_map[identity]["source_candidate_ranks"].append(candidate["rank"])
        for proof in candidate.get("sources", []):
            document = documents.setdefault(proof["document_id"], dict(id=proof["document_id"], title=proof["document_id"],
                date=proof["date"], visible_node_ids=[], candidate_ids=[], source=deepcopy(proof)))
            if candidate["id"] not in document["candidate_ids"]:
                document["candidate_ids"].append(candidate["id"])
    value["documents"] = list(documents.values())
    # Retain the original witnesses, but choose the public route display using
    # the existing source-checked, low-detour diversity selector. It observes
    # this new drawing; it neither changes the native walk nor adds an edge.
    render_routes = _route_renderer(snapshot, (matrix, prior, final, indices))
    for candidate in candidates:
        candidate["native_represented_routes"] = deepcopy(candidate.get("represented_routes", []))
        render_routes(value, candidate)
    return with_solver_stopping(value, result)


def guide(projection, candidate_id, route_index=0):
    if type(route_index) is not int or not 0 <= route_index < 3:
        raise ValueError("Unknown represented route")
    candidate = next((c for c in projection["candidates"] if c["id"] == candidate_id), None)
    if candidate is None or route_index >= len(routes_for(candidate)):
        raise ValueError("No saved route for this exact candidate")
    route = deepcopy(routes_for(candidate)[route_index])
    return dict(case_id=projection["case_id"], corpus=projection["scope"]["corpus"], scope=deepcopy(projection["scope"]),
        route=route, candidate=deepcopy(candidate), graph_binding=deepcopy(projection["scope"]["binding"]),
        resource_binding=deepcopy(projection["resource_binding"]), source_version=projection["source_case_sha256"],
        guidance_is_entailment=False)


def compact(projection, *, budget=256):
    """Slice the saved drawing; retain real targets, inputs, routes and parents."""
    if type(budget) is not int or not 32 <= budget <= 1024:
        raise ValueError("Compact drawing budget must be 32 through 1024")
    nodes = {n["id"]:n for n in projection["nodes"]}
    selected = set()
    capacity = budget-len(projection["starters"])-1

    def admit(identity, required=False):
        chain, seen, at = [], set(), identity
        while at and at in nodes:
            if at in seen:
                raise ValueError("Cyclic current drawing hierarchy")
            seen.add(at)
            chain.append(at)
            at = nodes[at].get("parent_id")
        if len(selected | set(chain)) > capacity:
            if required:
                raise ValueError("Required result routes exceed the compact drawing budget")
            return False
        selected.update(chain)
        return True

    for candidate in projection["candidates"]:
        for identity in candidate.get("presentation_target_ids", []):
            admit(identity, True)
        for route in routes_for(candidate):
            if route.get("route_kind") != "LEXICAL_SOURCE_READOUT":
                for node in route["nodes"]:
                    admit(node["id"], True)
    for starter in projection["starters"]:
        for target in sorted(starter["targets"], key=lambda t:(-t["mass"],t["id"])):
            if target["id"] in nodes and admit(target["id"], True):
                break
    for node in sorted(nodes.values(), key=lambda n:(-n["final_mass"],n["id"])):
        admit(node["id"])
    chosen = [n for n in projection["nodes"] if n["id"] in selected]
    positions = [n["mass_index"] for n in chosen]
    edge_positions = [i for i,e in enumerate(projection["edges"]) if e["source"] in selected and e["target"] in selected]
    value = {k:deepcopy(v) for k,v in projection.items() if k not in {"nodes","edges","frames","documents"}}
    value["nodes"] = [dict(deepcopy(n),mass_index=i) for i,n in enumerate(chosen)]
    value["edges"] = [deepcopy(projection["edges"][i]) for i in edge_positions]
    value["frames"] = []
    for original in projection["frames"]:
        weights = [original["weights"][i] for i in positions]
        edges = [original["edge_mass"][i] for i in edge_positions]
        frame = {k:deepcopy(v) for k,v in original.items() if k not in {"weights","edge_mass","other_mass","unshown_transport"}}
        frame.update(weights=weights,edge_mass=edges,other_mass=max(0.,original["total_mass"]-math.fsum(weights)),
            unshown_transport=original["unshown_transport"]+math.fsum(original["edge_mass"])-math.fsum(edges))
        value["frames"].append(frame)
    for starter in value["starters"]:
        starter["targets"] = [t for t in starter["targets"] if t["id"] in selected]
        starter["omitted_target_mass"] = max(0.,starter["total_mass"]-math.fsum(t["mass"] for t in starter["targets"]))
    value["documents"] = []
    for document in projection["documents"]:
        item = deepcopy(document)
        item["visible_node_ids"] = [n for n in item["visible_node_ids"] if n in selected]
        if item["visible_node_ids"] or item.get("candidate_ids"):
            value["documents"].append(item)
    for candidate in value["candidates"]:
        explanation = candidate.get("contributor_explanation", {})
        explanation["graph_node_ids"] = [n for n in explanation.get("graph_node_ids", []) if n in selected]
        explanation["graph_edges"] = [e for e in explanation.get("graph_edges", []) if e["source"] in selected and e["target"] in selected]
    value.update(version="current-kernel-compact-inspection/1",drawing_limit=budget,
        drawing_count=len(chosen)+len(value["starters"])+1,expanded_drawing_count=projection["drawing_count"],
        visual_slicing_only=True,native_kernel_or_ranking_changed=False)
    return value
