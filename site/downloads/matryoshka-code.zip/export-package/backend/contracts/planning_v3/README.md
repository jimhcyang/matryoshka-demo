# Shared Planning V3

The current v5 pipeline reuses this wire contract through `planning_v5.py`.
Its separate `retrieval_v5.py` executes **only atom text and direct-question
text**, never an extra whole-query search or an empty-plan whole-query fallback.
Full visible context is still available for construction and source ownership.
The v3 search-policy description below applies to the frozen v3 control, not v5.

Only `planning_v3.py`, its tests, and this contract directory implement this
profile. Old plans, prompts, caches, runners and validators are not rewritten.

`ARMS = ("llm_readings", "llm_atoms", "llm_local")`. Arm D, the original-src
reference, is outside this planner. A has model grammar readings and direct
context/grammar questions. B has no readings or questions. C has local-only
readings and no questions. All three share the **same** projected KG 2.32
extraction and **identical** compiled atoms. No model arm receives local reading
supplementation or local atom fallback. One separately receipted model repair of
invalid shared atoms is allowed, with the same public query and diagnostic;
both raw outputs remain saved. A subsequent failure stays explicit.

## API

`select_context(case, policy="paragraph")` returns a bounded public `case` and
an offset mapping to the supplied query. Main must use that returned case in
the public catalog and subsequent planning. Paragraphs over the versioned
200-word presentation threshold automatically use `focal_window`: the focal
sentence plus at most one adjacent sentence each way, within its paragraph and
budget. Preceding context is considered first. A focal sentence may exceed the
budget; it is never clipped. This threshold is not support/retrieval-tuned.
H/R retain the complete query. Selection is literal and contiguous; no source
documents, hidden answers, or other metadata are read. The physical sentence
splitter is deterministic, not a semantic sentence/exhaustiveness certificate.

`make_plans(case, api_root, cap=25, execute=True, *, output_root=None)` returns the three arm plans,
or raises `PlanFailure` with the diagnostic bundle. Redaction inputs must
already be one selected source paragraph. `validate_plan(plan, case)` validates
the v3 view. `prepare(..., execute=False)` also exposes raw outputs, receipts,
failures and shared hashes. `get_plans(bundle)` requires all three arms READY.
`execute=False` is strictly cache-only, including when an API client is passed.
Catalog/release writing belongs to main; optional `output_root` saves a new
content-addressed bundle, never an old plan. Main controls approved pilot cases.

## Requests And Provenance

There are three requests per case: shared extraction, shared atoms, and A's
readings/questions. Every prompt is one concise paragraph; schemas are separate.
Extraction uses the **actual** `contracts/kg_extraction_2_32.json#/schema`, not a
reduced substitute. Its SHA and each prompt/schema SHA are recorded per request.
The existing API request builder/cache and `Budget` remain authoritative for the
shared cap of $25. A per-call-bundle reservation limit defaults to $1. Pilot
callers must pass their remaining cumulative pilot allowance to `prepare`.
No paid call is made by import, validation, tests, or cache-only execution.

Each plan records `shared_atoms_sha256 = digest(plan["atoms"])` and
`shared_extraction_sha256 = digest(plan["extractions"])`; raw shared stage hashes
are recorded separately. Identical A/B/C inputs therefore have identical atom
and extraction hashes. Existing query projection and quarantine are applied only
to extraction, with QC; atoms/readings/questions are validated, never rewritten
or silently repaired. Reversible case/whitespace/terminal-punctuation quotation
alignment is logged with original text and literal source offsets; it never
changes the model's proposition. Raw outputs remain in bundles/API caches.

Reading `notes` is the plain explanation; legacy structural fields are routing
metadata, not display prose. Known focal boundary strings are compiled directly,
not guessed or recopied by the model; grammatical alternatives stay model-authored.
Ordinary prose novelty is an audit, not a rejection or proof of faithfulness.
Source-bound names/dates/quantities, literal anchors and closed forms are checked.
Questions have no quota: a genuinely empty list is valid. Leads contain full `question` text and links, never
keyword fields. Executable text is the full masked-visible query, atom text, or
lead question; no explanation, type code, or extracted description is executable.
Old keyword-oriented candidate validators need an explicit v3 adapter; these
views do not pretend to be old v2 plans.

### Closed Joint Grammar Constraints (3.1)

Model readings author `referent_kind` from person/organization/place/quantity/
property/action/any, `grammatical_number` from singular/plural/unknown, and a
literal, mask-free `cue_quote`. A known kind or number requires a nonempty cue;
the cue is a hypothesis license, not proof of coreference or identity. Unknown
values are retained rather than forcing a referent. Joint alternatives may share
a form when kind, number, or finiteness differs. No Cartesian product is added.

Canonical views expose these as `target_kind`, `grammatical_number`, and
`kind_cue_quote`; only `notes` is user-facing prose. The local C arm preserves
the local compiler's native target kind and any supplied number, defaulting only
an absent number to unknown. It does not copy model constraints. The earlier
all-any routing and untyped-reading runs remain preserved; schema revision 3 is
archived as `readings.r3.schema.json`.

Lexical/name/scope guards are conservative checks, not semantic entailment,
proof of model knowledge boundaries, or a guarantee of complete atom coverage.

## Global Model Profile And Resume

The selected global `sol` profile uses `gpt-6-luna` for the shared extraction and
`gpt-6.1-sol` for shared atoms and A's readings/questions. It is not selected per
case. Both the matched pre-kind and final closed-kind five-context pilots had
Sol validate 5/5 versus Luna 0/5. Final closed-kind failures were unbound/opaque
kind cues, a nonliteral question anchor, and an invalid metadata atom. The
matched contract/public inputs were identical; only atoms/readings models
differed, with extraction shared. This is a small development
planning-operability check, not retrieval/answer evaluation or a model
generalization claim. The final comparison is saved in
`pilot_first5_matched_kind_profiles.json`. Failed
attempts and old negative profiles remain under `data/development_v3` and in the
API ledger. `readings.r1.schema.json` preserves the initial boundary-copy schema.

Canonical plan receipts exclude cache-hit flags and reservation estimates;
those remain only in raw bundles. Fresh versus cache-only replay must yield
identical plan hashes. Shared atom/extraction rows have no per-arm overrides.

## Confirmed Provider Format Failure

`provider-format-retry/1` permits one operational format retry per stage, including
across an atom semantic-repair call. It requires an exact saved request, a
`PAID_INVALID_OUTPUT` receipt with recorded usage, and its matching raw response
marked `incomplete` with reason `max_output_tokens`. Legacy response/history
archives are matched by response ID and usage; new per-attempt archives are
preferred. No partial model JSON is parsed, repaired, or substituted.

The retry preserves question, schema, prompt, model and 4096-token cap. Only an
operational `format_retry` payload object is added, producing a different wire
key. Raw bundles retain the incomplete response and both receipt/request IDs.
Resume reuses the deterministic retry cache, not a second payment for the original
wire. A second format failure, other paid invalid output, pending reservation or
unknown network/billing status stops for explicit review. No blind 8192 increase
or generic transport retry is implemented. This is separate from source/semantic
validation; it cannot make an unlicensed atom or reading valid.

Sentence-initial grammatical prefixes in prose name-span checks use spaCy POS,
not case-specific word exceptions. An AUX question prefix is not a name, while
an unseen PROPN sequence remains rejected.

### Atom Transport Revision 4

`required-first/1` places the existing `required` boolean first in the atom
schema and adds a tiny compact complete-JSON shape to the one-paragraph prompt.
All fields, validation semantics, models, source/scope guards and the 4096-token
cap are unchanged. Flags remain model-authored; no task-specific flag compilation
or local atom fallback was introduced. The preceding schema and prompt are
archived as `atoms.r3.schema.json` and `atoms.r3.prompt.txt`. The new prompt and
schema fingerprints produce distinct cache keys without overwriting old records.

The motivating initial and format-retry responses both exhausted 4096 tokens
padding whitespace after a closed `source_quote`, before the final boolean.
One same-public-payload diagnostic with the revised transport completed on its
first call, used 174 output tokens, and passed unchanged source validation. Its
request key is
`857d0a26bd79674428c49b869b8e9095adf27ef137ec029d73b4facd55ed80c3`;
receipt `2c91b1240bdb424d86420e4164246739.json` records $0.002664 under workspace
rates. The complete diagnostic is
`data/development_v3/diagnostics/atom_required_first_212cd269dba5b005.json`.
This single combined field-order/prompt test is not proof of the provider's
failure mechanism or a general reliability result. No answer keys or grades
were read. Restart preparation to load this revision; in-process contracts are
cached. The separately bounded format-retry policy remains unchanged.

### Source-Quoted Possessive Boundaries

`source-quoted-possessive-boundary/1` prevents a capitalized-name regex from
combining an already source-quoted possessor with a following independent named
argument. A split requires a parsed `PART`/`case` genitive and a literal source
match for the complete possessor plus possessive marker. Each resulting name
still requires its own contiguous source match. Whole named-entity checks stay
unchanged; lexical apostrophes in surnames are not split. An unseen possessor,
recombined title/name, or recombined destination remains rejected. This is a
syntactic name-boundary check, not certification of the question's relationship
or factual truth. Raw questions are never rewritten and no API repair is needed
for a cached output that passes the corrected guard.

### Calendar Presentation Alignment

`CALENDAR_SPELLING_DAYPART_ALIGNMENT/1` recognizes English month names and their
standard abbreviations for a numeric day, retaining any explicit four-digit
year. An adjoining morning/afternoon/evening/night may precede or follow the
same date. The complete expression must match one contiguous source span;
month/day/year/daypart tokens cannot be assembled from unrelated dates. No
year, changed day, timezone, relative-date resolution or quantity conversion is
inferred. Each nonliteral alignment is logged in interpretation QC with the
unchanged model span and exact raw source quote/offsets. Raw questions stay
unchanged. Literal name/date/quantity matches have whole-token boundaries, so a
smaller number cannot be licensed by a longer one. Other date/quantity errors
remain rejected. This adds no model call or readings repair and does not change
the maximum-call preview.

### Local Personal Possessive Alternative

`local-personal-possessive/1` changes only the local C interpretation view.
Existing `any` possessives remain. A tentative additional `person`/`singular`
joint reading requires an immediate bare singular carrier followed by `; he`
or `; she`, with spaCy marking the pronoun as a subject of a verbal predicate
in the same sentence. There must be one visible common-noun host subject, no
intervening opaque argument, no preceding proper/named or pronominal competitor
in the visible paragraph, and no coordinated/appositional personal subject.
Other structures abstain, including distant pronouns, quoted pronoun mentions,
conditional/intervening clauses, paragraph breaks, `it`, `they` and `you`.
No name, entity database, model reading, corpus evidence, answer or ranking is
consulted. Later names cannot license or cancel this earlier grammatical cue.

The added reading copies the original form, attachment and finiteness, records
the literal pronoun as its cue, and explicitly leaves coreference unresolved.
An existing plural constraint is not overridden. When a cue alternative is
licensed, readings are stably ordered by the number of known kind/number
constraints with literal cues: the person/singular alternative precedes its
unconstrained fallback, and ties preserve compiler order. This is a declared
grammatical informativeness policy, not a candidate-ranking or answer policy.
This is not an identity assertion or proof of a human antecedent; the common-noun
host and the pronoun may still refer to other discourse participants. No
certainty or person-only replacement is claimed. All local views now retain
the full visible focal left/right strings; raw compiler records remain intact.

This revision does not change the shared planner version 3.1, prompts, API
schemas, shared atoms/extractions, model arm or call limits. Local plan identities
and execution bindings change: regenerate the 45 derived plan views from the
existing raw caches and publish a new release. Do not rewrite the old release.
The regeneration can be cache-only; no full preparation is launched by this
local change.

New C plans alone declare
`source_licensing.local_policy = "local-personal-possessive/1"`. Validation
dispatches on this saved policy rather than the current default. An absent
field selects the exact legacy base compiler view: no personal alternative and
the original compiler boundary lengths, not the new full-context strings.
Explicit unknown/null policies and local-policy fields on A/B are rejected.
Both declared views are recomputed and compared exactly. Old accepted releases,
native checkpoints, manifests and code archives are never migrated or resealed.
Development plans produced with the new view before the policy field existed
must be regenerated from raw caches; they cannot be mislabelled as legacy.
