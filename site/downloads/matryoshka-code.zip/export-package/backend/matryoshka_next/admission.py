"""Source-aware proposal admission/naturalness review, NEVER ordinary inference.

This module prepares and binds a lead-owned model call. It imports no API client,
workflow, planner, retrieval engine, grades or execution artifacts.
"""

from copy import deepcopy
from datetime import date
import re

from .sourcebank import digest, text_sha

VERSION = "source-aware-semantic-naturalness-admission/1.2"
EXPOSURE = "SOURCE_AWARE_QUESTION_EDITING_NOT_BLIND_INFERENCE_OR_NATIVE_ASSESSMENT"
PUBLIC_FIELDS = ("case_id", "corpus", "task", "query", "document_id", "date", "focal_marker")

PROMPT = """You are an independent SOURCE-ADMISSION and NATURALNESS critic/editor
for proposed historical analyst questions. Use ONLY the supplied exact source
frames, original public query, birth quotations and declared alteration. Source
annotations, when mentioned, are fallible. No external facts, remembered history,
retrieval assumptions or desired outcome may supply a premise.

ADMIT or HOLD each proposal. This is NOT an answer, atomizer, slot-reading planner,
evidence verdict, recovery forecast or ranking task. Do not produce atoms,
readings, leads, search terms, solver suggestions, native verdicts or ranks.

Questions such as 'What does the report/cable/bulletin say about ...?' are usually
inapt: the entire originating document is excluded as solver evidence. Prefer a
coherent historically situated question about the substantive events, relations,
decisions, positions or qualified statements. An editorial 'the report says'
question wrapper may be replaced by a natural historical analyst request, but
NEVER erase an actual speaker, report, belief, forecast, negation, condition,
uncertainty, time qualification or planned-versus-completed distinction. Do not
invent an anonymous reporting actor. Reconstruct the same intended substantive
scope, not an easier/narrower claim. No rewrite for matcher convenience or likely
success. Do not split one fact into artificial required components. HOLD an
unfaithful or unclear scope rather than quietly changing its meaning.

CIB H/R: the target fact MUST depend on the focal earlier-hidden/later-revealed
content. A visible subject/owner/attachment may legitimately come from licensed
visible context; not all query words must be inside the hidden unit. Cite focal
target content and visible-owner/operator context separately. Visible-only facts
are not valid hidden targets. Another unknown neighboring unit is NOT licensed
context. Full paired LATER pages are inspection-only: they cannot license a
target, owner, date, condition or other query qualification absent from the focal
reveal and licensed earlier-visible context. Cite the actual licensed frame;
do not borrow another later reveal's operator even if its text is literally present.
For cable sources preserve the supplied SECRET-origin scope and classifications;
do not invent source admission, dates or identities.

Redaction: inspect the literal mask/key and source context for substantive,
complete, nontrivial scope. Reject header/acronym expansion/partial-title/name or
visible-answer/alias giveaways, not merely short or uppercase meaningful words.
Source-faithful synthetic masks must remain labeled synthetic, not authentic
declassification redactions. Do not rewrite the actual masked source quotation or
change its focal mask, hidden extent or neighboring unknowns. HOLD if a different
source window/mask is needed. A synthetic source-faithful mask is not a falsified
proposition. Preserve a declared authored counterhypothesis/alteration as such;
do not silently invent or 'repair' it into a factual source assertion.

For each row provide exact verbatim justification quotes with provided source_id
and purpose. Cite complete relevant operator/owner context, not only a suggestive
word. Quotes must be unambiguous exact substrings of their own source frame; no
normalization or offsets guessed across concatenated frames. The local binder
will compute offsets. ADMIT requires a substantive target citation; CIB target
citations must be in the focal reveal. All source judgments remain advisory,
not gold truth or measured performance. Missing earlier solver evidence is not
an admission failure or opposition. Actual strictly earlier DIFFERENT-origin
source quotations may be supplied ONLY for demo difficulty/copy review. They are
not native retrieval outcomes, grades or ranks, and cannot supply an originating
target or its missing qualification. A complete hidden-bearing proposition or
source-window copy differing only in layout/punctuation stays HOLD even if a
model calls it nontrivial. A repeated answer name, isolated target label or bare
prior-hit flag is NOT such a copy and must not exclude a recoverable question.
Preserve actual owners, negation, numbers and reporting operators in comparisons.
Do not delete the canonical redaction target:
this only holds the new demonstration nomination. No-match is not source absence.

Return exactly one row per supplied proposal_id. KEEP uses an empty revised_query;
REVISE supplies the full natural revised query and certifies preserved meaning.
Any rewrite receives a fresh case ID downstream; no old grade transfers. When
uncertain about meaning, source dependence, mask difficulty or alteration, HOLD.
"""


def _obj(fields):
    return dict(type="object", properties=fields, required=list(fields), additionalProperties=False)


def schema():
    string = dict(type="string")
    citation = _obj(dict(source_id=string, quote=string, purpose=dict(type="string", enum=[
        "TARGET", "VISIBLE_OWNER_CONTEXT", "OPERATOR_OR_QUALIFICATION", "MASK_DIFFICULTY"])))
    row = _obj(dict(proposal_id=string, decision=dict(type="string", enum=["ADMIT", "HOLD"]),
        reason=string, action=dict(type="string", enum=["KEEP", "REVISE"]), revised_query=string,
        meaning_preserved=dict(type="boolean"), naturalness=dict(type="string", enum=["NATURAL", "EDITED_NATURAL", "UNCERTAIN"]),
        source_faithfulness=dict(type="string", enum=["FAITHFUL", "DECLARED_ALTERATION_PRESERVED", "UNFAITHFUL", "UNCERTAIN"]),
        hidden_dependence=dict(type="string", enum=["FOCAL_REVEAL_REQUIRED", "VISIBLE_ONLY", "NOT_CIB_HR", "UNCERTAIN"]),
        mask_check=dict(type="string", enum=["NOT_REDACTION", "NONTRIVIAL_COMPLETE", "TRIVIAL_OR_INCOMPLETE", "UNCERTAIN"]),
        alteration_status=dict(type="string", enum=["SOURCE_FAITHFUL", "DECLARED_ALTERATION_PRESERVED", "UNDECLARED_OR_NEW_MEANING_CHANGE", "UNCERTAIN"]),
        justifications=dict(type="array", items=citation)))
    return _obj(dict(reviews=dict(type="array", items=row)))


SCHEMA = schema()


def _frame(source_id, text, *, role, coordinate_space, start=0, provenance=None):
    if not isinstance(text, str) or not text:
        raise ValueError("Nonempty literal source frame required")
    return dict(source_id=source_id, text=text, frame_sha256=text_sha(text), role=role,
                coordinate_space=coordinate_space, parent_start=start, provenance=deepcopy(provenance or {}))


def source_frames(pack):
    """License raw owner context without exposing other hidden units as visible."""
    pid = pack["pack_id"];context = pack["literal_context"]
    frames = [_frame(pid+":focus", context["text"], role="TARGET_AND_QUALIFICATION",
        coordinate_space=context["coordinate_space"], start=context["start"],
        provenance=dict(source_id=pack["source"]["source_id"], source_file_ref=pack["source"]["source_file_ref"],
                        parent_text_sha256=context["parent_text_sha256"],
                        parent_text_hash_contract="RAW_UTF8_SHA256",
                        unit_index=pack["source"].get("unit_index"),
                        canonical_unit_sha256=pack["source"].get("canonical_unit_sha256"),
                        raw_document_start=pack["source"].get("raw_document_start")))]
    fragments = pack["source"].get("context_fragments", [])
    for fragment in fragments:
        if fragment.get("focal_revealed_unit") or fragment.get("adjacent_unknown_preserved"):
            continue
        if fragment.get("visible_context_can_bind_owner") is True and fragment.get("text"):
            if text_sha(fragment["text"]) != fragment["sha256"]:
                raise ValueError("Visible context frame changed")
            provenance={k:deepcopy(fragment[k]) for k in ("canonical_page_id","unit_index","field","unit_record_sha256") if k in fragment}
            provenance["source_file_ref"]=deepcopy(pack["source"]["source_file_ref"])
            frames.append(_frame(pid+":visible_unit_"+str(fragment["unit_index"]),fragment["text"],
                role="VISIBLE_OWNER_AND_QUALIFICATION",coordinate_space=fragment["coordinate_space"],
                provenance=provenance))
    # Compatibility with the source IDs used by the existing nomination caller:
    # only literal SHARED text is licensed; a neighboring later reveal is not.
    for i, unit in enumerate(pack["source"].get("adjacent_units", [])):
        if unit.get("unit_type") == "shared_text" and unit.get("text"):
            focal_index=pack["source"].get("unit_index")
            unit_index=(focal_index-1 if i==0 and focal_index>0 else focal_index+1) if type(focal_index) is int else None
            frames.append(_frame(pid+":context"+str(i),unit["text"],role="VISIBLE_OWNER_AND_QUALIFICATION",
                coordinate_space="INDEPENDENT_LITERAL_ADJACENT_SHARED_UNIT",
                provenance=dict(source_id=pack["source"]["source_id"],unit_index=unit_index,field="text",
                    unit_record_sha256=digest(unit),source_file_ref=deepcopy(pack["source"]["source_file_ref"]))))
    raw = pack.get("raw_document_context")
    if raw:
        if text_sha(raw["text"]) != raw["sha256"]:
            raise ValueError("Original cable context changed")
        frames.append(_frame(pid+":raw_context",raw["text"],role="SOURCE_CONTEXT_AND_QUALIFICATION",
            coordinate_space=raw["coordinate_space"],start=raw["start"],
            provenance=dict(raw_file_ref=pack["source"].get("raw_file_ref"))))
    pair = pack["source"].get("paired_pages", {})
    for side in ("earlier", "later"):
        text = pair.get(side+"_text")
        if text:
            if text_sha(text) != pair[side+"_sha256"]:
                raise ValueError("Physical paired source page changed")
            frames.append(_frame(pid+":"+side+"_page",text,
                role="VISIBLE_PAGE_CONTEXT" if side=="earlier" else "LATER_PAGE_INSPECTION_ONLY_NOT_TARGET",
                coordinate_space="PHYSICAL_PAIRED_PAGE_LITERAL_TEXT",
                provenance=dict(page=pair.get(side+"_page"),file_ref=pair.get("file_ref"))))
    return frames


def _exact(frame, quote):
    if not isinstance(quote, str) or not quote:
        raise ValueError("Nonempty exact source quotation required")
    start = frame["text"].find(quote)
    if start < 0 or frame["text"].find(quote,start+1) >= 0:
        raise ValueError("Missing or ambiguous literal source quotation")
    return dict(source_id=frame["source_id"],text=quote,start=start,end=start+len(quote),
        frame_sha256=frame["frame_sha256"],quote_sha256=text_sha(quote),coordinate_space=frame["coordinate_space"],
        parent_start=frame["parent_start"]+start,source_role=frame["role"],provenance=deepcopy(frame["provenance"]))


def _queries(row):
    values = [row[k] for k in ("query", "public_query") if isinstance(row.get(k),str)]
    if isinstance(row.get("case"),dict) and isinstance(row["case"].get("query"),str):values.append(row["case"]["query"])
    if not values or len(set(values)) != 1 or not values[0].strip():
        raise ValueError("One unambiguous complete public query required")
    return values[0]


def _copy_signature(text):
    # Keep number punctuation, negation/contractions and quotation/parenthesis
    # operators. Ignore sentence punctuation, case and layout, not lexical facts.
    return tuple(re.findall(r"\d+(?:[.,:/-]\d+)*|\w+(?:[-'\u2019]\w+)*|[\"\u201c\u201d\u2018\u2019()\[\]]",text.casefold()))


def _eligible_prior_sources(pack):
    rows=[];issues=[]
    allowed=("source_id","document_id","date","match_kind","text","context","start","end","context_start","context_end",
             "source_file_ref","source_text_sha256","context_sha256","coordinate_space","locator")
    for index,citation in enumerate(pack.get("prior_diagnostics",{}).get("citations",[])):
        try:
            when=citation["date"];origin_when=pack["origin"]["date"]
            if date.fromisoformat(when).isoformat()!=when or date.fromisoformat(origin_when).isoformat()!=origin_when:
                raise ValueError("non-ISO prior date")
            if (when>=origin_when or citation.get("document_id")==pack["origin"]["document_id"]
                    or citation.get("strictly_earlier") is False or citation.get("whole_origin_excluded") is False):
                raise ValueError("not strictly earlier different-origin source")
            text=citation.get("context") or citation.get("text")
            if not isinstance(text,str) or not text:raise ValueError("missing actual prior source quotation")
            if citation.get("context_sha256") and text_sha(citation["context"])!=citation["context_sha256"]:
                raise ValueError("prior context hash mismatch")
            row={k:deepcopy(citation[k]) for k in allowed if k in citation}
            row.update(source_id=citation.get("source_id","prior_"+str(index)),context=text,
                       strictly_earlier=True,whole_origin_excluded=True,source_support_assessed=False)
            rows.append(row)
        except (KeyError,ValueError,TypeError) as error:
            issues.append(dict(citation_index=index,reason=str(error)))
    return rows,issues


def source_difficulty_hold(pack,*,literal_window=None,details=False):
    """Hold a full hidden-bearing source-context copy, NEVER a bare name hit.

    This is a conservative source-copy/difficulty check, not a novelty or support
    certificate. A false result does not establish that the fact is new. The
    sourcebank's prior-hit boolean and single overlapping keys are not vetoes.
    """
    target=pack.get("authentic_redaction")
    hidden=target.get("answer") if target else None
    labels={_copy_signature(hidden)} if hidden else set()
    contexts=[]
    if target and target.get("query") and target.get("focus_marker") and target.get("answer"):
        contexts.append(("AUTHENTIC_COMPLETE_UNMASKED_QUESTION",target["query"].replace(target["focus_marker"],target["answer"])))
    if literal_window is not None:
        contexts.append(("VERIFIED_LITERAL_QUESTION_WINDOW",literal_window))
    focal=pack["literal_context"]["text"]
    fragments=pack.get("source",{}).get("context_fragments",[])
    if pack.get("difficulty",{}).get("fragment_pack_incomplete_context"):
        if (fragments and any(f.get("visible_context_can_bind_owner") for f in fragments)
                and all(isinstance(f.get("text"),str) and not f.get("adjacent_unknown_preserved") for f in fragments)
                and all(b["unit_index"]==a["unit_index"]+1 for a,b in zip(fragments,fragments[1:]))):
            contexts.append(("CONSECUTIVE_LITERAL_VISIBLE_OWNER_AND_REVEAL_FIELDS","".join(f["text"] for f in fragments)))
    else:
        contexts.append(("COMPLETE_SUPPLIED_FOCAL_CONTEXT",focal))
    contexts=[(kind,text,_copy_signature(text)) for kind,text in contexts if _copy_signature(text) and _copy_signature(text) not in labels]
    prior,issues=_eligible_prior_sources(pack);matches=[]
    for citation in prior:
        # The complete supplied prior context keeps a reporting/negative envelope.
        # Do not replace it with an isolated answer-label or stripped subquote.
        signature=_copy_signature(citation["context"])
        for kind,text,expected in contexts:
            if signature==expected:
                matches.append(dict(source_id=citation["source_id"],document_id=citation["document_id"],date=citation["date"],
                    target_context_kind=kind,target_context_sha256=text_sha(text),prior_context_sha256=text_sha(citation["context"]),
                    rule="FULL_CONTEXT_LEXICAL_IDENTITY_CASE_LAYOUT_SENTENCE_PUNCTUATION_ONLY"))
    result=dict(hold=bool(matches),matches=matches,eligible_prior_sources=prior,invalid_prior_source_notes=issues,
                declared_prior_literal_control=pack.get("difficulty",{}).get("prior_literal_hit_control",False),
                flag_or_answer_label_alone_is_veto=False,canonical_population_modified=False,
                no_match_does_not_establish_novelty_or_absence=True)
    return result if details else result["hold"]


def bind_mask_window(frame, query, marker, hidden, mask_map=None):
    """Validate a supplied literal crop, never generate a new question window.

    start/end/hidden_start/hidden_end are offsets in the full focus frame text,
    as emitted by curation v3. source_text_sha256 uses the shared JSON-string
    digest, not a raw UTF-8 byte digest; both contracts are returned explicitly.
    """
    raw=frame["text"]
    if not isinstance(hidden,str) or not hidden or not marker or query.count(marker)!=1:
        raise ValueError("Redaction requires a unique focal marker and nonempty hidden span")
    unmasked=query.replace(marker,hidden)
    if mask_map is not None:
        if (mask_map.get("source_id")!=frame["source_id"] or mask_map.get("source_text_sha256")!=digest(raw)
                or mask_map.get("literal_roundtrip") is not True):
            raise ValueError("Mask map source/hash/roundtrip binding changed")
        a,b,h0,h1=(mask_map.get(k) for k in ("start","end","hidden_start","hidden_end"))
        if any(type(v) is not int for v in (a,b,h0,h1)) or not 0<=a<=h0<h1<=b<=len(raw):
            raise ValueError("Mask map offsets are outside the literal focus")
        if mask_map.get("text")!=raw[a:b]:raise ValueError("Mask map literal window changed")
    else:
        a=raw.find(unmasked)
        if a<0 or raw.find(unmasked,a+1)>=0:raise ValueError("Cropped question is not a unique exact source window")
        b=a+len(unmasked);h0=a+query.index(marker);h1=h0+len(hidden)
    if raw[a:b]!=unmasked or raw[h0:h1]!=hidden or h0-a!=query.index(marker):
        raise ValueError("Question/key does not roundtrip at the saved hidden offsets")
    result=dict(source_id=frame["source_id"],start=a,end=b,text=raw[a:b],hidden_start=h0,hidden_end=h1,
        source_text_sha256=digest(raw),source_text_hash_contract="SHARED_JSON_STRING_ENSURE_ASCII_TRUE_SHA256",
        raw_source_text_sha256=text_sha(raw),literal_roundtrip=True,coordinate_space="SOURCE_FRAME_TEXT",
        parent_coordinate_space=frame["coordinate_space"],frame_parent_start=frame["parent_start"],
        parent_window_start=frame["parent_start"]+a,parent_window_end=frame["parent_start"]+b,
        parent_hidden_start=frame["parent_start"]+h0,parent_hidden_end=frame["parent_start"]+h1,
        source_provenance=deepcopy(frame["provenance"]),window_regenerated=False)
    raw_start=frame["provenance"].get("raw_document_start")
    if raw_start is not None:
        if type(raw_start) is not int or raw_start<0:raise ValueError("Invalid raw document origin offset")
        result["raw_document_window_start"]=raw_start+result["parent_window_start"]
        result["raw_document_window_end"]=raw_start+result["parent_window_end"]
        result["raw_document_hidden_start"]=raw_start+result["parent_hidden_start"]
        result["raw_document_hidden_end"]=raw_start+result["parent_hidden_end"]
    return result


def prepare_batch(packs, proposals, *, private_proofs=None, source_release_ref=None):
    """Accept raw curation rows or {cases, private} from bind_proposals()."""
    by_pack={p["pack_id"]:p for p in packs}
    if len(by_pack)!=len(packs):raise ValueError("Duplicate source-pack ID")
    if isinstance(proposals,dict):
        rows=proposals["cases"];private_proofs=private_proofs if private_proofs is not None else proposals.get("private",[])
    else:rows=proposals
    if isinstance(private_proofs,dict):private_proofs=private_proofs.get("cases",private_proofs)
    proof_map={p["case_id"]:p for p in (private_proofs or [])} if not isinstance(private_proofs,dict) else private_proofs
    supplied=[];bindings=[];seen=set()
    for row in rows:
        original=row.get("case",row);case_id=original.get("case_id")
        proof=proof_map.get(case_id,{})
        pack_id=row.get("pack_id",proof.get("pack_id"));pack=by_pack.get(pack_id)
        if pack is None:raise ValueError("Proposal has no supplied source-pack binding")
        if pack.get("pack_sha256")!=digest({k:v for k,v in pack.items() if k!="pack_sha256"}):
            raise ValueError("Private source pack changed before semantic review")
        proposal_id=row.get("proposal_id") or case_id or pack_id
        if proposal_id in seen:raise ValueError("Duplicate proposal ID")
        seen.add(proposal_id);query=_queries(row)
        for key,expected in (("corpus",pack["corpus"]),("task",pack["task"]),("document_id",pack["origin"]["document_id"]),("date",pack["origin"]["date"])):
            if key in original and original[key]!=expected:raise ValueError("Proposal/source origin or task binding changed")
        frames=source_frames(pack);frame_map={f["source_id"]:f for f in frames}
        birth=row.get("birth_quotes",proof.get("source_quotes",[]))
        if not birth:raise ValueError("No birth-of-question source quotations")
        bound=[]
        for quote in birth:
            if quote["source_id"] not in frame_map:raise ValueError("Unlicensed birth source frame (possibly another hidden unit)")
            bound.append(_exact(frame_map[quote["source_id"]],quote.get("text",quote.get("quote"))))
        if pack["corpus"]=="cib" and pack["task"] in {"hypothesis","reconstruction"} and not any(q["source_id"]==pack_id+":focus" for q in bound):
            raise ValueError("CIB target birth requires a focal revealed quote; context alone is insufficient")
        altered=row.get("deliberately_altered",proof.get("altered",False))
        if type(altered) is not bool:raise ValueError("Declared alteration flag must be boolean")
        marker=original.get("focal_marker","")
        hidden=row.get("hidden_quote",proof.get("answer"))
        mask_map=None
        if pack["task"]=="redaction":
            authenticated=pack.get("authentic_redaction")
            if authenticated:
                if query!=authenticated["query"]:raise ValueError("Authentic source question changed before review")
                marker=authenticated["focus_marker"];hidden=authenticated["answer"]
            if not marker:marker="[REDACTION 1]"
            if query.count(marker)!=1 or not isinstance(hidden,str) or not hidden:raise ValueError("Bound focal mask/key required")
            if not authenticated:
                supplied_mask_map=row.get("mask_map",proof.get("mask_map"))
                mask_map=bind_mask_window(frame_map[pack_id+":focus"],query,marker,hidden,supplied_mask_map)
        elif marker or hidden is not None:
            raise ValueError("H/R proposal cannot carry a focal redaction mask/key")
        public=dict(case_id=case_id or "next_"+digest([pack_id,query])[:24],corpus=pack["corpus"],task=pack["task"],
                    query=query,document_id=pack["origin"]["document_id"],date=pack["origin"]["date"],focal_marker=marker)
        prior=source_difficulty_hold(pack,literal_window=mask_map["text"] if mask_map else None,details=True)
        for index,citation in enumerate(prior["eligible_prior_sources"]):
            frame=_frame(pack_id+":prior_difficulty_"+str(index),citation["context"],role="PRIOR_DIFFICULTY_ONLY_NOT_ORIGIN_PROOF",
                coordinate_space=citation.get("coordinate_space","PRIOR_LITERAL_SOURCE_CONTEXT"),
                start=citation.get("context_start",0),provenance={k:deepcopy(citation[k]) for k in ("source_id","document_id","date","source_file_ref","source_text_sha256") if k in citation})
            frames.append(frame)
        item=dict(proposal_id=proposal_id,pack_id=pack_id,corpus=pack["corpus"],task=pack["task"],
            origin=deepcopy(pack["origin"]),public_query=query,focal_marker=marker,birth_quotes=bound,sources=frames,
            deliberately_altered=altered,alteration_label=row.get("alteration_label",proof.get("alteration_label","DECLARED_UNSPECIFIED" if altered else "NONE")),
            hidden_quote=hidden if pack["task"]=="redaction" else None,
            mask_map=deepcopy(mask_map),
            prior_difficulty=deepcopy(prior),
            mask_kind="AUTHENTIC_PAIRED_REDACTION" if pack.get("authentic_redaction") else "SYNTHETIC_SOURCE_BASED" if pack["task"]=="redaction" else "NOT_REDACTION")
        supplied.append(item)
        bindings.append(dict(proposal_id=proposal_id,pack_id=pack_id,pack_sha256=pack["pack_sha256"],
            original_public_case=public,birth_quotes=bound,declared_alteration=altered,source_frames_sha256=digest(frames),
            mask_map=deepcopy(mask_map),
            prior_difficulty=deepcopy(prior),
            dependency=deepcopy(pack.get("dependency",{}))))
    payload=dict(version=VERSION,exposure=EXPOSURE,proposals=supplied,
                 no_native_outputs_ranks_planning_atoms_readings_or_recovery_hints=True)
    binding=dict(version=VERSION,payload_sha256=digest(payload),prompt_sha256=text_sha(PROMPT),schema_sha256=digest(SCHEMA),
                 source_release_ref=deepcopy(source_release_ref),proposals=bindings)
    binding["sha256"]=digest(binding)
    return dict(version=VERSION,payload=payload,prompt=PROMPT,schema=deepcopy(SCHEMA),binding=binding)


def bind_reviews(prepared, response):
    """Bind an advisory source review; no API, files or inference mutation."""
    from jsonschema import validate
    validate(response,SCHEMA)
    binding=prepared["binding"]
    if (prepared.get("version")!=VERSION or binding.get("version")!=VERSION or prepared["payload"].get("version")!=VERSION
            or prepared.get("prompt")!=PROMPT or prepared.get("schema")!=SCHEMA):
        raise ValueError("Obsolete admission protocol; reprepare and review under the current version")
    if (binding["sha256"]!=digest({k:v for k,v in binding.items() if k!="sha256"})
            or binding["payload_sha256"]!=digest(prepared["payload"])
            or binding["prompt_sha256"]!=text_sha(prepared["prompt"])
            or binding["schema_sha256"]!=digest(prepared["schema"])):
        raise ValueError("Prepared admission packet binding changed")
    model_rows={r["proposal_id"]:r for r in response["reviews"]}
    inputs={r["proposal_id"]:r for r in prepared["payload"]["proposals"]}
    if len(model_rows)!=len(response["reviews"]) or set(model_rows)!=set(inputs):raise ValueError("Missing/duplicate/unrequested proposal review")
    output=[]
    for original in binding["proposals"]:
        pid=original["proposal_id"];row=model_rows[pid];inp=inputs[pid]
        frames={f["source_id"]:f for f in inp["sources"]};citations=[];problems=[]
        if original["prior_difficulty"]["hold"]:problems.append("RAW_COMPLETE_PRIOR_SOURCE_COPY_DIFFICULTY_HOLD")
        for justification in row["justifications"]:
            if justification["source_id"] not in frames:raise ValueError("Unprovided review source ID")
            frame=frames[justification["source_id"]]
            citation=_exact(frame,justification["quote"]);citation["purpose"]=justification["purpose"]
            if citation["purpose"]=="TARGET" and frame["role"] in {"VISIBLE_PAGE_CONTEXT","LATER_PAGE_INSPECTION_ONLY_NOT_TARGET"}:
                problems.append("TARGET_QUOTED_FROM_CONTEXT_PAGE_NOT_FOCAL_SOURCE")
            if citation["purpose"]=="VISIBLE_OWNER_CONTEXT" and frame["role"]=="LATER_PAGE_INSPECTION_ONLY_NOT_TARGET":
                problems.append("LATER_PAGE_DOES_NOT_LICENSE_VISIBLE_OWNER")
            if citation["purpose"]=="OPERATOR_OR_QUALIFICATION" and frame["role"]=="LATER_PAGE_INSPECTION_ONLY_NOT_TARGET":
                problems.append("LATER_PAGE_DOES_NOT_LICENSE_FOCAL_OPERATOR_OR_QUALIFICATION")
            if frame["role"]=="PRIOR_DIFFICULTY_ONLY_NOT_ORIGIN_PROOF" and citation["purpose"]!="MASK_DIFFICULTY":
                problems.append("PRIOR_DIFFICULTY_SOURCE_CANNOT_SUPPLY_ORIGIN_FACT_OR_OPERATOR")
            citations.append(citation)
        if row["action"]=="KEEP" and row["revised_query"]:raise ValueError("KEEP must not carry a rewritten query")
        query=inp["public_query"] if row["action"]=="KEEP" else row["revised_query"]
        if row["action"]=="REVISE" and (not query.strip() or query==inp["public_query"]):raise ValueError("REVISE requires genuinely new complete wording")
        if not row["meaning_preserved"]:problems.append("MEANING_NOT_CERTIFIED_PRESERVED")
        if row["naturalness"]=="UNCERTAIN":problems.append("NATURALNESS_UNRESOLVED")
        if row["source_faithfulness"] in {"UNFAITHFUL","UNCERTAIN"}:problems.append("SOURCE_SCOPE_UNRESOLVED")
        if row["alteration_status"] in {"UNDECLARED_OR_NEW_MEANING_CHANGE","UNCERTAIN"}:problems.append("ALTERATION_SCOPE_UNRESOLVED")
        if original["declared_alteration"]:
            if row["alteration_status"]!="DECLARED_ALTERATION_PRESERVED" or row["source_faithfulness"]!="DECLARED_ALTERATION_PRESERVED":problems.append("DECLARED_ALTERATION_ERASED_OR_CHANGED")
        elif row["alteration_status"]!="SOURCE_FAITHFUL" or row["source_faithfulness"]!="FAITHFUL":problems.append("UNDECLARED_ALTERATION")
        if not any(q["purpose"]=="TARGET" for q in citations):problems.append("NO_EXACT_TARGET_JUSTIFICATION")
        if inp["corpus"]=="cib" and inp["task"] in {"hypothesis","reconstruction"}:
            if row["hidden_dependence"]!="FOCAL_REVEAL_REQUIRED" or not any(q["purpose"]=="TARGET" and q["source_id"]==inp["pack_id"]+":focus" for q in citations):
                problems.append("CIB_FOCAL_HIDDEN_DEPENDENCE_UNRESOLVED")
        if inp["task"]=="redaction":
            if row["action"]!="KEEP":problems.append("SOURCE_REDACTION_QUERY_REWRITE_REQUIRES_NEW_BOUND_SOURCE_WINDOW")
            if row["mask_check"]!="NONTRIVIAL_COMPLETE":problems.append("MASK_DIFFICULTY_OR_EXTENT_UNRESOLVED")
        elif row["mask_check"]!="NOT_REDACTION":problems.append("TASK_MASK_STATUS_MISMATCH")
        case=deepcopy(original["original_public_case"])
        if query!=case["query"]:
            case["query"]=query
            case["case_id"]="next_edit_"+digest([VERSION,original["original_public_case"],query,binding["sha256"]])[:24]
        decision="ADMIT" if row["decision"]=="ADMIT" and not problems else "HOLD"
        output.append(dict(proposal_id=pid,decision=decision,model_decision=row["decision"],reason=row["reason"],local_hold_reasons=problems,
            public_case=case if decision=="ADMIT" else None,proposed_public_case=case,
            private_transformation=dict(exposure=EXPOSURE,source_aware=True,ordinary_runtime_input=False,
                old_public_case=deepcopy(original["original_public_case"]),new_public_case=case,
                wording_changed=query!=inp["public_query"],request_binding_sha256=binding["sha256"],response_sha256=digest(response),
                source_pack_id=original["pack_id"],source_pack_sha256=original["pack_sha256"],
                source_release_ref=deepcopy(binding.get("source_release_ref")),publication_requires_independent_source_adoption=True,
                original_birth_quotes=deepcopy(original["birth_quotes"]),exact_justifications=citations,
                mask_map=deepcopy(original.get("mask_map")),
                prior_difficulty=deepcopy(original["prior_difficulty"]),
                deliberate_alteration=original["declared_alteration"],old_grades_or_native_decisions_transferred=False,
                source_admission_not_gold=True,native_support_or_recovery_assessed=False)))
    return dict(version=VERSION,reviews=output,request_binding_sha256=binding["sha256"],api_calls=0,
                inference_or_source_population_modified=False,new_public_cases=[r["public_case"] for r in output if r["decision"]=="ADMIT"])


# Convenient names for lead-owned API orchestration, not a model-call wrapper.
prepare = prepare_batch
bind = bind_reviews
