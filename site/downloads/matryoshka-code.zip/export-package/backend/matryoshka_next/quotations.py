"""Literal quote coordinates, with explicit layout-only optional rebinding."""
import re


VERSION="unique-literal-or-layout-quotation/2"


def _whole_tokens(text, start, end):
    def word(char):
        return char.isalnum() or char == "_"
    return not ((word(text[start]) and start and word(text[start-1])) or
                (word(text[end-1]) and end < len(text) and word(text[end])))


def locate(text,quotation,*,allow_layout=False,ignore_case=False,token_boundaries=False):
    if not isinstance(quotation,str) or not quotation:
        raise ValueError("Nonempty quotation required")
    literal=list(re.finditer("(?=("+re.escape(quotation)+"))",text))
    if token_boundaries:
        literal=[m for m in literal if _whole_tokens(text,m.start(1),m.end(1))]
    if literal:
        if len(literal)>1:
            raise ValueError("Ambiguous literal quotation")
        at=literal[0].start(1)
        return at,at+len(quotation),quotation,"LITERAL"
    if not allow_layout or not quotation.split():
        raise ValueError("Quotation missing from source")
    pattern=r"\s+".join(re.escape(word) for word in quotation.split())
    # Lookahead is required: OLD OLD has two overlapping matches in old OLD old.
    matches=list(re.finditer("(?=("+pattern+"))",text,re.I if ignore_case else 0))
    if token_boundaries:
        matches=[m for m in matches if _whole_tokens(text,m.start(1),m.end(1))]
    if len(matches)!=1:
        raise ValueError("Quotation missing or ambiguous after layout normalization")
    hit=matches[0]
    return hit.start(1),hit.end(1),hit.group(1),"LAYOUT_AND_CASE" if ignore_case else "LAYOUT"
