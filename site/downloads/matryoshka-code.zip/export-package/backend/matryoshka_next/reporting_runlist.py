"""Select original saved envelopes from a pinned progress snapshot, API zero."""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest

VERSION = "next-complete-progress-runlist/2"
LEGACY_VERSION = "next-complete-progress-runlist/1"


def _path(root, name):
    p = Path(name); p = (p if p.is_absolute() else root/p).resolve()
    if not p.is_relative_to(root): raise ValueError("Runlist artifact outside workspace")
    return p


def _build(root, progress_text, progress_ref, expected_complete, *, version=VERSION):
    if hashlib.sha256(progress_text.encode()).hexdigest() != progress_ref["sha256"]:
        raise ValueError("Progress snapshot byte pin changed")
    if expected_complete is not None and (type(expected_complete) is not int or expected_complete < 0):
        raise ValueError("Expected completion count must be a nonnegative integer")
    progress = json.loads(progress_text)
    rows = progress["outcomes"]
    selected = [r for r in rows if r.get("status") == "COMPLETE"]
    if expected_complete is not None and len(selected) != expected_complete:
        raise ValueError("Progress COMPLETE count does not match the explicit expected count")
    refs, conditions, packets, cases = [], set(), set(), {}
    for row in selected:
        p = _path(root, row["path"]); raw = p.read_bytes()
        envelope = json.loads(gzip.decompress(raw) if p.suffix == ".gz" else raw)
        packet = envelope["packet"]; sha = digest(packet); case = public_case(packet["case"])
        if envelope.get("packet_sha256") != sha or packet.get("query_sha256") != digest(case["query"]):
            raise ValueError("Selected native packet/query seal changed")
        if packet["case"] != case or row["case_id"] != case["case_id"]:
            raise ValueError("Progress/native public case identity mismatch")
        if case["case_id"] in cases and cases[case["case_id"]] != case:
            raise ValueError("Same selected case ID has different public content")
        cases[case["case_id"]] = case
        method, mode = row.get("method"), row.get("mode")
        if not isinstance(method, str) or not method or not isinstance(mode, str) or not mode:
            raise ValueError("COMPLETE condition needs explicit method and mode")
        actual = packet.get("retrieval", {}).get("method", packet.get("config"))
        if actual != method: raise ValueError("Progress/native method mismatch")
        interpreter = packet["plan"].get("readings_packet", {}).get("interpreter") if case["task"] == "redaction" else "not_applicable"
        expected_interpreter = {"model":"model", "local":"spacy"}.get(mode) if version == VERSION else mode
        if case["task"] == "redaction" and (expected_interpreter is None or interpreter != expected_interpreter):
            raise ValueError("Progress/native Red reader mismatch")
        if "result_status" in row and row["result_status"] != packet["result"].get("status"):
            raise ValueError("Progress/native result status mismatch")
        key = case["case_id"], method, mode
        if key in conditions or sha in packets:
            raise ValueError("Duplicate COMPLETE condition or native packet")
        conditions.add(key); packets.add(sha)
        refs.append(dict(path=str(p.relative_to(root)), sha256=hashlib.sha256(raw).hexdigest(),
            packet_sha256=sha, case_id=case["case_id"], case_sha256=digest(case), method=method, mode=mode,
            task=case["task"], corpus=case["corpus"], native_version=packet.get("version"),
            result_version=packet["result"].get("version"), code_pins_sha256=digest(packet.get("code_pins")),
            environment_sha256=digest(packet.get("environment"))))
        if version == VERSION:
            refs[-1]["native_reading_interpreter"] = interpreter
    result = dict(version=version, progress_ref=progress_ref, progress_snapshot_utf8=progress_text,
        expected_complete=expected_complete, complete_conditions=len(refs), distinct_case_ids=len(cases),
        progress_status_counts=dict(Counter(r.get("status", "UNKNOWN") for r in rows)), runs=refs,
        directory_glob_used=False, original_native_files_only=True, api_calls=0)
    if version == VERSION:
        result["reading_mode_binding_policy"] = "EXACT_MODEL_TO_MODEL_LOCAL_TO_SPACY_HR_NOT_APPLICABLE"
    result["sha256"] = digest(result)
    return result


def prepare(root, progress_ref, *, expected_complete=None):
    root = Path(root).resolve(); p = _path(root, progress_ref["path"])
    ref = dict(path=str(p.relative_to(root)), sha256=progress_ref["sha256"])
    return _build(root, p.read_bytes().decode(), ref, expected_complete)


def validate(root, manifest):
    """Replay captured progress bytes, not a later live progress file."""
    if manifest.get("version") not in {VERSION, LEGACY_VERSION} or manifest.get("sha256") != digest({k:v for k,v in manifest.items() if k != "sha256"}):
        raise ValueError("Runlist seal or version changed")
    expected = _build(Path(root).resolve(), manifest["progress_snapshot_utf8"], manifest["progress_ref"], manifest["expected_complete"], version=manifest["version"])
    if manifest != expected: raise ValueError("Runlist original native bindings changed")
    return expected


def write(output, manifest):
    if manifest.get("sha256") != digest({k:v for k,v in manifest.items() if k != "sha256"}):
        raise ValueError("Runlist seal changed")
    p = Path(output)/("runlist_"+manifest["sha256"]+".json")
    raw = (json.dumps(manifest, sort_keys=True, ensure_ascii=True, indent=2)+"\n").encode()
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        if p.read_bytes() != raw: raise ValueError("Immutable runlist content changed")
    else:
        with p.open("xb") as f: f.write(raw)
    return dict(path=str(p.resolve()), sha256=hashlib.sha256(raw).hexdigest(), manifest_sha256=manifest["sha256"])
