"""Versioned nonblind SOURCE curation packs, not inference or support decisions.

The only ranking inputs are literal origin annotations and declared structural
strata. Earlier-source probes run AFTER nomination and never remove a pack.
No retrieval outputs, grades, answer-driven runtime plans or API clients enter.
"""

from collections import Counter, defaultdict
from copy import deepcopy
import csv
from datetime import date
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import time

VERSION = "source-first-origin-object-bank/1"
TASKS = ("hypothesis", "reconstruction", "redaction")
CORPORA = ("iran", "vietnam", "cib")
NOFORN = re.compile(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM", re.I)
MASK = re.compile(r"\[(?:REDACTED|REDACTION|MASK|UNKNOWN)[^\]]*\]", re.I)
WORD = re.compile(r"\w+(?:[-']\w+)*", re.UNICODE)
EXPOSURE = "SOURCE_AWARE_ANSWER_AWARE_NOMINATION_NOT_BLIND_EVALUATION"
_KINDS = dict(claims="claim", events="event", entities="entity", relations="relation")
_FIELDS = dict(claim=("claim_text", "speaker", "target", "stance", "temporal_context"),
               event=("label", "type", "date", "location", "description"),
               entity=("name", "type", "description"),
               relation=("source", "target", "relation", "temporal_context"))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def text_sha(value):
    return hashlib.sha256(value.encode()).hexdigest()


def normalize(value):
    return " ".join(value.casefold().split())


def _json(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON key")
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=unique)


def _path(root, value, *, exists=True):
    root = Path(root).absolute()
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts or "\\" in str(value) or "://" in str(value):
        raise ValueError("Expected a safe explicitly rooted relative path")
    path = root / relative
    for part in (path, *path.parents):
        if part.is_symlink():
            raise ValueError("Source/pack symlink is not authority")
        if part == root:
            break
    if exists and not path.is_file():
        raise ValueError("Missing bound file: " + str(value))
    return path


def _sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _iso(value):
    if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
        raise ValueError("Exact source ISO date required")
    return value


def _unique(rows, key):
    result = {}
    for row in rows:
        value = key(row)
        if value in result:
            raise ValueError("Duplicate source identity: " + str(value))
        result[value] = row
    return result


def _write(path, value, *, private=True):
    wire = (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    if path.suffix == ".gz":
        wire = gzip.compress(wire, mtime=0)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != wire:
            raise ValueError("Refusing to overwrite immutable source-bank artifact")
    else:
        with path.open("xb") as stream:
            stream.write(wire)
        path.chmod(0o600 if private else 0o644)
    return dict(path=path.name, sha256=hashlib.sha256(wire).hexdigest(), bytes=len(wire))


class Inputs:
    def __init__(self, root):
        self.root = Path(root).absolute()
        self.workspace = self.root.parent
        self.records = {}

    def resolve(self, ref, scope="workspace"):
        return _path(self.root if scope == "demo" else self.workspace, ref["path"])

    def _record(self, path, checksum, ref, scope):
        if checksum != ref["sha256"]:
            raise ValueError("Input hash changed: " + ref["path"])
        self.records[str(path.relative_to(self.workspace))] = dict(path=str(path.relative_to(self.workspace)),
            sha256=checksum, bytes=path.stat().st_size, authority_scope=scope)

    def load(self, ref, scope="workspace"):
        path = self.resolve(ref, scope)
        wire = path.read_bytes()
        self._record(path, hashlib.sha256(wire).hexdigest(), ref, scope)
        return _json(gzip.decompress(wire) if path.suffix == ".gz" else wire)

    def rows(self, ref):
        path = self.resolve(ref)
        before = path.stat()
        h = hashlib.sha256()
        with path.open("rb") as stream:
            for line in stream:
                h.update(line)
                if line.strip():
                    yield json.loads(line)
        after = path.stat()
        if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
            raise ValueError("Source changed during scan")
        self._record(path, h.hexdigest(), ref, "workspace")

    def csv(self, ref):
        path = self.resolve(ref)
        self._record(path, _sha(path), ref, "workspace")
        with path.open(encoding="utf-8-sig", newline="") as stream:
            return list(csv.DictReader(stream))


def document_admission(original, metadata, projection, segments, document):
    """Whole-source policy, including the previously corrected NOFORN ordering."""
    classification = metadata.get("origclass", "").strip().upper()
    handling = sorted(t.strip().upper() for t in re.split(r"[,;|]", metadata.get("orighand", ""))
                      if t.strip() and t.strip().upper() != "N/A")
    body = original.get("body", "")
    reason = None
    if classification not in {"SECRET", "CONFIDENTIAL"}:
        reason = "OTHER_OR_UNKNOWN_ORIGINAL_CLASSIFICATION"
    elif NOFORN.search(body + " " + metadata.get("orighand", "")):
        reason = "WHOLE_ORIGINAL_BODY_OR_HANDLING_NOFORN"
    elif (projection.get("classification") != classification or sorted(projection.get("handling", [])) != handling
          or projection.get("policy_role") != ("secret_expansion" if classification == "SECRET" else "confidential_evidence")):
        reason = "ORIGINAL_METADATA_PROJECTION_MISMATCH"
    else:
        try:
            _iso(original["date"])
            declared_dates = [document[k] for k in ("document_date_iso", "date_iso") if document.get(k)]
            if not declared_dates or any(value != original["date"] for value in declared_dates):
                raise ValueError("date")
            ordered = sorted(segments, key=lambda r: r["segment_sequence"])
            if not ordered or [r["segment_sequence"] for r in ordered] != list(range(1, len(ordered)+1)):
                raise ValueError("siblings")
            for row in ordered:
                a, b = row["source_char_start"], row["source_char_end"]
                if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(body)
                        or body[a:b] != row["text"] or row["segment_count"] != len(ordered)
                        or row["document_date_iso"] != original["date"]):
                    raise ValueError("raw offset/date")
        except (KeyError, ValueError, TypeError):
            reason = "RAW_DATE_OR_ALL_SIBLING_REPLAY_FAILED"
    return dict(eligible=reason is None, reason=reason, classification=classification, handling=handling,
        role=("origin" if classification == "SECRET" else "witness") if reason is None else "excluded",
        date=original.get("date"), whole_body_sha256=text_sha(body), metadata_sha256=digest(metadata),
        noforn_veto_before_projection_role=True)


def paragraph_bounds(text, start, end):
    if type(start) is not int or type(end) is not int or not 0 <= start < end <= len(text):
        raise ValueError("Invalid literal source span")
    a = text.rfind("\n\n", 0, start)
    b = text.find("\n\n", end)
    return (0 if a < 0 else a+2), (len(text) if b < 0 else b)


def bind_object(row, source, kind):
    if (row.get("document_id") != source["document_id"] or row.get("canonical_page_id") != source["source_id"]
            or row.get("document_date_iso") != source["date"]
            or row.get("source_text_sha256") != text_sha(source["text"])):
        raise ValueError("OBJECT_SOURCE_OR_HASH_MISMATCH")
    if source["corpus"] == "cib" and (row.get("visibility") != "later_only"
            or row.get("introduced_by_slot_id") not in source["slot_ids"]):
        raise ValueError("NOT_A_BOUND_LATER_ONLY_REVEAL_OBJECT")
    a, b = row.get("char_start"), row.get("char_end")
    if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(source["text"]):
        raise ValueError("OBJECT_OFFSET_OUTSIDE_SOURCE")
    raw = source["text"][a:b]
    if not row.get("evidence_quote") or normalize(raw) != normalize(row["evidence_quote"]):
        raise ValueError("OBJECT_QUOTATION_DOES_NOT_REPLAY")
    if MASK.search(raw):
        raise ValueError("OBJECT_QUOTE_CROSSES_UNKNOWN_MASK")
    visible_repeat = source["corpus"] == "cib" and normalize(raw) in source["whole_earlier_normalized"]
    oid = next((row[k] for k in ("claim_mention_id", "event_mention_id", "mention_id", "relation_evidence_id") if k in row), None)
    if not oid or not row.get("local_id") or not row.get("job_id"):
        raise ValueError("MISSING_EXTRACTED_OBJECT_IDENTITY")
    return dict(id=oid, local_id=row["local_id"], job_id=row["job_id"], kind=kind,
        annotation={k: row[k] for k in _FIELDS[kind] if k in row}, assertion_mode=row.get("assertion_mode"),
        model_confidence=row.get("confidence"), quotation=dict(start=a, end=b, text=raw, sha256=text_sha(raw),
        coordinate_space=source["coordinate_space"]), annotation_evidence_quote=row["evidence_quote"],
        quote_normalization="EXACT" if raw == row["evidence_quote"] else "CASE_AND_WHITESPACE_ONLY",
        same_origin_earlier_literal_repetition=visible_repeat,
        target_fact_hidden_dependence="REQUIRES_OWNER_AND_REVEAL_SCOPE_REVIEW" if source["corpus"] == "cib" else "SECRET_SOURCE_ORIGIN",
        annotation_is_fallible_not_support=True)


def _cables(inputs, registry, corpus, diagnostics):
    # Reuse explicit source-file references, not the cache's former admission labels.
    folder = "iran_89cdf5130bc937911259" if corpus == "iran" else "vietnam_8ca9868da3a4e1fdbf5a"
    identity_path = inputs.root / "experiments/presentation_refresh/reconstruction/full_source_discovery_v01" / folder / "identity.json"
    identity_ref = dict(path=str(identity_path.relative_to(inputs.root)), sha256=_sha(identity_path))
    identity = inputs.load(identity_ref, "demo")
    if not identity_path.parent.name.endswith(digest(identity)[:20]):
        raise ValueError("Source-reference cache identity changed")
    selected = registry["corpora"][corpus]
    if selected["status"] != "INCUMBENT_NOT_MIGRATED":
        raise ValueError("Cable successor requires an explicit new adapter")
    files = selected["incumbent_binding"]["files"]
    for key, name in (("canonical", "pages"), ("documents", "documents"), ("projection", "projection")):
        if identity["source_refs"][key] != files[name]:
            raise ValueError("Cached cable source references do not match current registry")
    refs = identity["source_refs"]
    originals = _unique(inputs.csv(refs["raw"]), lambda r:r["id"])
    metadata = _unique((r for r in inputs.csv(refs["metadata"]) if r["corpora"].lower() == corpus), lambda r:r["local_doc_id"].strip())
    documents = _unique(inputs.rows(files["documents"]), lambda r:r["document_id"])
    projection = inputs.load(files["projection"])["document_metadata"]
    grouped = defaultdict(list)
    for row in inputs.rows(files["pages"]):
        grouped[row["document_id"]].append(row)
    sources, witnesses = {}, []
    for did, segments in sorted(grouped.items()):
        decision = document_admission(originals.get(did, {}), metadata.get(did, {}), projection.get(did, {}), segments, documents.get(did, {}))
        diagnostics["documents"].append(dict(corpus=corpus, document_id=did, **decision))
        if not decision["eligible"]:
            continue
        for row in segments:
            item = dict(corpus=corpus, document_id=did, date=decision["date"], source_id=row["segment_id"],
                text=row["text"], title=documents[did].get("document_title", documents[did].get("title", "")),
                classification=decision["classification"], handling=decision["handling"],
                coordinate_space="CANONICAL_SEGMENT_TEXT", raw_document_start=row["source_char_start"],
                raw_body=originals[did]["body"],
                source_file_ref=files["pages"], raw_file_ref=refs["raw"], source_policy=decision,
                locator=dict(kind="CSV_DOCUMENT_SEGMENT_NOT_PDF_PAGE", segment_sequence=row["segment_sequence"]),
                earlier_evidence_eligible=decision["role"] == "witness")
            if decision["role"] == "origin":
                sources[row["segment_id"]] = item
            else:
                witnesses.append(item)
    return sources, witnesses, files


def unit_context_fragments(row, focal):
    """Each fragment has its own literal coordinate frame; never join/reoffset."""
    result=[]
    for i in range(max(0,focal-1),min(len(row["units"]),focal+2)):
        unit=row["units"][i];field="text" if unit["unit_type"]=="shared_text" else "later_text"
        licensed=i==focal or unit["unit_type"]=="shared_text"
        text=unit.get(field,"") if licensed else None
        result.append(dict(canonical_page_id=row["canonical_page_id"],unit_index=i,unit_type=unit["unit_type"],
            field=field if licensed else None,text=text,start=0 if licensed else None,end=len(text) if licensed else None,
            sha256=text_sha(text) if licensed else None,coordinate_space="INDEPENDENT_LITERAL_CANONICAL_UNIT_FIELD",
            focal_revealed_unit=i==focal,visible_context_can_bind_owner=i!=focal and licensed,
            adjacent_unknown_preserved=not licensed,unit_record_sha256=digest(unit)))
    return result


def _cib(inputs, registry, diagnostics):
    native = registry["corpora"]["cib"]["native_registry"]
    files = native["files"]
    canonical = next(r for r in native["artifact_inventory"] if r["path"] == native["paths"]["prepared"] + "/canonical_pages.jsonl")
    paired = dict(path=native["paths"]["prepared"] + "/page_pairs.jsonl",
                  sha256="56fb9772a1e6f35cfef38476501822725b7ab7e3b33f32a6268490f4bf9096de")
    raw_ref = dict(path="src-redaction/data/source/corpus/corpus_v3_clean.jsonl",
                   sha256="2f65f12c05b312846004f4020a395205f809a6c0387b50058f3c8c4e5b768e86")
    docs = {r["document_id"]: r for r in inputs.rows(files["documents"])}
    whole = {}
    for row in inputs.rows(raw_ref):
        whole[row["document_id"]] = "\n\n".join(row.get("raw_ocr", {}).get("redacted", []))
    rows = {r["canonical_page_id"]: r for r in inputs.rows(canonical)}
    guard = inputs.load(files["source_quarantine_policy"])
    excluded = {p["canonical_page_id"] for p in guard["quarantined_pages"] + guard["quarantined_jobs"]}
    for row in inputs.rows(files["quarantine"]):
        excluded.add(row["page_pair_id"])
    witnesses = []
    for row in inputs.rows(files["pages"]):
        if row["canonical_page_id"] in excluded or row.get("view") != "earlier":
            continue
        doc = docs[row["document_id"]]
        witnesses.append(dict(corpus="cib", document_id=row["document_id"], date=_iso(doc["document_date_iso"]),
            source_id=row["canonical_page_id"], text=row["text"], coordinate_space="EARLIER_CANONICAL_PAGE_TEXT",
            source_file_ref=files["pages"], locator=dict(kind="PHYSICAL_EARLIER_PDF_PAGE", page=row.get("source_page")),
            earlier_evidence_eligible=True))
    units = {}
    for pid, row in rows.items():
        if row.get("projection_status") != "ready":
            continue
        for i, unit in enumerate(row["units"]):
            if (unit.get("unit_type") != "redaction_zone" or not unit.get("slot_ids")
                    or not unit.get("later_text", "").strip()
                    or not set(unit.get("reveal_states", [])) & {"revealed", "partially_revealed"}):
                continue
            doc = docs[row["document_id"]]
            if not whole.get(row["document_id"]):
                diagnostics["rejected_counts"]["MISSING_WHOLE_EARLIER_ORIGIN_PROOF"] += 1
                continue
            source = dict(corpus="cib", source_id=pid, document_id=row["document_id"], date=_iso(doc["document_date_iso"]),
                title=doc.get("document_title", ""), text=unit["later_text"], classification=doc.get("classification_level"),
                handling=doc.get("distribution_controls", []), coordinate_space="LITERAL_LATER_REVEALED_UNIT_TEXT",
                unit_index=i, slot_ids=unit["slot_ids"], canonical_unit_sha256=digest(unit),
                canonical_unit=unit, source_file_ref=canonical, raw_file_ref=raw_ref, paired_ref=paired,
                whole_earlier_normalized=normalize(whole.get(row["document_id"], "")),
                whole_earlier_origin_sha256=text_sha(whole.get(row["document_id"], "")),
                source_policy=dict(origin_evidence_quarantined=pid in excluded, whole_origin_excluded_from_evidence=True,
                                   hidden_required_claim_check="TARGET_FACT_MUST_DEPEND_ON_FOCAL_REVEAL_NOT_ALL_QUERY_WORDS_HIDDEN",
                                   visible_context_may_bind_owner=True,visible_only_target_facts_forbidden=True),
                locator=dict(kind="PAIRED_PDF_PAGES", earlier_page=row["earlier_source_page"], later_page=row["later_source_page"]),
                context_fragments=unit_context_fragments(row,i),
                adjacent_units=deepcopy(row["units"][max(0, i-1):i] + row["units"][i+1:i+2]))
            for slot in unit["slot_ids"]:
                units[(pid, slot)] = source
    jobs = {}
    for job in inputs.rows(files["jobs"]):
        if job.get("visibility") != "later_only" or job.get("job_kind") != "revealed_slot_content":
            continue
        source = units.get((job["canonical_page_id"], job.get("introduced_by_slot_id")))
        if source is None or source["text"] != job.get("text") or source["document_id"] != job["document_id"]:
            diagnostics["rejected_counts"]["CIB_JOB_NOT_EXACT_CANONICAL_REVEAL"] += 1
            continue
        if source["date"] != job["document_date_iso"]:
            raise ValueError("Reveal job date differs from original document")
        jobs[job["job_id"]] = source
    seal_path = inputs.workspace / "matryoshka_redaction/data/preflight_v3/release/source_release.json"
    seal = inputs.load(dict(path=str(seal_path.relative_to(inputs.workspace)), sha256=_sha(seal_path)))
    target_path = "data/preflight_v3/source/reconciled_v2/targets.jsonl"
    targets = list(inputs.rows(dict(path="matryoshka_redaction/" + target_path, sha256=seal["files"][target_path])))
    if len(targets) != 332 or seal["targets"] != 332:
        raise ValueError("The source-sealed authentic redaction membership changed")
    red = []
    for target in targets:
        row = rows[target["canonical_page_id"]]
        unit = row["units"][target["zone_unit_index"]]
        boundary = target["cloze_source_boundaries"]
        if (not target["primary_admission"]["eligible"] or boundary["hidden_prefix"] or boundary["hidden_suffix"]
                or target["query"].count(target["focus_marker"]) != 1 or not target["answer"]
                or docs[target["document_id"]]["document_date_iso"] != target["document_date_iso"]):
            raise ValueError("Authentic redaction extent/date/admission mismatch")
        # Origin evidence quarantine is not target exclusion. The authenticated
        # reconciled target/overlay is retained verbatim, not rederived here.
        source = dict(corpus="cib", source_id=target["canonical_page_id"], document_id=target["document_id"],
            date=target["document_date_iso"], title="CURRENT INTELLIGENCE BULLETIN", text=unit.get("later_text", ""),
            coordinate_space="LITERAL_LATER_REVEALED_UNIT_TEXT", unit_index=target["zone_unit_index"],
            source_file_ref=canonical, raw_file_ref=raw_ref, paired_ref=paired,
            locator=dict(kind="PAIRED_PDF_PAGES", earlier_page=row["earlier_source_page"], later_page=row["later_source_page"]),
            source_policy=dict(authenticated_reconciled_target=True, origin_evidence_quarantined=row["canonical_page_id"] in excluded,
                               source_overlay_required=target["source_overlay_required"], source_overlay_sha256=target["source_overlay_sha256"]),
            canonical_unit_sha256=digest(unit), adjacent_units=deepcopy(row["units"][max(0,target["zone_unit_index"]-1):target["zone_unit_index"]+2]))
        source["context_fragments"]=unit_context_fragments(row,target["zone_unit_index"])
        red.append(dict(source=source, target={k: target[k] for k in ("case_id", "query", "focus_marker", "answer",
            "answer_start", "answer_end", "source_hash", "cloze_source_boundaries")}))
    diagnostics["cib_genuine_reveal_jobs"] = len(jobs)
    diagnostics["canonical332_unchanged"] = dict(count=len(targets), file_sha256=seal["files"][target_path])
    return jobs, witnesses, files, red, paired


def _scan_objects(inputs, corpus, sources, files, diagnostics, *, progress=None):
    by_job = defaultdict(list)
    names = dict(claims="claims", events="events", entities="entities", relations="relations") if corpus != "cib" else dict(
        claims="claim_mentions", events="event_mentions", entities="entity_mentions", relations="relation_evidence")
    scan = {}
    for table, key in names.items():
        total = admitted = 0
        if progress:
            progress(f"{corpus}: scan {key}")
        for row in inputs.rows(files[key]):
            total += 1
            source = sources.get(row.get("job_id") if corpus == "cib" else row.get("canonical_page_id"))
            if source is None:
                continue
            try:
                bound = bind_object(row, source, _KINDS[table])
            except ValueError as exc:
                diagnostics["rejected_counts"][str(exc)] += 1
                diagnostics["rejected_objects"].append(dict(corpus=corpus, job_id=row.get("job_id"), local_id=row.get("local_id"), reason=str(exc)))
                continue
            by_job[(row["job_id"], source["source_id"])].append(bound)
            admitted += 1
        scan[key] = dict(total_rows=total, literal_origin_objects=admitted, file_ref=files[key])
    diagnostics["ledger_scans"][corpus] = scan
    candidates = []
    for (job, pid), objects in sorted(by_job.items()):
        source = sources[job if corpus == "cib" else pid]
        grouped = defaultdict(list)
        for obj in objects:
            quote = obj["quotation"]
            bounds = (0, len(source["text"])) if corpus == "cib" else paragraph_bounds(source["text"], quote["start"], quote["end"])
            grouped[bounds].append(obj)
        for (a,b), contained in grouped.items():
            if not any(o["kind"] in {"claim", "event", "relation"} for o in contained):
                continue
            candidate = _candidate(source, a, b, contained)
            candidate["eligible_tasks"] = list(TASKS[:2])
            if corpus != "cib" and any(o["kind"] == "entity" for o in contained):
                candidate["eligible_tasks"].append("redaction")
            candidates.append(candidate)
    return candidates


def _candidate(source, a, b, objects, target=None):
    text = source["text"][a:b]
    locals_ = {o["local_id"]: o for o in objects}
    edges = [o for o in objects if o["kind"] == "relation" and o["annotation"].get("source") in locals_
             and o["annotation"].get("target") in locals_]
    counts = Counter(o["kind"] for o in objects)
    modes = sorted({str(o["assertion_mode"]) for o in objects})
    candidate = dict(candidate_id="sourcepack_" + digest([source["corpus"],source["document_id"],source["source_id"],
                     source.get("unit_index"),a,b,target and target["case_id"]])[:24],
        corpus=source["corpus"], origin=dict(document_id=source["document_id"], date=source["date"],
            classification=source.get("classification"), handling=source.get("handling", []), title=source.get("title", ""),
            policy=deepcopy(source.get("source_policy", {}))),
        source={k: deepcopy(v) for k,v in source.items() if k not in {"whole_earlier_normalized", "text", "source_policy", "raw_body"}},
        literal_context=dict(start=a,end=b,text=text,sha256=text_sha(text),coordinate_space=source["coordinate_space"],
                             parent_text_sha256=text_sha(source["text"])),
        objects=objects, eligible_tasks=["redaction"] if target else [],
        nomination=dict(object_counts=dict(counts), source_local_typed_edges=len(edges),
            linked_local_nodes=len({o["annotation"][e] for o in edges for e in ("source","target")}),
            distinct_object_quote_spans=len({(o["quotation"]["start"],o["quotation"]["end"]) for o in objects if o["kind"] != "entity"}),
            assertion_modes=modes, structural_counts_are_not_required_atoms=True, global_KG_degree_not_computed=True,
            score_is_not_support_or_correctness=True),
        dependency=dict(origin_document=source["document_id"], literal_source_copy_group=text_sha(normalize(text)),
                        episode_id_status="UNADJUDICATED_SOURCE_UNIT_NOT_INDEPENDENT_EPISODE", same_origin_not_independent=True),
        difficulty=dict(unknown_masks_preserved=bool(MASK.search(text)), source_scope_review_required=True,
                        natural_required_component_count_unassessed=True,
                        fragment_pack_incomplete_context=source["corpus"]=="cib" and not text.rstrip().rstrip("\"')]").endswith((".","!","?")),
                        fragment_flag_is_layout_heuristic_not_rejection=True),
        exposure=EXPOSURE, source_admission_not_conditioned_on_prior_hits=True,
        outcomes_or_grades_used=False, factual_support_assessed=False)
    if "raw_body" in source:
        lo,hi=paragraph_bounds(source["raw_body"],source["raw_document_start"]+a,source["raw_document_start"]+b)
        candidate["raw_document_context"]=dict(start=lo,end=hi,text=source["raw_body"][lo:hi],
            sha256=text_sha(source["raw_body"][lo:hi]),coordinate_space="ORIGINAL_FULL_CABLE_BODY",
            extends_across_segment_boundary=lo<source["raw_document_start"] or hi>source["raw_document_start"]+len(source["text"]))
    if target:
        candidate["authentic_redaction"] = deepcopy(target)
        candidate["difficulty"].update(authentic_not_synthetic=True,
            short_or_acronym_shape=bool(re.fullmatch(r"[A-Z0-9-]{1,5}", target["answer"])),
            answer_visible_elsewhere_in_query=normalize(target["answer"]) in normalize(target["query"]))
    else:
        entities = [o for o in objects if o["kind"] == "entity"]
        candidate["synthetic_mask_candidates"] = [dict(start=o["quotation"]["start"], end=o["quotation"]["end"],
            literal=o["quotation"]["text"], object_id=o["id"], type=o["annotation"].get("type"),
            mask_kind="PROPOSED_SYNTHETIC_SOURCE_BASED_NOT_AUTHENTIC_REDACTION", complete_nontrivial_span_unverified=True,
            literal_repeated_in_origin_context=normalize(text).count(normalize(o["quotation"]["text"]))>1) for o in entities]
    return candidate


def select_candidates(candidates, limit):
    """No prior support/results enter nomination. Prefer source diversity first."""
    if type(limit) is not int or not 1 <= limit <= 1000:
        raise ValueError("Operational per-cell limit must be 1..1000")
    def ranking(c):
        n=c["nomination"]
        return (-n["linked_local_nodes"], -n["source_local_typed_edges"],
                -n["distinct_object_quote_spans"], c["origin"]["date"], c["candidate_id"])
    remaining=sorted(candidates,key=ranking)
    selected=[];used_ids=set();used_copies=set();used_origins=set();counts=Counter()
    for distinct_origins in (True,False):
        changed=True
        while changed:
            changed=False
            for task in TASKS:
                if counts[task]>=limit: continue
                for c in remaining:
                    if (c["candidate_id"] in used_ids or task not in c["eligible_tasks"]
                            or c["dependency"]["literal_source_copy_group"] in used_copies
                            or distinct_origins and c["origin"]["document_id"] in used_origins):
                        continue
                    row=deepcopy(c);row["task"]=task;row["pack_id"]=c["candidate_id"]+"_"+task
                    row["nomination"].update(rank_in_cell=counts[task]+1,
                        method="SOURCE_LOCAL_TYPED_CONNECTIVITY_THEN_QUOTE_SPANS_WITH_ORIGIN_DIVERSITY",
                        selection_has_no_prior_probe_input=True, first_pass_distinct_origin=distinct_origins)
                    selected.append(row);used_ids.add(c["candidate_id"]);used_copies.add(c["dependency"]["literal_source_copy_group"])
                    used_origins.add(c["origin"]["document_id"]);counts[task]+=1;changed=True;break
    return selected,dict(counts)


def prior_diagnostics(packs,witnesses,*,max_candidates=64,max_citations=3):
    """Bounded literal diagnostics on eligible earlier DIFFERENT-origin sources."""
    probes={};wanted=defaultdict(set)
    for p in packs:
        quotes=sorted({o["quotation"]["text"] for o in p["objects"] if o["kind"] in {"claim","event"}},key=lambda x:(-len(x),x))[:3]
        if "authentic_redaction" in p:quotes=[p["authentic_redaction"]["answer"]]+quotes[:2]
        if not quotes:quotes=[p["literal_context"]["text"]]
        probes[p["pack_id"]]=quotes
        for q in quotes:
            toks=tuple(m.group().casefold() for m in WORD.finditer(q));n=min(5,len(toks))
            if n:
                wanted[n].update(tuple(toks[i:i+n]) for i in range(len(toks)-n+1))
    postings=defaultdict(dict)
    for i,w in enumerate(witnesses):
        tokens=list(WORD.finditer(w["text"]));words=[m.group().casefold() for m in tokens]
        for n,keys in wanted.items():
            for j in range(len(words)-n+1):
                key=tuple(words[j:j+n])
                if key in keys:postings[(n,key)].setdefault(i,(tokens[j].start(),tokens[j+n-1].end()))
    for p in packs:
        found=[];candidate_totals=0
        for q in probes[p["pack_id"]]:
            words=tuple(m.group().casefold() for m in WORD.finditer(q));n=min(5,len(words))
            candidates=Counter();positions={}
            for j in range(len(words)-n+1) if n else []:
                for i,pos in postings.get((n,words[j:j+n]),{}).items():
                    w=witnesses[i]
                    if w["document_id"]!=p["origin"]["document_id"] and w["date"]<p["origin"]["date"]:
                        candidates[i]+=1;positions[i]=pos
            candidate_totals+=len(candidates)
            pattern=r"\s+".join(re.escape(s) for s in q.split())
            if q[:1].isalnum():pattern=r"(?<!\w)"+pattern
            if q[-1:].isalnum():pattern+=r"(?!\w)"
            for i in sorted(candidates,key=lambda k:(-candidates[k],witnesses[k]["date"],witnesses[k]["source_id"]))[:max_candidates]:
                w=witnesses[i];hit=re.search(pattern,w["text"],re.I) if pattern else None
                start,end=hit.span() if hit else positions[i]
                a,b=paragraph_bounds(w["text"],start,end)
                found.append(dict(match_kind="CASE_WHITESPACE_LITERAL" if hit else "SHARED_LITERAL_TOKEN_RUN_NOMINATION",
                    needle_sha256=text_sha(q),document_id=w["document_id"],date=w["date"],source_id=w["source_id"],
                    source_file_ref=w["source_file_ref"],source_text_sha256=text_sha(w["text"]),
                    start=start,end=end,text=w["text"][start:end],context_start=a,context_end=b,context=w["text"][a:b],
                    context_sha256=text_sha(w["text"][a:b]),coordinate_space=w["coordinate_space"],locator=w.get("locator"),
                    strictly_earlier=True,whole_origin_excluded=True,source_support_assessed=False))
        found.sort(key=lambda w:(w["match_kind"]!="CASE_WHITESPACE_LITERAL",w["date"],w["source_id"],w["start"]))
        unique={}
        for match in found:unique.setdefault((match["source_id"],match["start"],match["end"]),match)
        p["prior_diagnostics"]=dict(stage="POST_NOMINATION_NONBLIND_SOURCE_ONLY_NOT_RUNTIME_RETRIEVAL",
            source_aware_includes_hidden_answers="authentic_redaction" in p,match_candidate_count=candidate_totals,
            max_candidates_per_needle=max_candidates,returned_citation_cap=max_citations,
            no_match_is_not_corpus_absence_or_no_support=True,short_or_exact_hits_not_excluded=True,
            citations=list(unique.values())[:max_citations],native_evaluation=False)
        p["difficulty"]["prior_literal_hit_control"]=any(w["match_kind"]=="CASE_WHITESPACE_LITERAL" for w in unique.values())


def _public(p):
    return dict(pack_id=p["pack_id"],corpus=p["corpus"],task=p["task"],document_id=p["origin"]["document_id"],
        date=p["origin"]["date"],source_id=p["source"]["source_id"],object_counts=p["nomination"]["object_counts"],
        nomination_rank=p["nomination"]["rank_in_cell"],source_local_typed_edges=p["nomination"]["source_local_typed_edges"],
        episode_independence_adjudicated=False,source_aware_nonblind=True,native_success_assessed=False,
        authentic_redaction="authentic_redaction" in p,proposed_synthetic_mask=p["task"]=="redaction" and p["corpus"]!="cib",
        prior_literal_control=p["difficulty"]["prior_literal_hit_control"])


def build_sourcebank(root,*,refs_ref,output_root="experiments/next_workbench/sourcebank",per_cell_limit=50,progress=print):
    root=Path(root).absolute();inputs=Inputs(root);code_sha=_sha(Path(__file__))
    output=_path(root,str(Path(output_root)/"placeholder"),exists=False).parent
    allowed=root/"experiments/next_workbench/sourcebank"
    if not output.is_relative_to(allowed):raise ValueError("Output must stay in owned sourcebank directory")
    output.mkdir(parents=True,exist_ok=True)
    if shutil.disk_usage(output).free<2*1024**3:raise RuntimeError("Less than 2 GiB safe disk headroom")
    refs=inputs.load(refs_ref,"demo");registry=inputs.load(refs["registry_ref"],"demo")
    if registry.get("sha256")!=digest({k:v for k,v in registry.items() if k!="sha256"}):raise ValueError("Registry self-seal changed")
    diagnostics=dict(documents=[],rejected_counts=Counter(),rejected_objects=[],ledger_scans={},no_outcomes_read=True)
    packs=[];cells={};candidate_counts={};pair_ref=None
    for corpus in CORPORA:
        if progress:progress("[sourcebank] origins "+corpus,flush=True)
        if corpus=="cib":sources,witnesses,files,red,pair_ref=_cib(inputs,registry,diagnostics)
        else:sources,witnesses,files=_cables(inputs,registry,corpus,diagnostics);red=[]
        candidates=_scan_objects(inputs,corpus,sources,files,diagnostics,progress=(lambda s:progress("[sourcebank] "+s,flush=True)) if progress else None)
        if corpus=="cib":
            for item in red:candidates.append(_candidate(item["source"],0,len(item["source"]["text"]),[],item["target"]))
        candidate_counts[corpus]=dict(source_units=len(candidates),origin_documents=len({c["origin"]["document_id"] for c in candidates}),
                                      eligible_by_task={t:sum(t in c["eligible_tasks"] for c in candidates) for t in TASKS})
        selected,counts=select_candidates(candidates,per_cell_limit)
        if progress:progress("[sourcebank] selected "+corpus+" "+repr(counts),flush=True)
        prior_diagnostics(selected,witnesses)
        for task in TASKS:cells[corpus+"/"+task]=dict(packs=counts.get(task,0),baseline_target=20,requested_nomination_limit=per_cell_limit,
            shortfall_to_20=max(0,20-counts.get(task,0)),distinct_origins=len({p["origin"]["document_id"] for p in selected if p["task"]==task}))
        packs.extend(selected)
        del sources,witnesses,candidates
    # Add physical source pages only for the selected CIB pool.
    if pair_ref:
        selected_pages={p["source"]["source_id"] for p in packs if p["corpus"]=="cib"}
        paired={r["canonical_page_id"]:r for r in inputs.rows(pair_ref) if r["canonical_page_id"] in selected_pages}
        for p in packs:
            if p["corpus"]!="cib":continue
            row=paired[p["source"]["source_id"]]
            if row["document_id"]!=p["origin"]["document_id"]:raise ValueError("Physical paired document mismatch")
            p["source"]["paired_pages"]=dict(earlier_page=row["earlier_page"],later_page=row["later_page"],
                earlier_text=row["earlier_text"],later_text=row["later_text"],earlier_sha256=text_sha(row["earlier_text"]),
                later_sha256=text_sha(row["later_text"]),file_ref=pair_ref)
    for p in packs:p["pack_sha256"]=digest(p)
    source_refs=list(inputs.records.values())
    if _sha(Path(__file__))!=code_sha:raise ValueError("Sourcebank code changed during build; preserve logs and rerun a new version")
    identity=dict(version=VERSION,code_sha256=code_sha,refs_ref=refs_ref,registry_ref=refs["registry_ref"],
                  registry_canonical_sha256=registry["sha256"],source_refs=source_refs,per_cell_limit=per_cell_limit)
    release_id="sourcebank_"+digest(identity)[:24];directory=output/"releases"/release_id
    artifacts={}
    artifacts["private_packs"]=_write(directory/"private_packs.json.gz",dict(version=VERSION,exposure=EXPOSURE,packs=packs))
    artifacts["public_summary"]=_write(directory/"public_summary.json",dict(version=VERSION,cells=cells,rows=[_public(p) for p in packs],
        private_quotes_or_answers_included=False,nomination_not_native_execution=True),private=False)
    artifacts["diagnostics"]=_write(directory/"diagnostics.json.gz",diagnostics)
    manifest=dict(version=VERSION,release_id=release_id,identity=identity,artifacts=artifacts,cells=cells,candidate_pool_counts=candidate_counts,
        private_pack_count=len(packs),source_aware_nonblind=True,native_outcomes_read=False,api_calls=0,new_native_runs=0,
        source_indexes_rebuilt=False,canonical332_modified=False,all_current_fifteen_provisional=True,
        downstream_targets_unmeasured=dict(reconstruction_complex_cases=2,reconstruction_complex_minimum_required=3,
            reconstruction_complex_minimum_backed=2,reconstruction_total_cases=4,reconstruction_total_minimum_required=2,
            reconstruction_total_minimum_backed=2,complex_cases_are_subset_of_total=True,redaction_backed_at_1_cases=2,
            redaction_correct_or_equivalent_at_5_cases=4),
        source_connectivity_or_quote_count_is_not_support=True,episode_independence_requires_adjudication=True)
    manifest["sha256"]=digest(manifest)
    _write(directory/"manifest.json",manifest)
    reference=dict(path=str((directory/"manifest.json").relative_to(root)),sha256=_sha(directory/"manifest.json"))
    _write(output/(release_id+"_receipt.json"),dict(release_ref=reference,cells=cells,api_calls=0))
    return reference


def load_packs(root,release_ref,*,corpus=None,task=None,verify_sources=True):
    root=Path(root).absolute();path=_path(root,release_ref["path"])
    if _sha(path)!=release_ref["sha256"]:raise ValueError("Sourcebank manifest bytes changed")
    manifest=_json(path.read_bytes())
    if manifest.get("version")!=VERSION or manifest.get("sha256")!=digest({k:v for k,v in manifest.items() if k!="sha256"}):
        raise ValueError("Sourcebank manifest seal/version changed")
    if manifest["release_id"]!="sourcebank_"+digest(manifest["identity"])[:24] or path.parent.name!=manifest["release_id"]:
        raise ValueError("Sourcebank content identity changed")
    if verify_sources:
        for ref in manifest["identity"]["source_refs"]:
            source=_path(root.parent,ref["path"])
            if source.stat().st_size!=ref["bytes"] or _sha(source)!=ref["sha256"]:raise ValueError("Bound sourcebank input changed")
    for ref in manifest["artifacts"].values():
        target=_path(path.parent,ref["path"])
        if target.stat().st_size!=ref["bytes"] or _sha(target)!=ref["sha256"]:raise ValueError("Sourcebank artifact changed")
    ref=manifest["artifacts"]["private_packs"]
    value=_json(gzip.decompress(_path(path.parent,ref["path"]).read_bytes()))
    packs=value["packs"];seen=set()
    for p in packs:
        if p["pack_id"] in seen or p["pack_sha256"]!=digest({k:v for k,v in p.items() if k!="pack_sha256"}):
            raise ValueError("Duplicate or changed source pack")
        seen.add(p["pack_id"])
        c=p["literal_context"]
        if c["sha256"]!=text_sha(c["text"]) or c["end"]-c["start"]!=len(c["text"]):raise ValueError("Literal source context changed")
    if corpus is not None and corpus not in CORPORA or task is not None and task not in TASKS:raise ValueError("Unknown corpus/task")
    return [p for p in packs if (corpus is None or p["corpus"]==corpus) and (task is None or p["task"]==task)]


def _compact_pack(pack,include_prior):
    """Remove repeated audit strings, never source context or a source object."""
    p=pack
    source_keys=("source_id","unit_index","coordinate_space","source_file_ref","raw_file_ref","paired_ref",
                 "locator","context_fragments","paired_pages","whole_earlier_origin_sha256")
    annotation_keys=dict(claim=("claim_text","speaker","target","stance","temporal_context"),
        event=("label","type","date","location"),entity=("name","type"),relation=("source","target","relation","temporal_context"))
    result=dict(pack_id=p["pack_id"],source_pack_sha256=p["pack_sha256"],corpus=p["corpus"],task=p["task"],
        origin=deepcopy(p["origin"]),source={k:deepcopy(p["source"][k]) for k in source_keys if k in p["source"]},
        literal_context=deepcopy(p["literal_context"]),difficulty=deepcopy(p["difficulty"]),dependency=deepcopy(p["dependency"]),
        nomination=deepcopy(p["nomination"]),objects=[],source_annotations_are_fallible_not_assertion_certificates=True,
        source_context_not_truncated=True,source_object_count=len(p["objects"]),
        projection_is_byte_identical_to_private_pack=False,
        projection_omits="Repeated quote strings/hashes, model confidence and entity/event description readouts; every object and its raw quote span remain")
    if "raw_document_context" in p:result["raw_document_context"]=deepcopy(p["raw_document_context"])
    for o in p["objects"]:
        result["objects"].append(dict(local_id=o["local_id"],kind=o["kind"],job_id=o["job_id"],
            annotation={k:v for k,v in o["annotation"].items() if k in annotation_keys[o["kind"]]},
            assertion_mode=o["assertion_mode"],quote_span=[o["quotation"]["start"],o["quotation"]["end"]],
            quote_coordinate_space=o["quotation"]["coordinate_space"],
            same_origin_earlier_literal_repetition=o.get("same_origin_earlier_literal_repetition",False)))
    if "authentic_redaction" in p:
        result["authentic_redaction"]={k:deepcopy(p["authentic_redaction"][k]) for k in ("case_id","query","focus_marker","answer","answer_start","answer_end")}
    elif p["task"]=="redaction":result["synthetic_mask_candidates"]=deepcopy(p.get("synthetic_mask_candidates",[]))
    if include_prior:result["prior_diagnostics"]=deepcopy(p["prior_diagnostics"])
    return result


def build_packet(packs,pack_ids=None,*,include_prior=True,compact=False):
    """Pure payload constructor for lead-owned source-curation calls, not runtime."""
    wanted=set(pack_ids) if pack_ids is not None else {p["pack_id"] for p in packs}
    if pack_ids is not None and len(wanted)!=len(pack_ids):raise ValueError("Duplicate requested source pack")
    available={p["pack_id"]:p for p in packs}
    if len(available)!=len(packs) or wanted-set(available):raise ValueError("Duplicate/missing source pack")
    selected=[]
    for pid in sorted(wanted):
        p=deepcopy(available[pid])
        if p["pack_sha256"]!=digest({k:v for k,v in p.items() if k!="pack_sha256"}):raise ValueError("Source pack changed before packet build")
        if compact:selected.append(_compact_pack(p,include_prior))
        else:
            if not include_prior:p.pop("prior_diagnostics",None)
            selected.append(p)
    return dict(version=VERSION,exposure=EXPOSURE,ordinary_runtime_planning=False,source_curator_payload=True,
                pack_ids=sorted(wanted),packs=selected,completed_question_generation_or_native_outcomes_included=False,
                extracted_objects_are_prior_fallible_model_annotations=True,
                packet_projection_version="source-curator-compact-packet/1" if compact else "FULL_AUDIT_PACKET",
                packet_projection_module_sha256=_sha(Path(__file__)))


def main(argv=None):
    import argparse
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--root",type=Path,required=True)
    parser.add_argument("--refs",required=True);parser.add_argument("--refs-sha256",required=True)
    parser.add_argument("--per-cell-limit",type=int,default=50);args=parser.parse_args(argv)
    reference=build_sourcebank(args.root,refs_ref=dict(path=args.refs,sha256=args.refs_sha256),per_cell_limit=args.per_cell_limit)
    print(json.dumps(dict(release_ref=reference,api_calls=0),indent=2),flush=True)


if __name__=="__main__":main()
