"""Source-literal Red question windows; no key, rank, candidate or grade input."""
from copy import deepcopy
import re

from matryoshka_demo.contracts import MASK,public_case
from matryoshka_demo.io import digest


VERSION="literal-paragraph-or-neighbor-sentence-window/1"


def bounds(query,marker,*,paragraph_char_budget=1600):
    from .readings import _model
    if query.count(marker)!=1 or type(paragraph_char_budget) is not int or paragraph_char_budget<1:
        raise ValueError("One focal mask and a positive presentation budget required")
    a=query.index(marker);b=a+len(marker)
    analyzed=MASK.sub(lambda m:"GAP"+" "*(len(m.group())-3),query)
    sentences=list(_model()(analyzed).sents)
    focal=[i for i,s in enumerate(sentences) if s.start_char<=a<a+3<=s.end_char]
    if len(focal)!=1:
        raise ValueError("Focal mask lacks a complete source sentence")
    i=focal[0]
    separators=list(re.finditer(r"\n[ \t]*\n",query))
    left=max((s.end() for s in separators if s.end()<=a),default=0)
    right=min((s.start() for s in separators if s.start()>=b),default=len(query))
    left=min(left,sentences[i].start_char);right=max(right,b,sentences[i].end_char)
    rule="FULL_PARAGRAPH_WITH_COMPLETE_FOCAL_SENTENCE"
    if right-left>paragraph_char_budget:
        left=sentences[max(0,i-1)].start_char
        right=sentences[min(len(sentences)-1,i+1)].end_char
        right=max(right,b)
        rule="COMPLETE_FOCAL_SENTENCE_AND_IMMEDIATE_NEIGHBORS"
    while left<right and query[left].isspace():left+=1
    while right>left and query[right-1].isspace():right-=1
    if not left<=a<b<=right:
        raise ValueError("Question window clipped its focal mask")
    return left,right,rule


def repair(case,*,paragraph_char_budget=1600):
    c=public_case(case)
    if c["task"]!="redaction":raise ValueError("Only Red uses a mask window")
    left,right,rule=bounds(c["query"],c["focal_marker"],paragraph_char_budget=paragraph_char_budget)
    value=deepcopy(c);value["query"]=c["query"][left:right]
    changed=value["query"]!=c["query"]
    if changed:value["case_id"]="window_"+digest([VERSION,c,left,right])[:24]
    record=dict(version=VERSION,old_case=deepcopy(c),new_case=deepcopy(value),
        old_query_sha256=digest(c["query"]),new_query_sha256=digest(value["query"]),
        start=left,end=right,rule=rule,context_changed=changed,target_membership_changed=False,
        source_text_substring_only=True,neighboring_masks_within_window_preserved=True,
        answer_or_outcomes_read=False,canonical_population_modified=False)
    return value,record
