"""Query-only model transport; no API, NLP, source lookup or new readings.

Models select a legal composite, not independent form/function/role fields.
Locators resolve positions only and never enter the existing reading response.
The caller owns API receipts and passes expand()'s response to readings.py.
"""
from copy import deepcopy

from jsonschema import Draft202012Validator, ValidationError

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest
from . import readings
from .quotations import VERSION as QUOTATION_VERSION, locate


VERSION = "next-reading-composite-quote-wire/2"
STAGE = "next_grammatical_reading_templates_v1"
TEMPLATE_VERSION = "next-reading-legal-composites/1"
MAX_READINGS = 8
COMPOSITE_FIELDS = ("outer_family", "function", "role", "variant")
PROMPT = (
    "Select only genuinely plausible grammatical readings of the exact public gap. "
    "Choose a template_id from legal_templates: that one choice jointly selects its "
    "outer_family, function, role and variant. Do not emit those four fields separately "
    "or combine templates. Typed hints, wrappers and operators are your own explicit "
    "selections, never inferred by the decoder. Select at most eight readings, not "
    "eight required slots; never enumerate the menu as a fallback. Unknown means "
    "abstain with zero readings. Form describes the FINAL insertion, not the bare "
    "source phrase: a noun phrase plus a proposed example linker has a prepositional "
    "final surface. Supply each span as {text,locator}, without numerical offsets. "
    "text must be a nonempty visible quotation, without any mask or hidden content. "
    "Use locator=null when text identifies a unique query occurrence; otherwise "
    "provide a larger unique query quotation containing exactly one occurrence of "
    "text. A locator may contain an opaque mask ONLY to identify position; it is "
    "not a grammatical cue, answer, identity or evidence. Quote only the visible "
    "target in text. Preserve scope and operators; hidden operators are hypothetical, "
    "not observed. Nondefault target_kind, number or finite hints need their own "
    "exact typed cues; otherwise use any, unknown or null respectively. Use only "
    "visible query grammar: do not fill the gap, name a hidden entity, use history "
    "or sources, invent cues, or generate questions, leads or search keywords. "
    "Return only the closed response schema."
)


def _templates():
    result = []
    registry = readings.REGISTRY
    for family in registry["families"]:
        family = family["id"]
        for function in registry["family_functions"][family]:
            for role in registry["roles"]:
                if function not in registry["role_functions"][role]:
                    continue
                for variant in registry["variants"]:
                    if variant == "compound_modifier" and (family, function) != ("nominal", "modifier"):
                        continue
                    if variant == "numeric_quantity" and family != "nominal_specifier":
                        continue
                    values = (family, function, role, variant)
                    result.append(dict(template_id="/".join(values), **dict(zip(COMPOSITE_FIELDS, values))))
    if len({t["template_id"] for t in result}) != len(result):
        raise ValueError("Composite template ID collision")
    return result


_TEMPLATES = _templates()
_BY_ID = {t["template_id"]: t for t in _TEMPLATES}
TEMPLATE_CATALOG_SHA256 = digest(_TEMPLATES)


def legal_templates():
    """Detached menu; its size is not an emitted interpretation count."""
    return deepcopy(_TEMPLATES)


def _case(case):
    if not isinstance(case, dict) or set(case) != readings.PUBLIC_FIELDS:
        raise ValueError("Reading wire requires exactly seven public case fields")
    return public_case(case)


def schema():
    """Provider-safe structural wire; the eight-reading cap is local too."""
    contract = readings.schema()
    contract["title"] = "Next legal composite and located quotation selections v1"
    contract["$defs"]["span"] = dict(type="object", additionalProperties=False,
        properties=dict(text=dict(type="string"), locator=dict(type=["string", "null"])),
        required=["text", "locator"])
    row = contract["$defs"]["reading"]
    for field in COMPOSITE_FIELDS:
        row["properties"].pop(field)
    row["properties"]["template_id"] = dict(type="string", enum=list(_BY_ID))
    row["required"] = list(row["properties"])
    contract["properties"]["readings"]["description"] = "At most eight actual selections; never a template product."
    readings.audit_provider_schema(contract)
    return contract


def model_input(case):
    case = _case(case)
    if case["task"] != "redaction":
        raise ValueError("H/R must skip the model-reading stage")
    return dict(wire_version=VERSION, template_version=TEMPLATE_VERSION,
        template_catalog_sha256=TEMPLATE_CATALOG_SHA256, max_readings=MAX_READINGS,
        packet_version=readings.VERSION, registry=deepcopy(readings.REGISTRY),
        registry_sha256=readings.REGISTRY_SHA256, legal_templates=legal_templates(),
        task=case["task"], query=case["query"], focal_marker=case["focal_marker"])


def expand(raw, case):
    """Return (existing v2 response, detached transport audit), not a packet.

    All selected rows and their order survive. Existing readings.py validation
    is preflighted, but its optional typed-constraint loss projection is NOT
    substituted for the returned model selections. The caller binds that next.
    """
    case = _case(case)
    try:
        Draft202012Validator(schema()).validate(raw)
    except ValidationError as error:
        raise ValueError("Invalid composite reading wire: " + error.message) from error
    if len(raw["readings"]) > MAX_READINGS:
        raise ValueError("At most eight model-selected readings are allowed")
    query = case["query"]
    bindings, selections = [], []

    def resolve(value, path):
        if value is None:
            return None
        locator = value["locator"]
        base, container, container_binding = 0, query, None
        if locator is not None:
            base, end, container, mode = locate(query, locator, allow_layout=True,
                ignore_case=True, token_boundaries=True)
            container_binding = dict(start=base, end=end, text=container, match=mode)
        start, end, literal, mode = locate(container, value["text"], allow_layout=True,
            ignore_case=True, token_boundaries=True)
        start, end = base + start, base + end
        if any(start < m.end() and m.start() < end for m in MASK.finditer(query)):
            raise ValueError("A target quote cannot contain, cross or overlap an opaque mask")
        bound = dict(start=start, end=end, text=literal)
        bindings.append(dict(path=path, input=deepcopy(value), locator_binding=container_binding,
            target_binding=deepcopy(bound), target_match=mode, locator_is_position_only=True))
        return bound

    expanded = dict(status=raw["status"], reason=raw["reason"], readings=[])
    for index, row in enumerate(raw["readings"]):
        template = _BY_ID[row["template_id"]]
        values = {k: template[k] for k in COMPOSITE_FIELDS}
        selected = dict(values, target_kind=row["target_kind"],
            grammatical_number=row["grammatical_number"], finite=row["finite"],
            attachment_spans=[resolve(v, f"/readings/{index}/attachment_spans/{i}")
                for i, v in enumerate(row["attachment_spans"])],
            wrappers=[], operators=[], cues=[])
        for i, wrapper in enumerate(row["wrappers"]):
            selected["wrappers"].append(dict(kind=wrapper["kind"], placement=wrapper["placement"],
                spans=[resolve(v, f"/readings/{index}/wrappers/{i}/spans/{j}")
                    for j, v in enumerate(wrapper["spans"])]))
        for i, operator in enumerate(row["operators"]):
            selected["operators"].append(dict(kind=operator["kind"], realization=operator["realization"],
                scope=resolve(operator["scope"], f"/readings/{index}/operators/{i}/scope"),
                cue=resolve(operator["cue"], f"/readings/{index}/operators/{i}/cue")))
        for i, cue in enumerate(row["cues"]):
            selected["cues"].append(dict(kind=cue["kind"],
                span=resolve(cue["span"], f"/readings/{index}/cues/{i}/span")))
        expanded["readings"].append(selected)
        selections.append(dict(input_reading_index=index, template_id=row["template_id"],
            expanded_fields=values, all_composite_fields_selected_jointly_by_model=True))

    # Reuse the existing grammar/status checks, not a parallel interpretation.
    preflight = readings.from_model_response(expanded, case)
    audit = dict(version=VERSION, template_version=TEMPLATE_VERSION,
        template_catalog_sha256=TEMPLATE_CATALOG_SHA256,
        registry_version=readings.REGISTRY_VERSION, registry_sha256=readings.REGISTRY_SHA256,
        packet_version=readings.VERSION, expanded_schema_version=readings.MODEL_SCHEMA_VERSION,
        quotation_version=QUOTATION_VERSION, cue_token_boundaries=True,
        case_sha256=digest(case), query_sha256=digest(query),
        input_response=deepcopy(raw), input_response_sha256=digest(raw),
        expanded_response_sha256=digest(expanded), template_selections=selections, span_bindings=bindings,
        selected_readings=len(raw["readings"]), expanded_readings=len(expanded["readings"]),
        max_readings=MAX_READINGS, model_chose_all_composite_fields=True,
        new_readings_added=False, grammar_inferred=False, typed_fields_changed=False,
        locator_exported_as_cue=False, existing_packet_preflight_passed=True,
        existing_typed_projection_changes=deepcopy(preflight["model_constraint_projection"]["changes"]),
        existing_typed_projection_not_applied_to_returned_response=True,
        raw_provider_response_is_callers_responsibility=True,
        query_only=True, source_access=False, answers_read=False, api_calls=0)
    return expanded, audit
