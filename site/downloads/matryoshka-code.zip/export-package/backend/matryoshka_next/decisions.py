"""Directed, source-local H/R decisions with explicit unresolved scope.

No rank, graph label, generated extraction claim or model assessment is evidence.
The reused literal linguistic helpers are not a general entailment oracle.
"""
from collections import Counter
from copy import deepcopy
import re

from matryoshka_demo.io import digest
from matryoshka_demo_v6.planning import sentences
from .facts import SourcePolicy, fact_index, normal, public_plan


VERSION = "next-directed-task-decisions/3.3"
STATES = ("SUPPORTED", "OPPOSED", "FEASIBLE", "NO_INFO", "CONFLICTED")
_RELATIVE = re.compile(r"\b(today|yesterday|tomorrow|currently|recently|now|ago)\b|\b(last|next|this)\s+(day|week|month|year)\b", re.I)
_LINK = re.compile(r"\b(?:same (?:event|tour|occasion|episode|speech|meeting|exchange|statement|report)|while|because|therefore|before|after|caused|led to)\b", re.I)
_WH = {"who", "what", "which", "where", "when", "how"}
_REQUEST = {"identify", "determine", "provide", "give", "describe", "reconstruct", "summarize",
            "explain", "list", "outline", "trace", "assess", "evaluate", "test", "investigate"}
_REPORT = {"say", "state", "report", "estimate", "assess", "believe", "claim", "predict",
           "forecast", "expect", "argue", "deny", "announce", "explain", "describe"}


def _request_view(text):
    value = re.sub(r"^\s*the analyst asks?\s+", "", text, flags=re.I)
    appraisal = re.match(r"^\s*(?:(?:assess|determine|evaluate|investigate|test|establish)\s+"
        r"(?:whether|if|the (?:assessment|claim|hypothesis) that)|"
        r"(?:whether|the (?:assessment|claim|hypothesis) that))(?:\s*,\s*|\s+)(.+)$", value, re.I | re.S)
    if appraisal:
        return "appraisal", appraisal[1].strip().rstrip("?")
    command = re.match(r"^\s*([A-Za-z]+)\s+(.+)$", value, re.S)
    if command and command[1].casefold() in _REQUEST:
        value = command[2].strip()
    account = re.match(r"^(?:an?\s+)?(?:account|summary|description)\s+of\s+(.+)$", value, re.I | re.S)
    return ("account", account[1]) if account else ("field", value)


def _spans(atom, case):
    values = atom.get("query_spans")
    if values is None:
        values = [dict(start=atom["start"], end=atom["end"],
                       text=case["query"][atom["start"]:atom["end"]])]
    return values


def _proposition_target(atom, engine):
    from matryoshka_current.proposition_matching import compile_proposition
    mode, target = _request_view(atom["text"])
    if mode != "appraisal":
        return compile_proposition(atom["text"], engine=engine)
    start = atom["text"].find(target)
    if start < 0:
        raise ValueError("Appraisal target is not a literal public-query substring")
    compiled = compile_proposition(target, engine=engine)
    compiled["query_projection"] = dict(kind="EXPLICIT_APPRAISAL_WRAPPER_ONLY",
        raw_text=atom["text"], target_text=target, start=start, end=start + len(target),
        factual_target_rephrased=False, time_modality_attribution_or_conjuncts_removed=False)
    return compiled


def _public_scope(atom, case):
    """Do not let a normalized atom silently erase visible critical operators."""
    visible = " ".join(s["text"] for s in _spans(atom, case))
    wanted = atom["text"]
    problems = []
    for value in re.findall(r"\b\d+(?:\.\d+)?\b", visible):
        if value not in wanted:
            problems.append("PUBLIC_NUMERIC_OR_TIME_SCOPE_NOT_RETAINED")
    if re.search(r"\b(?:not|never|neither)\b|n't\b", visible, re.I) and atom.get("polarity") != "negative" and not re.search(
            r"\b(?:not|never|neither)\b|n't\b", wanted, re.I):
        problems.append("PUBLIC_NEGATION_NOT_RETAINED")
    if re.search(r"\b(?:might|may|possibly|perhaps|if|unless)\b", visible, re.I) and atom.get("modality") not in {
            "possible", "conditional"} and not re.search(r"\b(?:might|may|possibly|perhaps|if|unless)\b", wanted, re.I):
        problems.append("PUBLIC_MODAL_OR_CONDITIONAL_NOT_RETAINED")
    if _RELATIVE.search(visible) and not _RELATIVE.search(wanted):
        problems.append("PUBLIC_RELATIVE_TIME_NOT_RETAINED")
    if re.search(r"\b(?:is|are|remains|remain)\b", visible, re.I) and re.search(
            r"\b(?:was|were)\b", wanted, re.I) and not re.search(r"\b(?:was|were)\b", visible, re.I):
        problems.append("PUBLIC_PRESENT_STATE_CANNOT_BECOME_PAST_ASCRIPTION")
    return sorted(set(problems))


def _prefix_blocker(page, start, engine):
    from matryoshka_current.reconstruction import _prefix
    return _prefix(page, start, engine)


def _pair(query, source):
    from matryoshka_current.proposition_matching import _pair as structural_pair
    value = structural_pair(query, source)
    reasons = list(value["reasons"])
    # A plain completed past event can be source-attested without dating it to
    # case.date. Negatives/states still need the stronger same-clock certificate.
    undated_positive = (reasons == ["SAME_EXPLICIT_EVENT_DAY_NOT_ESTABLISHED"]
        and query["kind"] == source["kind"] == "EVENT"
        and query["tense"] == source["tense"] == "past"
        and not query["negated"] and not source["negated"]
        and not query["event_dates"] and not source["event_dates"])
    if undated_positive:
        reasons = []
    direction = ("COUNTER" if query["negated"] != source["negated"] else "SUPPORT") if not reasons else "UNRESOLVED"
    return dict(value, direction=direction, reasons=reasons,
        temporal_policy="PAST_SOURCE_ATTESTATION_NOT_CASE_DATE_PERSISTENCE" if undated_positive else "EXPLICIT_SHARED_CLOCK_REQUIRED")


def _matches(compiled, source, page, engine):
    offered = source["proposition"]
    if not compiled["complete"] or not offered["complete"]:
        return None
    if _RELATIVE.search(compiled["text"]) or _RELATIVE.search(offered["text"]):
        return None
    if _prefix_blocker(page, source["citation"]["start"], engine):
        return None
    comparisons = [[_pair(q, s) for s in offered["propositions"]] for q in compiled["propositions"]]
    support = bool(comparisons) and all(any(p["direction"] == "SUPPORT" for p in row) for row in comparisons)
    counter = bool(comparisons) and all(any(p["direction"] in {"SUPPORT", "COUNTER"} for p in row)
        for row in comparisons) and any(any(p["direction"] == "COUNTER" for p in row) for row in comparisons)
    partial = any(any(p["direction"] == "SUPPORT" for p in row) for row in comparisons)
    if not support and not counter and not partial:
        return None
    direction = "CONFLICTED" if support and counter else "SUPPORT" if support else "COUNTER" if counter else "PARTIAL"
    ref = source["citation"]
    source_predicates = [p["matrix"]["start"] for p in offered["propositions"]]
    return dict(direction=direction, citation=deepcopy(ref), comparisons=comparisons,
        event_bindings=[digest([ref["canonical_page_id"], ref["start"] + p]) for p in source_predicates],
        checks=dict(eligible_source="PASS", literal_quote="PASS", ordered_roles="PASS",
            predicate_object="PASS", polarity="PASS", modality_attribution="PASS",
            temporal_scope="PASS", lexical_relevance_used_as_proof=False),
        qualified=any(p["qualified_content"] for p in offered["propositions"]),
        actual_inner_event_established=False, world_truth_certified=False)


def _predicate(atom, engine):
    value = atom.get("predicate")
    if value:
        doc = engine.parse(value)
        verbs = [t.lemma_.casefold() for t in doc if t.pos_ in {"VERB", "AUX"}]
        if len(verbs) == 1:
            return verbs[0]
        # Standalone imperative/bare lemmas are sometimes tagged as nouns. This
        # is only a query constraint; the witness still needs a real verb frame.
        tokens = [t for t in doc if not t.is_space and not t.is_punct]
        visible = {t.lemma_.casefold() for t in engine.parse(atom["text"])}
        if len(tokens) == 1 and tokens[0].lemma_.casefold() in visible:
            return tokens[0].lemma_.casefold()
        return None
    doc = engine.parse(atom["text"])
    roots = [t for t in doc if t.pos_ in {"VERB", "AUX"} and t.lemma_.casefold() not in _REQUEST
             and t.dep_ in {"ROOT", "ccomp", "xcomp"}]
    return roots[0].lemma_.casefold() if len(roots) == 1 else None


def _role_text(values):
    return [re.sub(r"^(?:the|a|an)\s+", "", normal(v["text"])) for v in values if not v.get("unresolved")]


def _subject(atom, engine):
    if atom.get("subject"):
        return atom["subject"]
    values = [p["text"] for f in engine.targets(atom["text"])
              for p in f["roles"].get("agent", f["roles"].get("owner", []))
              if not p.get("unresolved") and not _WH.intersection(normal(p["text"]).split())]
    return values[0] if len(set(values)) == 1 else None


def _need_unscoped(atom, engine):
    mode, view = _request_view(atom["text"])
    base = dict(version="next-requested-field/1", public_query_spans=deepcopy(atom.get("query_spans", [])),
        query_text=atom["text"], interpretation_text=view, answer_from_query=False,
        subject=atom.get("subject"), object=atom.get("object"),
        requested_modality=atom.get("modality", "unknown"), requested_polarity=atom.get("polarity", "unknown"),
        unknown_fields=[], executable=True, issues=[])
    if mode == "appraisal":
        from matryoshka_current.proposition_matching import compile_proposition
        return dict(base, request_kind="proposition_appraisal", target=compile_proposition(view, engine=engine),
            unknown_fields=["scoped_proposition_decision"], rendering="Signed appraisal of the public proposition")
    doc = engine.parse(view)
    wh = [t.lower_ for t in doc if t.lower_ in _WH]
    projected = dict(atom, text=view)
    predicate = _predicate(projected, engine)
    supplied = normal(atom.get("predicate") or "")
    if supplied:
        tokens = engine.parse(supplied)
        candidates = [t.lemma_.casefold() for t in tokens if t.pos_ == "VERB"]
        if len(candidates) == 1:
            predicate = candidates[0]
    nominal_projection = None
    nominal_candidates = []
    if mode == "account" and predicate is None:
        try:
            from matryoshka_demo.roles import lexicon, binding as lexical_binding
            wordnet = lexicon()
            derived = {form.name().replace("_", " ") for token in doc if token.pos_ == "NOUN"
                for lemma in wordnet.lemmas(token.lemma_.casefold(), pos="n")
                for form in lemma.derivationally_related_forms() if form.synset().pos() == "v"}
            if supplied in derived or not supplied and derived:
                nominal_candidates = [supplied] if supplied else sorted(derived)
                predicate = nominal_candidates[0] if len(nominal_candidates) == 1 else None
                nominal_projection = dict(kind="DICTIONARY_NOUN_VERB_DERIVATION_QUERY_CONSTRAINT_ONLY",
                    resource=lexical_binding(), is_evidence=False, historical_relation_inferred=False)
        except LookupError:
            pass
    if predicate in _REQUEST and predicate not in _REPORT:
        predicate = None
    if predicate in _REPORT and (wh or mode == "account"):
        return dict(base, request_kind="reported_content", predicate=predicate, wh=wh,
            subject=_subject(projected, engine), answer_role="reported_content",
            unknown_fields=["holder_bound_content"], rendering="Source-attributed account, not embedded-event truth")
    if mode == "account" or not wh:
        carrier = _subject(projected, engine)
        possessors = [t for t in doc if t.dep_ == "poss" and t.pos_ == "PROPN"]
        if len(possessors) == 1:
            from matryoshka_demo.vendor.matching import phrase
            carrier = phrase(possessors[0])["text"]
        role = re.search(r"\b(?:role|roles|office|offices|position|positions|title|titles)\b", view, re.I)
        if role:
            return dict(base, request_kind="role_account", subject=carrier, predicate=None,
                answer_role="source_role", unknown_fields=["source_role"],
                executable=bool(carrier), issues=[] if carrier else ["ROLE_CARRIER_NOT_BOUND"],
                rendering="Historical source identification; no current-tenure inference")
        preps = sorted({t.lemma_.casefold() for t in doc if t.dep_ == "prep"
                        and t.lemma_.casefold() in {"from", "to", "with", "for", "as"}})
        known_object = atom.get("object")
        if not known_object and len(preps) == 1:
            objects = [c for t in doc if t.dep_ == "prep" and t.lemma_.casefold() == preps[0]
                       for c in t.children if c.dep_ == "pobj"]
            if len(objects) == 1:
                from matryoshka_demo.vendor.matching import phrase
                known_object = phrase(objects[0])["text"]
        return dict(base, request_kind="source_account", predicate=predicate, wh=wh,
            subject=carrier, object=known_object, answer_role="source_statement",
            predicate_candidates=nominal_candidates or ([predicate] if predicate else []),
            known_object_role="prep:" + preps[0] if len(preps) == 1 else None,
            query_predicate_projection=nominal_projection,
            unknown_fields=["source_attested_account"], executable=bool((predicate or nominal_candidates) and carrier and len(preps) <= 1),
            issues=[] if (predicate or nominal_candidates) and carrier else ["ACCOUNT_RELATION_OR_CARRIER_NOT_BOUND"],
            rendering="Complete literal source account with all qualifications")
    if not predicate:
        return dict(base, request_kind="unresolved", predicate=None, wh=wh, executable=False,
            unknown_fields=["requested_field"], issues=["REQUESTED_RELATION_NOT_COMPILED"], rendering="Unresolved requested field")
    role = "patient"
    if "where" in wh:
        role = "location"
    elif "when" in wh:
        role = "event_date"
    elif "who" in wh and not atom.get("subject"):
        role = "agent"
    elif "how" in wh:
        role = "prep:as"
    else:
        preps = [t.lower_ for t in doc if t.dep_ == "prep" and t.lower_ in {"from", "to", "with", "for", "as"}]
        if len(set(preps)) == 1:
            role = "prep:" + preps[0]
    quantity = None
    for token in doc:
        if token.dep_ == "nummod" and any(t.lower_ in _WH for t in token.head.subtree):
            if token.text.isdigit():
                quantity = int(token.text)
            else:
                quantity = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5}.get(token.lower_, "UNRESOLVED")
    return dict(base, request_kind="argument_value", predicate=predicate, subject=_subject(projected, engine),
        answer_role=role, wh=wh, expected_answer_count=quantity,
        unknown_fields=[role], rendering="Literal source argument value")


def _need(atom, engine, *, unresolved_fields=()):
    """A missing optional model hint cannot erase a literal field qualifier."""
    spec = _need_unscoped(atom, engine)
    if spec["request_kind"] == "proposition_appraisal":
        return spec
    fields = set(unresolved_fields) | set(atom.get("field_intent", {}).get("unresolved_scope", []))
    if fields - {"subject", "predicate", "object"}:
        raise ValueError("Unknown withheld field-scope metadata")
    text = spec["interpretation_text"]
    doc = engine.parse(text)
    recovered = {}
    topics = [t for t in doc if t.lower_ in {"about", "on", "regarding", "concerning", "over"}
              and t.dep_ == "prep" and not any(a.dep_ == "pobj" for a in t.ancestors)]
    if topics:
        fields.add("object")
        values = [c for t in topics for c in t.children if c.dep_ == "pobj" and c.pos_ in {"NOUN", "PROPN"}]
        if len(topics) == len(values) == 1:
            tokens = [t for t in values[0].subtree if not t.is_space and not t.is_punct]
            a, b = min(t.idx for t in tokens), max(t.idx + len(t) for t in tokens)
            literal = text[a:b]
            # A conflicting retained hint is not repaired using source content.
            if not spec.get("object") or normal(spec["object"]) == normal(literal):
                spec["object"] = literal
                spec["known_object_role"] = None
                recovered["object"] = dict(text=literal, start=a, end=b, origin="LITERAL_PUBLIC_FIELD_TOPIC")
        if "object" not in recovered:
            spec["issues"].append("LITERAL_TOPIC_SCOPE_NOT_COMPILED")
    for name in sorted(fields):
        if name in recovered:
            continue
        value = spec.get(name)
        if not value:
            continue
        at = text.casefold().find(value.casefold())
        if at >= 0 and text.casefold().find(value.casefold(), at + 1) < 0:
            recovered[name] = dict(text=text[at:at + len(value)], start=at, end=at + len(value),
                                   origin="LITERAL_PUBLIC_FIELD")
        elif name == "predicate":
            verbs = [t for t in doc if t.pos_ in {"VERB", "AUX"} and t.lemma_.casefold() == value]
            if len(verbs) == 1:
                token = verbs[0]
                recovered[name] = dict(text=token.text, start=token.idx, end=token.idx + len(token),
                                       origin="LITERAL_PUBLIC_FIELD_PREDICATE")
    # An uncompiled explicit topic remains unresolved even if a model supplied
    # some other literal object elsewhere in this field.
    if topics and "LITERAL_TOPIC_SCOPE_NOT_COMPILED" in spec["issues"]:
        recovered.pop("object", None)
    unresolved = sorted(fields - set(recovered))
    spec.update(unresolved_scope=unresolved, literal_scope_bindings=recovered,
                metadata_scope_withheld=sorted(set(unresolved_fields) |
                    set(atom.get("field_intent", {}).get("unresolved_scope", []))))
    if unresolved:
        spec["executable"] = False
        spec["issues"].extend("FIELD_SCOPE_NOT_INDEPENDENTLY_BOUND:" + name for name in unresolved)
    return spec


def _source_doc(source, engine):
    if "_requested_field_doc" not in source:
        source["_requested_field_doc"] = engine.parse(source["citation"]["text"])
    return source["_requested_field_doc"]


def _argument_match(wanted, token, engine):
    if not wanted:
        return False
    from matryoshka_demo.vendor.matching import phrase, groups
    from matryoshka_demo.vendor.matching_base import phrase_matches
    target = [t for t in engine.parse(wanted) if t.dep_ == "ROOT" and t.pos_ in {"NOUN", "PROPN"}]
    if len(target) != 1:
        return False
    required, available = groups(target[0]), groups(token)
    return len(required) == len(available) and all(any(phrase_matches(r, a) for a in available) for r in required)


def _unmodeled_coordination(spec):
    text = normal(spec["interpretation_text"])
    for value in (spec.get("subject"), spec.get("object")):
        if value:
            text = text.replace(normal(value), " ")
    return bool(re.search(r"\b(?:and|or|neither|nor)\b", text))


def _topic_match(topic, content, engine):
    if not topic:
        return "FULL"
    def lexemes(text):
        return [t.lemma_.casefold() for t in engine.parse(text)
                if not t.is_punct and not t.is_space and not (t.dep_ == "det" and t.lower_ in {"a", "an", "the"})]
    wanted, actual = lexemes(topic), lexemes(content)
    if wanted and any(actual[i:i + len(wanted)] == wanted for i in range(len(actual) - len(wanted) + 1)):
        return "FULL"
    return "PARTIAL" if len(set(wanted).intersection(actual)) >= 2 else "NONE"


def _field_row(source, text, start, end, *, role, owner, complete, qualification, checks, predicate_start):
    ref = source["citation"]
    return dict(direction="SUPPORT" if complete else "PARTIAL", citation=deepcopy(ref),
        answer=dict(text=text, role=role, start=ref["start"] + start, end=ref["start"] + end,
            source_owner=owner, scope=qualification, full_source_statement=ref["text"]),
        requested_field_established=complete, qualified=True, qualified_account=ref["text"],
        event_bindings=[digest([ref["canonical_page_id"], ref["start"] + predicate_start])],
        checks=dict(eligible_source="PASS", literal_quote="PASS", generated_label_used_as_answer=False,
                    source_field_not_hypothesis_truth=True, **checks),
        actual_inner_event_established=False, world_truth_certified=False)


def _account_matches(spec, atom, source, page, engine):
    if not spec.get("executable") or _prefix_blocker(page, source["citation"]["start"], engine):
        return []
    doc = _source_doc(source, engine)
    text = source["citation"]["text"]
    result = []
    if spec["request_kind"] == "role_account":
        if (_unmodeled_coordination(spec) or re.search(
                r"\b(?:current|present|ongoing|still|at|during|since|throughout|before|after|on)\b",
                spec["query_text"], re.I)):
            return []
        from matryoshka_demo.vendor.matching import phrase
        from matryoshka_current.hypothesis_claims import _matrix_scope_error
        for role in doc:
            if role.dep_ != "appos" or role.pos_ not in {"NOUN", "PROPN"} or not _argument_match(spec["subject"], role.head, engine):
                continue
            governors = list(role.ancestors)
            if (any(t.dep_ in {"ccomp", "xcomp", "advcl", "acl", "relcl"} for t in governors)
                    or any(_matrix_scope_error(t) for t in governors if t.pos_ in {"VERB", "AUX"})
                    or any(t.dep_ == "neg" for t in role.subtree)):
                continue
            tokens = [t for t in role.subtree if not t.is_punct and not t.is_space]
            if not tokens:
                continue
            a, b = min(t.idx for t in tokens), max(t.idx + len(t) for t in tokens)
            if _RELATIVE.search(spec["query_text"]) or re.search(r"\b(?:19|20)\d\d\b", spec["query_text"]):
                continue
            result.append(_field_row(source, text[a:b], a, b, role="source_role", owner=spec["subject"], complete=True,
                qualification="HISTORICAL_SOURCE_ASCRIPTION_NOT_CURRENT_TENURE",
                checks=dict(source_role_attachment="PASS", owner="PASS", temporal_scope="HISTORICAL_ASCRIPTION_ONLY"),
                predicate_start=role.idx))
        return result
    if spec["request_kind"] == "reported_content":
        for root in doc:
            if root.dep_ != "ROOT" or root.pos_ not in {"VERB", "AUX"} or root.lemma_.casefold() != spec["predicate"]:
                continue
            subjects = [t for t in root.children if t.dep_ in {"nsubj", "nsubjpass"}]
            if len(subjects) != 1 or not _argument_match(spec["subject"], subjects[0], engine):
                continue
            if any(t.dep_ == "neg" or t.tag_ == "MD" for t in root.children):
                continue
            contents = [t for t in root.children if t.dep_ in {"ccomp", "xcomp", "dobj", "obj", "attr"}]
            for content in contents:
                tokens = list(content.subtree)
                a, b = min(t.idx for t in tokens), max(t.idx + len(t) for t in tokens)
                body = text[a:b]
                topic = _topic_match(spec.get("object"), body, engine)
                if topic == "NONE":
                    continue
                dates = re.findall(r"\b(?:19|20)\d\d\b", spec["query_text"])
                clock = not dates and not _RELATIVE.search(spec["query_text"])
                # Year tokens in an embedded event do not date the utterance.
                complete = topic == "FULL" and clock and not _unmodeled_coordination(spec)
                result.append(_field_row(source, body, a, b, role="reported_content", owner=spec["subject"], complete=complete,
                    qualification="LITERAL_HOLDER_BOUND_REPORTED_CONTENT_NOT_EMBEDDED_EVENT_TRUTH",
                    checks=dict(reporting_holder="PASS", reporting_predicate="PASS", content_scope="PRESERVED",
                        topic_scope=topic, utterance_time="UNBOUND" if not clock else "UNDATED_SOURCE_ATTESTATION"), predicate_start=root.idx))
        return result
    # A general account still needs an actual source predicate and bound actor;
    # mere noun/topic overlap never creates an established account.
    for frame in source["frames"]:
        if frame["predicate"] not in spec.get("predicate_candidates", [spec.get("predicate")]) or frame.get("unbound_arguments"):
            continue
        q = frame["qualifiers"]
        if q.get("scope") or q.get("attribution") or q.get("modality") or q.get("conditional") or q.get("unresolved"):
            continue
        actors = frame["roles"].get("agent", frame["roles"].get("owner", []))
        if normal(spec["subject"]) not in _role_text(actors):
            continue
        object_values = (frame["roles"].get(spec["known_object_role"], []) if spec.get("known_object_role") else
            [v for name, values in frame["roles"].items() if name not in {"agent", "owner"} for v in values])
        if spec.get("object") and re.sub(r"^(?:the|a|an)\s+", "", normal(spec["object"])) not in _role_text(object_values):
            continue
        topic = _topic_match(spec.get("object"), text, engine)
        if topic == "NONE":
            continue
        complete = (topic == "FULL" and source["proposition"]["complete"] and not _unmodeled_coordination(spec) and not _RELATIVE.search(spec["query_text"])
            and not re.search(r"\b(?:19|20)\d\d\b", spec["query_text"]))
        result.append(_field_row(source, text, 0, len(text), role="source_statement", owner=spec["subject"], complete=complete,
            qualification="SOURCE_ATTESTED_ACCOUNT_NOT_EXHAUSTIVE_HISTORY",
            checks=dict(ordered_actor_predicate="PASS", topic_scope=topic, complete_source_clause=source["proposition"]["complete"]),
            predicate_start=frame["predicate_proof"]["start"]))
    return result


def _need_matches(spec, atom, source, page, engine):
    """Fill actual source argument fields, never a generated annotation/label."""
    if _prefix_blocker(page, source["citation"]["start"], engine):
        return []
    if not spec.get("executable", True):
        return []
    if spec["request_kind"] == "proposition_appraisal":
        match = _matches(spec["target"], source, page, engine)
        return [match] if match is not None else []
    if spec["request_kind"] in {"reported_content", "role_account", "source_account"}:
        return _account_matches(spec, atom, source, page, engine)
    result = []
    for frame in source["frames"]:
        if frame["predicate"] != spec["predicate"] or frame.get("unbound_arguments") or frame.get("deictic_time"):
            continue
        q = frame["qualifiers"]
        if q.get("conditional") or q.get("modality") or q.get("unresolved") or q.get("question"):
            continue
        expected_negative = spec["requested_polarity"] == "negative"
        if q.get("negated", False) != expected_negative:
            continue
        # Do not drop a reported holder/modality to answer an unqualified event.
        if q.get("scope") or q.get("attribution"):
            continue
        roles = frame["roles"]
        agents = roles.get("agent", roles.get("owner", []))
        if spec["subject"] and re.sub(r"^(?:the|a|an)\s+", "", normal(spec["subject"])) not in _role_text(agents):
            continue
        if spec["object"] and re.sub(r"^(?:the|a|an)\s+", "", normal(spec["object"])) not in _role_text(roles.get("patient", [])):
            continue
        if _RELATIVE.search(atom["text"]):
            continue
        requested_dates = re.findall(r"\b(?:19|20)\d\d\b", atom["text"])
        if requested_dates and not all(value in " ".join(d["text"] for d in frame.get("event_dates", [])) for value in requested_dates):
            continue
        key = spec["answer_role"]
        if key == "event_date":
            values = frame.get("event_dates", [])
        elif key == "location":
            values = [v for r in ("prep:in", "prep:at", "prep:near") for v in roles.get(r, [])]
        else:
            values = roles.get(key, [])
        for value in values:
            if value.get("unresolved"):
                continue
            proofs = value.get("proofs", [])
            a = min((p["start"] for p in proofs), default=value.get("start"))
            b = max((p["end"] for p in proofs), default=value.get("end"))
            if a is None or b is None or not 0 <= a < b <= len(source["citation"]["text"]):
                continue
            fill = source["citation"]["text"][a:b]
            result.append(dict(direction="SUPPORT", citation=deepcopy(source["citation"]), requested_field_established=True,
                answer=dict(text=fill, role=key, start=source["citation"]["start"] + a,
                    end=source["citation"]["start"] + b, source_owner=spec["subject"],
                    scope="ATTESTED_SOURCE_VALUE_NOT_EXHAUSTIVE_WORLD_ENUMERATION"),
                event_bindings=[digest([source["citation"]["canonical_page_id"],
                    source["citation"]["start"] + frame["predicate_proof"]["start"]])],
                checks=dict(eligible_source="PASS", literal_quote="PASS", ordered_roles="PASS",
                    predicate_object="PASS", polarity="PASS", modality_attribution="PASS",
                    temporal_scope="PASS", open_object_filled_from_raw_source=True,
                    generated_label_used_as_answer=False),
                actual_inner_event_established=False, world_truth_certified=False))
    return result


def _dedup(evidence):
    output = {}
    for row in evidence:
        ref = row["citation"]
        # Exact copied quotes do not create independent support votes.
        key = (normal(ref["text"]), row["direction"], normal(row.get("answer", {}).get("text", "")))
        if key in output:
            output[key].setdefault("duplicate_source_citations", []).append(ref)
        else:
            output[key] = row
    return list(output.values())


def _historical_roles(case, plan, atoms, positions, corpus, policy, engine):
    """Reuse only raw role certificates under an explicit normalized projection."""
    eligible_atoms = []
    negative_ascriptions = set()
    for atom in atoms:
        if _public_scope(atom, case):
            continue
        mode, target = _request_view(atom["text"])
        if atom.get("kind", "proposition") != "proposition" and mode != "appraisal":
            continue
        text = target if mode == "appraisal" else atom["text"]
        negated = re.fullmatch(r"(?P<person>.+?)\s+(?:was|is)\s+not\s+identified\s+as\s+(?:the\s+)?"
            r"(?P<role>[A-Za-z]+)\s+of\s+(?:the\s+)?(?P<unit>[^.!?]+)[.]?", text, re.I)
        if negated is None:
            negated = re.fullmatch(r"(?:eligible\s+)?(?:earlier|prior)\s+(?:sources|records|accounts)\s+"
                r"do\s+not\s+identify\s+(?P<person>.+?)\s+as\s+(?:the\s+)?(?P<role>[A-Za-z]+)\s+"
                r"of\s+(?:the\s+)?(?P<unit>[^.!?]+)[.]?", text, re.I)
        if negated is not None:
            if _RELATIVE.search(text) or re.search(r"\b(?:19|20)\d\d\b|\b(?:during|throughout|since|before|after|on)\b", text, re.I):
                continue
            text = negated["person"].strip() + " was " + negated["role"] + " of " + negated["unit"].strip() + "."
            negative_ascriptions.add(atom["id"])
        eligible_atoms.append(dict(atom, text=text))
    if not eligible_atoms or case["task"] != "hypothesis":
        return {}
    from matryoshka_current.hypothesis_claims import role_claim_bindings
    canonical, projected = "", []
    for atom in eligible_atoms:
        if canonical:
            canonical += " "
        start = len(canonical)
        canonical += atom["text"]
        projected.append(dict(id=atom["id"], text=atom["text"], source_quote=atom["text"],
                              start=start, end=len(canonical), required=True))
    projection_case = dict(case, query=canonical)
    projection_plan = dict(query_sha256=digest(canonical), atoms=projected)
    admitted = {corpus.pages[pi]["id"]: corpus.pages[pi] for pi in positions}
    source_tuple = (policy.bound_pages, {pid: pid in admitted for pid in policy.bound_pages}, policy.veto)
    records = role_claim_bindings(projection_case, projection_plan, admitted, source_tuple, engine=engine)
    output = {}
    for record in records:
        counter_lookup = record["atom_id"] in negative_ascriptions
        if record["direction"] != "SUPPORT" and not (counter_lookup and record.get("certificates")):
            continue
        checked = []
        for certificate in record["certificates"]:
            ref = certificate["citation"]
            pi = next(pi for pi in positions if corpus.pages[pi]["id"] == ref["canonical_page_id"])
            actual = policy.citation(pi, ref["start"], ref["end"])
            if actual["text"] != ref["text"]:
                raise ValueError("Reused raw role certificate changed quote")
            counter = record["atom_id"] in negative_ascriptions
            checked.append(dict(direction="COUNTER" if counter else "SUPPORT", citation=actual, qualified=True,
                qualified_account=record["qualified_assertion"], event_bindings=[],
                checks=dict(eligible_source="PASS", literal_quote="PASS", ordered_roles="PASS",
                    predicate_object="PASS", polarity="PASS", modality_attribution="PASS",
                    temporal_scope="HISTORICAL_ASCRIPTION_ONLY_NOT_TENURE"),
                certificate=certificate, source_claim_binding=record,
                normalized_public_requirement_projection=True,
                ascription_counter_scope="EXPLICIT_NEGATIVE_SOURCE_IDENTIFICATION_REFUTED_BY_POSITIVE_EXISTENTIAL_IDENTIFICATION" if counter else None,
                time_local_tenure_denial_refuted=False,
                actual_inner_event_established=False, world_truth_certified=False))
        if checked:
            output[record["atom_id"]] = checked
    return output


def _summary(atoms, task, scope_complete):
    required = [a for a in atoms if a["required"]]
    counts = {s: sum(a["criterion_state"] == s for a in required) for s in STATES}
    supported, opposed = counts["SUPPORTED"], counts["OPPOSED"]
    n = len(required)
    if supported and opposed:
        status = "MIXED"
    elif counts["CONFLICTED"]:
        status = "CONFLICTED"
    elif n and supported == n and scope_complete:
        status = "SUPPORTED" if task == "hypothesis" else "EVIDENCE_BACKED_RECONSTRUCTION"
    elif n and opposed == n:
        status = "OPPOSED"
    elif supported:
        status = "PARTIAL_SUPPORT" if task == "hypothesis" else "PARTIAL_RECONSTRUCTION"
    elif opposed:
        status = "PARTIAL_OPPOSITION"
    elif counts["FEASIBLE"]:
        status = "PARTIAL_CONTEXT" if task == "hypothesis" else "PARTIAL_RECONSTRUCTION"
    else:
        status = "UNRESOLVED"
    return dict(status=status, required_atoms=n, counts=counts, fractions={s: dict(
        numerator=v, denominator=n, label=f"{v}/{n}") for s, v in counts.items()},
        supported_atom_ids=[a["id"] for a in required if a["criterion_state"] == "SUPPORTED"],
        opposed_atom_ids=[a["id"] for a in required if a["criterion_state"] == "OPPOSED"],
        joint_bindings_established=scope_complete, counts_are_probabilities=False,
        cross_atom_mixed=bool(supported and opposed),
        within_atom_source_conflict=bool(counts["CONFLICTED"]), world_truth_certified=False)


def _source_subject_bindings(row, subject, engine):
    """Bind a shared actor to one literal assertion, not its containing page."""
    if engine is None:
        return set()
    ref = row["citation"]
    bindings = set(row.get("event_bindings", []))
    positions = set()
    for token in engine.parse(ref["text"]):
        if digest([ref["canonical_page_id"], ref["start"] + token.idx]) not in bindings:
            continue
        if token.dep_ == "appos":
            owners = [token.head]
        else:
            owners = [t for t in token.children if t.dep_ in {"nsubj", "csubj"}]
            owners += [t for agent in token.children if agent.dep_ == "agent"
                       for t in agent.children if t.dep_ == "pobj"]
        for owner in owners:
            if _argument_match(subject, owner, engine):
                positions.add((ref["canonical_page_id"], ref["page_sha256"], ref["start"],
                    ref["end"], ref["start"] + owner.idx, ref["start"] + owner.idx + len(owner)))
    return positions


def _scope(case, plan, atoms, corpus=None, engine=None):
    required = [a for a in atoms if a["required"]]
    checks = []
    known = {a["id"]: a for a in atoms}
    groups = plan.get("scope_constraints", [])
    components = []
    for group in groups:
        ids = group.get("atom_ids", [])
        if group.get("kind") != "same_event" or len(set(ids)) < 2 or set(ids) - set(known):
            checks.append(dict(state="UNRESOLVED", reason="UNSUPPORTED_OR_UNBOUND_SCOPE_CONSTRAINT"))
            continue
        group_set = set(ids)
        overlaps = [c for c in components if c.intersection(group_set)]
        for component in overlaps:
            group_set.update(component)
            components.remove(component)
        components.append(group_set)
    for component in components:
        ids = sorted(component)
        events = [set(e for row in known[identity]["positive_evidence"] for e in row.get("event_bindings", [])) for identity in ids]
        shared = set.intersection(*events)
        checks.append(dict(kind="same_event", atom_ids=ids, state="SATISFIED" if shared else "UNRESOLVED",
            shared_event_bindings=sorted(shared), reason="SOURCE_PREDICATE_OCCURRENCE_IDENTITY_REQUIRED"))
    subjects = {}
    for atom in required:
        subject = atom.get("subject_binding", atom.get("subject"))
        if subject:
            subjects.setdefault(normal(subject), []).append(atom)
    for subject, members in subjects.items():
        if len(members) < 2:
            continue
        local_bindings = [set().union(*(_source_subject_bindings(r, subject, engine)
            for r in a["positive_evidence"])) for a in members]
        shared_local = set.intersection(*local_bindings)
        local = bool(shared_local)
        authorized, source_authorized = [], []
        if corpus is not None:
            for member in members:
                identities, source_identities = set(), set()
                for row in member["positive_evidence"]:
                    ref = row["citation"]
                    for occurrence in getattr(corpus, "occurrences", []):
                        pi = occurrence["page_index"]
                        authority = getattr(corpus, "nodes", {}).get(occurrence["node_id"], {}).get("native_reference_authority", {})
                        if (corpus.pages[pi]["id"] == ref["canonical_page_id"]
                                and ref["start"] <= occurrence["start"] < occurrence["end"] <= ref["end"]
                                and normal(occurrence.get("label", "")) == subject
                                and normal(corpus.pages[pi]["text"][occurrence["start"]:occurrence["end"]]) == subject):
                            if authority.get("global_identity_authorized") is True:
                                identities.add(occurrence["node_id"])
                            if authority.get("source_identity_authorized") is True:
                                source_identities.add((ref["canonical_page_id"], occurrence["node_id"]))
                authorized.append(identities)
                source_authorized.append(source_identities)
        global_identity = bool(authorized and set.intersection(*authorized))
        source_identity = bool(source_authorized and set.intersection(*source_authorized))
        checks.append(dict(kind="shared_subject", subject=subject,
            atom_ids=[a["id"] for a in members], state="SATISFIED" if local or global_identity or source_identity else "UNRESOLVED",
            reason="SAME_SOURCE_ASSERTION_SUBJECT_OR_AUTHORIZED_REFERENCE_REQUIRED",
            global_identity_certified=global_identity, source_identity_certified=source_identity,
            local_account_only=local and not global_identity, shared_source_subject_bindings=sorted(shared_local),
            shared_page_alone_is_identity=False))
    if len(required) > 1 and _LINK.search(case["query"]) and not groups:
        checks.append(dict(state="UNRESOLVED", reason="PUBLIC_CROSS_ATOM_EVENT_OR_CAUSAL_LINK_NOT_CERTIFIED"))
    if len(required) > 1 and re.search(r"\bsame\s+(?:office|unit|organization|place|object|person)\b", case["query"], re.I):
        if not any(c.get("kind") == "shared_subject" and c["state"] == "SATISFIED" for c in checks):
            checks.append(dict(state="UNRESOLVED", reason="PUBLIC_SHARED_REFERENT_NOT_JOINTLY_CERTIFIED"))
    information = [a for a in required if a.get("kind") == "information_need" and not a.get("proposition_appraisal")]
    if len(information) > 1 and len(re.findall(r"\b(?:who|what|which|where|when|how)\b", case["query"], re.I)) == 1:
        checks.append(dict(state="UNRESOLVED", reason="SHARED_OPEN_INFORMATION_VARIABLE_NEEDS_JOINT_ROLE_BINDING"))
    complete = all(c["state"] == "SATISFIED" for c in checks)
    return dict(complete=complete, checks=checks, independent_atom_merges_used_as_joint_proof=False,
        source_publication_used_as_event_time=False)


def execute(case, plan, retrieval, *, passage_budget=100, source_index=None,
            engine=None, source_groups=None, previous_casefile=None):
    case = public_plan(case, plan)
    if case["task"] not in {"hypothesis", "reconstruction"}:
        raise ValueError("Directed task decisions are H/R only")
    if type(passage_budget) is not int or passage_budget < 1:
        raise ValueError("Positive source inspection budget required")
    corpus = retrieval["eligible"].corpus
    if source_index is None:
        source_index = retrieval.get("source_index")
    policy = SourcePolicy(corpus, case, source_index)
    index = fact_index(corpus)
    engine = engine or index.linguistic_engine()
    positions = retrieval["pages"][:min(passage_budget, retrieval.get("passage_budget", passage_budget))]
    if any(not isinstance(i, (int,)) or isinstance(i, bool) for i in positions):
        # NumPy index scalars are accepted, but floats and bools never are.
        from numbers import Integral
        if any(not isinstance(i, Integral) or isinstance(i, bool) for i in positions):
            raise ValueError("Explicit admitted page indices required")
    positions = [int(i) for i in positions]
    if len(set(positions)) != len(positions):
        raise ValueError("Duplicate inspected source page")
    for pi in positions:
        page = corpus.pages[pi]
        if not policy.allowed(pi) or digest(page["text"]) != page["source_sha256"]:
            raise ValueError("Inspected source is ineligible or changed")
        bound = policy.bound_pages.get(page["id"])
        if bound is None or bound["text"] != page["text"] or bound["source_sha256"] != page["source_sha256"]:
            raise ValueError("Inspected source differs from explicit complete index")
    index.prime_local_records(positions)
    role_evidence = _historical_roles(case, plan, plan["atoms"], positions, corpus, policy, engine)
    specs = {}
    for atom in plan["atoms"]:
        kind = atom.get("kind", "proposition")
        withheld = {r["field"] for r in plan.get("projection_qc", [])
            if r.get("table") == "atoms" and r.get("local_id") == atom["id"]
            and r.get("field") in {"subject", "predicate", "object"}
            and str(r.get("reason", "")).endswith("WITHHELD")}
        specs[atom["id"]] = (_need(atom, engine, unresolved_fields=withheld) if kind == "information_need" else
            _proposition_target(atom, engine))
        if kind == "information_need":
            # A shared public clock is not licensed to disappear merely because
            # the model's atom quotation selected only its local topic fragment.
            clock = re.search(r"\b(?:during|in|on|throughout|since)\b[^.?;]{0,70}\b(?:19|20)\d\d\b", case["query"], re.I)
            if clock and any(value not in atom["text"] for value in re.findall(r"\b(?:19|20)\d\d\b", clock[0])):
                specs[atom["id"]]["unprojected_public_time_scope"] = clock[0]
    atoms = []
    considered, parsed = 0, set()
    for atom in plan["atoms"]:
        kind = atom.get("kind", "proposition")
        blockers = _public_scope(atom, case)
        spec = specs[atom["id"]]
        appraisal = kind == "proposition" or kind == "information_need" and spec.get("request_kind") == "proposition_appraisal"
        query_target = spec.get("target") if kind == "information_need" and appraisal else spec
        if kind == "information_need" and not spec.get("executable", True):
            blockers.extend(spec.get("issues", []))
        if kind == "proposition" and atom.get("polarity", "unknown") != "unknown" and spec["propositions"]:
            if any(p["negated"] != (atom["polarity"] == "negative") for p in spec["propositions"]):
                blockers.append("NORMALIZED_POLARITY_AND_PUBLIC_METADATA_DISAGREE")
        evidence = list(role_evidence.get(atom["id"], [])) if not blockers else []
        if kind != "context" and spec is not None and not blockers:
            subject = atom.get("subject")
            terms = set(re.findall(r"[a-z0-9]+", (subject or atom["text"]).casefold())) - {
                "the", "a", "an", "did", "does", "was", "were", "what", "which", "how", "who", "and", "of", "to"}
            for pi in positions:
                page = corpus.pages[pi]
                for unit in sentences(page["text"]):
                    considered += 1
                    # A lexical screen schedules NLP; it is never a support rule.
                    if terms and not terms.intersection(re.findall(r"[a-z0-9]+", unit["text"].casefold())):
                        continue
                    try:
                        source = index.source_clause(policy, pi, unit["start"], unit["end"], engine=engine)
                    except ValueError as error:
                        if "Opaque" in str(error):
                            continue
                        raise
                    parsed.add((pi, unit["start"], unit["end"]))
                    if kind == "information_need":
                        matches = _need_matches(spec, atom, source, page, engine)
                        for match in matches:
                            if spec.get("unprojected_public_time_scope") and match["direction"] in {"SUPPORT", "COUNTER"}:
                                match = dict(match, direction="PARTIAL", requested_field_established=False,
                                    public_shared_time_unresolved=spec["unprojected_public_time_scope"])
                            if case["task"] == "hypothesis" and not appraisal and match["direction"] == "SUPPORT":
                                match = dict(match, direction="PARTIAL", requested_field_established=True,
                                    field_answer_is_not_hypothesis_support=True)
                            evidence.append(match)
                    else:
                        match = _matches(spec, source, page, engine)
                        if match is not None:
                            evidence.append(match)
        evidence = _dedup(evidence)
        if kind == "information_need" and spec.get("expected_answer_count") is not None:
            count = len({normal(e["answer"]["text"]) for e in evidence if "answer" in e and e["direction"] == "SUPPORT"})
            if spec["expected_answer_count"] == "UNRESOLVED" or count != spec["expected_answer_count"]:
                evidence = [dict(e, direction="PARTIAL", requested_field_established=False,
                    requested_quantity_not_established=True) if e["direction"] == "SUPPORT" else e for e in evidence]
        field_evidence = [r for r in evidence if r.get("requested_field_established") or "answer" in r]
        positive = [r for r in evidence if r["direction"] in {"SUPPORT", "CONFLICTED"}]
        negative = [r for r in evidence if r["direction"] in {"COUNTER", "CONFLICTED"}]
        partial = [r for r in evidence if r["direction"] == "PARTIAL"]
        state = "CONFLICTED" if positive and negative else "SUPPORTED" if positive else "OPPOSED" if negative else "FEASIBLE" if partial else "NO_INFO"
        if kind == "context":
            state = "NO_INFO"
        status = {"SUPPORTED": "SUPPORT" if case["task"] == "hypothesis" else "ESTABLISHED",
            "OPPOSED": "OPPOSED", "CONFLICTED": "CONFLICTED", "FEASIBLE": "PARTIAL",
            "NO_INFO": "UNRESOLVED" if case["task"] == "hypothesis" else "INSUFFICIENT"}[state]
        coverage = dict(complete=state == "SUPPORTED", issues=blockers + ([] if positive else [
            "NO_COMPLETE_SCOPED_SOURCE_WITNESS"]), source_actor_predicate_object_verified=bool(positive))
        requirement = dict(id=atom["id"] + ".criterion", text=atom["text"], kind=kind,
            status=status, criterion_state=state, coverage=coverage, evidence=evidence,
            constraint_state="SATISFIED" if positive and not negative else "VIOLATED" if negative and not positive else "UNRESOLVED",
            opposition_is_not_missing=bool(negative), blockers=blockers)
        atoms.append(dict(id=atom["id"], text=atom["text"], kind=kind,
            subject_binding=spec.get("subject") if kind == "information_need" else _subject(atom, engine),
            required=atom.get("required", kind != "context"), status=status, criterion_state=state,
            requirements=[requirement], positive_evidence=positive, counterevidence=negative, partial_evidence=partial,
            evidence=evidence, answers=[deepcopy(e["answer"]) for e in field_evidence if "answer" in e],
            requested_field=deepcopy(spec) if kind == "information_need" else None,
            query_projection=deepcopy(spec.get("query_projection")),
            proposition_appraisal=appraisal, information_coverage="Established" if any(
                r.get("requested_field_established") for r in field_evidence) else "Partial" if field_evidence else "Unresolved",
            qualified_accounts=[dict(text=e.get("qualified_account", "The eligible source attests this qualified account; its embedded event is not independently certified."))
                for e in evidence if e.get("qualified")], actual_inner_event_established=False,
            complete_role_or_raw_clause_certificate=bool(positive) and not negative))
    scope = _scope(case, plan, atoms, corpus, engine)
    overall = _summary(atoms, case["task"], scope["complete"])
    if case["task"] == "hypothesis":
        overall.update(required_proposition_appraisals=sum(a["required"] and a["proposition_appraisal"] for a in atoms),
            answered_source_fields=[a["id"] for a in atoms if not a["proposition_appraisal"] and a["information_coverage"] == "Established"],
            field_context_does_not_promote_hypothesis=True)
    binding = dict(case_id=case["case_id"], query_sha256=digest(case["query"]),
        plan_sha256=digest(plan), source_pages={corpus.pages[i]["id"]: corpus.pages[i]["source_sha256"] for i in positions})
    if previous_casefile is not None:
        old = previous_casefile.get("binding", {})
        if (any(old.get(k) != binding[k] for k in ("case_id", "query_sha256", "plan_sha256"))
                or previous_casefile.get("sha256") != digest({k: v for k, v in previous_casefile.items() if k != "sha256"})):
            raise ValueError("Previous candidate casefile belongs to another binding or changed")
    casefile = dict(version=VERSION, binding=binding, criteria=deepcopy(atoms), scope=deepcopy(scope),
        previous_revision_sha256=previous_casefile.get("sha256") if previous_casefile else None,
        source_history_is_exhaustive=False, search_exhaustion_is_not_logical_opposition=True)
    casefile["sha256"] = digest(casefile)
    return dict(version=VERSION, case_id=case["case_id"], task=case["task"], status=overall["status"],
        atoms=atoms, overall=overall, query_requirements=scope, candidate_casefile=casefile,
        inspected_page_ids=[corpus.pages[i]["id"] for i in positions], source_pages_inspected=len(positions),
        source_pages_admitted=len(retrieval["pages"]), passage_budget=passage_budget,
        source_sentences_considered=considered, unique_source_sentences_parsed=len(parsed),
        query_sha256=digest(case["query"]), provided_plan_sha256=digest(plan),
        fact_index=index.stats(), keys_read=False, grades_read=False, api_calls=0,
        old_native_result_reused=False, kernel_mass_used_as_confidence=False,
        world_truth_certified=False, limitations=[
            "Literal structural and source-role matching, not a general entailment or discourse resolver.",
            "Unknown event identity, temporal completeness and unsupported cross-atom links remain unresolved.",
            "Open information needs report attested fields, not exhaustive world-history answers.",
            "Only admitted inspected pages supply evidence; no origin, keys, past results or model annotations are proof."])
