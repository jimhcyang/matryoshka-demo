"""Query-only fixed-family readers. No API, corpus, source origin or fill input.

compile_readings(case, nlp=None) runs a local spaCy reader. Model callers use
from_model_response(response, case); there is deliberately no paid-call helper.
validate_readings(packet, case) replays the entire detached packet. A legacy
constructor view is available only for declared subset-compatible readings.
Recognition, grammar hints and quote integrity never certify factual support.
"""
from copy import deepcopy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re

from jsonschema import Draft202012Validator, SchemaError, ValidationError
from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest


VERSION = "next-slot-readings/3"
LOCAL_VERSION = "next-local-spacy-readings/3"
CONSTRUCTOR_ROUTING_VERSION = "next-possessor-surface-routing/1"
MODEL_SCHEMA_VERSION = "next-reading-wire/2"
MODEL_STAGE = "next_grammatical_readings_v2"
MODEL_PROJECTION_VERSION = "next-reading-typed-constraint-projection/1"
TYPED_CUE_PROMPT_VERSION = "next-reading-typed-cues-prompt/1"
ROOT = Path(__file__).resolve().parents[1]
CONTRACTS = ROOT / "contracts/next_readings"
REGISTRY = json.loads((CONTRACTS / "registry.json").read_text())
REGISTRY_SHA256 = hashlib.sha256((CONTRACTS / "registry.json").read_bytes()).hexdigest()
MODEL_RESPONSE_SCHEMA = json.loads((CONTRACTS / "model_response.v2.schema.json").read_text())
MODEL_SCHEMA_SHA256 = hashlib.sha256((CONTRACTS / "model_response.v2.schema.json").read_bytes()).hexdigest()
# Preserve the original tighter local contract, including bounds/uniqueness.
# Provider wire restrictions must not relax what is admitted after decoding.
MODEL_VALIDATION_SCHEMA = json.loads((CONTRACTS / "model_response.schema.json").read_text())
REGISTRY_VERSION = REGISTRY["version"]
FAMILIES = {row["id"]: row for row in REGISTRY["families"]}
ORDER = {name: index for index, name in enumerate(FAMILIES)}
PUBLIC_FIELDS = frozenset({"case_id", "corpus", "task", "query", "document_id", "date", "focal_marker"})
PROMPT = (
    "Select grammatical interpretations of the exact public gap from the fixed registry only. "
    "Use only visible query grammar and literal cue/attachment spans. Do not fill the gap, "
    "name a hidden entity, consult history or sources, generate questions/keywords, or predict "
    "an answer. Form is the FINAL inserted surface, independent of function and target-kind "
    "hint. A nominal source plus a proposed example linker has a prepositional final surface. "
    "Retain genuine alternatives and scoped operators; hidden operators are hypothetical, "
    "not observed. Unknown means abstain with no readings, never all-family fallback. "
    "Return the response schema only; explanations and constructor routes are bound locally."
)
# Opt-in prompt revision. Keep PROMPT unchanged so successful v2 calls remain
# exact cache hits; this decoder repair itself never requires another call.
PROMPT_WITH_TYPED_CUES = PROMPT + (
    " For each nondefault target_kind include an exact target_kind cue; for singular or plural "
    "include an exact number cue; for a non-null finite value include an exact finite cue. "
    "An attachment cue does not substitute for these typed cues. Otherwise use target_kind=any, "
    "grammatical_number=unknown and finite=null. Never infer a possessor's number from its "
    "possessed noun, promote a pronoun to a known identity, or invent a cue or hidden word."
)


def _case(case):
    if not isinstance(case, dict) or set(case) != PUBLIC_FIELDS:
        raise ValueError("Reader requires exactly seven public case fields; no private extras")
    value = public_case(case)
    if value["task"] != "redaction" and value["focal_marker"] != "":
        raise ValueError("H/R have no focal slot or reading stage")
    return value


def schema():
    audit_provider_schema(MODEL_RESPONSE_SCHEMA)
    return deepcopy(MODEL_RESPONSE_SCHEMA)


def audit_provider_schema(value):
    """Conservative offline wire-subset check, not a provider acceptance claim."""
    try:
        Draft202012Validator.check_schema(value)
    except SchemaError as error:
        raise ValueError("Invalid JSON schema: " + error.message) from error
    allowed = {"title", "description", "$defs", "$ref", "type", "properties", "required",
               "additionalProperties", "enum", "anyOf", "items"}
    definitions = value.get("$defs", {})
    objects = []

    def visit(node, path):
        if not isinstance(node, dict):
            raise ValueError("Schema node must be an object: " + path)
        unsupported = set(node) - allowed
        if unsupported:
            raise ValueError("Unsupported conservative provider keyword at " + path + ": " + ",".join(sorted(unsupported)))
        if "$ref" in node:
            reference = node["$ref"]
            if not isinstance(reference, str) or not reference.startswith("#/$defs/") or reference[8:] not in definitions:
                raise ValueError("Unbound/nonlocal schema reference at " + path)
        elif "type" not in node and "anyOf" not in node:
            raise ValueError("Explicit schema type or anyOf required at " + path)
        if node.get("type") == "object":
            props = node.get("properties", {})
            if node.get("additionalProperties") is not False or set(node.get("required", [])) != set(props):
                raise ValueError("All object properties must be required and closed: " + path)
            objects.append(path)
            for name, child in props.items():
                visit(child, path + ".properties." + name)
        if node.get("type") == "array":
            if "items" not in node:
                raise ValueError("Array items required at " + path)
            visit(node["items"], path + ".items")
        for index, child in enumerate(node.get("anyOf", [])):
            visit(child, path + ".anyOf[" + str(index) + "]")
        for name, child in node.get("$defs", {}).items():
            visit(child, path + ".$defs." + name)
    if value.get("type") != "object" or "anyOf" in value:
        raise ValueError("Provider schema root must be one object")
    visit(value, "$")
    return dict(status="PASS_CONSERVATIVE_LOCAL_SCHEMA_CHECK", closed_object_definitions=len(objects),
        provider_acceptance_tested=False, api_calls=0)


def model_input(case):
    """No annotations/evidence are fetched; the common base is owned elsewhere."""
    case = _case(case)
    if case["task"] != "redaction":
        raise ValueError("H/R must skip the model-reading stage")
    return dict(task=case["task"], query=case["query"], focal_marker=case["focal_marker"],
        registry=deepcopy(REGISTRY), registry_sha256=REGISTRY_SHA256, model_schema_version=MODEL_SCHEMA_VERSION)


def _span(query, start, end):
    return dict(start=start, end=end, text=query[start:end])


def _check_span(query, value, *, scope=False):
    if value is None:
        return
    a, b = value["start"], value["end"]
    if not (type(a) is int and type(b) is int and 0 <= a < b <= len(query) and query[a:b] == value["text"]):
        raise ValueError("Reading quote does not replay in original Unicode code-point coordinates")
    if not scope and any(a < m.end() and m.start() < b for m in MASK.finditer(query)):
        raise ValueError("Opaque text cannot be a visible reading cue or attachment")


def _adjacent(case):
    q, marker = case["query"], case["focal_marker"]
    a, b = q.index(marker), q.index(marker) + len(marker)
    return any((m.start(), m.end()) != (a, b) and (
        m.end() <= a and not q[m.end():a].strip() or m.start() >= b and not q[b:m.start()].strip())
        for m in MASK.finditer(q))


def _possessor_binding(row, case):
    """Bind the chosen possessor function to visible surface morphology only.

    This neither supplies a hidden possessor nor derives person/number from a
    following pronoun. Ambiguous/incompatible surface declarations are held,
    never silently sent down the plain-nominal path.
    """
    q, marker = case["query"], case["focal_marker"]
    a, b = q.index(marker), q.index(marker) + len(marker)
    right, left = q[b:], q[:a]
    suffix = re.match(r"\s*(?P<suffix>['\u2019]s|s['\u2019])(?=\s|\W|$)", right)
    of = re.search(r"\bof\s*$", left, re.I)
    suffix_span = _span(q, b + suffix.start("suffix"), b + suffix.end("suffix")) if suffix else None
    of_span = _span(q, of.start(), of.start()+2) if of else None
    declared = [w for w in row["wrappers"] if w["kind"] == "genitive"]
    inside = any(w["placement"] == "inside_gap" for w in declared)
    external = [s for w in declared if w["placement"] == "visible" for s in w["spans"]]
    route, reason, cues = None, "UNRESOLVED_POSSESSOR_SURFACE", []
    heads = row["attachment_spans"]
    if any(w["kind"] != "genitive" for w in row["wrappers"]):
        reason = "NON_GENITIVE_WRAPPER_REQUIRES_EXPLICIT_CONSTRUCTOR"
    elif len(heads) != 1:
        reason = "ONE_BOUND_POSSESSED_CARRIER_REQUIRED"
    elif suffix_span is not None:
        cues = [suffix_span]
        if heads[0]["start"] < suffix_span["end"] or q[suffix_span["end"]:heads[0]["start"]].strip():
            reason = "VISIBLE_SUFFIX_NOT_ADJACENT_TO_BOUND_CARRIER"
        elif inside or external and external != [suffix_span]:
            reason = "DECLARED_GENITIVE_CONFLICTS_WITH_VISIBLE_SUFFIX"
        else:
            route, reason = "nominal", "GENITIVE_SUFFIX_ALREADY_VISIBLE"
    elif external and external != ([of_span] if of_span is not None else []):
        reason = "VISIBLE_GENITIVE_DECLARATION_NOT_AT_SLOT_BOUNDARY"
    elif heads[0]["start"] >= b and not q[b:heads[0]["start"]].strip():
        # The exact carrier is adjacent to the gap. Its number/category does
        # not license a person/singular hint about the missing possessor.
        if external:
            reason = "VISIBLE_GENITIVE_DECLARATION_DOES_NOT_LICENSE_THIS_CARRIER"
        else:
            route, reason, cues = "possessive", "POSSESSOR_FUNCTION_BEFORE_BARE_CARRIER", [deepcopy(heads[0])]
    elif of_span is not None and heads[0]["end"] <= of_span["start"] and not q[heads[0]["end"]:of_span["start"]].strip():
        cues = [of_span]
        if inside:
            reason = "DECLARED_INNER_GENITIVE_CONFLICTS_WITH_OF_COMPLEMENT"
        else:
            route, reason = "nominal", "POSSESSOR_IS_VISIBLE_OF_COMPLEMENT"
    return dict(version=CONSTRUCTOR_ROUTING_VERSION, constructor_form=route, reason=reason,
        query_spans=cues, source="CHOSEN_FUNCTION_AND_PUBLIC_BOUNDARY_NOT_MODEL_FILL",
        raw_wrappers_changed=False, person_or_number_inferred=False,
        hidden_genitive_observed=False, final_insertion_fit_still_required=True)


def _route(row, case):
    family, function, wrappers = row["outer_family"], row["function"], row["wrappers"]
    inside = {w["kind"] for w in wrappers if w["placement"] == "inside_gap"}
    if not row["attachment_spans"]:
        return None
    if family == "nominal" and function == "possessor":
        return _possessor_binding(row, case)["constructor_form"]
    if "example" in inside:
        return "member_example"
    if "genitive" in inside:
        return "possessive"
    if family == "nominal" and row["variant"] == "compound_modifier":
        return "modifier"
    if family == "nominal" and function != "modifier":
        return "nominal"
    if family == "adjectival":
        return "modifier"
    if family == "nominal_specifier" and row["variant"] == "numeric_quantity":
        return "quantity"
    return None


def _raw_identity(row):
    return {k: v for k, v in row.items() if k != "cues"}


def _validate_row(row, case, *, require_typed_cues=True):
    q = case["query"]
    family, function, role = row["outer_family"], row["function"], row["role"]
    if function not in REGISTRY["family_functions"][family] or function not in REGISTRY["role_functions"][role]:
        raise ValueError("Form, function and role disagree with fixed registry")
    if row["variant"] == "compound_modifier" and not (family == "nominal" and function == "modifier"):
        raise ValueError("Compound route is a nominal modifier analysis only")
    if row["variant"] == "numeric_quantity" and family != "nominal_specifier":
        raise ValueError("Numeric quantity route requires nominal-specifier form")
    for item in row["attachment_spans"]:
        _check_span(q, item)
    for cue in row["cues"]:
        _check_span(q, cue["span"])
    if not any(c["kind"] in {"boundary", "attachment"} for c in row["cues"]):
        raise ValueError("A reading needs a visible boundary/governor cue")
    for attachment in row["attachment_spans"]:
        if not any(c["kind"] == "attachment" and c["span"] == attachment for c in row["cues"]):
            raise ValueError("Attachment span needs its own exact cue")
    for field, unknown, kind in [("target_kind", "any", "target_kind"), ("grammatical_number", "unknown", "number"), ("finite", None, "finite")]:
        if require_typed_cues and row[field] != unknown and not any(c["kind"] == kind for c in row["cues"]):
            raise ValueError("Typed reading constraint needs exact " + kind + " cue")
    for wrapper in row["wrappers"]:
        for item in wrapper["spans"]:
            _check_span(q, item)
        if (wrapper["placement"] == "visible") != bool(wrapper["spans"]):
            raise ValueError("Visible wrapper needs a quote; hidden wrapper is only hypothetical")
        if wrapper["placement"] == "inside_gap":
            if wrapper["kind"] == "example" and not (family == "prepositional" and function == "example_member"):
                raise ValueError("Final inside-gap example insertion is PP/example, not bare source NP")
            if wrapper["kind"] == "genitive" and not (family == "nominal" and function == "possessor"):
                raise ValueError("Outer genitive insertion is a nominal possessor")
    if len([w for w in row["wrappers"] if w["placement"] == "inside_gap"]) > 1:
        raise ValueError("Nested inside-gap wrappers need a new explicit constructor contract")
    for operator in row["operators"]:
        _check_span(q, operator["scope"], scope=True)
        _check_span(q, operator["cue"])
        if (operator["realization"] == "visible") != (operator["cue"] is not None):
            raise ValueError("Hypothetical hidden operator cannot be labeled observed")


def _explanation(row, case):
    route = _route(row, case)
    suffix = " Legacy subset route: " + route + "." if route else " Requires a new constructor or explicit withholding."
    return FAMILIES[row["outer_family"]]["explanation"] + " Function: " + row["function"] + "." + suffix


def _bind(response, case, interpreter):
    try:
        Draft202012Validator(MODEL_VALIDATION_SCHEMA).validate(response)
    except ValidationError as error:
        raise ValueError("Invalid next reading response: " + error.message) from error
    status, rows = response["status"], response["readings"]
    if case["task"] != "redaction":
        if status != "not_applicable" or rows or response["reason"] != "NOT_A_REDACTION_TASK":
            raise ValueError("H/R have no reading response")
    elif status == "not_applicable":
        raise ValueError("Redaction requires readings or explicit abstention")
    elif status == "abstain":
        if rows or response["reason"] in {None, "NOT_A_REDACTION_TASK"}:
            raise ValueError("Abstention needs a reason and zero readings")
    elif not rows or response["reason"] is not None:
        raise ValueError("Ready response needs readings and no abstention reason")
    if case["task"] == "redaction" and rows and _adjacent(case):
        raise ValueError("Adjacent opaque boundary requires abstention")
    merged = {}
    for row in rows:
        _validate_row(row, case)
        identity = digest(_raw_identity(row))
        if identity not in merged:
            merged[identity] = deepcopy(row)
        else:
            cues = {digest(c): c for c in merged[identity]["cues"] + row["cues"]}
            merged[identity]["cues"] = list(cues.values())
    ordered = sorted(merged.values(), key=lambda r: (ORDER[r["outer_family"]], digest(_raw_identity(r))))
    bound = []
    for row in ordered:
        row["cues"].sort(key=lambda c: (c["span"]["start"], c["span"]["end"], c["kind"]))
        route = _route(row, case)
        identity = digest([VERSION, REGISTRY_SHA256, digest(case), _raw_identity(row)])
        bound.append(dict(row, id="next_reading_" + identity[:24], form=row["outer_family"],
            constructor_form=route, constructor_status="legacy_compatible_subset" if route else "requires_new_constructor",
            constructor_routing=_possessor_binding(row, case) if row["outer_family"] == "nominal" and row["function"] == "possessor"
                else dict(version=CONSTRUCTOR_ROUTING_VERSION, constructor_form=route, reason="UNCHANGED_NONPOSSESSOR_ROUTE"),
            explanation=_explanation(row, case)))
    if len({r["id"] for r in bound}) != len(bound):
        raise ValueError("Reading ID collision")
    return dict(version=VERSION, registry_version=REGISTRY_VERSION, registry_sha256=REGISTRY_SHA256,
        constructor_routing_version=CONSTRUCTOR_ROUTING_VERSION,
        model_schema_version=MODEL_SCHEMA_VERSION, model_schema_sha256=MODEL_SCHEMA_SHA256,
        task=case["task"], case_sha256=digest(case), query_sha256=digest(case["query"]),
        interpreter=interpreter, status=status, reason=response["reason"], readings=bound,
        query_only=True, source_access=False, answer_text_supplied=False, api_calls=0,
        mechanical_fallback=False, target_kind_is_hint=True, factual_support_certified=False)


def project_model_constraints(response, case):
    """Drop only unsupported optional typed claims, with explicit loss QC.

    Supplied spans, roles, forms, wrappers and operators must already validate.
    No coordinate repair, new cue, grammatical inference or fallback occurs.
    The input may be a caller's separately logged coordinate-bound response;
    it is not falsely described as the original provider response.
    """
    case = _case(case)
    try:
        Draft202012Validator(MODEL_VALIDATION_SCHEMA).validate(response)
    except ValidationError as error:
        raise ValueError("Invalid next reading response: " + error.message) from error
    projected, changes = deepcopy(response), []
    for index, row in enumerate(projected["readings"]):
        _validate_row(row, case, require_typed_cues=False)
        for field, unknown, kind in [("target_kind", "any", "target_kind"),
                ("grammatical_number", "unknown", "number"), ("finite", None, "finite")]:
            if row[field] != unknown and not any(c["kind"] == kind for c in row["cues"]):
                changes.append(dict(input_reading_index=index, field=field, previous=row[field],
                    projected=unknown, reason="MISSING_EXACT_TYPED_" + kind.upper() + "_CUE"))
                row[field] = unknown
    return projected, dict(version=MODEL_PROJECTION_VERSION,
        input_response=deepcopy(response), input_response_sha256=digest(response),
        projected_response_sha256=digest(projected), changes=changes,
        input_is_exact_caller_response_not_asserted_raw_provider_output=True,
        cue_or_coordinate_changes=False, added_cues=False, inference_performed=False,
        forms_roles_attachments_wrappers_operators_changed=False,
        mechanical_fallback=False)


def from_model_response(response, case):
    """Bind model selections with versioned conservative optional-claim loss."""
    case = _case(case)
    projected, qc = project_model_constraints(response, case)
    packet = _bind(projected, case, "model")
    packet["model_projection_version"] = MODEL_PROJECTION_VERSION
    packet["model_constraint_projection"] = qc
    return packet


bind_model_readings = from_model_response


def validate_readings(packet, case):
    case = _case(case)
    if not isinstance(packet, dict) or packet.get("interpreter") not in {"model", "spacy"}:
        raise ValueError("Explicit model/spacy packet required")
    if "model_constraint_projection" in packet:
        projection = packet["model_constraint_projection"]
        if packet["interpreter"] != "model" or not isinstance(projection, dict) or "input_response" not in projection:
            raise ValueError("Model projection metadata cannot modify a local/unknown packet")
        expected = from_model_response(projection["input_response"], case)
        if packet != expected:
            raise ValueError("Model typed-constraint projection or resulting packet changed")
        return deepcopy(expected)
    try:
        raw_keys = MODEL_RESPONSE_SCHEMA["$defs"]["reading"]["properties"]
        raw = dict(status=packet["status"], reason=packet["reason"],
            readings=[{k: row[k] for k in raw_keys} for row in packet["readings"]])
        expected = _bind(raw, case, packet["interpreter"])
    except (KeyError, TypeError) as error:
        raise ValueError("Incomplete next reading packet") from error
    if packet != expected:
        raise ValueError("Reading packet metadata, ID, explanation or constructor route changed")
    return deepcopy(expected)


def constructor_view(reading, case):
    """Return an old-constructor row only; caller still owes all source/fit gates."""
    case = _case(case)
    raw_keys = MODEL_RESPONSE_SCHEMA["$defs"]["reading"]["properties"]
    raw = {k: reading[k] for k in raw_keys}
    bound = _bind(dict(status="ready", reason=None, readings=[raw]), case, "model")["readings"][0]
    if bound != reading:
        raise ValueError("Reading is not the exact bound constructor interpretation")
    if bound["constructor_form"] is None:
        raise ValueError("No legacy constructor mapping; do not downgrade a new family")
    left, right = case["query"].split(case["focal_marker"])
    role = "nominal_property" if bound["role"] == "predicative_complement" else bound["role"]
    return dict(id=bound["id"], form=bound["constructor_form"], role=role, target_kind=bound["target_kind"],
        grammatical_number=bound["grammatical_number"], left_quote=left, right_quote=right,
        attachment_quote=bound["attachment_spans"][0]["text"], finite=bound["finite"], notes=bound["explanation"])


@lru_cache(maxsize=1)
def _model():
    import spacy
    return spacy.load("en_core_web_sm")


def compile_readings(case, nlp=None):
    """Local spaCy interpretation, without all-form fallback or source access."""
    case = _case(case)
    if case["task"] != "redaction":
        return _bind(dict(status="not_applicable", reason="NOT_A_REDACTION_TASK", readings=[]), case, "spacy")
    if _adjacent(case):
        return _bind(dict(status="abstain", reason="ADJACENT_OPAQUE_BOUNDARY", readings=[]), case, "spacy")
    from matryoshka_current import local_readings as old
    from spacy.language import Language
    language = _model() if nlp is None else nlp
    if not isinstance(language, Language) or not language.has_pipe("parser") or not language.has_pipe("tagger"):
        raise ValueError("A spaCy dependency/tagger pipeline is required; no fake fallback")
    q, marker = case["query"], case["focal_marker"]
    at, end = q.index(marker), q.index(marker) + len(marker)
    intervals = [m.span() for m in MASK.finditer(q)]
    baseline = old.baseline
    shadow, _ = baseline._parse(language, baseline._shadow(q, intervals), intervals, uppercase=q.isupper())
    blank, _ = baseline._parse(language, baseline._shadow(q, intervals, (at, end)), intervals, uppercase=q.isupper())
    slot = next(t for t in shadow if t.idx == at and t.text == "thing")
    sentence_start, sentence_end = slot.sent.start_char, slot.sent.end_char
    visible = lambda t: baseline._visible(t, intervals) and sentence_start <= t.idx < sentence_end
    left = [t for t in blank if visible(t) and t.idx + len(t) <= at]
    right = [t for t in blank if visible(t) and t.idx >= end]
    previous = left[-1] if left else None
    following = right[0] if right else None
    bare_verb = bool(following is not None and following.pos_ == "VERB" and following.tag_ in {"VB", "VBP"}
        and following.text.casefold() == following.lemma_.casefold())
    bound_subject = bool(following is not None and any(t.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"}
        and t.head == following for t in left))
    auxiliary_gap = bare_verb and previous is not None and previous.pos_ == "AUX"
    output = []

    def token_span(token):
        return _span(q, token.idx, token.idx + len(token))

    carrier = baseline._carrier(blank, end, intervals)

    def quoted(text, preferred=None):
        found = [t for t in blank if visible(t) and q[t.idx:t.idx + len(t)] == text]
        if preferred is not None:
            exact = [t for t in found if t.idx == preferred.idx]
            if len(exact) == 1:
                return exact[0]
        return found[0] if len(found) == 1 else None

    def emit(family, function, role, head, *, variant="default", target="any", number="unknown", finite=None,
             wrappers=(), operators=(), kind_cue=None, extra=()):
        cues = []
        attachments = [token_span(head)] if head is not None and visible(head) else []
        if attachments:
            cues.append(dict(kind="attachment", span=attachments[0]))
        for token in extra:
            if token is not None and visible(token):
                cues.append(dict(kind="boundary", span=token_span(token)))
        if not cues:
            return
        cue = token_span(kind_cue) if kind_cue is not None and visible(kind_cue) else attachments[0] if attachments else cues[0]["span"]
        for value, unknown, kind in [(target, "any", "target_kind"), (number, "unknown", "number"), (finite, None, "finite")]:
            if value != unknown:
                cues.append(dict(kind=kind, span=cue))
        output.append(dict(outer_family=family, function=function, role=role, variant=variant,
            attachment_spans=attachments, target_kind=target, grammatical_number=number, finite=finite,
            wrappers=deepcopy(list(wrappers)), operators=deepcopy(list(operators)), cues=cues))

    for old_row in old.compile_readings(q, marker, nlp=language):
        form = old_row["form"]
        if form == "unknown":
            continue
        preferred = carrier if form in {"modifier", "quantity", "possessive"} else slot.head
        head = quoted(old_row["attachment_quote"], preferred)
        if head is None:
            continue
        target = old_row.get("target_kind", "any")
        number = old_row.get("grammatical_number", "unknown")
        kind_cue = quoted(old_row.get("kind_cue_quote", ""))
        if target in {"person", "organization", "place"} and kind_cue is None:
            kind_cue = following if following is not None and following.lower_ in {"who", "whom", "whose"} else None
            if kind_cue is None:
                target = "any"
        if form == "nominal":
            if bare_verb and (auxiliary_gap or bound_subject):
                continue
            role = old_row["role"]
            function = "coordinate_member" if role == "actor_enumeration" else "complement" if role in {"quoted_characterization", "nominal_property"} else "argument" if role != "unknown" else "unknown"
            wrappers = []
            if previous is not None and previous.lower_ in {"like"} and previous.pos_ == "ADP":
                function, role = "example_member", "member_example"
                wrappers = [dict(kind="example", placement="visible", spans=[token_span(previous)])]
            emit("nominal", function, role, head, target=target, number=number, finite=False, wrappers=wrappers, kind_cue=kind_cue)
        elif form == "modifier":
            copular = head.lemma_.casefold() == "be" and head.pos_ in {"AUX", "VERB"}
            function = "complement" if copular else "modifier"
            emit("adjectival", function, "nominal_property", head, target=target, finite=False)
            if not copular and head.pos_ == "NOUN":
                emit("nominal", "modifier", "nominal_property", head, variant="compound_modifier", finite=False)
        elif form == "quantity":
            emit("nominal_specifier", "specifier", "quantity", head, variant="numeric_quantity", target="quantity", finite=False)
        elif form == "possessive":
            suffix = re.match(r"\s*(['\u2019]s|s['\u2019])(?=\s|\W|$)", q[end:])
            wrapper = dict(kind="genitive", placement="visible" if suffix else "inside_gap", spans=[])
            if suffix:
                wrapper["spans"] = [_span(q, end + suffix.start(1), end + suffix.end(1))]
            emit("nominal", "possessor", "possessor", head, target=target, number=number, finite=False,
                wrappers=[wrapper], kind_cue=kind_cue)
        elif form == "member_example":
            emit("prepositional", "example_member", "member_example", head, target=target, finite=False,
                wrappers=[dict(kind="example", placement="inside_gap", spans=[])])
        elif form == "verbal":
            emit("verbal_predicate", "predicate", "verbal_bridge", head, target="action", finite=False)

    def finite(token):
        return token.tag_ in {"VBD", "VBP", "VBZ", "MD"} or any(c.dep_ in {"aux", "auxpass", "cop"}
            and c.tag_ in {"VBD", "VBP", "VBZ", "MD"} for c in token.children)

    def subjects(token):
        return [t for t in token.children if t.dep_ in {"nsubj", "nsubjpass", "nsubj:pass"} and visible(t)]

    left_predicates = [t for t in left if t.pos_ in {"VERB", "AUX"} and finite(t) and len(subjects(t)) == 1]
    right_predicates = [t for t in right if t.pos_ in {"VERB", "AUX"} and finite(t) and len(subjects(t)) == 1]
    # Explicit comma + a fully visible finite clause licenses initial adjunct
    # alternatives, not an arbitrary union at any unknown gap.
    if not q[:at].strip() and following is not None and following.text == "," and right_predicates:
        governor = right_predicates[0]
        for family in ("prepositional", "adverbial", "clausal"):
            emit(family, "adjunct", "adjunct", governor, extra=[following])
    # A visibly complete determiner-led NP to the right can be the complement
    # of a missing preposition; a visible preposition to the left instead wants NP.
    if previous is not None and previous.pos_ == "VERB" and left_predicates and following is not None and following.pos_ == "DET":
        chunks = [chunk for chunk in blank.noun_chunks if chunk.start_char == following.idx and chunk.root.pos_ == "NOUN"]
        if chunks:
            emit("prepositional", "adjunct", "adjunct", previous, extra=[following, chunks[0].root])
    if following is not None and following.pos_ == "ADJ" and previous is not None and previous.lemma_.casefold() == "be":
        emit("adverbial", "modifier", "nominal_property", following, extra=[previous])
        emit("functional_piece", "operator", "operator", following,
            operators=[dict(kind="unknown", realization="hypothetical", cue=None, scope=token_span(following))], extra=[previous])
    if bare_verb:
        if previous is not None and previous.pos_ == "AUX":
            emit("functional_piece", "operator", "operator", following,
                operators=[dict(kind="unknown", realization="hypothetical", cue=None, scope=token_span(following))], extra=[previous])
            emit("adverbial", "adjunct", "adjunct", following, extra=[previous])
        elif bound_subject:
            emit("functional_piece", "operator", "operator", following,
                operators=[dict(kind="modality", realization="hypothetical", cue=None, scope=token_span(following))], extra=[previous])
    if previous is not None and previous.text == ":" and left_predicates and not q[end:].strip(" .!?\n\t"):
        emit("clausal", "complement", "statement", left_predicates[-1], extra=[previous])
    if previous is not None and previous.lower_ == "that" and len(left) >= 2 and left[-2] in left_predicates:
        emit("clausal", "complement", "statement", left[-2], extra=[previous])
    # Relative-clause alternative only in an explicit noun/main-predicate gap.
    if previous is not None and previous.pos_ == "NOUN" and following is not None and following in right_predicates and previous in subjects(following):
        emit("clausal", "modifier", "statement", previous, extra=[following])
    if not output:
        return _bind(dict(status="abstain", reason="NO_LICENSED_VISIBLE_READING", readings=[]), case, "spacy")
    return _bind(dict(status="ready", reason=None, readings=output), case, "spacy")
