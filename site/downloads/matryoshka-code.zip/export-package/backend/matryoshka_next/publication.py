"""Detached saved-packet publication. No inference, provider, source mutation or latest lookup."""
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import date
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath
import re


VERSION = "next-workbench-publication/1"
ORIGIN_VERSION = "next-source-birth-display/1"
SELECTION_VERSION = "next-showcase-criteria/2026-11-18-explicit-user"
PUBLIC_FIELDS = ("case_id", "task", "corpus", "document_id", "date", "query", "focal_marker")
TASKS = {"redaction", "hypothesis", "reconstruction"}
STATUS = {"SUPPORT": "SUPPORTED", "SUPPORTED": "SUPPORTED", "ESTABLISHED": "SUPPORTED",
          "EVIDENCE_BACKED": "SUPPORTED", "EVIDENCE_BACKED_SUGGESTION": "SUPPORTED",
          "OPPOSED": "OPPOSED", "COUNTER": "OPPOSED", "COUNTEREVIDENCE": "OPPOSED",
          "CONFLICTED": "CONFLICTED", "CONFLICT": "CONFLICTED", "PARTIAL": "PARTIAL",
          "PARTIAL_GROUNDING": "PARTIAL", "FEASIBLE": "FEASIBLE", "CONTEXT": "FEASIBLE",
          "EXPLORATORY_CONTEXTUAL": "FEASIBLE", "UNRESOLVED": "UNRESOLVED", "NO_INFO": "UNRESOLVED",
          "MISSING": "UNRESOLVED", "UNSUPPORTED": "UNRESOLVED", "INCOMPATIBLE": "INCOMPATIBLE"}
_HANDLING = re.compile(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM\b", re.I)


def digest(value):
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def public_case(value):
    result = {key: deepcopy(value[key]) for key in PUBLIC_FIELDS}
    if (result["task"] not in TASKS or result["corpus"] not in {"cib", "iran", "vietnam"}
            or not all(isinstance(v, str) for v in result.values()) or not result["query"].strip()):
        raise ValueError("Exact public case fields required")
    date.fromisoformat(result["date"])
    if result["task"] == "redaction" and (not result["focal_marker"] or result["query"].count(result["focal_marker"]) != 1):
        raise ValueError("One exact focal marker required")
    return result


def read_ref(root, ref):
    """Hash the same bytes parsed; reject absolute/traversal/symlink inputs."""
    raw = _read_bytes(root, ref)
    if ref["path"].endswith(".gz"):
        import gzip
        raw = gzip.decompress(raw)
    return json.loads(raw)


def _read_bytes(root, ref):
    root = Path(root).resolve()
    name = ref.get("path")
    if (not isinstance(name, str) or "\\" in name or PurePosixPath(name).is_absolute()
            or any(p in {"", ".", ".."} for p in name.split("/"))):
        raise ValueError("Canonical relative artifact reference required")
    path = root / name
    if path.resolve() != path:
        raise ValueError("Symlinked artifact reference")
    raw = path.read_bytes()
    if sha256(raw).hexdigest() != ref.get("sha256"):
        raise ValueError("Artifact hash changed")
    return raw


def _span(text, item):
    a, b = item.get("start"), item.get("end")
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(text)
            or text[a:b] != item.get("text")):
        raise ValueError("Exact Unicode source range does not replay")
    if item.get("quote_sha256") is not None and item["quote_sha256"] != digest(item["text"]):
        raise ValueError("Quote hash changed")
    return dict(start=a, end=b, text=item["text"], quote_sha256=digest(item["text"]))


def _ranges(text, items, *, context_excerpt=False):
    values = sorted((_span(text, a) for a in items), key=lambda a: (a["start"], -a["end"]))
    result = []
    for item in values:
        if not context_excerpt and item["start"] == 0 and item["end"] == len(text):
            raise ValueError("Whole-page/document substitute is not a precise birth range")
        if result and item["start"] < result[-1]["end"]:
            if item["end"] <= result[-1]["end"]:
                continue
            raise ValueError("Ambiguous source-range overlap")
        result.append(item)
    if not result:
        raise ValueError("No precise recorded source-birth quotes; publication blocked")
    return result


def _replace_mask(text, focal, marker, ranges, *, context_excerpt=False):
    a, b = focal["start"], focal["end"]
    _span(text, focal)
    delta = len(marker) - (b-a)
    changed = text[:a] + marker + text[b:]
    def boundary(position):
        if position <= a:
            return position
        if position >= b:
            return position + delta
        raise ValueError("Episode boundary clips a hidden focal extent")
    mapped = []
    for item in ranges:
        x, y = boundary(item["start"]), boundary(item["end"])
        mapped.append(dict(start=x, end=y, text=changed[x:y]))
    return changed, _ranges(changed, mapped, context_excerpt=context_excerpt), dict(start=a, end=a+len(marker), text=marker)


def _cib_window(case, proof, focal):
    """Replay persisted producer operations; never search the analyst query in source."""
    text = proof["origin"]["text"]
    a, b = focal["start"], focal["end"]
    masked = text[:a] + case["focal_marker"] + text[b:]
    body = masked.strip()
    prefix = len(masked) - len(masked.lstrip())
    blocks = body.split("\n\n")
    # Exact documented producer rule, checked against its committed output.
    if len(blocks) > 1 and not re.search(r"[.!?]", blocks[0]) and len(blocks[0].split()) < 16:
        removed = len(blocks[0]) + 2
        prefix += removed
        body = body[removed:]
    mapping = proof["question_context_mapping"]
    if (body != proof["original_masked_question"] or digest(body) != mapping["source_query_sha256"]
            or digest(case["query"]) != mapping["query_sha256"]):
        raise ValueError("Producer title/window generation does not replay")
    marker_end = a + len(case["focal_marker"])
    def inverse(position):
        if position <= a:
            return position
        if position >= marker_end:
            return position + (b-a) - len(case["focal_marker"])
        raise ValueError("COPY window clips focal mask")
    queries, ranges = [], []
    cursor = 0
    for piece in mapping["pieces"]:
        x, y = piece["source_start"], piece["source_end"]
        if (piece["kind"] != "COPY" or not 0 <= x < y <= len(body)
                or piece.get("selected_start", cursor) != cursor):
            raise ValueError("Only contiguous persisted COPY windows are supported")
        queries.append(body[x:y]); cursor += y-x
        left, right = inverse(prefix+x), inverse(prefix+y)
        ranges.append(dict(start=left, end=right, text=text[left:right]))
    if "".join(queries) != case["query"]:
        raise ValueError("Saved query-window COPY tape differs from public question")
    return _ranges(text, ranges), dict(kind="PERSISTED_PRODUCER_MASK_TITLE_COPY_COMPOSITION",
        original_masked_query_sha256=digest(body), title_prefix_characters=prefix,
        window_mapping=deepcopy(mapping), query_search_used=False)


def bind_origin(case, proof, *, proof_ref, native_binding=None, full_transcription=None):
    """Return a private two-view postrun bundle; publish each view separately.

    `proof_ref` is an explicit already byte-verified source proof/packet ref.
    No source or key is passed to inference; this function cannot run it.
    Optional full_transcription must carry existing producer anchors, not guesses.
    """
    case = public_case(case)
    before = digest(proof)
    origin = proof["origin"]
    text = origin["text"]
    if (origin["document_id"] != case["document_id"] or origin["date"] != case["date"]
            or digest(text) != origin["source_text_sha256"]
            or not re.fullmatch("[0-9a-f]{64}", proof_ref.get("sha256", ""))):
        raise ValueError("Origin identity/date/text/proof reference mismatch")
    audit = proof.get("source_origin_audit", {})
    completeness = False
    if case["corpus"] != "cib":
        checks = [r for r in audit.get("document_checks", []) if r["document_id"] == case["document_id"]]
        raw = audit.get("original_raw_documents", {}).get(case["document_id"], {})
        if (len(checks) != 1 or checks[0].get("classification") != "SECRET"
                or checks[0].get("valid") is not True or checks[0].get("whole_body_noforn") is not False
                or not audit.get("whole_origin_document_excluded")
                or re.search(r"\bNOFORN\b|NO\s+FOREIGN\s+DISSEM", text, re.I)):
            raise ValueError("Sealed whole-origin SECRET/handling audit required")
        if raw.get("body") == text and checks[0].get("raw_body_sha256") == digest(text):
            completeness = True
        rows = audit.get("canonical_origin_rows", [])
        if ({r["segment_id"] for r in rows} != set(audit.get("excluded_canonical_source_ids", []))
                or any(r["document_id"] != case["document_id"] for r in rows)):
            raise ValueError("Canonical origin sibling exclusion differs")
    base = origin.get("start", 0)
    def normalize(item):
        for key in ("source_id", "document_id", "date", "source_text_sha256"):
            if key in item and item[key] != origin.get(key):
                raise ValueError("Generation quote belongs to another origin")
        return _span(text, dict(item, start=item["start"]-base, end=item["end"]-base))
    recorded = [normalize(a) for a in proof.get("origin_anchors", [])]
    focal = None
    if case["task"] == "redaction":
        raw_focal = proof.get("hidden_span")
        if raw_focal is None:
            choices = [a for a in proof.get("origin_anchors", []) if a.get("focal") is True]
            if len(choices) != 1:
                raise ValueError("One producer-recorded complete hidden extent required")
            raw_focal = choices[0]
        focal = normalize(raw_focal)
    correction = proof.get("source_scope_correction", {}).get("origin_quote")
    mapping = dict(kind="RECORDED_SOURCE_BIRTH_RANGES", query_search_used=False)
    if correction is not None:
        recorded = [normalize(correction)]
        mapping["kind"] = "PERSISTED_NESTED_ORIGIN_SCOPE_QUOTE"
    elif focal is not None and all(a.get("focal") is True for a in proof.get("origin_anchors", [])):
        recorded, mapping = _cib_window(case, proof, focal)
    birth = _ranges(text, recorded)
    if focal and mapping["kind"] == "RECORDED_SOURCE_BIRTH_RANGES":
        if len(birth) != 1 or not birth[0]["start"] <= focal["start"] < focal["end"] <= birth[0]["end"]:
            raise ValueError("Recorded source episode does not contain the complete focal extent")
        episode = text[birth[0]["start"]:focal["start"]] + case["focal_marker"] + text[focal["end"]:birth[0]["end"]]
        if episode != case["query"]:
            raise ValueError("Recorded copy/mask/copy source episode differs from the public question")
    common = dict(version=ORIGIN_VERSION, case_id=case["case_id"], case_sha256=digest(case),
        query_sha256=digest(case["query"]), document_id=case["document_id"], date=case["date"],
        corpus=case["corpus"], task=case["task"], source_id=origin["source_id"],
        eligible_evidence=False, source_proof_ref=deepcopy(proof_ref), proof_record_sha256=digest(proof),
        coordinate_frame="ORIGIN_TEXT_UNICODE_CHARACTERS_HALF_OPEN",
        transformation=mapping, complete_original_supplied=completeness,
        native_binding=deepcopy(native_binding), source_audit="SEALED_PROOF_LITERAL_REPLAY_NOT_NEW_CORPUS_REAUDIT",
        postrun_only=True, inferred_anchors=False, native_outputs_modified=False)
    revealed = dict(common, text=text, text_sha256=digest(text), query_anchors=birth,
                    anchors=[focal] if focal else birth, focal_revealed=bool(focal))
    masked = deepcopy(revealed)
    masked["focal_revealed"] = False
    if focal:
        masked_text, mapped, hidden = _replace_mask(text, focal, case["focal_marker"], birth)
        masked.update(text=masked_text, text_sha256=digest(masked_text), query_anchors=mapped, anchors=[hidden])
    if full_transcription is not None:
        full = deepcopy(full_transcription)
        if full.get("text_sha256") != digest(full["text"]):
            raise ValueError("Full transcript hash mismatch")
        full["query_anchors"] = _ranges(full["text"], full.get("query_anchors", full.get("anchors", [])))
        if ({a["quote_sha256"] for a in full["query_anchors"]} != {a["quote_sha256"] for a in birth}
                or full.get("document_id", case["document_id"]) != case["document_id"]):
            raise ValueError("Full transcript birth quotes do not match this exact source episode")
        if case["task"] == "redaction":
            full_focal = _span(full["text"], full["focal_anchor"])
            if full_focal["quote_sha256"] != focal["quote_sha256"]:
                raise ValueError("Full-document focal mapping differs from the recorded hidden extent")
            changed, mapped, hidden = _replace_mask(full["text"], full_focal, case["focal_marker"], full["query_anchors"])
            masked["full_transcription"] = dict(text=changed, text_sha256=digest(changed), query_anchors=mapped,
                anchors=[hidden], coordinate_frame="FULL_ORIGINAL_MASKED_UNICODE_CHARACTERS_HALF_OPEN")
            revealed["full_transcription"] = dict(text=full["text"], text_sha256=digest(full["text"]),
                query_anchors=full["query_anchors"], anchors=[full_focal],
                coordinate_frame="FULL_ORIGINAL_UNICODE_CHARACTERS_HALF_OPEN")
        else:
            masked["full_transcription"] = full; revealed["full_transcription"] = deepcopy(full)
        masked["complete_original_supplied"] = revealed["complete_original_supplied"] = True
    if digest(proof) != before:
        raise AssertionError("Source proof mutated")
    bundle = dict(version=ORIGIN_VERSION, case=case, masked=masked,
                  revealed=revealed if focal else None, source_text_sha256=digest(text),
                  anchors_from_persisted_generation_only=True, whole_page_fallback=False)
    bundle["sha256"] = digest(bundle)
    return bundle


def _record_path(value, path):
    if not isinstance(path, list):
        raise ValueError("An explicit saved record/field path is required")
    for key in path:
        if isinstance(value, dict) and isinstance(key, str) and key in value:
            value = value[key]
        elif isinstance(value, list) and type(key) is int and 0 <= key < len(value):
            value = value[key]
        else:
            raise ValueError("Pinned source record/field path does not replay")
    return value


def _curated_full_text(full, pack, case, root):
    """Read one whole original from the pack's exact raw-file pin, never search text."""
    if root is None:
        raise ValueError("Full original requires an explicit root for raw-file pin replay")
    ref = full["raw_ref"]
    if ref != pack["source"].get("raw_file_ref"):
        raise ValueError("Full original raw-file pin differs from the source bank")
    raw = _read_bytes(root, ref)
    name = ref["path"]
    if name.endswith(".gz"):
        import gzip
        raw = gzip.decompress(raw)
        name = name[:-3]
    if name.endswith(".jsonl"):
        records = (json.loads(line) for line in raw.decode("utf-8").splitlines() if line.strip())
    elif name.endswith(".csv"):
        import csv
        import io
        records = csv.DictReader(io.StringIO(raw.decode("utf-8")))
    elif name.endswith(".json"):
        value = _record_path(json.loads(raw), full.get("records_path", []))
        records = value if isinstance(value, list) else [value]
    else:
        raise ValueError("Explicit JSON/JSONL/CSV raw-document transport required")
    matches = [row for row in records if _record_path(row, full["document_id_path"]) == case["document_id"]]
    if len(matches) != 1:
        raise ValueError("Raw origin identity is missing or ambiguous")
    allowed_paths = [["raw_ocr", "redacted"], ["raw_ocr", "unredacted"]] if case["corpus"] == "cib" else [["body"]]
    if full["text_path"] not in allowed_paths:
        raise ValueError("A whole original body/OCR field is required, not an extracted summary")
    text = _record_path(matches[0], full["text_path"])
    if isinstance(text, list):
        if not all(isinstance(v, str) for v in text) or full.get("join_with") not in {"\n", "\n\n"}:
            raise ValueError("Raw page arrays require an explicit literal newline composition")
        text = full["join_with"].join(text)
    if not isinstance(text, str) or not text or sha256(text.encode()).hexdigest() != full["text_sha256"]:
        raise ValueError("Full raw-document text hash mismatch")
    if "text" in full and full["text"] != text:
        raise ValueError("Supplied original text differs from its raw pin")
    if case["corpus"] != "cib" and (_HANDLING.search(text)
            or _HANDLING.search(str(matches[0].get("orighand", "")))):
        raise ValueError("Whole original handling disallows publication admission")
    return text


def bind_curated_origin(case, proof, pack, proof_ref, full_original=None, *, root=None, native_binding=None):
    """Bind source-bank generation coordinates, not rewritten-query matches.

    Preview frames keep independent context coordinates. Complete publication
    requires the pack's raw-file pin and literal context-to-document mappings.
    The result verifies provenance, not query entailment or benchmark admission.
    """
    case = public_case(case)
    before = digest([proof, pack, full_original])
    if (proof.get("case_id") != case["case_id"] or proof.get("pack_id") != pack.get("pack_id")
            or pack.get("corpus") != case["corpus"] or pack.get("task") != case["task"]
            or pack["origin"]["document_id"] != case["document_id"] or pack["origin"]["date"] != case["date"]
            or not re.fullmatch("[0-9a-f]{64}", proof_ref.get("sha256", ""))):
        raise ValueError("Curated case/proof/pack origin binding differs")
    if "pack_sha256" in pack and pack["pack_sha256"] != digest({k:v for k,v in pack.items() if k != "pack_sha256"}):
        raise ValueError("Source pack seal changed")
    if root is not None:
        saved = _record_path(read_ref(root, proof_ref), proof_ref.get("record_path", []))
        if saved != proof:
            raise ValueError("Curated proof differs from its pinned generation record")
    if case["corpus"] != "cib" and (pack["origin"].get("classification") != "SECRET"
            or _HANDLING.search(str(pack["origin"].get("handling", "")))):
        raise ValueError("Cable origin must be SECRET without excluded handling")
    focus, prefix = pack["literal_context"], pack["pack_id"]
    if sha256(focus["text"].encode()).hexdigest() != focus["sha256"]:
        raise ValueError("Source-bank literal context hash changed")
    expected = {prefix+":focus": dict(text=focus["text"], start=focus["start"],
        coordinate_space=focus["coordinate_space"], parent_text_sha256=focus["parent_text_sha256"])}
    for i, unit in enumerate(pack["source"].get("adjacent_units", [])):
        text = unit.get("later_text") or unit.get("earlier_text")
        if text:
            expected[prefix+":context"+str(i)] = dict(text=text, start=0,
                coordinate_space="EXPLICIT_CANONICAL_ADJACENT_UNIT", parent_text_sha256=digest(unit))
    contexts = {}
    for source in proof["sources"]:
        sid = source["source_id"]
        if sid in contexts or sid not in expected or any(source.get(k) != v for k,v in expected[sid].items()):
            raise ValueError("Generation context identity/text/parent mapping differs from pack")
        contexts[sid] = dict(source, query_anchors=[])
    for quote in proof["source_quotes"]:
        sid = quote["source_id"]
        if sid not in contexts:
            raise ValueError("Birth quote cites an unprovided generation context")
        source = contexts[sid]
        if (quote.get("source_text_sha256") != digest(source["text"])
                or quote.get("parent_text_sha256") != source["parent_text_sha256"]
                or quote.get("coordinate_space") != source["coordinate_space"]):
            raise ValueError("Generation quote hash/coordinate space changed")
        source["query_anchors"].append(_span(source["text"], quote))
    if not contexts.get(prefix+":focus", {}).get("query_anchors"):
        raise ValueError("At least one generation quote must come from the focal source")
    hidden = proof.get("hidden_span")
    mask_map = proof.get("mask_map")
    if case["task"] == "redaction" and mask_map is not None:
        source = contexts[prefix+":focus"]
        if (mask_map.get("source_id") != prefix+":focus"
                or mask_map.get("source_text_sha256") != digest(source["text"])
                or mask_map.get("literal_roundtrip") is not True):
            raise ValueError("Synthetic mask map source/hash/roundtrip differs")
        episode = _span(source["text"], mask_map)
        mapped_hidden = dict(source_id=prefix+":focus", start=mask_map["hidden_start"],
            end=mask_map["hidden_end"], text=proof.get("answer"))
        _span(source["text"], mapped_hidden)
        if (not episode["start"] <= mapped_hidden["start"] < mapped_hidden["end"] <= episode["end"]
                or source["text"][episode["start"]:mapped_hidden["start"]]+case["focal_marker"]
                   +source["text"][mapped_hidden["end"]:episode["end"]] != case["query"]):
            raise ValueError("Saved mask-window copy/mask/copy does not replay the public query")
        if hidden is not None and hidden != mapped_hidden:
            raise ValueError("Conflicting recorded focal context extents")
        hidden = mapped_hidden
        source["query_anchors"].append(episode)
    contexts = {sid:dict(s, query_anchors=_ranges(s["text"], s["query_anchors"], context_excerpt=True))
                for sid,s in contexts.items() if s["query_anchors"]}
    complete = full_original is not None
    mappings = {}
    if complete:
        text = _curated_full_text(full_original, pack, case, root)
        for item in full_original.get("context_mappings", []):
            if item["source_id"] in mappings:
                raise ValueError("Duplicate full-document context mapping")
            mappings[item["source_id"]] = item
        if mappings:
            mapping_ref = full_original.get("mapping_ref")
            if not mapping_ref or _record_path(read_ref(root, mapping_ref), mapping_ref.get("record_path", [])) != full_original["context_mappings"]:
                raise ValueError("Explicit context mappings need their own saved producer pin")
        # Cable source segments already carry producer-recorded raw offsets.
        if prefix+":focus" not in mappings and type(pack["source"].get("raw_document_start")) is int:
            a = pack["source"]["raw_document_start"]+focus["start"]
            mappings[prefix+":focus"] = dict(start=a, end=a+len(focus["text"]))
        birth = []
        for sid, source in contexts.items():
            if sid not in mappings:
                raise ValueError("Full original lacks an explicit generation-context mapping")
            mapping = mappings[sid]
            _span(text, dict(mapping, text=source["text"]))
            for quote in source["query_anchors"]:
                birth.append(dict(start=mapping["start"]+quote["start"],
                    end=mapping["start"]+quote["end"], text=quote["text"]))
        birth = _ranges(text, birth)
    else:
        text = contexts[prefix+":focus"]["text"]
        birth = contexts[prefix+":focus"]["query_anchors"]
    focal = None
    if case["task"] == "redaction":
        if not hidden or hidden.get("source_id") != prefix+":focus":
            raise ValueError("Redaction needs a recorded focal context extent, not an answer-text search")
        local = _span(contexts[prefix+":focus"]["text"], hidden)
        if local["text"] != proof.get("answer"):
            raise ValueError("Recorded focal extent differs from sealed reference")
        if mask_map is None:
            authentic = pack.get("authentic_redaction")
            if authentic is not None:
                if (authentic.get("query") != case["query"] or authentic.get("focus_marker") != case["focal_marker"]
                        or authentic.get("answer") != proof.get("answer")):
                    raise ValueError("Authenticated Red source target differs from public query/reference")
            elif not any(q["start"] <= local["start"] < local["end"] <= q["end"]
                    and contexts[prefix+":focus"]["text"][q["start"]:local["start"]]+case["focal_marker"]
                        +contexts[prefix+":focus"]["text"][local["end"]:q["end"]] == case["query"]
                    for q in contexts[prefix+":focus"]["query_anchors"]):
                raise ValueError("Synthetic Red needs a recorded source episode matching copy/mask/copy")
        focal = _span(text, dict(local, start=local["start"]+(mappings[prefix+":focus"]["start"] if complete else 0),
                                 end=local["end"]+(mappings[prefix+":focus"]["start"] if complete else 0)))
    common = dict(version=ORIGIN_VERSION, case_id=case["case_id"], case_sha256=digest(case),
        query_sha256=digest(case["query"]), document_id=case["document_id"], date=case["date"],
        corpus=case["corpus"], task=case["task"], source_id=prefix+":focus", eligible_evidence=False,
        source_proof_ref=deepcopy(proof_ref), proof_record_sha256=digest(proof), source_pack_sha256=digest(pack),
        coordinate_frame="FULL_ORIGINAL_UNICODE_CHARACTERS_HALF_OPEN" if complete else "GENERATION_CONTEXT_LOCAL_UNICODE_CHARACTERS_HALF_OPEN",
        transformation=dict(kind="SAVED_GENERATION_CONTEXT_TO_RAW_OFFSETS" if complete else "SAVED_GENERATION_CONTEXT_EXCERPTS_ONLY",
                            query_search_used=False, mask_window_verified=mask_map is not None,
                            analyst_query_entailment_certified=False), complete_original_supplied=complete,
        native_binding=deepcopy(native_binding), source_audit="SOURCEBANK_LITERAL_PROVENANCE_REPLAY_NOT_ENTAILMENT",
        postrun_only=True, inferred_anchors=False, native_outputs_modified=False)
    if complete:
        common["raw_original_ref"] = deepcopy(full_original["raw_ref"])
        if full_original.get("mapping_ref"):
            common["context_mapping_ref"] = deepcopy(full_original["mapping_ref"])
    revealed = dict(common, text=text, text_sha256=digest(text), query_anchors=birth,
                    anchors=[focal] if focal else birth, focal_revealed=bool(focal))
    masked = deepcopy(revealed); masked["focal_revealed"] = False
    if not complete:
        # Frames remain separate; concatenating them would fabricate document offsets.
        frames = [dict(source_id=sid, text=s["text"], text_sha256=digest(s["text"]),
            query_anchors=s["query_anchors"], coordinate_frame=common["coordinate_frame"])
            for sid,s in contexts.items()]
        revealed["source_contexts"] = deepcopy(frames); masked["source_contexts"] = deepcopy(frames)
    if focal:
        # Hide the entire focal context in preview frames except the masked main view.
        # No unmasked source context or answer is copied into the masked payload.
        changed, mapped, hidden = _replace_mask(text, focal, case["focal_marker"], birth, context_excerpt=not complete)
        masked.update(text=changed, text_sha256=digest(changed), query_anchors=mapped, anchors=[hidden])
        masked.pop("source_contexts", None)
    bundle = dict(version=ORIGIN_VERSION, case=case, masked=masked, revealed=revealed if focal else None,
        source_text_sha256=digest(text), anchors_from_persisted_generation_only=True, whole_page_fallback=False)
    bundle["sha256"] = digest(bundle)
    if digest([proof, pack, full_original]) != before:
        raise AssertionError("Curated source inputs changed")
    return validate_origin(bundle, case)


def validate_origin(bundle, case):
    if (bundle.get("version") != ORIGIN_VERSION or bundle.get("case") != public_case(case)
            or bundle.get("sha256") != digest({k:v for k,v in bundle.items() if k != "sha256"})):
        raise ValueError("Detached origin bundle changed or belongs to another question")
    for view in (bundle["masked"], bundle.get("revealed")):
        if view is None:
            continue
        if view["text_sha256"] != digest(view["text"]) or view.get("eligible_evidence") is not False:
            raise ValueError("Origin view hash or evidence exclusion mismatch")
        context_excerpt = view.get("coordinate_frame") == "GENERATION_CONTEXT_LOCAL_UNICODE_CHARACTERS_HALF_OPEN"
        _ranges(view["text"], view["query_anchors"], context_excerpt=context_excerpt)
        for frame in view.get("source_contexts", []):
            if frame.get("text_sha256") != digest(frame["text"]):
                raise ValueError("Generation context hash changed")
            _ranges(frame["text"], frame["query_anchors"], context_excerpt=True)
    return deepcopy(bundle)


def _registry(registry):
    values = registry.get("readings", registry.get("families", []))
    if isinstance(values, dict):
        values = [dict(v, id=k) for k, v in values.items()]
    if not values or any(not isinstance(v.get("id"), str) for v in values) or len({v["id"] for v in values}) != len(values):
        raise ValueError("A fixed reading registry with distinct IDs is required")
    return {v["id"]: deepcopy(v) for v in values}


def _status(value):
    if isinstance(value, dict):
        value = value.get("status", value.get("direction"))
    return STATUS.get(str(value or "").upper(), "UNRESOLVED")


def _source_assisted(condition):
    exposure = condition.get("exposure")
    return (condition.get("query_only_inference") is False
            or condition.get("answers_read") is True or condition.get("grades_read") is True
            or isinstance(exposure, dict) and (exposure.get("source_aware_planning") is True
                or "SOURCE_ASSISTED" in str(exposure.get("condition", "")).upper()))


def _source_document_vetoes(pages, case):
    # All supplied siblings can veto, even when that sibling was not retrieved.
    if case["corpus"] == "cib":
        return set()
    return {page["document_id"] for page in pages.values()
            if _HANDLING.search(page["text"])
            or _HANDLING.search(str(page.get("handling", "")))}


def _quotes(rows, pages, case, *, document_vetoes=None):
    result, seen = [], set()
    if document_vetoes is None:
        document_vetoes = _source_document_vetoes(pages, case)
    for item in rows or []:
        ref = item.get("citation", item)
        identity = ref.get("canonical_page_id", ref.get("source_id"))
        if identity is None:
            continue
        page = pages.get(identity)
        if page is None:
            raise ValueError("Citation outside supplied inspected source pages")
        if (page.get("permitted") is not True or page.get("visibility") not in {"earlier", "both"}
                or page["document_id"] == case["document_id"]
                or date.fromisoformat(page["date"]) >= date.fromisoformat(case["date"])
                or page.get("corpus") != case["corpus"]
                or ref.get("document_id") != page["document_id"] or ref.get("date") != page["date"]
                or ref.get("corpus", case["corpus"]) != case["corpus"]
                or page.get("source_sha256", digest(page["text"])) != digest(page["text"])
                or ref.get("page_sha256", ref.get("source_text_sha256")) != digest(page["text"])):
            raise ValueError("Citation source/visibility/date/origin/hash policy mismatch")
        if case["corpus"] != "cib" and (page.get("classification") != "CONFIDENTIAL"
                or page.get("whole_document_policy_verified") is not True
                or page["document_id"] in document_vetoes):
            raise ValueError("Cable citation requires explicit complete-document eligibility replay")
        quote = _span(page["text"], ref)
        key = identity, quote["start"], quote["end"]
        if key in seen:
            continue
        seen.add(key)
        result.append(dict(quote, canonical_page_id=identity, document_id=page["document_id"],
                           date=page["date"], page_sha256=digest(page["text"]),
                           page_text=page["text"], eligible_evidence=True))
    return result


def _dag(value):
    value = deepcopy(value or dict(nodes=[], edges=[]))
    nodes, edges = value.get("nodes", []), value.get("edges", [])
    ids = {n["id"] for n in nodes}
    if len(ids) != len(nodes):
        raise ValueError("Duplicate search DAG node")
    incoming, outgoing = dict.fromkeys(ids, 0), defaultdict(list)
    for edge in edges:
        a, b = edge["source"], edge["target"]
        if a not in ids or b not in ids:
            raise ValueError("Search edge has an unsaved endpoint")
        outgoing[a].append(b); incoming[b] += 1
    queue = sorted(n for n, count in incoming.items() if not count)
    consumed = 0
    while queue:
        a = queue.pop(); consumed += 1
        for b in outgoing[a]:
            incoming[b] -= 1
            if not incoming[b]: queue.append(b)
    if consumed != len(ids):
        raise ValueError("Search DAG contains a cycle; no diffusion is inferred")
    return dict(nodes=nodes, edges=edges, meaning="Saved search/constraint transitions, not transported mass or entailment",
                numerical_mass_invented=False)


def dag_from_receipt(receipt):
    """Acyclic provenance associations from saved rows, not fabricated KG/PPR edges."""
    nodes, edges, pages = [], [], set()
    def page_node(identity):
        if identity not in pages:
            pages.add(identity)
            nodes.append(dict(id="page/"+identity, label="Matched source page "+identity,
                              kind="page_match", source_ids=[identity]))
        return "page/"+identity
    for i, query in enumerate(receipt.get("search_queries", [])):
        identity = "query/"+str(i)
        nodes.append(dict(id=identity, label=query.get("query", query.get("text", "Saved query input")), kind="starter"))
        for target in query.get("top_pages", []):
            target = target.get("page_id", target.get("canonical_page_id")) if isinstance(target, dict) else target
            if not isinstance(target, str):
                raise ValueError("Saved lexical match has no source page identity")
            edges.append(dict(source=identity, target=page_node(target), kind="SAVED_LEXICAL_MATCH",
                              numerical_transition=False, historical_assertion=False))
    for i, row in enumerate(receipt.get("source_edges", [])):
        citation = row.get("citation", {})
        page = citation.get("canonical_page_id")
        if not page:
            raise ValueError("Saved source lookup has no citation locator")
        identity = "lookup/"+str(i)
        nodes.append(dict(id=identity, label=citation.get("text") or row.get("relation", "Saved source lookup"),
            kind="source_lookup", source_ids=[page],
            source_endpoint=row["source"], target_endpoint=row["target"],
            relation=row.get("relation"), lookup_direction=row.get("lookup_direction", "OUTGOING"),
            source_row_id=row.get("source_row_id"),
            explanation="Recorded lookup of a source assertion; incoming lookup does not reverse its factual direction."))
        edges.append(dict(source=page_node(page), target=identity, kind="SOURCE_RECORD_ON_PAGE",
            derived_association=True, numerical_transition=False, historical_assertion=False,
            explanation="A citation-to-record provenance association, not a new source graph edge."))
    for i, row in enumerate(receipt.get("navigation_edges", [])):
        nodes.append(dict(id="navigation/"+str(i), label="Membership: "+row["source"]+" to "+row["target"],
            kind="navigation_lookup", source_endpoint=row["source"], target_endpoint=row["target"],
            explanation="Saved retrospective hierarchy navigation, not source support."))
    return _dag(dict(nodes=nodes, edges=edges))


def adapt_condition(packet, *, registry, source_pages, origin, reviews=(), registry_ref=None, registry_root=None, condition_id=None):
    """Normalize one new-engine packet without changing its decisions or ranks."""
    before = digest(packet)
    if not str(packet.get("version", "")).startswith("next-"):
        raise ValueError("Old native records cannot be relabeled as next-engine runs")
    case = public_case(packet.get("case", packet.get("public_case", {})))
    origin = validate_origin(origin, case)
    plan, retrieval, result = packet["plan"], packet["retrieval"], packet["result"]
    document_vetoes = _source_document_vetoes(source_pages, case)
    if plan.get("query_sha256") != digest(case["query"]):
        raise ValueError("Query plan hash mismatch")
    menu = _registry(registry)
    registry_hash = digest(registry)
    if registry_ref is not None:
        if registry_root is None or read_ref(registry_root, registry_ref) != registry:
            raise ValueError("Explicit registry byte binding differs")
        registry_hash = registry_ref["sha256"]
    reading_packet = plan.get("readings_packet", {})
    declared_registry = reading_packet.get("registry_sha256", plan.get("registry_sha256"))
    if case["task"] == "redaction" and declared_registry != registry_hash:
        raise ValueError("Interpretation belongs to a different fixed reading registry")
    review_map = {}
    for review in reviews:
        if review["packet_sha256"] != before:
            raise ValueError("Post-run review belongs to a different exact packet")
        key = review.get("reading_id"), review["candidate_id"]
        if key in review_map:
            raise ValueError("Duplicate candidate assessment")
        review_map[key] = deepcopy(review)
    readings = reading_packet.get("readings", plan.get("readings", plan.get("slot_readings", [])))
    interpreted, reading_ids = [], set()
    for reading in readings:
        rid = reading["id"]
        if rid in reading_ids:
            raise ValueError("Duplicate reading identity")
        reading_ids.add(rid)
        family = reading.get("registry_id", reading.get("family_id", reading.get("outer_family")))
        if family not in menu:
            raise ValueError("Reading refers to an unknown fixed registry ID")
        interpreted.append(dict(id=rid, registry_id=family, registry_entry=menu[family],
                                label=reading.get("label", menu[family].get("label", family)),
                                explanation=reading.get("explanation", reading.get("notes", "")),
                                analysis={k: deepcopy(reading[k]) for k in (
                                    "form", "function", "role", "variant", "target_kind", "grammatical_number",
                                    "finite", "attachment_spans", "cues", "wrappers", "operators",
                                    "constructor_form", "constructor_status") if k in reading}))
    output_readings = []
    supplied = result.get("readings", result.get("top5", []))
    if isinstance(supplied, dict):
        supplied = [dict(reading_id=k, candidates=v) for k, v in supplied.items()]
    for branch in supplied:
        rid = branch.get("reading_id", branch.get("reading", {}).get("id"))
        if rid not in reading_ids:
            raise ValueError("Result branch has no saved interpretation")
        candidates, previous = [], 0
        for row in branch.get("candidates", []):
            rank = row["rank"]
            if type(rank) is not int or rank <= previous:
                raise ValueError("Saved candidate ranks are not strictly increasing")
            previous = rank
            if len(candidates) == 5:
                break
            local = row.get("local_decision", row.get("decision", row.get("status")))
            status = _status(local)
            quotes = _quotes(row.get("sources", row.get("evidence", [])), source_pages, case,
                             document_vetoes=document_vetoes)
            if status in {"SUPPORTED", "OPPOSED", "CONFLICTED"} and not quotes:
                raise ValueError("Signed candidate decision has no verified inspected quotation")
            candidates.append(dict(id=row["id"], fill=row["fill"], rank=rank, status=status,
                decision_label=(local or {}).get("label") if isinstance(local, dict) else None,
                explanation=row.get("explanation", (local or {}).get("explanation", "") if isinstance(local, dict) else ""),
                constraints=deepcopy(row.get("constraints", local.get("checklist", []) if isinstance(local, dict) else [])), sources=quotes,
                ranking_explanation=deepcopy(row.get("ranking_explanation", row.get("ranking", {}).get("tiers", []))),
                assessment=review_map.pop((rid, row["id"]), None)))
        output_readings.append(dict(reading_id=rid, candidates=candidates))
    atoms, identities = [], set()
    for row in result.get("atoms", []):
        identity = row["id"]
        if identity in identities:
            raise ValueError("Duplicate required component identity")
        identities.add(identity)
        status = _status(row.get("status"))
        quotes = _quotes(row.get("evidence", row.get("positive_evidence", [])), source_pages, case,
                         document_vetoes=document_vetoes)
        quotes += _quotes(row.get("counterevidence", []), source_pages, case, document_vetoes=document_vetoes)
        if status in {"SUPPORTED", "OPPOSED", "CONFLICTED"} and not quotes:
            raise ValueError("Signed atom lacks a verified inspected quotation")
        atoms.append(dict(id=identity, text=row.get("text", row.get("query", "")), required=row.get("required") is True,
            status=status, sources=quotes, gaps=deepcopy(row.get("gaps", row.get("unresolved_fields", []))),
            explanation=row.get("explanation", ""), answers=deepcopy(row.get("answers", [])),
            qualified_accounts=deepcopy(row.get("qualified_accounts", [])),
            assessment=review_map.pop((None, identity), None) if case["task"] != "redaction" else None))
    if review_map:
        raise ValueError("Assessment subject is not in the supplied displayed top five or H/R atoms")
    if len({" ".join(a["text"].casefold().split()) for a in atoms if a["required"]}) != sum(a["required"] for a in atoms):
        raise ValueError("Duplicate textual requirements cannot pad component counts")
    receipt = deepcopy(retrieval.get("receipt", retrieval))
    receipt.setdefault("inspected_pages", result.get("source_pages_inspected"))
    dag = retrieval.get("search_dag")
    for item in atoms + [c for branch in output_readings for c in branch["candidates"]]:
        if result.get("inspected_page_ids") is not None and any(q["canonical_page_id"] not in result["inspected_page_ids"] for q in item["sources"]):
            raise ValueError("A decision quote is outside the engine's actual inspected pool")
    config = packet.get("config", condition_id or packet.get("reading_mode", reading_packet.get("interpreter", "shared")))
    value = dict(version="next-workbench-condition/1", case=case, config=config,
        packet_sha256=before, run_id=packet.get("run_id"), registry_sha256=registry_hash,
        reading_registry=deepcopy(registry),
        engine_binding=deepcopy(packet.get("binding")), engine_code_pins=deepcopy(packet.get("code_pins", {})),
        plan=dict(atoms=deepcopy(plan.get("atoms", [])), readings=interpreted,
                  reading_status=reading_packet.get("status"), abstention_reason=reading_packet.get("reason")),
        retrieval=dict(receipt=receipt, search_dag=_dag(dag) if dag is not None else dag_from_receipt(receipt)),
        result=dict(status=result.get("status", "UNRESOLVED"), readings=output_readings, atoms=atoms,
                    assembly=deepcopy(result.get("assembly", {})),
                    scope_checks=deepcopy(result.get("query_requirements", {})),
                    limitations=deepcopy(result.get("limitations", [])),
                    rank_semantics=result.get("rank_semantics", "Saved native ranks; not a probability"),
                    evidence_scope=result.get("evidence_scope"), source_budget=deepcopy(result.get("source_budget")),
                    unsupported_readings=deepcopy(result.get("unsupported_readings", [])),
                    exploratory=deepcopy(result.get("exploratory", []))),
        origin=origin, family_id=packet.get("family_id"), episode_id=packet.get("episode_id"),
        authored_counterhypothesis=packet.get("authored_counterhypothesis") is True,
        altered_proposition=packet.get("altered_proposition") is True,
        source_dependencies=deepcopy(packet.get("source_dependencies", [])),
        native_packet_unchanged=True, adapted_not_recomputed=True, model_calls=0)
    for key in ("exposure", "query_only_inference", "answers_read", "grades_read"):
        if key in packet:
            value[key] = deepcopy(packet[key])
    if digest(packet) != before:
        raise AssertionError("New-engine packet mutated")
    value["sha256"] = digest(value)
    return value


def create_report(conditions, *, primary_config="model", titles=None):
    grouped = {}
    for condition in conditions:
        if (condition.get("version") != "next-workbench-condition/1"
                or condition.get("sha256") != digest({k:v for k,v in condition.items() if k != "sha256"})):
            raise ValueError("Adapted condition seal differs")
        case = condition["case"]
        row = grouped.setdefault(case["case_id"], dict(case=deepcopy(case), title=(titles or {}).get(case["case_id"], case["query"]), conditions={}))
        if row["case"] != case or condition["config"] in row["conditions"]:
            raise ValueError("Duplicate or mixed question/condition")
        row["conditions"][condition["config"]] = deepcopy(condition)
    report = dict(version=VERSION, cases=list(grouped.values()), primary_config=primary_config,
        benchmark_accuracy=False, outcome_informed_demo=True, provisional_selection=True,
        scope="Saved source-bound research demonstration; selection is not an accuracy estimate", no_live_inference=True)
    report["sha256"] = digest(report)
    return report


def _h_roles(rows):
    rules = (lambda s,o:s>=2, lambda s,o:o>=2, lambda s,o:s>=2 or o>=2, lambda s,o:s>=1, lambda s,o:o>=1)
    def assign(at, used, mapping):
        if at == 5:
            return mapping
        for row in rows:
            if row["case_id"] not in used and rules[at](row["supported"], row["opposed"]):
                found = assign(at+1, used|{row["case_id"]}, dict(mapping, **{"H"+str(at+1):row["case_id"]}))
                if found is not None: return found
        return None
    return assign(0, set(), {})


def qualify_selection(report, selected_ids):
    """Latest explicit user thresholds, not older stricter/looser docs or a source admission rule."""
    if report.get("sha256") != digest({k:v for k,v in report.items() if k != "sha256"}):
        raise ValueError("Selection report seal changed")
    if len(selected_ids) != len(set(selected_ids)):
        raise ValueError("Duplicate selected question")
    by_id = {r["case"]["case_id"]: r for r in report["cases"]}
    if not set(selected_ids) <= set(by_id):
        raise ValueError("Unknown selected question")
    primary = report["primary_config"]
    metrics, deficits, families, episodes = [], [], [], []
    for cid in selected_ids:
        row = by_id[cid]; case = row["case"]; item = row["conditions"].get(primary)
        if item is None:
            deficits.append(cid+": missing fixed primary condition"); continue
        if _source_assisted(item):
            deficits.append(cid+": source-assisted diagnostic is not a query-only qualifying condition")
        if not item.get("family_id") or not item.get("episode_id"):
            deficits.append(cid+": explicit family/episode metadata required")
        families.append(item.get("family_id")); episodes.append(item.get("episode_id"))
        required = [a for a in item["result"]["atoms"] if a["required"]]
        for atom in required:
            review = atom.get("assessment") or {}
            if (atom["status"] in {"SUPPORTED", "OPPOSED", "CONFLICTED"}
                    and review.get("local_decision_warranted") == "no"):
                deficits.append(cid+": exact-packet review rejects local decision for "+atom["id"])
        branches = item["result"]["readings"]
        locally_backed1 = any(c["rank"] == 1 and c["status"] == "SUPPORTED"
                              for b in branches for c in b["candidates"])
        backed1 = any(c["rank"] == 1 and c["status"] == "SUPPORTED"
                      and (c.get("assessment") or {}).get("judgment") in {"correct", "equivalent"}
                      for b in branches for c in b["candidates"])
        correct5 = any(c.get("assessment", {}).get("judgment") in {"correct", "equivalent"}
                       for b in branches for c in b["candidates"] if c.get("assessment") is not None and c["rank"] <= 5)
        metrics.append(dict(case_id=cid, task=case["task"], corpus=case["corpus"], required=len(required),
            supported=sum(a["status"] == "SUPPORTED" for a in required), opposed=sum(a["status"] == "OPPOSED" for a in required),
            exact_review_validated_backed=sum(a["status"] == "SUPPORTED"
                and (a.get("assessment") or {}).get("local_decision_warranted") == "yes"
                and (a.get("assessment") or {}).get("judgment") in {"correct", "equivalent"} for a in required),
            locally_backed_rank_one=locally_backed1, backed_rank_one=backed1,
            correct_backed_rank_one=backed1, correct_or_equivalent_top5=correct5,
            origin_ready=all(v["complete_original_supplied"] for v in (item["origin"]["masked"],)),
            authored=item["authored_counterhypothesis"], altered=item["altered_proposition"]))
    if len(selected_ids) != 15: deficits.append("Exactly fifteen starters required")
    for task, quota in (("redaction", {"cib":3,"iran":1,"vietnam":1}),
                        ("hypothesis", {"cib":1,"iran":2,"vietnam":2}),
                        ("reconstruction", {"cib":1,"iran":2,"vietnam":2})):
        rows = [r for r in metrics if r["task"] == task]
        if dict(Counter(r["corpus"] for r in rows)) != quota: deficits.append(task+": corpus/task quota unmet")
    if len(families) != len(set(families)) or len(episodes) != len(set(episodes)):
        deficits.append("Duplicate source fact family or episode among starters")
    red = [r for r in metrics if r["task"] == "redaction"]
    rec = [r for r in metrics if r["task"] == "reconstruction"]
    hyp = [r for r in metrics if r["task"] == "hypothesis"]
    if sum(r["backed_rank_one"] for r in red) < 2: deficits.append("Red: at least two locally backed AND exact-reviewed correct/equivalent rank-one cases required")
    if sum(r["correct_or_equivalent_top5"] for r in red) < 4: deficits.append("Red: at least four exact-reviewed correct/equivalent top-five cases required")
    if sum(r["required"] >= 3 and r["supported"] >= 2 for r in rec) < 2: deficits.append("R: at least two cases with >=3 required and >=2 backed components")
    if sum(r["required"] >= 2 and r["supported"] >= 2 for r in rec) < 4: deficits.append("R: at least four cases with >=2 required and >=2 backed components")
    roles = _h_roles(hyp)
    if roles is None: deficits.append("H: five distinct signed roles are not all filled")
    if not any(r["supported"] and r["opposed"] for r in hyp): deficits.append("H: a genuinely mixed case is required")
    if sum(r["authored"] for r in hyp) > 2: deficits.append("H: at most two authored counterhypotheses")
    for task in ("redaction", "reconstruction"):
        if sum(r["altered"] for r in metrics if r["task"] == task) > 1: deficits.append(task+": altered-proposition ceiling exceeded")
    if any(not r["origin_ready"] for r in metrics): deficits.append("Complete original source/birth publication gate unmet")
    return dict(version=SELECTION_VERSION, qualified=not deficits, deficits=deficits, metrics=metrics,
                hypothesis_roles=roles, outcome_informed_not_accuracy=True,
                source_admission_independent_of_recovery=True, primary_config=primary,
                semantic_unitization_verified=False,
                validation_warnings=[
                    "H/R supported and opposed counts are local statuses, not independently validated components.",
                    "Exact textual duplicates are rejected, but semantic duplicates, actor/predicate padding and background requirements need a separate case audit.",
                    "Threshold qualification alone is not publication readiness or an accuracy estimate; model assessment is not gold."],
                qualification_scope="LOCAL_THRESHOLD_CHECK_NOT_SEMANTIC_COMPONENT_AUDIT")


def export_bundle(output, report, *, asset_root=None):
    """Write an additive standalone static replay, separating explicit reveal views."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    asset_root = Path(asset_root or Path(__file__).resolve().parents[1] / "next_ui")
    public = deepcopy(report)
    for row in public["cases"]:
        for condition in row["conditions"].values():
            bundle = condition["origin"]
            base = "data/origins/" + bundle["sha256"]
            refs = {}
            for state in ("masked", "revealed"):
                if bundle.get(state) is None: continue
                payload = json.dumps(bundle[state], sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()
                path = base + "-" + state + ".json"
                _write(output / path, payload)
                refs[state] = dict(path=path, sha256=sha256(payload).hexdigest())
            condition["origin"] = dict(version=ORIGIN_VERSION, refs=refs, sha256=bundle["sha256"])
            condition["source_condition_sha256"] = condition.pop("sha256")
            condition["sha256"] = digest(condition)
    public.pop("sha256", None); public["sha256"] = digest(public)
    raw = json.dumps(public, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()
    _write(output / "data/report.json", raw)
    for name in ("index.html", "workbench.css", "workbench.js", "walkthrough.html"):
        _write(output / name, (asset_root / name).read_bytes())
    receipt = dict(version=VERSION, report_sha256=sha256(raw).hexdigest(), source_report_sha256=report["sha256"],
                   api_calls=0, native_outputs_modified=False, static_only=True)
    _write(output / "publication.json", json.dumps(receipt, sort_keys=True).encode())
    return receipt


def _write(path, raw):
    if path.absolute().resolve() != path.absolute():
        raise ValueError("Symlinked publication output")
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.read_bytes() != raw:
        raise ValueError("Refusing to overwrite a different detached publication artifact")
    path.write_bytes(raw)
