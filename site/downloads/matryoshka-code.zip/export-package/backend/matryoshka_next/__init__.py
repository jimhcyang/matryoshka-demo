"""Source-first task execution, independently versioned from frozen demos."""

VERSION = "matryoshka-source-first/1"
