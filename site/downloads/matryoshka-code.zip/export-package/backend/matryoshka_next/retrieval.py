"""Bounded typed source discovery and explicitly raw-page BM25 controls."""
from collections import defaultdict
import heapq
import re
import time

import numpy as np

from matryoshka_demo.corpus import ordered, ENGLISH_STOP_WORDS
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from .facts import SourcePolicy, fact_index, normal, public_plan
from matryoshka_demo.source_view_policy import descriptor, policy_of


VERSION = "next-directed-source-retrieval/1"
METHODS = {"integrated": "integrated", "bm25": "bm25", "bm25_text_only": "bm25",
           "text_only": "bm25", "shared_index": "shared_index",
           "shared_index_no_expansion": "shared_index", "integrated_hierarchy":"integrated_hierarchy"}


def searches(case, plan):
    public_plan(case, plan)
    values = []
    for text in [a["text"] for a in plan["atoms"] if a.get("kind") != "context"]:
        text = " ".join(MASK.sub(" ", text).split())
        if text and text not in values:
            values.append(text)
    if not values:
        raise ValueError("No executable atomic search input; no whole-query fallback")
    return values


def _rrf(orders):
    scores = defaultdict(float)
    for sequence in orders:
        for rank, pi in enumerate(sequence, 1):
            scores[int(pi)] += 1. / (60 + rank)
    return scores


def _entity_bindings(index, policy, plan):
    extraction = plan.get("extractions", plan.get("base_extractions", {}))
    if not isinstance(extraction, dict):
        return {}, {}, []
    entities = {e.get("local_id", e.get("id")): e for e in extraction.get("entities", [])}
    allowed_nodes = {}
    seeds = []
    for identity, entity in entities.items():
        label = entity.get("label", entity.get("text", ""))
        if (not label or MASK.search(label) or label.startswith("?") or entity.get("contains_unknown_slot")
                or entity.get("is_unknown") or str(entity.get("type", "")).casefold() in {"unknown", "masked"}):
            continue
        occurrences = set(index.entity_names.get(normal(label), []))
        terms = set(re.findall(r"[a-z0-9]+", normal(label))) - ENGLISH_STOP_WORDS
        if terms:
            # Name components can seed discovery but never certify identity.
            component_hits = set.intersection(*(index.entity_tokens.get(t, set()) for t in terms))
            occurrences.update(component_hits)
        allowed_nodes[identity] = set()
        for oi in sorted(occurrences):
            occurrence = index.corpus.occurrences[oi]
            if not policy.allowed(occurrence["page_index"]):
                continue
            node = occurrence["node_id"]
            allowed_nodes[identity].add(node)
            seeds.append((index.corpus.node_index[node], {identity: node}, occurrence["unit_index"]))
    return entities, allowed_nodes, seeds


def _relation_groups(relations, atoms):
    groups = defaultdict(list)
    for ri, relation in enumerate(relations):
        candidates = []
        for atom in atoms:
            if atom.get("kind") == "context":
                continue
            for r in relation.get("query_spans", []):
                if any(max(r["start"], a["start"]) < min(r["end"], a["end"])
                       for a in atom.get("query_spans", [])):
                    candidates.append(atom["id"])
                    break
        # Ambiguous context-wide relations nominate separately, not a fabricated
        # global conjunction binding every unrelated query assertion.
        key = (candidates[0],) if len(candidates) == 1 else ("relation_" + str(ri),)
        groups[key].append(ri)
    return list(groups.items())


def _typed_routes(index, policy, plan, *, limit):
    extraction = plan.get("extractions", plan.get("base_extractions", {}))
    if not isinstance(extraction, dict):
        return [], False, 0
    relations = extraction.get("relations", [])
    _, allowed_nodes, _ = _entity_bindings(index, policy, plan)
    states = [({}, (), tuple(indices), scope) for scope, indices in _relation_groups(relations, plan["atoms"])]
    completed, seen, examined = [], set(), 0
    while states:
        bindings, witnesses, remaining, scope = states.pop(0)
        if not remaining:
            if witnesses:
                completed.append((bindings, witnesses, scope))
            continue
        ri = remaining[0]
        relation = relations[ri]
        source, target = relation.get("source"), relation.get("target")
        if not source or not target:
            continue
        key = index.predicate_key(relation.get("relation", relation.get("predicate", "")))
        for ei in index.by_predicate.get(key, []):
            if examined >= limit:
                return completed, True, examined
            examined += 1
            edge = index.edges[ei]
            if not policy.allowed(edge["pi"]):
                continue
            a, b = index.corpus.node_ids[edge["a"]], index.corpus.node_ids[edge["b"]]
            proposed = dict(bindings)
            compatible = True
            for variable, actual in ((source, a), (target, b)):
                if variable in proposed and proposed[variable] != actual:
                    compatible = False
                if variable in allowed_nodes and actual not in allowed_nodes[variable]:
                    compatible = False
                proposed[variable] = actual
            if not compatible:
                continue
            next_remaining = remaining[1:]
            signature = (scope, tuple(sorted(proposed.items())), next_remaining)
            if signature in seen:
                continue
            seen.add(signature)
            states.append((proposed, witnesses + (ei,), next_remaining, scope))
    return completed, False, examined


def _terms(text):
    return {t for t in re.findall(r"[a-z0-9]+", text.casefold()) if t not in ENGLISH_STOP_WORDS
            and t not in {"what", "which", "who", "how", "did", "does", "would", "redaction"}}


def _affinity(query_terms, source_text):
    source = _terms(source_text)
    return sorted({q for q in query_terms if any(s == q or len(q) >= 4 and s.startswith(q) for s in source)})


def _edge_trace(index, policy, edge, bindings, *, lookup="OUTGOING", scope=(), affinity=()):
    return dict(source=index.corpus.node_ids[edge["a"]], target=index.corpus.node_ids[edge["b"]],
        relation=edge["relation"], kind="SOURCE_ASSERTION", source_row_id=edge["source_row_id"],
        citation=index.quote(policy, edge["ui"]), bindings=dict(bindings),
        pending_criteria=list(scope), source_clause_affinity=list(affinity),
        native_assertion_mode=edge.get("native_assertion_mode"),
        source_edge_direction_preserved=True, lookup_direction=lookup,
        semantic_support_certified=False, identity_equivalence_certified=False,
        relevance_is_not_entailment=True)


def _expand(index, policy, plan, node_scores, *, limit, max_depth, hierarchy):
    entities, _, seeds = _entity_bindings(index, policy, plan)
    query_terms = _terms(" ".join(a["text"] for a in plan["atoms"] if a.get("kind") != "context"))
    seed_terms = set().union(*(_terms(e.get("label", "")) for e in entities.values())) if entities else set()
    useful_terms = query_terms - seed_terms
    if not useful_terms:
        useful_terms = query_terms
    criteria = tuple(a["id"] for a in plan["atoms"] if a.get("required", a.get("kind") != "context"))
    # Source-owned fact matches may seed an event/claim connector even when no
    # entity spelling was extracted. This is a declared display/search seed cap.
    lexical_seeds = sorted(node_scores, key=lambda n: (-node_scores[n], index.corpus.node_ids[n]))
    seed_cap = min(limit, 64)
    incomplete = len(lexical_seeds) > seed_cap
    for ni in lexical_seeds[:seed_cap]:
        occurrences = index.by_node.get(index.corpus.node_ids[ni], [])
        oi = next((oi for oi in occurrences if policy.allowed(index.corpus.occurrences[oi]["page_index"])), None)
        if oi is not None:
            seeds.append((ni, {}, index.corpus.occurrences[oi]["unit_index"]))
    agenda, serial, visited, trace, navigation = [], 0, set(), [], {}
    memberships = getattr(index.corpus, "hierarchy", {})
    for node, bindings, ui in seeds:
        if serial >= limit:
            incomplete = True
            break
        seed_ref = index.quote(policy, ui)
        heapq.heappush(agenda, (0, serial, node, bindings, (), seed_ref))
        serial += 1
    examined = 0
    while agenda:
        _, _, node, bindings, path, seed_ref = heapq.heappop(agenda)
        signature = (node, tuple(sorted(bindings.items())), criteria)
        if signature in visited:
            continue
        visited.add(signature)
        edges = [(ei, "OUTGOING") for ei in index.outgoing.get(node, [])]
        edges += [(ei, "INCOMING_LOOKUP") for ei in index.incoming.get(node, [])]
        for ei, lookup in edges:
            if examined >= limit:
                return trace, list(navigation.values()), True, examined, len(seeds)
            examined += 1
            edge = index.edges[ei]
            if ei in path or not policy.allowed(edge["pi"]):
                continue
            unit = index.corpus.units[edge["ui"]]
            affinity = _affinity(useful_terms, unit["text"] + " " + edge["relation"])
            if not affinity:
                continue
            target = edge["b"] if lookup == "OUTGOING" else edge["a"]
            next_bindings = dict(bindings)
            next_bindings["?source_connector_" + str(len(path) + 1)] = index.corpus.node_ids[target]
            row = _edge_trace(index, policy, edge, next_bindings, lookup=lookup, scope=criteria, affinity=affinity)
            row.update(discovery="QUERY_CONDITIONED_SOURCE_NEIGHBOR", seed_citation=seed_ref,
                route_depth=len(path) + 1, path_source_row_ids=[index.edges[p]["source_row_id"] for p in (*path, ei)])
            trace.append(row)
            priority = -len(affinity)
            if hierarchy:
                source_member = memberships.get(index.corpus.node_ids[node], {})
                target_member = memberships.get(index.corpus.node_ids[target], {})
                shared = source_member.get("community_id")
                if shared and shared == target_member.get("community_id"):
                    priority -= 1
                for ni, member in ((node, source_member), (target, target_member)):
                    previous = index.corpus.node_ids[ni]
                    for name in ("community_id", "theme_id", "domain_id"):
                        destination = member.get(name)
                        if destination:
                            navigation[(previous, destination)] = dict(source=previous, target=destination,
                                kind="HIERARCHY_NAVIGATION", retrospective=True, is_evidence=False,
                                semantic_support_certified=False)
                            previous = destination
            if len(path) + 1 >= max_depth:
                if index.outgoing.get(target) or index.incoming.get(target):
                    incomplete = True
                continue
            heapq.heappush(agenda, (priority, serial, target, next_bindings, (*path, ei), seed_ref))
            serial += 1
    return trace, list(navigation.values()), incomplete, examined, len(seeds)


def retrieve(corpus, case, plan, *, document_budget=100, passage_budget=100,
             method="integrated", agenda_budget=10000, max_depth=3, hierarchy_scheduling=False,
             source_index=None):
    started = time.perf_counter()
    public_plan(case, plan)
    if method not in METHODS:
        raise ValueError("Unknown retrieval method")
    method = METHODS[method]
    hierarchy_navigation = method=="integrated_hierarchy"
    if hierarchy_navigation: method="integrated"
    if type(hierarchy_scheduling) is not bool or hierarchy_scheduling and method != "integrated":
        raise ValueError("Hierarchy priority scheduling is an explicit integrated-only experiment")
    if any(type(n) is not int or n < 1 for n in (document_budget, passage_budget, agenda_budget, max_depth)):
        raise ValueError("Positive integer source/search budgets required")
    eligible = corpus.eligible(case)
    policy = SourcePolicy(corpus, case, source_index)
    mask = np.asarray(eligible.page_mask, dtype=bool) & policy.mask()
    stats = corpus.page_bm25.stats(mask)
    queries = searches(case, plan)
    lexical, audits = [], []
    for query in queries:
        scores = corpus.page_bm25.score(query, mask, stats)
        order = ordered(scores, corpus.page_ids)
        lexical.append(order)
        audits.append(dict(query=query, pages_scored=int(mask.sum()), positive_pages=len(order),
            top_pages=[corpus.page_ids[i] for i in order[:5]]))
    lexical_scores = _rrf(lexical)
    rank = lambda values: sorted(values, key=lambda pi: (-values[pi], corpus.page_ids[pi]))
    page_scores = dict(lexical_scores)
    trace, navigation, node_scores, incomplete, examined = [], [], defaultdict(float), False, 0
    expansion_examined, expansion_seeds = 0, 0
    index = None
    if method != "bm25":
        index = fact_index(corpus)
        # Existing occurrence surfaces are source-owned discovery text, not facts.
        surface_mask = mask[corpus.surface_pages]
        node_stats = corpus.node_bm25.stats(surface_mask)
        structured = defaultdict(float)
        for query in queries:
            values = corpus.node_bm25.score(query, surface_mask, node_stats)
            for si in np.flatnonzero(values > 0):
                pi = int(corpus.surface_pages[si])
                structured[pi] = max(structured[pi], float(values[si]))
                node_scores[int(corpus.surface_nodes[si])] += float(values[si])
        for position, pi in enumerate(rank(structured), 1):
            page_scores[pi] = page_scores.get(pi, 0.) + 1. / (60 + position)
        if method == "integrated":
            routes, incomplete, examined = _typed_routes(index, policy, plan, limit=agenda_budget)
            route_pages = set()
            for bindings, witnesses, scope in routes:
                for ei in witnesses:
                    edge = index.edges[ei]
                    citation = index.quote(policy, edge["ui"])
                    route_pages.add(edge["pi"])
                    for ni in (edge["a"], edge["b"]):
                        node_scores[ni] += 1.
                    trace.append(dict(_edge_trace(index, policy, edge, bindings, scope=scope),
                        discovery="EXACT_TYPED_RELATION_NOMINATION"))
            remaining = agenda_budget - examined
            if remaining > 0:
                expanded, navigation, stopped, expansion_examined, expansion_seeds = _expand(
                    index, policy, plan, node_scores, limit=remaining, max_depth=max_depth,
                    hierarchy=hierarchy_scheduling)
            else:
                expanded, navigation, stopped = [], [], True
            trace.extend(expanded)
            incomplete = incomplete or stopped
            route_pages.update(corpus.page_index[r["citation"]["canonical_page_id"]] for r in expanded)
            for position, pi in enumerate(sorted(route_pages, key=corpus.page_ids.__getitem__), 1):
                page_scores[pi] = page_scores.get(pi, 0.) + 1. / (60 + position)
    hierarchy_result = None
    if hierarchy_navigation:
        from .hierarchy_control import nominate
        ranks={ni:i for i,ni in enumerate(sorted(node_scores,
            key=lambda n:(-node_scores[n],corpus.node_ids[n])),1)}
        hierarchy_result=nominate(corpus,case,plan,node_ranks=ranks,source_index=source_index,
            leaf_budget=passage_budget)
        for position,pi in enumerate(hierarchy_result["nominated_page_order"],1):
            if not mask[pi]:raise ValueError("Hierarchy nominated an ineligible source")
            page_scores[pi]=page_scores.get(pi,0.)+1./(60+position)
        incomplete=incomplete or hierarchy_result["receipt"]["search_status"]=="SEARCH_INCOMPLETE"
    order = rank(page_scores)
    documents = list(dict.fromkeys(corpus.pages[pi]["document_id"] for pi in order))[:document_budget]
    admitted = set(documents)
    pages = [pi for pi in order if corpus.pages[pi]["document_id"] in admitted and mask[pi]]
    # Include siblings of admitted documents, but do not silently exceed inspection.
    known = set(pages)
    pages.extend(i for i, p in enumerate(corpus.pages) if mask[i] and p["document_id"] in admitted and i not in known)
    for pi in pages:
        p = corpus.pages[pi]
        if digest(p["text"]) != p["source_sha256"]:
            raise ValueError("Admitted source bytes changed")
    page_ranks = {pi: i for i, pi in enumerate(order, 1)}
    node_ranks = {ni: i for i, ni in enumerate(sorted(node_scores,
        key=lambda n: (-node_scores[n], corpus.node_ids[n])), 1)}
    receipt = dict(version=VERSION, method="integrated_hierarchy" if hierarchy_navigation else method, text_matcher="BM25", search_queries=audits,
        eligible_pages=int(mask.sum()), eligible_documents=len({corpus.pages[i]["document_id"] for i in np.flatnonzero(mask)}),
        document_budget=document_budget, construction_passage_budget=passage_budget,
        documents_admitted=len(admitted), document_order=documents, pages_admitted=len(pages),
        pages_admitted_are_not_all_inspected=True, source_scope="RAW_PAGE_ONLY" if method == "bm25" else "SOURCE_OCCURRENCES_AND_DIRECTED_EDGES",
        source_edges=trace, navigation_edges=navigation, typed_relation_records_examined=examined,
        hierarchy_navigation=hierarchy_result,
        expansion_records_examined=expansion_examined, expansion_seed_count=expansion_seeds,
        expansion_depth_budget=max_depth, hierarchy_scheduling=bool(hierarchy_scheduling),
        hierarchy_control="ACTUAL_UP_DOWN_RETROSPECTIVE_NAVIGATION" if hierarchy_navigation else
            "MEMBERSHIP_PRIORITY_ONLY_NOT_UP_DOWN_TRAVERSAL" if hierarchy_scheduling else "OFF",
        hierarchy_membership_has_support_credit=False, source_edge_is_entailment=False,
        search_status="SEARCH_INCOMPLETE" if incomplete else "DECLARED_POSTINGS_EXHAUSTED_NOT_CORPUS_COMPLETE",
        agenda_budget=agenda_budget, ppr_used=False, generated_keywords=False,
        score_interpretation="Reciprocal-rank discovery relevance, never support or confidence",
        whole_query_search_executed=False, context_used_as_search=False,
        source_view_policy=descriptor(policy_of(corpus)),
        ranking_rule="RRF constant 60 over atom-only page searches and source occurrence/typed-route discovery"
            +(" plus an explicit retrospective hierarchy nomination stream" if hierarchy_navigation else ""),
        cutoff=case["date"], whole_origin_excluded=(case["document_id"] if case["corpus"] != "cib"
            or policy_of(corpus).value == "strict_prior" else None),
        query_sha256=digest(case["query"]), api_calls=0, keys_read=False, grades_read=False,
        complete_source_index_supplied=source_index is not None,
        wall_seconds=time.perf_counter() - started,
        fact_index=index.stats() if index is not None else None)
    return dict(eligible=eligible, pages=pages, page_ranks=page_ranks, page_scores=dict(page_scores),
        node_ranks=node_ranks, receipt=receipt, passage_budget=passage_budget,
        fact_index=index, source_policy=policy, source_index=source_index)
