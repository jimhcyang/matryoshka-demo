"""Query-only interpretation. Source-aware curation never enters this API."""
from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path
import re

from jsonschema import validate
from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest


VERSION = "next-query-interpretation/15"
PROMPT = """Parse this one public analyst query, not its answer. Extract its visible
entities, claims, events and relations, and split its actual requested facts or
information needs into concise atoms using visible wording and inflection.
Use propositions for claims being tested and short who/what/when/where/how
questions for missing values, without 'the analyst asks' or 'identify' prefaces.
Keep each actual requirement required=true; background and presentation
instructions are context with required=false. Preserve actor, patient, location,
quantity, polarity, time, attribution and uncertainty; questions do not assert
world truth. Copy exact query substrings into every query_quote/evidence_quote.
Argument, actor, object, speaker, date and location are exact visible substrings
or null, never commentary. Relation endpoints are extraction local_id values.
Do not supply hidden names, facts, answers, causal bridges, leads or keywords.
Unknowns stay unknown. Return only the schema; do not force an atom count."""
RECONSTRUCTION_PROMPT = ("Parse only this public reconstruction request, not its answer. Extract its "
    "visible entities, claims, events and relations, and separate its actual requested "
    "components into concise information_need atoms in their ORIGINAL grammatical "
    "form. Retain requested noun phrases, owners, attachments, dates, reporting and "
    "uncertainty. Do not turn a nominal request into new who/what/when questions. "
    "Resolve a visible pronoun only when its public antecedent is unambiguous. Use "
    "visible words and inflection only, not synonyms, hidden names or facts. Required "
    "components remain required; background stays optional. Copy exact public query "
    "substrings as quotations; argument fields are visible substrings or null. Do "
    "not answer, create leads or keywords, or force an atom count. Return only the schema.")
PRIVATE = {"answer", "answers", "hidden_answer", "reference_answer", "source_proof",
    "source_episode", "origin_text", "evidence", "grades", "oracle", "leads", "keywords",
    "candidate_ranks", "candidate_answers", "curator_readings"}
ATTRIBUTE_FIELDS={"description","role","occupation","affiliation","nationality","title",
    "alias","aliases","name","quantity","unit","date","location"}


def obj(fields):
    return dict(type="object", properties=fields, required=list(fields), additionalProperties=False)


def schema(task=None):
    text = dict(type="string")
    nullable = dict(type=["string", "null"])
    strings = dict(type="array", items=text)
    item = obj(dict(local_id=text, label=text, type=text, evidence_quote=text,
                    attributes=dict(type="array", items=obj(dict(key=text, value=text)))))
    claim = obj(dict(local_id=text, claim_text=text, speaker=nullable, assertion_mode=text,
                     evidence_quote=text))
    event = obj(dict(local_id=text, label=text, type=text, actor=nullable,
                     predicate=nullable, object=nullable, date=nullable, location=nullable,
                     assertion_mode=text, evidence_quote=text))
    relation = obj(dict(local_id=text, source=text, target=text, relation=text,
                        assertion_mode=text, evidence_quote=text))
    atom = obj(dict(id=text, text=text,
        kind=dict(type="string", enum=["proposition", "context"] if task=="redaction" else ["proposition", "information_need", "context"]),
        query_quotes=strings, subject=nullable, predicate=nullable, object=nullable,
        polarity=dict(type="string", enum=["positive", "negative", "unknown"]),
        modality=dict(type="string", enum=["asserted", "reported", "possible", "conditional", "unknown"]),
        required=dict(type="boolean")))
    return obj(dict(atoms=dict(type="array", items=atom, minItems=1),
        extractions=obj(dict(entities=dict(type="array", items=item),
            claims=dict(type="array", items=claim), events=dict(type="array", items=event),
            relations=dict(type="array", items=relation)))))


def public_input(case):
    # Whitelist instead of copying caller's answer-bearing dictionaries.
    value = public_case(case)
    return dict(task=value["task"], query=value["query"], focal_marker=value["focal_marker"])


def _spans(query, quote, *, allow_mask=False):
    if not quote or not allow_mask and MASK.search(quote):
        raise ValueError("Nonempty visible source quotation required")
    positions, start = [], query.find(quote)
    while start >= 0:
        positions.append(dict(start=start, end=start+len(quote), text=quote))
        start = query.find(quote, start+1)
    if not positions:
        raise ValueError("Quotation is not an exact public query substring")
    return positions


def _literal_visible_slice(text,query):
    if not text:return False
    word=lambda ch:ch.isalnum() or ch=="_"
    return any((not match.start() or not (word(text[0]) and word(query[match.start()-1])))
        and (match.end()==len(query) or not (word(text[-1]) and word(query[match.end()])))
        for match in re.finditer(re.escape(text),query))


def _visible_words(term, query):
    """Reordered visible arguments are allowed; new names/facts are not."""
    if _literal_visible_slice(term,query):return True
    words = lambda value: {surface for surface, _ in _query_tokens(value)}
    grammar = {"a", "an", "the", "of", "to", "from", "in", "on", "at", "for",
               "by", "with", "is", "was", "were", "be", "been", "being", "that",
               "which", "who", "what", "whom", "whose", "and", "as"}
    # This is a vocabulary hygiene check, not role/negation entailment.
    return words(term) <= words(query) | grammar


@lru_cache(maxsize=2048)
def _query_tokens(text):
    from .readings import _model
    # Mixed identifiers, format characters and symbols cannot disappear from
    # provenance checks just because the NLP tokenizer does not call them words.
    return tuple((t.text, (t.lemma_ or t.text).casefold()) for t in _model()(text.casefold())
        if not t.is_space and not t.is_punct)


@lru_cache(maxsize=2048)
def _lexemes(text):
    from .readings import _model
    return frozenset([lemma for _, lemma in _query_tokens(text)] +
        [(t.lemma_ or t.text).casefold() for t in _model()(text)
         if not t.is_space and not t.is_punct])


@lru_cache(maxsize=2048)
def _token_options(text):
    from .readings import _model
    original = {}
    for token in _model()(text):
        if not token.is_space and not token.is_punct:
            original.setdefault(token.text.casefold(), set()).add((token.lemma_ or token.text).casefold())
    return tuple((surface, frozenset({lemma} | original.get(surface, set())))
        for surface, lemma in _query_tokens(text))


def _query_bound_text(text, query, *, kind=None):
    # Inflection is allowed; unprovided substantive vocabulary is not. This is
    # conservative input hygiene, not a claim that lexical overlap entails truth.
    # Exact public bytes are already bound, including punctuation next to masks.
    # Tokenizing the sentence alone can otherwise disagree with its full context.
    if _literal_visible_slice(text,query):
        return True
    grammar = _lexemes("a an the of to from in on at for by with is was were be "
        "been being that which who what whom whose where when why how there and as do did does whether")
    if kind == "information_need":
        text = re.sub(r"^(?:the analyst asks?\s+|(?:identify|determine|assess|explain|provide)\s+)","",text,flags=re.I)
        grammar = grammar | {"well"}
    if kind == "context" and re.search(r"\bwithout\b",query,re.I):
        grammar = grammar | {"not"}
    # Mask-adjacent punctuation can make the parser swallow a visible word into
    # the mask token. Separate only recognized masks for vocabulary comparison;
    # the public text, quotations and their coordinates remain unchanged.
    comparison_query = MASK.sub(lambda m: " " + m.group() + " ", query)
    visible = {surface for surface, _ in _query_tokens(comparison_query)}
    allowed = _lexemes(comparison_query) | grammar
    return all(surface in visible or options.intersection(allowed) for surface, options in _token_options(text))


def _bind_quote(query, quotation, qc, *, field):
    if quotation in query:
        return quotation
    if not quotation or not quotation.split():
        return quotation
    from .quotations import locate
    try:
        start,end,rebound,_ = locate(query,quotation,allow_layout=True,ignore_case=True)
    except ValueError:
        return quotation
    qc.append(dict(field=field,reason="UNIQUE_PUBLIC_CASE_WHITESPACE_QUOTE_REBINDING",
        supplied_sha256=digest(quotation),start=start,end=end,text=rebound))
    return rebound


def _check_operators(case, atoms):
    required = [a for a in atoms if a["required"] and a["kind"] != "context"]
    if case["task"] != "redaction" and not required:
        raise ValueError("Query has no required information need or proposition")
    # Do not let disjoint literal quotations silently erase an explicit operator.
    for match in re.finditer(r"\b(?:not|never|no|without)\b|n't\b", case["query"], re.I):
        if not any(s["start"] <= match.start() and match.end() <= s["end"]
                   for a in atoms for s in a["query_spans"]):
            raise ValueError("Query negation operator has no annotation coverage")
    from .readings import _model
    for atom in atoms:
        if atom["polarity"] != "positive" or not atom["predicate"]:
            continue
        predicates = _lexemes(atom["predicate"])
        for quote in atom["query_quotes"]:
            doc = _model()(quote.casefold())
            if any(t.dep_ == "neg" and t.head.lemma_.casefold() in predicates for t in doc):
                raise ValueError("Requested polarity conflicts with query predicate negation")


_REQUEST_VERBS = {"ask", "assess", "describe", "determine", "discuss", "distinguish", "establish",
    "evaluate", "examine", "explain", "give", "identify", "include", "investigate", "keep",
    "preserve", "provide", "reconstruct", "test", "trace"}


def _literal_frames(text, parser=None):
    from .readings import _model
    parse = parser or _model()
    doc = parse(text)
    root_is_verbal = any(t.dep_ == "ROOT" and t.pos_ == "VERB" and
        any(c.dep_ in {"nsubj","nsubjpass"} for c in t.children) for t in doc)
    if not root_is_verbal and doc and doc[0].lower_ in {"did", "does", "do", "was", "were", "is", "are", "has", "have", "had",
            "can", "could", "will", "would", "should", "may", "might"}:
        pivot = next((t for t in list(doc)[1:] if t.pos_ in {"VERB", "AUX"}),None)
        if pivot is not None and pivot.idx > doc[0].idx+len(doc[0]):
            # Auxiliary inversion is grammar, not a truth assertion. The same
            # visible words are reparsed; the public question is never changed.
            subject = text[len(doc[0]):pivot.idx].strip()
            text = subject+" "+doc[0].text+" "+text[pivot.idx:]
            doc = parse(text)
    frames = []
    for token in doc:
        if token.pos_ not in {"VERB", "AUX"} or token.dep_ in {"aux", "auxpass", "amod", "compound"}:
            continue
        children = list(token.children)
        subjects = [c for c in children if c.dep_ == "nsubj"]
        if not subjects and token.dep_ in {"xcomp","conj"}:
            parent = token.head
            if not any(c.dep_ in {"dobj","obj","iobj"} for c in parent.children):
                subjects = [c for c in parent.children if c.dep_ == "nsubj"]
        objects = [c for c in children if c.dep_ in {"dobj", "obj", "iobj", "attr"}]
        objects += [c for c in children if c.dep_ == "nsubjpass"]
        if token.dep_ == "acl" and token.tag_ == "VBN" and token.head.pos_ in {"NOUN", "PROPN"}:
            objects.append(token.head)
        subjects += [p for c in children if c.dep_ == "agent" for p in c.children if p.dep_ == "pobj"]
        if token.lemma_.casefold() in _REQUEST_VERBS and not any(c.pos_ == "PROPN" for c in subjects):
            continue
        def mentions(values):
            result = []
            for c in values:
                if c.lower_ in {"that","which","who"} and token.dep_ == "relcl" and token.head.pos_ in {"NOUN","PROPN"}:
                    head = token.head
                    while head.dep_ == "conj" and head.head.pos_ in {"NOUN","PROPN"}:
                        head = head.head
                    excluded = {t.i for t in token.subtree}
                    result.append(" ".join(t.text for t in head.subtree if t.i not in excluded))
                elif c.lower_ not in {"who", "what", "which"}:
                    result.append(" ".join(t.text for t in c.subtree))
            return result
        roles = dict(agent=mentions(subjects),patient=mentions(objects))
        obliques = []
        for child in children:
            if child.dep_ != "prep":
                continue
            values = [c for c in child.children if c.dep_ == "pobj"]
            roles["prep:"+child.lemma_.casefold()] = mentions(values)
            obliques.extend(values)
        frames.append(dict(predicate=token.lemma_.casefold(),subjects=mentions(subjects),objects=mentions(objects),roles=roles,
            grammatical_subjects=mentions([c for c in children if c.dep_ in {"nsubj","nsubjpass"}]),
            named_arguments={t.lemma_.casefold() for c in subjects+objects+obliques for t in c.subtree
                             if t.pos_ == "PROPN" or t.like_num},
            negated=any(c.dep_ == "neg" for c in children),start=token.idx,end=token.idx+len(token)))
    return frames


def _role_present(term, roles):
    wanted = _lexemes(term) - {"the", "a", "an"}
    return any(wanted <= _lexemes(role) for role in roles)


@lru_cache(maxsize=2048)
def _question_slots(text):
    """Public WH variables, scoped to their predicate and known participants."""
    from .readings import _model
    doc = _model()(text)
    wh = {"who", "whom", "whose", "what", "which", "where", "when", "why", "how"}
    predicates = {"ROOT", "conj", "ccomp", "xcomp", "advcl", "relcl"}
    core = {"nsubj", "nsubjpass", "dobj", "obj", "iobj", "attr"}
    slots = set()
    for token in doc:
        if token.lower_ not in wh:
            continue
        head = next((a for a in token.ancestors if a.dep_ in predicates), token.head)
        if head.dep_ == "relcl":
            continue
        role = "who" if token.lower_ == "whom" else token.lower_
        if role in {"what", "which"} and token.head.pos_ == "NOUN":
            nominal = token.head.lemma_.casefold()
            role = {"time": "when", "date": "when", "place": "where", "location": "where",
                "way": "how", "manner": "how"}.get(nominal, "what:" + nominal)
        elif role == "which":
            role = "what"
        if role == "how" and token.head.pos_ in {"ADJ", "ADV"}:
            role += ":" + token.head.lemma_.casefold()
        arguments = [c for c in head.children if c.dep_ in core]
        arguments += [p for c in head.children if c.dep_ == "agent" for p in c.children if p.dep_ == "pobj"]
        if head.dep_ == "conj" and not any(c.dep_ in {"nsubj", "nsubjpass"} for c in arguments):
            arguments += [c for c in head.head.children if c.dep_ in {"nsubj", "nsubjpass"}]
        known = frozenset(t.lemma_.casefold() for c in arguments
            if not any(t.lower_ in wh for t in c.subtree) for t in c.subtree
            if t.pos_ in {"NOUN", "PROPN", "PRON", "NUM"})
        slots.add((role, head.lemma_.casefold(), known))
    return frozenset(slots)


_FIELD_GRAMMAR = frozenset("a an the be do what which how who whom whose and of to from in on at for by with as".split())


def _field_tokens(text):
    values = list(_token_options(text))
    if values and values[0][0] in _REQUEST_VERBS:
        values = values[1:]
    return [(surface, options) for surface, options in values
        if not options.intersection(_FIELD_GRAMMAR | {"include", "preserve"})]


def _field_projection(text, quote):
    offered = _field_tokens(quote)
    wanted = _field_tokens(text)
    from .readings import _model
    source, target = _model()(quote), _model()(text)
    unary = {t.lemma_.casefold() for t in source if t.dep_ == "amod" and t.tag_ == "VBG"
        and any(v.lemma_.casefold() == t.lemma_.casefold()
            and any(c.dep_ == "nsubj" and c.lemma_.casefold() == t.head.lemma_.casefold() for c in v.children)
            and not any(c.dep_ in {"dobj", "obj", "iobj"} for c in v.children) for v in target)}
    if unary:
        offered = [(s, opts) for s, opts in offered if not opts.intersection(unary)]
        wanted = [(s, opts) for s, opts in wanted if not opts.intersection(unary)]
    position = 0
    for surface, options in wanted:
        found = next((i for i in range(position, len(offered))
            if surface == offered[i][0] or options.intersection(offered[i][1])), None)
        if found is None:
            return False
        position = found + 1
    return bool(_field_tokens(text))


@lru_cache(maxsize=2048)
def _field_links(text):
    from .readings import _model
    doc = _model()(text)
    links = set()
    def add(kind, head, value):
        kind = "modifier" if kind in {"amod", "compound"} else kind
        heads = _lexemes(head.text) | {head.lemma_.casefold()}
        values = _lexemes(value.text) | {value.lemma_.casefold()}
        links.update((kind, h, v) for h in heads for v in values)
    def head_of(token):
        if token.lemma_.casefold() == "be":
            nouns = [c for c in token.children if c.dep_ in {"attr", "nsubj", "nsubjpass"}
                     and c.lower_ not in {"what", "which"}]
            if len(nouns) == 1:
                return nouns[0]
        if token.lower_ in _REQUEST_VERBS:
            nouns = [c for c in token.children if c.dep_ in {"dobj", "obj"} and c.pos_ in {"NOUN", "PROPN"}]
            if nouns:
                return nouns[0]
        return token
    for token in doc:
        if token.dep_ in {"poss", "compound", "amod", "nummod"} and token.lower_ not in _REQUEST_VERBS | {"what", "which"}:
            add(token.dep_, token.head, token)
        if token.dep_ == "prep":
            for child in token.children:
                if child.dep_ in {"pobj", "pcomp"}:
                    add("prep:" + token.lemma_.casefold(), head_of(token.head), child)
                    parent = head_of(token.head)
                    while parent.dep_ == "pobj" and parent.head.dep_ == "prep":
                        parent = head_of(parent.head.head)
                        add("prep:" + token.lemma_.casefold(), parent, child)
    # Shared possessors and adjectival qualifiers can scope a coordinated list;
    # a member's own explicit modifier is never replaced by its neighbour's.
    for token in doc:
        parent = token
        while parent.dep_ == "conj":
            parent = parent.head
            for kind in ("poss", "amod"):
                if not any(c.dep_ == kind for c in token.children):
                    for child in parent.children:
                        if child.dep_ == kind:
                            add(kind, token, child)
            if parent.dep_ in {"amod", "compound"}:
                add("modifier", parent.head, token)
            if parent.dep_ == "pobj" and parent.head.dep_ == "prep":
                add("prep:" + parent.head.lemma_.casefold(), head_of(parent.head.head), token)
    for match in re.finditer(r"\b(?:including|preserving)\s+", text, re.I):
        links.update(_field_links(text[match.end():]))
    return frozenset(links)


def _bind_nominal_fields(case, atoms, qc):
    if case["task"] != "reconstruction" or _question_slots(case["query"]):
        return
    from .readings import _model
    public = _model()(case["query"])
    if not public or public[0].lower_ not in _REQUEST_VERBS:
        return
    required = [a for a in atoms if a["required"] and a["kind"] != "context"]
    fields = [a for a in required if a["kind"] == "information_need"]
    if not fields:
        return
    public_links = _field_links(case["query"])
    for atom in fields:
        unresolved_scope = []
        slots = _question_slots(atom["text"])
        if any(role not in {"what", "how"} and not role.startswith("what:") for role, _, _ in slots):
            raise ValueError("Nominal field introduced an unrequested question answer role")
        quotes = atom["query_quotes"]
        if not any(_field_projection(atom["text"], quote) for quote in quotes):
            raise ValueError("Nominal field is not an ordered projection of its selected query quotation")
        selected_links = public_links | set().union(*(_field_links(q) for q in quotes))
        if not _field_links(atom["text"]) <= selected_links:
            raise ValueError("Nominal field owner, qualifier or attachment changed")
        for key in ("subject", "predicate", "object"):
            if atom[key] and not (_query_bound_text(atom[key], " ".join(quotes))
                    and _query_bound_text(atom[key], atom["text"])):
                if not _query_bound_text(atom[key], case["query"]):
                    raise ValueError("Nominal field metadata introduced unprovided query content")
                qc.append(dict(table="atoms", local_id=atom["id"], field=key,
                    reason="PUBLIC_METADATA_OUTSIDE_SELECTED_FIELD_WITHHELD", supplied_sha256=digest(atom[key])))
                atom[key] = None
                unresolved_scope.append(key)
        atom["field_intent"] = dict(kind="NOMINAL_SOURCE_FIELD", query_spans=deepcopy(atom["query_spans"]),
            model_selected_field=True, local_atom_creation=False, asserted_world_fact=False,
            unresolved_scope=sorted(unresolved_scope))
    covered = set().union(*(_lexemes(a["text"]) | {s for s, _ in _query_tokens(a["text"])} for a in required))
    if any(surface not in covered and not options.intersection(covered)
           for surface, options in _field_tokens(case["query"])):
        raise ValueError("Required nominal query field or qualification disappeared")


def _check_question_slots(case, atoms):
    if case["task"] != "reconstruction":
        return
    public = _question_slots(case["query"])
    required = [a for a in atoms if a["required"] and a["kind"] != "context"]
    if not public and required and all(a.get("field_intent") or
            a["kind"] == "proposition" and not _question_slots(a["text"]) for a in required):
        return
    normalized = set().union(*(_question_slots(a["text"]) for a in atoms
        if a["required"] and a["kind"] != "context"))
    if normalized != public:
        raise ValueError("Required question answer role or clause binding changed")


def _check_query_structure(case, atoms):
    if case["task"] == "redaction":
        return
    public = _literal_frames(case["query"])
    required = [a for a in atoms if a["required"] and a["kind"] != "context"]
    normalized = {a["id"]:_literal_frames(a["text"]) for a in required}
    for atom in required:
        predicates = {f["predicate"] for f in normalized[atom["id"]]}
        if atom["predicate"]:
            from .readings import _model
            supplied = {t.lemma_.casefold() for t in _model()(atom["predicate"])
                        if t.pos_ == "VERB" or t.lemma_.casefold() not in {"be", "have", "do"} and t.is_alpha}
            known = {f["predicate"] for f in public}
            if supplied and not supplied.intersection(known | set(_lexemes(case["query"]))):
                raise ValueError("Query predicate metadata introduced an unprovided action")
        for frame in normalized[atom["id"]]:
            if atom.get("field_intent") and frame["predicate"] == "be":
                continue
            alternatives = [f for f in public if f["predicate"] == frame["predicate"]]
            if not alternatives:
                continue
            if frame["subjects"] and not any(all(_role_present(s,f["subjects"]) for s in frame["subjects"])
                                              for f in alternatives):
                raise ValueError("Normalized atom reverses or changes a public subject role")
            if not any(all(all(_role_present(value,f["roles"].get(role,[])) for value in values)
                           for role,values in frame["roles"].items()) for f in alternatives):
                raise ValueError("Normalized query patient, recipient or location role changed")
        selected = [f for f in public if f["predicate"] in predicates or atom["predicate"] and
                    f["predicate"] in _lexemes(atom["predicate"])]
        if atom["subject"] and selected and not atom.get("field_intent") and not any(_role_present(atom["subject"],f["subjects"]+f["grammatical_subjects"]) for f in selected):
            raise ValueError("Query subject metadata does not bind the public actor role: "+atom["id"]+" / "+atom["subject"])
    for frame in public:
        covering = [a for a in required if frame["predicate"] in _lexemes(a["text"])]
        if not covering:
            raise ValueError("Required public predicate/reporting clause has no normalized query coverage")
        if not all(_role_present(term, [a["text"] for a in covering]) for term in frame["named_arguments"]):
            raise ValueError("Named/quantity query arguments disappeared from required coverage")
        if frame["negated"] and not any(a["polarity"] == "negative" and
                any(s["start"] <= frame["start"] < s["end"] and
                    re.search(r"\b(?:not|never)\b|n't\b",s["text"],re.I) for s in a["query_spans"])
                for a in covering):
            raise ValueError("Required query negation cannot be moved into optional context")


def bind(case, output, *, receipt=None):
    case = public_case(case)
    validate(output, schema(case["task"]))
    query = case["query"]
    value = deepcopy(output)
    qc = []
    if len({a["id"] for a in value["atoms"]}) != len(value["atoms"]):
        raise ValueError("Duplicate atom IDs")
    for atom in value["atoms"]:
        if not atom["query_quotes"]:
            raise ValueError("Atom requires exact query evidence")
        atom["query_quotes"] = [_bind_quote(query,q,qc,field="atom_quote") for q in atom["query_quotes"]]
        atom["query_spans"] = [span for quote in atom["query_quotes"]
                               for span in _spans(query, quote, allow_mask=True)]
        if not _query_bound_text(atom["text"], query,kind=atom["kind"]):
            if atom["kind"] != "context" or atom["required"]:
                raise ValueError("Atom text introduced unprovided query content: "+atom["id"])
            qc.append(dict(table="atoms",local_id=atom["id"],field="context_text",
                reason="UNBOUND_BACKGROUND_NORMALIZATION_WITHHELD",supplied_sha256=digest(atom["text"])))
            atom["text"] = " ".join(atom["query_quotes"])
        if atom["kind"] == "context" and atom["required"]:
            raise ValueError("Background is not a required answer component")
        for key in ("subject", "predicate", "object"):
            term = atom[key]
            if term and key == "predicate" and not _query_bound_text(term,query):
                qc.append(dict(table="atoms",local_id=atom["id"],field=key,
                    reason="UNBOUND_GENERATED_FIELD_WITHHELD",supplied_sha256=digest(term)))
                atom[key]=None
            elif term and key != "predicate" and not _visible_words(term, query):
                raise ValueError("A query argument introduced an unseen spelling")
        atom["source_quote"] = atom["query_quotes"][0]
        atom["status"] = "REQUIREMENT_NOT_ASSERTED_WORLD_FACT"
    _check_operators(case, value["atoms"])
    _bind_nominal_fields(case, value["atoms"], qc)
    _check_question_slots(case, value["atoms"])
    _check_query_structure(case, value["atoms"])
    ids = set()
    for rows in value["extractions"].values():
        for row in rows:
            if row["local_id"] in ids:
                raise ValueError("Duplicate extraction local IDs")
            ids.add(row["local_id"])
            row["evidence_quote"] = _bind_quote(query,row["evidence_quote"],qc,field="extraction_quote")
            row["query_spans"] = _spans(query, row["evidence_quote"], allow_mask=True)
            row["contains_unknown_slot"] = bool(MASK.search(row["evidence_quote"]))
            if "claim_text" in row and not _query_bound_text(row["claim_text"], query):
                qc.append(dict(table="claims", local_id=row["local_id"], field="claim_text",
                    reason="UNBOUND_GENERATED_FIELD_WITHHELD", supplied_sha256=digest(row["claim_text"])))
                row["claim_text"] = row["evidence_quote"]
            if "attributes" in row:
                accepted = []
                for attribute in row["attributes"]:
                    if (_query_bound_text(attribute["value"], query) and
                            (attribute["key"].casefold() in ATTRIBUTE_FIELDS or _query_bound_text(attribute["key"],query))):
                        accepted.append(attribute)
                    else:
                        qc.append(dict(table="entities", local_id=row["local_id"], field="attribute",
                            reason="UNBOUND_GENERATED_FIELD_WITHHELD", supplied_sha256=digest(attribute)))
                row["attributes"] = accepted
            for field in ("label", "actor", "object", "speaker", "date", "location", "predicate"):
                term = row.get(field)
                valid = _query_bound_text(term,query) if field=="predicate" and term else _visible_words(term,query) if term else True
                if term and not valid:
                    qc.append(dict(table=next(k for k,v in value["extractions"].items() if rows is v),
                        local_id=row["local_id"], field=field,
                        reason="UNBOUND_GENERATED_FIELD_WITHHELD", supplied_sha256=digest(term)))
                    row[field] = row["evidence_quote"] if field == "label" else None
    retained_relations = []
    for row in value["extractions"]["relations"]:
        if row["source"] not in ids or row["target"] not in ids:
            qc.append(dict(table="relations", local_id=row["local_id"], field="endpoints",
                reason="UNRESOLVED_RELATION_ENDPOINTS_WITHHELD", supplied_sha256=digest(row)))
        elif not (_query_bound_text(row["relation"],query)
                or _query_bound_text(row["relation"].replace("_"," "),query)):
            qc.append(dict(table="relations",local_id=row["local_id"],field="relation",
                reason="UNBOUND_GENERATED_FIELD_WITHHELD",supplied_sha256=digest(row["relation"])))
        else:
            retained_relations.append(row)
    value["extractions"]["relations"] = retained_relations
    return dict(version=VERSION, task=case["task"], query_sha256=digest(query),
        atoms=value["atoms"], extractions=value["extractions"], query_only=True,
        hidden_answers_read=False, corpus_read=False, receipt=receipt,
        projection_qc=qc, raw_output_sha256=digest(output))


def validate_plan(plan, case):
    if (plan.get("version") != VERSION or plan.get("task") != case["task"]
            or plan.get("query_sha256") != digest(case["query"])):
        raise ValueError("Plan belongs to different public question")
    raw = dict(atoms=[{k:v for k,v in a.items() if k in schema()["properties"]["atoms"]["items"]["properties"]}
                      for a in plan["atoms"]],
        extractions={key:[{k:v for k,v in row.items() if k not in {"query_spans", "contains_unknown_slot"}} for row in rows]
                     for key, rows in plan["extractions"].items()})
    expected = bind(case, raw, receipt=plan.get("receipt"))
    # Projection is lossy: rebind sees None, not the discarded original value.
    # Recover its unresolved scope from the retained, field-specific loss record.
    expected_atoms = {a["id"]: a for a in expected["atoms"]}
    for record in plan.get("projection_qc", []):
        if record.get("reason") != "PUBLIC_METADATA_OUTSIDE_SELECTED_FIELD_WITHHELD":
            continue
        atom = expected_atoms.get(record.get("local_id"))
        field = record.get("field")
        if (record.get("table") != "atoms" or atom is None or not atom.get("field_intent")
                or field not in {"subject", "predicate", "object"} or atom[field] is not None
                or not re.fullmatch(r"[a-f0-9]{64}", record.get("supplied_sha256", ""))):
            raise ValueError("Invalid nominal metadata scope-loss record")
        atom["field_intent"]["unresolved_scope"].append(field)
    for atom in expected["atoms"]:
        if atom.get("field_intent"):
            atom["field_intent"]["unresolved_scope"] = sorted(set(atom["field_intent"]["unresolved_scope"]))
    audit_fields = {"projection_qc", "raw_output_sha256"}
    if ({k:v for k,v in plan.items() if k not in audit_fields}
            != {k:v for k,v in expected.items() if k not in audit_fields}):
        raise ValueError("Derived query annotation changed")
    if not re.fullmatch(r"[a-f0-9]{64}", plan.get("raw_output_sha256", "")):
        raise ValueError("Raw model-output identity missing")
    return deepcopy(plan)


def prompt_for_task(task):
    if task == "reconstruction":
        return RECONSTRUCTION_PROMPT
    if task == "redaction":
        return PROMPT + " For redaction, atoms are visible cloze statements with the gap left opaque, not questions asking which text is missing; that request is already the fixed task."
    if task == "hypothesis":
        return PROMPT
    raise ValueError("Unknown planning task")


def request_output(case, api_root, *, cap=25., model="gpt-6-luna"):
    """Independent one-query wire; binding/NLP remains on the caller's thread."""
    from matryoshka_demo.api_v2 import call
    stage = "next_query_interpretation_v5" if case["task"] == "reconstruction" else "next_query_interpretation_v4"
    return call(api_root, stage, public_input(case), prompt_for_task(case["task"]),
        schema(case["task"]), model=model, max_output_tokens=6000, cap=cap)


def parse(case, api_root, *, cap=25., model="gpt-6-luna"):
    output, receipt = request_output(case,api_root,cap=cap,model=model)
    return bind(case, output, receipt=receipt)


def from_literal(case):
    """Explicit debug control, not a substitute for a paid/model parsed plan."""
    query = case["query"]
    return bind(case, dict(atoms=[dict(id="a1", text=query,
        kind="information_need" if case["task"] == "reconstruction" else "proposition",
        query_quotes=[query], subject=None, predicate=None, object=None,
        polarity="unknown", modality="unknown", required=True)],
        extractions=dict(entities=[], claims=[], events=[], relations=[])),
        receipt=dict(debug_literal_control=True, api_calls=0))
