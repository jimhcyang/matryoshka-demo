"""Source-first Red prototype. No old full constructor or model calls.

All explicitly inspected pages are enumerated once. A fixed source-only rank permits exact
lazy grammar/evidence admission, rather than parsing every completed insertion.
All raw occurrences survive grouping; no entity or evidence fields are merged.
"""
from collections import Counter, defaultdict
from copy import deepcopy
from functools import lru_cache
import re
import time

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo.candidates_v2 import source_parser
from matryoshka_demo.corpus import words, ENGLISH_STOP_WORDS
from matryoshka_current.arm_controls import _checked_page
from matryoshka_current.construction import proposal_spans, _nominal_carrier
from matryoshka_demo_v61.candidates import boundary_fit
from matryoshka_demo.fill_wording_v23 import modifier_wording
from matryoshka_demo import roles
from matryoshka_demo.candidate_types_v22 import NounResource, person_guard
from matryoshka_demo_v6 import reporting_fixed_pool_decisions_v65 as evidence_gate
from . import constraints
from .source_label_spans import spans as source_label_spans


VERSION = "next-source-first-redaction-construction/0.9"
CONSTRAINT_ADAPTER_VERSION = "next-constructor-constraint-audit/1"
PROPERTY_SCOPE_VERSION = "source-owned-property-instance-scope/1"
FEASIBILITY_VERSION = "source-owned-positive-slot-feasibility/1"
FORMS = {"nominal", "modifier", "possessive", "member_example", "quantity"}
RANK_TIERS = ("positive_source_feasibility", "source_owned_relation_match", "source_type_match", "owned_carrier_match", "focal_argument_predicate_match", "visible_name_overlap_penalty",
    "source_owned_role_context", "whole_query_context_coverage", "literal_attachment_coverage", "focal_context_coverage", "retrieval_page_score",
    "retrieval_page_rank", "stable_source_occurrence")
TYPE_MAP = {"Person":"person", "Organization":"organization", "Government":"organization",
    "Military":"organization", "PoliticalGroup":"organization", "Country":"place", "Location":"place"}


class SourceParses:
    """Per-call immutable raw/analysis Docs, copied on return; no global cache edits."""
    def __init__(self, parse=None):
        self.parse = parse or source_parser()
        self.docs = {}
        self.calls = 0
        self.misses = 0
        self.noun_resource = NounResource()

    def __call__(self, text):
        self.calls += 1
        if text not in self.docs:
            doc = self.parse(text)
            if doc.text != text:
                raise ValueError("Source parser changed literal characters")
            self.docs[text] = doc.copy()
            self.misses += 1
        return self.docs[text].copy()


def _constraint_audit(case, reading, candidate, admitted):
    """Persist delegated checks after ranking; never infer semantic instance IDs.

    Literal source replay authorizes citations, not entailment. Existing decision
    certificates lack the helper's explicit actor/event instance assignments, so
    they remain verbatim caller results rather than newly signed ledger facts.
    """
    identity = dict(case_id=case["case_id"], query_sha256=digest(case["query"]),
        reading_id=reading["id"], candidate_id=candidate["id"])
    result = dict(version=CONSTRAINT_ADAPTER_VERSION, helper_version=constraints.VERSION,
        audit_only=True, affects_selection=False, binding=identity,
        source_binding_kind="EXACT_CANDIDATE_CITATION_SNAPSHOT_NOT_CORPUS_INDEX_ID",
        scope="ALREADY_CHECKED_VIABLE_CANDIDATE; NOT_ALL_SOURCE_GROUPS",
        ledger_scope="SOURCE_SLOT_PLAUSIBILITY_AND_REPORTED_CHECKS_NOT_FOCAL_TRUTH",
        semantic_instance_ids_inferred=False, original_local_decision_unchanged=True)
    try:
        left, right = case["query"].split(case["focal_marker"])
        if (reading != candidate["v6_reading"] or candidate["reading_id"] != reading["id"]
                or reading.get("left_quote") != left or reading.get("right_quote") != right):
            raise ValueError("Candidate/reading does not bind this exact masked query")
        occurrences = candidate["source_occurrences"]
        if not occurrences:
            raise ValueError("No candidate-owned source occurrences")
        for occurrence in occurrences:
            ref = occurrence["citation"]
            page = admitted[ref["canonical_page_id"]]
            a, b = ref["start"], ref["end"]
            lo, hi = occurrence["source_span"]
            if (type(a) is not int or type(b) is not int or type(lo) is not int or type(hi) is not int
                    or not 0 <= a <= lo < hi <= b <= len(page["text"])
                    or page["text"][a:b] != ref["text"]
                    or page["text"][lo:hi] != occurrence["source_wording"]
                    or any(ref[k] != page[p] for k, p in (("document_id", "document_id"),
                        ("date", "date"), ("page_sha256", "source_sha256")))):
                raise ValueError("Candidate citation or constituent lost its admitted literal binding")
        if not any(o["source_span"] == candidate["source_span"] and o["source_wording"] == candidate["source_wording"]
                and o["insertion_edits"] == candidate["insertion_edits"] and candidate["id"] == "next_fill_"+digest([
                    case["case_id"], reading["id"], candidate["fill"], candidate["node_id"],
                    o["citation"]["page_sha256"], o["source_span"]])[:28] for o in occurrences):
            raise ValueError("Candidate identity or insertion differs from its owned source occurrence")
        refs = list({digest(o["citation"]): o["citation"] for o in occurrences}.values())
        if {digest(r) for r in refs} != {digest(r) for r in candidate["sources"]}:
            raise ValueError("Candidate sources differ from owned occurrence citations")
        binding = dict(identity, source_binding_sha256=digest(occurrences),
            query_scope="exact_focal_contract_"+digest([case["query"], reading]))
        authorization = {k: binding[k] for k in ("case_id", "query_sha256", "source_binding_sha256")}
        citations = [dict(deepcopy(ref), source_authorized=True, authorization=deepcopy(authorization)) for ref in refs]
        decision = candidate["local_decision"]
        checks = []
        def delegated(name, row):
            checks.append((name, dict(state={"pass": "SATISFIED", "conflict": "VIOLATED"}.get(
                row.get("state"), "UNRESOLVED"), reason="EXISTING_CALLER_CHECK_NOT_RECOMPUTED",
                caller_check=deepcopy(row), candidate_context_citations_not_new_entailment=True)))
        for i, row in enumerate(decision.get("checklist", [])):
            delegated("local_check_"+str(i)+"_"+row["id"], row)
        requirements = decision.get("requirements", [])
        for i, requirement in enumerate(requirements):
            for j, row in enumerate(requirement.get("checks", [])):
                delegated("requirement_"+str(i)+"_check_"+str(j)+"_"+row["id"], row)
        positive = candidate["source_candidate_feasibility"]
        for i, row in enumerate(positive.get("criteria", [])):
            delegated("feasibility_"+str(i)+"_"+row["id"], row)
        delegated("joint_slot", candidate["joint_slot_fit"])
        checks.extend([
            ("source_authorization", dict(state="SATISFIED", reason="EXISTING_INSPECTED_SOURCE_POLICY_PLUS_LITERAL_REPLAY",
                policy_reexecuted_here=False, literal_occurrences_replayed_here=True)),
            ("semantic_instance_binding", dict(state="UNRESOLVED",
                reason="CALLER_HAS_NO_CERTIFIED_ACTOR_OWNER_EVENT_INSTANCE_ASSIGNMENT; NO_LABEL_IDENTITY_GUESS")),
            ("event_time", constraints.time_relation(constraints.Interval("unknown"), constraints.Interval("unknown"),
                quantifier="existential", scope=binding["query_scope"]))])
        # These are checks on the reported candidate, not resolved actor/event
        # certificates. Focal facts remain untranslated in the caller result.
        required = {"source_slot_clue": ("candidate",)}
        ledger = constraints.CandidateCase(binding, required, tuple(name for name, _ in checks))
        assignment = "reported_candidate_not_a_semantic_instance_join"
        ledger.branch(assignment, dict(candidate=candidate["id"], owner_instance=None, event_instance=None))
        ledger.record(assignment, "source_slot_clue", "FEASIBLE" if positive.get("positive_clue") else "NO_INFO",
            citations if positive.get("positive_clue") else [], bindings={"candidate": candidate["id"]},
            context=bool(positive.get("positive_clue")))
        for name, check in checks:
            ledger.constrain(assignment, name, check, citations, bindings={"candidate": candidate["id"]})
        result.update(status="COMPLETE_AUDIT_NOT_NEW_ADJUDICATION", binding=binding, ledger=ledger.snapshot(),
            reported_local_decision=deepcopy(decision), reported_reading=deepcopy(reading),
            reported_source_feasibility=deepcopy(positive),
            source_publication_dates=[dict(canonical_page_id=r["canonical_page_id"], date=r["date"]) for r in refs],
            publication_dates_used_as_event_intervals=False,
            factual_translation="No signed focal facts without certified instance bindings; original verdict retained separately",
            helper_constructor_integrated_means_solver_adoption=False)
    except (KeyError, TypeError, ValueError) as exc:
        result.update(status="AUDIT_UNAVAILABLE", error_type=type(exc).__name__, error=str(exc),
            incomplete_audit_is_not_a_changed_decision=True)
    return result


def _readings(case, plan):
    expected = digest(case["query"])
    if plan.get("query_sha256",expected) != expected:
        raise ValueError("Plan belongs to another query")
    packet = plan.get("readings_packet",plan.get("readings",plan.get("slot_readings",[])))
    if isinstance(packet,dict):
        if packet.get("query_sha256",expected) != expected:
            raise ValueError("Readings packet belongs to another query")
        if "version" in packet:
            from .readings import VERSION as READING_VERSION,validate_readings,constructor_view
            if packet["version"]!=READING_VERSION:
                raise ValueError("Readings packet is not the exact current bound version")
            validate_readings(packet,case)
            converted=[]
            for row in packet["readings"]:
                converted.append(constructor_view(row,case) if row["constructor_form"] is not None else
                    dict(id=row["id"],form="UNSUPPORTED_"+row["outer_family"]))
            packet=converted
        else:
            packet = packet.get("readings",[])
    if not isinstance(packet,list):
        raise ValueError("Explicit readings array required")
    left,right = case["query"].split(case["focal_marker"])
    values = []
    for i,row in enumerate(packet):
        form = row.get("constructor_form",row)
        if isinstance(form,str):
            form = dict(row,form=form)
        if not isinstance(form,dict):
            raise ValueError("constructor_form must be a reading dictionary or form string")
        if "form" in row and row["form"] != form.get("form"):
            raise ValueError("Conflicting reading/constructor forms")
        value = {k:deepcopy(form[k]) for k in ("id","form","role","target_kind","attachment_quote",
            "left_quote","right_quote","finite","grammatical_number") if k in form}
        value.setdefault("id",row.get("id","r"+str(i+1)))
        value.setdefault("role","unknown")
        value.setdefault("target_kind","any")
        value.setdefault("finite",None)
        value.setdefault("attachment_quote","")
        for k,wanted in (("left_quote",left),("right_quote",right)):
            if k in value and value[k] != wanted:
                raise ValueError("Reading boundary does not replay the exact query")
            value[k] = wanted
        quote = value["attachment_quote"]
        if quote and quote not in case["query"]:
            raise ValueError("Attachment quote is not literal query text")
        values.append(value)
    if len({r["id"] for r in values}) != len(values):
        raise ValueError("Reading IDs must be unique")
    return values


def _pages(case, retrieval, source_index=None):
    from .facts import SourcePolicy
    e = retrieval["eligible"]
    corpus = e.corpus
    supplied_index=source_index if source_index is not None else retrieval.get("source_index")
    policy=SourcePolicy(corpus,case,supplied_index) if supplied_index is not None else retrieval.get("source_policy")
    if policy is None:
        policy=SourcePolicy(corpus,case)
    if policy.corpus is not corpus or policy.case!=case:
        raise ValueError("Source policy belongs to another corpus or query")
    admitted = retrieval["pages"]
    if len(admitted) != len(set(admitted)) or any(type(i) is not int or not 0 <= i < len(corpus.pages) for i in admitted):
        raise ValueError("Admitted page indices must be unique and in range")
    ids=retrieval.get("inspected_page_ids")
    budget=retrieval.get("passage_budget",len(ids) if isinstance(ids,list) else None)
    if type(budget) is not int or budget<1:
        raise ValueError("Explicit positive passage_budget or inspected_page_ids required")
    if ids is not None:
        if not isinstance(ids,list) or len(ids)!=len(set(ids)) or len(ids)>budget:
            raise ValueError("Inspected IDs exceed or duplicate the explicit source budget")
        by_id={corpus.pages[i]["id"]:i for i in admitted}
        if any(pid not in by_id for pid in ids):
            raise ValueError("Inspected IDs must belong to admitted pages")
        inspected=[by_id[pid] for pid in ids]
    else:
        inspected=admitted[:budget]
    veto = {p["document_id"] for p in corpus.pages if case["corpus"] != "cib" and (
        re.search(r"\bNOFORN\b|NO\s+FOREIGN\s+DISSEMINATION",p["text"],re.I)
        or any(re.search(r"\bNOFORN\b|NO\s+FOREIGN\s+DISSEMINATION",str(h),re.I) for h in p.get("handling",[])))}
    values = []
    for i in inspected:
        p = corpus.pages[i]
        if not bool(e.page_mask[i]) or not policy.allowed(i) or p["document_id"] in veto or p.get("visibility") not in {None,"earlier","both"}:
            raise ValueError("Admitted source violates the eligible mask or whole-document handling veto")
        _checked_page(p,case)
        bound=policy.bound_pages.get(p["id"])
        if bound is None or any(bound.get(k)!=p.get(k) for k in ("text","document_id","date","source_sha256","classification","permitted","visibility","corpus")):
            raise ValueError("Inspected corpus page differs from the explicit source index")
        values.append((i,p))
    uninspected=[corpus.pages[i]["id"] for i in admitted if i not in set(inspected)]
    return corpus,values,policy,dict(passage_budget=budget,admitted_page_count=len(admitted),
        inspected_page_count=len(values),uninspected_page_ids=uninspected,
        public_source_policy_citations=True,explicit_source_index_supplied=supplied_index is not None,
        selection="EXPLICIT_INSPECTED_IDS" if ids is not None else "ADMITTED_PREFIX_WITH_EXPLICIT_PASSAGE_BUDGET")


def _facts(corpus, pi, page, part):
    values = []
    a,b = part.start_char,part.end_char
    for j in corpus.occurrences_by_page.get(pi,[]):
        row = corpus.occurrences[j]
        if row.get("source_type") != "entities" or row.get("page_index") != pi:
            continue
        ra,rb,label = row.get("start"),row.get("end"),row.get("label","")
        if not isinstance(label,str) or not label or type(ra) is not int or type(rb) is not int or not 0 <= ra < rb <= len(page["text"]):
            continue
        # Preserve the exact intersection stream; layout uniqueness must be
        # decided over the full owning occurrence, never a convenient NP slice.
        exact = list(re.finditer(r"(?<!\w)"+re.escape(label)+r"(?!\w)",
            page["text"][max(a,ra):min(b,rb)],re.I))
        bound = [dict(start=max(a,ra)+m.start(), end=max(a,ra)+m.end()) for m in exact]
        if not exact:
            bound = [m for m in source_label_spans(page["text"], ra, rb, label)
                if m["mode"] == "UNIQUE_WHITESPACE_ONLY_LAYOUT" and a <= m["start"] < m["end"] <= b]
        for m in bound:
            lo,hi = m["start"],m["end"]
            if lo <= part.root.idx < hi and row.get("node_id") in corpus.nodes:
                values.append(dict(node_id=row["node_id"],source_entity_type=row.get("entity_type"),
                    start=lo,end=hi,label=page["text"][lo:hi],canonical_page_id=page["id"],page_sha256=page["source_sha256"]))
    return values


def _terms(text):
    return set(words(text))-set(ENGLISH_STOP_WORDS)


def _owner_constraints(head, excluded=None):
    values=[]
    for child in head.children:
        if child.dep_ not in {"amod","compound","nummod","poss","prep"}:
            continue
        tokens=[t for t in child.subtree if not t.is_space and not t.is_punct
            and not (excluded is not None and excluded.start_char<=t.idx<excluded.end_char)]
        if tokens:
            values.append((child.dep_,tuple(t.lemma_.casefold() for t in tokens)))
    return sorted(values)


def _owner_compatibility(source, query):
    conflicts=[];unresolved=[]
    for kind in sorted({k for k,_ in source+query}):
        found={tuple(words) for k,words in source if k==kind}
        wanted={tuple(words) for k,words in query if k==kind}
        if found and wanted and not (found<=wanted or wanted<=found):
            conflicts.append(dict(kind=kind,source=sorted(found),query=sorted(wanted)))
        elif wanted and not found:
            unresolved.append(dict(kind=kind,query=sorted(wanted)))
    return dict(compatible=not conflicts,conflicts=conflicts,unresolved_query_discriminators=unresolved,
        owner_identity_certified=False,missing_is_counterevidence=False)


def _clause_constraints(predicate, excluded=None):
    arguments=[]
    for child in predicate.children:
        if child.dep_ in {"nsubj","nsubjpass","dobj","obj","iobj","dative","attr","acomp","prep","agent","prt"}:
            tokens=tuple(t.lemma_.casefold() for t in child.subtree if not t.is_space and not t.is_punct and t.pos_!="DET"
                and not (excluded is not None and excluded.start_char<=t.idx<excluded.end_char))
            if not tokens:
                continue
            arguments.append((child.dep_,tokens))
    scope=[]
    for token in (predicate,*predicate.ancestors):
        operators=tuple(sorted((c.dep_,c.lemma_.casefold()) for c in token.children
            if c.dep_ in {"neg","mark","aux","auxpass","advmod"}))
        scope.append((token.lemma_.casefold(),str(token.morph),operators))
        if token.dep_=="ROOT":
            break
    return dict(arguments=sorted(arguments),scope=scope)


def _argument_binding(head):
    """Keep grammatical argument roles; no actor/patient or voice conversion."""
    while head.dep_ in {"compound","flat","flat:name","appos"} and head.head.pos_ in {"NOUN","PROPN"}:
        head=head.head
    if head.dep_ in {"nsubj","nsubjpass","dobj","obj","iobj","dative","attr","oprd"} and head.head.pos_ in {"VERB","AUX"}:
        return head.head,(head.dep_,)
    if head.dep_=="pobj" and head.head.pos_=="ADP" and head.head.head.pos_ in {"VERB","AUX"}:
        return head.head.head,("prep",head.head.lemma_.casefold(),"pobj")
    return None,None


def _person_cue(case, reading, doc):
    if reading["role"]!="possessor":
        return None
    left,right=case["query"].split(case["focal_marker"])
    quote=reading["attachment_quote"]
    match=re.match(r"\s*"+re.escape(quote)+r"\s*[;,]\s*(he|she)\b",right,re.I) if quote else None
    if match is None:
        return None
    before=left+" "*len(case["focal_marker"])+right[:match.start(1)]
    if (any(e.label_=="PERSON" and e.start_char<len(before) for e in doc.ents)
            or any(t.pos_=="PROPN" and t.dep_ in {"nsubj","nsubjpass"} and t.idx<len(before) for t in doc)):
        return None
    a=len(left)+len(case["focal_marker"])+match.start(1)
    return dict(start=a,end=a+len(match[1]),text=match[1],kind="ADJACENT_SINGULAR_PERSONAL_ANAPHOR",
        coreference_or_identity_certified=False)


@lru_cache(maxsize=10000)
def _role_match(query_words, source_words):
    try:
        return roles.compare(set(query_words),set(source_words))
    except (LookupError,OSError):
        return dict(matched=False,resource_unavailable=True)


def _owned_role_context(part, query_words):
    """Only own NP/title and direct apposition, never a nearby actor's role."""
    if any(t.dep_=="neg" for t in part.root.children):
        return dict(matched=False,supports_missing_action=False,absence_is_counterevidence=False)
    spans=[(part,"EXACT_SOURCE_NP")]
    for child in part.root.children:
        if child.dep_!="appos" or child in part:
            continue
        tokens=list(child.subtree)
        if any(t.pos_ in {"VERB","AUX"} or t.dep_ in {"neg","relcl","ccomp","advcl"} for t in tokens):
            continue
        spans.append((part.doc[min(t.i for t in tokens):max(t.i for t in tokens)+1],"DIRECT_APPOSITION"))
    governor=part.root.head
    if (part.root.dep_ in {"attr","nsubj"} and governor.lemma_.casefold()=="be"
            and not any(c.dep_=="neg" for c in governor.children)):
        other="nsubj" if part.root.dep_=="attr" else "attr"
        for child in governor.children:
            if child.dep_!=other or child in part or child.pos_ not in {"NOUN","PROPN"}:
                continue
            tokens=list(child.subtree)
            spans.append((part.doc[min(t.i for t in tokens):max(t.i for t in tokens)+1],"COPULAR_NOMINAL_DESCRIPTOR"))
    for span,ownership in spans:
        if any(t.dep_=="neg" or t.dep_=="det" and t.lemma_.casefold()=="no" for t in span):
            continue
        # A descriptor can contain another named person's possessions or a
        # separately acting subject. Their properties do not belong to this NP.
        def owned(token):
            for node in (token,*token.ancestors):
                if node not in span:
                    break
                if any(c.dep_=="poss" and c.pos_ in {"NOUN","PROPN"} and c not in part for c in node.children):
                    return False
                if node.pos_ in {"VERB","AUX"} and any(c.dep_ in {"nsubj","nsubjpass"}
                        and c.pos_ in {"NOUN","PROPN"} and c not in part for c in node.children):
                    return False
            return True
        words=roles.common_words(t for t in span if owned(t))
        if not words:
            continue
        match=_role_match(tuple(sorted(query_words)),tuple(sorted(words)))
        if match.get("matched"):
            return dict(deepcopy(match),source_role_span=[span.start_char,span.end_char],source_role_quote=span.text,
                ownership=ownership,supports_missing_action=False,
                factual_support_certified=False,absence_is_counterevidence=False)
    return dict(matched=False,supports_missing_action=False,absence_is_counterevidence=False)


def _actor_predicate(head):
    seen=set()
    while head.i not in seen:
        seen.add(head.i)
        if head.dep_=="nsubj" and head.head.pos_ in {"VERB","AUX"}:
            return head.head
        if head.dep_ not in {"compound","flat","flat:name","appos","conj"} or head.head.pos_ not in {"NOUN","PROPN"}:
            return None
        head=head.head
    return None


def _unqualified_property_attachment(part):
    for token in (part.root,*part.root.ancestors):
        if token.dep_ in {"ccomp","advcl"}:
            return False
        if any(c.dep_=="mark" and c.lemma_.casefold() in {"if","unless","whether"}
                or c.tag_=="MD" and c.lemma_.casefold()!="can" for c in token.children):
            return False
    return True


def _boundary_frame_cue(part, q, parse):
    """A complete adjacent source anchor must own both subject and governor."""
    anchor=q["adjacent_frame_anchor"]
    if not anchor:
        return dict(matched=False,reason="NO_COMPLETE_ADJACENT_QUERY_FRAME")
    prefix=part.doc.text[part.root.sent.start_char:part.start_char]
    match=re.search(r"(?<!\w)"+r"\s+".join(re.escape(w) for w in anchor.split())+r"\s*$",prefix,re.I)
    if match is None:
        return dict(matched=False,reason="SOURCE_BOUNDARY_DOES_NOT_REPLAY_QUERY_FRAME")
    view=part.doc
    normalization="ORIGINAL_SOURCE"
    if part.doc.text.isupper() and len(part.doc.text.lower())==len(part.doc.text):
        view=parse(part.doc.text.lower());normalization="LOWERCASE_SAME_RAW_OFFSETS"
    source=view.char_span(part.start_char,part.end_char,alignment_mode="strict")
    a=part.root.sent.start_char+match.start();b=part.start_char
    if source is None:
        return dict(matched=False,reason="SOURCE_FRAME_TOKEN_BOUNDARY_UNRESOLVED")
    head=source.root.head
    subjects=[t for t in head.children if t.dep_ in {"nsubj","nsubjpass"} and t.pos_ in {"NOUN","PROPN"}]
    owned=(head not in source and head.pos_ in {"VERB","AUX"} and a<=head.idx<b
        and len(subjects)==1 and a<=subjects[0].idx<b
        and source.root.dep_ in {"acomp","oprd","advmod","xcomp","dobj","obj"}
        and all(a<=t.idx<b for t in subjects[0].subtree if not t.is_punct and not t.is_space))
    if not owned:
        return dict(matched=False,reason="ANCHOR_DOES_NOT_BIND_SOURCE_SUBJECT_AND_GOVERNOR")
    return dict(matched=True,source_anchor_span=[a,b],source_anchor_quote=part.doc.text[a:b],query_anchor=anchor,
        predicate=head.lemma_.casefold(),subject=subjects[0].lemma_.casefold(),argument_role=source.root.dep_,
        normalization=normalization,factual_support_certified=False,operators_retained_in_raw_quote=True)


def _query_features(case, reading, parse):
    at = case["query"].index(case["focal_marker"])
    text = MASK.sub(lambda m:"thing"+" "*(len(m.group())-5) if m.group()==case["focal_marker"] else " "*len(m.group()),case["query"])
    doc = parse(text)
    slot = next((t for t in doc if t.idx==at and t.text.casefold()=="thing"),None)
    focal = slot.sent.text if slot is not None else text
    quote = reading["attachment_quote"]
    attachment = parse(quote) if quote else None
    carrier = attachment[:].root.lemma_.casefold() if attachment is not None and len(attachment) else None
    predicates = set()
    required_predicate,required_role=_argument_binding(slot) if slot is not None else (None,None)
    visible_people=[set(t.lemma_.casefold() for t in e if t.pos_=="PROPN") for e in doc.ents if e.label_=="PERSON"]
    visible_people=[v for v in visible_people if v]
    if slot is not None:
        for token in slot.subtree:
            if token.dep_ in {"relcl","acl","xcomp"} and token.pos_ == "VERB":
                predicates.add(token.lemma_.casefold())
        if slot.dep_ in {"nsubj","nsubjpass","dobj","obj"}:
            predicates.add(slot.head.lemma_.casefold())
    cue=_person_cue(case,reading,doc)
    left=case["query"].split(case["focal_marker"])[0]
    adjacent=quote if quote and " ".join(left.casefold().split()).endswith(" ".join(quote.casefold().split())) else None
    slot_role_words=roles.common_words(attachment) if attachment is not None and reading["form"]=="member_example" else None
    member_class=None
    if (reading["form"]=="member_example" and attachment is not None and len(attachment)
            and attachment[:].root.pos_=="NOUN" and not attachment[:].root.ent_type_):
        head=attachment[:].root;lookup=parse.noun_resource.lookup(head.lemma_)
        possible=[kind for kind in ("person","organization","place") if lookup["status"]=="SENSES_AVAILABLE"
            and all(s["possible_kinds"].get(kind,False) for s in lookup["senses"])]
        if len(possible)==1:
            member_class=dict(kind=possible[0],head=head.text,lemma=head.lemma_.casefold(),literal_attachment=quote,
                basis="ALL_ORDINARY_SENSES_OF_VISIBLE_MEMBER_CLASS",resource=deepcopy(parse.noun_resource.resource),
                senses=[s["synset"] for s in lookup["senses"]],bound_reading_modified=False,
                source_identity_or_factual_action_certified=False)
    effective=reading["target_kind"]
    if effective=="any":
        effective="person" if cue is not None else member_class["kind"] if member_class else "any"
    return dict(carrier=carrier,owner_constraints=_owner_constraints(attachment[:].root) if attachment is not None and len(attachment) else None,
        attachment_terms=_terms(quote),focal_terms=_terms(focal)-{"thing"},predicates=predicates,
        whole_query_terms=_terms(MASK.sub(" ",case["query"])),
        role_words=roles.common_words(t for t in doc if not at<=t.idx<at+len(case["focal_marker"])),person_cue=cue,
        slot_role_words=slot_role_words,adjacent_frame_anchor=adjacent,
        member_class_constraint=member_class,effective_target_kind=effective,
        required_argument_role=required_role,
        required_predicate=required_predicate.lemma_.casefold() if required_predicate is not None else None,
        required_clause=_clause_constraints(required_predicate,doc[slot.i:slot.i+1]) if required_predicate is not None else None,
        visible_people=visible_people)


def _source_features(part, raw, facts, reading, q, page, pi, retrieval, parser):
    kinds = {TYPE_MAP[f["source_entity_type"]] for f in facts if f["source_entity_type"] in TYPE_MAP}
    ner = {"PERSON":"person","ORG":"organization","GPE":"place","LOC":"place","FAC":"place"}.get(part.root.ent_type_)
    if not kinds and ner:
        kinds.add(ner)
    target = q["effective_target_kind"]
    role_type=dict(eligible=target in kinds and target in {"person","organization"},basis="OWN_SOURCE_ENTITY_KIND_OR_NER",
        identity_or_factual_action_certified=False)
    if not role_type["eligible"] and target in {"person","organization"}:
        if target=="person" and part.root.dep_=="appos" and part.root.head not in part and part.root.head.ent_type_=="PERSON":
            role_type.update(eligible=True,basis="EXPLICIT_APPOSITION_TO_SOURCE_PERSON",head=part.root.head.text)
        elif part.root.pos_=="NOUN" and not part.root.ent_type_:
            lookup=parser.noun_resource.lookup(part.root.lemma_)
            unambiguous=lookup["status"]=="SENSES_AVAILABLE" and all(s["possible_kinds"].get(target,False) for s in lookup["senses"])
            role_type.update(eligible=unambiguous,basis="ALL_ORDINARY_HEAD_SENSES_COMPATIBLE" if unambiguous else "AMBIGUOUS_OR_UNKNOWN_HEAD_IS_NOT_A_POSITIVE_TYPE_CLUE")
    if len(kinds)==1 and target in {"person","organization","place"} and target not in kinds:
        return None,"EXPLICIT_SOURCE_TYPE_MISMATCH"
    if target=="person":
        fit=dict(known_kind=next(iter(kinds)) if len(kinds)==1 else None,source_kind_conflict=len(kinds)>1)
        guard=person_guard(part,dict(reading,target_kind=target),fit,parser.noun_resource)
        if not guard["admissible"]:
            return None,guard["reason"]
        singular=q["person_cue"] is not None or reading.get("grammatical_number")=="singular"
        if singular and (any(t.dep_ in {"cc","conj"} and t.head in part for t in part)
                or "Plur" in part.root.morph.get("Number")):
            return None,"PLURAL_OR_COORDINATED_SOURCE_NOT_SINGULAR_PERSON"
        if (part.root.dep_=="conj" and part.root.head not in part
                and part.root.head.ent_type_ in {"GPE","LOC","FAC","ORG"} and "person" not in kinds):
            return None,"UNBOUND_SOURCE_CONJUNCT_IS_NOT_A_COMPLETE_PERSON_LABEL"
    carrier = _nominal_carrier(part)
    own = carrier.lemma_.casefold() if carrier is not None else None
    own_text = carrier.sent.text if carrier is not None else part.root.sent.text
    predicate=_actor_predicate(part.root)
    actor_predicate=predicate is not None and predicate.lemma_.casefold() in q["predicates"]
    type_match = target in kinds or target=="property" and raw["kind"]=="modifier" or target=="quantity" and raw["kind"]=="quantity"
    owned_relation=(carrier is not None and own==q["carrier"] and q["owner_constraints"] is not None
        and _owner_constraints(carrier,part)==q["owner_constraints"] and raw["kind"] in {"modifier","quantity"}
        and _unqualified_property_attachment(part))
    owner_compatibility=_owner_compatibility(_owner_constraints(carrier,part),q["owner_constraints"] or []) if carrier is not None else None
    property_compatible=(carrier is not None and own==q["carrier"] and q["owner_constraints"] is not None
        and owner_compatibility["compatible"] and raw["kind"] in {"modifier","quantity"} and _unqualified_property_attachment(part))
    argument_predicate,argument_role=_argument_binding(part.root)
    clause=_clause_constraints(argument_predicate,part) if argument_predicate is not None else None
    direct_argument_relation=(argument_predicate is not None and argument_predicate.lemma_.casefold()==q["required_predicate"]
        and argument_role==q["required_argument_role"] and q["required_clause"] is not None and clause==q["required_clause"])
    source_names={t.lemma_.casefold() for t in part if t.pos_=="PROPN"}
    visible_overlap=any(v<=source_names for v in q["visible_people"])
    attachment = len(q["attachment_terms"] & _terms(own_text))
    coverage = len(q["focal_terms"] & _terms(part.root.sent.text))
    role_words=q["slot_role_words"] if q["slot_role_words"] is not None else q["role_words"]
    role_context=_owned_role_context(part,role_words) if target in {"person","organization"} else dict(matched=False)
    role_context["query_basis"]="LITERAL_MEMBER_CLASS_ATTACHMENT" if q["slot_role_words"] is not None else "VISIBLE_QUERY_ROLE_CONTEXT_WITH_EXPLICIT_ENTITY_KIND"
    boundary_cue=_boundary_frame_cue(part,q,parser)
    feature = dict(source_type_match=bool(type_match),source_owned_relation_match=bool(owned_relation or direct_argument_relation),
        owned_carrier_match=bool(q["carrier"] and own==q["carrier"]),
        focal_actor_predicate_match=bool(actor_predicate),literal_attachment_coverage=attachment,
        focal_argument_predicate_match=bool(argument_predicate is not None and argument_predicate.lemma_.casefold()==q["required_predicate"]
            and argument_role==q["required_argument_role"]),
        direct_actor_relation_match=bool(direct_argument_relation and argument_role==("nsubj",)),
        direct_argument_relation_match=bool(direct_argument_relation),source_argument_role=argument_role,
        query_argument_role=q["required_argument_role"],source_clause_constraints=clause,
        query_clause_constraints=q["required_clause"],visible_name_overlap_penalty=visible_overlap,
        visible_name_overlap_is_identity_or_counterevidence=False,
        focal_context_coverage=coverage,source_carrier=own,query_carrier=q["carrier"],
        whole_query_context_coverage=len(q["whole_query_terms"] & _terms(part.root.sent.text)),
        source_owned_role_context=role_context,person_compatibility_cue=q["person_cue"],effective_target_kind=target,
        visible_member_class_constraint=q["member_class_constraint"],
        source_role_type_license=role_type,
        source_owned_property_match=bool(property_compatible),source_owner_compatibility=owner_compatibility,source_boundary_frame_cue=boundary_cue,
        source_carrier_pos=carrier.pos_ if carrier is not None else None,
        source_carrier_precedes_property=carrier.idx<part.start_char if carrier is not None else None,
        source_type_witnesses=facts,source_ner=part.root.ent_type_,
        retrieval_page_score=float(retrieval.get("page_scores",{}).get(pi,0)),
        retrieval_page_rank=retrieval.get("page_ranks",{}).get(pi,10**12),
        owned_relation_scope="Literal property/quantity attachment and owner discriminators only; not event or identity proof",
        source_owner_constraints=_owner_constraints(carrier,part) if carrier is not None else None,
        query_owner_constraints=q["owner_constraints"],
        relevance_is_factual_support=False,missing_alignment_is_counterevidence=False)
    return feature,None


def _key(feature, page, span, reading_id, fill):
    return (not _positive_feasibility(feature)["positive_clue"],not feature["source_owned_relation_match"],not feature["source_type_match"],not feature["owned_carrier_match"],
        not feature["focal_argument_predicate_match"],feature["visible_name_overlap_penalty"],
        not feature["source_owned_role_context"].get("matched",False),-feature["whole_query_context_coverage"],-feature["literal_attachment_coverage"],
        -feature["focal_context_coverage"],-feature["retrieval_page_score"],feature["retrieval_page_rank"],
        page["id"],tuple(span),reading_id,fill)


def _positive_feasibility(feature):
    """A source-owned slot clue, not proof of the completed missing assertion."""
    definitions=[
        ("owner_property","Attested property of a compatible carrier; unresolved owner details are not certified",feature.get("source_owned_property_match",False)),
        ("argument_relation","Same scoped predicate, argument role and other visible participants",feature.get("direct_argument_relation_match",False)),
        ("owned_role","Own nominal/appositional/copular role matches the typed slot class or role context",
            feature.get("source_role_type_license",{}).get("eligible",False) and feature.get("source_owned_role_context",{}).get("matched",False)),
        ("local_frame","Literal adjacent source frame binds both owner and governor",feature.get("source_boundary_frame_cue",{}).get("matched",False)),
    ]
    positive=any(value for _,_,value in definitions)
    return dict(version=FEASIBILITY_VERSION,status="POSITIVE_SOURCE_CLUE" if positive else "NO_INFO",positive_clue=positive,
        criteria=[dict(id=identity,label=label,state="pass" if value else "no_info") for identity,label,value in definitions],
        rule="At least one complete criterion in this single source occurrence, then bounded completed-slot and factual/counter gates",
        generic_lexical_overlap_suffices=False,source_type_alone_suffices=False,old_grammar_alone_suffices=False,
        factual_support_certified=False,absence_is_counterevidence=False)


def _wording(case, reading, raw, part):
    form = reading["form"]
    kind = raw["kind"]
    if form in {"nominal","possessive","member_example"} and kind != "nominal":
        return None,"SOURCE_FORM_MISMATCH"
    if form == "quantity" and kind != "quantity":
        return None,"SOURCE_FORM_MISMATCH"
    if form == "modifier" and kind != "modifier":
        return None,"SOURCE_FORM_MISMATCH"
    fill,edits = raw["text"],[]
    if form in {"nominal","possessive","member_example"}:
        a,b=part.start_char,part.end_char;text=part.doc.text
        if (a>=2 and text[a-1]=="-" and text[a-2].isalnum()
                or b+1<len(text) and text[b]=="-" and text[b+1].isalnum()):
            return None,"SOURCE_NOMINAL_CLIPS_HYPHENATED_WORD"
        if part.root.pos_ not in {"NOUN","PROPN"} or any(t.dep_ in {"ccomp","advcl","relcl"}
                or t.pos_ in {"VERB","AUX"} and (t.tag_ in {"VBD","VBP","VBZ","MD"} or "Fin" in t.morph.get("VerbForm")) for t in part):
            return None,"SOURCE_NOMINAL_CONTAINS_CLAUSE_OR_NONNOMINAL_HEAD"
        if part.root.dep_ in {"compound","flat","flat:name"} and part.root.head not in part:
            return None,"SOURCE_NOMINAL_HEAD_IS_CLIPPED_DEPENDENT"
    if form == "modifier":
        carrier=_nominal_carrier(part)
        if any(c.dep_=="neg" and c not in part for token in (part.root,carrier) if token is not None for c in token.children):
            return None,"SOURCE_NEGATION_OUTSIDE_MODIFIER_SPAN"
        if raw.get("clausal_complement"):
            return None,"INCOMPLETE_SOURCE_VERBAL_COMPLEMENT"
        supplied=raw.get("edited",fill)
        tokens=[t for t in part if not t.is_space]
        without=[t for t in tokens if not(t.pos_=="AUX" and t.lemma_=="be" and t.dep_ in {"aux","auxpass"} and t.head==part.root)]
        if " ".join(supplied.split())!=" ".join(fill.split()) and " ".join(supplied.split())==" ".join(t.text for t in without):
            edits.append(dict(kind="SOURCE_PASSIVE_AUXILIARY_NOT_COPIED_INTO_PRENOMINAL_PROPERTY",before=fill,after=supplied,
                source_modified=False,source_scope_operators_retained_in_quote=True,factual_support_certified=False))
            fill=supplied
        fill,changed = modifier_wording(fill,part)
        edits.extend(changed)
    if form == "possessive" and not re.search(r"(?:['\u2019]s|s['\u2019])$",fill):
        plural_s="Plur" in part.root.morph.get("Number") and fill.casefold().endswith("s")
        changed=fill+("'" if plural_s else "'s")
        edits.append(dict(kind="POSSESSIVE_MARKER_ADDED",before=fill,after=changed,source_modified=False))
        fill=changed
    if form == "member_example":
        changed="like "+fill
        edits.append(dict(kind="EXAMPLE_CONNECTOR_ADDED",before=fill,after=changed,source_modified=False))
        fill=changed
    fitted=boundary_fit(case,fill)
    if not fitted["admissible"]:
        return None,fitted.get("reason","VISIBLE_BOUNDARY_ALREADY_PRESENT")
    return (fitted["fill"],edits+fitted["edits"]),None


def _property_scope_binding(doc, part):
    """Literal owned scope, not a common-head identity or a time classifier."""
    owner=_nominal_carrier(part)
    if owner is None:
        return None
    def kept(token):
        return not token.is_space and not token.is_punct and not part.start_char<=token.idx<part.end_char
    def signature(tokens):
        return tuple((t.lemma_.casefold(),"OWNER" if t==owner else t.dep_,str(t.morph)) for t in tokens if kept(t)
            and not (t.dep_=="det" and t.lemma_.casefold() in {"a","an","the"}))
    owner_tokens=list(owner.subtree)
    named_owner=owner.pos_=="PROPN"
    predicate,role=_argument_binding(owner)
    if predicate is None:
        return dict(head=owner.lemma_.casefold(),owner=signature(owner_tokens),named_owner=named_owner,
            event=None,adjunct_scope=None)
    # Preserve explicit scope adjuncts literally; do not turn publication dates,
    # numeric overlap or recurring-time words into an event interval certificate.
    adjuncts=[]
    for child in predicate.children:
        if child==owner:
            continue
        tokens=list(child.subtree)
        if child.dep_=="npadvmod" or child.dep_=="prep" and any(t.ent_type_ in {"DATE","TIME"} for t in tokens):
            adjuncts.append(signature(tokens))
    participants=[c for c in predicate.children if c.dep_ in {"nsubj","nsubjpass","dobj","obj","iobj","dative"}
        and c!=owner]
    bound_participants=bool(participants) and all(not any(t.pos_=="PRON" for t in c.subtree)
        and any(t.pos_=="PROPN" for t in c.subtree) for c in participants)
    event=dict(predicate=predicate.lemma_.casefold(),role=role,clause=signature(predicate.subtree),
        ancestors=_clause_constraints(predicate,part)["scope"],participants_bound=bound_participants)
    return dict(head=owner.lemma_.casefold(),owner=signature(owner_tokens),named_owner=named_owner,
        event=event,adjunct_scope=adjuncts)


def _property_witness_scope(case, candidate, requirement, witness, pages, parse):
    left,right=case["query"].split(case["focal_marker"])
    completed=left+candidate["fill"]+right
    def analysis(text):
        lower=text.lower()
        return parse(lower if text.isupper() and len(lower)==len(text) else text)
    query=analysis(completed)
    part=query.char_span(len(left),len(left)+len(candidate["fill"]),alignment_mode="strict")
    wanted=_property_scope_binding(query,part) if part is not None else None
    if wanted is None:
        return dict(state="missing",reason="QUERY_PROPERTY_OWNER_SCOPE_UNRESOLVED")
    attempts=[]
    for ref in witness.get("citations",[]):
        page=pages.get(ref.get("canonical_page_id"))
        a,b=ref.get("start"),ref.get("end")
        if (page is None or type(a) is not int or type(b) is not int or not 0<=a<b<=len(page["text"])
                or page["text"][a:b]!=ref.get("text") or page["source_sha256"]!=ref.get("page_sha256")
                or page["document_id"]!=ref.get("document_id") or page["date"]!=ref.get("date")):
            attempts.append(dict(state="missing",reason="PROPERTY_WITNESS_NOT_BOUND_TO_ADMITTED_RAW_PAGE"))
            continue
        source=analysis(ref["text"])
        for token in source:
            if token.dep_!="amod" or token.lemma_.casefold()!=requirement.get("predicate"):
                continue
            offered=_property_scope_binding(source,source[token.i:token.i+1])
            exact=offered is not None and wanted["head"]==offered["head"] and wanted["owner"]==offered["owner"]
            named=bool(exact and wanted["named_owner"] and offered["named_owner"]
                and wanted["adjunct_scope"]==offered["adjunct_scope"])
            event=bool(exact and wanted["event"] is not None and wanted["event"]["participants_bound"]
                and wanted["event"]==offered["event"] and wanted["adjunct_scope"]==offered["adjunct_scope"])
            attempt=dict(state="pass" if named or event else "missing",
                reason="BOUNDED_LITERAL_NAMED_OWNER_SCOPE" if named else "SAME_SCOPED_GOVERNOR_AND_BOUND_PARTICIPANTS" if event
                    else "COMMON_OWNER_HEAD_DOES_NOT_ESTABLISH_SAME_INSTANCE_OR_EVENT_SCOPE",
                query_binding=wanted,source_binding=offered,citation=deepcopy(ref),
                source_property_span=[a+token.idx,a+token.idx+len(token)],
                property_only=True,surrounding_action_certified=False,absence_is_counterevidence=False)
            attempt.update(canonical_cross_document_identity_certified=False,homonyms_or_aliases_resolved=False)
            attempts.append(attempt)
            if named or event:
                return dict(attempt,attempts=attempts)
    return dict(state="missing",reason="NO_AUTHORIZED_SAME_OWNER_INSTANCE_OR_COMPATIBLE_EVENT_SCOPE",attempts=attempts,
        absence_is_counterevidence=False)


def _property_scope_guard(case, reading, candidate, decision, pages, parse=None):
    """Recheck only borrowed definite-NP backing; never create signed evidence."""
    if decision.get("status")!="evidence_backed_suggestion" or not any(
            e.get("adapter")=="EXPLICIT_DEFINITE_NP_PROPERTY/6.5" and e.get("direction")=="Support"
            for u in decision.get("requirements",[]) for e in u.get("evidence",[])):
        return decision
    parse=parse or SourceParses()
    result=deepcopy(decision); reviews=[];blocked=False
    for unit in result.get("requirements",[]):
        if unit.get("kind")!="PROPERTY":
            continue
        retained=[];held=[]
        for witness in unit.get("evidence",[]):
            if witness.get("adapter")!="EXPLICIT_DEFINITE_NP_PROPERTY/6.5" or witness.get("direction")!="Support":
                retained.append(witness)
                continue
            proof=_property_witness_scope(case,candidate,unit,witness,pages,parse)
            reviews.append(dict(requirement_id=unit["id"],proof=proof,original_witness=deepcopy(witness)))
            (retained if proof["state"]=="pass" else held).append(witness)
        unit["evidence"]=retained
        if held and not any(e.get("direction")=="Support" for e in retained):
            blocked=True
            unit.update(coverage="Missing",direction="Unresolved")
            refs=unit.setdefault("context_citations",[])
            for witness in held:
                for ref in witness.get("citations",[]):
                    if ref not in refs:
                        refs.append(deepcopy(ref))
            for check in unit.get("checks",[]):
                if check["id"]=="actor":
                    check.update(state="missing",detail="The property is source-attested, but this query owner's instance/event scope is not established.")
            unit.setdefault("checks",[]).append(dict(id="owner_instance_scope",label="Same property-owner instance / scoped event",
                state="missing",detail="Common carrier heads and definite articles alone do not identify the recurring period, actor, unit or event."))
    result["property_scope_guard"]=dict(version=PROPERTY_SCOPE_VERSION,reviews=reviews,blocked_backing=blocked,
        original_decision=deepcopy(decision),no_new_support_or_counterevidence=True,
        event_intervals_inferred=False,source_publication_dates_used_as_event_time=False,
        named_owner_scope="BOUNDED_LITERAL_OWNED_SCOPE_NOT_CANONICAL_CROSS_DOCUMENT_IDENTITY",
        canonical_cross_document_identity_certified=False,homonyms_or_aliases_resolved=False)
    if blocked:
        supported=any(u.get("coverage")=="Established" and u.get("direction")=="Support" for u in result["requirements"])
        result.update(status="partial_grounding" if supported else "exploratory_contextual",
            label="Partial grounding" if supported else "Exploratory / contextual",coverage="Partial" if supported else "Missing",
            support_present=supported)
        for check in result.get("checklist",[]):
            if check["id"]=="facts":
                check.update(state="missing",detail="Source-attested property does not bind the query's owner instance or event scope.")
        result["checklist"].append(dict(id="owner_instance_scope",label="Same property-owner instance / scoped event",
            state="missing",detail="Literal owner scope or compatible governor, participants and event scope remains unestablished; not counterevidence."))
        result["what_would_suffice"]=["An eligible source must bind the property to the same owner instance, or preserve its governor, bound participants and event scope; common-head wording alone is context."]
    return result


def _gate(case, plan, reading, candidate, pages, parse=None):
    sanitized = dict(case=case,config="next_source_first",plan=dict(query_sha256=digest(case["query"]),
        atoms=deepcopy(plan.get("atoms",[]))),result=dict(readings=[dict(reading=reading,candidates=[candidate])]))
    packet = evidence_gate.derive(sanitized,case,pages)
    return _property_scope_guard(case,reading,candidate,packet["candidates"][candidate["id"]],pages,parse)


def _route_issue(case, reading):
    left,right=case["query"].split(case["focal_marker"])
    if (reading["role"]=="possessor" and reading["form"]=="nominal"
            and not re.match(r"\s*['\u2019]s\b",right) and not re.search(r"\bof\s*$",left,re.I)):
        return "DECLARED_POSSESSOR_WITHOUT_GENITIVE_CONSTRUCTION_OPERATION"
    return None


def _joint_slot_fit(case, reading, candidate, parse):
    left,right=case["query"].split(case["focal_marker"])
    doc=parse(left+candidate["fill"]+right)
    a,b=len(left),len(left)+len(candidate["fill"])
    part=doc.char_span(a,b,alignment_mode="strict")
    result=dict(state="pass",scope="BOUNDED_DECLARED_ROLE_AND_LITERAL_COMPLETED_SLOT",
        reading_modified=False,factual_support_certified=False,absence_is_counterevidence=False)
    if part is None:
        return dict(result,state="missing",reason="COMPLETED_SLOT_TOKEN_BOUNDARIES_UNRESOLVED")
    if reading["form"]=="modifier":
        feature=candidate.get("ranking",{}).get("features",{})
        view=doc
        if doc.text.isupper() and len(doc.text.lower())==len(doc.text):
            view=parse(doc.text.lower())
        property_part=view.char_span(a,b,alignment_mode="strict")
        if property_part is None:
            return dict(result,state="missing",reason="MODIFIER_ANALYSIS_BOUNDARY_UNRESOLVED")
        carrier=_nominal_carrier(property_part)
        directional_license=(carrier is not None and (carrier.idx>=property_part.end_char
            or property_part.root.head.lemma_.casefold()=="be" or feature.get("source_carrier_precedes_property") is True))
        carrier_match=bool(directional_license and carrier.lemma_.casefold()==feature.get("source_carrier"))
        frame=feature.get("source_boundary_frame_cue",{})
        head=property_part.root.head
        frame_match=bool(frame.get("matched") and head.pos_ in {"VERB","AUX"} and head.lemma_.casefold()==frame["predicate"]
            and property_part.root.dep_==frame["argument_role"]
            and any(t.dep_ in {"nsubj","nsubjpass"} and t.lemma_.casefold()==frame["subject"] for t in head.children))
        if not carrier_match and not frame_match:
            return dict(result,state="missing",reason="NO_SOURCE_OWNED_LICENSE_FOR_COMPLETED_PROPERTY_FRAME",
                completed_head=property_part.root.text,completed_relation=property_part.root.dep_,completed_governor=head.text,
                full_english_ungrammaticality_certified=False)
        result["property_frame_license"]="SAME_SOURCE_PROPERTY_CARRIER" if carrier_match else "SOURCE_OWNER_AND_GOVERNOR_FRAME"
    if reading["role"]=="possessor" or reading["form"]=="possessive":
        if reading["form"]=="nominal" and re.search(r"\bof\s*$",left,re.I):
            head=part.root
            licensed=(head.dep_=="pobj" and head.head.lemma_.casefold()=="of" and head.head not in part
                and head.head.head.pos_ in {"NOUN","PROPN"} and head.head.head.idx<a)
            return dict(result,state="pass" if licensed else "missing",reason="VISIBLE_NOMINAL_OF_POSSESSOR" if licensed else "OF_POSSESSOR_ATTACHMENT_UNRESOLVED")
        genitive=bool(re.search(r"(?:['\u2019]s|s['\u2019])$",candidate["fill"]) or re.match(r"\s*['\u2019]s\b",right))
        if not genitive:
            return dict(result,state="conflict",reason="POSSESSOR_MISSING_GENITIVE_REALIZATION")
        attached=[t for t in part if t.dep_ in {"poss","nmod:poss"} and t.head not in part and t.head.idx>=b]
        if not attached:
            return dict(result,state="missing",reason="COMPLETED_GENITIVE_TO_VISIBLE_CARRIER_UNRESOLVED")
        result["attachment"]=[dict(start=t.idx,end=t.idx+len(t),text=t.text,head=t.head.text,dependency=t.dep_) for t in attached]
    return result


def construct(case, plan, retrieval, top_k=5, *, source_index=None):
    """Per-reading top-k after source constraints and bounded joint slot gates."""
    if type(top_k) is not int or not 1<=top_k<=5:
        raise ValueError("One-to-five per-reading display budget required")
    case=public_case(case)
    if case["task"] != "redaction":
        raise ValueError("Next constructor is Red-only")
    started=time.perf_counter()
    readings=_readings(case,plan)
    corpus,pages,policy,budget=_pages(case,retrieval,source_index)
    parser=SourceParses()
    admitted={p["id"]:p for _,p in pages}
    counts=Counter()
    rejected=[]
    groups={}
    unsupported=[dict(reading_id=r["id"],form=r["form"],reason="UNSUPPORTED_SOURCE_CONSTRUCTION_FORM_NO_PADDING")
        for r in readings if r["form"] not in FORMS]
    unsupported.extend(dict(reading_id=r["id"],form=r["form"],reason=_route_issue(case,r),bound_reading_modified=False)
        for r in readings if _route_issue(case,r))
    usable={r["id"] for r in readings if r["form"] in FORMS and not _route_issue(case,r)}
    with offline():
        query={r["id"]:_query_features(case,r,parser) for r in readings if r["id"] in usable}
        for pi,page in (pages if usable else ()):
            doc,spans=proposal_spans(page["text"],parser)
            seen=set()
            for raw in spans:
                key=(raw["start"],raw["end"],raw["kind"])
                if key in seen:
                    continue
                seen.add(key)
                counts["unique_source_constituents"]+=1
                if raw.get("source_format_rejection"):
                    counts["source_format_rejections"]+=1
                    continue
                a,b=raw["start"],raw["end"]
                if not 0<=a<b<=len(page["text"]) or page["text"][a:b]!=raw["text"]:
                    raise ValueError("Constituent does not replay its literal source span")
                part=doc.char_span(a,b,alignment_mode="strict")
                if part is None or not part.root.sent.start_char<=a<b<=part.root.sent.end_char:
                    counts["source_quote_boundary_rejections"]+=1
                    continue
                if re.search(r"\n[ \t]*\n",part.text):
                    counts["cross_paragraph_constituent_rejections"]+=1
                    continue
                if MASK.search(page["text"][part.root.sent.start_char:part.root.sent.end_char]):
                    counts["opaque_source_quote_rejections"]+=1
                    continue
                citation=policy.citation(pi,part.root.sent.start_char,part.root.sent.end_char)
                facts=_facts(corpus,pi,page,part)
                for reading in readings:
                    if reading["id"] not in usable:
                        continue
                    if query[reading["id"]]["effective_target_kind"]=="person" and any(e.label_=="PERSON" and e.start_char<=part.root.idx<e.end_char
                            and not a<=e.start_char<e.end_char<=b for e in doc.ents):
                        counts["incomplete_person_entity_span_rejections"]+=1
                        continue
                    wording,reason=_wording(case,reading,raw,part)
                    if reason:
                        counts["early_"+reason]+=1
                        continue
                    feature,reason=_source_features(part,raw,facts,reading,query[reading["id"]],page,pi,retrieval,parser)
                    if reason:
                        counts["early_"+reason]+=1
                        continue
                    fill,edits=wording
                    ids={f["node_id"] for f in facts}
                    node=next(iter(ids)) if len(ids)==1 else None
                    groupkey=(reading["id"]," ".join(fill.casefold().split()),node)
                    rankkey=_key(feature,page,[a,b],reading["id"],fill)
                    occurrence=dict(source_span=[a,b],source_wording=raw["text"],citation=citation,
                        insertion_edits=edits,features=feature,identity_merged=False)
                    counts["source_reading_drafts"]+=1
                    if groupkey not in groups:
                        groups[groupkey]=dict(key=rankkey,reading=reading,fill=fill,node_id=node,
                            primary=occurrence,occurrences=[occurrence])
                    else:
                        group=groups[groupkey]
                        group["occurrences"].append(occurrence)
                        if rankkey<group["key"]:
                            group.update(key=rankkey,fill=fill,primary=occurrence)
        by_reading={r["id"]:[] for r in readings}
        used={r["id"]:set() for r in readings}
        ordered=sorted(groups.values(),key=lambda g:g["key"])
        for position,group in enumerate(ordered,1):
            rid=group["reading"]["id"]
            positive=_positive_feasibility(group["primary"]["features"])
            if not positive["positive_clue"]:
                counts["no_info_source_groups_retained_not_displayed"]+=1
                continue
            # Exhaust the cheap relation-positive tier, even after five viable
            # rows. Context rows cannot hide an observed complete source match.
            if len(by_reading[rid])>=top_k and not (group["primary"]["features"]["source_owned_relation_match"]
                    or group["primary"]["features"]["source_owned_property_match"]
                    or group["primary"]["features"]["source_boundary_frame_cue"].get("matched")):
                counts["per_reading_lower_context_groups_unevaluated"]+=1
                continue
            displaykey=" ".join(group["fill"].casefold().split())
            if displaykey in used[rid]:
                counts["display_literal_duplicate_skips"]+=1
                continue
            primary=group["primary"]
            candidate=dict(id="next_fill_"+digest([case["case_id"],group["reading"]["id"],group["fill"],group["node_id"],
                primary["citation"]["page_sha256"],primary["source_span"]])[:28],fill=group["fill"],node_id=group["node_id"],
                source_span=primary["source_span"],source_wording=primary["source_wording"],
                insertion_edits=primary["insertion_edits"],source_occurrences=group["occurrences"],
                sources=list({digest(o["citation"]):o["citation"] for o in group["occurrences"]}.values()),
                v6_reading=group["reading"],support="SOURCE_WORDING_CONTEXT_ONLY",source_owner=primary["features"]["source_carrier"],
                source_rank_position=position,ranking=dict(tiers=RANK_TIERS,features=primary["features"],calibrated_probability=False))
            positive["witness"]=dict(source_span=primary["source_span"],source_wording=primary["source_wording"],citation=primary["citation"],
                property_owner=primary["features"]["source_carrier"],owner_constraints=primary["features"]["source_owner_constraints"],
                role=primary["features"]["source_owned_role_context"],frame=primary["features"]["source_boundary_frame_cue"])
            candidate["source_candidate_feasibility"]=positive
            joint=_joint_slot_fit(case,group["reading"],candidate,parser)
            counts["joint_slot_checks"]+=1
            candidate["joint_slot_fit"]=joint
            if joint["state"]!="pass":
                counts["joint_slot_withheld"]+=1
                rejected.append(dict(candidate_id=candidate["id"],fill=candidate["fill"],source_rank_position=position,joint_slot_fit=joint,
                    reason="JOINT_SLOT_FIT_NOT_ESTABLISHED",not_factual_counterevidence=True))
                continue
            before=time.perf_counter()
            decision=_gate(case,plan,group["reading"],candidate,admitted,parser)
            counts["scoped_gate_calls"]+=1
            counts["scoped_gate_microseconds"]+=round((time.perf_counter()-before)*1e6)
            candidate["local_decision"]=decision
            grammar=next((x for x in decision["checklist"] if x["id"]=="grammar"),None)
            if decision["status"]=="incompatible_not_viable" or grammar is None or grammar["state"]!="pass":
                rejected.append(dict(candidate_id=candidate["id"],fill=candidate["fill"],source_rank_position=position,decision=decision))
                continue
            candidate.update(reading_id=rid,
                support_assessment=dict(label=decision["label"],substantive_support=decision["status"]=="evidence_backed_suggestion",
                    scope=decision.get("scope"),same_scoped_counterevidence=decision["counterevidence"],
                    absence_is_counterevidence=False),candidate_feasibility=dict(status="SOURCE_GROUNDED_PLAUSIBLE_UNDER_BOUNDED_SLOT_CRITERIA",version=FEASIBILITY_VERSION,
                    positive_source_clue=True,criteria=deepcopy(positive["criteria"]),joint_slot=deepcopy(joint),
                    evidence_gate_version=evidence_gate.VERSION,factual_support_certified=False,full_english_grammar_certified=False))
            by_reading[rid].append(candidate)
            used[rid].add(displaykey)
    tiers={"evidence_backed_suggestion":0,"partial_grounding":1,"exploratory_contextual":2}
    views=[]
    for reading in readings:
        values=sorted(by_reading[reading["id"]],key=lambda candidate:(tiers.get(candidate["local_decision"]["status"],3),candidate["source_rank_position"]))[:top_k]
        for rank,candidate in enumerate(values,1):
            candidate["rank"]=rank
            candidate["ranking"]["adjudication_tier"]=tiers.get(candidate["local_decision"]["status"],3)
            candidate["ranking"]["canonical_order"]="Observed scoped sufficiency tier, then fixed source relevance; no model/key correctness input"
        views.append(dict(reading=reading,candidates=values))
    selected=[candidate for row in views for candidate in row["candidates"]]
    diagnostic=[];seen_literal=set()
    for rank in range(top_k):
        for row in views:
            if rank<len(row["candidates"]):
                candidate=row["candidates"][rank];literal=" ".join(candidate["fill"].casefold().split())
                if literal not in seen_literal and len(diagnostic)<top_k:
                    diagnostic.append(candidate);seen_literal.add(literal)
    # This runs only after all gates, per-reading ordering and display selection.
    audits=[]
    for reading in readings:
        for candidate in by_reading[reading["id"]]:
            candidate["constraint_audit"]=_constraint_audit(case,reading,candidate,admitted)
            audits.append(candidate["constraint_audit"])
    return dict(version=VERSION,task="redaction",candidates=selected,
        constraint_audit=dict(version=CONSTRAINT_ADAPTER_VERSION,helper_version=constraints.VERSION,
            audit_only=True,ranking_and_decisions_unchanged=True,checked_viable_count=len(audits),
            completed_count=sum(a["status"]=="COMPLETE_AUDIT_NOT_NEW_ADJUDICATION" for a in audits),
            unavailable_count=sum(a["status"]=="AUDIT_UNAVAILABLE" for a in audits),
            coverage="CHECKED_VIABLE_ONLY; NO_INFO_UNEVALUATED_AND_REJECTED_GROUPS_KEEP_ORIGINAL_AUDIT"),
        readings=views,global_diagnostic_candidates=diagnostic,
        display_budgets=dict(per_reading=top_k,reading_count=len(readings),maximum_total=top_k*len(readings),
            actual_total=len(selected),unique_literal_total=len({" ".join(c["fill"].casefold().split()) for c in selected}),
            global_diagnostic=top_k,global_diagnostic_is_canonical=False),
        inspected_page_ids=list(admitted),source_pages_inspected=len(admitted),source_budget=budget,
        inspected_page_ids_scope="SOURCE_POLICY_VALIDATED_SELECTED_POOL; NOT_CONSTITUENT_ENUMERATION_COVERAGE",
        source_pages_enumerated=len(pages) if usable else 0,
        all_admitted_pages_enumerated=bool(usable) and budget["inspected_page_count"]==budget["admitted_page_count"],
        readings_not_constructible=not bool(usable),
        no_construction_reason="NO_EXECUTABLE_READINGS; NOT_A_CORPUS_ABSENCE_RESULT" if not usable else None,
        status="CANDIDATE_SUGGESTIONS" if selected else "NO_SOURCE_GROUNDED_SUGGESTIONS",unsupported_readings=unsupported,
        display_policy=dict(version=FEASIBILITY_VERSION,maximum_per_reading=top_k,padding_to_budget=False,
            required="Positive source-owned slot clue AND bounded joint syntax AND scoped factual/counter gate",
            no_info_retained_in_audit=True,missing_clue_is_counterevidence=False),
        execution=dict(elapsed_seconds=time.perf_counter()-started,counts=dict(counts),source_parse_requests=parser.calls,
            unique_parsed_texts=parser.misses,source_ranked_groups=len(groups),per_reading_display_budget=top_k,
            source_constituent_enumeration_skipped=not usable,
            source_constituent_skip_reason="NO_EXECUTABLE_READINGS" if not usable else None,
            old_full_constructor_called=False,all_insertions_preparsed=False,source_budget_enforced=True),
        _candidate_audit=dict(source_groups=[dict(reading_id=g["reading"]["id"],fill=g["fill"],node_id=g["node_id"],
            rank=list(g["key"]),source_candidate_feasibility=_positive_feasibility(g["primary"]["features"]),occurrences=g["occurrences"]) for g in ordered],scoped_rejections=rejected,
            checked_viable=[dict(id=c["id"],reading_id=c["reading_id"],fill=c["fill"],source_rank_position=c["source_rank_position"],
                local_decision=c["local_decision"],displayed=any(c is v for v in selected),constraint_audit=c["constraint_audit"])
                for rows in by_reading.values() for c in rows],
            unevaluated_lower_ranked_groups=len(ordered)-counts["joint_slot_checks"]-counts["display_literal_duplicate_skips"]-counts["no_info_source_groups_retained_not_displayed"],
            no_info_retained_group_count=counts["no_info_source_groups_retained_not_displayed"],
            source_relation_positive_groups=sum(bool(g["primary"]["features"]["source_owned_relation_match"]) for g in ordered),
            unevaluated_is_rejection=False,identity_or_source_proofs_merged=False,keys_read=False,grades_read=False),
        rank_semantics="Per reading: exhaust cheap positive source-relation tier; scoped evidence-backed before partial/context among checked viable rows, then fixed source relevance. Lower context remains explicitly unevaluated, not rejected; complete corpus supported-candidate recall is not certified.",
        evidence_scope="Only exact candidate-owned citations; no claim of an exhaustive corpus counterevidence search.",
        evidence_gate_version=evidence_gate.VERSION,API_calls=0,keys_read=False,grades_read=False)
