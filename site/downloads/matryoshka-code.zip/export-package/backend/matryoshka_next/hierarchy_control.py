"""Optional retrospective up/down discovery; never a factual evidence route.

The caller supplies source-retrieval seeds. Memberships schedule raw source
inspection, not identity joins, entailment, probabilities or decision credit.
Nothing in the primary retrieval/workflow imports this experimental control.
"""
from collections import Counter, defaultdict
from collections.abc import Mapping
from copy import deepcopy
import hashlib
from numbers import Integral
import time

from matryoshka_demo.corpus import ENGLISH_STOP_WORDS, words
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from .facts import SourcePolicy, public_plan


VERSION = "next-retrospective-hierarchy-navigation/1"
LEVELS = ("community", "theme", "domain")
_REQUEST_WORDS = {"assess", "whether", "reconstruct", "identify", "provide", "account",
                  "analyst", "asks", "describe", "explain", "determine"}


def _terms(text):
    return set(words(text)) - ENGLISH_STOP_WORDS - _REQUEST_WORDS


class _HierarchyIndex:
    """Context-local metadata postings; no corpus-wide source NLP or new graph."""
    def __init__(self, corpus):
        self.corpus = corpus
        self.hierarchy = getattr(corpus, "hierarchy", {})
        self.rows, self.members = {}, defaultdict(list)
        self.parents, self.rejections = defaultdict(set), Counter()
        whole = hashlib.sha256()
        for node, row in sorted(self.hierarchy.items()):
            row_hash = digest(row)
            whole.update((digest([node, row_hash]) + "\n").encode("ascii"))
            if (node not in corpus.node_index or not isinstance(row, Mapping)
                    or row.get("node_id") != node):
                self.rejections["UNKNOWN_OR_MISMATCHED_NODE"] += 1
                continue
            if (row.get("view") != "earlier" or row.get("visibility") not in {"earlier", "earlier_only", "both"}
                    or row.get("hierarchy_bridge_eligible") is not True):
                self.rejections["NONSELECTED_OR_UNVERIFIED_MEMBERSHIP"] += 1
                continue
            path = [(level, row.get(level + "_id")) for level in LEVELS]
            if any(not isinstance(identity, str) or not identity for _, identity in path):
                self.rejections["INCOMPLETE_CONTAINER_PATH"] += 1
                continue
            self.rows[node] = dict(path=path, sha256=row_hash)
            for key in path:
                self.members[key].append(node)
            for child, parent in zip(path, path[1:]):
                self.parents[child].add(parent)
        self.sha256 = whole.hexdigest()
        self.conflicted = {child for child, parents in self.parents.items() if len(parents) != 1}
        self.occurrences = defaultdict(list)
        for oi, row in enumerate(corpus.occurrences):
            self.occurrences[row["node_id"]].append(oi)

    def member(self, node):
        record = self.rows.get(node)
        if record is None:
            return None
        if (getattr(self.corpus, "hierarchy", None) is not self.hierarchy
                or digest(self.hierarchy.get(node)) != record["sha256"]):
            raise ValueError("Hierarchy membership changed; open a fresh immutable context")
        if any(key in self.conflicted for key in record["path"]):
            return None
        return dict(node_id=node, path=[dict(level=level, id=identity) for level, identity in record["path"]],
                    row_sha256=record["sha256"], retrospective=True, is_evidence=False)


class _Budget:
    def __init__(self, **limits):
        self.limits, self.used, self.stops = limits, Counter(), set()

    def take(self, name):
        if self.used[name] >= self.limits[name]:
            self.stops.add(name.upper() + "_BUDGET")
            return False
        self.used[name] += 1
        return True


def _node(corpus, value):
    if isinstance(value, Integral) and not isinstance(value, bool):
        return corpus.node_ids[int(value)] if 0 <= value < len(corpus.node_ids) else None
    return value if isinstance(value, str) and value in corpus.node_index else None


def _seeds(corpus, seeds, node_ranks, pending):
    if (seeds is None) == (node_ranks is None):
        raise ValueError("Supply exactly one explicit seed list or node-rank mapping")
    if node_ranks is not None:
        if not isinstance(node_ranks, Mapping) or any(
                not isinstance(rank, Integral) or isinstance(rank, bool) or rank < 1
                for rank in node_ranks.values()):
            raise ValueError("Source node ranks must be positive integer ranks, not confidence")
        seeds = [node for node, _ in sorted(node_ranks.items(), key=lambda pair: (pair[1], str(pair[0])))]
    if not isinstance(seeds, (list, tuple)):
        raise ValueError("Explicit source seeds must be an ordered list")
    output, seen = [], set()
    for value in seeds:
        raw = value if isinstance(value, Mapping) else dict(node_id=value)
        node = _node(corpus, raw.get("node_id"))
        bindings = raw.get("bindings", {})
        criteria = raw.get("pending_criteria", pending)
        if not isinstance(bindings, Mapping) or any(
                not isinstance(key, str) or _node(corpus, target) != target for key, target in bindings.items()):
            raise ValueError("Navigation may preserve only explicit existing node bindings")
        if (not isinstance(criteria, (list, tuple)) or any(not isinstance(item, str) for item in criteria)
                or len(set(criteria)) != len(criteria) or not set(criteria) <= set(pending)):
            raise ValueError("Pending criteria must refer to distinct required public atoms")
        identity = digest([node, bindings, list(criteria)])
        if identity not in seen:
            seen.add(identity)
            output.append(dict(node_id=node, bindings=dict(bindings), pending_criteria=list(criteria)))
    return output


def _leaf(index, policy, node, query_terms, criteria_terms, budget, rejected):
    """Literal source-clause affinity nominates; it does not discharge criteria."""
    corpus = index.corpus
    for oi in index.occurrences.get(node, []):
        if not budget.take("occurrence"):
            return None
        row = corpus.occurrences[oi]
        pi, ui = row.get("page_index"), row.get("unit_index")
        if (not isinstance(pi, Integral) or not 0 <= pi < len(corpus.pages)
                or not policy.allowed(pi)):
            rejected["INELIGIBLE_SOURCE_OCCURRENCE"] += 1
            continue
        if not isinstance(ui, Integral) or not 0 <= ui < len(corpus.units):
            rejected["UNBOUND_SOURCE_UNIT"] += 1
            continue
        unit = corpus.units[ui]
        start, end = row.get("start"), row.get("end")
        if (unit["pi"] != pi or corpus.node_index[node] not in unit["nodes"]
                or type(start) is not int or type(end) is not int
                or not unit["start"] <= start < end <= unit["end"]
                or not isinstance(row.get("source_row_id"), str) or not row["source_row_id"]):
            rejected["UNBOUND_SOURCE_UNIT"] += 1
            continue
        if MASK.search(corpus.pages[pi]["text"][unit["start"]:unit["end"]]):
            rejected["OPAQUE_SOURCE_UNIT"] += 1
            continue
        citation = policy.citation(pi, unit["start"], unit["end"])
        occurrence = policy.citation(pi, start, end)
        if citation["text"] != unit["text"]:
            raise ValueError("Navigation leaf quote differs from raw source")
        literal = _terms(citation["text"])
        matched = sorted(literal & query_terms)
        if not matched:
            continue
        return dict(node_id=node, citation=citation, occurrence_citation=occurrence,
            source_row_id=row["source_row_id"], matched_query_terms=matched,
            criterion_affinity=[dict(atom_id=identity, matched_terms=sorted(terms & literal))
                for identity, terms in criteria_terms.items() if terms & literal],
            affinity_is_entailment=False, is_evidence=False)
    return None


def _path(seed_member, target_member, level):
    up = [dict(level="semantic", id=seed_member["node_id"]), *seed_member["path"][:level + 1]]
    down = [dict(level="semantic", id=target_member["node_id"]), *target_member["path"][:level]]
    nodes = up + list(reversed(down))
    return nodes, [dict(source=left, target=right, direction="UP" if i < len(up) - 1 else "DOWN",
        kind="RETROSPECTIVE_MEMBERSHIP" if "semantic" in {left["level"], right["level"]}
            else "RETROSPECTIVE_CONTAINMENT", is_evidence=False, identity_authority=False)
        for i, (left, right) in enumerate(zip(nodes, nodes[1:]))]


def nominate(corpus, case, plan, *, seeds=None, node_ranks=None, source_index=None,
             seed_budget=8, container_budget=24, member_budget=512, occurrence_budget=2048,
             leaf_budget=100, max_container_members=512):
    """Return a separately budgeted optional nomination stream, not a verdict.

    A seed must replay to an eligible query-matched leaf. For each seed, inspect
    community, then theme, then domain, widening only if the smaller container
    yielded no new leaf. Oversized containers are not traversed. A semantic node
    is nominated at most once. No primary ranks, source admissions or bindings
    are changed; callers must separately admit/re-evaluate nominated pages.
    """
    started = time.perf_counter()
    case = public_plan(case, plan)
    limits = dict(seed=seed_budget, container=container_budget, member=member_budget,
                  occurrence=occurrence_budget, leaf=leaf_budget)
    if any(type(value) is not int or value < 1 for value in [*limits.values(), max_container_members]):
        raise ValueError("Positive integer navigation budgets are required")
    required = [a for a in plan["atoms"] if a.get("required", a.get("kind") != "context")]
    pending = [a["id"] for a in required]
    proposed = _seeds(corpus, seeds, node_ranks, pending)
    query_terms = _terms(case["query"]) | set().union(*(_terms(a["text"]) for a in required))
    criteria_terms = {a["id"]: _terms(a["text"]) for a in required}
    policy = SourcePolicy(corpus, case, source_index)
    index = getattr(corpus, "_next_hierarchy_navigation_index", None)
    cache_hit = index is not None
    if index is None:
        index = _HierarchyIndex(corpus)
        corpus._next_hierarchy_navigation_index = index
    if index.hierarchy is not getattr(corpus, "hierarchy", None):
        raise ValueError("Hierarchy context changed; construct a fresh navigation index")
    budget, rejected = _Budget(**limits), Counter()
    traces, containers, pages, page_ids, nominated = [], [], [], [], set()
    seed_ids = {row["node_id"] for row in proposed[:seed_budget] if row["node_id"] is not None}
    for seed in proposed:
        if not budget.take("seed"):
            break
        node = seed["node_id"]
        membership = index.member(node)
        if membership is None:
            rejected["UNVERIFIED_OR_CONFLICTED_SEED_MEMBERSHIP"] += 1
            continue
        leaf = _leaf(index, policy, node, query_terms, criteria_terms, budget, rejected)
        if leaf is None:
            rejected["NO_ELIGIBLE_QUERY_MATCHED_SEED_QUOTE"] += 1
            continue
        for level, key in enumerate(index.rows[node]["path"]):
            if not budget.take("container"):
                break
            members = index.members[key]
            report = dict(seed_node_id=node, level=key[0], container_id=key[1],
                declared_member_count=len(members), nominated_leaves=0)
            containers.append(report)
            if len(members) > max_container_members:
                report["status"] = "OVERSIZED_CONTAINER_SKIPPED"
                budget.stops.add("MAX_CONTAINER_MEMBERS")
                continue
            report["status"] = "DECLARED_MEMBERS_EXAMINED"
            for target in members:
                if target in seed_ids or target in nominated:
                    continue
                if not budget.take("member"):
                    report["status"] = "MEMBER_BUDGET_STOP"
                    break
                target_membership = index.member(target)
                if target_membership is None:
                    rejected["CONFLICTED_TARGET_MEMBERSHIP"] += 1
                    continue
                target_leaf = _leaf(index, policy, target, query_terms, criteria_terms, budget, rejected)
                if target_leaf is None:
                    continue
                if not budget.take("leaf"):
                    report["status"] = "LEAF_BUDGET_STOP"
                    break
                nodes, edges = _path(membership, target_membership, level)
                traces.append(dict(seed_node_id=node, target_node_id=target,
                    selected_container=dict(level=key[0], id=key[1]), nodes=nodes, edges=edges,
                    source_leaf=deepcopy(leaf), target_leaf=target_leaf,
                    membership_refs=[membership, target_membership],
                    bindings=deepcopy(seed["bindings"]), pending_criteria=list(seed["pending_criteria"]),
                    source_support_certified=False, identity_equivalence_certified=False,
                    retrospective=True, is_evidence=False))
                nominated.add(target)
                report["nominated_leaves"] += 1
                pid = target_leaf["citation"]["canonical_page_id"]
                if pid not in page_ids:
                    page_ids.append(pid)
                    pages.append(corpus.page_index[pid])
            if report["nominated_leaves"]:
                report["wider_containers_intentionally_not_inspected"] = True
                break
            if budget.stops & {"MEMBER_BUDGET", "OCCURRENCE_BUDGET", "LEAF_BUDGET"}:
                break
        if budget.stops & {"MEMBER_BUDGET", "OCCURRENCE_BUDGET", "LEAF_BUDGET", "CONTAINER_BUDGET"}:
            break
    return dict(version=VERSION, case_id=case["case_id"], query_sha256=digest(case["query"]),
        plan_sha256=digest(plan), navigation_traces=traces, nominated_page_order=pages,
        nominated_page_ids=page_ids, nominated_node_ids=[row["target_node_id"] for row in traces],
        receipt=dict(version=VERSION, control="EXPERIMENTAL_ACTUAL_UP_DOWN_NAVIGATION",
            corpus_binding_sha256=digest(getattr(corpus, "binding", {})),
            hierarchy_memberships_sha256=index.sha256,
            hierarchy_hash_contract="SHA256_SORTED_NODE_AND_CANONICAL_ROW_HASH_JSON_PAIRS_WITH_NEWLINES",
            hierarchy_rows=len(index.hierarchy), indexed_member_rows=len(index.rows),
            membership_rejections=dict(index.rejections), conflicted_parent_containers=len(index.conflicted),
            index_cache_hit=cache_hit, index_build_scans_metadata_and_occurrences_not_source_nlp=True,
            budgets=limits, budget_used={name: budget.used[name] for name in limits},
            max_container_members=max_container_members, seed_candidates=len(proposed),
            stop_reasons=sorted(budget.stops), rejected=dict(rejected), containers=containers,
            nominated_unique_source_quotes=len({digest([row["target_leaf"]["citation"][key]
                for key in ("canonical_page_id", "start", "end")]) for row in traces}),
            nominated_unique_documents=len({row["target_leaf"]["citation"]["document_id"] for row in traces}),
            search_status="SEARCH_INCOMPLETE" if budget.stops else
                "DECLARED_NAVIGATION_SCHEDULE_EXHAUSTED_NOT_CORPUS_COMPLETE",
            smallest_successful_container_only=True, raw_leaf_quotes_replayed=True,
            complete_source_index_supplied=source_index is not None,
            retrospective=True, is_evidence=False, hierarchy_membership_has_support_credit=False,
            query_bindings_extended=False, primary_ranks_or_verdicts_modified=False,
            nomination_order="Supplied seed order, smallest usable container, stable member node ID; no probability or entailment score",
            limitations=["Literal query/source affinity is discovery, not semantic entailment.",
                "Seed, container, member, occurrence, leaf and container-size caps limit recall.",
                "Only the first eligible matched occurrence per leaf is retained; repeated leaves are not independent witnesses.",
                "Membership and hierarchy are retrospective; raw quotations do not prove these clustering links.",
                "Without a complete source index, handling reconciliation is limited to materialized corpus pages.",
                "Caller must independently admit and evaluate nominated pages; navigation supplies no factual support.",
                "Context/index objects are assumed immutable; changed source resources require a fresh context."],
            api_calls=0, grades_read=False, keys_read=False,
            wall_seconds=time.perf_counter() - started))
