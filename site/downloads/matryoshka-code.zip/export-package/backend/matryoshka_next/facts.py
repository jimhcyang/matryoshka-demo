"""Source-owned discovery records and context-local linguistic caches.

Extraction labels, role fields and graph connectivity nominate source text. They
are deliberately not assertion/identity/entailment certificates.
"""
from collections import defaultdict
from collections.abc import Mapping
from copy import deepcopy
from datetime import date
import re

import numpy as np

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.io import digest, rows


VERSION = "next-source-fact-index/2"
_HANDLING = re.compile(r"\bNOFORN\b|\bNO\s+FOREIGN\s+DISSEM(?:INATION)?\b", re.I)
_PRIVATE = {"reference_answer", "evaluation_keys", "answer_key", "gold", "grades",
            "origin_text", "origin_body", "source_proof", "predicted_fill"}


def normal(text):
    return " ".join(str(text).casefold().split())


def public_plan(case, plan):
    """Check public bindings without requiring canonical atoms to be verbatim."""
    case = public_case(case)
    if not isinstance(plan, Mapping) or not isinstance(plan.get("atoms"), list):
        raise ValueError("A query-only atom packet is required")
    def inspect(value):
        if isinstance(value, Mapping):
            if _PRIVATE.intersection(value):
                raise ValueError("Private answer/source/grade fields are not planner inputs")
            for item in value.values():
                inspect(item)
        elif isinstance(value, (tuple, list)):
            for item in value:
                inspect(item)
    inspect(plan)
    if plan.get("query_sha256", digest(case["query"])) != digest(case["query"]):
        raise ValueError("Plan and public query differ")
    if plan.get("task", case["task"]) != case["task"]:
        raise ValueError("Plan belongs to another task")
    seen = set()
    for atom in plan["atoms"]:
        if not isinstance(atom, Mapping) or not isinstance(atom.get("text"), str) or not atom["text"].strip():
            raise ValueError("Nonempty normalized atoms required")
        if not isinstance(atom.get("id"), str) or atom["id"] in seen:
            raise ValueError("Distinct atom IDs required")
        seen.add(atom["id"])
        if atom.get("kind", "proposition") not in {"proposition", "information_need", "context"}:
            raise ValueError("Unknown atom kind")
        if atom.get("polarity", "unknown") not in {"positive", "negative", "unknown"}:
            raise ValueError("Unknown requested polarity")
        if atom.get("modality", "unknown") not in {"asserted", "reported", "possible", "conditional", "unknown"}:
            raise ValueError("Unknown requested modality")
        spans = atom.get("query_spans")
        if spans is None and "start" in atom and "end" in atom:
            spans = [dict(start=atom["start"], end=atom["end"],
                          text=atom.get("source_quote", atom["text"]))]
        if not spans:
            raise ValueError("Every normalized atom needs exact public-query spans")
        for span in spans:
            a, b = span.get("start"), span.get("end")
            if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(case["query"])
                    or case["query"][a:b] != span.get("text")):
                raise ValueError("Public-query span does not replay")
    return case


class SourcePolicy:
    """Whole-document vetoes are computed before any query-source selection."""
    def __init__(self, corpus, case, source_index=None):
        self.corpus, self.case = corpus, public_case(case)
        if corpus.corpus != self.case["corpus"]:
            raise ValueError("Mixed source corpus")
        self.pages = {p["id"]: p for p in corpus.pages}
        if len(self.pages) != len(corpus.pages):
            raise ValueError("Ambiguous source-page identity")
        self.bound_pages = self.pages
        if source_index is not None:
            if isinstance(source_index, Mapping):
                self.bound_pages = dict(source_index)
            elif hasattr(source_index, "execute"):
                import json
                self.bound_pages = {p["id"]: p for p in
                    (json.loads(r[0]) for r in source_index.execute("SELECT payload FROM main.page"))}
            else:
                raise ValueError("Explicit complete source index required")
        self.veto = set()
        if self.case["corpus"] != "cib":
            for p in self.bound_pages.values():
                if _HANDLING.search(p["text"]) or any(_HANDLING.search(str(h)) for h in p.get("handling", [])):
                    self.veto.add(p["document_id"])
            for did, metadata in getattr(corpus, "classification", {}).items():
                if any(_HANDLING.search(str(h)) for h in metadata.get("handling", [])):
                    self.veto.add(did)

    def allowed(self, pi):
        p = self.corpus.pages[int(pi)]
        return (p.get("permitted") is True and p.get("corpus") == self.case["corpus"]
            and p.get("visibility") in {"earlier", "both"}
            and date.fromisoformat(p["date"]) < date.fromisoformat(self.case["date"])
            and p["document_id"] != self.case["document_id"] and p["document_id"] not in self.veto
            and (self.case["corpus"] == "cib" or p.get("classification") == "CONFIDENTIAL"))

    def mask(self):
        return np.asarray([self.allowed(i) for i in range(len(self.corpus.pages))], dtype=bool)

    def citation(self, pi, start, end):
        p = self.corpus.pages[int(pi)]
        bound = self.bound_pages.get(p["id"])
        if bound is None or any(bound.get(k) != p.get(k) for k in
                ("id", "text", "document_id", "date", "source_sha256", "classification", "permitted", "visibility", "corpus")):
            raise ValueError("Retrieval source differs from its explicit index")
        if not self.allowed(pi):
            raise ValueError("Source fails strict earlier/whole-origin/handling admission")
        if (digest(p["text"]) != p["source_sha256"] or type(start) is not int or type(end) is not int
                or not 0 <= start < end <= len(p["text"])):
            raise ValueError("Raw source hash or quote offsets changed")
        text = p["text"][start:end]
        if MASK.search(text):
            raise ValueError("Opaque source text cannot certify a fact")
        return dict(canonical_page_id=p["id"], document_id=p["document_id"], date=p["date"],
            start=start, end=end, text=text, page_sha256=p["source_sha256"],
            earlier_page=p.get("earlier_page"), corpus=p["corpus"])


class FactIndex:
    """Cheap indices over existing source records; no corpus-wide query NLP."""
    def __init__(self, corpus):
        self.corpus = corpus
        self.by_page = defaultdict(list)
        self.by_predicate = defaultdict(list)
        self.by_node = defaultdict(list)
        self.entity_names = defaultdict(list)
        self.entity_tokens = defaultdict(set)
        self.outgoing = defaultdict(list)
        self.incoming = defaultdict(list)
        self.edges = []
        self.local_record_cache = {}
        self.role_postings = defaultdict(list)
        self.source_cache = {}
        self.engine = None
        self.cache_hits = 0
        self.cache_misses = 0
        self.records_examined = 0
        for oi, occurrence in enumerate(getattr(corpus, "occurrences", [])):
            pi = occurrence["page_index"]
            self.by_page[pi].append(oi)
            self.by_node[occurrence["node_id"]].append(oi)
            if occurrence.get("source_type") != "entities":
                continue
            quote = corpus.pages[pi]["text"][occurrence["start"]:occurrence["end"]]
            label = occurrence.get("label", "")
            # A generated label not literally in the source cannot bind an actor.
            if label and normal(label) in normal(quote):
                self.entity_names[normal(label)].append(oi)
                for term in re.findall(r"[a-z0-9]+", normal(label)):
                    self.entity_tokens[term].add(oi)
        for edge in getattr(corpus, "edge_rows", []):
            value = dict(edge)
            value["edge_index"] = len(self.edges)
            self.edges.append(value)
            self.by_predicate[self.predicate_key(edge.get("relation", ""))].append(value["edge_index"])
            self.outgoing[edge["a"]].append(value["edge_index"])
            self.incoming[edge["b"]].append(value["edge_index"])

    @staticmethod
    def predicate_key(value):
        return "_".join(re.findall(r"[a-z0-9]+", str(value).casefold()))

    def quote(self, policy, unit_index):
        unit = self.corpus.units[unit_index]
        ref = policy.citation(unit["pi"], unit["start"], unit["end"])
        if ref["text"] != unit["text"]:
            raise ValueError("Source-owned extraction quote does not replay")
        return ref

    def local_records(self, pi):
        """Retain native role fields, never promote their generated semantics."""
        pid = self.corpus.pages[pi]["id"]
        if pid in self.local_record_cache:
            return self.local_record_cache[pid]
        current = getattr(self.corpus, "current_index", None)
        result = []
        if current is not None:
            from matryoshka_current.index import _unpack
            for table in ("observation", "assertion"):
                for stored in current.db.execute("SELECT payload FROM " + table + " WHERE page=? AND eligible=1", (pid,)):
                    result.append(_unpack(stored[0]))
        else:
            if not hasattr(self, "_incumbent_records"):
                self._incumbent_records = defaultdict(list)
                for name in ("entities", "events", "claims", "relations"):
                    path = getattr(self.corpus, "files", {}).get(name)
                    if path is not None:
                        for record in rows(path):
                            page = record.get("canonical_page_id")
                            if (page in self.corpus.page_index
                                    and self.corpus.pages[self.corpus.page_index[page]].get("permitted") is True
                                    and record.get("visibility") in {"both", "earlier_only"}
                                    and not record.get("introduced_by_slot_id")):
                                self._incumbent_records[page].append(record)
            result = self._incumbent_records[pid]
        self.local_record_cache[pid] = result
        self._index_roles(pid, result)
        return result

    def _index_roles(self, pid, records):
        for record in records:
            native = record.get("native_relation", record)
            quote = native.get("evidence_quote", "")
            page = self.corpus.pages[self.corpus.page_index[pid]]
            if (not quote or quote not in page["text"] or MASK.search(quote)
                    or native.get("canonical_page_id", pid) != pid
                    or native.get("document_id", page["document_id"]) != page["document_id"]
                    or native.get("document_date_iso", page["date"]) != page["date"]):
                continue
            for role in ("actor", "subject", "speaker", "target", "object", "predicate", "location"):
                value = native.get(role)
                if isinstance(value, str) and value and normal(value) in normal(quote):
                    self.role_postings[(pid, role, normal(value))].append(native)

    def prime_local_records(self, positions):
        """One source-ledger scan, not one full SQLite table scan per page."""
        current = getattr(self.corpus, "current_index", None)
        if current is None:
            for pi in positions:
                self.local_records(pi)
            return
        missing = [self.corpus.pages[pi]["id"] for pi in positions
                   if self.corpus.pages[pi]["id"] not in self.local_record_cache]
        if not missing:
            return
        from matryoshka_current.index import _unpack
        grouped = {pid: [] for pid in missing}
        for table in ("observation", "assertion"):
            placeholders = ",".join("?" for unused in missing)
            for stored in current.db.execute("SELECT page,payload FROM " + table
                    + " WHERE eligible=1 AND page IN (" + placeholders + ")", missing):
                grouped[stored[0]].append(_unpack(stored[1]))
        for pid, records in grouped.items():
            self.local_record_cache[pid] = records
            self._index_roles(pid, records)

    def linguistic_engine(self):
        if self.engine is None:
            from matryoshka_demo_v61.scope_matching import Engine
            self.engine = Engine()
        return self.engine

    def source_clause(self, policy, pi, start, end, *, engine=None):
        ref = policy.citation(pi, start, end)
        key = (ref["canonical_page_id"], ref["page_sha256"], start, end, VERSION)
        if key in self.source_cache:
            self.cache_hits += 1
            return self.source_cache[key]
        from matryoshka_current import proposition_matching
        engine = engine or self.linguistic_engine()
        value = dict(citation=ref, frames=engine.targets(ref["text"]),
            proposition=proposition_matching.compile_proposition(ref["text"], engine=engine),
            event_identity_certified=False, generated_role_fields_are_not_truth=True)
        self.source_cache[key] = value
        self.cache_misses += 1
        return value

    def stats(self):
        return dict(version=VERSION, source_occurrences=sum(map(len, self.by_page.values())),
            directed_edges=len(self.edges), source_clause_cache_hits=self.cache_hits,
            source_clause_cache_misses=self.cache_misses,
            source_local_pages_cached=len(self.local_record_cache),
            literal_source_role_postings=len(self.role_postings),
            corpus_wide_source_nlp=False, extraction_semantics_certified=False)


def fact_index(corpus):
    value = getattr(corpus, "_next_source_fact_index", None)
    if value is None:
        value = FactIndex(corpus)
        setattr(corpus, "_next_source_fact_index", value)
    return value
