"""Explicit saved-input audit. No inference, network, source reaudit or gold claims."""
from collections import Counter, defaultdict
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import re

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest


VERSION = "next-explicit-run-audit/3"
PUBLIC_FIELDS = {"case_id", "corpus", "task", "query", "document_id", "date", "focal_marker"}
STATUS = {"SUPPORT": "SUPPORTED", "ESTABLISHED": "SUPPORTED", "COUNTER": "OPPOSED",
    "PARTIAL_GROUNDING": "PARTIAL", "NO_INFO": "UNRESOLVED", "INSUFFICIENT": "UNRESOLVED"}


def _status(value):
    value = value.get("status", "UNKNOWN") if isinstance(value, dict) else value
    return STATUS.get(value, value or "UNKNOWN")


def snapshot(root, *, runs=(), nominees=(), admitted_cohorts=(), assessments=(),
             api_root="experiments/presentation_refresh/api", qualification_input=None, runlist_ref=None):
    """Inputs are explicit; directories named by runs contain native envelopes only.

    An assessment can be assessment.bind's result, or {assessment, payload}.
    The latter replays the reference-bearing assessment input without exporting
    the reference. Standalone results retain their opaque request-payload pin;
    their reference key has NOT been replayed, so Red recovery stays unmeasured.
    """
    root = Path(root).resolve()
    inputs, cases, categories, packets, rows, reviews = {}, {}, defaultdict(set), {}, [], {}
    cohort_records = []
    code_root = Path(__file__).resolve().parents[1]
    code_names = ["matryoshka_next/reporting.py", "scripts/audit_source_first_run.py"]

    def path(name):
        p = Path(name)
        return (p if p.is_absolute() else root/p).resolve()

    def read(name, *, decode=True):
        p = path(name); raw = p.read_bytes(); sha = hashlib.sha256(raw).hexdigest()
        if str(p) in inputs and inputs[str(p)]["sha256"] != sha:
            raise ValueError("Input changed during snapshot: " + str(p))
        inputs[str(p)] = dict(path=str(p), sha256=sha, bytes=len(raw))
        return json.loads(gzip.decompress(raw) if p.suffix == ".gz" else raw) if decode else None

    def add(case, category):
        if not isinstance(case, dict) or set(case) != PUBLIC_FIELDS:
            raise ValueError("Exactly seven public case fields required")
        case = public_case(case); cid = case["case_id"]
        if cid in cases and cases[cid] != case:
            raise ValueError("Same case ID has different public query/content: " + cid)
        cases[cid] = case; categories[category].add(cid)
        return case

    def catalog(name, category):
        value = read(name)
        values = value.get("cases") if isinstance(value, dict) else value
        if not isinstance(values, list):
            raise ValueError("Public catalog cases must be an array")
        if len({c["case_id"] for c in values}) != len(values):
            raise ValueError("Duplicate case ID in public catalog")
        for case in values: add(case, category)
        return values

    def count_matches(cohort, size):
        counts = [cohort[k] for k in ("cases", "admitted", "admitted_count", "distinct_admitted") if k in cohort]
        if not counts or any(type(n) is not int or n != size for n in counts):
            raise ValueError("Admission cohort/public catalog count mismatch")

    def verify_union(directory, cohort, admitted):
        pins = cohort.get("source_input_pins")
        if not isinstance(pins, dict) or not pins or cohort.get("source_review_model_not_gold") is not True:
            raise ValueError("Union requires explicit child source pins and model-not-gold declaration")
        for name, sha in sorted(pins.items()):
            if Path(name).is_absolute() or ".." in Path(name).parts or not path(name).is_relative_to(root):
                raise ValueError("Union child reference is not a canonical workspace path")
            read(name, decode=False)
            if inputs[str(path(name))]["sha256"] != sha:
                raise ValueError("Union child artifact hash changed: " + name)
        child_cases, original_cases, expected_history, batch_count = {}, {}, Counter(), 0
        for name in sorted(n for n in pins if Path(n).name == "cohort.json"):
            child_dir = path(name).parent; child = read(name)
            if not str(child.get("version", "")).startswith("immutable-source-admission-cli/"):
                # Original nomination cohorts are pinned provenance, not admission.
                if child.get("status") != "SOURCE_CITED_NOMINEES_NOT_FINAL_SEMANTIC_ADMISSION":
                    raise ValueError("Unrecognized union child admission protocol")
                for leaf in ("public_cases.json", "private_proofs.json"):
                    if str((child_dir/leaf).relative_to(root)) not in pins:
                        raise ValueError("Union original cohort lacks pinned public/proof artifacts")
                for item in read(child_dir/"public_cases.json")["cases"]:
                    cid = item["case_id"]
                    if cid in original_cases and original_cases[cid] != item:
                        raise ValueError("Conflicting original source-nomination case")
                    original_cases[cid] = item
                continue
            for leaf in ("public_cases.json", "private_proofs.json", "holds.json"):
                if str((child_dir/leaf).relative_to(root)) not in pins:
                    raise ValueError("Union semantic child lacks a pinned catalog/proof/hold artifact")
            public = read(child_dir/"public_cases.json")["cases"]
            count_matches(child, len(public))
            bound_cases = {}
            if not child.get("batches"): raise ValueError("Union semantic child has no bound review batches")
            for batch in child["batches"]:
                base = path(batch["directory"])
                if not base.is_relative_to(root): raise ValueError("Union review batch outside workspace")
                policy, prepared, wire = (read(base/n) for n in ("policy.json", "private_input.json", "model_request.json"))
                binding = prepared["binding"]
                if (binding.get("sha256") != digest({k:v for k,v in binding.items() if k != "sha256"})
                        or binding.get("payload_sha256") != digest(prepared["payload"])
                        or binding.get("prompt_sha256") != hashlib.sha256(prepared["prompt"].encode()).hexdigest()
                        or binding.get("schema_sha256") != digest(prepared["schema"])
                        or policy.get("binding_sha256") != binding["sha256"]):
                    raise ValueError("Union child review preparation binding changed")
                identity = digest(dict(version=policy["version"], binding=binding, code_pins=policy["code_pins"],
                    input_pins=policy["input_pins"], wire_sha256=digest(wire)))
                if batch.get("identity") != identity or base.name != identity:
                    raise ValueError("Union child review batch hash identity changed")
                for source, sha in policy["input_pins"].items():
                    source = path(source)
                    if not source.is_relative_to(root) or pins.get(str(source.relative_to(root))) != sha:
                        raise ValueError("Union review input is not in the pinned child closure")
                bound = read(base/"bound.json")
                if bound.get("request_binding_sha256") != binding["sha256"]:
                    raise ValueError("Union child bound review request changed")
                if len(bound["reviews"]) != batch["reviewed"] or len(bound["new_public_cases"]) != batch["admitted"]:
                    raise ValueError("Union child review batch counts differ")
                for item in bound["new_public_cases"]:
                    cid = item["case_id"]
                    if cid in bound_cases: raise ValueError("Duplicate admitted case in child review batches")
                    bound_cases[cid] = item
                for item in bound["reviews"]:
                    if item["decision"] not in {"ADMIT", "HOLD"}: raise ValueError("Unknown source admission decision")
                    expected_history[(str(child_dir.relative_to(root)), item["proposal_id"], item["decision"], binding["sha256"])] += 1
                batch_count += 1
            if bound_cases != {c["case_id"]:c for c in public} or len(bound_cases) != len(public):
                raise ValueError("Union child public catalog does not replay its review batches")
            for cid, item in bound_cases.items():
                if cid in child_cases and child_cases[cid] != item:
                    raise ValueError("Conflicting public case across union children")
                child_cases[cid] = item
        if not expected_history or child_cases != {c["case_id"]:c for c in admitted}:
            raise ValueError("Union admitted membership differs from verified semantic children")
        history = cohort.get("review_history", [])
        actual_history = Counter((h["source_snapshot"], h["original_case_id"], h["decision"], h["request_binding_sha256"]) for h in history)
        if actual_history != expected_history: raise ValueError("Union review history differs from child batches")
        decisions = defaultdict(set)
        for h in history: decisions[h["original_case_id"]].add(h["decision"])
        authorized = set(cohort.get("authorized_red_contract_replacements", []))
        if ({cid for cid,v in decisions.items() if len(v)>1} != authorized
                or any(bool(h.get("authorized_red_contract_replacement")) !=
                    (h["original_case_id"] in authorized) for h in history)):
            raise ValueError("Union conflicting reviews lack explicit contract-replacement authorization")
        if not set(decisions) <= set(original_cases) or cohort.get("original_cohort_cases") != len(original_cases):
            raise ValueError("Union original nomination population differs from pinned public catalogs")
        holds = read(directory/"holds.json")["reviews"]
        held_ids = {h["proposal_id"] for h in holds}
        if (len(held_ids) != len(holds) or held_ids != {cid for cid,v in decisions.items() if v == {"HOLD"}}
                or cohort.get("held") != len(holds) or cohort.get("reviewed_instances") != len(history)
                or cohort.get("reviewed_unique_cases") != len(decisions)
                or cohort.get("unreviewed_original_cases") != len(original_cases)-len(decisions)):
            raise ValueError("Union held/reviewed/unreviewed accounting differs from its bound history")
        return dict(child_source_pins_verified=len(pins), child_review_batches_verified=batch_count,
            historical_review_decisions=dict(Counter(h["decision"] for h in history)))

    for name in sorted(set(map(str, nominees))): catalog(name, "nominees")
    for name in sorted(set(map(str, admitted_cohorts))):
        directory = path(name); cohort = read(directory/"cohort.json")
        union = cohort.get("version") == "source-admission-snapshot-union/1"
        if not union and not str(cohort.get("version", "")).startswith(("source-aware-semantic-naturalness-admission/", "immutable-source-admission-cli/")):
            raise ValueError("Nomination cohort is not a semantic-admission cohort")
        admitted = catalog(directory/"public_cases.json", "admitted")
        count_matches(cohort, len(admitted))
        proof = directory/"private_proofs.json"
        if not proof.is_file(): raise ValueError("Admission cohort lacks its bound private source proofs")
        read(proof, decode=False)  # Pin source/key bytes without exporting or treating them as gold.
        verified = verify_union(directory, cohort, admitted) if union else {}
        cohort_records.append(dict(ref=str(directory/"cohort.json"), version=cohort["version"], admitted=len(admitted),
            **{k:cohort.get(k) for k in ("status", "complete_requested_review", "selected", "reviewed", "held", "pending",
                "reviewed_instances", "reviewed_unique_cases", "original_cohort_cases", "unreviewed_original_cases")}, **verified))

    files, selected_pins, selection = set(), {}, None
    if runlist_ref is not None:
        if runs: raise ValueError("Explicit runlist and directory-glob modes cannot be combined")
        from .reporting_runlist import validate
        code_names.append("matryoshka_next/reporting_runlist.py")
        manifest = read(runlist_ref["path"])
        if inputs[str(path(runlist_ref["path"]))]["sha256"] != runlist_ref["sha256"]:
            raise ValueError("Runlist file byte pin changed")
        manifest = validate(root, manifest)
        for ref in manifest["runs"]:
            files.add(path(ref["path"])); selected_pins[str(path(ref["path"]))] = ref
        selection = dict(manifest_ref=inputs[str(path(runlist_ref["path"]))], manifest_sha256=manifest["sha256"],
            progress_ref=manifest["progress_ref"], complete_conditions=manifest["complete_conditions"],
            progress_status_counts=manifest["progress_status_counts"], directory_glob_used=False)
    for name in runs:
        directory = path(name)
        if not directory.is_dir(): raise ValueError("Explicit run directory required")
        files.update(p for p in directory.rglob("*") if p.is_file() and p.name.endswith((".json", ".json.gz")))
    for file in sorted(files):
        envelope = read(file)
        if str(file) in selected_pins and inputs[str(file)]["sha256"] != selected_pins[str(file)]["sha256"]:
            raise ValueError("Selected native envelope byte pin changed")
        if not isinstance(envelope, dict) or "packet" not in envelope:
            raise ValueError("Run file is not a saved native envelope: " + str(file))
        packet = envelope["packet"]; sha = digest(packet)
        if envelope.get("packet_sha256") != sha:
            raise ValueError("Native envelope packet_sha256 mismatch")
        case = add(packet["case"], "executed")
        if packet.get("query_sha256") != digest(case["query"]):
            raise ValueError("Native packet public query binding mismatch")
        if sha in packets: continue  # Duplicate paths are not independent executions.
        packets[sha] = packet
        pins, env = packet.get("code_pins"), packet.get("environment")
        profile = dict(native_version=packet.get("version"), code_pins_sha256=digest(pins),
            environment_sha256=digest(env), code_pins_present=bool(pins), environment_present=bool(env))
        reading = packet.get("plan", {}).get("readings_packet", {})
        retrieval = packet.get("retrieval", {})
        rows.append(dict(case_id=case["case_id"], corpus=case["corpus"], task=case["task"],
            packet_sha256=sha, run_ref=str(file), profile_id=digest(profile), profile=profile,
            envelope_signature=envelope.get("signature"), plan_sha256=digest(packet.get("plan")),
            method=retrieval.get("method", retrieval.get("config", packet.get("config", "UNDECLARED"))),
            reading_mode=reading.get("interpreter", "not_applicable" if case["task"] != "redaction" else "UNDECLARED"),
            source_binding_sha256=digest(packet.get("binding")),
            budgets={k: retrieval.get(k) for k in ("document_budget", "construction_passage_budget", "passage_budget")},
            native_status=packet["result"].get("status", "UNKNOWN")))

    for name in sorted(set(map(str, assessments))):
        value = read(name); review = value.get("assessment", value); payload = value.get("payload")
        sha = review.get("packet_sha256")
        if sha not in packets or review.get("version") != "next-exact-packet-assessment/2":
            raise ValueError("Assessment is not for an exact supplied native packet/version")
        if review.get("postrun_only") is not True or review.get("inference_modified") is not False:
            raise ValueError("Assessment is not a detached post-run review")
        if sha in reviews: raise ValueError("Multiple assessments for one packet; select an explicit review version")
        from . import assessment
        code_names.append("matryoshka_next/assessment.py")
        packet = packets[sha]
        if payload is not None:
            expected = assessment.packet_input(packet, reference_answer=payload.get("reference_answer"))
            if payload != expected or digest(payload) != review.get("request_payload_sha256"):
                raise ValueError("Exact assessment payload/reference binding mismatch")
            expected_items = {r["item_id"]: r for r in expected["items"]}
        elif packet["case"]["task"] == "redaction":
            expected_items = {}
            for branch in packet["result"]["readings"]:
                rid = branch.get("reading_id", branch.get("reading", {}).get("id"))
                for candidate in branch["candidates"]:
                    identity = rid+"/"+candidate["id"]
                    if identity in expected_items: raise ValueError("Duplicate native assessment subject")
                    expected_items[identity] = dict(item_id=identity, reading_id=rid, candidate_id=candidate["id"])
        else:
            expected_items = {a["id"]:dict(item_id=a["id"]) for a in packet["result"]["atoms"] if a.get("required")}
        model_rows = review["reviews"]
        if not re.fullmatch(r"[a-f0-9]{64}", review.get("request_payload_sha256", "")):
            raise ValueError("Assessment request-payload binding missing")
        fields = assessment.schema()["properties"]["items"]["items"]["properties"]
        response = dict(items=[{k:r[k] for k in fields} for r in model_rows])
        if digest(response) != review.get("raw_response_sha256"):
            raise ValueError("Assessment raw response seal changed")
        if len({r["item_id"] for r in model_rows}) != len(model_rows) or {r["item_id"] for r in model_rows} != set(expected_items):
            raise ValueError("Assessment subjects are missing, duplicate or not displayed")
        for r in model_rows:
            item = expected_items[r["item_id"]]
            if (r.get("packet_sha256") != sha or r.get("reading_id") != item.get("reading_id")
                    or r.get("candidate_id") != item.get("candidate_id", item["item_id"])
                    or r.get("model_assessment_not_gold") is not True
                    or r.get("judgment") not in {"correct", "equivalent", "partial", "incorrect", "unjudgeable"}):
                raise ValueError("Assessment subject/key identity or judgment mismatch")
        reviews[sha] = dict(ref=str(path(name)), items={r["item_id"]: r for r in model_rows},
            request_payload_sha256=review.get("request_payload_sha256"),
            reference_answer_sha256=payload.get("reference_answer_sha256") if payload else None,
            reference_payload_replayed=payload is not None, model_assessment_not_gold=True,
            displayed_review_subjects=len(model_rows),
            judgment_counts=dict(Counter(r["judgment"] for r in model_rows)),
            evidence_counts=dict(Counter(r["evidence"] for r in model_rows)),
            local_decision_warranted_counts=dict(Counter(r["local_decision_warranted"] for r in model_rows)))
        if value.get("proof_ref") is not None:
            if payload is None: raise ValueError("Source-key binding requires the exact assessment payload")
            proofs = read(value["proof_ref"])["cases"]
            bound = [p for p in proofs if p["case_id"] == packet["case"]["case_id"]]
            if len({p["case_id"] for p in proofs}) != len(proofs) or digest(proofs) != value.get("proof_catalog_sha256"):
                raise ValueError("Assessment source-key catalog binding changed")
            if (len(bound) != 1 or bound[0].get("answer") != payload.get("reference_answer")
                    or bound[0].get("semantic_admission", {}).get("public_case") != packet["case"]
                    or bound[0]["semantic_admission"].get("decision") != "ADMIT"
                    or bound[0]["semantic_admission"].get("local_hold_reasons")):
                raise ValueError("Assessment source key does not bind the admitted native case")
            reviews[sha]["source_key_binding"] = dict(ref=inputs[str(path(value["proof_ref"]))],
                catalog_sha256=digest(proofs), reference_answer_sha256=payload["reference_answer_sha256"], source_proof_not_gold=True)

    for row in rows:
        packet = packets[row["packet_sha256"]]; result = packet["result"]
        review = reviews.get(row["packet_sha256"])
        if row["task"] != "redaction":
            atoms = [a for a in result["atoms"] if a.get("required") is True and a.get("kind") != "context"]
            row["required_atom_status_counts"] = dict(Counter(_status(a["status"]) for a in atoms))
            row["required_atom_raw_status_counts"] = dict(Counter(a["status"] for a in atoms))
            row["required_atoms"] = len(atoms)
        else:
            row["readings"] = []
            seen_readings = set()
            for branch in result["readings"]:
                rid = branch.get("reading_id", branch.get("reading", {}).get("id")); candidates = branch["candidates"]
                ranks = [c["rank"] for c in candidates]
                if (not rid or len(candidates) > 5 or any(type(r) is not int or not 1 <= r <= 5 for r in ranks)
                        or ranks != sorted(set(ranks)) or len({c["id"] for c in candidates}) != len(candidates)):
                    raise ValueError("Red branch must have at most five distinct, saved-order ranked candidates")
                if rid in seen_readings: raise ValueError("Duplicate Red reading branch")
                seen_readings.add(rid)
                recovery = None
                if review and review["reference_payload_replayed"]:
                    recovery = {label: {str(k): any(c["rank"] <= k and review["items"][rid+"/"+c["id"]]["judgment"] in judgments
                        for c in candidates) for k in (1, 3, 5)} for label, judgments in (
                        ("correct", {"correct"}), ("correct_or_equivalent", {"correct", "equivalent"}), ("partial", {"partial"}))}
                row["readings"].append(dict(reading_id=rid, candidates=len(candidates),
                    native_status_counts=dict(Counter(_status(c.get("local_decision", c.get("status"))) for c in candidates)),
                    assessed_recovery_at=recovery))
            row["unsupported_readings"] = result.get("unsupported_readings", [])
        row["assessment_binding"] = {k:v for k,v in review.items() if k != "items"} if review else None

    profiles = {}
    assessment_summaries = {}
    for row in rows:
        profile = profiles.setdefault(row["profile_id"], dict(row["profile"], conditions=0,
            overall_native_statuses=defaultdict(Counter), required_atom_statuses=defaultdict(Counter)))
        profile["conditions"] += 1
        cell = row["corpus"]+"/"+row["task"]
        profile["overall_native_statuses"][cell][row["native_status"]] += 1
        profile["required_atom_statuses"][cell].update(row.get("required_atom_status_counts", {}))
        binding = row["assessment_binding"]
        if row["task"] == "redaction" and binding and binding["reference_payload_replayed"]:
            summary = assessment_summaries.setdefault(row["profile_id"], dict(reference_bound_red_conditions=0,
                distinct_case_ids=set(), nonempty_conditions=0, nonempty_reading_branches=0,
                reviewed_ranked_occurrences=0, judgment_counts=Counter(), evidence_counts=Counter(),
                local_decision_warranted_counts=Counter(), correct_conditions_at=Counter(), correct_or_equivalent_conditions_at=Counter()))
            summary["reference_bound_red_conditions"] += 1; summary["distinct_case_ids"].add(row["case_id"])
            summary["nonempty_conditions"] += int(binding["displayed_review_subjects"] > 0)
            summary["nonempty_reading_branches"] += sum(b["candidates"] > 0 for b in row["readings"])
            summary["reviewed_ranked_occurrences"] += binding["displayed_review_subjects"]
            for field in ("judgment_counts", "evidence_counts", "local_decision_warranted_counts"):
                summary[field].update(binding[field])
            for k in ("1", "3", "5"):
                summary["correct_conditions_at"][k] += int(any(b["assessed_recovery_at"]["correct"][k] for b in row["readings"]))
                summary["correct_or_equivalent_conditions_at"][k] += int(any(b["assessed_recovery_at"]["correct_or_equivalent"][k] for b in row["readings"]))
    for summary in assessment_summaries.values():
        summary["distinct_case_ids"] = len(summary["distinct_case_ids"])
        summary["occurrences_are_not_independent_queries_or_unique_answers"] = True
    inventories = {}
    for category in ("nominees", "admitted", "executed"):
        selected = [cases[c] for c in sorted(categories[category])]
        unique = {(c["corpus"], c["task"], c["query"], c["focal_marker"]) for c in selected}
        inventories[category] = dict(public_case_ids=len(selected), distinct_public_queries=len(unique),
            public_cases_by_cell=dict(Counter(c["corpus"]+"/"+c["task"] for c in selected)),
            distinct_queries_by_cell=dict(Counter(c+"/"+t for c,t,_,_ in unique)))

    receipts, actual, reserved = [], Decimal(0), Decimal(0)
    ledger = path(api_root)/"receipts"
    if not ledger.is_dir(): raise ValueError("Explicit shared API receipt directory does not exist")
    for file in sorted(ledger.glob("*.json")):
        r = read(file); amount = Decimal(str(r["charged_or_reserved_usd"]))
        if not amount.is_finite() or not 0 <= amount <= 25: raise ValueError("Invalid ledger amount")
        known = r.get("status") in {"PASS", "PAID_INVALID_OUTPUT"}
        if known: actual += amount
        else: reserved += amount
        receipts.append(dict(ref=str(file), status=r["status"], model=r.get("model"),
            request_sha256=r.get("request_sha256"), charged_or_reserved_usd=float(amount), recorded_actual=known))

    qualification = dict(qualified=False, status="UNMET_NO_EXPLICIT_QUALIFICATION_INPUT",
        deficits=["No explicit sealed publication report and selected_ids were supplied to pub.qualify_selection."])
    if qualification_input:
        supplied = read(qualification_input); ref = supplied["report_ref"]; report = read(ref["path"])
        if inputs[str(path(ref["path"]))]["sha256"] != ref["sha256"]: raise ValueError("Qualification report byte pin changed")
        selectable = {r["case"]["case_id"]: r for r in report["cases"]}
        if not set(supplied["selected_ids"]) <= set(selectable): raise ValueError("Unknown qualification selection")
        selected_packets = set()
        for cid in supplied["selected_ids"]:
            selected = selectable[cid]
            condition = selected["conditions"][report["primary_config"]]
            if condition["packet_sha256"] not in packets or packets[condition["packet_sha256"]]["case"] != selected["case"]:
                raise ValueError("Qualification selection does not bind the supplied native runs")
            selected_packets.add(condition["packet_sha256"])
        selected_runs = [r for r in rows if r["packet_sha256"] in selected_packets]
        if len({r["profile_id"] for r in selected_runs}) > 1 or any(
                not r["profile"]["code_pins_present"] or not r["profile"]["environment_present"] for r in selected_runs):
            raise ValueError("Qualification cannot aggregate different or unbound code/environment profiles")
        from .publication import qualify_selection
        code_names.append("matryoshka_next/publication.py")
        qualification = qualify_selection(report, supplied["selected_ids"])
    result = dict(version=VERSION, reporter_code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        reporter_code_pins={n:hashlib.sha256((code_root/n).read_bytes()).hexdigest() for n in sorted(set(code_names))},
        inventories=inventories, admission_cohorts=cohort_records, conditions=len(rows), profiles=profiles, runs=rows, run_selection=selection,
        exact_red_assessment_by_profile=assessment_summaries,
        public_cases=[dict(case=cases[c], categories=[k for k in sorted(categories) if c in categories[k]]) for c in sorted(cases)],
        api_ledger=dict(root=str(path(api_root)), actual_recorded_usd=float(actual), retained_reserved_usd=float(reserved),
            charged_or_reserved_usd=float(actual+reserved), receipts=receipts, provider_invoice=False),
        qualification=qualification, inputs=[inputs[k] for k in sorted(inputs)],
        source_admission="EXPLICIT_COHORT_CLAIM_WITH_HASHED_PROOFS_NOT_REAUDITED_NOT_GOLD",
        comparisons_are_accuracy=False, conditions_are_independent_samples=False, full_benchmark_run_claimed=False,
        api_calls=0, inference_or_ranks_modified=False)
    result["sha256"] = digest(result)
    return result


def markdown(report):
    lines = ["# Source-First Saved-Run Audit", "", "Snapshot: `"+report["sha256"]+"`", "",
        "Outcome-informed development summary, not accuracy, gold, independent samples or a full benchmark run.", "",
        "| Inventory | Case IDs | Distinct public queries |", "|---|---:|---:|"]
    lines += [f"| {k} | {v['public_case_ids']} | {v['distinct_public_queries']} |" for k,v in sorted(report["inventories"].items())]
    lines += ["", f"Saved conditions: {report['conditions']}; code/environment profiles: {len(report['profiles'])}.",
        "Source admission is a bound cohort claim, not a fresh policy reaudit.",
        "Red correctness is model assessment of the exact packet, never inferred from backing. Unreviewed recovery is unmeasured.",
        "Standalone reviews have only a request-payload hash; recovery stays unmeasured until the reference-bearing exact payload is replayed.", "",
        "Admission snapshots:"]
    if report.get("run_selection"):
        lines.append("Explicit COMPLETE-only runlist: `"+report["run_selection"]["manifest_sha256"]+"`; no run-directory glob was used.")
    lines += [f"- `{c['ref']}`: {c['admitted']} admitted; held={c['held']}; status={c['status']}; complete_requested_review={c['complete_requested_review']}; pending={c['pending']}; unreviewed originals={c['unreviewed_original_cases']}." for c in report["admission_cohorts"]]
    for profile, s in sorted(report.get("exact_red_assessment_by_profile", {}).items()):
        lines += ["", f"Exact Red review profile `{profile[:12]}`: {s['reference_bound_red_conditions']} conditions / {s['distinct_case_ids']} case IDs; "
            f"{s['nonempty_conditions']} nonempty conditions / {s['nonempty_reading_branches']} nonempty reading branches / {s['reviewed_ranked_occurrences']} reviewed ranked occurrences.",
            "Occurrences are not independent questions or unique answers. Model judgments: "+json.dumps(s["judgment_counts"],sort_keys=True)+".",
            "Exact-reviewed correct recovery conditions @1/3/5: "+json.dumps(s["correct_conditions_at"],sort_keys=True)+"; not a benchmark accuracy estimate."]
    lines += ["", "| Case | Profile | Method / Reader | Native Outcome | Required Atoms / Red Branches |", "|---|---|---|---|---|"]
    for r in report["runs"]:
        detail = r.get("required_atom_status_counts", {b["reading_id"]:dict(native=b["native_status_counts"], recovery=b["assessed_recovery_at"]) for b in r.get("readings", [])})
        lines.append(f"| `{r['case_id']}` | `{r['profile_id'][:12]}` | {r['method']} / {r['reading_mode']} | {r['native_status']} | {json.dumps(detail,sort_keys=True)} |")
    money = report["api_ledger"]
    lines += ["", f"API recorded actual: ${money['actual_recorded_usd']:.8f}; retained reservations: ${money['retained_reserved_usd']:.8f}; total: ${money['charged_or_reserved_usd']:.8f}.",
        "", "Fifteen-case qualification: **"+("PASS" if report["qualification"]["qualified"] else "UNMET / NOT ESTABLISHED")+"**."]
    lines += ["- "+d for d in report["qualification"].get("deficits", [])]
    return "\n".join(lines)+"\n"


def write_snapshot(output, report):
    if report.get("sha256") != digest({k:v for k,v in report.items() if k != "sha256"}):
        raise ValueError("Audit snapshot seal changed")
    directory = Path(output)/("audit_"+report["sha256"])
    contents = {"report.json": (json.dumps(report,sort_keys=True,ensure_ascii=True,indent=2,allow_nan=False)+"\n").encode(),
        "report.md": markdown(report).encode()}
    if directory.exists():
        if any(not (directory/k).is_file() or (directory/k).read_bytes() != v for k,v in contents.items()):
            raise ValueError("Immutable audit directory already exists with different content")
    else:
        directory.mkdir(parents=True)
        for name, raw in contents.items():
            with (directory/name).open("xb") as f: f.write(raw)
    return dict(directory=str(directory), sha256=report["sha256"],
        files={k:hashlib.sha256(v).hexdigest() for k,v in contents.items()})
