"""Private source-aware nomination; never imported by ordinary inference."""
from collections import Counter
from copy import deepcopy
import hashlib
from pathlib import Path
import re

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest
from .planning import obj
from .workflow import put,put_immutable,read


VERSION = "next-source-first-curation/6"
PROMPT = """Select natural, historically situated analyst questions from these
source-cited sensitive/revealed excerpts. Use only supplied text; extraction
annotations are fallible. Follow the nominated task for each pack. Prefer
substantive connected episodes and nontrivial questions, not source metadata or
obvious identity giveaways. Write one coherent question/request, not a list of
preselected atoms. H tests a claim; R asks for an inspectable account of the
source's substantive facts. Keep important uncertainty and attribution scope.
You may propose a few natural, time-scoped alternative hypotheses, marking each
deliberately altered; never invent their source or call absence opposition.
For Red choose a complete meaningful source span; CIB must use the authenticated
mask/key, while cable masks are synthetic. Keep enough surrounding context and
never supply a fill to the later planner. Cite exact supplied quotations with
source IDs. Prior lexical diagnostics are difficulty information, not proof of
absence or recoverability. Return at most the requested number, and hold bad
packs honestly. Do not generate atoms, leads, keywords, verdicts or expected
success labels. The later solver is independent; do not write to fit a matcher."""


def schema(task=None):
    string = dict(type="string")
    quote = obj(dict(source_id=string, text=string))
    row = obj(dict(pack_id=string, query=string, birth_quotes=dict(type="array", items=quote),
        hidden_quote=dict(type="string") if task == "redaction" else dict(type=["string", "null"]), deliberately_altered=dict(type="boolean"),
        analyst_value=string, mask_giveaway_risk=dict(type="boolean"),
        hold_reason=dict(type=["string", "null"])))
    return obj(dict(cases=dict(type="array", items=row)))


def _mask_window(text, start, end, marker):
    from .readings import _model
    # Source sentence segmentation only; do not parse hypothetical completed fills.
    spans = list(_model()(text).sents)
    hits = [i for i,s in enumerate(spans) if s.start_char <= start < s.end_char]
    if len(hits) != 1:
        raise ValueError("Synthetic target has no complete source-sentence attachment")
    i = hits[0]
    last = next((j for j in range(i,len(spans)) if spans[j].end_char >= end),None)
    if last is None:
        raise ValueError("Synthetic target is clipped at a source boundary")
    # Keep the paragraph when short; otherwise retain its neighboring sentences.
    left = text.rfind("\n\n",0,start)+2 if "\n\n" in text[:start] else 0
    right = text.find("\n\n",end)
    right = len(text) if right < 0 else right
    if right-left > 1600:
        left, right = spans[max(0,i-1)].start_char, spans[min(len(spans)-1,last+1)].end_char
    return text[left:start]+marker+text[end:right], left, right


def sources(pack):
    focus = pack["literal_context"]
    rows = [dict(source_id=pack["pack_id"]+":focus", text=focus["text"],
        start=focus["start"], coordinate_space=focus["coordinate_space"],
        parent_text_sha256=focus["parent_text_sha256"])]
    for index, unit in enumerate(pack["source"].get("adjacent_units", [])):
        text = unit.get("later_text") or unit.get("earlier_text")
        if text:
            rows.append(dict(source_id=pack["pack_id"]+":context"+str(index), text=text,
                start=0, coordinate_space="EXPLICIT_CANONICAL_ADJACENT_UNIT",
                parent_text_sha256=digest(unit)))
    return rows


def payload(packs, requested=20):
    rows = []
    for pack in packs:
        annotations, seen = [], set()
        source_rows = sources(pack)
        literal = "\n".join(s["text"] for s in source_rows)
        for item in pack["objects"]:
            native = item.get("annotation", {})
            quotation = native.get("evidence_quote", native.get("evidence", ""))
            if not isinstance(quotation, str) or not quotation or quotation not in literal:
                continue
            label = native.get("claim_text", native.get("label", native.get("name", "")))
            record = dict(local_id=item.get("local_id"), kind=item["kind"], label=label,
                source=native.get("source"), target=native.get("target"), relation=native.get("relation"))
            signature = digest(record)
            if signature not in seen:
                annotations.append(record); seen.add(signature)
            if len(annotations) == 12:
                break
        prior = pack.get("prior_diagnostics", {})
        rows.append(dict(pack_id=pack["pack_id"], corpus=pack["corpus"], task=pack["task"],
            origin=pack["origin"], sources=source_rows, objects=annotations,
            source_annotation_count=len(pack["objects"]),
            annotation_compaction="SOURCE_QUOTATIONS_RETAINED_IN_FULL_CONTEXT_NOT_DUPLICATED_PER_OBJECT",
            nomination=pack["nomination"], difficulty=pack["difficulty"],
            prior_difficulty=deepcopy(prior),
            authentic_redaction=pack.get("authentic_redaction")))
    return dict(exposure="SOURCE_AWARE_CURATION_NOT_BLIND_INFERENCE", requested=requested,
        packs=rows, no_native_results_or_grades=True)


def _exact(source, quote):
    text = source["text"]
    if not isinstance(quote, str) or not quote:
        raise ValueError("Nonempty exact source quotation required")
    at = text.find(quote)
    if at < 0:
        from .quotations import locate
        at,_,quote,_ = locate(text,quote,allow_layout=True)
    if not quote or at < 0 or text.find(quote, at+1) >= 0:
        raise ValueError("Birth quotation must be an unambiguous exact source excerpt")
    return dict(source_id=source["source_id"], text=quote, start=at, end=at+len(quote),
        coordinate_space=source["coordinate_space"], source_text_sha256=digest(text),
        parent_text_sha256=source["parent_text_sha256"])


def bind_proposals(packs, output):
    from jsonschema import validate
    validate(output, schema())
    by_id = {p["pack_id"]:p for p in packs}
    cases, private, rejected, seen = [], [], [], set()
    for row in output["cases"]:
        try:
            if row["pack_id"] not in by_id or row["pack_id"] in seen:
                raise ValueError("Duplicate or unprovided source pack")
            seen.add(row["pack_id"])
            pack = by_id[row["pack_id"]]
            from .admission import source_difficulty_hold
            if source_difficulty_hold(pack):
                raise ValueError("DEMO_DIFFICULTY_HOLD_STRICT_PRIOR_LITERAL; canonical population unchanged")
            if row["hold_reason"]:
                raise ValueError("CURATOR_HOLD: " + row["hold_reason"])
            src = {s["source_id"]:s for s in sources(pack)}
            quotes = [_exact(src[q["source_id"]], q["text"]) for q in row["birth_quotes"]]
            if not quotes:
                raise ValueError("No exact birth-of-question quotation")
            if not any(q["source_id"].endswith(":focus") for q in quotes):
                raise ValueError("Visible context alone cannot supply hidden target content")
            query, marker, key, mask_map = row["query"].strip(), "", None, None
            if pack["task"] == "redaction":
                if row["mask_giveaway_risk"]:
                    raise ValueError("CURATOR_TRIVIAL_MASK_DIFFICULTY_HOLD")
                marker = "[REDACTION 1]"
                if pack.get("authentic_redaction"):
                    target = pack["authentic_redaction"]
                    query, marker, key = target["query"], target["focus_marker"], target["answer"]
                    if row["hidden_quote"] != key:
                        raise ValueError("CIB proposal altered the authenticated hidden span")
                else:
                    key = row["hidden_quote"]
                    focused = _exact(src[pack["pack_id"]+":focus"], key)
                    raw = src[pack["pack_id"]+":focus"]["text"]
                    query, window_start, window_end = _mask_window(raw,focused["start"],focused["end"],marker)
                    if key.casefold() in query.casefold():
                        raise ValueError("Synthetic fill remains literally visible in question")
                    if query.replace(marker, key) != raw[window_start:window_end]:
                        raise ValueError("Synthetic mask fails source roundtrip")
                    mask_map = dict(source_id=pack["pack_id"]+":focus",start=window_start,end=window_end,
                        text=raw[window_start:window_end],hidden_start=focused["start"],hidden_end=focused["end"],
                        source_text_sha256=digest(raw),literal_roundtrip=True)
                    if source_difficulty_hold(pack,literal_window=mask_map["text"]):
                        raise ValueError("DEMO_DIFFICULTY_HOLD_COMPLETE_PRIOR_MASK_WINDOW_COPY")
                if row["deliberately_altered"]:
                    raise ValueError("An authentic/source-faithful mask is not a falsified proposition")
            case = public_case(dict(case_id="next_"+digest([VERSION,pack["pack_id"],query])[:24],
                corpus=pack["corpus"], task=pack["task"], query=query,
                document_id=pack["origin"]["document_id"], date=pack["origin"]["date"], focal_marker=marker))
            cases.append(case)
            private.append(dict(case_id=case["case_id"], pack_id=pack["pack_id"],
                source_quotes=quotes, sources=list(src.values()), answer=key,
                mask_map=mask_map,
                altered=row["deliberately_altered"], analyst_value=row["analyst_value"],
                source_admission="SOURCE_CITED_NOMINEE_SEMANTIC_REVIEW_NOT_GOLD",
                dependency=deepcopy(pack["dependency"]), exposure="SOURCE_AWARE_DEVELOPMENT"))
        except (ValueError, KeyError) as error:
            rejected.append(dict(pack_id=row.get("pack_id"), reason=str(error)))
    return dict(cases=cases, private=private, rejected=rejected,
        counts=dict(Counter(c["corpus"]+":"+c["task"] for c in cases)),
        source_qc_is_not_entailment_or_difficulty_gold=True)


def curate(packs, output_root, api_root, *, cap=25., requested=20, model=None):
    from matryoshka_demo.api_v2 import call
    packet = payload(packs, requested)
    tasks = {p["task"] for p in packs}
    if len(tasks) != 1:
        raise ValueError("Curation batches must have one explicitly named task")
    task = next(iter(tasks))
    frame = ("This entire batch is REDACTION: return a literal nonempty hidden_quote and the "
        "source sentence with exactly that span masked as [REDACTION 1]; do not write a reconstruction question. "
        "For a held item, hidden_quote may be empty. " if task == "redaction" else
        "This entire batch is HYPOTHESIS: formulate a concise, testable claim or connected claims "
        "as a natural analyst question (for example, 'Assess whether Mira resigned from the council "
        "and challenged its legality'). Do not substitute an open-ended request for explanations "
        "or a quiz about this document. Choose a specific substantive episode, not every topic "
        "in the excerpt. Keep hidden_quote null. " if task == "hypothesis" else
        "This entire batch is RECONSTRUCTION: write a concise natural request to reconstruct one "
        "specified substantive account, naming its actual components in fluent prose (for example, "
        "'Reconstruct Mira's resignation from the council and presidency, including her challenge "
        "to its legality'). Do not invent a new why-question or demand inferences beyond the "
        "supplied source account. Choose one episode, not every topic. Keep hidden_quote null. ")
    red_prompt = ("Create source-faithful redaction examples, not questions about a report. "
        "For each selected cable choose one meaningful complete name, role, property, quantity, "
        "action or clause verbatim from the focus text as hidden_quote; mask it exactly once "
        "with [REDACTION 1] and retain its surrounding sentence context. It is fine to choose "
        "one incident from a multi-topic document or mask a qualified/reported claim while "
        "preserving its qualifications. Do not reject such material just because it is complex. "
        "For CIB keep the supplied authentic mask and answer exactly. Avoid metadata, clipped "
        "words, purely connective spans or names immediately given away by an adjacent title. "
        "Cite exact source excerpts and source IDs. Select up to the requested count, keeping "
        "hidden_quote nonempty for accepted items. Hold only genuinely unsuitable material; "
        "a held item may have empty hidden_quote. Do not produce atoms, leads, readings, "
        "search terms, answers for the future solver, or recovery forecasts.")
    prompt, contract = (red_prompt if task == "redaction" else frame + PROMPT), schema(task)
    policy_pins={name:hashlib.sha256((Path(__file__).parent/name).read_bytes()).hexdigest()
        for name in ("curation.py","admission.py","quotations.py")}
    identity = digest([VERSION,packet,prompt,contract,policy_pins])
    root = Path(output_root)/identity
    put_immutable(root/"private_input.json", packet)
    raw, receipt = call(api_root, "next_source_curation_v4", packet, prompt, contract,
        model=model or ("gpt-6.1-sol" if task == "redaction" else "gpt-6-luna"),
        max_output_tokens=16000, cap=cap)
    raw_path=root/"raw_result.json"
    if raw_path.exists():
        previous=read(raw_path)
        if previous["output"]!=raw:
            raise ValueError("Saved curator output differs from the exact provider cache")
    else:
        put_immutable(raw_path,dict(output=raw, receipt=receipt))
    bound = bind_proposals(packs, raw)
    put_immutable(root/"public_cases.json", dict(version=VERSION,cases=bound["cases"]))
    put_immutable(root/"private_proofs.json", dict(version=VERSION,cases=bound["private"]))
    put_immutable(root/"qc.json", {k:v for k,v in bound.items() if k not in {"cases","private"}})
    put_immutable(root/"policy.json",dict(version=VERSION,code_pins=policy_pins,api_request_sha256=receipt["request_sha256"]))
    return root, bound
