"""Isolated caller-certified constraint ledger, NOT an adopted task solver.

Callers certify source eligibility, entailment, identity, event binding and time
semantics. This helper checks declared bindings/time arithmetic; it cannot infer
those certificates from exact quotes, graph labels or source publication dates.
Declare required binding variables/checks, create separate branches, then record
evidence and constrain each branch using the SAME bindings. Time permission does
not create factual opposition; complete_scope is a separate caller certificate.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass, field
from datetime import date
import re


VERSION = "next-scoped-candidate-constraints/1"
FACT_STATES = {"SUPPORTED", "OPPOSED", "FEASIBLE", "NO_INFO", "CONFLICTED"}
CHECK_STATES = {"SATISFIED", "VIOLATED", "UNRESOLVED"}
TIME_KINDS = {"exact_occurrence", "uncertain_occurrence_window", "continuous_validity", "unknown"}


@dataclass(frozen=True)
class Interval:
    kind: str
    start: str | None = None
    end: str | None = None
    scope: str = ""
    complete: bool = False

    def __post_init__(self):
        if self.kind not in TIME_KINDS or type(self.complete) is not bool or not isinstance(self.scope, str):
            raise ValueError("Explicit supported time kind/completeness required")
        if self.complete and not self.scope:
            raise ValueError("Completeness must name its certified scope")
        if self.kind == "unknown":
            if self.start is not None or self.end is not None or self.complete:
                raise ValueError("Unknown time cannot carry dates or complete coverage")
            return
        if any(not isinstance(v, str) or date.fromisoformat(v).isoformat() != v for v in (self.start, self.end)):
            raise ValueError("Canonical ISO dates required; years are not inferred")
        if self.start > self.end or self.kind == "exact_occurrence" and self.start != self.end:
            raise ValueError("Invalid occurrence/validity interval")


def time_relation(left, right, *, quantifier, scope):
    """A declared interval comparison, not evidence that anyone fought together."""
    if quantifier not in {"existential", "fixed", "tour"} or not isinstance(scope, str) or not scope:
        raise ValueError("Explicit temporal quantifier and query scope required")
    uncertain = {"unknown", "uncertain_occurrence_window"}
    if left.kind in uncertain or right.kind in uncertain:
        state, reason = "UNRESOLVED", "UNKNOWN_OR_UNCERTAIN_OCCURRENCE_IS_NOT_TEMPORAL_COVERAGE"
    elif left.end < right.start or right.end < left.start:
        state, reason = "VIOLATED", "DECLARED_INSTANCE_INTERVALS_DISJOINT"
    elif quantifier == "fixed" and not (left.start <= right.start and left.end >= right.end):
        state, reason = "UNRESOLVED", "OVERLAP_DOES_NOT_ESTABLISH_WHOLE_FIXED_PERIOD"
    else:
        state, reason = "SATISFIED", "DECLARED_POSITIVE_TIME_COMPATIBILITY_ONLY"
    complete = all(i.kind == "continuous_validity" and i.complete and i.scope == scope for i in (left, right))
    return dict(state=state, reason=reason, quantifier=quantifier, scope=scope, left=asdict(left), right=asdict(right),
        opposition_permitted=state == "VIOLATED" and (quantifier in {"fixed", "tour"} or complete),
        person_level_opposition_permitted=state == "VIOLATED" and quantifier == "existential" and complete,
        co_fighting_established=False)


def join_bindings(*parts):
    """One assignment across ALL parts; None is unknown, never an identity join."""
    result = {}
    for part in parts:
        for key, value in part.items():
            if not isinstance(key, str) or not key or value is not None and (not isinstance(value, str) or not value):
                raise ValueError("Opaque bound IDs or explicit unknowns required")
            if result.get(key) is not None and value is not None and result[key] != value:
                raise ValueError("Incompatible joint identity/event assignment")
            if key not in result or result[key] is None:
                result[key] = value
    return result


def _factual_state(rows):
    states = {r["state"] for r in rows}
    if "CONFLICTED" in states or {"SUPPORTED", "OPPOSED"} <= states:
        return "CONFLICTED"
    return next((state for state in ("SUPPORTED", "OPPOSED", "FEASIBLE") if state in states), "NO_INFO")


def _check_state(rows):
    states = {row["state"] for row in rows}
    if {"SATISFIED", "VIOLATED"} <= states:
        return "UNRESOLVED"
    return next((s for s in ("VIOLATED", "SATISFIED") if s in states), "UNRESOLVED")


@dataclass
class CandidateCase:
    binding: dict
    required: dict
    required_checks: tuple = ()
    assignments: dict = field(default_factory=dict, init=False)

    def __post_init__(self):
        fields = ("case_id", "query_sha256", "reading_id", "candidate_id", "source_binding_sha256", "query_scope")
        if any(not isinstance(self.binding.get(k), str) or not self.binding[k] for k in fields):
            raise ValueError("Complete query/reading/candidate/source/scope binding required")
        if any(not re.fullmatch(r"[0-9a-f]{64}", self.binding[k]) for k in ("query_sha256", "source_binding_sha256")):
            raise ValueError("Canonical query and source digest pins required")
        self.binding = deepcopy(self.binding)
        self.required = {key: tuple(values) for key, values in self.required.items()}
        if not self.required or any(not key or not values or len(set(values)) != len(values)
                                    or any(not isinstance(v, str) or not v for v in values) for key, values in self.required.items()):
            raise ValueError("Each required criterion needs its exact shared binding variables")
        if len(set(self.required_checks)) != len(self.required_checks):
            raise ValueError("Duplicate constraint names")
        self.required_checks = tuple(self.required_checks)

    def branch(self, identity, bindings):
        bindings = join_bindings(bindings)
        if not isinstance(identity, str) or not identity or identity in self.assignments:
            raise ValueError("New distinct assignment ID required")
        self.assignments[identity] = dict(bindings=bindings, evidence={k: [] for k in self.required}, checks={})

    def _citations(self, citations, *, required=True):
        expected = {k: self.binding[k] for k in ("case_id", "query_sha256", "source_binding_sha256")}
        if required and not citations:
            raise ValueError("Positive/negative evidence and constraints require source citations")
        for ref in citations:
            a, b, text = ref.get("start"), ref.get("end"), ref.get("text")
            if (ref.get("source_authorized") is not True or ref.get("authorization") != expected
                    or not ref.get("canonical_page_id") or not ref.get("document_id")
                    or not re.fullmatch(r"[0-9a-f]{64}", ref.get("page_sha256", ""))
                    or type(a) is not int or type(b) is not int or not isinstance(text, str)
                    or not text or a < 0 or b - a != len(text)):
                raise ValueError("Exact caller-authorized citation metadata/binding required")
            if date.fromisoformat(ref["date"]).isoformat() != ref["date"]:
                raise ValueError("Canonical source publication date required")
        return deepcopy(citations)

    def record(self, assignment, criterion, state, citations, *, bindings, context=False, complete_scope=None):
        branch = self.assignments[assignment]
        if criterion not in self.required or state not in FACT_STATES:
            raise ValueError("Declared criterion and factual state required")
        if type(context) is not bool or context and state not in {"SUPPORTED", "FEASIBLE"}:
            raise ValueError("Only caller-certified positive context can be feasible")
        if state != "NO_INFO" and not bindings:
            raise ValueError("A positive or negative clue must bind to this assignment")
        if any(value is None or branch["bindings"].get(key) != value for key, value in bindings.items()):
            raise ValueError("Evidence cannot change or guess an assignment's bound instance")
        if state in {"SUPPORTED", "OPPOSED", "CONFLICTED"} and not context and any(
                not bindings.get(key) for key in self.required[criterion]):
            raise ValueError("Signed evidence needs every required identity/event variable")
        if complete_scope is not None and complete_scope != self.binding["query_scope"]:
            raise ValueError("Completeness does not cover this query's scope")
        if context:
            state, complete_scope = "FEASIBLE", None
        row = dict(state=state, bindings=deepcopy(bindings), context_only=context, complete_scope=complete_scope,
                   citations=self._citations(citations, required=state != "NO_INFO"))
        if row not in branch["evidence"][criterion]:
            branch["evidence"][criterion].append(row)

    def constrain(self, assignment, name, check, citations, *, bindings):
        if name not in self.required_checks or check.get("state") not in CHECK_STATES:
            raise ValueError("Declared constraint name/state required")
        branch = self.assignments[assignment]
        if not bindings or any(value is None or branch["bindings"].get(key) != value for key, value in bindings.items()):
            raise ValueError("Constraint certificate belongs to another or unknown assignment")
        if check["state"] != "UNRESOLVED" and any(not bindings.get(key) for keys in self.required.values() for key in keys):
            raise ValueError("Resolved constraints need the complete declared joint binding")
        row = dict(deepcopy(check), bindings=deepcopy(bindings), citations=self._citations(citations))
        history = branch["checks"].setdefault(name, [])
        if row not in history:
            history.append(row)

    def snapshot(self):
        branches, supported, opposite, feasible, conflicted = deepcopy(self.assignments), [], False, False, False
        for identity, branch in branches.items():
            states = {k: _factual_state(rows) for k, rows in branch["evidence"].items()}
            checks = {k: _check_state(branch["checks"].get(k, [])) for k in self.required_checks}
            rejected = "VIOLATED" in checks.values()
            branch.update(criterion_states=states, constraint_states=checks,
                route_state="INCOMPATIBLE_ROUTE" if rejected else "OPEN_ROUTE",
                route_rejections=[dict(check=k, certificate=row) for k, rows in branch["checks"].items()
                                  for row in rows if row["state"] == "VIOLATED"])
            if all(s == "SUPPORTED" for s in states.values()) and all(s == "SATISFIED" for s in checks.values()):
                supported.append(identity)
            feasible |= not rejected and any(s in {"SUPPORTED", "FEASIBLE"} for s in states.values())
            conflicted |= "CONFLICTED" in states.values()
            opposite |= any(row["state"] in {"OPPOSED", "CONFLICTED"} and row["complete_scope"] == self.binding["query_scope"]
                            for rows in branch["evidence"].values() for row in rows)
        state = ("CONFLICTED" if supported and opposite else "SUPPORTED" if supported else "OPPOSED" if opposite
                 else "CONFLICTED" if conflicted else "FEASIBLE" if feasible else "NO_INFO")
        return dict(version=VERSION, binding=deepcopy(self.binding), required=deepcopy(self.required),
            required_checks=list(self.required_checks), assignments=branches, candidate_state=state,
            supported_assignment_ids=supported, source_policy_replayed_here=False,
            semantic_entailment_or_completeness_inferred_here=False, independent_witness_counts_not_computed=True,
            time_permission_is_not_automatic_factual_opposition=True, constructor_integrated=False)
