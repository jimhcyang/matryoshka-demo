"""Explicit post-run assessment. Never imported by retrieval or task execution."""
from copy import deepcopy

from jsonschema import validate
from matryoshka_demo.io import digest
from .planning import obj


VERSION = "next-exact-packet-assessment/2"
PROMPT = ("Assess the saved output, not an answer you recall. Use only this query, "
    "reference fill when supplied, and the quoted candidate evidence. For redaction "
    "judge full-slot correctness separately from whether the supplied corpus "
    "quotation establishes the missing claim. An unsupported right guess can be "
    "correct; an attested but wrong fill is incorrect. Equivalent means the same "
    "meaning in this sentence, partial means an integral but incomplete element. "
    "For other tasks judge each saved local decision against its scoped requirement "
    "and quotations. Missing evidence is not opposition. Preserve actor, event, "
    "date, polarity, attribution and uncertainty; do not consult history or the web. "
    "Return exactly one assessment per supplied item. Do not rewrite or rerank it.")


def schema():
    string = dict(type="string")
    row = obj(dict(item_id=string,
        judgment=dict(type="string", enum=["correct", "equivalent", "partial", "incorrect", "unjudgeable"]),
        evidence=dict(type="string", enum=["supported", "opposed", "partial", "context", "unresolved"]),
        local_decision_warranted=dict(type="string", enum=["yes", "no", "uncertain"]),
        explanation=string))
    return obj(dict(items=dict(type="array", items=row)))


def packet_input(packet, *, reference_answer=None):
    """Private keys enter only this explicitly post-run boundary."""
    if not str(packet.get("version", "")).startswith("next-"):
        raise ValueError("Only new native packets can be assessed here")
    case, result = packet["case"], packet["result"]
    items, seen = [], set()
    if case["task"] == "redaction":
        if not isinstance(reference_answer, str) or not reference_answer:
            raise ValueError("Recovery assessment requires a separately held reference fill")
        for branch in result["readings"]:
            rid = branch.get("reading_id", branch.get("reading", {}).get("id"))
            for row in branch["candidates"]:
                if not 1 <= row["rank"] <= 5:
                    continue
                identity = rid + "/" + row["id"]
                if identity in seen:
                    raise ValueError("Duplicate displayed assessment subject")
                seen.add(identity)
                items.append(dict(item_id=identity, reading_id=rid, candidate_id=row["id"],
                    fill=row["fill"], rank=row["rank"], local_decision=deepcopy(row["local_decision"]),
                    quotes=deepcopy(row.get("sources", []))))
    else:
        if reference_answer is not None:
            raise ValueError("H/R assessments do not take a redaction answer")
        for row in result["atoms"]:
            if not row.get("required"):
                continue
            if row["id"] in seen:
                raise ValueError("Duplicate assessment component")
            seen.add(row["id"])
            items.append(dict(item_id=row["id"], requirement=row["text"],
                local_decision=row["status"],
                quotes=deepcopy(row.get("evidence", [])),
                counterquotes=deepcopy(row.get("counterevidence", [])),
                answers=deepcopy(row.get("answers", []))))
    return dict(version=VERSION, packet_sha256=digest(packet), task=case["task"],
        query=case["query"], focal_marker=case["focal_marker"],
        reference_answer=reference_answer, reference_answer_sha256=digest(reference_answer),
        items=items, postrun_only=True,
        no_external_sources=True)


def bind(packet, payload, response, *, receipt=None):
    validate(response, schema())
    if digest(packet) != payload["packet_sha256"]:
        raise ValueError("Assessment packet identity changed")
    if payload != packet_input(packet,reference_answer=payload.get("reference_answer")):
        raise ValueError("Assessment inputs differ from the exact saved inference packet")
    expected = {x["item_id"]:x for x in payload["items"]}
    actual = [r["item_id"] for r in response["items"]]
    if len(set(actual)) != len(actual) or set(actual) != set(expected):
        raise ValueError("Missing, duplicate or unprovided assessment subjects")
    reviews = []
    for row in response["items"]:
        subject = expected[row["item_id"]]
        reviews.append(dict(row, packet_sha256=digest(packet),
            reading_id=subject.get("reading_id"), candidate_id=subject.get("candidate_id",subject["item_id"]),
            model_assessment_not_gold=True, receipt=deepcopy(receipt)))
    return dict(version=VERSION, packet_sha256=digest(packet), reviews=reviews,
        request_payload_sha256=digest(payload), raw_response_sha256=digest(response),
        postrun_only=True, inference_modified=False)


def assess(packet, api_root, *, reference_answer=None, cap=25., model="gpt-6.1-sol"):
    from matryoshka_demo.api_v2 import call
    payload = packet_input(packet, reference_answer=reference_answer)
    if not payload["items"]:
        return bind(packet,payload,dict(items=[]),receipt=dict(no_displayed_subjects=True,api_calls=0))
    raw, receipt = call(api_root,"next_postrun_assessment_v1",payload,PROMPT,schema(),
        model=model,max_output_tokens=12000,cap=cap)
    return bind(packet,payload,raw,receipt=receipt)
