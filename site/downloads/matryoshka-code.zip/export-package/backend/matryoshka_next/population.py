"""Approved exposure-aware population replay, never a benchmark execution.

The workspace root is the IARPA root, not src-demo-day. No caller-selectable
overlay or latest pointer can restore the older potentially-reserved split.
Resource/index authority and per-query source eligibility remain separate.
"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path


VERSION = "next-exposure-population-preflight/2"
EXPOSURE_RELEASE_VERSION = "next-hidden-source-curation-exposure/2/release"
ADAPTER_REF = {
    "path": "src-demo-day/experiments/current_refresh/exposure_overlay_next_v02/adapter.py",
    "sha256": "64b0802a1b23448847a0c7f6f0ad1444ae76b6f624368294d956a52850bd9a45",
}
MANIFEST_REF = {
    "path": "src-demo-day/experiments/current_refresh/exposure_overlay_next_v02/releases/bffd5b6d17b92bdcc1826d2a/manifest.json",
    "sha256": "4c41bf3a5156a72d228a15aea9dfdd61160632b33e89bb228f8c7648a106a0d7",
}
OVERLAY_REF = {
    "path": "src-demo-day/experiments/current_refresh/exposure_overlay_next_v02/releases/bffd5b6d17b92bdcc1826d2a/overlay.json",
    "sha256": "58fdb36755491b576c2f47152007ff3e8dd4a5c2e409b3649f8df330cf178a53",
}
PARENT_OVERLAY_REF = {
    "path": "src-demo-day/experiments/current_refresh/exposure_overlay_next_v01/releases/e416369a14cf8655591a94d7/overlay.json",
    "sha256": "28014e745f09b9ccb3f0f426b93904b5b1424d397d774549490ae5bdbbf8c307",
}
INVENTORY_REF = {
    "path": "src-demo-day/experiments/current_refresh/exposure_overlay_next_v02/inventories/cf98df3b0b59383d3b5f083c.json",
    "sha256": "364bb0e8f0f7b90a7963b5c62de6f19a644434e0bb95413463a7c25a77433df4",
}
BASE_REF = {
    "path": "matryoshka_redaction/data/canonical_redaction/jobs/cib_r6_top5_v1/public_population.json",
    "sha256": "fcc61a71022a3cae92e9635ec095bd14253d9d552cc0d2f3eb475363398c46ea",
}


class PopulationError(ValueError):
    """Approved source-exposure replay is unavailable or inconsistent."""


def _read(root, ref, pins):
    name = ref.get("path")
    if (not isinstance(name, str) or not name or "\\" in name or Path(name).is_absolute()
            or any(p in {"", ".", ".."} for p in name.split("/"))):
        raise PopulationError("Explicit workspace-relative preflight reference required")
    path = root / name
    if path.resolve(strict=True) != path or not path.is_file():
        raise PopulationError("Symlinked or missing preflight evidence")
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != ref.get("sha256"):
        raise PopulationError("Approved preflight byte pin changed: " + name)
    if name in pins and pins[name] != ref["sha256"]:
        raise PopulationError("Conflicting preflight reference")
    pins[name] = ref["sha256"]
    return raw


def _json(raw):
    def pairs(values):
        result = {}
        for key, value in values:
            if key in result:
                raise PopulationError("Duplicate preflight manifest field")
            result[key] = value
        return result
    def invalid(_):
        raise PopulationError("Nonfinite preflight manifest value")
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def load_population(workspace_root):
    """Return the exact approved merged population, with explicit nonauthorization.

    The pinned adapter freshly verifies v1 and all additional source-curation
    evidence. No inference, model, assessment or persistent trust cache is used.
    Errors propagate; there is no fallback to base labels or the older overlay.
    """
    root, pins = Path(workspace_root).resolve(), {}
    code_pin = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    try:
        manifest = _json(_read(root, MANIFEST_REF, pins))
        if (manifest.get("version") != EXPOSURE_RELEASE_VERSION
                or manifest.get("adapter_code_sha256") != ADAPTER_REF["sha256"]
                or manifest.get("overlay_ref") != OVERLAY_REF
                or manifest.get("parent_overlay_ref") != PARENT_OVERLAY_REF
                or manifest.get("inventory_ref") != INVENTORY_REF
                or manifest.get("native_outputs_modified") is not False
                or manifest.get("source_membership_changed") is not False):
            raise PopulationError("Approved exposure release contract differs")
        raw = _read(root, ADAPTER_REF, pins)
        path = root / ADAPTER_REF["path"]
        spec = importlib.util.spec_from_file_location("approved_next_exposure_adapter", path)
        adapter = importlib.util.module_from_spec(spec)
        # Execute the exact bytes just hashed, not a loader's second file read.
        exec(compile(raw, str(path), "exec"), adapter.__dict__)
        if adapter.PARENT_REF != PARENT_OVERLAY_REF or adapter.APPROVED_INVENTORY_REF != INVENTORY_REF:
            raise PopulationError("Approved adapter points to a different exposure minimum")
        result = adapter.load_population(root, deepcopy(BASE_REF), deepcopy(PARENT_OVERLAY_REF), deepcopy(OVERLAY_REF))
        if (result.get("exposure_overlay_ref") != OVERLAY_REF
                or result.get("additional_exposure_inventory_ref") != INVENTORY_REF
                or result.get("source_membership_changed") is not False
                or result.get("source_admission_changed") is not False
                or result.get("untouched_reserved_certified") is not False):
            raise PopulationError("Adapter did not return the approved effective exposure state")
        # The adapter replays these; retaining outer pins catches observed changes
        # between adapter verification and returning the stable entry point.
        for ref in (OVERLAY_REF, PARENT_OVERLAY_REF, INVENTORY_REF):
            _read(root, ref, pins)
        for name, expected in tuple(pins.items()):
            _read(root, dict(path=name, sha256=expected), {})
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != code_pin:
            raise PopulationError("Population wrapper changed during verification")
        result = deepcopy(result)
        result.update(population_preflight=dict(version=VERSION, wrapper_code_sha256=code_pin,
            adapter_ref=deepcopy(ADAPTER_REF), manifest_ref=deepcopy(MANIFEST_REF),
            overlay_ref=deepcopy(OVERLAY_REF), parent_overlay_ref=deepcopy(PARENT_OVERLAY_REF),
            inventory_ref=deepcopy(INVENTORY_REF), verified_outer_inputs_sha256=pins),
            status="EXPOSURE_REPLAY_ONLY_NOT_EVALUATION_READY", full_evaluation_authorized=False,
            source_eligibility_must_be_applied_per_query=True, native_resource_authority_certified=False,
            native_outputs_modified=False, benchmark_run=False, api_calls=0)
        return result
    except PopulationError:
        raise
    except (KeyError, TypeError, IndexError, OSError, ValueError) as error:
        raise PopulationError("Approved exposure population preflight failed") from error


def load(workspace_root):
    """Alias returning the same population object shape as load_population."""
    return load_population(workspace_root)


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace-root", type=Path, required=True)
    args = parser.parse_args(argv)
    population = load_population(args.workspace_root)
    print(json.dumps(dict(version=VERSION, status=population["status"],
        targets=population["targets"], documents=population["documents"],
        effective_partition_counts=population["partition_counts"],
        base_partition_counts=population["base_partition_counts"],
        additional_newly_exposed_targets=population["additional_newly_exposed_targets"],
        additional_newly_exposed_documents=population["additional_newly_exposed_documents"],
        untouched_reserved_certified=False, full_evaluation_authorized=False,
        benchmark_run=False, api_calls=0, population_preflight=population["population_preflight"]), sort_keys=True))


if __name__ == "__main__":
    main()
