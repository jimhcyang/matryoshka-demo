"""Post-run source-pool diagnosis; never used as an inference or ranking input."""
from copy import deepcopy

from jsonschema import validate
from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from .planning import obj


VERSION="next-source-pool-diagnosis/1"
PROMPT=("Diagnose this completed development run using only the supplied query and "
    "eligible source pages. Do not use remembered history or external sources. For "
    "each requirement identify any genuinely supporting, opposing or partial "
    "source statements, retaining actor, event, time, polarity and reporting scope. "
    "Copy exact non-redacted quotations and page IDs. A relevant name, word overlap "
    "or a report about another occasion is not full support. Missing evidence is "
    "not opposition. State which generic matching capability appears responsible "
    "for a discrepancy. Do not rewrite the saved result or suggest a named-answer "
    "exception. This is a bounded inspected-page audit, not a corpus-completeness "
    "test; no quote found cannot establish unrecoverability.")


def schema():
    string=dict(type="string")
    quote=obj(dict(page_id=string,text=string))
    row=obj(dict(atom_id=string,judgment=dict(type="string",enum=["support","oppose","partial","unresolved"]),
        quotes=dict(type="array",items=quote),
        issue=dict(type="string",enum=["none","lexical_paraphrase","argument_binding","attribution",
            "temporal_scope","query_interpretation","source_availability","uncertain"]),explanation=string))
    return obj(dict(requirements=dict(type="array",items=row)))


def prepare(packet,context,*,page_cap=20):
    from .facts import SourcePolicy
    if packet["binding"] != context.index_ref:
        raise ValueError("Diagnostic source context differs from saved execution")
    if type(page_cap) is not int or not 1<=page_cap<=100:
        raise ValueError("Explicit one-to-one-hundred page audit budget required")
    policy=SourcePolicy(context.corpus,packet["case"],context.source_index)
    inspected=packet["result"]["inspected_page_ids"]
    if len(inspected)!=len(set(inspected)):
        raise ValueError("Duplicate inspected source identity")
    pages=[]
    for identity in inspected[:page_cap]:
        pi=context.corpus.page_index[identity]
        page=context.corpus.pages[pi]
        if not policy.allowed(pi) or digest(page["text"])!=page["source_sha256"]:
            raise ValueError("Inspected diagnostic source failed eligibility/replay")
        pages.append(dict(page_id=identity,document_id=page["document_id"],date=page["date"],text=page["text"],
            source_sha256=page["source_sha256"],opaque_spans_are_not_evidence=True))
    payload=dict(version=VERSION,case=deepcopy(packet["case"]),packet_sha256=digest(packet),
        requirements=[dict(id=a["id"],text=a["text"],query_spans=deepcopy(a["query_spans"]))
            for a in packet["plan"]["atoms"] if a["required"]],pages=pages,
        supplied_pages=len(pages),total_inspected_pages=len(inspected),
        complete_corpus_or_pool_audit=False,source_aware_development_only=True)
    return payload,policy


def bind(packet,payload,raw,policy):
    validate(raw,schema())
    if payload["packet_sha256"]!=digest(packet):
        raise ValueError("Diagnostic inference packet changed")
    expected={a["id"] for a in payload["requirements"]}
    actual=[a["atom_id"] for a in raw["requirements"]]
    if len(set(actual))!=len(actual) or set(actual)!=expected:
        raise ValueError("Diagnostic requirement identities differ")
    pages={p["page_id"]:p for p in payload["pages"]}
    output=deepcopy(raw)
    for row in output["requirements"]:
        bound=[]
        for quote in row["quotes"]:
            page=pages.get(quote["page_id"])
            if page is None or not quote["text"] or MASK.search(quote["text"]):
                raise ValueError("Diagnostic quotation is opaque or outside supplied pages")
            at=page["text"].find(quote["text"])
            if at<0 or page["text"].find(quote["text"],at+1)>=0:
                raise ValueError("Diagnostic quote is not unique literal supplied source text")
            pi=policy.corpus.page_index[page["page_id"]]
            bound.append(policy.citation(pi,at,at+len(quote["text"])))
        if row["judgment"]!="unresolved" and not bound:
            raise ValueError("Signed source diagnosis needs actual quotations")
        row["citations"]=bound
        row["model_opinion_not_gold"]=True
    return dict(version=VERSION,packet_sha256=digest(packet),payload_sha256=digest(payload),
        diagnosis=output,ordinary_inference_modified=False,source_aware_development_only=True,
        complete_corpus_audit=False)


def audit(packet,context,api_root,*,page_cap=20,cap=25.):
    from matryoshka_demo.api_v2 import call
    payload,policy=prepare(packet,context,page_cap=page_cap)
    raw,receipt=call(api_root,"next_source_pool_diagnosis_v1",payload,PROMPT,schema(),
        model="gpt-6.1-sol",max_output_tokens=10000,cap=cap)
    result=bind(packet,payload,raw,policy)
    return result,dict(input=payload,raw_output=raw,receipt=receipt)
