"""Literal focal-boundary view for an opt-in grammatical reader control."""
import re

from matryoshka_demo.contracts import MASK
from matryoshka_demo.io import digest
from . import readings

VERSION = "literal-focal-reading-boundary/1"
GUIDANCE = (
    " Focus on the ONE focal_marker. boundary_view contains exact visible words beside that gap. "
    "Other, distant masks do not make these boundaries opaque. An unknown identity/content does "
    "not itself make grammatical form unknown. Consider distinct plausible final surfaces, not "
    "only the parser's dummy noun: a gap after a complete noun can be a postmodifier; a gap "
    "before an already complete finite clause can introduce that clause. Do not assume either "
    "construction if the visible grammar conflicts. Choose only applicable legal templates and "
    "their own literal cues. These are grammatical possibilities, never hidden facts or fills."
)


def boundary_view(case, words=32):
    if set(case) != readings.PUBLIC_FIELDS or case["task"] != "redaction":
        raise ValueError("Exactly seven public Redaction fields required")
    if type(words) is not int or not 1 <= words <= 64:
        raise ValueError("One to64 literal boundary words required")
    query, marker = case["query"], case["focal_marker"]
    if not marker or query.count(marker) != 1:
        raise ValueError("One exact focal marker required")
    at, end = query.index(marker), query.index(marker) + len(marker)
    a = query.rfind("\n\n",0,at)
    a = 0 if a < 0 else a+2
    b = query.find("\n\n",end)
    b = len(query) if b < 0 else b
    left_masks = list(MASK.finditer(query[a:at]))
    right_mask = MASK.search(query[end:b])
    left_edge = a + left_masks[-1].end() if left_masks else a
    right_edge = end + right_mask.start() if right_mask else b
    left_tokens = list(re.finditer(r"\S+",query[left_edge:at]))
    right_tokens = list(re.finditer(r"\S+",query[end:right_edge]))
    la = left_edge + left_tokens[-words].start() if len(left_tokens) > words else left_edge
    rb = end + right_tokens[words-1].end() if len(right_tokens) > words else right_edge
    span = lambda s,e:dict(start=s,end=e,text=query[s:e])
    return dict(version=VERSION,query_sha256=digest(query),focal=span(at,end),
        left=span(la,at),right=span(end,rb),
        left_paragraph_boundary=at==a,right_paragraph_boundary=end==b,
        adjacent_left_mask=bool(left_masks) and not query[left_edge:at].strip(),
        adjacent_right_mask=bool(right_mask) and not query[end:right_edge].strip(),
        hidden_words_or_syntax_inferred=False,source_access=False)
