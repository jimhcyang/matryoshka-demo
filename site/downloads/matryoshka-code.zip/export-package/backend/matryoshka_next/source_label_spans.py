"""Own-occurrence label spans; layout rebinding never changes a lexical word."""
import re

from matryoshka_demo.contracts import MASK

VERSION = "bounded-own-source-label-layout/2"


def spans(text, start, end, label):
    if (not isinstance(text, str) or type(start) is not int or type(end) is not int
            or not 0 <= start < end <= len(text) or not isinstance(label, str)
            or not label or MASK.search(label)):
        return []
    quoted = text[start:end]
    exact = list(re.finditer(r"(?<!\w)" + re.escape(label) + r"(?!\w)", quoted, re.I))
    if exact:
        return [dict(start=start+m.start(), end=start+m.end(), text=m.group(),
                     mode="LITERAL_CASE_INSENSITIVE", record_label=label) for m in exact]
    words = label.split()
    if len(words) < 2:
        return []
    pattern = r"(?<!\w)(?=(" + r"\s+".join(re.escape(w) for w in words) + r")(?!\w))"
    matches = list(re.finditer(pattern, quoted, re.I))
    if len(matches) != 1:
        return []
    match = matches[0]
    lo, hi = start + match.start(1), start + match.end(1)
    word = lambda char: char.isalnum() or char == "_"
    if ((lo and word(text[lo]) and word(text[lo-1]))
            or (hi < len(text) and word(text[hi-1]) and word(text[hi]))):
        return []
    return [dict(start=lo, end=hi, text=match.group(1),
                 mode="UNIQUE_WHITESPACE_ONLY_LAYOUT", record_label=label)]
