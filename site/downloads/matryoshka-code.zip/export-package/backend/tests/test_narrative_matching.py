"""Independent contrasts for the opt-in source-frame supplement, API0."""
from copy import deepcopy
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments/narrative_demo/redteam"))
from narrative_redteam_fixtures import no_external_requests, public_case, source_fixture  # noqa: E402,F401
from matryoshka_narrative.matching import supplement_evidence, VERSION as MATCHING_VERSION  # noqa: E402
from matryoshka_demo.io import digest  # noqa: E402


def match(query, source, *, task="hypothesis"):
    case, plan, found, index = source_fixture(public_case(task, query), [source])
    page = index["p0"]
    unit = dict(start=0, end=len(source), text=source)
    before = deepcopy((case, plan, index))
    result = supplement_evidence(case, plan["atoms"][0], page, unit, source_index=index)
    assert before == (case, plan, index)
    assert result["citation"]["text"] == source
    assert not result["baseline_decision_modified"] and not result["source_text_modified"]
    assert not result["actual_inner_event_established"] and not result["world_truth_certified"]
    assert result["api_calls"] == 0
    return result


@pytest.mark.parametrize("task", ["hypothesis", "mosaic"])
@pytest.mark.parametrize("source", ["Oren Vale opened the gate.",
    "Oren Vale opened the gate. He left the building.",
    "Oren Vale opened the gate and Daria Venn closed the window.",
    "Daria Venn closed the window. Oren Vale opened the gate."])
def test_independent_extra_source_assertions_and_unrelated_pronouns_do_not_erase_a_positive(task, source):
    result = match("Oren Vale opened the gate.", source, task=task)
    assert result["direction"] == "SUPPORT", result
    assert result["complete_required_frames"]


@pytest.mark.parametrize("source", ["Daria Venn opened the gate.",
    "Oren Vale closed the gate.", "Oren Vale opened the window.",
    "Daria Venn said that Oren Vale opened the gate.",
    "Oren Vale might open the gate.", "If Oren Vale opened the gate, Daria Venn would leave.",
    "Oren Vale will open the gate.", "Oren Vale was opening the gate.",
    "Oren Vale opening the gate.", "Oren Vale opened the gate or Daria Venn closed the window."])
def test_actor_predicate_object_reporting_modality_condition_tense_aspect_and_disjunction_do_not_loosen(source):
    result = match("Oren Vale opened the gate.", source)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


@pytest.mark.parametrize("source", ["The director opened the gate.", "The country opened the gate."])
def test_common_title_or_country_is_not_an_actor_identity_certificate(source):
    result = match(source, source)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result
    assert any("ACTOR_OR_HOLDER_IDENTITY_NOT_BOUND_BY_LITERAL_NAME" in m["narrative_guard_issues"]
        for row in result["comparisons"] for m in row), result


def test_same_name_with_different_owned_role_discriminators_is_not_same_actor():
    result = match("Mira, the secretary, opened the gate.", "Mira, the physician, opened the gate.")
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


def test_every_required_query_frame_needs_coverage_not_just_the_first_matching_leaf():
    result = match("Oren Vale opened the gate and Daria Venn closed the window.",
        "Oren Vale opened the gate.")
    assert result["required_frame_count"] == 2
    assert not result["complete_required_frames"]
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}


def test_repeated_preposition_not_represented_by_the_old_frame_extractor_cannot_be_dropped():
    result = match("Oren Vale resigned from the council and from the ministry.",
        "Oren Vale resigned from the council.")
    assert result["direction"] in {"PARTIAL", "UNRESOLVED"}, result
    assert not result["complete_required_frames"]
    assert result["uncovered_query_tokens"], result


@pytest.mark.parametrize("source", ["Oren Vale sent four crates to Daria Venn in Oslo.",
    "Oren Vale sent three books to Daria Venn in Oslo.",
    "Oren Vale sent three crates to Daria Venn in Lima.",
    "Daria Venn sent three crates to Oren Vale in Oslo."])
def test_quantities_locations_patient_kinds_and_role_direction_are_noncompensatory(source):
    result = match("Oren Vale sent three crates to Daria Venn in Oslo.", source)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


def test_undated_opposite_does_not_borrow_the_source_publication_clock():
    result = match("Oren Vale opened the gate.", "Oren Vale did not open the gate.")
    assert result["direction"] not in {"COUNTER", "CONFLICTED", "SUPPORT"}, result


def test_identical_untimed_negative_does_not_gain_a_shared_event_clock_from_literal_equality():
    text = "Oren Vale did not open the gate."
    result = match(text, text)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


def test_qualified_report_of_negative_content_is_not_an_untimed_world_negative():
    text = "Mira Soren said that Oren Vale did not open the gate."
    result = match(text, text)
    assert result["direction"] == "SUPPORT", result
    assert not result["actual_inner_event_established"]


def test_untimed_negation_of_the_reporting_event_is_not_negation_of_reported_content():
    text = "Mira Soren did not say that Oren Vale opened the gate."
    result = match(text, text)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result
    assert result["whole_clause_certificate"] is None


def test_different_explicit_event_day_is_not_opposition():
    result = match("Oren Vale opened the gate on May 1, 1971.",
        "Oren Vale did not open the gate on May 2, 1971.")
    assert result["direction"] not in {"COUNTER", "CONFLICTED", "SUPPORT"}, result


def test_same_explicit_event_day_can_establish_a_signed_opposite():
    result = match("Oren Vale opened the gate on May 1, 1971.",
        "Oren Vale did not open the gate on May 1, 1971.")
    assert result["direction"] == "COUNTER", result
    assert not result["publication_date_used_as_event_time"]


def test_complete_attributed_uncertain_content_remains_qualified_not_a_performed_inner_event():
    text = "Mira Soren said that Oren Vale might open the gate."
    result = match(text, text)
    assert result["direction"] == "SUPPORT", result
    assert not result["actual_inner_event_established"]


def test_named_holder_can_attest_literal_common_inner_content_without_certifying_inner_identity():
    text = "Mira Soren said that the peace proposal might fail."
    result = match(text, text)
    assert result["direction"] == "SUPPORT", result
    assert not result["actual_inner_event_established"]


def test_named_inner_actor_cannot_substitute_for_an_unbound_reporting_holder():
    text = "The director said that Oren Vale opened the gate."
    result = match(text, text)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result
    assert any("ACTOR_OR_HOLDER_IDENTITY_NOT_BOUND_BY_LITERAL_NAME" in m["narrative_guard_issues"]
        for row in result["comparisons"] for m in row), result


def test_another_named_reporting_holder_does_not_attest_the_requested_utterance():
    result = match("Mira Soren said that Oren Vale opened the gate.",
        "Daria Venn said that Oren Vale opened the gate.")
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


def test_asserted_order_with_negative_requested_action_does_not_establish_the_inner_event():
    text = "Mira Soren ordered Oren Vale not to engage the patrol."
    result = match(text, text)
    assert result["direction"] == "SUPPORT", result
    assert not result["actual_inner_event_established"]
    certificate = result["whole_clause_certificate"]
    assert certificate["raw_byte_equality"]
    assert certificate["source_attestation_not_persistence"]
    assert not certificate["embedded_event_execution_certified"]
    assert result["uncovered_query_tokens"]  # No invented claim that leaf compilation was complete.


def test_opposite_negation_attachment_is_not_support_for_the_order_or_inner_event():
    result = match("Mira Soren ordered Oren Vale not to engage the patrol.",
        "Mira Soren did not order Oren Vale to engage the patrol.")
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


@pytest.mark.parametrize("query", ["The director ordered Oren Vale not to engage the patrol.",
    "Mira Soren did not order Oren Vale to engage the patrol.",
    "Mira Soren orders Oren Vale not to engage the patrol.",
    "Mira Soren is commander of Sector III.",
    "Mira Soren ordered Oren Vale not to engage the patrol and the director closed the gate."])
def test_literal_whole_clause_fallback_does_not_override_unbound_actor_negative_clock_or_present_state(query):
    result = match(query, query)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result
    assert result["whole_clause_certificate"] is None


def test_literal_whole_clause_fallback_retains_the_source_prefix_guard():
    query = "Mira Soren ordered Oren Vale not to engage the patrol."
    source = "The following allegation was fabricated:\n" + query
    case, plan, found, index = source_fixture(public_case("hypothesis", query), [source])
    unit = dict(start=source.index(query), end=len(source), text=query)
    result = supplement_evidence(case, plan["atoms"][0], index["p0"], unit, source_index=index)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result
    assert result["whole_clause_certificate"] is None


@pytest.mark.parametrize("query", ["Oren Vale was opening the gate.",
    "Mira Soren was commander of Sector III."])
def test_undated_past_progressive_and_role_are_source_attested_without_case_date_persistence(query):
    result = match(query, query + " Daria Venn left the harbor.")
    assert result["direction"] == "SUPPORT", result
    assert not result["publication_date_used_as_event_time"]


def test_present_state_is_not_established_at_case_date_by_an_earlier_present_state():
    result = match("Mira Soren is commander of Sector III.", "Mira Soren is commander of Sector III.")
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


@pytest.mark.parametrize("query,source", [
    ("Mira Soren was commander of Sector III.", "Mira Soren is commander of Sector III."),
    ("Mira Soren led the Harbor Council.", "Mira Soren leads the Harbor Council."),
    ("Mira Soren belonged to the Harbor Council.", "Mira Soren belongs to the Harbor Council."),
    ("Oren Vale was opening the gate.", "Oren Vale is opening the gate."),
    ("Mira Soren said that Oren Vale might open the gate.",
        "Mira Soren says that Oren Vale might open the gate."),
    ("Mira Soren said that Oren Vale might open the gate.",
        "Mira Soren is saying that Oren Vale might open the gate."),
    ("Mira Soren considered opening the gate.", "Mira Soren was considering opening the gate."),
    ("Oren Vale opened the gate.", "Oren Vale had opened the gate."),
])
def test_unrestricted_past_is_dated_source_ascription_not_continuing_tenure(query, source):
    result = match(query, source)
    assert result["direction"] == "SUPPORT", result
    assert result["source_attestation_not_persistence"]
    assert result["source_ascription_date"] == result["citation"]["date"]
    assert not result["publication_date_used_as_event_time"]
    clocks = [m["historical_source_ascription"] for row in result["comparisons"] for m in row
        if m["direction"] == "SUPPORT"]
    assert clocks and all(c["temporal_form_projected"] for c in clocks)
    assert all(not c["continued_tenure_at_query_cutoff_certified"] for c in clocks)


@pytest.mark.parametrize("query,source", [
    ("Mira Soren was commander of Sector III on May 1, 1971.", "Mira Soren is commander of Sector III."),
    ("Mira Soren was commander of Sector III.", "Mira Soren might be commander of Sector III."),
    ("Mira Soren was commander of Sector III.", "Mira Soren will be commander of Sector III."),
    ("Mira Soren currently leads the Harbor Council.", "Mira Soren leads the Harbor Council."),
    ("Mira Soren led the Harbor Council yesterday.", "Mira Soren leads the Harbor Council."),
    ("Oren Vale opened the gate.", "Oren Vale is opening the gate."),
    ("Oren Vale had opened the gate.", "Oren Vale opened the gate."),
    ("Mira Soren considered opening the gate.", "Mira Soren will consider opening the gate."),
    ("Mira Soren considered opening the gate.", "Daria Venn was considering opening the gate."),
    ("Mira Soren considered opening the gate.", "Mira Soren was planning opening the gate."),
    ("Mira Soren considered opening the gate.", "Mira Soren was considering closing the gate."),
    ("Mira Soren considered opening the gate.", "Mira Soren was considering not opening the gate."),
    ("Mira Soren considered opening the gate.", "Mira Soren was considering opening the window."),
    ("Oren Vale opened the gate.", "Mira Soren is considering opening the gate."),
    ("Oren Vale opened the gate.", "Mira Soren says that Oren Vale might open the gate."),
    ("Mira Soren said that Oren Vale might open the gate.",
        "Daria Venn says that Oren Vale might open the gate."),
    ("Mira Soren said that Oren Vale might open the gate.",
        "Mira Soren says that Oren Vale opened the gate."),
])
def test_ascription_does_not_erase_required_clock_aspect_modality_or_reporting_holder(query, source):
    result = match(query, source)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


@pytest.mark.parametrize("query,source", [
    ("Mira Soren led the Harbor Council.", "Harbor Council leader Mira Soren spoke to journalists."),
    ("Mira Soren commanded the Harbor Council.", "Harbor Council commander Mira Soren left the building."),
])
def test_explicit_named_authority_role_attests_historical_role_not_completed_action(query, source):
    result = match(query, source)
    assert result["direction"] == "SUPPORT", result
    cert = result["role_ascription_certificate"]
    assert cert["source_attestation_not_persistence"]
    assert cert["lexical_links"]
    assert not cert["completed_action_certified"]
    assert not cert["continued_tenure_at_query_cutoff_certified"]
    assert result["event_bindings"] == []


@pytest.mark.parametrize("source", [
    "Harbor Council leader Daria Venn spoke to journalists.",
    "West Harbor Council leader Mira Soren spoke to journalists.",
    "Harbor Council deputy leader Mira Soren spoke to journalists.",
    "Former Harbor Council leader Mira Soren spoke to journalists.",
    "Purported Harbor Council leader Mira Soren spoke to journalists.",
    "Mira Soren met Harbor Council leader Daria Venn.",
    "Harbor Council leader Mira Soren might leave the building.",
    "If Harbor Council leader Mira Soren leaves, Daria Venn will stay.",
    "Daria Venn claimed that Harbor Council leader Mira Soren left.",
    "Harbor Council leader Mira Soren or Daria Venn left.",
])
def test_authority_role_ascription_requires_exact_owner_organization_and_asserted_scope(source):
    result = match("Mira Soren led the Harbor Council.", source)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


@pytest.mark.parametrize("query", [
    "Mira Soren led the Harbor Council on May 1, 1971.",
    "Mira Soren led the Harbor Council yesterday.",
    "Mira Soren currently leads the Harbor Council.",
    "Mira Soren did not lead the Harbor Council.",
    "Mira Soren led the Harbor Council into the building.",
    "Mira Soren led the Harbor Council and Daria Venn opened the gate.",
    "Mira Soren belonged to the Harbor Council.",
])
def test_role_ascription_is_not_current_tenure_dated_action_membership_or_incomplete_query(query):
    result = match(query, "Harbor Council leader Mira Soren spoke to journalists.")
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


def test_arbitrary_person_deverbal_noun_is_not_an_executed_event():
    result = match("Mira Soren opened the Harbor Gate.", "Harbor Gate opener Mira Soren left.")
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


def test_qualified_complement_ascription_does_not_inherit_matrix_holder_as_inner_actor():
    result = match("Mira Soren considered opening the gate.", "Mira Soren was considering opening the gate.")
    assert result["direction"] == "SUPPORT", result
    certificates = [m["qualified_complement_certificate"] for row in result["comparisons"] for m in row
        if m["direction"] == "SUPPORT"]
    assert certificates and all(not c["inner_actor_certified"] and not c["inner_execution_certified"]
        for c in certificates)
    assert not result["actual_inner_event_established"]


def test_claimed_content_is_not_the_unqualified_event():
    source = "Mira Soren claimed that Oren Vale opened the gate."
    result = match("Oren Vale opened the gate.", source)
    assert result["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, result


@pytest.mark.parametrize("acronym", ["NATO", "IAEA", "UN", "UNSC", "US", "NASA"])
def test_public_bound_acronym_analysis_keeps_exact_raw_characters_and_positive_roles(acronym):
    from matryoshka_narrative.matching import MatcherCase
    query, source = acronym + " opened the gate.", acronym + " OPENED THE GATE."
    case, plan, unused, index = source_fixture(public_case("hypothesis", query), [source])
    matcher = MatcherCase(case, index)
    row = matcher.supplement(plan["atoms"][0], index["p0"], dict(start=0, end=len(source), text=source))
    assert row["direction"] == "SUPPORT", row
    assert acronym in row["analysis_policy"]["public_query_bound_acronyms"]
    doc = matcher.engine.parse(source)
    assert doc.text == source
    assert all(source[t.idx:t.idx + len(t)] == t.text for t in doc)
    assert not row["source_text_modified"]


def test_public_acronym_analysis_is_query_local_and_does_not_mutate_a_supplied_engine():
    from matryoshka_demo_v61.scope_matching import Engine
    from matryoshka_narrative.matching import MatcherCase
    query = "After the Paracels clash, the GVN considered taking the dispute to the court."
    source = "THE GVN WAS CONSIDERING TAKING THE DISPUTE TO THE COURT."
    case, plan, unused, index = source_fixture(public_case("hypothesis", query), [source])
    base = Engine()
    original = [(t.idx, t.text, t.pos_, t.dep_, t.head.idx) for t in base.parse(query)]
    matcher = MatcherCase(case, index, engine=base)
    assert "GVN" in matcher.public_acronyms
    assert [(t.pos_, t.dep_) for t in matcher.engine.parse(query) if t.text == "GVN"] == [("PROPN", "nsubj")]
    assert original == [(t.idx, t.text, t.pos_, t.dep_, t.head.idx) for t in base.parse(query)]
    row = matcher.supplement(plan["atoms"][0], index["p0"], dict(start=0, end=len(source), text=source))
    assert row["direction"] in {"PARTIAL", "UNRESOLVED"}  # The temporal/clash obligation is not deleted.
    other_case, other_plan, unused, other_index = source_fixture(public_case("hypothesis"), ["Oren Vale opened the gate."])
    other = MatcherCase(other_case, other_index, engine=base)
    assert "GVN" not in other.public_acronyms and other.engine is not base
    assert other.analysis_policy["query_sha256"] == digest(other_case["query"])
    assert "GVN" not in other.analysis_policy["public_query_bound_acronyms"]
    assert original == [(t.idx, t.text, t.pos_, t.dep_, t.head.idx) for t in base.parse(query)]


@pytest.mark.parametrize("query,source", [
    ("NATO opened the gate.", "UN OPENED THE GATE."),
    ("NATO opened the gate.", "MIRA SOREN SAID THAT NATO OPENED THE GATE."),
    ("NATO said that Oren Vale opened the gate.", "UN SAID THAT OREN VALE OPENED THE GATE."),
    ("NATO opened the gate.", "NATO WILL OPEN THE GATE."),
    ("NATO praised the UN.", "THE UN PRAISED NATO."),
    ("WHO approved the treaty.", "THE DIRECTOR WHO APPROVED THE TREATY LEFT."),
    ("WHO opened the gate.", "WHO OPENED THE GATE?"),
    ("US opened the gate.", "Mira Soren asked us to open the gate."),
    ("US opened the gate.", "MIRA SOREN ASKED US TO OPEN THE GATE."),
    ("WHO opened the gate.", "Mira Soren asked who opened the gate."),
])
def test_all_ten_acronym_wrong_actor_scope_operator_and_common_word_controls_stay_unsigned(query, source):
    row = match(query, source)
    assert row["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, row


@pytest.mark.parametrize("source", ["Mira Soren stated the answer.", "Mira Soren reported the answer.",
    "Mira Soren noted the answer.", "Mira Soren states the answer."])
def test_only_declared_positive_one_way_speech_projection_preserves_existing_capability(source):
    row = match("Mira Soren said the answer.", source)
    assert row["direction"] == "SUPPORT", row
    proofs = [m["validated_speech_projection"] for group in row["comparisons"] for m in group
        if m["direction"] == "SUPPORT"]
    assert proofs and all(p["validated_positive_only"] and p["not_reverse"] for p in proofs)
    assert row["citation"]["text"] == source
    assert not row["actual_inner_event_established"]


@pytest.mark.parametrize("query,source", [
    ("Mira Soren said the answer.", "Daria Venn stated the answer."),
    ("Mira Soren said the answer.", "Mira Soren stated the warning."),
    ("Mira Soren stated the answer.", "Mira Soren said the answer."),
    ("Mira Soren said the answer.", "Mira Soren announced the answer."),
    ("Mira Soren said the answer.", "Mira Soren might state the answer."),
    ("Mira Soren said the answer.", "Daria Venn claimed that Mira Soren stated the answer."),
    ("Mira Soren did not say the answer on May 1, 1971.", "Mira Soren did not state the answer on May 1, 1971."),
])
def test_speech_projection_is_not_reverse_arbitrary_lexical_or_negated_specialization(query, source):
    row = match(query, source)
    assert row["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, row


@pytest.mark.parametrize("query", [
    "Nine votes were required for inscription on the UN Security Council agenda.",
    "The Harbor Council treaty was approved.",
    "Mira Soren was appointed.",
    "Three crates were sent to the Harbor Council.",
    "Three crates were sent to Oslo.",
])
def test_agentless_passive_requires_only_applicable_roles_and_a_matched_named_anchor(query):
    row = match(query, query)
    assert row["direction"] == "SUPPORT", row
    proofs = [m["applicable_passive_identity"] for group in row["comparisons"] for m in group
        if m["direction"] == "SUPPORT"]
    assert proofs and all(p and not p["agent_obligation"] for p in proofs)
    assert row["whole_clause_certificate"] is None


@pytest.mark.parametrize("source", [
    "Eight votes were required for inscription on the UN Security Council agenda.",
    "Nine votes were required for inscription on the UN Economic Council agenda.",
    "Nine votes were required for inscription on the Harbor Council agenda.",
    "Nine votes were required for removal from the UN Security Council agenda.",
    "Nine votes were required for inscription under the UN Security Council agenda.",
    "Nine votes were required for inscription.",
    "Nine votes might be required for inscription on the UN Security Council agenda.",
    "Nine votes will be required for inscription on the UN Security Council agenda.",
    "Nine votes were not required for inscription on the UN Security Council agenda.",
    "Daria Venn claimed that nine votes were required for inscription on the UN Security Council agenda.",
    "At least nine votes were required for inscription on the UN Security Council agenda.",
    "At most nine votes were required for inscription on the UN Security Council agenda.",
    "The UN Security Council agenda was required for inscription on nine votes.",
])
def test_passive_anchor_cannot_compensate_wrong_institution_quantity_patient_role_or_operator(source):
    query = "Nine votes were required for inscription on the UN Security Council agenda."
    row = match(query, source)
    assert row["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, row


@pytest.mark.parametrize("query,source", [
    ("The gate was opened.", "The gate was opened."),
    ("The director was appointed.", "The director was appointed."),
    ("The gate was opened.", "The gate was opened by Mira Soren."),
    ("The director was appointed.", "The director was appointed by Mira Soren."),
    ("The director sent three crates to Oslo.", "The director sent three crates to Oslo."),
    ("The director said that Mira Soren was appointed.", "The director said that Mira Soren was appointed."),
    ("Three crates were sent from the Harbor Council.", "Three crates were sent to the Harbor Council."),
    ("Nine votes were required by Mira Soren for inscription on the Harbor Council agenda.",
        "Nine votes were required for inscription on the Harbor Council agenda."),
])
def test_passive_waiver_cannot_borrow_a_source_only_name_or_erase_an_actual_actor_holder_or_role_obligation(query, source):
    row = match(query, source)
    assert row["direction"] not in {"SUPPORT", "COUNTER", "CONFLICTED"}, row


@pytest.mark.parametrize("query,source", [
    ("Nine votes were required for inscription on the UN Security Council agenda.",
        "Nine votes were required for inscription on the UN Security Council agenda."),
    ("Mira Soren said the answer.", "Mira Soren stated the answer."),
])
def test_v4_positive_certificates_reach_the_actual_final_engine_without_baseline_promotion(query, source):
    from matryoshka_narrative.decisions import execute
    case, plan, found, index = source_fixture(public_case("hypothesis", query), [source])
    result = execute(case, plan, found, source_index=index)
    assert result["status"] == "SUPPORTED", result
    assert result["atoms"][0]["positive_evidence"]
    assert any(r.get("version") == MATCHING_VERSION for r in result["atoms"][0]["positive_evidence"])
    assert not result["world_truth_certified"] and result["api_calls"] == 0


def test_case_factory_builds_source_policy_once_and_reuses_atom_and_unit_analysis(monkeypatch):
    from matryoshka_narrative import matching
    case, plan, found, index = source_fixture(public_case("hypothesis"), ["Oren Vale opened the gate."])
    original, calls = matching.SourcePolicy, []

    def counted(*args, **kwargs):
        calls.append(1)
        return original(*args, **kwargs)

    monkeypatch.setattr(matching, "SourcePolicy", counted)
    cached = matching.MatcherCase(case, index)
    page = index["p0"]
    unit = dict(start=0, end=len(page["text"]), text=page["text"])
    for _ in range(3):
        assert cached.supplement(plan["atoms"][0], page, unit)["direction"] == "SUPPORT"
    assert len(calls) == 1
    assert len(cached.query_cache) == len(cached.unit_cache) == 1


def test_cached_matcher_cannot_be_reused_under_a_different_explicit_source_view():
    from matryoshka_narrative.matching import MatcherCase
    case, plan, found, index = source_fixture(public_case("hypothesis"), ["Oren Vale opened the gate."])
    cached = MatcherCase(case, index)
    page = index["p0"]
    unit = dict(start=0, end=len(page["text"]), text=page["text"])
    with pytest.raises(ValueError, match="source index"):
        supplement_evidence(case, plan["atoms"][0], page, unit,
            source_index=deepcopy(index), matcher=cached)


@pytest.mark.parametrize("change", [dict(date="1971-06-02"), dict(document_id="excluded_origin"),
    dict(classification="SECRET"), dict(visibility="unknown"), dict(permitted=False)])
def test_supplement_replays_source_policy_instead_of_trusting_the_caller(change):
    case, plan, found, index = source_fixture(public_case("hypothesis"), ["Oren Vale opened the gate."])
    page = index["p0"]
    page.update(change)
    with pytest.raises(ValueError):
        supplement_evidence(case, plan["atoms"][0], page,
            dict(start=0, end=len(page["text"]), text=page["text"]), source_index=index)


def test_full_index_uninspected_noforn_sibling_and_quote_tampering_remain_fatal():
    case, plan, found, index = source_fixture(public_case("hypothesis"), ["Oren Vale opened the gate."])
    page = index["p0"]
    unit = dict(start=0, end=len(page["text"]), text=page["text"])
    index["sibling"] = dict(page, id="sibling", text="NOFORN", source_sha256=digest("NOFORN"), permitted=False)
    with pytest.raises(ValueError):
        supplement_evidence(case, plan["atoms"][0], page, unit, source_index=index)
    del index["sibling"]
    unit["text"] = "Oren Vale closed the gate."
    with pytest.raises(ValueError):
        supplement_evidence(case, plan["atoms"][0], page, unit, source_index=index)
