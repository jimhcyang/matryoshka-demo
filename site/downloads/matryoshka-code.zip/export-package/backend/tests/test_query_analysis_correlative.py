"""Exact approved correlative port, with retained baseline failures visible."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import ModuleType

import pytest

from matryoshka_demo.io import digest, offline
from matryoshka_demo_v61.scope_matching import Engine
from matryoshka_narrative import matching, query_analysis

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / 'phase/analyst_release_20261123/frame_probe'
PORT_SHA = 'fb1683efadadf75b7c2d673a798b26e8ea28e8702c2947162d73211868167e7c'
OLD_SHA = '79010c710d9c0a43602f009202ae4102bfb18ff0b96299772256f1a19071ea3a'
PROTOTYPE_SHA = '24cfeb2ab82a307bdd6bbd57471ae8ab626232397246bc1afab105fa3c20b682'
raw = (PROBE / 'layout-correlative-tests-v01.json').read_bytes()
assert hashlib.sha256(raw).hexdigest() == '144a80641459f1d708ed9564acad290404bf7e69af86d3ee0cb30fed85ee2c0f'
RECEIPT = json.loads(raw)
sys.path.insert(0, str(PROBE))
from vn_parser_regression import inspect, QUERY, SOURCE


@pytest.fixture(autouse=True)
def api0():
    with offline():
        yield


def signature(doc):
    return dict(text=doc.text, tokens=[(t.text, t.idx, t.whitespace_, t.head.idx,
        t.pos_, t.tag_, t.dep_, t.lemma_, str(t.morph), t.is_sent_start,
        t.ent_iob_, t.ent_type_) for t in doc],
        entities=[(e.start_char, e.end_char, e.label_, e.text) for e in doc.ents])


def semantic(value):
    if isinstance(value, dict):
        return {k: semantic(v) for k, v in value.items() if k not in {'v5_analysis', 'analysis_policy'}}
    if isinstance(value, list):
        return [semantic(v) for v in value]
    return value


@pytest.fixture(scope='module')
def engines():
    text = Path(query_analysis.__file__).read_text()
    assert hashlib.sha256(text.encode()).hexdigest() == PORT_SHA
    node = next(n for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)
                and n.name == '_correlative_layout_fallback')
    helper = ast.get_source_segment(text, node)
    hook = ('            fallback = _correlative_layout_fallback(original, result)\n'
            '            if fallback is not None:\n'
            '                self.records[digest(text)] = dict(version=VERSION, **fallback)\n'
            '                return original\n')
    previous_text = text.replace(helper + '\n\n\n', '', 1).replace(hook, '', 1).replace(
        'narrative-query-bound-case-layout-analysis/3', 'narrative-query-bound-case-layout-analysis/2', 1)
    assert hashlib.sha256(previous_text.encode()).hexdigest() == OLD_SHA
    previous = ModuleType('frozen_query_analysis_2_in_memory')
    exec(compile(previous_text, '<SHA-verified frozen analysis2>', 'exec'), previous.__dict__)
    prototype_path = PROBE / 'layout_correlative_fallback.py'
    assert hashlib.sha256(prototype_path.read_bytes()).hexdigest() == PROTOTYPE_SHA
    spec = importlib.util.spec_from_file_location('approved_correlative_against_frozen2', prototype_path)
    prototype = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(prototype)
    prototype.build_engine = previous.build_engine
    base = Engine()
    acronyms = matching._public_acronyms({'query': QUERY}, base)
    approved, _ = prototype.experimental_engine(base, {'query': QUERY}, acronyms=acronyms)
    actual, _ = query_analysis.build_engine(base, {'query': QUERY}, acronyms=acronyms)
    return approved, actual


def test_exact_production_version_and_full_reviewed_bytes():
    assert query_analysis.VERSION == 'narrative-query-bound-case-layout-analysis/3'
    assert hashlib.sha256(Path(query_analysis.__file__).read_bytes()).hexdigest() == PORT_SHA


@pytest.mark.parametrize('record', RECEIPT['source_parse_cases'], ids=lambda r: r['label'])
def test_source_tokens_entities_frames_and_fallback_equal_approved_prototype(engines, record):
    approved, actual = engines
    text = record['source']
    assert signature(actual.parse(text)) == signature(approved.parse(text))
    assert semantic(actual.frames(text)) == semantic(approved.frames(text))
    applied = actual.analysis_parser.records.get(digest(text), {}).get('kind') == 'CORRELATIVE_AND_ORIGINAL_PARSE_RETAINED'
    assert applied == record['fallback']


@pytest.mark.parametrize('record', RECEIPT['match_cases'], ids=lambda r: r['label'])
def test_match_equivalence_not_claiming_baseline_disjunction_fixes(engines, record):
    approved, actual = engines
    q, source = QUERY, SOURCE
    label = record['label']
    if label == 'west_only': source = 'THE NVA HAVE MOUNTED STIFF ATTACKS IN THE WESTERN SECTIONS OF MR-3.'
    if label == 'wrong_region': q = q.replace('MR-3', 'MR-2')
    if label == 'wrong_actor': q = q.replace('NVA', 'ARVN')
    if label == 'negative_query': q = q.replace('mounted', 'did not mount')
    if label == 'modal_query': q = q.replace('mounted', 'might mount')
    if label == 'negative_source': source = SOURCE.replace('HAVE MOUNTED', 'HAVE NOT MOUNTED')
    if label == 'modal_source': source = SOURCE.replace('HAVE MOUNTED', 'MIGHT MOUNT')
    if label == 'either_source': source = SOURCE.replace('BOTH', 'EITHER').replace('AND', 'OR')
    if label == 'neither_source': source = SOURCE.replace('BOTH', 'NEITHER').replace('AND', 'NOR')
    if label == 'conditional_source': source = 'IF ' + SOURCE[:-1] + ', OFFICIALS WILL RESPOND.'
    a, b = inspect(approved, q, source), inspect(actual, q, source)
    assert semantic(a) == semantic(b)
    assert b['every_frame_supported'] == record['result']['every_frame_supported']
    if record['verdict'] == 'FAIL_BASELINE_EXISTING':
        assert b['every_frame_supported'] and not record['expected_support']


def test_fallback_retains_both_exact_conjunct_tokens_without_claiming_expansion(engines):
    _, actual = engines
    doc = actual.parse(SOURCE)
    assert next(t for t in doc if t.text == 'BOTH').dep_ == 'preconj'
    assert next(t for t in doc if t.text == 'WESTERN').dep_ == 'conj'
    record = actual.analysis_parser.records[digest(SOURCE)]
    assert [row['text'] for row in record['members']] == ['EASTERN', 'WESTERN']
    assert record['coordination_expanded'] is False and record['entailment_certified'] is False
    assert all(SOURCE[row['start']:row['end']] == row['text'] for row in record['members'])
