"""Exact-span NER regression for whitespace projection, API0 only."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tarfile
from types import ModuleType, SimpleNamespace

import pytest

from matryoshka_demo.io import digest, offline
from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE
from matryoshka_demo_v61.scope_matching import Engine
from matryoshka_narrative import assertion_matching, query_analysis

ROOT = Path(__file__).resolve().parents[1]
PHASE = ROOT / 'phase/analyst_release_20261123'


@pytest.fixture(autouse=True)
def api0():
    with offline():
        yield


def entity_signature(doc):
    return [(e.start_char, e.end_char, e.label_, e.text) for e in doc.ents]


def lexical_signature(token):
    return (token.text, token.idx, len(token), token.dep_, token.pos_, token.tag_, token.lemma_,
            str(token.morph), token.ent_iob_, token.ent_type_, token.is_sent_start,
            token.head.idx, len(token.head))


@pytest.mark.parametrize('text,phrases', [
    ('AT LEAST\n ONE delegate arrived.', [('AT LEAST\n ONE', 'CARDINAL')]),
    ('Mira\n \tSoren counted AT LEAST\r\n  TWO votes.',
     [('Mira\n \tSoren', 'PERSON'), ('AT LEAST\r\n  TWO', 'CARDINAL')]),
    ('Mira\n Soren arrived.\n\nLeena\t  Rao left.',
     [('Mira\n Soren', 'PERSON'), ('Leena\t  Rao', 'PERSON')]),
    ('Mira\n Soren Leena\r\n Rao arrived.',
     [('Mira\n Soren', 'PERSON'), ('Leena\r\n Rao', 'PERSON')]),
])
def test_whole_entity_intervals_include_raw_spaces_without_splitting(text, phrases):
    import spacy
    from spacy.attrs import ENT_IOB, ENT_TYPE
    nlp = spacy.blank('en')
    raw = nlp.make_doc(text)
    proposed = nlp.make_doc(text.replace('\n', ' ').replace('\r', ' ').replace('\t', ' '))
    expected = [(text.index(s), text.index(s) + len(s), label, s) for s, label in phrases]
    entities = [proposed.char_span(a, b, label=label, alignment_mode='strict') for a, b, label, _ in expected]
    assert all(e is not None for e in entities)
    proposed.set_ents(entities, default='outside')
    result = raw.copy()
    values = result.to_array([ENT_IOB, ENT_TYPE])
    lookup = {(t.idx, len(t)): t for t in proposed if not t.is_space}
    projected = proposed.to_array([ENT_IOB, ENT_TYPE])
    for token in result:
        if not token.is_space:
            values[token.i] = projected[lookup[token.idx, len(token)].i]
    result.from_array([ENT_IOB, ENT_TYPE], values)
    geometry = [(t.text, t.idx, len(t), t.whitespace_) for t in result]
    ok, reason = query_analysis._project_entity_intervals(result, proposed)
    assert ok and reason is None
    assert entity_signature(result) == expected
    assert [(t.text, t.idx, len(t), t.whitespace_) for t in result] == geometry
    for token in result:
        if token.is_space:
            containing = [row for row in expected if row[0] <= token.idx and token.idx + len(token) <= row[1]]
            assert token.ent_iob_ == ('I' if containing else 'O')
            assert token.ent_type_ == (containing[0][2] if containing else '')


@pytest.fixture(scope='module')
def actual_corpus():
    sys.path.insert(0, str(PHASE / 'frame_probe'))
    from natural_preflight import load
    return load()


@pytest.mark.parametrize('query,origin,cutoff', [
    ('Ayatollah Khomeini has called for departure of the Shah.', 'live-analyst-origin:entity-stress', '1978-12-13'),
    ("Haeri's father taught Khomeini.", '1979STATE139731', '1979-06-01'),
])
def test_actual_11206_and_haeri_parse_entities_frames_and_supplement(actual_corpus, query, origin, cutoff):
    _, pages, index, classification = actual_corpus
    page = index['segment_69e8bffc7038b45df5b6']
    text = page['text'][503:725]
    assert 'AT LEAST\nONE' in text
    case = dict(case_id='entity-stress', corpus='iran', task='hypothesis', query=query,
                document_id=origin, date=cutoff, focal_marker='')
    engine, _ = query_analysis.build_engine(Engine(), case)
    parent = type(engine.analysis_parser).__mro__[1]
    proposed = parent.__call__(engine.analysis_parser, text.replace('\r', ' ').replace('\n', ' ').replace('\t', ' '))
    parsed = engine.parse(text)
    expected = [(e.start_char, e.end_char, e.label_, text[e.start_char:e.end_char]) for e in proposed.ents]
    assert entity_signature(parsed) == expected
    lookup = {(t.idx, len(t)): t for t in proposed if not t.is_space}
    assert all(lexical_signature(t) == lexical_signature(lookup[t.idx, len(t)]) for t in parsed if not t.is_space)
    list(engine.parse(page['text']).ents)
    engine.frames(text)
    engine.frames(page['text'])
    corpus = SimpleNamespace(corpus='iran', pages=pages, classification=classification,
                             source_view_policy=SOURCE_DAY_INCLUSIVE)
    matcher = assertion_matching.MatcherCase(case, index, corpus=corpus)
    atom = dict(id='a1', kind='proposition', text=query, query_spans=[dict(start=0, end=len(query), text=query)])
    before = digest(page)
    row = matcher.supplement(atom, page, dict(start=503, end=725, text=text))
    assert row['citation']['text'] == text and digest(page) == before
    assert not row['source_text_modified']


def test_old_archive_reproduces_e093_on_actual_numeric_entity(actual_corpus):
    path = PHASE / 'backend/pre_entity_fix_code.tar.gz'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == 'cddcf80759c3041a301eeef2bba752799117d141f1807750da63d13dc1d63b7f'
    with tarfile.open(path, 'r:gz') as archive:
        raw = archive.extractfile('matryoshka_narrative/query_analysis.py').read()
    old = ModuleType('pre_entity_query_analysis')
    exec(compile(raw, str(path) + ':query_analysis.py', 'exec'), old.__dict__)
    text = actual_corpus[2]['segment_69e8bffc7038b45df5b6']['text'][503:725]
    engine, _ = old.build_engine(Engine(), {'query': 'Ayatollah Khomeini has called for departure of the Shah.'})
    with pytest.raises(ValueError, match='E093'):
        list(engine.parse(text).ents)


def test_invalid_projected_entities_fail_closed():
    import spacy
    from spacy.attrs import ENT_IOB, ENT_TYPE
    nlp = spacy.blank('en')
    proposed = nlp.make_doc('Mira Soren arrived.')
    values = proposed.to_array([ENT_IOB, ENT_TYPE])
    values[0, 0] = 2  # Outside followed by an orphan I is deliberately invalid.
    values[1, 0] = 1
    values[1, 1] = proposed.vocab.strings['PERSON']
    proposed.from_array([ENT_IOB, ENT_TYPE], values)
    ok, reason = query_analysis._project_entity_intervals(nlp.make_doc(proposed.text), proposed)
    assert not ok and reason == 'INVALID_ENTITY_SPAN_PROJECTION'


def test_entity_validation_failure_returns_original_with_reason(monkeypatch):
    engine, _ = query_analysis.build_engine(Engine(), {'query': 'Majlis approved Bakhtiar government.'})
    text = 'MAJLIS EARLIER\nAPPROVED BAKHTIAR GOVERNMENT.'
    parent = type(engine.analysis_parser).__mro__[1]
    original = parent.__call__(engine.analysis_parser, text)
    monkeypatch.setattr(query_analysis, '_project_entity_intervals', lambda *a: (False, 'TEST_ENTITY_MISMATCH'))
    result = engine.parse(text)
    assert [lexical_signature(t) for t in result] == [lexical_signature(t) for t in original]
    assert entity_signature(result) == entity_signature(original)
    assert engine.analysis_parser.records[digest(text)]['fallback_reason'] == 'TEST_ENTITY_MISMATCH'


@pytest.mark.parametrize('text', [
    'AT LEAST\n ONE DELEGATE SIGNED THE LETTER.',
    'Mira\n \tSoren signed the letter.',
    'Mira\n Soren signed the letter.\n\nLeena\t Rao counted AT LEAST\r\n TWO votes.',
])
def test_synthetic_entities_through_frames_and_full_supplement(text):
    sys.path.insert(0, str(ROOT / 'experiments/narrative_demo/redteam'))
    from narrative_redteam_fixtures import public_case, source_fixture
    case, plan, found, index = source_fixture(public_case('hypothesis', 'Mira Soren signed the letter.'), [text])
    page = index['p0']
    before = deepcopy(page)
    matcher = assertion_matching.MatcherCase(case, index, corpus=found['eligible'].corpus)
    engine = matcher.baseline.engine
    doc = engine.parse(text)
    entities = entity_signature(doc)
    assert doc.text == text
    assert all(text[a:b] == spelling for a, b, _, spelling in entities)
    engine.frames(text)
    row = matcher.supplement(plan['atoms'][0], page, dict(start=0, end=len(text), text=text))
    assert row['citation']['text'] == text and page == before
    assert query_analysis.VERSION == 'narrative-query-bound-case-layout-analysis/3'
