"""API0 equivalence and countercontrols for the reviewed isolated parser port."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
PROBE = ROOT / 'phase/analyst_release_20261123/frame_probe'
REVIEW = PROBE.parent / 'diagnostics/relative_review'
sys.path.insert(0, str(ROOT / 'experiments/narrative_demo/redteam'))
from narrative_redteam_fixtures import public_case, source_fixture
from matryoshka_demo.io import offline
from matryoshka_demo_v61.scope_matching import Engine
from matryoshka_narrative import assertion_matching, matching, planning, query_analysis, workflow


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture(scope='module')
def engines():
    with offline():
        base = Engine()
        names = load_module('reviewed_name_projection', PROBE / 'query_names.py')
        layout = load_module('reviewed_layout_projection', PROBE / 'layout_projection.py')
        yield base, names, layout


@pytest.fixture(autouse=True)
def api0():
    with offline():
        yield


def signature(doc):
    return doc.text, [(t.text, t.idx, len(t), t.whitespace_, t.dep_, t.pos_, t.tag_,
                       t.lemma_, str(t.morph), t.ent_iob_, t.ent_type_, t.is_sent_start,
                       t.head.idx, len(t.head)) for t in doc]


def semantic_frames(value):
    if isinstance(value, dict):
        return {k: semantic_frames(v) for k, v in value.items() if k != 'v5_analysis'}
    if isinstance(value, (list, tuple)):
        return [semantic_frames(v) for v in value]
    return value


GEOMETRY = ['MAJLIS EARLIER' + s + 'APPROVED BAKHTIAR GOVERNMENT.'
            for s in ('\n', '\r\n', '\r', '\t', '\n\n', '\r\n\t  ', '    ')] + [
    'MAJLIS\nAPPROVED. BAKHTIAR\nRESIGNED.',
    'MAJLIS\u00a0APPROVED BAKHTIAR GOVERNMENT.',
    'MAJLIS APPROVED BAKHTIAR\nGOVERNMENT BY 149-43-13.',
    'MAJLIS APPROVED BAKH-\nTIAR GOVERNMENT.',
    'MAJLIS\nDID NOT APPROVE BAKHTIAR GOVERNMENT.',
    'MAJLIS APPROVED BAKHTIAR GOVERNMENT.\r\n',
]


@pytest.mark.parametrize('text', GEOMETRY)
def test_exact_reviewed_parser_equivalence_and_raw_geometry(engines, text):
    base, names, layout = engines
    case = dict(query='Majlis approved Bakhtiar government.')
    named, expected_names = names.experimental_engine(base, case)
    reviewed = layout.experimental_engine(named)
    port, policy = query_analysis.build_engine(base, case)
    before = signature(base.analysis_parser.identity.parser(text))
    assert signature(port.parse(text)) == signature(reviewed.parse(text))
    assert [(t.text, t.idx, len(t), t.whitespace_) for t in port.parse(text)] == [r[:4] for r in before[1]]
    assert signature(base.analysis_parser.identity.parser(text)) == before
    assert policy['public_query_bound_names'] == expected_names['names']
    assert policy['common_words_rejected'] == expected_names['common_words_rejected']
    assert semantic_frames(port.frames(text)) == semantic_frames(reviewed.frames(text))


@pytest.mark.parametrize('word', ['May', 'March', 'Must', 'Will', 'General', 'Able'])
def test_common_words_never_become_name_hints(engines, word):
    base, _, _ = engines
    _, policy = query_analysis.build_engine(base, dict(query=word + ' approved Bakhtiar government.'))
    assert word.casefold() not in policy['public_query_bound_names']


def test_hints_and_caches_are_query_bound_not_source_bound(engines):
    base, _, _ = engines
    a, policy_a = query_analysis.build_engine(base, dict(query='Majlis approved Bakhtiar government.',
        answer='HiddenName', source='SourceHint', model_reading='ReadingHint'))
    b, policy_b = query_analysis.build_engine(base, dict(query='Oren opened the gate.'))
    text = 'MAJLIS EARLIER\nAPPROVED BAKHTIAR GOVERNMENT.'
    before = signature(a.parse(text))
    b.parse(text)
    assert signature(a.parse(text)) == before
    assert not {'hiddenname', 'sourcehint', 'readinghint'} & policy_a['public_query_bound_names'].keys()
    assert 'bakhtiar' not in policy_b['public_query_bound_names']
    assert a is not b and a.analysis_parser is not b.analysis_parser


LAYOUT_ROWS = [r for r in json.loads((REVIEW / 'LAYOUT_RESULT_v01.json').read_bytes())['rows']
               if r['mode'] == 'combined']


@pytest.mark.parametrize('row', LAYOUT_ROWS, ids=lambda r: r['label'])
def test_production_matching_retains_all_reviewed_source_and_query_controls(row):
    case, plan, found, index = source_fixture(public_case('hypothesis', row['query']), [row['source_text']])
    source = index['p0']
    unit = dict(start=0, end=len(source['text']), text=source['text'])
    before = deepcopy((case, plan, index))
    result = assertion_matching.MatcherCase(case, index, corpus=found['eligible'].corpus).supplement(
        plan['atoms'][0], source, unit)
    assert result['direction'] == row['direction']
    assert before == (case, plan, index)
    assert result['citation']['text'] == row['source_text']
    assert not result['source_text_modified'] and not result['baseline_decision_modified']
    assert not result['actual_inner_event_established']


def test_acronym_behavior_and_combined_analysis(engines):
    base, _, _ = engines
    case = dict(query='NATO approved the plan.')
    acronyms = matching._public_acronyms(case, base)
    legacy = matching._acronym_engine(base, acronyms)
    port, policy = query_analysis.build_engine(base, case, acronyms=acronyms)
    assert signature(port.parse('NATO APPROVED THE PLAN.')) == signature(legacy.parse('NATO APPROVED THE PLAN.'))
    assert policy['public_query_bound_acronyms'] == ['NATO']
    mixed = dict(query='NATO approved Bakhtiar government.')
    port, policy = query_analysis.build_engine(base, mixed, acronyms=matching._public_acronyms(mixed, base))
    assert 'bakhtiar' in policy['public_query_bound_names'] and 'NATO' in policy['public_query_bound_acronyms']
    assert port.parse('NATO\nAPPROVED BAKHTIAR GOVERNMENT.').text == 'NATO\nAPPROVED BAKHTIAR GOVERNMENT.'


OPRD_ROWS = json.loads((REVIEW / 'OBJECT_RESULT_v01.json').read_bytes())['records']


@pytest.mark.parametrize('row', [r for r in OPRD_ROWS if 'expected' in r], ids=lambda r: r['label'])
def test_reviewed_oprd_structure_controls(row):
    atoms = [dict(id='a' + str(i), kind='proposition', required=True, text=text)
             for i, text in enumerate(row['atoms'])]
    case = dict(task='mosaic', query=row['query'])
    if row['expected']:
        planning._check_structure(case, atoms)
    else:
        with pytest.raises(ValueError):
            planning._check_structure(case, atoms)


def test_oprd_matches_frozen_output_and_is_idempotent():
    frozen = json.loads((PROBE / 'object-complement-receipt.json').read_bytes())
    parts = ["The armed forces supported Bakhtiar's government.",
             'Khomeini named Bazargan provisional prime minister.']
    normalize = lambda value: json.loads(json.dumps(value, default=sorted))
    assert normalize([planning.literal_frames(s) for s in parts]) == frozen['atom_frames_after']
    from matryoshka_next.readings import _model
    doc = _model()(parts[1])
    frame = planning.literal_frames(parts[1])[0]
    before = deepcopy(frame)
    planning._attach_nominal_object_complement(frame, next(t for t in doc if t.idx == frame['start']), parts[1])
    assert frame == before


@pytest.mark.parametrize('row', [r for r in OPRD_ROWS if 'same_frames' in r], ids=lambda r: r['label'])
def test_unrelated_oprd_frames_stay_without_new_bindings(row):
    assert not any(b.get('kind') == 'EXPLICIT_NAMED_NOMINAL_OBJECT_COMPLEMENT'
                   for f in planning.literal_frames(row['query']) for b in f.get('public_attachment_bindings', []))


def test_versions_pins_and_no_phase_or_relative_imports():
    assert matching.VERSION.endswith('/4')  # Existing role-certificate protocol is unchanged.
    assert planning.VERSION.endswith('/14')
    assert planning._scope['VERSION'] == 'narrative-declarative-native-plan/6'
    key = 'matryoshka_narrative/query_analysis.py'
    assert workflow.code_pins()[key] == hashlib.sha256((ROOT / key).read_bytes()).hexdigest()
    for path in (ROOT / key, ROOT / 'matryoshka_narrative/matching.py', ROOT / 'matryoshka_narrative/planning.py'):
        text = path.read_text()
        assert 'phase/' not in text and 'relative_certificate' not in text


@pytest.mark.parametrize('variant', ['subclass', 'context', 'method'])
def test_custom_engine_protocol_and_context_are_preserved(variant):
    from types import MethodType
    if variant == 'subclass':
        class CustomEngine(Engine):
            def targets(self, text):
                return super().targets(text)
        base = CustomEngine()
    else:
        base = Engine()
    if variant == 'context':
        base._case = {'context': 'must-remain-on-this-engine'}
    if variant == 'method':
        original = base.targets
        base.targets = MethodType(lambda self, text: original(text), base)
    original_dict = dict(vars(base))
    result, policy = query_analysis.build_engine(base, {'query': 'Majlis approved Bakhtiar government.'})
    assert result is base and vars(base) == original_dict
    assert policy['mode'] == 'CUSTOM_ENGINE_PRESERVED'
    assert policy['analysis_extension_applied'] is False
    assert policy['public_query_bound_names'] == {}
    case, _, found, index = source_fixture(public_case('hypothesis', 'Majlis approved Bakhtiar government.'),
        ['MAJLIS APPROVED BAKHTIAR GOVERNMENT.'])
    matcher = matching.MatcherCase(case, index, engine=base, corpus=found['eligible'].corpus)
    assert matcher.engine is base and vars(base) == original_dict


def test_native_plan_six_bind_validate_roundtrip():
    from narrative_redteam_fixtures import raw_plan
    from matryoshka_narrative.contracts import engine_case
    query = "The armed forces supported Bakhtiar's government, and Khomeini named Bazargan provisional prime minister."
    parts = ["The armed forces supported Bakhtiar's government.", 'Khomeini named Bazargan provisional prime minister.']
    case = engine_case(public_case('mosaic', query))
    plan = planning.bind(case, raw_plan(query, parts))
    assert plan['version'] == 'narrative-declarative-native-plan/6'
    assert planning.validate_plan(plan, case) == plan


def test_actual_bound_majlis_unit_without_source_or_index_edits():
    sys.path.insert(0, str(PROBE))
    from natural_preflight import load
    from types import SimpleNamespace
    from matryoshka_demo.io import digest
    from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE
    binding, pages, index, classification = load()
    page = index['segment_86c4795b9e86d827cb8b']
    text = page['text'][517:579]
    assert text == 'MAJLIS EARLIER\nAPPROVED BAKHTIAR GOVERNMENT BY VOTE 149-43-13.'
    before = digest(page)
    case = dict(case_id='port-actual-majlis', corpus='iran', task='hypothesis',
                query='Majlis approved Bakhtiar government.', date='1979-02-11',
                document_id='live-analyst-origin:port-actual', focal_marker='')
    corpus = SimpleNamespace(corpus='iran', pages=pages, classification=classification,
                             source_view_policy=SOURCE_DAY_INCLUSIVE)
    atom = dict(id='a1', kind='proposition', text=case['query'],
                query_spans=[dict(start=0, end=len(case['query']), text=case['query'])])
    row = assertion_matching.MatcherCase(case, index, corpus=corpus).supplement(
        atom, page, dict(start=517, end=579, text=text))
    assert row['direction'] == 'SUPPORT'
    assert row['citation']['text'] == text and row['citation']['start'] == 517 and row['citation']['end'] == 579
    assert digest(page) == before
    assert binding['sha256'] == '2c32af1c71e5b33a6da1648794e6bc1a65f449a918758f8a025c8b2d8ea47c45'


@pytest.mark.parametrize('change', [dict(date='1971-06-03'), dict(classification='SECRET'),
    dict(handling=['NOFORN']), dict(visibility='private'), dict(permitted=False), dict(source_sha256='0' * 64)])
def test_layout_cannot_bypass_source_policy(change):
    case, plan, found, index = source_fixture(public_case('hypothesis', 'Majlis approved Bakhtiar government.'),
        ['MAJLIS EARLIER\nAPPROVED BAKHTIAR GOVERNMENT.'])
    page = index['p0']
    page.update(change)
    with pytest.raises(ValueError):
        assertion_matching.MatcherCase(case, index, corpus=found['eligible'].corpus).supplement(
            plan['atoms'][0], page, dict(start=0, end=len(page['text']), text=page['text']))


def test_layout_preserves_document_wide_noforn_veto():
    from matryoshka_demo.io import digest
    case, plan, found, index = source_fixture(public_case('hypothesis', 'Majlis approved Bakhtiar government.'),
        ['MAJLIS EARLIER\nAPPROVED BAKHTIAR GOVERNMENT.'])
    page = index['p0']
    sibling = dict(page, id='hidden-sibling', text='NOFORN', source_sha256=digest('NOFORN'))
    index[sibling['id']] = sibling
    with pytest.raises(ValueError):
        assertion_matching.MatcherCase(case, index, corpus=found['eligible'].corpus).supplement(
            plan['atoms'][0], page, dict(start=0, end=len(page['text']), text=page['text']))


def test_layout_preserves_explicit_inclusive_same_day_policy():
    from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE
    case, plan, found, index = source_fixture(public_case('hypothesis', 'Majlis approved Bakhtiar government.',
        date='1971-06-01'), ['MAJLIS EARLIER\nAPPROVED BAKHTIAR GOVERNMENT.'])
    found['eligible'].corpus.source_view_policy = SOURCE_DAY_INCLUSIVE
    page = index['p0']
    row = assertion_matching.MatcherCase(case, index, corpus=found['eligible'].corpus).supplement(
        plan['atoms'][0], page, dict(start=0, end=len(page['text']), text=page['text']))
    assert row['direction'] == 'SUPPORT' and row['citation']['date'] == case['date']
