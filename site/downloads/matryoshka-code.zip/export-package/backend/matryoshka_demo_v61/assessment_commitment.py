"""Operator-accepted source/key commitment, outside answer-blind inference."""
from pathlib import Path

from matryoshka_demo.io import digest, load, save, sha

VERSION = "accepted-demo-assessment-source/6.1"


def prepare(root, release_path, *, execute=False):
    from .study import load_release
    root = Path(root).resolve()
    release_path, release = load_release(root, release_path)
    catalog = root / release["catalog_ref"]["path"]
    source = catalog.parent / "release_manifest.json"
    keys = catalog.parent / "private/evaluation_keys.json"
    seal = load(source)
    if seal["public_catalog_sha256"] != sha(catalog) or seal["artifacts"]["private/evaluation_keys.json"] != sha(keys):
        raise ValueError("Source release is inconsistent before assessment acceptance")
    value = dict(version=VERSION, release_ref=dict(path=str(release_path.relative_to(root)), sha256=sha(release_path)),
        catalog_ref=release["catalog_ref"], source_manifest_ref=dict(path=str(source.relative_to(root)), sha256=sha(source)),
        key_ref=dict(path=str(keys.relative_to(root)), sha256=sha(keys), used_for_inference=False),
        operator_accepted_before_assessment=True, cryptographic_signature=False)
    value["sha256"] = digest(value)
    target = root / "data/development_v6/assessment_source_commitments" / (sha(release_path)+".json")
    if target.exists() and load(target) != value:
        raise ValueError("Accepted assessment source changed; version it rather than overwriting the commitment")
    if execute and not target.exists():
        save(target, value)
    return value, dict(path=str(target.relative_to(root)), sha256=sha(target) if target.exists() else None)


def verify(root, manifest):
    root = Path(root).resolve()
    release = manifest["release_ref"]
    target = root / "data/development_v6/assessment_source_commitments" / (release["sha256"]+".json")
    value = load(target)
    if (value.get("version") != VERSION or value.get("release_ref") != release
            or value.get("operator_accepted_before_assessment") is not True
            or value.get("sha256") != digest({k:v for k,v in value.items() if k != "sha256"})):
        raise ValueError("Assessment source commitment changed")
    for field in ("release_ref", "catalog_ref", "source_manifest_ref", "key_ref"):
        ref = value[field]
        path = (root / ref["path"]).resolve()
        if not path.is_relative_to(root) or sha(path) != ref["sha256"]:
            raise ValueError("Accepted assessment "+field+" changed")
    return value, dict(path=str(target.relative_to(root)), sha256=sha(target))
