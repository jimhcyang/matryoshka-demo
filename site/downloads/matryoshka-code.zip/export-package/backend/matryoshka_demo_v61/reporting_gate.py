"""Same read-only native audit, bound to the follow-up dispatcher."""
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo_v6 import reporting_gate as previous
from . import study

VERSION = "ordered-selection-native-reporting-gate/6.1-followup"
_scope, _functions = clone(previous, dict(study=study, VERSION=VERSION,
    __package__=__package__, __file__=__file__))
for _name, _value in _functions.items():
    globals()[_name] = _value
