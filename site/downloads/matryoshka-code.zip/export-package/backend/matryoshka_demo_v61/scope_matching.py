"""Source-bound scope matching with protected nonfactive constraints."""
from copy import deepcopy
from functools import lru_cache
import re
from types import FunctionType

from matryoshka_demo.io import digest, offline
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo_v6 import task_execution as native
from matryoshka_demo_v6.planning import sentences
from . import planning

VERSION = "source-scoped-matching/6.1"
matching = native.previous.base.matching
_PURPOSE_NOUNS = {"effort", "attempt"}
_MODAL_ADJECTIVES = {"likely", "unlikely", "certain", "able", "unable"}


class AnalysisParser(native.previous._AnalysisParser):
    def __call__(self, text):
        doc = super().__call__(text).copy()
        raw = self.identity.parser(text)
        for token, original in zip(doc,raw):
            # The lowercase pipeline sometimes calls a literal long proper
            # name PRON/DT with no pronoun morphology. Short acronyms, real
            # pronouns, common roles and every character/identity stay intact.
            if (len(token.text) > 3 and token.text.isupper() and token.pos_ == "PRON" and token.tag_ == "DT"
                    and not token.morph.get("PronType") and original.pos_ == "PROPN"
                    and token.idx == original.idx and token.text == original.text):
                token.pos_ = "PROPN"
                token.tag_ = original.tag_
                token.lemma_ = original.text.casefold()
        return doc


_scope, _ = clone(native.previous,dict(_AnalysisParser=AnalysisParser))
_original_source = native.previous._source_frames.__wrapped__
_source_frames = FunctionType(_original_source.__code__,_scope,_original_source.__name__,
    _original_source.__defaults__,_original_source.__closure__)


@lru_cache(maxsize=512)
def _collective(lemma):
    try:
        return any(a.name() == "social_group.n.01" for s in native.old.lexicon().synsets(lemma,pos="n")
            for path in s.hypernym_paths() for a in path)
    except LookupError:
        return False


def _layout(engine,text):
    view, first, edits = engine.source_view(text)
    # Ordinary dictionary-attested word wraps were joined first. Retain the
    # literal hyphen of the remaining compounds; remove one wrapped newline.
    omitted = {i for m in re.finditer(r"(?<=[A-Za-z0-9.]-)[ \t]*\r?\n[ \t]*(?=[A-Za-z])",view)
        for i in range(*m.span())}
    second = [i for i in range(len(view)) if i not in omitted]
    offsets = [first[i] if first is not None else i for i in second]
    joined = "".join(view[i] for i in second)
    if omitted:
        edits.append(dict(kind="LITERAL_HYPHEN_COMPOUND_LINEWRAP",source_modified=False,hyphen_retained=True))
    initial,third,initial_edits = native.initialism_view(joined)
    if third is not None:
        offsets = [offsets[i] for i in third]
        edits.extend(initial_edits)
    return initial,offsets if first is not None or omitted or third is not None else None,edits


def _frame_at(frames,token):
    return next((f for f in frames if f["predicate_proof"]["start"] == token.idx),None)


def _repetition(phrase,doc):
    heads = [t for t in doc if any(p["start"] == t.idx and p["lemma"] == phrase["head"] for p in phrase["proofs"])]
    if any(any(c.lower_ in {"another","further"} for c in t.children) for t in heads):
        phrase["quantifiers"] = sorted(set(phrase["quantifiers"])|{"additional"})
        numbers = {number for t in heads for number in t.morph.get("Number")}
        if len(numbers) == 1:
            phrase["grammatical_number"] = next(iter(numbers))
    for modifier in phrase.get("modifiers",[]):
        _repetition(modifier["phrase"],doc)


def _existential_states(frames,doc):
    added = []
    for be in doc:
        if be.lemma_.casefold() != "be" or not any(c.dep_ == "expl" for c in be.children):
            continue
        attrs = [c for c in be.children if c.dep_ == "attr" and c.pos_ in {"NOUN","PROPN"}]
        if len(attrs) != 1:
            continue
        attribute = attrs[0]
        ways = [obj for prep in [*be.children,*attribute.children] if prep.dep_ == "prep" and prep.lower_ == "under"
            for obj in prep.children if obj.dep_ == "pobj" and obj.lemma_.casefold() == "way"]
        if len(ways) != 1:
            continue
        way = ways[0]
        owner = matching.phrase(attribute)
        owner["modifiers"] = [m for m in owner["modifiers"] if not (
            m["relation"] == "under" and any(p["start"] == way.idx for p in m["phrase"]["proofs"]))]
        if owner["unresolved"]:
            continue
        original = _frame_at(frames,attribute) or _frame_at(frames,be)
        state = dict(kind="PROPERTY",predicate="underway",predicate_proof=matching.proof(way),
            predicate_phrase=None,copula="be",roles=dict(owner=[owner]),qualifiers=matching.qualifiers(be),
            event_dates=deepcopy(original["event_dates"]) if original else [],passive=False,
            unbound_arguments=deepcopy(original["unbound_arguments"]) if original else [],
            deictic_time=native.old._attached_deictics(be),
            start=be.sent.start_char,end=be.sent.end_char,quote=be.sent.text,
            v61_projection=dict(kind="EXPLICIT_EXISTENTIAL_NP_STATE",state_spelling="under way",
                state_alias="underway",raw_predicate_proof=matching.proof(way),
                existential_referent=deepcopy(owner),scope_preserved=True))
        added.append(state)
        if original is not None:
            original["v61_replaced_existential_nominal"] = True
    for frame in frames:
        if frame["kind"] == "PROPERTY" and frame["predicate"] == "underway":
            frame["roles"].pop("property",None)
            frame["predicate_phrase"] = None
    return frames+added


def _nominal_one(frames,doc):
    states = [f for f in frames if f.get("v61_projection",{}).get("kind") == "EXPLICIT_EXISTENTIAL_NP_STATE"]
    for frame in frames:
        patients = frame["roles"].get("patient",[])
        if frame["predicate"] != "see" or len(patients) != 1 or patients[0]["head"] not in {"need","necessity"}:
            continue
        attached = [m for m in patients[0].get("modifiers",[]) if m["relation"] == "for"]
        values = frame["roles"].get("prep:for",[]) or [m["phrase"] for m in attached]
        if len(values) != 1 or values[0]["head"] != "one":
            continue
        one = next((t for t in doc if any(p["start"] == t.idx and p["lemma"] == "one" for p in values[0]["proofs"])),None)
        if one is None or not any(c.lower_ in {"further","another"} for c in one.children):
            continue
        antecedents = [f for f in states if f["start"] == frame["start"]
            and f["predicate_proof"]["start"] < one.idx and len(f["roles"].get("owner",[])) == 1]
        if len(antecedents) != 1:
            continue
        antecedent_head = next((t for t in doc if any(p["start"] == t.idx and p["lemma"] ==
            antecedents[0]["roles"]["owner"][0]["head"] for p in antecedents[0]["roles"]["owner"][0]["proofs"])),None)
        if (antecedent_head is None or antecedent_head.pos_ != "NOUN"
                or any(c.dep_ == "conj" and c.pos_ in {"NOUN","PROPN"} for c in antecedent_head.children)):
            continue
        antecedent = antecedents[0]["roles"]["owner"][0]
        # Type ellipsis licenses the noun, not all the antecedent's modifiers.
        # Nonasserted/status-qualified types and overtly qualified anaphors
        # need a different proof; do not erase those qualifications here.
        if (antecedent["role_qualifiers"] or any(p["lemma"] in {"possible","purported","fake","imaginary"}
                for p in antecedent["proofs"])
                or any(p["lemma"] not in {"one","another","further"} for p in values[0]["proofs"])
                or values[0].get("modifiers")
                or antecedents[0]["qualifiers"]["scope"] != frame["qualifiers"]["scope"]):
            continue
        number = "Sing" if one.lower_ == "one" else next(iter(one.morph.get("Number")),None)
        if number is None:
            continue
        head_proof = matching.proof(antecedent_head)
        phrase = dict(text=antecedent_head.text,head=antecedent["head"],terms=[antecedent["head"]],
            names=[],unresolved=False,quantifiers=["additional"],role_qualifiers=[],modifiers=[],
            descriptive_terms=[],proofs=[head_proof],grammatical_number=number)
        original_argument = deepcopy(values[0])
        prep = one.head
        if attached:
            attached[0]["phrase"] = phrase
        else:
            patients[0]["modifiers"].append(dict(relation="for",relation_proof=matching.proof(prep),phrase=phrase))
            frame["roles"].pop("prep:for")
        frame["v61_one_binding"] = dict(kind="SAME_SENTENCE_UNIQUE_EXISTENTIAL_NOMINAL_ONE",
            original_argument=original_argument,antecedent=deepcopy(antecedent),
            resolved_argument=deepcopy(phrase),original_anaphor_proof=matching.proof(one),
            additional_operator_preserved=True,entity_id_invented=False,resolution_inference=True,
            direct_literal_argument=False,resolution_scope="SAME_SENTENCE_EXISTENTIAL_TYPE_ELLIPSIS",
            qualified_modifiers_certified=False,head_only_projection=True,
            inherited_qualifications=[],
            antecedent_qualifications=[p["text"] for p in antecedent["proofs"] if p["start"] != antecedent_head.idx]
                +[m["relation"] for m in antecedent.get("modifiers",[])])


def _collective_anaphora(frames,doc):
    sentences = list(doc.sents)
    for i,sentence in enumerate(sentences[1:],1):
        previous = sentences[i-1]
        body_end = previous.start_char+len(previous.text.rstrip())
        if "\n\n" in doc.text[body_end:sentence.start_char]:
            continue
        demonstratives = [t for t in sentence if t.pos_ == "NOUN" and t.lemma_.casefold() == "group"
            and any(c.dep_ == "det" and c.lower_ == "this" for c in t.children)]
        subjects = [t for t in previous if t.dep_ in {"nsubj","nsubjpass"} and t.pos_ in {"NOUN","PROPN"}
            and _collective(t.lemma_.casefold())]
        if len(subjects) != 1:
            continue
        subject = subjects[0]
        # A competing explicit collective argument is ambiguous.
        if any(t != subject and _collective(t.lemma_.casefold())
                and t.dep_ in {"conj","dobj","pobj","nsubj"} for t in previous):
            continue
        antecedent = matching.phrase(subject)
        q = matching.qualifiers(subject.head)
        if (antecedent["unresolved"] or len(antecedent["terms"]) < 2 or q["scope"]
                or q["conditional"] or q["question"] or q["epistemic_absence"]):
            continue
        for group in demonstratives:
            for frame in frames:
                if frame["start"] != sentence.start_char:
                    continue
                changed = False
                for role,values in frame["roles"].items():
                    for j,value in enumerate(values):
                        if value["head"] == "group" and any(p["start"] == group.idx for p in value["proofs"]):
                            values[j] = deepcopy(antecedent)
                            changed = True
                if changed:
                    frame["v61_collective_binding"] = dict(kind="ADJACENT_SOURCE_COLLECTIVE_SUBJECT",
                        demonstrative=matching.proof(group),antecedent=deepcopy(antecedent),
                        factual_predicate_transferred=False,entity_id_invented=False)
                    frame["start"] = previous.start_char
                    frame["quote"] = doc.text[frame["start"]:frame["end"]]


def _constraints(frames,doc):
    for frame in frames:
        token = next((t for t in doc if t.idx == frame["predicate_proof"]["start"]),None)
        if token is None:
            continue
        children = []
        kind = None
        if frame["kind"] == "EVENT":
            carriers = [c for c in token.children if c.dep_ in {"dobj","obj"} and c.lemma_.casefold() in _PURPOSE_NOUNS]
            children = [child for carrier in carriers for child in carrier.children
                if child.dep_ == "acl" and child.pos_ == "VERB" and any(c.lower_ == "to" for c in child.children)]
            kind = "PURPOSE_NOT_COMPLETION"
        elif frame["kind"] == "PROPERTY" and frame["predicate"] in _MODAL_ADJECTIVES:
            children = [c for c in token.children if c.dep_ == "xcomp" and c.pos_ == "VERB"]
            kind = "MODAL_PROPOSITION_NOT_ACTUAL_EVENT"
        for child in children:
            embedded = _frame_at(frames,child)
            if embedded is None:
                continue
            goal = deepcopy(embedded)
            owner = frame["roles"].get("agent" if frame["kind"] == "EVENT" else "owner",[])
            if not goal["roles"].get("agent") and owner and not goal["passive"]:
                goal["roles"]["agent"] = deepcopy(owner)
            frame.setdefault("v61_constraints",[]).append(dict(kind=kind,frame=goal,
                actual_event_required=False,analysis_goal_quote=doc.text[child.left_edge.idx:child.right_edge.idx+len(child.right_edge)]))
            embedded["v61_embedded_constraint"] = dict(kind=kind,parent_predicate=frame["predicate"],
                parent_start=frame["predicate_proof"]["start"],actual_event_established=False)


class Engine(native._Engine):
    def __init__(self,parse=None):
        super().__init__(parse)
        self.analysis_parser = AnalysisParser(self.analysis_parser.identity.parser)
        self.parse = self.analysis_parser

    def frames(self,text,*,antecedents=False):
        key = ("v61",text,antecedents)
        if key in self.cache:
            return deepcopy(self.cache[key])
        view,offsets,edits = _layout(self,text)
        frames,resource = _source_frames(self.analysis_parser.identity,self.analysis_parser.language,view,antecedents)
        self.lexical_resource.update(resource)
        frames += native._appositions(view,self.parse)
        doc = self.parse(view)
        frames = _existential_states(frames,doc)
        for frame in frames:
            for values in frame["roles"].values():
                for phrase in values:
                    _repetition(phrase,doc)
            q = frame["qualifiers"]
            for scope in q["scope"]:
                if scope["predicate"] in native._ASSERTIVE_REPORTS:
                    for speaker in scope["speakers"]:
                        if speaker not in q["attribution"]:
                            q["attribution"].append(deepcopy(speaker))
            if "PRIOR_REPORTING_BLOCK_SCOPE_UNCLEAR" in q["unresolved"]:
                prior = view[:frame["start"]].split("\n\n")[-1]
                if not native._reporting_block(prior,self.parse):
                    q["unresolved"].remove("PRIOR_REPORTING_BLOCK_SCOPE_UNCLEAR")
        _nominal_one(frames,doc)
        if antecedents:
            _collective_anaphora(frames,doc)
        _constraints(frames,doc)
        if offsets is not None:
            frames = native.old._Engine.restore_offsets(frames,text,offsets)
            for frame in frames:
                frame.setdefault("v61_layout",[]).extend(deepcopy(edits))
        self.cache[key] = frames
        return deepcopy(frames)

    def targets(self,text):
        excluded = lambda f: f.get("v61_embedded_constraint") or f.get("v61_replaced_existential_nominal")
        # Delegate the ordinary target set, including V6's roleless reporting
        # filter. Restore only explicit parent constraints that native leaf
        # selection removed; no other native filter is replaced.
        result = [f for f in native._Engine.targets(self,text) if not excluded(f)]
        keys = {(f["kind"],f["predicate_proof"]["start"]) for f in result}
        for frame in self.frames(text):
            key = frame["kind"],frame["predicate_proof"]["start"]
            if frame.get("v61_constraints") and not frame.get("v3_binding") and not excluded(frame) and key not in keys:
                result.append(frame)
                keys.add(key)
        return result


def _constraint_match(target,source,engine):
    targets,sources = target.get("v61_constraints",[]),source.get("v61_constraints",[])
    if not targets:
        return True,[]
    records = []
    if len(targets) != len(sources):
        return False,[dict(reason="EMBEDDED_CONSTRAINT_COUNT_DIFFERS",target=len(targets),source=len(sources))]
    for wanted in targets:
        compared = []
        for offered in sources:
            if wanted["kind"] != offered["kind"]:
                continue
            normalize = lambda value: " ".join(value.casefold().split())
            if (wanted.get("analysis_goal_quote") and normalize(wanted["analysis_goal_quote"]) ==
                    normalize(offered.get("analysis_goal_quote",""))):
                # Only the complete, nonfactive complement may use exact
                # wording. Parent actor/assertion checks still run normally;
                # this cannot establish the embedded event's occurrence.
                compared.append(dict(direction="SUPPORT",basis="EXACT_WHOLE_NONFACTIVE_COMPLEMENT",
                    target_quote=wanted["analysis_goal_quote"],source_quote=offered["analysis_goal_quote"],
                    target_predicate_proof=deepcopy(wanted["frame"]["predicate_proof"]),
                    source_predicate_proof=deepcopy(offered["frame"]["predicate_proof"]),actual_event_established=False))
                continue
            match = native.compare_frames(wanted["frame"],offered["frame"],engine=engine)
            if match is not None:
                compared.append(match)
        supported = next((m for m in compared if m["direction"] == "SUPPORT"),None)
        records.append(dict(kind=wanted["kind"],supported_as_constraint=bool(supported),
            actual_event_required=False,matches=compared))
        if supported is None:
            return False,records
    return True,records


def compare_frames(target,source,*,engine=None):
    engine = engine or Engine()
    result = native.compare_frames(target,source,engine=engine)
    if result is None:
        return None
    if source.get("v61_embedded_constraint"):
        result.update(direction="RELATED")
        result["reasons"].append("SOURCE_EMBEDDED_PURPOSE_OR_MODAL_NOT_ACTUAL_EVENT")
        return result
    complete,records = _constraint_match(target,source,engine)
    if not complete and result["direction"] in {"SUPPORT","COUNTER"}:
        result["direction"] = "PARTIAL"
        result["reasons"].append("EMBEDDED_GOAL_OR_MODAL_PROPOSITION_NOT_MATCHED")
    if records:
        result["v61_constraint_comparison"] = records
    ellipsis = source.get("v61_one_binding",{})
    if ellipsis.get("head_only_projection") and result["direction"] in {"SUPPORT","COUNTER"}:
        def phrases(value):
            yield value
            for modifier in value.get("modifiers",[]):
                yield from phrases(modifier["phrase"])
        wanted = [p for values in target["roles"].values() for value in values for p in phrases(value)
            if p["head"] == ellipsis["resolved_argument"]["head"] and "additional" in p["quantifiers"]]
        if any(p.get("grammatical_number") != ellipsis["resolved_argument"]["grammatical_number"] for p in wanted):
            result["direction"] = "PARTIAL"
            result["reasons"].append("NOMINAL_ONE_NUMBER_NOT_MATCHED")
    for key in ("v61_projection","v61_one_binding","v61_collective_binding"):
        if source.get(key):
            result[key] = deepcopy(source[key])
    return result


def _bind(atom,query,engine):
    bound,issues = _native_bind(atom,query,engine)
    if bound and not issues:
        return bound,issues
    units = [u for u in sentences(query) if u["start"] < atom["end"] and atom["start"] < u["end"]]
    if not units:
        return bound,issues
    start,end = units[0]["start"],units[-1]["end"]
    context = query[start:end]
    found = []
    for target in engine.targets(atom["text"]):
        choices = []
        for candidate in engine.targets(context):
            match = compare_frames(target,candidate,engine=engine)
            if (match is not None and match["direction"] == "SUPPORT" and target["predicate"] == candidate["predicate"]
                    and atom["start"]-start <= candidate["predicate_proof"]["start"] < atom["end"]-start):
                choices.append(candidate)
        if len(choices) != 1:
            return bound,issues
        frame = deepcopy(choices[0])
        frame["query_context"] = dict(start=start,end=end,text=context)
        frame["v61_binding"] = "EXACT_SCOPED_QUERY_FRAME_NOT_EDITED_ATOM"
        found.append(frame)
    return (found,[]) if found else (bound,issues)


_native_bind = native._functions()["_bind"]


def execute(case,plan,retrieval,passage_budget=100):
    planning.validate_plan(plan,case)
    with offline():
        functions = native._functions(_Engine=Engine,compare_frames=compare_frames,_bind=_bind,VERSION=VERSION)
        result = functions["execute_v3"](case,plan,retrieval,passage_budget=passage_budget)
    result["scope_matching_policy"] = dict(version=VERSION,source_text_modified=False,
        nonfactive_complements_are_constraints=True,qualified_ellipsis_modifiers_certified=False)
    result["provided_plan_sha256"] = digest(plan)
    return result
