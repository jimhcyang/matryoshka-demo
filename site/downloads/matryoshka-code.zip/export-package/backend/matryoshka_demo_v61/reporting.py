"""Follow-up publication through the unchanged inspectable V6 interface."""
from pathlib import Path

from matryoshka_demo.io import load, sha
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo_v6 import reporting as previous

VERSION = "task-directed-inspection-report/6.1"
_scope, _functions = clone(previous, dict(VERSION=VERSION,
    __package__=__package__, __file__=__file__))
for _name, _value in _scope.items():
    if not _name.startswith("__") and _name != "VERSION":
        globals()[_name] = _value


_read_keys = _scope["assessment_keys"]


def assessment_keys(root, manifest):
    """Require the source-release commitment even before the first grading call."""
    from .study import load_release
    from .assessment_commitment import verify
    root = Path(root).resolve()
    verify(root, manifest)
    _, release = load_release(root, root / manifest["release_ref"]["path"])
    catalog = root / release["catalog_ref"]["path"]
    seal = load(catalog.parent / "release_manifest.json")
    expected = seal["artifacts"]["private/evaluation_keys.json"]
    if seal["public_catalog_sha256"] != sha(catalog):
        raise ValueError("Accepted source release and public catalog differ")
    keys_path = (catalog.parent / "private/evaluation_keys.json").resolve()
    if not keys_path.is_relative_to(root) or sha(keys_path) != expected:
        raise ValueError("Evaluation keys changed from the accepted source release")
    return _read_keys(root, manifest)


_scope["assessment_keys"] = assessment_keys
