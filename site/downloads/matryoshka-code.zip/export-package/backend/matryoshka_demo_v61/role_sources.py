"""Read pinned source-owned entity rows for bounded role-atom certificates.

No ledger access for non-role queries or unbound fixture corpora. A declared
but missing/changed native artifact is an integrity error, never a fallback.
"""
from collections import defaultdict
from copy import deepcopy
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re

from .role_alignment import align_role, digest, literal_pattern, normalized, pointer, query_roles

VERSION = "pinned-source-local-role-readout/6.1"


def _stamp(path):
    stat = path.stat()
    return stat.st_mtime_ns, stat.st_size, stat.st_ctime_ns, stat.st_ino


@lru_cache(maxsize=12)
def _verify(path, stamp, expected):
    path = Path(path)
    with path.open("rb") as handle:
        actual = hashlib.file_digest(handle,"sha256").hexdigest()
    if actual != expected or _stamp(path) != stamp:
        raise ValueError("Pinned role source artifact changed: "+str(path))
    return actual


def _pinned(corpus, key):
    declared = corpus.binding["files"].get(key)
    if not declared:
        raise ValueError("Required pinned role source artifact is absent: "+key)
    files = getattr(corpus,"files",{})
    workspace = getattr(corpus,"workspace",None)
    if workspace is not None:
        workspace = Path(workspace).resolve()
        expected = (workspace/declared["path"]).resolve()
        if not expected.is_relative_to(workspace):
            raise ValueError("Pinned role source path escapes workspace")
        path = Path(files.get(key,expected)).resolve()
        if path != expected:
            raise ValueError("Role source path differs from native binding")
    elif key in files:
        path = Path(files[key]).resolve()
    else:
        raise ValueError("Cannot resolve expected pinned role source: "+key)
    stamp = _stamp(path)  # Missing declared files MUST raise.
    _verify(str(path),stamp,declared["sha256"])
    return path,stamp


def _rows(path):
    with path.open() as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


@lru_cache(maxsize=3)
def _metadata(path, stamp, expected):
    _verify(path,stamp,expected)
    return json.loads(Path(path).read_text())["document_metadata"]


def _canonical_text(row, corpus):
    if corpus != "cib":
        return row["text"]
    return "".join(u.get("text","") if u.get("unit_type") == "shared_text" else " [REDACTION] "
                   for u in row["units"]).strip()


def _quote(page, row):
    quote = row.get("evidence_quote","")
    a,b = row.get("char_start"),row.get("char_end")
    if (type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"])
            or page["text"][a:b] != quote):
        return None
    return dict(canonical_page_id=page["id"],document_id=page["document_id"],date=page["date"],
        start=a,end=b,text=quote,page_sha256=page["source_sha256"])


def proofs(case, plan, pages, corpus):
    from matryoshka_demo.source_view_policy import policy_of, source_page_allowed
    """Return only role-atom certificates; all other query components stay native."""
    specs = query_roles(case,plan)
    if not specs:
        return []
    binding = getattr(corpus,"binding",None)
    if not binding or not binding.get("files",{}).get("entities"):
        return []
    if binding.get("corpus") != case["corpus"] or corpus.corpus != case["corpus"]:
        raise ValueError("Role corpus binding differs from public case")
    pins = {key:_pinned(corpus,key) for key in ("entities","pages")}
    if case["corpus"] != "cib":
        pins["projection"] = _pinned(corpus,"projection")
    admitted = {}
    for supplied in pages:
        pid = supplied.get("id",supplied.get("canonical_page_id")) if isinstance(supplied,dict) else supplied
        pi = pid if isinstance(pid,int) else corpus.page_index.get(pid)
        if pi is None:
            raise ValueError("Admitted role source is not in native corpus")
        original = corpus.pages[pi]
        if isinstance(supplied,dict) and any(supplied.get(k) != original[k]
                for k in ("text","document_id","date","source_sha256")):
            raise ValueError("Admitted role source differs from canonical full page")
        if not corpus.allowed[pi] or not source_page_allowed(original, case, policy_of(corpus),allow_legacy_visibility=True):
            continue
        if digest(original["text"]) != original["source_sha256"]:
            raise ValueError("Role canonical page text hash changed")
        # This is only a cheap necessary condition for the literal apposition;
        # it cannot replace the local-object and role checks below.
        if not any(re.search(r"(?<!\w)"+literal_pattern(s["person"]["label"])+r"(?!\w)",original["text"],re.I)
            and re.search(r"(?<!\w)"+literal_pattern(s["organization"]["label"])+r"(?!\w)",original["text"],re.I) for s in specs):
            continue
        admitted[original["id"]] = deepcopy(original)
    if not admitted:
        return []
    metadata = {}
    if case["corpus"] != "cib":
        path,stamp = pins["projection"]
        metadata = _metadata(str(path),stamp,binding["files"]["projection"]["sha256"])
    for pid,page in list(admitted.items()):
        if case["corpus"] != "cib":
            meta = metadata.get(page["document_id"],{})
            page["handling"] = list(meta.get("handling",[]))
            if (meta.get("classification") != "CONFIDENTIAL" or meta.get("policy_role") != "confidential_evidence"
                    or meta.get("date_iso") != page["date"] or page.get("classification") != "CONFIDENTIAL"
                    or any("NOFORN" in str(h).upper() for h in page["handling"])):
                del admitted[pid]
    if not admitted:
        return []
    docs = {p["document_id"] for p in admitted.values()}
    audits = defaultdict(list)
    seen = set()
    for raw in _rows(pins["pages"][0]):
        if raw["document_id"] not in docs:
            continue
        pid = raw.get("canonical_page_id",raw.get("segment_id"))
        text = _canonical_text(raw,case["corpus"])
        audits[raw["document_id"]].append(dict(canonical_page_id=pid,
            raw_text_utf8_sha256=hashlib.sha256(text.encode()).hexdigest(),
            standalone_noforn=bool(re.search(r"\bNOFORN\b",text,re.I))))
        if pid in admitted:
            if text != admitted[pid]["text"]:
                raise ValueError("Role page differs from pinned prepared source")
            seen.add(pid)
    if seen != set(admitted):
        raise ValueError("Role admitted source missing from pinned raw pages")
    if case["corpus"] != "cib":
        veto = {doc for doc,rr in audits.items() if any(r["standalone_noforn"] for r in rr)}
        admitted = {pid:p for pid,p in admitted.items() if p["document_id"] not in veto}
    if not admitted:
        return []
    groups = defaultdict(list)
    for row in _rows(pins["entities"][0]):
        pid = row.get("canonical_page_id")
        if pid in admitted and row.get("visibility") == "both" and not row.get("introduced_by_slot_id"):
            groups[row["job_id"],pid].append(row)
    certificates = []
    for (job,pid),records in groups.items():
        page = admitted[pid]
        if not any(any(normalized(r.get("label","")) == normalized(s["person"]["label"]) for r in records) for s in specs):
            continue
        objects = []
        invalid = False
        for row in records:
            if row.get("document_id") != page["document_id"] or row.get("document_date_iso") != page["date"]:
                invalid = True; break
            citation = _quote(page,row)
            if citation is None:
                invalid = True; break
            objects.append(dict(row_id=row["mention_id"],record=row,citation=citation))
        # Never drop an ungrounded duplicate and then claim unique identity.
        if invalid or len({o["row_id"] for o in objects}) != len(objects):
            continue
        scope = dict(kind="SOURCE_LOCAL_ENTITY_RECORDS",corpus=case["corpus"],canonical_page_id=pid,
            document_id=page["document_id"],date=page["date"],page_sha256=page["source_sha256"],
            job_id=job,source_objects={o["row_id"]:pointer(o) for o in objects},
            whole_document_audit=audits[page["document_id"]])
        for spec in specs:
            certificate = align_role(case,plan,page,objects,scope,atom_id=spec["atom"]["id"],
                source_view_policy=policy_of(corpus))
            if certificate["status"] != "KG_MEDIATED_ROLE_ALIGNMENT":
                continue
            certificate.update(source_ledger_ref=deepcopy(binding["files"]["entities"]),
                prepared_source_ref=deepcopy(binding["files"]["pages"]),source_binding_sha256=digest(binding),
                source_job_object_count=len(objects),scope_job_object_set_sha256=digest(scope["source_objects"]),
                whole_document_audit=deepcopy(scope["whole_document_audit"]))
            certificate.pop("certificate_sha256",None)
            certificate["certificate_sha256"] = digest(certificate)
            certificates.append(certificate)
    for path,stamp in pins.values():
        if _stamp(path) != stamp:
            raise ValueError("Pinned role source changed during streaming")
    return certificates
