"""Versioned source-owned construction with paired-NP-quote layout fitting."""
from copy import deepcopy
import re
from types import ModuleType

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo_v6 import candidates as native_candidates
from matryoshka_demo_v6 import task_execution as native_task
from matryoshka_demo_v6 import planning as source_units
from . import planning

VERSION = "source-owned-candidates/6.1"
RANK_TIERS = native_candidates.RANK_TIERS
BASE_VERSION = native_candidates.BASE_VERSION


def quoted_nominal_view(case):
    q,marker = case["query"],case["focal_marker"]
    at = q.index(marker)
    end = at+len(marker)
    stack,pairs = [],[]
    for i,char in enumerate(q):
        if char == '"':
            if stack and stack[-1][1] == '"':
                pairs.append((stack.pop()[0],i))
            else:
                stack.append((i,char))
        elif char == "\u201c":
            stack.append((i,char))
        elif char == "\u201d":
            if not stack or stack[-1][1] != "\u201c":
                return None
            pairs.append((stack.pop()[0],i))
    if stack:
        return None
    enclosing = [(a,b) for a,b in pairs if a < at < end <= b]
    if len(enclosing) != 1:
        return None
    a,b = enclosing[0]
    if q[end:b].strip():
        return None
    prefix = q[a+1:at]
    if re.search(r"[,;:!?]",prefix) or not native_candidates._layout_safe(native_candidates._tokens(prefix)):
        return None
    parse = native_task._Engine().parse
    if any(t.pos_ in {"VERB","AUX","PRON"} for t in parse(prefix)):
        return None
    after = q[b+1:].lstrip()
    if not after or not after[0].isalnum():
        return None
    first = next((t for t in parse(after) if not t.is_space),None)
    if first is None or first.pos_ not in {"NOUN","PROPN"}:
        return None
    visible = q[:a]+" "+q[a+1:b]+" "+q[b+1:]
    return dict(case=dict(case,query=visible),proof=dict(kind="PAIRED_VISIBLE_NP_QUOTES_LAYOUT_ONLY",
        quote_offsets=[a,b],quote_characters=[q[a],q[b]],original_query_sha256=digest(q),
        analysis_query_sha256=digest(visible),same_character_offsets=True,
        query_modified=False,source_modified=False,assertion_scope_certified=False))


def boundary_fit(case,fill):
    view = quoted_nominal_view(case)
    if view is None:
        at = case["query"].index(case["focal_marker"])
        units = [u for u in source_units.sentences(case["query"]) if u["start"] <= at < u["end"]]
        if units and any(c in units[0]["text"] for c in {'"',"\u201c","\u201d"}):
            return dict(fill=fill,original_fill=fill,admissible=bool(fill.strip()),remaining_fill_span=[0,len(fill)],
                edits=[],source_text_modified=False,quote_layout_withheld="NO_LICENSED_PAIRED_NP_QUOTE_BOUNDARY")
        return native_candidates.boundary_fit(case,fill)
    result = native_candidates.boundary_fit(view["case"],fill)
    for edit in result["edits"]:
        edit["analysis_visible_text"] = edit["visible_text"]
        edit["visible_text"] = case["query"][edit["visible_query_start"]:edit["visible_query_end"]]
        edit["paired_quote_layout"] = deepcopy(view["proof"])
    result["visible_quote_layout"] = deepcopy(view["proof"])
    return result


def _grammar_admission(case,reading,fill,parse,bounds):
    result = native_task._grammar_admission(case,reading,fill,parse,bounds)
    view = quoted_nominal_view(case)
    if view is None or reading.get("form") != "modifier":
        return result
    analysis = native_task._grammar_admission(view["case"],reading,fill,parse,bounds)
    licensed = analysis.get("compound_modifier",{}).get("licensed")
    if not licensed:
        return result
    result["reasons"] = [r for r in result["reasons"] if r != "NOMINAL_OR_FINITE_FILL_IS_NOT_A_MODIFIER"]
    result["admissible"] = not result["reasons"]
    result["compound_modifier"] = dict(analysis["compound_modifier"],paired_quote_layout=view["proof"],
        original_head_pos=result.get("head_pos"),original_postnominal_modifier=result.get("postnominal_modifier"))
    result["postnominal_modifier"] = False
    result["quoted_np_analysis"] = dict(view["proof"],head_pos=analysis["head_pos"],head_tag=analysis["head_tag"],
        lexical_source_words_changed=False,quotation_semantics_not_erased=True)
    return result


_task_scope,_task_functions = clone(native_task,dict(_grammar_admission=_grammar_admission,VERSION=VERSION+":grammar"))
_admission = ModuleType("matryoshka_demo_v61._quote_admission")
_admission.__dict__.update(_task_scope)


class Context(native_candidates.Context):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if quoted_nominal_view(self.case) is None:
            return
        language = getattr(native_task._raw_parser(),"nlp",None)
        # The private source cache otherwise hides the model handle needed to
        # preserve its original tokenization during uppercase analysis.
        if language is not None and self.parse(self.case["query"]).vocab is language.vocab:
            self.parse.nlp = language


_scope,_functions = clone(native_candidates,dict(boundary_fit=boundary_fit,Context=Context,
    task_execution=_admission,VERSION=VERSION))


def construct(case,plan,retrieval,*,passage_budget=100,top_k=5):
    case = public_case(case)
    planning.validate_plan(plan,case)
    result = _functions["construct"](case,plan,retrieval,passage_budget=passage_budget,top_k=top_k)
    result["quote_layout_policy"] = dict(version=VERSION,native_modules_modified=False,
        layout_view=deepcopy((quoted_nominal_view(case) or {}).get("proof")),
        source_and_query_quotes_preserved=True,known_answer_bonus=False)
    return result


def filter_redaction(case,result,top_k=5,*,retrieval=None,passage_budget=100,parse=None):
    """Compatibility filter; parent execution can inject _grammar_admission."""
    return _task_functions["filter_redaction"](case,result,top_k=top_k,retrieval=retrieval,
        passage_budget=passage_budget,parse=parse)


def grammar_admission(case,reading,fill,*,parse=None):
    return _task_functions["grammar_admission"](case,reading,fill,parse=parse)


def finalize_untyped(result,*,top_k=5):
    return _functions["finalize_untyped"](result,top_k=top_k)
