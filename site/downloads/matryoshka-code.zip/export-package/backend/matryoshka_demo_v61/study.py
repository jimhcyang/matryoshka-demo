"""Versioned V6.1 dispatcher with its own immutable code/file-set identity.

The execution/checkpoint protocol is unchanged. Shared helpers and frozen V6
components remain bound in the archive alongside this follow-up package.
"""
from pathlib import Path
import fcntl

from matryoshka_demo.io import sha
from matryoshka_demo.vendor.matching import clone
from matryoshka_demo_v6 import study as previous

VERSION = "atomic-only-three-task-study/6.1"
ARMS = previous.ARMS
CHECKPOINT_VERSION = previous.CHECKPOINT_VERSION


def binding(root):
    root = Path(root).resolve()
    result = previous.binding(root)
    excluded = ("server", "reporting", "assessment", "ui_release", "corpus_explorer", "flow_projection", "digest", "guide")
    for path in (root / "matryoshka_demo_v61").rglob("*.py"):
        if not path.name.startswith(excluded):
            result[str(path.relative_to(root))] = sha(path)
    return dict(sorted(result.items()))


def _save(path, value):
    path = Path(path)
    if path.name != "latest_run_v6.json":
        return previous.save(path, value)
    # Independent shards may finish together. The inherited writer uses a
    # fixed temporary filename, so serialize only this shared convenience pin.
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_suffix(".lock").open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return previous.save(path, value)


_scope, _functions = clone(previous, dict(VERSION=VERSION, binding=binding,
    save=_save, __package__=__package__, __file__=__file__))
for _name, _value in _scope.items():
    if not _name.startswith("__") and _name not in {"binding", "VERSION"}:
        globals()[_name] = _value
