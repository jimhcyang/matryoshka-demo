"""Isolated follow-up; frozen V6 native outputs are never rewritten."""
VERSION = "source-scoped-three-task-workbench/6.1"
