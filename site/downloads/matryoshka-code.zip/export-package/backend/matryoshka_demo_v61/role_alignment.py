"""Source-local literal role certificates; no global aliases or node attributes.

Pure standard-library interpretation. Only a complete positive past role atom
is certified. Other H/R components remain for the native task engine to check.
"""
from copy import deepcopy
from datetime import date
import hashlib
import json
import re

VERSION = "source-local-role-certificate/6.1"
ROLES = frozenset("chairman chairwoman chairperson president director secretary commander minister member chief head leader governor treasurer".split())
ORGANIZATION_TYPES = frozenset({"Organization", "Government", "Military", "PoliticalGroup", "ReligiousGroup"})
ROLE_QUERY = re.compile(r"(?P<person>[^,.!?;:\n]+?)\s+was\s+(?:the\s+)?(?P<role>[A-Za-z]+)\s+of\s+(?:the\s+)?(?P<organization>[^,.!?;:\n]+)\.")


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def public_case(case):
    fields = ("case_id", "corpus", "task", "query", "document_id", "date", "focal_marker")
    value = {key:case[key] for key in fields}
    if (value["task"] not in {"hypothesis","reconstruction"} or value["corpus"] not in {"cib","iran","vietnam"}
            or not isinstance(value["query"],str) or not value["query"].strip() or not value["document_id"]
            or value["focal_marker"] or not re.fullmatch(r"\d{4}-\d{2}-\d{2}",value["date"])):
        raise ValueError("A complete public H/R case is required")
    date.fromisoformat(value["date"])
    return value


class Refusal(ValueError):
    pass


def require(condition, reason):
    if not condition:
        raise Refusal(reason)


def normalized(text):
    return " ".join(text.split()).casefold()


def literal_pattern(text):
    return r"\s+".join(re.escape(word) for word in text.split())


def pointer(entry):
    row = entry["record"]
    return dict(row_id=entry["row_id"], job_id=row["job_id"], local_id=row["local_id"],
        canonical_page_id=row["canonical_page_id"], document_id=row["document_id"],
        document_date=row["document_date_iso"], extraction_run_id=row["extraction_run_id"],
        original_record_sha256=digest(row))


def _source_context(page, objects, scope, case, source_view_policy=None):
    from matryoshka_demo.source_view_policy import STRICT_PRIOR, source_page_allowed
    policy = STRICT_PRIOR if source_view_policy is None else source_view_policy
    require(scope.get("kind") == "SOURCE_LOCAL_ENTITY_RECORDS", "GLOBAL_OR_UNOWNED_ATTRIBUTES_FORBIDDEN")
    require(not any(k in scope for k in ("representative_descriptions", "aliases", "maximum_document_date", "properties")),
            "GLOBAL_OR_FUTURE_AGGREGATE_FORBIDDEN")
    require(scope["corpus"] == case["corpus"] == page["corpus"], "CORPUS_MISMATCH")
    require(scope["canonical_page_id"] == page["id"] and scope["document_id"] == page["document_id"]
            and scope["date"] == page["date"], "LOCAL_PAGE_DOCUMENT_DATE_MISMATCH")
    require(source_page_allowed(page, case, policy,allow_legacy_visibility=True),
            "SOURCE_CUTOFF_OR_ORIGIN_VIOLATION")
    require(digest(page["text"]) == page["source_sha256"] == scope["page_sha256"], "PAGE_HASH_MISMATCH")
    document_audit = scope["whole_document_audit"]
    require(document_audit, "WHOLE_DOCUMENT_HANDLING_AUDIT_MISSING")
    own = [r for r in document_audit if r["canonical_page_id"] == page["id"]]
    require(len(own) == 1 and own[0]["raw_text_utf8_sha256"] == hashlib.sha256(page["text"].encode()).hexdigest(),
            "DOCUMENT_AUDIT_PAGE_MISMATCH")
    if case["corpus"] in {"iran", "vietnam"}:
        require(page["classification"] == "CONFIDENTIAL" and not any(r["standalone_noforn"] for r in document_audit)
                and not any("NOFORN" in str(h).upper() for h in page.get("handling", [])), "CABLE_HANDLING_VETO")
    expected = scope["source_objects"]
    require(len(objects) == len(expected) and {e["row_id"] for e in objects} == set(expected), "INCOMPLETE_OR_DUPLICATED_LOCAL_OBJECT_SET")
    local_ids = set()
    for entry in objects:
        row = entry["record"]
        require(pointer(entry) == expected[entry["row_id"]], "LOCAL_OBJECT_ID_OR_RECORD_BINDING_MISMATCH")
        require(row["mention_id"] == entry["row_id"] and row["local_id"] not in local_ids,
                "LOCAL_OBJECT_ID_OR_RECORD_BINDING_MISMATCH")
        local_ids.add(row["local_id"])
        require(row["job_id"] == scope["job_id"] and row["canonical_page_id"] == page["id"]
                and row["document_id"] == page["document_id"] and row["document_date_iso"] == page["date"],
                "LOCAL_PAGE_JOB_OR_DATE_MISMATCH")
        require(row["visibility"] == "both" and not row.get("introduced_by_slot_id"), "NONSHARED_OBJECT_FORBIDDEN")
        citation = entry["citation"]
        require(citation["canonical_page_id"] == page["id"] and citation["document_id"] == page["document_id"]
                and citation["date"] == page["date"] and citation["page_sha256"] == page["source_sha256"], "CITATION_ID_MISMATCH")
        a, b = citation["start"], citation["end"]
        require(type(a) is int and type(b) is int and 0 <= a < b <= len(page["text"]), "INVALID_CITATION_OFFSETS")
        require(page["text"][a:b] == citation["text"] and normalized(citation["text"]) == normalized(row["evidence_quote"]),
                "QUOTE_REPLAY_FAILED")


def _unqualified(row):
    return (row.get("assertion_mode") in {"unknown","observation","report"}
            and not row.get("speaker") and not row.get("temporal_context"))


def query_roles(case, plan):
    """Return exact role-atom/KG subsets, or [] BEFORE any corpus access."""
    try:
        case = public_case(case)
        atoms = plan.get("atoms", [])
        candidates = [(a, ROLE_QUERY.fullmatch(a["text"])) for a in atoms]
        candidates = [(a,m) for a,m in candidates if m is not None]
        if not candidates:
            return []
        require(plan["task"] == case["task"] and plan["query_sha256"] == digest(case["query"]), "QUERY_PLAN_BINDING_MISMATCH")
        require(len({a["id"] for a in atoms}) == len(atoms), "QUERY_ATOM_IDS_AMBIGUOUS")
        ordered = sorted(atoms,key=lambda a:a["start"])
        prior = 0
        for atom in ordered:
            a,b = atom["start"],atom["end"]
            require(type(a) is int and type(b) is int and prior <= a < b <= len(case["query"])
                and not case["query"][prior:a].strip() and atom.get("required") is True
                and case["query"][a:b] == atom["text"] == atom["source_quote"], "NONLITERAL_OR_UNCONSUMED_QUERY_CONTEXT")
            prior = b
        require(not case["query"][prior:].strip(), "UNCONSUMED_QUERY_CONTEXT")
        if case["task"] == "hypothesis":
            require(len(atoms) == 1 and atoms[0]["text"] == case["query"], "HYPOTHESIS_NOT_ONE_LITERAL_ROLE_ATOM")
        kg = plan["extractions"]
        ids = [r["local_id"] for records in kg.values() for r in records]
        require(len(ids) == len(set(ids)), "QUERY_LOCAL_OBJECT_IDS_AMBIGUOUS")
        results = []
        for atom, match in candidates:
            person,role,organization = (match[k] for k in ("person","role","organization"))
            if role.casefold() not in ROLES:
                continue
            if not all(w[0].isupper() and re.fullmatch(r"[A-Za-z]+(?:[-'][A-Za-z]+)*",w) for w in person.split()):
                continue
            people = [e for e in kg["entities"] if normalized(e["label"]) == normalized(person)]
            orgs = [e for e in kg["entities"] if normalized(e["label"]) == normalized(organization)]
            claims = [c for c in kg["claims"] if c["claim_text"] == atom["text"] == c["evidence_quote"]]
            if len(people) != 1 or len(orgs) != 1 or len(claims) != 1:
                continue
            p,o,c = people[0],orgs[0],claims[0]
            if p["type"] != "Person" or o["type"] not in ORGANIZATION_TYPES | {"Other"} or not _unqualified(c):
                continue
            if c.get("target","").rstrip(".") not in {"",atom["text"].rstrip("."),person,organization}:
                continue
            if any(e["evidence_quote"] not in atom["text"] or normalized(e["label"]) not in normalized(e["evidence_quote"])
                or e.get("description") and normalized(e["description"]) != normalized(e["label"]) for e in (p,o)):
                continue
            if any(e["evidence_quote"] == atom["text"] for e in kg["events"]):
                continue
            relations = [r for r in kg["relations"] if r["evidence_quote"] == atom["text"]]
            if not relations or not all(_unqualified(r) for r in relations):
                continue
            claim_targets = {(r["source"],r["target"]) for r in relations if r["relation"] == "CLAIM_TARGET"}
            affiliation = [(r["source"],r["target"]) for r in relations if r["relation"] == "AFFILIATION"]
            good_targets = len(relations) == 2 and claim_targets == {(c["local_id"],p["local_id"]),(c["local_id"],o["local_id"])}
            good_affiliation = len(relations) == 1 and affiliation == [(p["local_id"],o["local_id"])]
            if not (good_targets or good_affiliation):
                continue
            subset = dict(entities=deepcopy([p,o]),claims=[deepcopy(c)],events=[],relations=deepcopy(relations))
            results.append(dict(atom=deepcopy(atom),match=dict(match.groupdict()),person=deepcopy(p),
                organization=deepcopy(o),claim=deepcopy(c),subset=subset,
                subset_policy="EXACT_SUBSET_NO_ADDED_OR_REWRITTEN_KG_FIELDS",
                original_plan_sha256=digest(plan), whole_case_sha256=digest(case)))
        return results
    except (Refusal,KeyError,TypeError,ValueError):
        return []


def _source_role(case, spec, page, objects, scope, source_view_policy=None):
    from matryoshka_demo.source_view_policy import STRICT_PRIOR, descriptor
    policy = STRICT_PRIOR if source_view_policy is None else source_view_policy
    _source_context(page, objects, scope, case, source_view_policy)
    query_match, query_person, query_organization = spec["match"], spec["person"], spec["organization"]
    # Compare the complete QUERY label to the complete LOCAL label. The longer
    # raw name below only corroborates this already-bound source object.
    people = [e for e in objects if normalized(e["record"]["label"]) == normalized(query_match["person"])]
    require(len(people) == 1, "LOCAL_PERSON_LABEL_ABSENT_OR_AMBIGUOUS")
    person = people[0]; row = person["record"]
    require(row["type"] == "Person", "SOURCE_LOCAL_OBJECT_NOT_PERSON")
    organizations = [e for e in objects if normalized(e["record"]["label"]) == normalized(query_match["organization"])]
    require(len(organizations) == 1 and organizations[0]["record"]["type"] in ORGANIZATION_TYPES,
            "SOURCE_ORGANIZATION_LABEL_TYPE_OR_AMBIGUITY")
    organization = organizations[0]
    for own in (person, organization):
        require(own["record"]["char_start"] == own["citation"]["start"]
                and own["record"]["char_end"] == own["citation"]["end"]
                and own["record"]["evidence_quote"] == own["citation"]["text"], "OWN_RECORD_QUOTE_OFFSETS_MISMATCH")
    role_pattern = literal_pattern(query_match["role"])
    org_pattern = literal_pattern(query_match["organization"])
    description = re.fullmatch(r"(?P<name>[^,]+),\s*(?:described as|identified as)\s+(?:the\s+)?" + role_pattern
        + r"\s+of\s+(?:the\s+)?" + org_pattern + r"\.", row["description"], re.I)
    require(description is not None, "SOURCE_OWN_DESCRIPTION_ROLE_MISMATCH")
    full_name = description["name"]
    require(all(w[0].isupper() for w in full_name.split())
            and all(re.fullmatch(r"[A-Za-z]+(?:[-'][A-Za-z]+)*", w) for w in full_name.split()), "DESCRIPTION_NAME_NOT_PROPER_NAME")
    label_in_name = re.search(r"(?<!\w)"+literal_pattern(row["label"])+r"(?!\w)", full_name, re.I)
    require(label_in_name is not None, "LOCAL_LABEL_NOT_ATTESTED_IN_OWN_FULL_NAME")
    apposition = re.compile(r"(?<!\w)(?P<name>"+literal_pattern(full_name)+r"),\s*(?P<role>"+role_pattern
        +r")\s+of\s+(?:the\s+)?(?P<organization>"+org_pattern+r"),", re.I)
    matches = list(apposition.finditer(page["text"]))
    citation = person["citation"]
    matches = [m for m in matches if citation["start"] <= m.start() and m.end() <= citation["end"]]
    require(len(matches) == 1, "LITERAL_PROPER_NAME_ROLE_APPOSITION_ABSENT_OR_AMBIGUOUS")
    raw = matches[0]
    label_match = re.search(r"(?<!\w)"+literal_pattern(row["label"])+r"(?!\w)", raw["name"], re.I)
    require(label_match is not None, "RAW_LOCAL_LABEL_NOT_ATTESTED")
    org_quote = organization["citation"]
    require(org_quote["start"] <= raw.start("organization") and raw.end("organization") <= org_quote["end"],
            "ROLE_ORGANIZATION_NOT_SAME_LOCAL_OBJECT_QUOTE")
    # Only a source-owned paragraph/numbered-section lead is licensed. Do not
    # unwrap allegation, quotation, conditional, negation or a prior speaker.
    section_markers = list(re.finditer(r"(?m)^\s*\d+\.\s*", page["text"][:raw.start()]))
    starts = [0] + [m.end() for m in section_markers]
    prefix = page["text"][max(starts):raw.start()]
    require(not prefix.strip(), "APPOSITION_HAS_UNLICENSED_GOVERNING_OR_REPORTING_CONTEXT")
    before_section = page["text"][:section_markers[-1].start()].rstrip() if section_markers else ""
    require(not before_section or before_section.endswith((".", "!", "?")), "OPEN_REPORTING_OR_QUOTED_SECTION_CONTEXT")
    before_name = page["text"][:raw.start()]
    require((before_name.count('"') + before_name.count("\u201c") + before_name.count("\u201d")) % 2 == 0,
            "OPEN_REPORTING_OR_QUOTED_SECTION_CONTEXT")
    proof = dict(canonical_page_id=page["id"], document_id=page["document_id"], date=page["date"],
        start=raw.start(), end=raw.end(), text=page["text"][raw.start():raw.end()], page_sha256=page["source_sha256"])
    return dict(version=VERSION, status="KG_MEDIATED_ROLE_ALIGNMENT", case_id=case["case_id"], query_sha256=digest(case["query"]),
        claim=spec["atom"]["text"], quote=deepcopy(citation), apposition_quote=proof,
        source_person=pointer(person), source_organization=pointer(organization),
        interpretation_trace=[
            dict(step="QUERY_SCOPE", grammar="PERSON was [the] ROLE of [the] ORGANIZATION.", full_role_atom_consumed=True,
                extracted_scope_was_unknown=spec["claim"]["assertion_mode"] == "unknown",
                interpretation="Explicit positive past-role grammar only; no date, reporting clause, negation, or extra predicate is dropped."),
            dict(step="EXACT_LOCAL_ENTITY_LABEL", query_entity_id=query_person["local_id"], query_label=query_person["label"],
                source_local_id=row["local_id"], source_row_id=person["row_id"], source_label=row["label"],
                comparison="Complete labels equal under case/whitespace only", suffix_identity_matching=False),
            dict(step="OWN_ROLE_DESCRIPTION", source_description=row["description"], description_is_raw_quote=False,
                role=query_match["role"], organization=query_match["organization"], role_head_in_declared_person_role_inventory=True),
            dict(step="LITERAL_PROPER_NAME_APPOSITION", raw_person=raw["name"], raw_role=raw["role"], raw_organization=raw["organization"],
                proper_name_span=[raw.start("name"),raw.end("name")], role_span=[raw.start("role"),raw.end("role")],
                organization_span=[raw.start("organization"),raw.end("organization")], quotation_original=True),
            dict(step="SAME_LOCAL_ORGANIZATION", query_entity_id=query_organization["local_id"],
                query_type=query_organization["type"], source_local_id=organization["record"]["local_id"],
                source_type=organization["record"]["type"], unknown_query_type_not_falsely_certified=True),
            dict(step="SCOPE_LIMIT", source_date=page["date"], cutoff=case["date"],source_view_policy=descriptor(policy),
                strictly_before=case["date"] if descriptor(policy)["date_relation"] == "<" else None,
                origin_excluded=case["document_id"] if case["corpus"] != "cib" or policy is STRICT_PRIOR else None,
                historical_role_statement_only=True, current_role_persistence_inferred=False)],
        global_node_aggregate_used=False, canonical_identity_merge=False, certificate_only=True,
        certifies_whole_query=False, source_statement_alignment_not_world_truth=True, api_calls=0)



def align_role(case, plan, page, local_objects, source_scope, *, atom_id, source_view_policy=None):
    """Issue one atom-scoped certificate, never a whole-query truth verdict."""
    try:
        case = public_case(case)
        views = [s for s in query_roles(case,plan) if s["atom"]["id"] == atom_id]
        require(len(views) == 1,"NO_UNIQUE_BOUNDED_ROLE_ATOM")
        spec = views[0]
        result = _source_role(case,spec,page,local_objects,source_scope,source_view_policy)
        result.update(atom_id=atom_id, whole_query_sha256=digest(case["query"]),
            whole_case_sha256=digest(case), original_plan_sha256=spec["original_plan_sha256"],
            atom_sha256=digest(spec["atom"]["text"]), atom_binding=deepcopy(spec["atom"]),
            query_extraction_subset=deepcopy(spec["subset"]), query_subset_sha256=digest(spec["subset"]),
            query_subset_policy=spec["subset_policy"],
            remaining_query_atom_ids=[a["id"] for a in plan["atoms"] if a["id"] != atom_id],
            certificate_only=True,certifies_whole_query=False)
        result["interpretation_trace"].insert(0,dict(step="EXACT_ORIGINAL_QUERY_ROLE_SUBSET",
            whole_query_sha256=result["whole_query_sha256"],atom_id=atom_id,
            original_start=spec["atom"]["start"],original_end=spec["atom"]["end"],
            fields_added_or_rewritten=False,other_atoms_certified=False,
            original_local_relation_ids=[r["local_id"] for r in spec["subset"]["relations"]]))
        identity = next(t for t in result["interpretation_trace"] if t["step"] == "EXACT_LOCAL_ENTITY_LABEL")
        raw = next(t for t in result["interpretation_trace"] if t["step"] == "LITERAL_PROPER_NAME_APPOSITION")
        a,b = raw["proper_name_span"]
        found = list(re.finditer(r"(?<!\w)"+literal_pattern(identity["source_label"])+r"(?!\w)",page["text"][a:b],re.I))
        require(len(found) == 1,"AMBIGUOUS_LOCAL_LABEL_WITHIN_OWN_RAW_NAME")
        lo,hi = a+found[0].start(),a+found[0].end()
        result["source_actor_label"] = page["text"][lo:hi]
        result["source_actor_label_span"] = [lo,hi]
        result["certificate_sha256"] = digest(result)
        return result
    except (Refusal,KeyError,TypeError,ValueError) as error:
        return dict(version=VERSION,status="UNRESOLVED",reason=str(error),certificate_only=True,
            certifies_whole_query=False,absence_is_counterevidence=False)


# Kept small and explicit for callers porting the tested experimental API.
align = align_role
