"""Source-scoped task decisions with independently checked local KG roles.

Role certificates add one scoped comparison, never a new alias or a fact from
an aggregate node description. Ordinary frames retain every existing gate.
"""
from copy import deepcopy

from matryoshka_demo.contracts import public_case
from matryoshka_demo.io import digest, offline
from matryoshka_demo_v6 import task_execution as native

VERSION = "source-structured-task-execution/6.1"
SLOTS = native.SLOTS


def _signature(frame):
    return digest({k: frame[k] for k in ("kind", "predicate", "predicate_proof",
        "roles", "qualifiers", "event_dates", "predicate_phrase", "unbound_arguments")})


def _role_match(target, source):
    certificate = source.get("source_local_role_certificate")
    if not certificate or _signature(target) not in source["target_frame_signatures"]:
        return None
    matched = {"actor", "predicate", "object", "polarity", "uncertainty"}
    fields = {name: dict(status="MATCH" if name in matched else "UNSPECIFIED",
        basis="SOURCE_LOCAL_ROLE_CERTIFICATE" if name in matched else "NO_QUERY_REQUIREMENT")
        for name in SLOTS}
    return dict(direction="SUPPORT", reasons=["EXACT_LOCAL_LABEL_AND_RAW_ROLE_APPOSITION"],
        diagnostics=fields, bindings=dict(argument_matches=[], aligned_arguments=2,
            predicate_match=True, event_identity_certified=False, named_identity_certified=False,
            source_local_object_binding=True, global_identity_merge=False),
        source_binding=dict(kind="SOURCE_LOCAL_KG_ROLE_ALIGNMENT", raw_quote_replayed=True),
        source_local_role_certificate=deepcopy(certificate), event_date_from_publication=False)


def _source_citation(page, frame, admitted):
    certificate = frame.get("source_local_role_certificate")
    if certificate:
        citation = certificate["apposition_quote"]
        # The legacy parser accepts text rather than a page identity. Identical
        # page texts can share a frame, but never relabel its certified source.
        page = admitted[citation["canonical_page_id"]]
        actual = native.previous.base._citation(page, frame)
        if any(actual[k] != citation[k] for k in citation):
            raise ValueError("Role certificate differs from its exact admitted source")
        return actual
    return native.previous.base._citation(page, frame)


def _executor(case, plan, pages, corpus):
    from . import scope_matching
    from .role_sources import proofs
    certificates = proofs(case, plan, pages, corpus)
    by_text = {}

    class Engine(scope_matching.Engine):
        def frames(self, text, *, antecedents=False):
            result = super().frames(text, antecedents=antecedents)
            if antecedents:
                result.extend(deepcopy(by_text.get(text, [])))
            return result

    # Bind certificates to the actual, unchanged atom frames. A role proof for
    # one component cannot discharge another component or a larger question.
    engine = Engine()
    atoms = {a["id"]: a for a in plan["atoms"]}
    source_pages = {p["id"]: p for p in pages}
    for certificate in certificates:
        atom = atoms[certificate["atom_id"]]
        targets, issues = scope_matching._bind(atom, case["query"], engine)
        if issues or not targets:
            continue
        citation = certificate["apposition_quote"]
        page = source_pages[citation["canonical_page_id"]]
        if page["text"][citation["start"]:citation["end"]] != citation["text"]:
            raise ValueError("Certified role source no longer replays")
        by_text.setdefault(page["text"], []).append(dict(start=citation["start"],
            end=citation["end"], quote=citation["text"],
            source_local_role_certificate=deepcopy(certificate),
            target_frame_signatures=sorted({_signature(t) for t in targets})))

    def compare(target, source, *, engine=None):
        if "source_local_role_certificate" in source:
            return _role_match(target, source)
        return scope_matching.compare_frames(target, source, engine=engine)

    functions = native._functions(_Engine=Engine, compare_frames=compare,
        _bind=scope_matching._bind, VERSION=VERSION)
    functions["execute_v3"].__globals__["base"]._citation = (
        lambda page, frame: _source_citation(page, frame, source_pages))
    return functions


def execute(case, plan, retrieval, passage_budget=100, parse=None):
    from .planning import validate_plan
    case = public_case(case)
    validate_plan(plan, case)
    if parse is not None:
        raise ValueError("V6.1 execution binds its recorded local parser; custom parsers are test-only")
    with offline():
        pages, _ = native.old._source_pages(case, retrieval, passage_budget)
        functions = _executor(case, plan, pages, retrieval["eligible"].corpus)
        result = functions["execute_v3"](case, plan, retrieval, passage_budget=passage_budget)
    for atom in result["atoms"]:
        atom["factual_support"] = native.previous._factual(atom["status"])
        for evidence in atom["evidence"]:
            if evidence.get("source_local_role_certificate"):
                evidence["match_representation"] = "SOURCE_LOCAL_KG_ROLE_ALIGNMENT"
    result["factual_support"] = dict(status=native.previous._factual(result["status"]),
        missing_support_is_counterevidence=False, basis="CITED_RAW_TEXT_AND_STRUCTURED_GATES",
        generated_labels_are_proof=False)
    result["execution_policy"] = dict(version=VERSION, frozen_engine_modified=False,
        source_text_modified=False, general_entailment_certified=False,
        eligibility_rechecked=True, global_node_descriptions_are_facts=False)
    return result


def filter_redaction(case, result, top_k=5, **kwargs):
    from .candidates import filter_redaction as checked_filter
    return checked_filter(case, result, top_k=top_k, **kwargs)


execute_v6 = execute
filter_redaction_v6 = filter_redaction
