"""Start the current local workbench with private password authentication."""
import argparse
import getpass
import json
import os
from pathlib import Path
import socket
import stat
import sys
import tempfile

DEMO = Path(__file__).resolve().parents[1]
WORKSPACE = DEMO.parent
LIVE = DEMO / 'phase/motion_login_20261122/live'
PRIVATE = Path.home() / 'Library/Application Support/Matryoshka Live'


def write_verifier(path, verifier):
    descriptor, temporary = tempfile.mkstemp(prefix='.verifier-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w') as stream:
            json.dump(dict(version='matryoshka-local-access/2', verifier=verifier.export()), stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def private_credentials(directory):
    from auth import PasswordVerifier
    if directory.is_symlink():
        raise ValueError('Private configuration cannot be a symlink')
    directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    if directory.stat().st_uid != os.getuid() or directory.stat().st_mode & 0o077:
        raise ValueError('Private configuration must be owned by you and mode 0700')
    path = directory / 'credentials.json'
    if path.exists() or path.is_symlink():
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077 or info.st_size > 4096:
            raise ValueError('Credentials must be a private regular file')
        value = json.loads(path.read_bytes())
        if set(value) == {'version', 'verifier'} and value['version'] == 'matryoshka-local-access/2':
            return PasswordVerifier.parse(value['verifier']), path
        if set(value) == {'version', 'password', 'verifier'} and value['version'] == 'matryoshka-local-access/1':
            verifier = PasswordVerifier.parse(value['verifier'])
            if not verifier.verify(value['password']):
                raise ValueError('Private password/verifier mismatch')
            # Preserve the login secret while removing its recoverable copy.
            write_verifier(path, verifier)
            return verifier, path
        raise ValueError('Unknown private credential format')
    if not sys.stdin.isatty():
        raise ValueError('Initialize the private login verifier from an interactive terminal')
    password = getpass.getpass('Choose a private Live password (at least 16 bytes): ')
    if password != getpass.getpass('Confirm private Live password: '):
        raise ValueError('Private passwords do not match')
    verifier = PasswordVerifier.make(password)
    write_verifier(path, verifier)
    return verifier, path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=8977)
    parser.add_argument('--execute-paid', action='store_true', help='Enable paid queries only after login and explicit submission')
    parser.add_argument('--allocate-usd', type=float, help='Explicit new allocation, at most $1, within the shared $50 cap')
    args = parser.parse_args()
    from dotenv import load_dotenv
    load_dotenv(WORKSPACE / '.env', override=False)
    load_dotenv(WORKSPACE / 'src-redaction/.env', override=False)
    sys.path.insert(0, str(LIVE))
    from server import Config, create_server
    from allocations import allocate
    from contract import API_ROOT, STATE, headroom, ledger_total
    from scope_defaults import corpus_defaults
    if not os.environ.get('OPENAI_API_KEY'):
        parser.error('Set OPENAI_API_KEY privately in the server environment; it is never stored by this launcher')
    headroom()
    corpus_defaults()
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', args.port))
    os.umask(0o077)
    verifier, path = private_credentials(PRIVATE)
    if args.allocate_usd is not None:
        grant = allocate(STATE, API_ROOT, args.allocate_usd, ledger_total)
        print(f'Additional Live allowance: ${grant["amount_usd"]:.2f}; cumulative cap remains $50.', flush=True)
    config = Config(site=WORKSPACE / 'matryoshka_demo_site/site', execute_paid=args.execute_paid,
                    allowed_origins=('http://127.0.0.1:8964', 'http://localhost:8964',
                                     'http://127.0.0.1:8990', 'http://localhost:8990',
                                     'http://127.0.0.1:8992', 'http://localhost:8992',
                                     'https://jimhcyang.github.io', 'https://matryoshka-demo.midllmat.com'))
    http = create_server(config, port=args.port, verifier=verifier)
    print(f'http://127.0.0.1:{http.server_port}/matryoshka-demo/live.html', flush=True)
    print('Private verifier: ' + str(path), flush=True)
    print('Paid queries ' + ('enabled after login and explicit submission' if args.execute_paid else 'disabled')
          + '; no startup model call.', flush=True)
    try:
        http.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        http.jobs.close()
        http.server_close()


if __name__ == '__main__':
    main()
