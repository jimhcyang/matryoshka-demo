"""One explicit paid CIB preparation -> offline native -> QA pipeline, resumable in place."""
import argparse
from datetime import datetime, timezone
from decimal import Decimal
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts/run_redaction_study.py"
COHORTS = {"substantive184": 184, "mechanical215": 215}
MODEL = "gpt-6.1-sol"
TERMINAL_POLICIES = ("evidence_fit_v3", "evidence_fit_v5", "evidence_fit_v6")
DEFAULT_TERMINAL_POLICY = "evidence_fit_v6"
PAUSED = 3


def load_runner():
    spec = importlib.util.spec_from_file_location("cib_batch_existing_study", RUNNER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def shared_authorization(study):
    path = study.API / "authorization.json"
    expected = dict(version="narrative-development-api/1", authorization="narrative-demo-new-phase-50-usd", ceiling_usd=50)
    if study.read(path) != expected:
        raise ValueError("Existing original cumulative $50 authorization required; never initialize/reset it")
    total = Decimal(0)
    for receipt in (study.API / "receipts").glob("*.json"):
        row = study.read(receipt)
        value = row.get("charged_or_reserved_usd")
        if type(value) not in (int, float) or not math.isfinite(value) or not 0 <= value <= 50 or row.get("authorization") != expected["authorization"]:
            raise ValueError("Invalid original shared budget receipt")
        total += Decimal(str(value))
    if total > 50:
        raise ValueError("Original cumulative budget is exhausted/invalid")
    return study.ref(path)


def checked_dataset(study, path, cohort):
    dataset = study.checked_cases(path)
    if dataset["cohort"] != cohort or len(dataset["cases"]) != COHORTS[cohort]:
        raise ValueError("Full requested cohort/order required, never silently drop cases")
    return dataset


def check_grant(study, plans, dataset, spend):
    path = plans / "planning_authorization.json"
    if not path.exists():
        if any(plans.glob("planned/*.json")) or any(plans.glob("planning_failures/*.json")):
            raise ValueError("Planning artifacts without their original grant; never refresh the baseline")
        return None
    grant = study.read(path)
    expected = dict(dataset_sha256=study.digest(dataset), model=MODEL, reading_model=MODEL,
                    incremental_ceiling_usd=spend, cumulative_cap_usd=50., planner_policy="SINGLE_REQUESTED_MODEL")
    baseline = grant.get("baseline_usd")
    if (any(grant.get(k) != v for k, v in expected.items()) or type(baseline) not in (int, float)
            or not math.isfinite(baseline) or not 0 <= baseline <= 50):
        raise ValueError("Original planning grant changed; keep the same dataset/model/slice/baseline")
    return study.ref(path)


def planning_state(study, plans, dataset):
    missing = []
    for case in dataset["cases"]:
        ready = plans / "planned" / (case["case_id"] + ".json")
        failed = plans / "planning_failures" / (case["case_id"] + ".json")
        if ready.exists() and failed.exists():
            raise ValueError("Conflicting planning success/failure, preserve and review")
        if not ready.exists() and not failed.exists():
            missing.append(case["case_id"])
        elif ready.exists():
            value = study.checked_prepared(ready, case)
            if value["model"] != MODEL or value["reading_model"] != MODEL:
                raise ValueError("Uncontrolled planning model substitution")
        elif study.read(failed).get("case_id") != case["case_id"]:
            raise ValueError("Planning failure belongs to another case")
    if not missing:
        study.planning_inventory(plans, dataset["cases"])
    return missing


def invoke(study, out, stage, arguments, pins):
    for reference in pins:
        study.checked_ref(reference)
    attempt = out / "stages" / uuid.uuid4().hex
    command = [sys.executable, "-B", str(RUNNER), stage, *arguments]
    study.put(attempt / "started.json", dict(stage=stage, command=command, pins=pins,
              started_utc=datetime.now(timezone.utc).isoformat()))
    environment = dict(os.environ)
    if stage != "plan":
        environment.pop("OPENAI_API_KEY", None)
    try:
        result = subprocess.run(command, cwd=ROOT, env=environment, check=True)
    except BaseException as error:
        study.put(attempt / "finished.json", dict(status="FAILED_OR_INTERRUPTED", error_type=type(error).__name__))
        raise
    study.put(attempt / "finished.json", dict(status="COMPLETE", exit_code=result.returncode))
    for reference in pins:
        study.checked_ref(reference)


def reject_uncertain_paid_stage(study, out):
    for path in (out / "stages").glob("*/started.json"):
        if study.read(path)["stage"] != "plan":
            continue
        finished = path.with_name("finished.json")
        if not finished.exists() or study.read(finished).get("status") != "COMPLETE":
            raise ValueError("Interrupted/nonzero paid subprocess needs review; no automatic uncertain paid retry: " + str(path.parent))


def native_inventory(study, native, dataset, options):
    frozen, cases = study.validate_freeze(native, dataset)
    if (cases != dataset["cases"] or frozen["population_confirmation"] != dataset["public_cases_sha256"]
            or frozen["configuration"] != study.configuration(study.settings(True, getattr(options, "terminal_ranking", DEFAULT_TERMINAL_POLICY)))
            or frozen["per_case_timeout_seconds"] != options.timeout_seconds):
        raise ValueError("Native full-population/terminal-policy/source-alignment/timeout freeze differs")
    return frozen, cases, [study.terminal_state(native, case, frozen) for case in cases]


def verify_qa(study, out, native, dataset, options):
    qa = native / "QA" / options.qa_epoch
    result_path = qa / "recovery_QA_ONLY.json"
    before_path = qa / "metric_freeze_BEFORE_GOLD.json"
    seal_path = out / ("qa_seal_" + options.qa_epoch + ".json")
    if seal_path.exists():
        seal = study.read(seal_path)
        for reference in seal.values():
            study.checked_ref(reference)
        if seal != dict(result=study.ref(result_path), before_gold=study.ref(before_path)):
            raise ValueError("Sealed QA paths changed")
    result, before = study.read(result_path), study.read(before_path)
    frozen, cases, states = native_inventory(study, native, dataset, options)
    ids = [case["case_id"] for case in cases]
    if (result.get("qa_only") is not True or result.get("version") != study.RUN_VERSION
            or result.get("qa_epoch") != options.qa_epoch or result.get("cohort") != options.cohort
            or result.get("dataset_n") != len(cases) or result.get("selected_n") != len(cases)
            or result.get("metric_freeze") != study.ref(before_path)
            or [row["case_id"] for row in result.get("rows", [])] != ids
            or before.get("selected_case_ids") != ids or before.get("dataset") != study.ref(out / "dataset/public_cases.json")
            or before.get("producer") != study.runner_reference()
            or before.get("run_freeze") != study.ref(native / "freeze.json")
            or before.get("pre_gold_case_states") != states
            or before.get("terminal_inventory") != study.terminal_inventory(native, cases)):
        raise ValueError("Existing QA does not match the complete frozen study")
    if any(row["status"] in {"NOT_RUN", "INTERRUPTED"} for row in states):
        raise ValueError("Partial QA cannot close the one-command batch")
    for reference in before["input_references"]:
        study.checked_ref(reference)
    study.checked_ref(before["metric"])
    if before["metric"] != frozen["metric_freeze"]:
        raise ValueError("QA metric contract differs from native freeze")
    study.put(seal_path, dict(result=study.ref(result_path), before_gold=study.ref(before_path)))
    print(json.dumps(dict(status="QA_SEALED_VERIFIED", path=str(result_path), selected_n=len(cases),
                          statuses=result["statuses"], existing_results_not_overwritten=True)))


def pipeline(options):
    if not options.execute_paid:
        raise ValueError("--execute-paid is required; no implicit API authorization")
    if not math.isfinite(options.max_additional_usd) or not 0 < options.max_additional_usd <= 50:
        raise ValueError("Explicit positive --max-additional-usd within the original cumulative $50 cap required")
    if not 1 <= options.timeout_seconds <= 900 or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}", options.qa_epoch):
        raise ValueError("Timeout must be1..900 and QA epoch must be a literal name")
    study = load_runner()
    policy = getattr(options, "terminal_ranking", DEFAULT_TERMINAL_POLICY)
    if policy not in TERMINAL_POLICIES:
        raise ValueError("Unknown explicit terminal ranking policy")
    study.settings(True, policy)  # Reject unsupported backend policies before any paid stage.
    out = study.local_output(options.out or ROOT / "experiments/cib_study_v5" / options.cohort)
    auth = shared_authorization(study)
    pins = [study.ref(Path(__file__)), study.runner_reference()]
    manifest = dict(version="cib-one-command-batch/1", cohort=options.cohort, expected_n=COHORTS[options.cohort],
                    max_additional_usd=options.max_additional_usd, model=MODEL, reading_model=MODEL,
                    source_alignment=True, terminal_ranking=policy, timeout_seconds=options.timeout_seconds,
                    original_authorization=auth, pins=pins)
    with study.stage_lock(out):
        manifest_path = out / "batch.json"
        if not manifest_path.exists() and any(p.name != ".study.lock" for p in out.iterdir()):
            raise ValueError("Nonempty unowned batch output; do not adopt/reset earlier grants or artifacts")
        study.put(manifest_path, manifest)
        dataset_path = out / "dataset/public_cases.json"
        if not dataset_path.exists():
            invoke(study, out, "prepare", ["--cohort", options.cohort, "--out", str(dataset_path.parent)], pins)
        dataset = checked_dataset(study, dataset_path, options.cohort)
        study.put(out / "population.json", dict(dataset=study.ref(dataset_path), public_cases_sha256=dataset["public_cases_sha256"],
                  selected_case_ids=[case["case_id"] for case in dataset["cases"]]))
        plans, native = out / "plans", out / "native"
        grant = check_grant(study, plans, dataset, options.max_additional_usd)
        grant_pin = out / "planning_grant_ref.json"
        if grant_pin.exists():
            study.checked_ref(study.read(grant_pin))
        if grant is not None:
            study.put(grant_pin, grant)
        qa = native / "QA" / options.qa_epoch
        if qa.exists():
            verify_qa(study, out, native, dataset, options)
            return 0
        full = ["--dataset", str(dataset_path), "--all", "--confirm-population-sha", dataset["public_cases_sha256"]]
        missing = planning_state(study, plans, dataset)
        if missing and (native / "freeze.json").exists():
            raise ValueError("Frozen planning inputs are missing; do not replan a native epoch")
        if missing:
            reject_uncertain_paid_stage(study, out)
            invoke(study, out, "plan", ["--out", str(plans), *full, "--execute-paid",
                   "--max-additional-usd", str(options.max_additional_usd), "--model", MODEL, "--reading-model", MODEL], pins)
            current_grant = check_grant(study, plans, dataset, options.max_additional_usd)
            if current_grant is None or grant is not None and current_grant != grant:
                raise ValueError("Original planning grant missing or rewritten")
            study.put(grant_pin, current_grant)
        missing = planning_state(study, plans, dataset)
        if missing:
            print(json.dumps(dict(status="PAUSED_UNPLANNED_CASES", selected_n=len(dataset["cases"]),
                                  unplanned_case_ids=missing, next="Repeat the same command under the same grant; no new allowance")))
            return PAUSED
        if shared_authorization(study) != auth:
            raise ValueError("Original shared authorization changed during preparation")
        invoke(study, out, "run", ["--out", str(native), *full, "--plans", str(plans), "--source-alignment",
               "--terminal-ranking", policy, "--timeout-seconds", str(options.timeout_seconds)], pins)
        _, _, states = native_inventory(study, native, dataset, options)
        if any(row["status"] in {"NOT_RUN", "INTERRUPTED"} for row in states):
            print(json.dumps(dict(status="PAUSED_NATIVE_INCOMPLETE", case_states=states)))
            return PAUSED
        invoke(study, out, "score", ["--out", str(native), "--dataset", str(dataset_path), "--qa-epoch", options.qa_epoch], pins)
        verify_qa(study, out, native, dataset, options)
        return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", choices=tuple(COHORTS), default="substantive184")
    parser.add_argument("--out", help="Stable literal directory inside src-demo-day; never a reset/fresh allowance on resume")
    parser.add_argument("--execute-paid", action="store_true")
    parser.add_argument("--max-additional-usd", type=float, required=True)
    parser.add_argument("--terminal-ranking", choices=TERMINAL_POLICIES, default=DEFAULT_TERMINAL_POLICY,
                        help="Job-bound scoring policy; default evidence_fit_v6, with no silent fallback")
    parser.add_argument("--qa-epoch", help="New immutable QA epoch; default final_vN for the selected terminal policy")
    parser.add_argument("--timeout-seconds", type=int, default=300)
    options = parser.parse_args()
    if options.qa_epoch is None:
        options.qa_epoch = options.terminal_ranking.replace("evidence_fit_", "final_")
    try:
        return pipeline(options)
    except (ValueError, OSError, KeyError, subprocess.SubprocessError) as error:
        print("BATCH_STOPPED: " + str(error), file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("BATCH_INTERRUPTED: preserve receipts; no automatic paid retries", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
