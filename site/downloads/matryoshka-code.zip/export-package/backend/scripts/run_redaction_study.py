"""Explicit preparation, paid planning, resumable native runs and separate QA.

No stage starts another stage implicitly. Inference receives seven public fields,
never the target catalog's answers, scouting witnesses or semantic review labels.
"""
import argparse
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import fcntl
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
sys.path.insert(0, str(ROOT))
FIELDS = ('case_id', 'corpus', 'task', 'query', 'document_id', 'date', 'focal_marker')
VERSION = 'bounded-real-redaction-study/1'
RUN_VERSION = 'bounded-real-redaction-native/2'
METRIC_VERSION = 'bounded-real-redaction-metric/2'
METRIC_POLICY = 'FIRST_NONEMPTY_READING_ELSE_FIRST_DECLARED; ERRORS_AND_ABSTENTIONS_RETAINED'
TARGETS = WORKSPACE / 'matryoshka_redaction/data/preflight_v3/source/reconciled_v2/targets.jsonl'
TARGETS_SHA = 'fdc32702374002a636f62ee82bee2cf8d9f9fdab8bb49a511ccdeeacef38073a'
PREVIOUS = ROOT / 'phase/agenda_20261123/screening'
API = ROOT / 'experiments/narrative_demo/api'
REFS = ROOT / 'experiments/current_refresh/resource_handoff/registries/db09a0bd26047428e9350b57/execution_refs_v01.json'
IMPORTED_RUNNER_SHA = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()


def digest(value):
    from matryoshka_demo.io import digest as canonical
    return canonical(value)


def read(path):
    path = Path(path)
    raw = path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix == '.gz' else raw)


def ref(path):
    path = Path(path).resolve()
    return dict(path=str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
        sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def put(path, value):
    from matryoshka_next.workflow import put_immutable
    put_immutable(Path(path), value)


def runner_reference():
    value=ref(__file__)
    if value['sha256']!=IMPORTED_RUNNER_SHA:
        raise ValueError('Runner file changed after import; start a fresh process')
    return value


def local_output(value):
    literal = Path(value).absolute()
    if '..' in literal.parts or any(p.is_symlink() for p in [literal, *literal.parents]):
        raise ValueError('Study output/reference paths cannot traverse symlinks')
    path = literal.resolve()
    if not path.is_relative_to(ROOT) or path == ROOT or path.is_relative_to(API):
        raise ValueError('Study outputs must be literal directories inside src-demo-day')
    return path


@contextmanager
def stage_lock(output):
    output.mkdir(parents=True, exist_ok=True)
    with (output/'.study.lock').open('a+') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError('Another stage owns this study output') from error
        yield


def checked_ref(reference):
    path = Path(reference['path'])
    path = path if path.is_absolute() else ROOT/path
    path = local_output(path)
    if ref(path) != reference:
        raise ValueError('Referenced artifact changed')
    return path


def checked_cases(dataset):
    value = read(dataset)
    cases = value['cases']
    if value.get('version') != VERSION or value.get('public_cases_sha256') != digest(cases):
        raise ValueError('Public case inventory changed')
    from matryoshka_demo.contracts import public_case
    from matryoshka_narrative.contracts import engine_case
    if len({case['case_id'] for case in cases}) != len(cases):
        raise ValueError('Duplicate public case')
    for case in cases:
        if set(case) != set(FIELDS):
            raise ValueError('Only seven public fields may enter inference')
        public_case(engine_case(case))
        if case['corpus'] != 'cib' or case['task'] != 'redaction' or len(case['case_id']) > 160:
            raise ValueError('This study admits only bounded CIB Redaction case identities')
    if not cases:
        raise ValueError('Empty public case inventory')
    if value.get('metric_policy') != METRIC_POLICY:
        raise ValueError('Unknown primary reading/denominator policy')
    return value


def public_target(row):
    from matryoshka_demo.contracts import MASK
    query, focal = row['query'], row.get('focus_marker', row.get('focal_marker'))
    if not focal or query.count(focal) != 1:
        raise ValueError('Focal mask is not unique')
    normalized = MASK.sub(lambda match: '[REDACTION]' if match.group() == focal else '[MASKED]', query)
    return dict(case_id=row['case_id'], corpus='cib', task='redaction', query=normalized,
        document_id=row['document_id'], date=row['document_date_iso'], focal_marker='[REDACTION]')


def checked_prepared(path, case):
    return validate_prepared(read(path),case)


def validate_prepared(value, case):
    from matryoshka_narrative.contracts import engine_case
    from matryoshka_next.readings import validate_readings
    fields = {'case','plan','readings','readings_audit','model','reading_model','query_only'}
    if set(value) != fields or value['case'] != case or value['query_only'] is not True:
        raise ValueError('Prepared input is not the exact public query-only planning record')
    if value['reading_model'] not in {'gpt-6.1-sol','gpt-6-luna'}:
        raise ValueError('Unknown explicit reading model')
    validate_query_plan(value['plan'],case,value['model'])
    validate_readings(value['readings'], engine_case(case))
    return value


def validate_query_plan(wrapper,case,model):
    from matryoshka_narrative import planning
    from matryoshka_narrative.contracts import engine_case,public_query
    if model not in {'gpt-6.1-sol','gpt-6-luna'}:
        raise ValueError('Unknown explicit planner model')
    if (set(wrapper)-{'provider_retry'} != {'version','public_task','compatibility_task','native_plan','public_query'}
            or wrapper['version'] != planning.VERSION
            or wrapper['public_query'] != public_query(case) or wrapper['public_task'] != case['task']
            or wrapper['compatibility_task'] != engine_case(case)['task']):
        raise ValueError('Prepared public plan wrapper changed')
    if wrapper.get('provider_retry',{}).get('actual_model',model)!=model:
        raise ValueError('Uncontrolled planner model substitution; use an explicit controlled planning epoch')
    planning.validate_plan(wrapper['native_plan'], engine_case(case))
    return wrapper


def single_model_query_plan(case,output,model):
    from matryoshka_narrative import planning
    key=digest(dict(case=case,model=model,contract=planning.VERSION,policy='SINGLE_REQUESTED_MODEL'))
    path=output/'planning_cache'/(key+'.json')
    if path.exists():
        saved=read(path)
        if set(saved)!={'case','model','plan'} or saved['case']!=case or saved['model']!=model:
            raise ValueError('Query planning cache binding changed')
        return validate_query_plan(saved['plan'],case,model)
    # parse retains its explicit same-model contract correction, never capacity-model fallback.
    value=planning.parse(case,API,model=model)
    validate_query_plan(value,case,model)
    put(path,dict(case=case,model=model,plan=value))
    return value


def metric_contract(dataset):
    return dict(version=METRIC_VERSION, primary_reading_rule=dataset['metric_policy'], ks=[1,3,5],
        literal='EXACT_FULL_STRING', normalized_literal='CASEFOLD_AND_WHITESPACE_ONLY',
        reading_choice='FIRST_NONEMPTY_DECLARED_ELSE_FIRST_DECLARED; ANSWER_BLIND_RESULT_DEPENDENT_NOT_UI_DEFAULT',
        denominator='ALL_FROZEN_SELECTED_IDS; ERRORS_AND_ABSTENTIONS_ARE_MISSES; INTEGRITY_OR_GOLD_JOINS_HOLD_RATES',
        semantic_equivalence_graded=False, source_support_correctness_graded=False,
        population_accuracy_claimed=False, gold_opened_by_native_stage=False)


def prepare(options):
    from matryoshka_demo.contracts import MASK
    raw = TARGETS.read_bytes()
    if hashlib.sha256(raw).hexdigest() != TARGETS_SHA:
        raise ValueError('The frozen 332 target catalog changed')
    targets = [json.loads(line) for line in raw.splitlines() if line.strip()]
    if len(targets) != 332:
        raise ValueError('Unexpected historical population')
    if options.cohort == 'historical332':
        ids = {row['case_id'] for row in targets}
        selection = dict(kind='FROZEN_HISTORICAL_POPULATION', n=332)
    elif options.cohort == 'mechanical215':
        path = PREVIOUS / 'v3/source_validity_332.jsonl'
        ids = {row['case_id'] for row in (json.loads(line) for line in path.read_text().splitlines())
            if row['disposition'] == 'include'}
        selection = dict(kind='MECHANICAL_SOURCE_VALIDITY_NOT_RECOVERABILITY', n=215, source=ref(path))
    else:
        path = PREVIOUS / 'semantic_value_v1/final/substantive_mechanical_include_QA_ONLY.json'
        ids = set(read(path)['case_ids'])
        selection = dict(kind='POSTHOC_ANSWER_AWARE_SUBSTANTIVE_PROSPECTS_NOT_SUPPORTED_POPULATION', n=184, source=ref(path))
    if len(ids) != selection['n']:
        raise ValueError('Selection count changed; do not silently repair a denominator')
    cases, mapping = [], []
    for row in targets:
        if row['case_id'] not in ids:
            continue
        query, focal = row['query'], row.get('focus_marker', row.get('focal_marker'))
        if query.count(focal) != 1:
            raise ValueError('Focal mask is not unique')
        spans = []
        shift = 0
        def replace(match):
            nonlocal shift
            text = '[REDACTION]' if match.group() == focal else '[MASKED]'
            spans.append(dict(raw_start=match.start(),raw_end=match.end(),display_start=match.start()+shift,
                display_end=match.start()+shift+len(text),focal=match.group()==focal))
            shift += len(text)-len(match.group())
            return text
        normalized = MASK.sub(replace, query)
        case = dict(case_id=row['case_id'], corpus='cib', task='redaction', query=normalized,
            document_id=row['document_id'], date=row['document_date_iso'], focal_marker='[REDACTION]')
        cases.append(case)
        mapping.append(dict(case_id=case['case_id'], raw_query_sha256=digest(query),
            public_query_sha256=digest(normalized), marker_mapping=spans))
    if set(ids) != {case['case_id'] for case in cases}:
        raise ValueError('Selected case is absent from the frozen catalog')
    value = dict(version=VERSION, cohort=options.cohort, selection=selection, cases=cases,
        public_cases_sha256=digest(cases), historical_targets_ref=ref(TARGETS),
        marker_mappings=mapping, gold_exported=False, scouting_evidence_exported=False,
        metric_policy=METRIC_POLICY,
        population_accuracy_claimed=False, source_supported_population_known=False)
    output = local_output(options.out)
    put(output/'public_cases.json', value)
    print(json.dumps(dict(prepared=len(cases), cohort=options.cohort, path=str(output/'public_cases.json'),
        public_cases_sha256=value['public_cases_sha256'], api_calls=0)))


def bounded_selection(options, dataset):
    if options.all:
        if options.confirm_population_sha != dataset['public_cases_sha256']:
            raise ValueError('Full population requires its exact --confirm-population-sha')
        return dataset['cases']
    if options.limit is None or not 1 <= options.limit <= 32:
        raise ValueError('Use --limit 1..32 for a bounded pilot, or explicit --all with its SHA')
    return dataset['cases'][:options.limit]


def plan(options):
    from matryoshka_narrative import workflow
    from matryoshka_narrative.guards import require_headroom
    if not options.execute_paid:
        raise ValueError('Paid preparation requires --execute-paid and a bounded spending envelope')
    output=local_output(options.out)
    require_headroom(output)
    old_output=workflow.OUTPUT
    names=('NARRATIVE_INCREMENTAL_BASELINE_USD','NARRATIVE_INCREMENTAL_CEILING_USD')
    old_environment={key:os.environ.get(key) for key in names}
    with stage_lock(output):
        try:
            return _plan(options)
        finally:
            workflow.OUTPUT=old_output
            for key,value in old_environment.items():
                if value is None:
                    os.environ.pop(key,None)
                else:
                    os.environ[key]=value


def _plan(options):
    if not options.execute_paid:
        raise ValueError('Paid preparation requires --execute-paid and a bounded spending envelope')
    from dotenv import load_dotenv
    load_dotenv(WORKSPACE/'.env'); load_dotenv(WORKSPACE/'src-redaction/.env')
    from matryoshka_narrative import workflow, planning
    from matryoshka_narrative.api import Budget
    from matryoshka_narrative.guards import require_headroom
    dataset = checked_cases(options.dataset)
    cases = bounded_selection(options,dataset)
    output = local_output(options.out)
    require_headroom(output)
    if options.max_additional_usd is None or not 0 < options.max_additional_usd <= 50:
        raise ValueError('An explicit positive --max-additional-usd within the existing $50 cap is required')
    if not (API/'authorization.json').is_file():
        raise ValueError('The original shared ledger must already exist; never initialize a new allowance')
    budget=Budget(API)
    auth_path=output/'planning_authorization.json'
    expected=dict(dataset_sha256=digest(dataset),model=options.model,reading_model=options.reading_model,
        incremental_ceiling_usd=options.max_additional_usd,cumulative_cap_usd=50.,planner_policy='SINGLE_REQUESTED_MODEL')
    if auth_path.exists():
        grant=read(auth_path)
        if any(grant.get(key)!=value for key,value in expected.items()):
            raise ValueError('Use a new planning epoch for changed model, dataset or spending bounds')
    else:
        grant=dict(expected,baseline_usd=budget.total())
        put(auth_path,grant)
    os.environ['NARRATIVE_INCREMENTAL_BASELINE_USD']=str(grant['baseline_usd'])
    os.environ['NARRATIVE_INCREMENTAL_CEILING_USD']=str(grant['incremental_ceiling_usd'])
    workflow.OUTPUT=output/'planning_cache'
    for case in cases:
        target=output/'planned'/(case['case_id']+'.json')
        if target.exists():
            saved=checked_prepared(target,case)
            if saved['model']!=options.model or saved['reading_model']!=options.reading_model:
                raise ValueError('Saved planning models changed')
            continue
        failure=output/'planning_failures'/(case['case_id']+'.json')
        if failure.exists():
            continue  # Explicit new epoch required; no invisible paid retries.
        try:
            require_headroom(output)
        except OSError:
            print(case['case_id']+' PAUSED_BEFORE_REQUEST',flush=True)
            break  # No request began. The same epoch/baseline may resume.
        previous_receipts={p.name for p in (API/'receipts').glob('*.json')}
        try:
            saved=single_model_query_plan(case,output,options.model)
            readings,audit=planning.model_readings(case,API,model=options.reading_model)
            value=dict(case=case,plan=saved,readings=readings,readings_audit=audit,
                model=options.model,reading_model=options.reading_model,query_only=True)
            validate_prepared(value,case)
            put(target,value)
        except Exception as error:
            if isinstance(error,OSError) and previous_receipts=={p.name for p in (API/'receipts').glob('*.json')}:
                print(case['case_id']+' PAUSED_WITHOUT_NEW_PAID_ATTEMPT',flush=True)
                break
            put(failure,dict(case_id=case['case_id'],error_type=type(error).__name__,
                message=str(error) if isinstance(error,ValueError) else type(error).__name__,
                paid_receipts_retained=True))
            print(case['case_id']+' PLANNING_FAILED',flush=True)
            if isinstance(error,(RuntimeError,OSError)):
                break
        else:
            print(case['case_id']+' PLANNED',flush=True)


def settings(alignment=False, terminal_ranking='evidence_fit_v3'):
    from matryoshka_demo.source_view_policy import SOURCE_DAY_INCLUSIVE
    if terminal_ranking not in {'evidence_fit_v3', 'evidence_fit_v5', 'evidence_fit_v6'}:
        raise ValueError('Unknown explicit terminal scoring policy')
    return dict(method='current_hierarchy',passage_budget=80,document_budget=40,
        construction_pages=32,draft_budget=64,terminal_ranking=terminal_ranking,
        source_view_policy=SOURCE_DAY_INCLUSIVE,
        selection_profile=dict(page_focal_fraction=.5,candidate_focal_fraction=.5,scan_pages=512,
            identity_first=True,supplemental_mode='legacy',counter_policy='positive_support',
            cue_order_mode='source_alignment' if alignment else 'source_priority'))


def monitored_child(command, *, seconds, max_rss_mib=8192, disk_check=None):
    environment={key:value for key,value in os.environ.items() if key in
        {'PATH','HOME','TMPDIR','LANG','LC_ALL','VIRTUAL_ENV','NARRATIVE_DEADLINE_UTC','NARRATIVE_NO_NEW_WORK_UTC'}}
    environment.update(PYTHONPATH=str(ROOT),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='1',
        OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    process=subprocess.Popen(command,env=environment,stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    start=time.monotonic()
    peak=0
    try:
        while process.poll() is None:
            if time.monotonic()-start>seconds:
                raise TimeoutError('WALL_TIME_LIMIT')
            if disk_check:
                disk_check()
            measured=subprocess.run(['/bin/ps','-o','rss=','-p',str(process.pid)],
                capture_output=True,text=True,timeout=2)
            if measured.returncode==0 and measured.stdout.strip():
                peak=max(peak,int(measured.stdout.strip())/1024)
                if peak>max_rss_mib:
                    raise RuntimeError('MEMORY_LIMIT')
            time.sleep(.15)
        if process.returncode:
            raise RuntimeError('NATIVE_CHILD_FAILED_EXIT_'+str(process.returncode))
        return dict(peak_rss_mib=peak,seconds=time.monotonic()-start,api_key_in_child_environment=False)
    finally:
        if process.poll() is None:
            process.kill()
        process.wait(timeout=5)


def current_runtime():
    from matryoshka_narrative import workflow
    from matryoshka_demo.runner_v2 import environment_binding
    pins=workflow.code_pins()
    if pins!=workflow._IMPORT_PINS:
        raise ValueError('Engine files changed after import; start a fresh process')
    return dict(code_pins=pins,resource_refs=read(REFS),environment=environment_binding(ROOT))


def configuration(config):
    from matryoshka_narrative.workflow import configuration as bind
    from matryoshka_demo.source_view_policy import SourceViewPolicy
    return bind(**dict(config,source_view_policy=SourceViewPolicy(config['source_view_policy'])))


def planning_inventory(plans,cases):
    plans=local_output(plans)
    rows=[]
    for case in cases:
        prepared=plans/'planned'/(case['case_id']+'.json')
        failure=plans/'planning_failures'/(case['case_id']+'.json')
        if prepared.exists()==failure.exists():
            raise ValueError('Every selected ID needs exactly one prepared plan or retained planning failure')
        if prepared.exists():
            checked_prepared(prepared,case)
        elif read(failure).get('case_id')!=case['case_id']:
            raise ValueError('Planning failure belongs to another case')
        rows.append(dict(case_id=case['case_id'],prepared=ref(prepared) if prepared.exists() else None,
            planning_failure=ref(failure) if failure.exists() else None))
    return rows


def freeze_run(options,dataset,cases,output):
    runtime=current_runtime()
    config=settings(options.source_alignment, getattr(options, 'terminal_ranking', 'evidence_fit_v3'))
    config={**config,'source_view_policy':config['source_view_policy'].value}
    runner=runner_reference()
    entries={**runtime['code_pins'],runner['path']:runner['sha256']}
    archive={}
    for name,checksum in entries.items():
        raw=(ROOT/name).read_bytes()
        if hashlib.sha256(raw).hexdigest()!=checksum:
            raise ValueError('Code drift while taking source archive')
        archive[name]=dict(sha256=checksum,text=raw.decode('utf8'))
    put(output/'source_archive.json.gz',archive)
    put(output/'metric_freeze.json',metric_contract(dataset))
    frozen=dict(version=RUN_VERSION,dataset=ref(options.dataset),dataset_sha256=digest(dataset),
        dataset_n=len(dataset['cases']),selected_case_ids=[c['case_id'] for c in cases],
        selected_cases_sha256=digest(cases),population_confirmation=(dataset['public_cases_sha256'] if options.all else None),
        case_inputs=planning_inventory(options.plans,cases),runner=runner,execution_refs=ref(REFS),
        source_archive=ref(output/'source_archive.json.gz'),metric_freeze=ref(output/'metric_freeze.json'),
        settings=config,configuration=configuration(config),per_case_timeout_seconds=options.timeout_seconds,**runtime)
    if (output/'freeze.json').exists() and read(output/'freeze.json')!=frozen:
        raise ValueError('Native epoch/selection/plans changed; create a new output directory')
    put(output/'freeze.json',frozen)
    return frozen


def validate_freeze(root,dataset,*,live=False,validate_plans=True):
    frozen=read(root/'freeze.json')
    if (frozen.get('version')!=RUN_VERSION or ref(checked_ref(frozen['dataset']))!=frozen['dataset']
            or frozen['dataset_sha256']!=digest(dataset) or frozen['dataset_n']!=len(dataset['cases'])):
        raise ValueError('Run/dataset binding changed')
    ids=frozen['selected_case_ids']
    by_id={c['case_id']:c for c in dataset['cases']}
    if not ids or len(ids)!=len(set(ids)) or any(cid not in by_id for cid in ids):
        raise ValueError('Invalid frozen selected IDs')
    cases=[by_id[cid] for cid in ids]
    if (digest(cases)!=frozen['selected_cases_sha256'] or
            [row['case_id'] for row in frozen['case_inputs']]!=ids or
            len(ids)>32 and frozen['population_confirmation']!=dataset['public_cases_sha256']):
        raise ValueError('Execution selection/authorization changed')
    if read(checked_ref(frozen['metric_freeze']))!=metric_contract(dataset):
        raise ValueError('Pre-native metric contract changed')
    if frozen['configuration']!=configuration(frozen['settings']):
        raise ValueError('Native settings descriptor changed')
    archive=read(checked_ref(frozen['source_archive']))
    expected={**frozen['code_pins'],frozen['runner']['path']:frozen['runner']['sha256']}
    if set(archive)!=set(expected) or any(archive[k]['sha256']!=v or
            hashlib.sha256(archive[k]['text'].encode('utf8')).hexdigest()!=v for k,v in expected.items()):
        raise ValueError('Source archive does not bind exact engine/runner bytes')
    if read(checked_ref(frozen['execution_refs']))!=frozen['resource_refs']:
        raise ValueError('Resource reference file changed')
    if runner_reference()!=frozen['runner']:
        raise ValueError('Runner bytes differ from the frozen execution/metric producer')
    for case,entry in zip(cases,frozen['case_inputs']):
        if bool(entry['prepared'])==bool(entry['planning_failure']):
            raise ValueError('Ambiguous frozen planning state')
        if entry['prepared'] and validate_plans:
            checked_prepared(checked_ref(entry['prepared']),case)
        elif entry['planning_failure'] and validate_plans and read(checked_ref(entry['planning_failure'])).get('case_id')!=case['case_id']:
            raise ValueError('Frozen planning failure changed')
    if live and (ref(REFS)!=frozen['execution_refs'] or current_runtime()!=
            {k:frozen[k] for k in ('code_pins','resource_refs','environment')}):
        raise ValueError('Live runner/engine/resources/environment drifted')
    return frozen,cases


def case_input(root,case,frozen):
    entry=next(row for row in frozen['case_inputs'] if row['case_id']==case['case_id'])
    value=dict(case=case,freeze=ref(root/'freeze.json'),prepared=entry['prepared'],planning_failure=entry['planning_failure'])
    return dict(value,execution_key=digest(value))


def validate_native(packet,case,prepared,frozen):
    from matryoshka_narrative import workflow
    workflow.validate_packet(packet,case,prepared['plan']['native_plan'],prepared['readings'],
        pins=frozen['code_pins'],binding=frozen['resource_refs']['index_refs'][case['corpus']],
        environment=frozen['environment'],settings=frozen['configuration'])
    rows=packet['result'].get('readings',[])
    declared=prepared['readings']['readings']
    if [row['reading'] for row in rows]!=declared:
        raise ValueError('Native reading order/interpretation differs from its saved declaration')
    seen=set()
    for row in rows:
        candidates=row['candidates']
        if len(candidates)>5 or [c['rank'] for c in candidates]!=list(range(1,len(candidates)+1)):
            raise ValueError('Terminal rank/list contradiction; never reorder for QA')
        for candidate in candidates:
            if candidate['id'] in seen or candidate.get('reading_id')!=row['reading']['id'] or not isinstance(candidate['fill'],str):
                raise ValueError('Ambiguous terminal identity/reading binding')
            seen.add(candidate['id'])
    if packet['result'].get('candidates')!=[c for row in rows for c in row['candidates']]:
        raise ValueError('Flat native display differs from declared branch order')
    return packet


def child_receipt(target,packet,payload):
    return dict(version=RUN_VERSION,case_id=payload['case']['case_id'],execution_key=payload['execution_key'],
        input=ref(target/'input.json'),native=ref(target/'native.json.gz'),packet_digest=digest(packet),
        native_checksum=packet['native_checksum'],query_sha256=digest(payload['case']['query']),api_calls=0,
        inference_network_access=False)


def validated_child(target,payload,frozen):
    prepared=checked_prepared(checked_ref(payload['prepared']),payload['case'])
    packet=read(target/'native.json.gz')
    if read(target/'child_completion.json')!=child_receipt(target,packet,payload):
        raise ValueError('Child completion/input/native seal changed')
    return validate_native(packet,payload['case'],prepared,frozen)


def completed_receipt(target,payload):
    return dict(version=RUN_VERSION,case_id=payload['case']['case_id'],execution_key=payload['execution_key'],
        freeze=payload['freeze'],input=ref(target/'input.json'),child_completion=ref(target/'child_completion.json'),
        supervisor=ref(target/'supervisor.json'),api_calls=0)


def terminal_state(root,case,frozen):
    target=root/case['case_id']
    payload=case_input(root,case,frozen)
    completion,failure=target/'completion.json',target/'failure.json'
    if completion.exists() and failure.exists():
        raise ValueError('Conflicting terminal states')
    if not (target/'input.json').exists():
        if completion.exists() or failure.exists() or target.exists() and any(target.iterdir()):
            raise ValueError('Unbound terminal or interrupted artifacts')
        return dict(case_id=case['case_id'],status='NOT_RUN')
    if read(target/'input.json')!=payload:
        raise ValueError('Case input/plan/config/freeze binding changed')
    if failure.exists():
        record=read(failure)
        if (set(record)!={'version','case_id','input','stage','reason','in_denominator','automatic_retry'} or
                record.get('version')!=RUN_VERSION or record.get('case_id')!=case['case_id'] or
                record.get('input')!=ref(target/'input.json') or record.get('in_denominator') is not True or
                record.get('automatic_retry') is not False or record.get('stage') not in {'planning','native','interrupted'} or
                (record['stage']=='planning')!=bool(payload['planning_failure']) or not isinstance(record['reason'],str)):
            raise ValueError('Failure receipt changed')
        return dict(case_id=case['case_id'],status='PLANNING_ERROR' if record['stage']=='planning' else 'NATIVE_ERROR')
    if not completion.exists():
        return dict(case_id=case['case_id'],status='INTERRUPTED')
    if payload['prepared'] is None or read(completion)!=completed_receipt(target,payload):
        raise ValueError('Parent completion is not bound to the exact successful child')
    telemetry=read(checked_ref(read(completion)['supervisor']))
    if (telemetry.get('api_key_in_child_environment') is not False or
            any(type(telemetry.get(k)) not in (int,float) or not math.isfinite(telemetry[k]) or telemetry[k]<0
                for k in ('seconds','peak_rss_mib')) or telemetry['peak_rss_mib']>8192 or
            telemetry['seconds']>frozen['per_case_timeout_seconds']+3):
        raise ValueError('Missing native supervisor receipt')
    packet=validated_child(target,payload,frozen)
    branches=packet['result']['readings']
    branch=next((b for b in branches if b['candidates']),branches[0] if branches else {})
    return dict(case_id=case['case_id'],status='COMPLETE',primary_reading=branch.get('reading',{}).get('id'),
        candidates=[dict(id=c['id'],rank=c['rank'],fill=c['fill'],status=c['local_decision']['status'])
            for c in branch.get('candidates',[])])


def fail_case(target,case,stage,reason):
    put(target/'failure.json',dict(version=RUN_VERSION,case_id=case['case_id'],input=ref(target/'input.json'),
        stage=stage,reason=reason,in_denominator=True,automatic_retry=False))


def run(options):
    from matryoshka_narrative.guards import require_headroom
    dataset=checked_cases(options.dataset)
    cases=bounded_selection(options,dataset)  # Authorization precedes any epoch creation.
    output=local_output(options.out)
    require_headroom(output)
    with stage_lock(output):
        frozen=freeze_run(options,dataset,cases,output)
        validate_freeze(output,dataset,live=True)
        for case in cases:
            validate_freeze(output,dataset,live=True,validate_plans=False)
            target=output/case['case_id']
            state=terminal_state(output,case,frozen)
            if state['status'] in {'COMPLETE','NATIVE_ERROR','PLANNING_ERROR'}:
                continue
            if state['status']=='INTERRUPTED':
                fail_case(target,case,'interrupted','INTERRUPTED_NO_AUTOMATIC_RETRY')
                continue
            require_headroom(output)  # An unpaid pre-launch pause leaves no attempted case.
            payload=case_input(output,case,frozen)
            if payload['prepared']:
                checked_prepared(checked_ref(payload['prepared']),case)
            put(target/'input.json',payload)
            if payload['planning_failure']:
                fail_case(target,case,'planning','RETAINED_PLANNING_FAILURE')
                continue
            try:
                telemetry=monitored_child([sys.executable,'-B',str(Path(__file__).resolve()),'_case',
                    '--out',str(target)],seconds=options.timeout_seconds,disk_check=lambda:require_headroom(output))
                validated_child(target,payload,frozen)
                validate_freeze(output,dataset,live=True,validate_plans=False)
                put(target/'supervisor.json',telemetry)
                put(target/'completion.json',completed_receipt(target,payload))
            except (TimeoutError,RuntimeError,OSError,ValueError,KeyError) as error:
                fail_case(target,case,'native','TIMEOUT' if isinstance(error,TimeoutError) else type(error).__name__)
                print(case['case_id']+' FAILED',flush=True)
                validate_freeze(output,dataset,live=True)  # Drift stops all subsequent work.
            else:
                print(case['case_id']+' COMPLETE',flush=True)


def child(options):
    with stage_lock(local_output(options.out)):
        return _child(options)


def _child(options):
    import resource
    from matryoshka_narrative import workflow
    from matryoshka_demo.io import offline
    from matryoshka_demo.source_view_policy import SourceViewPolicy
    target=local_output(options.out)
    payload=read(target/'input.json')
    root=checked_ref(payload['freeze']).parent
    dataset=checked_cases(checked_ref(read(root/'freeze.json')['dataset']))
    frozen,cases=validate_freeze(root,dataset,live=True,validate_plans=False)
    if (target.parent!=root or payload['case'] not in cases or target.name!=payload['case']['case_id'] or
            payload!=case_input(root,payload['case'],frozen) or payload['prepared'] is None or
            any((target/name).exists() for name in ('completion.json','failure.json','child_completion.json',
                'native.json.gz','attempt_started.json'))):
        raise ValueError('Child is not a new authorized selected-case attempt')
    prepared=checked_prepared(checked_ref(payload['prepared']),payload['case'])
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_CPU,(frozen['per_case_timeout_seconds'],frozen['per_case_timeout_seconds']+1))
    workflow.OUTPUT=target/'checkpoints'
    cfg=dict(frozen['settings'],source_view_policy=SourceViewPolicy(frozen['settings']['source_view_policy']))
    put(target/'attempt_started.json',dict(execution_key=payload['execution_key'],input=ref(target/'input.json'),
        api_calls=0,started_utc=datetime.now(timezone.utc).isoformat()))
    with offline(), workflow.Session(root=ROOT,refs_path=checked_ref(frozen['execution_refs'])) as session:
        if session.refs!=frozen['resource_refs'] or session.environment!=frozen['environment']:
            raise ValueError('Native Session is not the frozen resource/environment')
        packet=session.execute(payload['case'],prepared['plan']['native_plan'],readings_packet=prepared['readings'],**cfg)
        validate_native(packet,payload['case'],prepared,frozen)
        validate_freeze(root,dataset,live=True,validate_plans=False)
        put(target/'native.json.gz',packet)
        put(target/'child_completion.json',child_receipt(target,packet,payload))


def read_gold_for_qa():
    raw=TARGETS.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=TARGETS_SHA:
        raise ValueError('Gold catalog changed')
    rows=[json.loads(line) for line in raw.splitlines() if line.strip()]
    if len(rows)!=len({row['case_id'] for row in rows}):
        raise ValueError('Duplicate gold identities')
    return {row['case_id']:row for row in rows}


def terminal_inventory(root,cases):
    names=('input.json','completion.json','failure.json','child_completion.json','supervisor.json',
        'native.json.gz','attempt_started.json')
    return [dict(case_id=case['case_id'],files={name:ref(root/case['case_id']/name)
        if (root/case['case_id']/name).is_file() else None for name in names}) for case in cases]


def score(options):
    epoch=getattr(options,'qa_epoch',None)
    if not isinstance(epoch,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',epoch):
        raise ValueError('Scoring requires a new explicit --qa-epoch literal name')
    dataset=checked_cases(options.dataset)
    root=local_output(options.out)
    with stage_lock(root):
        qa=root/'QA'/epoch
        if qa.exists():
            raise ValueError('QA epoch already exists; preserve it and name a new epoch')
        frozen,cases=validate_freeze(root,dataset)
        rows=[]
        for case in cases:
            try:
                rows.append(terminal_state(root,case,frozen))
            except (ValueError,KeyError,OSError,TypeError) as error:
                rows.append(dict(case_id=case['case_id'],status='INTEGRITY_ERROR',error_type=type(error).__name__))
        references=[ref(root/'freeze.json'),frozen['source_archive'],frozen['metric_freeze']]
        references.extend(reference for entry in frozen['case_inputs'] for reference in
            (entry['prepared'],entry['planning_failure']) if reference)
        inventory=terminal_inventory(root,cases)
        references.extend(reference for entry in inventory for reference in entry['files'].values() if reference)
        before=dict(version=METRIC_VERSION,qa_epoch=epoch,frozen_utc=datetime.now(timezone.utc).isoformat(),
            dataset=ref(options.dataset),run_freeze=ref(root/'freeze.json'),metric=frozen['metric_freeze'],
            producer=runner_reference(),selected_case_ids=frozen['selected_case_ids'],pre_gold_case_states=rows,
            input_references=references,terminal_inventory=inventory,
            gold_expected_sha256=TARGETS_SHA,gold_opened_by_this_QA_stage=False)
        put(qa/'metric_freeze_BEFORE_GOLD.json',before)
        gold=read_gold_for_qa()  # The only scoring gold access, after all bindings/choices are sealed.
        normalize=lambda value:' '.join(value.casefold().split())
        for case,row in zip(cases,rows):
            row.update(literal={},normalized_literal={})
            target=gold.get(case['case_id'])
            try:
                valid_gold=target is not None and public_target(target)==case and isinstance(target.get('answer'),str) and bool(target['answer'])
            except (KeyError,ValueError,TypeError,AttributeError):
                valid_gold=False
            if not valid_gold:
                row['prior_status']=row['status'];row['status']='GOLD_JOIN_ERROR'
                continue
            if row['status']=='COMPLETE':
                for k in (1,3,5):
                    candidates=row['candidates'][:k]
                    row['literal'][str(k)]=any(c['fill']==target['answer'] for c in candidates)
                    row['normalized_literal'][str(k)]=any(normalize(c['fill'])==normalize(target['answer']) for c in candidates)
        for reference in references:
            checked_ref(reference)
        if terminal_inventory(root,cases)!=inventory:
            raise ValueError('Native terminal state changed during QA; keep the pre-gold hold and choose a new epoch')
        counts={status:sum(row['status']==status for row in rows) for status in
            ('COMPLETE','NOT_RUN','NATIVE_ERROR','PLANNING_ERROR','INTERRUPTED','INTEGRITY_ERROR','GOLD_JOIN_ERROR')}
        result=dict(version=RUN_VERSION,qa_only=True,qa_epoch=epoch,metric_freeze=ref(qa/'metric_freeze_BEFORE_GOLD.json'),
            cohort=dataset['cohort'],dataset_n=len(dataset['cases']),selected_n=len(cases),statuses=counts,
            completed_n=counts['COMPLETE'],not_run_n=counts['NOT_RUN'],native_error_n=counts['NATIVE_ERROR'],
            planning_error_n=counts['PLANNING_ERROR'],
            literal_hits={k:sum(row['literal'].get(k,False) for row in rows) for k in ('1','3','5')},
            normalized_literal_hits={k:sum(row['normalized_literal'].get(k,False) for row in rows) for k in ('1','3','5')},
            literal_denominator=len(cases),errors_count_as_misses=True,accuracy_rate_reportable=False,
            development_literal_rate_reportable=not any(counts[k] for k in
                ('NOT_RUN','INTERRUPTED','INTEGRITY_ERROR','GOLD_JOIN_ERROR')),
            semantic_equivalence_graded=False,source_support_correctness_graded=False,
            population_accuracy_claimed=False,source_supported_population_known=False,rows=rows)
        put(qa/'recovery_QA_ONLY.json',result)
        print(json.dumps({key:value for key,value in result.items() if key!='rows'}))
        return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['prepare','plan','run','score','_case'])
    parser.add_argument('--out',required=True)
    parser.add_argument('--cohort',choices=['substantive184','mechanical215','historical332'],default='substantive184')
    parser.add_argument('--dataset')
    parser.add_argument('--plans')
    selection=parser.add_mutually_exclusive_group()
    selection.add_argument('--limit',type=int)
    selection.add_argument('--all',action='store_true')
    parser.add_argument('--confirm-population-sha')
    parser.add_argument('--execute-paid',action='store_true')
    parser.add_argument('--max-additional-usd',type=float)
    parser.add_argument('--model',choices=['gpt-6-luna','gpt-6.1-sol'],default='gpt-6.1-sol')
    parser.add_argument('--reading-model',choices=['gpt-6-luna','gpt-6.1-sol'],default='gpt-6.1-sol')
    parser.add_argument('--source-alignment',action='store_true')
    parser.add_argument('--terminal-ranking',choices=['evidence_fit_v3','evidence_fit_v5','evidence_fit_v6'],default='evidence_fit_v6')
    parser.add_argument('--qa-epoch',help='New explicit QA snapshot name; scoring never overwrites a prior epoch')
    parser.add_argument('--timeout-seconds',type=int,default=300)
    options=parser.parse_args()
    if options.stage in {'plan','run','score'} and not options.dataset:
        parser.error('--dataset required')
    if options.stage=='run' and not options.plans:
        parser.error('--plans required')
    if not 1<=options.timeout_seconds<=900:
        parser.error('Timeout must be 1..900 seconds')
    globals()[{'_case':'child'}.get(options.stage,options.stage)](options)


if __name__=='__main__':
    main()
