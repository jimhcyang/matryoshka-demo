"""Isolated code ZIP import check; no installs, inference, API or source databases."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    bundle, output = args.bundle.resolve(), args.output.absolute()
    assert bundle.is_relative_to(HERE) and output.is_relative_to(HERE) and not output.exists()
    receipt = json.loads(bundle.with_suffix('.json').read_bytes())
    with tempfile.TemporaryDirectory(dir=HERE) as temporary:
        root = Path(temporary)
        with zipfile.ZipFile(bundle) as archive:
            for row in receipt['files']:
                name = 'export-package/' + row['path']
                assert not name.startswith('/') and '..' not in Path(name).parts
                raw = archive.read(name)
                assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
                if row['path'] == 'backend-source-snapshot.json':
                    value = json.loads(raw)
                    assert b'/Users/' not in raw
                    assert all(r['source'].startswith('SOURCE_ROOT/') and not r['target'].startswith('/') for r in value['files'])
            assert set(archive.namelist()) == {'export-package/' + r['path'] for r in receipt['files']}
            assert 'export-package/backend/contracts/planning_v2/masked_examples.json' not in archive.namelist()
            archive.extractall(root)
        package = root / 'export-package'
        script = ('import sys;sys.path.insert(0,' + repr(str(package / 'backend')) + ');'
            'import matryoshka_narrative.server;from pathlib import Path;'
            'root=Path(' + repr(str(package / 'backend')) + ');'
            'mods=[m for n,m in sys.modules.items() if n.startswith("matryoshka_") and getattr(m,"__file__",None)];'
            'assert mods and all(Path(m.__file__).is_relative_to(root) for m in mods);print(len(mods))')
        result = subprocess.run([sys.executable, '-I', '-B', '-c', script], cwd='/tmp', capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        help_result = subprocess.run([sys.executable, '-B', str(package / 'export_narrative.py'), '--help'],
            cwd='/tmp', capture_output=True, text=True)
        assert help_result.returncode == 0, help_result.stderr
        assert '--reuse-graph-stage' in help_result.stdout and '--resume' in help_result.stdout
    value = dict(pass_=True, zip_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest(), files=len(receipt['files']),
        isolated_import_modules=int(result.stdout.strip()), contained_backend_imports=True,
        generic_export_help_pass=True, api_calls=0, native_executions=0)
    output.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(value))


if __name__ == '__main__':
    main()
