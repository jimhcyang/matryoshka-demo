"""Final same-repository export with explicit replaceable release inputs."""
import argparse
from pathlib import Path
from export_narrative import ROOT, main


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--backend-root', type=Path, required=True)
    parser.add_argument('--map-root', type=Path, default=Path(__file__).resolve().parent / 'map_inputs_v01')
    parser.add_argument('--report-ref', default='phase/release_finish_20261121/publication_final_update_v02/report_ref.json')
    parser.add_argument('--casebook-ref', default='phase/release_finish_20261121/publication_final_update_v02/casebook_ref.json')
    parser.add_argument('--digest-ref', default='experiments/full_resume_20261120/digests_release_finish_v04/index_ref.json')
    parser.add_argument('--field-guide-directory', default='phase/release_finish_20261121/walkthrough/saved_fourteen_v05')
    parser.add_argument('--ui-root', type=Path, default=ROOT / 'experiments/full_resume_20261120/ui')
    parser.add_argument('--reuse-response-stage', type=Path)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    flags = ['--root', str(ROOT), '--map-root', str(args.map_root),
        '--map-index-sha256', 'a4f08ac865bb21faed97e1792fc2c84baba0e8483f5fb92c7604fec96f5e30f0',
        '--pdf-catalog', 'experiments/visual_refinement_20261120/pdfs/catalog-resource-bound.json',
        '--pdf-catalog-sha256', '9cff25abf01546029a3fc6060bb0490b07f79424c684f8182770c72afbc9c0ef',
        '--supplement-manifest', str(ROOT / 'experiments/full_resume_20261120/deploy/swedish_supplement_v03_ref.json'),
        '--public-metadata-projection', '--graph-delivery', 'same-repository', '--backend-root', str(args.backend_root),
        '--ui-root', str(args.ui_root), '--output', str(args.output)]
    for name in ('report_ref', 'casebook_ref', 'digest_ref', 'field_guide_directory'):
        flags.extend(('--' + name.replace('_', '-'), str(ROOT / getattr(args, name))))
    if args.reuse_response_stage:
        flags.extend(('--reuse-response-stage', str(args.reuse_response_stage)))
    if args.resume:
        flags.append('--resume')
    main(flags)
