# Slot Context Handoff

Complete. Main owns client/runtime wiring, stage changes, sealing and publication.
No graph JS, runtime, stage or installed-repo files were edited for this task.
No network/API/native execution or full graph/corpus regeneration was used.

## Contract

Contract version is UNCHANGED: `current-opaque-source-slots/2`.
Additive policy identifier: `source-visible-slot-context/1`.
New record fields: `context_policy`, `label_context` (exact visible proof or null).
Status adds `context_policy`; rebuilt status also adds `context_rebuild` receipts.
Thin catalogs now include `label` and `context_policy` as well as existing fields.
All existing slot IDs, observed slot IDs, ordinals, marker offsets, page routes,
page hashes, coverage and source-audit entries are preserved.

## Implementation

- `matryoshka_current/slot_context.py`: rejects function-word-only labels, bare
  titles/directions/generic fragments, dangling function-word endings, ambiguous
  duplicate labels, bare tokens within longer capitalized names, and nested
  shorter matches. Complete titles/names such as The Hague and General + surname
  remain valid. No entity or case-specific production exceptions.
- Matching is exact and case-insensitive with source whitespace wrapping allowed;
  punctuation cannot disappear. Full-text word boundaries are checked even at
  the 320-character anchoring-window boundary. At most six anchors; complete
  multiword terms rank first. Selection is conservative, not entity resolution.
- Labels are `Redacted Slot / near <exact visible anchor>`, or a brief literal
  nearby excerpt without inventing an anchor. With no usable visible context the
  label is just `Redacted Slot`. Label proofs are exact normalized-page spans.
- Search preview is a word-bounded, marker-centered +/-960-character visible
  window; anchors remain +/-320. Both `opaque slot` and `redacted slot` aliases
  work in the lazy Python overlay. No hidden answer/case query fields are used.
- `slot_overlay.recontextualize_record` validates saved page hashes/provenance,
  marker identity/offsets, nonsemantic status and existing source proof spans,
  then changes only naming/context/navigation fields.

## Ready-To-Merge Artifacts

Use ONLY `slots/rebuilt-verified/overlay-index.json` and its referenced gzip
packets. This is a sparse logical-route overlay, NOT a replacement site index.
It contains 224 routes: 221 CIB record shards plus the three corpus catalogs.
All existing `/data/slots/<corpus>/<page-hash>.json` routes MUST remain unchanged.
The original stage and dataset store were read-only inputs.

Main can decode each gzip packet, verify its wire/decoded hashes, then pass
`worker.put(logical_route, json.loads(decoded_bytes))` to the existing exporter,
or merge equivalent gzip entries with appropriately rebased physical paths.
Do not replace the full `api-index.json` with this sparse index. No graph pack,
source-page pack or dataset re-export is necessary.

Client/runtime must search the updated thin `label` and `context_preview` and
accept the additive fields. Keep reverse anchor lookup using the updated thin
anchor IDs, and retain zero semantic/layout weights. Include `slot_context.py`
alongside `slot_overlay.py` in any backend/code bundle. If the future static
exporter thins rows again, retain `label` and `context_policy`; this task did not
edit the exporter/runtime. No client/browser verification was run in this scope.

## Verification

`slots/pytest.xml`: 37 passed (32 focused slot cases + 5 map-transport tests).
Focused tests cover The/function words, fragments, duplicate names, The Hague,
genuine General titles, wrapping/punctuation, clipping-boundary prefixes, phrase
search, hidden-value isolation, stable markers/provenance, bidirectional lookup,
page/vocabulary tampering, nonsemantic guards and bounded rebuild behavior.

`slots/rebuilt-verified/report.json`: 28,201 slots, 221 record shards, 16,133
saved pages, 16,358 CIB input routes. Links changed from 143,258 to 136,640.
Iran/Vietnam remain zero observed slots; no unused vocabulary was loaded there.
The complete 3GB graph, comparison roots and original source shards were NOT read.

`slots/rebuilt-verified/verification.json`: independent all-record validation of
immutable fields, thin/detail consistency, source word boundaries, exact label
and anchor proofs, unchanged source audits, zero-weight links and reciprocity.
Zero immutable-field changes and zero forbidden anchor labels. 23,943 explicit
label proofs. 24,004 reciprocal anchor IDs. All checks passed.

Real requested query: `Israel determined to transfer Foreign Ministry to Jerusalem`.
The matching following mask is `opaque_slot_b771169aa36650e0e648f95b`, document
`CIA-RDP79T00975A000800210001-2`, source page 5. Its label is
`Redacted Slot / near Israeli Foreign Minister`; anchors include visible Jerusalem
and Israel, never The. The wider context also finds another mask on that page;
the verification receipt distinguishes the immediately following marker.
The production matcher contains no query/entity-specific special case.

## Reproduce

From workspace root (choose a NEW output directory):

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src-demo-day .venv/bin/python -m pytest -q -p no:cacheprovider src-demo-day/tests/test_current_slot_context_patch.py src-demo-day/tests/test_current_map_transport.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python src-demo-day/phase/kg_patch_20261122/slots/rebuild.py --site src-demo-day/phase/kg_patch_20261122/stage/site --datasets-root matryoshka_demo_site/datasets --output src-demo-day/phase/kg_patch_20261122/slots/NEW_OUTPUT
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python src-demo-day/phase/kg_patch_20261122/slots/verify.py --site src-demo-day/phase/kg_patch_20261122/stage/site --datasets-root matryoshka_demo_site/datasets --output src-demo-day/phase/kg_patch_20261122/slots/NEW_OUTPUT --query 'Israel determined to transfer Foreign Ministry to Jerusalem'
```

`rebuild_slots(read_bytes, put_json, guard, corpora=...)` is also callable by main.
The CLI refuses output under its read-only site and guards each read/write at
3 GiB free space. Final free space exceeded 5 GiB. Do not merge earlier attempts;
their limitations are recorded in `FAILED_ATTEMPTS.md`. `exact-files.json` pins
the authoritative code, test receipt, handoff and final sparse artifact files.
