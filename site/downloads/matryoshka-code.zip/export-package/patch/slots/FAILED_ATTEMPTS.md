# Retained Attempts

- `rebuilt/`: initial CIB transformation completed, then stopped on the empty
  Iran catalog because that binding lacks CIB's optional `search_sha256` field.
  No final overlay index was published. Retained for audit; do not merge.
- `rebuilt-final/`: complete intermediate overlay, but a stricter source-word
  boundary audit detected three clipped-prefix matches. Its earlier
  `verification.json` predates that stricter check and is superseded. Labels
  were also refined afterward. Retained for audit; do not merge.
- `rebuilt-verified/`: authoritative completed overlay after the fixes, with
  strict independent verification and concise exact-anchor labels. Only this
  directory is suitable for main's sparse merge.
