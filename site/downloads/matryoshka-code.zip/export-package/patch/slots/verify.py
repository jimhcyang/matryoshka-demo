"""Independently verify every rebuilt record against its saved visible page."""
from collections import OrderedDict
import argparse
import gzip
import json
from pathlib import Path
import re
import shutil

from rebuild import StaticInputs, encoded, sha
from matryoshka_current.slot_context import MARKER, POLICY, substantive
from matryoshka_current.slot_overlay import normalized

CONTEXT_FIELDS = {"label", "label_context", "context_policy", "context_preview", "anchors", "context_links",
                  "hierarchy_placement", "domain_id", "theme_id", "community_id"}


def verify(inputs, output, query=""):
    output = Path(output)
    entries = json.loads((output / "overlay-index.json").read_bytes())["entries"]
    report = dict(verified=True, records=0, pages=0, links=0, label_proofs=0,
                  rejected_anchor_labels=0, immutable_field_changes=0, query=query, query_matches=[], corpora=[])
    for corpus in ("cib", "iran", "vietnam"):
        if shutil.disk_usage(output).free < 3 * 1024**3:
            raise RuntimeError("Stop: less than 3 GiB available")
        def load(route):
            entry = entries[route]
            wire = (output / entry["path"]).read_bytes()
            assert sha(wire) == entry["wire_sha256"]
            raw = gzip.decompress(wire)
            assert sha(raw) == entry["sha256"]
            return json.loads(raw)

        path = "/data/slots/" + corpus + ".json"
        old_catalog = json.loads(inputs.read(path))
        catalog = load(path)
        assert catalog["details"] == old_catalog["details"]
        assert catalog["status"]["coverage"] == old_catalog["status"]["coverage"]
        assert catalog["status"]["source_audit"] == old_catalog["status"]["source_audit"]
        assert catalog["status"]["context_policy"] == POLICY
        assert [s["id"] for s in catalog["slots"]] == [s["id"] for s in old_catalog["slots"]]
        thin_by_id = {s["id"]: s for s in catalog["slots"]}
        pages, seen_pages, count, reverse = OrderedDict(), set(), 0, {}
        query_words = normalized(query).split()
        for route in dict.fromkeys(s["record_path"] for s in catalog["slots"]):
            old_records = json.loads(inputs.read(route))
            records = load(route)
            assert len(old_records) == len(records) <= 128
            for old, record in zip(old_records, records):
                assert {k: v for k, v in old.items() if k not in CONTEXT_FIELDS} == {
                    k: v for k, v in record.items() if k not in CONTEXT_FIELDS}
                count += 1
                page_path = catalog["details"][record["id"]]
                if page_path not in pages:
                    pages[page_path] = json.loads(inputs.read(page_path))
                    if len(pages) > 2:
                        pages.popitem(last=False)
                pages.move_to_end(page_path)
                seen_pages.add(page_path)
                page = pages[page_path]
                text = page["text"]
                assert page["release"] == ("earlier" if corpus == "cib" else "confidential")
                assert sha(text.encode()) == page["text_sha256"]
                assert record["page_provenance"] == {k: v for k, v in page.items() if k != "text"}
                assert text[record["marker_start"]:record["marker_end"]] == "[REDACTED]"
                assert record["label"].startswith("Redacted Slot") and len(record["label"]) <= 144
                assert record["context_preview"] in text
                assert record["label_context"] is None or not MARKER.search(record["label_context"]["text"])
                assert len(record["anchors"]) == len(record["context_links"]) <= 6
                for anchor, edge in zip(record["anchors"], record["context_links"]):
                    assert substantive(anchor["label"])
                    proof = anchor["visible_proof"]
                    assert text[proof["start"]:proof["end"]] == proof["text"]
                    assert not proof["start"] or not (text[proof["start"] - 1].isalnum() or text[proof["start"] - 1] == "_")
                    assert proof["end"] == len(text) or not (text[proof["end"]].isalnum() or text[proof["end"]] == "_")
                    assert " ".join(proof["text"].casefold().split()) == " ".join(anchor["label"].casefold().split())
                    assert all(proof[k] == page[k] for k in ("document_id", "canonical_page_id", "release"))
                    assert proof["semantic"] is False and proof["identity_certified"] is False
                    assert not MARKER.search(proof["text"])
                    assert proof["end"] <= record["marker_start"] or proof["start"] >= record["marker_end"]
                    assert edge["source"] == record["id"] and edge["target"] == anchor["id"]
                    assert edge["source_proof"] == proof and edge["weight"] == edge["layout_weight"] == 0
                    assert edge["semantic"] is False and edge["eligible_evidence"] is False and edge["slot_navigation"] is True
                    reverse.setdefault(anchor["id"], set()).add(record["id"])
                    report["links"] += 1
                excerpt = record["label_context"]
                if excerpt:
                    assert text[excerpt["start"]:excerpt["end"]] == excerpt["text"]
                    prefix = "Redacted Slot / near " if record["anchors"] else "Redacted Slot / "
                    assert record["label"] == prefix + " ".join(excerpt["text"].split())
                    if record["anchors"]:
                        proof = record["anchors"][0]["visible_proof"]
                        assert excerpt["start"] <= proof["start"] < proof["end"] <= excerpt["end"]
                    report["label_proofs"] += 1
                thin = thin_by_id[record["id"]]
                assert thin["anchors"] == [dict(id=a["id"]) for a in record["anchors"]]
                assert all(thin[k] == record[k] for k in ("label", "context_preview", "domain_id", "theme_id", "community_id"))
                if query_words and all(w in normalized(record["context_preview"]).split() for w in query_words):
                    before_mask = text[:record["marker_start"]]
                    report["query_matches"].append(dict(corpus=corpus, id=record["id"], document_id=record["document_id"],
                        source_page=record["source_page"], label=record["label"], anchors=[a["label"] for a in record["anchors"]],
                        phrase_immediately_before_mask=normalized(before_mask).endswith(normalized(query))))
        for thin in catalog["slots"]:
            for anchor in thin["anchors"]:
                assert thin["id"] in reverse[anchor["id"]]
        assert count == catalog["status"]["coverage"]["total_slots"]
        report["records"] += count
        report["pages"] += len(seen_pages)
        report["corpora"].append(dict(corpus=corpus, records=count, pages=len(seen_pages), reciprocal_anchor_ids=len(reverse)))
    assert set(entries) == {"/data/slots/" + c + ".json" for c in ("cib", "iran", "vietnam")} | {
        route for route in entries if re.fullmatch(r"/data/slots/cib/records-\d+\.json", route)}
    if query:
        assert report["query_matches"] and any(m["phrase_immediately_before_mask"] for m in report["query_matches"])
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", required=True, type=Path)
    parser.add_argument("--datasets-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--query", default="")
    args = parser.parse_args()
    report = verify(StaticInputs(args.site, args.datasets_root), args.output, args.query)
    (args.output / "verification.json").write_bytes(encoded(report))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
