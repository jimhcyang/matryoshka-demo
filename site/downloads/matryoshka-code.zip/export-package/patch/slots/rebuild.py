"""Sparse, bounded slot-only rebuild. Never loads comparison/graph/source-shard roots.

Integration: rebuild_slots(read_bytes, put_json, guard, corpora=(...)). Reuse every
existing details/page route; merge only returned record/catalog routes upstream.
The CLI writes a sparse gzip packet overlay, not a site or publication manifest.
"""
from collections import OrderedDict
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from matryoshka_current.slot_context import POLICY, VisibleVocabulary
from matryoshka_current.slot_overlay import VERSION, recontextualize_record
from matryoshka_current.map_transport import SavedMaps


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def rebuild_slots(read, put, guard, *, corpora=("cib", "iran", "vietnam")):
    report = dict(context_policy=POLICY, version=VERSION, api_calls=0, native_executions=0,
                  semantic_graph_modified=False, hidden_values_read=False, corpora=[])
    for corpus in corpora:
        if corpus not in {"cib", "iran", "vietnam"}:
            raise ValueError("Unknown slot corpus")
        guard()
        inputs = OrderedDict()

        def load(path):
            guard()
            raw = read(path)
            digest = sha(raw)
            if path in inputs and inputs[path] != digest:
                raise ValueError("Rebuild input changed while reading")
            inputs[path] = digest
            return json.loads(raw)

        path = "/data/slots/" + corpus + ".json"
        catalog = load(path)
        original_catalog_sha = inputs[path]
        status = catalog["status"]
        original_audit = {r["path"]: r["sha256"] for r in status["source_audit"]}
        view, release = ("current_earlier", "earlier") if corpus == "cib" else ("current_redaction", "confidential")
        if (status["version"] != VERSION or status["corpus"] != corpus
                or status["source_view"] != view or status["release"] != release
                or status["hidden_values_read"] is not False or status["semantic_graph_modified"] is not False
                or status["coverage"]["complete"] is not True
                or len(catalog["slots"]) != status["coverage"]["total_slots"]):
            raise ValueError("Existing slot catalog is not a complete base-visible census")
        base = "/graph-assets-v4/" + corpus + "/"
        binding = load("/api/graph-v4-viewer?corpus=" + corpus)
        if binding["asset_base"] != base:
            raise ValueError("Unexpected slot vocabulary asset binding")
        search_path = base + binding["search_asset"]
        search = load(search_path)
        if inputs[search_path] != binding.get("search_sha256", original_audit.get(search_path)):
            raise ValueError("Search manifest bytes changed")
        if any(value[k] != status[k] for value in (binding, search) for k in ("graph_run_id", "hierarchy_run_id")):
            raise ValueError("Slot graph/hierarchy pins differ")
        vocab_path = base + search["view_files"][view]
        if view not in vocab_path or any(t in vocab_path for t in ("current_later", "current_reveal", "..", "\\")):
            raise ValueError("Vocabulary is not a bound base-visible path")
        vocabulary = None
        if catalog["slots"]:
            vocabulary = load(vocab_path)
            if vocabulary["view_key"] != view or inputs[vocab_path] != original_audit.get(vocab_path):
                raise ValueError("Vocabulary differs from existing source audit")
            vocabulary = VisibleVocabulary(vocabulary["records"])
        pages, groups, seen = OrderedDict(), OrderedDict(), set()
        for thin in catalog["slots"]:
            route = thin["record_path"]
            if not re.fullmatch(r"/data/slots/" + corpus + r"/records-\d+\.json", route):
                raise ValueError("Unbound slot record route")
            groups.setdefault(route, []).append(thin)
        changed = links_before = links_after = label_changes = page_reads = 0
        for route, thin_rows in groups.items():
            old_records = load(route)
            if len(old_records) > 128 or len(old_records) != len(thin_rows):
                raise ValueError("Slot record shard exceeds its existing bound")
            records = []
            for old, thin in zip(old_records, thin_rows):
                identity = old["id"]
                if identity != thin["id"] or identity in seen:
                    raise ValueError("Duplicate or reordered slot record")
                seen.add(identity)
                page_path = catalog["details"][identity]
                if not re.fullmatch(r"/data/slots/" + corpus + r"/[a-f0-9]{64}\.json", page_path):
                    raise ValueError("Unbound saved slot page route")
                if page_path not in pages:
                    pages[page_path] = load(page_path)
                    page_reads += 1
                    if len(pages) > 2:
                        pages.popitem(last=False)
                pages.move_to_end(page_path)
                page = pages[page_path]
                if page["release"] != release:
                    raise ValueError("Saved slot page is not base-visible")
                record = recontextualize_record(old, page, vocabulary)
                records.append(record)
                changed += old != record
                label_changes += old["label"] != record["label"]
                links_before += len(old["context_links"])
                links_after += len(record["context_links"])
                for key in ("label", "context_preview", "domain_id", "theme_id", "community_id", "context_policy"):
                    thin[key] = record[key]
                thin["anchors"] = [dict(id=a["id"]) for a in record["anchors"]]
            guard()
            put(route, records)
        if len(seen) != len(catalog["slots"]) or set(catalog["details"]) != seen:
            raise ValueError("Slot catalog coverage changed")
        input_digest = sha(encoded(list(inputs.items())))
        receipt = dict(corpus=corpus, slots=len(seen), record_shards=len(groups), pages_read=page_reads,
            changed=changed, label_changes=label_changes, links_before=links_before, links_after=links_after,
            input_routes=len(inputs), input_routes_sha256=input_digest,
            original_catalog_sha256=original_catalog_sha, vocabulary_sha256=inputs.get(vocab_path),
            graph_run_id=status["graph_run_id"], hierarchy_run_id=status["hierarchy_run_id"])
        status.update(context_policy=POLICY, context_rebuild=receipt)
        guard()
        put(path, catalog)
        report["corpora"].append(receipt)
    return report


class StaticInputs(SavedMaps):
    """Reuse the existing hash-verifying DAG decoder with a tiny manifest cache."""
    def __init__(self, site, datasets):
        self.site, self.datasets = Path(site).resolve(), Path(datasets).resolve()
        self.root = self.site.parent
        raw = (self.site / "data/api-index.json").read_bytes()
        self.entries = json.loads(raw)["entries"]
        self.index_sha256 = sha(raw)
        self.chunks, self.manifests = OrderedDict(), OrderedDict()

    def _bytes(self, name, expected):
        path = self.site / name[5:] if name.startswith("site/") else self.datasets / name[9:] if name.startswith("datasets/") else None
        if path is None or ".." in Path(name).parts or "\\" in name or path.resolve() != path:
            raise ValueError("Unbound static input path")
        key = (name, expected)
        if key in self.manifests:
            self.manifests.move_to_end(key)
            return self.manifests[key]
        raw = path.read_bytes()
        if sha(raw) != expected:
            raise ValueError("Static input pin changed")
        if name.endswith(".json") and len(raw) <= 32 * 1024**2:
            self.manifests[key] = raw
            if len(self.manifests) > 2:
                self.manifests.popitem(last=False)
        return raw

    def read(self, route):
        if not (re.fullmatch(r"/data/slots/(cib|iran|vietnam)(?:/(?:records-\d+|[a-f0-9]{64}))?\.json", route)
                or re.fullmatch(r"/api/graph-v4-viewer\?corpus=(cib|iran|vietnam)", route)
                or re.fullmatch(r"/graph-assets-v4/(cib|iran|vietnam)/[^/]+_search(?:\.current_(?:earlier|redaction))?\.json", route)):
            raise ValueError("Not a bounded slot/base-vocabulary route: " + route)
        entry = self.entries[route]
        if entry["encoding"] == "fragment-dag":
            return self._fragments(entry)
        if entry.get("external_url"):
            wire = self._bytes("datasets/" + route.split("/")[2] + "/" + entry["wire_sha256"] + ".json.gz", entry["wire_sha256"])
        else:
            wire = self._bytes("site/" + entry["path"], entry["wire_sha256"])
        raw = gzip.decompress(wire) if entry["encoding"] == "gzip" else wire
        if sha(raw) != entry["sha256"]:
            raise ValueError("Decoded static input pin changed")
        return raw


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, required=True)
    parser.add_argument("--datasets-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--corpus", action="append", choices=("cib", "iran", "vietnam"))
    args = parser.parse_args()
    output = args.output.resolve()
    if output == args.site.resolve() or args.site.resolve() in output.parents:
        raise ValueError("Output must be outside the read-only site")
    output.mkdir(parents=True, exist_ok=False)

    def guard():
        if shutil.disk_usage(output).free < 3 * 1024**3:
            raise RuntimeError("Stop: less than 3 GiB available")

    guard()
    inputs, entries = StaticInputs(args.site, args.datasets_root), {}

    def put(route, value):
        guard()
        raw = encoded(value)
        wire = gzip.compress(raw, mtime=0)
        path = "packets/" + sha(wire) + ".json.gz"
        target = output / path
        target.parent.mkdir(exist_ok=True)
        target.write_bytes(wire)
        entries[route] = dict(path=path, encoding="gzip", mime="application/json", sha256=sha(raw), wire_sha256=sha(wire))

    report = rebuild_slots(inputs.read, put, guard, corpora=args.corpus or ("cib", "iran", "vietnam"))
    (output / "overlay-index.json").write_bytes(encoded(dict(version="slot-context-sparse-overlay/1", entries=entries)))
    (output / "report.json").write_bytes(encoded(report))
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
