"""Merge only the verified sparse slot overlay and compose its runtime block."""
import argparse
from copy import deepcopy
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile

HERE = Path(__file__).resolve().parent
PATCH = HERE.parent
DEPLOY = PATCH.parent / "release_finish_20261121/deploy"
OLD_BRANCH = '    if (key.startsWith("/api/current/slots-v1?") && !own(index.entries,key)) return verifiedSlots(key, signal);'
NEW_BRANCH = '    if (key.startsWith("/api/current/slots-v1?")) return verifiedSlots(key, signal);'
ROUTE = re.compile(r"/data/slots/(cib|iran|vietnam)(?:/records-\d+)?\.json")
PAGE = re.compile(r"/data/slots/(cib|iran|vietnam)/[a-f0-9]{64}\.json")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def alias(key):
    return key.split("?", 1)[0] == "/api/current/slots-v1"


def guard(path):
    if shutil.disk_usage(path).free < 3 * 1024**3:
        raise RuntimeError("Stop: less than 3 GiB free")


def compose_runtime(raw, original=None, replacement=None):
    original = (DEPLOY / "slot-runtime.js").read_bytes() if original is None else original
    replacement = (HERE / "slot-runtime.js").read_bytes() if replacement is None else replacement
    if raw.count(original) == 1:
        updated = raw.replace(original, replacement, 1)
    elif raw.count(replacement) == 1:
        updated = raw
    else:
        raise ValueError("The exact original/generated slot runtime block is not unique")
    old, new = OLD_BRANCH.encode(), NEW_BRANCH.encode()
    if updated.count(old) == 1:
        updated = updated.replace(old, new, 1)
    elif updated.count(new) != 1:
        raise ValueError("The exact slot dispatch seam changed")
    if updated.count(b"  function selectStaticSlots(") != 1:
        raise ValueError("Duplicate slot selector")
    before = raw.replace(original if original in raw else replacement, b"SLOT_BLOCK", 1).replace(old, new)
    after = updated.replace(replacement, b"SLOT_BLOCK", 1)
    if before != after:
        raise ValueError("Composition changed code outside the slot block/dispatch")
    return updated


def merge_index(index, sparse, prefix="data/slot-context-patch/"):
    if sparse.get("version") != "slot-context-sparse-overlay/1" or not sparse.get("entries"):
        raise ValueError("Not a verified sparse slot overlay")
    result = deepcopy(index)
    removed = sorted(key for key in result["entries"] if alias(key))
    for key in removed:
        del result["entries"][key]
    for key, entry in sparse["entries"].items():
        if not ROUTE.fullmatch(key) or entry.get("encoding") != "gzip" or key not in index["entries"]:
            raise ValueError("Sparse overlay may only replace existing slot record/catalog routes")
        if not re.fullmatch(r"packets/[a-f0-9]{64}\.json\.gz", entry.get("path", "")):
            raise ValueError("Unsafe sparse packet path")
        result["entries"][key] = dict(entry, path=prefix + Path(entry["path"]).name)
    unchanged = {k: v for k, v in index["entries"].items() if k not in sparse["entries"] and not alias(k)}
    if unchanged != {k: v for k, v in result["entries"].items() if k not in sparse["entries"]}:
        raise ValueError("A non-slot root/source-page binding changed")
    return result, removed


def atomic_write(path, raw):
    guard(path.parent)
    with tempfile.NamedTemporaryFile(dir=path.parent, prefix=".slot-patch-", delete=False) as stream:
        name = Path(stream.name)
        stream.write(raw)
    os.replace(name, path)


def integrate(site, overlay, output):
    site, overlay, output = Path(site).resolve(), Path(overlay).resolve(), Path(output).resolve()
    if site in output.parents or output == site:
        raise ValueError("Integration receipts must be outside the site")
    guard(output.parent)
    output.mkdir(exist_ok=False)
    index_path, runtime_path = site / "data/api-index.json", site / "runtime/public-runtime.js"
    index_raw, runtime_raw = index_path.read_bytes(), runtime_path.read_bytes()
    sparse = json.loads((overlay / "overlay-index.json").read_bytes())
    verification = json.loads((overlay / "verification.json").read_bytes())
    if verification.get("verified") is not True or verification.get("immutable_field_changes") != 0:
        raise ValueError("Sparse source-only verification did not pass")
    index = json.loads(index_raw)
    updated, removed = merge_index(index, sparse)
    runtime = compose_runtime(runtime_raw)
    files, bytes_added = [], 0
    for route, entry in sparse["entries"].items():
        guard(site)
        path = overlay / entry["path"]
        if path.resolve() != path:
            raise ValueError("Sparse packet cannot be a symlink")
        wire = path.read_bytes()
        if sha(wire) != entry["wire_sha256"] or sha(gzip.decompress(wire)) != entry["sha256"]:
            raise ValueError("Sparse packet wire/decoded pin changed")
        if re.fullmatch(r"/data/slots/(cib|iran|vietnam)\.json", route):
            catalog = json.loads(gzip.decompress(wire))
            current = index["entries"][route]["sha256"]
            if current not in {entry["sha256"], catalog["status"]["context_rebuild"]["original_catalog_sha256"]}:
                raise ValueError("Slot catalog changed since the verified rebuild")
        destination = site / updated["entries"][route]["path"]
        destination.parent.mkdir(exist_ok=True)
        if destination.exists():
            if destination.read_bytes() != wire:
                raise ValueError("Content-addressed slot packet collision")
        else:
            atomic_write(destination, wire)
            bytes_added += len(wire)
        files.append(dict(path=str(destination.relative_to(site)), bytes=len(wire), sha256=sha(wire), route=route))
    # Compare-and-swap guard: parallel owners must not lose index/runtime work.
    if index_path.read_bytes() != index_raw or runtime_path.read_bytes() != runtime_raw:
        raise ValueError("Stage index/runtime changed during integration; retry from current inputs")
    (output / "before-api-index.json").write_bytes(index_raw)
    (output / "before-public-runtime.js").write_bytes(runtime_raw)
    new_index_raw = encoded(updated)
    atomic_write(runtime_path, runtime)
    atomic_write(index_path, new_index_raw)
    unchanged = {k: v for k, v in index["entries"].items() if k not in sparse["entries"] and not alias(k)}
    pages = {k: v for k, v in unchanged.items() if PAGE.fullmatch(k)}
    report = dict(version="slot-runtime-integration/1", contract_version="current-opaque-source-slots/2",
        context_policy="source-visible-slot-context/1", before_index_sha256=sha(index_raw), index_sha256=sha(new_index_raw),
        before_runtime_sha256=sha(runtime_raw), runtime_sha256=sha(runtime), entries_before=len(index["entries"]),
        entries_after=len(updated["entries"]), sparse_routes=len(files), removed_slot_aliases=removed,
        unchanged_non_slot_routes=len(unchanged), unchanged_non_slot_routes_sha256=sha(encoded(unchanged)),
        preserved_source_pages=len(pages), preserved_source_pages_sha256=sha(encoded(pages)),
        api_calls=0, native_executions=0, dataset_files_read=0, bytes_added=bytes_added, files=files,
        html_hooks_updated=False, release_seal_updated=False)
    (output / "integration.json").write_bytes(encoded(report))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, default=PATCH / "stage/site")
    parser.add_argument("--overlay", type=Path, default=PATCH / "slots/rebuilt-verified")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = integrate(args.site, args.overlay, args.output)
    print(json.dumps({k: v for k, v in result.items() if k != "files"}, indent=2))


if __name__ == "__main__":
    main()
