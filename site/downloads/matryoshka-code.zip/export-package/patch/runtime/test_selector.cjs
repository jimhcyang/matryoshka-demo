"use strict";
const assert=require("node:assert/strict"),fs=require("node:fs"),vm=require("node:vm"),path=require("node:path");
const runtime=fs.readFileSync(process.argv[2]||path.join(__dirname,"../stage/site/runtime/public-runtime.js"),"utf8");
const start=runtime.indexOf("  function selectStaticSlots("),end=runtime.indexOf("  async function verifiedSlots(",start);
assert(start>=0&&end>start);
const box={slotNormalized:s=>s.toLowerCase().replace(/[^a-z0-9]+/g," ").trim(),fail:(c,m)=>{throw Error(c+":"+m);}};
vm.createContext(box);
vm.runInContext(runtime.slice(start,end)+"\nglobalThis.select=selectStaticSlots",box);
const row={id:"opaque_1",slot_id:"slot_abc",document_id:"document_1",date:"1951-01-01",
  context_policy:"source-visible-slot-context/1",label:"Redacted Slot / near The Hague",
  context_preview:"Delegates in The Hague consulted General Nadir. [REDACTED]",
  anchors:[{id:"hague"},{id:"general_nadir"}],community_id:"c"};
const other={...row,id:"opaque_2",label:"Redacted Slot / near General Nadir",anchors:[{id:"general_nadir"}]};
const catalog={status:{corpus:"cib",graph_run_id:"g",hierarchy_run_id:"h"},slots:[row,other]};
const p={corpus:"cib",graph_id:"g",hierarchy_id:"h",offset:"0",limit:"32",scan:"0",q:""};
assert.equal(box.select(catalog,{...p,q:"Redacted Slot"}).matched_count,2);
assert.equal(box.select(catalog,{...p,q:row.label}).matched_count,2);
assert.equal(box.select(catalog,{...p,anchor_id:"hague"}).matched_count,1);
assert.equal(box.select(catalog,{...p,anchor_id:"general_nadir"}).matched_count,2);
assert.equal(box.select(catalog,{...p,anchor_id:"The"}).matched_count,0);
assert.equal(box.select(catalog,{...p,anchor_id:"hague",community_id:"wrong"}).matched_count,0);
for(const label of ["CONCEALED_SENTINEL","Redacted Slot / near CONCEALED_SENTINEL"]){
  const hidden={...row,label};
  const data={...catalog,slots:[hidden]};
  assert.equal(box.select(data,{...p,q:"CONCEALED_SENTINEL"}).matched_count,0);
  assert.equal(box.select(data,{...p,q:"The Hague"}).matched_count,1);
}
assert.equal(box.select({...catalog,slots:[{...row,context_policy:undefined}]},{...p,q:"near Hague"}).matched_count,0);
assert.equal(box.select(catalog,{...p,slot_id:row.id}).slot.id,row.id);
assert.equal(box.select(catalog,{...p,limit:"1"}).next_offset,1);
for(const change of [{graph_id:"wrong"},{hierarchy_id:"wrong"},{limit:"65"},{offset:"-1"},{scan:"2"},{q:"x".repeat(201)},{slot_id:"missing"}])
  assert.throws(()=>box.select(catalog,{...p,...change}));
assert(runtime.includes('if (key.startsWith("/api/current/slots-v1?")) return verifiedSlots(key, signal);'));
assert(!runtime.includes('if (key.startsWith("/api/current/slots-v1?") && !own(index.entries,key))'));
console.log("PASS actual staged selector: visible-label guard, generic search, reciprocal anchors, pins, pagination and unconditional alias bypass");
