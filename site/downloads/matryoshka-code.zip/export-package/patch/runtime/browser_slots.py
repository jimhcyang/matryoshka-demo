"""Exercise the actual staged transport in managed Chromium, without HTML edits."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import argparse
import gzip
import json
from pathlib import Path
import sys
import threading
from urllib.parse import urlencode, urlsplit

from playwright.sync_api import sync_playwright

from integrate_slots import HERE, encoded, guard, sha

sys.path.insert(0, str(HERE.parent / "slots"))
from rebuild import StaticInputs


def run(site, output):
    site, output = Path(site).resolve(), Path(output).resolve()
    guard(output.parent)
    index_raw = (site / "data/api-index.json").read_bytes()
    index = json.loads(index_raw)
    verification = json.loads((HERE.parent / "slots/rebuilt-verified/verification.json").read_bytes())
    target = next(row for row in verification["query_matches"] if row["phrase_immediately_before_mask"])
    query = verification["query"]
    inputs = StaticInputs(site, HERE)
    bindings = {c: json.loads(inputs.read("/api/graph-v4-viewer?corpus=" + c)) for c in ("cib", "iran", "vietnam")}
    catalog = json.loads(inputs.read("/data/slots/cib.json"))
    thin = next(row for row in catalog["slots"] if row["id"] == target["id"])
    expected = next(row for row in json.loads(inputs.read(thin["record_path"])) if row["id"] == target["id"])
    original = StaticInputs(site, HERE)
    original.entries = json.loads((HERE / "integration-v1/before-api-index.json").read_bytes())["entries"]
    old_records = json.loads(original.read(thin["record_path"]))
    old_target = next(row for row in old_records if row["id"] == target["id"])
    stale_anchors = sorted({a["id"] for row in old_records for a in row["anchors"] if a["label"].casefold() == "the"})
    assert stale_anchors, "Need an actual old The-anchor identity for the reverse regression"
    assert all(expected[k] == old_target[k] for k in ("id", "slot_id", "ordinal", "marker_start", "marker_end", "page_provenance"))
    sentinel = encoded(dict(status="STALE_PRECOMPUTED_ALIAS", hidden="CONCEALED_SENTINEL", anchors=[dict(label="The")]))
    alias_params = dict(corpus="cib", graph_id=bindings["cib"]["graph_run_id"], hierarchy_id=bindings["cib"]["hierarchy_run_id"],
                        limit="64", offset="0", q=query, scan="0")
    alias_key = "/api/current/slots-v1?" + urlencode(sorted(alias_params.items()))
    injected_index = json.loads(index_raw)
    injected_index["entries"][alias_key] = dict(path="runtime/__stale-slot-alias.json", encoding="identity",
        mime="application/json", sha256=sha(sentinel), wire_sha256=sha(sentinel))
    injected_raw = encoded(injected_index)
    requests = []
    prefix = "/slot-runtime-probe/"

    class Handler(SimpleHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            requests.append(self.path)
            path = urlsplit(self.path).path
            if path in (prefix + "__probe", prefix + "__alias_probe"):
                injected = path.endswith("__alias_probe")
                pin = sha(injected_raw if injected else index_raw)
                index_path = "runtime/__alias-index.json" if injected else "data/api-index.json"
                raw = ("<!doctype html><html><head><meta charset=\"utf-8\">"
                       "<script src=\"runtime/public-runtime.js\" data-site-base=\"../\" data-index=\"" + index_path +
                       "\" data-index-sha256=\"" + pin + "\"></script></head><body>Saved slot transport probe</body></html>").encode()
                return self.respond(raw, "text/html")
            if path == prefix + "runtime/__alias-index.json":
                return self.respond(injected_raw, "application/json")
            if path == prefix + "runtime/__stale-slot-alias.json":
                return self.respond(sentinel, "application/json")
            if not path.startswith(prefix):
                self.send_error(404)
                return
            self.path = self.path[len(prefix) - 1:]
            return super().do_GET()

        def respond(self, raw, mime):
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

    server = ThreadingHTTPServer(("127.0.0.1", 0), partial(Handler, directory=str(site)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    origin = "http://127.0.0.1:" + str(server.server_port)
    report = dict(pass_=False, managed_chromium_headless_shell=True, actual_staged_runtime=True,
        actual_staged_index=True, persistent_html_edits=False, index_sha256=sha(index_raw),
        runtime_sha256=sha((site / "runtime/public-runtime.js").read_bytes()), model_api_calls=0,
        native_executions=0, dataset_files_read=0, cells=[], external_or_api_requests=[],
        stale_the_anchor_ids=stale_anchors)
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.launch(headless=True)
            try:
                for name, width, injected in (("desktop", 1280, False), ("mobile", 390, False), ("precomputed-alias-bypass", 1280, True)):
                    context = browser.new_context(viewport=dict(width=width, height=900), service_workers="block")
                    page = context.new_page()
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))

                    def route_guard(route):
                        if route.request.url.startswith(origin + "/") and "/api/" not in urlsplit(route.request.url).path:
                            route.continue_()
                        else:
                            report["external_or_api_requests"].append(route.request.url)
                            route.abort()

                    context.route("**/*", route_guard)
                    page.set_default_timeout(90000)
                    page.goto(origin + prefix + ("__alias_probe" if injected else "__probe"), wait_until="domcontentloaded")
                    page.evaluate("() => PublicReplay.ready")
                    served = page.request.get(origin + prefix + "runtime/public-runtime.js")
                    assert sha(served.body()) == report["runtime_sha256"]
                    result = page.evaluate("""async fixture => {
                      const binding=fixture.bindings.cib;
                      const defaults={corpus:'cib',graph_id:binding.graph_run_id,hierarchy_id:binding.hierarchy_run_id,limit:'64'};
                      async function fetchSlot(selectors={},changes={}){
                        const url='/api/current/slots-v1?'+new URLSearchParams({...defaults,...selectors,...changes});
                        const response=await PublicReplay.fetch(url);
                        return {http:response.status,value:await response.json()};
                      }
                      const search=await fetchSlot({q:fixture.query});
                      if(search.http!==200)throw Error(JSON.stringify(search));
                      if(search.value.version!=='current-opaque-source-slots/2'||search.value.context_policy!=='source-visible-slot-context/1')throw Error('Wrong slot contract');
                      const found=search.value.slots.find(s=>s.id===fixture.expected.id);
                      if(!found||found.label!==fixture.expected.label)throw Error('Following source mask was not found');
                      if(search.value.slots.some(s=>s.anchors.some(a=>a.label.toLowerCase()==='the')))throw Error('Old The links survived');
                      const detail=await fetchSlot({slot_id:found.id});
                      if(detail.http!==200)throw Error(JSON.stringify(detail));
                      const slot=detail.value.slot,source=detail.value.page,text=Array.from(source.text);
                      for(const key of ['id','slot_id','ordinal','marker_start','marker_end','page_provenance'])
                        if(JSON.stringify(slot[key])!==JSON.stringify(fixture.expected[key]))throw Error('Immutable slot field changed: '+key);
                      if(text.slice(slot.marker_start,slot.marker_end).join('')!=='[REDACTED]')throw Error('Wrong source marker');
                      for(const anchor of slot.anchors){
                        const proof=anchor.visible_proof;
                        if(text.slice(proof.start,proof.end).join('')!==proof.text)throw Error('Incorrect anchor proof');
                      }
                      for(const edge of slot.context_links)
                        if(edge.weight!==0||edge.layout_weight!==0||edge.semantic!==false||edge.eligible_evidence!==false||edge.slot_navigation!==true)throw Error('Semantic slot edge');
                      const literal=await fetchSlot({q:slot.label});
                      if(literal.http!==200||!literal.value.slots.some(s=>s.id===slot.id))throw Error('Source-derived display label is not searchable');
                      const generic=await fetchSlot({q:'Redacted Slot',limit:'2'});
                      if(generic.value.matched_count!==28201||generic.value.slots.length!==2||generic.value.next_offset!==2)throw Error('Generic search/pagination mismatch');
                      const next=await fetchSlot({q:'Redacted Slot',limit:'2',offset:'2'});
                      if(next.value.slots.some(s=>generic.value.slots.some(t=>s.id===t.id)))throw Error('Pagination repeated records');
                      const anchor=slot.anchors.find(a=>a.community_id)||slot.anchors[0];
                      const reverse=await fetchSlot({anchor_id:anchor.id,q:slot.id});
                      if(reverse.http!==200||reverse.value.matched_count!==1||reverse.value.slots[0].id!==slot.id)throw Error('Reverse anchor lookup failed');
                      for(const id of fixture.staleAnchors){
                        const removed=await fetchSlot({anchor_id:id});
                        if(removed.http!==200||removed.value.matched_count!==0)throw Error('Old The reverse links survived');
                      }
                      const hidden=await fetchSlot({q:'CONCEALED_SENTINEL'});
                      if(hidden.value.matched_count!==0)throw Error('Concealed label became searchable');
                      const negatives=[];
                      for(const change of [{graph_id:'wrong'},{hierarchy_id:'wrong'},{limit:'65'},{scan:'2'},{slot_id:'missing'}]){
                        const bad=await fetchSlot({},change);if(bad.http!==404)throw Error('Invalid selector accepted');negatives.push(bad.value.code);
                      }
                      const empty=[];
                      for(const corpus of ['iran','vietnam']){
                        const b=fixture.bindings[corpus];
                        const v=await fetchSlot({corpus,graph_id:b.graph_run_id,hierarchy_id:b.hierarchy_run_id,q:'Redacted Slot'});
                        if(v.http!==200||v.value.matched_count!==0||v.value.coverage.total_slots!==0)throw Error('Empty corpus invented masks');
                        empty.push(corpus);
                      }
                      return {query_matches:search.value.matched_count,slot_id:slot.id,label:slot.label,anchor_ids:slot.anchors.map(a=>a.id),
                        source_text_sha256:source.text_sha256,transport_text_sha256:source.transport_text_sha256,
                        reciprocal_anchor_id:anchor.id,rejected_selectors:negatives,empty_corpora:empty,
                        has_saved:PublicReplay.hasSaved('/api/current/slots-v1?'+new URLSearchParams(defaults))};
                    }""", dict(bindings=bindings, query=query, expected=expected, staleAnchors=stale_anchors))
                    assert not errors, errors
                    assert result["has_saved"] is True
                    report["cells"].append(dict(name=name, pass_=True, **result))
                    context.close()
                    print("PASS", name, flush=True)
            finally:
                browser.close()
        assert not report["external_or_api_requests"]
        assert not any("__stale-slot-alias.json" in path for path in requests)
        report["requests"] = len(requests)
        report["stale_alias_fetched"] = False
        report["pass_"] = True
        return report
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
        output.write_bytes(encoded(report))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, default=HERE.parent / "stage/site")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.site, args.output)
    print(json.dumps(result, indent=2))
