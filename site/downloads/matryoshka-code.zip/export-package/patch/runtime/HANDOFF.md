# Slot Runtime Integration Handoff

Complete. This supersedes the source-only phase's integration instructions in
`slots/HANDOFF.md`. No further API-index change is planned or needed here.

## Pins For Main

Staged `data/api-index.json` SHA256:
`67e1901e204a5a0d6f3ad06f28bf60caeaa905882c84ac4b27013563c6468c3e`

Staged `runtime/public-runtime.js` SHA256:
`e107facfb384bb460e37d0415f49fa4251cce7ae9a5bfef9d5a329aca25bcb36`

Main rebound the HTML hooks separately after the merge. This owner did not edit
HTML, UI JS/CSS, guides, release seals, ordinary reports, installed repositories,
or native artifacts. Contract remains `current-opaque-source-slots/2`, with
additive `source-visible-slot-context/1` policy metadata.

## Staged Changes

- Merged exactly 224 verified sparse routes: 221 CIB record shards and three
  corpus catalogs. New physical packets are under `data/slot-context-patch/`.
  Total new wire bytes: 29,416,435. No source-page packets were rewritten.
- All 51,877 non-slot route bindings, including all 16,133 saved slot source-page
  bindings, are byte-for-byte identical as index objects. All other graph roots,
  aliases, reports and dataset bindings are untouched. No dataset file was read,
  copied or rehashed by integration or its transport tests.
- Runtime changes are generated from the exact original slot block in
  `deploy/slot-runtime.js`, replacing that block and the slot-dispatch branch
  only. The composition is idempotent and rejects ambiguous/changed seams.
- Literal `Redacted Slot` search, source context, source-guarded display labels,
  pagination and cached reciprocal anchor lookup use the rebuilt thin catalog.
  Arbitrary label-only hidden words are never added to search. A display label
  must have the policy/form and every non-generic word in visible context.
- The builder removes every precomputed `/api/current/slots-v1` alias it sees;
  there were zero in the real input. Runtime dispatch also ALWAYS derives every
  slot API response from the current verified catalog, even if an old exact
  alias is reintroduced later. No stale precomputed The-anchor response wins.
- Hydration checks thin/detail agreement, zero-weight nonsemantic links, exact
  marker/source provenance, source text SHA256 and visible proof spans. Source
  offsets use Unicode code points, matching Python's saved offsets.
- Future `deploy/static_slots.py` exports retain thin `label` and `context_policy`.
  They must use the updated slot backend, including `slot_context.py`; no older
  backend or older slot snapshot is a substitute.

## Files And Reproduction

`integration-v1/integration.json` contains the exact 224 staged packet routes,
physical paths, byte lengths and hashes. `new-files.json` separates staged new
files from modified files and supporting code/receipts. `exact-files.json` pins
all integration-owned files, excluding itself. Before-index/runtime bytes are
retained under `integration-v1/`; they are audit inputs, not publication files.

Reusable builder (new receipt directory required):

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python src-demo-day/phase/kg_patch_20261122/runtime/integrate_slots.py --output src-demo-day/phase/kg_patch_20261122/runtime/NEW_RECEIPT
```

Do not rerun solely to rebind HTML; the current index is already stable. If a
future integration changes its bytes, announce the new SHA to main before main
rebounds hooks. The builder checks current index/runtime bytes before writing,
preserves non-slot roots, verifies each sparse wire/decoded hash and stops below
3 GiB free. Final free space exceeded 5 GiB.

## Tests

- `pytest.xml`: 47 passed. Includes source-only slot tests, map transport,
  composition/idempotence/seam rejection, alias removal, preserved actual staged
  roots/pages, all new packet hashes and exporter thin-label retention.
- `test_selector.cjs`: passed against the actual staged runtime. Includes valid
  source-derived labels, generic names, reverse lookup, removed The selectors,
  pins/pagination, concealed sentinel labels with and without a valid policy,
  and unconditional API-alias bypass.
- `qa-renderer-selector.json`: all five existing QA checks passed unchanged,
  including `real_static_slot_selector_rejects_label_only_hidden_search`.
  QA's extraction contract and hidden-label guard were not weakened.
- `browser-v1.json`: three managed Chromium headless-shell cells passed using
  the actual staged runtime and packets: desktop, mobile and a deliberately
  injected obsolete exact API alias. The obsolete response was never fetched.
  Real data checks cover full visible phrase/label/generic searches, markers,
  source proofs, reverse lookup, old The identity, zero weights, invalid selectors
  and the zero-marker Iran/Vietnam catalogs. No external/backend API requests.
- `preview-v2.json`: actual rebound preview at
  `http://127.0.0.1:8971/matryoshka-demo/`, desktop and mobile, passed. Uses a real
  existing HTML hook without modifying HTML and verifies the served runtime,
  index pin, requested following mask, exact source text SHA/proofs, six reverse
  anchors, zero weights, label search, hidden sentinel and removed The identity.
  `preview-v1.json` is the retained failed attempt with the wrong root base URL;
  the server requires the project prefix. It made no API or dataset requests.

Commands from workspace root:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src-demo-day .venv/bin/python -m pytest -q -p no:cacheprovider src-demo-day/phase/kg_patch_20261122/runtime/test_integration.py src-demo-day/tests/test_current_slot_context_patch.py src-demo-day/tests/test_current_map_transport.py
node src-demo-day/phase/kg_patch_20261122/runtime/test_selector.cjs
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python src-demo-day/phase/kg_patch_20261122/runtime/preview_slots.py --preview http://127.0.0.1:8971/matryoshka-demo/ --output src-demo-day/phase/kg_patch_20261122/runtime/NEW_PREVIEW_REPORT.json
```

The requested following-mask identity remains
`opaque_slot_b771169aa36650e0e648f95b`, labeled
`Redacted Slot / near Israeli Foreign Minister`. Its original IDs, marker
offsets, normalized/transport page hashes and provenance are unchanged. All
28,201 source-only slots and their proof spans were independently validated in
the prior source-only receipt; the integrated gzip files are those exact bytes.
