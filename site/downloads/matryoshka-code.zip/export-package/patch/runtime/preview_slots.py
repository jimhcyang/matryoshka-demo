"""Verify source-only slots through main's existing rebound loopback preview."""
import argparse
import json
from pathlib import Path
from urllib.parse import urljoin, urlsplit

from playwright.sync_api import sync_playwright

from integrate_slots import HERE, encoded, guard, sha


def run(preview, output):
    parts = urlsplit(preview)
    if parts.scheme != "http" or parts.hostname not in {"127.0.0.1", "localhost", "::1"} or parts.query or parts.fragment:
        raise ValueError("Only a clean, explicit loopback preview is allowed")
    guard(output.parent)
    preview = preview.rstrip("/") + "/"
    origin = parts.scheme + "://" + parts.netloc
    site = HERE.parent / "stage/site"
    integration = json.loads((HERE / "integration-v1/integration.json").read_bytes())
    verification = json.loads((HERE.parent / "slots/rebuilt-verified/verification.json").read_bytes())
    stale = json.loads((HERE / "browser-v1.json").read_bytes())["stale_the_anchor_ids"]
    target = next(row for row in verification["query_matches"] if row["phrase_immediately_before_mask"])
    report = dict(preview=preview, passed=False, managed_chromium_headless_shell=True,
        persistent_html_edits=False, external_or_api_requests=[], cells=[])
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        try:
            for viewport in (dict(width=1280, height=900), dict(width=390, height=844)):
                context = browser.new_context(viewport=viewport, service_workers="block")
                page = context.new_page()
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))

                def route_guard(route):
                    if route.request.url.startswith(origin + "/") and "/api/" not in urlsplit(route.request.url).path:
                        route.continue_()
                    else:
                        report["external_or_api_requests"].append(route.request.url)
                        route.abort()

                context.route("**/*", route_guard)
                page.set_default_timeout(90000)
                # No corpus selector: this real page loads no saved case/report or graph.
                page.goto(urljoin(preview, "corpus-tour.html"), wait_until="domcontentloaded")
                page.evaluate("() => PublicReplay.ready")
                hook = page.locator('script[src="runtime/public-runtime.js"]').get_attribute("data-index-sha256")
                assert hook == integration["index_sha256"] == sha((site / "data/api-index.json").read_bytes())
                served = page.request.get(urljoin(preview, "runtime/public-runtime.js"))
                assert sha(served.body()) == integration["runtime_sha256"]
                result = page.evaluate("""async fixture => {
                  const binding=await (await fetch('/api/graph-v4-viewer?corpus=cib')).json();
                  const pins={corpus:'cib',graph_id:binding.graph_run_id,hierarchy_id:binding.hierarchy_run_id,limit:'64'};
                  async function request(selectors){
                    const response=await fetch('/api/current/slots-v1?'+new URLSearchParams({...pins,...selectors}));
                    const value=await response.json();if(!response.ok)throw Error(JSON.stringify(value));return value;
                  }
                  const search=await request({q:fixture.query});
                  if(!search.slots.some(s=>s.id===fixture.target.id))throw Error('Following mask absent');
                  const detail=await request({slot_id:fixture.target.id}),slot=detail.slot,page=detail.page,text=Array.from(page.text);
                  if(slot.label!==fixture.target.label||text.slice(slot.marker_start,slot.marker_end).join('')!=='[REDACTED]')throw Error('Wrong source slot');
                  if(detail.version!=='current-opaque-source-slots/2'||detail.source_view!=='current_earlier'||detail.hidden_values_read!==false||detail.semantic_graph_modified!==false)throw Error('Source-only contract changed');
                  for(const proof of [...slot.anchors.map(a=>a.visible_proof),slot.label_context].filter(Boolean)){
                    if(text.slice(proof.start,proof.end).join('')!==proof.text||proof.release!=='earlier'||proof.identity_certified!==false||proof.semantic!==false)throw Error('Visible proof mismatch');
                  }
                  for(const anchor of slot.anchors){
                    if(anchor.label.toLowerCase()==='the')throw Error('Vacuous The anchor');
                    const back=await request({anchor_id:anchor.id,q:slot.id});
                    if(back.matched_count!==1||back.slots[0].id!==slot.id)throw Error('Missing reciprocal anchor');
                  }
                  for(const id of fixture.stale){if((await request({anchor_id:id})).matched_count!==0)throw Error('Stale The reverse anchors');}
                  if((await request({q:'CONCEALED_SENTINEL'})).matched_count!==0)throw Error('Hidden label search');
                  if(!(await request({q:slot.label})).slots.some(s=>s.id===slot.id))throw Error('Literal label search');
                  if(slot.context_links.some(e=>e.weight!==0||e.layout_weight!==0||e.semantic!==false||e.eligible_evidence!==false))throw Error('Semantic link introduced');
                  const rawHash=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(page.text)))].map(n=>n.toString(16).padStart(2,'0')).join('');
                  if(rawHash!==page.text_sha256||rawHash!==slot.page_provenance.text_sha256)throw Error('Source text SHA mismatch');
                  return {slot_id:slot.id,label:slot.label,query_matches:search.matched_count,source_text_sha256:rawHash,
                    transport_text_sha256:page.transport_text_sha256,anchors:slot.anchors.map(a=>a.label),reciprocal_links:slot.anchors.length};
                }""", dict(query=verification["query"], target=target, stale=stale))
                assert not errors, errors
                report["cells"].append(dict(viewport=viewport, passed=True, index_sha256=hook, **result))
                context.close()
                print("PASS actual preview", viewport["width"], flush=True)
        finally:
            browser.close()
            output.write_bytes(encoded(report))
    assert not report["external_or_api_requests"]
    report["passed"] = True
    output.write_bytes(encoded(report))
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", required=True)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.preview, args.output), indent=2))
