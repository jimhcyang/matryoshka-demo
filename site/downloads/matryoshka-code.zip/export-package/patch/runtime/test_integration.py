"""Slot-only composition and source/root preservation, no corpus execution."""
from copy import deepcopy
import ast
import json
from pathlib import Path

import pytest

from integrate_slots import (DEPLOY, HERE, NEW_BRANCH, OLD_BRANCH, compose_runtime,
                             encoded, merge_index, sha)


def entry(name="a", **kwargs):
    return dict(path="data/" + name + ".json.gz", encoding="gzip", mime="application/json",
                sha256="1" * 64, wire_sha256="2" * 64, **kwargs)


def sparse():
    return dict(version="slot-context-sparse-overlay/1", entries={
        "/data/slots/cib/records-0.json": dict(entry(), path="packets/" + "2" * 64 + ".json.gz")})


def test_exact_runtime_composition_is_repeatable_and_changes_only_slot_block_and_dispatch():
    original = (DEPLOY / "slot-runtime.js").read_bytes()
    replacement = (HERE / "slot-runtime.js").read_bytes()
    raw = b"UNCHANGED PREFIX\n" + original + OLD_BRANCH.encode() + b"\nUNCHANGED SUFFIX"
    result = compose_runtime(raw)
    assert result == b"UNCHANGED PREFIX\n" + replacement + NEW_BRANCH.encode() + b"\nUNCHANGED SUFFIX"
    assert compose_runtime(result) == result


@pytest.mark.parametrize("mutation", ["missing", "duplicate", "dispatch"])
def test_composition_rejects_unknown_or_ambiguous_seams(mutation):
    original = (DEPLOY / "slot-runtime.js").read_bytes()
    raw = original + OLD_BRANCH.encode()
    if mutation == "missing":
        raw = raw.replace(original, b"unknown")
    if mutation == "duplicate":
        raw += original
    if mutation == "dispatch":
        raw = raw.replace(OLD_BRANCH.encode(), b"unknown")
    with pytest.raises(ValueError):
        compose_runtime(raw)


def test_merge_removes_all_slot_api_aliases_but_preserves_every_other_root_and_source_page():
    roots = {"/graph-assets-v4/cib/source.json": entry("source"),
             "/api/current/report-v6": entry("report"),
             "/data/slots/cib/" + "a" * 64 + ".json": entry("page"),
             "/data/slots/cib/records-0.json": entry("record"),
             "/data/slots/cib/records-99.json": entry("orphan_unchanged"),
             "/api/current/slots-v1?corpus=cib&q=The": entry("obsolete"),
             "/api/current/slots-v1": entry("obsolete_default")}
    source = dict(version="matryoshka-public-api-index/1", entries=roots)
    before = deepcopy(source)
    result, removed = merge_index(source, sparse())
    assert source == before
    assert len(removed) == 2
    assert all(not key.startswith("/api/current/slots-v1") for key in result["entries"])
    assert result["entries"]["/data/slots/cib/records-0.json"]["path"].startswith("data/slot-context-patch/")
    assert all(result["entries"][key] == value for key, value in roots.items()
               if not key.startswith("/api/current/slots-v1") and key not in sparse()["entries"])
    assert merge_index(result, sparse())[0] == result


@pytest.mark.parametrize("route", ["/api/current/report-v6", "/graph-assets-v4/cib/graph.json",
                                   "/data/slots/cib/" + "a" * 64 + ".json"])
def test_sparse_merge_cannot_replace_reports_graphs_or_saved_source_pages(route):
    patch = sparse()
    value = next(iter(patch["entries"].values()))
    patch["entries"] = {route: value}
    with pytest.raises(ValueError, match="only replace existing slot"):
        merge_index(dict(entries={route: entry()}), patch)


def test_actual_staged_index_and_runtime_match_receipt_and_all_unowned_routes_are_identical():
    output = HERE / "integration-v1"
    if not (output / "integration.json").exists():
        pytest.skip("Run the bounded stage integration first")
    report = json.loads((output / "integration.json").read_bytes())
    before = json.loads((output / "before-api-index.json").read_bytes())
    site = HERE.parent / "stage/site"
    raw = (site / "data/api-index.json").read_bytes()
    current = json.loads(raw)
    overlay = json.loads((HERE.parent / "slots/rebuilt-verified/overlay-index.json").read_bytes())
    assert sha(raw) == report["index_sha256"]
    assert sha((site / "runtime/public-runtime.js").read_bytes()) == report["runtime_sha256"]
    assert (site / "runtime/public-runtime.js").read_bytes() == compose_runtime((output / "before-public-runtime.js").read_bytes())
    expected, removed = merge_index(before, overlay)
    assert current == expected and removed == report["removed_slot_aliases"]
    for path in report["files"]:
        assert sha((site / path["path"]).read_bytes()) == path["sha256"]
    assert report["preserved_source_pages"] == 16133
    assert report["sparse_routes"] == 224 and report["dataset_files_read"] == 0
    assert report["html_hooks_updated"] is False


def test_future_static_exporter_retains_source_label_and_policy_without_hidden_fields():
    module = ast.parse((DEPLOY / "static_slots.py").read_text())
    assignment = next(node for node in ast.walk(module) if isinstance(node, ast.Assign)
                      and any(isinstance(target, ast.Name) and target.id == "thin" for target in node.targets))
    fields = {node.value for node in assignment.value.generators[0].iter.elts}
    assert {"id", "slot_id", "label", "context_policy", "context_preview"} <= fields
    assert not fields & {"hidden_answer", "answer", "candidate", "question", "query"}
