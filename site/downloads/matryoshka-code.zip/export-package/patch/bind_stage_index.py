"""Rebind static replay hooks after the unsealed slot navigation index changes."""
from hashlib import sha256
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
SITE = ROOT / "stage/site"
assert not (SITE / "release-manifest.json").exists(), "Never alter a sealed candidate"
digest = sha256((SITE / "data/api-index.json").read_bytes()).hexdigest()
count = 0
for folder in (SITE, ROOT / "ui"):
    for path in folder.rglob("*.html"):
        text = path.read_text()
        changed, matches = re.subn(r'data-index-sha256="[a-f0-9]{64}"',
                                  f'data-index-sha256="{digest}"', text)
        if matches and changed != text:
            path.write_text(changed)
            count += 1
print(f"INDEX_HOOKS_BOUND {digest} {count}")
