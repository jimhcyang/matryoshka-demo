# Knowledge Graph Patch

## Renderer And Geometry

The reference site uses a custom Canvas 2D renderer in `app.js`, rather than
D3, Cytoscape or a graph-widget dependency. Its view-local radius scaling,
isotropic camera fit and restrained edge treatment are the relevant precedents.

The patch keeps the current source-bound graph and hierarchy. It changes only
drawing geometry and interaction. A node's visual radius is monotone in its
mass relative to the other nodes actually shown at that level. A camera Fit
changes only the camera transform; it does not stretch graph coordinates to
the browser aspect ratio. Collision relaxation runs when a graph is loaded.

Evidence overviews may still be denser than the older demo: they display the
current saved projection, including grounded co-evidence connections. The
patch does not remove real connections, add attractive artificial links, or
recluster the corpus to manufacture the older topology. Inspecting a specific
community or direct neighborhood gives a more focused view.

Neighborhood rings encode hierarchy distance, not hop distance or historical
causation. Other displayed-neighbor connections are enabled by default. Slow
motion changes positions only, preserves ring membership, pauses for node
inspection/dragging and respects reduced-motion preferences. Automatic labels
are restricted to the upper-right quadrant; manual label toggles remain usable
elsewhere. Turning off motion leaves the graph fully inspectable.

## Source-Visible Redacted Slots

The slot contract remains `current-opaque-source-slots/2`; technical IDs retain
their original names for link compatibility. Human-facing names are Redacted
Slot plus a brief literal visible-source anchor. Navigation links require exact
substantive visible terms. Function words, incomplete title fragments and
ambiguous clipped names cannot create links. These links have zero semantic
and layout weight and do not assert the identity hidden by a mask.

All 28,201 CIB slot identities, marker coordinates and source-page hashes are
preserved. Iran and Vietnam have no observed markers in their current bound
exports; the interface does not manufacture synthetic corpus-wide slots.

## Paired Views And Dates

Toolbar actions and search navigation apply to both visible projections. A
direct click/drag inside one graph acts only on that graph. A later-only node
must not be inserted into the earlier semantic projection to make the panels
look symmetric. Display caps default to 32 at hierarchy levels and 256 at the
evidence level. Valid dates outside the corpus range clamp to the nearest
endpoint; malformed dates remain invalid rather than silently changing scope.

## Swedish Study

Both nationality masks are separate queries behind equal First/Second tabs.
The saved S2 scope is the default and no acknowledgment gate blocks its
display. S2 admits later-release prior documents and the exact dated origin;
that exception does not apply to ordinary cases. The withheld words remain
unknown, so a Swedish nomination is not a verified recovery.

Two fresh, explicitly scoped executions now use the shared retrieval kernel
and narrative construction/decision functions. Their versioned source adapter
admits the declared S2 view without modifying ordinary source guards. They are
not relabeled canonical historical native runs. Query-only planning and model
readings are saved separately from local retrieval and execution.

Two general construction fixes are confined to this study implementation:
supplemental page selection no longer suppresses a strong page simply because
another page of its document was already selected; case/whitespace-identical
fills are grouped before the five-item cap without pooling their support
decisions. The final source adapter requires producer-declared job-local
coordinates, a valid complete source window and literal quotation replay.
It never rescues a bad declaration by finding the same words elsewhere on the
page. Earlier-page coordinates are admitted into the later view only when the
entire earlier and later page texts are verified identical.

Adversarial testing exposed a global-first occurrence bug in the first two
study attempts. Their executed bytes remain archived, not certified by the
final tests. Both queries were rerun locally under the separately pinned third
adapter using the exact cached plans and readings. No new API call, altered
date/visibility metadata or ordinary-case source exception was introduced.

Both final runs inspect the origin page. Neither nominates Swedish: the source
word Swedes fails the current literal adjective realization. No country-specific
conversion, identity dictionary or named ranking bonus was added. The earlier
lexical study and its Swedish nomination remain a separately labeled archive,
not a replacement for the fresh results. Their reference answers remain unknown.
The existing fourteen ordinary case outputs and source policies are unchanged.

## Release Checks

Before publication: verify all slot records and proofs; compare ordinary native
roots and graph routes with the previous release; check managed-browser desktop
and mobile geometry, pair synchronization, date clamping and label interaction;
create a fresh release inventory and authorization; then verify the deployed
website. Earlier failed attempts and the previous published release remain
available for diagnosis.
