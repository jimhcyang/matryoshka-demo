"""Freeze, prepare, then seal a bounded KG patch. Never authorize publication."""
import argparse
import gzip
import io
from pathlib import Path
import re

import code_snapshot
from release_common import (DEPLOY, HERE, INSTALLED, MAX_SITE, PATCH, SOURCE, WORKSPACE,
                            at, encoded, gate_module, load, pinned, public_json,
                            put_json, read, relative, require, sha, space, within, write)

SWEDISH_PIN = '5f89de6716af649b145604f45c1db02e60647f8cb847e7ae89e36d4114d137b8'
SLOTS_PIN = 'f612f7678093c5dfacd23d762de39ef95c7cd8a41bb0e3f5217376bcb6a11d0b'
RUNTIME_PIN = '615291e743bcf7b79d077f2f8b84ae2fc189f442bc4694757e0a8d079d78aecc'
UI = {'graph-full-v6.js', 'graph-full-v6.html', 'graph-full-v6.css',
      'swedish-study.js', 'swedish-study.html', 'swedish-study.css',
      'workbench-v6.js', 'workbench-v6.html', 'runtime/public-runtime.js', 'slot-runtime.js'}
SLOT_ROUTE = re.compile(r'/data/slots/(?:cib|iran|vietnam)(?:/records-\d+)?\.json')
CONTEXT = {'label', 'label_context', 'context_policy', 'context_preview', 'anchors',
           'context_links', 'hierarchy_placement', 'domain_id', 'theme_id', 'community_id'}
POLICY = 'source-visible-slot-context/1'


def decode_packet(raw, limit):
    with gzip.GzipFile(fileobj=io.BytesIO(raw)) as stream:
        decoded = stream.read(limit + 1)
    require(len(decoded) <= limit, 'Decoded packet exceeds its bounded limit')
    return decoded


def without_index_hooks(raw):
    return re.sub(rb'(data-index-sha256=[\"\'])[a-f0-9]{64}([\"\'])', rb'\1INDEX_PIN\2', raw)


def inventory(site, gate):
    space(HERE)
    for path in site.rglob('*'):
        require(not path.is_symlink(), 'Symlink in site')
        require(path.name != 'release-manifest.json' or path.parent == site, 'Uninventoried nested manifest')
    rows = gate.inventory(site)
    require(sum(r['bytes'] for r in rows) < MAX_SITE, 'Site exceeds 900 MB')
    require(all(r['bytes'] < 100_000_000 for r in rows), 'Site asset exceeds 100 MB')
    return rows


def input_files():
    paths = set()
    for root in (DEPLOY, PATCH, HERE):
        paths.update(p for p in root.glob('*') if p.is_file() and p.suffix in
                     {'.py', '.js', '.md', '.txt', '.pdf', '.json'})
    for root, suffixes in ((DEPLOY / 'ci', {'.py', '.yml'}),
                           (PATCH / 'ui', {'.js', '.css', '.html'}),
                           (HERE / 'ci', {'.py'}),
                           (INSTALLED / 'tools', {'.py'}),
                           (INSTALLED / 'release-tools', {'.py'}),
                           (INSTALLED / 'runtime', {'.py', '.js', '.html', '.md', '.txt'})):
        paths.update(p for p in root.rglob('*') if p.is_file() and p.suffix in suffixes
                     and '__pycache__' not in p.parts)
    for directory in ('slots', 'swedish', 'qa', 'runtime'):
        paths.update(p for p in (PATCH / directory).glob('*') if p.is_file()
                     and p.suffix in {'.py', '.js', '.cjs', '.md'})
    paths.update((INSTALLED / 'tests').glob('*.py'))
    paths.update(INSTALLED / p for p in ('.github/workflows/pages.yml', 'requirements-dev.txt'))
    paths.update(PATCH / p for p in ('runtime/exact-files.json', 'runtime/integration-v1/integration.json'))
    paths.update(SOURCE / p for p in ('matryoshka_current/slot_overlay.py', 'matryoshka_current/slot_context.py',
                                    'tests/test_navigation_publication_cache.py', 'tests/test_current_slot_context_patch.py'))
    return [dict(path=p.relative_to(WORKSPACE).as_posix(), sha256=sha(read(within(WORKSPACE, p))))
            for p in sorted(paths)]


def handoffs(swedish_path, swedish_pin, slots_pin):
    sw_path = within(PATCH / 'swedish', swedish_path)
    sw_path, raw = pinned(SOURCE, dict(path=sw_path.relative_to(SOURCE).as_posix(), sha256=swedish_pin))
    swedish = public_json(raw)
    require(swedish['version'] in ('swedish-patch-integration-handoff/1', 'swedish-patch-integration-handoff/2'),
            'Unknown Swedish integration format')
    require(swedish['native_execution'] is False and swedish['native_completions_created'] == 0
            and swedish['default_policy'] == 'S2', 'This helper only supports the declared non-native Swedish fallback')
    _, test_receipt = pinned(SOURCE, swedish['tests']['receipt'])
    if swedish.get('source_policy_feasibility_ref'):
        pinned(SOURCE, swedish['source_policy_feasibility_ref'])
    copies = {}
    for row in swedish['copies']:
        name = relative(row['destination'])
        require('/' not in name and name not in copies, 'Unsafe or duplicate Swedish destination')
        path, data = pinned(SOURCE, row['source'])
        require(path.is_relative_to(PATCH / 'ui') or path.is_relative_to(PATCH / 'swedish'), 'Foreign Swedish source')
        copies[name] = data
    required = {'swedish-study.html', 'swedish-study.css', 'swedish-study.js'}
    require(required <= set(copies) and all(name in required | {'workbench-v6.js'} or
            re.fullmatch(r'(?:swedish-(?:study-patch|first|second|first-completion|second-completion)|native-preflight|s2-seam-feasibility)-v\d+\.json', name)
            for name in copies), 'Unexpected Swedish copy set')
    for name, data in copies.items():
        if name.endswith('.json'):
            public_json(data)
    study_names = [name for name in copies if re.fullmatch(r'swedish-study-patch-v\d+\.json', name)]
    require(len(study_names) == 1, 'Need exactly one pinned Swedish study manifest')
    study = load(copies[study_names[0]])
    require(study['gold'] is None and study['native_execution'] is False
            and study['default_policy'] == 'S2', 'Swedish gold/native policy changed')
    for row in study['cases'] + study['display_completions']:
        data = copies[row['path']]
        require(sha(data) == row['sha256'], 'Swedish internal pin mismatch')
        value = load(data)
        require(value['gold'] is None and value['native_execution'] is False
                and value['native_run_ref'] is None, 'Swedish fallback mislabeled native or known gold')
    _, slots_raw = pinned(WORKSPACE, dict(path='src-demo-day/phase/kg_patch_20261122/slots/exact-files.json', sha256=slots_pin))
    slots = public_json(slots_raw)
    require(slots['version'] == 'slot-context-exact-files/1' and slots['context_policy'] == POLICY,
            'Unknown slot handoff')
    pins = {}
    for row in slots['files']:
        require(row['path'] not in pins, 'Duplicate slot pin')
        # Only small code/overlay artifacts; never datasets or comparison/native roots.
        require(row['path'].startswith(('src-demo-day/phase/kg_patch_20261122/slots/',
                'src-demo-day/matryoshka_current/', 'src-demo-day/tests/')), 'Foreign slot input')
        _, data = pinned(WORKSPACE, row)
        require(len(data) == row['bytes'], 'Slot byte count mismatch')
        pins[row['path']] = row['sha256']
    overlay_path = at(WORKSPACE, slots['authoritative_overlay'])
    require(overlay_path.is_relative_to(PATCH / 'slots'), 'Foreign slot overlay')
    require(sha(read(overlay_path)) == pins[slots['authoritative_overlay']], 'Unpinned overlay')
    overlay = load(read(overlay_path))
    require(overlay['version'] == 'slot-context-sparse-overlay/1', 'Not a sparse slot overlay')
    require(overlay['entries'] and all(SLOT_ROUTE.fullmatch(k) for k in overlay['entries']), 'Non-slot overlay route')
    verification_path = overlay_path.parent / 'verification.json'
    require(sha(read(verification_path)) == pins[verification_path.relative_to(WORKSPACE).as_posix()], 'Unpinned slot verification')
    verification = load(read(verification_path))
    require(verification['verified'] is True and verification['immutable_field_changes'] == 0
            and verification['rejected_anchor_labels'] == 0, 'Slot verification failed')
    packets = {}
    for route, entry in overlay['entries'].items():
        require(entry['encoding'] == 'gzip' and entry['mime'] == 'application/json'
                and not entry.get('external_url'), 'Unexpected overlay transport')
        path = at(overlay_path.parent, entry['path'])
        raw = read(path)
        require(sha(raw) == entry['wire_sha256'] == pins[path.relative_to(WORKSPACE).as_posix()], 'Slot wire pin mismatch')
        decoded = decode_packet(raw, 20_000_000 if '/records-' in route else 100_000_000)
        require(sha(decoded) == entry['sha256'], 'Slot decoded pin mismatch')
        packets[route] = (entry, raw, public_json(decoded))
    return swedish, copies, pins, packets, dict(swedish_integration_path=sw_path.relative_to(PATCH).as_posix(),
                                              swedish_integration_sha256=sha(read(sw_path)),
                                              swedish_test_receipt_sha256=sha(test_receipt),
                                              slots_exact_files_sha256=sha(slots_raw),
                                              slot_verification_sha256=sha(read(verification_path)))


def baseline(gate):
    base = public_json(read(PATCH / 'baseline.json'))
    site = at(WORKSPACE, base['source'])
    raw = read(site / 'release-manifest.json')
    require(sha(raw) == base['manifest_sha256'], 'Installed baseline seal changed; retain the pinned old baseline')
    manifest = public_json(raw)
    require(manifest['source_report_ref']['sha256'] == base['source_report_sha256'], 'Baseline report mismatch')
    entries_raw = read(at(site, manifest['api_index']['path']))
    require(sha(entries_raw) == manifest['api_index']['sha256'], 'Baseline index bytes changed')
    return site, manifest, load(entries_raw), base


def unchanged_routes(original, current, allowed):
    require(set(original) == set(current), 'Logical routes added or removed')
    require(all(original[k] == current[k] for k in original if k not in allowed),
            'Ordinary/native/graph/page route changed')


def staged_preflight(stage, packets):
    """Check the already-integrated runtime/index, not all native packet contents."""
    site = stage / 'site'
    _, original, old_index, base = baseline(None)
    index_raw = read(site / 'data/api-index.json')
    current = load(index_raw)['entries']
    unchanged_routes(old_index['entries'], current, packets)
    changed = {key for key in current if current[key] != old_index['entries'][key]}
    require(changed == set(packets), 'Staged index is not exactly the verified slot delta')
    for key, (entry, wire, _) in packets.items():
        staged = current[key]
        require(all(staged.get(k) == entry[k] for k in ('encoding', 'mime', 'sha256', 'wire_sha256')),
                'Staged slot entry differs from the authoritative overlay')
        require(read(at(site, staged['path'])) == wire, 'Staged slot packet differs from the authoritative wire')
    require(sha(read(site / 'data/report-v6.json')) == base['source_report_sha256'], 'Staged ordinary report changed')
    _, raw = pinned(PATCH, dict(path='runtime/exact-files.json', sha256=RUNTIME_PIN))
    runtime = public_json(raw)
    require(runtime['version'] == 'slot-runtime-integration-exact-files/1'
            and runtime['index_sha256'] == sha(index_raw), 'Runtime integration index pin changed')
    for ref in runtime['files']:
        _, data = pinned(WORKSPACE, ref)
        require(len(data) == ref['bytes'], 'Runtime integration byte count changed')
    return dict(status='PASS_READ_ONLY_STAGED_DELTA', index_sha256=sha(index_raw),
        slot_routes_changed=len(changed), non_slot_route_bindings_unchanged=len(current) - len(changed),
        source_report_sha256=base['source_report_sha256'], runtime_manifest_sha256=sha(raw),
        native_route_bindings_unchanged=True, native_packets_reconstructed=False,
        dataset_files_read=0, dataset_files_rehashed=0, publish_authorized=False)


def check_slots(packets, old_catalogs):
    for corpus in ('cib', 'iran', 'vietnam'):
        route = '/data/slots/' + corpus + '.json'
        catalog = packets[route][2]
        old = old_catalogs[corpus]
        status = catalog['status']
        require(status['hidden_values_read'] is False and status['semantic_graph_modified'] is False
                and status['context_policy'] == POLICY, 'Slot semantic/source policy changed')
        require(status['coverage'] == old['status']['coverage'] and catalog['details'] == old['details']
                and status['source_audit'] == old['status']['source_audit'], 'Slot source/page census changed')
        for key in ('graph_run_id', 'hierarchy_run_id', 'source_view', 'release'):
            require(status[key] == old['status'][key], 'Slot source binding changed')
        require([s['id'] for s in catalog['slots']] == [s['id'] for s in old['slots']], 'Slot identities changed')
        if corpus != 'cib':
            require(catalog['slots'] == [], 'Invented ordinary slots')
    for route, (_, _, value) in packets.items():
        if '/records-' not in route:
            continue
        require(isinstance(value, list) and len(value) <= 128, 'Unbounded slot record shard')
        for record in value:
            require(record['context_policy'] == POLICY, 'Wrong slot context policy')
            for edge in record['context_links']:
                require(edge['weight'] == edge['layout_weight'] == 0
                        and edge['semantic'] is False and edge['eligible_evidence'] is False
                        and edge['slot_navigation'] is True, 'Slot route became semantic/evidence')


def dataset_metadata(site, original_site, receipt):
    name = 'data/dataset-delivery.json'
    raw = read(site / name)
    require(raw == read(original_site / name) and sha(raw) == receipt['dataset_delivery_ref']['sha256'],
            'Dataset delivery binding changed')
    delivery = public_json(raw)
    for row in delivery['files']:
        path = at(INSTALLED, row['path'])
        require(row['path'].startswith('datasets/') and path.is_file()
                and path.stat().st_size == row['bytes'], 'Dataset file missing or resized')
    return dict(files=len(delivery['files']), hashes_recomputed=False, copied=False,
                scope='UNCHANGED_PINNED_MANIFEST_AND_FILE_TYPE_SIZE_ONLY_NOT_CONTENT_REVALIDATION')


def refresh_hooks(site, digest):
    changes = []
    for path in sorted(site.rglob('*.html')):
        raw = read(path)
        text = raw.decode('utf-8')
        if 'data-index-sha256=' not in text:
            continue
        updated, count = re.subn(r'(data-index-sha256=[\"\'])[a-f0-9]{64}([\"\'])',
                                 lambda match: match[1] + digest + match[2], text)
        require(count > 0, 'Malformed HTML index hook')
        if updated != text:
            write(path, updated.encode('utf-8'))
        changes.append(dict(path=path.relative_to(site).as_posix(), sha256=sha(updated.encode('utf-8'))))
    require(changes, 'No HTML runtime index hooks found')
    return changes


def freeze(stage, work, gate, swedish_path, swedish_pin, slots_pin):
    require(not work.exists(), 'Use a new work directory for every freeze/attempt')
    require(not (stage / 'site/release-manifest.json').exists(), 'Stage is sealed')
    _, _, _, _, refs = handoffs(swedish_path, swedish_pin, slots_pin)
    _, _, _, base = baseline(gate)
    value = dict(version='kg-patch-frozen-inputs/1', stable_ui_and_data_declared_by_main=True,
        stage=stage.relative_to(PATCH).as_posix(), baseline=base, handoffs=refs,
        source_files=input_files(), stage_receipt_sha256=sha(read(stage / 'stage_receipt.json')),
        site_inventory_sha256=sha(encoded(inventory(stage / 'site', gate))))
    put_json(at(work, 'freeze.json'), value)
    return dict(frozen_inputs_sha256=sha(encoded(value)), publish_authorized=False)


def check_freeze(stage, work, gate):
    frozen = public_json(read(work / 'freeze.json'))
    require(frozen['version'] == 'kg-patch-frozen-inputs/1'
            and frozen['stable_ui_and_data_declared_by_main'] is True
            and frozen['stage'] == stage.relative_to(PATCH).as_posix(), 'Wrong freeze/stage')
    require(input_files() == frozen['source_files'], 'Frozen code/UI inputs changed')
    require(sha(read(stage / 'stage_receipt.json')) == frozen['stage_receipt_sha256'], 'Frozen stage receipt changed')
    require(sha(encoded(inventory(stage / 'site', gate))) == frozen['site_inventory_sha256'], 'Frozen site changed')
    return frozen


def prepare(stage, work, gate):
    site = stage / 'site'
    require(not (site / 'release-manifest.json').exists() and not (work / 'prepare.json').exists(), 'Sealed or already prepared')
    frozen = check_freeze(stage, work, gate)
    refs = frozen['handoffs']
    swedish, copies, slot_pins, packets, refs_now = handoffs(at(PATCH, refs['swedish_integration_path']),
        refs['swedish_integration_sha256'], refs['slots_exact_files_sha256'])
    require(refs == refs_now, 'Handoff changed after freeze')
    original_site, original, old_index, base = baseline(gate)
    require(base == frozen['baseline'], 'Baseline changed after freeze')
    receipt = load(read(stage / 'stage_receipt.json'))
    for key in ('source_report_ref', 'casebook_ref', 'digest_ref', 'field_guide', 'dataset_delivery_ref'):
        require(receipt.get(key) == original.get(key), 'Original reference retargeted: ' + key)
    require(sha(read(site / 'data/report-v6.json')) == base['source_report_sha256'], 'Ordinary report changed')
    index = load(read(site / 'data/api-index.json'))
    unchanged_routes(old_index['entries'], index['entries'], packets)
    for key in packets:
        require(key in old_index['entries'], 'Overlay adds a previously absent slot route')
        require(index['entries'][key] == old_index['entries'][key]
                or index['entries'][key].get('sha256') == packets[key][0]['sha256'], 'Unrecognized staged slot transformation')
    datasets = dataset_metadata(site, original_site, receipt)
    from fragment_reader import Reader
    old_catalogs = {}
    with_reader = Reader(original_site, work / 'baseline-slots.sqlite3')
    try:
        for corpus in ('cib', 'iran', 'vietnam'):
            old_catalogs[corpus] = load(with_reader.read(old_index['entries']['/data/slots/' + corpus + '.json']))
        check_slots(packets, old_catalogs)
        for route, (_, _, rows) in packets.items():
            if '/records-' in route:
                old_rows = load(with_reader.read(old_index['entries'][route]))
                require([{k:v for k,v in r.items() if k not in CONTEXT} for r in rows] ==
                        [{k:v for k,v in r.items() if k not in CONTEXT} for r in old_rows], 'Slot immutable fields changed')
    finally:
        with_reader.close()
    for row in swedish['existing_dependencies']:
        require(sha(read(at(site, row['name']))) == row['sha256'], 'Swedish retained dependency changed')
    addendum_names = {'docs/kg-patch-addendum.pdf', 'docs/kg-patch-addendum.txt'}
    allowed = UI | set(copies) | addendum_names | {'export-lineage.json', 'publication.json', 'data/api-index.json'}
    before_rows = inventory(site, gate)
    before_by_name = {r['path']:r for r in before_rows}
    for row in original['files']:
        if row['path'] not in allowed:
            if before_by_name.get(row['path']) == row:
                continue
            require(row['path'].endswith('.html'), 'Unapproved original asset change: ' + row['path'])
            old_html, new_html = read(at(original_site, row['path'])), read(at(site, row['path']))
            require(sha(old_html) == row['sha256'] and without_index_hooks(old_html) == without_index_hooks(new_html),
                    'Non-index-hook change in original HTML: ' + row['path'])
    known_names = {r['path'] for r in original['files']} | allowed
    slot_assets = {index['entries'][key]['path'] for key in packets}
    require(all(name in known_names or name in slot_assets for name in before_by_name),
            'Unexpected extra staged file; explicitly review it before freeze')
    prior_code = original['code_bundle']
    prior_raw = read(at(original_site, prior_code['path']))
    manifest_raw = read(at(original_site, prior_code['manifest_path']))
    require(sha(prior_raw) == prior_code['sha256'] and sha(manifest_raw) == prior_code['manifest_sha256'], 'Prior code pin mismatch')
    # Build/check the small code snapshot before changing the candidate's site files.
    bundle_raw, bundle_manifest, tree, check = code_snapshot.build(prior_raw, load(manifest_raw), work, slot_pins)
    require(input_files() == frozen['source_files'], 'Source mutated during code packaging')
    require(inventory(site, gate) == before_rows
            and sha(read(stage / 'stage_receipt.json')) == frozen['stage_receipt_sha256'],
            'Stage mutated during code packaging')
    for name in sorted(UI):
        if name.startswith('runtime/') or name == 'slot-runtime.js':
            continue
        path = PATCH / 'ui' / name
        if path.is_file() and name not in copies:
            write(at(site, name), read(path))
    for name, raw in copies.items():
        write(at(site, name), raw)
    for route, (entry, raw, _) in sorted(packets.items()):
        name = 'data/slot-context-patch-v01/' + entry['wire_sha256'] + '.json.gz'
        write(at(site, name), raw)
        index['entries'][route] = dict(entry, path=name)
    unchanged_routes(old_index['entries'], index['entries'], packets)
    index_raw = encoded(index)
    write(site / 'data/api-index.json', index_raw)
    hooks = refresh_hooks(site, sha(index_raw))
    code_ref = dict(path='downloads/matryoshka-code.zip', sha256=sha(bundle_raw), bytes=len(bundle_raw),
        manifest_path='downloads/matryoshka-code-manifest.json', manifest_sha256=sha(bundle_manifest),
        source_backend_tree_sha256=tree, code_only=True)
    write(at(site, code_ref['path']), bundle_raw)
    write(at(site, code_ref['manifest_path']), bundle_manifest)
    addendum = {}
    for name in ('kg-patch-addendum.pdf', 'kg-patch-addendum.txt'):
        raw = read(HERE / name)
        write(at(site, 'docs/' + name), raw)
        addendum[name] = sha(raw)
    transform = dict(version='kg-presentation-slot-context-patch/1', baseline_manifest_sha256=base['manifest_sha256'],
        **refs, source_report_bytes_unchanged=True, ordinary_case_and_native_routes_unchanged=True,
        graph_alias_hierarchy_and_page_routes_unchanged=True, slot_context_policy=POLICY,
        slot_routes=len(packets), slot_links_semantic=False, slot_links_weight=0,
        swedish_default_policy='S2', swedish_acknowledgment_required=False, swedish_gold=None,
        swedish_native_execution=False, new_ordinary_native_executions=0, new_api_calls=0,
        requested_new_native_swedish_s2_completed=False, native_s2_deferral_user_accepted=False,
        dataset_check=datasets, addendum=addendum, html_index_hooks=hooks,
        frozen_inputs_sha256=sha(read(work / 'freeze.json')))
    receipt.pop('backend_root', None)
    receipt.update(backend_code_sha256=tree, code_bundle=code_ref, index_sha256=sha(index_raw),
        routes=len(index['entries']), kg_patch=transform, current_native_execution=False,
        backend_snapshot_canonical=False, native_outputs_modified=False, report_bytes_unchanged=True,
        privacy_approval_inherited=False, publish_authorized=False, release_qualified=False,
        browser_smoke='NOT_RUN_FOR_THIS_PREPARED_CANDIDATE')
    put_json(stage / 'stage_receipt.json', receipt)
    lineage = load(read(site / 'export-lineage.json'))
    lineage.pop('backend_root', None)
    lineage.update(receipt)
    lineage['backend_snapshot'] = dict(tree_sha256=tree, canonical=False,
        scope='Implementation snapshot with slot context patch. Historical native versions unchanged per case.')
    put_json(site / 'export-lineage.json', lineage)
    publication = load(read(site / 'publication.json'))
    if 'graph_data_manifest' in publication:
        publication['original_graph_source_reference'] = publication.pop('graph_data_manifest')
    publication.update(privacy_approval_inherited=False, publish_authorized=False, release_qualified=False,
                       api_index='data/api-index.json', kg_patch=transform)
    publication['files'] = [r for r in inventory(site, gate) if r['path'] != 'publication.json']
    put_json(site / 'publication.json', publication)
    rows = inventory(site, gate)
    final_by_name = {r['path']: r for r in rows}
    final_allowed = allowed | {code_ref['path'], code_ref['manifest_path']}
    for row in original['files']:
        if row['path'] not in final_allowed and not row['path'].endswith('.html'):
            require(final_by_name.get(row['path']) == row, 'Original immutable asset changed during prepare: ' + row['path'])
    for row in rows:
        if row['path'].endswith('.html'):
            path = at(site, row['path'])
            gate.Dependencies(site, path).feed(read(path).decode('utf-8'))
    prepared = dict(version='kg-patch-prepared/1', stage=frozen['stage'],
        site_inventory_sha256=sha(encoded(rows)), stage_receipt_sha256=sha(read(stage / 'stage_receipt.json')),
        frozen_inputs_sha256=sha(read(work / 'freeze.json')), code_check=check,
        gate_scope='Existing gate.make inventory at seal; no full gate.validate or dataset content rehash',
        publish_authorized=False, privacy_approval_inherited=False)
    put_json(work / 'prepared-inventory.json', rows)
    put_json(work / 'prepare.json', prepared)
    return dict(prepared_sha256=sha(encoded(prepared)), publish_authorized=False, sealed=False)


def validate_qa(raw, prepared_raw, site_digest):
    qa = public_json(raw)
    require(qa['version'] == 'kg-patch-post-prepare-qa/1' and qa['status'] == 'PASS', 'Fresh QA must pass')
    require(qa['prepared_sha256'] == sha(prepared_raw) and qa['site_inventory_sha256'] == site_digest,
            'QA refers to a different candidate')
    for key in ('browser_desktop', 'browser_mobile', 'source_and_binding_regressions',
                'slot_context_navigation_only', 'swedish_both_tabs_s2_noack_unknown_gold'):
        require(qa.get(key) is True, 'Missing QA acceptance: ' + key)
    require(isinstance(qa.get('evidence'), list) and qa['evidence'], 'QA needs hash-bound evidence')
    for ref in qa['evidence']:
        path, _ = pinned(PATCH, ref)
        require(path.is_relative_to(PATCH / 'qa') or path.is_relative_to(HERE), 'QA evidence outside allowed directories')
    return qa


def seal(stage, work, gate, qa_ref):
    require(not (stage / 'site/release-manifest.json').exists() and not (work / 'seal.json').exists(), 'Already sealed')
    prepared_raw = read(work / 'prepare.json')
    prepared = public_json(prepared_raw)
    require(prepared['version'] == 'kg-patch-prepared/1' and prepared['stage'] == stage.relative_to(PATCH).as_posix(), 'Wrong prepared stage')
    frozen = load(read(work / 'freeze.json'))
    require(input_files() == frozen['source_files'], 'Frozen sources changed; new freeze/prepare required')
    require(sha(read(stage / 'stage_receipt.json')) == prepared['stage_receipt_sha256'], 'Prepared receipt changed')
    rows = inventory(stage / 'site', gate)
    digest = sha(encoded(rows))
    require(digest == prepared['site_inventory_sha256'], 'Prepared site changed; rerun QA on a new prepare')
    qa_path = within(PATCH, qa_ref)
    qa_raw = read(qa_path)
    validate_qa(qa_raw, prepared_raw, digest)
    receipt = public_json(read(stage / 'stage_receipt.json'))
    site = stage / 'site'
    # make(), not validate(): the latter rehashes the whole 3 GB dataset even in inventory-only mode.
    value = gate.make(site, receipt)
    require(value['files'] == rows and value['publish_authorized'] is False
            and value['privacy_approval_inherited'] is False, 'Fresh gate inventory mismatch')
    public_json(read(site / 'release-manifest.json'))
    result = dict(version='kg-patch-seal/1', manifest_sha256=sha(read(site / 'release-manifest.json')),
        prepared_sha256=sha(prepared_raw), qa_ref=dict(path=qa_path.relative_to(PATCH).as_posix(), sha256=sha(qa_raw)),
        integrity_scope=prepared['gate_scope'], publish_authorized=False, privacy_approval_inherited=False,
        full_native_root_reconstruction_run=False, datasets_copied=False, datasets_rehashed=False)
    put_json(work / 'seal.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--freeze', action='store_true', help='Main only: declare UI/data stable and capture frozen input pins')
    modes.add_argument('--prepare', action='store_true', help='Integrate frozen handoffs; leave stage unsealed for QA')
    modes.add_argument('--seal', action='store_true', help='Seal exact prepared bytes after fresh QA; no authorization')
    modes.add_argument('--check-handoffs', action='store_true', help='Read-only validation; no freeze, stage writes or packaging')
    parser.add_argument('--stage', type=Path, default=PATCH / 'stage')
    parser.add_argument('--work', type=Path, help='New candidate directory under release/runs/')
    parser.add_argument('--qa-ref', type=Path, help='Main-authored post-prepare QA record under patch root')
    parser.add_argument('--swedish-pin', default=SWEDISH_PIN)
    parser.add_argument('--swedish-ref', '--swedish-handoff', dest='swedish_handoff', type=Path,
                        default=PATCH / 'swedish/artifacts_v01/integration-v03.json')
    parser.add_argument('--slots-pin', default=SLOTS_PIN)
    parser.add_argument('--check-stage', action='store_true', help='With --check-handoffs: validate current staged slot/runtime delta read-only')
    args = parser.parse_args()
    require(sys_flags_ok(), 'Do not run release gates with Python assertions disabled')
    space(HERE)
    if args.check_handoffs:
        swedish, copies, _, packets, refs = handoffs(args.swedish_handoff, args.swedish_pin, args.slots_pin)
        value = dict(status='PASS_READ_ONLY_HANDOFF_CHECK', copies=len(copies), slot_routes=len(packets),
                     swedish_native_execution=swedish['native_execution'],
                     requested_new_native_swedish_s2_completed=False, **refs)
        if args.check_stage:
            value['staged_integration'] = staged_preflight(within(PATCH, args.stage), packets)
        print(encoded(value).decode(), end='')
        return
    require(args.work is not None, '--work is required for freeze/prepare/seal')
    stage = within(PATCH, args.stage)
    require(stage == PATCH / 'stage', 'Only the explicit workspace patch/stage may be packaged outside olddeploy')
    work = within(HERE / 'runs', args.work)
    require(not work.is_relative_to(stage) and not stage.is_relative_to(work), 'Overlapping output/stage')
    space(HERE)
    gate = gate_module()
    if args.freeze:
        value = freeze(stage, work, gate, args.swedish_handoff, args.swedish_pin, args.slots_pin)
    elif args.prepare:
        value = prepare(stage, work, gate)
    else:
        require(args.qa_ref is not None, '--seal requires a new --qa-ref, never old authorization')
        value = seal(stage, work, gate, args.qa_ref)
    print(encoded(value).decode(), end='')


def sys_flags_ok():
    import sys
    return not sys.flags.optimize


if __name__ == '__main__':
    main()
