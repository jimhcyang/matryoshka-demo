"""Extend the exact existing code ZIP, retaining replaced historical bytes."""
import ast
import io
from pathlib import Path
import subprocess
import sys
import zipfile

from release_common import (DEPLOY, HERE, INSTALLED, PATCH, SOURCE, at, encoded,
                            load, public_json, read, relative, require, sha,
                            space, tree_sha, write)

PREFIX = 'export-package/'


def include_patch_file(directory, path):
    if path.suffix not in {'.py', '.js', '.cjs', '.css', '.html', '.md', '.pdf', '.txt', '.json'}:
        return False
    if path.suffix == '.json':
        return (directory == 'release' and path.name == 'post-prepare-qa.example.json'
                or directory == 'root' and path.name == 'baseline.json')
    return True


def unpack(raw, receipt):
    files = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'Duplicate ZIP member')
        require(len(receipt['files']) == len({r['path'] for r in receipt['files']}), 'Duplicate code manifest row')
        require(set(names) == {PREFIX + relative(r['path']) for r in receipt['files']}, 'ZIP/manifest mismatch')
        require(sum(i.file_size for i in archive.infolist()) < 80_000_000, 'Code ZIP expands beyond 80 MB')
        for row in receipt['files']:
            name = relative(row['path'])
            info = archive.getinfo(PREFIX + name)
            require((info.external_attr >> 16) & 0o170000 != 0o120000, 'Symlink in code ZIP')
            data = archive.read(info)
            require(len(data) == row['bytes'] and sha(data) == row['sha256'], 'Code file hash mismatch: ' + name)
            require(name != 'backend/contracts/planning_v2/masked_examples.json', 'Corpus fixture in code ZIP')
            if name.endswith('.json'):
                public_json(data)
            files[name] = data
    return files


def replace(files, name, raw):
    relative(name)
    if name in files and files[name] != raw:
        historical = 'history/pre-kg/' + name
        if historical in files and files[historical] != files[name]:
            historical = 'history/pre-kg/' + sha(files[name]) + '/' + name
        files[historical] = files[name]
    files[name] = raw


def add_tree(files, root, prefix, suffixes):
    for path in sorted(root.rglob('*')):
        require(not path.is_symlink(), 'Symlink in selected code tree')
        if path.is_file() and '__pycache__' not in path.parts and path.suffix in suffixes:
            replace(files, prefix + path.relative_to(root).as_posix(), read(path))


def make_zip(files):
    output = io.BytesIO()
    rows = []
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(files.items()):
            relative(name)
            if name.endswith('.json'):
                public_json(raw)
            info = zipfile.ZipInfo(PREFIX + name, date_time=(2026, 11, 22, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, raw, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            rows.append(dict(path=name, bytes=len(raw), sha256=sha(raw)))
    return output.getvalue(), rows


def check_imports(snapshot):
    package = snapshot / 'export-package'
    code = ('import sys;from pathlib import Path;'
            'root=Path(' + repr(str(package / 'backend')) + ');sys.path.insert(0,str(root));'
            'import matryoshka_narrative.server;'
            'from matryoshka_current.slot_context import POLICY;'
            'import matryoshka_current.slot_overlay;'
            'mods=[m for n,m in sys.modules.items() if n.startswith("matryoshka_") and getattr(m,"__file__",None)];'
            'assert mods and all(Path(m.__file__).is_relative_to(root) for m in mods);print(len(mods))')
    result = subprocess.run([sys.executable, '-I', '-B', '-c', code], cwd=snapshot,
                            capture_output=True, text=True, timeout=60)
    require(result.returncode == 0, 'Isolated backend import failed: ' + result.stderr)
    # Explicit sibling path, still -I and no ambient PYTHONPATH/source checkout imports.
    script = ('import sys,runpy;sys.path.insert(0,' + repr(str(package)) + ');'
              'sys.argv=["export_narrative.py","--help"];runpy.run_path('
              + repr(str(package / 'export_narrative.py')) + ',run_name="__main__")')
    result_help = subprocess.run([sys.executable, '-I', '-B', '-c', script], cwd=snapshot,
                                 capture_output=True, text=True, timeout=60)
    require(result_help.returncode == 0 and '--resume' in result_help.stdout
            and '--reuse-graph-stage' in result_help.stdout, 'Contained exporter help failed')
    return dict(contained_backend_imports=True, isolated_import_modules=int(result.stdout.strip()),
                generic_export_help_pass=True, api_calls=0, native_executions=0)


def build(prior_raw, prior_manifest, work, slot_pins, *, deploy=DEPLOY, installed=INSTALLED, patch=PATCH, source=SOURCE):
    files = unpack(prior_raw, prior_manifest)
    excluded = prior_manifest.get('excluded_corpus_derived_inputs', [])
    old_tree = tree_sha(files, excluded)
    require(old_tree == prior_manifest['backend_tree_sha256'], 'Prior backend tree mismatch')
    # Keep the complete old archive, then add all exporter helpers, including omitted tests.
    for path in sorted(deploy.iterdir()):
        if path.is_file() and (path.suffix in {'.py', '.js', '.md'} or path.name == 'requirements-readonly.txt'):
            replace(files, path.name, read(path))
    add_tree(files, deploy / 'ci', 'ci/', {'.py', '.yml'})
    for name in ('slot_overlay.py', 'slot_context.py'):
        key = 'src-demo-day/matryoshka_current/' + name
        raw = read(source / 'matryoshka_current' / name)
        require(sha(raw) == slot_pins[key], 'Slot implementation differs from verified handoff')
        replace(files, 'backend/matryoshka_current/' + name, raw)
    for directory, suffixes in (('tools', {'.py'}), ('release-tools', {'.py'}),
                                ('runtime', {'.py', '.js', '.html', '.md', '.txt'})):
        add_tree(files, installed / directory, 'installed/' + directory + '/', suffixes)
    for path in sorted((installed / 'tests').glob('*.py')):
        replace(files, 'installed/tests/' + path.name, read(path))
    workflow = read(installed / '.github/workflows/pages.yml')
    replace(files, 'installed/.github/workflows/pages.yml', workflow)
    replace(files, 'installed/requirements-dev.txt', read(installed / 'requirements-dev.txt'))
    for path in sorted((installed / 'release-tools/ci').glob('*.py')):
        replace(files, 'ci/' + path.name, read(path))
    replace(files, 'ci/pages.yml', workflow)
    for name in ('export_current_replays.py', 'check_current_readout_cache.py'):
        replace(files, 'vendor/tools/' + name, read(installed / 'tools' / name))
    # Keep the live CI six-test suite, rather than resurrecting the older four-test file.
    suite = ast.parse(files['ci/test_manifest.py'])
    tests = sum(isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_')
                for node in ast.walk(suite))
    require(tests >= 6, 'Active installed manifest CI suite was not retained')
    replace(files, 'patch/tests/test_navigation_publication_cache.py',
            read(source / 'tests/test_navigation_publication_cache.py'))
    replace(files, 'patch/tests/test_current_slot_context_patch.py',
            read(source / 'tests/test_current_slot_context_patch.py'))
    for directory in ('ui', 'release', 'runtime'):
        # release/runs and generated candidate snapshots must never recursively enter the ZIP.
        root = patch / directory
        selected = root.rglob('*') if directory == 'ui' else root.glob('*')
        for path in sorted(selected):
            if path.is_file() and include_patch_file(directory, path):
                replace(files, 'patch/' + directory + '/' + path.relative_to(root).as_posix(), read(path))
    add_tree(files, patch / 'release/ci', 'patch/release/ci/', {'.py'})
    smoke = read(patch / 'release/ci/browser_smoke.py')
    replace(files, 'ci/browser_smoke.py', smoke)
    replace(files, 'installed/release-tools/ci/browser_smoke.py', smoke)
    replace(files, 'slot-runtime.js', read(patch / 'runtime/slot-runtime.js'))
    for name in ('exact-files.json', 'integration-v1/integration.json'):
        replace(files, 'patch/runtime/' + name, read(patch / 'runtime' / name))
    replace(files, 'vendor/runtime/public-runtime.js', read(patch / 'stage/site/runtime/public-runtime.js'))
    replace(files, 'patch/staged-runtime/public-runtime.js', read(patch / 'stage/site/runtime/public-runtime.js'))
    static = files['static_slots.py']
    require(b"'label', 'context_policy'" in static, 'Exporter drops thin slot label/context policy')
    replace(files, 'CODE_BUNDLE_README.md', read(patch / 'release/CODE_BUNDLE_PATCH_README.md'))
    for directory in ('slots', 'swedish', 'qa'):
        for path in sorted((patch / directory).glob('*')):
            if path.is_file() and path.suffix in {'.py', '.js', '.cjs', '.md'}:
                replace(files, 'patch/' + directory + '/' + path.name, read(path))
    for path in sorted(patch.glob('*')):
        if path.is_file() and path.suffix in {'.py', '.md', '.json'} and include_patch_file('root', path):
            replace(files, 'patch/' + path.name, read(path))
    new_tree = tree_sha(files, excluded)
    snapshot = dict(version='kg-patch-backend-snapshot/1', canonical=False,
        tree_sha256=new_tree, prior_tree_sha256=old_tree, source_paths='RELATIVE_SOURCE_ROOT_TAGS_NO_LOCAL_ABSOLUTE_PATHS',
        native_execution_versions_rewritten=False,
        files=[dict(target=name, source='SOURCE_ROOT/' + name, sha256=sha(raw))
               for name, raw in sorted(files.items()) if name.startswith('backend/')],
        excluded_corpus_derived_inputs=excluded)
    replace(files, 'backend-source-snapshot.json', encoded(snapshot))
    raw, rows = make_zip(files)
    manifest = dict(prior_manifest, files=rows, backend_tree_sha256=new_tree,
                    prior_bundle_sha256=sha(prior_raw), prior_backend_tree_sha256=old_tree,
                    original_backend_code_modified=True, backend_changes=['matryoshka_current/slot_overlay.py',
                    'matryoshka_current/slot_context.py'], historical_bytes_retained_under='history/pre-kg/',
                    native_execution_versions_rewritten=False, active_installed_ci_tests=tests,
                    api_calls=0, native_executions=0)
    unpack(raw, manifest)
    snapshot_root = at(work, 'snapshot')
    require(not snapshot_root.exists(), 'Snapshot already exists')
    space(HERE, sum(len(data) for data in files.values()) + len(raw))
    for name, data in sorted(files.items()):
        write(at(snapshot_root, PREFIX + name), data)
    write(at(work, 'matryoshka-code.zip'), raw)
    write(at(work, 'matryoshka-code-manifest.json'), encoded(manifest))
    return raw, encoded(manifest), new_tree, check_imports(snapshot_root)
