"""Code exports select sources and explicit bindings, never arbitrary QA JSON."""
from pathlib import Path

import pytest

import code_snapshot as bundle
from release_common import encoded


@pytest.mark.parametrize('name', ['qa-renderer-selector.json', 'browser-v1.json',
    'preview-v2.json', 'new-files.json', 'unrecognized-receipt.json'])
def test_runtime_receipts_are_not_implicitly_code(name):
    assert not bundle.include_patch_file('runtime', Path(name))


def test_sources_and_explicit_binding_route_are_preserved():
    assert bundle.include_patch_file('runtime', Path('integrate_slots.py'))
    assert bundle.include_patch_file('runtime', Path('slot-runtime.js'))
    assert bundle.include_patch_file('root', Path('verify_native_roots.py'))
    assert bundle.include_patch_file('root', Path('baseline.json'))
    assert not bundle.include_patch_file('root', Path('ordinary-native-roots-v01.json'))
    source = Path(bundle.__file__).read_text()
    assert "('exact-files.json', 'integration-v1/integration.json')" in source


def test_private_receipt_is_excluded_not_sanitized_or_waived():
    candidates = {'integrate_slots.py': b'# code\n',
                  'qa-renderer-selector.json': encoded(dict(source='/Users/test/private/graph.js'))}
    selected = {name: raw for name, raw in candidates.items()
                if bundle.include_patch_file('runtime', Path(name))}
    raw, manifest = bundle.make_zip(selected)
    assert {r['path'] for r in manifest} == {'integrate_slots.py'}
    assert bundle.unpack(raw, dict(files=manifest)) == selected
    with pytest.raises(ValueError, match='Machine-local path'):
        bundle.make_zip(candidates)
