# Bounded KG Release Helpers

Status: helpers implemented and fixture-tested. NO real freeze, prepare, seal,
install or live verification was run. Main still owns final UI/data, artifact
selection, QA acceptance, privacy/rights review, fresh authorization and install.
Do not freeze while the bounded Swedish shared-kernel attempt is unresolved.
Current v03 support is explicitly non-native. Requested new native Swedish S2
completion remains UNMET, not a user-accepted deferral. False-field guards have
not been relaxed for a hypothetical new native packet.

## Exact Deliverables

- `package_release.py`: read-only handoff check; main-only freeze; prepare; seal.
- `release_common.py`: strict paths, duplicate-key JSON, pins, space guard, gate import.
- `code_snapshot.py`: reproducible contained ZIP and expanded small code snapshot.
- `ci/browser_smoke.py`: installed smoke helper with ONLY its Swedish operation replaced.
- `build_addendum.py`: reproducible five-page PDF/text and optional separate append.
- `kg-patch-addendum.pdf` and `kg-patch-addendum.txt`: outward-facing addendum.
- `CODE_BUNDLE_PATCH_README.md`: current bundle contract; replaces old root README in ZIP.
- `post-prepare-qa.example.json`: schema example, not evidence or authorization.
- `test_release.py`: tiny fixtures, archive/path adversaries, immutable-route checks and seal checks.
- `tests-v01.xml`: retained initial attempt, 23 passed and 7 fixture setup errors.
- `tests-v02.xml`: 31 passed after fixing fixture setup.
- `tests-v03.xml`: 31 passed, 1 failed; final immutable-file check initially disallowed the intended replacement code ZIP.
- `tests-v04.xml`: 32 passed after scoping that exception to the two code-download assets.
- `addendum-preview-page4.png`: rendered Swedish page, visually inspected.
- `HANDOFF.md`: this handoff. Generated `test-tmp-v*` directories are tiny local test fixtures only.

Every file authored here is under `release/`. No ui/, stage/, installed repo,
slots/, swedish/, qa/, canonical docs, git state or API ledger was written.
Only the read-only handoff check reads the actual worker artifacts. Tests use
temporary fixture trees under `release/test-tmp-v*`, never a real release build.

## Commands

All commands below are from workspace root. These are instructions for MAIN;
the real-stage commands have deliberately NOT been executed by this helper task.

Read-only check, safe before freeze:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/package_release.py --check-handoffs --check-stage --swedish-ref src-demo-day/phase/kg_patch_20261122/swedish/artifacts_v01/integration-v03.json --swedish-pin 5f89de6716af649b145604f45c1db02e60647f8cb847e7ae89e36d4114d137b8
```

This passed against all 10 v03 copy pins, its test/feasibility receipt pins and
all 224 authoritative slot routes. The CIB thin catalog is 47,443,038 decoded
bytes: catalogs are bounded at 100 MB, record shards at 20 MB, enforced DURING
gzip decoding. No dataset store or native comparison root was read by this check.
`--check-stage` additionally reads the staged index, report, slot packets and
pinned runtime integration files, and compares every non-slot route with the
baseline. It does not reconstruct all native packets or read the dataset store.
This is an index/native-reference preservation check, not a content QA substitute.
The final read-only staged preflight passed: exactly 224 slot route changes,
51,877 unchanged non-slot route bindings (including native/source/graph routes),
unchanged ordinary report hash and exact staged index
`67e1901e204a5a0d6f3ad06f28bf60caeaa905882c84ac4b27013563c6468c3e`.
No dataset files were read or rehashed.
An alternate handoff uses `--swedish-ref PATH --swedish-pin EXACT_SHA256` at
freeze. The path is not hardcoded to v01; pins cannot be silently refreshed.
Unknown schemas/new native execution remain fail-closed pending explicit review.

Only after main announces a stable UI/data freeze and resolves the native decision:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/build_addendum.py
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/package_release.py --freeze --work src-demo-day/phase/kg_patch_20261122/release/runs/kg-v01 --swedish-ref src-demo-day/phase/kg_patch_20261122/swedish/artifacts_v01/integration-v03.json --swedish-pin 5f89de6716af649b145604f45c1db02e60647f8cb847e7ae89e36d4114d137b8
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/package_release.py --prepare --work src-demo-day/phase/kg_patch_20261122/release/runs/kg-v01
```

Use a NEW work directory for every freeze/attempt. Stop editing frozen sources.
Freeze records exact source files, the unsealed stage inventory and receipt.
Prepare refuses changed inputs, integrates only pinned Swedish copies and the
verified sparse slot overlay, then refreshes all stage HTML index hooks. Slot
packets receive deterministic `data/slot-context-patch-v01/` physical paths;
the index will change, so PREPARED bytes require new QA. Existing pre-prepare
screenshots/QA do not qualify the prepared candidate. Do NOT rerun the main
binding helper afterward: prepare already binds stage HTML; editing source UI
after freeze invalidates it. No release-manifest exists until seal.

Main-run post-prepare smoke command, when server/browser checks are permitted:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src-demo-day/phase/release_finish_20261121/deploy .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/ci/browser_smoke.py --site src-demo-day/phase/kg_patch_20261122/stage/site --datasets-root matryoshka_demo_site/datasets --output src-demo-day/phase/kg_patch_20261122/release/runs/kg-v01/browser-smoke
```

This retains the installed graph/walk cells and uses managed headless Chromium,
not installed Chrome. Swedish now checks both tabs, immediate default S2, no
ack/result-opening control, Input/Sources/Results, masked queries, exact source
quotation, eight inspected pages and null gold/non-native metadata. No empty
Facts/Readings panels are assumed. The other graph/walk checks are unchanged.
Run main's desktop/mobile geometry and source/binding regression QA too.

Main authors `release/runs/kg-v01/post-prepare-qa.json` using the example schema
and actual fresh evidence pins. Its `prepared_sha256` binds the exact bytes of
`runs/kg-v01/prepare.json`; `site_inventory_sha256` comes from that file. Evidence
paths are PATCH-root-relative, not absolute. Store QA under the work directory,
NOT as a new top-level release JSON that would change frozen source selection.
Only mark the five acceptance booleans true after their checks pass.

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/package_release.py --seal --work src-demo-day/phase/kg_patch_20261122/release/runs/kg-v01 --qa-ref src-demo-day/phase/kg_patch_20261122/release/runs/kg-v01/post-prepare-qa.json
```

Seal refuses changed site/source/receipt bytes, missing/failed/different-candidate
QA, tampered evidence and an existing seal. It calls the existing `gate.make`
for a FRESH inventory. Both manifest and seal keep publish_authorized=false and
privacy_approval_inherited=false. No old approval is read, adopted or generated.
Main's `install_patch.py` still requires separately hash-bound all-native
integrity checks and a fresh gate-authorized approval. This helper never invokes it.
Main's top-level `verify_live.py` is included in the ZIP; main runs it only after
sealing/install/publication decisions, never against this mutable preview.

## Scope And Guarantees

Only the exact workspace `patch/stage` is accepted outside olddeploy; symlink,
traversal, alternate workspace root and output overlap fail. Work outputs must
be under `release/runs/`. Published JSON and code manifests reject local workspace
paths. Public lineage drops the old absolute backend_root and distinguishes the
implementation snapshot from historical native versions. Native version/coverage
metadata is retained, not relabeled as a new run.

Every existing non-slot API/graph/source-page entry must match the pinned old
index object exactly. No logical routes are added or removed. Only slot record
shards/catalogs change; all slot identities, immutable fields, page routes,
source audits, coverage and graph/hierarchy bindings remain fixed. Links must
be zero-weight, nonsemantic, navigation-only and ineligible evidence. Iran and
Vietnam remain zero-marker catalogs. Ordinary report bytes and guide assets
remain exact. Existing HTML changes outside the owned UI set may change only
the runtime index pin. Final HTML dependencies are checked with the old gate.

No 3 GB dataset copy or content rehash: only unchanged dataset-manifest bytes
and dataset path/type/size metadata are checked. Existing `gate.validate()`,
even `--inventory-only`, calls `same_repo.validate()` and rehashes the WHOLE
dataset store. It is deliberately NOT invoked here. Seal receipts explicitly
say this is fresh inventory plus invariant checks, NOT full native-root
reconstruction or full dataset content validation. Main's separate native
integrity review remains required; do not call this a full old-gate PASS.
The 3 GiB free-space floor and 900 MB / 100 MB publication caps remain enforced.

The ZIP starts with ALL prior archive members, then snapshots all olddeploy
export helpers/tests and the active installed helpers, eight exporter transport
tests, runtime test sources, six authorization tests and cache checker. It adds
PATCH runtime `.py/.js/.cjs`, active root `slot-runtime.js`, updated thin-retaining
`static_slots.py`, the staged composed public runtime, all patch UI/release
tools, and top-level patch `.py/.md/.json` including `bind_stage_index.py`,
`verify_live.py`, `install_patch.py` and `IMPLEMENTATION_NOTES.md`. Root and
installed CI browser smoke copies use the NEW helper. Historical replacements
are retained; corpus-derived authoring input stays excluded with its hash.
ZIP metadata/order and backend tree identity are deterministic. An isolated
`-I -B` backend import and generic exporter `--help` run only during prepare,
never a server, native engine, model or installation.

The guide addendum is five outward-facing pages, separately published under
`docs/kg-patch-addendum.{pdf,txt}`. It does not alter the old 36-page report-bound
guide or its binding. Main decides final links/artifacts. Optional append creates
a separate combined PDF under release/, never overwrites the original:

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B src-demo-day/phase/kg_patch_20261122/release/build_addendum.py --append-to src-demo-day/phase/kg_patch_20261122/stage/site/docs/matryoshka-guide.pdf --combined-output src-demo-day/phase/kg_patch_20261122/release/guide-with-addendum.pdf
```

Build any optional combined PDF BEFORE freeze. pypdf is installed; reportlab is
not, so the standalone PDF uses deterministic standard PDF fonts without installs.
If prepare fails, preserve the failed work directory and inspect the stage
before a new freeze; no automatic rollback/clobber of main-owned files occurs.

## Recheck Helpers

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp=src-demo-day/phase/kg_patch_20261122/release/test-tmp-next --junitxml=src-demo-day/phase/kg_patch_20261122/release/tests-next.xml src-demo-day/phase/kg_patch_20261122/release/test_release.py
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=matryoshka_demo_site/release-tools/ci:src-demo-day/phase/release_finish_20261121/deploy .venv/bin/python -B -m unittest discover -s matryoshka_demo_site/release-tools/ci -p 'test_*.py'
```

No browser or server was launched by this task. Actual final-stage layout,
transport/browser behavior and native integrity remain main's checks after freeze.
The active installed authorization suite was also executed: 6 tests passed.
Final helper files are stable; no further edits are planned before main's freeze.
