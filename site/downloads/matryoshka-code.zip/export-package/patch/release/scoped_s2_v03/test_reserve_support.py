"""Tiny installed-reader fixtures; no browser, real stage, native or S2 run."""
import ast
import gzip
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

import assets
from release_common import INSTALLED, sha
from reserve_support import reserve_source


@pytest.fixture
def reader_module():
    spec = importlib.util.spec_from_file_location('reserve_fixture_reader', INSTALLED / 'release-tools/fragment_reader.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_reserve_default_and_explicit_workstation_floor(reader_module, tmp_path):
    reader = reader_module.Reader(tmp_path, tmp_path / 'default.sqlite3')
    assert reader.minimum_free_bytes == 8 * 1024**3
    reader.close()
    reader = reader_module.Reader(tmp_path, tmp_path / 'bounded.sqlite3', minimum_free_bytes=3 * 1024**3)
    assert reader.minimum_free_bytes == 3 * 1024**3
    reader.close()
    for invalid in (0, 2 * 1024**3, 3.0 * 1024**3, True):
        with pytest.raises(ValueError):
            reader_module.Reader(tmp_path, tmp_path / 'invalid.sqlite3', minimum_free_bytes=invalid)


def test_reserve_eight_blocks_three_passes_without_weakening_hashes(reader_module, tmp_path, monkeypatch):
    raw = json.dumps(dict(first_id=1, fragments=[['saved']])).encode()
    wire = gzip.compress(raw, mtime=0)
    (tmp_path / 'chunk.gz').write_bytes(wire)
    manifest = dict(version='graph-fragment-dag/1', chunks=[dict(path='chunk.gz', wire_sha256=sha(wire), wire_bytes=len(wire),
        sha256decoded=sha(raw), decoded_bytes=len(raw), first_id=1, last_id=1)])
    data = json.dumps(manifest).encode()
    (tmp_path / 'pack.json').write_bytes(data)
    entry = dict(path='pack.json', manifest_sha256=sha(data))
    monkeypatch.setattr(reader_module.shutil, 'disk_usage', lambda path: SimpleNamespace(free=4 * 1024**3))
    strict = reader_module.Reader(tmp_path, tmp_path / 'strict.sqlite3')
    try:
        with pytest.raises(AssertionError, match='reserve'):
            strict.pack(entry)
    finally:
        strict.close()
    bounded = reader_module.Reader(tmp_path, tmp_path / 'bounded.sqlite3', minimum_free_bytes=3 * 1024**3)
    try:
        assert bounded.pack(entry) == manifest
    finally:
        bounded.close()
    (tmp_path / 'chunk.gz').write_bytes(b'tampered')
    tampered = reader_module.Reader(tmp_path, tmp_path / 'tampered.sqlite3', minimum_free_bytes=3 * 1024**3)
    try:
        with pytest.raises(AssertionError):
            tampered.pack(entry)
    finally:
        tampered.close()


def test_reserve_ci_composition_is_explicit_and_fails_closed():
    source = assets.smoke_source().decode()
    assert 'matryoshka_demo_site/release-tools' in source
    assert 'minimum_free_bytes=args.minimum_free_gib * 1024**3' in source
    tree = ast.parse(source)
    call = next(n for n in ast.walk(tree) if isinstance(n, ast.Call) and n.args
                and isinstance(n.args[0], ast.Constant) and n.args[0].value == '--minimum-free-gib')
    options = {k.arg: ast.literal_eval(k.value) for k in call.keywords if k.arg in ('choices', 'default')}
    assert options == dict(choices=(3, 8), default=8)
    with pytest.raises(ValueError):
        reserve_source(source)


def test_reserve_generated_ci_matches_source_and_remains_managed_shell():
    source = assets.smoke_source()
    assert b'p.chromium.launch(headless=True)' in source
    assert b'channel=' not in source
    generated = Path(assets.HERE / 'ci/browser_smoke.py')
    assert generated.read_bytes() == source
