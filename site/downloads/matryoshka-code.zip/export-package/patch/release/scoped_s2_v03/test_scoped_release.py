"""Focused v02 tests: real read-only audit plus tiny mutation/packaging fixtures."""
import ast
from copy import deepcopy
import io
from pathlib import Path
import shutil

import pytest

import assets
import contract
import package_release_v03 as package
from release_common import PATCH, SOURCE, encoded, gate_module, load, read, sha

FINAL = PATCH / 'swedish/isolated_engine/SCOPED_RELEASE_CONTRACT_v04.json'
PIN = 'ae7bc8d2b8e165c4887aa205c0474519559be254c87864e4c072b5095f960a99'


def put(root, name, value):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value if isinstance(value, bytes) else encoded(value))
    return path


@pytest.fixture(scope='module')
def actual():
    return package.load_binding(FINAL, PIN)


def test_actual_final_contract_and_index_are_read_only(actual):
    assert actual['manifest_ref']['path'].endswith('SCOPED_RELEASE_CONTRACT_v04.json')
    assert actual['manifest_ref']['sha256'] == PIN
    assert len(actual['copies']) == 9 and len(actual['code_files']) == len(actual['manifest']['code_snapshot_ref']['python_source_allowlist'])
    assert len(actual['audits']) == 2 and len({a['case_id'] for a in actual['audits']}) == 2
    proof = package.check_stage(PATCH / 'stage')
    assert proof['non_slot_route_bindings_unchanged'] == 51877
    assert proof['index_sha256'] == '67e1901e204a5a0d6f3ad06f28bf60caeaa905882c84ac4b27013563c6468c3e'
    assert proof['dataset_files_read'] == 0
    assert actual['producer_qa']['tests_passed'] == 136
    assert actual['displays'][0]['execution_version'] == 'narrative-scoped-source-study-execution/3'


@pytest.fixture
def pair(actual):
    query = deepcopy(actual['manifest']['queries'][0])
    row = deepcopy(actual['displays'][0])
    execution = load(package.legacy.decode_packet(read(SOURCE / query['private_execution_ref']['path']), 100_000_000))
    completion = load(read(SOURCE / query['private_execution_completion_ref']['path']))
    public = load(actual['copies'][Path(query['public_completion_ref']['path']).name])
    return row, query, execution, completion, public, deepcopy(actual['manifest']['code_snapshot_ref'])


def test_actual_display_validates_without_sweden_requirement(pair):
    contract.validate_display(*pair)
    assert pair[0]['readings'] == contract.expected_readings(pair[2]['result'])


@pytest.mark.parametrize('mutation', ['gold', 'canonical', 'not-executed', 'wrong-version', 'query', 'utf8',
    'scope', 'source-view', 'snapshot', 'completion', 'private-completion', 'rank', 'decision', 'quote', 'variant-proof', 'facts'])
def test_actual_binding_adversaries_reject(pair, mutation):
    row, query, execution, completion, public, code = pair
    candidate = next(r['candidates'][0] for r in row['readings'] if r['candidates'])
    if mutation == 'gold': row['gold'] = 'a hidden answer'
    elif mutation == 'canonical': row['canonical_native_run'] = True
    elif mutation == 'not-executed': row['execution_performed'] = False
    elif mutation == 'wrong-version': execution['version'] = 'narrative-local-execution/3'
    elif mutation == 'query': row['case']['query'] += ' changed'
    elif mutation == 'utf8': public['query_utf8_sha256'] = '0'*64
    elif mutation == 'scope': row['source_policy_version'] = 'ordinary'
    elif mutation == 'source-view': public['source_view_sha256'] = '0'*64
    elif mutation == 'snapshot': code['executed_snapshot_identity'] = '0'*64
    elif mutation == 'completion': public['public_display_ref']['sha256'] = '0'*64
    elif mutation == 'private-completion': completion['execution_digest'] = '0'*64
    elif mutation == 'rank': candidate['rank'] = 99
    elif mutation == 'decision': candidate['local_decision']['status'] = 'UNSUPPORTED'
    elif mutation == 'quote': candidate['sources'][0]['text'] += ' changed'
    elif mutation == 'variant-proof': candidate['source_variants'][0]['raw_decision_digest'] = '0'*64
    else: row['facts'] = []
    with pytest.raises(ValueError):
        contract.validate_display(row, query, execution, completion, public, code)


@pytest.mark.parametrize('mutation', ['json', 'duplicate', 'traversal'])
def test_isolated_code_allowlist_rejects_noncode_and_ambiguity(actual, mutation):
    code = deepcopy(actual['manifest']['code_snapshot_ref'])
    if mutation == 'json':
        code['python_source_allowlist'].append(code['public_metadata_ref'])
    elif mutation == 'duplicate':
        code['python_source_allowlist'].append(code['python_source_allowlist'][0])
    else:
        code['python_source_allowlist'][0]['path'] = '../outside.py'
    with pytest.raises(ValueError):
        contract.snapshot(code, SOURCE, PATCH / 'swedish/isolated_engine')


def test_only_swedish_smoke_operation_changes():
    old = read(assets.HERE.parent / 'ci/browser_smoke.py').decode()
    new = assets.smoke_source().decode()
    def outside(text):
        lines = text.splitlines()
        node = next(n for n in ast.walk(ast.parse(text)) if isinstance(n, ast.FunctionDef) and n.name == 'swedish')
        return lines[:node.lineno-1], lines[node.end_lineno:]
    from reserve_support import reserve_source
    assert outside(reserve_source(old)) == outside(new)
    assert 'scoped-candidate' in new and 'private_requests' in new
    assert "'fill'] for c in expected" in new
    assert 'channel=' not in new


def test_addendum_is_new_deterministic_and_five_pages():
    from pypdf import PdfReader
    pdf, text = assets.addendum()
    assert (pdf, text) == assets.addendum()
    reader = PdfReader(io.BytesIO(pdf))
    assert len(reader.pages) == 5
    assert b'two actual, bounded shared-kernel executions' in text
    assert b'The executed results need not include Swedish' in text
    assert b'full window' not in text or b'guess' not in text
    assert pdf != read(assets.HERE.parent / 'kg-patch-addendum.pdf')


def test_latest_main_helpers_are_in_frozen_source_selection(actual):
    names = {r['path'] for r in package.input_files(actual)}
    for name in ('authorize_patch.py', 'install_patch.py', 'verify_live.py', 'bind_stage_index.py'):
        assert 'src-demo-day/phase/kg_patch_20261122/' + name in names


def test_code_extension_uses_only_python_and_metadata(actual, tmp_path, monkeypatch):
    old_files = {'backend/old.py': b'pass\n', 'ci/test_manifest.py': b'preserved six tests\n',
                 'installed/tests/test_export_current_replays.py': b'preserved eight tests\n'}
    raw, rows = package.legacy_bundle.make_zip(old_files)
    metadata = dict(files=rows, backend_tree_sha256='a'*64)
    def base_build(prior, manifest, work, pins):
        for name, data in old_files.items():
            put(work / 'snapshot/export-package', name, data)
        return raw, encoded(metadata), 'a'*64, dict(base_imports_checked=True)
    monkeypatch.setattr(package.legacy_bundle, 'build', base_build)
    monkeypatch.setattr(package.legacy_bundle, 'check_imports', lambda root: dict(contained_backend_imports=True))
    monkeypatch.setattr(package, 'slot_inputs', lambda: ({}, {}))
    original_site = tmp_path / 'prior'
    put(original_site, 'code.zip', raw)
    put(original_site, 'code.json', metadata)
    original = dict(code_bundle=dict(path='code.zip', sha256=sha(raw), manifest_path='code.json', manifest_sha256=sha(encoded(metadata))))
    result, manifest_raw, _, _ = package.build_bundle(actual, tmp_path / 'work', original, original_site)
    files = package.legacy_bundle.unpack(result, load(manifest_raw))
    prefix = 'phase/kg_patch_20261122/swedish/isolated_engine/'
    selected = [n for n in files if n.startswith(prefix)]
    assert sum(n.endswith('.json') for n in selected) == 1
    assert all(n.endswith(('.py', 'scoped-engine-source-manifest-v03.json')) for n in selected)
    assert not any(n.endswith('execution.json.gz') or 'attempt02/' in n for n in files)
    assert 'swedish-scoped-study-v04.json' not in files
    assert files['ci/test_manifest.py'] == old_files['ci/test_manifest.py']
    assert files['installed/tests/test_export_current_replays.py'] == old_files['installed/tests/test_export_current_replays.py']
    assert files['ci/browser_smoke.py'] == assets.smoke_source()


@pytest.mark.parametrize('attack', ['none', 'changed-index', 'changed-css', 'changed-receipt', 'stale-qa', 'failed-qa', 'tampered-evidence'])
def test_tiny_freeze_prepare_seal_keeps_frozen_kg_and_index(actual, tmp_path, monkeypatch, attack):
    patch, gate = tmp_path / 'patch', gate_module()
    stage, work, original_site = patch / 'stage', patch / 'work', patch / 'prior/site'
    monkeypatch.setattr(package, 'PATCH', patch)
    monkeypatch.setattr(package, 'input_files', lambda binding: [])
    monkeypatch.setattr(package, 'check_stage', lambda stage: dict(index_sha256='pinned', dataset_files_read=0))
    monkeypatch.setattr(package, 'load_binding', lambda *args: actual)
    report = dict(cases=[dict(case=dict(case_id='ordinary'))])
    put(original_site, 'data/report-v6.json', report)
    put(original_site, 'data/api-index.json', dict(entries={}))
    put(original_site, 'runtime/public-runtime.js', b'frozen runtime')
    put(original_site, 'graph-full-v6.js', b'frozen KG')
    put(original_site, 'graph-full-v6.css', b'frozen CSS')
    put(original_site, 'docs/matryoshka-guide.pdf', b'original guide')
    put(original_site, 'app-navigation.js', b'fixture nav')
    put(original_site, 'app-navigation.css', b'fixture nav css')
    put(original_site, 'publication.json', {})
    put(original_site, 'export-lineage.json', {})
    receipt = dict(source_report_ref=dict(path='report.json', sha256=sha(encoded(report))), casebook_ref=dict(path='cases', sha256='b'*64),
                   digest_ref=dict(path='digest', sha256='c'*64), backend_code_sha256='d'*64,
                   native_versions={'historical/2': 1}, coverage=[dict(native_version='historical/2')])
    original = gate.make(original_site, receipt)
    monkeypatch.setattr(package.legacy, 'baseline', lambda gate: (original_site, original, {}, dict(manifest_sha256='e'*64)))
    monkeypatch.setattr(package.legacy, 'dataset_metadata', lambda *args: dict(copied=False, hashes_recomputed=False))
    monkeypatch.setattr(package, 'build_bundle', lambda *args: (b'new code', b'{"files":[]}\n', 'a'*64, dict(contained_backend_imports=True)))
    shutil.copytree(original_site, stage / 'site')
    (stage / 'site/release-manifest.json').unlink()
    put(patch, 'ui/graph-full-v6.js', b'frozen KG')
    put(patch, 'ui/graph-full-v6.css', b'frozen CSS')
    put(stage, 'stage_receipt.json', receipt)
    package.freeze(stage, work, actual, gate)
    package.prepare(stage, work, gate)
    site = stage / 'site'
    assert read(site / 'graph-full-v6.js') == b'frozen KG'
    assert read(site / 'graph-full-v6.css') == b'frozen CSS'
    assert read(site / 'runtime/public-runtime.js') == b'frozen runtime'
    assert read(site / 'data/api-index.json') == encoded(dict(entries={}))
    assert read(site / 'docs/matryoshka-guide.pdf') == b'original guide'
    assert load(read(stage / 'stage_receipt.json'))['native_versions'] == receipt['native_versions']
    prepared = load(read(work / 'prepare.json'))
    evidence = put(patch, 'qa/fresh.json', dict(status='PASS'))
    qa = dict(version='kg-scoped-s2-post-prepare-qa/3', status='PASS', prepared_sha256=sha(read(work / 'prepare.json')),
              site_inventory_sha256=prepared['site_inventory_sha256'], evidence=[dict(path='qa/fresh.json', sha256=sha(read(evidence)))])
    for flag in ('browser_desktop', 'browser_mobile', 'source_and_binding_regressions', 'slot_context_navigation_only',
                 'scoped_s2_both_actual_tabs_unknown_gold', 'archived_lexical_separate', 'ordinary_native_integrity_accepted'):
        qa[flag] = True
    qa_path = put(work, 'qa.json', qa)
    if attack == 'changed-index': put(site, 'data/api-index.json', dict(entries={'changed': {}}))
    elif attack == 'changed-css': put(site, 'graph-full-v6.css', b'changed')
    elif attack == 'changed-receipt': put(stage, 'stage_receipt.json', dict(changed=True))
    elif attack == 'stale-qa':
        qa['prepared_sha256'] = '0'*64
        put(work, 'qa.json', qa)
    elif attack == 'failed-qa':
        qa['scoped_s2_both_actual_tabs_unknown_gold'] = False
        put(work, 'qa.json', qa)
    elif attack == 'tampered-evidence': put(patch, 'qa/fresh.json', dict(status='FAIL'))
    if attack != 'none':
        with pytest.raises(ValueError):
            package.seal(stage, work, gate, qa_path)
        assert not (site / 'release-manifest.json').exists()
        return
    result = package.seal(stage, work, gate, qa_path)
    assert result['publish_authorized'] is False
    assert result['datasets_rehashed'] is False
    with pytest.raises(ValueError):
        package.seal(stage, work, gate, qa_path)


def test_whitelist_rejects_index_native_or_kg_change():
    before = [dict(path='data/api-index.json', sha256='a'), dict(path='graph-full-v6.js', sha256='b'), dict(path='data/native.gz', sha256='c')]
    for index in range(3):
        after = deepcopy(before)
        after[index]['sha256'] = 'changed'
        with pytest.raises(ValueError):
            package.unchanged_assets(before, after, {'swedish-study.html'})


def test_old_scoped_contract_cannot_be_used_for_attempt03():
    with pytest.raises(ValueError):
        contract.validate(PATCH / 'swedish/isolated_engine/SCOPED_RELEASE_CONTRACT_v03.json',
                          '5d7759a6083669dafff7b94b7b1dfe64b68bcdd8da0242e97200f555b798f1eb')


@pytest.mark.parametrize('target', ['display', 'private-completion', 'public-completion'])
def test_attempt02_versions_are_not_reinterpreted(pair, target):
    row, query, execution, completion, public, code = pair
    if target == 'display': row['execution_version'] = 'narrative-scoped-source-study-execution/2'
    elif target == 'private-completion': completion['version'] = 'scoped-study-execution-completion/2'
    else: public['version'] = 'scoped-study-public-completion/2'
    with pytest.raises(ValueError):
        contract.validate_display(row, query, execution, completion, public, code)
