"""Versioned source composition and deterministic outward-facing guide bytes."""
import ast
from copy import deepcopy
import io
from pathlib import Path
import sys
import textwrap
from reserve_support import reserve_source

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import build_addendum as accepted_guide
from release_common import require, read


def smoke_source(base=None):
    base = read(HERE.parent / 'ci/browser_smoke.py').decode() if base is None else base
    nodes = [n for n in ast.walk(ast.parse(base)) if isinstance(n, ast.FunctionDef) and n.name == 'swedish']
    require(len(nodes) == 1, 'Ambiguous accepted Swedish CI seam')
    node = nodes[0]
    operation = ast.parse(read(HERE / 'smoke_operation.py')).body[-1]
    require(isinstance(operation, ast.FunctionDef) and operation.name == 'swedish', 'Missing scoped smoke operation')
    replacement = ast.get_source_segment(read(HERE / 'smoke_operation.py').decode(), operation)
    lines = base.splitlines(keepends=True)
    result = ''.join(lines[:node.lineno-1]) + textwrap.indent(replacement, ' ' * node.col_offset) + '\n' + ''.join(lines[node.end_lineno:])
    result = reserve_source(result)
    compile(result, 'ci/browser_smoke.py', 'exec')
    return result.encode()


def addendum():
    pages = deepcopy(accepted_guide.PAGES)
    pages[3] = ('04', 'Two Executed Queries', 'S2 by default / exact sources / reference unknown', [
        ('Read The Actual Results', 'First query and Second query now open results from two actual, bounded shared-kernel executions. '
         'S2 is selected without an acknowledgment gate. Facts are query-derived planning propositions, not established world facts. '
         'Readings are model-selected grammatical alternatives. Choose a reading to inspect its own results and quotations.'),
        ('The Same Narrow Source Exception', 'Both queries use later-release prior documents plus the exact origin '
         'CIA-RDP79T00975A004300220001-9 on 1959-02-17. Unrelated same-day and future reports remain excluded. '
         'Permission and quarantine checks are retained. This study-specific exception does not apply to ordinary cases.'),
        ('Do Not Substitute The Archive', 'The withheld answers remain unknown. The executed results need not include Swedish. '
         'The older lexical nomination of Swedish remains under archived-study details, separate from the actual results. '
         'It is not a recovered answer, a new engine nomination or a rank to transplant into an empty result. These scoped '
         'runs have their own declared source-policy and execution versions; they are not unchanged canonical native runs.'),
    ])
    pages[4] = ('05', 'Inspect Before Concluding', 'Input / Facts / Readings / Sources / Results', [
        ('A Bounded Comparison', 'Both queries use the same retrieval and construction budgets: 40 documents, up to 80 retrieval '
         'pages, 20 inspected constructor pages and 24 checked drafts per reading. Those are search limits, not completeness '
         'claims about every potentially relevant source. Changing the reading changes the grammatical question being tested.'),
        ('Separate Source Observations', 'Repeated normalized surface forms are grouped before the five-result cap. Inspect '
         'the separate source variants: their literal quotations and individual decisions remain distinct. A union of '
         'quotations does not establish a shared identity or turn several uncertain observations into pooled proof.'),
        ('Bind The Source Occurrence', 'A complete producer window plus its declared job-local mapping binds the source occurrence. '
         'An identical quotation elsewhere does not authorize relocation or a direct-page fallback. Earlier-view coordinates '
         'require pinned full-page earlier/later identity; otherwise the observation is held. Document, date, record and '
         'view identities must agree before any quotation is accepted.'),
    ])
    objects = [b'<< /Type /Catalog /Pages 2 0 R >>', b'',
        b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
        b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>',
        b'<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >>']
    ids = []
    for number, title, subtitle, sections in pages:
        stream = accepted_guide.draw_page(number, title, subtitle, sections)
        content = len(objects) + 1
        objects.append(b'<< /Length ' + str(len(stream)).encode() + b' >>\nstream\n' + stream + b'endstream')
        ids.append(len(objects) + 1)
        objects.append(('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] '
            '/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> '
            f'/Contents {content} 0 R >>').encode())
    objects[1] = ('<< /Type /Pages /Count 5 /Kids [' + ' '.join(f'{n} 0 R' for n in ids) + '] >>').encode()
    output = io.BytesIO()
    output.write(b'%PDF-1.4\n')
    offsets = [0]
    for number, raw in enumerate(objects, 1):
        offsets.append(output.tell())
        output.write(f'{number} 0 obj\n'.encode() + raw + b'\nendobj\n')
    xref = output.tell()
    output.write(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:
        output.write(f'{offset:010d} 00000 n \n'.encode())
    output.write(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    text = ('\n\n'.join(f'{n} / {title}\n{subtitle}\n\n' + '\n\n'.join(h + '\n' + body for h,body in sections)
                        for n,title,subtitle,sections in pages) + '\n').encode('ascii')
    return output.getvalue(), text
