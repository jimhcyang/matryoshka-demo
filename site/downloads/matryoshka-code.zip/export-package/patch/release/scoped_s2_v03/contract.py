"""Validate explicit Attempt03 release bytes, without a canonical-native claim."""
from copy import deepcopy
from html.parser import HTMLParser
from pathlib import Path
import re
import sys
from xml.etree import ElementTree

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
from release_common import PATCH, SOURCE, encoded, load, pinned, public_json, relative, require, sha, within
from package_release import decode_packet

VERSION = 'swedish-scoped-shared-kernel-integration/1'
EXECUTION = 'narrative-scoped-source-study-execution/3'
DISPLAY = 'scoped-shared-kernel-study-display/3'
COMPLETION = 'scoped-study-execution-completion/3'
PUBLIC_COMPLETION = 'scoped-study-public-completion/3'
STUDY = 'swedish-scoped-shared-kernel-ui/3'
POLICY = 'isolated-explicit-s2-source-admission/1'
COORDINATE_POLICY = 'declared-producer-job-local-coordinates/3'
HASH_SCHEME = 'SHA256_CANONICAL_JSON_STRING_ENSURE_ASCII_TRUE_SORT_KEYS_COMPACT'
ORIGIN, CUTOFF = 'CIA-RDP79T00975A004300220001-9', '1959-02-17'
CONFIGURATION = dict(construction_pages=20, discovery_profile=None, drafts_per_reading=24,
                     retrieval_documents=40, retrieval_pages=80, selection_profile=None, top_k=5)
NAMES = {'swedish-study.html', 'swedish-study.css', 'swedish-study.js', 'swedish-scoped-study-v04.json',
         'swedish-scoped-first-v03.json', 'swedish-scoped-second-v03.json',
         'swedish-scoped-first-completion-v03.json', 'swedish-scoped-second-completion-v03.json',
         'scoped-engine-source-manifest-v03.json'}


def digest(value):
    return sha(encoded(value).removesuffix(b'\n'))


def keys(value, required, optional=()):
    require(isinstance(value, dict) and set(required) <= set(value)
            and set(value) <= set(required) | set(optional), 'Unsupported contract fields')


def ref(value):
    keys(value, ('path', 'sha256'))
    relative(value['path'])
    require(re.fullmatch('[a-f0-9]{64}', value['sha256']) is not None, 'Invalid reference hash')
    return value


def executed(value):
    require('gold' in value and value['gold'] is None and value.get('execution_performed') is True
            and value.get('canonical_native_run') is False, 'Expected actual noncanonical execution with unknown gold')


def decision(value):
    return {k: deepcopy(value[k]) for k in ('id', 'status', 'label', 'scope', 'coverage', 'counterevidence', 'checklist') if k in value}


def expected_readings(result):
    rows = []
    for reading in result['readings']:
        candidates = []
        for candidate in reading['candidates']:
            group = candidate['surface_duplicate_group']
            value = {k: deepcopy(candidate[k]) for k in ('id', 'rank', 'fill', 'local_decision', 'source_wording', 'source_span', 'sources')}
            value.update(citation_union=deepcopy(group['citation_union']), source_variants=deepcopy(group['source_variants']),
                         identity_merged=False, union_is_support_proof=False)
            value['raw_decision_digest'] = digest(value['local_decision'])
            value['local_decision'] = decision(value['local_decision'])
            for variant in value['source_variants']:
                variant['raw_decision_digest'] = digest(variant['local_decision'])
                variant['local_decision'] = decision(variant['local_decision'])
            candidates.append(value)
        require(len(candidates) <= 5 and [c['rank'] for c in candidates] == list(range(1, len(candidates) + 1)), 'Invalid actual rank sequence')
        rows.append(dict(reading=reading['reading'], candidates=candidates))
    return rows


class StudyPin(HTMLParser):
    def __init__(self):
        super().__init__()
        self.pins = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == 'meta' and values.get('name') == 'study-data-sha256':
            self.pins.append(values.get('content'))


def snapshot(code, source, engine):
    keys(code, ('parent_snapshot_ref', 'variant_snapshot_ref', 'inherited_variant_ref', 'public_metadata_ref',
                'python_source_allowlist', 'executed_snapshot_identity'))
    _, parent_raw = pinned(source, ref(code['parent_snapshot_ref']))
    _, variant_raw = pinned(source, ref(code['variant_snapshot_ref']))
    parent, variant = public_json(parent_raw), public_json(variant_raw)
    _, inherited_raw = pinned(source, ref(code['inherited_variant_ref']))
    inherited = public_json(inherited_raw)
    require(parent['version'] == 'isolated-narrative-s2-source-snapshot/1'
            and parent['canonical_files_modified'] is False and parent['in_place_global_monkeypatching'] is False,
            'Parent snapshot changed canonical guards')
    require(inherited['version'] == 'scoped-engine-v02-delta/1'
            and inherited['canonical_engine_modified'] is False
            and inherited['parent_snapshot_sha256'] == code['parent_snapshot_ref']['sha256'], 'Inherited source lineage mismatch')
    require(variant['version'] == 'scoped-engine-v03-coordinate-delta/1' and variant['canonical_engine_modified'] is False
            and variant['additional_model_calls'] == 0 and variant['parent_variant_ref'] == code['inherited_variant_ref']
            and variant['coordinate_policy_version'] == COORDINATE_POLICY
            and variant['producer_offsets_always_job_local'] is True and variant['direct_page_quote_fallback'] is False
            and variant['earlier_tag_requires_pinned_full_page_earlier_later_identity'] is True
            and variant['previous_attempts_preserved'] is True, 'Attempt03 coordinate/source lineage mismatch')
    files = {}
    for item in code['python_source_allowlist']:
        path, raw = pinned(source, ref(item))
        require(path.suffix == '.py' and (path.is_relative_to(engine) or path == engine.parent / 'scoped_context.py'),
                'Only allowlisted isolated/parent Python may enter code ZIP')
        name = path.relative_to(source).as_posix()
        require(name not in files and '__pycache__' not in path.parts, 'Duplicate isolated Python')
        compile(raw, name, 'exec')
        files[name] = raw
    require(files, 'Empty explicit Python source allowlist')
    metadata_rows = []
    for item in parent['files']:
        keys(item, ('source', 'source_sha256', 'snapshot', 'snapshot_sha256'), ('diff',))
        name = (engine / relative(item['snapshot'])).relative_to(source).as_posix()
        require(name in files and sha(files[name]) == item['snapshot_sha256'], 'Parent snapshot Python missing or changed')
        relative(item['source'])
        pinned(source, dict(path=item['source'], sha256=item['source_sha256']))
        metadata_rows.append({k: item[k] for k in ('source', 'source_sha256', 'snapshot', 'snapshot_sha256')})
    for item in inherited['files']:
        keys(item, ('new_source', 'new_sha256', 'parent_source', 'parent_sha256'), ('diff',))
        name = (engine / relative(item['new_source'])).relative_to(source).as_posix()
        parent_name = (engine / relative(item['parent_source'])).relative_to(source).as_posix()
        require(name in files and sha(files[name]) == item['new_sha256']
                and parent_name in files and sha(files[parent_name]) == item['parent_sha256'], 'Variant Python lineage changed')
        metadata_rows.append(dict(source='isolated_engine/' + item['parent_source'], source_sha256=item['parent_sha256'],
                                  snapshot=item['new_source'], snapshot_sha256=item['new_sha256']))
    for item in variant['files']:
        keys(item, ('new_source', 'new_sha256', 'parent_source', 'parent_sha256'), ('diff',))
        for name, expected in ((item['new_source'], item['new_sha256']), (item['parent_source'], item['parent_sha256'])):
            target = (engine / relative(name)).relative_to(source).as_posix()
            require(target in files and sha(files[target]) == expected, 'Job-local adapter diff lineage changed')
    for name, expected in variant['version_three_code_pins'].items():
        target = (engine / relative(name)).relative_to(source).as_posix()
        require(target in files and sha(files[target]) == expected, 'Executed Attempt03 source missing or changed')
        metadata_rows.append(dict(source=name, source_sha256=expected, snapshot=name, snapshot_sha256=expected))
    expected = dict(version='scoped-engine-public-source-metadata/1', canonical_files_modified=False,
                    global_monkeypatching=False, execution_version=EXECUTION, source_policy_version=POLICY, files=metadata_rows)
    _, public_raw = pinned(source, ref(code['public_metadata_ref']))
    require(public_json(public_raw) == expected, 'Public metadata is not the exact allowlisted source projection')
    identity = digest(dict(parent_snapshot=code['parent_snapshot_ref'], variant_snapshot=code['variant_snapshot_ref'],
                           python_sources=code['python_source_allowlist']))
    require(identity == code['executed_snapshot_identity'], 'Executed snapshot identity mismatch')
    return files, expected


def source_view(value):
    keys(value, ('binding', 'view_sha256', 'rss_peak_mb', 'coordinate_audit_ref'))
    binding = value['binding']
    require(value['view_sha256'] == digest(binding) and binding['version'] == 'full-later-source-view/1'
            and binding['verified_source_bytes'] is True and binding['actual_release'] == 'later'
            and binding['complete_eligible_source_page_universe'] is True, 'Unverified later source view')
    require(binding['source_scope'] == dict(version='explicit-scoped-source-view-prototype/1', corpus='cib',
            cutoff=CUTOFF, exact_origin_at_cutoff=True, origin=ORIGIN, release='later'), 'S2 scope changed')
    require(isinstance(binding['source_pins'], dict) and binding['source_pins'], 'Missing source pins')
    require(binding['offsets'] == COORDINATE_POLICY, 'Old/global-fallback coordinate policy is not accepted')
    require(binding['earlier_coordinate_policy'] ==
            'Only pinned earlier/later full-page identity permits earlier-window coordinates; otherwise held, never aligned or searched',
            'Earlier/later full-page identity policy changed')
    ref(binding['source_pins']['earlier_pages_identity_proof'])


def coordinate_audit(audit, context, declaration):
    require(audit['version'] == 'old-new-producer-coordinate-audit/1'
            and audit['new_coordinate_version'] == COORDINATE_POLICY
            and audit['full_population_occurrence_resolution_comparison'] is True
            and audit['historical_old_materialized_graph_reconstructed'] is False,
            'Coordinate audit is incomplete or claims an unperformed graph reconstruction')
    require(digest(audit) == context['binding']['coordinate_audit_sha256'], 'Context coordinate audit digest differs')
    require(declaration['policy_version'] == COORDINATE_POLICY and declaration['direct_page_fallback'] is False
            and declaration['earlier_requires_full_page_identity'] is True
            and declaration['counts'] == audit['counts'] and declaration['scope'] == audit['scope'],
            'Public coordinate declaration does not match the pinned streamed audit')


def validate_display(row, query, execution, completion, public, code):
    require(row['version'] == DISPLAY and execution['version'] == EXECUTION, 'Unsupported executed/display version')
    require(row['execution_version'] == EXECUTION, 'A /2 execution cannot be relabeled as /3')
    executed(row)
    executed(execution)
    require(execution['api_calls'] == 0, 'Attempt03 must reuse cached planning without new API calls')
    require(execution['original_canonical_native_run'] is False and execution['parent_workflow'] == 'narrative-local-execution/3', 'Canonical native claim')
    case = execution['case']
    require(case == row['case'] == query['public_case'] and case['corpus'] == 'cib'
            and case['document_id'] == ORIGIN and case['date'] == CUTOFF
            and case['query'].count('[MASK]') == 1 and case['query'].count('[REDACTED]') == 2, 'Masked query/origin changed')
    require(row['position'] == query['position'] and execution['configuration'] == CONFIGURATION
            and row['facts'] == execution['plan']['atoms'], 'Facts/profile/position changed')
    result = execution['result']
    checksum = digest(result)
    require(execution['native_checksum'] == checksum and execution['source_citations_replayed'] > 0, 'Result/citation audit failed')
    require(row['readings'] == expected_readings(result), 'Actual rank, decision, quotation or variant changed')
    require(row['inspected_page_count'] == result['source_pages_inspected']
            and row['execution_ref'] == dict(sha256=query['private_execution_ref']['sha256'])
            and 'source_context_ref' not in row, 'Only the execution audit hash may enter the public display')
    require(execution['source_snapshot_ref'] == code['parent_snapshot_ref']
            and execution['engine_manifest_ref'] == code['variant_snapshot_ref'], 'Execution snapshot mismatch')
    require(completion['version'] == COMPLETION and completion['execution_performed'] is True
            and completion['original_canonical_native_completion'] is False and completion['gold'] is None
            and completion['execution_ref'] == query['private_execution_ref']
            and completion['execution_digest'] == digest(execution) and completion['native_checksum'] == checksum, 'Private completion mismatch')
    keys(public, ('version', 'execution_performed', 'canonical_native_run', 'gold', 'case_id', 'position',
                  'public_display_ref', 'query_sha256', 'query_utf8_sha256', 'query_hash_scheme', 'source_view_sha256',
                  'source_policy_version', 'executed_snapshot_identity', 'raw_result_audit_digest',
                  'private_execution_wire_sha256', 'private_execution_completion_sha256', 'coordinate_policy_version'))
    require(public['version'] == PUBLIC_COMPLETION, 'Unsupported public completion version')
    executed(public)
    require(execution['coordinate_policy_version'] == completion['coordinate_policy_version'] == COORDINATE_POLICY,
            'Execution/completion coordinate policy mismatch')
    require(public['case_id'] == case['case_id'] and public['position'] == query['position']
            and public['private_execution_wire_sha256'] == query['private_execution_ref']['sha256']
            and public['private_execution_completion_sha256'] == query['private_execution_completion_ref']['sha256'], 'Completion substitution')
    for item in (row, public, query):
        require(item['query_sha256'] == execution['query_sha256'] == digest(case['query'])
                and item['query_utf8_sha256'] == sha(case['query'].encode()) and item['source_policy_version'] == POLICY
                and item['source_view_sha256'] == execution['source_view_sha256']
                and item['executed_snapshot_identity'] == code['executed_snapshot_identity']
                and item['raw_result_audit_digest'] == checksum
                and item['coordinate_policy_version'] == COORDINATE_POLICY, 'Query/policy/view/snapshot/result binding mismatch')
    require(row['query_hash_scheme'] == public['query_hash_scheme'] == HASH_SCHEME, 'Unknown query hash scheme')
    require(public['public_display_ref'] == dict(path=Path(query['public_projection_ref']['path']).name,
                                               sha256=query['public_projection_ref']['sha256']), 'Public display pin mismatch')


def archive_files(value, source, patch):
    keys(value, ('integration_ref', 'archive_default', 'archived_ui_source_overrides', 'data_manifest_ref', 'assets'))
    require(value['archive_default'] is False, 'Archive cannot be default')
    _, old_raw = pinned(source, ref(value['integration_ref']))
    old = public_json(old_raw)
    require(old['version'] == 'swedish-patch-integration-handoff/1' and old['native_execution'] is False, 'Archive relabeled native')
    require(value['assets'] == [r for r in old['copies'] if r['destination'].endswith('.json')], 'Archived asset set changed')
    files = {}
    for item in value['assets']:
        path, raw = pinned(source, ref(item['source']))
        require(path.is_relative_to(patch / 'swedish/artifacts_v01'), 'Foreign archive asset')
        files[relative(item['destination'])] = raw
    require(len(value['archived_ui_source_overrides']) == 3, 'Missing historical UI')
    for item in value['archived_ui_source_overrides']:
        original = ref(item['original_source_ref'])
        path, raw = pinned(source, ref(item['archived_source_ref']))
        require(path.is_relative_to(patch / 'swedish/archived-ui-v03') and sha(raw) == original['sha256']
                and any(r['source'] == original for r in old['copies']), 'Archived UI mismatch')
    require(value['data_manifest_ref'] in [r['source'] for r in value['assets']], 'Unpinned archived manifest')
    manifest = public_json(files[Path(value['data_manifest_ref']['path']).name])
    require(manifest['native_execution'] is False and manifest['gold'] is None, 'Historical false-native fields changed')
    return files, manifest


def validate(path, pin, *, source=SOURCE, patch=PATCH):
    engine = patch / 'swedish/isolated_engine'
    path = within(patch / 'swedish', path)
    handoff_path = path
    _, raw = pinned(source, dict(path=path.relative_to(source).as_posix(), sha256=pin))
    value = public_json(raw)
    keys(value, ('version', 'default_view', 'default_policy', 'execution_performed', 'canonical_native_run', 'parent_workflow',
                 'gold', 'execution_contract', 'copies', 'queries', 'archived_study_ref', 'code_snapshot_ref', 'tests',
                 'existing_dependencies', 'budget', 'stage_modified', 'index_modified', 'publish_performed',
                 'full_context_or_private_execution_public_copy', 'coordinate_provenance'),
         ('presentation_revision', 'previous_integration_ref', 'archived_actual_ui', 'preview_contract_ref'))
    require(value['version'] == VERSION and value['default_view'] == 'scoped_shared_kernel' and value['default_policy'] == 'S2', 'Unsupported integration/default')
    executed(value)
    require(value['parent_workflow'] == 'narrative-local-execution/3' and all(value[k] is False for k in
        ('stage_modified', 'index_modified', 'publish_performed', 'full_context_or_private_execution_public_copy')), 'Unexpected producer side effects')
    require(value['execution_contract'] == dict(execution=EXECUTION, display=DISPLAY, public_completion=PUBLIC_COMPLETION,
            source_policy=POLICY, coordinate_policy=COORDINATE_POLICY, snapshot='scoped-engine-v03-coordinate-delta/1', canonical_native_run=False,
            parent_workflow='narrative-local-execution/3'), 'Execution contract differs')
    copies, copy_refs = {}, {}
    for item in value['copies']:
        keys(item, ('source', 'destination'))
        name = relative(item['destination'])
        require(name in NAMES and name not in copies, 'Unexpected/repeated public destination')
        src, data = pinned(source, ref(item['source']))
        require(src.parent == engine / 'ui_v07', 'Copy outside the Attempt03 public projection directory')
        if name.endswith('.json'):
            public_json(data)
        copies[name], copy_refs[name] = data, item['source']
    require(set(copies) == NAMES, 'Exactly nine named public assets required')
    if 'previous_integration_ref' in value:
        _, previous_raw = pinned(source, ref(value['previous_integration_ref']))
        previous = public_json(previous_raw)
        require(previous['version'] == VERSION, 'Unknown previous presentation contract')
        require(previous['execution_contract']['execution'] == 'narrative-scoped-source-study-execution/2',
                'Expected preserved /2 history, not a substituted default /3 run')
        require(len(value.get('archived_actual_ui', [])) == 3, 'Missing archived actual UI')
        for item in value['archived_actual_ui']:
            path, data = pinned(source, ref(item['archived_source_ref']))
            require(path.is_relative_to(patch / 'swedish/archived-ui-v04')
                    and sha(data) == ref(item['original_source_ref'])['sha256'], 'Archived actual UI changed')
    study_name = 'swedish-scoped-study-v04.json'
    study = public_json(copies[study_name])
    require(study['version'] == STUDY and study['default_policy'] == 'S2' and study['configuration'] == CONFIGURATION, 'Study contract/budget mismatch')
    executed(study)
    parser = StudyPin()
    parser.feed(copies['swedish-study.html'].decode('utf-8'))
    require(parser.pins == [sha(copies[study_name])], 'HTML study pin mismatch')
    require([r['position'] for r in value['queries']] == ['first', 'second'] and len(study['cases']) == len(study['public_completions']) == 2, 'Exactly two ordered runs required')
    code_files, metadata = snapshot(value['code_snapshot_ref'], source, engine)
    require(study['executed_snapshot_identity'] == value['code_snapshot_ref']['executed_snapshot_identity']
            and study['coordinate_policy_version'] == COORDINATE_POLICY, 'UI snapshot/coordinate policy changed')
    require(public_json(copies['scoped-engine-source-manifest-v03.json']) == metadata, 'Public metadata copy mismatch')
    archives, archive_manifest = archive_files(value['archived_study_ref'], source, patch)
    audits, private_inputs, displays = [], [], []
    for number, query in enumerate(value['queries']):
        display_ref, public_ref = ref(query['public_projection_ref']), ref(query['public_completion_ref'])
        display_name, public_name = Path(display_ref['path']).name, Path(public_ref['path']).name
        for query_ref in (display_ref, public_ref):
            source_path, query_data = pinned(source, query_ref)
            require(source_path.parent == engine / 'ui_v07'
                    and query_data == copies[source_path.name], 'Query public data differs from copied bytes')
        require(sha(copies[display_name]) == display_ref['sha256'] and sha(copies[public_name]) == public_ref['sha256']
                and study['cases'][number] == dict(path=display_name, sha256=display_ref['sha256'])
                and study['public_completions'][number] == dict(path=public_name, sha256=public_ref['sha256']), 'Swapped query/completion')
        row, public = public_json(copies[display_name]), public_json(copies[public_name])
        exec_path, execution_wire = pinned(source, ref(query['private_execution_ref']))
        comp_path, completion_raw = pinned(source, ref(query['private_execution_completion_ref']))
        require(exec_path == engine / 'attempt03' / query['position'] / 'execution.json.gz'
                and comp_path == engine / 'attempt03' / query['position'] / 'execution-completion.json', 'Unexpected private audit location')
        execution, completion = load(decode_packet(execution_wire, 100_000_000)), load(completion_raw)
        validate_display(row, query, execution, completion, public, value['code_snapshot_ref'])
        for name, expected in execution['canonical_code_pins'].items():
            require(name.startswith(('matryoshka_', 'contracts/')) and Path(name).suffix in {'.py', '.json'}, 'Unexpected canonical code pin')
            pinned(source, dict(path=name, sha256=expected))
        _, context_raw = pinned(source, ref(execution['source_context_ref']))
        context = load(context_raw)
        source_view(context)
        require(context['view_sha256'] == row['source_view_sha256'], 'Source view changed')
        audit_ref = ref(execution['coordinate_audit_ref'])
        require(audit_ref == context['coordinate_audit_ref'] == value['coordinate_provenance']['audit_ref'], 'Coordinate audit pin mismatch')
        _, audit_raw = pinned(source, audit_ref)
        audit = load(audit_raw)
        coordinate_audit(audit, context, value['coordinate_provenance'])
        require(study['coordinate_audit_summary'] == dict(counts=audit['counts'], held_reasons=audit['held_reasons'],
                    ordered_row_resolution_sha256=audit['ordered_row_resolution_sha256']), 'UI coordinate summary differs')
        declared = {name: sha(data) for name,data in code_files.items()}
        executed_sources = {r['path']: r['sha256'] for r in execution['inherited_python_source_pins']}
        executed_sources.update({(engine / relative(name)).relative_to(source).as_posix(): expected
                                 for name,expected in execution['variant_code_pins'].items()})
        require(declared == executed_sources, 'Explicit source allowlist must equal the dynamically derived executed closure')
        for name, expected in execution['variant_code_pins'].items():
            target = (engine / relative(name)).relative_to(source).as_posix()
            require(target in code_files and sha(code_files[target]) == expected, 'Executed variant changed')
        old_ref = archive_manifest['cases'][number]
        old = public_json(archives[old_ref['path']])
        require(sha(archives[old_ref['path']]) == old_ref['sha256'] and old['public_case'] == row['case'], 'Archived case changed')
        old_records = [r for r in old['records'] if r['profile_id'] == 'bridge_v2' and r['policy_id'] == 'S2']
        require(len(old_records) == 1, 'Ambiguous archive')
        record = old_records[0]
        expected_archive = dict(execution_kind='ARCHIVED_LEXICAL_NOT_THIS_EXECUTION', native_execution=False,
            saved_record_sha256=record['saved_record_sha256'],
            candidates=[{k: c[k] for k in ('rank', 'fill', 'source', 'context')} for c in record['candidates']])
        require(row['archived_lexical'] == expected_archive, 'Archive ranks transplanted or changed')
        audits.append(dict(position=query['position'], case_id=row['case']['case_id'], execution_audit_sha256=query['private_execution_ref']['sha256'],
                           result_sha256=execution['native_checksum'], source_view_sha256=context['view_sha256'], public_display_ref=study['cases'][number]))
        private_inputs.extend((query['private_execution_ref'], query['private_execution_completion_ref'], execution['source_context_ref']))
        private_inputs.append(audit_ref)
        displays.append(row)
    require(len({a['case_id'] for a in audits}) == 2, 'Repeated first query substituted for second')
    require(value['tests']['receipts'], 'Missing producer tests')
    for test_ref in value['tests']['receipts']:
        test_path, test_raw = pinned(source, ref(test_ref))
        require(test_path.is_relative_to(patch / 'swedish/coordinate_tests_v03') and test_path.suffix == '.xml', 'Expected Attempt03 XML tests')
        suites = list(ElementTree.fromstring(test_raw).iter('testsuite'))
        require(suites and sum(int(s.get('tests', 0)) for s in suites) > 0
                and not any(int(s.get('failures', 0)) or int(s.get('errors', 0)) or int(s.get('skipped', 0)) for s in suites), 'Producer tests failed/skipped')
    return dict(manifest=value, manifest_ref=dict(path=handoff_path.relative_to(source).as_posix(), sha256=pin),
                copies=copies, study=study, displays=displays, code_files=code_files, code_metadata=metadata,
                archive_files=archives, audits=audits, private_inputs=private_inputs,
                public_assets=[dict(path=n, sha256=sha(data)) for n, data in sorted(copies.items())])
