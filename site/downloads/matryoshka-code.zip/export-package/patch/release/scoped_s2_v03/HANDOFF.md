# Attempt03 Packaging Handoff

Helper implementation is ready. Main must finish final renderer-byte QA before
declaring a freeze. No real freeze/prepare/seal, API call, native execution,
server/browser launch, installation or git operation was run by this task.
The real contract/stage preflight was READ-ONLY. All packaging tests use tiny
fixture stages under this directory, never the real main-owned stage.

Earlier v01/v02 helpers, guides, source snapshots, receipts, failures and study
attempts are preserved in place. Do not use the rejected /2 contract v03 as
the release default. This helper accepts exactly execution/display/completion
`/3` and the declared job-local coordinate policy, not a relabeled /2 packet.

## Exact Files

- `package_release_v03.py`: read-only preflight, freeze, prepare, fresh QA seal.
- `contract.py`: exact v04 schema, source/execution/coordinate/public bindings.
- `assets.py`, `smoke_operation.py`, `reserve_support.py`: deterministic CI/PDF builders.
- `ci/browser_smoke.py`: NEW INSTALLER CI SOURCE, actual /3 controls plus explicit reserve.
- `kg-patch-addendum-scoped-s2-v03.pdf` and `.txt`: new five-page job-local guide.
- `test_scoped_release.py`, `test_job_local.py`, `test_reserve_support.py`: focused tests.
- `tests-v01.xml`: 37 passed; `tests-v02.xml`: 51 passed; `tests-v03.xml`: 55 passed.
- `post-prepare-qa.example.json`: schema example, not an approval or QA result.
- `addendum-preview-page5.png`: rendered source-occurrence page for inspection.
- `HANDOFF.md`: this handoff. `test-tmp-v*` directories contain tiny fixtures only.

The exact CI source path for main's installer is:
`src-demo-day/phase/kg_patch_20261122/release/scoped_s2_v03/ci/browser_smoke.py`.
Neither earlier `release/ci/` nor `scoped_s2_v02/ci/` is the current CI source.

## Exact Pins

Contract, PATCH-root-relative:
`swedish/isolated_engine/SCOPED_RELEASE_CONTRACT_v04.json`
SHA `ae7bc8d2b8e165c4887aa205c0474519559be254c87864e4c072b5095f960a99`.

Producer QA:
`swedish/isolated_engine/FINAL_QA_v02.json`
SHA `08fa24fc4864c391ba190529fec1df60893715aa8114c47251d24cfdd0017c41`.

The read-only preflight passed: nine ui_v07 public copies, 25 dynamically
allowlisted Python sources, both actual Attempt03 executions, private and
public completions, canonical-JSON/UTF-8 query hashes, source-view/snapshot
identities, exact public rank/decision/quotation variants, archived comparison
separation, pinned coordinate audit and producer 136-test XML with no skips or
expected failures. All four formerly failing provenance requirements must be
recorded as passing in the producer QA. Prior legacy fixture limitations are
retained, not recast as a whole-repository PASS.

The helper verifies declared source bytes and audit identities; it does not
rebuild the full context or independently reconstruct the prior materialized
graph. The source hierarchy pin is observed, not producer-declared. These
limitations remain in lineage. Unknown gold, canonical_native_run=false and
separate archived lexical results remain mandatory. Swedish is NOT required
in the actual results. Historical /2 outputs cannot satisfy current /3 checks.

## Main Commands

From workspace root. The read-only check has been run. Freeze/prepare/seal
commands below are for MAIN and have NOT been run. Use a NEW work directory.

```sh
P=src-demo-day/phase/kg_patch_20261122
R=$P/release/scoped_s2_v03
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B "$R/package_release_v03.py" --check-handoff --contract-ref "$P/swedish/isolated_engine/SCOPED_RELEASE_CONTRACT_v04.json" --contract-pin ae7bc8d2b8e165c4887aa205c0474519559be254c87864e4c072b5095f960a99
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B "$R/package_release_v03.py" --freeze --work "$R/runs/final-v04" --contract-ref "$P/swedish/isolated_engine/SCOPED_RELEASE_CONTRACT_v04.json" --contract-pin ae7bc8d2b8e165c4887aa205c0474519559be254c87864e4c072b5095f960a99 --producer-qa-ref "$P/swedish/isolated_engine/FINAL_QA_v02.json" --producer-qa-pin 08fa24fc4864c391ba190529fec1df60893715aa8114c47251d24cfdd0017c41
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B "$R/package_release_v03.py" --prepare --work "$R/runs/final-v04"
```

Freeze requires matching source/staged graph JS and CSS bytes and captures the
exact current source/UI/installed-tool closure and stage inventory. Main must
sync and QA its final renderer first. No renderer hash is hardcoded to an older
revision; the latest main helpers are selected, including `verify_live.py`,
`install_patch.py`, `authorize_patch.py`, `verify_native_roots.py` and the binding
helper. Keep generated native/integrity receipts in QA/work subdirectories,
not top-level source JSON. Do not edit frozen source files afterward.

Prepare leaves the entire API index, existing slot packet paths, public runtime,
KG JS/CSS/HTML, ordinary report/case/native/source-page packets and old guide
unchanged. Index remains
`67e1901e204a5a0d6f3ad06f28bf60caeaa905882c84ac4b27013563c6468c3e`.
The 224 original slot-context deltas and 51,877 unchanged non-slot route
bindings are checked against the old baseline. No duplicate 30 MB slot copy,
HTML hook rebind, dataset copy, dataset rehash or full re-export is performed.

Writes are limited to the nine public copies, absent byte-pinned historical
JSON files, code downloads, lineage/publication metadata and separate addendum
assets. Any change outside this whitelist fails. Existing archive bytes may
not be replaced with different bytes. Native version/coverage rows and the
original report-bound guide assets remain intact. Historical asset-lineage
rows are retained and new active Swedish presentation hashes are explicit.

## Fresh Candidate Checks

After prepare, run main's full local candidate/native/integrity/privacy checks
and fresh browser QA. The /3 smoke retains all accepted graph/walk cells;
Swedish checks both actual default tabs, no-ack S2, exact pinned results and
source variants, null gold, separate archive and no private execution fetches.
It does not require a preferred nationality answer.

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B "$R/ci/browser_smoke.py" --site "$P/stage/site" --datasets-root matryoshka_demo_site/datasets --minimum-free-gib 3 --output "$R/runs/final-v04/browser"
```

Managed Chromium headless shell only. The smoke imports the installed transport
closure in the source workspace, or its adjacent contained closure after
installation/extraction. Reserve defaults to 8 GiB; the explicit local option
is 3 GiB, never lower. The code ZIP's active root reader is the installed reader;
historical deploy reader/gate are not edited. Full main validation must use
the installed gate with `--minimum-free-gib 3`, not the historical deploy gate.
The normal CI default remains 8 GiB. The 3 GiB packaging floor is enforced.

Main authors `WORK/post-prepare-qa.json` using the new `/3` example, exact
`prepare.json` byte SHA and `site_inventory_sha256`, with actual fresh evidence
hashes and all seven acceptance booleans. Store it under WORK, not as a new
top-level helper JSON that would invalidate frozen source selection. Main's
ordinary-native acceptance and source review must actually be completed.

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B "$R/package_release_v03.py" --seal --work "$R/runs/final-v04" --qa-ref "$R/runs/final-v04/post-prepare-qa.json"
```

Seal makes a FRESH inventory using existing `gate.make`, rejects stale/missing/
tampered QA or changed sources/site/receipt bytes, and leaves authorization
FALSE. It does not create/adopt approval, run full dataset validation, start
the installer or publish. Main separately runs its full logical/native/dataset
integrity, source/privacy/rights review, browser cells, fresh authorization and
any install/live verification. No previous approval or producer test substitutes
for those requirements.

## Code And Guide

The ZIP retains the full preceding exporter/backend code and historical
replacements, active installed transport/cache/auth tests, and current patch
runtime/tools/UI. The added isolated namespace contains ONLY the dynamically
derived executed Python closure (currently 25 exact files) and one allowlisted
source-metadata JSON. No raw diff, private execution/context, model receipt,
ledger, corpus or source-index data enters it. New public study/display/
completion JSON remains separate site assets. Source path metadata is relative.
All added Python sources are syntax-checked, pinned and matched to the actual
execution closure; no native query is executed to check the package.

The active ZIP smoke is the v03 file above. Expanded code snapshot:
`WORK/base-code/snapshot/export-package/`. Historical native versions are not
rewritten. The backend snapshot and separately versioned scoped source identity
are both hash-bound. Root installed-reader changes preserve their old bytes in
code ZIP history. Current full checker/native helper sources are included;
their output receipts need not be code assets.

The new five-page PDF/text is copied to `docs/kg-patch-addendum.{pdf,txt}` in the
candidate. It explicitly states: a complete producer window plus its declared
job-local mapping binds the occurrence; matching text elsewhere cannot rescue
an invalid window. Earlier-view coordinates require pinned full-page identity.
It makes no old /2 occurrence-certification claim. The original guide and all
earlier helper PDFs remain unchanged. Main chooses final links/artifacts.

Focused reproduction (no real-stage packaging or browser/server):

```sh
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -B -m pytest -q -p no:cacheprovider --basetemp="$R/test-tmp-next" --junitxml="$R/tests-next.xml" "$R/test_scoped_release.py" "$R/test_reserve_support.py" "$R/test_job_local.py"
```

Final local helper tests: 55 passed. Earlier 37/51-test attempts are preserved.
No final main renderer or release-QA PASS is claimed by this handoff.
