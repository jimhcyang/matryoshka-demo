"""Pure, tiny coordinate regressions; no context build or native query execution."""
import ast
from collections import Counter
from copy import deepcopy
import hashlib
import re
from types import SimpleNamespace

import pytest

import contract
from release_common import PATCH, load, read, sha


@pytest.fixture(scope='module')
def resolve():
    engine = PATCH / 'swedish/isolated_engine'
    variant = load(read(engine / 'v03/variant-manifest.json'))
    raw = read(engine / 'v03/coordinates.py')
    assert sha(raw) == variant['version_three_code_pins']['v03/coordinates.py']
    node = next(n for n in ast.parse(raw).body if isinstance(n, ast.FunctionDef) and n.name == 'resolve')
    assert not any(isinstance(n, ast.Attribute) and n.attr in ('find', 'rfind', 'index', 'replace') for n in ast.walk(node))
    module = ast.fix_missing_locations(ast.Module(body=[node], type_ignores=[]))
    scope = dict(digest=contract.digest, hashlib=hashlib, MASK=re.compile(r'\[(?:MASK|REDACTED)\]'))
    exec(compile(module, 'pinned-pure-coordinate-resolver', 'exec'), scope)
    return scope['resolve']


@pytest.fixture
def source():
    prefix, job_text = 'echo text / spacer / ', 'echo text tail'
    text = prefix + job_text
    page = dict(document_id='doc', date='1959-02-16', text=text, source_sha256=contract.digest(text))
    window = dict(coordinate_system='later_canonical_page_text', char_start=len(prefix), char_end=len(text))
    job = ('page', 'doc', '1959-02-16', 'later_only', 'record', window, job_text)
    corpus = SimpleNamespace(source_index={'page': page}, page_index={'page': 0}, verified_earlier_identity_pages=frozenset())
    row = dict(canonical_page_id='page', job_id='job', document_id='doc', document_date_iso='1959-02-16',
               visibility='later_only', record_id='record')
    props = dict(source_provenance=dict(record_id='record', document_date_iso='1959-02-16', document_id='doc'),
                 target_span=deepcopy(window), source_text_sha256=sha(job_text.encode()),
                 char_start=0, char_end=9, evidence_quote='echo text')
    return corpus, {'job': job}, row, props, len(prefix)


def test_global_first_match_cannot_override_declared_job_window(resolve, source):
    corpus, jobs, row, props, base = source
    assert corpus.source_index['page']['text'][:9] == props['evidence_quote']
    assert resolve(row, props, corpus, jobs, Counter()) == (0, base, base + 9, 'echo text')


@pytest.mark.parametrize('failure', ['bounds', 'full-window', 'target-span', 'job-hash', 'bad-tag', 'wrong-view', 'quote-bounds', 'quote-text'])
def test_literal_match_never_rescues_invalid_declared_window(resolve, source, failure):
    corpus, jobs, row, props, _ = source
    job = list(jobs['job'])
    if failure == 'bounds':
        job[5] = dict(job[5], char_start=-1)
        props['target_span'] = deepcopy(job[5])
    elif failure == 'full-window': job[6] += ' mismatch'
    elif failure == 'target-span': props['target_span']['char_start'] = 0
    elif failure == 'job-hash': props['source_text_sha256'] = '0'*64
    elif failure == 'bad-tag':
        job[5] = dict(job[5], coordinate_system='guessed_alignment')
        props['target_span'] = deepcopy(job[5])
    elif failure == 'wrong-view':
        job[3] = row['visibility'] = 'both'
    elif failure == 'quote-bounds': props['char_end'] = 999
    else: props['evidence_quote'] = 'some other literal'
    jobs['job'] = tuple(job)
    assert resolve(row, props, corpus, jobs, Counter()) is None


def test_earlier_coordinates_need_proven_full_page_identity(resolve, source):
    corpus, jobs, row, props, base = source
    job = list(jobs['job'])
    job[3] = row['visibility'] = 'both'
    job[5] = dict(job[5], coordinate_system='earlier_canonical_page_text')
    props['target_span'] = deepcopy(job[5])
    jobs['job'] = tuple(job)
    assert resolve(row, props, corpus, jobs, Counter()) is None
    corpus.verified_earlier_identity_pages = frozenset({'page'})
    assert resolve(row, props, corpus, jobs, Counter()) == (0, base, base + 9, 'echo text')


@pytest.mark.parametrize('field', ['record_id', 'document_id', 'document_date_iso'])
def test_nested_source_identity_cannot_be_defaulted_or_bypassed(resolve, source, field):
    corpus, jobs, row, props, _ = source
    props['source_provenance'][field] = 'wrong'
    with pytest.raises(ValueError):
        resolve(row, props, corpus, jobs, Counter())


def test_version_three_guard_rejects_old_offset_binding():
    execution = dict(gold=None, execution_performed=True, canonical_native_run=False)
    contract.executed(execution)
    assert contract.EXECUTION.endswith('/3') and contract.COMPLETION.endswith('/3')
    assert contract.COORDINATE_POLICY == 'declared-producer-job-local-coordinates/3'
    context = load(read(PATCH / 'swedish/isolated_engine/attempt03/context-binding.json'))
    contract.source_view(context)
    context['binding']['offsets'] = 'EXACT_PAGE_OFFSETS_OR_DECLARED_LATER_JOB_WINDOW_PLUS_LOCAL_OFFSET_FULL_WINDOW_AND_QUOTE_REPLAY_NO_WORD_CHANGES'
    context['view_sha256'] = contract.digest(context['binding'])
    with pytest.raises(ValueError):
        contract.source_view(context)
