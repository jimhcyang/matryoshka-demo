"""Explicit workstation reserve support; installed/package transport only."""
import ast


def reserve_source(source):
    seams = (
        ("sys.path.insert(0, str(Path(__file__).resolve().parents[1]))\n", """tools_root = Path(__file__).resolve().parents[1]
if not (tools_root / 'fragment_reader.py').is_file():
    tools_root = next((parent / 'matryoshka_demo_site/release-tools'
        for parent in Path(__file__).resolve().parents
        if (parent / 'matryoshka_demo_site/release-tools/fragment_reader.py').is_file()), None)
    if tools_root is None:
        raise RuntimeError('Run with the installed or contained release-tools closure')
sys.path.insert(0, str(tools_root))
"""),
        ("    parser.add_argument('--datasets-root', type=Path)\n",
         "    parser.add_argument('--datasets-root', type=Path)\n"
         "    parser.add_argument('--minimum-free-gib', type=int, choices=(3, 8), default=8,\n"
         "                        help='Default CI reserve 8 GiB; explicit bounded-workstation option 3 GiB')\n"),
        ("    reader = Reader(site, out / 'smoke.sqlite3')\n",
         "    reader = Reader(site, out / 'smoke.sqlite3', minimum_free_bytes=args.minimum_free_gib * 1024**3)\n"),
    )
    for before, after in seams:
        if source.count(before) != 1:
            raise ValueError('Ambiguous reserve/transport CI seam')
        source = source.replace(before, after)
    ast.parse(source)
    return source
