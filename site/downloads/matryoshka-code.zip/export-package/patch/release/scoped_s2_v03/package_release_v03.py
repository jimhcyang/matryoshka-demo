"""Scoped S2 freeze/prepare/seal. Reuse the already integrated, immutable KG index."""
import argparse
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import code_snapshot as legacy_bundle
import package_release as legacy
from release_common import (PATCH, SOURCE, WORKSPACE, at, encoded, gate_module, load, pinned,
                            public_json, put_json, read, require, sha, space, within, write)
import assets
import contract

FINAL_QA = PATCH / 'swedish/isolated_engine/FINAL_QA_v02.json'
FINAL_QA_PIN = '08fa24fc4864c391ba190529fec1df60893715aa8114c47251d24cfdd0017c41'
DOC_NAMES = ('docs/kg-patch-addendum.pdf', 'docs/kg-patch-addendum.txt')
META_NAMES = {'export-lineage.json', 'publication.json', 'downloads/matryoshka-code.zip',
              'downloads/matryoshka-code-manifest.json', *DOC_NAMES}


def slot_inputs():
    path, raw = pinned(WORKSPACE, dict(path='src-demo-day/phase/kg_patch_20261122/slots/exact-files.json', sha256=legacy.SLOTS_PIN))
    value = public_json(raw)
    pins = {r['path']: r['sha256'] for r in value['files']}
    overlay_path = at(WORKSPACE, value['authoritative_overlay'])
    require(sha(read(overlay_path)) == pins[value['authoritative_overlay']], 'Slot overlay changed')
    entries = load(read(overlay_path))['entries']
    packets = {}
    for route, entry in entries.items():
        require(legacy.SLOT_ROUTE.fullmatch(route), 'Non-slot sparse route')
        source = at(overlay_path.parent, entry['path'])
        wire = read(source)
        require(sha(wire) == entry['wire_sha256'] == pins[source.relative_to(WORKSPACE).as_posix()], 'Sparse slot wire changed')
        packets[route] = (entry, wire, None)
    return pins, packets


def input_files(binding):
    rows = {r['path']: r for r in legacy.input_files()}
    paths = list(HERE.glob('*.py')) + list(HERE.glob('*.md')) + list(HERE.glob('*.json'))
    paths += list(HERE.glob('*.pdf')) + list(HERE.glob('*.txt'))
    paths += list((HERE / 'ci').glob('*.py'))
    for path in paths:
        path = within(WORKSPACE, path)
        name = path.relative_to(WORKSPACE).as_posix()
        rows[name] = dict(path=name, sha256=sha(read(path)))
    for name, raw in binding['code_files'].items():
        key = 'src-demo-day/' + name
        rows[key] = dict(path=key, sha256=sha(raw))
    return [rows[key] for key in sorted(rows)]


def producer_qa(binding, path, pin):
    path = within(PATCH / 'swedish/isolated_engine', path)
    _, raw = pinned(SOURCE, dict(path=path.relative_to(SOURCE).as_posix(), sha256=pin))
    value = public_json(raw)
    require(value['version'] == 'scoped-study-final-qa/2' and value['validation'] == 'PASS_TARGETED_ATTEMPT03'
            and value['integration_ref'] == binding['manifest_ref'], 'Attempt03 final QA does not bind this contract')
    require(value['stage_modified'] is False and value['index_modified'] is False
            and value['shared_or_ordinary_outputs_modified'] is False and value['publish_performed'] is False
            and value['new_spend_usd'] == 0 and value['strict_expected_failures'] == 0
            and value['formerly_failed_provenance_requirements_now_pass'] == 4
            and value['public_copies_exact_pins_verified'] is True, 'Incomplete Attempt03 producer acceptance')
    require(value['executed_python_allowlist_files'] == len(binding['code_files'])
            and value['public_copies'] == len(binding['copies'])
            and value['browser_kind'] == 'PLAYWRIGHT_MANAGED_CHROMIUM_HEADLESS_SHELL'
            and value['prior_execution_source_and_contract_bytes_preserved'] is True
            and value['executed_source_manifest_ref'] == binding['manifest']['code_snapshot_ref']['variant_snapshot_ref']
            and value['coordinate_audit_ref'] == binding['manifest']['coordinate_provenance']['audit_ref'],
            'Final QA source/coordinate audit identity mismatch')
    _, xml = pinned(SOURCE, contract.ref(value['test_receipt_ref']))
    from xml.etree import ElementTree
    suites = list(ElementTree.fromstring(xml).iter('testsuite'))
    require(sum(int(s.get('tests', 0)) for s in suites) == value['tests_passed'] and value['tests_passed'] > 0
            and not any(int(s.get('failures', 0)) or int(s.get('errors', 0)) or int(s.get('skipped', 0)) for s in suites),
            'Producer final XML did not pass without expected failures')
    require(len(value['query_audits']) == len(binding['audits']) == 2, 'Missing producer query audit')
    for row, actual in zip(value['query_audits'], binding['audits']):
        require(row['position'] == actual['position'] and row['execution_ref']['sha256'] == actual['execution_audit_sha256']
                and row['source_view_sha256'] == actual['source_view_sha256']
                and row['public_selected_quotes_and_decisions_equal_execution'] is True
                and row['query_plan_readings_exactly_reused'] is True and row['origin_inspected'] is True,
                'Producer query audit mismatch')
    for row in value['existing_dependencies']:
        pinned(SOURCE, contract.ref(row['source']))
    pinned(SOURCE, contract.ref(value['impact_ref']))
    return dict(path=path.relative_to(SOURCE).as_posix(), sha256=pin, producer_limitations=value['limitations'],
                impact_ref=value['impact_ref'], tests_passed=value['tests_passed'],
                independent_context_rebuild_for_final_qa=False)


def load_binding(path, pin, qa_path=FINAL_QA, qa_pin=FINAL_QA_PIN):
    binding = contract.validate(path, pin)
    binding['producer_qa'] = producer_qa(binding, qa_path, qa_pin)
    return binding


def check_stage(stage):
    _, packets = slot_inputs()
    return legacy.staged_preflight(stage, packets)


def allowed_changes(binding):
    return set(binding['copies']) | set(binding['archive_files']) | META_NAMES


def unchanged_assets(before, after, allowed):
    before = {r['path']: r for r in before}
    after = {r['path']: r for r in after}
    require(all(before.get(name) == after.get(name) for name in set(before) | set(after) if name not in allowed),
            'An asset outside the explicit Swedish/release whitelist changed')
    require(set(before) <= set(after), 'Existing published/staged asset removed')


def freeze(stage, work, binding, gate):
    require(not work.exists() and not (stage / 'site/release-manifest.json').exists(), 'New work directory and unsealed stage required')
    for name in ('graph-full-v6.js', 'graph-full-v6.css'):
        require(read(stage / 'site' / name) == read(PATCH / 'ui' / name),
                'Main must sync and QA the same renderer/style bytes before freeze: ' + name)
    preflight = check_stage(stage)
    _, original, _, base = legacy.baseline(gate)
    receipt = load(read(stage / 'stage_receipt.json'))
    for key in ('source_report_ref', 'casebook_ref', 'digest_ref', 'field_guide', 'dataset_delivery_ref'):
        require(receipt.get(key) == original.get(key), 'Original reference retargeted: ' + key)
    value = dict(version='kg-scoped-s2-frozen-inputs/3', stage='stage',
        contract_ref=binding['manifest_ref'], producer_qa=binding['producer_qa'], baseline=base,
        source_files=input_files(binding), stage_receipt_sha256=sha(read(stage / 'stage_receipt.json')),
        site_inventory_sha256=sha(encoded(legacy.inventory(stage / 'site', gate))), staged_integration=preflight)
    put_json(at(work, 'freeze.json'), value)
    return dict(status='FROZEN', frozen_sha256=sha(encoded(value)), publish_authorized=False)


def build_bundle(binding, work, original, original_site):
    code = original['code_bundle']
    _, raw = pinned(original_site, dict(path=code['path'], sha256=code['sha256']))
    _, manifest_raw = pinned(original_site, dict(path=code['manifest_path'], sha256=code['manifest_sha256']))
    slot_pins, _ = slot_inputs()
    base = at(work, 'base-code')
    bundled, metadata, tree, checks = legacy_bundle.build(raw, load(manifest_raw), base, slot_pins)
    manifest = load(metadata)
    files = legacy_bundle.unpack(bundled, manifest)
    # Active validation uses the installed reader's explicit >=3 GiB reserve API.
    # The unchanged historical deploy reader remains in ZIP history.
    legacy_bundle.replace(files, 'fragment_reader.py',
        read(WORKSPACE / 'matryoshka_demo_site/release-tools/fragment_reader.py'))
    for name, data in binding['code_files'].items():
        legacy_bundle.replace(files, name, data)
    metadata_name = 'phase/kg_patch_20261122/swedish/isolated_engine/scoped-engine-source-manifest-v03.json'
    legacy_bundle.replace(files, metadata_name, encoded(binding['code_metadata']))
    for path in sorted(HERE.glob('*')):
        if path.is_file() and path.suffix in {'.py', '.md', '.json', '.pdf', '.txt'}:
            legacy_bundle.replace(files, 'patch/release/scoped_s2_v03/' + path.name, read(path))
    for name in ('swedish-study.html', 'swedish-study.css', 'swedish-study.js'):
        legacy_bundle.replace(files, 'patch/ui/' + name, binding['copies'][name])
    smoke = assets.smoke_source()
    for name in ('ci/browser_smoke.py', 'installed/release-tools/ci/browser_smoke.py',
                 'patch/release/scoped_s2_v03/ci/browser_smoke.py'):
        legacy_bundle.replace(files, name, smoke)
    readme = ('# Scoped S2 Release Code\n\nActual scoped engine runs use an explicit S2 policy; '
              'they are not unchanged canonical native executions. Gold is unknown. Archived lexical results '
              'remain separate. The isolated namespace contains only explicitly pinned Python files '
              'and allowlisted source metadata. No context corpus, API receipts, ledger or private execution '
              'packet is bundled. See patch/release/scoped_s2_v03/HANDOFF.md.\n').encode()
    legacy_bundle.replace(files, 'CODE_BUNDLE_README.md', readme)
    # Do not place the contract itself in the ZIP: it is an audit input, not source code.
    isolated_prefix = 'phase/kg_patch_20261122/swedish/isolated_engine/'
    for name in files:
        if name.startswith(isolated_prefix):
            require(name in binding['code_files'] or name == metadata_name, 'Unexpected isolated artifact in ZIP')
    bundled, rows = legacy_bundle.make_zip(files)
    manifest.update(files=rows, scoped_shared_kernel=dict(execution_version=contract.EXECUTION,
        source_policy_version=contract.POLICY, canonical_native_run=False,
        executed_snapshot_identity=binding['manifest']['code_snapshot_ref']['executed_snapshot_identity'],
        python_files=len(binding['code_files']), private_execution_included=False, api_receipts_included=False),
        public_study_data_included=False)
    legacy_bundle.unpack(bundled, manifest)
    snapshot = base / 'snapshot'
    for name, data in files.items():
        target = at(snapshot, legacy_bundle.PREFIX + name)
        if not target.exists() or read(target) != data:
            write(target, data)
    write(work / 'matryoshka-code.zip', bundled)
    put_json(work / 'matryoshka-code-manifest.json', manifest)
    checks.update(legacy_bundle.check_imports(snapshot))
    return bundled, encoded(manifest), tree, checks


def frozen_binding(stage, work, gate):
    frozen = public_json(read(work / 'freeze.json'))
    require(frozen['version'] == 'kg-scoped-s2-frozen-inputs/3' and frozen['stage'] == 'stage', 'Wrong frozen candidate')
    ref = frozen['contract_ref']
    qa = frozen['producer_qa']
    binding = load_binding(at(SOURCE, ref['path']), ref['sha256'], at(SOURCE, qa['path']), qa['sha256'])
    require(input_files(binding) == frozen['source_files'], 'Frozen source/tool pins changed')
    return frozen, binding


def prepare(stage, work, gate):
    require(not (stage / 'site/release-manifest.json').exists() and not (work / 'prepare.json').exists(), 'Already sealed/prepared')
    frozen, binding = frozen_binding(stage, work, gate)
    site = stage / 'site'
    before = legacy.inventory(site, gate)
    require(sha(encoded(before)) == frozen['site_inventory_sha256']
            and sha(read(stage / 'stage_receipt.json')) == frozen['stage_receipt_sha256'], 'Frozen stage changed')
    check_stage(stage)
    original_site, original, _, base = legacy.baseline(gate)
    require(base == frozen['baseline'], 'Baseline changed')
    receipt = load(read(stage / 'stage_receipt.json'))
    dataset_check = legacy.dataset_metadata(site, original_site, receipt)
    old_index = read(site / 'data/api-index.json')
    old_runtime = read(site / 'runtime/public-runtime.js')
    zip_raw, code_raw, tree, checks = build_bundle(binding, work, original, original_site)
    require(input_files(binding) == frozen['source_files'] and legacy.inventory(site, gate) == before
            and sha(read(stage / 'stage_receipt.json')) == frozen['stage_receipt_sha256'], 'Inputs mutated during packaging')
    for name, data in binding['archive_files'].items():
        target = at(site, name)
        require(not target.exists() or read(target) == data, 'Existing archive would be overwritten')
        if not target.exists():
            write(target, data)
    for name, data in binding['copies'].items():
        write(at(site, name), data)
    pdf, text = assets.addendum()
    write(at(site, DOC_NAMES[0]), pdf)
    write(at(site, DOC_NAMES[1]), text)
    code_ref = dict(path='downloads/matryoshka-code.zip', sha256=sha(zip_raw), bytes=len(zip_raw),
        manifest_path='downloads/matryoshka-code-manifest.json', manifest_sha256=sha(code_raw),
        source_backend_tree_sha256=tree, code_only=True)
    write(at(site, code_ref['path']), zip_raw)
    write(at(site, code_ref['manifest_path']), code_raw)
    transform = dict(version='kg-scoped-s2-release/3', contract_ref=binding['manifest_ref'], producer_qa=binding['producer_qa'],
        scoped_execution_version=contract.EXECUTION, source_policy_version=contract.POLICY,
        execution_performed=True, canonical_native_run=False, gold=None, default_policy='S2',
        archived_lexical_default=False, ordinary_native_outputs_modified=False, new_ordinary_native_executions=0,
        packaging_api_calls=0, study_budget=binding['manifest']['budget'], query_audits=binding['audits'],
        slot_context_policy=legacy.POLICY, slot_packet_paths_reused=True, api_index_bytes_unchanged=True,
        producer_limitations=binding['manifest']['tests']['limitations'], dataset_check=dataset_check,
        offset_policy=contract.COORDINATE_POLICY, coordinate_provenance=binding['manifest']['coordinate_provenance'],
        public_assets=binding['public_assets'])
    # Keep every historical native version and coverage row verbatim.
    receipt.pop('backend_root', None)
    source_refs = {item['destination']: item['source'] for item in binding['manifest']['copies']}
    historical = []
    for collection in ('asset_lineage', 'supplement_assets'):
        for row in receipt.get(collection, []):
            target = row.get('path', row.get('target'))
            if target not in binding['copies']:
                continue
            historical.append(dict(collection=collection, row=dict(row)))
            row.update(public_sha256=sha(binding['copies'][target]), source_ref=source_refs[target],
                bytes_unchanged=False, binding='EXPLICIT_SCOPED_S2_PUBLIC_PROJECTION',
                scope='ACTUAL_SCOPED_SHARED_KERNEL_NOT_CANONICAL_NATIVE')
            if 'active_ui_sha256' in row:
                row['active_ui_sha256'] = row['public_sha256']
    if historical:
        receipt['historical_swedish_asset_lineage'] = historical
    receipt.update(backend_code_sha256=tree, code_bundle=code_ref, kg_patch=transform,
        current_native_execution=False, native_outputs_modified=False, report_bytes_unchanged=True,
        privacy_approval_inherited=False, publish_authorized=False, release_qualified=False,
        browser_smoke='NOT_RUN_FOR_THIS_PREPARED_CANDIDATE')
    put_json(stage / 'stage_receipt.json', receipt)
    lineage = load(read(site / 'export-lineage.json'))
    lineage.pop('backend_root', None)
    lineage.update(receipt)
    lineage['backend_snapshot'] = dict(tree_sha256=tree, canonical=False,
        scope='Bundled backend plus separately versioned isolated scoped S2 source; historical native versions unchanged.')
    put_json(site / 'export-lineage.json', lineage)
    publication = load(read(site / 'publication.json'))
    publication.update(privacy_approval_inherited=False, publish_authorized=False, release_qualified=False, kg_patch=transform)
    publication['files'] = [r for r in legacy.inventory(site, gate) if r['path'] != 'publication.json']
    put_json(site / 'publication.json', publication)
    after = legacy.inventory(site, gate)
    unchanged_assets(before, after, allowed_changes(binding))
    require(read(site / 'data/api-index.json') == old_index and read(site / 'runtime/public-runtime.js') == old_runtime,
            'Frozen index/runtime changed')
    for row in after:
        if row['path'].endswith('.html'):
            path = at(site, row['path'])
            gate.Dependencies(site, path).feed(read(path).decode())
    prepared = dict(version='kg-scoped-s2-prepared/3', stage='stage', contract_ref=binding['manifest_ref'],
        source_files_sha256=sha(encoded(frozen['source_files'])), frozen_inputs_sha256=sha(read(work / 'freeze.json')),
        site_inventory_sha256=sha(encoded(after)), stage_receipt_sha256=sha(read(stage / 'stage_receipt.json')),
        code_check=checks, public_assets=binding['public_assets'], publish_authorized=False,
        api_index_sha256=sha(old_index), all_non_slot_route_bindings_unchanged=True,
        integrity_scope='Fresh gate.make inventory and frozen-reference checks; main must run full native/dataset integrity separately')
    put_json(work / 'prepared-inventory.json', after)
    put_json(work / 'prepare.json', prepared)
    return dict(status='PREPARED_UNSEALED', prepared_sha256=sha(encoded(prepared)), publish_authorized=False)


def seal(stage, work, gate, qa_path):
    require(not (stage / 'site/release-manifest.json').exists() and not (work / 'seal.json').exists(), 'Already sealed')
    frozen, binding = frozen_binding(stage, work, gate)
    raw = read(work / 'prepare.json')
    prepared = public_json(raw)
    require(prepared['version'] == 'kg-scoped-s2-prepared/3'
            and prepared['frozen_inputs_sha256'] == sha(read(work / 'freeze.json'))
            and prepared['stage_receipt_sha256'] == sha(read(stage / 'stage_receipt.json')), 'Prepared binding changed')
    rows = legacy.inventory(stage / 'site', gate)
    require(prepared['site_inventory_sha256'] == sha(encoded(rows)), 'Prepared site changed')
    qa_path = within(PATCH, qa_path)
    qa_raw = read(qa_path)
    qa = public_json(qa_raw)
    require(qa['version'] == 'kg-scoped-s2-post-prepare-qa/3' and qa['status'] == 'PASS'
            and qa['prepared_sha256'] == sha(raw) and qa['site_inventory_sha256'] == prepared['site_inventory_sha256'], 'Fresh candidate-bound QA required')
    for key in ('browser_desktop', 'browser_mobile', 'source_and_binding_regressions', 'slot_context_navigation_only',
                'scoped_s2_both_actual_tabs_unknown_gold', 'archived_lexical_separate', 'ordinary_native_integrity_accepted'):
        require(qa.get(key) is True, 'Missing post-prepare QA: ' + key)
    require(qa['evidence'], 'Hash-bound evidence required')
    for ref in qa['evidence']:
        pinned(PATCH, contract.ref(ref))
    manifest = gate.make(stage / 'site', public_json(read(stage / 'stage_receipt.json')))
    require(manifest['files'] == rows and manifest['publish_authorized'] is False
            and manifest['privacy_approval_inherited'] is False, 'Fresh inventory mismatch')
    result = dict(version='kg-scoped-s2-seal/3', manifest_sha256=sha(read(stage / 'site/release-manifest.json')),
        prepared_sha256=sha(raw), qa_ref=dict(path=qa_path.relative_to(PATCH).as_posix(), sha256=sha(qa_raw)),
        integrity_scope=prepared['integrity_scope'], publish_authorized=False, privacy_approval_inherited=False,
        datasets_copied=False, datasets_rehashed=False)
    put_json(work / 'seal.json', result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    for name in ('check-handoff', 'freeze', 'prepare', 'seal', 'build-assets'):
        mode.add_argument('--' + name, action='store_true')
    parser.add_argument('--contract-ref', type=Path)
    parser.add_argument('--contract-pin')
    parser.add_argument('--producer-qa-ref', type=Path, default=FINAL_QA)
    parser.add_argument('--producer-qa-pin', default=FINAL_QA_PIN)
    parser.add_argument('--stage', type=Path, default=PATCH / 'stage')
    parser.add_argument('--work', type=Path)
    parser.add_argument('--qa-ref', type=Path)
    args = parser.parse_args()
    require(not sys.flags.optimize, 'Do not disable gate assertions')
    space(HERE)
    if args.build_assets:
        pdf, text = assets.addendum()
        write(HERE / 'kg-patch-addendum-scoped-s2-v03.pdf', pdf)
        write(HERE / 'kg-patch-addendum-scoped-s2-v03.txt', text)
        write(HERE / 'ci/browser_smoke.py', assets.smoke_source())
        print('VERSIONED_CI_AND_FIVE_PAGE_ADDENDUM_BUILT')
        return
    stage = within(PATCH, args.stage)
    require(stage == PATCH / 'stage', 'Only the validated workspace patch/stage is allowed')
    gate = gate_module()
    if args.check_handoff or args.freeze:
        require(args.contract_ref is not None and args.contract_pin, 'Explicit final contract path and SHA required')
        binding = load_binding(args.contract_ref, args.contract_pin, args.producer_qa_ref, args.producer_qa_pin)
        if args.check_handoff:
            result = dict(status='PASS_READ_ONLY_SCOPED_HANDOFF', public_copies=len(binding['copies']),
                python_sources=len(binding['code_files']), audits=binding['audits'], staged_integration=check_stage(stage),
                producer_qa=binding['producer_qa'], publish_authorized=False)
            print(encoded(result).decode(), end='')
            return
    require(args.work is not None, '--work is required')
    work = within(HERE / 'runs', args.work)
    if args.freeze:
        result = freeze(stage, work, binding, gate)
    elif args.prepare:
        result = prepare(stage, work, gate)
    else:
        require(args.qa_ref is not None, 'Fresh --qa-ref required')
        result = seal(stage, work, gate, args.qa_ref)
    print(encoded(result).decode(), end='')


if __name__ == '__main__':
    main()
