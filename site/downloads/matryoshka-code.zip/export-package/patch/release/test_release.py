"""Tiny local fixtures and adversarial gates. No real-stage writes or servers."""
import ast
import gzip
import io
from pathlib import Path
import shutil
import zipfile

import pytest

import build_addendum
import code_snapshot as bundle
import package_release as release
from release_common import (DEPLOY, HERE, INSTALLED, PATCH, SOURCE, at, encoded,
                            gate_module, load, public_json, relative, sha, tree_sha, within)


def put(root, name, raw):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw if isinstance(raw, bytes) else encoded(raw))
    return path


def test_pdf_is_deterministic_five_pages_and_current():
    from pypdf import PdfReader
    first = build_addendum.pdf_bytes()
    assert first == build_addendum.pdf_bytes()
    reader = PdfReader(io.BytesIO(first))
    assert len(reader.pages) == 5
    text = '\n'.join(page.extract_text() for page in reader.pages)
    assert 'Input / Sources / Results' in text and 'acknowledgment checkbox' in text
    assert 'reference answers remain unknown' in text.lower()
    assert 'fallback' not in text.lower() and 'privacy review' not in text.lower()
    assert all(page.mediabox.width == 612 and page.mediabox.height == 792 for page in reader.pages)


@pytest.mark.parametrize('name', ['', '/abs', '../x', 'a/../b', 'a//b', './a', 'a\\b'])
def test_relative_names_fail_closed(name):
    with pytest.raises(ValueError):
        relative(name)


def test_ownership_rejects_escape_and_symlink_parent(tmp_path):
    root = tmp_path / 'patch'
    root.mkdir()
    (root / 'alias').symlink_to(tmp_path, target_is_directory=True)
    with pytest.raises(ValueError):
        at(root, 'alias/out')
    with pytest.raises(ValueError):
        within(root, tmp_path / 'other')


@pytest.mark.parametrize('raw', [b'{"x":1,"x":2}', b'{"x":NaN}', b'{"source":"/Users/test/private"}'])
def test_public_metadata_rejects_duplicates_nonfinite_and_local_paths(raw):
    with pytest.raises(ValueError):
        public_json(raw)


def test_catalog_bound_handles_real_47mb_shape_without_unbounded_decode():
    raw = gzip.compress(b' ' * 47_443_038, mtime=0)
    assert len(release.decode_packet(raw, 100_000_000)) == 47_443_038
    with pytest.raises(ValueError, match='bounded limit'):
        release.decode_packet(raw, 20_000_000)


def test_route_invariants_reject_native_retarget_and_page_rewrite():
    original = {'/api/native': {'sha256': 'a'}, '/data/slots/cib/records-0.json': {'sha256': 'b'},
                '/data/slots/cib/' + 'a'*64 + '.json': {'sha256': 'c'}}
    allowed = {'/data/slots/cib/records-0.json'}
    current = dict(original)
    current[next(iter(allowed))] = {'sha256': 'new'}
    release.unchanged_routes(original, current, allowed)
    for key in ('/api/native', '/data/slots/cib/' + 'a'*64 + '.json'):
        bad = dict(current, **{key: {'sha256': 'tampered'}})
        with pytest.raises(ValueError):
            release.unchanged_routes(original, bad, allowed)
    with pytest.raises(ValueError):
        release.unchanged_routes(original, dict(current, added={}), allowed)


def test_only_runtime_html_pin_changes_are_accepted():
    old = b'<script data-index-sha256="' + b'a'*64 + b'" src="runtime/public-runtime.js"></script>'
    new = old.replace(b'a'*64, b'b'*64)
    assert release.without_index_hooks(old) == release.without_index_hooks(new)
    assert release.without_index_hooks(old) != release.without_index_hooks(new.replace(b'public-runtime', b'wrong-runtime'))


def test_zip_is_deterministic_preserves_history_and_rejects_tampering():
    files = {'x.py': b'original', 'backend/a.py': b'pass\n'}
    bundle.replace(files, 'x.py', b'updated')
    bundle.replace(files, 'x.py', b'latest')
    assert files['history/pre-kg/x.py'] == b'original'
    assert b'updated' in files.values()
    raw, rows = bundle.make_zip(files)
    assert bundle.make_zip(files) == (raw, rows)
    assert bundle.unpack(raw, dict(files=rows)) == files
    rows[0] = dict(rows[0], sha256='0'*64)
    with pytest.raises(ValueError):
        bundle.unpack(raw, dict(files=rows))


@pytest.mark.parametrize('mode', ['duplicate', 'traversal', 'symlink', 'fixture'])
def test_adversarial_zip_members(mode):
    data = io.BytesIO()
    name = {'traversal': '../outside', 'fixture': 'backend/contracts/planning_v2/masked_examples.json'}.get(mode, 'x.py')
    with zipfile.ZipFile(data, 'w') as archive:
        info = zipfile.ZipInfo('export-package/' + name)
        if mode == 'symlink':
            info.external_attr = 0o120777 << 16
        archive.writestr(info, b'x')
        if mode == 'duplicate':
            with pytest.warns(UserWarning):
                archive.writestr(info, b'x')
    with pytest.raises(ValueError):
        bundle.unpack(data.getvalue(), dict(files=[dict(path=name, bytes=1, sha256=sha(b'x'))]))


@pytest.fixture
def code_inputs(tmp_path):
    root = tmp_path / 'workspace'
    deploy, installed, patch, source = [root / name for name in ('deploy', 'installed', 'patch', 'source')]
    for path in (deploy, installed, patch, source):
        path.mkdir(parents=True)
    old = {'backend/matryoshka_narrative/__init__.py': b'',
           'backend/matryoshka_narrative/server.py': b'VALUE = 1\n',
           'backend/matryoshka_current/slot_overlay.py': b'OLD = True\n',
           'ci/browser_smoke.py': b'old smoke\n',
           'ci/test_manifest.py': b'old four tests\n',
           'slot-runtime.js': b'old slots\n',
           'cached_transport_test.py': b'preserve all prior tests\n',
           'backend-source-snapshot.json': encoded(dict(files=[]))}
    raw, rows = bundle.make_zip(old)
    excluded = [dict(path='contracts/planning_v2/masked_examples.json', sha256='a'*64)]
    manifest = dict(files=rows, backend_tree_sha256=tree_sha(old, excluded), excluded_corpus_derived_inputs=excluded)
    put(deploy, 'export_narrative.py', b'import argparse\np=argparse.ArgumentParser()\np.add_argument("--resume")\np.add_argument("--reuse-graph-stage")\np.parse_args()\n')
    put(deploy, 'static_slots.py', b"thin = ('id', 'label', 'context_policy')\n")
    put(deploy, 'ci/browser_smoke.py', old['ci/browser_smoke.py'])
    put(deploy, 'ci/test_manifest.py', old['ci/test_manifest.py'])
    for name in ('slot_overlay.py', 'slot_context.py'):
        put(source, 'matryoshka_current/' + name,
            b'from .slot_context import POLICY\n' if name == 'slot_overlay.py' else b'POLICY = "source-visible-slot-context/1"\n')
    for name in ('test_navigation_publication_cache.py', 'test_current_slot_context_patch.py'):
        put(source, 'tests/' + name, b'def test_fixture():\n    assert True\n')
    for name in ('export_current_replays.py', 'check_current_readout_cache.py'):
        put(installed, 'tools/' + name, b'pass\n')
    put(installed, 'release-tools/ci/test_manifest.py',
        ''.join(f'def test_{i}():\n    pass\n' for i in range(6)).encode())
    put(installed, 'release-tools/ci/browser_smoke.py', old['ci/browser_smoke.py'])
    put(installed, '.github/workflows/pages.yml', b'name: installed\n')
    put(installed, 'requirements-dev.txt', b'pytest\n')
    put(patch, 'release/ci/browser_smoke.py', b'new both tab no ack smoke\n')
    put(patch, 'release/CODE_BUNDLE_PATCH_README.md', b'Current patch contract\n')
    put(patch, 'runtime/slot-runtime.js', b'active slots\n')
    put(patch, 'runtime/integrate_slots.py', b'pass\n')
    put(patch, 'runtime/test_selector.cjs', b'console.log("fixture");\n')
    put(patch, 'runtime/exact-files.json', dict(files=[]))
    put(patch, 'runtime/integration-v1/integration.json', dict(files=[]))
    put(patch, 'stage/site/runtime/public-runtime.js', b'active composed runtime\n')
    put(patch, 'ui/graph-full-v6.js', b'active graph\n')
    for name in ('bind_stage_index.py', 'verify_live.py', 'IMPLEMENTATION_NOTES.md'):
        put(patch, name, b'current patch helper\n')
    pins = {'src-demo-day/matryoshka_current/' + name: sha((source / 'matryoshka_current' / name).read_bytes())
            for name in ('slot_overlay.py', 'slot_context.py')}
    return raw, manifest, deploy, installed, patch, source, pins, tmp_path / 'bundle-work'


def test_tiny_complete_code_snapshot_keeps_active_runtime_ci_tests_and_all_prior_code(code_inputs):
    raw, manifest, deploy, installed, patch, source, pins, work = code_inputs
    output, metadata, tree, check = bundle.build(raw, manifest, work, pins,
        deploy=deploy, installed=installed, patch=patch, source=source)
    current = load(metadata)
    files = bundle.unpack(output, current)
    assert tree == tree_sha(files, manifest['excluded_corpus_derived_inputs'])
    assert files['slot-runtime.js'] == b'active slots\n'
    assert files['vendor/runtime/public-runtime.js'] == b'active composed runtime\n'
    assert b"'label', 'context_policy'" in files['static_slots.py']
    assert files['ci/browser_smoke.py'] == b'new both tab no ack smoke\n'
    assert current['active_installed_ci_tests'] == 6 and check['generic_export_help_pass']
    assert files['history/pre-kg/ci/test_manifest.py'] == b'old four tests\n'
    assert files['history/pre-kg/backend/matryoshka_current/slot_overlay.py'] == b'OLD = True\n'
    assert files['cached_transport_test.py'] == b'preserve all prior tests\n'
    for name in ('bind_stage_index.py', 'verify_live.py', 'IMPLEMENTATION_NOTES.md',
                 'runtime/integrate_slots.py', 'runtime/test_selector.cjs'):
        assert 'patch/' + name in files
    assert (work / 'snapshot/export-package/backend/matryoshka_current/slot_context.py').is_file()
    assert b'/Users/' not in metadata and b'/Users/' not in files['backend-source-snapshot.json']


def test_new_smoke_changes_only_swedish_operation():
    old = (INSTALLED / 'release-tools/ci/browser_smoke.py').read_text()
    new = (HERE / 'ci/browser_smoke.py').read_text()
    def without_swedish(text):
        before, tail = text.split('            def swedish(page, row):\n', 1)
        _, after = tail.split("            run('swedish-S2', swedish, mobile=True)\n", 1)
        return before, after
    assert without_swedish(old) == without_swedish(new)
    assert 'origin-exception-ack\').check()' not in new
    assert "('first', 'First query'), ('second', 'Second query')" in new
    assert "['Input', 'Sources', 'Results']" in new
    assert 'channel=' not in new and '/Applications/Google Chrome.app' not in new


def test_active_ci_has_six_auth_and_existing_eight_export_transport_tests():
    def count(path):
        return sum(isinstance(node, ast.FunctionDef) and node.name.startswith('test_')
                   for node in ast.walk(ast.parse(path.read_bytes())))
    assert count(INSTALLED / 'release-tools/ci/test_manifest.py') == 6
    assert count(INSTALLED / 'tests/test_export_current_replays.py') == 8
    assert 'test_current_relative_approval_path_remains_hash_bound' in (INSTALLED / 'release-tools/ci/test_manifest.py').read_text()


@pytest.fixture
def candidate(tmp_path, monkeypatch):
    patch = tmp_path / 'patch'
    home = patch / 'release'
    stage = patch / 'stage'
    work = home / 'runs/test'
    site = stage / 'site'
    home.mkdir(parents=True)
    monkeypatch.setattr(release, 'PATCH', patch)
    monkeypatch.setattr(release, 'HERE', home)
    monkeypatch.setattr(release, 'input_files', lambda: [])
    report = dict(cases=[dict(case=dict(case_id='ordinary', query='saved query'))])
    put(site, 'data/report-v6.json', report)
    put(site, 'data/api-index.json', dict(entries={}))
    receipt = dict(source_report_ref=dict(path='report.json', sha256=sha(encoded(report))),
                   casebook_ref=dict(path='casebook.json', sha256='b'*64),
                   digest_ref=dict(path='digest.json', sha256='c'*64), backend_code_sha256='d'*64)
    put(stage, 'stage_receipt.json', receipt)
    gate = gate_module()
    rows = release.inventory(site, gate)
    prepared = dict(version='kg-patch-prepared/1', stage='stage', site_inventory_sha256=sha(encoded(rows)),
        stage_receipt_sha256=sha(encoded(receipt)), gate_scope='existing make; no dataset content rehash')
    put(work, 'prepare.json', prepared)
    put(work, 'freeze.json', dict(source_files=[]))
    evidence = put(patch, 'qa/browser.json', dict(status='PASS'))
    qa = dict(version='kg-patch-post-prepare-qa/1', status='PASS', prepared_sha256=sha(encoded(prepared)),
        site_inventory_sha256=prepared['site_inventory_sha256'], browser_desktop=True, browser_mobile=True,
        source_and_binding_regressions=True, slot_context_navigation_only=True,
        swedish_both_tabs_s2_noack_unknown_gold=True,
        evidence=[dict(path='qa/browser.json', sha256=sha(evidence.read_bytes()))])
    qa_ref = put(home, 'post-prepare-qa.json', qa)
    return patch, stage, work, gate, qa_ref, qa


def test_fresh_seal_does_not_inherit_approval(candidate):
    _, stage, work, gate, qa_ref, _ = candidate
    result = release.seal(stage, work, gate, qa_ref)
    manifest = load((stage / 'site/release-manifest.json').read_bytes())
    assert result['publish_authorized'] is False and manifest['publish_authorized'] is False
    assert manifest['privacy_approval_inherited'] is False and result['datasets_rehashed'] is False
    with pytest.raises(AssertionError):
        gate.authorize(stage / 'site', None)
    with pytest.raises(ValueError, match='Already sealed'):
        release.seal(stage, work, gate, qa_ref)


@pytest.mark.parametrize('mutation', ['site', 'receipt', 'code', 'wrong-candidate', 'missing-qa', 'tamper-evidence'])
def test_seal_rejects_changed_inputs_and_stale_or_unaccepted_qa(candidate, monkeypatch, mutation):
    patch, stage, work, gate, qa_ref, qa = candidate
    if mutation == 'site':
        put(stage / 'site', 'changed.js', b'changed')
    elif mutation == 'receipt':
        put(stage, 'stage_receipt.json', dict(changed=True))
    elif mutation == 'code':
        monkeypatch.setattr(release, 'input_files', lambda: [dict(changed=True)])
    elif mutation == 'wrong-candidate':
        qa['prepared_sha256'] = '0'*64
        qa_ref.write_bytes(encoded(qa))
    elif mutation == 'missing-qa':
        qa['browser_mobile'] = False
        qa_ref.write_bytes(encoded(qa))
    else:
        put(patch, 'qa/browser.json', dict(status='FAIL'))
    with pytest.raises(ValueError):
        release.seal(stage, work, gate, qa_ref)
    assert not (stage / 'site/release-manifest.json').exists()


def test_real_handoffs_read_only_and_real_catalog_size():
    swedish, copies, _, packets, refs = release.handoffs(
        PATCH / 'swedish/artifacts_v01/integration-v03.json', release.SWEDISH_PIN, release.SLOTS_PIN)
    assert swedish['native_execution'] is False and swedish['full_same_pipeline_achieved'] is False
    assert len(copies) == 10 and len(packets) == 224
    assert len(encoded(packets['/data/slots/cib.json'][2])) > 20_000_000
    assert refs['swedish_integration_sha256'] == release.SWEDISH_PIN
    assert not (PATCH / 'stage/site/release-manifest.json').exists()


def test_tiny_freeze_prepare_qa_seal_preserves_native_pages_runtime_and_guide(tmp_path, monkeypatch):
    patch = tmp_path / 'patch'
    home, stage, original_site = patch / 'release', patch / 'stage', tmp_path / 'baseline/site'
    home.mkdir(parents=True)
    work = home / 'runs/candidate'
    gate = gate_module()
    monkeypatch.setattr(release, 'PATCH', patch)
    monkeypatch.setattr(release, 'HERE', home)
    monkeypatch.setattr(release, 'input_files', lambda: [])
    report = dict(cases=[dict(case=dict(case_id='ordinary', query='unchanged'))])
    put(original_site, 'data/report-v6.json', report)
    entries, packets = {}, {}
    for corpus in ('cib', 'iran', 'vietnam'):
        status = dict(coverage=dict(total_slots=0), source_audit=[], graph_run_id='g-' + corpus,
                      hierarchy_run_id='h-' + corpus, source_view='earlier', release='earlier',
                      hidden_values_read=False, semantic_graph_modified=False)
        old = dict(status=status, slots=[], details={})
        raw = encoded(old)
        wire = gzip.compress(raw, mtime=0)
        name = 'data/' + corpus + '.json.gz'
        put(original_site, name, wire)
        route = '/data/slots/' + corpus + '.json'
        entry = dict(encoding='gzip', mime='application/json', path=name,
                     sha256=sha(raw), wire_sha256=sha(wire))
        entries[route] = entry
        new = dict(old, status=dict(status, context_policy=release.POLICY))
        new_raw = encoded(new)
        new_wire = gzip.compress(new_raw, mtime=0)
        packets[route] = (dict(entry, sha256=sha(new_raw), wire_sha256=sha(new_wire)), new_wire, new)
    native = dict(encoding='gzip', mime='application/json', path='data/native.json.gz',
                  sha256=sha(b'{}'), wire_sha256=sha(gzip.compress(b'{}', mtime=0)))
    put(original_site, native['path'], gzip.compress(b'{}', mtime=0))
    entries['/api/current/native-v6?case=ordinary'] = native
    entries['/data/slots/cib/' + 'a'*64 + '.json'] = native
    index = dict(entries=entries)
    put(original_site, 'data/api-index.json', index)
    put(original_site, 'data/dataset-delivery.json', dict(files=[]))
    put(original_site, 'docs/matryoshka-guide.pdf', b'original guide')
    put(original_site, 'runtime/public-runtime.js', b'old runtime')
    put(original_site, 'graph-full-v6.js', b'old graph')
    put(original_site, 'graph-full-v6.html', b'<script data-index-sha256="' + b'a'*64 + b'"></script>')
    put(original_site, 'swedish-study.html', b'old study')
    put(original_site, 'export-lineage.json', {})
    put(original_site, 'publication.json', {})
    prior_zip, prior_rows = bundle.make_zip({'old.py': b'pass'})
    prior_manifest = encoded(dict(files=prior_rows))
    put(original_site, 'downloads/matryoshka-code.zip', prior_zip)
    put(original_site, 'downloads/matryoshka-code-manifest.json', prior_manifest)
    code_ref = dict(path='downloads/matryoshka-code.zip', sha256=sha(prior_zip),
                    manifest_path='downloads/matryoshka-code-manifest.json', manifest_sha256=sha(prior_manifest))
    receipt = dict(source_report_ref=dict(path='source/report.json', sha256=sha(encoded(report))),
                   casebook_ref=dict(path='casebook.json', sha256='b'*64), digest_ref=dict(path='digest.json', sha256='c'*64),
                   backend_code_sha256='d'*64, code_bundle=code_ref,
                   dataset_delivery_ref=dict(path='data/dataset-delivery.json',
                       sha256=sha((original_site / 'data/dataset-delivery.json').read_bytes())),
                   native_versions={'historical/2': 1}, coverage=[dict(native_version='historical/2')],
                   backend_root='/Users/private/old-backend')
    original = gate.make(original_site, receipt)
    base = dict(manifest_sha256=sha((original_site / 'release-manifest.json').read_bytes()),
                source_report_sha256=receipt['source_report_ref']['sha256'])
    monkeypatch.setattr(release, 'baseline', lambda unused: (original_site, original, index, base))
    monkeypatch.setattr(release, 'dataset_metadata', lambda *args: dict(hashes_recomputed=False))
    refs = dict(swedish_integration_path='swedish/integration.json', swedish_integration_sha256='e'*64,
                slots_exact_files_sha256='f'*64)
    monkeypatch.setattr(release, 'handoffs', lambda *args: (dict(existing_dependencies=[]),
                        {'swedish-study.html': b'new study'}, {}, packets, refs))
    monkeypatch.setattr(bundle, 'build', lambda *args: (b'new code zip', encoded(dict(files=[])), '1'*64, dict(pass_=True)))
    shutil.copytree(original_site, stage / 'site')
    (stage / 'site/release-manifest.json').unlink()
    put(stage / 'site', 'runtime/public-runtime.js', b'active composed runtime')
    put(stage, 'stage_receipt.json', receipt)
    put(patch, 'ui/graph-full-v6.js', b'new graph')
    put(home, 'kg-patch-addendum.pdf', b'%PDF fixture')
    put(home, 'kg-patch-addendum.txt', b'fixture addendum')
    release.freeze(stage, work, gate, patch / 'swedish/integration.json', 'e'*64, 'f'*64)
    release.prepare(stage, work, gate)
    site = stage / 'site'
    prepared = load((work / 'prepare.json').read_bytes())
    assert not (site / 'release-manifest.json').exists()
    assert (site / 'data/report-v6.json').read_bytes() == encoded(report)
    assert (site / 'docs/matryoshka-guide.pdf').read_bytes() == b'original guide'
    assert (site / 'runtime/public-runtime.js').read_bytes() == b'active composed runtime'
    new_index = load((site / 'data/api-index.json').read_bytes())
    assert new_index['entries']['/api/current/native-v6?case=ordinary'] == native
    assert new_index['entries']['/data/slots/cib/' + 'a'*64 + '.json'] == native
    assert sha((site / 'data/api-index.json').read_bytes()).encode() in (site / 'graph-full-v6.html').read_bytes()
    new_receipt = load((stage / 'stage_receipt.json').read_bytes())
    assert new_receipt['native_versions'] == {'historical/2': 1}
    assert new_receipt['coverage'] == receipt['coverage']
    assert 'backend_root' not in new_receipt
    evidence = put(patch, 'qa/fresh.json', dict(status='PASS'))
    qa = dict(version='kg-patch-post-prepare-qa/1', status='PASS',
        prepared_sha256=sha((work / 'prepare.json').read_bytes()),
        site_inventory_sha256=prepared['site_inventory_sha256'], browser_desktop=True, browser_mobile=True,
        source_and_binding_regressions=True, slot_context_navigation_only=True,
        swedish_both_tabs_s2_noack_unknown_gold=True,
        evidence=[dict(path='qa/fresh.json', sha256=sha(evidence.read_bytes()))])
    qa_ref = put(work, 'post-prepare-qa.json', qa)
    result = release.seal(stage, work, gate, qa_ref)
    assert result['publish_authorized'] is False
    assert (site / 'release-manifest.json').is_file()
