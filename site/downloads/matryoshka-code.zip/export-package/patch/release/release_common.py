"""Small fail-closed primitives shared by the bounded patch packaging tools."""
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import shutil

HERE = Path(__file__).resolve().parent
PATCH = HERE.parent
SOURCE = PATCH.parents[1]
WORKSPACE = SOURCE.parent
DEPLOY = SOURCE / 'phase/release_finish_20261121/deploy'
INSTALLED = WORKSPACE / 'matryoshka_demo_site'
MIN_FREE = 3 * 1024**3
MAX_FILE = 100_000_000
MAX_SITE = 900_000_000


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    value = {}
    for key, child in pairs:
        require(key not in value, 'Repeated JSON key: ' + key)
        value[key] = child
    return value


def load(raw):
    return json.loads(raw, object_pairs_hook=unique,
                      parse_constant=lambda value: require(False, 'Nonfinite JSON: ' + value))


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True,
                      separators=(',', ':'), allow_nan=False).encode() + b'\n'


def relative(name):
    require(isinstance(name, str) and name and '\\' not in name, 'Unsafe relative name')
    require(not PurePosixPath(name).is_absolute()
            and all(p not in ('', '.', '..') for p in name.split('/')), 'Unsafe relative name: ' + name)
    return name


def within(root, path):
    root, path = root.absolute(), Path(path).absolute()
    require(root.resolve() == root and path.resolve() == path, 'Symlink or noncanonical path')
    require(path.is_relative_to(root) and path != root, 'Path outside allowed root')
    return path


def at(root, name):
    return within(root, root / relative(name))


def space(path, additional=0):
    require(shutil.disk_usage(path).free - additional >= MIN_FREE, 'Stop: 3 GiB free-space floor')


def read(path):
    require(path.is_file() and not path.is_symlink(), 'Missing or unsafe file: ' + path.name)
    require(path.stat().st_size < MAX_FILE, 'File exceeds bounded read limit: ' + path.name)
    return path.read_bytes()


def public_json(raw):
    value = load(raw)
    normalized = encoded(value)
    for prefix in (b'/Users/', b'/home/', b'/private/', str(WORKSPACE).encode(), b'C:\\\\Users\\\\'):
        require(prefix not in normalized, 'Machine-local path in public JSON')
    return value


def write(path, raw):
    space(HERE, len(raw))
    require(not path.is_symlink(), 'Refusing symlink write')
    require(len(raw) < MAX_FILE, 'File exceeds publication limit')
    path.parent.mkdir(parents=True, exist_ok=True)
    require(path.resolve() == path.absolute(), 'Unsafe output parent')
    temporary = path.with_name(path.name + '.writing')
    require(not temporary.exists(), 'Interrupted write exists; inspect it first')
    with temporary.open('xb') as stream:
        stream.write(raw)
    temporary.replace(path)


def put_json(path, value):
    raw = encoded(value)
    public_json(raw)
    write(path, raw)


def pinned(root, ref):
    require(re.fullmatch('[a-f0-9]{64}', ref.get('sha256', '')), 'Missing SHA-256 pin')
    path = at(root, ref['path'])
    raw = read(path)
    require(sha(raw) == ref['sha256'], 'Pinned input changed: ' + ref['path'])
    return path, raw


def gate_module(deploy=DEPLOY):
    # Imports only local transport readers; no server, API or native execution.
    import sys
    sys.path.insert(0, str(deploy))
    spec = importlib.util.spec_from_file_location('kg_release_gate', deploy / 'ci/validate_manifest.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tree_sha(files, excluded=()):
    selected = {name.removeprefix('backend/'): sha(raw) for name, raw in files.items()
                if name.startswith('backend/') and Path(name).suffix in {'.py', '.json', '.txt'}}
    for row in excluded:
        relative(row['path'])
        require(row['path'] not in selected, 'Excluded backend input unexpectedly bundled')
        selected[row['path']] = row['sha256']
    return sha(json.dumps(selected, sort_keys=True, separators=(',', ':')).encode())
