"""Deterministic five-page public addendum; optional non-destructive PDF append."""
import argparse
import io
from pathlib import Path
import textwrap

from release_common import HERE, at, require, sha, within, write

PAGES = [
    ('01', 'A Closer Graph', 'KG interaction / November 2026 patch', [
        ('What This Edition Changes',
         'This addendum describes the KG interaction and source-visible slot context patch. '
         'Read it alongside the saved-report field guide. Where that guide describes the old Swedish '
         'result-opening acknowledgment, use the updated behavior on page 4 of this addendum.'),
        ('Explore Without Reinterpreting',
         'The graph keeps its saved entities, aliases, hierarchy, relationships and source bindings. '
         'Node sizing, compact circular fitting, neighborhood spacing and label placement are view-local '
         'presentation choices. A larger node or shorter screen distance is not new evidence, a changed '
         'identity, a confidence score or a new relationship.'),
        ('A Practical Starting Point',
         'Choose a corpus, search across all evidence, then inspect a result and its source. The default '
         'hierarchy view shows up to 32 nodes; evidence views allow up to 256. These are drawing limits, '
         'not claims about corpus coverage. Use source and case bindings, not visual prominence, to '
         'interpret a saved result.'),
    ]),
    ('02', 'Navigate The Neighborhood', 'Fitting, paired panels and source scope', [
        ('Read The Rings',
         'Neighborhood rings express hierarchy distance. The temporary legend explains the visible '
         'groups; an empty group is not filled with invented neighbors. Induced links between displayed '
         'nodes are enabled by default. A visible link still has the meaning recorded in its saved source.'),
        ('Move The View',
         'Fit returns the visible neighborhood to a compact circular envelope. Drag nodes to inspect '
         'crowded areas. Slow orbital motion and quadrant-aware labels help separate nearby labels '
         'without changing the graph. Reduced-motion settings suppress orbiting. Layout motion is not '
         'a temporal narrative or an inferred causal sequence.'),
        ('Compare Carefully',
         'Paired panels begin with synchronized search and controls. Direct manipulation of one panel '
         'can leave its view independent, so compare the selected corpus, source view and date settings '
         'before interpreting a visual difference. Date hints and clamps use the selected corpus bounds. '
         'A valid date does not override source eligibility, resource identity or a case-specific policy.'),
    ]),
    ('03', 'Redacted Slots', 'Visible context is navigation, never a recovered answer', [
        ('What A Label Means',
         'A Redacted Slot marks an observed mask in a saved base-visible source page. Labels use an '
         'exact nearby visible phrase, or a short literal excerpt. With no usable context, the label '
         'remains Redacted Slot. A label such as Redacted Slot / near Israeli Foreign Minister describes '
         'neighboring text; it does not identify the hidden value.'),
        ('Conservative Anchors',
         'Function words, generic fragments and ambiguous partial names are not useful anchors. '
         'Complete titles or multiword names may be retained when visible source spans support them. '
         'Search previews remain marker-centered and source-only. Open the source to inspect the literal '
         'wording, marker position and document/page provenance rather than treating a label as a finding.'),
        ('Hard Boundaries',
         'Slot context links have zero semantic and layout weight. They are navigation/provenance only, '
         'not eligible case evidence, new semantic relationships or a hidden-answer lookup. Existing '
         'slot identities, marker offsets, saved page routes, page hashes and source audits remain fixed. '
         'A zero-marker source stays empty; missing or unobserved masks are not invented.'),
    ]),
    ('04', 'The Swedish Study', 'Two queries / S2 by default / unknown reference answer', [
        ('Immediate, Equal Treatment',
         'First query and Second query have the same controls and saved-profile treatment. S2 with the '
         'matched eight-page profile is selected by default. Results appear immediately, with no '
         'acknowledgment checkbox or result-opening gate. This replaces the older guide behavior. '
         'Method details, exact source quotations and inspected source pages remain available.'),
        ('A Narrow Source Exception',
         'S2 admits later-release prior documents plus the exact origin document '
         'CIA-RDP79T00975A004300220001-9 on 1959-02-17. It does not admit unrelated same-day reports, '
         'future reports or an origin with a different date. Permission and quarantine rules still '
         'apply. This study-specific exception never changes the ordinary cases. S0 and S1 retain '
         'their stricter prior-only scopes.'),
        ('Context, Not Verification',
         'The reference answers remain unknown. Swedish is a saved contextual nomination, not a '
         'verified recovery; literal Swedes is source wording, not proof of the withheld delegation. '
         'These results replay saved lexical source-inspection records; they are not new normal-engine '
         'completions or original query traversals. '
         'An unavailable profile/scope remains unavailable rather than borrowing another result.'),
    ]),
    ('05', 'Read The Saved Evidence', 'Input / Sources / Results', [
        ('Follow The Binding',
         'In the nationality study, Input shows the selected masked query, Sources opens exact '
         'quotations and inspected pages, and Results shows the saved contextual nominations. '
         'Additional route details describe source-nomination edges, not a normal-engine query '
         'execution. The ordinary workbench uses Input and Facts; its saved questions, resource '
         'bindings, checkpoints and judgments remain unchanged.'),
        ('Inspect Before Concluding',
         'Check the selected query and policy, then open the exact quotation and inspect the saved '
         'source pages. Compare the document, date, release and page identity. Keep source-owned '
         'claims separate from an identity hypothesis. Historical future-inclusive controls are not '
         'default admissible evidence and do not verify either withheld word.'),
        ('Keep Comparisons Like For Like',
         'Use the same saved profile and source scope when comparing the two queries. A broader '
         'archived pool can change what was inspected and where a nomination appears; it is not '
         'interchangeable with the matched eight-page profile. Empty and unrecorded selections mean '
         'different things, and neither identifies the hidden word. Inspect the quoted source before '
         'drawing a conclusion about a candidate or its rank.'),
    ]),
]


def literal(value):
    return '(' + value.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)') + ')'


def draw_page(number, title, subtitle, sections):
    commands = ['0.97 0.96 0.92 rg 0 0 612 792 re f',
                '0.10 0.23 0.28 rg 0 694 612 98 re f',
                '0.82 0.34 0.15 rg 44 673 45 5 re f']

    def text(x, y, size, font, content, color='0.10 0.23 0.28'):
        commands.append(f'{color} rg BT /{font} {size} Tf 1 0 0 1 {x} {y} Tm {literal(content)} Tj ET')

    text(44, 756, 10, 'F2', 'MATRYOSHKA / FIELD GUIDE ADDENDUM', '0.96 0.94 0.87')
    text(44, 714, 26, 'F3', title, '1 1 1')
    text(44, 645, 11, 'F1', subtitle)
    y = 596
    for heading, body in sections:
        text(44, y, 15, 'F2', heading)
        y -= 26
        for line in textwrap.wrap(body, width=82):
            text(44, y, 11.3, 'F1', line)
            y -= 16
        y -= 27
    require(y >= 70, 'Addendum text exceeds page')
    commands.append('0.74 0.76 0.72 RG 44 55 m 568 55 l S')
    text(44, 34, 9, 'F1', 'KG PATCH / INTERACTION AND SOURCE POLICY / 22 NOVEMBER 2026')
    text(533, 34, 9, 'F2', number + ' / 05')
    return ('\n'.join(commands) + '\n').encode('ascii')


def pdf_bytes():
    # Standard PDF fonts avoid a font install or machine-specific font embedding.
    objects = [b'<< /Type /Catalog /Pages 2 0 R >>', b'',
               b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>',
               b'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>',
               b'<< /Type /Font /Subtype /Type1 /BaseFont /Times-Bold >>']
    pages = []
    for number, title, subtitle, sections in PAGES:
        stream = draw_page(number, title, subtitle, sections)
        content_id = len(objects) + 1
        objects.append(b'<< /Length ' + str(len(stream)).encode() + b' >>\nstream\n' + stream + b'endstream')
        page_id = len(objects) + 1
        objects.append(('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] '
            '/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R >> >> '
            f'/Contents {content_id} 0 R >>').encode())
        pages.append(page_id)
    objects[1] = ('<< /Type /Pages /Count 5 /Kids [' + ' '.join(f'{p} 0 R' for p in pages) + '] >>').encode()
    output = io.BytesIO()
    output.write(b'%PDF-1.4\n')
    offsets = [0]
    for identity, raw in enumerate(objects, 1):
        offsets.append(output.tell())
        output.write(f'{identity} 0 obj\n'.encode() + raw + b'\nendobj\n')
    xref = output.tell()
    output.write(f'xref\n0 {len(offsets)}\n0000000000 65535 f \n'.encode())
    for offset in offsets[1:]:
        output.write(f'{offset:010d} 00000 n \n'.encode())
    output.write(f'trailer\n<< /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n'.encode())
    return output.getvalue()


def text_bytes():
    return ('\n\n'.join(f'{n} / {title}\n{subtitle}\n\n' + '\n\n'.join(h + '\n' + b for h,b in sections)
                       for n,title,subtitle,sections in PAGES) + '\n').encode('ascii')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--append-to', type=Path, help='Optional read-only original guide; never overwritten')
    parser.add_argument('--combined-output', type=Path, help='New separate PDF under release/')
    args = parser.parse_args()
    require(bool(args.append_to) == bool(args.combined_output), 'Append requires both PDF paths')
    pdf, txt = pdf_bytes(), text_bytes()
    write(HERE / 'kg-patch-addendum.pdf', pdf)
    write(HERE / 'kg-patch-addendum.txt', txt)
    if args.append_to:
        from pypdf import PdfReader, PdfWriter
        target = within(HERE, args.combined_output)
        require(not target.exists() and target != args.append_to.resolve(), 'Never overwrite an existing guide')
        writer = PdfWriter()
        for reader in (PdfReader(args.append_to), PdfReader(io.BytesIO(pdf))):
            for page in reader.pages:
                writer.add_page(page)
        output = io.BytesIO()
        writer.write(output)
        write(target, output.getvalue())
    print(f'pages=5 pdf_sha256={sha(pdf)} text_sha256={sha(txt)}')


if __name__ == '__main__':
    main()
