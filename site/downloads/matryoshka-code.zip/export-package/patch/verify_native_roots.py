"""Replay the fourteen ordinary native roots before sealing; not full dataset QA."""
import argparse
import gc
from importlib.util import module_from_spec, spec_from_file_location
import json
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.absolute()
    assert output.is_relative_to(HERE) and not output.exists()
    import sys
    ci = WORKSPACE / 'matryoshka_demo_site/release-tools/ci'
    sys.path.insert(0, str(ci))
    spec = spec_from_file_location('ordinary_integrity_gate', ci / 'validate_manifest.py')
    gate = module_from_spec(spec)
    spec.loader.exec_module(gate)
    site = HERE / 'stage/site'
    report_raw = (site / 'data/report-v6.json').read_bytes()
    assert gate.sha(report_raw) == 'c832585b07e9b5947eaece0b0584b6e646d0127cc4999a770204ee90e5c2d089'
    report = gate.load(report_raw)
    entries = gate.load((site / 'data/api-index.json').read_bytes())['entries']
    output.parent.mkdir(parents=True, exist_ok=True)
    rows = []
    with tempfile.TemporaryDirectory(dir=output.parent) as temporary:
        reader = gate.Reader(site, Path(temporary) / 'ordinary.sqlite3', minimum_free_bytes=3 * 1024**3)
        try:
            def packet(route):
                return gate.load(reader.read(entries[route]))

            for row in report['cases']:
                for config, item in row['configurations'].items():
                    params = dict(case_id=row['case']['case_id'], config=config,
                        **{k: row['resource_binding'][k] for k in
                           ('resource_id', 'registry_sha256', 'index_sha256')})
                    condition = packet(gate.route('condition-v6', params))
                    assert condition['case'] == row['case']
                    assert condition['resource_binding'] == row['resource_binding']
                    saved = condition['configurations'][config]
                    assert saved['native_checkpoint'] == item['native_checkpoint']
                    native = packet(gate.route('native-v6', params))['native']
                    assert native['public_case'] == row['case']
                    checksum = gate.sha(gate.encoded(native['result']))
                    assert native['native_checksum'] == checksum == saved['native_checksum']
                    rows.append(dict(case_id=row['case']['case_id'], config=config,
                        native_checkpoint=item['native_checkpoint'], checksum=checksum))
                    del native, condition, saved
                    gc.collect()
        finally:
            reader.close()
    assert len(rows) == 14
    result = dict(status='PASS', scope='ORDINARY_NATIVE_ROOTS_ONLY', native=rows,
        report_sha256=gate.sha(report_raw), dataset_store_rehashed=False,
        all_logical_roots_reconstructed=False, minimum_free_bytes=3 * 1024**3,
        api_calls=0, native_runs=0)
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status='PASS', ordinary_native_roots=len(rows))))


if __name__ == '__main__':
    main()
