# Archived Initial Swedish Patch Handoff

Status: ready for main integration, not installed into the shared stage and
not published. Native S2 is blocked; the coordinating agent chose a scoped
fallback. Full normal-engine S2 remains an unmet part of the user's request;
no user acceptance of that deferral is recorded. Do not describe this as two
new native completions.

## Native Blocker

`artifacts_v01/native-preflight-v01.json` pins the actual current CIB index
and guard code. All 22,579 indexed pages are earlier-release text.
`matryoshka_demo/corpus.py:279` enforces strict-prior/whole-origin eligibility;
`matryoshka_next/facts.py:116` independently enforces earlier/both visibility,
strict-prior dates and whole-origin exclusion. The native context builder also
rejects non-earlier pages. `Session.execute` has no injected source-policy or
later-context seam. S2 needs later text plus the exact origin/date. A changed
date/origin or monkeypatched native guard would misrepresent normal execution.

All 278 archived narrative `native.json.gz` packets were inspected; neither
query has a matching native packet. No native context was materialized, no
index was built or copied, and no planning/model/native execution was run.
Two new immutable **saved-display verification completions** and two public
projections were created instead, with `native_execution: false`, no native
run reference, null native Facts/Readings/Routes and unknown gold. Their query,
rank, source quotation, hash and nomination-edge bindings were replayed through
the existing exact-source policy adapter. The pinned original bundle retains
the actual archived run references and resource context; none is renamed native.

## Integration Files

Machine-readable copy destinations and exact SHA-256 pins:
`artifacts_v01/integration-v01.json`, SHA-256
`a8f03ce29e10e24bbba760633006029e5206f639fb05fcef19efdd14fad91c91`.
All paths below are relative to `src-demo-day/phase/kg_patch_20261122/`.

- `ui/swedish-study.html`
- `ui/swedish-study.css`
- `ui/swedish-study.js`
- `ui/workbench-v6.js`: only stage labels Question -> Input and Atoms -> Facts.
- `swedish/artifacts_v01/swedish-study-patch-v01.json`
- `swedish/artifacts_v01/swedish-first-v01.json`
- `swedish/artifacts_v01/swedish-second-v01.json`
- `swedish/artifacts_v01/swedish-first-completion-v01.json`
- `swedish/artifacts_v01/swedish-second-completion-v01.json`
- `swedish/artifacts_v01/native-preflight-v01.json`

Copy the listed files to their sibling basenames under the main release site.
Retain existing `app-navigation.{js,css}`, `swedish-study-origins.json` and
`swedish-study-history.json`; the latter two existing byte pins were checked.
`ui/workbench-v6.html` contains no requested stage labels and is byte-identical
to the current release, so it was not edited. No unrelated workbench change.

The Swedish page intentionally omits the shared public replay fetch shim:
the frozen API index does not contain these new static JSON names. Its own
loader permits only literal same-directory JSON filenames, same-origin
HTTP(S), GET without credentials/redirects, and exact SHA-256 verification.
It verifies both query projections and their display completions before
showing results, failing closed on missing/swapped/tampered records. No shared
runtime or API-index edit is needed for this standalone page. Main still owns
the complete release authorization, integration seal and any publication.

## UI Behavior

First/Second query tabs receive identical treatment. S2 and the matched
eight-page archived profile are default; results are visible immediately.
There are no acknowledgment checkboxes or result-opening gates. Keyboard tabs
work; `slot=last` remains a compatible alias and normalizes to `slot=second`.
The compact flow is Input, Facts, Readings, Routes, Results. Unavailable native
Facts/Readings are stated, never fabricated. Routes are genuine saved
source-nomination edges, never an original query traversal.

Both S2 results preserve archived rank 1 `Swedish`, literal `Swedes`, eight
inspected pages and 15,300 eligible pages. Broader archived rank 2 stays rank 2.
Missing profile/scope combinations stay missing; S0/S1 empty results remain
unresolved. All three nonfocal query masks remain hidden. Exact-origin S2
scope, permission/quarantine rules, future exclusion, unknown reference answer
and lexical/native limitations remain readable in compact method details and
metadata. No exception is applied to ordinary source policy.

## Verification

`tests_final_v01.xml`: **157 passed, 1 deselected**, zero failures/errors/skips.
This includes 33 patch checks and 124 unchanged archived policy/adapter/route/
projection checks. Playwright explicitly launched its managed
`chromium_headless_shell-1248/.../chrome-headless-shell`, not installed Chrome
or a personal profile. Desktop 1440x1050 and mobile 390x844 checked both tabs,
S2 without a gate, masking, exact source dialogs and eight-page previews,
keyboard focus, preserved broader rank, unavailable/empty selections, legacy
deep links, no overflow and manifest/case/completion tamper failures.

The one deselected test is the existing archived
`test_small_public_projection_and_exact_static_integrity_pins`: its old
`public_projection_manifest_v03.json` predates the untouched archived HTML/JS/
CSS. Its full failure remains in `tests_source_regression_v01.xml` (124 passed,
1 failed). Do not repair or silently reseal that historical manifest.

Earlier attempt receipts remain: `tests_v01.xml` (shared fetch-shim integration
failure), `tests_v02.xml` (async dialog assertion timing), `tests_v03.xml`
(33 passed). `verification_attempt_v01.md`, `verification_attempt_v02.md` and
`verification_attempt_v03.md` explain the retained attempts. Final screenshots:
`browser_artifacts_final_v01/{first,second}-{1440,390}.png`; both layouts were
visually inspected. `node --check` passed for both modified JavaScript files.

New local scripts/tests: `build.py`, `test_patch.py`, `seal_handoff.py`.
Build and seal scripts write only new immutable artifacts under this worker's
`swedish/artifacts_v01/`; they never copy files into the shared stage.

## Resource Boundaries

New API calls/spend: **0 / $0**. The existing 605-receipt cumulative ledger is
unchanged at approximately **$12.7218961 of $50**; receipt-set digest is in the
manifest and integration receipt. No authorization reset or adoption.
About 5.8GB remained free at final checks, above the 3GB stop boundary.
No full dataset/index copy. No canonical native-engine, ordinary 14-case
report, production data, shared stage, deployment or publication was changed.

Worker stopped after this handoff. Main KG work remains independent.
