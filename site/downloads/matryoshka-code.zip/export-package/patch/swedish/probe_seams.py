"""Audit real injection boundaries without a paid plan or a counterfeit run."""
import gzip
import inspect
import json
from types import SimpleNamespace

from build import HERE, ROOT, OLD, budget, file_sha, freeze, read, ref
from scoped_context import SourceScope, load_bounded_sources


def rejected(callback):
    try:
        callback()
    except (ValueError,TypeError) as error:
        return dict(accepted=False,error_type=type(error).__name__,message=str(error))
    return dict(accepted=True)


def main():
    from matryoshka_current import execution
    from matryoshka_current.arm_controls import _checked_page
    from matryoshka_demo.candidates_v24 import Context
    from matryoshka_demo_v6 import reporting_local_decisions_v65 as gate
    from matryoshka_next.construction import _pages
    from matryoshka_narrative import construction, workflow, planning
    before = budget()
    paths = [ROOT / p for p in ("matryoshka_current/execution.py", "matryoshka_demo/candidates_v24.py",
        "matryoshka_demo/retrieval_v5.py", "matryoshka_current/resources.py", "matryoshka_next/construction.py",
        "matryoshka_narrative/construction.py", "matryoshka_narrative/workflow.py", "matryoshka_current/arm_controls.py",
        "matryoshka_demo_v6/reporting_local_decisions_v65.py")]
    pins = [ref(p) for p in paths]
    envelopes = read(ROOT / workflow.native.REFS)
    registry_path = ROOT / envelopes["registry_ref"]["path"]
    assert file_sha(registry_path) == envelopes["registry_ref"]["sha256"]
    registry = read(registry_path)
    parent = registry["corpora"]["cib"]
    native = parent["native_registry"]
    late_pins = read(ROOT / "experiments/recovery_comparison_20261120/swedes/resource_pins_v2.json")
    source_refs = {k:{x:native["files"][k][x] for x in ("path","sha256")}
        for k in ("documents","quarantine","source_quarantine_policy")}
    source_refs["later_pages"] = next(dict(path=p,sha256=sha) for p,sha in late_pins["source_files"].items()
        if p.endswith("/views/later/pages.jsonl"))
    assert source_refs["later_pages"]["path"].rsplit("/views/",1)[0] == source_refs["documents"]["path"].rsplit("/",1)[0]
    old = read(OLD / "swedish-study-data-v02.json")
    public_cases = old["cases"]
    contexts = []
    probes = []
    for case in public_cases:
        context = load_bounded_sources(ROOT.parent,case=case,page_ids=[old["target"]["canonical_page_id"]],
            source_refs=source_refs,parent_binding=parent)
        contexts.append(context)
        # _context genuinely accepts a loader. This probe is not run/_execute.
        loader_calls = []
        def loader(*args):
            loader_calls.append(args[3]); return context
        with execution._context(ROOT,envelopes["registry_ref"],envelopes["index_refs"]["cib"],"cib",loader) as loaded:
            assert loaded is context and loader_calls == ["cib"]
        corpus, policy = context.corpus,context.source_policy
        eligible = corpus.eligible(case)
        page = corpus.pages[0]
        ref_quote = policy.citation(0,1737,1834)
        retrieval = dict(eligible=eligible,pages=[0],passage_budget=80,source_policy=policy)
        candidate_context = SimpleNamespace(c=corpus,e=eligible,case=case,pages_used={})
        indexed = gate._pages(context.source_index,case)
        probes.append(dict(case_id=case["case_id"],query_sha256=workflow.digest(case["query"]),
            loader_injection_accepted=True,scoped_eligible_mask=eligible.page_mask.tolist(),
            exact_source_scope=policy.scope.binding(),source_page_sha256=page["source_sha256"],
            s2_literal_citation=ref_quote,
            narrative_with_source_index=rejected(lambda:_pages(case,retrieval,context.source_index)),
            narrative_with_injected_policy_only=rejected(lambda:_pages(case,retrieval)),
            shared_checked_page=rejected(lambda:_checked_page(page,case)),
            current_candidate_context_page=rejected(lambda:Context.page(candidate_context,page["id"])),
            evidence_gate_quote=rejected(lambda:gate._quote(ref_quote,*indexed,case)),
            current_execute_binding_would_match=corpus.binding == parent,
            context_is_full_discovery=False,native_execution=False))
    # Cached planning is keyed by public query, not only a historical case ID.
    cache_rows = []
    planning_files = sorted((workflow.OUTPUT / "planning").glob("*.json"))
    reading_files = sorted((workflow.OUTPUT / "readings").glob("*.json"))
    for case in public_cases:
        matches = []
        for p in planning_files:
            saved = read(p)
            if saved.get("version") == planning.VERSION and saved.get("public_query") == workflow.public_query(case):
                matches.append(ref(p))
        readings = []
        for p in reading_files:
            packet = read(p).get("packet",{})
            if packet.get("query_sha256") == workflow.digest(case["query"]):
                readings.append(ref(p))
        cache_rows.append(dict(case_id=case["case_id"],current_planning_refs=matches,current_reading_refs=readings))
    report = read(ROOT / "experiments/narrative_demo/publication/narrative_publication_656d652b622a0a065dcd18ce/report.json")
    native_versions = {}
    for row in report["cases"]:
        for config in row["configurations"].values():
            pin = config["native_checkpoint"]
            path = ROOT / pin["path"]
            assert file_sha(path) == pin["sha256"]
            with gzip.open(path,"rt") as stream:
                version = json.load(stream)["version"]
            native_versions[version] = native_versions.get(version,0) + 1
    assert [ref(p) for p in paths] == pins
    assert budget() == before
    result = dict(version="swedish-source-policy-seam-feasibility/1",native_execution=False,api_calls=0,
        canonical_code_refs=pins,ordinary_report_native_versions=native_versions,
        actual_loader_signature=str(inspect.signature(execution._context)),
        actual_narrative_signature=str(inspect.signature(workflow.Session.execute)),
        actual_constructor_signature=str(inspect.signature(construction.construct)),
        narrative_construct_cap=dict(default_pages=20,without_profile_max_pages=20,with_profile_max_pages=64,
            session_default_pages=16,session_default_drafts=24,retrieval_documents=40,retrieval_pages=80),
        current_run_free_disk_guard_gib=8,source_refs=source_refs,case_probes=probes,planning_cache=cache_rows,
        cache_file_counts=dict(planning=len(planning_files),readings=len(reading_files)),budget=before,
        adapter_ref=ref(HERE / "scoped_context.py"),
        conclusion="Explicit loader and Corpus/Eligible seams are genuine; later context is feasible without a full index copy. Neither current nor narrative candidate paths accept S2 end-to-end today: independent candidate/quote guards and current binding contract must receive the same explicit source-view policy. No paid planning or native result was attempted.")
    print(json.dumps(freeze("s2-seam-feasibility-v02.json",result),indent=2))


if __name__ == "__main__":
    main()
