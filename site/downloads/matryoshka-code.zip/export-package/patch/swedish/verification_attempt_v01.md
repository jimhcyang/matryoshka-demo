# Initial Verification Attempt

The first display build stopped at a strict full-dictionary equality check
between the public citation and the saved citation. The saved citation also
contains `raw_text_sha256`, deliberately omitted by the existing public
projection. No source, rank, result, or native execution was changed.

The corrected check compares every public source field against the saved
record, and still independently replays the complete source quotation and
page hash through the original policy adapter. The immutable native preflight
from that attempt is retained. This is a verification-harness shape mismatch,
not a new native run or a reason to relax source admission.
