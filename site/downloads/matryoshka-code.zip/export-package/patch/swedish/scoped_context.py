"""Explicit source-view prototype. No global patching or native run sealing.

Corpus/Eligible subclasses expose the shared kernel's real extension surface.
The bounded loader below supplies exact source text, not full graph discovery.
It deliberately does not masquerade as the parent's earlier-only index.
"""
from collections import defaultdict
from copy import deepcopy
from dataclasses import dataclass
from datetime import date
import hashlib
import json
from pathlib import Path
import re
import shutil
from types import SimpleNamespace

import numpy as np
from scipy import sparse

from matryoshka_demo.contracts import MASK, public_case
from matryoshka_demo.corpus import BM25, Corpus, Eligible
from matryoshka_demo.corpus_policy_v5 import PolicyView
from matryoshka_demo.io import digest
from matryoshka_next.facts import SourcePolicy
from experiments.full_resume_20261120.swedish.source_policy import ORIGIN, ORIGIN_DATE

VERSION = "explicit-scoped-source-view-prototype/1"
PUBLIC_FIELDS = {"case_id", "corpus", "task", "query", "document_id", "date", "focal_marker"}


@dataclass(frozen=True)
class SourceScope:
    corpus: str
    release: str
    cutoff: str
    origin: str
    exact_origin_at_cutoff: bool = False

    @classmethod
    def swedish_s2(cls, case):
        if set(case) != PUBLIC_FIELDS:
            raise ValueError("Seven public fields required")
        case = public_case(case)
        if case["corpus"] != "cib" or case["document_id"] != ORIGIN or case["date"] != ORIGIN_DATE:
            raise ValueError("S2 binds only its exact CIB origin/date")
        return cls("cib", "later", case["date"], case["document_id"], True)

    def check_case(self, case):
        if (case["corpus"], case["document_id"], case["date"]) != (self.corpus, self.origin, self.cutoff):
            raise ValueError("Source view belongs to another case scope")
        date.fromisoformat(self.cutoff)

    def admits(self, page):
        when = page.get("date")
        if not isinstance(when,str) or date.fromisoformat(when).isoformat() != when:
            raise ValueError("Canonical source document date required")
        same = page.get("document_id") == self.origin
        return (page.get("corpus") == self.corpus and page.get("permitted") is True
            and page.get("quarantined") is False and page.get("release") == self.release
            and page.get("visibility") in {self.release, "both"}
            and ((when < self.cutoff and not same)
                or (self.exact_origin_at_cutoff and same and when == self.cutoff)))

    def binding(self):
        return dict(version=VERSION, **vars(self))


class ScopedSourcePolicy(SourcePolicy):
    """Reuse exact index/hash/span/opacity replay; override admission explicitly."""
    def __init__(self, corpus, case, source_index, *, scope):
        scope.check_case(case)
        self.scope = scope
        super().__init__(corpus,case,source_index)

    def allowed(self, pi):
        return self.scope.admits(self.corpus.pages[int(pi)])

    def citation(self, pi, start, end):
        page = self.corpus.pages[int(pi)]
        bound = self.bound_pages.get(page["id"])
        if bound is None or any(bound.get(k) != page.get(k) for k in ("release", "quarantined", "source_page")):
            raise ValueError("Source view differs from its bound index")
        return dict(super().citation(pi,start,end),release=page["release"],source_page=page.get("source_page"),
            source_scope_sha256=digest(self.scope.binding()))


class ScopedEligible(Eligible):
    """Same node scoring/citation methods, explicit policy-derived masks."""
    def __init__(self, corpus, case):
        self.corpus, self.case = corpus, public_case(case)
        self.source_policy = ScopedSourcePolicy(corpus,self.case,corpus.source_index,scope=corpus.scope)
        self.page_mask = self.source_policy.mask()
        self.unit_mask = self.page_mask[corpus.unit_pages]
        self.surface_mask = self.page_mask[corpus.surface_pages]
        self.active = np.zeros(len(corpus.nodes),dtype=bool)
        self.active[corpus.surface_nodes[self.surface_mask]] = True
        support = {(min(e["a"],e["b"]),max(e["a"],e["b"]),corpus.pages[e["pi"]]["document_id"])
            for e in corpus.edge_rows if self.page_mask[e["pi"]] and self.active[e["a"]] and self.active[e["b"]]}
        aa,bb = [],[]
        for a,b,_ in sorted(support):
            aa.extend((a,b)); bb.extend((b,a))
        self.adjacency = sparse.coo_matrix((np.ones(len(aa)),(aa,bb)),shape=(len(self.active),len(self.active))).tocsr()
        self.page_stats = corpus.page_bm25.stats(self.page_mask)
        self.node_stats = corpus.node_bm25.stats(self.surface_mask)

    def citation(self, ui):
        unit = self.corpus.units[ui]
        return dict(super().citation(ui), **self.source_policy.citation(unit["pi"],unit["start"],unit["end"]))


class ScopedCorpus(Corpus, PolicyView):
    """A bounded exact projection, not a claim of a complete discovery universe.

PolicyView inheritance preserves this instance through retrieval_v5.policy_view;
otherwise its ordinary wrapper would recreate strict-prior Eligible masks.
No parent instance, module function, source metadata or date is modified.
"""
    def __getattr__(self, name):
        # This is a concrete view, not PolicyView's forwarding wrapper.
        raise AttributeError(name)

    def __init__(self, pages, *, scope, binding, nodes=None, units=(), occurrences=(), edges=(), hierarchy=None):
        if not 1 <= len(pages) <= 80 or len({p["document_id"] for p in pages}) > 40:
            raise ValueError("Bounded projection permits at most 40 documents / 80 pages")
        self.corpus, self.scope, self.binding = scope.corpus, scope, deepcopy(binding)
        self.pages = deepcopy(pages)
        self.source_index = {p["id"]:p for p in self.pages}
        if len(self.source_index) != len(pages):
            raise ValueError("Duplicate canonical page")
        for p in self.pages:
            if digest(p["text"]) != p["source_sha256"] or not scope.admits(p):
                raise ValueError("Projection includes an unbound or inadmissible page")
        self.page_ids = [p["id"] for p in self.pages]
        self.page_index = {pid:i for i,pid in enumerate(self.page_ids)}
        self.page_dates = np.asarray([p["date"] for p in self.pages])
        self.page_docs = np.asarray([p["document_id"] for p in self.pages])
        self.allowed = np.asarray([scope.admits(p) for p in self.pages])
        self.excluded_documents = []
        self.classification, self.files = {}, {}
        self.nodes = deepcopy(nodes or {})
        self.node_ids = list(self.nodes)
        self.node_index = {n:i for i,n in enumerate(self.node_ids)}
        self.units, self.occurrences, self.edge_rows = deepcopy(list(units)),deepcopy(list(occurrences)),deepcopy(list(edges))
        self.occurrences_by_page, self.occurrences_by_node = defaultdict(list),defaultdict(list)
        self.surfaces, surface_nodes, surface_pages = [],[],[]
        for ui,u in enumerate(self.units):
            if type(u["pi"]) is not int or not 0 <= u["pi"] < len(self.pages):
                raise ValueError("Source unit has an unknown page")
            p = self.pages[u["pi"]]
            if (type(u["start"]) is not int or type(u["end"]) is not int
                    or not 0 <= u["start"] < u["end"] <= len(p["text"])
                    or p["text"][u["start"]:u["end"]] != u["text"] or MASK.search(u["text"])):
                raise ValueError("Source unit does not replay")
            if any(type(ni) is not int or not 0 <= ni < len(self.nodes) for ni in u["nodes"]):
                raise ValueError("Source unit has an unknown node")
        for j,o in enumerate(self.occurrences):
            if type(o["page_index"]) is not int or not 0 <= o["page_index"] < len(self.pages):
                raise ValueError("Source occurrence has an unknown page")
            p = self.pages[o["page_index"]]
            if (o["node_id"] not in self.node_index or not o.get("source_row_id")
                    or type(o["start"]) is not int or type(o["end"]) is not int
                    or not 0 <= o["start"] < o["end"] <= len(p["text"])
                    or p["text"][o["start"]:o["end"]] != o["quote"]):
                raise ValueError("Source occurrence does not replay")
            self.occurrences_by_page[o["page_index"]].append(j)
            self.occurrences_by_node[o["node_id"]].append(j)
            self.surfaces.append(o["quote"])
            surface_nodes.append(self.node_index[o["node_id"]]); surface_pages.append(o["page_index"])
        for e in self.edge_rows:
            u = self.units[e["ui"]]
            if e["pi"] != u["pi"] or e["a"] not in u["nodes"] or e["b"] not in u["nodes"] or not e.get("source_row_id"):
                raise ValueError("Edge lacks its literal source unit witness")
        self.unit_pages = np.asarray([u["pi"] for u in self.units],dtype=int)
        self.surface_nodes, self.surface_pages = np.asarray(surface_nodes,dtype=int),np.asarray(surface_pages,dtype=int)
        self.membership = [(ui,ni) for ui,u in enumerate(self.units) for ni in u["nodes"]]
        self.hierarchy = deepcopy(hierarchy or {})
        self.page_bm25, self.node_bm25 = BM25([p["text"] for p in self.pages]),BM25(self.surfaces)
        self.counts = dict(pages=len(pages),nodes=len(self.nodes),units=len(self.units),relations=len(self.edge_rows))

    def eligible(self, case):
        self.scope.check_case(case)
        return ScopedEligible(self,case)


def retrieve_scoped(corpus, case, plan, *, document_budget=40, passage_budget=80):
    """Exercise the unchanged shared kernel, with honest scoped receipt metadata."""
    from matryoshka_demo.retrieval_v5 import retrieve
    from matryoshka_next.facts import public_plan
    public_plan(case,plan)
    if plan.get("leads"):
        raise ValueError("Only query-bound atoms, no generated leads")
    if not isinstance(corpus,ScopedCorpus):
        raise ValueError("Explicit scoped Corpus required")
    value = retrieve(corpus,case,plan,document_budget=document_budget,passage_budget=passage_budget,
        hierarchy=True,graph=True)
    receipt = value["receipt"]
    receipt["kernel_legacy_scope_metadata"] = {k:receipt[k] for k in ("whole_origin_excluded","source_policy_version")}
    receipt.update(source_policy_version=VERSION,whole_origin_excluded=not corpus.scope.exact_origin_at_cutoff,
        explicit_source_scope=corpus.scope.binding(),source_view_binding=deepcopy(corpus.binding),
        source_universe="EXPLICIT_BOUNDED_PROJECTION_NOT_FULL_DISCOVERY",native_execution=False)
    value.update(source_policy=value["eligible"].source_policy,source_index=corpus.source_index,
        passage_budget=passage_budget)
    return value


def bound_source(root, pin):
    root = Path(root).resolve()
    raw_path = Path(pin["path"])
    if raw_path.is_absolute() or ".." in raw_path.parts:
        raise ValueError("Workspace-relative source path required")
    path = root / raw_path
    if path.resolve() != path or not path.is_file():
        raise ValueError("Missing or redirected source path")
    return path


def scan_pinned(root, pin, *, keep=None, prefilter=None, cap=100000):
    """Hash original bytes in the same streaming read; retain only bounded rows."""
    path = bound_source(root,pin)
    sha, result = hashlib.sha256(),[]
    with path.open("rb") as stream:
        for line in stream:
            sha.update(line)
            if not line.strip() or prefilter is not None and not prefilter.search(line):
                continue
            row = json.loads(line)
            if keep is None or keep(row):
                result.append(row)
                if len(result) > cap:
                    raise ValueError("Bounded source projection cap exceeded")
    if sha.hexdigest() != pin["sha256"]:
        raise ValueError("Original source byte pin changed")
    return result


def load_bounded_sources(workspace, *, case, page_ids, source_refs, parent_binding):
    """Exact page-view loader for diagnostics; not answer-informed retrieval.

Caller-selected IDs are recorded as such. No archived ranks/candidates enter.
Full discovery must supply a separately verified native graph projection.
"""
    if shutil.disk_usage(workspace).free < 3_000_000_000:
        raise RuntimeError("Stop: below 3GB free")
    scope = SourceScope.swedish_s2(case)
    if not isinstance(page_ids,list) or not 1 <= len(page_ids) <= 80 or len(set(page_ids)) != len(page_ids):
        raise ValueError("One-to-80 unique requested page IDs required")
    wanted = set(page_ids)
    docs = {r["document_id"]:r for r in scan_pinned(workspace,source_refs["documents"])}
    quarantine = {r["page_pair_id"] for r in scan_pinned(workspace,source_refs["quarantine"])}
    guard_path = bound_source(workspace,source_refs["source_quarantine_policy"])
    guard_raw = guard_path.read_bytes()
    if hashlib.sha256(guard_raw).hexdigest() != source_refs["source_quarantine_policy"]["sha256"]:
        raise ValueError("Quarantine guard pin changed")
    guard = json.loads(guard_raw)
    quarantine.update(r["canonical_page_id"] for r in guard["quarantined_pages"] + guard["quarantined_jobs"])
    raw = scan_pinned(workspace,source_refs["later_pages"],keep=lambda r:r["canonical_page_id"] in wanted,cap=80)
    pages = {}
    for r in raw:
        doc = docs[r["document_id"]]
        pid = r["canonical_page_id"]
        if r.get("view") != "later" or pid in pages:
            raise ValueError("Wrong source release or duplicate page")
        pages[pid] = dict(id=pid,corpus="cib",document_id=r["document_id"],date=doc["document_date_iso"],
            text=r["text"],source_sha256=digest(r["text"]),release="later",visibility="later",
            source_page=r["source_page"],earlier_page=None,permitted=pid not in quarantine,
            quarantined=pid in quarantine,classification=doc.get("classification_level"),
            handling=deepcopy(doc.get("distribution_controls",[])))
    if set(pages) != wanted:
        raise ValueError("An exact requested source page is missing")
    binding = dict(version=VERSION,parent_binding=deepcopy(parent_binding),source_refs=deepcopy(source_refs),
        scope=scope.binding(),selected_page_ids=page_ids,selection_kind="CALLER_SELECTED_DIAGNOSTIC_POOL",
        complete_discovery_universe=False,graph_projection_loaded=False,native_execution=False)
    corpus = ScopedCorpus([pages[pid] for pid in page_ids],scope=scope,binding=binding)
    return SimpleNamespace(corpus=corpus,source_index=corpus.source_index,source_view_ref=binding,
        source_policy=ScopedSourcePolicy(corpus,case,corpus.source_index,scope=scope),
        parent_binding=deepcopy(parent_binding),native_execution=False)
