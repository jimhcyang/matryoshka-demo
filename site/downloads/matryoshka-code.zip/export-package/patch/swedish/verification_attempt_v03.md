# Browser And Archive Rechecks

`tests_v02.xml`: 31 passed, 2 failed. The two viewport flows completed both
tabs, ranks, source quotes, source-page previews, keyboard navigation and
profile/scope changes. The test then asserted synchronously immediately after
the asynchronous original-source fetch. It now waits for the dialog before
asserting. This was a test timing error; the original source data pin did not
change. Screenshots from both viewport flows were produced.

`tests_source_regression_v01.xml`: 124 passed, 1 failed. The failure is an
existing archived display-manifest mismatch in
`experiments/full_resume_20261120/swedish/test_public_projection.py`:
`public_projection_manifest_v03.json` expects the older archived HTML SHA
`4a1ea76bb72a24fb92475579e76dba357a9ee92040bdcbfda41982fba0f86aab`,
but the untouched archived HTML SHA is
`7b4eaa751bf4a4e1f0183b5f401de308f083151c0294227955c5246bf33ed556`.
The old JS/CSS display pins also predate their archived files. This patch did
not write any file in that directory. Do not repair or silently reseal that
historical manifest; the new patch verifies its own exact UI/data pins.
All policy, original query binding, source quotation, ordinary-policy
isolation and saved-route checks in that run passed.
