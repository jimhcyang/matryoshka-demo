"""Synthetic extension-surface tests, never native demo runs or results."""
from copy import deepcopy
from types import SimpleNamespace

import pytest

from build import digest
from scoped_context import SourceScope, ScopedCorpus, ScopedSourcePolicy, retrieve_scoped, scan_pinned
from experiments.full_resume_20261120.swedish.source_policy import ORIGIN, ORIGIN_DATE
from matryoshka_demo.corpus import Corpus, Eligible
from matryoshka_demo.corpus_policy_v5 import policy_view
from matryoshka_next.facts import SourcePolicy


def case():
    return dict(case_id="scoped_synthetic_test_only",corpus="cib",task="redaction",document_id=ORIGIN,
        date=ORIGIN_DATE,query="The delegation observed [MASK].",focal_marker="[MASK]")


def page(**changes):
    text = "The delegation observed an exercise."
    return dict(dict(id="fixture_page",corpus="cib",document_id=ORIGIN,date=ORIGIN_DATE,text=text,
        source_sha256=digest(text),release="later",visibility="later",permitted=True,quarantined=False,
        classification=None,earlier_page=None,source_page=8),**changes)


def corpus():
    p = page()
    nodes = {"fixture_event":dict(id="fixture_event",kind="Event"),"fixture_entity":dict(id="fixture_entity",kind="Entity")}
    unit = dict(id="fixture_unit",pi=0,start=0,end=len(p["text"]),text=p["text"],nodes={0,1})
    observations = [dict(node_id=n,page_index=0,start=0,end=len(p["text"]),quote=p["text"],
        label=p["text"],source_type="entities",unit_index=0,source_row_id="fixture_"+n) for n in nodes]
    edges = [dict(a=0,b=1,pi=0,ui=0,source_row_id="fixture_witness",relation="OBSERVES")]
    return ScopedCorpus([p],scope=SourceScope.swedish_s2(case()),binding={"fixture_only":True},
        nodes=nodes,units=[unit],occurrences=observations,edges=edges)


@pytest.mark.parametrize("changes,expected", [({},True),({"date":"1959-02-19"},False),
    ({"date":"1959-02-16"},False),({"document_id":"unrelated"},False),
    ({"document_id":"prior","date":"1959-02-16"},True),({"release":"earlier"},False),
    ({"visibility":"earlier"},False),({"visibility":None},False),({"permitted":False},False),
    ({"permitted":None},False),({"quarantined":True},False),({"quarantined":None},False),
    ({"corpus":"iran"},False)])
def test_exact_scope_and_no_ordinary_policy_change(changes,expected):
    p = page(**changes)
    assert SourceScope.swedish_s2(case()).admits(p) is expected
    original = SimpleNamespace(corpus="cib",pages=[p])
    assert SourcePolicy(original,case(),{p["id"]:p}).allowed(0) is False


def test_scope_cannot_be_applied_to_another_query_origin():
    for bad in [dict(case(),date="1959-02-18"),dict(case(),document_id="other"),dict(case(),gold="private")]:
        with pytest.raises(ValueError):
            SourceScope.swedish_s2(bad)


def test_corpus_eligible_subclass_and_shared_kernel_preserve_scope():
    c = corpus()
    before = deepcopy(c.pages)
    assert isinstance(c,Corpus) and isinstance(c.eligible(case()),Eligible)
    assert policy_view(c) is c
    assert c.eligible(case()).page_mask.tolist() == [True]
    query = case()["query"]
    plan = dict(query_sha256=digest(query),task="redaction",leads=[],atoms=[dict(id="test_atom",
        text=query,query_spans=[dict(start=0,end=len(query),text=query)])])
    result = retrieve_scoped(c,case(),plan)
    assert result["pages"] == [0]
    assert result["eligible"].corpus is c
    assert result["receipt"]["hierarchy_active"] is True
    assert result["receipt"]["whole_origin_excluded"] is False
    assert result["receipt"]["native_execution"] is False
    assert result["receipt"]["source_universe"] == "EXPLICIT_BOUNDED_PROJECTION_NOT_FULL_DISCOVERY"
    assert c.pages == before


def test_subclass_reuses_exact_quote_and_hash_checks():
    c = corpus()
    policy = ScopedSourcePolicy(c,case(),c.source_index,scope=c.scope)
    citation = policy.citation(0,0,len(c.pages[0]["text"]))
    assert citation["release"] == "later" and citation["earlier_page"] is None
    assert c.eligible(case()).citation(0)["text"] == citation["text"]
    policy.bound_pages = deepcopy(policy.bound_pages)
    policy.bound_pages["fixture_page"]["release"] = "earlier"
    with pytest.raises(ValueError,match="bound index"):
        policy.citation(0,0,4)


@pytest.mark.parametrize("mode", ["index","policy","candidate","checked","gate"])
def test_existing_candidate_and_quote_paths_still_reject_s2(mode):
    from matryoshka_next.construction import _pages
    from matryoshka_current.arm_controls import _checked_page
    from matryoshka_demo.candidates_v24 import Context
    from matryoshka_demo_v6 import reporting_local_decisions_v65 as gate
    c = corpus()
    e = c.eligible(case())
    p = c.pages[0]
    pool = dict(eligible=e,pages=[0],passage_budget=80,source_policy=e.source_policy)
    calls = dict(index=lambda:_pages(case(),pool,c.source_index),policy=lambda:_pages(case(),pool),
        candidate=lambda:Context.page(SimpleNamespace(c=c,e=e,case=case(),pages_used={}),p["id"]),
        checked=lambda:_checked_page(p,case()),
        gate=lambda:gate._quote(e.source_policy.citation(0,0,4),*gate._pages(c.source_index,case()),case()))
    with pytest.raises(ValueError):
        calls[mode]()


def test_narrative_80_page_constructor_is_not_an_80_page_retrieval_budget():
    from matryoshka_narrative.construction import construct
    with pytest.raises(ValueError,match="One-to-five"):
        construct(case(),{}, {},passage_budget=80,draft_budget=64,selection_profile={})


@pytest.mark.parametrize("mutation", ["hash","scope","duplicate","cap"])
def test_context_rejects_unbound_or_oversized_projection(mutation):
    p = page()
    pages = [p]
    if mutation == "hash": p["text"] += " tampered"
    if mutation == "scope": p["date"] = "1959-02-19"
    if mutation == "duplicate": pages = [p,p]
    if mutation == "cap": pages = [p] * 81
    with pytest.raises(ValueError):
        ScopedCorpus(pages,scope=SourceScope.swedish_s2(case()),binding={})


def test_streaming_pin_verification_and_no_source_copy(tmp_path):
    source = tmp_path / "source.jsonl"
    source.write_bytes(b'{"id":"synthetic_test"}\n')
    import hashlib
    pin = dict(path=source.name,sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    assert scan_pinned(tmp_path,pin) == [{"id":"synthetic_test"}]
    with pytest.raises(ValueError,match="pin changed"):
        scan_pinned(tmp_path,dict(pin,sha256="0" * 64))
    with pytest.raises(ValueError,match="relative"):
        scan_pinned(tmp_path,dict(pin,path="../source.jsonl"))
    assert list(tmp_path.iterdir()) == [source]
