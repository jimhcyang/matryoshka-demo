"""Regression and managed-headless UI checks for the isolated Swedish patch."""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import re
import threading

import pytest
from playwright.sync_api import sync_playwright

from build import OUT, ROOT, OLD, HERE, budget, read, ref
from experiments.full_resume_20261120.swedish.source_policy import admits, strict_case_page
from experiments.full_resume_20261120.swedish.storage import digest

UI = HERE.parent / "ui"
MANIFEST = read(OUT / "swedish-study-patch-v01.json")
CASES = [read(OUT / r["path"]) for r in MANIFEST["cases"]]
SHOTS = HERE / "browser_artifacts_final_v03"


def test_immutable_manifest_and_completion_pins():
    assert ref(OUT / "swedish-study-patch-v01.json", public=True)["sha256"] in (UI / "swedish-study.html").read_text()
    for projection_ref, completion_ref in zip(MANIFEST["cases"], MANIFEST["display_completions"]):
        assert ref(OUT / projection_ref["path"], public=True) == projection_ref
        assert ref(OUT / completion_ref["path"], public=True) == completion_ref
        projection = read(OUT / projection_ref["path"])
        completion = read(OUT / completion_ref["path"])
        assert completion["projection_ref"] == projection_ref
        assert completion["projection_digest"] == digest(projection)
        assert completion["native_execution"] is False
        assert completion["native_completion_claimed"] is False
        assert completion["native_run_ref"] is None
        assert completion["case_id"] == projection["public_case"]["case_id"]


@pytest.mark.parametrize("index", [0, 1])
def test_query_rank_source_and_context_are_archived_not_native(index):
    case = CASES[index]
    old = read(OLD / "swedish-study-data-v02.json")
    assert case["public_case"] == old["cases"][index]
    assert len(case["public_case"]) == 7
    assert case["public_case"]["query"].count("[MASK]") == 1
    assert case["public_case"]["query"].count("[REDACTED]") == 2
    assert "[[REDACTION_SLOT:" in case["public_case"]["query"]
    assert case["records"] == [r for r in old["records"] if r["case_id"] == case["public_case"]["case_id"]]
    assert case["native_execution"] is False and case["native_run_ref"] is None
    assert all(case[k] is None for k in ("native_facts", "native_readings", "native_routes", "gold"))
    assert case["source_context"]["graph_id"] == old["map_binding"]["graph_id"]
    assert case["ranks_modified"] is False and case["original_traversal_claimed"] is False
    s2 = next(r for r in case["records"] if r["profile_id"] == "bridge_v2" and r["policy_id"] == "S2")
    assert s2["inspected_page_count"] == 8 and s2["eligible_page_count"] == 15300
    assert [(c["rank"],c["fill"]) for c in s2["candidates"]] == [(1,"Swedish")]
    c = s2["candidates"][0]
    assert c["context"]["text"][c["source"]["start"]-c["context"]["start"]:c["source"]["end"]-c["context"]["start"]] == "Swedes"
    assert c["browser_node"]["instance_identity_asserted"] is False


def test_actual_native_blocker_and_budget():
    preflight = read(OUT / MANIFEST["preflight_ref"]["path"])
    assert preflight["native_index_visibility_counts"] == {"earlier":22579}
    assert preflight["archived_native_packets_scanned"] == 278
    assert preflight["matching_native_packets"] == []
    assert preflight["native_context_opened"] is False
    for pin in preflight["guard_code_refs"]:
        assert ref(ROOT / pin["path"]) == pin
    assert budget() == MANIFEST["budget"]
    assert MANIFEST["budget"]["new_spend_usd"] == 0


@pytest.mark.parametrize("policy", ["S0", "S1", "S2"])
@pytest.mark.parametrize("mutation", ["origin", "future", "unrelated_same_day", "wrong_origin_date", "quarantine", "not_permitted"])
def test_exception_is_exact_and_never_ordinary(policy, mutation):
    target = CASES[0]["public_case"]
    page = dict(id="fixture", corpus="cib", permitted=True, quarantined=False,
        visibility="later", release="later", date=target["date"], document_id=target["document_id"], text="fixture")
    if mutation == "future": page.update(date="1959-02-19",document_id="future")
    if mutation == "unrelated_same_day": page.update(document_id="unrelated")
    if mutation == "wrong_origin_date": page.update(date="1959-02-16")
    if mutation == "quarantine": page.update(quarantined=True)
    if mutation == "not_permitted": page.update(permitted=False)
    assert admits(page,target,policy) is (policy == "S2" and mutation == "origin")
    assert strict_case_page(page,target) is False


def test_only_requested_workbench_labels_changed():
    original = (ROOT.parent / "matryoshka_demo_site/site/workbench-v6.js").read_text()
    patched = (UI / "workbench-v6.js").read_text()
    assert patched == original.replace('[["01","Question"],["02","Atoms"]', '[["01","Input"],["02","Facts"]')
    # Main owns the current transport-index pin while integrating in parallel.
    normalize_pin = lambda text:re.sub(r'data-index-sha256="[a-f0-9]{64}"','data-index-sha256="MAIN_PIN"',text)
    assert normalize_pin((UI / "workbench-v6.html").read_text()) == normalize_pin((ROOT.parent / "matryoshka_demo_site/site/workbench-v6.html").read_text())


def test_no_paths_or_old_ack_controls_in_public_assets():
    for path in [UI / "swedish-study.html", UI / "swedish-study.js", *[OUT / r["path"] for r in MANIFEST["cases"]]]:
        text = path.read_text()
        assert not any(token in text for token in ("/Users/", "file://", "/private/", "origin-exception-ack", "origin-ack", "history-ack", "acknowledged"))
    assert 'type="checkbox"' not in (UI / "swedish-study.html").read_text()


class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path):
        name = path.split("?",1)[0].lstrip("/")
        if name in {"swedish-study.html", "swedish-study.css", "swedish-study.js"}:
            return str(UI / name)
        if re.fullmatch(r"[a-zA-Z0-9_-]+\.json", name) and (OUT / name).is_file():
            return str(OUT / name)
        if name in {"swedish-study-history.json", "swedish-study-origins.json"}:
            return str(OLD / name)
        return super().translate_path(path)

    def log_message(self, *args):
        pass


@pytest.fixture(scope="module")
def base_url():
    server = ThreadingHTTPServer(("127.0.0.1",0),partial(Handler,directory=str(HERE.parent / "stage/site")))
    thread = threading.Thread(target=server.serve_forever,daemon=True)
    thread.start()
    yield "http://127.0.0.1:" + str(server.server_port)
    server.shutdown()
    server.server_close()
    thread.join()


@pytest.fixture(scope="module")
def browser(record_testsuite_property):
    with sync_playwright() as playwright:
        managed = next(p for p in Path(playwright.chromium.executable_path).parents
            if re.fullmatch(r"chromium-\d+",p.name))
        revision = managed.name.removeprefix("chromium-")
        shell_root = managed.parent / ("chromium_headless_shell-" + revision)
        shells = [p for p in shell_root.rglob("chrome-headless-shell") if p.is_file()]
        assert len(shells) == 1, "Install the managed shell with python -m playwright install chromium --only-shell"
        record_testsuite_property("browser_binary_kind","PLAYWRIGHT_MANAGED_CHROMIUM_HEADLESS_SHELL")
        record_testsuite_property("managed_shell_path",str(shells[0]))
        browser = playwright.chromium.launch(executable_path=str(shells[0]),headless=True)
        yield browser
        browser.close()


@pytest.mark.parametrize("width,height", [(1440,1050),(390,844)])
def test_both_equal_tabs_s2_no_gate_and_source_dialogs(browser,base_url,width,height):
    page = browser.new_page(viewport=dict(width=width,height=height),device_scale_factor=1)
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.goto(base_url + "/swedish-study.html",wait_until="networkidle")
    page.wait_for_selector('body[data-study-ready="true"]',timeout=10000)
    assert page.locator('input[type="checkbox"]').count() == 0
    assert page.locator('.method-details').get_attribute('open') is None
    for slot,label in (("first","First query"),("second","Second query"),("first","First query")):
        page.get_by_role('tab',name=label,exact=True).click()
        assert page.locator('button[role="tab"][aria-selected="true"]').get_attribute('data-slot') == slot
        assert page.evaluate('document.activeElement.getAttribute("data-slot")') == slot
        assert page.locator('[data-policy="S2"] [data-rank="1"] .fill').inner_text() == 'Swedish'
        assert page.locator('#query-text mark').count() == 1
        query = page.locator('#query-text').inner_text()
        assert query.count('[MASKED]') == 3 and '[REDACTED]' not in query and 'slot_' not in query
        assert 'Swedish' not in query and 'Swedes' not in query
        assert page.locator('.stage-nav a').all_text_contents() == ['Input','Sources','Results']
        assert page.locator('#facts,#readings').count() == 0
        assert page.locator('#routes').get_attribute('open') is None
        assert page.locator('#sources').is_visible()
        assert not page.locator('.method-details').is_visible() or page.locator('.method-details').get_attribute('open') is None
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        page.locator('[data-testid="candidate-source"]').click()
        assert page.locator('dialog[open]').count() == 1
        assert page.locator('#dialog-body mark').inner_text() == 'Swedes'
        page.get_by_role('button',name='Close',exact=True).click()
        page.locator('[data-testid="inspected-sources"]').click()
        assert page.locator('#dialog-body .citation-block').count() == 8
        page.keyboard.press('Escape')
        SHOTS.mkdir(exist_ok=True)
        page.evaluate('window.scrollTo(0,0)')
        page.screenshot(path=str(SHOTS / f'{slot}-{width}.png'),full_page=True)
    page.get_by_role('tab',name='First query').focus()
    page.keyboard.press('ArrowRight')
    assert page.get_by_role('tab',name='Second query').get_attribute('aria-selected') == 'true'
    page.locator('.method-details > summary').click()
    page.select_option('#profile-select','broad_v1')
    assert page.locator('[data-testid="saved-candidate"][data-rank="2"] .fill').inner_text() == 'Swedish'
    page.get_by_role('tab',name='First query').click()
    assert page.locator('[data-testid="saved-candidate"][data-rank="2"] .fill').inner_text() == 'Swedish'
    page.get_by_role('tab',name='Second query').click()
    assert page.locator('#profile-select').input_value() == 'broad_v1'
    page.select_option('#profile-select','native_boundary_v2')
    assert page.locator('[data-testid="missing-result"]').count() == 1
    assert page.locator('[data-testid="saved-candidate"]').count() == 0
    page.select_option('#profile-select','bridge_v2')
    page.select_option('#policy-select','S1')
    assert page.locator('[data-testid="empty-result"]').count() == 1
    page.select_option('#policy-select','S0')
    assert page.locator('[data-testid="empty-result"]').count() == 1
    page.select_option('#policy-select','S2')
    assert page.locator('[data-testid="saved-candidate"]').count() == 1
    page.locator('details').filter(has=page.locator('#origin-open')).locator('summary').click()
    page.locator('#origin-open').click()
    page.wait_for_selector('dialog[open]')
    assert page.locator('dialog[open]').count() == 1
    assert '[REDACTED]' in page.locator('#dialog-body').inner_text()
    page.keyboard.press('Escape')
    page.locator('details').filter(has=page.locator('#history-open')).locator('summary').click()
    page.locator('#history-open').click()
    page.wait_for_selector('.history-record')
    assert 'Future-inclusive archived controls' in page.locator('#history-content').inner_text()
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    assert not errors
    page.close()


@pytest.mark.parametrize("slot", ["second", "last"])
def test_second_query_deep_link(browser,base_url,slot):
    page = browser.new_page()
    page.goto(base_url + '/swedish-study.html?slot=' + slot,wait_until='networkidle')
    page.wait_for_selector('body[data-study-ready="true"]',timeout=10000)
    assert page.get_by_role('tab',name='Second query').get_attribute('aria-selected') == 'true'
    assert 'slot=second' in page.url and 'policy=S2' in page.url
    page.close()


@pytest.mark.parametrize("kind", ["manifest", "case", "completion", "missing_case", "wrong_case"])
def test_tamper_or_missing_projection_fails_closed(browser,base_url,kind):
    page = browser.new_page()
    manifest_ref = ref(OUT / 'swedish-study-patch-v01.json',public=True)
    target = {'manifest':manifest_ref,'case':MANIFEST['cases'][0],
        'completion':MANIFEST['display_completions'][1],'missing_case':MANIFEST['cases'][1],
        'wrong_case':MANIFEST['cases'][1]}[kind]
    def intercept(route):
        if kind == 'missing_case': route.fulfill(status=404,body='missing')
        elif kind == 'wrong_case': route.fulfill(status=200,body=(OUT / MANIFEST['cases'][0]['path']).read_bytes(),content_type='application/json')
        else: route.fulfill(status=200,body='{}',content_type='application/json')
    page.route('**/' + target['path'],intercept)
    page.goto(base_url + '/swedish-study.html',wait_until='networkidle')
    page.wait_for_selector('[role="alert"]')
    assert page.locator('[data-testid="saved-candidate"]').count() == 0
    assert page.locator('body').get_attribute('data-study-ready') is None
    page.close()
