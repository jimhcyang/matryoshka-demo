# Final Swedish UI Handoff

Ready for main integration. **Full normal-engine S2 is deferred, not complete.**
The coordinating agent deferred this work to keep the UI/KG patch scoped; it
remains an unmet part of the user's request. No user acceptance is recorded.
No native result or native completion was produced; no API calls were made.

## Current Integration

Use `artifacts_v01/integration-v03.json`, SHA-256:
`5f89de6716af649b145604f45c1db02e60647f8cb847e7ae89e36d4114d137b8`.
It supplies exact source paths, sibling destination names and byte hashes.
It supersedes the initial integration receipt, without deleting that receipt.
All paths below are relative to `src-demo-day/phase/kg_patch_20261122/`.

- `ui/swedish-study.html`: `3165dcd567a4d760711383f69426d3da5a8b3997d5876964664f58ea07f745bc`
- `ui/swedish-study.css`: `459282af7613cede560400db1ee14d1974d30b5a4793687483cad0d6271aa28a`
- `ui/swedish-study.js`: `1a06ea98afb0777bacf49647e07c4327fa66f12f7b9a04908457f02564de4b8e`
- `ui/workbench-v6.js`: `002d1f796b2fda38c4aa19dd3d51e56bdfb18f0ee044a70b6ea73016dccf63f8`

Workbench JS changes remain only `01 Question` -> `01 Input` and `02 Atoms` ->
`02 Facts`. This worker did not edit workbench HTML; main's parallel transport
index-pin changes are preserved and all non-pin HTML bytes are tested.

Copy the six pinned static JSON files listed in `integration-v03.json` beside
the UI: the original saved-study manifest, first/second projections, first/
second saved-display verification records, and original native preflight.
Retain existing `app-navigation.{js,css}`, `swedish-study-origins.json` and
`swedish-study-history.json`; their data pins were verified. The Swedish page
uses its own literal-name, same-origin, exact-SHA-256 static loader and does
not require changes to the shared API replay index. There is no inference API.
No shared stage or production/publication file was written by this worker.

## Final UI

The source-aware study shows **Input, actual Sources, Results**, not five
empty/development stages. First/Second tabs have equal treatment. S2 is the
default with no acknowledgment checkbox or result-opening gate. Its exact
origin/date exception and engine limitation are confined to compact method
details and metadata. Both reference answers remain visibly unknown.

The query keeps one focal redaction and all three other masks. Both saved S2
context nominations preserve rank 1 `Swedish` with exact literal source
`Swedes`, eight inspected pages and 15,300 eligible pages. The source is
context, not a recovered hidden word or verified delegation identity. Broader
archived rank 2 remains rank 2; unavailable profiles/scopes never borrow ranks.
Saved source routes remain deferred, explicitly not query traversals.

## Feasibility, Not Execution

Read `S2_SEAM_PROPOSAL.md` and
`artifacts_v01/s2-seam-feasibility-v02.json` (SHA-256
`fb66659862ef3f07e27d0059b98624c9abd3f1ffbffc4d43deb61e87fba0d9f0`).

`current.execution._context(..., loader)` is a genuine seam. The isolated
`scoped_context.py` implements principled Corpus/Eligible/SourcePolicy
subclasses and a bounded, pinned later-page loader without monkeypatching,
altered dates or fake earlier metadata. Synthetic tests exercise the real
shared graph/hierarchy kernel; real source probes validate both query scopes.
This is a feasibility prototype, not full later-graph discovery or a native run.

Independent constructor/source-page/final-quote guards still reject S2 in the
unchanged normal paths. The current execution binding also cannot honestly
claim later text is its earlier index. Normal query-only planning/readings
are absent from current caches. The published 14 use narrative execution:
13 `/3`, one retained `/2`. The proposal gives precise optional scoped-policy
parameters, guard propagation, new source-view/cache lineage, bounds and
regressions needed for a later authorized engine change. Ordinary eligibility
was not changed. No paid planning was attempted on an unexecutable path.

## Verification And Preservation

`tests_final_v04.xml`: **184 passed, 1 deselected**, zero failures/errors/skips.
This includes 33 UI/projection checks, 27 scoped-interface checks and 124
unchanged archived policy/adapter/route checks. The single deselection is the
previously identified stale archived HTML/JS/CSS manifest test; its full
original failure receipt remains, and that historical manifest was not repaired.

Managed Chromium **headless shell** was explicitly selected. Both queries
passed at 1440x1050 and 390x844, including immediate S2, source quotations,
eight-page previews, keyboard tabs, masks, no empty Facts/Readings panels,
no overflow, profile/rank preservation, no-ack original-source/history access,
legacy `slot=last`, and missing/swapped/tampered JSON failing closed.
Screenshots for both slots/sizes are in `browser_artifacts_final_v03/`;
final desktop and mobile screenshots were visually inspected.
`node --check` passed for Swedish JS; the ordinary workbench labels are tested.

All first-fallback artifacts, original false native metadata, intermediate
failure receipts and earlier handoff/screenshots are archived in place.
`ARTIFACT_STATUS.md` identifies current versus historical evidence. No prior
projection or saved verification record was overwritten. Do not call those
records native completions or claim the full same-pipeline request is achieved.

API calls/new spend: **0 / $0**. Existing ledger remains 605 receipts,
approximately **$12.7218961 / $50**, with unchanged receipt-set hash in the
integration receipt. Free disk remains about 5.6GB, above the 3GB stop boundary.
No full index/dataset copy, canonical engine edit, ordinary report change,
production-data modification, deployment or publication. Main owns integration
and the final release seal. Worker stopped after this handoff.
