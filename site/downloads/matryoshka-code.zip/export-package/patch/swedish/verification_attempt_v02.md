# Initial Browser Attempt

The first browser test ran against the staged release's global public replay
transport, which replaces `window.fetch`. Its frozen API index does not contain
the new standalone study projection names. Consequently the new study failed
closed instead of loading a substituted record.

The Swedish HTML now omits that transport. Its own loader permits only literal
same-directory JSON names, same-origin HTTP(S), and exact SHA-256 matches.
The study makes no API requests and has no inference endpoint. Shared runtime,
ordinary casebook, API index and production data remain untouched. Integration
needs only the specified static files and the main release seal. The first
pytest receipt is preserved as `tests_v01.xml`; the rerun uses a new receipt.
