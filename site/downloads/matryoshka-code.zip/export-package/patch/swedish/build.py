"""Freeze honest saved-display projections; never run or impersonate native S2."""
from copy import deepcopy
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT))

from experiments.full_resume_20261120.swedish.adapter import StudyAdapter
from experiments.full_resume_20261120.swedish.source_policy import POLICIES, quote
from experiments.full_resume_20261120.swedish.storage import digest, file_sha

OLD = ROOT / "experiments/full_resume_20261120/swedish"
OUT = HERE / "artifacts_v01"
FIELDS = {"case_id", "corpus", "task", "query", "document_id", "date", "focal_marker"}


def read(path):
    return json.loads(Path(path).read_bytes())


def ref(path, *, public=False):
    return dict(path=path.name if public else path.relative_to(ROOT).as_posix(), sha256=file_sha(path))


def freeze(name, value):
    path = OUT / name
    raw = (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False) + "\n").encode()
    OUT.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != raw:
            raise ValueError("Immutable artifact changed; use a new version: " + name)
    else:
        with path.open("xb") as stream:
            stream.write(raw)
    return ref(path, public=True)


def budget():
    receipts = sorted((ROOT / "experiments/narrative_demo/api/receipts").glob("*.json"))
    values = [json.loads(p.read_text(), parse_float=Decimal) for p in receipts]
    assert all(v["authorization"] == "narrative-demo-new-phase-50-usd" for v in values)
    return dict(total_usd=str(sum((Decimal(v["charged_or_reserved_usd"]) for v in values), Decimal(0))),
        receipt_count=len(receipts), receipt_set_sha256=digest([ref(p) for p in receipts]),
        new_spend_usd=0, cumulative_ceiling_usd=50, incremental_ceiling_usd=1)


def preflight(cases):
    paths = [ROOT / "matryoshka_next/facts.py", ROOT / "matryoshka_demo/corpus.py",
        ROOT / "matryoshka_current/index.py", ROOT / "matryoshka_narrative/retrieval.py"]
    assert 'p.get("visibility") in {"earlier", "both"}' in paths[0].read_text()
    assert '(corpus.page_dates < case["date"])' in paths[1].read_text()
    refs = read(ROOT / "experiments/current_refresh/resource_handoff/registries/db09a0bd26047428e9350b57/execution_refs_v01.json")
    index_ref = refs["index_refs"]["cib"]
    index = ROOT / index_ref["path"]
    assert file_sha(index) == index_ref["sha256"]
    with sqlite3.connect(index.as_uri() + "?mode=ro&immutable=1", uri=True) as db:
        visibility = dict(db.execute("SELECT json_extract(payload,'$.visibility'),count(*) FROM page GROUP BY 1"))
        page = json.loads(db.execute("SELECT payload FROM page WHERE id=?", ("page_d884726ce3791d6d8092",)).fetchone()[0])
    assert set(visibility) == {"earlier"}
    ids = {c["case_id"] for c in cases}
    matches, count = [], 0
    for path in sorted((ROOT / "experiments/narrative_demo/runs").glob("*/native.json.gz")):
        count += 1
        with gzip.open(path, "rt") as stream:
            packet = json.load(stream)
        if packet.get("public_case", packet.get("case", {})).get("case_id") in ids:
            matches.append(ref(path))
    if matches:
        raise ValueError("A native match requires full current-code/context/completion verification before using fallback")
    return dict(status="NATIVE_S2_UNAVAILABLE_WITHOUT_POLICY_AND_CONTEXT_CHANGE",
        explanation="The current native CIB index contains earlier text only. Native retrieval and SourcePolicy both enforce strictly prior dates and whole-origin exclusion. S2 requires later text plus its exact origin/date. No policy/context injection seam exists in Session.execute; changing the public date or origin, monkeypatching guards, or presenting this lexical adapter as native would misstate execution.",
        guard_code_refs=[ref(p) for p in paths], native_index_ref=deepcopy(index_ref),
        native_index_visibility_counts=visibility, native_origin_text_sha256=digest(page["text"]),
        archived_native_packets_scanned=count, matching_native_packets=matches,
        native_context_opened=False, native_execution=False, api_calls=0)


def main():
    if shutil.disk_usage(ROOT).free < 3_000_000_000:
        raise RuntimeError("Stop: less than 3GB free")
    before = budget()
    original = read(OLD / "swedish-study-data-v02.json")
    refs = read(OLD / "artifacts_v02/refs.json")
    study = StudyAdapter(ROOT.parent, refs["bundle_ref"], verify_source_inputs=True)
    catalog = study.catalog()
    assert catalog["cases"] == original["cases"]
    assert all(set(c) == FIELDS and c["query"].count("[MASK]") == 1 for c in catalog["cases"])
    blocker = preflight(catalog["cases"])
    blocker_ref = freeze("native-preflight-v01.json", blocker)
    projections, completions = [], []
    for i, case in enumerate(catalog["cases"]):
        position = ("first", "second")[i]
        records = [deepcopy(r) for r in original["records"] if r["case_id"] == case["case_id"]]
        for record in records:
            saved = study.result(case["case_id"], record["profile_id"], record["policy_id"], opened_result=True)
            assert record["saved_record_sha256"] == saved["saved_record_sha256"]
            for candidate in record["candidates"]:
                actual = next(c for c in saved["candidates"] if c["id"] == candidate["id"])
                assert all(candidate[k] == actual[k] for k in ("id", "fill", "rank"))
                assert all(actual["source"][k] == v for k, v in candidate["source"].items())
                page = study.source(case["case_id"], record["profile_id"], record["policy_id"],
                    candidate["source"]["canonical_page_id"], opened_result=True, acknowledge_origin=True)["page"]
                quote(page, candidate["source"])
                quote(page, candidate["context"])
                navigation = study.navigation(case["case_id"], record["profile_id"], record["policy_id"],
                    candidate["id"], opened_result=True, acknowledge_origin=True)
                assert navigation["original_traversal_claimed"] is False
                if candidate.get("own_source_edge"):
                    assert all(navigation["route"]["edge_witness"].get(k) == v
                        for k, v in candidate["own_source_edge"].items())
        keys = {p["source_key"] for r in records for p in r["inspected_sources"]}
        for key in keys:
            quote(study.bundle["pages"][key], original["source_previews"][key])
        projection = dict(version="withheld-nationality-saved-projection/2", public_case=case,
            position=position, source_position=original["case_positions"][case["case_id"]],
            default_policy="S2", default_profile="bridge_v2", gold=None, native_execution=False,
            execution_kind="ARCHIVED_LEXICAL_DISPLAY_NOT_NATIVE", native_run_ref=None,
            native_facts=None, native_readings=None, native_routes=None,
            records=records, source_previews={k:original["source_previews"][k] for k in sorted(keys)},
            map_binding=original["map_binding"], source_context=study.bundle["resource_binding"],
            query_binding=study.verify_query_binding(case), source_bundle_ref=refs["bundle_ref"],
            original_projection_ref=ref(OLD / "swedish-study-data-v02.json"),
            archived_native_runs=[], original_traversal_claimed=False,
            all_displayed_citations_replayed=True, ranks_modified=False)
        projection_ref = freeze("swedish-" + position + "-v01.json", projection)
        projections.append(projection_ref)
        completions.append(freeze("swedish-" + position + "-completion-v01.json", dict(
            version="swedish-saved-display-verification-completion/1", case_id=case["case_id"],
            projection_ref=projection_ref, projection_digest=digest(projection),
            native_execution=False, native_run_ref=None, native_completion_claimed=False,
            completed_work="Exact saved query, source policy, rank, quote and nomination-edge replay",
            preflight_ref=blocker_ref, source_bundle_ref=refs["bundle_ref"],
            saved_records=[{k:r[k] for k in ("profile_id", "policy_id", "saved_record_sha256")} for r in records],
            native_facts_recorded=False, native_readings_recorded=False, gold=None)))
    after = budget()
    assert before == after, "This display-only build must not change the API ledger"
    manifest = dict(version="withheld-nationality-study-patch/1", default_policy="S2", default_profile="bridge_v2",
        native_execution=False, gold=None, profiles=original["profiles"], policies=POLICIES,
        cases=projections, display_completions=completions, preflight_ref=blocker_ref,
        native_blocker=blocker["explanation"], budget=after,
        source_projection_ref=ref(OLD / "swedish-study-data-v02.json"),
        historical_controls=original["historical_controls"], original_source_display=original["original_source_display"])
    result = freeze("swedish-study-patch-v01.json", manifest)
    print(json.dumps(dict(manifest=result, projections=projections, display_completions=completions,
        native_runs=0, api_calls=0, budget=after, free_bytes=shutil.disk_usage(ROOT).free), indent=2))


if __name__ == "__main__":
    main()
