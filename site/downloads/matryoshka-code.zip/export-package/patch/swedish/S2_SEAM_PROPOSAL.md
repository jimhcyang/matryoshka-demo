# S2 Source-Policy Seam: Deferred, Not Completed

The coordinating agent deferred normal-engine S2 to keep this UI/KG patch
scoped. It remains an unmet part of the user's request; no user acceptance of
that deferral is recorded. No canonical engine, trusted source guard,
production data or API ledger was changed.
`artifacts_v01/s2-seam-feasibility-v02.json` is the executable feasibility audit,
not a run/completion. Both original queries remain distinct seven-field inputs.

## What Actually Exists

`matryoshka_current.execution._context(..., loader)` and
`execution.run(..., resource_loader=...)` genuinely accept alternate loaders.
The unchanged shared `retrieval_v5` kernel accepts Corpus/Eligible subclasses.
This is a legitimate extension surface, not a need to monkeypatch globals.

`scoped_context.py` prototypes `SourceScope`, `ScopedSourcePolicy`,
`ScopedCorpus(Corpus, PolicyView)` and `ScopedEligible(Eligible)`:

- Scoped masks admit permitted, nonquarantined later-release prior pages plus only the exact origin/date. Ordinary SourcePolicy is unmodified.
- The subclasses preserve source IDs, text, dates, release and raw citation/hash/opacity replay; PolicyView recognizes the instance and does not replace its eligibility implementation.
- `retrieve_scoped` calls the unchanged shared BM25/graph/hierarchy kernel and explicitly corrects the inherited strict-origin receipt description. It labels its bounded universe honestly.
- `load_bounded_sources` streams hash-pinned prepared pages/documents/quarantine roots, retaining at most 40 documents/80 caller-selected pages. It creates no index or dataset copy. Its binding says diagnostic pool, not full discovery; no archived rank or candidate is used as input.

The real-origin loader probe succeeded for both cases and exact later source
citations replayed. A synthetic source-witness fixture also passes the real
shared graph/hierarchy kernel with same-day origin eligibility. This is an
interface test, not Swedish native execution. The loader prototype does not
yet materialize the complete later graph/alias/hierarchy projection.

## Independent Blockers

The actual ordinary published 14 cases use `narrative-local-execution/3`
(13 cases) and `/2` (one retained case), not `current.execution.run`.
The audit verified each native packet byte pin before reading its version.

The probes, on unchanged source metadata, fail at these exact boundaries:

1. `matryoshka_next.construction._pages`: a supplied source index constructs a new ordinary SourcePolicy, replacing the injected policy. Without that index, the separate visibility check still rejects later pages.
2. `matryoshka_current.arm_controls._checked_page`: independently rejects the origin/date and later visibility, even after scoped eligibility succeeds.
3. `matryoshka_demo.candidates_v24.Context.page`: the older/current constructor independently enforces strict-prior, whole-origin and earlier visibility.
4. `matryoshka_demo_v6.reporting_local_decisions_v65._quote`: the final evidence gate independently enforces the ordinary policy. A loader or eligibility subclass alone cannot authorize S2 through this gate.
5. `current.execution._execute`: requires the corpus binding to equal the original earlier-resource binding. Returning later text under that earlier binding would misstate provenance. `run` additionally requires 8GiB free; currently only about 5.8GB is available. That guard was not bypassed.

No current-version planning or reading packet exists for either exact public
query in the narrative planning/readings caches. No planning calls were made:
paying for a plan would not remove any of the trusted runtime blockers.

## Smallest Principled Integration

This is a proposal for a separately authorized, versioned engine change, not
code secretly installed by this worker:

1. Add a pinned `SourceViewSpec` to the context interface: corpus/release, prepared-source/graph/alias/hierarchy refs, and a versioned SourceScope. The default is the exact unchanged ordinary view/policy. S2 is explicitly bound to its origin/date. Include the new view/scope digest in execution/cache identities and completion lineage; never borrow the earlier index label.
2. Extend the source loader to construct a read-only later-view Corpus from existing saved roots. Preserve actual producer IDs, lexical/reference authority, quarantine and job-local quote provenance. Replay coordinate systems against actual later text; do not reuse earlier offsets blindly. Use streaming/in-memory projections, not a duplicate persistent index. Complete S2 source eligibility and BM25 statistics must precede retrieval; an answer-picked 80-page pool is not full normal discovery.
3. Thread `context.policy_for(case)` explicitly through narrative retrieval, construction `_pages`, source-page validation and final quote admission. Validate exact case/corpus/view/index binding and reuse the same policy object. Retain every hash/span/opacity/handling check. Only the eligibility predicate varies. The default path keeps its old behavior byte-for-byte; arbitrary caller callbacks must not acquire policy authority.
4. Give the current constructor Context and evidence-gate entry points an optional explicit source-policy parameter, propagated by callers. Replace duplicated eligibility predicates with the same trusted policy, not normalized fake earlier metadata or function-global rebinding. Version the changed gate contract; retain frozen old packets and scores.
5. Then obtain or reuse exact query-only normal planning/readings, run both queries with identical current release caps/profile, and seal genuine new runs only after source/citation/context identity checks. Regression-test ordinary origin/date/visibility exclusions, mixed-view rejection, permissions/quarantine, same-day/future negatives and exact quotes. Keep gold unknown and S2 retrospective.

Retrieval 40 documents/80 pages is supported. The narrative constructor's
session defaults are 16 pages/24 drafts; its direct defaults are 20/48. An
explicit selection profile permits at most 64 construction pages. The current
ordinary release profile must be read from its pinned configuration (commonly
32 pages/64 drafts), not inferred from the retrieval cap. Passing 80 directly
as the narrative construction-page budget fails. A fixed-pool native constructor
control after these seams is possible, but is not identical full discovery.

## Retained Evidence

`tests_scoped_v02.xml`: 27 passed, including real shared-kernel subclass use,
ordinary-policy noninterference and the five unchanged rejection boundaries.
`tests_scoped_v01.xml` retains an initial synthetic fixture missing its
`source_row_id`; the fixture and constructor validation were corrected.
Both feasibility JSON versions and all earlier saved-display artifacts remain.
No new native completion or answer was fabricated. API calls/spend remain zero.
