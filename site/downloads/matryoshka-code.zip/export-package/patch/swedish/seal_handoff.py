"""Record integration copies and test pins without changing the shared stage."""
import json
import xml.etree.ElementTree as ET

from build import HERE, ROOT, OUT, OLD, budget, file_sha, freeze, read, ref


def main():
    manifest = read(OUT / "swedish-study-patch-v01.json")
    assert budget() == manifest["budget"]
    tests = HERE / "tests_final_v04.xml"
    suite = ET.parse(tests).getroot().find("testsuite")
    assert suite is not None and int(suite.get("tests")) == 184
    assert all(int(suite.get(k,0)) == 0 for k in ("failures", "errors", "skipped"))
    copies = []
    for name in ("swedish-study.html", "swedish-study.css", "swedish-study.js", "workbench-v6.js"):
        source = HERE.parent / "ui" / name
        copies.append(dict(source=ref(source), destination=name))
    public_refs = [ref(OUT / "swedish-study-patch-v01.json",public=True),
        *manifest["cases"], *manifest["display_completions"], manifest["preflight_ref"]]
    for pin in public_refs:
        assert ref(OUT / pin["path"],public=True) == pin
        copies.append(dict(source=ref(OUT / pin["path"]), destination=pin["path"]))
    existing = []
    for key in ("historical_controls", "original_source_display"):
        pin = manifest[key]
        source = ROOT.parent / "matryoshka_demo_site/site" / pin["path"]
        assert file_sha(source) == pin["sha256"]
        assert ref(OLD / pin["path"])["sha256"] == pin["sha256"]
        existing.append(dict(name=pin["path"],sha256=pin["sha256"],retain_existing=True))
    receipt = dict(version="swedish-patch-integration-handoff/1", copies=copies,
        existing_dependencies=existing, default_policy="S2", native_execution=False,
        native_completions_created=0, saved_display_completions_created=2,
        budget=budget(), tests=dict(receipt=ref(tests),passed=184,deselected=1,
            deselection="Existing archived test_small_public_projection_and_exact_static_integrity_pins has stale historical HTML/JS/CSS pins; failure retained, original files untouched.",
            prior_failure_receipts=[ref(HERE / n) for n in ("tests_v01.xml", "tests_v02.xml", "tests_source_regression_v01.xml")]),
        unchanged_workbench_html=ref(HERE.parent / "ui/workbench-v6.html"),
        integration_note="Copy listed files to sibling paths under the main release site. The standalone Swedish page uses its own literal-name/same-origin/SHA-256 static loader, not the old shared fetch replay index. Main owns integration, authorization, new release seal and deployment; this worker does not modify the stage, runtime, report, native engine, data store or publication.")
    receipt["source_policy_feasibility_ref"] = ref(OUT / "s2-seam-feasibility-v02.json")
    receipt["full_same_pipeline_achieved"] = False
    result = freeze("integration-v03.json",receipt)
    print(json.dumps(result,indent=2))


if __name__ == "__main__":
    main()
