# KG Patch Edition

Preserve the deployed case results, canonical graph, aliases, hierarchy and
source rules. Build and test an isolated patch, then reseal and publish it.

1. Reference renderer: identify its actual canvas/layout/radius/edge code.
2. View-local sizes, compact circular fitting, shorter edge distances and legible labels.
3. Hierarchy-distance neighborhood rings, temporary legend, slow orbital motion,
   quadrant-driven labels, draggable nodes and induced links enabled by default.
4. All-evidence default search; paired controls/search synchronized unless a
   panel is directly manipulated; 32-node hierarchy defaults and 256 evidence.
5. Source-only slot labels/search and substantive visible anchors; reject
   vacuous words, preserve zero-weight navigation/provenance and hidden-value isolation.
6. Date-range hints and clamping using the actual corpus bounds.
7. Two equally treated nationality queries in the Swedish study, S2 default
   without a blocking acknowledgment. Keep its exceptional source scope and
   unknown reference answer in compact details; never apply it to ordinary cases.
8. Workbench stage names Input and Facts. Managed-shell desktop/mobile tests,
   source/binding regressions, fresh release authorization, GitHub deployment
   and direct live verification. Preserve failed attempts and the prior release.

Space: about6GB available initially. Do not duplicate the3GB dataset store,
repack the entire corpus, clear original experiments or reset the API ledger.
Stop substantial work below3GB; use the existing bounded native/context caches.
