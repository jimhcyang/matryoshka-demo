"""Real isolated-preview checks. No server, inference, response mocks, or Chrome profile."""
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import traceback
from urllib.parse import urlencode, urljoin, urlsplit

from playwright.sync_api import sync_playwright
from interaction_probes import LABEL_CONTRACT, POINT_STATE, drag_diagnostics

HERE = Path(__file__).resolve().parent
STOP_WORDS = {"a", "an", "and", "as", "at", "be", "by", "for", "from", "in", "is", "it",
              "of", "on", "or", "that", "the", "this", "to", "was", "were", "with"}


def graph_url(base, corpus, **params):
    return urljoin(base, "graph-full-v6.html") + "?" + urlencode({"corpus": corpus, **params})


def require(value, message):
    if not value:
        raise AssertionError(message)


def geometry_assertions(snapshot):
    require(snapshot["nodes"], "The real graph must contain rendered nodes")
    require(all(isinstance(node.get("r"), (int, float)) and math.isfinite(node["r"]) and node["r"] > 0
                for node in snapshot["nodes"]), "Every rendered node must have a finite positive radius")
    require(snapshot["overlapCount"] == 0, f"Node overlaps: {snapshot['overlaps']}")
    require(not snapshot["labelOverlaps"], f"Label overlaps: {snapshot['labelOverlaps']}")
    require(not snapshot["labelNodeOverlaps"], f"Label/node overlaps: {snapshot['labelNodeOverlaps']}")
    require(not snapshot.get("labelOverflows", []), f"Text overflows its label capsule: {snapshot.get('labelOverflows', [])}")
    require(not snapshot["clipped"], f"Clipped footprints: {snapshot['clipped'][:12]}")
    require(snapshot["pageOverflow"] <= 1, f"Horizontal page overflow: {snapshot['pageOverflow']}px")
    # Sparse outer rings need not populate every quadrant; their occupied-node
    # bounding box is not the aspect ratio of the circular ring geometry.
    if len(snapshot["nodes"]) >= 8 and not snapshot.get("focusMode"):
        require(snapshot["shapeAspect"] <= 1.45, f"Noncompact circular envelope: {snapshot['shapeAspect']:.3f}")
    require(snapshot["edges"]["p95PerDiameter"] <= 1.0,
            f"Long-edge p95 exceeds the usable circle diameter: {snapshot['edges']}")


def focal_brim_assertions(value):
    focal = value.get("focalLabel")
    require(focal and focal["candidate"] and focal["visible"], f"Focal label is not visible: {focal}")
    box = next((row for row in value["labels"] if row["id"] == focal["id"]), None)
    require(box, "Focal label has no measured DOM rectangle")
    center = focal["center"]
    gap = box["top"] - center["y"] - center["r"]
    horizontal = (box["left"] + box["right"]) / 2 - center["x"]
    outer_corner = max(math.hypot(x-center["x"], y-center["y"])
                       for x in (box["left"], box["right"]) for y in (box["top"], box["bottom"]))
    hole = value["bands"][0]["inner"] * value["transform"]["scale"]
    metrics = {"id":focal["id"], "placement":box["placement"], "brim_gap_px":gap,
               "horizontal_offset_px":horizontal, "farthest_corner_radius_px":outer_corner,
               "hole_radius_px":hole, "center":center, "box":box}
    require(box["placement"] == "lower-rim" and 5 <= gap <= 15 and abs(horizontal) <= 13,
            f"Focal caption is not attached to its own lower brim: {metrics}")
    require(outer_corner <= hole + 1, f"Focal caption extends out of the reserved inner hole: {metrics}")
    return metrics


def own_caption_clearance_assertions(value, identity):
    node = next(row for row in value["nodes"] if row["id"] == identity)
    box = next((row for row in value["labels"] if row["id"] == identity), None)
    require(box, f"Explicitly requested caption is not rendered: {identity}")
    distance = math.hypot(node["x"]-max(box["left"], min(node["x"], box["right"])),
                          node["y"]-max(box["top"], min(node["y"], box["bottom"])))
    gap = distance - node["r"]
    require(gap >= 3, f"Caption covers its own painted node or clearance: {identity}, gap={gap}, box={box}, node={node}")
    return {"id":identity,"own_circle_clearance_px":gap,"box":box}


def focused_ring_assertions(page):
    rings = page.evaluate("__kgQA.ringDistances()")
    occupied = [row for row in rings if row["count"]]
    require(len(occupied) >= 2, f"Actual fixture lacks multiple hierarchy distances: {rings}")
    for left, right in zip(occupied, occupied[1:]):
        require(left["maximum"] < right["minimum"], f"Interleaved hierarchy rings: {rings}")
    actual = page.evaluate("__kgQA.ringGeometry()")
    require(actual["arcs"] and all(any(abs(arc["r"]-band[side]) < 1e-6 for arc in actual["arcs"])
            for band in actual["bands"] for side in ("inner", "outer")), f"Ring boundaries not drawn: {actual}")
    require(all(abs(arc["axisX"]-arc["axisY"]) < 1e-6 and not arc["clipped"] for arc in actual["arcs"]),
            f"Actual ring arc is anisotropic or clipped: {actual}")
    require(abs(actual["maximumRatio"]-actual["minimumRatio"]) < 1e-6,
            f"Directional screen/world radius distortion: {actual}")
    return {"distances":rings, "arcs":actual}


def run_browser(base, output, fixtures, corpora, viewports, groups, renderer_sha256, unfrozen=False, asset_pins=None):
    parts = urlsplit(base)
    require(parts.scheme == "http" and parts.hostname in {"127.0.0.1", "localhost", "::1"},
            "Only an explicitly supplied isolated loopback preview is allowed")
    require(not parts.query and not parts.fragment and not parts.username, "Preview must be a clean base URL")
    base = base.rstrip("/") + "/"
    origin = f"{parts.scheme}://{parts.netloc}"
    report = {"started_utc": datetime.now(timezone.utc).isoformat(), "preview": base,
              "expected_renderer_sha256": renderer_sha256,
              "unfrozen_preview": unfrozen, "final_signoff": False,
              "expected_presentation_assets": asset_pins or {},
              "managed_chromium_headless_shell": True, "model_api_calls": 0,
              "native_executions": 0, "response_mocking": False, "cells": [], "external_requests": []}
    probe = (HERE / "probe.js").read_text()
    with sync_playwright() as pw:
        # Default headless Chromium uses Playwright's managed headless shell, never installed Chrome.
        browser = pw.chromium.launch(headless=True)
        try:
            for corpus in corpora:
                for viewport in viewports:
                    for group in groups:
                        name = f"{corpus}-{viewport}-{group}"
                        context = browser.new_context(viewport={"width": 390, "height": 844}
                            if viewport == "mobile" else {"width": 1440, "height": 1000},
                            reduced_motion="no-preference" if group in {"orbit", "focus"} else "reduce",
                            service_workers="block")
                        page = context.new_page()
                        page.set_default_timeout(15000)
                        errors = []
                        renderer_responses = []
                        presentation_responses = {}
                        cell = {"name": name, "checks": [], "pageerrors": errors}
                        page.on("pageerror", lambda error, sink=errors: sink.append(str(error)))
                        page.on("response", lambda response, sink=renderer_responses: sink.append(response)
                                if response.request.resource_type == "script" and
                                urlsplit(response.url).path.endswith("/graph-full-v6.js") else None)
                        def record_presentation(response, sink=presentation_responses):
                            name = urlsplit(response.url).path.rsplit('/', 1)[-1]
                            if name in (asset_pins or {}):
                                sink[name] = response
                        page.on("response", record_presentation)

                        def route_guard(route):
                            request = route.request
                            wire_path = urlsplit(request.url).path
                            if (request.url.startswith(origin + "/") and request.method in {"GET", "HEAD"}
                                    and "/api/" not in wire_path):
                                route.continue_()
                            else:
                                report["external_requests"].append({"url": request.url, "method": request.method})
                                route.abort()

                        context.route("**/*", route_guard)

                        def check(label, operation):
                            item = {"name": label}
                            try:
                                item["details"] = operation()
                                overflows = page.evaluate("""()=>[...document.querySelectorAll('.map-label')]
                                  .filter(el=>el.getClientRects().length&&(el.scrollHeight>el.clientHeight+1||el.scrollWidth>el.clientWidth+1))
                                  .map(el=>{const style=getComputedStyle(el);return {id:el.dataset.nodeLabel,text:el.textContent,
                                    scrollHeight:el.scrollHeight,clientHeight:el.clientHeight,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth,
                                    fontFamily:style.fontFamily,fontWeight:style.fontWeight,fontSize:style.fontSize,whiteSpace:style.whiteSpace,
                                    characterCodes:[...el.textContent].map(c=>c.codePointAt(0))};})""")
                                require(not overflows, f"Visible label capsule text overflow: {overflows}")
                                item["pass"] = True
                            except Exception:
                                item["pass"] = False
                                item["error"] = traceback.format_exc()
                                try:
                                    item["last_measurement"] = page.evaluate("window.__kgQALastSnapshot||null")
                                    item["pointer_diagnostics"] = page.evaluate("window.__kgQALastPointer||null")
                                    item["pan_diagnostics"] = page.evaluate("window.__kgQALastPan||null")
                                    item["click_diagnostics"] = page.evaluate("window.__kgQALastClick||null")
                                    item["label_placement_diagnostics"] = page.evaluate("window.__kgQALastLabelTrace||null")
                                    page.screenshot(path=str(output / f"{name}-FAIL-{label}.png"))
                                except Exception as error:
                                    item["capture_error"] = str(error)
                            cell["checks"].append(item)
                            print(f"{'PASS' if item['pass'] else 'FAIL'} {name}/{label}", flush=True)
                            return item["pass"]

                        def capture(label):
                            page.screenshot(path=str(output / f"{name}-{label}.png"))

                        def ready(**params):
                            page.goto(graph_url(base, corpus, **params),
                                      wait_until="domcontentloaded")
                            page.wait_for_function("""()=>document.body.dataset.graphReady==='true'||
                              document.querySelector('#purpose')?.textContent.startsWith('Frozen exploration graph unavailable:')""",
                              timeout=120000)
                            require(page.evaluate("document.body.dataset.graphReady==='true'"),
                                    page.locator('#purpose').text_content())
                            page.add_script_tag(content=probe)
                            page.evaluate("() => document.fonts.ready")
                            # Hash the actual script response used by this page, not a later refetch.
                            require(renderer_responses, "No actual renderer script response was captured")
                            served = renderer_responses[-1]
                            require(served.ok, "Served renderer is unavailable")
                            served_sha = hashlib.sha256(served.body()).hexdigest()
                            cell["served_renderer_sha256"] = served_sha
                            cell["offline_renderer_matches"] = served_sha == renderer_sha256
                            if not unfrozen:
                                require(served_sha == renderer_sha256, f"Preview renderer is stale or different: {served_sha}")
                            cell["presentation_assets"] = {}
                            for asset_name, expected in (asset_pins or {}).items():
                                require(asset_name in presentation_responses, f"Presentation response not captured: {asset_name}")
                                actual = hashlib.sha256(presentation_responses[asset_name].body()).hexdigest()
                                cell["presentation_assets"][asset_name] = actual
                                if not unfrozen:
                                    require(actual == expected, f"Presentation asset changed during this run: {asset_name} {actual}")
                            binding = page.evaluate("({g:refreshBinding.graph_run_id,h:refreshBinding.hierarchy_run_id})")
                            fixture_binding = fixtures["corpora"][corpus]
                            require(binding == {"g": fixture_binding["graph_run_id"], "h": fixture_binding["hierarchy_run_id"]},
                                    "Preview substituted a different graph/hierarchy binding")
                            page.wait_for_timeout(200)

                        try:
                            ready()
                            fixture = fixtures["corpora"][corpus]
                            if group == "layout":
                                layout_checks(page, fixture, check, capture, corpus == "cib" and viewport == "desktop")
                            elif group == "focus":
                                focus_record(page, fixture["focus"]["id"])
                                focus_neighborhood(page, fixture["focus"]["id"])
                                def focal_probe():
                                    value = snapshot(page)
                                    capture("focal-label")
                                    return focal_brim_assertions(value)
                                check("actual_focal_identity_label_visible", focal_probe)
                                def focused_geometry():
                                    value = snapshot(page)
                                    geometry_assertions(value)
                                    return value
                                check("focused_scene_geometry", focused_geometry)
                                check("focused_ring_order_isotropy_and_clipping", lambda: focused_ring_assertions(page))
                                orbit_checks(page, fixture, check, capture)
                            elif group == "paired":
                                paired_checks(page, fixture, check, capture, ready)
                            elif group in {"source", "controls"}:
                                source_checks(page, fixture, check, capture, include_slots=group == "source")
                            elif group == "orbit":
                                orbit_checks(page, fixture, check, capture)
                        except Exception:
                            cell["checks"].append({"name": "preview_ready", "pass": False, "error": traceback.format_exc()})
                        finally:
                            check("no_uncaught_page_errors", lambda: require(not errors, errors))
                            try:
                                capture("final")
                            except Exception as error:
                                cell["screenshot_error"] = str(error)
                            cell["pass"] = all(row["pass"] for row in cell["checks"])
                            report["cells"].append(cell)
                            context.close()
                            (output / "browser-progress.json").write_text(json.dumps(report, indent=2) + "\n")
        finally:
            browser.close()
    report["pass"] = all(cell["pass"] for cell in report["cells"]) and not report["external_requests"]
    return report


def snapshot(page):
    return page.evaluate("window.__kgQALastSnapshot=__kgQA.snapshot()")


def focus_record(page, identity):
    return page.evaluate("""async id => {
      const p=state.panels.current; await ensureEvidenceSearchCatalog([p.view.key]);
      const record=state.searchEvidenceIndexes[p.view.key].get(id);
      if(!record)throw Error('Exact saved semantic identity is absent: '+id);
      await p.openLocalCommunity(record,{scroll:false});
      return {id:record.id,label:record.label};
    }""", identity)


def focus_neighborhood(page, identity):
    page.evaluate("""async id => {
      const p=state.panels.current;
      const record=p.nodeMap.get(id)||state.searchEvidenceIndexes[p.view.key]?.get(id);
      if(!record)throw Error('Exact neighborhood identity absent');
      await p.focusNeighborhood(record,{scroll:false});
    }""", identity)
    page.wait_for_function("!state.panels.current.inducedLoading", timeout=120000)


def layout_checks(page, fixture, check, capture, wait_for_legend_timeout=False):
    def defaults():
        actual = page.evaluate("({scope:state.searchScope,select:document.querySelector('#search-scope').value,cap:state.panels.current.nodeLimit})")
        require(actual == {"scope": "evidence", "select": "evidence", "cap": 32}, actual)
        return actual
    check("all_evidence_and_32_hierarchy_defaults", defaults)

    for level in ("domain", "theme", "community", "evidence"):
        def level_check(level=level):
            if not page.locator("#map-options").evaluate("el=>el.open"):
                page.locator("#map-options > summary").click()
            page.locator(f'button[data-level="{level}"]').click()
            page.wait_for_function("level=>state.panels.current.level===level", arg=level, timeout=120000)
            page.wait_for_timeout(350)
            if page.locator("#map-options").evaluate("el=>el.open"):
                page.locator("#map-options > summary").click()
            value = snapshot(page)
            require(value["nodeLimit"] == (256 if level == "evidence" else 32), value["nodeLimit"])
            geometry_assertions(value)
            capture(level)
            return value
        check(f"real_{level}_geometry", level_check)
        def fit_check(level=level):
            details = page.evaluate("__kgQA.repeatFit()")
            page.evaluate("value=>window.__kgQALastFit=value", details)
            require(details["samples"][-1]["maximumDriftPx"] <= 1,
                    f"Repeated Fit keeps changing {level} coordinates: {details}")
            return details
        check(f"real_{level}_repeat_fit", fit_check)

    check("exact_saved_identity_to_community", lambda: focus_record(page, fixture["focus"]["id"]))

    def community_geometry():
        value = snapshot(page)
        require(value["nodeLimit"] == 256, "Scoped evidence default must be 256")
        geometry_assertions(value)
        capture("scoped-evidence")
        return value
    check("scoped_evidence_geometry", community_geometry)

    def neighborhood():
        focus_neighborhood(page, fixture["focus"]["id"])
        value = snapshot(page)
        require(value["focus"] == fixture["focus"]["id"], "Focus changed to a label substitute")
        geometry_assertions(value)
        rings = page.evaluate("__kgQA.ringDistances()")
        occupied = [row for row in rings if row["count"]]
        require(len(occupied) >= 2, f"Fixture does not exercise multiple hierarchy distances: {rings}")
        for left, right in zip(occupied, occupied[1:]):
            require(left["maximum"] < right["minimum"], f"Interleaved hierarchy rings: {rings}")
        capture("neighborhood")
        return {"geometry": value, "rings": rings}
    check("hierarchy_distance_neighborhood_geometry", neighborhood)

    def circular_rings():
        value = page.evaluate("__kgQA.ringGeometry()")
        require(value["arcs"] and len(value["arcs"]) >= value["bandCount"] and all(
                    any(abs(arc["r"]-band[boundary]) < 1e-6 for arc in value["arcs"])
                    for band in value["bands"] for boundary in ("inner", "outer")),
                f"Actual renderer did not draw each populated hierarchy ring: {value}")
        require(all(abs(arc["axisX"]-arc["axisY"]) < 1e-6 and not arc["clipped"] for arc in value["arcs"]),
                f"Actual ring drawing is anisotropic or clipped: {value}")
        require(abs(value["maximumRatio"]-value["minimumRatio"]) < 1e-6,
                f"Screen/world radius mapping differs across ring directions: {value}")
        return value
    check("actual_ring_arcs_are_isotropic_and_unclipped", circular_rings)

    def focal_label():
        value = snapshot(page)
        metrics = focal_brim_assertions(value)
        capture("focal-label")
        return metrics
    check("actual_focal_identity_label_visible", focal_label)

    def legend():
        actual = page.evaluate("""()=>{
          const legend=state.panels.current.ringLegend;
          if(!legend)throw Error('Neighborhood has no temporary legend');
          return {visible:!legend.hidden,text:legend.textContent,groups:legend.querySelectorAll('div').length,
            placement:__kgQA.snapshot().legend};
        }""")
        require(actual["visible"] and actual["groups"] >= 4, actual)
        require(not actual["placement"]["clippedByOwnCanvas"] and not actual["placement"]["overlapsToolbar"],
                f"Misplaced neighborhood legend: {actual['placement']}")
        page.locator('.neighborhood-legend button[aria-label="Hide neighborhood legend"]').click()
        require(page.evaluate("state.panels.current.ringLegend.hidden"), "Legend close does not dismiss it")
        page.evaluate("state.panels.current.showRingLegend()")
        if wait_for_legend_timeout:
            page.wait_for_function("state.panels.current.ringLegend.hidden", timeout=15000)
            actual["auto_dismissed"] = True
        return actual
    check("four_group_legend_can_be_dismissed_and_is_temporary", legend)

    def induced():
        actual = page.evaluate("""async()=>{
          const p=state.panels.current, ids=p.nodes.map(n=>n.id), set=new Set(ids), focus=p.neighborhood.node.id;
          const expected=(await ensureInducedEdges(p.view,ids)).filter(e=>e.source!==focus&&e.target!==focus);
          const pair=e=>[e.source,e.target].sort().join('|');
          const drawn=new Set(p.edges.map(pair));
          return {enabled:p.showNeighborEdges,error:p.inducedError,expected:expected.length,
            missing:expected.filter(e=>set.has(e.source)&&set.has(e.target)&&!drawn.has(pair(e))).map(pair)};
        }""")
        require(actual["enabled"] and not actual["error"], actual)
        require(not actual["missing"], actual)
        return actual
    check("induced_neighbor_links_on_by_default", induced)

    def fit_idempotent():
        before = snapshot(page)
        page.evaluate("state.panels.current.fit()")
        first = snapshot(page)
        page.evaluate("state.panels.current.fit()")
        second = snapshot(page)
        require(before["signature"] == first["signature"] == second["signature"], "Fit modified graph facts")
        first_map = {n["id"]: n for n in first["nodes"]}
        drift = max((math.hypot(n["x"] - first_map[n["id"]]["x"], n["y"] - first_map[n["id"]]["y"])
                     for n in second["nodes"]), default=0)
        require(drift <= 1, f"Repeated Fit compounds shape changes: {drift:.2f}px")
        return {"repeat_fit_max_drift_px": drift}
    check("fit_preserves_facts_and_does_not_compound_ellipse", fit_idempotent)


def paired_checks(page, fixture, check, capture, ready):
    ready(view="pair")

    def panel_boxes():
        value = page.evaluate("""()=>['legacy','current'].map(name=>{
          const p=state.panels[name],r=p.canvas.getBoundingClientRect();
          return {name,width:r.width,height:r.height,left:r.left,top:r.top,right:r.right,bottom:r.bottom,
            visible:!p.canvas.closest('[data-panel]').hidden};})""")
        require(all(v["visible"] and v["width"] > 100 and v["height"] > 100 for v in value), value)
        a, b = value
        require(a["right"] <= b["left"] + 1 or b["right"] <= a["left"] + 1 or
                a["bottom"] <= b["top"] + 1 or b["bottom"] <= a["top"] + 1, "Paired canvases overlap")
        return value
    check("two_physical_paired_panels", panel_boxes)

    def left_activity():
        labels = page.locator('[data-panel="legacy"] .map-label')
        def exposed_label_index():
            return labels.evaluate_all("""els=>els.findIndex(el=>{
              const b=el.getBoundingClientRect(),top=document.elementFromPoint(b.left+b.width/2,b.top+b.height/2);
              return b.width>0&&b.height>0&&(top===el||top?.closest('.map-label')===el);
            })""")
        index = exposed_label_index()
        setup_steps = []
        if index < 0:
            page.locator("#legacy-canvas").press("ArrowRight")
            setup_steps.append("Physical left ArrowRight selected and pinned its label")
            index = exposed_label_index()
        require(index >= 0, "No physically exposed left-panel label for activity regression")
        wanted = labels.nth(index).get_attribute("data-node-label")
        page.locator("#current-canvas").press("ArrowRight")
        require(page.evaluate("state.activePanelName") == "current", "Right keyboard setup did not activate current")
        page.locator("#legacy-canvas").scroll_into_view_if_needed()
        labels.nth(index).click()
        page.wait_for_function("id=>state.activePanelName==='legacy'&&state.panels.legacy.drawerOpen&&state.panels.legacy.selected?.id===id",
                               arg=wanted, timeout=15000)
        page.keyboard.press("Escape")
        page.locator("#current-canvas").press("ArrowRight")
        page.locator("#legacy-canvas").press("ArrowRight")
        active = page.evaluate("({name:state.activePanelName,id:state.panels.legacy.selected?.id})")
        require(active["name"] == "legacy" and active.get("id"), "Left keyboard input did not activate its physical panel")
        page.locator("#map-context").click()
        page.wait_for_function("id=>state.panels.legacy.neighborhood?.node.id===id&&state.panels.legacy.graph.focusNodeId===id",
                               arg=active["id"], timeout=120000)
        require(page.locator("#map-context").inner_text() == "Community", "Toolbar mode does not reflect active left neighborhood")
        capture("left-label-keyboard-active")
        return {"setup_steps":setup_steps,"physically_clicked_left_label":wanted,"left_keyboard_selected":active,
                "left_actual_focus":page.evaluate("state.panels.legacy.graph.focusNodeId")}
    check("left_physical_label_and_keyboard_activate_toolbar_target", left_activity)
    ready(view="pair")

    def caps():
        if not page.locator("#map-options").evaluate("el=>el.open"):
            page.locator("#map-options > summary").click()
        page.locator('button[data-level="community"]').click()
        page.wait_for_function("Object.values(state.panels).every(p=>p.level==='community')", timeout=120000)
        control = page.locator('#map-options [data-node-cap="current"]')
        require(control.is_enabled(), "Real toolbar drawing cap is disabled even in the complete community layer")
        control.select_option("256")
        if page.locator("#map-options").evaluate("el=>el.open"):
            page.locator("#map-options > summary").click()
        page.wait_for_timeout(350)
        actual = page.evaluate("Object.values(state.panels).map(p=>p.nodeLimit)")
        require(actual == [256, 256], f"Control did not synchronize panels: {actual}")
        return actual
    check("drawing_control_synchronizes_pair", caps)

    def search():
        page.locator("#graph-search").fill(fixture["focus"]["label"])
        page.wait_for_function("!document.querySelector('#search-status').textContent.startsWith('Loading')&&state.searchResults.current.length>0", timeout=120000)
        buttons = page.locator('[data-search-panel="current"]')
        require(buttons.count() > 0, "Actual paired search produced no current result")
        exact = page.evaluate("id=>state.searchResults.current.findIndex(r=>r.id===id)", fixture["focus"]["id"])
        require(exact >= 0, "Search replaced the exact semantic identity")
        page.locator(f'[data-search-panel="current"][data-search-index="{exact}"]').click(force=True)
        page.wait_for_function("""id=>Object.values(state.panels).every(p=>p.level==='evidence'&&
          (p.selected?.id===id||p.pinnedFocusIds.has(id))&&p.nodeMap.has(id)&&!p.v64Busy&&
          p.canvas.dataset.searchTarget===id&&p.canvas.dataset.searchTargetState==='present')""",
          arg=fixture["focus"]["id"], timeout=120000)
        return page.evaluate("Object.values(state.panels).map(p=>({name:p.name,level:p.level,selected:p.selected?.id,trail:p.trail.map(n=>n.id)}))")
    check("actual_search_result_navigation_synchronizes_pair", search)

    def physical_pan():
        require(page.evaluate("!state.panels.current.v64Busy&&state.panels.current.canvas.dataset.searchTargetState==='present'"),
                "Physical pan requires completed search navigation, not its evidence-stage animation")
        page.locator("#current-canvas").scroll_into_view_if_needed()
        before = page.evaluate("({legacy:__kgQA.snapshot('legacy'),current:__kgQA.snapshot('current')})")
        target = page.evaluate("__kgQA.emptyPoint('current')")
        box = page.locator("#current-canvas").bounding_box()
        x, y = box["x"] + target["x"], box["y"] + target["y"]
        # Pick a bounded direction so the complete drag remains on the canvas.
        dx = 32 if target["x"] < box["width"] / 2 else -32
        pan_state = """point=>{
          const p=state.panels.current,r=p.canvas.getBoundingClientRect(),local={x:point.x-r.left,y:point.y-r.top},
            top=document.elementFromPoint(point.x,point.y);
          return {client:point,local,canvas:{left:r.left,top:r.top,width:r.width,height:r.height,right:r.right,bottom:r.bottom},
            topElement:top?{tag:top.tagName,id:top.id,className:top.className,canvas:top===p.canvas}:null,
            hitNode:p.hitNode(local)?.id||null,hitEdge:p.hitEdge(local)?.id||null,transform:{...p.transform},
            drag:p.drag?{node:p.drag.node?.id||null,moved:p.drag.moved,start:p.drag.start,last:p.drag.last}:null,
            selected:p.selected?.id,level:p.level,nodeCount:p.nodes.length,navigationRevision:p.navigationRevision,
            searchTarget:p.canvas.dataset.searchTarget,searchTargetState:p.canvas.dataset.searchTargetState,
            busy:p.v64Busy,scrollTop:document.querySelector('.graph-grid').scrollTop};
        }"""
        trace={"chosen":target,"before":page.evaluate(pan_state,{"x":x,"y":y})}
        page.evaluate("value=>window.__kgQALastPan=value",trace)
        page.mouse.move(x, y)
        trace["hovered"]=page.evaluate(pan_state,{"x":x,"y":y})
        page.mouse.down()
        trace["pointerDown"]=page.evaluate(pan_state,{"x":x,"y":y})
        page.mouse.move(x + dx, y + 18, steps=8)
        trace["duringDrag"]=page.evaluate(pan_state,{"x":x+dx,"y":y+18})
        page.mouse.up()
        trace["afterRelease"]=page.evaluate(pan_state,{"x":x+dx,"y":y+18})
        page.evaluate("value=>window.__kgQALastPan=value",trace)
        after = page.evaluate("({legacy:__kgQA.snapshot('legacy'),current:__kgQA.snapshot('current')})")
        require(before["legacy"]["transform"] == after["legacy"]["transform"], "Physical pan moved the other panel")
        require(abs(after["current"]["transform"]["x"] - before["current"]["transform"]["x"] - dx) < 2,
                "Physical pan did not move the manipulated canvas")
        require(before["current"]["signature"] == after["current"]["signature"], "Pan changed topology or mass")
        capture("physical-pan")
        return {"before": {k:v["transform"] for k,v in before.items()}, "after": {k:v["transform"] for k,v in after.items()},
                "pointer_trace":trace}
    check("physical_canvas_pan_is_independent", physical_pan)

    def absent_counterpart():
        row = page.evaluate("""async()=>{
          const a=state.panels.legacy,b=state.panels.current;
          await ensureEvidenceSearchCatalog([a.view.key,b.view.key]);
          const earlier=state.searchEvidenceIndexes[a.view.key];
          const rows=state.searchEvidenceViews[b.view.key].filter(r=>!earlier.has(r.id)&&r.community_id&&!r.overlay_slot);
          const row=rows.find(r=>r.type==='Entity'&&r.label.length<=100)||rows[0];
          if(!row)throw Error('No actual later-only counterpart-negative fixture found');
          const counterpart=await counterpartSearchRecord(a,row);
          if(counterpart!==null)throw Error('Missing semantic ID was replaced by another counterpart');
          await navigateSharedSearch('current',row);
          return {id:row.id,label:row.label,type:row.type,
            currentPresent:b.nodeMap.has(row.id),currentState:b.canvas.dataset.searchTargetState,
            earlierPresent:a.nodeMap.has(row.id),earlierState:a.canvas.dataset.searchTargetState,
            earlierSelected:a.selected?.id,earlierPinned:[...a.pinnedFocusIds],
            earlierLevel:a.level,earlierParents:a.trail.map(n=>n.id)};
        }""")
        require(row["currentPresent"] and row["currentState"] == "present", row)
        require(not row["earlierPresent"] and row["earlierState"] == "absent" and
                row.get("earlierSelected") != row["id"] and row["id"] not in row["earlierPinned"],
                f"Paired counterpart was invented: {row}")
        capture("absent-counterpart")
        return row
    check("missing_paired_counterpart_not_invented", absent_counterpart)


def source_checks(page, fixture, check, capture, include_slots=True):
    def dates():
        expected = fixture["date_range"]
        actual = page.evaluate("({bounds:state.data.corpus_metadata.date_range,policy:{...state.asOfPolicy},min:document.querySelector('#as-of-date').min,max:document.querySelector('#as-of-date').max,placeholder:document.querySelector('#as-of-date').placeholder})")
        require(actual["bounds"] == expected, actual)
        require(actual["policy"]["minimum"] == expected["minimum"] and actual["policy"]["maximum"] == expected["maximum"], actual)
        before = page.evaluate("({g:refreshBinding.graph_run_id,h:refreshBinding.hierarchy_run_id})")
        control = page.locator("#as-of-date")
        for attempted, wanted in (("1900-01-01", expected["minimum"]), ("2099-12-31", expected["maximum"])):
            control.fill(attempted, force=True)
            control.press("Enter")
            page.wait_for_timeout(150)
            got = page.evaluate("({cutoff:state.asOfPolicy.cutoff,input:document.querySelector('#as-of-date').value})")
            require(got == {"cutoff": wanted, "input": wanted}, f"Out-of-corpus date not clamped: {got}")
        require(before == page.evaluate("({g:refreshBinding.graph_run_id,h:refreshBinding.hierarchy_run_id})"), "Dates refit graph or hierarchy")
        hints = page.locator("#temporal-control").inner_text()
        require(expected["minimum"] in hints and expected["maximum"] in hints, "Both actual corpus date bounds must be visible")
        return actual
    check("corpus_date_hints_and_input_clamping", dates)

    def all_evidence():
        row = page.evaluate("""async()=>{
          const key=state.panels.current.view.key;await ensureEvidenceSearchCatalog([key]);
          const r=state.searchEvidenceViews[key].find(r=>['Claim','Event'].includes(r.type)&&r.community_id&&r.label.length>12);
          if(!r)throw Error('No real Claim/Event fixture in the complete evidence catalog');
          return {id:r.id,label:r.label,type:r.type};}""")
        require(page.locator("#search-scope").input_value() == "evidence", "Default search is not all evidence")
        page.locator("#graph-search").fill(row["label"])
        page.wait_for_function("id=>state.searchResults.current.some(r=>r.id===id)", arg=row["id"], timeout=120000)
        return row
    check("default_search_returns_real_nonentity_evidence", all_evidence)
    if not include_slots:
        return

    def slots():
        status = page.evaluate("async()=>{await ensureSlotCensus();return slotOverlayState.payload;}")
        require(status["coverage"]["complete"] and status["hidden_values_read"] is False and
                status["semantic_graph_modified"] is False, status)
        if not fixture.get("slot"):
            require(status["coverage"]["total_slots"] == 0, "Zero-marker corpus must not invent slots")
            return {"coverage": status["coverage"], "zero_markers_not_invented": True}
        value = page.evaluate("id=>slotPacket({slot_id:id})", fixture["slot"]["id"])
        slot = value["slot"]
        source_packet = page.evaluate(r"""async slot=>{
          const normalized=await ensureOpaqueSlotPage(slot);
          const view=Object.values(state.data.views).find(v=>v.release_view==='earlier');
          if(!view)throw Error('No base-visible release view for exact source proof');
          const document=await ensureCibSource(view,slot.document_id);
          const source=document.pages.find(p=>p.canonical_page_id===slot.canonical_page_id);
          if(!source)throw Error('Exact base-visible source page missing');
          const hash=async text=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)))]
            .map(n=>n.toString(16).padStart(2,'0')).join('');
          const normalizedTransport=source.text.replace(/\[\[REDACTION_SLOT:\d+:[^\]]+\]\]|\[(?:STILL\s+)?(?:REDACTION|REDACTED)(?:\s+\d+)?\]/gi,'[REDACTED]');
          return {text:normalized.text,normalizedSha256:await hash(normalized.text),
            transportSha256:await hash(source.text),pageTextPin:normalized.text_sha256,
            pageTransportPin:normalized.transport_text_sha256,
            markerNormalizationReplays:normalizedTransport===normalized.text,
            document_id:normalized.document_id,canonical_page_id:normalized.canonical_page_id};
        }""", slot)
        source = source_packet["text"]
        require(source_packet["normalizedSha256"] == source_packet["pageTextPin"] ==
                slot["page_provenance"]["text_sha256"], f"Normalized visible-page hash differs: {source_packet}")
        require(source_packet["transportSha256"] == source_packet["pageTransportPin"] ==
                slot["page_provenance"]["transport_text_sha256"], f"Original marker-transport hash differs: {source_packet}")
        require(source_packet["markerNormalizationReplays"] and source_packet["document_id"] == slot["document_id"] and
                source_packet["canonical_page_id"] == slot["canonical_page_id"], "Exact transport-to-normalized source binding did not replay")
        require(slot["semantic"] is False and slot["eligible_evidence"] is False, "Opaque slot became semantic evidence")
        require("israel" in source.lower() and "jerusalem" in source.lower(), "Actual Israel/Jerusalem source fixture not opened")
        visible_anchors = []
        for anchor in slot["anchors"]:
            proof = anchor["visible_proof"]
            words = set(re.findall(r"[a-z]+", anchor["label"].lower()))
            require(words - STOP_WORDS, f"Vacuous The/common-word anchor retained: {anchor}")
            require(proof["text"].casefold() == anchor["label"].casefold(), "Anchor not exactly visible label")
            require(source[proof["start"]:proof["end"]] == proof["text"], "Visible anchor proof offsets did not replay")
            require(proof["identity_certified"] is False and proof["semantic"] is False, "Visible vocabulary falsely certifies hidden identity")
            visible_anchors.append(anchor["label"])
        require(visible_anchors, "Actual named-context example lost every substantive anchor")
        for edge in slot["context_links"]:
            require(edge["weight"] == edge["layout_weight"] == 0 and edge["semantic"] is False and
                    edge["eligible_evidence"] is False and edge["slot_navigation"] is True,
                    f"Slot provenance boundary changed: {edge}")
        unsafe = {"answer", "answer_text", "answer_word_count", "hidden_text", "hidden_value", "revealed_text"}
        require(not unsafe.intersection(slot), f"Concealed fields in source-only slot: {unsafe.intersection(slot)}")
        page.evaluate("slot=>navigateOpaqueSlot(state.panels.current,slot)", slot)
        capture("israel-jerusalem-slot")
        for query in ("Israel", "Jerusalem"):
            result = page.evaluate("q=>slotPacket({q,limit:32})", query)
            require(result["matched_count"] > 0, f"Source-only slot search cannot find {query}")
        vacuous = fixture.get("vacuous_anchor")
        require(vacuous, "The actual vacuous The node must be present in the negative-test fixture")
        negative = page.evaluate("id=>slotPacket({anchor_id:id,limit:1})", vacuous["id"])
        require(negative["matched_count"] == 0, f"Vacuous The still anchors source slots: {negative['matched_count']}")
        return {"id": slot["id"], "label": slot["label"], "anchors": visible_anchors,
                "context_links": len(slot["context_links"]), "vacuous_the_identity": vacuous["id"],
                "normalized_source_sha256": source_packet["normalizedSha256"],
                "marker_transport_sha256": source_packet["transportSha256"],
                "coverage": status["coverage"]}
    check("source_only_slots_israel_jerusalem_and_vacuous_the_negative", slots)


def orbit_checks(page, fixture, check, capture):
    check("open_actual_neighborhood", lambda: focus_record(page, fixture["focus"]["id"]))
    focus_neighborhood(page, fixture["focus"]["id"])

    def orbit():
        before = snapshot(page)
        page.wait_for_timeout(1800)
        after = snapshot(page)
        left = {n["id"]: n for n in before["nodes"]}
        deltas, radial = [], []
        center = next(n for n in before["nodes"] if n["id"] == before["focus"])
        after_center = next(n for n in after["nodes"] if n["id"] == after["focus"])
        for n in after["nodes"]:
            old = left[n["id"]]
            if n["id"] == before["focus"]:
                continue
            a = math.atan2(old["y"] - center["y"], old["x"] - center["x"])
            b = math.atan2(n["y"] - after_center["y"], n["x"] - after_center["x"])
            deltas.append(abs(math.atan2(math.sin(b-a), math.cos(b-a))))
            radial.append(abs(math.hypot(n["x"]-after_center["x"], n["y"]-after_center["y"]) -
                              math.hypot(old["x"]-center["x"], old["y"]-center["y"])))
        require(deltas and max(deltas) > .001, "No orbital motion in normal-motion mode")
        require(max(deltas) < .25, f"Orbit is not slow: {max(deltas):.3f} radians / 1.8s")
        require(max(radial) < 3, f"Orbit changes hierarchy distance: {max(radial):.3f}px")
        require(before["signature"] == after["signature"], "Orbit changed semantic graph facts")
        geometry_assertions(after)
        brim = focal_brim_assertions(after)
        capture("orbit")
        return {"angular_delta_max": max(deltas), "radial_drift_max_px": max(radial), "focal_brim":brim}
    check("slow_orbit_preserves_ring_distance_and_facts", orbit)

    def quadrant_labels():
        value = page.evaluate(LABEL_CONTRACT)
        center = value["center"]
        require(all(row["focus"] or row["x"] > center["x"] and row["y"] < center["y"]
                    for row in value["automatic"]), f"Automatic label outside upper-right quarter: {value}")
        require(set(value["actualVisible"]).issubset({r["id"] for r in value["automatic"]}), value)
        for row in value["cases"]:
            wanted = row["x"] > 0 and row["y"] < 0
            require(row["autoSelected"] == wanted and row["visible"] == wanted,
                    f"Automatic label set does not track upper-right quarter: {value}")
            if wanted:
                require(row["placement"] == "lower-rim" and row["dy"] > 0, value)
        require(value["pinned"]["visible"] and value["pinned"]["override"] is True, value)
        require(not value["reclick"]["visible"] and value["reclick"]["override"] is False and
                value["reclick"]["nodeStillPresent"] and value["remainsHiddenInAutomaticQuarter"], value)
        return value
    check("upper_right_auto_labels_bottom_rim_and_manual_toggle", quadrant_labels)

    def drag_and_reduced():
        page.emulate_media(reduced_motion="reduce")
        # Reopen to remove controlled label-placement perturbations and apply media preference.
        focus_neighborhood(page, fixture["focus"]["id"])
        before = snapshot(page)
        page.wait_for_timeout(700)
        after = snapshot(page)
        before_map = {n["id"]:n for n in before["nodes"]}
        drift = max((math.hypot(n["x"]-before_map[n["id"]]["x"],n["y"]-before_map[n["id"]]["y"])
                     for n in after["nodes"]), default=0)
        require(drift < .25, f"Reduced-motion graph continues orbiting: {drift:.3f}px")
        require(page.evaluate("state.panels.current.canvas.dataset.orbitState") == "stopped",
                "Reduced motion must report orbitState=stopped")
        legend = page.locator('.neighborhood-legend:not([hidden]) button[aria-label="Hide neighborhood legend"]')
        if legend.count() and legend.is_visible():
            legend.click()
        target = page.evaluate("""()=>{
          const p=state.panels.current,a=p.usableBounds(),b=p.canvas.getBoundingClientRect();
          const candidates=p.nodes.filter(n=>n.id!==p.graph.focusNodeId&&p.screen(n).x>a.left+40&&p.screen(n).x<a.right-40&&p.screen(n).y>a.top+40&&p.screen(n).y<a.bottom-40);
          const n=candidates.find(n=>{const q=p.screen(n);return p.hitNode(q)?.id===n.id&&document.elementFromPoint(b.left+q.x,b.top+q.y)===p.canvas;});
          if(!n)throw Error('No exposed painted circle for physical node drag');return {id:n.id,...p.screen(n)};
        }""")
        original = drag_diagnostics(page, target["id"], 22, 16)
        # The initial fixed diagonal can be radial and constrained back into its band.
        # A tangent displacement tests drag responsiveness without violating ring distance.
        current = page.evaluate(POINT_STATE, target["id"])
        wx, wy = current["world"]["x"], current["world"]["y"]
        length = max(1, math.hypot(wx, wy))
        tangent = drag_diagnostics(page, target["id"], -wy / length * 26, wx / length * 26)
        require(tangent["pointerDown"]["dragNode"] == target["id"], f"Physical drag hit a different object: {tangent}")
        require(tangent["finalMovementPx"] > 8, f"Physical tangent drag did not move node: {tangent}")
        band = tangent["afterRelease"]["band"]
        radial = math.hypot(tangent["afterRelease"]["world"]["x"], tangent["afterRelease"]["world"]["y"])
        require(band and band["inner"] < radial < band["outer"], f"Dragged node left its hierarchy annulus: {tangent}")
        require(before["signature"] == snapshot(page)["signature"], "Drag changed graph facts")
        brim = focal_brim_assertions(snapshot(page))
        capture("drag-reduced")
        return {"stationary_drift_px":drift,"dragged_id":target["id"],
                "original_diagonal":original,"tangent_drag":tangent,"focal_brim":brim}
    check("real_node_drag_and_reduced_motion", drag_and_reduced)

    def physical_label_toggle():
        target = page.evaluate("""()=>{
          const p=state.panels.current,focus=p.nodeMap.get(p.graph.focusNodeId),b=p.canvas.getBoundingClientRect();
          const eligible=p.nodes.filter(n=>n!==focus&&!n.overlay_slot&&!(n.x>focus.x&&n.y<focus.y)&&p.mapLabelSize(n))
            .sort((a,b)=>p.mapLabelSize(a).width-p.mapLabelSize(b).width);
          for(const n of eligible){
            p.labelOverrides.set(n.id,false);p.draw();const q=p.screen(n);
            if(p.hitNode(q)?.id===n.id&&document.elementFromPoint(b.left+q.x,b.top+q.y)===p.canvas)
              return {id:n.id,label:n.label,...q};
          }
          throw Error('No exposed outside-quarter circle for real click-toggle test');
        }""")
        before = page.evaluate(POINT_STATE, target["id"])
        page.mouse.click(before["client"]["x"], before["client"]["y"])
        first = page.evaluate(POINT_STATE, target["id"])
        shown_scene = snapshot(page)
        page.evaluate("value=>window.__kgQALastClick=value", {"before":before,"afterClick":first})
        if not first["labelVisible"]:
            from trace_legacy_labels import TRACE
            placement_trace = page.evaluate(TRACE, "current")
            page.evaluate("value=>window.__kgQALastLabelTrace=value", placement_trace)
        require(first["selected"] == target["id"] and first["labelVisible"] and first["labelOverride"] is True,
                f"Actual circle click did not show its outside-quarter label: {first}")
        own_clearance = own_caption_clearance_assertions(shown_scene, target["id"])
        require(not shown_scene["labelNodeOverlaps"] and not shown_scene["labelOverlaps"],
                f"Manual caption overlaps a node or caption: {shown_scene['labelNodeOverlaps']}, {shown_scene['labelOverlaps']}")
        page.wait_for_timeout(250)
        page.mouse.click(first["client"]["x"], first["client"]["y"])
        second = page.evaluate(POINT_STATE, target["id"])
        require(not second["labelVisible"] and second["labelOverride"] is False and second["radius"] > 0,
                f"Actual second circle click did not hide the label and preserve its node: {second}")
        capture("actual-label-toggle")
        return {"before":before,"firstClick":first,"secondClick":second,"own_clearance":own_clearance}
    check("physical_outside_quarter_click_and_reclick_toggle", physical_label_toggle)
