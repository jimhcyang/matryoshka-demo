"""Trace actual legacy-panel label candidates, without changing graph geometry."""
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright
from run_qa import arguments
from saved_fixtures import HERE


TRACE = r"""name=>{
  const p=state.panels[name||'legacy'],rows=[],original=p.drawMapLabels;
  const requested=p.mapLabelNodes().map(n=>({id:n.id,label:n.label,type:n.type,
    sameAsMap:p.nodeMap.get(n.id)===n,world:{x:n.x,y:n.y},screen:p.screen(n),radius:p.nodeRadius(n),
    display:mapDisplayLabel(n),wrapped:p.mapLabelSize(n),override:p.labelOverrides.get(n.id)??null}));
  const code=original.toString();
  const marker=['const {x,y}=position,candidate={...position,...wrapped};',
    'const candidate={...position,x,y,...wrapped};'].find(text=>code.includes(text));
  if(!marker)throw Error('Actual renderer candidate statement changed; refusing a substitute trace');
  const added=marker+`
    window.__legacyCandidateTrace.push({id:node.id,label:node.label,x,y,width:wrapped.width,height:wrapped.height,
      text:wrapped.text,placement:position.placement,area:{...area},
      boundsRejected:x<area.left||y<area.top||x+wrapped.width>area.right||y+wrapped.height>area.bottom,
      placedRejected:overlaps(candidate),priorLabels:placed.map(b=>({...b})),
      blockers:this.nodes.filter(other=>${code.includes('if(other===node)return false;')?'other!==node':'true'}).map(other=>{
        const q=this.screen(other),distance=Math.hypot(q.x-Math.max(x,Math.min(q.x,x+wrapped.width)),q.y-Math.max(y,Math.min(q.y,y+wrapped.height))),
          threshold=this.nodeRadius(other)+4;
        return {id:other.id,label:other.label,x:q.x,y:q.y,radius:this.nodeRadius(other),distance,threshold,
          sameIdentity:other.id===node.id,blocks:distance<threshold};
      }).filter(b=>b.blocks)});
  `;
  window.__legacyCandidateTrace=rows;
  p.drawMapLabels=(0,eval)('('+code.replace(/^drawMapLabels\s*\(/,'function drawMapLabels(').replace(marker,added)+')');
  try{p.draw();}finally{p.drawMapLabels=original;delete window.__legacyCandidateTrace;}
  const rect=b=>({left:b.left,top:b.top,right:b.right,bottom:b.bottom,width:b.width,height:b.height});
  const grid=document.querySelector('.graph-grid'),body=getComputedStyle(document.body);
  const labels=[...p.labelButtons].map(([id,el])=>{
    const b=el.getBoundingClientRect(),style=getComputedStyle(el),top=document.elementFromPoint(b.left+b.width/2,b.top+b.height/2);
    return {id,text:el.textContent,rect:rect(b),clientHeight:el.clientHeight,scrollHeight:el.scrollHeight,
      clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,display:style.display,visibility:style.visibility,
      font:style.font,fontFamily:style.fontFamily,fontWeight:style.fontWeight,
      topElement:top?{tag:top.tagName,id:top.id,className:top.className,text:top.textContent?.slice(0,120)}:null,
      exposed:top===el||top?.closest('.map-label')===el};
  });
  return {panel:name||'legacy',level:p.level,selected:p.selected?.id,labelButtonsSize:p.labelButtons.size,
    canvas:{...rect(p.canvas.getBoundingClientRect()),logicalWidth:p.width,logicalHeight:p.height},
    usableBounds:p.usableBounds(),viewport:{width:innerWidth,height:innerHeight},
    toolbar:rect(document.querySelector('.map-toolbar').getBoundingClientRect()),
    grid:{...rect(grid.getBoundingClientRect()),scrollTop:grid.scrollTop,scrollHeight:grid.scrollHeight,clientHeight:grid.clientHeight},
    bodyFont:{family:body.fontFamily,size:body.fontSize,weight:body.fontWeight,font:body.font},canvasFont:p.ctx.font,
    requested:requested.map(r=>({...r,characterCodes:r.wrapped?[...r.wrapped.text].map(c=>c.codePointAt(0)):null})),
    candidates:rows,labels};
}"""


def main():
    args = arguments()
    if not args.preview:
        raise SystemExit('Explicit --preview and --preview-ready required')
    output = args.output.absolute()
    if output.exists() or not output.resolve().is_relative_to(HERE):
        raise SystemExit('Use a new output directory under qa/')
    output.mkdir(parents=True)
    origin = urlsplit(args.preview)
    result = {'preview':args.preview,'model_api_calls':0,'native_executions':0,'managed_headless_shell':True}
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        try:
            context = browser.new_context(viewport={'width':390,'height':844},reduced_motion='reduce',service_workers='block')
            context.route('**/*',lambda route: route.continue_() if urlsplit(route.request.url).netloc == origin.netloc
                          and '/api/' not in urlsplit(route.request.url).path and route.request.method == 'GET' else route.abort())
            page = context.new_page()
            scripts=[]
            page.on('response',lambda r:scripts.append(r) if urlsplit(r.url).path.endswith('/graph-full-v6.js') else None)
            page.goto(args.preview.rstrip('/')+'/graph-full-v6.html?corpus=iran&view=pair',wait_until='domcontentloaded')
            page.wait_for_function("document.body.dataset.graphReady==='true'",timeout=60000)
            page.evaluate('()=>document.fonts.ready')
            result['renderer_sha256']=hashlib.sha256(scripts[-1].body()).hexdigest()
            result['root']=page.evaluate(TRACE)
            page.screenshot(path=str(output/'root.png'))
            page.locator('#legacy-canvas').press('ArrowRight')
            result['after_arrow_right']=page.evaluate(TRACE)
            page.screenshot(path=str(output/'after-arrow-right.png'))
            context.close()
        finally:
            browser.close()
    (output/'trace.json').write_text(json.dumps(result,indent=2)+'\n')
    lines=[]
    for phase in ('root','after_arrow_right'):
        row=result[phase]
        lines.append(f"{phase}: labelButtons={row['labelButtonsSize']} canvas={row['canvas']} usable={row['usableBounds']}")
        lines.append('bodyFont='+str(row['bodyFont'])+' canvasFont='+row['canvasFont'])
        for request in row['requested']:
            lines.append('REQUEST '+json.dumps(request))
        for candidate in row['candidates']:
            lines.append('CANDIDATE '+json.dumps(candidate))
        lines.append('DOM_LABELS '+json.dumps(row['labels']))
    (output/'trace.txt').write_text('\n'.join(lines)+'\n')
    for phase in ('root','after_arrow_right'):
        row=result[phase]
        print(phase,'buttons',row['labelButtonsSize'],'requested',[(r['id'],r['display'],r['wrapped'])for r in row['requested']],flush=True)
        print('bounds',row['usableBounds'],'font',row['bodyFont'],flush=True)
        first=row['requested'][0]['id'] if row['requested'] else None
        candidates=[c for c in row['candidates']if c['id']==first]
        print('first-candidates',len(candidates),'boundsRejected',sum(c['boundsRejected']for c in candidates),
              'placedRejected',sum(c['placedRejected']for c in candidates),'nodeRejected',sum(bool(c['blockers'])for c in candidates),flush=True)
    print(output/'trace.txt',flush=True)


if __name__=='__main__':
    main()
