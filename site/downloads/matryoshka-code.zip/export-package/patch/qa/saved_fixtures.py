"""Read a bounded set of existing public packets, never run a corpus producer."""
from functools import lru_cache
import gzip
import importlib.util
import json
from pathlib import Path
from urllib.parse import urlsplit


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[3]
FRENCH_ID = "identity_7c054ac6826e71ca5669143344bf24e64224e9fec2e937cad5b2fa5e403cf6cc"
CORPORA = ("cib", "iran", "vietnam")


class SavedPackets:
    def __init__(self, site, datasets):
        self.site = Path(site).resolve()
        self.datasets = Path(datasets).resolve()
        self.entries = json.loads((self.site / "data/api-index.json").read_bytes())["entries"]
        self.reads = []

    @lru_cache(maxsize=12)
    def read(self, route):
        entry = self.entries[route]
        encoding = entry["encoding"]
        if encoding == "fragment-dag":
            path = WORKSPACE / "src-demo-day/phase/release_finish_20261121/deploy/packet_pack.py"
            spec = importlib.util.spec_from_file_location("qa_packet_reader", path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            raw = module.read_packed(self.site, entry)
        else:
            if entry.get("external_url"):
                relative = urlsplit(entry["external_url"]).path.split("/datasets/", 1)[1]
                path = self.datasets / relative
                if not path.resolve().is_relative_to(self.datasets):
                    raise ValueError("Dataset path escapes the existing read-only store")
            else:
                path = self.site / entry["path"]
            raw = path.read_bytes()
            if encoding == "gzip":
                raw = gzip.decompress(raw)
            elif encoding != "identity":
                raise ValueError(f"Unsupported saved packet encoding: {encoding}")
        self.reads.append({"route": route, "decoded_bytes": len(raw)})
        return json.loads(raw)


def short_node(row):
    keys = ("id", "label", "type", "domain_id", "theme_id", "community_id", "mass", "document_count")
    return {key: row[key] for key in keys if key in row}


def build_fixtures(site, datasets):
    packets = SavedPackets(site, datasets)
    fixtures = {"corpora": {}, "reads": packets.reads, "native_executions": 0,
                "network_calls": 0, "full_dataset_hashes": 0}
    for corpus in CORPORA:
        binding = packets.read(f"/api/graph-v4-viewer?corpus={corpus}")
        comparison = packets.read(binding["asset_base"] + binding["comparison_asset"])
        manifest = packets.read(binding["asset_base"] + binding["search_asset"])
        assert comparison["graph_run_id"] == manifest["graph_run_id"] == binding["graph_run_id"]
        assert comparison["hierarchy_run_id"] == manifest["hierarchy_run_id"] == binding["hierarchy_run_id"]
        view = "current_earlier" if corpus == "cib" else "current_redaction"
        records = packets.read(binding["asset_base"] + manifest["view_files"][view])["records"]
        if corpus == "cib":
            node = next(row for row in records if row["id"] == FRENCH_ID)
            assert "french" in node["label"].lower() and "atomic" in node["label"].lower(), node["label"]
        else:
            candidates = [r for r in records if r.get("community_id") and r.get("domain_id")]
            node = max(candidates, key=lambda r: (r.get("document_count", 0), r["id"]))
        slots = packets.read(f"/data/slots/{corpus}.json")
        assert slots["status"]["hidden_values_read"] is False
        example = next((s for s in slots["slots"] if all(
            word in s.get("context_preview", "").lower() for word in ("israel", "jerusalem"))), None)
        if corpus == "cib":
            assert example, "The actual CIB Israel/Jerusalem slot fixture is required"
        elif slots["slots"] and example is None:
            example = slots["slots"][0]
        row = {"graph_run_id": binding["graph_run_id"], "hierarchy_run_id": binding["hierarchy_run_id"],
               "date_range": comparison["corpus_metadata"]["date_range"], "focus": short_node(node),
               "slot_count": len(slots["slots"])}
        vacuous = next((r for r in records if r["label"].strip().casefold() == "the"), None)
        if vacuous:
            row["vacuous_anchor"] = short_node(vacuous)
        if example:
            row["slot"] = {k: example.get(k) for k in ("id", "document_id", "canonical_page_id", "context_preview")}
            row["slot"]["detail_route"] = slots["details"][example["id"]]
        fixtures["corpora"][corpus] = row
    return fixtures
