"use strict";

// Read live renderer coordinates and real DOM footprints; do not replace layout.
window.__kgQA = (() => {
  const quantile = (items, fraction) => {
    const sorted = [...items].sort((a, b) => a - b);
    return sorted.length ? sorted[Math.floor((sorted.length - 1) * fraction)] : 0;
  };
  const rect = value => ({left: value.left, top: value.top, right: value.right,
    bottom: value.bottom, width: value.width, height: value.height});
  const intersects = (a, b) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > 1 &&
    Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 1;
  function snapshot(name = "current") {
    const panel = state.panels[name], canvas = panel.canvas.getBoundingClientRect();
    const area = panel.usableBounds();
    const nodes = panel.nodes.map(node => ({id: node.id, ...panel.screen(node),
      r: panel.nodeRadius(node), world: [node.x, node.y], baseRadius: node.r,
      mass: node.mass, focus_scope: node.focus_scope, community_id: node.community_id,
      theme_id: node.theme_id, domain_id: node.domain_id, label: node.label}));
    const labels = [...panel.labelLayer.querySelectorAll(".map-label")].filter(el => el.getClientRects().length)
      .map(el => { const b = el.getBoundingClientRect(); return {id: el.dataset.nodeLabel,
        placement: el.dataset.placement, text: el.textContent, left: b.left - canvas.left,
        right: b.right - canvas.left, top: b.top - canvas.top, bottom: b.bottom - canvas.top,
        width: b.width, height: b.height,scrollWidth:el.scrollWidth,clientWidth:el.clientWidth,
        scrollHeight:el.scrollHeight,clientHeight:el.clientHeight}; });
    const map = new Map(nodes.map(node => [node.id, node]));
    const edgeLengths = panel.edges.map(edge => {
      const a = map.get(edge.source), b = map.get(edge.target);
      return a && b ? Math.max(0, Math.hypot(a.x - b.x, a.y - b.y) - a.r - b.r) : NaN;
    }).filter(Number.isFinite);
    const overlaps = [], labelOverlaps = [], labelNodeOverlaps = [], clipped = [];
    for (let i = 0; i < nodes.length; i++) {
      const a = nodes[i];
      if (a.x - a.r < area.left - 1 || a.x + a.r > area.right + 1 ||
          a.y - a.r < area.top - 1 || a.y + a.r > area.bottom + 1) clipped.push(a.id);
      for (let j = i + 1; j < nodes.length; j++) {
        const b = nodes[j], intrusion = a.r + b.r - Math.hypot(a.x - b.x, a.y - b.y);
        if (intrusion > 1) overlaps.push({a: a.id, b: b.id, intrusion});
      }
    }
    for (let i = 0; i < labels.length; i++) {
      const a = labels[i];
      if (a.left < area.left - 1 || a.right > area.right + 1 ||
          a.top < area.top - 1 || a.bottom > area.bottom + 1) clipped.push("label:" + a.id);
      for (let j = i + 1; j < labels.length; j++) if (intersects(a, labels[j]))
        labelOverlaps.push([a.id, labels[j].id]);
      for (const node of nodes) {
        const distance = Math.hypot(node.x - Math.max(a.left, Math.min(node.x, a.right)),
          node.y - Math.max(a.top, Math.min(node.y, a.bottom)));
        if (distance < node.r - 1) labelNodeOverlaps.push([a.id, node.id]);
      }
    }
    const spanX = nodes.length ? Math.max(...nodes.map(n => n.x + n.r)) - Math.min(...nodes.map(n => n.x - n.r)) : 0;
    const spanY = nodes.length ? Math.max(...nodes.map(n => n.y + n.r)) - Math.min(...nodes.map(n => n.y - n.r)) : 0;
    const diameter = Math.min(area.width, area.height);
    const signature = JSON.stringify({nodes: panel.nodes.map(n => [n.id, n.mass, n.document_count,
      n.community_id, n.theme_id, n.domain_id]).sort(), edges: panel.edges.map(e => [e.id,
      e.source, e.target, e.weight, e.layout_weight, e.slot_navigation]).sort()});
    let legend = null;
    if (panel.ringLegend && !panel.ringLegend.hidden) {
      const b = panel.ringLegend.getBoundingClientRect(), toolbar = document.querySelector('.map-toolbar').getBoundingClientRect();
      legend = {...rect(b), clippedByOwnCanvas: b.left < canvas.left - 1 || b.right > canvas.right + 1 ||
        b.top < canvas.top - 1 || b.bottom > canvas.bottom + 1,
        overlapsToolbar: intersects(b, toolbar),
        occludesNodes: nodes.filter(n => Math.hypot(n.x + canvas.left - Math.max(b.left,Math.min(n.x + canvas.left,b.right)),
          n.y + canvas.top - Math.max(b.top,Math.min(n.y + canvas.top,b.bottom))) < n.r).map(n => n.id)};
    }
    return {name, level: panel.level, nodeLimit: panel.nodeLimit, nodes, labels, area,
      canvas: rect(canvas), transform: {...panel.transform}, signature, legend,
      focalLabel: panel.graph?.focusMode ? {id:panel.graph.focusNodeId,
        visible:panel.labelButtons.has(panel.graph.focusNodeId),
        candidate:panel.mapLabelNodes().some(n=>n.id===panel.graph.focusNodeId),
        capsule:panel.mapLabelSize(panel.nodeMap.get(panel.graph.focusNodeId)),
        center:nodes.find(n=>n.id===panel.graph.focusNodeId),
        nearbyNodes:nodes.filter(n=>n.id!==panel.graph.focusNodeId).sort((a,b)=>{
          const c=nodes.find(n=>n.id===panel.graph.focusNodeId);
          return Math.hypot(a.x-c.x,a.y-c.y)-Math.hypot(b.x-c.x,b.y-c.y);
        }).slice(0,12),visibleLabels:labels} : null,
      focus: panel.neighborhood?.node?.id || null, focusMode: Boolean(panel.graph?.focusMode),
      bands: panel.focusBands.map(b => ({scope: b.scope, inner: b.inner, outer: b.outer, count: b.count})),
      availableNodeCount: panel.graph?.availableNodeCount, edgeCount: panel.edges.length,
      showNeighborEdges: panel.showNeighborEdges, inducedLoading: panel.inducedLoading,
      overlaps: overlaps.slice(0, 20), overlapCount: overlaps.length,
      labelOverlaps, labelNodeOverlaps, clipped,
      labelOverflows:labels.filter(l=>l.scrollWidth>l.clientWidth+1||l.scrollHeight>l.clientHeight+1),
      shapeAspect: spanX && spanY ? Math.max(spanX / spanY, spanY / spanX) : 0,
      fitOccupancy: diameter ? Math.max(spanX, spanY) / diameter : 0,
      edges: {count: edgeLengths.length, p50: quantile(edgeLengths, .5),
        p95: quantile(edgeLengths, .95), maximum: Math.max(0, ...edgeLengths),
        p95PerDiameter: diameter ? quantile(edgeLengths, .95) / diameter : 0},
      pageOverflow: document.documentElement.scrollWidth - innerWidth};
  }
  function ringGeometry(name='current'){
    const p=state.panels[name],focus=p.nodeMap.get(p.graph.focusNodeId),area=p.usableBounds();
    if(!focus)throw Error('No actual focus for circular-ring measurement');
    const arcs=[],drawBands=p.drawFocusBands,hadOwn=Object.hasOwn(p,'drawFocusBands');
    p.drawFocusBands=function(...args){
      const native=this.ctx.arc,ownArc=Object.hasOwn(this.ctx,'arc');
      this.ctx.arc=function(x,y,r,...rest){
        const m=this.getTransform();arcs.push({x,y,r,axisX:Math.hypot(m.a,m.b),axisY:Math.hypot(m.c,m.d),
          clipped:x-r<area.left-1||x+r>area.right+1||y-r<area.top-1||y+r>area.bottom+1});
        return native.call(this,x,y,r,...rest);
      };
      try{return drawBands.apply(this,args);}finally{if(ownArc)this.ctx.arc=native;else delete this.ctx.arc;}
    };
    try{p.draw();}finally{if(hadOwn)p.drawFocusBands=drawBands;else delete p.drawFocusBands;}
    const center=p.screen(focus),ratios=p.nodes.filter(n=>n!==focus).map(n=>{
      const world=Math.hypot(n.x-focus.x,n.y-focus.y),screen=p.screen(n);
      return world>1e-9?Math.hypot(screen.x-center.x,screen.y-center.y)/world:null;
    }).filter(n=>n!==null);
    return {arcs,bandCount:p.focusBands.length,
      bands:p.focusBands.map(b=>({scope:b.scope,inner:b.inner*p.transform.scale,outer:b.outer*p.transform.scale})),
      minimumRatio:Math.min(...ratios),maximumRatio:Math.max(...ratios),
      transformScale:p.transform.scale,focus:focus.id};
  }
  function repeatFit(name = 'current') {
    const p = state.panels[name], samples = [];
    let previous = p.nodes.map(n => ({id:n.id,...p.screen(n)}));
    for(let iteration=1;iteration<=3;iteration++) {
      p.fit();
      const positions = p.nodes.map(n => ({id:n.id,...p.screen(n)})), old = new Map(previous.map(n=>[n.id,n]));
      const deltas = positions.map(n=>Math.hypot(n.x-old.get(n.id).x,n.y-old.get(n.id).y));
      samples.push({iteration,maximumDriftPx:Math.max(0,...deltas),meanDriftPx:deltas.reduce((a,b)=>a+b,0)/Math.max(1,deltas.length),
        scale:p.transform.scale});
      previous=positions;
    }
    return {level:p.level,focusMode:Boolean(p.graph?.focusMode),nodeCount:p.nodes.length,samples};
  }
  function ringDistances() {
    const panel = state.panels.current, focus = panel.nodes.find(n => n.id === panel.graph.focusNodeId);
    if (!focus) throw Error("No real neighborhood focus node");
    const distances = [[], [], [], []];
    for (const node of panel.nodes) {
      if (node === focus) continue;
      const group = focus.community_id && node.community_id === focus.community_id ? 0 :
        focus.theme_id && node.theme_id === focus.theme_id ? 1 :
        focus.domain_id && node.domain_id === focus.domain_id ? 2 : 3;
      distances[group].push(Math.hypot(node.x - focus.x, node.y - focus.y));
    }
    return distances.map((values, group) => ({group, count: values.length,
      minimum: values.length ? Math.min(...values) : null,
      maximum: values.length ? Math.max(...values) : null, median: quantile(values, .5)}));
  }
  function emptyPoint(name) {
    const panel = state.panels[name], area = panel.usableBounds(),canvas=panel.canvas.getBoundingClientRect();
    for (let row = 0; row < 12; row++) for (let col = 0; col < 12; col++) {
      const point = {x: area.left + (col + .5) * area.width / 12,
        y: area.top + (row + .5) * area.height / 12};
      if (!panel.hitNode(point) && document.elementFromPoint(canvas.left+point.x,canvas.top+point.y)===panel.canvas && ![...panel.labelButtons.values()].some(el => {
        const b = el.getBoundingClientRect(), c = panel.canvas.getBoundingClientRect();
        return point.x + c.left >= b.left && point.x + c.left <= b.right &&
          point.y + c.top >= b.top && point.y + c.top <= b.bottom;
      })) return point;
    }
    throw Error("No blank canvas point for a genuine physical-pan check");
  }
  return {snapshot, ringDistances, emptyPoint, repeatFit, ringGeometry};
})();
