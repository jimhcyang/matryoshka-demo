# Independent KG Patch QA

Ownership: this directory only. No main JS/UI edits, producer execution, server
startup, dataset copy, full-store hashing, inference API, native graph rebuild,
personal Chrome, or browser process termination. Stop below 3 GiB free.

## Entrypoint

From workspace root:

```sh
.venv/bin/python src-demo-day/phase/kg_patch_20261122/qa/run_qa.py
.venv/bin/python -m pytest -q src-demo-day/phase/kg_patch_20261122/qa/test_qa_harness.py
```

The default run reads 15 selected saved packets from the existing site/dataset
store and runs actual `GraphPanel` and public-runtime slot-selector methods in
Node. It does not launch a browser. An offline pass is not a layout pass.
Every run gets a new `qa/runs/<UTC>/` directory; failed attempts are preserved.

Await the main agent's explicit isolated-preview release, then use its exact
base URL, including any project prefix:

```sh
.venv/bin/python src-demo-day/phase/kg_patch_20261122/qa/run_qa.py \
  --preview http://127.0.0.1:PORT/PROJECT_PREFIX/ --preview-ready
```

Do not use the placeholder URL as an assumed running preview. Both flags are
mandatory. The runner does not find, start, or stop a preview server. It uses
`playwright.chromium.launch(headless=True)` without an installed-browser channel
or profile. It blocks external requests, physical HTTP `/api/` calls, and all
non-GET/HEAD requests. Saved `/api/...` selectors are handled by the existing
public-runtime fetch implementation, not an API/native backend. No responses
are mocked. The workspace managed headless shell is already installed.
Each browser cell verifies the served renderer's small-file SHA-256 against
the exact JS used by the mechanics tests, plus the saved graph/hierarchy IDs.
This does not hash the dataset store. A stale/different preview fails closed.

Filter a rerun with `--corpora cib`, `--viewports mobile`, or
`--groups layout paired source orbit`. `--site`, `--datasets`, and `--renderer`
can select an explicitly prepared snapshot without duplicating it. Outputs
must be new paths under this QA directory.

## Coverage And Oracles

- Actual CIB French Atomic Energy Commission ID:
  `identity_7c054ac6826e71ca5669143344bf24e64224e9fec2e937cad5b2fa5e403cf6cc`.
- Actual saved Iran `IRAN` and Vietnam `SAIGON` identities are discovered from
  their own base-visible entity catalogs and recorded in `fixtures.json`.
- All three corpora run at desktop 1440x1000 and mobile 390x844, in reduced
  motion and normal-motion orbit checks. No layout is pre-certified.
- Real Domain/Theme/Community/Evidence and scoped evidence layouts: positive
  radii, screen-space circle/circle and label/label/node intersections,
  clipping, overflow, envelope aspect, and edge length p50/p95/max.
- Every browser check also verifies all visible label capsules, including paired
  canvases: `scrollHeight <= clientHeight + 1` and `scrollWidth <= clientWidth + 1`.
  Failures retain actual font metrics and wrapped-text character codes.
- Explicit visual budgets: no >1px circle overlap or clipping; no >1px label
  footprint intersection; non-neighborhood envelope aspect <=1.45 for >=8 nodes; edge p95 no
  longer than the usable circle diameter. These are QA budgets, not corpus
  facts. Screenshots and measurements remain available even on failure.
- View-local mass/radius scaling and singleton baseline; Fit cannot turn a
  synthetic circle into a viewport-shaped ellipse or compound repeated fits.
  DOM plumbing is stubbed only in the offline mechanics test.
- Four hierarchy-distance groups are exercised offline. Browser membership
  groups are independently derived from actual Community/Theme/Domain IDs;
  populated groups must not interleave radially. Empty groups are reported,
  not invented. Outside-hierarchy nodes occupy the fourth/distant group.
- Published induced neighbor edges must be on without a toggle and complete
  for the actual displayed endpoints; provenance/navigation stays zero weight.
- Slow orbit must move without changing topology/mass or ring distances;
  reduced motion must remain stationary. Real pointer drag moves a node.
  Automatic neighbor labels must be a subset of the upper-right quarter;
  explicit pins can show elsewhere. Controlled-quarter tests retain bottom-rim
  placement, click/reclick hiding, and node visibility. Actual physical click
  toggles are checked separately. Controlled cases are not layout passes.
- Pair means two visible nonoverlapping physical canvases; drawing caps and
  actual search-result navigation synchronize. A real blank-canvas drag moves
  only its own panel, without changing graph facts.
- Hierarchy default 32, evidence default 256, all-evidence search default, and
  an actual Claim/Event must be returned by default search.
- Date input hints and out-of-range clamping use each actual saved corpus
  bound. Date eligibility must not replace graph/hierarchy bindings.
- CIB actual Israel/Jerusalem slot, exact base-source visible proofs,
  source-only search, no hidden-value fields, substantive anchors and the
  actual `The` identity as a zero-match anchor negative. Static search also
  rejects a concealed sentinel present only in an untrusted label.
- Iran and Vietnam saved zero-marker snapshots must stay empty; classification
  additions do not authorize invented redaction slots.

Browser artifacts: `browser.json`, incremental `browser-progress.json`, full
geometry measurements, screenshots, and uncaught exceptions. A failed check
does not turn into a pass merely because a screenshot exists. Swedish/Input
and Facts edits/tests remain with their other assigned owner.
