"""Actual renderer label policy and physical pointer diagnostics, without app edits."""
import math


LABEL_CONTRACT = r"""()=>{
  const p=state.panels.current;p.stopPhysics();p.stopOrbit?.();
  const center=p.nodes.find(n=>n.id===p.graph.focusNodeId);
  if(!center)throw Error('Actual neighborhood focus missing');
  const saved={nodes:p.nodes,edges:p.edges,nodeMap:p.nodeMap,transform:p.transform,
    fitScale:p.fitScale,overrides:p.labelOverrides};
  p.labelOverrides=new Map();p.draw();
  const automatic=p.mapLabelNodes().map(n=>({id:n.id,x:n.x,y:n.y,focus:n===center}));
  const actualVisible=[...p.labelButtons.keys()];
  const node=p.nodes.filter(n=>n!==center&&n.label.length<=32&&p.mapLabelSize(n))
    .sort((a,b)=>p.mapLabelSize(a).width-p.mapLabelSize(b).width)[0];
  if(!node)throw Error('No actual short labelable neighbor');
  const old={x:node.x,y:node.y},cases=[];
  try{
    p.nodes=[center,node];p.edges=[];p.nodeMap=new Map(p.nodes.map(n=>[n.id,n]));
    const area=p.usableBounds(),d=Math.min(area.width,area.height)*.18;
    p.transform={scale:1,x:area.left+area.width/2,y:area.top+area.height/2};p.fitScale=1;
    p.labelOverrides=new Map([[center.id,false]]);
    for(const [x,y] of [[-1,-1],[1,-1],[-1,1],[1,1]]){
      node.x=center.x+x*d;node.y=center.y+y*d;p.draw();
      const label=p.labelButtons.get(node.id),point=p.screen(node),c=p.canvas.getBoundingClientRect();
      const b=label?.getBoundingClientRect();
      cases.push({x,y,autoSelected:p.mapLabelNodes().some(n=>n.id===node.id),visible:Boolean(label),
        placement:label?.dataset.placement,dy:b?b.top-c.top+b.height/2-point.y:null});
    }
    node.x=center.x-d;node.y=center.y+d;p.draw();
    p.toggleLabel(node);
    const pinned={visible:p.labelButtons.has(node.id),override:p.labelOverrides.get(node.id),
      placement:p.labelButtons.get(node.id)?.dataset.placement};
    p.toggleLabel(node);
    const reclick={visible:p.labelButtons.has(node.id),override:p.labelOverrides.get(node.id),
      nodeStillPresent:p.nodes.includes(node)&&p.nodeMap.has(node.id)};
    node.x=center.x+d;node.y=center.y-d;p.draw();
    const remainsHiddenInAutomaticQuarter=!p.labelButtons.has(node.id)&&!p.mapLabelNodes().some(n=>n.id===node.id);
    return {center:{id:center.id,x:center.x,y:center.y},automatic,actualVisible,
      controlledNode:{id:node.id,label:node.label},cases,pinned,reclick,remainsHiddenInAutomaticQuarter};
  }finally{
    node.x=old.x;node.y=old.y;p.nodes=saved.nodes;p.edges=saved.edges;p.nodeMap=saved.nodeMap;
    p.transform=saved.transform;p.fitScale=saved.fitScale;p.labelOverrides=saved.overrides;p.draw();
  }
}"""


POINT_STATE = r"""id=>{
  const p=state.panels.current,n=p.nodeMap.get(id),point=p.screen(n),b=p.canvas.getBoundingClientRect();
  const x=b.left+point.x,y=b.top+point.y,top=document.elementFromPoint(x,y);
  const band=p.focusBands.find(b=>b.index===n.orbitBand);
  return {id,label:n.label,screen:point,client:{x,y},world:{x:n.x,y:n.y},radius:p.nodeRadius(n),
    selected:p.selected?.id||null,hitNode:p.hitNode(point)?.id||null,
    topElement:top?{tag:top.tagName,id:top.id,className:top.className,canvas:top===p.canvas}:null,
    dragNode:p.drag?.node?.id||null,dragMoved:p.drag?.moved||false,orbitState:p.canvas.dataset.orbitState,
    orbitRadius:n.orbitRadius,band:band?{inner:band.inner,outer:band.outer}:null,
    labelVisible:p.labelButtons.has(id),labelOverride:p.labelOverrides.get(id)??null};
}"""


def drag_diagnostics(page, identity, dx, dy):
    before = page.evaluate(POINT_STATE, identity)
    x, y = before["client"]["x"], before["client"]["y"]
    page.mouse.move(x, y)
    hovered = page.evaluate(POINT_STATE, identity)
    page.mouse.down()
    down = page.evaluate(POINT_STATE, identity)
    page.mouse.move(x + dx, y + dy, steps=8)
    during = page.evaluate(POINT_STATE, identity)
    page.mouse.up()
    after = page.evaluate(POINT_STATE, identity)
    distance = lambda a, b: math.hypot(a["screen"]["x"] - b["screen"]["x"], a["screen"]["y"] - b["screen"]["y"])
    result = {"requestedDelta": {"x": dx, "y": dy}, "before": before, "hovered": hovered,
              "pointerDown": down, "duringDrag": during, "afterRelease": after,
              "duringMovementPx": distance(during, before), "finalMovementPx": distance(after, before),
              "releaseConstraintPx": distance(after, during)}
    page.evaluate("value=>window.__kgQALastPointer=value", result)
    return result
