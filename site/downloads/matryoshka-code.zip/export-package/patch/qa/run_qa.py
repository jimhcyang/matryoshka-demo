"""Independent KG patch QA. Offline by default; explicit preview release is mandatory."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

from saved_fixtures import CORPORA, HERE, WORKSPACE, build_fixtures


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, default=HERE.parent / "stage/site",
                        help="Existing saved public packets; read only")
    parser.add_argument("--datasets", type=Path, default=WORKSPACE / "matryoshka_demo_site/datasets",
                        help="Existing dataset store, never copied or rehashed wholesale")
    parser.add_argument("--renderer", type=Path, default=HERE.parent / "ui/graph-full-v6.js")
    parser.add_argument("--preview", help="Main agent's isolated loopback preview base, including any project prefix")
    parser.add_argument("--preview-ready", action="store_true",
                        help="Explicit receipt that main has released this isolated preview for browser QA")
    parser.add_argument("--unfrozen-preview", action="store_true",
                        help="Provisional diagnostics only; record each actually loaded JS revision and allow main refinements")
    parser.add_argument("--corpora", nargs="+", choices=CORPORA, default=list(CORPORA))
    parser.add_argument("--viewports", nargs="+", choices=("desktop", "mobile"), default=["desktop", "mobile"])
    parser.add_argument("--groups", nargs="+", choices=("layout", "paired", "source", "orbit", "controls", "focus"),
                        default=["layout", "paired", "source", "orbit"])
    parser.add_argument("--output", type=Path, help="New directory under qa/; existing runs are never overwritten")
    args = parser.parse_args(argv)
    if bool(args.preview) != args.preview_ready:
        parser.error("Browser QA requires both --preview URL and --preview-ready, supplied after main's preview is ready")
    if args.unfrozen_preview and not args.preview:
        parser.error("--unfrozen-preview requires an explicitly released isolated preview")
    if args.preview:
        from urllib.parse import urlsplit
        url = urlsplit(args.preview)
        if (url.scheme != "http" or url.hostname not in {"127.0.0.1", "localhost", "::1"}
                or url.username or url.password or url.query or url.fragment):
            parser.error("Only a clean isolated loopback HTTP preview base is allowed")
    return args


def main(argv=None):
    args = arguments(argv)
    if shutil.disk_usage(HERE).free < 3 * 1024**3:
        raise SystemExit("QA stopped: less than 3 GiB free; no substantial work is allowed")
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    output = (args.output or HERE / "runs" / stamp).absolute()
    if not output.resolve().is_relative_to(HERE) or output.exists():
        raise SystemExit("Output must be a new directory under patch/qa/; preserve every prior attempt")
    output.mkdir(parents=True)
    report = {"output": str(output), "browser_requested": bool(args.preview),
              "native_executions": 0, "model_api_calls": 0, "full_dataset_hashes": 0,
              "dataset_copies": 0, "layout_pass_claimed": False}
    report["unfrozen_preview"] = args.unfrozen_preview
    report["final_signoff"] = False
    try:
        fixtures = build_fixtures(args.site, args.datasets)
        (output / "fixtures.json").write_text(json.dumps(fixtures, indent=2) + "\n")
        report["fixture_reads"] = len(fixtures["reads"])
        report["fixture_decoded_bytes"] = sum(r["decoded_bytes"] for r in fixtures["reads"])
        completed = subprocess.run(["node", str(HERE / "test_renderer.cjs"), str(args.renderer),
                                    str(output / "renderer.json")], capture_output=True, text=True)
        (output / "renderer.log").write_text(completed.stdout + completed.stderr)
        print(completed.stdout, end="")
        if completed.stderr:
            print(completed.stderr, file=sys.stderr, end="")
        report["renderer_pass"] = completed.returncode == 0
        if args.preview:
            from browser_qa import run_browser
            renderer_report = json.loads((output / "renderer.json").read_text())
            presentation_pins = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                 for p in (args.renderer, args.renderer.with_suffix('.css'), args.renderer.with_suffix('.html'))}
            browser = run_browser(args.preview, output, fixtures, args.corpora, args.viewports, args.groups,
                                  renderer_report["source_sha256"], unfrozen=args.unfrozen_preview,
                                  asset_pins=presentation_pins)
            (output / "browser.json").write_text(json.dumps(browser, indent=2) + "\n")
            report["presentation_assets_start"] = presentation_pins
            report["presentation_assets_end"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                for p in (args.renderer, args.renderer.with_suffix('.css'), args.renderer.with_suffix('.html'))}
            report["presentation_assets_unchanged"] = report["presentation_assets_start"] == report["presentation_assets_end"]
            report["browser_pass"] = browser["pass"]
            report["tested_scope"] = {"corpora": args.corpora, "viewports": args.viewports, "groups": args.groups}
            report["layout_pass_claimed"] = (not args.unfrozen_preview and browser["pass"] and set(args.corpora) == set(CORPORA)
                and set(args.viewports) == {"desktop", "mobile"}
                and set(args.groups) == {"layout", "paired", "source", "orbit"})
        else:
            report["browser_status"] = "NOT RUN: awaiting main's explicitly released isolated preview"
        report["pass"] = (report["renderer_pass"] and report.get("browser_pass", True)
                          and report.get("presentation_assets_unchanged", True))
    except Exception:
        import traceback
        report["pass"] = False
        report["error"] = traceback.format_exc()
        print(report["error"], file=sys.stderr)
    finally:
        (output / "summary.json").write_text(json.dumps(report, indent=2) + "\n")
        print(f"QA report: {output / 'summary.json'}", flush=True)
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
