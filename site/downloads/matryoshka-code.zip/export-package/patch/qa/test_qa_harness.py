"""Tests of the QA guards/oracles, not evidence that an application layout passed."""
import pytest

from browser_qa import focal_brim_assertions, geometry_assertions, graph_url, own_caption_clearance_assertions
from run_qa import arguments


@pytest.mark.parametrize("argv", [
    ["--preview", "http://127.0.0.1:9999/patch/"],
    ["--preview-ready"],
    ["--unfrozen-preview"],
    ["--preview", "https://example.com/", "--preview-ready"],
    ["--preview", "http://localhost:9999/?q=secret", "--preview-ready"],
])
def test_browser_cannot_run_without_explicit_clean_isolated_preview(argv):
    with pytest.raises(SystemExit):
        arguments(argv)


def test_default_is_offline():
    args = arguments([])
    assert args.preview is None and args.preview_ready is False


def test_preview_graph_url_keeps_the_query_delimiter_and_prefix():
    assert graph_url("http://127.0.0.1:8971/matryoshka-demo/", "cib", view="pair") == (
        "http://127.0.0.1:8971/matryoshka-demo/graph-full-v6.html?corpus=cib&view=pair")


def geometry(**updates):
    return {"nodes": [{"id": "real-node", "r": 10}], "overlapCount": 0, "overlaps": [],
            "labelOverlaps": [], "labelNodeOverlaps": [], "clipped": [],
            "pageOverflow": 0, "shapeAspect": 1, "edges": {"p95PerDiameter": .5}, **updates}


@pytest.mark.parametrize("updates", [
    {"nodes": []}, {"nodes": [{"id": "broken-radius", "r": 0}]},
    {"overlapCount": 1, "overlaps": [["a", "b"]]},
    {"labelOverlaps": [["a", "b"]]}, {"labelNodeOverlaps": [["label", "node"]]},
    {"labelOverflows": [{"id": "capsule", "scrollHeight": 80, "clientHeight": 52}]},
    {"clipped": ["node"]}, {"pageOverflow": 30},
    {"nodes": [{"id": str(i), "r": 10} for i in range(8)], "shapeAspect": 2},
    {"edges": {"p95PerDiameter": 1.2}},
])
def test_geometry_oracle_rejects_each_failure_class(updates):
    with pytest.raises(AssertionError):
        geometry_assertions(geometry(**updates))


def test_geometry_oracle_accepts_valid_measured_shape():
    geometry_assertions(geometry())


def test_sparse_circle_ring_population_is_not_an_ellipse_failure():
    geometry_assertions(geometry(nodes=[{"id": str(i), "r": 10} for i in range(8)],
                                focusMode=True, shapeAspect=2))


def brim_sample(**box_updates):
    box = {"id":"focus", "placement":"lower-rim", "left":80,"right":120,
           "top":116,"bottom":146, **box_updates}
    return {"focalLabel":{"id":"focus","visible":True,"candidate":True,
                          "center":{"x":100,"y":100,"r":10}},
            "labels":[box],"bands":[{"inner":60}],"transform":{"scale":1}}


def test_brim_oracle_accepts_near_lower_caption():
    assert focal_brim_assertions(brim_sample())["brim_gap_px"] == 6


@pytest.mark.parametrize("updates", [
    {"placement":"focus-caption"}, {"top":150,"bottom":180},
    {"left":110,"right":150}, {"bottom":170},
])
def test_brim_oracle_rejects_remote_misaligned_or_outer_ring_captions(updates):
    with pytest.raises(AssertionError):
        focal_brim_assertions(brim_sample(**updates))


def test_own_caption_oracle_accepts_clear_brim():
    value=brim_sample()
    value["nodes"]=[{"id":"focus","x":100,"y":100,"r":10}]
    assert own_caption_clearance_assertions(value,"focus")["own_circle_clearance_px"] == 6


def test_own_caption_oracle_rejects_bounds_clamp_covering_the_clicked_circle():
    value=brim_sample(left=95,right=125,top=95,bottom=125)
    value["nodes"]=[{"id":"focus","x":100,"y":100,"r":10}]
    with pytest.raises(AssertionError):
        own_caption_clearance_assertions(value,"focus")
