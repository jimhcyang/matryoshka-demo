"use strict";

// Execute the real class, with presentation/DOM plumbing stubbed, not a second layout.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");
const crypto = require("node:crypto");
const sourcePath = path.resolve(process.argv[2] || path.join(__dirname, "../ui/graph-full-v6.js"));
const source = fs.readFileSync(sourcePath, "utf8");
const start = source.indexOf("class GraphPanel {");
const end = source.indexOf("\n}\n", start) + 3;
assert(start >= 0 && end > start, "Actual GraphPanel class not found");
const helpers = source.slice(0, source.indexOf("const pause ="));
const hashStart = source.indexOf("function hashNumber(");
const hash = source.slice(hashStart, source.indexOf("\n}", hashStart) + 2);
const state = {panels: {}, guidePath: null};
const sandbox = {state, performance, console, Map, Set, document: {},
  guideReducedMotion: () => true,
  requestAnimationFrame: () => { throw Error("Reduced motion must not schedule animation"); },
  cancelAnimationFrame: () => {}};
vm.createContext(sandbox);
vm.runInContext(`${helpers}\n${hash}\n${source.slice(start, end)}\nglobalThis.Panel = GraphPanel;`, sandbox);
const Panel = sandbox.Panel;
const results = [];
function check(name, test) {
  try { const details = test(); results.push({name, pass: true, details}); }
  catch (error) { results.push({name, pass: false, error: error.stack}); }
}
function panel(nodes = [], width = 1280, height = 720) {
  const p = Object.create(Panel.prototype);
  Object.assign(p, {nodes, edges: [], width, height, level: "evidence", selected: null,
    transform: {scale: 1, x: 0, y: 0}, physicsFrame: null,
    canvas: {dataset: {}}, ringLegend: {hidden: true}, orbitFrame: null,
    graph: {}, focusBands: [], pinnedFocusIds: new Set(),
    searchMatchIds: new Set(), nodeMap: new Map(), labelOverrides: new Map()});
  p.usableBounds = () => ({left: 28, top: 28, right: width - 28, bottom: height - 28,
    width: width - 56, height: height - 56});
  p.reserveLabelSpace = () => {};
  p.draw = () => {};
  p.renderInspector = () => {};
  p.updateChrome = () => {};
  return p;
}

check("fit_preserves_circle_not_viewport_aspect", () => {
  for (const [width, height] of [[1440, 800], [390, 844]]) {
    const nodes = Array.from({length: 12}, (_, i) => ({id: `n${i}`, r: 8,
      x: Math.cos(i * Math.PI / 6) * 100, y: Math.sin(i * Math.PI / 6) * 100}));
    const p = panel(nodes, width, height);
    const before = nodes.map(n => [n.x, n.y]);
    p.fit();
    const afterX = Math.max(...nodes.map(n => n.x)) - Math.min(...nodes.map(n => n.x));
    const afterY = Math.max(...nodes.map(n => n.y)) - Math.min(...nodes.map(n => n.y));
    assert(Math.abs(afterX / afterY - 1) < .02,
      `Fit stretched a circle to aspect ${afterX / afterY} at ${width}x${height}`);
    p.fit();
    const repeatX = Math.max(...nodes.map(n => n.x)) - Math.min(...nodes.map(n => n.x));
    assert(Math.abs(repeatX - afterX) < .01, "Repeated fit compounds geometry changes");
    assert.equal(before.length, nodes.length);
  }
});

check("radii_are_view_local_and_monotone_without_mutating_mass", () => {
  const rows = [{id: "small", mass: 2}, {id: "middle", mass: 20}, {id: "large", mass: 200}];
  const p = panel();
  p.graphSelection = () => ({nodes: rows, edges: []});
  p.layout = () => {};
  p.resolveCollisions = () => {};
  p.fit = () => {};
  p.refreshGraph();
  const radii = p.nodes.map(n => n.r);
  assert(radii.every(Number.isFinite) && radii[0] > 0);
  assert(radii[0] < radii[1] && radii[1] < radii[2]);
  state.data = {irrelevant_out_of_view_mass: 1e20};
  p.refreshGraph();
  assert.deepEqual(p.nodes.map(n => n.r), radii);
  assert.deepEqual(rows.map(r => r.mass), [2, 20, 200]);
  p.graphSelection = () => ({nodes: [{id: "only", mass: 2}], edges: []});
  p.refreshGraph();
  assert(p.nodes[0].r > radii[0], "Singleton uses a local baseline, not tiny corpus-global scaling");
  return {radii, singleton: p.nodes[0].r};
});

check("four_hierarchy_distances_have_ordered_rings", () => {
  const scopes = ["same_community", "same_theme", "same_domain", "cross_domain"];
  const nodes = [{id: "focus", r: 10, index: 0}, ...scopes.flatMap((scope, group) =>
    Array.from({length: 4}, (_, i) => ({id: `${scope}-${i}`, focus_scope: scope, r: 8, index: group * 4 + i + 1})))];
  const p = panel(nodes);
  p.graph = {focusMode: true, focusNodeId: "focus"};
  p.positionFocusRings();
  const distances = scopes.map(scope => nodes.filter(n => n.focus_scope === scope).map(n => Math.hypot(n.x, n.y)));
  assert.equal(nodes[0].x, 0);
  assert.equal(nodes[0].y, 0);
  for (let i = 1; i < distances.length; i++) assert(Math.min(...distances[i]) > Math.max(...distances[i - 1]));
  return {distances, bands: p.focusBands.map(b => b.scope)};
});

check("reduced_motion_does_not_schedule_physics", () => {
  const p = panel([{id: "n", x: 0, y: 0, r: 10, index: 0, vx: 0, vy: 0}]);
  p.settlePhysics();
  assert.equal(p.physicsFrame, null);
});

check("painted_slot_center_beats_later_neighbor_padding", () => {
  for(const width of [390,1440]){
    const slot={id:'painted-slot',overlay_slot:true,x:0,y:0,r:5,index:0};
    const neighbor={id:'later-large-neighbor',x:0,y:0,r:18,index:1};
    const p=panel([slot,neighbor],width,844);
    neighbor.x=p.nodeRadius(neighbor)+5;
    assert(Math.hypot(neighbor.x,neighbor.y)>p.nodeRadius(neighbor));
    assert(Math.hypot(neighbor.x,neighbor.y)<p.nodeRadius(neighbor)+6);
    assert.equal(p.hitNode({x:0,y:0})?.id,slot.id,
      `Later neighbor's padded shell stole the actual painted slot center at width ${width}`);
    neighbor.x=4;
    assert.equal(p.hitNode({x:0,y:0})?.id,slot.id,'Center of the painted slot must remain selectable even in overlapping painted areas');
  }
});

check("outside_painted_nodes_prefers_nearest_boundary_not_array_order", () => {
  const a={id:'near-boundary',x:0,y:0,r:5,index:0},b={id:'later-farther-boundary',x:16,y:0,r:5,index:1};
  const p=panel([a,b]);
  assert.equal(p.hitNode({x:7,y:0})?.id,a.id);
  assert.equal(p.hitNode({x:100,y:100}),null);
});

const runtimePath = path.resolve(path.dirname(sourcePath), "../stage/site/runtime/public-runtime.js");
if (fs.existsSync(runtimePath)) {
  check("real_static_slot_selector_rejects_label_only_hidden_search", () => {
    const runtime = fs.readFileSync(runtimePath, "utf8");
    const a = runtime.indexOf("  function selectStaticSlots(");
    const b = runtime.indexOf("  async function verifiedSlots(", a);
    assert(a >= 0 && b > a, "Actual static slot selector not found");
    const box = {slotNormalized: value => value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim(),
      fail: (code, message) => { throw Error(`${code}: ${message}`); }};
    vm.createContext(box);
    vm.runInContext(runtime.slice(a, b) + "\nglobalThis.select = selectStaticSlots;", box);
    const slot = {id: "opaque-1", slot_id: "s1", label: "CONCEALED_SENTINEL",
      document_id: "source-1", date: "1960-01-01", context_preview: "Israel near Jerusalem [REDACTED]",
      anchors: [{id: "Israel"}]};
    const catalog = {status: {corpus: "cib", graph_run_id: "g", hierarchy_run_id: "h"}, slots: [slot]};
    const params = {corpus: "cib", graph_id: "g", hierarchy_id: "h", offset: "0", limit: "32", scan: "0"};
    assert.equal(box.select(catalog, {...params, q: "Israel Jerusalem"}).matched_count, 1);
    assert.equal(box.select(catalog, {...params, q: "CONCEALED_SENTINEL"}).matched_count, 0);
    assert.equal(box.select(catalog, {...params, q: "Israel", anchor_id: "unrelated"}).matched_count, 0);
    assert.throws(() => box.select(catalog, {...params, q: "", graph_id: "wrong"}));
  });
}
const report = {source: sourcePath, source_sha256: crypto.createHash("sha256").update(source).digest("hex"),
  browser_run: false, layout_pass_claimed: false, results};
if (process.argv[3]) fs.writeFileSync(process.argv[3], JSON.stringify(report, null, 2) + "\n");
for (const row of results) console.log(`${row.pass ? "PASS" : "FAIL"} ${row.name}${row.pass ? "" : ": " + row.error.split("\n")[0]}`);
process.exitCode = results.some(r => !r.pass) ? 1 : 0;
