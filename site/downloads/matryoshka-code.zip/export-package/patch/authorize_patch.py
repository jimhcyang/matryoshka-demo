"""Record the lead's publication decision only for a sealed, fully checked patch."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
REPO = WORKSPACE / "matryoshka_demo_site"
SITE = HERE / "stage/site"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    assert path.resolve().is_relative_to(HERE) and not path.is_symlink()
    return json.loads(path.read_bytes())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seal", type=Path, required=True)
    parser.add_argument("--integrity", type=Path, required=True)
    parser.add_argument("--browser", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    seal, integrity, browser = read(args.seal), read(args.integrity), read(args.browser)
    manifest_raw = (SITE / "release-manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    identity = sha(manifest_raw)
    assert seal["manifest_sha256"] == identity
    qa_path = HERE / seal["qa_ref"]["path"]
    qa_raw = qa_path.read_bytes()
    assert sha(qa_raw) == seal["qa_ref"]["sha256"] and read(qa_path)["status"] == "PASS"
    assert integrity["status"] == "PASS" and integrity["manifest_sha256"] == identity
    assert integrity["all_logical_roots_reconstructed"] is True
    assert len(integrity["native"]) == 14
    assert integrity["same_repository_datasets"]["files"] == 1576
    assert browser["status"] == "PASS" and browser["manifest_sha256"] == identity
    assert len(browser["browser_cells"]) >= 20
    assert all(row["status"] == "PASS" for row in browser["browser_cells"])
    assert sha((SITE / "NOTICES.txt").read_bytes()) == sha((REPO / "site/NOTICES.txt").read_bytes())

    patterns = {
        "credential": rb"(?<![A-Za-z0-9_-])(?:sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[A-Z0-9]{16})",
        "private_key_body": rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\s+[A-Za-z0-9+/=]{32,}",
        "machine_home": re.escape(str(Path.home()).encode() + b"/"),
    }
    findings = []
    scanned = 0

    def inspect(name, raw):
        nonlocal scanned
        scanned += 1
        for kind, pattern in patterns.items():
            if re.search(pattern, raw):
                findings.append(dict(path=name, indicator=kind))

    for path in sorted(SITE.rglob("*")):
        if path.is_file() and path.suffix in {".html", ".js", ".css", ".json", ".md", ".txt"}:
            inspect(path.relative_to(SITE).as_posix(), path.read_bytes())
    bundle = SITE / "downloads/matryoshka-code.zip"
    with zipfile.ZipFile(bundle) as archive:
        for name in archive.namelist():
            assert not name.startswith("/") and ".." not in Path(name).parts
            assert not name.endswith(("/.env", "/credentials.json"))
            inspect(name, archive.read(name))
    assert not findings, findings

    common = dict(date="2026-11-22", candidate_manifest_sha256=identity,
                  source_report_sha256=manifest["source_report_ref"]["sha256"])
    data = dict(version="source-bound-kg-patch-data-qa/1", status="PASS_DIAGNOSTIC_DATA", **common,
                qa_sha256=sha(qa_raw), integrity_sha256=sha(args.integrity.read_bytes()),
                browser_sha256=sha(args.browser.read_bytes()),
                ordinary_native_packets_replayed=14, datasets_revalidated=1576,
                source_only_slot_records=28201, ordinary_report_changed=False,
                benchmark_accuracy_claimed=False, research_qualification_inferred=False)
    privacy = dict(version="source-bound-kg-patch-privacy-review/1", **common,
                   status="PASS_SCOPED_INDICATOR_AND_SOURCE_REVIEW", indicators_scanned=scanned,
                   unresolved_indicator_findings=findings, notices_unchanged=True,
                   review_scope="Source-visible slot contexts, explicitly scoped CIB study quotations, code and original authored guide; retained dataset/source permissions and notices. Not a general legal certification.")
    planned = {}

    def record(name, value):
        raw = (json.dumps(value, indent=2) + "\n").encode()
        planned[name] = raw
        return dict(path=name, sha256=sha(raw))

    data_ref = record("data-qa-2026-11-22.json", data)
    privacy_ref = record("privacy-and-rights-2026-11-22.json", privacy)
    approval_ref = record("authorization-2026-11-22.json", dict(
        version="source-bound-release-authorization/1", **common,
        backend_code_sha256=manifest["backend_snapshot"]["tree_sha256"],
        publish_authorized=True, new_data_qa_accepted=True, privacy_review_accepted=True,
        licensing_review_accepted=True, scope="diagnostic_demo_with_declared_limitations",
        qualified_data_qa_ref=data_ref, privacy_and_rights_ref=privacy_ref,
        ordinary_inference_preserved=True, hidden_nationality_reference_unknown=True))
    output = args.output.absolute()
    assert output.is_relative_to(HERE) and not output.exists()
    output.mkdir(parents=True)
    for name, raw in planned.items():
        (output / name).write_bytes(raw)
    approval_raw = (json.dumps(approval_ref, indent=2) + "\n").encode()
    (output / "approval_ref.json").write_bytes(approval_raw)
    if args.execute:
        for name, raw in planned.items():
            target = REPO / "release" / name
            assert not target.exists()
            target.write_bytes(raw)
        (REPO / "release/approval_ref.json").write_bytes(approval_raw)
    print(json.dumps(dict(status="PASS", executed=args.execute, manifest_sha256=identity,
                          indicators_scanned=scanned, approval_ref=approval_ref)))


if __name__ == "__main__":
    main()
