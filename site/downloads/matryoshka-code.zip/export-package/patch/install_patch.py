"""Install the specifically reviewed update, preserving the former complete site."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
REPO = WORKSPACE / 'matryoshka_demo_site'
BASE = 'e11107cbf758b80e677f26e6292fe139f00f7d03'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory(site):
    result = []
    for path in sorted(site.rglob('*')):
        assert not path.is_symlink()
        if path.is_file():
            result.append(dict(path=str(path.relative_to(site)), bytes=path.stat().st_size, sha256=sha(path)))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--approval-ref', type=Path, required=True)
    parser.add_argument('--integrity', type=Path, required=True)
    args = parser.parse_args()
    MANIFEST = args.manifest
    assert len(MANIFEST) == 64 and all(c in '0123456789abcdef' for c in MANIFEST)
    stage = HERE / 'stage/site'
    assert sha(stage / 'release-manifest.json') == MANIFEST
    manifest = json.loads((stage / 'release-manifest.json').read_bytes())
    actual = inventory(stage)
    assert [{k:r[k] for k in ('path','bytes','sha256')} for r in manifest['files']] == [
        r for r in actual if r['path'] != 'release-manifest.json']
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=REPO, text=True).strip() == BASE
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location('patch_authorization_gate', REPO / 'release-tools/ci/validate_manifest.py')
    gate = module_from_spec(spec); spec.loader.exec_module(gate)
    assert gate.authorize(stage, args.approval_ref)
    ref = json.loads(args.approval_ref.read_bytes())
    approval_path = args.approval_ref.parent / ref['path']
    assert approval_path.parent == args.approval_ref.parent and sha(approval_path) == ref['sha256']
    approval = json.loads(approval_path.read_bytes())
    assert approval['candidate_manifest_sha256'] == MANIFEST and approval['publish_authorized'] is True
    assert args.integrity.resolve().is_relative_to(HERE)
    integrity = json.loads(args.integrity.read_bytes())
    assert integrity['status'] == 'PASS' and integrity['manifest_sha256'] == MANIFEST
    assert integrity['same_repository_datasets']['files'] == 1576
    if not args.execute:
        print('PREFLIGHT_PASS_EXACT_APPROVED_CANDIDATE')
        return
    output = HERE / 'installed_patch'
    assert not output.exists()
    assert shutil.disk_usage(REPO).free > 3 * 1024**3 + sum(r['bytes'] for r in actual)
    output.mkdir()
    staged = output / 'prepared_site'
    shutil.copytree(stage, staged)
    assert inventory(staged) == actual
    (output / 'former_README.md').write_bytes(subprocess.check_output(['git','show','HEAD:README.md'], cwd=REPO))
    (REPO / 'site').rename(output / 'former_site')
    try:
        staged.rename(REPO / 'site')
    except BaseException:
        (output / 'former_site').rename(REPO / 'site')
        raise
    # Preserve the installed suite's additional relative-path/symlink regressions.
    for source in [HERE / 'release/scoped_s2_v03/ci/browser_smoke.py']:
        target = REPO / 'release-tools/ci' / source.name
        shutil.copyfile(source, target)
    assert inventory(REPO / 'site') == actual
    receipt = dict(version='source-bound-kg-patch-install/1', base_commit=BASE,
        candidate_manifest_sha256=MANIFEST, source_report_sha256=manifest['source_report_ref']['sha256'],
        files=len(actual), site_bytes=sum(r['bytes'] for r in actual), datasets_modified=False,
        former_site_preserved=True, copy_verified_before_swap=True, api_calls=0, native_runs=0)
    (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()

