from collections import OrderedDict
import json
from functools import partial
from http.server import HTTPServer
from threading import Thread
from urllib.error import HTTPError
from urllib.request import urlopen
from types import SimpleNamespace

import pytest

from matryoshka_current import publication,server


def cache(tmp_path):
    viewer=object.__new__(server.Viewer)
    viewer.root=tmp_path
    viewer.flow_cache=OrderedDict()
    return viewer


def test_saved_flow_decodes_once_without_changing_contents(tmp_path,monkeypatch):
    viewer=cache(tmp_path)
    value=dict(weights=[.1,.2],resource_binding=dict(resource_id="r"))
    ref=publication.write(tmp_path,publication.PREFIX+"flow.json.gz",value)
    read=publication.read
    calls=[]
    def tracked(root,reference):
        calls.append(reference)
        return read(root,reference)
    monkeypatch.setattr(publication,"read",tracked)
    assert viewer.published_flow(ref)==value
    assert viewer.published_flow(ref)==value
    assert len(calls)==1


def test_warm_flow_bytes_cannot_be_changed(tmp_path):
    viewer=cache(tmp_path)
    ref=publication.write(tmp_path,publication.PREFIX+"flow.json",dict(version="first"))
    viewer.published_flow(ref)
    (tmp_path/ref["path"]).write_text(json.dumps(dict(version="other")))
    with pytest.raises(ValueError):
        viewer.published_flow(ref)


def test_flow_cache_is_bounded_and_hash_specific(tmp_path):
    viewer=cache(tmp_path)
    refs=[publication.write(tmp_path,publication.PREFIX+f"flow{i}.json",dict(i=i)) for i in range(4)]
    for i,ref in enumerate(refs):
        assert viewer.published_flow(ref)==dict(i=i)
    assert len(viewer.flow_cache)==3
    with pytest.raises(ValueError):
        viewer.published_flow(dict(refs[-1],sha256="0"*64))


def test_snapshot_changes_only_explicit_public_ui_assets(tmp_path):
    web=tmp_path/"web"
    web.mkdir()
    (web/"corpus-home.html").write_text("current home")
    (web/"app-navigation.js").write_text("shared navigation")
    snapshot=tmp_path/"snapshot"
    snapshot.mkdir()
    (snapshot/"corpus-home.html").write_text("snapshot home")
    viewer=SimpleNamespace(root=tmp_path,ui_root=snapshot)
    httpd=HTTPServer(("127.0.0.1",0),partial(server.Handler,viewer=viewer))
    thread=Thread(target=httpd.serve_forever,daemon=True)
    thread.start()
    base=f"http://127.0.0.1:{httpd.server_port}"
    try:
        assert urlopen(base+"/").read()==b"snapshot home"
        assert urlopen(base+"/app-navigation.js").read()==b"shared navigation"
        with pytest.raises(HTTPError) as error:
            urlopen(base+"/snapshot/corpus-home.html")
        assert error.value.code==404
        (snapshot/"app-navigation.js").symlink_to(web/"app-navigation.js")
        with pytest.raises(HTTPError) as error:
            urlopen(base+"/app-navigation.js")
        assert error.value.code==409
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=2)
