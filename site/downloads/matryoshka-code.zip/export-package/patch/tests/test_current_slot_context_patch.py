"""Source-only slot naming, proof-preserving navigation and bounded rebuild."""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from matryoshka_current.slot_context import POLICY, VisibleVocabulary, substantive
from matryoshka_current.slot_overlay import MARKER, VERSION, SlotOverlay, recontextualize_record, sha

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("slot_patch_rebuild", ROOT / "phase/kg_patch_20261122/slots/rebuild.py")
rebuild = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rebuild)


def entity(label, identity=None, **kwargs):
    return dict(id=identity or "entity_" + label.replace(" ", "_"), type="Entity", label=label,
                visibility="both", domain_id="d", theme_id="t", community_id="c", **kwargs)


class Maps:
    index_sha256 = "test_index_pin"

    def __init__(self, text, entities):
        base = "/graph-assets-v4/cib/"
        pins = dict(graph_run_id="g", hierarchy_run_id="h")
        self.data = {
            "/api/graph-v4-viewer?corpus=cib": dict(pins, asset_base=base,
                comparison_asset="comparison.json", search_asset="fixture_search.json"),
            base + "comparison.json": dict(pins, source_catalogs=dict(views=dict(current_earlier=dict(
                release="earlier", files_by_document={"document": "sources.json"})))),
            base + "fixture_search.json": dict(pins, view_files={"current_earlier": "fixture_search.current_earlier.json"}),
            base + "fixture_search.current_earlier.json": dict(view_key="current_earlier", records=entities),
            base + "sources.json": dict(view_key="current_earlier", release="earlier", documents=dict(document=dict(
                document_id="document", release="earlier", document_date_iso="1951-01-01", pages=[dict(
                    text=text, canonical_page_id="page", source_page=2, sequence_in_document=1)]))),
        }
        self.reads = []
        self.data["/api/graph-v4-viewer?corpus=cib"]["search_sha256"] = sha(self.raw(base + "fixture_search.json"))

    def raw(self, path):
        return json.dumps(self.data[path], sort_keys=True).encode()

    def packet(self, path):
        self.reads.append(path)
        assert "later" not in path and "reveal" not in path
        return self.raw(path), "application/json"


def fixture(text, entities):
    maps = Maps(text, entities)
    overlay = SlotOverlay(maps, [dict(case=dict(case_id="saved", document_id="document", hidden_answer="DO_NOT_USE"))])
    params = dict(corpus=["cib"], graph_id=["g"], hierarchy_id=["h"], scan=["1"], limit=["64"])
    result = overlay.packet(params)
    params.pop("scan")
    return maps, overlay, params, result


@pytest.mark.parametrize("label", ["The", "AND", "the and of", "There", "Which", "Itself", "General", "the General", "Central", "the city", "the country", "Mrs", "Bank of", "1234"])
def test_vacuous_or_fragment_vocabulary_is_rejected(label):
    assert not substantive(label)
    text = label + " [REDACTED]"
    assert VisibleVocabulary([entity(label)]).anchors(text, len(label) + 1, len(text)) == []


@pytest.mark.parametrize("label", ["The Hague", "General Nadir", "General Assembly", "Attorney General", "Foreign Ministry", "Bank of Meridian"])
def test_complete_visible_names_and_titles_survive(label):
    text = "A meeting at " + label + ". [REDACTED]"
    start = text.index("[REDACTED]")
    anchors = VisibleVocabulary([entity(label)]).anchors(text, start, len(text))
    assert len(anchors) == 1 and anchors[0][3] == label
    assert text[anchors[0][1]:anchors[0][2]] == label


def test_no_function_word_links_and_longest_complete_term_wins():
    text = "The General Nadir met delegates in The Hague. [REDACTED]"
    rows = [entity(s) for s in ("The", "General", "Nadir", "Hague", "General Nadir", "The Hague")]
    _, _, _, result = fixture(text, rows)
    slot = result["slots"][0]
    assert {a["label"] for a in slot["anchors"]} == {"The Hague", "General Nadir"}
    assert slot["label"].startswith("Redacted Slot / ")
    assert "The Hague" in slot["label"]
    assert slot["context_policy"] == POLICY and result["version"] == VERSION


def test_ambiguous_labels_and_bare_names_do_not_substitute_for_complete_names():
    text = "Lena Soren consulted Harborside officials. [REDACTED]"
    rows = [entity("Lena"), entity("Soren"), entity("Harborside", "a"), entity("Harborside", "b")]
    _, _, _, result = fixture(text, rows)
    assert not result["slots"][0]["anchors"]
    assert result["slots"][0]["hierarchy_placement"] == "unplaced_no_verified_visible_anchor"


def test_exact_whitespace_wrapping_and_punctuation_keep_original_proof_offsets():
    text = "foreign\nMINISTRY; Bank, of Meridian; Bank of Meridian. [REDACTED]"
    rows = [entity("Foreign Ministry"), entity("Bank of Meridian")]
    _, _, _, result = fixture(text, rows)
    proofs = [a["visible_proof"] for a in result["slots"][0]["anchors"]]
    assert {p["text"] for p in proofs} == {"foreign\nMINISTRY", "Bank of Meridian"}
    for proof in proofs:
        assert text[proof["start"]:proof["end"]] == proof["text"]


def test_search_window_edge_cannot_turn_a_longer_word_into_an_exact_entity_term():
    prefix = "[REDACTED] "
    # Place the window end immediately after the shorter vocabulary prefix.
    text = prefix + "x" * (len("[REDACTED]") + 320 - len(prefix) - 7) + " Harborview"
    assert text[len("[REDACTED]") + 320 - 6:len("[REDACTED]") + 320] == "Harbor"
    assert VisibleVocabulary([entity("Harbor")]).anchors(text, 0, len("[REDACTED]")) == []


def test_full_visible_phrase_search_finds_following_mask_without_hidden_answers():
    phrase = "Israel determined to transfer Foreign Ministry to Jerusalem"
    text = phrase + ". " + "Visible diplomatic reporting continued. " * 12 + "[[REDACTION_SLOT:7:slot_abc]]"
    maps, overlay, params, result = fixture(text, [entity("The"), entity("Foreign Ministry"), entity("Jerusalem")])
    slot = result["slots"][0]
    assert phrase in slot["context_preview"]
    assert overlay.packet(dict(params, q=[phrase]))["matched_count"] == 1
    assert overlay.packet(dict(params, q=["Redacted Slot"]))["matched_count"] == 1
    assert overlay.packet(dict(params, q=["DO_NOT_USE"]))["matched_count"] == 0
    assert "DO_NOT_USE" not in json.dumps(result)
    assert all("later" not in path and "reveal" not in path for path in maps.reads)


def test_markers_provenance_zero_weight_and_reciprocal_anchor_navigation():
    text = "The Hague met General Nadir. [[REDACTION_SLOT:7:slot_abc]] Then [REDACTED]"
    _, overlay, params, result = fixture(text, [entity("The"), entity("The Hague"), entity("General Nadir")])
    index = overlay.corpora["cib"]
    for ordinal, slot in enumerate(result["slots"], 1):
        assert slot["ordinal"] == ordinal
        assert slot["id"] == "opaque_slot_" + sha(f"document|page|{ordinal}".encode())[:24]
        assert slot["slot_id"] == ("slot_abc" if ordinal == 1 else None)
        detail = overlay.packet(dict(params, slot_id=[slot["id"]]))
        page = detail["page"]
        assert page["text"][slot["marker_start"]:slot["marker_end"]] == "[REDACTED]"
        assert page["text_sha256"] == sha(page["text"].encode())
        assert page["transport_text_sha256"] == sha(text.encode())
        assert detail["slot"] == slot and index.record(index.by_id[slot["id"]]) == slot
        proof = slot["label_context"]
        assert page["text"][proof["start"]:proof["end"]] == proof["text"]
        assert not MARKER.search(proof["text"])
        for edge, anchor in zip(slot["context_links"], slot["anchors"]):
            assert edge["source"] == slot["id"] and edge["target"] == anchor["id"]
            assert edge["semantic"] is False and edge["eligible_evidence"] is False
            assert edge["weight"] == edge["layout_weight"] == 0 and edge["slot_navigation"] is True
            assert edge["source_proof"] == anchor["visible_proof"]
            reverse = overlay.packet(dict(params, anchor_id=[anchor["id"]]))
            assert slot["id"] in {row["id"] for row in reverse["slots"]}
            p = edge["source_proof"]
            assert page["text"][p["start"]:p["end"]] == p["text"]


def test_no_mask_no_invented_slot_and_uninformative_context_has_no_label_claim():
    _, _, _, result = fixture("There are no observed masks.", [entity("The Hague")])
    assert result["slots"] == [] and result["coverage"]["total_slots"] == 0
    _, _, _, result = fixture("The and of [REDACTED]", [entity("The")])
    slot = result["slots"][0]
    assert slot["label"] == "Redacted Slot" and slot["label_context"] is None and slot["anchors"] == []


def test_recontextualization_is_idempotent_and_preserves_immutable_fields():
    _, overlay, params, result = fixture("The Hague [REDACTED] General Nadir.", [entity("The Hague"), entity("General Nadir")])
    original = result["slots"][0]
    page = overlay.packet(dict(params, slot_id=[original["id"]]))["page"]
    vocab = overlay.corpora["cib"].visible_vocabulary
    updated = recontextualize_record(original, page, vocab)
    assert updated == original and original == result["slots"][0]
    for mutate in (lambda p: p.update(release="later"), lambda p: p.update(text=p["text"] + "edited")):
        changed = deepcopy(page)
        mutate(changed)
        with pytest.raises(ValueError, match="provenance"):
            recontextualize_record(original, changed, vocab)
    changed = deepcopy(original)
    changed["marker_start"] += 1
    with pytest.raises(ValueError, match="boundary"):
        recontextualize_record(changed, page, vocab)
    changed = deepcopy(original)
    changed["anchors"][0]["visible_proof"]["text"] = "NOT_VISIBLE"
    with pytest.raises(ValueError, match="proof"):
        recontextualize_record(changed, page, vocab)
    changed = deepcopy(original)
    changed["semantic"] = True
    with pytest.raises(ValueError, match="nonsemantic"):
        recontextualize_record(changed, page, vocab)


def adapter_fixture():
    maps, overlay, params, result = fixture("The Hague [REDACTED] General Nadir.", [entity("The Hague"), entity("General Nadir")])
    slot = result["slots"][0]
    detail = overlay.packet(dict(params, slot_id=[slot["id"]]))
    page_path = "/data/slots/cib/" + "a" * 64 + ".json"
    record_path = "/data/slots/cib/records-0.json"
    thin = {k: slot[k] for k in ("id", "slot_id", "document_id", "date", "context_preview", "domain_id", "theme_id", "community_id")}
    thin.update(record_path=record_path, anchors=[dict(id=a["id"]) for a in slot["anchors"]])
    status = {k: v for k, v in result.items() if k not in ("slots", "offset", "limit", "matched_count", "next_offset")}
    maps.data.update({"/data/slots/cib.json": dict(status=status, slots=[thin], details={slot["id"]: page_path}),
                      record_path: [slot], page_path: detail["page"]})
    return maps, slot, page_path, record_path


def test_sparse_adapter_uses_only_existing_slots_pages_and_bound_base_vocabulary():
    maps, slot, page_path, record_path = adapter_fixture()
    reads, writes = [], {}
    def read(path):
        assert path not in ("/graph-assets-v4/cib/comparison.json", "/graph-assets-v4/cib/sources.json")
        reads.append(path)
        return maps.raw(path)
    report = rebuild.rebuild_slots(read, lambda k, v: writes.update({k: deepcopy(v)}), lambda: None, corpora=("cib",))
    assert set(writes) == {record_path, "/data/slots/cib.json"}
    assert set(reads) == {record_path, page_path, "/data/slots/cib.json", "/api/graph-v4-viewer?corpus=cib",
                          "/graph-assets-v4/cib/fixture_search.json", "/graph-assets-v4/cib/fixture_search.current_earlier.json"}
    updated = writes[record_path][0]
    assert updated == slot
    assert writes["/data/slots/cib.json"]["slots"][0]["label"] == slot["label"]
    assert writes["/data/slots/cib.json"]["details"] == maps.data["/data/slots/cib.json"]["details"]
    assert report["corpora"][0]["slots"] == 1
    assert report["api_calls"] == report["native_executions"] == 0


def test_sparse_adapter_stops_on_guard_before_read_or_write():
    def stop():
        raise RuntimeError("disk guard")
    def forbidden(*args):
        pytest.fail("No IO below disk floor")
    with pytest.raises(RuntimeError, match="disk guard"):
        rebuild.rebuild_slots(forbidden, forbidden, stop)


def test_sparse_adapter_empty_catalog_needs_no_vocabulary_and_accepts_audit_search_pin():
    maps, _, _, _ = adapter_fixture()
    catalog = maps.data["/data/slots/cib.json"]
    catalog.update(slots=[], details={})
    catalog["status"]["coverage"].update(observed_slots=0, total_slots=0)
    del maps.data["/api/graph-v4-viewer?corpus=cib"]["search_sha256"]
    reads, writes = [], {}
    def read(path):
        reads.append(path)
        assert "current_earlier" not in path
        return maps.raw(path)
    report = rebuild.rebuild_slots(read, lambda k, v: writes.update({k: v}), lambda: None, corpora=("cib",))
    assert set(writes) == {"/data/slots/cib.json"}
    assert report["corpora"][0]["slots"] == 0 and report["corpora"][0]["vocabulary_sha256"] is None


def test_sparse_adapter_rejects_changed_vocab_pin_and_marker():
    maps, _, _, path = adapter_fixture()
    maps.data["/graph-assets-v4/cib/fixture_search.current_earlier.json"]["records"].append(entity("Hidden Surname"))
    with pytest.raises(ValueError, match="source audit"):
        rebuild.rebuild_slots(maps.raw, lambda *a: None, lambda: None, corpora=("cib",))
    maps, _, _, path = adapter_fixture()
    maps.data[path][0]["ordinal"] = 2
    with pytest.raises(ValueError, match="ordinal"):
        rebuild.rebuild_slots(maps.raw, lambda *a: None, lambda: None, corpora=("cib",))
