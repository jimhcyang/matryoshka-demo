"""Copy explicitly selected patch assets into the unsealed preview stage."""
import argparse
import hashlib
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+')
    args = parser.parse_args()
    stage = HERE / 'stage/site'
    assert not (stage / 'release-manifest.json').exists()
    for name in args.files:
        assert Path(name).name == name and not name.startswith('.')
        source, target = HERE / 'ui' / name, stage / name
        assert source.is_file() and target.is_file()
        shutil.copyfile(source, target)
        assert hashlib.sha256(source.read_bytes()).digest() == hashlib.sha256(target.read_bytes()).digest()
    print('PATCH_ASSETS_SYNCED')


if __name__ == '__main__':
    main()
