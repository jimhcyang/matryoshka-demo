"""Check deployed bytes and real saved-page interactions; never run inference."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from playwright.sync_api import expect, sync_playwright


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--site", type=Path, required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    base = args.base.rstrip("/") + "/"
    manifest_raw = (args.site / "release-manifest.json").read_bytes()
    manifest = json.loads(manifest_raw)
    index = {row["path"]: row for row in manifest["files"]}
    checks, cells = [], []
    stamp = sha(manifest_raw)

    def download(relative):
        request = Request(base + relative + "?release=" + stamp,
            headers={"Cache-Control": "no-cache", "User-Agent": "Matryoshka-Release-Verification"})
        with urlopen(request, timeout=120) as response:
            assert response.status == 200
            return response.read()

    assert download("release-manifest.json") == manifest_raw, "Live manifest differs"
    for relative in ("index.html", "workbench-v6.html", "workbench-v6.js", "graph-full-v6.html",
            "graph-full-v6.js", "narrative-trace-v1.js", "narrative-endpoint-v1.js",
            "data/report-v6.json", "data/casebook-v6.json", "data/api-index.json",
            "docs/matryoshka-guide.pdf", "downloads/matryoshka-code.zip", "swedish-study.html", "swedish-study.js",
            "docs/kg-patch-addendum.pdf", "runtime/public-runtime.js"):
        if relative not in index:
            continue
        raw = download(relative)
        assert sha(raw) == index[relative]["sha256"], relative
        checks.append(dict(path=relative, bytes=len(raw), sha256=sha(raw)))
    report = json.loads((args.site / "data/report-v6.json").read_bytes())
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        try:
            context = browser.new_context(viewport=dict(width=1440, height=1000), reduced_motion="reduce")
            page = context.new_page()
            errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))

            def visit(name, relative, operation):
                errors.clear()
                page.goto(base + relative, wait_until="domcontentloaded")
                operation()
                assert not errors, (name, errors)
                page.screenshot(path=str(args.output / (name + ".png")))
                cells.append(dict(name=name, status="PASS"))
                print(name + " PASS", flush=True)

            visit("home", "index.html", lambda: page.wait_for_function(
                "()=>document.querySelector('#narrative-stories')?.dataset.status==='ready'", timeout=120000))
            for number, saved in enumerate(report["cases"]):
                def workbench():
                    expect(page.get_by_test_id("open-saved-result")).to_be_visible(timeout=120000)
                    assert page.get_by_test_id("query-text").text_content() == saved["case"]["query"]
                    page.get_by_test_id("open-saved-result").click()
                    page.wait_for_function("()=>document.querySelector('#case-view')?.getAttribute('aria-busy')==='false'", timeout=120000)
                    expect(page.get_by_test_id("local-verdict-title").first).to_be_visible(timeout=120000)
                visit("case-" + str(number), "workbench-v6.html?" + urlencode(dict(case=saved["case"]["case_id"], arm="A")), workbench)
            for corpus in ("iran", "cib", "vietnam"):
                def graph():
                    page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=180000)
                    assert page.evaluate("()=>state.panels.current.nodes.length") > 0
                    slots = page.evaluate("async()=>{await ensureSlotCensus();return slotOverlayState.payload;}")
                    assert slots["corpus"] == corpus and slots["coverage"]["complete"] and slots["hidden_values_read"] is False
                visit("graph-" + corpus, "graph-full-v6.html?corpus=" + corpus, graph)

            def french():
                page.wait_for_function("()=>document.body.dataset.graphReady==='true'", timeout=180000)
                page.wait_for_function("()=>/French Atomic Energy Commission/i.test(state.panels.current.selected?.label||state.panels.current.external?.label||'')", timeout=120000)
                page.wait_for_function("()=>document.querySelectorAll('[data-cib-document]').length>0", timeout=120000)
                assert page.locator("[data-cib-document]").count() > 0
                addon = json.loads((args.site / "data/map-source-pdf-supplement.json").read_bytes())
                for row in addon["bindings"]:
                    actual = page.evaluate("""async route=>{
                      const response=await fetch(route), raw=await response.arrayBuffer();
                      return {status:response.status, header:String.fromCharCode(...new Uint8Array(raw).slice(0,5)),
                        sha256:[...new Uint8Array(await crypto.subtle.digest('SHA-256',raw))].map(n=>n.toString(16).padStart(2,'0')).join('')};
                    }""", row["route"])
                    assert actual == dict(status=200, header="%PDF-", sha256=row["sha256"])
            visit("french-neighborhood", "graph-full-v6.html?corpus=cib&q=French%20Atomic%20Energy%20Commission&inspect=1&release=earlier", french)

            def swedish():
                page.wait_for_function("()=>document.body.dataset.studyReady==='true'", timeout=120000)
                tabs = page.get_by_role("tab")
                assert tabs.count() == 2
                for label in ("First query", "Second query"):
                    page.get_by_role("tab", name=label, exact=True).click()
                    expect(page.get_by_test_id("scoped-candidate").first).to_be_visible(timeout=120000)
                    assert page.locator("[data-testid=origin-exception-ack]").count() == 0
                    assert page.locator("[data-testid=open-saved-result]").count() == 0
                    expect(page.locator(".study-badge")).to_contain_text("Reference unknown")
            visit("swedish-S2-both", "swedish-study.html", swedish)
            context.close()
        finally:
            browser.close()
    result = dict(status="PASS", utc=datetime.now(timezone.utc).isoformat(), base=base,
        manifest_sha256=stamp, byte_checks=checks, browser_cells=cells,
        managed_chromium_headless_shell=True, browser_closed=True, api_calls=0, native_executions=0,
        research_qualification_inferred=False)
    (args.output / "receipt.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(dict(status="PASS", manifest_sha256=stamp, byte_checks=len(checks), browser_cells=len(cells))))


if __name__ == "__main__":
    main()

