"""Prepare an isolated patch edition from the exact deployed saved release."""
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REPO = ROOT / 'matryoshka_demo_site'
BASE = 'e38161d15e82227997f3d8b2dcd60a5ef3627600ce5712e3c49fc2b025ca86d9'


def main():
    source = REPO / 'site'
    assert hashlib.sha256((source / 'release-manifest.json').read_bytes()).hexdigest() == BASE
    target = HERE / 'stage'
    assert not target.exists()
    # One bounded presentation copy; no dataset duplication or full graph repack.
    assert shutil.disk_usage(HERE).free > 4 * 1024**3
    target.mkdir()
    shutil.copytree(source, target / 'site')
    (target / 'site/release-manifest.json').unlink()
    receipt = ROOT / 'src-demo-day/phase/release_finish_20261121/deploy/release_final_v06/stage_receipt.json'
    shutil.copyfile(receipt, target / 'stage_receipt.json')
    ui = HERE / 'ui'
    ui.mkdir()
    for name in ('graph-full-v6.js','graph-full-v6.html','graph-full-v6.css',
                 'swedish-study.js','swedish-study.html','swedish-study.css',
                 'workbench-v6.js','workbench-v6.html'):
        shutil.copyfile(source / name, ui / name)
    (HERE / 'baseline.json').write_text(json.dumps(dict(manifest_sha256=BASE,
        source_report_sha256=json.loads((source / 'release-manifest.json').read_bytes())['source_report_ref']['sha256'],
        source='matryoshka_demo_site/site', native_data_unchanged=True), indent=2) + '\n')
    print('PATCH_WORKSPACE_PREPARED')


if __name__ == '__main__':
    main()
