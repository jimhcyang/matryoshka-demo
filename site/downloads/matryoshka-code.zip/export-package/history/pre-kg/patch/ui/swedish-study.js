// Static, byte-pinned archived display. No inference endpoint or native claim.
const $ = selector => document.querySelector(selector);
const state = {manifest:null, cases:[], completions:[], selected:0, profile:'bridge_v2', policy:'S2', history:null};
const policyNames = {S0:'Earlier strict', S1:'Later release, prior only', S2:'Later prior + exact origin'};
const profileNotes = {
  bridge_v2:'Matched archived profile: eight inspected pages, eight candidate budget, one source-inspection hop. Identical caps for both queries and all three scopes. Lexical nomination, not the normal native constructor.',
  broad_v1:'Separate archived 40-document / 80-page pool. Its ranks are not comparable with the eight-page profile. S0 is not recorded. The old L4 base dependency hash is incomplete.',
  native_boundary_v2:'Archived quotation-boundary lexical profile, not native execution. Only S1 is recorded; S0 and S2 remain unavailable.'
};
const node = (tag, text, attrs={}) => {
  const el = document.createElement(tag);
  if(text != null) el.textContent = String(text);
  for(const [key,value] of Object.entries(attrs)) if(value != null) el.setAttribute(key,String(value));
  return el;
};
const button = (text, callback, attrs={}) => {
  const el = node('button',text,{type:'button',...attrs});
  el.addEventListener('click',callback);
  return el;
};
const current = () => state.cases[state.selected];
const record = () => current().records.find(r => r.profile_id === state.profile && r.policy_id === state.policy);
const hex = bytes => [...new Uint8Array(bytes)].map(x => x.toString(16).padStart(2,'0')).join('');
async function readJSON(ref) {
  if(!/^[a-zA-Z0-9_-]+\.json$/.test(ref.path) || !/^[a-f0-9]{64}$/.test(ref.sha256)) throw Error('Invalid saved-study reference.');
  const url = new URL(ref.path,import.meta.url);
  if(url.origin !== location.origin || !['http:','https:'].includes(url.protocol)) throw Error('Only this static study may supply a saved projection.');
  const response = await fetch(url,{cache:'no-store',credentials:'omit',redirect:'error',mode:'same-origin'});
  if(!response.ok) throw Error('The pinned static study file is unavailable.');
  const bytes = await response.arrayBuffer();
  if(hex(await crypto.subtle.digest('SHA-256',bytes)) !== ref.sha256) throw Error('Saved data failed its exact byte pin. No other record is substituted.');
  return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
}
function showDialog(title, content) {
  $('#dialog-title').textContent = title;
  $('#dialog-body').replaceChildren(content);
  $('#source-dialog').showModal();
}
function highlighted(text,start,end,expected) {
  const chars = Array.from(text), el = node('div',null,{class:'exact-quote'});
  if(Number.isInteger(start) && Number.isInteger(end) && start >= 0 && end > start && end <= chars.length && chars.slice(start,end).join('') === expected) {
    el.append(document.createTextNode(chars.slice(0,start).join('')),node('mark',expected),document.createTextNode(chars.slice(end).join('')));
  } else el.textContent = text;
  return el;
}
function displayQuery(query) {
  const el = node('div'), markers = /\[\[REDACTION_SLOT:[^\]\r\n]*\]\]|\[REDACTED\]|\[MASK\]/g;
  let cursor = 0;
  for(const match of query.matchAll(markers)) {
    el.append(document.createTextNode(query.slice(cursor,match.index)));
    el.append(match[0] === '[MASK]' ? node('mark','[REDACTION]',{'aria-label':'Focal redaction'}) : document.createTextNode('[MASKED]'));
    cursor = match.index + match[0].length;
    if(match[0] !== '[MASK]' && query[cursor] && !/\s/.test(query[cursor])) el.append(document.createTextNode(' '));
  }
  el.append(document.createTextNode(query.slice(cursor)));
  return el;
}
function citationBlock(ref,{word=null,preview=false}={}) {
  const block = node('section',null,{class:'citation-block','data-source-page-id':ref.canonical_page_id});
  block.append(node('p',`${ref.document_id} / ${ref.date} / ${ref.release || 'saved release'} / physical page ${ref.source_page ?? 'not supplied'}`,{class:'citation-meta'}));
  block.append(node('p',`${ref.canonical_page_id} / exact span [${ref.start}, ${ref.end})`,{class:'citation-meta'}));
  block.append(word ? highlighted(ref.text,word.start-ref.start,word.end-ref.start,word.text) : highlighted(ref.text));
  if(preview) block.append(node('p','Page preview only, not decision evidence.',{class:'citation-meta'}));
  block.append(node('p','Original page SHA-256: '+ref.page_sha256,{class:'source-hash'}));
  return block;
}
function sourceFor(candidate) {
  const body = node('div');
  body.append(citationBlock(candidate.context,{word:candidate.source}),node('p',`Literal wording: "${candidate.source.text}". Archived grammatical form: "${candidate.fill}". This does not verify the hidden word or delegation identity.`));
  showDialog('Exact eligible source context',body);
}
function graphLink(candidate) {
  if(!candidate.browser_node || candidate.browser_node.id !== candidate.source_node_id) return null;
  const url = new URL('graph-full-v6.html',location.href);
  url.search = new URLSearchParams({corpus:'cib',release:'later',view:'single',node_id:candidate.source_node_id}).toString();
  return node('a','Inspect exact source-vocabulary node',{href:url.pathname+url.search,target:'_blank',rel:'noopener','data-testid':'exact-graph-link','data-node-id':candidate.source_node_id});
}
function candidateCard(candidate) {
  const li = node('li',null,{class:'candidate','data-testid':'saved-candidate','data-rank':candidate.rank});
  const head = node('div',null,{class:'candidate-head'});
  head.append(node('span',String(candidate.rank).padStart(2,'0'),{class:'rank'}),node('strong',candidate.fill,{class:'fill'}),node('span','Context only / reference unknown',{class:'context-tag'}));
  li.append(head,node('p',`Source wording: "${candidate.source.text}". A source-group mention is not proof that this is the masked delegation.`));
  const link = graphLink(candidate);
  if(link) li.append(link);
  return li;
}
function renderSources(value) {
  const host = $('#sources-content');
  host.replaceChildren();
  $('#sources').hidden = !value?.candidates.length;
  $('#sources-metrics').textContent = value ? `${value.inspected_page_count} inspected / ${value.eligible_page_count.toLocaleString('en-US')} eligible pages` : '';
  if(!value?.candidates.length) return;
  const seen = new Set();
  for(const candidate of value.candidates) {
    const key = JSON.stringify(candidate.context);
    if(seen.has(key)) continue;
    seen.add(key);
    const quote = button('',() => sourceFor(candidate),{class:'quote-button','data-testid':'candidate-source'});
    const text = highlighted(candidate.context.text,candidate.source.start-candidate.context.start,candidate.source.end-candidate.context.start,candidate.source.text);
    text.className = '';
    quote.append(text,node('small',`${candidate.context.document_id} / ${candidate.context.date}`));
    host.append(quote);
  }
  host.append(button(`Inspect ${value.inspected_page_count} saved source pages`,() => inspectedSources(value),{class:'sources-button','data-testid':'inspected-sources'}));
}
function inspectedSources(value) {
  const body = node('div');
  body.append(node('p',`${value.inspected_page_count} saved inspected pages, replayed against this exact scope. Previews are not independent evidence votes.`));
  for(const source of value.inspected_sources) body.append(citationBlock(current().source_previews[source.source_key],{preview:true}));
  showDialog('Saved inspected sources / '+value.policy_id,body);
}
function renderRoutes(value) {
  const host = $('#route-content');
  host.replaceChildren();
  const candidates = value?.candidates.filter(c => c.own_source_edge) || [];
  if(!candidates.length) { host.append(node('p','No source-owned edge view is recorded for this selection. No original query-to-source walk is claimed.')); return; }
  for(const candidate of candidates) {
    const edge = candidate.own_source_edge, line = node('div',null,{class:'route-line'});
    line.append(node('span','Source event',{class:'route-label'}),node('span',edge.relation_type.replaceAll('_',' '),{class:'relation'}),node('span',candidate.source.text,{class:'route-label'}));
    const details = node('details',null,{class:'route-provenance'});
    details.append(node('summary','Exact source-owned edge'),node('p',`${edge.source_id} / ${edge.target_id}`,{class:'source-meta'}),node('p',`${edge.semantic_edge_id} / ${edge.relation_evidence_id}`,{class:'source-meta'}),node('p','Source nomination/navigation only. No original kernel traversal or hidden-delegation identity is asserted.'),button('Inspect source quotation',() => sourceFor(candidate)));
    host.append(line,details);
  }
}
function renderResult() {
  const value = record(), host = $('#policy-cards');
  host.replaceChildren();
  $('#result-scope').textContent = 'Saved contextual nomination';
  renderSources(value);
  renderRoutes(value);
  const card = node('article',null,{class:'policy-card','data-policy':state.policy,'data-testid':'policy-card'});
  if(!value) card.append(node('p','Not recorded for this exact profile and scope. No other saved result is substituted.',{class:'missing-card','data-testid':'missing-result'}));
  else {
    if(value.candidates.length) {
      const list = node('ol',null,{class:'candidate-list'});
      for(const candidate of value.candidates) list.append(candidateCard(candidate));
      card.append(list);
      if(value.candidates_omitted) card.append(node('p',`First ${value.candidate_display_limit} saved ranks shown; ${value.candidates_omitted} omitted. No reranking.`,{class:'scope-copy'}));
    } else card.append(node('p','No grounded nationality form was nominated in this saved inspection. Unresolved, not a negative identity finding.',{class:'empty-result','data-testid':'empty-result'}));
  }
  host.append(card);
}
function updateLocation() {
  const url = new URL(location.href);
  url.search = new URLSearchParams({slot:current().position,profile:state.profile,policy:state.policy}).toString();
  history.replaceState(null,'',url);
}
function selectCase(index,focus=false) {
  state.selected = index;
  $('#history-content').replaceChildren();
  render();
  updateLocation();
  if(focus) $(`[data-slot="${current().position}"]`).focus();
}
function render() {
  const c = current(), host = $('#slot-controls');
  host.replaceChildren();
  state.cases.forEach((entry,index) => {
    const selected = index === state.selected;
    const tab = button(index === 0 ? 'First query' : 'Second query',() => selectCase(index,true),{id:'tab-'+entry.position,role:'tab','aria-controls':'query-workspace','aria-selected':String(selected),tabindex:selected?'0':'-1','data-slot':entry.position});
    tab.addEventListener('keydown',event => {
      const target = {ArrowRight:(index+1)%2,ArrowLeft:(index+1)%2,Home:0,End:1}[event.key];
      if(target != null) { event.preventDefault(); selectCase(target,true); }
    });
    host.append(tab);
  });
  $('#query-workspace').setAttribute('aria-labelledby','tab-'+c.position);
  $('#slot-position').textContent = state.selected === 0 ? 'First nationality slot' : 'Second nationality slot';
  $('#query-text').replaceChildren(displayQuery(c.public_case.query));
  const position = c.source_position;
  $('#origin-binding').textContent = `${c.public_case.document_id} / ${c.public_case.date} / ${position.source_page_id} / later original mask [${position.source_mask_span.join(', ')})`;
  $('#profile-note').textContent = profileNotes[state.profile];
  $('#profile-select').value = state.profile;
  $('#policy-select').value = state.policy;
  $('#execution-pin').textContent = `Display verification completion SHA-256: ${state.manifest.display_completions[state.selected].sha256}. Native run: none.`;
  renderResult();
}
$('#dialog-close').onclick = () => $('#source-dialog').close();
$('#source-dialog').addEventListener('click',event => {
  if(event.target !== $('#source-dialog')) return;
  const r = event.target.getBoundingClientRect();
  if(event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) event.target.close();
});
$('#profile-select').onchange = event => { state.profile = event.target.value; render(); updateLocation(); };
$('#policy-select').onchange = event => { state.policy = event.target.value; render(); updateLocation(); };
$('#origin-open').onclick = async () => {
  try {
    const data = await readJSON(state.manifest.original_source_display), release = $('#origin-release').value;
    showDialog('Original still-masked source / '+release,citationBlock(data.source[release]));
  } catch(error) { $('#study-status').textContent = error.message; }
};
$('#history-open').onclick = async () => {
  try {
    if(!state.history) state.history = await readJSON(state.manifest.historical_controls);
    const host = $('#history-content');
    host.replaceChildren(node('p','Future-inclusive archived controls / not default evidence'));
    for(const row of state.history.controls.filter(c => c.case_id === current().public_case.case_id)) {
      const section = node('section',null,{class:'history-record'});
      section.append(node('h3',`${row.profile_id} / ${row.condition}: ${row.label}`));
      const list = node('ol');
      for(const candidate of row.candidates) {
        const li = node('li');
        li.append(node('strong',`${candidate.rank}. ${candidate.fill} / context only`),node('p',`${candidate.source.document_id} / ${candidate.source.date}${candidate.future_document ? ' / FUTURE DOCUMENT: excluded from S0/S1/S2' : ''}`),button('Exact archived quotation',() => showDialog('Archived control / not default evidence',citationBlock(candidate.context)),{class:'quote-button'}));
        list.append(li);
      }
      section.append(list);
      host.append(section);
    }
  } catch(error) { $('#study-status').textContent = error.message; }
};
try {
  const expected = document.querySelector('meta[name=study-data-sha256]').content;
  state.manifest = await readJSON({path:'swedish-study-patch-v01.json',sha256:expected});
  const m = state.manifest;
  if(m.version !== 'withheld-nationality-study-patch/1' || m.gold !== null || m.native_execution !== false || m.cases.length !== 2 || m.display_completions.length !== 2) throw Error('The saved study contract does not match this display.');
  state.cases = await Promise.all(m.cases.map(readJSON));
  state.completions = await Promise.all(m.display_completions.map(readJSON));
  state.cases.forEach((c,i) => {
    const completion = state.completions[i];
    if(c.version !== 'withheld-nationality-saved-projection/2' || c.gold !== null || c.native_execution !== false || c.native_run_ref !== null || c.position !== ['first','second'][i] || c.public_case.query.split('[MASK]').length !== 2 || completion.version !== 'swedish-saved-display-verification-completion/1' || completion.case_id !== c.public_case.case_id || completion.native_completion_claimed !== false || completion.native_execution !== false || completion.projection_ref.path !== m.cases[i].path || completion.projection_ref.sha256 !== m.cases[i].sha256) throw Error('Case/projection/completion binding failed.');
  });
  const params = new URLSearchParams(location.search);
  state.selected = ['second','last'].includes(params.get('slot')) ? 1 : 0;
  state.profile = Object.hasOwn(m.profiles,params.get('profile')) ? params.get('profile') : m.default_profile;
  state.policy = Object.hasOwn(policyNames,params.get('policy')) ? params.get('policy') : m.default_policy;
  render();
  updateLocation();
  $('#data-pin').textContent = 'Study manifest SHA-256: '+expected;
  $('#study-status').textContent = 'Saved contextual study. Reference answers remain unknown.';
  document.body.dataset.studyReady = 'true';
} catch(error) {
  $('#study-status').textContent = error.message;
  $('#query-workspace').replaceChildren(node('p','The exact saved study is unavailable. No inferred answer or alternate record is substituted.',{role:'alert'}));
}
