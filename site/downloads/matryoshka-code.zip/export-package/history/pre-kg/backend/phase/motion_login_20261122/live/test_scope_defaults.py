"""API0 scope normalization; saved/native historical admission stays unchanged."""
from copy import deepcopy
from datetime import date, timedelta
from pathlib import Path
from types import SimpleNamespace
import sys
import unittest
from unittest.mock import patch

from contract import ANALYST_ORIGIN_PREFIX, ROOT, Reject, case_for, scope_for, validate

sys.path.insert(0, str(ROOT))
from matryoshka_next.facts import SourcePolicy

SNAPSHOT = {'corpora': {
    'cib': {'default_before': '1961-06-14'},
    'iran': {'default_before': '1979-06-02'},
    'vietnam': {'default_before': '1975-04-30'},
}}
BASE = dict(task='hypothesis', corpus='cib', query='The council discussed trade.',
            as_of='1961-06-14', excluded_origin='real-source', focal_marker='')


class ScopeTests(unittest.TestCase):
    def test_explicit_historical_input_is_unchanged(self):
        self.assertEqual(validate(BASE), BASE)
        self.assertEqual(case_for(BASE)['document_id'], 'real-source')
        self.assertEqual(scope_for(BASE)['document_exclusion'], 'real-source')

    def test_blank_origin_gets_stable_internal_query_id_not_a_document(self):
        raw = dict(BASE, excluded_origin='')
        result = validate(raw)
        self.assertEqual(raw['excluded_origin'], '')
        self.assertTrue(result['excluded_origin'].startswith(ANALYST_ORIGIN_PREFIX))
        self.assertEqual(validate(result), result)
        self.assertEqual(validate(dict(reversed(list(raw.items())))), result)
        scope = scope_for(result)
        self.assertIsNone(scope['document_exclusion'])
        self.assertEqual(scope['origin_kind'], 'analyst_authored')
        self.assertEqual(scope['evidence_through'], '1961-06-13')
        self.assertEqual(case_for(result)['document_id'], result['excluded_origin'])
        self.assertNotEqual(validate(dict(raw, query='The council discussed defense.'))['excluded_origin'], result['excluded_origin'])

    def test_blank_or_absent_date_and_origin_use_the_selected_corpus(self):
        with patch('scope_defaults.corpus_defaults', return_value=SNAPSHOT):
            for corpus in SNAPSHOT['corpora']:
                for omitted in (True, False):
                    raw = dict(BASE, corpus=corpus, as_of='', excluded_origin='')
                    if omitted:
                        del raw['as_of'], raw['excluded_origin']
                    value = validate(raw)
                    self.assertEqual(value['as_of'], SNAPSHOT['corpora'][corpus]['default_before'])
                    self.assertTrue(value['excluded_origin'].startswith(ANALYST_ORIGIN_PREFIX))
                    self.assertEqual(validate(value), value)

    def test_empty_origin_does_not_exclude_actual_source_documents(self):
        value = validate(dict(BASE, excluded_origin=''))
        page = dict(id='p1', corpus='cib', document_id='real-source', date='1961-06-13',
                    permitted=True, visibility='earlier', text='The council discussed trade.')
        corpus = SimpleNamespace(corpus='cib', pages=[page], classification={})
        self.assertTrue(SourcePolicy(corpus, case_for(value)).allowed(0))
        self.assertFalse(SourcePolicy(corpus, case_for(BASE)).allowed(0))

    def test_last_evidence_day_is_included_but_the_boundary_is_not(self):
        value = validate(dict(BASE, excluded_origin=''))
        page = dict(id='p1', corpus='cib', document_id='actual', date='1961-06-13',
                    permitted=True, visibility='earlier', text='Source content.')
        corpus = SimpleNamespace(corpus='cib', pages=[page], classification={})
        self.assertTrue(SourcePolicy(corpus, case_for(value)).allowed(0))
        page['date'] = value['as_of']
        self.assertFalse(SourcePolicy(corpus, case_for(value)).allowed(0))

    def test_analyst_mode_does_not_relax_visibility_classification_or_noforn(self):
        value = validate(dict(BASE, corpus='iran', as_of='1979-06-02', excluded_origin=''))
        first = dict(id='p1', corpus='iran', document_id='actual', date='1979-06-01',
                     permitted=True, visibility='both', classification='CONFIDENTIAL', text='Plain source.')
        def policy(pages):
            return SourcePolicy(SimpleNamespace(corpus='iran', pages=pages, classification={}), case_for(value))
        self.assertTrue(policy([first]).allowed(0))
        for key, bad in [('visibility', 'later'), ('classification', 'SECRET'), ('permitted', False)]:
            self.assertFalse(policy([dict(first, **{key: bad})]).allowed(0))
        self.assertFalse(policy([first, dict(first, id='p2', text='NOFORN')]).allowed(0))

    def test_invalid_inputs_and_spoofed_internal_ids_fail_closed(self):
        for fields in ({'excluded_origin': None}, {'excluded_origin': '../file'},
                       {'excluded_origin': 'sk-' + 'x' * 40},
                       {'excluded_origin': ANALYST_ORIGIN_PREFIX + '0' * 32},
                       {'as_of': '1961-02-30'}, {'model': 'anything'}, {'corpus': 'other'}):
            with self.subTest(fields=fields), self.assertRaises(Reject):
                validate(dict(BASE, **fields))
        with patch('scope_defaults.corpus_defaults', side_effect=ValueError('changed snapshot')):
            with self.assertRaises(Reject) as caught:
                validate(dict(BASE, as_of=''))
            self.assertEqual(caught.exception.status, 503)


if __name__ == '__main__':
    unittest.main()
