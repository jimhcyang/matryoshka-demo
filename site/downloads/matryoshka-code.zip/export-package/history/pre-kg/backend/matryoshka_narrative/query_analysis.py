"""Query-bound case/layout analysis; source strings and token spans stay raw."""
from copy import deepcopy
from functools import lru_cache
import re
from types import FunctionType, MethodType

from matryoshka_demo.io import digest
from matryoshka_demo.roles import lexicon
from matryoshka_demo_v61 import scope_matching as scoped

VERSION = "narrative-query-bound-case-layout-analysis/3"
_PLAIN_ENGINE_FIELDS = frozenset({
    "adjective_positions", "analysis_parser", "cache", "disposition_reading",
    "grammar_sources", "layout_words", "lexical_resource", "nouns", "parse",
    "plural_labels", "predicates", "quantity_units", "verb_objects",
})


def _plain_engine(base):
    if type(base) is not scoped.Engine or set(vars(base)) - _PLAIN_ENGINE_FIELDS:
        return False
    if type(base.analysis_parser) is not scoped.AnalysisParser or base.parse is not base.analysis_parser:
        return False
    return all(getattr(getattr(base, name), "__func__", None) is getattr(scoped.Engine, name)
               for name in ("frames", "targets", "source_view"))


def public_names(case, base):
    """Admit unambiguous mixed-case query proper nouns, never source hints."""
    forms, rejected = {}, {}
    for token in base.analysis_parser.identity.parser(case["query"]):
        text = token.text
        if token.pos_ != "PROPN" or not re.fullmatch(r"[A-Za-z][A-Za-z-]{2,}", text):
            continue
        if not any(c.islower() for c in text) or not any(c.isupper() for c in text):
            continue
        key = text.casefold()
        try:
            common = any(lemma.name() == key for sense in lexicon().synsets(key) for lemma in sense.lemmas())
        except LookupError:
            common = True
        if common:
            rejected[key] = "COMMON_LEXEME"
            continue
        forms.setdefault(key, set()).add(text)
    names = {key: next(iter(values)) for key, values in forms.items() if len(values) == 1}
    return names, rejected


def _project_entity_intervals(result, proposed):
    """Rebuild whole entity spans, including raw SPACE tokens between words."""
    from spacy.tokens import Span
    try:
        expected = [(e.start_char, e.end_char, e.label) for e in proposed.ents]
        starts = {t.idx: t.i for t in result}
        ends = {t.idx + len(t): t.i + 1 for t in result}
        spans = []
        for start, end, label in expected:
            if start not in starts or end not in ends:
                return False, "ENTITY_SPAN_BOUNDARY_MISMATCH"
            a, b = starts[start], ends[end]
            if a >= b or result[a].is_space or result[b - 1].is_space:
                return False, "ENTITY_SPAN_BOUNDARY_MISMATCH"
            spans.append(Span(result, a, b, label=label))
        result.set_ents(spans, default="outside")
        if [(e.start_char, e.end_char, e.label) for e in result.ents] != expected:
            return False, "ENTITY_SPAN_RECONSTRUCTION_MISMATCH"
        lexical = {(t.idx, len(t)): t for t in proposed if not t.is_space}
        for token in result:
            if not token.is_space:
                counterpart = lexical[(token.idx, len(token))]
                if (token.ent_iob, token.ent_type) != (counterpart.ent_iob, counterpart.ent_type):
                    return False, "ENTITY_LEXICAL_TAG_MISMATCH"
            elif token.ent_iob_ not in {"I", "O"}:
                return False, "ENTITY_SPACE_TAG_MISMATCH"
        return True, None
    except (ValueError, IndexError, KeyError):
        return False, "INVALID_ENTITY_SPAN_PROJECTION"


def _correlative_layout_fallback(original, projected):
    """License only one preconj->det difference with explicit AND siblings."""
    if original.text != projected.text:
        return None
    a = [t for t in original if not t.is_space]
    b = [t for t in projected if not t.is_space]
    if [(t.idx, t.text) for t in a] != [(t.idx, t.text) for t in b]:
        return None
    try:
        if [(e.start_char, e.end_char, e.label_) for e in original.ents] != [
                (e.start_char, e.end_char, e.label_) for e in projected.ents]:
            return None
    except ValueError:
        return None
    changed = []
    for old, new in zip(a, b):
        attrs = lambda t: (t.head.idx, t.head.text, t.pos, t.tag, t.lemma,
                            str(t.morph), t.ent_iob, t.ent_type, t.is_sent_start)
        if attrs(old) != attrs(new):
            return None
        if old.dep != new.dep:
            if old.lower_ != 'both' or old.dep_ != 'preconj' or new.dep_ != 'det':
                return None
            changed.append(old)
    if len(changed) != 1:
        return None
    both = changed[0]
    host = both.head
    if host.pos_ not in {'NOUN', 'PROPN'}:
        return None
    candidates = [host, *[t for t in host.children if t.dep_ == 'amod' and t.pos_ == 'ADJ']]
    pairs = []
    for first in candidates:
        conjuncts = [t for t in first.children if t.dep_ == 'conj' and t.pos_ == first.pos_]
        conjunctions = [t for t in first.children if t.dep_ == 'cc']
        if len(conjuncts) != 1 or len(conjunctions) != 1 or conjunctions[0].lower_ != 'and':
            continue
        second, conjunction = conjuncts[0], conjunctions[0]
        if not both.idx < first.idx < conjunction.idx < second.idx:
            continue
        if first != host and not second.idx < host.idx:
            continue
        pairs.append((first, conjunction, second))
    if len(pairs) != 1:
        return None
    first, conjunction, second = pairs[0]
    proof = lambda t: dict(text=t.text, start=t.idx, end=t.idx + len(t))
    return dict(kind='CORRELATIVE_AND_ORIGINAL_PARSE_RETAINED',
        both=proof(both), host=proof(host), members=[proof(first), proof(second)],
        conjunction=proof(conjunction), original_dependency='preconj',
        proposed_dependency='det', other_lexical_attributes_and_heads_equal=True,
        entity_intervals_equal=True, complete_source_and_tokens_retained=True,
        query_independent=True, quantifiers_deleted=False, frames_rewritten=False,
        coordination_expanded=False, entailment_certified=False)


def build_engine(base, case, *, acronyms=frozenset()):
    """Build a bounded per-case parser/cache without changing the supplied engine."""
    if not _plain_engine(base):
        return base, dict(version=VERSION, query_sha256=digest(case["query"]),
            mode="CUSTOM_ENGINE_PRESERVED", public_query_bound_names={}, common_words_rejected={},
            public_query_bound_acronyms=sorted(acronyms), analysis_extension_applied=False,
            source_characters_and_offsets_preserved=True, source_oracle_used=False)
    names, rejected = public_names(case, base)
    acronyms = frozenset(acronyms)

    class QueryNameParser(scoped.AnalysisParser):
        def __call__(self, text):
            baseline = super().__call__(text)
            raw = self.identity.parser(text)
            changes = {i: names[t.text.casefold()] for i, t in enumerate(raw)
                       if t.text.isupper() and t.text.casefold() in names
                       and baseline[i].pos_ not in {"AUX", "PRON", "DET"} and baseline[i].tag_ != "MD"}
            if (not changes and not any(t.text in acronyms for t in raw)) or self.language is None:
                return baseline
            from spacy.tokens import Doc
            from spacy.attrs import DEP, ENT_IOB, ENT_TYPE, HEAD, LEMMA, MORPH, POS, SENT_START, TAG
            words = [changes.get(i, t.text if t.text in acronyms else t.text.lower() if t.text.isupper() else t.text)
                     for i, t in enumerate(raw)]
            if any(len(word) != len(t.text) for word, t in zip(words, raw)):
                return baseline
            expected = list(text)
            for t, word in zip(raw, words):
                expected[t.idx:t.idx + len(t)] = word
            analysis = Doc(raw.vocab, words=words, spaces=[bool(t.whitespace_) for t in raw])
            bounds = lambda doc: [(t.idx, len(t)) for t in doc]
            if analysis.text != "".join(expected) or bounds(analysis) != bounds(raw):
                return baseline
            analysis = self.language(analysis)
            if bounds(analysis) != bounds(raw):
                return baseline
            restored = raw.copy()
            attrs = [HEAD, DEP, POS, TAG, LEMMA, MORPH, ENT_IOB, ENT_TYPE, SENT_START]
            restored.from_array(attrs, analysis.to_array(attrs))
            for token, original in zip(restored, raw):
                if (len(token.text) > 3 and token.text.isupper() and token.pos_ == "PRON" and token.tag_ == "DT"
                        and not token.morph.get("PronType") and original.pos_ == "PROPN"):
                    token.pos_ = "PROPN"
                    token.tag_ = original.tag_
                    token.lemma_ = original.text.casefold()
            assert restored.text == text and bounds(restored) == bounds(raw)
            self.records[digest(text)] = dict(kind="PUBLIC_QUERY_BOUND_NAME_CASE_ANALYSIS",
                changed=[dict(start=raw[i].idx, end=raw[i].idx + len(raw[i]), spelling=word)
                         for i, word in changes.items()],
                public_acronyms=sorted(acronyms), source_modified=False,
                offsets_preserved=True, identity_certified=False)
            return restored

    class LayoutParser(QueryNameParser):
        def __call__(self, text):
            original = super().__call__(text)
            flattened = text.replace("\r", " ").replace("\n", " ").replace("\t", " ")
            if flattened == text:
                return original
            proposed = super().__call__(flattened)
            source = {(t.idx, len(t)): t for t in original if not t.is_space}
            projected = {(t.idx, len(t)): t for t in proposed if not t.is_space}
            if source.keys() != projected.keys():
                return original
            if any(source[k].text != projected[k].text for k in source):
                return original
            if any((t.head.idx, len(t.head)) not in source for t in projected.values()):
                return original
            from spacy.attrs import DEP, ENT_IOB, ENT_TYPE, HEAD, LEMMA, MORPH, POS, SENT_START, TAG
            import numpy as np
            attrs = [HEAD, DEP, POS, TAG, LEMMA, MORPH, ENT_IOB, ENT_TYPE, SENT_START]
            result = original.copy()
            values = result.to_array(attrs)
            proposed_values = proposed.to_array(attrs)
            # Normalized SPACE tokens can differ. Map lexical heads by exact raw span.
            for key, raw in source.items():
                token = projected[key]
                values[raw.i] = proposed_values[token.i]
                head = source[(token.head.idx, len(token.head))]
                values[raw.i, 0] = np.asarray(head.i - raw.i, dtype="int64").view("uint64")
            result.from_array(attrs, values)
            valid_entities, reason = _project_entity_intervals(result, proposed)
            if not valid_entities:
                self.records[digest(text)] = dict(kind="WHITESPACE_SYNTAX_PROJECTION_WITHHELD",
                    fallback_reason=reason, source_text_modified=False,
                    all_source_offsets_preserved=True, projection_applied=False)
                return original
            assert result.text == text
            assert [(t.idx, len(t)) for t in result] == [(t.idx, len(t)) for t in original]
            fallback = _correlative_layout_fallback(original, result)
            if fallback is not None:
                self.records[digest(text)] = dict(version=VERSION, **fallback)
                return original
            self.records[digest(text)] = dict(kind="EXACT_WHITESPACE_SYNTAX_PROJECTION",
                source_text_modified=False, all_source_offsets_preserved=True,
                lexical_tokens_added_or_removed=False, normalized_line_breaks=True,
                entity_intervals_preserved=True)
            return result

    original = scoped._source_frames
    source = FunctionType(original.__code__, dict(scoped._scope, _AnalysisParser=LayoutParser),
                          original.__name__, original.__defaults__, original.__closure__)
    source = lru_cache(maxsize=128)(source)
    original = scoped.Engine.frames
    frames = FunctionType(original.__code__, dict(vars(scoped), _source_frames=source),
                          original.__name__, original.__defaults__, original.__closure__)
    frames.__kwdefaults__ = deepcopy(original.__kwdefaults__)
    engine = scoped.Engine(base.analysis_parser.identity.parser)
    engine.disposition_reading = base.disposition_reading
    engine.analysis_parser = LayoutParser(base.analysis_parser.identity.parser)
    engine.parse = engine.analysis_parser
    engine.frames = MethodType(frames, engine)
    return engine, dict(version=VERSION, query_sha256=digest(case["query"]),
                        mode="QUERY_BOUND_CASE_AND_LAYOUT", analysis_extension_applied=True,
                        public_query_bound_names=dict(names), common_words_rejected=dict(rejected),
                        public_query_bound_acronyms=sorted(acronyms),
                        source_characters_and_offsets_preserved=True, source_oracle_used=False)
