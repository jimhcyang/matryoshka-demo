# Live integration v1

Live is separate from saved `/api/` replay. Do not route `/live-api/` through
`PublicReplay.fetch`. The Live page deliberately does not load the replay shim.
No existing case catalog, answer bank, gold cache or saved native run is an input.

All endpoints below require `Authorization: Bearer <session capability>`.
Capabilities are memory-only in the browser, supplied out of band, expire with
the server session and are never URL parameters, cookies, files or postMessages.
`Origin` must exactly match a server-configured origin, including its port.

* `GET /live-api/health`: authenticated readiness, mode, limits, current model.
* `POST /live-api/jobs`: exact JSON fields `task` (mosaic/hypothesis/redaction),
  `corpus` (cib/iran/vietnam), `query` (declarative clause, <=2000 UTF-8 bytes),
  `as_of` (YYYY-MM-DD, strict BEFORE), `excluded_origin` (whole document ID;
  an explicitly declared new analyst origin is allowed), `focal_marker`
  (empty unless Redaction, then a unique supported mask such as `[MASK]`).
  JSON-only, <=8192 bytes. Returns 202 with `job_id`, `run_id`, status and stages.
* `GET /live-api/jobs/{id}`: snapshot including ordered public stage events.
  Poll at ~800ms; this is status polling, not a token/reasoning stream.
* `POST /live-api/jobs/{id}/cancel`: JSON `{}`; kills active worker or cancels
  queued work. Provider billing already incurred/reserved is not refunded.
* `POST /live-api/jobs/{id}/retry`: JSON `{}`; explicit new attempt, at most two
  retries per job lineage. Failed/cancelled/timed-out attempts stay retained.
* `GET /live-api/jobs/{id}/result`: only after completion. Version
  `matryoshka-live-result/1`, `run_id`, `execution_kind` (`live` or clearly
  `fixture`), `native`, `condition` (the existing display_record output),
  `trace` (the existing build_trace output, no postrun graph reconstruction),
  `selected_evidence`, `source_scope`, `receipt`, and private artifact references.
  `sources` remains inspected referenced pages only. `document_pages` maps each
  referenced document ID to an array of ALL policy-eligible complete-index pages,
  individually hash verified. Every inventory page has `provenance_only: true`
  and `inspection_not_implied: true`. This is eligible-release provenance, not
  a claim to supply the complete original document or additional evidence.

The native output, condition, selected evidence and actual paths are retained
separately with checksums. Source scope is analyst-declared and shown explicitly;
absence of evidence is not opposition. No chain-of-thought is retained or sent.

The browser reconstructs the producer's native atom or reading/candidate units
and permitted evidence locations. An inventory item cannot borrow another
unit's location, citations or direction. A path's accepted evidence ID, target,
direction, endpoint purpose and exact decision citations must match that same
native unit; its readout repeats the unchanged candidate status. Context paths
have no accepted evidence IDs, retain `CONTEXT`, and cannot use `FOR`, support or
opposition tones. Graph routes additionally need actual native retrieval edges;
the configured hierarchy kernel has source handoffs, not invented KG walks.

## Workbench handoff (main owns workbench/nav)

Import `live-result-adapter.js`; it exports `LiveClient`, `verifyEnvelope`,
`toWorkbenchPacket`, `loadWorkbenchRun`, `sendToWorkbench`, and `receiveFromLive`.
No imports have automatic side effects. It uses narrowly scoped XHR, because the
existing saved runtime actually replaces ALL fetch requests and rejects bearer
headers even for `/live-api/`. No global transport override is installed.

Main's early `?live_run=` branch can use:

```js
const {loadWorkbenchRun} = await import('./live-result-adapter.js');
const packet = await loadWorkbenchRun(new URLSearchParams(location.search).get('live_run'));
window.MatryoshkaLiveWorkbench.mount(packet);
```

`packet` is `{report, row, condition, trace, sources, document_pages, origins: null, receipt,
source_scope, selected_evidence, run_id, execution_kind}`. `report.cases === [row]`
conceptually, `row.case` is the exact public case, `row.configurations.llm_readings`
is the full `condition` DTO, `report.run_id` is the opaque Live run ID,
`report.version` is `matryoshka-live-report/1`, and `report.saved_replay` is false.
`sources` maps canonical page IDs to exact source pages. `origins` is null: no
answer-bearing historical original is fetched or invented. To load directly
instead of the opener handshake, explicitly pass `{backend, capability}` as the
second argument; the adapter disconnects that temporary client after loading.

The Live page opens `workbench-v6.html?live_run=<run_id>` (no credential). Main can
call `receiveFromLive(callback)` in that window. It sends a
`matryoshka:live-ready` handshake to its same-origin opener, validates origin,
source window and the query's run ID, then receives
`{type:'matryoshka:live-result', result:<envelope>}`. Main's callback can display
`result.condition.configurations.llm_readings`, `result.trace` and scope/receipt.
This does not replace any saved API endpoint or turn a saved replay into Live.
The returned cleanup function removes the handshake listener/timer. The Live
page retains its verified result for a bounded handshake, not in web storage.

## Hosting boundary

GitHub Pages only hosts the frontend. Connect explicitly to an independently
operated authenticated HTTPS backend, or this loopback companion. Both sides
must opt in to the exact origin. Browser mixed-content/private-network policy
may prevent public HTTPS Pages from reaching loopback; open the local companion
page in that case. No unauthenticated inference endpoint or remote deployment
is supplied. Backend URL is not an API key, and must end in `/live-api/`.
