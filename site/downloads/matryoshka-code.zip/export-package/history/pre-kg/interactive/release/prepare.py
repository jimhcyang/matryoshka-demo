"""Clone the published baseline without copying its large shared dataset store."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
SOURCE = WORKSPACE / 'matryoshka_demo_site/site'


def main():
    assert shutil.disk_usage(HERE).free >= 3 * 1024**3
    target = HERE / 'stage/site'
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    raw = (SOURCE / 'release-manifest.json').read_bytes()
    identity = hashlib.sha256(raw).hexdigest()
    assert identity == '9d03341150d9cc137e6842a897cde7d461f9f645d3d189dd0eb9449f95b9a818'
    subprocess.run(['cp', '-cR', str(SOURCE), str(target)], check=True)
    assert (target / 'release-manifest.json').read_bytes() == raw
    (target / 'release-manifest.json').unlink()
    (HERE / 'baseline.json').write_text(json.dumps(dict(manifest_sha256=identity,
        commit='9f11c5c6923ef53b04d35b5838914cb2534c0844',
        source='matryoshka_demo_site/site', datasets_copied=False,
        source_report_ref=json.loads(raw)['source_report_ref']), indent=2) + '\n')
    print('UNSEALED_APFS_CLONE_READY')


if __name__ == '__main__':
    main()
