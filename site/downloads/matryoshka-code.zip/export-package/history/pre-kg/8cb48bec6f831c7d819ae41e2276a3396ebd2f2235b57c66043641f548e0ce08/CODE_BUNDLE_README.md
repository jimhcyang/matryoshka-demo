# KG Patch Code Snapshot

This contained code ZIP extends the exact preceding release code archive. It
retains the full exporter/backend import closure, vendor helpers and contracts,
and adds the active patch UI, runtime integration tools, source-visible slot
implementation and release helpers. Replaced originals are retained under
`history/pre-kg/`. The corpus-derived authoring fixture remains excluded with
its original hash declared, not silently removed from backend tree identity.

Only `slot_overlay.py` and the new `slot_context.py` change the backend snapshot.
This is an implementation snapshot, not a claim that historical native results
were rerun with this code. Per-case historical execution versions are unchanged.
Root `slot-runtime.js` is the active patch version; `static_slots.py` retains
thin labels and context policy. The composed staged public runtime is included.

`ci/` uses the installed six-test manifest/authorization suite, with the new
Swedish browser contract: both query tabs, immediate S2, no acknowledgment,
exact source inspection and unknown gold. The installed transport tests, tools
and readout-cache checker are under `installed/`; their original layout is
retained. Legacy copies in `history/` are audit evidence, not active CI.

The Swedish study presents Input, Sources and Results. It replays archived
source-inspection nominations with unknown reference answers, not new native
S2 completions. The requested new normal-engine S2 completion remains unmet;
no user acceptance of a deferral is asserted. A legitimate new native handoff
requires explicit schema and guard review before this helper can accept it.

Use explicit pinned input roots for generic exporter regeneration. Source
corpora, datasets, native artifacts, ledgers, credentials and hidden answers are
not included. Patch packaging does not copy or content-rehash the dataset store.
It does not call models, install software, run a server, change git state or
authorize publication. `patch/release/HANDOFF.md` documents the bounded workflow.

The five-page interaction addendum supplements the previous saved-report guide.
Its Swedish S2/no-ack behavior supersedes the older guide's acknowledgment
description. The original report-bound guide assets stay byte-identical.
