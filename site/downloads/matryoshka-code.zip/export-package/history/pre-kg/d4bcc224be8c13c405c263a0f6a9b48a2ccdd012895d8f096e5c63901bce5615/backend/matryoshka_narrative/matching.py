"""Opt-in, bounded frame evidence; never a replacement for the strict baseline.

The caller supplies an already adapted H/M case and the complete frozen source
index. One unit may attest extra independent assertions, but every requested
frame and its literal argument/scope checks must still be covered in that unit.
"""
from copy import deepcopy
from datetime import datetime
from collections.abc import Mapping
from functools import lru_cache
import json
import re
from types import FunctionType, MethodType, SimpleNamespace

from matryoshka_demo.io import digest, offline
from matryoshka_demo.contracts import public_case
from matryoshka_demo_v61 import scope_matching as scoped
from matryoshka_next.facts import SourcePolicy, public_plan
from .query_analysis import build_engine

# Existing source certificates bind this unchanged proof protocol explicitly.
VERSION = "narrative-guarded-source-frame-matching/4"
HISTORICAL_SOURCE_ASCRIPTION = "DATED_SOURCE_ASCRIPTION_NOT_CONTINUED_TENURE/1"
_CONTENT = {"NOUN", "PROPN", "ADJ", "NUM", "VERB", "ADV", "ADP"}


def _public_acronyms(case, engine):
    doc = engine.analysis_parser.identity.parser(case["query"])
    return frozenset(t.text for t in doc if re.fullmatch("[A-Z]{2,10}", t.text)
        and (t.pos_ == "PROPN" or t.ent_type_ in {"ORG", "GPE", "LOC"}))


def _acronym_engine(base, acronyms):
    """Query-local analysis only; raw strings and the supplied engine stay intact."""
    if not acronyms:
        return base

    class PublicAcronymParser(scoped.AnalysisParser):
        def __call__(self, text):
            raw = self.identity.parser(text)
            if not any(t.text in acronyms for t in raw):
                return super().__call__(text)
            from spacy.tokens import Doc
            from spacy.attrs import DEP, ENT_IOB, ENT_TYPE, HEAD, LEMMA, MORPH, POS, SENT_START, TAG
            words = [t.text if t.text in acronyms else t.text.lower() if t.text.isupper() else t.text for t in raw]
            if self.language is None or any(len(w) != len(t) for w, t in zip(words, raw)):
                return super().__call__(text)
            expected = list(text)
            for token, word in zip(raw, words):
                expected[token.idx:token.idx + len(token)] = word
            analysis = Doc(raw.vocab, words=words, spaces=[bool(t.whitespace_) for t in raw])
            if analysis.text != "".join(expected):
                return super().__call__(text)
            analysis = self.language(analysis)
            if [(t.idx, len(t)) for t in analysis] != [(t.idx, len(t)) for t in raw]:
                return super().__call__(text)
            doc = raw.copy()
            attrs = [HEAD, DEP, POS, TAG, LEMMA, MORPH, ENT_IOB, ENT_TYPE, SENT_START]
            doc.from_array(attrs, analysis.to_array(attrs))
            # Preserve the existing scoped parser's separate proper-name repair.
            for token, original in zip(doc, raw):
                if (len(token.text) > 3 and token.text.isupper() and token.pos_ == "PRON" and token.tag_ == "DT"
                        and not token.morph.get("PronType") and original.pos_ == "PROPN"):
                    token.pos_ = "PROPN"
                    token.tag_ = original.tag_
                    token.lemma_ = original.text.casefold()
            self.records[digest(text)] = dict(kind="PUBLIC_QUERY_BOUND_ACRONYM_ANALYSIS",
                public_acronyms=sorted(acronyms), source_text_modified=False,
                offsets_preserved=True, canonical_identity_certified=False)
            return doc

    original = scoped._source_frames
    source = FunctionType(original.__code__, dict(scoped._scope, _AnalysisParser=PublicAcronymParser),
        original.__name__, original.__defaults__, original.__closure__)
    source = lru_cache(maxsize=512)(source)
    original = scoped.Engine.frames
    frames = FunctionType(original.__code__, dict(vars(scoped), _source_frames=source),
        original.__name__, original.__defaults__, original.__closure__)
    frames.__kwdefaults__ = deepcopy(original.__kwdefaults__)
    engine = scoped.Engine(base.analysis_parser.identity.parser)
    engine.disposition_reading = base.disposition_reading
    engine.analysis_parser = PublicAcronymParser(base.analysis_parser.identity.parser)
    engine.parse = engine.analysis_parser
    engine.frames = MethodType(frames, engine)
    return engine


def _proof_spans(value):
    spans = set()
    if isinstance(value, dict):
        if isinstance(value.get("text"), str) and type(value.get("start")) is int and type(value.get("end")) is int:
            spans.add((value["start"], value["end"]))
        for key, item in value.items():
            if key not in {"v5_analysis", "v6_analysis", "source_normalization", "v61_layout"}:
                spans.update(_proof_spans(item))
    elif isinstance(value, (list, tuple)):
        for item in value:
            spans.update(_proof_spans(item))
    return spans


def _token(frame, doc):
    proof = frame["predicate_proof"]
    return next((t for t in doc if t.idx == proof["start"]
        and t.idx + len(t) == proof["end"] and t.lemma_.casefold() == frame["predicate"]), None)


def _covered_query(frames, doc):
    spans = _proof_spans(frames)
    for frame in frames:
        token = _token(frame, doc)
        if token is None:
            continue
        scope = {s["predicate"] for s in frame["qualifiers"].get("scope", [])}
        for ancestor in token.ancestors:
            if ancestor.lemma_.casefold() in scope:
                spans.add((ancestor.idx, ancestor.idx + len(ancestor)))
        for prep in token.children:
            if prep.dep_ == "prep" and "prep:" + prep.lemma_.casefold() in frame["roles"]:
                spans.add((prep.idx, prep.idx + len(prep)))
            elif prep.dep_ == "prep" and prep.lemma_.casefold() in {"on", "in", "at", "during"}:
                children = list(prep.subtree)
                if any(min(t.idx for t in children) <= d["start"] < d["end"] <=
                        max(t.idx + len(t) for t in children) for d in frame.get("event_dates", [])):
                    spans.add((prep.idx, prep.idx + len(prep)))
    return [dict(text=t.text, start=t.idx, end=t.idx + len(t), dependency=t.dep_)
        for t in doc if t.pos_ in _CONTENT and t.dep_ not in {"aux", "auxpass", "cop"}
        and not any(a <= t.idx < t.idx + len(t) <= b for a, b in spans)]


def _named_actor(frame):
    actors = frame["roles"].get("agent", frame["roles"].get("owner", []))
    holders = [p for scope in frame["qualifiers"].get("scope", []) for p in scope.get("speakers", [])]
    # A bound reporting holder attests qualified content, not the inner actor's
    # identity or occurrence of the described event. Scope matching still runs.
    bound = lambda values: bool(values) and all(p.get("names") and not p.get("unresolved") for p in values)
    return bound(holders) if holders else bound(actors)


def _passive_anchor(target, source, match):
    """No invented agent obligation; identity must bind in a requested role."""
    if (target["kind"] != "EVENT" or not target.get("passive")
            or target["roles"].get("agent") or target["roles"].get("owner")
            or any(f["qualifiers"].get(k) for f in (target, source) for k in ("scope", "attribution"))):
        return None

    def named(phrase, path=()):
        if phrase.get("names") and not phrase.get("unresolved"):
            yield path, phrase
        for modifier in phrase.get("modifiers", []):
            yield from named(modifier["phrase"], path + (modifier["relation"],))

    for row in match["bindings"]["argument_matches"]:
        if row["role"] in {"agent", "owner"} or row["status"] != "EXACT_SCOPED_ARGUMENT":
            continue
        wanted, offered = dict(named(row["target"])), dict(named(row["source"]))
        for path in wanted.keys() & offered.keys():
            a, b = wanted[path], offered[path]
            if (not set(a["names"]) <= set(b["terms"]) or not set(b["names"]) <= set(a["terms"])):
                continue
            return dict(kind="AGENTLESS_PASSIVE_MATCHED_REQUESTED_NAMED_ANCHOR",
                agent_obligation=False, role=row["role"], modifier_path=list(path),
                target_anchor=deepcopy(a), source_anchor=deepcopy(b),
                all_requested_roles_still_required=True, canonical_identity_certified=False,
                event_identity_certified=False)
    return None


def _speech_projection(target, source, match):
    projection = match.get("reporting_projection", {})
    if (match["direction"] != "SUPPORT" or target["kind"] != source["kind"]
            or projection.get("kind") != "ASSERTIVE_SPEECH_SPECIALIZATION_TO_SAY"
            or projection.get("not_reverse") is not True or projection.get("original_source_preserved") is not True
            or any(f["qualifiers"].get("negated") or any(s.get("negated")
                for s in f["qualifiers"].get("scope", [])) for f in (target, source))):
        return None
    pairs = [(target["predicate"], source["predicate"])]
    ts, ss = target["qualifiers"].get("scope", []), source["qualifiers"].get("scope", [])
    if len(ts) != len(ss):
        return None
    pairs.extend((t["predicate"], s["predicate"]) for t, s in zip(ts, ss))
    changed = [(t, s) for t, s in pairs if t != s]
    if (not changed or any(t != "say" or s not in scoped.native._ASSERTIVE_REPORTS - {"say"}
            or s not in projection.get("original_predicates", []) for t, s in changed)):
        return None
    return dict(projection, validated_positive_only=True,
        leaf_predicate_projected=target["predicate"] != source["predicate"],
        allowed_clock_pairs=[list(pair) for pair in sorted(set(changed))])


def _clock(frame, doc, *, with_heads=False):
    token = _token(frame, doc)
    if token is None:
        return None
    clocks = []
    for head in (token, *token.ancestors):
        if head.pos_ not in {"VERB", "AUX"}:
            continue
        auxiliaries = [c for c in head.children if c.dep_ in {"aux", "auxpass", "cop"}]
        finite = [t for t in (head, *auxiliaries) if t.tag_ in {"VBD", "VBP", "VBZ", "MD"}]
        if finite:
            clock = dict(tense="past" if any(t.tag_ == "VBD" for t in finite) else "present",
                progressive=head.tag_ == "VBG" and any(t.lemma_.casefold() == "be" for t in auxiliaries),
                perfect=any(t.lemma_.casefold() == "have" for t in auxiliaries))
            clocks.append((head, clock) if with_heads else clock)
        if head.dep_ == "ROOT":
            break
    return clocks or None


def _disjunctive(frame, doc):
    token = _token(frame, doc)
    return token is None or any(c.dep_ == "cc" and c.lower_ in {"or", "nor"}
        for head in (token, *token.ancestors) for c in head.children)


def _day_values(frame):
    values = []
    for proof in frame.get("event_dates", []):
        text = proof.get("text", proof.get("literal", ""))
        text = " ".join(text.replace(",", "").split())
        day = None
        for form in ("%Y-%m-%d", "%B %d %Y", "%d %B %Y"):
            try:
                day = datetime.strptime(text, form).date().isoformat()
                break
            except ValueError:
                pass
        if day is None:
            return []
        values.append(day)
    return values


def _counter_clock(target, source):
    if target["kind"] != "EVENT" or source["kind"] != "EVENT":
        return False
    if any(frame.get("deictic_time") or any(frame["qualifiers"].get(k)
            for k in ("scope", "attribution", "modality", "conditional", "question", "epistemic_absence", "unresolved"))
            for frame in (target, source)):
        return False
    wanted, offered = _day_values(target), _day_values(source)
    return bool(wanted) and wanted == offered


def _unrestricted_past(frame, doc):
    clock = _clock(frame, doc)
    return (bool(clock) and clock[-1]["tense"] == "past"
        and not frame.get("event_dates") and not frame.get("deictic_time")
        and not any(t.ent_type_ in {"DATE", "TIME"} or t.lower_ in {
            "now", "currently", "presently", "today", "tonight", "yesterday", "tomorrow",
            "recently", "ago", "since", "until", "during", "before", "after", "when"} for t in doc))


def _historical_clock(target, source, query_doc, source_doc, speech=None):
    """Project a positive source assertion, not its persistence or completion."""
    wanted, offered = _clock(target, query_doc), _clock(source, source_doc)
    if not _unrestricted_past(target, query_doc) or not offered or len(wanted) != len(offered):
        return None
    reductions = []
    target_heads = _clock(target, query_doc, with_heads=True)
    source_heads = _clock(source, source_doc, with_heads=True)
    for (th, a), (sh, b) in zip(target_heads, source_heads):
        literal_head = th.lemma_.casefold() == sh.lemma_.casefold()
        speech_head = speech and [th.lemma_.casefold(), sh.lemma_.casefold()] in speech["allowed_clock_pairs"]
        if a["tense"] != b["tense"] and (a["tense"] != "past" or b["tense"] != "present"):
            return None
        if a["perfect"] and not b["perfect"]:
            return None
        if a["progressive"] != b["progressive"]:
            # "Was considering doing" attests consideration, never doing.
            # This license cannot turn "was opening" into a completed opening.
            scoped_heads = all(any(s["predicate"] == h.lemma_.casefold()
                for s in f["qualifiers"].get("scope", [])) for f, h in ((target, th), (source, sh)))
            if a["progressive"] or not scoped_heads or not (literal_head or speech_head):
                return None
            reductions.append(dict(kind="PROGRESSIVE_QUALIFYING_SCOPE_NOT_INNER_COMPLETION",
                target_proof=scoped.matching.proof(th), source_proof=scoped.matching.proof(sh)))
        if b["perfect"] and not a["perfect"]:
            reductions.append(dict(kind="EXPLICIT_PERFECT_TO_UNDATED_PAST_ASCRIPTION",
                target_proof=scoped.matching.proof(th), source_proof=scoped.matching.proof(sh)))
        if not (literal_head or speech_head):
            return None
    return dict(policy=HISTORICAL_SOURCE_ASCRIPTION, target_clock=wanted, source_clock=offered,
        temporal_form_projected=wanted != offered, source_attestation_not_persistence=True,
        source_publication_is_ascription_date_only=True, precise_event_time_certified=False,
        continued_tenure_at_query_cutoff_certified=False, aspect_projections=reductions)


def _compare(target, source, engine, query_doc, source_doc):
    match = scoped.compare_frames(target, source, engine=engine)
    if match is None:
        return None
    match = deepcopy(match)
    # An exact qualified complement may be attested without deciding who would
    # perform it. The named matrix holder is not inherited as the inner actor.
    if (match["direction"] == "RELATED" and match["reasons"] == [
            "EMBEDDED_EVENT_ACTOR_BINDING_UNRESOLVED_NOT_EVENT_EVIDENCE"]
            and _named_actor(target) and _named_actor(source)):
        tt, st = _token(target, query_doc), _token(source, source_doc)
        normalize = lambda text: " ".join(text.casefold().split())
        if (tt is not None and st is not None and tt.dep_ == st.dep_ == "xcomp"
                and not target["roles"].get("agent") and not source["roles"].get("agent")
                and target["qualifiers"].get("scope") and source["qualifiers"].get("scope")
                and all(d["status"] in {"MATCH", "UNSPECIFIED"} for k, d in match["diagnostics"].items()
                    if k != "actor")
                and normalize(query_doc.text[tt.left_edge.idx:tt.right_edge.idx + len(tt.right_edge)]) ==
                    normalize(source_doc.text[st.left_edge.idx:st.right_edge.idx + len(st.right_edge)])):
            match.update(direction="SUPPORT", qualified_complement_certificate=dict(
                kind="EXACT_XCOMP_CONTENT_AND_LITERAL_NAMED_MATRIX_HOLDER",
                inner_actor_certified=False, inner_execution_certified=False,
                target_start=tt.left_edge.idx, target_end=tt.right_edge.idx + len(tt.right_edge),
                source_start=st.left_edge.idx, source_end=st.right_edge.idx + len(st.right_edge)))
            match["reasons"].append("QUALIFIED_SOURCE_CONTENT_NOT_INNER_EVENT_EVIDENCE")
    failures = []
    speech = _speech_projection(target, source, match)
    if (target["kind"] != source["kind"]
            or (target["predicate"] != source["predicate"] and not speech)):
        failures.append("LITERAL_PREDICATE_AND_FRAME_KIND_REQUIRED")
    passive_anchor = _passive_anchor(target, source, match)
    if (not _named_actor(target) or not _named_actor(source)) and passive_anchor is None:
        failures.append("ACTOR_OR_HOLDER_IDENTITY_NOT_BOUND_BY_LITERAL_NAME")
    if _disjunctive(target, query_doc) or _disjunctive(source, source_doc):
        failures.append("DISJUNCTIVE_ASSERTION_NOT_A_CONJUNCTIVE_WITNESS")
    ascription = (_historical_clock(target, source, query_doc, source_doc, speech)
        if match["direction"] == "SUPPORT" else None)
    if (_clock(target, query_doc) is None or _clock(target, query_doc) != _clock(source, source_doc)) and not ascription:
        failures.append("TENSE_OR_ASPECT_NOT_ALIGNED")
    if target["kind"] in {"PROPERTY", "NOMINAL_RELATION"} and _clock(target, query_doc) and \
            _clock(target, query_doc)[0]["tense"] == "present" and not target.get("event_dates"):
        failures.append("PRESENT_STATE_NOT_CASE_DATE_PERSISTENCE")
    if match["direction"] == "COUNTER" and not _counter_clock(target, source):
        failures.append("OPPOSITION_REQUIRES_SAME_EXPLICIT_EVENT_DAY_NOT_PUBLICATION")
    qualified_content = bool(target["qualifiers"].get("scope")) and all(
        not scope.get("negated") for scope in target["qualifiers"]["scope"])
    if (match["direction"] == "SUPPORT" and target["qualifiers"].get("negated")
            and not qualified_content and not _counter_clock(target, source)):
        failures.append("UNTIMED_NEGATIVE_WORLD_CLAIM_NOT_A_SOURCE_CLOCK_CERTIFICATE")
    if match["direction"] == "SUPPORT" and any(s.get("negated") for s in target["qualifiers"].get("scope", [])):
        failures.append("NEGATED_MATRIX_REQUIRES_ITS_OWN_BOUND_EVENT_CLOCK")
    if failures and match["direction"] in {"SUPPORT", "COUNTER"}:
        match["direction"] = "PARTIAL"
    match["narrative_guard_issues"] = failures
    match["target_predicate_proof"] = deepcopy(target["predicate_proof"])
    match["source_predicate_proof"] = deepcopy(source["predicate_proof"])
    match["historical_source_ascription"] = ascription
    match["validated_speech_projection"] = speech
    match["applicable_passive_identity"] = passive_anchor
    match.update(canonical_identity_certified=False, aliases_or_homonyms_resolved=False,
        publication_date_used_as_event_time=False, world_truth_certified=False)
    return match


@lru_cache(maxsize=512)
def _authority_role_links(noun, verb):
    """Only literal agentive authority roles, not arbitrary deverbal events."""
    from matryoshka_demo.roles import lexicon
    try:
        wn = lexicon()
        links = []
        for sense in wn.synsets(noun, pos="n"):
            if sense.lexname() != "noun.person" or not any(a.name() == "leader.n.01"
                    for path in sense.hypernym_paths() for a in path):
                continue
            for lemma in sense.lemmas():
                if lemma.name() != noun:
                    continue
                for related in lemma.derivationally_related_forms():
                    if related.name() == verb and related.synset().lexname() == "verb.social":
                        links.append(dict(noun_synset=sense.name(), verb_synset=related.synset().name(),
                            relation="DIRECT_DERIVATION_OF_PERSON_AUTHORITY_ROLE", wordnet_version=wn.get_version()))
        return links
    except LookupError:
        return []


def _authority_role_certificate(targets, compiled, query_doc, source_doc, prefix_blocked):
    """An explicit ORG authority-role NAME NP attests a historical role only."""
    if prefix_blocked or not compiled["complete"] or len(targets) != 1:
        return None
    target = targets[0]
    if (target["kind"] != "EVENT" or set(target["roles"]) != {"agent", "patient"}
            or not _unrestricted_past(target, query_doc)
            or any(c["progressive"] or c["perfect"] for c in _clock(target, query_doc))
            or target.get("unbound_arguments")):
        return None
    q = target["qualifiers"]
    if any(q.get(k) for k in ("negated", "scope", "attribution", "modality", "conditional",
            "question", "epistemic_absence", "unresolved", "manner", "role_qualifiers")):
        return None
    args = [target["roles"][k] for k in ("agent", "patient")]
    if any(len(a) != 1 for a in args):
        return None
    actor, organization = [a[0] for a in args]
    if any(not p["names"] or any(p.get(k) for k in
            ("unresolved", "modifiers", "quantifiers", "role_qualifiers")) for p in (actor, organization)):
        return None
    spelling = lambda tokens: [t.text.casefold() for t in tokens if not t.is_space]
    wanted_actor = [p["text"].casefold() for p in actor["proofs"]]
    wanted_org = [p["text"].casefold() for p in organization["proofs"]]
    for role in source_doc:
        links = _authority_role_links(role.lemma_.casefold(), target["predicate"]) if role.pos_ == "NOUN" else []
        head = role.head
        if not links or role.dep_ != "compound" or head.pos_ != "PROPN" or head.i <= role.i:
            continue
        name = [t for t in source_doc[role.i + 1:head.i + 1] if not t.is_space]
        if (spelling(name) != wanted_actor or any(t.pos_ != "PROPN" or
                (t != head and (t.head != head or t.dep_ not in {"compound", "flat"})) for t in name)):
            continue
        org = sorted((t for t in role.subtree if t != role and not t.is_space), key=lambda t: t.i)
        if (spelling(org) != wanted_org or not org or org[-1].i != role.i - 1
                or any(t.i >= role.i or t.pos_ not in {"NOUN", "PROPN", "ADJ"} for t in org)):
            continue
        allowed = {t.i for t in (*name, *org, role)}
        if any(t.i not in allowed and t.dep_ not in {"det", "punct", "cc", "conj"}
                and not t.is_space for t in head.children):
            continue
        # Inspect the complete governing path, never an isolated NP that loses
        # a report, hypothetical, modal, negation or uncertain role modifier.
        path = (role, head, *head.ancestors)
        qualified = [scoped.matching.qualifiers(t) for t in path]
        if any(any(q.get(k) for k in ("negated", "scope", "attribution", "modality", "conditional",
                "question", "epistemic_absence", "unresolved")) for q in qualified):
            continue
        if (_disjunctive(dict(predicate=role.lemma_.casefold(),
                predicate_proof=scoped.matching.proof(role)), source_doc)
                or any(t.is_quote for t in role.sent)):
            continue
        return dict(kind="LITERAL_AUTHORITY_ROLE_SOURCE_ASCRIPTION", policy=HISTORICAL_SOURCE_ASCRIPTION,
            grammar="ORG_AUTHORITY_NOUN_LITERAL_FULL_NAME", role_proof=scoped.matching.proof(role),
            actor_proofs=[scoped.matching.proof(t) for t in name],
            organization_proofs=[scoped.matching.proof(t) for t in org], lexical_links=deepcopy(links),
            source_attestation_not_persistence=True, completed_action_certified=False,
            continued_tenure_at_query_cutoff_certified=False, precise_event_time_certified=False,
            source_governing_qualifiers=qualified, source_text_modified=False)
    return None


def _whole_clause_certificate(atom, text, compiled, doc, prefix_blocked):
    """A complete literal past assertion may outstrip the leaf-frame extractor."""
    if (prefix_blocked or atom.get("kind", "proposition") != "proposition"
            or atom["text"] != text or not compiled["complete"]
            or len(compiled["propositions"]) != 1):
        return None
    proposition = compiled["propositions"][0]
    if (proposition["kind"] != "EVENT" or proposition["tense"] != "past"
            or proposition["negated"] or proposition["modality"]):
        return None
    roots = [t for t in doc if t.dep_ == "ROOT"]
    if len(roots) != 1:
        return None
    root = roots[0]
    subjects = [t for t in root.children if t.dep_ in {"nsubj", "nsubjpass", "csubj"}]
    if (len(subjects) != 1 or subjects[0].pos_ != "PROPN"
            or any(t.pos_ == "PRON" for t in subjects[0].subtree)):
        return None
    # A named first clause cannot lend identity to an independently asserted
    # generic-title conjunct. Complement content remains literal and qualified.
    for token in doc:
        if token.dep_ != "conj" or token.pos_ not in {"VERB", "AUX"}:
            continue
        if not any(t.dep_ in {"ccomp", "xcomp", "acl", "relcl"} for t in token.ancestors if t != root):
            return None
    return dict(kind="EXACT_WHOLE_PAST_CLAUSE_SOURCE_ATTESTATION", raw_byte_equality=True,
        complete_matrix_and_all_subordinate_content=True,
        named_matrix_subject=dict(text=subjects[0].text, start=subjects[0].idx,
            end=subjects[0].idx + len(subjects[0])),
        matrix=deepcopy(proposition["matrix"]),
        source_attestation_not_persistence=True, embedded_event_execution_certified=False,
        canonical_identity_certified=False, unqualified_world_truth=False)


class MatcherCase:
    """One explicit frozen query/source view, with no ambient cross-case cache."""
    def __init__(self, case, source_index, *, engine=None, corpus=None, source_policy=None):
        if case.get("task") not in {"hypothesis", "reconstruction"}:
            raise ValueError("Use the explicit public-task compatibility boundary; H/M only")
        self.case = public_case(case)
        self.source_index_argument = source_index
        base = engine or scoped.Engine()
        self.public_acronyms = _public_acronyms(self.case, base)
        self.engine, self.analysis_policy = build_engine(base, self.case, acronyms=self.public_acronyms)
        if source_policy is not None:
            if public_case(source_policy.case) != self.case:
                raise ValueError("Precomputed source policy belongs to another public case")
            self.policy = source_policy
            self.corpus = source_policy.corpus
        else:
            if corpus is None:
                if isinstance(source_index, Mapping):
                    pages = deepcopy(list(source_index.values()))
                elif hasattr(source_index, "execute"):
                    pages = [json.loads(row[0]) for row in source_index.execute("SELECT payload FROM main.page")]
                    source_index = {p["id"]: p for p in pages}
                else:
                    raise ValueError("Complete explicit source-page mapping/index required")
                if not pages:
                    raise ValueError("Nonempty complete source index required")
                corpus = SimpleNamespace(corpus=self.case["corpus"], pages=pages)
            self.corpus = corpus
            self.policy = SourcePolicy(corpus, self.case, source_index)
        self.positions = {p["id"]: i for i, p in enumerate(self.corpus.pages)}
        self.query_cache, self.unit_cache = {}, {}

    def supplement(self, atom, page, unit):
        return _supplement(self, atom, page, unit)


def supplement_evidence(case, atom, page, unit, engine=None, *, source_index, matcher=None):
    """Return one source-unit appraisal, retaining partial/unknown diagnostics.

    Only SUPPORT/COUNTER/CONFLICTED are signed evidence. PARTIAL is not backing.
    The complete index is mandatory for whole-document handling vetoes. This
    function neither joins units nor changes a baseline decision or source text.
    """
    matcher = matcher or MatcherCase(case, source_index, engine=engine)
    if matcher.case != public_case(case):
        raise ValueError("Cached matcher belongs to another public query/source policy")
    if matcher.source_index_argument is not source_index:
        raise ValueError("Cached matcher belongs to another explicit source index")
    return matcher.supplement(atom, page, unit)


def _supplement(matcher, atom, page, unit):
    case, engine, corpus, policy = matcher.case, matcher.engine, matcher.corpus, matcher.policy
    public_plan(case, dict(atoms=[atom], query_sha256=digest(case["query"])))
    pi = matcher.positions.get(page.get("id"))
    if pi is None or any(page.get(k) != corpus.pages[pi].get(k) for k in
            ("id", "text", "document_id", "date", "source_sha256", "classification", "permitted", "visibility", "corpus")):
        raise ValueError("Source page differs from the complete bound index")
    a, b = unit.get("start"), unit.get("end")
    text = unit.get("text", unit.get("quote"))
    if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(page["text"]) or page["text"][a:b] != text:
        raise ValueError("Source unit quotation does not replay")
    citation = policy.citation(pi, a, b)
    with offline():
        from matryoshka_current.proposition_matching import compile_proposition
        from matryoshka_next.decisions import _prefix_blocker
        key = digest(atom)
        if key not in matcher.query_cache:
            matcher.query_cache[key] = (compile_proposition(atom["text"], engine=engine),
                engine.targets(atom["text"]), engine.parse(atom["text"]))
        compiled, targets, query_doc = matcher.query_cache[key]
        source_key = (page["id"], page["source_sha256"], a, b)
        if source_key not in matcher.unit_cache:
            matcher.unit_cache[source_key] = (engine.targets(text), engine.parse(text))
        offered, source_doc = matcher.unit_cache[source_key]
        issues = list(compiled["issues"])
        uncovered = _covered_query(targets, query_doc)
        if uncovered:
            issues.append("REQUIRED_QUERY_CONTENT_NOT_REPRESENTED_BY_TARGET_FRAMES")
        if not targets or atom.get("kind", "proposition") != "proposition":
            issues.append("NO_COMPLETE_DECLARATIVE_TARGET_FRAME")
        prefix_blocked = bool(_prefix_blocker(page, a, engine))
        if prefix_blocked:
            issues.append("UNBOUND_PRECEDING_SOURCE_QUALIFICATION")
        comparisons = [[_compare(t, s, engine, query_doc, source_doc) for s in offered] for t in targets]
        comparisons = [[m for m in row if m is not None] for row in comparisons]
    support = bool(comparisons) and all(any(m["direction"] == "SUPPORT" for m in row) for row in comparisons)
    counter = bool(comparisons) and all(any(m["direction"] in {"SUPPORT", "COUNTER"} for m in row)
        for row in comparisons) and any(any(m["direction"] == "COUNTER" for m in row) for row in comparisons)
    partial = any(any(m["direction"] in {"SUPPORT", "PARTIAL"} for m in row) for row in comparisons)
    direction = ("PARTIAL" if issues and partial else "UNRESOLVED" if issues else "CONFLICTED" if support and counter else "SUPPORT" if support
        else "COUNTER" if counter else "PARTIAL" if partial else "UNRESOLVED")
    certificate = (_whole_clause_certificate(atom, text, compiled, query_doc, prefix_blocked)
        if direction in {"PARTIAL", "UNRESOLVED"} else None)
    if certificate is not None:
        direction = "SUPPORT"
    role_certificate = (_authority_role_certificate(targets, compiled, query_doc, source_doc, prefix_blocked)
        if not issues and direction in {"PARTIAL", "UNRESOLVED"} else None)
    if role_certificate is not None:
        direction = "SUPPORT"
    predicates = {m["source_predicate_proof"]["start"] for row in comparisons for m in row
        if m["direction"] in {"SUPPORT", "COUNTER"}}
    if certificate is not None:
        predicates = {certificate["matrix"]["start"]}
    return dict(version=VERSION, direction=direction, citation=citation, comparisons=comparisons,
        analysis_policy=deepcopy(matcher.analysis_policy),
        required_frame_count=len(targets), complete_required_frames=direction in {"SUPPORT", "COUNTER", "CONFLICTED"},
        event_bindings=[digest([page["id"], a + p]) for p in sorted(predicates)],
        query_issues=sorted(set(issues)), uncovered_query_tokens=uncovered,
        whole_clause_certificate=certificate,
        role_ascription_certificate=role_certificate,
        source_ascription_policy=HISTORICAL_SOURCE_ASCRIPTION,
        source_ascription_date=citation["date"] if direction == "SUPPORT" else None,
        source_attestation_not_persistence=direction == "SUPPORT",
        frame_extraction_complete=not issues,
        checks=dict(eligible_source="PASS", literal_quote="PASS", all_query_frames="PASS" if not issues else "UNRESOLVED",
            independent_source_assertions_may_be_extra=True, topical_relevance_used_as_proof=False),
        source_text_modified=False, baseline_decision_modified=False, unit_join_performed=False,
        actual_inner_event_established=False, world_truth_certified=False,
        publication_date_used_as_event_time=False, api_calls=0)
