"""Snapshot the existing opaque overlay, never concealed values or a new topology."""
import json


def export_slots(worker, maps, cases):
    from matryoshka_current.slot_overlay import SlotOverlay
    overlay = SlotOverlay(maps, cases)
    coverage, parity = [], []
    for corpus in ('cib', 'iran', 'vietnam'):
        raw, _ = maps.packet('/api/graph-v4-viewer?corpus=' + corpus)
        binding = json.loads(raw)
        params = dict(corpus=[corpus], graph_id=[binding['graph_run_id']], hierarchy_id=[binding['hierarchy_run_id']], limit=['1'])
        overlay.packet(params)
        index = overlay.corpora[corpus]
        while index.cursor < len(index.files):
            worker.stage.guard()
            index.scan_one()
        slots, details, page_paths = [], {}, {}
        records = []
        for row in index.rows:
            record = index.record(row)
            record_path = '/data/slots/' + corpus + '/records-' + str(len(slots) // 128) + '.json'
            thin = {k: record[k] for k in ('id', 'slot_id', 'document_id', 'date', 'context_preview', 'domain_id', 'theme_id', 'community_id')}
            thin.update(anchors=[dict(id=a['id']) for a in record['anchors']], record_path=record_path)
            records.append(record)
            if len(records) == 128:
                worker.put(record_path, records.copy())
                records.clear()
            slots.append(thin)
            page_key = row['page_key']
            if page_key not in page_paths:
                _, page = index.detail(row['id'])
                import hashlib
                token = hashlib.sha256(json.dumps(page_key).encode()).hexdigest()
                path = '/data/slots/' + corpus + '/' + token + '.json'
                worker.put(path, page)
                page_paths[page_key] = path
            details[row['id']] = page_paths[page_key]
        if records:
            worker.put(record_path, records)
        status = index.status()
        worker.put('/data/slots/' + corpus + '.json', dict(status=status, slots=slots, details=details))
        queries = [dict(limit='1'), dict(limit='32', offset='32'), dict(q='nonexistentprobevalue')]
        if slots:
            first = slots[0]
            queries.extend((dict(q=first['document_id']), dict(slot_id=first['id'])))
            if first['anchors']:
                queries.append(dict(anchor_id=first['anchors'][0]['id']))
            for key in ('domain_id', 'theme_id', 'community_id'):
                if first.get(key):
                    queries.append({key: first[key]})
        for selectors in queries:
            selected = dict(corpus=corpus, graph_id=binding['graph_run_id'], hierarchy_id=binding['hierarchy_run_id'], **selectors)
            expected = overlay.packet({k: [v] for k, v in selected.items()})
            parity.append(dict(params=selected, expected=expected))
        coverage.append(dict(corpus=corpus, slots=len(slots), pages=len(page_paths), coverage=status['coverage'],
            graph_run_id=binding['graph_run_id'], hierarchy_run_id=binding['hierarchy_run_id']))
        print(json.dumps(dict(slots_corpus=corpus, slots=len(slots), pages=len(page_paths))), flush=True)
        overlay.corpora.clear()
    worker.stage.write('slots-parity.json', json.dumps(parity, sort_keys=True, separators=(',', ':')).encode())
    return coverage
