"""Bounded existing-wire measurement only; never re-parse a graph or alter it."""
import argparse
import gzip
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--pdf', action='store_true')
    args = parser.parse_args()
    stage, output = args.stage.resolve(), args.output.absolute()
    assert stage.is_relative_to(HERE) and output.is_relative_to(HERE) and not output.exists()
    paths = sorted((stage / ('site/data/replays' if args.pdf else 'site/data/packet-pack/chunks')).glob('*.pdf' if args.pdf else '*.json.gz'))
    sample = [paths[i * (len(paths)-1) // 31] for i in range(32)]
    old, new, decoded = 0, 0, 0
    started = time.monotonic()
    for path in sample:
        wire = path.read_bytes()
        raw = wire if args.pdf else gzip.decompress(wire)
        old += len(wire)
        new += len(gzip.compress(raw, compresslevel=9, mtime=0))
        decoded += len(raw)
    value = dict(chunks_sampled=len(sample), kind='PDF' if args.pdf else 'fragment_chunks', existing_wire_bytes=old, level9_wire_bytes=new, decoded_bytes=decoded,
        ratio=new / old, elapsed_seconds=round(time.monotonic()-started, 3),
        existing_chunks_modified=False, api_calls=0, native_executions=0)
    output.write_text(json.dumps(value, indent=2) + '\n')
    print(json.dumps(value))


if __name__ == '__main__':
    main()
