"""Explicit, byte-preserving outward guide assets bound to one saved report."""
import hashlib
import json
from pathlib import Path


TARGETS = {'field-guide.pdf': 'docs/matryoshka-guide.pdf',
    'field-guide.txt': 'docs/matryoshka-guide.txt', 'guide-public.json': 'docs/guide-public.json'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def assets(root, directory, report_ref, inputs):
    if directory is None:
        return None
    root = Path(root).resolve()
    directory = Path(directory)
    directory = directory.absolute() if directory.is_absolute() else (root / directory).absolute()
    require(directory.resolve() == directory and directory.is_dir() and directory.is_relative_to(root),
        'Field guide must be an explicit nonsymlinked directory under the source root')
    source = directory.relative_to(root)
    path = directory / 'guide-public.json'
    require(path.resolve() == path and path.is_file(), 'Missing or unsafe guide-public.json')
    guide_ref = dict(path=(source / path.name).as_posix(), sha256=sha(path.read_bytes()))
    guide = json.loads(inputs.raw(root, guide_ref))
    require(guide.get('version') == 'evidence-field-guide/1' and guide.get('mode') == 'saved_report_snapshot',
        'Field guide must be a saved report snapshot, not an unbound draft')
    require(guide.get('report_byte_sha256') == report_ref['sha256'], 'Field guide report binding differs')
    report = json.loads(inputs.raw(root, report_ref))
    cases = {r['case']['case_id']:r['case'] for r in report['cases']}
    described = guide.get('cases', [])
    ids = [r.get('case_id') for r in described]
    require(len(ids) == len(set(ids)) == len(cases) and set(ids) == set(cases), 'Field guide case coverage differs')
    for row in described:
        case = cases[row['case_id']]
        require(row.get('query_utf8_sha256') == sha(case['query'].encode('utf-8'))
            and row.get('corpus') == case['corpus'] and row.get('task') == case['task'],
            'Field guide public case/query binding differs')
    require(set(guide.get('files', {})) == {'field-guide.pdf', 'field-guide.txt'}, 'Unexpected outward guide file inventory')
    selected = []
    for name, target in TARGETS.items():
        ref = guide_ref if name == 'guide-public.json' else dict(path=(source / name).as_posix(), sha256=guide['files'][name])
        raw = inputs.raw(root, ref)
        if name.endswith('.pdf'):
            require(raw.startswith(b'%PDF-'), 'Field guide is not a PDF')
        elif name.endswith('.txt'):
            raw.decode('utf-8')
        selected.append(dict(source_ref=ref, target=target, public_sha256=sha(raw)))
    return dict(version='source-bound-field-guide/1', source_report_ref=report_ref, guide_public_ref=guide_ref,
        source_mode=guide['mode'], cases=ids, pdf_pages=guide.get('pdf_pages'), assets=selected,
        publication_qualification_inferred=False, bytes_modified=False)


def install(stage, root, selection, inputs):
    lineage = []
    for row in selection['assets']:
        raw = inputs.raw(root, row['source_ref'])
        require(sha(raw) == row['public_sha256'], 'Field guide changed after validation')
        stage.write('site/' + row['target'], raw)
        lineage.append(dict(path=row['target'], source_ref=row['source_ref'], source_sha256=sha(raw),
            public_sha256=sha(raw), report_sha256=selection['source_report_ref']['sha256'], scope='EXPLICIT_REPORT_BOUND_FIELD_GUIDE'))
    return lineage
